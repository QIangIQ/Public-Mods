return {
	mod_name = {
		en = "QIangIQ's Zealot Deflect",
	},
	mod_description = {
		en = "Adds Deflect, a new Zealot combat ability, to the legacy Zealot tree from QIangIQs Legacy Talents. Plant your feet for 4 seconds: every enemy melee attack is parried and hits back for 40%% of the attacker's max health (20%% for bosses) with the heaviest stagger, ranged damage is cut by 60%%, you can't be knocked back, Trapper nets and Pox Hound pounces miss, and a Mutant that tries to grab you dies. Legacy trees only, so Fatshark missions are untouched. Every player in a Realms game needs this mod.",
	},
	talent_name = {
		en = "Deflect",
	},
	talent_description = {
		en = "Plant your feet and raise a perfect guard for {duration:%%s} seconds. You cannot move, dodge, jump or sprint, but every enemy melee attack from any direction is parried and deals 40%% of the attacker's max health back to it, or 20%% for bosses, and staggers it as hard as the game allows.\n\nWhile active you take 60%% less ranged damage, cannot be knocked back, staggered or launched, Trapper nets and Pox Hound pounces miss you, and any Mutant that tries to grab you is killed. You can still attack.\n\nCooldown: {cooldown:%%s} seconds.",
	},
	augment_horde_kill_name = {
		en = "Deflect: Cull the Masses",
	},
	augment_horde_kill_description = {
		en = "While Deflect is active, any horde or roamer enemy whose melee attack you deflect dies instantly. Elites, specialists and bosses are not affected.",
	},
	augment_toughness_name = {
		en = "Deflect: Unbroken Faith",
	},
	augment_toughness_description = {
		en = "While Deflect is active, you regenerate 30%% of your maximum toughness every second.",
	},
	command_description = {
		en = "Shows whether Zealot Deflect is in the legacy Zealot tree.",
	},
}
