local mod = get_mod("QIangIQsZealotDeflect")

-- Deflect: a Zealot combat ability for the legacy (1.6.1) Zealot tree from
-- QIangIQsLegacyTalents. Instant cast like the stance abilities: the player
-- is rooted for DURATION seconds and every enemy melee hit counts as a perfect
-- block. Each blocked hit deals REFLECT_HEALTH_FRACTION of the attacker's max
-- health back to it (BOSS_REFLECT_HEALTH_FRACTION for bosses) plus the
-- heaviest stagger. Ranged damage
-- taken is cut by 60%, the player cannot be knocked back, staggered or
-- launched, Trapper nets and Pox Hound pounces miss, and a Mutant that tries
-- to grab the player dies instead.
--
-- The node only goes into the legacy nodes table, so it exists only while
-- QIangIQsLegacyTalents runs legacy data (Realms, SoloPlay, Psykhanium). On
-- Fatshark's mission servers the official tree is used and nothing here runs:
-- every hook below does nothing unless the Deflect buff is on the unit.

local AttackSettings = require("scripts/settings/damage/attack_settings")
local ArchetypeTalents = require("scripts/settings/ability/archetype_talents/archetype_talents")
local Breed = require("scripts/utilities/breed")
local BuffSettings = require("scripts/settings/buff/buff_settings")
local BuffTemplates = require("scripts/settings/buff/buff_templates")
local DamageProfileTemplates = require("scripts/settings/damage/damage_profile_templates")
local DamageSettings = require("scripts/settings/damage/damage_settings")
local EffectTemplates = require("scripts/settings/fx/effect_templates")
local PlayerAbilities = require("scripts/settings/ability/player_abilities/player_abilities")
local PowerLevelSettings = require("scripts/settings/damage/power_level_settings")
local Stagger = require("scripts/utilities/attack/stagger")
local StaggerSettings = require("scripts/settings/damage/stagger_settings")

local attack_results = AttackSettings.attack_results
local attack_types = AttackSettings.attack_types
local damage_efficiencies = AttackSettings.damage_efficiencies
local damage_types = DamageSettings.damage_types
local keywords = BuffSettings.keywords
local proc_events = BuffSettings.proc_events
local stat_buffs = BuffSettings.stat_buffs

local DURATION = 4
local COOLDOWN = 45
local REFLECT_HEALTH_FRACTION = 0.4
local BOSS_REFLECT_HEALTH_FRACTION = 0.2
local RANGED_DAMAGE_TAKEN = 0.4

local TALENT_NAME = "qiangiq_zealot_deflect"
local ABILITY_NAME = "qiangiq_zealot_deflect"
local BUFF_NAME = "qiangiq_zealot_deflect_stance"
local EFFECT_TEMPLATE_NAME = "qiangiq_zealot_deflect_aura"
local NODE_NAME = "node_qiangiq_zealot_deflect"
local LOC_NAME = "loc_qiangiq_zealot_deflect"
local LOC_DESCRIPTION = "loc_qiangiq_zealot_deflect_description"

local LAYOUT_PATH = "scripts/ui/views/talent_builder_view/layouts/zealot_tree"

-- 1.6.1 zealot_tree.lua: the two stat nodes above the Chastise the Wicked
-- (node_5bf70f4d, x 729) and Bolstering Prayer (node_c286494b, x 1059)
-- ability nodes. Deflect sits between those two ability nodes.
local PARENT_NODES = {
	"node_7dc8720d-c371-47a4-8f77-39264310fdb3",
	"node_2a4793f6-24fb-4f75-b087-9e763d5cc694",
}
local NODE_X, NODE_Y = 894, 1560

-- Augments: ability_modifier nodes hanging under Deflect, in the space Holy
-- Cause left (1.6.1 x 965, y 1745) at the height of the 1.6.1 Banishing Light
-- modifier (y 1715). Each talent's passive adds a marker buff that the stance
-- checks for, the way 1.6.1 passives add their buff (zealot_talents.lua
-- zealot_improved_stun_grenade).
local AUGMENT_HORDE_KILL = "qiangiq_zealot_deflect_horde_kill"
local AUGMENT_TOUGHNESS = "qiangiq_zealot_deflect_toughness"
local TOUGHNESS_PER_SECOND = 0.3
local AUGMENTS = {
	{
		talent = AUGMENT_HORDE_KILL,
		node = "node_qiangiq_zealot_deflect_horde_kill",
		icon = "content/ui/textures/icons/talents/zealot/zealot_multi_hits_increase_damage",
		loc_name = "loc_qiangiq_zealot_deflect_horde_kill",
		loc_description = "loc_qiangiq_zealot_deflect_horde_kill_description",
		mod_name_key = "augment_horde_kill_name",
		mod_description_key = "augment_horde_kill_description",
		x = 834,
		y = 1715,
	},
	{
		talent = AUGMENT_TOUGHNESS,
		node = "node_qiangiq_zealot_deflect_toughness",
		icon = "content/ui/textures/icons/talents/zealot/zealot_toughness_in_melee",
		loc_name = "loc_qiangiq_zealot_deflect_toughness",
		loc_description = "loc_qiangiq_zealot_deflect_toughness_description",
		mod_name_key = "augment_toughness_name",
		mod_description_key = "augment_toughness_description",
		x = 954,
		y = 1715,
	},
}
-- 1.6.1 zealot_tree.lua: the Bolstering Prayer modifiers use this ramp.
local AUGMENT_GRADIENT = "content/ui/textures/color_ramps/class_node_colors/zealot_01"

-- 1.6.1 zealot_tree.lua: the two stat nodes under the ability row that lead
-- into the lower half of the tree. Deflect links down to both.
local CHILD_NODES = {
	"node_f9919123-5c32-4bbe-a1c1-6adb84e2286f",
	"node_7f263cb5-3031-4d9d-8c8a-8d2b83683105",
}

-- Extra two-way links { parent, child } for the new middle layout: Bolstering
-- Prayer also hangs off the stat node above Shroudfield, and Banishing Light
-- also leads down to the stat node under Shroudfield.
local EXTRA_LINKS = {
	{ "node_0c22fa98-2651-45b4-8ae8-d7d777a0b529", "node_c286494b-4e57-42a2-9c41-04809ee97c41" },
	{ "node_8922b54d-6532-4ac0-910f-c12a9e77bb01", "node_228ca33d-e567-42c7-8ff2-316ce4464a5b" },
}

-- Middle of the tree: Deflect sits between the left and middle stat nodes,
-- Bolstering Prayer between the middle and right ones, with Banishing Light
-- under it and Ecclesiarch's Call / Holy Cause forking off to its right.
-- Shroudfield and its modifiers move right to make room. Each move only
-- applies when the node still sits at its 1.6.1 position.
-- { x, y } before -> { x, y } after (1.6.1 layout units, before
-- smaller_talent_tree scales them).
local NODE_MOVES = {
	-- zealot_bolstering_prayer
	["node_c286494b-4e57-42a2-9c41-04809ee97c41"] = { 1059, 1569, 1212, 1569 },
	-- zealot_channel_staggers (Banishing Light), under Bolstering Prayer
	["node_8922b54d-6532-4ac0-910f-c12a9e77bb01"] = { 1085, 1715, 1233, 1715 },
	-- zealot_channel_grants_damage (Ecclesiarch's Call), up and right of Banishing Light
	["node_518fc5ca-a334-46b2-9177-42cc04f43002"] = { 1205, 1745, 1325, 1640 },
	-- zealot_channel_grants_toughness_damage_reduction (Holy Cause), down and right of Banishing Light
	["node_72c78ca8-a422-429a-90cf-b85d0b36aa19"] = { 965, 1745, 1355, 1753 },
	-- zealot_stealth (Shroudfield) and its modifiers
	["node_f1b10508-b92d-45c4-8661-941d3eadac13"] = { 1359, 1599, 1439, 1599 },
	["node_374f4845-26ff-40f4-a893-75b4e4ac324d"] = { 1535, 1655, 1615, 1655 },
	["node_d4c52149-9efe-492d-947e-f4c9e1b4bef7"] = { 1595, 1775, 1675, 1775 },
	["node_748ebcf8-f38e-4ff1-badf-8f74f9b2efb7"] = { 1445, 1745, 1525, 1745 },
}

-- Textures the current game already draws in the Zealot tree and HUD.
local NODE_ICON = "content/ui/textures/icons/talents/zealot/zealot_defensive_knockback"
local BUFF_HUD_ICON = "content/ui/textures/icons/buffs/hud/zealot/zealot_defensive_knockback"
-- The HUD draws hud_icon as the talent_icon of a material, the same as the
-- holier_revenant mod does with a talent texture (zealot_2_base_2), so the
-- Deflect node's own talent texture shows on the HUD too.
local ABILITY_HUD_ICON = NODE_ICON
local ABILITY_ICON = "content/ui/materials/icons/abilities/ultimate/default"

-- Zealot's own Resist Death effects (zealot_buff_templates.lua, zealot_resist_death).
local SCREEN_EFFECT = "content/fx/particles/screenspace/screen_zealot_invincibility"
local LOOP_START = "wwise/events/player/play_ability_zealot_maniac_resist_death_on"
local LOOP_STOP = "wwise/events/player/play_ability_zealot_maniac_resist_death_off"
-- The Havoc/Mortis shield hit sound (hordes_buff_templates.lua reduced_damage_hit),
-- played to the Deflect player on each deflected hit.
local DEFLECT_HIT_SOUND = "wwise/events/player/play_horde_mode_buff_shield_hit"
-- Force sword block shimmer (player_character_particle_aliases.lua,
-- force_weapon_block default), loaded for every player profile.
local AURA_PARTICLE = "content/fx/particles/weapons/swords/forcesword/psyker_block"
local AURA_NODE = "j_spine"
local AURA_RESPAWN_INTERVAL = 0.5

local _deflect_visuals, _instakill

local state = mod:persistent_table("deflect_state", {
	registered = false,
	node_inserted = false,
	node_message = nil,
})

-- PlayerUnitInputExtension does not keep its unit, so it is recorded at init.
local input_units = mod:persistent_table("deflect_input_units", {})

if getmetatable(input_units) == nil then
	setmetatable(input_units, { __mode = "k" })
end

-- ####################################################################
-- Shared checks
-- ####################################################################

-- Player units on the server and the local player's own unit use
-- PlayerUnitBuffExtension; other players' units on a client use
-- PlayerHuskBuffExtension, which has no buff list and returns false here.
local function _has_stance(unit)
	local buff_extension = unit and ScriptUnit.has_extension(unit, "buff_system")

	if not buff_extension or not buff_extension.has_buff_using_buff_template then
		return false
	end

	if not buff_extension:has_keyword(keywords.count_as_blocking) then
		return false
	end

	return buff_extension:has_buff_using_buff_template(BUFF_NAME)
end

-- attack.lua instakill_non_monster_or_captain_or_ogryn: the breeds counted as
-- bosses are the ones tagged monster, captain or cultist_captain.
local function _is_boss(breed)
	local tags = breed and breed.tags

	return tags ~= nil and (tags.monster or tags.captain or tags.cultist_captain) and true or false
end

-- Plain horde and roamer enemies: minions that are not elites, specials,
-- bosses or lords (breed tags as in the breed files under settings/breed).
local function _is_trash(breed)
	local tags = breed and breed.tags

	return tags ~= nil and tags.minion and not (tags.elite or tags.special or tags.monster or tags.captain or tags.cultist_captain or tags.lord) and true or false
end

local function _has_augment(unit, augment_name)
	local buff_extension = ScriptUnit.has_extension(unit, "buff_system")

	return buff_extension ~= nil and buff_extension.has_buff_using_buff_template ~= nil and buff_extension:has_buff_using_buff_template(augment_name)
end

local function _reflect_damage(attacking_unit, breed, blocked_damage)
	local fraction = _is_boss(breed) and BOSS_REFLECT_HEALTH_FRACTION or REFLECT_HEALTH_FRACTION
	local health_extension = ScriptUnit.has_extension(attacking_unit, "health_system")
	local max_health = health_extension and health_extension.max_health and health_extension:max_health()

	if not max_health or max_health <= 0 then
		return blocked_damage
	end

	return max_health * fraction
end

local function _is_server()
	local game_session = Managers.state and Managers.state.game_session

	return game_session ~= nil and game_session:is_server()
end

-- ####################################################################
-- Damage sent back
-- ####################################################################

-- While a reflected hit runs, DamageCalculation.calculate returns the damage
-- the blocked hit carried (attack.lua _handle_attack: damage_absorbed =
-- calculated_damage) instead of computing it from the push profile.
local reflect_override = {
	target = nil,
	damage = 0,
}

local function _reflect(player_unit, attacking_unit, damage)
	local Attack = require("scripts/utilities/attack/attack")
	local player_position = POSITION_LOOKUP[player_unit]
	local attacking_position = POSITION_LOOKUP[attacking_unit]

	if not player_position or not attacking_position then
		return
	end

	-- Same direction setup as hordes_buff_reflect_melee_damage.
	local direction = Vector3.normalize(Vector3.flat(attacking_position - player_position))

	if Vector3.length(direction) == 0 then
		direction = Vector3.up()
	end

	reflect_override.target = attacking_unit
	reflect_override.damage = damage

	-- hordes_buff_damage_reflection_hit is Fatshark's own melee reflect profile
	-- (buff_damage_profile_templates.lua): a push that staggers the attacker.
	-- Argument order as in adamant_buff_templates.lua Attack.execute calls.
	local ok, err = pcall(Attack.execute, attacking_unit, DamageProfileTemplates.hordes_buff_damage_reflection_hit, "power_level", PowerLevelSettings.default_power_level, "damage_type", damage_types.physical, "attack_type", attack_types.buff, "attacking_unit", player_unit, "attack_direction", direction)

	reflect_override.target = nil
	reflect_override.damage = 0

	if not ok then
		mod:error("Reflected hit failed: %s", tostring(err))

		return
	end

	-- Heaviest stagger (stagger_settings.lua stagger_impact_comparison:
	-- explosion = 4), with the same arguments the Psyker and Arbites shouts
	-- use, so fast attackers like Ragers are thrown off their combo instead
	-- of swinging into the reflect again.
	if HEALTH_ALIVE[attacking_unit] then
		Stagger.force_stagger(attacking_unit, StaggerSettings.stagger_types.explosion, direction, 4, 1, 4, player_unit)
	end

	local fx_extension = ScriptUnit.has_extension(player_unit, "fx_system")

	if fx_extension and fx_extension.trigger_wwise_events_local_only then
		fx_extension:trigger_wwise_events_local_only(DEFLECT_HIT_SOUND, false, player_unit)
	end
end

-- ####################################################################
-- Shimmer seen by everyone (server effect template, synced to clients)
-- ####################################################################

-- Built like effect_templates/zealot_relic_blessed.lua: a particle linked to
-- j_spine on the third person unit, hidden while that unit is in first person.
-- The particle is restarted every AURA_RESPAWN_INTERVAL so it stays visible
-- for the whole stance.
local function _aura_create(template_data, template_context)
	local world = template_context.world
	local unit = template_data.unit

	if template_data.effect_id or template_data.is_in_first_person_mode then
		return
	end

	if not unit or not Unit.has_node(unit, AURA_NODE) then
		return
	end

	local node_index = Unit.node(unit, AURA_NODE)
	local node_position = Unit.world_position(unit, node_index)
	local effect_id = World.create_particles(world, AURA_PARTICLE, node_position, nil, nil, template_data.particle_group)

	World.link_particles(world, effect_id, unit, node_index, Matrix4x4.identity(), "destroy")

	template_data.effect_id = effect_id
end

local function _aura_stop(template_data, template_context)
	local effect_id = template_data.effect_id

	if effect_id then
		World.stop_spawning_particles(template_context.world, effect_id)

		template_data.effect_id = nil
	end
end

local aura_effect_template = {
	name = EFFECT_TEMPLATE_NAME,
	resources = {},
	start = function (template_data, template_context)
		local first_person_extension = ScriptUnit.has_extension(template_data.unit, "first_person_system")

		template_data.first_person_extension = first_person_extension
		template_data.is_in_first_person_mode = first_person_extension and first_person_extension:is_in_first_person_mode() or false
		template_data.next_respawn_t = nil

		_aura_create(template_data, template_context)
	end,
	update = function (template_data, template_context, dt, t)
		local first_person_extension = template_data.first_person_extension
		local is_in_first_person_mode = first_person_extension and first_person_extension:is_in_first_person_mode() or false

		template_data.is_in_first_person_mode = is_in_first_person_mode

		if is_in_first_person_mode then
			_aura_stop(template_data, template_context)

			return
		end

		local next_respawn_t = template_data.next_respawn_t

		if not next_respawn_t or next_respawn_t <= t then
			_aura_stop(template_data, template_context)
			_aura_create(template_data, template_context)

			template_data.next_respawn_t = t + AURA_RESPAWN_INTERVAL
		end
	end,
	stop = function (template_data, template_context)
		_aura_stop(template_data, template_context)
	end,
}

-- ####################################################################
-- Game data
-- ####################################################################

local function _buff_template()
	return {
		class_name = "proc_buff",
		duration = DURATION,
		hud_icon = BUFF_HUD_ICON,
		hud_icon_gradient_map = "content/ui/textures/color_ramps/talent_ability",
		hud_priority = 4,
		predicted = true,
		unique_buff_id = BUFF_NAME,
		keywords = {
			-- dodge.lua Dodge.is_dodging: nets and pounces count as dodged.
			keywords.count_as_dodge_vs_netgunner,
			keywords.count_as_dodge_vs_chaos_hound_pounce,
			-- block.lua: counts as blocking without holding block.
			keywords.count_as_blocking,
			-- block.lua: unblockable melee attacks are blocked too.
			keywords.block_unblockable,
			keywords.stun_immune_block_broken,
			-- hit_reaction.lua / stun.lua: no stuns or staggers; push.lua:
			-- no melee or ranged pushes. Launches are removed in the
			-- HitReaction.apply hook below.
			keywords.stun_immune,
			keywords.melee_push_immune,
			keywords.ranged_push_immune,
			keywords.no_sprint,
		},
		stat_buffs = {
			-- block.lua _block_buff_modifier multiplies the block cost by this.
			[stat_buffs.block_cost_multiplier] = 0,
			-- buff_settings.lua: multiplicative, so 0.4 = 60% less ranged damage.
			[stat_buffs.ranged_damage_taken_multiplier] = RANGED_DAMAGE_TAKEN,
		},
		proc_events = {
			[proc_events.on_player_hit_received] = 1,
		},
		check_proc_func = function (params, template_data, template_context)
			local attacking_unit = params.attacking_unit

			return params.attack_result == attack_results.blocked and params.attack_type == attack_types.melee and (params.damage_absorbed or 0) > 0 and attacking_unit ~= nil and ALIVE[attacking_unit] and true or false
		end,
		proc_func = function (params, template_data, template_context)
			if not template_context.is_server then
				return
			end

			local attacking_unit = params.attacking_unit
			local unit_data_extension = ScriptUnit.has_extension(attacking_unit, "unit_data_system")
			local breed = unit_data_extension and unit_data_extension:breed()

			if not Breed.is_minion(breed) or not HEALTH_ALIVE[attacking_unit] then
				return
			end

			local player_unit = template_context.unit

			if _is_trash(breed) and _has_augment(player_unit, AUGMENT_HORDE_KILL) then
				_instakill(player_unit, attacking_unit)

				return
			end

			_reflect(player_unit, attacking_unit, _reflect_damage(attacking_unit, breed, params.damage_absorbed))
		end,
		-- Toughness augment: TOUGHNESS_PER_SECOND of max toughness per second,
		-- as cryptic_buff_templates.lua's precision stance regen does it.
		update_func = function (template_data, template_context, dt, t)
			if not template_context.is_server then
				return
			end

			local unit = template_context.unit

			if _has_augment(unit, AUGMENT_TOUGHNESS) then
				local Toughness = require("scripts/utilities/toughness/toughness")

				Toughness.replenish_percentage(unit, TOUGHNESS_PER_SECOND * dt, false, "ability_stance")
			end
		end,
		player_effects = {
			on_screen_effect = SCREEN_EFFECT,
			looping_wwise_start_event = LOOP_START,
			looping_wwise_stop_event = LOOP_STOP,
			wwise_state = {
				group = "player_ability",
				off_state = "none",
				on_state = "zealot_maniac_resist_death",
			},
			effect_template = aura_effect_template,
		},
	}
end

local function _ability()
	-- Same fields as zealot_abilities.lua zealot_invisibility. The
	-- zealot_invisibility ability template is an instant stance_change that
	-- adds ability_template_tweak_data.buff_to_add (action_stance_change.lua).
	return {
		ability_group = ABILITY_NAME,
		ability_template = "zealot_invisibility",
		cooldown = COOLDOWN,
		hud_icon = ABILITY_HUD_ICON,
		icon = ABILITY_ICON,
		max_charges = 1,
		name = ABILITY_NAME,
		resource_cost_per_charge = COOLDOWN,
		resource_regen_per_second = 1,
		usage_cost_type = "charges",
		ability_template_tweak_data = {
			buff_to_add = BUFF_NAME,
		},
		archetypes = {
			"zealot",
		},
	}
end

-- archetype_resource_dependencies.lua loads every "wwise/events/player/" and
-- "content/fx/particles/screenspace/" string found in the archetype table,
-- talents included, so these load for every Zealot.
local function _resource_strings()
	local out = {}

	for _, name in ipairs({ SCREEN_EFFECT, LOOP_START, LOOP_STOP, DEFLECT_HIT_SOUND }) do
		if Application.can_get_resource("package", name) then
			out[#out + 1] = name
		end
	end

	return out
end

local function _talent(ability)
	local zealot_talents = ArchetypeTalents.zealot
	local stealth = zealot_talents and rawget(zealot_talents, "zealot_stealth")

	return {
		description = LOC_DESCRIPTION,
		display_name = LOC_NAME,
		icon = NODE_ICON,
		is_main_ability = true,
		large_icon = stealth and stealth.large_icon or nil,
		name = "Zealot Deflect",
		format_values = {
			duration = {
				format_type = "number",
				value = DURATION,
			},
			cooldown = {
				format_type = "number",
				value = COOLDOWN,
			},
		},
		player_ability = {
			ability_type = "combat_ability",
			ability = ability,
		},
		qiangiq_resources = _resource_strings(),
	}
end

-- Same as QIangIQsLegacyTalents class_swap.lua _append_lookup: new names go
-- at the end so every existing id keeps its index.
local function _append_lookup(lookup_name, name)
	local NetworkLookup = rawget(_G, "NetworkLookup") or require("scripts/network_lookup/network_lookup")
	local lookup = NetworkLookup[lookup_name]

	if not lookup then
		mod:error("NetworkLookup.%s is missing", lookup_name)

		return
	end

	if rawget(lookup, name) == nil then
		local index = #lookup + 1

		rawset(lookup, index, name)
		rawset(lookup, name, index)
	end
end

local function _register_data()
	if state.registered then
		return
	end

	local buff = _buff_template()

	buff.name = BUFF_NAME
	BuffTemplates[BUFF_NAME] = buff

	local predicted_lookup = rawget(BuffTemplates, "PREDICTED")

	if predicted_lookup then
		predicted_lookup[BUFF_NAME] = BUFF_NAME
	end

	EffectTemplates[EFFECT_TEMPLATE_NAME] = aura_effect_template

	local ability = _ability()

	PlayerAbilities[ABILITY_NAME] = ability
	ArchetypeTalents.zealot[TALENT_NAME] = _talent(ability)

	_append_lookup("archetype_talent_names", TALENT_NAME)
	_append_lookup("talent_node_names", NODE_NAME)
	_append_lookup("buff_templates", BUFF_NAME)
	_append_lookup("player_abilities", ABILITY_NAME)
	_append_lookup("effect_templates", EFFECT_TEMPLATE_NAME)

	for _, augment in ipairs(AUGMENTS) do
		-- Marker buff: no duration, no HUD icon, removed with the talent.
		BuffTemplates[augment.talent] = {
			name = augment.talent,
			class_name = "buff",
			predicted = false,
		}

		ArchetypeTalents.zealot[augment.talent] = {
			description = augment.loc_description,
			display_name = augment.loc_name,
			icon = augment.icon,
			name = augment.talent,
			passive = {
				buff_template_name = augment.talent,
				identifier = augment.talent,
			},
		}

		_append_lookup("archetype_talent_names", augment.talent)
		_append_lookup("talent_node_names", augment.node)
		_append_lookup("buff_templates", augment.talent)
	end

	state.registered = true
end

-- ####################################################################
-- Legacy tree node
-- ####################################################################

-- QIangIQsLegacyTalents swaps layout.nodes between the official and legacy
-- tables (mode_toggle.lua). Its record holds the legacy table whichever mode
-- is active, so the node goes in there and never into the official tree.
local function _legacy_nodes()
	local legacy_mod = get_mod("QIangIQsLegacyTalents")

	if not legacy_mod then
		return nil, "QIangIQsLegacyTalents is not installed or loads after this mod"
	end

	local legacy_state = legacy_mod:persistent_table("legacy_state")
	local toggle = legacy_state and legacy_state.toggle

	if not toggle or not toggle.tables then
		return nil, "QIangIQsLegacyTalents has no legacy data loaded"
	end

	local layout = require(LAYOUT_PATH)

	for i = 1, toggle.count do
		if toggle.tables[i] == layout and toggle.keys[i] == "nodes" then
			return toggle.legacy[i]
		end
	end

	return nil, "the legacy Zealot tree is turned off in QIangIQsLegacyTalents"
end

local function _add_unique(node, key, name)
	local list = node[key]

	if not list then
		list = {}
		node[key] = list
	end

	for i = 1, #list do
		if list[i] == name then
			return
		end
	end

	list[#list + 1] = name
end

-- Augment nodes, fields as the 1.6.1 Banishing Light ability_modifier node.
-- Runs on its own so a tree that already has Deflect still gets them.
local function _insert_augments(nodes, by_name)
	local deflect = by_name[NODE_NAME]

	if not deflect then
		return
	end

	for _, augment in ipairs(AUGMENTS) do
		if not by_name[augment.node] then
			local node = {
				cost = 1,
				gradient_color = AUGMENT_GRADIENT,
				icon = augment.icon,
				max_points = 1,
				talent = augment.talent,
				type = "ability_modifier",
				widget_name = augment.node,
				x = augment.x,
				x_normalized = 0,
				y = augment.y,
				y_normalized = 0,
				children = {},
				parents = {
					NODE_NAME,
				},
				requirements = {
					all_parents_chosen = false,
					children_unlock_points = 1,
					min_points_spent = 0,
				},
			}

			nodes[#nodes + 1] = node
			by_name[augment.node] = node
		end

		_add_unique(deflect, "children", augment.node)
	end
end

local function _insert_node()
	local nodes, reason = _legacy_nodes()

	if not nodes then
		return false, reason
	end

	local by_name = {}

	for _, node in ipairs(nodes) do
		by_name[node.widget_name] = node
	end

	if by_name[NODE_NAME] then
		_insert_augments(nodes, by_name)

		return true
	end

	for _, parent_name in ipairs(PARENT_NODES) do
		if not by_name[parent_name] then
			return false, "the legacy Zealot tree has no node " .. parent_name
		end
	end

	for _, child_name in ipairs(CHILD_NODES) do
		if not by_name[child_name] then
			return false, "the legacy Zealot tree has no node " .. child_name
		end
	end

	local parents, children = {}, {}

	for i, parent_name in ipairs(PARENT_NODES) do
		parents[i] = parent_name
	end

	for i, child_name in ipairs(CHILD_NODES) do
		children[i] = child_name
	end

	-- Fields as the 1.6.1 Zealot ability nodes, plus cost and target_slot the
	-- way QIangIQsLegacyTalents _adapt_layout sets them. Appended last, so the
	-- index of every existing node (used by saved builds) is unchanged.
	nodes[#nodes + 1] = {
		cost = 1,
		icon = NODE_ICON,
		max_points = 1,
		talent = TALENT_NAME,
		target_slot = "slot_combat_ability",
		type = "ability",
		widget_name = NODE_NAME,
		x = NODE_X,
		x_normalized = 0,
		y = NODE_Y,
		y_normalized = 0,
		children = children,
		parents = parents,
		requirements = {
			all_parents_chosen = false,
			children_unlock_points = 1,
			exclusive_group = "combat",
			min_points_spent = 0,
		},
	}
	by_name[NODE_NAME] = nodes[#nodes]

	for _, parent_name in ipairs(PARENT_NODES) do
		local parent = by_name[parent_name]
		local children = parent.children

		if not children then
			children = {}
			parent.children = children
		end

		children[#children + 1] = NODE_NAME
	end

	-- Two-way links, as Chastise the Wicked and its child list each other.
	for _, child_name in ipairs(CHILD_NODES) do
		_add_unique(by_name[child_name], "parents", NODE_NAME)
	end

	for _, link in ipairs(EXTRA_LINKS) do
		local parent, child = by_name[link[1]], by_name[link[2]]

		if parent and child then
			_add_unique(parent, "children", link[2])
			_add_unique(child, "parents", link[1])
		end
	end

	for widget_name, move in pairs(NODE_MOVES) do
		local node = by_name[widget_name]

		if node and node.x == move[1] and node.y == move[2] then
			node.x = move[3]
			node.y = move[4]
		end
	end

	_insert_augments(nodes, by_name)

	return true
end

local function _try_insert_node()
	if state.node_inserted then
		return
	end

	local ok, reason = _insert_node()

	state.node_inserted = ok
	state.node_message = reason

	if ok then
		mod:info("Deflect added to the legacy Zealot tree")
	end
end

_register_data()
_try_insert_node()

-- ####################################################################
-- Custom icons (PNG files in this mod's assets folder, loaded by SimpleAssets)
-- ####################################################################

-- SimpleAssets docs/api/textures.md: load_textures resolves a PNG to a
-- texture object. ui_passes.lua sets userdata material values with
-- Material.set_resource, so the object can stand in for a texture path in
-- the HUD ability icon (talent_icon) and in talent tree nodes (node.icon,
-- read by talent_builder_view_node_definitions.lua). Without SimpleAssets
-- the game textures named above stay in place.
local ASSET_DIR = "mods/QIangIQsZealotDeflect/assets/"
local HUD_ICON_FILE = ASSET_DIR .. "deflect_hud.png"
local NODE_ICON_FILES = {
	[NODE_NAME] = ASSET_DIR .. "deflect_node.png",
	["node_qiangiq_zealot_deflect_horde_kill"] = ASSET_DIR .. "horde_kill_node.png",
	["node_qiangiq_zealot_deflect_toughness"] = ASSET_DIR .. "toughness_node.png",
}

local custom_icons = mod:persistent_table("deflect_custom_icons", {
	requested = false,
	attempts = 0,
	textures = {},
})

local MAX_LOAD_ATTEMPTS = 3

local function _apply_node_icons()
	local nodes = _legacy_nodes()

	if not nodes then
		return
	end

	for _, node in ipairs(nodes) do
		local texture = custom_icons.textures[NODE_ICON_FILES[node.widget_name] or false]

		if texture then
			node.icon = texture
		end
	end
end

-- SimpleAssets loads PNGs through Managers.url_loader, which goes through the
-- backend manager; until the backend is up every request is rejected with
-- "Backend not initialized" (backend_manager.lua _not_initialized). Loading
-- waits for BackendManager._initialized.
local function _backend_ready()
	local backend = Managers.backend

	return backend ~= nil and backend._initialized == true
end

local function _load_custom_icons()
	if custom_icons.requested or (custom_icons.attempts or 0) >= MAX_LOAD_ATTEMPTS then
		return
	end

	local SimpleAssets = get_mod("SimpleAssets")

	if not SimpleAssets or not SimpleAssets.load_textures then
		mod:info("SimpleAssets is not loaded, Deflect keeps the game's icons")

		return
	end

	local files = {}

	if not custom_icons.textures[HUD_ICON_FILE] then
		files[1] = HUD_ICON_FILE
	end

	for _, file in pairs(NODE_ICON_FILES) do
		if not custom_icons.textures[file] then
			files[#files + 1] = file
		end
	end

	if #files == 0 then
		custom_icons.requested = true

		return
	end

	custom_icons.requested = true
	custom_icons.attempts = (custom_icons.attempts or 0) + 1

	local ok, promise = pcall(SimpleAssets.load_textures, files)

	if not ok or not promise then
		mod:error("Deflect icons could not be loaded: %s", tostring(promise))

		return
	end

	promise:next(function (results)
		local failed = false

		for file, result in pairs(results) do
			if result.is_ok and result.texture then
				custom_icons.textures[file] = result.texture
			else
				failed = true
			end
		end

		_apply_node_icons()

		-- Failed files are tried again on a later frame, up to MAX_LOAD_ATTEMPTS.
		if failed then
			if custom_icons.attempts < MAX_LOAD_ATTEMPTS then
				custom_icons.requested = false
			else
				mod:warning("Some Deflect icons could not be loaded, the game's icons are used for them")
			end
		end
	end)
end

mod.update = function ()
	if not custom_icons.requested and _backend_ready() then
		_load_custom_icons()
	end
end

mod.on_all_mods_loaded = function ()
	_try_insert_node()

	if not state.node_inserted then
		mod:warning("Deflect was not added to the Zealot tree: %s", tostring(state.node_message))
	end

	_apply_node_icons()
end

-- ####################################################################
-- Deflect feedback and Mutant kill
-- ####################################################################

-- player_unit_weapon_extension.lua _block_anim_event, copied: weapons can
-- override the parry anim per attack type.
local function _block_anim_event(weapon_template, attack_type, event_name)
	local block_override = weapon_template and weapon_template.block_override_anims
	local attack_type_override = block_override and block_override[attack_type]

	return attack_type_override and attack_type_override[event_name] or event_name
end

-- PlayerUnitWeaponExtension.blocked_attack only plays the parry anim while the
-- block action is held. During the stance the player is not holding block, so
-- the same parry_hit_reaction events are played here, and the local player
-- also sees the force sword block shimmer where the hit was turned aside.
_deflect_visuals = function (player_unit, hit_world_position, weapon_template, attack_type)
	local unit_data_extension = ScriptUnit.has_extension(player_unit, "unit_data_system")
	local block_component = unit_data_extension and unit_data_extension:read_component("block")

	if block_component and block_component.is_blocking then
		return
	end

	local animation_extension = ScriptUnit.has_extension(player_unit, "animation_system")

	if animation_extension and weapon_template then
		local event_name = _block_anim_event(weapon_template, attack_type, "parry_hit_reaction")

		pcall(animation_extension.anim_event_1p, animation_extension, event_name)
		pcall(animation_extension.anim_event, animation_extension, event_name)
	end

	local first_person_extension = ScriptUnit.has_extension(player_unit, "first_person_system")
	local in_first_person = first_person_extension and first_person_extension:is_in_first_person_mode()

	if in_first_person and hit_world_position then
		local world = Managers.world:world("level_world")

		if world then
			World.create_particles(world, AURA_PARTICLE, hit_world_position)
		end
	end
end

_instakill = function (player_unit, mutant_unit)
	local Attack = require("scripts/utilities/attack/attack")
	local player_position = POSITION_LOOKUP[player_unit]
	local mutant_position = POSITION_LOOKUP[mutant_unit]
	local direction = player_position and mutant_position and Vector3.normalize(Vector3.flat(mutant_position - player_position)) or Vector3.up()

	if Vector3.length(direction) == 0 then
		direction = Vector3.up()
	end

	-- attack.lua: "instakill" sets the damage to the target's max health, as
	-- prop_health.lua and valkyrie_gameplay.lua use it.
	local ok, err = pcall(Attack.execute, mutant_unit, DamageProfileTemplates.hordes_buff_damage_reflection_hit, "instakill", true, "damage_type", damage_types.physical, "attack_type", attack_types.buff, "attacking_unit", player_unit, "attack_direction", direction)

	if not ok then
		mod:error("Mutant kill failed: %s", tostring(err))

		return
	end

	local fx_extension = ScriptUnit.has_extension(player_unit, "fx_system")

	if fx_extension and fx_extension.trigger_wwise_events_local_only then
		fx_extension:trigger_wwise_events_local_only(DEFLECT_HIT_SOUND, false, player_unit)
	end
end

-- ####################################################################
-- Hooks
-- ####################################################################

-- Every enemy melee attack is blocked, from any direction, while the stance is
-- up. block.lua attempt_block_break needs the weapon's stamina template block
-- cost, so the check matches _get_block_cost.
mod:hook_require("scripts/utilities/attack/block", function (Block)
	mod:hook(Block, "is_blocking", function (func, target_unit, attacking_unit, attack_type, weapon_template, is_server)
		local result = func(target_unit, attacking_unit, attack_type, weapon_template, is_server)

		if result or attack_type ~= attack_types.melee or not _has_stance(target_unit) then
			return result
		end

		local weapon_extension = ScriptUnit.has_extension(target_unit, "weapon_system")
		local stamina_template = weapon_extension and weapon_extension.stamina_template and weapon_extension:stamina_template()

		if stamina_template and (stamina_template.block_cost_melee or stamina_template.block_cost_default) then
			return true
		end

		return result
	end)

	-- On the server every blocked hit during the stance counts as a perfect
	-- block, so on_perfect_block procs fire (player_unit_weapon_extension.lua).
	mod:hook(Block, "player_blocked_attack", function (func, target_unit, attacking_unit, hit_world_position, block_broken, weapon_template, attack_type, block_cost, is_perfect_block)
		if not is_perfect_block and _is_server() and _has_stance(target_unit) then
			is_perfect_block = true
		end

		local result = func(target_unit, attacking_unit, hit_world_position, block_broken, weapon_template, attack_type, block_cost, is_perfect_block)

		-- Runs on the server and, through rpc_player_blocked_attack, on clients.
		if not block_broken and _has_stance(target_unit) then
			_deflect_visuals(target_unit, hit_world_position, weapon_template, attack_type)
		end

		return result
	end)
end)

-- Knockback: hit_reaction.lua _player_hit_reaction reads the push, catapult
-- (launch) and ignore_stun_immunity entries from the damage profile. While the
-- stance is up the player's hit reaction gets a view of the profile with those
-- three entries empty, so no hit can push, launch or force a stun.
local function _no_knockback_profile(damage_profile, breed)
	local hit_reaction_keys = breed and breed.hit_reaction_keys

	if not hit_reaction_keys then
		return damage_profile
	end

	local removed = {}

	for _, key in ipairs({ "catapulting_template", "push_template", "ignore_stun_immunity" }) do
		local profile_key = hit_reaction_keys[key]

		if profile_key then
			removed[profile_key] = true
		end
	end

	return setmetatable({}, {
		__index = function (_, key)
			if removed[key] then
				return nil
			end

			return damage_profile[key]
		end,
	})
end

mod:hook_require("scripts/utilities/attack/hit_reaction", function (HitReaction)
	mod:hook(HitReaction, "apply", function (func, damage_profile, damage_profile_lerp_values, target_weapon_template, attacked_breed_or_nil, target_buff_extension, attack_result, attacked_unit, ...)
		if damage_profile and Breed.is_player(attacked_breed_or_nil) and _has_stance(attacked_unit) then
			damage_profile = _no_knockback_profile(damage_profile, attacked_breed_or_nil)
		end

		return func(damage_profile, damage_profile_lerp_values, target_weapon_template, attacked_breed_or_nil, target_buff_extension, attack_result, attacked_unit, ...)
	end)
end)

-- Mutant grabs: every grab (charge hit, lag compensated hit, close up grab)
-- starts in BtMutantChargerChargeAction._hit_target, which runs on the server.
-- While the stance is up the grab never starts and the Mutant dies instead.
mod:hook_require("scripts/extension_systems/behavior/nodes/actions/bt_mutant_charger_charge_action", function (BtMutantChargerChargeAction)
	mod:hook(BtMutantChargerChargeAction, "_hit_target", function (func, self, unit, hit_unit, scratchpad, action_data, t)
		if _has_stance(hit_unit) and HEALTH_ALIVE[unit] then
			_instakill(hit_unit, unit)

			return
		end

		return func(self, unit, hit_unit, scratchpad, action_data, t)
	end)
end)

mod:hook_require("scripts/utilities/attack/damage_calculation", function (DamageCalculation)
	mod:hook(DamageCalculation, "calculate", function (func, ...)
		local target = reflect_override.target

		-- The 30th argument is target_unit (damage_calculation.lua).
		if target ~= nil and select(30, ...) == target then
			local damage = reflect_override.damage

			return damage, damage_efficiencies.full, damage, 0, 0, 0, 0, 0, 1, 1
		end

		return func(...)
	end)
end)

-- Rooted: no movement, dodge, jump or sprint input while the stance is up.
-- The server reads the same inputs for the player's unit, so both sides agree.
local LOCKED_INPUTS = {
	move = true,
	dodge = true,
	jump = true,
	jump_held = true,
	sprint = true,
	sprinting = true,
}

mod:hook_require("scripts/extension_systems/input/player_unit_input_extension", function (PlayerUnitInputExtension)
	mod:hook_safe(PlayerUnitInputExtension, "init", function (self, extension_init_context, unit)
		input_units[self] = unit
	end)

	mod:hook(PlayerUnitInputExtension, "get", function (func, self, action)
		if LOCKED_INPUTS[action] then
			local unit = input_units[self]

			if unit and _has_stance(unit) then
				if action == "move" then
					return Vector3.zero()
				end

				return false
			end
		end

		return func(self, action)
	end)
end)

-- HUD: hud_element_player_ability.lua set_icon writes hud_icon into
-- style.icon.material_values.talent_icon. Once the custom PNG has loaded it
-- replaces the game texture for the Deflect slot.
mod:hook_require("scripts/ui/hud/elements/player_ability/hud_element_player_ability", function (HudElementPlayerAbility)
	mod:hook_safe(HudElementPlayerAbility, "update", function (self)
		local texture = custom_icons.textures[HUD_ICON_FILE]
		local data = self._data

		if not texture or not data or data.icon ~= ABILITY_HUD_ICON then
			return
		end

		local widget = self._widgets_by_name and self._widgets_by_name.ability
		local material_values = widget and widget.style.icon and widget.style.icon.material_values

		if material_values and material_values.talent_icon ~= texture then
			material_values.talent_icon = texture
			widget.dirty = true
		end
	end)
end)

-- ####################################################################
-- Text
-- ####################################################################

local loc_text = {
	[LOC_NAME] = "talent_name",
	[LOC_DESCRIPTION] = "talent_description",
}

for _, augment in ipairs(AUGMENTS) do
	loc_text[augment.loc_name] = augment.mod_name_key
	loc_text[augment.loc_description] = augment.mod_description_key
end

mod:hook(CLASS.LocalizationManager, "_lookup", function (func, self, key)
	local mod_key = loc_text[key]

	if mod_key then
		return mod:localize(mod_key)
	end

	return func(self, key)
end)

mod:command("zealot_deflect", mod:localize("command_description"), function ()
	if state.node_inserted then
		mod:echo("Deflect is in the legacy Zealot tree, between Chastise the Wicked and Bolstering Prayer.")
	else
		mod:echo("Deflect is not in the Zealot tree: %s", tostring(state.node_message))
	end
end)
