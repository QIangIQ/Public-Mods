# QIangIQs Zealot Deflect

A new Zealot combat ability, **Deflect**, in the legacy (1.6.1) Zealot tree from QIangIQsLegacyTalents.

- Instant cast on the combat ability key, like the other stance abilities. Cooldown 45 s.
- For 4 seconds you are rooted: no moving, dodging, jumping or sprinting. You can still turn and attack.
- Every enemy melee attack, from any direction and including unblockable ones, is blocked as a perfect block at no stamina cost.
- Each blocked hit deals 40% of the attacker's max health back to it and gives it the heaviest stagger in the game (the `explosion` stagger, as the Psyker and Arbites shouts use), so Ragers and fast attackers don't keep swinging into the reflect. Bosses (breeds tagged monster, captain or cultist_captain, the same set attack.lua treats as non-instakillable) take 20% of their max health per deflected hit.
- 60% less ranged damage taken (`ranged_damage_taken_multiplier` 0.4).
- Knockback immunity: no pushes, staggers, stuns or launches (`stun_immune`, `melee_push_immune`, `ranged_push_immune`, plus launch and forced-stun entries removed from incoming hit reactions).
- Trapper nets and Pox Hound pounces count as dodged (the game's own `count_as_dodge_vs_netgunner` and `count_as_dodge_vs_chaos_hound_pounce` keywords).
- A Mutant whose charge reaches you never grabs you and is killed outright instead.
- Visuals: Zealot's Resist Death screen effect and sound loop for you, a shield-hit sound per deflected hit, and a force-sword block shimmer on your body that other players see. In first person each deflected hit plays your weapon's own parry animation and a force-sword shimmer flash where the hit landed.
- Icons: custom PNGs in `assets/` (made from QIangIQ's own icon art), loaded with SimpleAssets: `deflect_hud.png` fills the HUD ability hexagon, and `deflect_node.png`, `horde_kill_node.png` and `toughness_node.png` are the talent tree node icons. Without SimpleAssets the game's own textures are used instead.

## Augments

Two ability modifier nodes under Deflect. You can take either or both.

- **Cull the Masses:** while Deflect is active, any horde or roamer enemy whose melee attack you deflect dies instantly. Elites, specialists, bosses and lords are not affected.
- **Unbroken Faith:** while Deflect is active, you regenerate 30% of your maximum toughness every second.

## Where it is

In the middle of the Zealot talent tree: Deflect sits between the left and middle stat nodes and links down to the two stat nodes below. Bolstering Prayer moves right, with Banishing Light under it and Ecclesiarch's Call and Holy Cause forking off to its right; Shroudfield shifts right to make room. It is one of the three combat abilities (only one can be picked).

## Requirements

- QIangIQsLegacyTalents with the Zealot legacy tree turned on. This mod loads right after it in mod_load_order.txt.
- Every player in a Realms game needs this mod, the same as the legacy talents mod.

## Official missions

The node only exists in the legacy tree, so Fatshark mission servers use the official tree and build as before. Every hook checks for the Deflect buff and does nothing without it.

## Command

`/zealot_deflect` says whether Deflect made it into the tree, and why not if it did not.
