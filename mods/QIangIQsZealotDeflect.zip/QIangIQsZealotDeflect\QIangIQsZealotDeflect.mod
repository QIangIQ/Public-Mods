return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsZealotDeflect` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsZealotDeflect", {
			mod_script       = "QIangIQsZealotDeflect/scripts/mods/QIangIQsZealotDeflect/QIangIQsZealotDeflect",
			mod_data         = "QIangIQsZealotDeflect/scripts/mods/QIangIQsZealotDeflect/QIangIQsZealotDeflect_data",
			mod_localization = "QIangIQsZealotDeflect/scripts/mods/QIangIQsZealotDeflect/QIangIQsZealotDeflect_localization",
		})
	end,
	packages = {},
}
