return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsCitlali` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsCitlali", {
            mod_script = "QIangIQsCitlali/scripts/mods/QIangIQsCitlali/QIangIQsCitlali",
            mod_data = "QIangIQsCitlali/scripts/mods/QIangIQsCitlali/QIangIQsCitlali_data",
            mod_localization = "QIangIQsCitlali/scripts/mods/QIangIQsCitlali/QIangIQsCitlali_localization",
        })
    end,
    version = "1.0.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
