return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsMMJSniper` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsMMJSniper", {
            mod_script = "QIangIQsMMJSniper/scripts/mods/QIangIQsMMJSniper/QIangIQsMMJSniper",
            mod_data = "QIangIQsMMJSniper/scripts/mods/QIangIQsMMJSniper/QIangIQsMMJSniper_data",
            mod_localization = "QIangIQsMMJSniper/scripts/mods/QIangIQsMMJSniper/QIangIQsMMJSniper_localization",
        })
    end,
    version = "0.1.0",
    author = "QIangIQ",
    packages = {},
}
