-- QIangIQsMMJSniper per-weapon data (gen.py spec sniper). Clips are MMJ clip names from sniper\OBJ-Weapond-Sniper lv1__11793.
-- Action map sources: Darktide weapon templates (Aussiemon master) via tools\dump_actions.py.
return {
    ranged = true,
    idle = "sniper iddle - std",
    aim = "sniper iddle - zoom",
    templates = { autogun_p3_m1 = true, autogun_p3_m2 = true, autogun_p3_m3 = true },
    shot = { clips = { "sniper-shoot-iddle", "sniper-reload-bolt" }, sounds = { "sfx_gp_wp_sniper_shot_01.ogg", "sfx_gp_wp_sniper_shot_02.ogg", "sfx_gp_wp_sniper_shot_03.ogg", "sfx_gp_wp_sniper_shot_04.ogg", "sfx_gp_wp_sniper_shot_05.ogg", "sfx_gp_wp_sniper_shot_06.ogg" } },
    actions = {
        action_wield = { clips = { "sniper-pickup quick" }, over_shot = true, sounds = { "sfx_wp_sniper_intro.ogg" } },
        action_reload = { clips = { "sniper-reload" }, stretch = true, reload_template = true, over_shot = true, sounds = { "sfx_wp_sniper_reload.ogg" } },
    },
}
