local mod = get_mod("QIangIQsMMJSniper")

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = true,
    options = {
        widgets = {
            { setting_id = "replace_autogun_p3_m1", type = "checkbox", default_value = true },
            { setting_id = "replace_autogun_p3_m2", type = "checkbox", default_value = true },
            { setting_id = "replace_autogun_p3_m3", type = "checkbox", default_value = true },
            {
                setting_id = "third_person",
                type = "dropdown",
                default_value = "hide",
                options = {
                    { text = "third_person_hide", value = "hide" },
                    { text = "third_person_retail", value = "retail" },
                },
            },
            {
                setting_id = "third_person_others",
                type = "dropdown",
                default_value = "retail",
                options = {
                    { text = "third_person_hide", value = "hide" },
                    { text = "third_person_retail", value = "retail" },
                },
            },
            { setting_id = "sounds", type = "checkbox", default_value = true },
            { setting_id = "volume", type = "numeric", default_value = 100, range = { 0, 200 }, decimals_number = 0 },
            {
                setting_id = "layout",
                type = "group",
                sub_widgets = {
                    { setting_id = "mmj_fov", type = "numeric", default_value = 60, range = { 20, 120 }, decimals_number = 0 },
                    { setting_id = "size", type = "numeric", default_value = 100, range = { 30, 200 }, decimals_number = 0 },
                    { setting_id = "offset_x", type = "numeric", default_value = 0, range = { -20, 20 }, decimals_number = 1 },
                    { setting_id = "offset_y", type = "numeric", default_value = 0, range = { -20, 20 }, decimals_number = 1 },
                    { setting_id = "smear_cap", type = "numeric", default_value = 100, range = { 0, 300 }, decimals_number = 0 },
                },
            },
        },
    },
}
