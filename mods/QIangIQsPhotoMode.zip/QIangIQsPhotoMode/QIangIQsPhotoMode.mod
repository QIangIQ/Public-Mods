
return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsPhotoMode` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsPhotoMode", {
			mod_script       = "QIangIQsPhotoMode/scripts/mods/QIangIQsPhotoMode/QIangIQsPhotoMode",
			mod_data         = "QIangIQsPhotoMode/scripts/mods/QIangIQsPhotoMode/QIangIQsPhotoMode_data",
			mod_localization = "QIangIQsPhotoMode/scripts/mods/QIangIQsPhotoMode/QIangIQsPhotoMode_localization",
		})
	end,
	packages = {},
}
