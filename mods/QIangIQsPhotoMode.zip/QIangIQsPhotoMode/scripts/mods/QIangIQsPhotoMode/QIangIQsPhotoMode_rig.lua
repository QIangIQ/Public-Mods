--[[
	QIangIQ's Photo Mode: the reference poses, bone by bone.

	The four reference images (A-D) were fitted offline (posefit/: landmarks and outline of each image against the
	Lacrima mesh). Every bone's turn from the bind pose is stored in QIangIQsPhotoMode_poses.lua. In game the poses are
	shown the way QIangIQsOraxia's floating form and QIangIQsEmotes' prayer show theirs:

	  * a skeleton-only driver unit (pm_driver, the human third-person skeleton, nothing keyed, built with
	    DMS\work\mmd\build_driver.py) is spawned at the player and linked to the player's root (door.lua:170);
	  * the character model units, the game's own body and gear units, and the third-person item units are unlinked
	    from the player and linked to the driver (by node name, as the character mods link them);
	  * the driver's bones are set from Lua. Nothing animates the driver, so what is set stays.

	Pose maths (root-relative, node 1 = the character's feet, x right / y forward / z up):
	  bind      B_n = B_parent * L_n             (L_n = the driver's local rotation right after it is spawned)
	  posed     T_n = R_n * B_n                  (R_n = the stored world turn; a bone without one turns with its parent)
	  local     L'_n = T_parent^-1 * T_n
	  hips      p'_hips = p_hips + T_parent^-1 * offset
	Checked offline against the fitting code (posefit/verify_export.py: the same chain gives every bone's position to
	0.0 mm). World rotation = parent world rotation * local rotation (projectile_linking.lua:18).

	Engine calls, all used this way in the game's code or the QIangIQ mods: Unit.node / has_node,
	Unit.scene_graph_parent (components/foot_ik.lua:112), Unit.local_rotation / set_local_rotation,
	Unit.local_position / set_local_position, World.link_unit / unlink_unit (LINK_MODE_NODE_NAME),
	World.update_unit_and_children (player_unit_locomotion_extension.lua:980), Quaternion.from_elements,
	Quaternion.multiply / inverse / lerp / rotate, unit_spawner:spawn_unit / mark_for_deletion.
]]

local Rig = {}

local DRIVER_FOLDER = "pm_driver"
local DRIVER_UNIT = "content/mods/qiangiq_photomode/pm_driver"
local BLEND_TIME = 0.35

-- the human third-person skeleton (the driver's .bones file, as QIangIQsEmotes_pray.lua lists it), parents first
local NODES = {
	"root_point", "j_aim_target", "j_foot_grounded", "j_hips_transform", "j_left_foot_ik_transform",
	"j_left_hand_ik_transform", "j_right_foot_ik_transform", "j_right_hand_ik_transform", "j_hips_ref",
	"j_left_foot_anim_ref", "j_right_foot_anim_ref", "j_hips", "j_left_foot_ik_orient_transform",
	"j_left_hand_ik", "j_left_hand_pv", "j_right_foot_ik_orient_transform", "j_right_hand_ik",
	"j_right_hand_pv", "j_left_foot_ik_orient_ref", "j_leftupleg", "j_right_foot_ik_orient_ref",
	"j_rightupleg", "j_spine", "j_left_foot_ik", "j_left_foot_pv", "j_leftleg", "j_right_foot_ik",
	"j_right_foot_pv", "j_rightleg", "j_spine1", "j_leftfoot", "j_rightfoot", "j_spine2", "j_leftshoulder",
	"j_lefttoebase", "j_neck", "j_rightshoulder", "j_righttoebase", "j_head", "j_leftarm", "j_rightarm",
	"j_leftforearm", "j_rightforearm", "j_lefthand", "j_righthand", "j_lefthandthumb1", "j_leftinhandindex",
	"j_leftinhandmiddle", "j_leftinhandpinky", "j_leftinhandring", "j_leftweaponattach", "j_righthandthumb1",
	"j_rightinhandindex", "j_rightinhandmiddle", "j_rightinhandpinky", "j_rightinhandring",
	"j_rightweaponattach", "j_lefthandindex1", "j_lefthandmiddle1", "j_lefthandpinky1", "j_lefthandring1",
	"j_lefthandthumb2", "j_righthandindex1", "j_righthandmiddle1", "j_righthandpinky1", "j_righthandring1",
	"j_righthandthumb2", "j_lefthandindex2", "j_lefthandmiddle2", "j_lefthandpinky2", "j_lefthandring2",
	"j_lefthandthumb3", "j_righthandindex2", "j_righthandmiddle2", "j_righthandpinky2", "j_righthandring2",
	"j_righthandthumb3", "j_lefthandindex3", "j_lefthandmiddle3", "j_lefthandpinky3", "j_lefthandring3",
	"j_righthandindex3", "j_righthandmiddle3", "j_righthandpinky3", "j_righthandring3", "j_hub_head_aim",
	"j_hub_torso_aim", "j_leftuplegroll1", "j_rightuplegroll1", "j_leftlegroll1", "j_rightlegroll1",
	"j_backchestplate", "j_frontchestplate", "j_leftarmroll1", "j_rightarmroll1", "j_leftforearmroll1",
	"j_leftforearmroll2", "j_rightforearmroll1", "j_rightforearmroll2", "j_trail_01", "j_trail_01_offhand",
	"j_trail_02", "j_trail_02_offhand", "j_trail_03", "j_trail_03_offhand", "j_trail_04",
	"j_trail_04_offhand",
}

-- bones of the Lacrima model that the driver does not have (her pauldrons): set on the model units themselves
local MODEL_ONLY = { "armor_shoulder_01_l", "armor_shoulder_01_r" }

-- weapon, pocketable, device and ability item units go onto the driver (QIangIQsOraxia float_item_slots)
local PlayerCharacterConstants = require("scripts/settings/player_character/player_character_constants")
local ITEM_SLOT_TYPES = { weapon = true, pocketable = true, device = true, ability = true }

local function unit_ok(unit)
	return unit ~= nil and Unit.alive(unit)
end

local function quat(q)
	return Quaternion.from_elements(q[1], q[2], q[3], q[4])
end

local function vec(v)
	return Vector3(v[1], v[2], v[3])
end

-- ------------------------------------------------------------------ asset --

local loader = { requested = false, ready = false, error = nil }

-- The driver unit comes from the mod's Custom folder, loaded the way every QIangIQ mod loads its custom units.
function Rig.request(mod)
	if loader.ready or loader.requested then
		return loader.ready
	end

	local custom_assets = get_mod("CustomAssets")

	if not custom_assets or not custom_assets.is_api_compatible or not custom_assets.is_api_compatible(1) then
		loader.error = "the Custom Assets loader is not running"

		return false
	end

	loader.requested = true

	local asset_id = "QIangIQsPhotoMode:" .. DRIVER_FOLDER
	local ticket, err = custom_assets.acquire(mod, asset_id, function(_, _, load_error)
		if load_error then
			loader.requested = false
			loader.error = tostring(load_error)
			mod:error("Photo mode: %s failed to load: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", asset_id, tostring(load_error))

			return
		end

		loader.ready = true
		loader.error = nil
	end, { resident = true, reference_name = asset_id })

	if not ticket then
		loader.requested = false
		loader.error = tostring(err)
	end

	return false
end

function Rig.status()
	return loader.ready, loader.error
end

function Rig.release(mod)
	local custom_assets = get_mod("CustomAssets")

	if custom_assets and custom_assets.release_owner then
		pcall(custom_assets.release_owner, mod)
	end

	loader.requested, loader.ready = false, false
end

-- ---------------------------------------------------------- what is moved --

local function slot_type(slot_name)
	local conf = PlayerCharacterConstants.slot_configuration and PlayerCharacterConstants.slot_configuration[slot_name]

	return conf and conf.slot_type
end

-- where the game linked an item's unit (visual_loadout_customization.lua:257-340), as QIangIQsOraxia float_item_link
local function item_link(slot, parent)
	local item = slot.item

	if not item then
		return nil
	end

	local node = (item.breed_attach_node and slot.breed_name and item.breed_attach_node[slot.breed_name]) or item.attach_node
	local index

	if tonumber(node) ~= nil then
		index = tonumber(node) == 1 and 1 or nil
	elseif node then
		index = Unit.has_node(parent, node) and Unit.node(parent, node) or nil
	else
		index = 1
	end

	local mode

	if World[item.link_map_mode] then
		mode = World[item.link_map_mode]
	elseif slot.skip_link_children and not item.force_link_children then
		mode = World.LINK_MODE_NONE
	else
		mode = World.LINK_MODE_NODE_NAME
	end

	return index, mode
end

local function is_body_slot(name)
	return type(name) == "string" and (string.find(name, "^slot_body_") ~= nil or string.find(name, "^slot_gear_") ~= nil)
end

-- Units linked to the player by node name that make up the visible character: QIangIQ models
-- (__qiangiq_<key>_unit / _parts on the visual loadout extension), QIangIQsNovitiate's units whose parent is the player
-- (__nov_units / __nov_parents), and the game's own body and gear units.
local function body_units(player_unit, ext)
	local list, seen = {}, {}

	-- slot: the game's body / gear slot, whose item names the node it hangs on (nil = the root, node name links)
	local function add(unit, slot)
		if unit_ok(unit) and not seen[unit] and unit ~= player_unit then
			seen[unit] = true
			list[#list + 1] = { unit = unit, slot = slot }
		end
	end

	for key, value in pairs(ext) do
		if type(key) == "string" then
			if string.find(key, "^__qiangiq_.+_unit$") then
				add(value)
			elseif string.find(key, "^__qiangiq_.+_parts$") and type(value) == "table" then
				for _, part in pairs(value) do
					add(part)
				end
			end
		end
	end

	local nov_units, nov_parents = rawget(ext, "__nov_units"), rawget(ext, "__nov_parents")

	if type(nov_units) == "table" and type(nov_parents) == "table" then
		for id, unit in pairs(nov_units) do
			if nov_parents[id] == player_unit then
				add(unit)
			end
		end
	end

	local equipment = ext._equipment

	if equipment then
		for name, slot in pairs(equipment) do
			if is_body_slot(name) and slot.parent_unit_3p == player_unit then
				local item = slot.item
				local map_mode = item and item.link_map_mode and World[item.link_map_mode]

				if map_mode == nil or map_mode == World.LINK_MODE_NODE_NAME then
					add(slot.unit_3p, slot)
				end
			end
		end
	end

	return list
end

local function item_slots(ext, player_unit, fn)
	local equipment = ext._equipment

	if not equipment then
		return
	end

	for slot_name, slot in pairs(equipment) do
		if ITEM_SLOT_TYPES[slot_type(slot_name)] and not slot.use_existing_unit_3p and slot.parent_unit_3p == player_unit
			and unit_ok(slot.unit_3p) and slot.unit_3p ~= player_unit then
			fn(slot)
		end
	end
end

-- ------------------------------------------------------------------ maths --

-- Bind data of a freshly spawned driver: per node its parent, local rotation / position and root-relative rotation.
local function capture_bind(driver)
	local bind = { nodes = {}, by_name = {} }

	for i = 1, #NODES do
		local name = NODES[i]

		if Unit.has_node(driver, name) then
			local node = Unit.node(driver, name)

			if node ~= 1 then
				local entry = { name = name, node = node, parent = Unit.scene_graph_parent(driver, node) }

				entry.local_rotation = QuaternionBox(Unit.local_rotation(driver, node))
				entry.local_position = Vector3Box(Unit.local_position(driver, node))
				bind.nodes[#bind.nodes + 1] = entry
				bind.by_name[name] = entry
			end
		end
	end

	-- root-relative rotations / positions, walking up the parent chain (node 1 = identity, origin)
	local by_node = {}

	for i = 1, #bind.nodes do
		by_node[bind.nodes[i].node] = bind.nodes[i]
	end

	bind.by_node = by_node

	local function resolve(entry)
		if entry.world_rotation then
			return entry.world_rotation:unbox(), entry.world_position:unbox()
		end

		local parent = entry.parent and by_node[entry.parent]
		local parent_rotation, parent_position

		if parent then
			parent_rotation, parent_position = resolve(parent)
		elseif entry.parent and entry.parent ~= 1 then
			-- a parent that is not in the list: its own local transform chain up to node 1
			local rotation, position = Quaternion.identity(), Vector3.zero()
			local chain, node = {}, entry.parent

			while node and node ~= 1 do
				chain[#chain + 1] = node
				node = Unit.scene_graph_parent(driver, node)
			end

			for c = #chain, 1, -1 do
				position = position + Quaternion.rotate(rotation, Unit.local_position(driver, chain[c]))
				rotation = Quaternion.multiply(rotation, Unit.local_rotation(driver, chain[c]))
			end

			parent_rotation, parent_position = rotation, position
		else
			parent_rotation, parent_position = Quaternion.identity(), Vector3.zero()
		end

		local rotation = Quaternion.multiply(parent_rotation, entry.local_rotation:unbox())
		local position = parent_position + Quaternion.rotate(parent_rotation, entry.local_position:unbox())

		entry.world_rotation = QuaternionBox(rotation)
		entry.world_position = Vector3Box(position)

		return rotation, position
	end

	for i = 1, #bind.nodes do
		resolve(bind.nodes[i])
	end

	return bind
end

-- The turn that takes the pose data's frame into the driver's root frame: both are x right / y forward / z up when
-- the build kept the axes; measured from the bind (hips -> head = up, right shoulder -> left shoulder = left) so a
-- different export frame is still right. Returns the turn and its angle in degrees for the log.
local function frame_fix(bind, rest)
	local function position(name)
		local entry = bind.by_name[name]

		return entry and entry.world_position:unbox()
	end

	local hips, head, left, right = position("j_hips"), position("j_head"), position("j_leftarm"), position("j_rightarm")

	if not (hips and head and left and right and rest) then
		return Quaternion.identity(), 0
	end

	local up_d = Vector3.normalize(head - hips)
	local left_d = Vector3.normalize(left - right)
	local up_r = Vector3.normalize(vec(rest.j_head) - vec(rest.j_hips))
	local left_r = Vector3.normalize(vec(rest.j_leftarm) - vec(rest.j_rightarm))

	-- Quaternion.look(forward, up) builds a frame from two directions: frame_d = F * frame_r
	local frame_d = Quaternion.look(Vector3.normalize(Vector3.cross(left_d, up_d)), up_d)
	local frame_r = Quaternion.look(Vector3.normalize(Vector3.cross(left_r, up_r)), up_r)
	local fix = Quaternion.multiply(frame_d, Quaternion.inverse(frame_r))
	local w = select(4, Quaternion.to_elements(fix))
	local angle = math.deg(2 * math.acos(math.min(1, math.abs(w))))

	-- under 2 degrees is the rounding of the stored rest positions: the frames are the same
	if angle < 2 then
		return Quaternion.identity(), angle
	end

	return fix, angle
end

-- Local rotation (and j_hips position) of every driver node for one pose, boxed.
local function targets(bind, pose, fix)
	local fix_inverse = Quaternion.inverse(fix)
	local turn = {} -- node -> root-relative turn R (unboxed values only live this frame, so this is built in one go)
	local posed = {} -- node -> T
	local out = {}

	local function pose_turn(name)
		local q = pose.bones[name]

		if not q then
			return nil
		end

		return Quaternion.multiply(Quaternion.multiply(fix, quat(q)), fix_inverse)
	end

	local function resolve(entry)
		local node = entry.node

		if posed[node] then
			return posed[node], turn[node]
		end

		local parent = entry.parent and bind.by_node[entry.parent]
		local parent_turn = Quaternion.identity()

		if parent then
			parent_turn = select(2, resolve(parent))
		end

		local r = pose_turn(entry.name) or parent_turn
		local t = Quaternion.multiply(r, entry.world_rotation:unbox())

		turn[node], posed[node] = r, t

		return t, r
	end

	for i = 1, #bind.nodes do
		local entry = bind.nodes[i]
		local t = resolve(entry)
		local parent = entry.parent and bind.by_node[entry.parent]
		local parent_t = parent and resolve(parent) or Quaternion.identity()
		local parent_inverse = Quaternion.inverse(parent_t)
		local position = entry.local_position:unbox()

		if entry.name == "j_hips" and pose.hips then
			position = position + Quaternion.rotate(parent_inverse, Quaternion.rotate(fix, vec(pose.hips)))
		end

		out[i] = { rotation = QuaternionBox(Quaternion.multiply(parent_inverse, t)), position = Vector3Box(position) }
	end

	-- bones only the model has: L' = (B_p^-1 R_p^-1 R_n B_p) * L_bind, with the parent on the driver
	local extra = {}

	for i = 1, #MODEL_ONLY do
		local name = MODEL_ONLY[i]
		local r = pose_turn(name)
		local parent_name = name == "armor_shoulder_01_l" and "j_leftshoulder" or "j_rightshoulder"
		local parent = bind.by_name[parent_name]

		if r and parent then
			local b = parent.world_rotation:unbox()
			local _, rp = resolve(parent)
			local delta = Quaternion.multiply(Quaternion.inverse(b), Quaternion.multiply(Quaternion.inverse(rp), Quaternion.multiply(r, b)))

			extra[name] = QuaternionBox(delta)
		end
	end

	return out, extra
end

-- ------------------------------------------------------------- life cycle --

-- Starts a pose on the player. Returns the state or nil and the reason.
function Rig.start(world, player_unit, pose_data, rest)
	if not loader.ready then
		return nil, loader.error or "the pose skeleton is still loading"
	end

	local unit_spawner = Managers.state and Managers.state.unit_spawner
	local ext = ScriptUnit.has_extension(player_unit, "visual_loadout_system")

	if not (world and unit_spawner and ext) then
		return nil, "no world or no visual loadout"
	end

	local driver = unit_spawner:spawn_unit(DRIVER_UNIT, Unit.world_pose(player_unit, 1))

	if not driver then
		return nil, "the pose skeleton could not be spawned"
	end

	local ok, bind = pcall(capture_bind, driver)

	if not ok or not bind or #bind.nodes < 50 then
		unit_spawner:mark_for_deletion(driver)

		return nil, "the pose skeleton has too few bones (" .. tostring(ok and bind and #bind.nodes or bind) .. ")"
	end

	local fix, fix_angle = frame_fix(bind, rest)
	local state = {
		world = world,
		player = player_unit,
		ext = ext,
		driver = driver,
		bind = bind,
		fix = QuaternionBox(fix),
		fix_angle = fix_angle,
		bodies = {},
		items = {},
		extras = {},
		weight = 0,
		blend_from = nil,
	}

	state.extra_targets = {}
	Rig.set_pose(state, pose_data)
	state.weight = pose_data and 0 or 1
	state.blend_from = nil

	-- the driver copies the body as it is now before anything is moved onto it: no pop on the first frame
	for i = 1, #bind.nodes do
		local entry = bind.nodes[i]

		if Unit.has_node(player_unit, entry.name) then
			local body_node = Unit.node(player_unit, entry.name)

			Unit.set_local_rotation(driver, entry.node, Unit.local_rotation(player_unit, body_node))
			Unit.set_local_position(driver, entry.node, Unit.local_position(player_unit, body_node))
		end
	end

	World.link_unit(world, driver, 1, player_unit, 1)

	local bodies = body_units(player_unit, ext)

	for i = 1, #bodies do
		local body, slot = bodies[i].unit, bodies[i].slot
		local index = 1

		if slot then
			index = item_link(slot, driver)
		end

		if index then
			World.unlink_unit(world, body)
			World.link_unit(world, body, 1, driver, index, World.LINK_MODE_NODE_NAME)
			state.bodies[#state.bodies + 1] = bodies[i]

			for e = 1, #MODEL_ONLY do
				local name = MODEL_ONLY[e]

				if Unit.has_node(body, name) then
					local node = Unit.node(body, name)

					state.extras[#state.extras + 1] = { unit = body, node = node, name = name, bind = QuaternionBox(Unit.local_rotation(body, node)) }
				end
			end
		end
	end

	item_slots(ext, player_unit, function(slot)
		local index, mode = item_link(slot, driver)

		if index then
			World.unlink_unit(world, slot.unit_3p)
			World.link_unit(world, slot.unit_3p, 1, driver, index, mode)
			state.items[#state.items + 1] = { unit = slot.unit_3p, slot = slot }
		end
	end)

	-- QIangIQsArmoryVis hangs stowed weapons on this unit when it is set (see QIangIQsOraxia float_parent)
	if rawget(ext, "__qiangiq_body_host") == nil then
		ext.__qiangiq_body_host = driver
		state.set_body_host = true
	end

	World.update_unit_and_children(world, driver)

	return state, nil, #state.bodies, #state.items
end

-- Switches the pose the driver blends to. pose_data nil = follow mode: the driver copies the game's own animated body
-- every frame (as the QIangIQsEmotes prayer does), so emotes and idles still play and the head can turn to the camera.
function Rig.set_pose(state, pose_data)
	local out, extra

	if pose_data then
		out, extra = targets(state.bind, pose_data, state.fix:unbox())
	end

	if unit_ok(state.driver) and (state.targets or pose_data) then
		local current = {}

		for i = 1, #state.bind.nodes do
			local node = state.bind.nodes[i].node

			current[i] = { rotation = QuaternionBox(Unit.local_rotation(state.driver, node)), position = Vector3Box(Unit.local_position(state.driver, node)) }
		end

		state.blend_from = current
		state.weight = 0
	end

	-- the pauldrons go back to their bind turn when the pose ends
	if not pose_data then
		for i = 1, #state.extras do
			local e = state.extras[i]

			if unit_ok(e.unit) then
				Unit.set_local_rotation(e.unit, e.node, e.bind:unbox())
			end
		end
	end

	state.targets, state.extra_targets, state.pose = out, extra or {}, pose_data
end

-- Where the head should look (world position, e.g. the camera); nil = not at all.
function Rig.set_look(state, position)
	if position then
		state.look_target = Vector3Box(position)
	else
		state.look_target = nil
	end
end

local LOOK_LIMIT = math.rad(75)
local LOOK_NECK_SHARE = 0.4
local LOOK_SPEED = 3 -- weight per second

-- Head (and some neck) turned so the face points at the look target: the face's forward is the character's forward at
-- bind, carried in the head's own frame. World rotations are read after World.update_unit_and_children.
local function apply_look(state, dt)
	local want = state.look_target and 1 or 0

	state.look_weight = state.look_weight or 0

	if state.look_weight < want then
		state.look_weight = math.min(want, state.look_weight + dt * LOOK_SPEED)
	elseif state.look_weight > want then
		state.look_weight = math.max(want, state.look_weight - dt * LOOK_SPEED)
	end

	local weight = state.look_weight
	local target = state.look_target and state.look_target:unbox() or state.last_look and state.last_look:unbox()

	if weight <= 0 or not target then
		return false
	end

	if state.look_target then
		state.last_look = Vector3Box(target)
	end

	local driver = state.driver
	local neck, head = state.bind.by_name.j_neck, state.bind.by_name.j_head

	if not (neck and head) then
		return false
	end

	local head_rotation = Unit.world_rotation(driver, head.node)
	local head_position = Unit.world_position(driver, head.node)
	local forward = Quaternion.rotate(state.fix:unbox(), Vector3(0, 1, 0))
	local face_local = Quaternion.rotate(Quaternion.inverse(head.world_rotation:unbox()), forward)
	local face = Quaternion.rotate(head_rotation, face_local)
	local to = target - head_position

	if Vector3.length(to) < 0.05 then
		return false
	end

	to = Vector3.normalize(to)

	local axis = Vector3.cross(face, to)
	local length = Vector3.length(axis)

	if length < 0.00001 then
		return false
	end

	axis = axis / length

	local angle = math.min(math.atan2(length, Vector3.dot(face, to)), LOOK_LIMIT) * weight
	local smooth = weight * weight * (3 - 2 * weight)

	angle = angle * smooth / math.max(weight, 0.0001)

	local neck_world = Quaternion.multiply(Quaternion.axis_angle(axis, angle * LOOK_NECK_SHARE), Unit.world_rotation(driver, neck.node))
	local neck_parent = neck.parent and Unit.world_rotation(driver, neck.parent) or Unit.world_rotation(driver, 1)
	local head_world = Quaternion.multiply(Quaternion.axis_angle(axis, angle), head_rotation)

	Unit.set_local_rotation(driver, neck.node, Quaternion.multiply(Quaternion.inverse(neck_parent), neck_world))
	Unit.set_local_rotation(driver, head.node, Quaternion.multiply(Quaternion.inverse(neck_world), head_world))

	return true
end

-- Every frame (before the world update): blend in, then hold (or follow the body), then the head look.
function Rig.update(state, dt)
	local driver = state.driver

	if not (unit_ok(driver) and unit_ok(state.player)) then
		return false
	end

	dt = dt > 0 and dt or 0.016
	state.weight = math.min(1, state.weight + dt / BLEND_TIME)

	local w = state.weight
	local s = w * w * (3 - 2 * w)
	local nodes, targets_list, from = state.bind.nodes, state.targets, state.blend_from
	local player = state.player

	for i = 1, #nodes do
		local entry = nodes[i]
		local rotation, position

		if targets_list then
			rotation, position = targets_list[i].rotation:unbox(), targets_list[i].position:unbox()
		elseif Unit.has_node(player, entry.name) then
			local body_node = Unit.node(player, entry.name)

			rotation, position = Unit.local_rotation(player, body_node), Unit.local_position(player, body_node)
		else
			rotation, position = entry.local_rotation:unbox(), entry.local_position:unbox()
		end

		if s < 1 then
			local from_rotation, from_position

			if from then
				from_rotation, from_position = from[i].rotation:unbox(), from[i].position:unbox()
			elseif targets_list and Unit.has_node(player, entry.name) then
				local body_node = Unit.node(player, entry.name)

				from_rotation, from_position = Unit.local_rotation(player, body_node), Unit.local_position(player, body_node)
			end

			if from_rotation then
				rotation = Quaternion.lerp(from_rotation, rotation, s)
				position = Vector3.lerp(from_position, position, s)
			end
		end

		Unit.set_local_rotation(driver, entry.node, rotation)
		Unit.set_local_position(driver, entry.node, position)
	end

	if s >= 1 then
		state.blend_from = nil
	end

	if targets_list then
		local extras = state.extras

		for i = 1, #extras do
			local extra = extras[i]
			local delta = state.extra_targets[extra.name]

			if delta and unit_ok(extra.unit) then
				local bind = extra.bind:unbox()

				Unit.set_local_rotation(extra.unit, extra.node, Quaternion.lerp(bind, Quaternion.multiply(delta:unbox(), bind), s))
			end
		end
	end

	World.update_unit_and_children(state.world, driver)

	if apply_look(state, dt) then
		World.update_unit_and_children(state.world, driver)
	end

	-- one check a second in, for the log: does the model's hand sit on the driver's hand (posed) or the game's body's?
	state.age = (state.age or 0) + dt

	if not state.check and state.age > 1 then
		local entry = state.bind.by_name.j_righthand
		local body = state.bodies[1] and state.bodies[1].unit

		if entry and unit_ok(body) and Unit.has_node(body, "j_righthand") and Unit.has_node(player, "j_righthand") then
			local on_driver = Unit.world_position(driver, entry.node)
			local on_body = Unit.world_position(body, Unit.node(body, "j_righthand"))
			local on_player = Unit.world_position(player, Unit.node(player, "j_righthand"))

			state.check = string.format("right hand of the model is %.3f m from the pose skeleton's and %.3f m from the game body's (%d bodies, %s)",
				Vector3.length(on_body - on_driver), Vector3.length(on_body - on_player), #state.bodies, state.targets and "posed" or "following")
		else
			state.check = string.format("pose check skipped (%d bodies)", #state.bodies)
		end
	end

	if not state.reported then
		state.reported = true
		state.first_frame_ok = true
	end

	return true
end

-- Everything back onto the player, then the driver goes.
function Rig.stop(state)
	local world = state.world
	local player = state.player
	local player_ok = unit_ok(player)

	for i = 1, #state.extras do
		local extra = state.extras[i]

		if unit_ok(extra.unit) then
			Unit.set_local_rotation(extra.unit, extra.node, extra.bind:unbox())
		end
	end

	for i = 1, #state.items do
		local item = state.items[i]

		if unit_ok(item.unit) then
			World.unlink_unit(world, item.unit)

			if player_ok then
				local index, mode = item_link(item.slot, player)

				World.link_unit(world, item.unit, 1, player, index or 1, mode)
			end
		end
	end

	for i = 1, #state.bodies do
		local body, slot = state.bodies[i].unit, state.bodies[i].slot

		if unit_ok(body) then
			World.unlink_unit(world, body)

			if player_ok then
				local index = slot and item_link(slot, player) or 1

				World.link_unit(world, body, 1, player, index or 1, World.LINK_MODE_NODE_NAME)
			end
		end
	end

	if state.set_body_host and state.ext and rawget(state.ext, "__qiangiq_body_host") == state.driver then
		state.ext.__qiangiq_body_host = nil

		local armory_vis = get_mod("QIangIQsArmoryVis")

		if armory_vis and armory_vis.release_host then
			pcall(armory_vis.release_host, state.ext)
		end
	end

	if unit_ok(state.driver) then
		local unit_spawner = Managers.state and Managers.state.unit_spawner

		if unit_spawner then
			unit_spawner:mark_for_deletion(state.driver)
		end
	end

	if player_ok and state.ext and state.ext.force_update_item_visibility then
		pcall(state.ext.force_update_item_visibility, state.ext)
	end
end

-- Camera of a pose in the world: the stored camera is in the character's frame (feet = origin).
function Rig.camera(state_or_player, pose_data, fix)
	local player = type(state_or_player) == "table" and state_or_player.player or state_or_player
	local camera = pose_data.camera
	local root_position = Unit.world_position(player, 1)
	local root_rotation = Unit.world_rotation(player, 1)

	fix = fix or Quaternion.identity()

	local frame = Quaternion.multiply(root_rotation, fix)
	local position = root_position + Quaternion.rotate(frame, vec(camera.pos))
	local forward = Quaternion.rotate(frame, vec(camera.fwd))
	local up = Quaternion.rotate(frame, vec(camera.up))

	return position, Quaternion.look(forward, up), math.rad(camera.vfov)
end

Rig.NODES = NODES

return Rig
