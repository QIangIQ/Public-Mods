local mod = get_mod("QIangIQsPhotoMode")

--[[
	Photo mode for missions, the Mourningstar hub and the Psykhanium. Standalone: no other mod is needed.

	Camera : CameraManager._update_camera_properties is hooked and the pose of the player's camera is replaced
	         (the technique of QIangIQsIsoCam). RootCamera.use_collision is forced off; the selfie camera does its
	         own wall check. Depth of field goes through camera_data.shading_environment, which
	         CameraManager.shading_callback reads (camera_manager.lua:291-310).
	Input  : the character is detached from the keyboard and mouse (HumanUnitInput.get returns neutral values,
	         the orientation is put back after DefaultPlayerOrientation / HubPlayerOrientation.pre_update). The photo
	         mode itself reads Keyboard / Mouse directly, like the game's free flight (free_flight_default_input.lua).
	HUD    : UIHud.draw returns early while the HUD is hidden.
	Time   : Managers.world:set_world_update_time_scale (client only, world_manager.lua:199); in the Psykhanium on a
	         host Managers.time:set_local_scale("gameplay") as training_grounds_steps.lua does.
	Poses  : the four reference poses (A-D) and the selfie-stick pose are set bone by bone on a skeleton-only driver
	         unit that the character is moved onto (QIangIQsPhotoMode_rig.lua, data in QIangIQsPhotoMode_poses.lua,
	         fitted offline to the reference images). Each comes with the camera of its image. The game's emote
	         items (item.animation_event / face_animation_event, emote_manager.lua:96-127) are played on the body
	         through the hub's third-person state machine, as the emote manager does in the hub.
]]

local PlayerUnitAnimationState = require("scripts/extension_systems/animation/utilities/player_unit_animation_state")
local PlayerUnitAnimationMachineSettings = require("scripts/settings/animation/player_unit_animation_state_machine_settings")
local WeaponTemplate = require("scripts/utilities/weapon/weapon_template")
local WeaponTemplates = require("scripts/settings/equipment/weapon_templates/weapon_templates")
local MasterItems = require("scripts/backend/master_items")
local Rig = mod:io_dofile("QIangIQsPhotoMode/scripts/mods/QIangIQsPhotoMode/QIangIQsPhotoMode_rig")
local PoseData = mod:io_dofile("QIangIQsPhotoMode/scripts/mods/QIangIQsPhotoMode/QIangIQsPhotoMode_poses")

local PACKAGE_REFERENCE = "QIangIQsPhotoMode"
local EMOTE_SLOTS = {
	slot_animation_emote_1 = true,
	slot_animation_emote_2 = true,
	slot_animation_emote_3 = true,
	slot_animation_emote_4 = true,
	slot_animation_emote_5 = true,
}
local FACE_NEUTRAL = "pose_neutral" -- emote_manager.lua:72
local FACE_FEAR = "pose_fear" -- character_appearance_view.lua:3318
local HEAD_NODE = "j_head"
local HUMAN_HEIGHT = 1.7
local TIME_SLOW, TIME_FROZEN = 2, 3

-- Camera angle presets. The first four are the reference images: their pose and their exact camera (image = pose
-- id in QIangIQsPhotoMode_poses.lua). The others orbit the character: distance (m, human sized), look-at height
-- (fraction of the body height), orbit yaw (deg, 0 = in front of the character), elevation (deg, + = camera above),
-- fov, roll.
local ANGLES = {
	{ id = "hero_full", image = "A" },
	{ id = "full_low", image = "B" },
	{ id = "portrait_tilt", image = "C" },
	{ id = "blade_closeup", image = "D" },
	{ id = "side_profile", dist = 2.4, look = 0.82, yaw = 90, elev = 2, fov = 32 },
	{ id = "from_behind", dist = 3.5, look = 0.56, yaw = 180, elev = 4, fov = 40 },
	{ id = "top_down", dist = 3.5, look = 0.50, yaw = 0, elev = 70, fov = 40 },
	{ id = "wide_establishing", dist = 7.5, look = 0.55, yaw = 25, elev = 4, fov = 55 },
}

local cfg = {}
local pm = {
	active = false,
	need_init = true,
	mode = "free",
	-- free camera
	x = 0, y = 0, z = 0, yaw = 0, pitch = 0,
	-- selfie camera
	s_yaw = 38, s_elev = 2, s_dist = 4.4, s_look = 0.56,
	roll = 0, fov = 0.7,
	-- mounted cameras (weapon tip, helmet): view offsets from the mount
	m_yaw = 0, m_pitch = 0, m_back = 0, m_up = 0, m_side = 0,
	image_id = nil, -- reference image whose camera the "image" mode shows
	pose_offset = 0,
	pose_entry = nil,
	base_yaw = 0, -- character facing when the photo mode started (the selfie yaw is relative to it)
	angle_index = 0,
	hud_hidden = false,
	time_mode = 1,
	dof = false,
	dof_offset = 0,
	drift = false,
	keyframes = {},
	path = nil, -- { t, dir }
	pose_index = 0,
	rig = nil, -- the driver while a reference pose is shown (QIangIQsPhotoMode_rig.lua)
	rig_pose = nil, -- id of the pose shown or wanted
	rig_owner = nil, -- "image" (J/K, angle presets), "stick" (the selfie-stick camera) or "look" (no pose, head to the camera)
	rig_wanted = false, -- waiting for the driver unit to load
	face_index = 0,
	look = false, -- V: the head turns to the camera
	key_state = {},
	key_index = {},
	own_unit = nil,
	last_dt = 0,
}
local posing = {} -- [unit] = "emote" or "action" while a game animation is played by the photo mode
local packages = {}
local emote_list, face_list

local function refresh_settings()
	cfg.move_speed = mod:get("move_speed")
	cfg.look_sens = mod:get("look_sens")
	cfg.start_mode = mod:get("start_mode")
	cfg.selfie_collision = mod:get("selfie_collision")
	cfg.face_camera = mod:get("face_camera")
	cfg.hide_hud_on_start = mod:get("hide_hud_on_start")
	cfg.time_slow = mod:get("time_slow")
	cfg.orbit_speed = mod:get("orbit_speed")
	cfg.pan_speed = mod:get("pan_speed")
	cfg.dolly_speed = mod:get("dolly_speed")
	cfg.rise_speed = mod:get("rise_speed")
	cfg.path_duration = mod:get("path_duration")
	cfg.path_mode = mod:get("path_mode")
	cfg.dof_region = mod:get("dof_region")
	cfg.dof_padding = mod:get("dof_padding")
	cfg.dof_scale = mod:get("dof_scale")
	cfg.auto_focus = mod:get("auto_focus")
	cfg.pose_hold = mod:get("pose_hold")
end
refresh_settings()

mod.on_setting_changed = function()
	refresh_settings()
end

-- ------------------------------------------------------------------ helpers --

local function local_player()
	return Managers.player and Managers.player:local_player(1)
end

local function player_unit()
	local player = local_player()
	local unit = player and player.player_unit

	if unit and ALIVE[unit] then
		return unit
	end
end

local function game_mode_name()
	local manager = Managers.state and Managers.state.game_mode

	return manager and manager:game_mode_name()
end

local function is_server()
	return Managers.state and Managers.state.game_session and Managers.state.game_session:is_server()
end

local function in_menu()
	return (Managers.input and Managers.input:cursor_active()) or (Managers.ui and Managers.ui:chat_using_input())
end

local function key_index(name)
	local index = pm.key_index[name]

	if index == nil then
		local ok, value = pcall(Keyboard.button_index, name)

		index = ok and value or false
		pm.key_index[name] = index
	end

	return index
end

local function key_down(name)
	local index = key_index(name)

	return index and Keyboard.button(index) > 0.5 or false
end

local function key_pressed(name)
	local index = key_index(name)

	return index and Keyboard.pressed(index) or false
end

local function notify(text, ...)
	mod:notify(text, ...)
end

local function wrap(index, count, step)
	return (index + step) % (count + 1) -- 0 = off, 1..count
end

-- ------------------------------------------------------ state machines (poses) --

local function hub_template(breed_name)
	return WeaponTemplates[breed_name == "ogryn" and "unarmed_hub_ogryn" or "unarmed_hub_human"]
end

-- third-person half of PlayerUnitAnimationState.set_anim_state_machine (player_unit_animation_state.lua:41-55, 111-128)
local function set_state_machine_3p(unit, ext, weapon_template)
	local unit_data_extension = ScriptUnit.extension(unit, "unit_data_system")
	local breed_name = unit_data_extension:breed_name()
	local state_machine_3p, _, initialization_variables = WeaponTemplate.state_machines(weapon_template, breed_name)
	local settings = state_machine_3p and PlayerUnitAnimationMachineSettings[state_machine_3p]

	if not settings then
		return false
	end

	Unit.set_animation_state_machine_blend_base_layer(unit, state_machine_3p, settings.blend_time)

	if initialization_variables then
		for variable_name, value in pairs(initialization_variables) do
			local variable_id = Unit.animation_find_variable(unit, variable_name)

			if variable_id then
				value = type(value) == "function" and value(unit) or value

				Unit.animation_set_variable(unit, variable_id, value)
			end
		end
	end

	PlayerUnitAnimationState.cache_anim_variable_ids(unit, ext._first_person_unit, ext._anim_variable_ids_third_person, ext._anim_variable_ids_first_person)

	local aim_extension = ScriptUnit.has_extension(unit, "aim_system")

	if aim_extension then
		aim_extension:state_machine_changed(unit)
	end

	return true
end

local function current_weapon_template(unit)
	local unit_data_extension = ScriptUnit.has_extension(unit, "unit_data_system")

	if not unit_data_extension then
		return nil
	end

	local weapon_action_component = unit_data_extension:read_component("weapon_action")

	return weapon_action_component and WeaponTemplate.current_weapon_template(weapon_action_component)
end

-- A state machine's resource name is the name of its package (weapon_template_resource_dependencies.lua:55-57)
local function with_package(name, fn)
	local entry = packages[name]

	if entry and entry.loaded then
		fn()

		return
	end

	if not entry then
		if not Application.can_get_resource("package", name) then
			mod:error("Photo mode: the package %s does not exist in this game version.", name)

			return
		end

		entry = { loaded = false, waiting = { fn } }
		packages[name] = entry
		entry.id = Managers.package:load(name, PACKAGE_REFERENCE, function()
			entry.loaded = true

			local waiting = entry.waiting

			entry.waiting = {}

			for i = 1, #waiting do
				waiting[i]()
			end
		end)

		return
	end

	entry.waiting[#entry.waiting + 1] = fn
end

local function release_packages()
	for name, entry in pairs(packages) do
		if entry.id and Managers.package then
			Managers.package:release(entry.id)
		end

		packages[name] = nil
	end
end

-- the logic of EmoteManager._trigger_face_event (emote_manager.lua:47-65), with the reason when it does nothing
local function face_event(unit, event_name)
	if not event_name or event_name == "" then
		return false, "no event"
	end

	local visual_loadout = unit and ScriptUnit.has_extension(unit, "visual_loadout_system")

	if not visual_loadout then
		return false, "no visual loadout"
	end

	local face_unit = visual_loadout:unit_3p_from_slot("slot_body_face")

	if not face_unit or not Unit.alive(face_unit) then
		return false, "this character has no face unit"
	end

	if not Unit.has_animation_state_machine(face_unit) then
		return false, "the face unit has no animation state machine"
	end

	if not Unit.has_animation_event(face_unit, event_name) then
		return false, "the face has no event " .. tostring(event_name)
	end

	Unit.animation_event(face_unit, event_name)

	return true
end

-- Weapons and other items stay in the hands during an emote (the emote is not the weapon's animation): hidden while
-- it plays, as QIangIQsEmotes hide_equipment does. Body, gear and companion units stay.
local function hide_items(ext)
	local equipment = ext and ext._equipment

	if not equipment then
		return
	end

	for name, slot in pairs(equipment) do
		local unit = slot.unit_3p

		if type(name) == "string" and not string.find(name, "^slot_body_") and not string.find(name, "^slot_gear_")
			and name ~= "slot_companion" and unit and Unit.alive(unit) and unit ~= ext._unit then
			Unit.set_unit_visibility(unit, false, true)

			local attachments = slot.attachments_by_unit_3p and slot.attachments_by_unit_3p[unit]

			if attachments then
				for i = 1, #attachments do
					if attachments[i] and Unit.alive(attachments[i]) then
						Unit.set_unit_visibility(attachments[i], false, true)
					end
				end
			end
		end
	end
end

local stop_body_pose

function stop_body_pose(unit, restore)
	if not posing[unit] then
		return
	end

	local kind = posing[unit]

	posing[unit] = nil

	if not (unit and Unit.alive(unit)) then
		return
	end

	if kind == "action" then
		local variable = Unit.animation_find_variable(unit, "attack_speed")

		if variable then
			Unit.animation_set_variable(unit, variable, 1)
		end
	end

	if restore then
		local ext = ScriptUnit.has_extension(unit, "animation_system")
		local weapon_template = current_weapon_template(unit)

		if ext and weapon_template then
			set_state_machine_3p(unit, ext, weapon_template)

			-- the recorded animation states belong to the hub machine the emote ran; a server correction would replay
			-- them onto the restored machine (player_unit_animation_extension.lua:191-208)
			if ext._animation_state_component and ext._first_person_unit then
				pcall(PlayerUnitAnimationState.record_animation_state, ext._animation_state_component, unit, ext._first_person_unit)
			end
		end
	end

	face_event(unit, FACE_NEUTRAL)

	if kind == "emote" then
		local visual = ScriptUnit.has_extension(unit, "visual_loadout_system")

		if visual and visual.force_update_item_visibility then
			pcall(visual.force_update_item_visibility, visual)
		end
	end
end

local function play_body_pose(unit, event, face)
	local ext = ScriptUnit.has_extension(unit, "animation_system")
	local unit_data_extension = ScriptUnit.has_extension(unit, "unit_data_system")

	if not ext or not unit_data_extension or not ext._anim_variable_ids_third_person then
		return false
	end

	local breed_name = unit_data_extension:breed_name()
	local template = hub_template(breed_name)
	local state_machine_3p = template and WeaponTemplate.state_machines(template, breed_name)

	if not state_machine_3p then
		return false
	end

	with_package(state_machine_3p, function()
		if not (unit and Unit.alive(unit)) or not pm.active then
			return
		end

		if posing[unit] == "action" then
			stop_body_pose(unit, true)
		end

		if not posing[unit] and not set_state_machine_3p(unit, ext, template) then
			return
		end

		posing[unit] = "emote"
		hide_items(ScriptUnit.has_extension(unit, "visual_loadout_system"))

		if event and Unit.has_animation_event(unit, event) then
			-- played on the unit itself, not through the animation extension: on a host the extension would send the
			-- event index to clients whose copy of this body still runs the weapon's state machine
			Unit.animation_event(unit, event)
		end

		face_event(unit, face)
	end)

	return true
end

-- A pose from the wielded weapon's own 3p animations: ActionBase.trigger_anim_event (action_base.lua:83-95) plays
-- action.anim_event_3p with the variables attack_speed and action_time_offset; here the event is started at a chosen
-- time offset and the animation is held by setting attack_speed to 0 (hold = false plays it out).
local function play_action_pose(unit, event, offset, hold)
	if not unit or not Unit.alive(unit) then
		return false, "no unit"
	end

	if posing[unit] then
		stop_body_pose(unit, true)
	end

	if not Unit.has_animation_event(unit, event) then
		return false, "the event " .. tostring(event) .. " is not in this weapon's 3p animations"
	end

	local speed_variable = Unit.animation_find_variable(unit, "attack_speed")
	local offset_variable = Unit.animation_find_variable(unit, "action_time_offset")

	if offset_variable then
		Unit.animation_set_variable(unit, offset_variable, offset)
	end

	if speed_variable then
		Unit.animation_set_variable(unit, speed_variable, hold and 0 or 1)
	end

	Unit.animation_event(unit, event)

	posing[unit] = "action"

	return true, (speed_variable and "" or "no attack_speed variable, the animation plays out")
end

-- -------------------------------------------------------- reference poses --

local function pose_by_id(id)
	for i = 1, #PoseData.poses do
		if PoseData.poses[i].id == id then
			return PoseData.poses[i]
		end
	end
end

local function stop_rig_pose()
	local state = pm.rig

	pm.rig, pm.rig_pose, pm.rig_owner, pm.rig_wanted = nil, nil, nil, false

	if state then
		local ok, err = pcall(Rig.stop, state)

		if not ok then
			mod:error("Photo mode: putting the character back failed: %s", tostring(err))
		end
	end
end

-- Ends the reference pose. With the look at the camera on (V) the driver stays and follows the game's animation again,
-- so the head can keep turning to the camera; otherwise everything goes back onto the player.
local function release_rig_pose()
	if pm.look and pm.rig then
		Rig.set_pose(pm.rig, nil)
		pm.rig_pose, pm.rig_owner = nil, "look"
	else
		stop_rig_pose()
	end
end

-- Shows a reference pose (owner "image": J/K and the angle presets, "stick": the selfie-stick camera; pose id nil with
-- owner "look": no pose, the driver follows the game's animation and only the head is turned to the camera). Returns true
-- when it is shown, or will be once the pose skeleton has loaded; false and the reason when it cannot be.
local function show_rig_pose(id, owner)
	local unit = pm.own_unit
	local pose = id and pose_by_id(id)

	if not ((pose or owner == "look") and unit and ALIVE[unit]) then
		return false, "no such pose"
	end

	if pose and posing[unit] then
		stop_body_pose(unit, true)
	end

	pm.rig_pose, pm.rig_owner = id, owner

	if pm.rig then
		if pose then
			Rig.set_pose(pm.rig, pose)
		end

		return true
	end

	if not Rig.request(mod) then
		local _, err = Rig.status()

		if err then
			pm.rig_pose, pm.rig_owner = nil, nil

			return false, err
		end

		pm.rig_wanted = true

		return true, "loading"
	end

	local world = Managers.world and Managers.world:world("level_world")
	local state, err, bodies, items = Rig.start(world, unit, pose, PoseData.rest)

	if not state then
		pm.rig_pose, pm.rig_owner = nil, nil

		return false, err
	end

	pm.rig = state
	mod:info("Photo mode: pose %s on (%s), %d body units and %d item units moved, frame turn %.1f deg", tostring(id), tostring(owner), bodies or 0, items or 0, state.fix_angle or 0)

	if bodies == 0 then
		notify("Photo mode: no character units were found to pose")
	end

	return true
end

-- --------------------------------------------------------------- pose lists --

local function localized(name)
	if not name then
		return nil
	end

	local ok, text = pcall(Localize, name)

	return ok and text or name
end

local action_list, action_list_template

local function build_action_list(unit)
	local template = unit and current_weapon_template(unit)
	local name = template and template.name or false

	if action_list and action_list_template == name then
		return action_list
	end

	action_list, action_list_template = {}, name

	local seen = {}
	local actions = template and template.actions

	if actions then
		for action_name, action in pairs(actions) do
			if type(action) == "table" and not action.skip_3p_anims then
				local event = action.anim_event_3p or action.anim_event

				if type(event) == "string" and not seen[event] then
					seen[event] = true
					action_list[#action_list + 1] = { kind = "action", name = tostring(action_name) .. " (" .. event .. ")", event = event }
				end
			end
		end
	end

	table.sort(action_list, function(a, b)
		return a.name < b.name
	end)

	return action_list
end

local function build_lists()
	if emote_list then
		return
	end

	emote_list = {}
	face_list = { { event = FACE_NEUTRAL, name = "Neutral" }, { event = FACE_FEAR, name = "Fear" } }

	local seen_face = { [FACE_NEUTRAL] = true, [FACE_FEAR] = true }
	local items = MasterItems.get_cached()

	if not items then
		emote_list, face_list = nil, nil
		mod:info("Photo mode: MasterItems.get_cached() is empty, no emote or face list")

		return
	end

	for id, item in pairs(items) do
		local slot = item.slots and item.slots[1]

		if slot and EMOTE_SLOTS[slot] and item.animation_event then
			emote_list[#emote_list + 1] = {
				kind = "emote",
				id = id,
				name = localized(item.display_name) or id,
				event = item.animation_event,
				face = item.face_animation_event,
			}

			local face = item.face_animation_event

			if face and face ~= "" and not seen_face[face] then
				seen_face[face] = true
				face_list[#face_list + 1] = { event = face, name = (localized(item.display_name) or id) .. " (face)" }
			end
		end
	end

	mod:info("Photo mode: %d emote items, %d face events found", #emote_list, #face_list)

	table.sort(emote_list, function(a, b)
		return a.name < b.name
	end)
	table.sort(face_list, function(a, b)
		if a.event == FACE_NEUTRAL or b.event == FACE_NEUTRAL then
			return a.event == FACE_NEUTRAL and b.event ~= FACE_NEUTRAL
		end

		return a.name < b.name
	end)
end

-- ------------------------------------------------------------ camera maths --

local function body_scale(unit)
	local root = Unit.world_position(unit, 1)
	local top

	if Unit.has_node(unit, HEAD_NODE) then
		top = Unit.world_position(unit, Unit.node(unit, HEAD_NODE))
	else
		top = root + Vector3(0, 0, 1.6)
	end

	local height = math.max(0.5, top.z - root.z) / 0.93

	return root, top, height
end

local function with_roll(rotation, roll)
	if roll == 0 then
		return rotation
	end

	return Quaternion.multiply(Quaternion.axis_angle(Quaternion.forward(rotation), roll), rotation)
end

local function raycast_closest(physics_world, from, to)
	local direction = to - from
	local distance = Vector3.length(direction)

	if distance < 0.01 then
		return nil
	end

	local hit, position = PhysicsWorld.raycast(physics_world, from, direction / distance, distance, "closest", "types", "statics", "collision_filter", "filter_camera_sweep")

	if hit and position then
		return position
	end
end

-- "selfie" is the orbit camera of the angle presets; "stick" is the real selfie stick (her arm holds it out, pose S).
local CAMERA_MODES = { "free", "selfie", "stick", "weapon", "weapon_selfie", "helmet" }
-- mounted cameras, metres from the mount: back = along the weapon / the view (+ = beyond the tip / ahead of the
-- face), up = above the weapon / the eyes, side = to the right of it. The weapon camera sits on top of the blade or
-- barrel like an action camera so the weapon is not around the lens; the helmet camera is clamped to the right side
-- of the head.
local MODE_DEFAULTS = {
	weapon = { back = -0.02, up = 0.07, side = 0.04 },
	weapon_selfie = { back = 0.55, up = 0.12, side = 0 },
	helmet = { back = 0.03, up = 0.05, side = 0.16 },
}

-- Tip of the wielded weapon and the direction it points: the far end (from the right hand) of the oriented box of
-- the weapon's third-person unit (Unit.box returns the box pose and half extents, as in vector_field_push_pull.lua:98),
-- or its fx_muzzle_01 node when it has one (the muzzle node of the ranged weapon templates).
local function weapon_mount(unit)
	local visual_loadout = ScriptUnit.has_extension(unit, "visual_loadout_system")
	local unit_data = ScriptUnit.has_extension(unit, "unit_data_system")
	local inventory = unit_data and unit_data:read_component("inventory")
	local slot = inventory and inventory.wielded_slot
	local weapon = slot and visual_loadout and visual_loadout:unit_3p_from_slot(slot)

	if not weapon or not Unit.alive(weapon) then
		return nil
	end

	local ok, pose, half = pcall(Unit.box, weapon)

	if not ok or not pose or not half then
		return nil
	end

	local center = Matrix4x4.translation(pose)
	local axes = { Matrix4x4.x(pose), Matrix4x4.y(pose), Matrix4x4.z(pose) }
	local extents = { half.x, half.y, half.z }
	local longest = 1

	for i = 2, 3 do
		if extents[i] > extents[longest] then
			longest = i
		end
	end

	local axis, length = axes[longest], extents[longest]
	local hand = Unit.has_node(unit, "j_righthand") and Unit.world_position(unit, Unit.node(unit, "j_righthand")) or center
	local end_a, end_b = center + axis * length, center - axis * length
	local tip, butt = end_a, end_b

	if Vector3.length(end_b - hand) > Vector3.length(end_a - hand) then
		tip, butt = end_b, end_a
	end

	local direction = Vector3.normalize(tip - butt)

	if Unit.has_node(weapon, "fx_muzzle_01") then
		tip = Unit.world_position(weapon, Unit.node(weapon, "fx_muzzle_01"))
	end

	return tip, direction
end

local function mode_defaults(mode)
	local d = MODE_DEFAULTS[mode]

	pm.m_yaw, pm.m_pitch = 0, 0
	pm.m_back = d and d.back or 0
	pm.m_up = d and d.up or 0
	pm.m_side = d and d.side or 0
end

local function compose(camera_manager)
	local unit = pm.own_unit

	if (pm.mode == "image" or pm.mode == "stick") and unit and ALIVE[unit] then
		local pose = pose_by_id(pm.mode == "stick" and "S" or pm.image_id)

		if pose then
			local position, rotation, fov = Rig.camera(unit, pose, pm.rig and pm.rig.fix:unbox())
			local _, head = body_scale(unit)
			-- the game multiplies the field of view by the player's setting (camera_manager.lua:948-952): divided out
			-- here so the shot is the reference image's
			local multiplier = camera_manager and camera_manager._fov_multiplier or 1

			return position, with_roll(rotation, pm.roll), fov / multiplier, Vector3.length(position - head)
		end
	end

	if (pm.mode == "weapon" or pm.mode == "weapon_selfie") and unit and ALIVE[unit] then
		local tip, direction = weapon_mount(unit)

		if tip then
			-- the weapon's own up (world up made square to it) and right
			local weapon_up = Vector3.up() - direction * Vector3.dot(Vector3.up(), direction)

			weapon_up = Vector3.length(weapon_up) > 0.001 and Vector3.normalize(weapon_up) or Vector3(0, 0, 1)

			local weapon_right = Vector3.cross(direction, weapon_up)
			local position = tip + direction * pm.m_back + weapon_up * pm.m_up + weapon_right * pm.m_side
			local _, head = body_scale(unit)
			local rotation

			if pm.mode == "weapon" then
				rotation = Quaternion.look(direction, Vector3.up())
			else
				rotation = Quaternion.look(Vector3.normalize(head - position), Vector3.up())
			end

			rotation = Quaternion.multiply(rotation, Quaternion.from_yaw_pitch_roll(math.rad(pm.m_yaw), math.rad(pm.m_pitch), 0))

			return position, with_roll(rotation, pm.roll), pm.fov, Vector3.length(position - head)
		end
	elseif pm.mode == "helmet" and unit and ALIVE[unit] then
		local unit_data = ScriptUnit.has_extension(unit, "unit_data_system")
		local first_person = unit_data and unit_data:read_component("first_person")

		if first_person then
			local _, head = body_scale(unit)
			local look = first_person.rotation
			local position = head + Quaternion.forward(look) * pm.m_back + Quaternion.up(look) * pm.m_up + Quaternion.right(look) * pm.m_side
			local rotation = Quaternion.multiply(look, Quaternion.from_yaw_pitch_roll(math.rad(pm.m_yaw), math.rad(pm.m_pitch), 0))

			return position, with_roll(rotation, pm.roll), pm.fov, 6
		end
	end

	if pm.mode == "selfie" and unit and ALIVE[unit] then
		local root, top, height = body_scale(unit)
		local scale = height / HUMAN_HEIGHT
		local base = Quaternion.from_yaw_pitch_roll(pm.base_yaw, 0, 0)
		local forward = Quaternion.forward(base)
		local right = Quaternion.right(base)
		local look_at = Vector3(root.x, root.y, root.z + pm.s_look * height)
		local yaw, elev = math.rad(pm.s_yaw), math.rad(pm.s_elev)
		local horizontal = forward * math.cos(yaw) + right * math.sin(yaw)
		local offset = (horizontal * math.cos(elev) + Vector3(0, 0, math.sin(elev))) * (pm.s_dist * scale)
		local position = look_at + offset

		if cfg.selfie_collision and camera_manager._physics_world then
			local hit = raycast_closest(camera_manager._physics_world, look_at, position)

			if hit then
				position = look_at + (hit - look_at) * 0.92
			end
		end

		local rotation = Quaternion.look(Vector3.normalize(look_at - position), Vector3.up())

		return position, with_roll(rotation, pm.roll), pm.fov, Vector3.length(position - look_at)
	end

	local rotation = Quaternion.from_yaw_pitch_roll(pm.yaw, pm.pitch, 0)
	local position = Vector3(pm.x, pm.y, pm.z)
	local focus = 8

	if unit and ALIVE[unit] then
		focus = Vector3.length(position - select(2, body_scale(unit)))
	end

	return position, with_roll(rotation, pm.roll), pm.fov, focus
end

-- selfie / free state -> world pose, used to carry the view over when the mode changes
local function adopt_free_from_pose(position, rotation)
	pm.x, pm.y, pm.z = position.x, position.y, position.z
	pm.yaw = Quaternion.yaw(rotation)
	pm.pitch = Quaternion.pitch(rotation)
end

-- ---------------------------------------------------------------------- path --

local function catmull(p0, p1, p2, p3, t)
	local t2, t3 = t * t, t * t * t

	return (p1 * 2 + (p2 - p0) * t + (p0 * 2 - p1 * 5 + p2 * 4 - p3) * t2 + (p1 * 3 - p0 - p2 * 3 + p3) * t3) * 0.5
end

local function path_pose(u)
	local keys = pm.keyframes
	local count = #keys

	if count == 0 then
		return nil
	end

	if count == 1 then
		local k = keys[1]

		return k.pos:unbox(), k.rot:unbox(), k.fov
	end

	local f = math.clamp(u, 0, 1) * (count - 1)
	local i = math.min(math.floor(f), count - 2)
	local t = f - i
	local k1, k2 = keys[i + 1], keys[i + 2]
	local k0, k3 = keys[math.max(i, 1)], keys[math.min(i + 3, count)]
	local position = catmull(k0.pos:unbox(), k1.pos:unbox(), k2.pos:unbox(), k3.pos:unbox(), t)
	local rotation = Quaternion.lerp(k1.rot:unbox(), k2.rot:unbox(), t)
	local fov = k1.fov + (k2.fov - k1.fov) * t

	return position, rotation, fov
end

local function stop_path()
	pm.path = nil
end

-- ------------------------------------------------------------- activation --

local function apply_time()
	local scale = 1

	if pm.active then
		scale = pm.time_mode == TIME_SLOW and cfg.time_slow or (pm.time_mode == TIME_FROZEN and 0 or 1)
	end

	local world_manager = Managers.world

	if world_manager and world_manager.set_world_update_time_scale and not is_server() then
		world_manager:set_world_update_time_scale(scale)
	end

	local name = game_mode_name()

	if is_server() and (name == "shooting_range" or name == "training_grounds") and Managers.time then
		Managers.time:set_local_scale("gameplay", scale)
	end
end

local function set_forced_third_person(unit, value)
	local extension = ScriptUnit.has_extension(unit, "first_person_system")

	if extension then
		extension._force_third_person_mode = value
	end
end

local function apply_angle(index)
	local a = ANGLES[index]

	if not a then
		return
	end

	pm.angle_index = index

	if a.image then
		-- a reference image: its pose and its camera
		local ok, reason = show_rig_pose(a.image, "image")

		pm.mode = "image"
		pm.image_id = a.image
		pm.roll = 0
		notify("Photo mode: angle %s%s", mod:localize("angle_" .. a.id), ok and (reason == "loading" and " (pose loading)" or "") or (", pose failed: " .. tostring(reason)))

		return
	end

	pm.mode = "selfie"
	pm.s_yaw, pm.s_elev, pm.s_dist, pm.s_look = a.yaw, a.elev, a.dist, a.look
	pm.fov = math.rad(a.fov)
	pm.roll = math.rad(a.roll or 0)

	notify("Photo mode: angle %s", mod:localize("angle_" .. a.id))
end

local function deactivate()
	if not pm.active then
		return
	end

	pm.active = false
	pm.path = nil
	stop_rig_pose()

	local unit = player_unit()

	if unit then
		stop_body_pose(unit, true)
		set_forced_third_person(unit, false)
		face_event(unit, FACE_NEUTRAL)
	end

	pm.hud_hidden = false
	pm.time_mode = 1
	apply_time()
	release_packages()
	notify("Photo mode off")
end

local function activate()
	local unit = player_unit()
	local name = game_mode_name()

	if not unit or not name then
		notify("Photo mode needs a living character in a mission, the hub or the Psykhanium.")

		return
	end

	pm.active = true
	pm.need_init = true
	pm.own_unit = unit
	pm.drift = false
	pm.path = nil
	pm.hud_hidden = cfg.hide_hud_on_start
	pm.time_mode = 1
	pm.dof = false
	pm.dof_offset = 0
	pm.roll = 0
	pm.pose_index = 0
	pm.face_index = 0
	pm.image_id = nil
	pm.pose_entry = nil
	pm.pose_offset = 0
	mode_defaults("free")

	pm.base_yaw = Quaternion.yaw(Unit.world_rotation(unit, 1))
	set_forced_third_person(unit, true)
	build_lists()
	Rig.request(mod) -- the pose skeleton loads in the background
	notify("Photo mode on. C cycles cameras (free, selfie stick, weapon tip, weapon-tip selfie, helmet), T angle presets, J/K poses, U/I faces, V look at the camera.")
end

local function toggle()
	if pm.active then
		deactivate()
	elseif not in_menu() then
		activate()
	end
end

mod.kb_toggle = toggle

mod:command("photo", "Photo mode: /photo toggles it, /photo clear removes the saved camera keyframes", function(arg)
	if arg == "clear" then
		pm.keyframes = {}
		stop_path()
		mod:echo("Photo mode: keyframes cleared.")
	else
		toggle()
	end
end)

-- ---------------------------------------------------------- per frame input --

local function move_vector(dt)
	local x = (key_down("d") and 1 or 0) - (key_down("a") and 1 or 0)
	local y = (key_down("w") and 1 or 0) - (key_down("s") and 1 or 0)
	local z = (key_down("e") and 1 or 0) - (key_down("q") and 1 or 0)
	local speed = cfg.move_speed

	if key_down("left shift") then
		speed = speed * 4
	end

	if key_down("left ctrl") then
		speed = speed * 0.25
	end

	return x * speed * dt, y * speed * dt, z * speed * dt
end

local function add_keyframe(position, rotation, fov)
	pm.keyframes[#pm.keyframes + 1] = { pos = Vector3Box(position), rot = QuaternionBox(rotation), fov = fov }
	notify("Photo mode: keyframe %d saved", #pm.keyframes)
end

local function toggle_path(position, rotation)
	if pm.path then
		stop_path()
		notify("Photo mode: camera path stopped")

		return
	end

	if #pm.keyframes < 2 then
		notify("Photo mode: save at least two keyframes with P first")

		return
	end

	pm.path = { t = 0, dir = 1 }
	notify("Photo mode: camera path playing")
end

local function handle_keys(dt, position, rotation, fov)
	if in_menu() then
		return
	end

	if key_pressed("c") then
		local index = 1

		for i = 1, #CAMERA_MODES do
			if CAMERA_MODES[i] == pm.mode then
				index = i
			end
		end

		local p, r = compose(Managers.state.camera)

		pm.mode = CAMERA_MODES[index % #CAMERA_MODES + 1]
		mode_defaults(pm.mode)

		if pm.mode == "free" then
			adopt_free_from_pose(p, r)
		end

		local stick_note = ""

		if pm.mode == "stick" then
			-- her arm holds the stick out: the selfie-stick pose
			local ok, reason = show_rig_pose("S", "stick")

			pm.roll = 0
			stick_note = ok and (reason == "loading" and " (pose loading)" or "") or (" (pose failed: " .. tostring(reason) .. ")")
		elseif pm.rig_owner == "stick" then
			release_rig_pose()
		end

		if (pm.mode == "weapon" or pm.mode == "weapon_selfie") and not weapon_mount(pm.own_unit) then
			notify("Photo mode: %s camera needs a wielded weapon; using the free camera instead", mod:localize("mode_" .. pm.mode))
		else
			notify("Photo mode: %s camera%s", mod:localize("mode_" .. pm.mode), stick_note)
		end
	end

	if key_pressed("t") then
		apply_angle(pm.angle_index % #ANGLES + 1)
	end

	if key_pressed("y") then
		apply_angle((pm.angle_index - 2) % #ANGLES + 1)
	end

	if key_pressed("h") then
		pm.hud_hidden = not pm.hud_hidden
	end

	if key_pressed("f") then
		pm.time_mode = pm.time_mode % 3 + 1
		apply_time()
		notify("Photo mode: time %s", pm.time_mode == 1 and "normal" or (pm.time_mode == TIME_SLOW and "slow" or "frozen"))
	end

	if key_pressed("o") then
		pm.dof = not pm.dof
		notify("Photo mode: depth of field %s", pm.dof and "on" or "off")
	end

	if key_pressed("g") then
		pm.drift = not pm.drift
		notify("Photo mode: slow pan %s", pm.drift and "on" or "off")
	end

	if key_pressed("r") then
		pm.roll = 0
		pm.fov = math.rad(mod:get("fov"))
		pm.dof_offset = 0
	end

	if key_pressed("n") then
		pm.roll = pm.roll - math.rad(2)
	end

	if key_pressed("m") then
		pm.roll = pm.roll + math.rad(2)
	end

	if key_down("z") then
		pm.fov = math.max(math.rad(5), pm.fov - math.rad(20) * dt)
	end

	if key_down("x") then
		pm.fov = math.min(math.rad(110), pm.fov + math.rad(20) * dt)
	end

	if key_down("num -") then
		pm.dof_offset = pm.dof_offset - 2 * dt
	end

	if key_down("numpad +") then
		pm.dof_offset = pm.dof_offset + 2 * dt
	end

	if key_pressed("p") then
		add_keyframe(position, rotation, fov)
	end

	if key_pressed("l") then
		toggle_path(position, rotation)
	end

	local unit = pm.own_unit

	local pose_next, pose_previous = key_pressed("k"), key_pressed("j")

	if pose_next or pose_previous then
		build_lists()

		local actions = build_action_list(unit)
		local combined = {}

		-- the reference image poses first, then the weapon's own animations, then the emotes
		for i = 1, #PoseData.poses do
			local pose = PoseData.poses[i]

			combined[#combined + 1] = { kind = "image", id = pose.id, name = pose.name }
		end

		for i = 1, #actions do
			combined[#combined + 1] = actions[i]
		end

		for i = 1, #(emote_list or {}) do
			combined[#combined + 1] = emote_list[i]
		end

		pm.pose_index = wrap(pm.pose_index, #combined, pose_next and 1 or -1)

		if pm.pose_index == 0 then
			release_rig_pose()
			stop_body_pose(unit, true)
			pm.pose_entry = nil
			notify("Photo mode: pose off")
		else
			local entry = combined[pm.pose_index]

			pm.pose_entry = entry

			if entry.kind == "image" then
				local ok, reason = show_rig_pose(entry.id, "image")

				-- the pose comes with its image's camera; moving the mouse hands the shot to the free camera
				if ok and entry.id ~= "S" then
					pm.mode = "image"
					pm.image_id = entry.id
					pm.roll = 0
				elseif ok then
					pm.mode = "stick"
					pm.roll = 0
				end

				notify("Photo mode: pose %s%s", entry.name, ok and (reason == "loading" and " (loading)" or "") or (" failed: " .. tostring(reason)))
			else
				if pm.rig and pm.rig_owner ~= "look" then
					release_rig_pose()
				end

				if entry.kind == "action" then
					local ok, reason = play_action_pose(unit, entry.event, pm.pose_offset, cfg.pose_hold)

					notify("Photo mode: weapon pose %s %s", entry.name, ok and "" or ("failed: " .. tostring(reason)))
				else
					local ok = play_body_pose(unit, entry.event, entry.face)

					notify("Photo mode: emote %s %s", entry.name, ok and "" or "failed")
				end
			end
		end
	end

	local offset_step = (key_pressed("oem_period (> .)") and 0.05 or 0) - (key_pressed("oem_comma (< ,)") and 0.05 or 0)

	if offset_step ~= 0 and pm.pose_entry and pm.pose_entry.kind == "action" then
		pm.pose_offset = math.max(0, pm.pose_offset + offset_step)

		local ok, reason = play_action_pose(unit, pm.pose_entry.event, pm.pose_offset, cfg.pose_hold)

		notify("Photo mode: pose time %.2f s %s", pm.pose_offset, ok and "" or ("failed: " .. tostring(reason)))
	end

	if key_pressed("v") then
		pm.look = not pm.look

		if pm.look and not pm.rig then
			local ok, reason = show_rig_pose(nil, "look")

			if not ok then
				pm.look = false
			end

			notify("Photo mode: look at the camera %s", ok and (reason == "loading" and "on (loading)" or "on") or ("failed: " .. tostring(reason)))
		else
			notify("Photo mode: look at the camera %s", pm.look and "on" or "off")
		end
	end

	if key_pressed("b") then
		release_rig_pose()
		stop_body_pose(unit, true)
		pm.pose_index = 0
		pm.face_index = 0
		pm.pose_entry = nil
	end

	local face_next, face_previous = key_pressed("i"), key_pressed("u")

	if face_next or face_previous then
		build_lists()

		if face_list and #face_list > 0 then
			pm.face_index = wrap(pm.face_index, #face_list, face_next and 1 or -1)

			local entry = face_list[pm.face_index == 0 and 1 or pm.face_index]
			local ok, reason = face_event(unit, entry.event)

			notify("Photo mode: face %s %s", entry.name, ok and "" or ("did nothing: " .. tostring(reason)))
		else
			notify("Photo mode: no face list (item data not loaded)")
		end
	end
end

local function step(camera_manager, dt)
	if in_menu() then
		return
	end

	local mouse = Mouse.axis(0)
	local dx, dy = Vector3.x(mouse), Vector3.y(mouse)
	local wheel = Vector3.y(Mouse.axis(Mouse.axis_index("wheel")))
	local sens = cfg.look_sens

	if pm.path then
		-- the camera path owns the view; any look or move input cancels it
		if math.abs(dx) + math.abs(dy) > 25 or key_down("w") or key_down("s") or key_down("a") or key_down("d") then
			stop_path()
		end
	end

	if not pm.path then
		if pm.mode == "image" or pm.mode == "stick" then
			local mx, my, mz = move_vector(dt)

			if math.abs(dx) + math.abs(dy) > 3 or mx ~= 0 or my ~= 0 or mz ~= 0 then
				local p, r, f = compose(camera_manager)

				adopt_free_from_pose(p, r)
				pm.fov = f
				pm.roll = 0
				pm.mode = "free"
				notify("Photo mode: free camera from this shot")
			end
		elseif pm.mode == "free" then
			pm.yaw = pm.yaw - dx * sens
			pm.pitch = math.clamp(pm.pitch - dy * sens, -1.55, 1.55)

			local mx, my, mz = move_vector(dt)
			local rotation = Quaternion.from_yaw_pitch_roll(pm.yaw, pm.pitch, 0)
			local offset = Quaternion.right(rotation) * mx + Quaternion.forward(rotation) * my + Vector3(0, 0, mz)

			pm.x, pm.y, pm.z = pm.x + offset.x, pm.y + offset.y, pm.z + offset.z

			if wheel ~= 0 then
				cfg.move_speed = math.clamp(cfg.move_speed * (1 + 0.15 * wheel), 0.2, 40)
			end

			if pm.drift then
				local drift = Quaternion.right(rotation) * (cfg.pan_speed * dt) + Quaternion.forward(rotation) * (cfg.dolly_speed * dt) + Vector3(0, 0, cfg.rise_speed * dt)

				pm.x, pm.y, pm.z = pm.x + drift.x, pm.y + drift.y, pm.z + drift.z
				pm.yaw = pm.yaw + math.rad(cfg.orbit_speed) * dt * 0.25
			end
		elseif pm.mode == "weapon" or pm.mode == "weapon_selfie" or pm.mode == "helmet" then
			pm.m_yaw = pm.m_yaw - dx * sens * 57.2958
			pm.m_pitch = math.clamp(pm.m_pitch - dy * sens * 57.2958, -85, 85)

			local mx, my, mz = move_vector(dt)

			pm.m_back = math.clamp(pm.m_back + my * 0.5 + wheel * 0.05, -2, 3)
			pm.m_up = math.clamp(pm.m_up + mz * 0.3, -1, 2)
			pm.m_side = math.clamp(pm.m_side + mx * 0.3, -1, 1)

			if pm.drift then
				pm.m_yaw = pm.m_yaw + cfg.orbit_speed * dt
			end
		else
			pm.s_yaw = pm.s_yaw - dx * sens * 57.2958
			pm.s_elev = math.clamp(pm.s_elev - dy * sens * 57.2958, -80, 85)
			pm.s_dist = math.clamp(pm.s_dist - wheel * 0.25, 0.4, 30)

			local mx, my, mz = move_vector(dt)

			pm.s_dist = math.clamp(pm.s_dist - my * 0.5, 0.4, 30)
			pm.s_look = math.clamp(pm.s_look + mz * 0.15, 0.1, 1.3)
			pm.s_yaw = pm.s_yaw + mx * 20

			if pm.drift then
				pm.s_yaw = pm.s_yaw + cfg.orbit_speed * dt
				pm.s_dist = math.clamp(pm.s_dist - cfg.dolly_speed * dt, 0.4, 30)
				pm.s_look = math.clamp(pm.s_look + cfg.rise_speed * dt * 0.3, 0.1, 1.3)
			end
		end
	end
end

local function advance_path(dt)
	local path = pm.path

	if not path then
		return nil
	end

	local duration = math.max(1, cfg.path_duration)

	path.t = path.t + dt / duration * path.dir

	if path.t >= 1 then
		if cfg.path_mode == "loop" then
			path.t = path.t - 1
		elseif cfg.path_mode == "pingpong" then
			path.t, path.dir = 1, -1
		else
			path.t = 1
			stop_path()
		end
	elseif path.t <= 0 then
		path.t, path.dir = 0, 1
	end

	local u = path.t
	u = u * u * (3 - 2 * u) -- smoothstep over the whole path

	return path_pose(u)
end

local function apply_camera(camera_manager, camera_nodes, camera_data, viewport_name)
	local player = local_player()

	if not player or viewport_name ~= player.viewport_name then
		return
	end

	local unit = player_unit()

	if not unit then
		deactivate()

		return
	end

	pm.own_unit = unit

	if pm.need_init then
		pm.need_init = false

		local position = camera_data.position
		local rotation = camera_data.rotation

		if position and rotation then
			adopt_free_from_pose(position, rotation)
		else
			local _, top = body_scale(unit)

			pm.x, pm.y, pm.z = top.x, top.y, top.z
		end

		pm.fov = math.rad(mod:get("fov"))
		pm.mode = "free"

		if cfg.start_mode == "selfie" then
			apply_angle(1)
		end
	end

	local dt = Managers.time:delta_time("main")

	pm.last_dt = dt

	local position, rotation, fov, focus = compose(camera_manager)

	handle_keys(dt, position, rotation, fov)
	step(camera_manager, dt)

	local path_position, path_rotation, path_fov = advance_path(dt)

	if path_position then
		position, rotation, fov = path_position, path_rotation, path_fov
		focus = pm.mode == "selfie" and focus or 8
	else
		position, rotation, fov, focus = compose(camera_manager)
	end

	if pm.rig then
		Rig.set_look(pm.rig, pm.look and position or nil)
	end

	camera_data.position = position
	camera_data.rotation = rotation
	camera_data.vertical_fov = fov
	camera_data.near_range = 0.05
	camera_data.far_range = math.max(camera_data.far_range or 0, 400)

	if pm.dof then
		camera_data.shading_environment = {
			dof_enabled = 1,
			focal_distance = math.max(0.2, (cfg.auto_focus and focus or 8) + pm.dof_offset),
			focal_region = cfg.dof_region,
			focal_padding = cfg.dof_padding,
			focal_scale = cfg.dof_scale,
		}
	end
end

mod:hook(CLASS.CameraManager, "_update_camera_properties", function(func, self, camera, shadow_cull_camera, camera_nodes, camera_data, viewport_name)
	if pm.active then
		local ok, err = pcall(apply_camera, self, camera_nodes, camera_data, viewport_name)

		if not ok then
			mod:error("QIangIQsPhotoMode switched itself off after an error in the camera: %s", tostring(err))
			pcall(deactivate)
		end
	end

	return func(self, camera, shadow_cull_camera, camera_nodes, camera_data, viewport_name)
end)

mod:hook_require("scripts/managers/camera/cameras/root_camera", function(RootCamera)
	mod:hook(RootCamera, "use_collision", function(func, self)
		if pm.active then
			return false
		end

		return func(self)
	end)
end)

-- the character is shown in third person whatever the camera is
mod:hook_require("scripts/extension_systems/first_person/player_unit_first_person_extension", function(PlayerUnitFirstPersonExtension)
	mod:hook(PlayerUnitFirstPersonExtension, "_update_first_person_mode", function(func, self, t)
		if pm.active and self._is_local_unit then
			return false, false
		end

		return func(self, t)
	end)
end)

-- ----------------------------------------------------------- HUD and input --

mod:hook_require("scripts/managers/ui/ui_hud", function(UIHud)
	mod:hook(UIHud, "draw", function(func, self, ...)
		if pm.active and pm.hud_hidden then
			return
		end

		return func(self, ...)
	end)
end)

-- the character does not react to the keyboard or the mouse while the photo mode is on
mod:hook_require("scripts/extension_systems/input/human_unit_input", function(HumanUnitInput)
	mod:hook(HumanUnitInput, "get", function(func, self, action)
		local value = func(self, action)

		if pm.active and self._player == local_player() and not (Managers.input and Managers.input:cursor_active()) then
			local value_type = type(value)

			if value_type == "boolean" then
				return false
			elseif value_type == "number" then
				return 0
			elseif value_type == "userdata" then
				return Vector3.zero()
			end
		end

		return value
	end)
end)

local function freeze_orientation(func, self, ...)
	local orientation = self._orientation
	local yaw, pitch, roll = orientation.yaw, orientation.pitch, orientation.roll

	func(self, ...)

	if pm.active and self._player == local_player() then
		if cfg.face_camera and pm.mode == "selfie" and pm.own_unit and ALIVE[pm.own_unit] then
			-- turn the character to the selfie camera (yaw convention of the aim code: atan2(-dx, dy))
			local base = Quaternion.from_yaw_pitch_roll(pm.base_yaw, 0, 0)
			local a = math.rad(pm.s_yaw)
			local dir = Quaternion.forward(base) * math.cos(a) + Quaternion.right(base) * math.sin(a)

			yaw = math.mod_two_pi(math.atan2(-dir.x, dir.y))
		end

		orientation.yaw, orientation.pitch, orientation.roll = yaw, pitch, roll
	end
end

mod:hook_require("scripts/extension_systems/first_person/character_state_orientation/default_player_orientation", function(DefaultPlayerOrientation)
	mod:hook(DefaultPlayerOrientation, "pre_update", freeze_orientation)
end)

mod:hook_require("scripts/extension_systems/first_person/character_state_orientation/hub_player_orientation", function(HubPlayerOrientation)
	mod:hook(HubPlayerOrientation, "pre_update", freeze_orientation)
end)

-- -------------------------------------------------------- pose every frame --

-- Mod updates run before the world update (mod_loader hooks StateGame.update), so the driver's bones set here are
-- the ones drawn this frame.
mod.update = function(dt)
	if not pm.active then
		return
	end

	if pm.rig_wanted and Rig.status() then
		pm.rig_wanted = false

		local id, owner = pm.rig_pose, pm.rig_owner

		if id or owner == "look" then
			local ok, reason = show_rig_pose(id, owner)

			if not ok then
				notify("Photo mode: pose %s failed: %s", id, tostring(reason))
			end
		end
	end

	if pm.rig then
		local ok, alive = pcall(Rig.update, pm.rig, dt)

		if not ok or not alive then
			if not ok then
				mod:error("Photo mode: the pose was stopped after an error: %s", tostring(alive))
			else
				mod:info("Photo mode: the pose was stopped, the pose skeleton or the character is gone")
			end

			stop_rig_pose()
		elseif pm.rig.check and not pm.rig.check_logged then
			pm.rig.check_logged = true
			mod:info("Photo mode: %s", pm.rig.check)
		end

		-- the look alone: once the head has turned back, everything goes back onto the player
		if pm.rig and pm.rig_owner == "look" and not pm.look and (pm.rig.look_weight or 0) <= 0 then
			stop_rig_pose()
		end
	end
end

-- an emote's items stay hidden when the game updates item visibility (QIangIQsEmotes does the same for its dances)
for _, class_name in ipairs({ "PlayerUnitVisualLoadoutExtension", "PlayerHuskVisualLoadoutExtension" }) do
	mod:hook_safe(CLASS[class_name], "_update_item_visibility", function(self)
		if self._unit and posing[self._unit] == "emote" then
			hide_items(self)
		end
	end)
end

-- --------------------------------------------- keep the game's animations out --

-- Any third-person animation the game plays on a body that is posed belongs to the weapon's state machine, which
-- the body is not running now: it is dropped while the photo mode holds a pose.
local THIRD_PERSON_EVENTS = { "anim_event", "anim_event_with_variable_float", "anim_event_with_variable_floats", "anim_event_with_variable_int" }

for _, class_name in ipairs({ "PlayerUnitAnimationExtension", "AuthoritativePlayerUnitAnimationExtension" }) do
	for _, method in ipairs(THIRD_PERSON_EVENTS) do
		mod:hook(CLASS[class_name], method, function(func, self, ...)
			if posing[self._unit] then
				return
			end

			return func(self, ...)
		end)
	end
end

for _, class_name in ipairs({ "PlayerUnitAnimationExtension", "AuthoritativePlayerUnitAnimationExtension", "PlayerHuskAnimationExtension" }) do
	mod:hook(CLASS[class_name], "inventory_slot_wielded", function(func, self, ...)
		if posing[self._unit] then
			stop_body_pose(self._unit, false)
			pm.pose_index = 0
		end

		return func(self, ...)
	end)
end

-- a server correction may write the server's animation states onto the body (player_unit_animation_extension.lua:191-209);
-- those belong to the weapon's machine, so the pose is ended and the rollback skipped once
mod:hook(CLASS.PlayerUnitAnimationExtension, "server_correction_occurred", function(func, self, unit, ...)
	if posing[unit] then
		stop_body_pose(unit, true)
		pm.pose_index = 0

		local weapon_template = current_weapon_template(unit)

		if weapon_template and weapon_template.name then
			self._local_wielded_weapon_template = weapon_template.name
		end

		return
	end

	return func(self, unit, ...)
end)

-- ---------------------------------------------------------------- plumbing --

local function reset_all()
	if pm.active then
		pm.active = false
	end

	pcall(stop_rig_pose)
	table.clear(posing)
	pm.path = nil
	pm.hud_hidden = false
	pm.time_mode = 1
	emote_list, face_list = nil, nil
	pcall(apply_time)
	pcall(release_packages)
end

mod.on_game_state_changed = function(status)
	if status == "enter" or status == "exit" then
		reset_all()
	end
end

mod.on_disabled = function()
	pcall(deactivate)
end

mod.on_unload = function()
	pcall(deactivate)
	pcall(Rig.release, mod)
end
