return {
	mod_name = {
		en = "QIangIQ's Photo Mode",
	},
	mod_description = {
		en = "Photo mode for missions, the Mourningstar hub and the Psykhanium: free camera, orbit camera with angle presets, a real selfie stick, slow pans and keyframe camera paths, field of view, roll, depth of field, hide HUD, slow or frozen time, the four reference poses with their cameras, a selfie-stick pose, game emotes and face expressions.",
	},
	angle_hero_full = {
		en = "A: pistol out, full body",
	},
	angle_portrait_tilt = {
		en = "C: portrait",
	},
	angle_full_low = {
		en = "B: blade raised, full body",
	},
	angle_blade_closeup = {
		en = "D: blade to camera, close-up",
	},
	angle_side_profile = {
		en = "Side profile",
	},
	angle_from_behind = {
		en = "From behind",
	},
	angle_top_down = {
		en = "Top down",
	},
	angle_wide_establishing = {
		en = "Wide establishing",
	},
	mode_free = {
		en = "free",
	},
	mode_selfie = {
		en = "orbit",
	},
	mode_stick = {
		en = "selfie stick",
	},
	mode_image = {
		en = "reference shot",
	},
	mode_weapon = {
		en = "weapon tip",
	},
	mode_weapon_selfie = {
		en = "weapon-tip selfie",
	},
	mode_helmet = {
		en = "helmet",
	},
}
