local mod = get_mod("QIangIQsPhotoMode")

local function numeric(id, default, lo, hi, decimals, title, tooltip)
	return { setting_id = id, type = "numeric", default_value = default, range = { lo, hi }, decimals_number = decimals, localize = false, title = title, tooltip = tooltip }
end

local function checkbox(id, default, title, tooltip)
	return { setting_id = id, type = "checkbox", default_value = default, localize = false, title = title, tooltip = tooltip }
end

local function dropdown(id, default, title, tooltip, options)
	local list = {}

	for i = 1, #options do
		list[i] = { text = options[i][2], value = options[i][1], show_widget_localization = false }
	end

	return { setting_id = id, type = "dropdown", default_value = default, localize = false, title = title, tooltip = tooltip, options = list }
end

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			{ setting_id = "toggle_key", type = "keybind", default_value = { "f10" }, keybind_trigger = "pressed", keybind_type = "function_call", function_name = "kb_toggle", localize = false, title = "Photo mode (key)", tooltip = "Turns photo mode on and off in a mission, the Mourningstar hub and the Psykhanium. Also /photo. Inside photo mode: WASD move, Q/E down/up, Shift fast, Ctrl slow, mouse looks, wheel = speed (free) or distance (orbit); C cycles camera (free, orbit, selfie stick, weapon tip, weapon-tip selfie, helmet), T/Y angle presets (the first four are the reference images with their pose), Z/X field of view, N/M roll, R reset, H hide HUD, F time normal/slow/frozen, O depth of field, - and + focus, G slow pan, P save keyframe, L play path, J/K pose (the reference poses first, then weapon animations, then emotes), comma/period pose time, B stop pose, U/I face, V look at the camera (on and off; weapons are hidden during emotes). Moving the mouse in a reference shot hands it to the free camera." },
			dropdown("start_mode", "free", "Start with", "Which camera photo mode starts with.", { { "free", "Free camera (from your view)" }, { "selfie", "Orbit (hero angle)" } }),
			numeric("fov", 40, 10, 110, 0, "Starting field of view (degrees)", "Vertical field of view when photo mode starts. The game's own field of view setting still multiplies it."),
			numeric("move_speed", 3, 0.2, 40, 1, "Free camera speed (metres per second)", "Shift = 4x, Ctrl = 0.25x, mouse wheel changes it."),
			numeric("look_sens", 0.0025, 0.0005, 0.01, 4, "Look sensitivity (radians per mouse count)", "How fast the mouse turns the free camera or orbits the selfie camera."),
			checkbox("selfie_collision", true, "Selfie camera stays out of walls", "Casts a ray from the character to the camera and pulls the camera in front of walls."),
			checkbox("face_camera", false, "Character turns to the selfie camera", "Turns your character to face the selfie camera as you orbit."),
			checkbox("pose_hold", true, "Hold weapon poses", "A weapon pose (J/K) starts at the chosen time and is held still by setting the animation's attack_speed to 0. Turn off to let it play out."),
			checkbox("hide_hud_on_start", false, "Hide the HUD when photo mode starts", "H toggles it in photo mode."),
			numeric("time_slow", 0.15, 0.02, 0.9, 2, "Slow time speed", "World speed used by the slow setting of F (client only; the host of a game is not slowed)."),
			numeric("orbit_speed", 6, -60, 60, 1, "Slow pan: orbit speed (degrees per second)", "Selfie camera orbits around the character; the free camera turns a quarter of this."),
			numeric("pan_speed", 0.15, -3, 3, 2, "Slow pan: sideways speed (m/s)", "Free camera drifts sideways."),
			numeric("dolly_speed", 0.1, -3, 3, 2, "Slow pan: dolly speed (m/s)", "Positive moves the camera forward / closer."),
			numeric("rise_speed", 0.0, -2, 2, 2, "Slow pan: rise speed (m/s)", "Positive lifts the camera."),
			numeric("path_duration", 12, 1, 120, 0, "Camera path length (seconds)", "Time to travel through all the keyframes saved with P."),
			dropdown("path_mode", "once", "Camera path playback", "What the saved path does when it reaches the end.", { { "once", "Play once" }, { "loop", "Loop" }, { "pingpong", "Back and forth" } }),
			checkbox("auto_focus", true, "Depth of field focuses on the character", "Focus distance follows the distance to your character; - and + shift it."),
			numeric("dof_region", 3, 0.2, 30, 1, "Depth of field: sharp region (m)", "Depth of the in-focus zone."),
			numeric("dof_padding", 3, 0.2, 30, 1, "Depth of field: blur ramp (m)", "Distance over which the image blurs in front of and behind the sharp zone."),
			numeric("dof_scale", 0.8, 0.05, 1, 2, "Depth of field: blur strength", "1 is the strongest blur."),
		},
	},
}
