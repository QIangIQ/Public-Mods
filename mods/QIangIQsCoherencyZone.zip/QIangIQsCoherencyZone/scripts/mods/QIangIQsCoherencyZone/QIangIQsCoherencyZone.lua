-- QIangIQsCoherencyZone
-- Filled coherency circles that follow the game's real coherency rules.
--
-- Rules, all from the game source (Darktide 1.13.4, scripts/extension_systems/coherency):
--   * PlayerCharacterConstants.coherency: radius 8, stickiness_limit 20, stickiness_time 2,
--     buff_template_names { "coherency_toughness_regen" }.
--   * UnitCoherencyExtension.current_radius: radius = 8 * (coherency_radius_modifier * coherency_radius_multiplier).
--     coherency_radius_modifier is an additive multiplier (base 1, talents add 0.5 / 0.75),
--     the stickiness limit is scaled by the same factor.
--   * CoherencySystem.update (server): every unit queries the broadphase with ITS OWN radius,
--     so A and B are directly linked when the distance is within the larger of the two radii.
--     Direct links are then merged into daisy chains: everyone in a chain is in coherency
--     with everyone else in that chain (the chain includes yourself).
--   * Proximity.check_sticky_proximity: a unit that drops out of range stays linked for
--     stickiness_time seconds, unless it gets further than stickiness_limit metres.
--   * CompanionCoherencyExtension: the Arbites dog joins chains only with the special rule
--     adamant_dog_counts_towards_coherency, using its owner's radius.
--   * coherency_toughness_regen (stepped_stat_buff): one stack per unit in coherency
--     (yourself included); step N sets toughness_coherency_regen_rate_modifier.
-- Radius sources found in the 1.13.4 source (every buff template with coherency_radius_modifier):
--   ogryn_bigger_coherency_radius +0.5  (Ogryn base talent ogryn_coherency_radius_increase, always on)
--   veteran_share_toughness_gained +0.5 (Veteran tree talent veteran_allies_in_coherency_share_toughness_gain)
--   psyker_coherency_aura_size_increase +0.75 (Psyker tree talent of the same name)
--   veteran_coherency_aura_size_increase +0.5, broker_passive_increased_aura_size +0.75 (defined, not in any tree)
--   live-event buff +0.25, Training Grounds tg_no_aura_radius x0 (buffs, read from stat_buffs for yourself only)
-- The mod does not list them by hand: it sums whatever the unit's loadout grants, so new ones work too.
-- On a Fatshark server every player is a husk on your client. Husk coherency extensions
-- receive the server's enter/exit RPCs, so "who is in my coherency" is the server's answer.
-- Radii of husks are rebuilt from their talents' buff templates, since husk stat buffs are empty.

local mod = get_mod("QIangIQsCoherencyZone")

local BuffTemplates = require("scripts/settings/buff/buff_templates")
local PlayerCharacterConstants = require("scripts/settings/player_character/player_character_constants")
local SpecialRulesSettings = require("scripts/settings/ability/special_rules_settings")

local special_rules = SpecialRulesSettings.special_rules
local COHERENCY = PlayerCharacterConstants.coherency or {}
local BASE_RADIUS = COHERENCY.radius or 8
local BASE_STICKY_LIMIT = COHERENCY.stickiness_limit or 20
local BASE_STICKY_TIME = COHERENCY.stickiness_time or 2

local TWO_PI = math.pi * 2
local SEGMENTS = 40
local NUM_SAMPLE_RINGS = 3
local LIFT_SELF = 0.12
local LIFT_OTHER = 0.10
-- Floor probes start just above knee height so they cannot land on crates, railings or
-- ledges above you (those hits made triangles stand up as walls that blocked the view).
local RAY_ABOVE = 0.9
local RAY_LENGTH = 4
-- Any triangle whose corners differ in height by more than this is a wall, not floor: skip it.
local MAX_TRIANGLE_STEP = 0.45
local RESAMPLE_DISTANCE = 0.75
local RESAMPLE_TIME = 1
local RADIUS_REFRESH_TIME = 1
local FONT = "content/ui/fonts/proxima_nova_bold"
local TEXT_LAYER = 900

local SEG_COS, SEG_SIN = {}, {}

for s = 1, SEGMENTS do
	local angle = TWO_PI * (s - 1) / SEGMENTS

	SEG_COS[s], SEG_SIN[s] = math.cos(angle), math.sin(angle)
end

-- ---------------------------------------------------------------------------
-- Settings
-- ---------------------------------------------------------------------------

local settings_cache = {}

local function _setting(id)
	local value = settings_cache[id]

	if value == nil then
		value = mod:get(id)
		settings_cache[id] = value
	end

	return value
end

local function _colour(state, alpha)
	return Color(alpha, _setting(state .. "_r") or 255, _setting(state .. "_g") or 255, _setting(state .. "_b") or 255)
end

-- ---------------------------------------------------------------------------
-- Render resources (same lifecycle as QIangIQsSpillway / Blitz Augur)
-- ---------------------------------------------------------------------------

local render = {
	world = nil,
	world_gui = nil,
	screen_gui = nil,
	lines = nil,
	triangles_failed = false,
}

local function _level_world()
	local world_manager = Managers.world

	if world_manager and world_manager:has_world("level_world") then
		return world_manager:world("level_world")
	end

	return nil
end

local function _destroy_render_resources()
	local world = render.world

	if world then
		pcall(function ()
			if render.world_gui then
				World.destroy_gui(world, render.world_gui)
			end

			if render.screen_gui then
				World.destroy_gui(world, render.screen_gui)
			end
		end)
	end

	-- Line objects are abandoned, not destroyed: the old pointer may already be invalid.
	render.world = nil
	render.world_gui = nil
	render.screen_gui = nil
	render.lines = nil
end

local function _ensure_render_resources()
	local world = _level_world()

	if not world then
		return false
	end

	if render.world ~= world then
		_destroy_render_resources()

		render.world = world
	end

	if not render.world_gui then
		render.world_gui = World.create_world_gui(world, Matrix4x4.identity(), 1, 1, "immediate")
	end

	if not render.screen_gui then
		render.screen_gui = World.create_screen_gui(world, "immediate")
	end

	if not render.lines then
		local ok, line_object = pcall(World.create_line_object, world)

		render.lines = ok and line_object or nil
	end

	return true
end

local function _clear_lines()
	if render.world and render.lines then
		pcall(function ()
			LineObject.reset(render.lines)
			LineObject.dispatch(render.world, render.lines)
		end)
	end
end

local function _camera()
	local camera_manager = Managers.state and Managers.state.camera
	local player = Managers.player and Managers.player:local_player(1)

	if not camera_manager or not player or not player.viewport_name then
		return nil
	end

	local ok, camera = pcall(camera_manager.camera, camera_manager, player.viewport_name)

	return ok and camera or nil
end

-- ---------------------------------------------------------------------------
-- Game state
-- ---------------------------------------------------------------------------

local function _gameplay_time()
	local time_manager = Managers.time

	if time_manager and time_manager:has_timer("gameplay") then
		return time_manager:time("gameplay")
	end

	return nil
end

local function _game_mode_name()
	local game_mode_manager = Managers.state and Managers.state.game_mode

	if not game_mode_manager then
		return nil
	end

	local ok, name = pcall(game_mode_manager.game_mode_name, game_mode_manager)

	return ok and name or nil
end

local function _should_draw()
	local game_mode = _game_mode_name()

	-- CoherencySystem.update returns early in the hub: there is no coherency there.
	if not game_mode or game_mode == "hub" or game_mode == "prologue_hub" then
		return false
	end

	if _setting("disable_in_psykhanium") and (game_mode == "survival" or game_mode == "shooting_range") then
		return false
	end

	return true
end

-- ---------------------------------------------------------------------------
-- True radius per unit
-- ---------------------------------------------------------------------------

local radius_cache = {}

-- Sums coherency_radius_modifier / coherency_radius_multiplier over the buff templates
-- the unit's talents grant (CharacterSheet.class_loadout -> buff_template_tiers).
local function _talent_radius_factors(unit)
	local add, mult = 0, 1
	local parts = {}
	local talent_extension = ScriptUnit.has_extension(unit, "talent_system")
	local tiers = talent_extension and talent_extension._buff_template_tiers

	if type(tiers) == "table" then
		for buff_name, _ in pairs(tiers) do
			local template = BuffTemplates[buff_name]
			local stat_buffs = template and template.stat_buffs

			if type(stat_buffs) == "table" then
				local modifier = stat_buffs.coherency_radius_modifier

				if type(modifier) == "number" then
					add = add + modifier
					parts[#parts + 1] = string.format("+%.2f %s", modifier, buff_name)
				end

				local multiplier = stat_buffs.coherency_radius_multiplier

				if type(multiplier) == "number" then
					mult = mult * multiplier
					parts[#parts + 1] = string.format("x%.2f %s", multiplier, buff_name)
				end
			end
		end
	end

	return 1 + add, mult, parts
end

-- Returns radius, stickiness limit (nil = no limit), stickiness time, source tag.
local function _compute_radius(unit)
	local coherency_extension = ScriptUnit.has_extension(unit, "coherency_system")

	-- When we are the server (solo / local host) the real extension answers directly.
	if coherency_extension and coherency_extension.current_radius then
		local ok, radius, limit = pcall(coherency_extension.current_radius, coherency_extension)

		if ok and type(radius) == "number" then
			local time = BASE_STICKY_TIME

			if coherency_extension.current_stickiness_time then
				local ok_time, value = pcall(coherency_extension.current_stickiness_time, coherency_extension)

				time = ok_time and value or time
			end

			return radius, limit, time, "server"
		end
	end

	local modifier, multiplier, parts = _talent_radius_factors(unit)
	local source = #parts > 0 and table.concat(parts, ", ") or "no radius talents"
	local buff_extension = ScriptUnit.has_extension(unit, "buff_system")
	local sticky_time = BASE_STICKY_TIME
	local no_limit = false

	if buff_extension and buff_extension.stat_buffs then
		local ok, stat_buffs = pcall(buff_extension.stat_buffs, buff_extension)

		if ok and type(stat_buffs) == "table" then
			local live_modifier = stat_buffs.coherency_radius_modifier
			local live_multiplier = stat_buffs.coherency_radius_multiplier

			if type(live_modifier) == "number" and live_modifier > modifier then
				source = source .. string.format(", live buffs %.2f instead of %.2f", live_modifier, modifier)
				modifier = live_modifier
			end

			if type(live_multiplier) == "number" then
				multiplier = live_multiplier
			end

			local extra_time = stat_buffs.coherency_stickiness_time_value

			if type(extra_time) == "number" then
				sticky_time = sticky_time + extra_time
			end
		end

		if buff_extension.has_keyword then
			local ok_kw, has = pcall(buff_extension.has_keyword, buff_extension, "no_coherency_stickiness_limit")

			no_limit = ok_kw and has or false
		end
	end

	local factor = modifier * multiplier
	local limit = not no_limit and BASE_STICKY_LIMIT * factor or nil

	return BASE_RADIUS * factor, limit, sticky_time, source
end

local function _radius_info(unit, t)
	local entry = radius_cache[unit]

	if not entry or t - entry.t > RADIUS_REFRESH_TIME then
		local radius, limit, sticky_time, source = _compute_radius(unit)

		entry = entry or {}
		entry.radius, entry.limit, entry.sticky_time, entry.source, entry.t = radius, limit, sticky_time, source, t
		radius_cache[unit] = entry
	end

	return entry
end

local function _has_special_rule(unit, rule)
	local talent_extension = ScriptUnit.has_extension(unit, "talent_system")

	if not talent_extension or not talent_extension.has_special_rule or not rule then
		return false
	end

	local ok, has = pcall(talent_extension.has_special_rule, talent_extension, rule)

	return ok and has and true or false
end

-- ---------------------------------------------------------------------------
-- Floor sampling (QIangIQsSpillway technique: one raycast per vertex)
-- ---------------------------------------------------------------------------

local floor_cache = {}

-- Draws a floor triangle unless it would stand up as a wall (step between corners too big).
local function _floor_triangle(gui, a, b, c, colour)
	local z1, z2, z3 = a.z, b.z, c.z
	local top = math.max(z1, z2, z3)
	local bottom = math.min(z1, z2, z3)

	if top - bottom <= MAX_TRIANGLE_STEP then
		Gui.triangle(gui, a, b, c, 1, colour)
	end
end

local function _raycast_floor_z(physics_world, x, y, from_z, length)
	local ok, hit, hit_position = pcall(PhysicsWorld.raycast, physics_world, Vector3(x, y, from_z), Vector3.down(), length, "closest", "collision_filter", "filter_player_mover")

	if ok and hit and hit_position then
		return hit_position.z
	end

	return nil
end

local function _floor_samples(unit, x, y, z, radius, t)
	local entry = floor_cache[unit]
	local follow = _setting("follow_floor")

	if entry and entry.follow == follow then
		local dx, dy = x - entry.cx, y - entry.cy
		local moved_sq = dx * dx + dy * dy

		if moved_sq < RESAMPLE_DISTANCE * RESAMPLE_DISTANCE and math.abs(entry.radius - radius) < 0.05 and t - entry.t < RESAMPLE_TIME then
			return entry
		end
	end

	entry = entry or { heights = {} }
	entry.cx, entry.cy, entry.cz, entry.radius, entry.t, entry.follow = x, y, z, radius, t, follow

	local heights = entry.heights
	local physics_world = follow and render.world and World.physics_world(render.world)

	for s = 1, SEGMENTS do
		for j = 1, NUM_SAMPLE_RINGS do
			local r = radius * j / NUM_SAMPLE_RINGS
			local h = physics_world and _raycast_floor_z(physics_world, x + r * SEG_COS[s], y + r * SEG_SIN[s], z + RAY_ABOVE, RAY_LENGTH)

			heights[(s - 1) * NUM_SAMPLE_RINGS + j] = h or z
		end
	end

	floor_cache[unit] = entry

	return entry
end

-- ---------------------------------------------------------------------------
-- Drawing
-- ---------------------------------------------------------------------------

local function _draw_disc_triangles(x, y, z, radius, samples, lift, fill_colour, rim_colour)
	local gui = render.world_gui
	local rim = math.min((_setting("rim_width") or 25) / 100, radius * 0.5)
	local heights = samples.heights
	local dz = z - samples.cz
	local center = Vector3(x, y, z + lift)
	local band_radii = {}

	for j = 1, NUM_SAMPLE_RINGS do
		band_radii[j] = radius * j / NUM_SAMPLE_RINGS
	end

	-- Fill stops at the inner edge of the rim.
	band_radii[NUM_SAMPLE_RINGS] = radius - rim

	for s = 1, SEGMENTS do
		local s2 = s % SEGMENTS + 1
		local c1, n1, c2, n2 = SEG_COS[s], SEG_SIN[s], SEG_COS[s2], SEG_SIN[s2]
		local base1, base2 = (s - 1) * NUM_SAMPLE_RINGS, (s2 - 1) * NUM_SAMPLE_RINGS
		local prev_a, prev_b

		for j = 1, NUM_SAMPLE_RINGS do
			local r = band_radii[j]
			local a = Vector3(x + r * c1, y + r * n1, heights[base1 + j] + dz + lift)
			local b = Vector3(x + r * c2, y + r * n2, heights[base2 + j] + dz + lift)

			if j == 1 then
				_floor_triangle(gui, center, a, b, fill_colour)
			else
				_floor_triangle(gui, prev_a, a, b, fill_colour)
				_floor_triangle(gui, prev_a, b, prev_b, fill_colour)
			end

			prev_a, prev_b = a, b
		end

		local hi1 = heights[base1 + NUM_SAMPLE_RINGS] + dz + lift
		local hi2 = heights[base2 + NUM_SAMPLE_RINGS] + dz + lift
		local oa = Vector3(x + radius * c1, y + radius * n1, hi1)
		local ob = Vector3(x + radius * c2, y + radius * n2, hi2)

		_floor_triangle(gui, prev_a, oa, ob, rim_colour)
		_floor_triangle(gui, prev_a, ob, prev_b, rim_colour)
	end
end

-- Fallback when the engine refuses world-space triangles: concentric line rings.
local function _draw_disc_lines(x, y, z, radius, samples, lift, colour, rim_colour)
	local lines = render.lines

	if not lines then
		return
	end

	local heights = samples.heights
	local dz = z - samples.cz
	local steps = math.max(2, math.floor(radius / 0.5))

	for k = 1, steps do
		local r = radius * k / steps
		local j = math.max(1, math.min(NUM_SAMPLE_RINGS, math.ceil(k / steps * NUM_SAMPLE_RINGS)))
		local use = k == steps and rim_colour or colour

		for s = 1, SEGMENTS do
			local s2 = s % SEGMENTS + 1
			local a = Vector3(x + r * SEG_COS[s], y + r * SEG_SIN[s], heights[(s - 1) * NUM_SAMPLE_RINGS + j] + dz + lift)
			local b = Vector3(x + r * SEG_COS[s2], y + r * SEG_SIN[s2], heights[(s2 - 1) * NUM_SAMPLE_RINGS + j] + dz + lift)

			LineObject.add_line(lines, use, a, b)
		end
	end
end

local function _draw_disc(node, t, lift, state)
	if node.radius <= 0 then
		return
	end

	local samples = _floor_samples(node.unit, node.x, node.y, node.z, node.radius, t)
	local fill = _colour(state, _setting("fill_alpha") or 45)
	local rim = _colour(state, _setting("rim_alpha") or 170)

	if not render.triangles_failed then
		local ok, err = pcall(_draw_disc_triangles, node.x, node.y, node.z, node.radius, samples, lift, fill, rim)

		if ok then
			return
		end

		render.triangles_failed = true

		mod:info("world-space triangles failed, using line rings: %s", tostring(err))
	end

	_draw_disc_lines(node.x, node.y, node.z, node.radius, samples, lift, _colour(state, math.min(255, (_setting("fill_alpha") or 45) * 3)), rim)
end

-- ---------------------------------------------------------------------------
-- Blob drawing: one merged shape per daisy chain (union of the members' circles)
-- Field f(p) = max_i (R_i - |p - c_i|) is the exact distance to the union's edge
-- outside it, so f >= 0 is the area and 0 <= f < rim is the edge band. The grid
-- is clipped per cell (marching squares with linear edge interpolation).
-- ---------------------------------------------------------------------------

local BLOB_CELL = 0.75
local BLOB_MERGE = 8

local function _clip(poly, level, keep_above)
	local out = {}
	local count = #poly

	for i = 1, count do
		local p, q = poly[i], poly[i % count + 1]
		local p_in = (p[4] >= level) == keep_above
		local q_in = (q[4] >= level) == keep_above

		if p_in then
			out[#out + 1] = p
		end

		if p_in ~= q_in then
			local k = (level - p[4]) / (q[4] - p[4])

			out[#out + 1] = { p[1] + (q[1] - p[1]) * k, p[2] + (q[2] - p[2]) * k, p[3] + (q[3] - p[3]) * k, level }
		end
	end

	return out
end

local function _fan(gui, poly, colour)
	local n = #poly

	if n < 3 then
		return
	end

	local a = Vector3(poly[1][1], poly[1][2], poly[1][3])

	for i = 2, n - 1 do
		local b, c = poly[i], poly[i + 1]

		_floor_triangle(gui, a, Vector3(b[1], b[2], b[3]), Vector3(c[1], c[2], c[3]), colour)
	end
end

-- Floor height of every blob grid point, probed straight down at that exact point and
-- cached per level (the floor does not move). Keyed by grid cell and by the 1 m height
-- band of the nearest member, so different storeys keep separate values.
-- (The first blob version reused the members' polar samples taken somewhere else, which put
-- crate and ledge heights in the wrong places and made panels float or stand up.)
local floor_grid = {}
local floor_grid_count = 0
local FLOOR_GRID_LIMIT = 200000

local function _blob_floor_z(members, x, y, ix, iy)
	local best, best_f

	for i = 1, #members do
		local n = members[i]
		local dx, dy = x - n.x, y - n.y
		local f = n.radius - math.sqrt(dx * dx + dy * dy)

		if not best_f or f > best_f then
			best, best_f = n, f
		end
	end

	local ref_z = best.z

	if not _setting("follow_floor") or not render.world then
		return ref_z
	end

	local band = math.floor(ref_z + 0.5)
	local by_band = floor_grid[band]

	if not by_band then
		by_band = {}
		floor_grid[band] = by_band
	end

	local row = by_band[ix]

	if not row then
		row = {}
		by_band[ix] = row
	end

	local cached = row[iy]

	if cached == nil then
		if floor_grid_count > FLOOR_GRID_LIMIT then
			table.clear(floor_grid)
			floor_grid_count = 0
		end

		local physics_world = World.physics_world(render.world)
		local h = physics_world and _raycast_floor_z(physics_world, x, y, band + RAY_ABOVE, RAY_LENGTH)

		cached = h or false
		row[iy] = cached
		floor_grid_count = floor_grid_count + 1
	end

	return cached or ref_z
end

local function _draw_blob_triangles(members, t, lift, fill_colour, rim_colour)
	local gui = render.world_gui
	local rim = (_setting("rim_width") or 25) / 100
	local min_x, min_y, max_x, max_y = math.huge, math.huge, -math.huge, -math.huge

	for i = 1, #members do
		local n = members[i]

		min_x, min_y = math.min(min_x, n.x - n.radius), math.min(min_y, n.y - n.radius)
		max_x, max_y = math.max(max_x, n.x + n.radius), math.max(max_y, n.y + n.radius)
	end

	min_x = math.floor(min_x / BLOB_CELL) * BLOB_CELL - BLOB_CELL
	min_y = math.floor(min_y / BLOB_CELL) * BLOB_CELL - BLOB_CELL

	local nx = math.ceil((max_x - min_x) / BLOB_CELL) + 2
	local ny = math.ceil((max_y - min_y) / BLOB_CELL) + 2
	local field, height = {}, {}

	for iy = 0, ny - 1 do
		local y = min_y + iy * BLOB_CELL

		for ix = 0, nx - 1 do
			local x = min_x + ix * BLOB_CELL
			local f = -math.huge

			for i = 1, #members do
				local n = members[i]
				local dx, dy = x - n.x, y - n.y
				local v = n.radius - math.sqrt(dx * dx + dy * dy)

				if v > f then
					f = v
				end
			end

			local index = iy * nx + ix + 1

			field[index] = f

			if f > -BLOB_CELL * 1.5 then
				height[index] = _blob_floor_z(members, x, y, math.floor(x / BLOB_CELL + 0.5), math.floor(y / BLOB_CELL + 0.5)) + lift
			end
		end
	end

	for iy = 0, ny - 2 do
		local ix = 0

		while ix <= nx - 2 do
			local i00 = iy * nx + ix + 1
			local i10, i01, i11 = i00 + 1, i00 + nx, i00 + nx + 1
			local f00, f10, f01, f11 = field[i00], field[i10], field[i01], field[i11]
			local x0, y0 = min_x + ix * BLOB_CELL, min_y + iy * BLOB_CELL

			if f00 < 0 and f10 < 0 and f01 < 0 and f11 < 0 then
				ix = ix + 1
			elseif f00 >= rim and f10 >= rim and f01 >= rim and f11 >= rim then
				-- Run of fully filled cells drawn as one strip quad.
				local run = 1

				while run < BLOB_MERGE and ix + run <= nx - 2 do
					local j00 = i00 + run
					local j10, j11 = j00 + 1, j00 + nx + 1

					-- Only merge while the floor stays level, so a strip never floats over a step.
					if field[j10] >= rim and field[j11] >= rim and math.abs(height[j10] - height[i00]) < 0.15 and math.abs(height[j11] - height[i01]) < 0.15 then
						run = run + 1
					else
						break
					end
				end

				local e10, e11 = i00 + run, i00 + run + nx
				local x1 = x0 + run * BLOB_CELL
				local a = Vector3(x0, y0, height[i00])
				local b = Vector3(x1, y0, height[e10])
				local c = Vector3(x1, y0 + BLOB_CELL, height[e11])
				local d = Vector3(x0, y0 + BLOB_CELL, height[i01])

				_floor_triangle(gui, a, b, c, fill_colour)
				_floor_triangle(gui, a, c, d, fill_colour)

				ix = ix + run
			else
				local x1, y1 = x0 + BLOB_CELL, y0 + BLOB_CELL
				local quad = {
					{ x0, y0, height[i00], f00 },
					{ x1, y0, height[i10], f10 },
					{ x1, y1, height[i11], f11 },
					{ x0, y1, height[i01], f01 },
				}
				local inside = _clip(quad, 0, true)

				if #inside >= 3 then
					_fan(gui, _clip(inside, rim, false), rim_colour)
					_fan(gui, _clip(inside, rim, true), fill_colour)
				end

				ix = ix + 1
			end
		end
	end
end

local function _draw_blob(members, t, lift, state)
	local any = false

	for i = 1, #members do
		if members[i].radius > 0 then
			any = true
		end
	end

	if not any then
		return
	end

	if render.triangles_failed then
		for i = 1, #members do
			_draw_disc(members[i], t, lift, state)
		end

		return
	end

	local fill = _colour(state, _setting("fill_alpha") or 45)
	local rim = _colour(state, _setting("rim_alpha") or 170)
	local ok, err = pcall(_draw_blob_triangles, members, t, lift, fill, rim)

	if not ok then
		render.triangles_failed = true

		mod:info("blob triangles failed, using line rings: %s", tostring(err))
	end
end

local function _project(camera, position)
	local camera_position = Camera.world_position(camera)
	local camera_forward = Quaternion.forward(Camera.world_rotation(camera))
	local in_front = Vector3.dot(position - camera_position, camera_forward) > 0.5
	local screen = Camera.world_to_screen(camera, position)

	return screen.x, screen.y, in_front
end

local function _text_centered(text, x, y, size, colour)
	local gui = render.screen_gui
	local min, max = Gui.slug_text_extents(gui, text, FONT, size)

	Gui.slug_text(gui, text, FONT, size, Vector3(x - (max.x - min.x) / 2, y, TEXT_LAYER), nil, colour, "shadow", Color(200, 0, 0, 0))
end

-- ---------------------------------------------------------------------------
-- Coherency graph
-- ---------------------------------------------------------------------------

local held_since = {}

local function _collect_nodes(t, local_unit)
	local nodes = {}
	local players = Managers.player and Managers.player:players()

	if not players then
		return nodes
	end

	for _, player in pairs(players) do
		local unit = player.player_unit

		if unit and Unit.alive(unit) and HEALTH_ALIVE[unit] and ScriptUnit.has_extension(unit, "coherency_system") then
			-- POSITION_LOOKUP can hold a stale value that is no longer a Vector3 ("Vector3 or Vector4 expected, got userdata" on .x,
			-- every frame, console-2026-11-03-23.48.31); read the live unit instead
			local position = Unit.world_position(unit, 1)

			if position then
				local info = _radius_info(unit, t)

				nodes[#nodes + 1] = {
					unit = unit,
					x = position.x,
					y = position.y,
					z = position.z,
					radius = info.radius,
					info = info,
					is_self = unit == local_unit,
					is_dog = false,
					name = player.name and player:name() or "?",
				}

				local spawner = ScriptUnit.has_extension(unit, "companion_spawner_system")

				if spawner and spawner.companion_units and _has_special_rule(unit, special_rules.adamant_dog_counts_towards_coherency) then
					local ok, dogs = pcall(spawner.companion_units, spawner)

					if ok and type(dogs) == "table" then
						for _, dog in ipairs(dogs) do
							local dog_position = dog and Unit.alive(dog) and HEALTH_ALIVE[dog] and Unit.world_position(dog, 1)

							if dog_position then
								nodes[#nodes + 1] = {
									unit = dog,
									x = dog_position.x,
									y = dog_position.y,
									z = dog_position.z,
									-- CompanionCoherencyExtension uses its owner's buffs.
									radius = info.radius,
									info = info,
									is_self = false,
									is_dog = true,
									owner = unit,
									name = (player.name and player:name() or "?") .. "'s dog",
								}
							end
						end
					end
				end
			end
		end
	end

	return nodes
end

local function _distance(a, b)
	local dx, dy, dz = a.x - b.x, a.y - b.y, a.z - b.z

	return math.sqrt(dx * dx + dy * dy + dz * dz)
end

-- Direct links (distance within the larger radius) and the geometric chain that holds you.
local function _build_links(nodes, self_node)
	local edges = {}
	local adjacency = {}

	for i = 1, #nodes do
		adjacency[i] = {}
	end

	for i = 1, #nodes do
		for j = i + 1, #nodes do
			local a, b = nodes[i], nodes[j]
			local need = math.max(a.radius, b.radius)
			local d = _distance(a, b)

			if d <= need and need > 0 then
				edges[#edges + 1] = { a = a, b = b }
				adjacency[i][#adjacency[i] + 1] = j
				adjacency[j][#adjacency[j] + 1] = i
			end
		end
	end

	-- Label every daisy chain (connected component). Everyone in one chain is in
	-- coherency with everyone else in it (CoherencySystem.update merges the chains).
	local components = {}

	for i = 1, #nodes do
		if not nodes[i].component then
			local members = { nodes[i] }
			local queue, head = { i }, 1

			nodes[i].component = members

			while queue[head] do
				local current = queue[head]

				head = head + 1

				for _, neighbour in ipairs(adjacency[current]) do
					if not nodes[neighbour].component then
						nodes[neighbour].component = members
						members[#members + 1] = nodes[neighbour]
						queue[#queue + 1] = neighbour
					end
				end
			end

			components[#components + 1] = members
		end
	end

	local chain_units = {}

	if self_node then
		for _, member in ipairs(self_node.component) do
			chain_units[member.unit] = true
		end
	end

	return edges, chain_units, components
end

local function _server_coherency_set(local_unit)
	local coherency_extension = ScriptUnit.has_extension(local_unit, "coherency_system")

	if not coherency_extension or not coherency_extension.in_coherence_units then
		return nil
	end

	local ok, set = pcall(coherency_extension.in_coherence_units, coherency_extension)

	return ok and type(set) == "table" and set or nil
end

local function _toughness_step(local_unit, count)
	local template = BuffTemplates.coherency_toughness_regen

	if not template or not template.stepped_stat_buffs then
		return nil
	end

	local min, max = 0, template.max_stacks

	if template.min_max_step_func then
		local template_data = { talent_extension = ScriptUnit.has_extension(local_unit, "talent_system") }
		local template_context = { unit = local_unit, buff_extension = ScriptUnit.has_extension(local_unit, "buff_system") }
		local ok, a, b = pcall(template.min_max_step_func, template_data, template_context)

		if ok then
			min, max = a or 0, b or template.max_stacks
		end
	end

	local step = math.clamp(count, min, max or count)
	local stats = template.stepped_stat_buffs[step]

	return stats and stats.toughness_coherency_regen_rate_modifier or 0, step
end

-- ---------------------------------------------------------------------------
-- Frame
-- ---------------------------------------------------------------------------

local function _classify(node, self_node, server_set, chain_units, t)
	if node.is_self then
		return "self"
	end

	local direct = self_node and _distance(node, self_node) <= math.max(node.radius, self_node.radius)
	local linked

	if server_set then
		linked = server_set[node.unit] and true or false
	else
		linked = chain_units[node.unit] or false
	end

	if not linked then
		held_since[node.unit] = nil

		return "out"
	end

	if direct then
		held_since[node.unit] = nil

		return "direct"
	end

	if chain_units[node.unit] then
		held_since[node.unit] = nil

		return "chain"
	end

	held_since[node.unit] = held_since[node.unit] or t

	return "held"
end

local function _update(t)
	local player = Managers.player and Managers.player:local_player(1)
	local local_unit = player and player.player_unit

	if not local_unit or not Unit.alive(local_unit) then
		return
	end

	local nodes = _collect_nodes(t, local_unit)
	local self_node

	for i = 1, #nodes do
		if nodes[i].is_self then
			self_node = nodes[i]
		end
	end

	local edges, chain_units, components = _build_links(nodes, self_node)
	local blob_mode = _setting("draw_style") ~= "circles"
	local server_set = _server_coherency_set(local_unit)
	local camera = _setting("show_labels") and _camera()
	local width, height = Gui.resolution()
	local scale = height / 1080
	local label_size = (_setting("label_size") or 16) * scale

	-- Discs: others first, yourself on top.
	for i = 1, #nodes do
		local node = nodes[i]

		if not node.is_self then
			local state = _classify(node, self_node, server_set, chain_units, t)
			local wanted = node.is_dog and _setting("show_dogs") or not node.is_dog and _setting("show_teammates")

			node.state = state

			if wanted and not blob_mode then
				_draw_disc(node, t, LIFT_OTHER, state)
			end

			if camera and wanted then
				local d = self_node and _distance(node, self_node) or 0
				local text

				if state == "direct" then
					text = string.format("%s  %.1f m  DIRECT", node.name, d)
				elseif state == "chain" then
					text = string.format("%s  %.1f m  CHAINED", node.name, d)
				elseif state == "held" then
					local left = math.max(0, (self_node and self_node.info.sticky_time or BASE_STICKY_TIME) - (t - (held_since[node.unit] or t)))

					text = string.format("%s  %.1f m  HELD %.1f s", node.name, d, left)
				else
					local need = self_node and math.max(node.radius, self_node.radius) or node.radius

					text = string.format("%s  %.1f m  OUT (link at %.1f m)", node.name, d, need)
				end

				local x, y, in_front = _project(camera, Vector3(node.x, node.y, node.z + (node.is_dog and 1.2 or 2.3)))

				if in_front then
					_text_centered(text, x, y, label_size, _colour(state, 255))
				end
			end
		end
	end

	if blob_mode then
		-- One blob per chain. Your chain uses your colour; another chain is "held"
		-- when the server still counts its members in your coherency, else "out".
		for _, members in ipairs(components) do
			local has_self, has_player, linked = false, false, false

			for _, member in ipairs(members) do
				has_self = has_self or member.is_self
				has_player = has_player or not member.is_dog
				linked = linked or member.state == "held" or member.state == "chain" or member.state == "direct"
			end

			if has_self then
				if _setting("show_self") then
					_draw_blob(members, t, LIFT_SELF, "self")
				end
			elseif has_player and _setting("show_teammates") or not has_player and _setting("show_dogs") then
				_draw_blob(members, t, LIFT_OTHER, linked and "held" or "out")
			end
		end
	elseif self_node and _setting("show_self") then
		_draw_disc(self_node, t, LIFT_SELF, "self")
	end

	local lines = render.lines

	if lines then
		if _setting("show_links") then
			for _, edge in ipairs(edges) do
				local a, b = edge.a, edge.b
				local state = chain_units[a.unit] and chain_units[b.unit] and ((a.is_self or b.is_self) and "direct" or "chain") or "out"

				LineObject.add_line(lines, _colour(state, 230), Vector3(a.x, a.y, a.z + 0.25), Vector3(b.x, b.y, b.z + 0.25))
			end
		end

		if self_node and _setting("show_leash") and self_node.info.limit then
			local center = Vector3(self_node.x, self_node.y, self_node.z + 0.1)

			pcall(LineObject.add_circle, lines, _colour("held", 140), center, self_node.info.limit, Vector3.up(), 72)
		end
	end

	if _setting("show_status") and self_node then
		local count

		if server_set then
			count = 0

			for _ in pairs(server_set) do
				count = count + 1
			end
		else
			count = 0

			for _ in pairs(chain_units) do
				count = count + 1
			end
		end

		-- The server's chain always contains yourself; an empty set means no data yet.
		count = math.max(count, 1)

		local regen, step = _toughness_step(local_unit, count)
		local text = string.format("COHERENCY %d (you + %d)   radius %.1f m   leash %s", count, count - 1, self_node.radius, self_node.info.limit and string.format("%.0f m / %.1f s", self_node.info.limit, self_node.info.sticky_time) or "none")

		if regen then
			text = text .. string.format("   toughness regen x%.2f (step %d, out of combat)", regen, step)
		end

		local gui = render.screen_gui
		local size = 18 * scale
		local min, max = Gui.slug_text_extents(gui, text, FONT, size)
		local x = (width - (max.x - min.x)) / 2
		local y = height * (_setting("status_position") or 12) / 100

		Gui.slug_text(gui, text, FONT, size, Vector3(x, y, TEXT_LAYER), nil, _colour(count > 1 and "direct" or "out", 255), "shadow", Color(200, 0, 0, 0))
	end
end

local function _clear_caches()
	table.clear(floor_grid)
	floor_grid_count = 0
	table.clear(radius_cache)
	table.clear(floor_cache)
	table.clear(held_since)
end

mod.update = function (dt)
	local t = _gameplay_time()

	if not t or not _should_draw() then
		_clear_lines()

		return
	end

	if not _ensure_render_resources() then
		return
	end

	if render.lines then
		LineObject.reset(render.lines)
	end

	local ok, err = pcall(_update, t)

	if not ok then
		mod:info("update failed: %s", tostring(err))
	end

	if render.lines then
		LineObject.dispatch(render.world, render.lines)
	end
end

mod.on_setting_changed = function ()
	table.clear(settings_cache)
	table.clear(floor_cache)
end

mod.on_game_state_changed = function (status, state_name)
	if state_name == "StateGameplay" then
		_clear_caches()
		_destroy_render_resources()
	end
end

mod.on_disabled = function ()
	_clear_lines()
	_clear_caches()
end

mod.on_unload = function ()
	_clear_lines()
	_clear_caches()
	_destroy_render_resources()
end

-- /czinfo prints every unit's radius and where the number came from.
mod:command("czinfo", "QIangIQs Coherency Zone: print each unit's coherency radius", function ()
	local t = _gameplay_time() or 0
	local player = Managers.player and Managers.player:local_player(1)
	local local_unit = player and player.player_unit

	if not local_unit then
		mod:echo("No player unit.")

		return
	end

	table.clear(radius_cache)

	local server_set = _server_coherency_set(local_unit)

	for _, node in ipairs(_collect_nodes(t, local_unit)) do
		local info = node.info

		mod:echo(string.format("%s: radius %.2f m, leash %s, grace %.1f s (%s)%s", node.name, node.radius, info.limit and string.format("%.1f m", info.limit) or "none", info.sticky_time or 0, info.source or "?", server_set and server_set[node.unit] and ", in your coherency" or ""))
	end
end)
