local mod = get_mod("QIangIQsCoherencyZone")

local function checkbox(id, default)
	return { setting_id = id, type = "checkbox", default_value = default, tooltip = id .. "_tooltip" }
end

local function numeric(id, default, low, high)
	return { setting_id = id, type = "numeric", default_value = default, range = { low, high } }
end

local function colour_group(state, r, g, b)
	return {
		setting_id = "group_colour_" .. state,
		type = "group",
		sub_widgets = {
			numeric(state .. "_r", r, 0, 255),
			numeric(state .. "_g", g, 0, 255),
			numeric(state .. "_b", b, 0, 255),
		},
	}
end

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			checkbox("disable_in_psykhanium", true),
			{
				setting_id = "draw_style",
				type = "dropdown",
				default_value = "blob",
				tooltip = "draw_style_tooltip",
				options = {
					{ text = "style_blob", value = "blob" },
					{ text = "style_circles", value = "circles" },
				},
			},
			{
				setting_id = "group_show",
				type = "group",
				sub_widgets = {
					checkbox("show_self", true),
					checkbox("show_teammates", true),
					checkbox("show_dogs", true),
					checkbox("show_leash", true),
					checkbox("show_links", true),
					checkbox("show_labels", true),
					checkbox("show_status", true),
					checkbox("follow_floor", true),
				},
			},
			{
				setting_id = "group_look",
				type = "group",
				sub_widgets = {
					{
						setting_id = "fill_style",
						type = "dropdown",
						default_value = "glow",
						tooltip = "fill_style_tooltip",
						options = {
							{ text = "fill_glow", value = "glow" },
							{ text = "fill_solid", value = "solid" },
						},
					},
					numeric("glow_width", 120, 20, 400),
					numeric("glow_alpha", 90, 0, 255),
					numeric("fill_alpha", 30, 0, 255),
					numeric("rim_alpha", 170, 0, 255),
					numeric("rim_width", 25, 5, 80),
					numeric("label_size", 16, 10, 40),
					numeric("status_position", 12, 0, 95),
				},
			},
			colour_group("self", 0, 200, 255),
			colour_group("direct", 60, 255, 90),
			colour_group("chain", 255, 220, 40),
			colour_group("held", 255, 140, 0),
			colour_group("out", 255, 60, 60),
		},
	},
}
