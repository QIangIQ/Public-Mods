local loc = {
	mod_name = { en = "QIangIQs Coherency Zone" },
	mod_description = { en = "Filled coherency circles with the game's real rules: each player's true radius (talents included), daisy chains through allies, the 20 m / 2 s grace leash and the toughness regen step. Values come from the game's coherency code." },

	disable_in_psykhanium = { en = "Disable in Psykhanium" },
	disable_in_psykhanium_tooltip = { en = "Hide everything in the Meat Grinder and the Training Area." },

	draw_style = { en = "Drawing style" },
	draw_style_tooltip = { en = "Blobs: every daisy chain is drawn as one merged shape (the union of its members' circles), coloured by its link to you. Circles: one circle per unit, coloured per unit." },
	style_blob = { en = "Merged blobs per chain" },
	style_circles = { en = "Separate circles" },

	group_show = { en = "What to show" },
	show_self = { en = "Your circle" },
	show_self_tooltip = { en = "Filled circle of your own coherency radius." },
	show_teammates = { en = "Teammate circles" },
	show_teammates_tooltip = { en = "Filled circle around every teammate at their own radius (an Ogryn, Psyker or Hive Scum with the radius talent has a bigger one). Coloured by how they are linked to you." },
	show_dogs = { en = "Arbites dog circle" },
	show_dogs_tooltip = { en = "The Arbites dog only counts for coherency when its owner has the talent that makes it count. When it counts it can also link players in a chain." },
	show_leash = { en = "Grace leash ring" },
	show_leash_tooltip = { en = "Thin ring at the distance where an ally who already was in coherency is dropped at once. Inside it an ally who walks out of range stays linked for the grace time (2 s base)." },
	show_links = { en = "Link lines" },
	show_links_tooltip = { en = "Lines between every pair of units that are directly in range of each other. A chain of lines that reaches you means everyone on it is in your coherency." },
	show_labels = { en = "Labels over allies" },
	show_labels_tooltip = { en = "Distance and link state over each ally, plus the distance they need to reach to link with you directly." },
	show_status = { en = "Status line" },
	show_status_tooltip = { en = "How many units are in your coherency and the toughness regen step that gives you." },
	follow_floor = { en = "Follow the floor" },
	follow_floor_tooltip = { en = "Bend the circles over stairs and slopes by probing the floor. Turn off for flat circles at foot height." },

	group_look = { en = "Look" },
	fill_alpha = { en = "Fill opacity (0 = edge only)" },
	rim_alpha = { en = "Edge opacity" },
	rim_width = { en = "Edge width (cm)" },
	label_size = { en = "Label size" },
	status_position = { en = "Status line height (from top)" },

	group_colour_self = { en = "Colour: you" },
	group_colour_direct = { en = "Colour: ally linked directly" },
	group_colour_chain = { en = "Colour: ally linked through a chain" },
	group_colour_held = { en = "Colour: ally held by the grace leash" },
	group_colour_out = { en = "Colour: ally out of coherency" },
}

for _, state in ipairs({ "self", "direct", "chain", "held", "out" }) do
	loc[state .. "_r"] = { en = "Red" }
	loc[state .. "_g"] = { en = "Green" }
	loc[state .. "_b"] = { en = "Blue" }
end

return loc
