return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsCoherencyZone` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsCoherencyZone", {
			mod_script       = "QIangIQsCoherencyZone/scripts/mods/QIangIQsCoherencyZone/QIangIQsCoherencyZone",
			mod_data         = "QIangIQsCoherencyZone/scripts/mods/QIangIQsCoherencyZone/QIangIQsCoherencyZone_data",
			mod_localization = "QIangIQsCoherencyZone/scripts/mods/QIangIQsCoherencyZone/QIangIQsCoherencyZone_localization",
		})
	end,
	packages = {},
}
