return {
    mod_name = {
        en = "QIangIQ's Bismuth Sword",
    },
    mod_description = {
        en = "Shows QIangIQ's bismuth-and-gilt rapier (modelled from scratch, Custom Assets; the slender sibling of the Bismuth Relic Blade) in place of the Maccabian Duelling Sword Mk IV and, optionally, the Relic Blade Mk II. Each weapon has its own toggle. By QIangIQ.",
    },
    replace_duelling_sword = {
        en = "Replace Maccabian Duelling Sword Mk IV",
    },
    replace_duelling_sword_description = {
        en = "Weapon template combatsword_p3_m2.",
    },
    replace_relic_blade = {
        en = "Replace Relic Blade Mk II",
    },
    replace_relic_blade_description = {
        en = "Weapon template powersword_2h_p1_m2.",
    },
    duelling_tilt = {
        en = "Duelling Sword tilt (degrees)",
    },
    duelling_tilt_description = {
        en = "Turns the sword in the plane of its flat side, pivoting on the hand. Positive = tip away from your body / view centre, negative = towards it.",
    },
    relic_tilt = {
        en = "Relic Blade tilt (degrees)",
    },
    relic_tilt_description = {
        en = "Turns the sword in the plane of its flat side, pivoting on the hand. Positive = tip away from your body / view centre, negative = towards it.",
    },
    model_size = {
        en = "Sword size",
    },
    model_size_description = {
        en = "Scales the whole sword about the hand. 1 = the tip reaches as far from your hand as the original weapon's.",
    },
    grip_shift = {
        en = "Grip position",
    },
    grip_shift_description = {
        en = "Moves the point of the sword that sits in the hand, in blade lengths. Positive = hold nearer the guard and blade, negative = hold nearer the pommel. 0 = middle of the grip; the grip runs from about 0.07 (guard side) to -0.07 (pommel side).",
    },
    glow_brightness = {
        en = "Inlay glow brightness",
    },
    glow_brightness_description = {
        en = "Brightness of the violet inlay lines and gems. 0 = no glow, 3 = as built, up to 100.",
    },
    menu_previews = {
        en = "Show in menus (inventory, operative previews)",
    },
    menu_previews_description = {
        en = "Also swaps the weapon in menu previews of your own operatives and in the weapon inspect view.",
    },
    toggle_duelling_keybind = {
        en = "Toggle Duelling Sword replacement",
    },
    toggle_relic_keybind = {
        en = "Toggle Relic Blade replacement",
    },
}
