return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsBismuthSword` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsBismuthSword", {
            mod_script = "QIangIQsBismuthSword/scripts/mods/QIangIQsBismuthSword/QIangIQsBismuthSword",
            mod_data = "QIangIQsBismuthSword/scripts/mods/QIangIQsBismuthSword/QIangIQsBismuthSword_data",
            mod_localization = "QIangIQsBismuthSword/scripts/mods/QIangIQsBismuthSword/QIangIQsBismuthSword_localization",
        })
    end,
    version = "1.3.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
