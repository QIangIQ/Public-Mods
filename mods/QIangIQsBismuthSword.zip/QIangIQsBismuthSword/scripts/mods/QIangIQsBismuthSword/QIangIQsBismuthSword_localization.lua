return {
    mod_name = {
        en = "QIangIQ's Bismuth Sword",
    },
    mod_description = {
        en = "Shows QIangIQ's bismuth-and-gilt rapier (modelled from scratch, Custom Assets; the slender sibling of the Bismuth Relic Blade) in place of every Duelling Sword and Heavy Sword mark and, optionally, the Relic Blade Mk II. A Sword model dropdown swaps between the rapier and the Holy Bismuth Greatsword. Each weapon has its own toggle. By QIangIQ.",
    },
    sword_model = {
        en = "Sword model",
    },
    sword_model_description = {
        en = "Which bismuth sword is shown on the replaced weapons. Bismuth Sword = the original rapier. Holy Bismuth Greatsword = the Holy Greatsword of the Ancient Kingdom with the same bismuth film, gilt wire grip and violet eye glow.",
    },
    sword_model_bismuth = {
        en = "Bismuth Sword",
    },
    sword_model_holy = {
        en = "Holy Bismuth Greatsword",
    },
    replace_duelling_sword = {
        en = "Replace Duelling Swords (all marks)",
    },
    replace_duelling_sword_description = {
        en = "Weapon templates combatsword_p3_m1, combatsword_p3_m2, combatsword_p3_m3.",
    },
    replace_heavy_sword = {
        en = "Replace Heavy Swords (all marks)",
    },
    replace_heavy_sword_description = {
        en = "Weapon templates combatsword_p2_m1, combatsword_p2_m2, combatsword_p2_m3.",
    },
    replace_relic_blade = {
        en = "Replace Relic Blade Mk II",
    },
    replace_relic_blade_description = {
        en = "Weapon template powersword_2h_p1_m2.",
    },
    duelling_tilt = {
        en = "Duelling Sword tilt (degrees)",
    },
    duelling_tilt_description = {
        en = "Turns the sword in the plane of its flat side, pivoting on the hand. Positive = tip away from your body / view centre, negative = towards it.",
    },
    heavy_tilt = {
        en = "Heavy Sword tilt (degrees)",
    },
    heavy_tilt_description = {
        en = "Turns the sword in the plane of its flat side, pivoting on the hand. Positive = tip away from your body / view centre, negative = towards it.",
    },
    relic_tilt = {
        en = "Relic Blade tilt (degrees)",
    },
    relic_tilt_description = {
        en = "Turns the sword in the plane of its flat side, pivoting on the hand. Positive = tip away from your body / view centre, negative = towards it.",
    },
    model_size = {
        en = "Sword size",
    },
    model_size_description = {
        en = "Scales the whole sword about the hand. 1 = the tip reaches as far from your hand as the original weapon's.",
    },
    grip_shift = {
        en = "Grip position",
    },
    grip_shift_description = {
        en = "Moves the point of the sword that sits in the hand, in blade lengths. Positive = hold nearer the guard and blade, negative = hold nearer the pommel. 0 = middle of the grip; the grip runs from about 0.07 (guard side) to -0.07 (pommel side).",
    },
    glow_brightness = {
        en = "Inlay glow brightness",
    },
    glow_brightness_description = {
        en = "Brightness of the violet inlay lines and gems. 0 = no glow, 3 = as built, up to 100.",
    },
    menu_previews = {
        en = "Show in menus (inventory, operative previews)",
    },
    menu_previews_description = {
        en = "Also swaps the weapon in menu previews of your own operatives and in the weapon inspect view.",
    },
    toggle_duelling_keybind = {
        en = "Toggle Duelling Sword replacement",
    },
    toggle_heavy_keybind = {
        en = "Toggle Heavy Sword replacement",
    },
    toggle_relic_keybind = {
        en = "Toggle Relic Blade replacement",
    },
}
