return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsMesaHeirloom` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsMesaHeirloom", {
            mod_script = "QIangIQsMesaHeirloom/scripts/mods/QIangIQsMesaHeirloom/QIangIQsMesaHeirloom",
            mod_data = "QIangIQsMesaHeirloom/scripts/mods/QIangIQsMesaHeirloom/QIangIQsMesaHeirloom_data",
            mod_localization = "QIangIQsMesaHeirloom/scripts/mods/QIangIQsMesaHeirloom/QIangIQsMesaHeirloom_localization",
        })
    end,
    version = "1.0.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
