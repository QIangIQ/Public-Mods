return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsChainLaspistol` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsChainLaspistol", {
            mod_script = "QIangIQsChainLaspistol/scripts/mods/QIangIQsChainLaspistol/QIangIQsChainLaspistol",
            mod_data = "QIangIQsChainLaspistol/scripts/mods/QIangIQsChainLaspistol/QIangIQsChainLaspistol_data",
            mod_localization = "QIangIQsChainLaspistol/scripts/mods/QIangIQsChainLaspistol/QIangIQsChainLaspistol_localization",
        })
    end,
    version = "1.3.1",
    author = "QIangIQ",
    packages = {},
}
