-- Block brace (first person): while action_block runs, the left arm is posed by script so the Laspistol's trigger
-- guard (or the forearm) props up the Chainsword blade.
--
-- Method = QIangIQsKarambit / QIangIQsButterflyKnife (seen working in game): a skeleton-only "driver" unit with the
-- first-person bone names (bf_fp_driver / kb_fp_driver, compiled against content/characters/player/human/first_person/base)
-- is linked to the first-person unit; every frame it copies the animated first-person pose (QIangIQsKarambit_fingers.lua
-- Fingers.update), the arm mesh units are re-linked to it with LINK_MODE_NODE_NAME (fp_start / fp_stop), and Lua then
-- overrides bones. Here the override is a two-bone IK on j_leftarm / j_leftforearm towards a point under the blade.
-- The driver asset ships in this mod (Custom/cl_fp_driver), so the mod depends on no other QIangIQs mod.
local Brace = {}
local CFG = nil

function Brace.setup(cfg)
    CFG = cfg
end

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function parent_chain(unit, node)
    local list, current, guard = {}, node, 0

    while current and guard < 64 do
        list[#list + 1] = current

        if current == 1 then
            break
        end

        current = Unit.scene_graph_parent(unit, current)
        guard = guard + 1
    end

    return list
end

local function root_relative(unit, node)
    if node == nil or node == 1 then
        return Quaternion.identity(), Vector3(0, 0, 0)
    end

    local chain = parent_chain(unit, node)
    local rotation, position = Quaternion.identity(), Vector3(0, 0, 0)
    local first = chain[#chain] == 1 and #chain - 1 or #chain

    for i = first, 1, -1 do
        position = position + Quaternion.rotate(rotation, Unit.local_position(unit, chain[i]))
        rotation = Quaternion.multiply(rotation, Unit.local_rotation(unit, chain[i]))
    end

    return rotation, position
end

-- driver <-> first-person node table (Fingers.driver without the finger part)
local function make_fpd(driver, fp_unit)
    local fpd = { driver = driver, fp_unit = fp_unit, nodes = {}, by_node = {}, fp_chains = {} }

    for _, name in ipairs(CFG.fp_nodes) do
        if Unit.has_node(driver, name) then
            local node = Unit.node(driver, name)

            if node ~= 1 and not fpd.by_node[node] then
                local entry = { node = node, parent = Unit.scene_graph_parent(driver, node) }

                if Unit.has_node(fp_unit, name) then
                    entry.fp = Unit.node(fp_unit, name)
                    fpd.fp_chains[entry.fp] = parent_chain(fp_unit, entry.fp)
                end

                fpd.by_node[node] = entry
                fpd.nodes[#fpd.nodes + 1] = entry
            end
        end
    end

    for _, name in ipairs({ "j_leftarm", "j_leftforearm", "j_lefthand", "j_leftweaponattach", "ap_camera_node" }) do
        if not Unit.has_node(driver, name) then
            return nil
        end
    end

    return fpd
end

-- copy the animated first-person pose onto the driver (Fingers.update, first loop)
local function copy_pose(fpd)
    local driver, fp_unit = fpd.driver, fpd.fp_unit
    local poses = {}

    local function pose_of(node)
        if node == nil or node == 1 then
            return Quaternion.identity(), Vector3(0, 0, 0)
        end

        local pose = poses[node]

        if pose then
            return pose[1], pose[2]
        end

        local entry = fpd.by_node[node]
        local rotation, position

        if entry and entry.fp then
            local chain = fpd.fp_chains[entry.fp]
            rotation, position = Quaternion.identity(), Vector3(0, 0, 0)

            local first = chain[#chain] == 1 and #chain - 1 or #chain

            for i = first, 1, -1 do
                position = position + Quaternion.rotate(rotation, Unit.local_position(fp_unit, chain[i]))
                rotation = Quaternion.multiply(rotation, Unit.local_rotation(fp_unit, chain[i]))
            end
        else
            local parent_rotation, parent_position = pose_of(Unit.scene_graph_parent(driver, node))

            rotation = Quaternion.multiply(parent_rotation, Unit.local_rotation(driver, node))
            position = parent_position + Quaternion.rotate(parent_rotation, Unit.local_position(driver, node))
        end

        poses[node] = { rotation, position }

        return rotation, position
    end

    for i = 1, #fpd.nodes do
        local entry = fpd.nodes[i]

        if entry.fp then
            local rotation, position = pose_of(entry.node)
            local parent_rotation, parent_position = pose_of(entry.parent)
            local inverse_parent = Quaternion.inverse(parent_rotation)

            Unit.set_local_rotation(driver, entry.node, Quaternion.multiply(inverse_parent, rotation))
            Unit.set_local_position(driver, entry.node, Quaternion.rotate(inverse_parent, position - parent_position))
        end
    end
end

-- IK helpers (driver root-relative space) --------------------------------------------------------------------------
local function rotation_between(u, v)
    local lu, lv = Vector3.length(u), Vector3.length(v)

    if lu < 1e-6 or lv < 1e-6 then
        return Quaternion.identity()
    end

    u, v = u * (1 / lu), v * (1 / lv)

    local axis = Vector3.cross(u, v)
    local s = Vector3.length(axis)

    if s < 1e-6 then
        return Quaternion.identity()
    end

    return Quaternion.axis_angle(axis * (1 / s), math.atan2(s, Vector3.dot(u, v)))
end

-- turn a node by q (root-relative) about its own origin
local function turn_node(driver, node, q)
    local pr = root_relative(driver, Unit.scene_graph_parent(driver, node))
    local r = root_relative(driver, node)

    Unit.set_local_rotation(driver, node, Quaternion.multiply(Quaternion.inverse(pr), Quaternion.multiply(q, r)))
end

local function pos(driver, name)
    local _, p = root_relative(driver, Unit.node(driver, name))

    return p
end

local function two_bone(driver, target, pole_point, w)
    local arm, fore = Unit.node(driver, "j_leftarm"), Unit.node(driver, "j_leftforearm")
    local S, E, H = pos(driver, "j_leftarm"), pos(driver, "j_leftforearm"), pos(driver, "j_lefthand")
    local a, b = Vector3.length(E - S), Vector3.length(H - E)
    local to_target = target - S
    local d = math.clamp(Vector3.length(to_target), math.abs(a - b) + 1e-3, a + b - 1e-3)
    local dir = Vector3.normalize(to_target)
    local pv = pole_point - S

    pv = pv - dir * Vector3.dot(pv, dir)

    if Vector3.length(pv) < 1e-5 then
        pv = (E - S) - dir * Vector3.dot(E - S, dir)
    end

    if Vector3.length(pv) < 1e-5 then
        return
    end

    pv = Vector3.normalize(pv)

    local cos_a = math.clamp((a * a + d * d - b * b) / (2 * a * d), -1, 1)
    local sin_a = math.sqrt(math.max(0, 1 - cos_a * cos_a))
    local elbow = S + dir * (cos_a * a) + pv * (sin_a * a)
    local q1 = Quaternion.lerp(Quaternion.identity(), rotation_between(E - S, elbow - S), w)

    turn_node(driver, arm, q1)

    local E1, H1 = pos(driver, "j_leftforearm"), pos(driver, "j_lefthand")
    local goal = H + (S + dir * d - H) * w
    local q2 = rotation_between(H1 - E1, goal - E1)

    turn_node(driver, fore, q2)
end

-- blade in driver root space: grip = right weapon node, tip direction towards the sword's fx_sweep node
local function blade(ext, slot, driver, fp_unit)
    local sweep_world

    for unit in pairs(slot.item_name_by_unit_1p or {}) do
        if unit_ok(unit) and Unit.has_node(unit, "fx_sweep") then
            sweep_world = Unit.world_position(unit, Unit.node(unit, "fx_sweep"))

            break
        end
    end

    if not sweep_world or not Unit.has_node(driver, "j_rightweaponattach") then
        return nil
    end

    local root_r, root_p = Unit.world_rotation(fp_unit, 1), Unit.world_position(fp_unit, 1)
    local sweep = Quaternion.rotate(Quaternion.inverse(root_r), sweep_world - root_p)
    local grip = pos(driver, "j_rightweaponattach")
    local dir = sweep - grip

    if Vector3.length(dir) < 1e-4 then
        return nil
    end

    return grip, Vector3.normalize(dir)
end

local function apply_brace(ext, slot, data, w)
    local driver = data.driver
    local grip, dir = blade(ext, slot, driver, data.fp_unit)

    if not grip then
        return
    end

    local cam_r = root_relative(driver, Unit.node(driver, "ap_camera_node"))
    local down = Quaternion.rotate(cam_r, Vector3(0, 0, -1))
    local left = Quaternion.rotate(cam_r, Vector3(-1, 0, 0))
    local point = grip + dir * CFG.opt("brace_tip", 0.58) + down * CFG.opt("brace_above", 0.033)
    local mode = CFG.opt("brace_with", "trigger")

    if mode == "forearm" then
        -- forearm across under the blade: hand out to the left of the contact point, elbow to the right of it
        local fore_len = Vector3.length(pos(driver, "j_lefthand") - pos(driver, "j_leftforearm"))
        local perp = left - dir * Vector3.dot(left, dir)

        if Vector3.length(perp) < 1e-4 then
            return
        end

        perp = Vector3.normalize(perp)
        two_bone(driver, point + perp * (0.5 * fore_len), point - perp * fore_len, w)
    else
        -- trigger guard: the left hand (holding the pistol) goes under the blade, elbow keeps its animated side
        two_bone(driver, point, pos(driver, "j_leftforearm") + down * 0.2, w)
    end
end

-- 0.5.0 hold (user: pistol not held properly): the pistol frame sits at a fixed point in camera space (hold_offset /
-- hold_rotation, the 1P sliders). The left hand is solved backwards from it: j_leftweaponattach, the node a left-hand
-- item hangs from, keeps its animated offset to j_lefthand, so the hand target = pistol frame * inverse(that offset).
-- The arm is IK'd to the hand position, the hand gets the solved rotation, and the main file links the pistol to the
-- driver's j_leftweaponattach with an identity pose, so it sits in the palm. With grip_fingers the left fingers copy
-- the right hand's local finger rotations (closed on the sword grip); this assumes the rig's left/right joints are
-- behaviour-mirrored.
local FINGERS = {}         -- { left node name, right node name }

for _, finger in ipairs({ "index", "middle", "ring", "pinky" }) do
    FINGERS[#FINGERS + 1] = { "j_leftinhand" .. finger, "j_rightinhand" .. finger }

    for i = 1, 3 do
        FINGERS[#FINGERS + 1] = { "j_lefthand" .. finger .. i, "j_righthand" .. finger .. i }
    end
end

for i = 1, 3 do
    FINGERS[#FINGERS + 1] = { "j_lefthandthumb" .. i, "j_righthandthumb" .. i }
end

-- 0.7.0 (user: the back of the hand is inside the pistol): j_leftweaponattach's orientation does not describe a
-- pistol grip, so the hand rotation is built from the hand's own finger bones (QIangIQsKarambit_fingers.lua builds its
-- hand frame the same way: forward = hand -> j_*handmiddle1, up = j_*handpinky1 -> j_*handindex1). Target in pistol
-- axes (x right, y forward, z up): pinky -> index runs up the grip (slanted forward, HAND_UP), fingers point forward.
-- Which side the palm faces then follows from the rig itself, so no left/right mirroring is assumed. Position: the
-- j_leftweaponattach point (in the palm) goes to the pistol origin (the origin sits in the palm for a right-hand
-- pistol) plus the hand_* sliders.
local HAND_UP = Vector3Box(0, 0.25, 1)

function Brace.hand_sliders()
    local h = Vector3(CFG.opt("hand_x", -0.041), CFG.opt("hand_y", -0.134), CFG.opt("hand_z", -0.05))
    local extra = Quaternion.from_yaw_pitch_roll(math.rad(CFG.opt("hand_yaw", 0)), math.rad(CFG.opt("hand_pitch", 1)),
        math.rad(CFG.opt("hand_roll", 0)))

    return h, extra
end

-- pistol frame (driver-root space) of the last update, for the main file to place the pistol
function Brace.pistol_pose(ext)
    local data = ext.__qiangiq_chainlas_brace

    if data and data.pistol_p then
        return data.pistol_p:unbox(), data.pistol_r:unbox()
    end
end

local function hold_frame(data, hold_offset, hold_rotation)
    local cam_r, cam_p = root_relative(data.driver, Unit.node(data.driver, "ap_camera_node"))

    return Quaternion.multiply(cam_r, hold_rotation), cam_p + Quaternion.rotate(cam_r, hold_offset)
end

-- 0.9.0 brace (user: the blade must sit under the pistol's muzzle / handguard at the front, not at the magwell):
-- during action_block the pistol rests on top of the blade near the tip (brace_tip along it, brace_above over its
-- centre line); the pistol's contact point is just behind and below its muzzle (front_point = the measured fx_muzzle_01
-- position in pistol axes, minus brace_back along the barrel and 3 cm down), then the same hand solve as the hold.
local function brace_frame(ext, slot, data, pistol_r, front_point)
    local driver = data.driver
    local grip, dir = blade(ext, slot, driver, data.fp_unit)

    if not grip then
        return nil
    end

    local cam_r = root_relative(driver, Unit.node(driver, "ap_camera_node"))
    local up = Quaternion.rotate(cam_r, Vector3(0, 0, 1))
    local point = grip + dir * CFG.opt("brace_tip", 0.58) + up * CFG.opt("brace_above", 0.033)
    local contact = (front_point or Vector3(0, 0.18, 0.02)) + Vector3(0, -CFG.opt("brace_back", 0.072), -0.03)

    return point - Quaternion.rotate(pistol_r, contact)
end

local function apply_hold(data, pistol_r, pistol_p, grip_point)
    local driver = data.driver
    local hand, attach = Unit.node(driver, "j_lefthand"), Unit.node(driver, "j_leftweaponattach")
    local cam_r = root_relative(driver, Unit.node(driver, "ap_camera_node"))
    local h, extra = Brace.hand_sliders()
    local hand_r, hand_p = root_relative(driver, hand)
    local inv_hand = Quaternion.inverse(hand_r)
    local _, attach_p = root_relative(driver, attach)
    local rel_p = Quaternion.rotate(inv_hand, attach_p - hand_p)
    local f_local = Quaternion.rotate(inv_hand, pos(driver, "j_lefthandmiddle1") - hand_p)
    local u_local = Quaternion.rotate(inv_hand, pos(driver, "j_lefthandindex1") - pos(driver, "j_lefthandpinky1"))
    local frame_r = Quaternion.multiply(pistol_r, extra)
    local up = Quaternion.rotate(frame_r, Vector3.normalize(HAND_UP:unbox()))
    local forward = Quaternion.rotate(frame_r, Vector3(0, 1, 0))

    forward = Vector3.normalize(forward - up * Vector3.dot(forward, up))
    f_local = Vector3.normalize(f_local - Vector3.normalize(u_local) * Vector3.dot(f_local, Vector3.normalize(u_local)))

    -- Quaternion.look(dir, up): y axis = dir, z axis = up (orthogonalised)
    local target_r = Quaternion.multiply(Quaternion.look(forward, up),
        Quaternion.inverse(Quaternion.look(f_local, Vector3.normalize(u_local))))
    -- 1.0.0: the measured grip point (0.8.0/0.9.0) put the hand under the muzzle in game, while 0.5.0 (palm point on the
    -- pistol origin) had the fist on the grip, only too high, so: origin, 2 cm down, plus the hand sliders.
    -- grip_from_parts turns the measured point back on.
    local palm = (CFG.opt("grip_from_parts", false) and grip_point or Vector3(0, 0, 0)) + Vector3(0, 0, -0.02) + h
    local target_p = pistol_p + Quaternion.rotate(pistol_r, palm) - Quaternion.rotate(target_r, rel_p)
    local down = Quaternion.rotate(cam_r, Vector3(0, 0, -1))
    local left = Quaternion.rotate(cam_r, Vector3(-1, 0, 0))

    two_bone(driver, target_p, target_p + down * 0.3 + left * 0.15, 1)

    local parent_r = root_relative(driver, Unit.scene_graph_parent(driver, hand))

    Unit.set_local_rotation(driver, hand, Quaternion.multiply(Quaternion.inverse(parent_r), target_r))

    if CFG.opt("grip_fingers", true) ~= false then
        for i = 1, #FINGERS do
            local l, r = FINGERS[i][1], FINGERS[i][2]

            if Unit.has_node(driver, l) and Unit.has_node(driver, r) then
                Unit.set_local_rotation(driver, Unit.node(driver, l), Unit.local_rotation(driver, Unit.node(driver, r)))
            end
        end
    end

    data.pistol_p = Vector3Box(pistol_p)
    data.pistol_r = QuaternionBox(pistol_r)
end

-- start / stop / update --------------------------------------------------------------------------------------------
local function arm_units(ext)
    local found = {}

    for slot_name, slot in pairs(ext._equipment or {}) do
        if type(slot_name) == "string" and (slot_name:find("^slot_body") or slot_name:find("^slot_gear")) and unit_ok(slot.unit_1p) then
            found[#found + 1] = slot.unit_1p
        end
    end

    return found
end

local function relink(world, unit, parent)
    World.unlink_unit(world, unit)
    World.link_unit(world, unit, 1, parent, 1, World.LINK_MODE_NODE_NAME)
end

function Brace.stop(ext)
    local data = ext.__qiangiq_chainlas_brace

    if not data then
        return
    end

    ext.__qiangiq_chainlas_brace = nil

    local world = ext.__qiangiq_chainlas_world

    if world and unit_ok(data.fp_unit) then
        for unit in pairs(data.arms) do
            if unit_ok(unit) then
                relink(world, unit, data.fp_unit)
            end
        end
    end

    if unit_ok(data.driver) then
        local unit_spawner = Managers.state and Managers.state.unit_spawner

        if unit_spawner then
            unit_spawner:mark_for_deletion(data.driver)
        end
    end
end

local function start(ext, fp_unit, world)
    local unit_spawner = Managers.state and Managers.state.unit_spawner
    local path = CFG.driver_path()

    if not (unit_spawner and path) then
        return nil
    end

    local driver = unit_spawner:spawn_unit(path, Unit.world_pose(fp_unit, 1))

    if not driver then
        return nil
    end

    local ok, fpd = pcall(make_fpd, driver, fp_unit)

    if not ok or not fpd then
        unit_spawner:mark_for_deletion(driver)
        CFG.error("brace driver lacks the left arm / camera nodes: brace off")

        return nil
    end

    World.link_unit(world, driver, 1, fp_unit, 1)
    copy_pose(fpd)

    local data = { driver = driver, fpd = fpd, fp_unit = fp_unit, arms = {}, blend = 0 }

    ext.__qiangiq_chainlas_brace = data

    return data
end

-- returns the unit the left-hand pistol must be linked to in first person (driver while bracing is set up)
function Brace.update(ext, slot, is_blocking, dt, hold_offset, hold_rotation, grip_point, front_point)
    local fpe = unit_ok(ext._unit) and ScriptUnit.has_extension(ext._unit, "first_person_system")
    local fp_unit = fpe and fpe:first_person_unit()
    local world = ext.__qiangiq_chainlas_world
    local data = ext.__qiangiq_chainlas_brace
    local bracing = CFG.opt("brace_with", "trigger") ~= "off"
    local want = slot ~= nil and slot.hidden_1p == false and (bracing or hold_offset ~= nil) and CFG.driver_path() ~= nil
        and world ~= nil and unit_ok(fp_unit) and fpe.is_in_first_person_mode and fpe:is_in_first_person_mode()

    if data and (not want or data.fp_unit ~= fp_unit or not unit_ok(data.driver)) then
        Brace.stop(ext)
        data = nil
    end

    if not want then
        return nil
    end

    data = data or start(ext, fp_unit, world)

    if not data then
        return nil
    end

    -- arm meshes follow the driver (re-check: a body slot can be re-spawned)
    for _, unit in ipairs(arm_units(ext)) do
        if not data.arms[unit] then
            relink(world, unit, data.driver)
            data.arms[unit] = true
        end
    end

    for unit in pairs(data.arms) do
        if not unit_ok(unit) then
            data.arms[unit] = nil
        end
    end

    copy_pose(data.fpd)

    -- 1.2.0 (user: at the start of the block the pistol arm snaps to the top right before settling): the blade is still
    -- swinging up during the first frames of parry_pose, so the brace now waits brace_delay before blending in (over
    -- 0.2 s), and the contact point follows the blade through a damped filter instead of every frame's raw position.
    dt = dt or 0
    data.block_t = is_blocking and (data.block_t or 0) + dt or 0

    local blend_time = 0.2
    local engaged = is_blocking and data.block_t >= CFG.opt("brace_delay", 0.15)

    data.blend = math.clamp(data.blend + (engaged and 1 or -1) * dt / blend_time, 0, 1)

    local mode = CFG.opt("brace_with", "trigger")
    local w = data.blend * data.blend * (3 - 2 * data.blend)

    -- 1.2.0 (user: the block is too close to the screen): while braced, the whole driver (both arms, the pistol) moves
    -- block_forward along the view; the main file moves the sword by the same world offset (Brace.shift_world)
    local cam_r = root_relative(data.driver, Unit.node(data.driver, "ap_camera_node"))
    local shift = Quaternion.rotate(cam_r, Vector3(0, 1, 0)) * (CFG.opt("block_forward", 0.08) * w)

    Unit.set_local_position(data.driver, 1, shift)
    data.shift_world = Vector3Box(Quaternion.rotate(Unit.world_rotation(fp_unit, 1), shift))

    if hold_offset then
        local ok, err = pcall(function()
            local pistol_r, pistol_p = hold_frame(data, hold_offset, hold_rotation or Quaternion.identity())

            if mode == "trigger" and w > 0 then
                local braced_p = brace_frame(ext, slot, data, pistol_r, front_point)

                if braced_p then
                    local smoothed = data.brace_p and data.brace_p:unbox() or pistol_p

                    smoothed = Vector3.lerp(smoothed, braced_p, 1 - math.exp(-dt * 14))
                    data.brace_p = Vector3Box(smoothed)
                    pistol_p = Vector3.lerp(pistol_p, smoothed, w)
                end
            else
                data.brace_p = nil
            end

            apply_hold(data, pistol_r, pistol_p, grip_point)
        end)

        if not ok and not data.reported then
            data.reported = true
            CFG.error("hold: " .. tostring(err))
        end
    end

    if bracing and w > 0 and (mode == "forearm" or not hold_offset) then
        local ok, err = pcall(apply_brace, ext, slot, data, w)

        if not ok and not data.reported then
            data.reported = true
            CFG.error("brace: " .. tostring(err))
        end
    end

    World.update_unit_and_children(world, data.driver)

    return data.driver
end

function Brace.shift_world(ext)
    local data = ext.__qiangiq_chainlas_brace

    return data and data.shift_world and data.shift_world:unbox() or nil
end

function Brace.debug(ext)
    local data = ext.__qiangiq_chainlas_brace

    if not data then
        return "brace: not active (driver asset " .. tostring(CFG.driver_path()) .. ")"
    end

    local n = 0

    for _ in pairs(data.arms) do
        n = n + 1
    end

    return string.format("brace: active, %d arm units on the driver, blend %.2f", n, data.blend)
end

return Brace
