-- QIangIQ's Chainsword & Laspistol 0.2.0: a dual-wield Zealot weapon (Chainsword right hand, Laspistol left hand).
--
-- Nothing is invented: every piece is an existing retail asset or template, listed here with its source.
--   * Swings: chainsword_p1_m1 (weapon_templates/chain_swords/chainsword_p1_m1.lua), cloned whole, so the light/heavy
--     chain, damage, animation state machines (power_sword 3p, chain_sword 1p), sweeps and sounds are the Chainsword's.
--   * Shot: laspistol_p1_m1 action_shoot_hip (laspistol_p1_m1.lua:225-312) cloned as action_pistol_shot, started by the
--     melee "special_action" input (the Chainsword's own special action, action_toggle_special, is replaced; the rev has
--     no use here). Every swing already chains to special_action, so a shot cancels a recovery; the shot chains back
--     into start_attack. The laspistol's hit scan template / damage type are baked into the clone. No recoil.
--   * Reload: laspistol_p1_m1 action_reload (:478), reload template ReloadTemplates.laspistol, ammo template
--     laspistol_p1_m1, conditional_state_to_action_input (:887-896) for the empty-clip auto reload. The chain_sword
--     state machine lacks the pistol reload anim events: Unit.has_animation_event guards them (as QIangIQsDauntlessArmory).
--   * Model: the Laspistol master item is cloned and added as a child attachment of the Chainsword item, so the game
--     spawns, loads (item_package.lua dependency recursion) and cleans it up with the Chainsword. Its rig is then
--     re-linked from the Chainsword to the character's left weapon node "j_leftweaponattach"
--     (player_unit_data_component_config.lua:590, ui_weapon_spawner.lua:339) with LINK_MODE_NONE, the way the
--     QIangIQsDauntlessArmory clip is moved; the fx_sources node "fx_muzzle_01" is found on the pistol's barrel.
--     The orientation in the hand is unknown (no data), so 1P/3P offset sliders are in the options.
--
-- 0.1.1: the live game's (Aussiemon master) weapon templates have no grenade_ability chain entries any more
--   (laspistol_p1_m1.lua action_shoot_hip / action_reload), so cloning them errored "bad argument #1 to 'clone'"
--   and the template never registered. Those entries are gone; checked against the live laspistol/chainsword files.
--
-- 0.1.2: CTD on equip, weapon_tweak_templates.lua:579 pairs(nil): the borrowed pistol fields carry preparsed names
--   ("base_laspistol_p1_m1", "action_shoot_hip_<handling>") whose __base_template_lookup entries were not copied.
--   They are now merged into the clone's lookup (see the Tweak lookups block).
--
-- 0.2.0 (user: the block should rest on the pistol's trigger guard or the forearm, custom animation like the Butterfly
--   Knife / Karambit mods): first-person left arm IK during action_block, see QIangIQsChainLaspistol_brace.lua.
-- 0.2.1 (user: standalone, rely on no other mods): the driver skeleton ships in this mod (Custom/cl_fp_driver).
-- 0.3.0 (user: use the unreleased chainsword + laspistol animations): template uses Fatshark's chainsword_laspistol
--   1p/3p state machines; the pistol shot plays attack_shoot, the reload plays reload_start/middle/end. Brace defaults off.
-- 0.3.2 (user, in game: the unreleased set holds the sword reverse-grip / flat across both hands, wants the default
--   chainsword hold): the unreleased animations are now opt-in (option off by default); chainsword animations again.
-- 0.4.0 (in game: pistol renders but sat 0.43 m left of the camera, out of view; saved settings kept the old defaults):
--   1P pistol held at a fixed camera-space point with the left arm posed onto it; settings renamed (unreleased_anims,
--   block_brace) so stale saved values no longer apply.
-- 0.5.0 (in game: pistol floats above an open left hand): the hand is solved from the pistol frame through
--   j_leftweaponattach, the pistol rides that node of the driver, and the left fingers copy the right hand's grip.
-- 0.6.0 (in game: pistol half inside the fist, block not braced): grip offset sliders (hand 5 cm back, 4 cm down in the
--   pistol frame by default); brace on by default (setting brace_with, trigger guard): during the block the pistol moves
--   under the blade with its trigger guard on the contact point.
-- 0.7.0 (in game: back of the hand inside the pistol; brace nearer the tip; teeth forward; permanently revved): hand
--   rotation built from the finger bones, brace contact 0.5 m along the blade, sword turned about the blade axis in the
--   block (teeth_block), chainsword special kept and held on (permanent_rev).
-- 0.8.0 (in game: line 779 error every frame, which also skipped the teeth turn; hand on the handguard; pistol inside
--   the sword in the block): pistol pose return fixed, the hand goes to the pistol's measured grip point, brace contact
--   sits brace_gap (8 cm) under the blade.
-- 0.9.0 (in game: grip unchanged; the blade rests at the magwell, should be under the muzzle/handguard; user: rev with
--   no gameplay effect, 3x cleave): grip part near the origin ignored, muzzle measured; the pistol now lies on the blade
--   with its front on it; special_active written directly, *_special_active action overrides removed; cleave x3.
-- 1.0.0 (in game: the hand grips under the muzzle, the grip sits in the forearm; the push flips the blade up; user:
--   push = cleaving attack): palm back on the pistol origin (0.5.0 showed the origin sits in the fist), measured pistol
--   points are logged; the push is the horizontal heavy with big_cleave.
-- 1.1.0 (user: cannot attack after the push attack; the slider values are the new normal; two magazines): push branch
--   of the input hierarchy also takes start_attack / block, the push swing keeps the push_follow_up stab, the user's
--   tuned slider values are the defaults, the off-hand pistol's spare reload magazine (magazine2) is dropped.
-- 1.2.0 (user: the pistol arm snaps to the top right as the block starts; the block is too close to the screen): brace
--   waits brace_delay, blends over 0.2 s and follows a damped blade point; block_forward moves arms, pistol and sword
--   forward while braced.
-- 1.3.0 (user picked the optional Dauntless sound after the 2026-10-30 name list): dauntless_sound (off by default)
--   points this template's swing, heavy swing, stuck loop and idle hum aliases at the hash-matched
--   wwise/events/weapon/*dauntless_2h_chainsword* events, which sit in the same package as the retail chainsword swing.
-- 1.3.1 (meltagun thread lesson, its 0.10.1 CTD at network_lookup.lua:605): synced gear sounds are sent as indices into
--   NetworkLookup.player_character_sounds, built once from the retail aliases, so the Dauntless events (play/stop, husk)
--   are appended to it in a fixed sorted order whenever the template registers, whether or not the option is on.
--
-- New weapon pattern = QIangIQsDauntlessArmory / QIangIQsShardStaff: template clone into WeaponTemplates + NetworkLookup
-- append + particle/sound alias copy, item clone into MasterItems.get_cached(), equip by override_slot.
-- Author: QIangIQ
local mod = get_mod("QIangIQsChainLaspistol")

local WeaponTemplates = require("scripts/settings/equipment/weapon_templates/weapon_templates")
local MasterItems = require("scripts/backend/master_items")
local NetworkLookup = require("scripts/network_lookup/network_lookup")

local MELEE_ROOT = "content/items/weapons/player/melee/"
local RANGED_ROOT = "content/items/weapons/player/ranged/"

local TEMPLATE = "chainsword_laspistol_p1_m1"
local SOURCE_TEMPLATE = "chainsword_p1_m1"
local PISTOL_TEMPLATE = "laspistol_p1_m1"
local ITEM = MELEE_ROOT .. TEMPLATE
local SOURCE_ITEM = MELEE_ROOT .. SOURCE_TEMPLATE
local PISTOL_ITEM = RANGED_ROOT .. PISTOL_TEMPLATE
local OFFHAND_ITEM = RANGED_ROOT .. "qiangiq_chainlaspistol/offhand_laspistol_01"
local OFFHAND_SLOT = "qiangiq_offhand"
local LEFT_NODE = "j_leftweaponattach"

-- 0.3.0: Fatshark's unreleased chainsword + laspistol animation sets (asset sweep of build 139617; packages and state
-- machines exist in the shipped bundles, no Lua uses them). Their event lists (id32 matched against every string in the
-- game source) hold every chainsword_p1_m1 event plus attack_shoot and the laspistol reload_start/middle/end.
local CHAINLAS_SM_1P = "content/characters/player/human/first_person/animations/chainsword_laspistol"
local CHAINLAS_SM_3P = "content/characters/player/human/third_person/animations/chainsword_laspistol"

mod:add_global_localize_strings({
    loc_qiangiq_chainlaspistol = { en = "Chainsword & Laspistol" },
})

local function say(fmt, ...)
    local text = string.format(fmt, ...)

    mod:echo(text)
    mod:info(text)
end

-- Block brace (first person, QIangIQsKarambit driver method): QIangIQsChainLaspistol_brace.lua -----------------------
-- Standalone (user rule): the skeleton-only driver unit ships in this mod's own Custom/cl_fp_driver, a rename of
-- QIangIQsButterflyKnife's bf_fp_driver build (only name hashes and stream names differ, as in QIangIQsAWP's aw_fp_driver).
local DRIVERS = {
    { id = "QIangIQsChainLaspistol:cl_fp_driver", unit = "content/mods/qiangiq_chainlas/cl_fp_driver" },
}
local driver_loaded = {}

local Brace = mod:io_dofile("QIangIQsChainLaspistol/scripts/mods/QIangIQsChainLaspistol/QIangIQsChainLaspistol_brace")

Brace.setup({
    fp_nodes = mod:io_dofile("QIangIQsChainLaspistol/scripts/mods/QIangIQsChainLaspistol/QIangIQsChainLaspistol_fp_nodes"),
    opt = function(key, default)
        local v = mod:get(key)

        if v == nil then
            return default
        end

        return v
    end,
    driver_path = function()
        for i, d in ipairs(DRIVERS) do
            if driver_loaded[i] then
                return d.unit
            end
        end
    end,
    error = function(text)
        mod:error("%s", text)
    end,
})

-- Network lookups: new names go at the end so no existing id moves (QIangIQsShardStaff append_lookup) ---------------
local function append_lookup(lookup_name, key)
    local lookup = NetworkLookup[lookup_name]

    if not lookup then
        return false, "no lookup"
    end

    local existing = rawget(lookup, key)

    if existing then
        return true, existing
    end

    local index = #lookup + 1

    rawset(lookup, index, key)
    rawset(lookup, key, index)

    return true, index
end

-- Particle / sound aliases keyed by wielded_weapon_template -----------------------------------------------------------
local ALIAS_MODULES = {
    "scripts/settings/particles/player_character_particle_aliases",
    "scripts/settings/sound/player_character_sound_event_aliases",
}

local function alias_keys(root, source, target, seen, counter)
    if type(root) ~= "table" or seen[root] then
        return
    end

    seen[root] = true

    local value = rawget(root, source)

    if value ~= nil and rawget(root, target) == nil then
        root[target] = value
        counter.n = counter.n + 1
    end

    for _, child in pairs(root) do
        if type(child) == "table" then
            alias_keys(child, source, target, seen, counter)
        end
    end
end

local function copy_aliases(source, target)
    local counter = { n = 0 }

    for _, path in ipairs(ALIAS_MODULES) do
        local ok, module = pcall(require, path)

        if ok then
            alias_keys(module, source, target, {}, counter)
        else
            mod:error("alias module %s: %s", path, tostring(module))
        end
    end

    return counter.n
end

-- Optional Dauntless 2H chainsword sound set (Datavault Techniques/datafile-name-list-2026-10-30, lines 97745-97750 and
-- 99121-99124). Patterns follow the retail chainsword_2h_p1_m1 entries of player_character_sound_event_aliases.
local DAUNTLESS_SOUNDS = {
    sfx_swing = "wwise/events/weapon/play_dauntless_2h_chainsword_swing",
    sfx_swing_heavy = "wwise/events/weapon/play_dauntless_2h_chainsword_swing",
    melee_sticky_loop = "wwise/events/weapon/%s_dauntless_2h_chainsword_stuck_loop",
    equipped_item_passive = "wwise/events/weapon/%s_dauntless_2h_chainsword",
}

local function register_dauntless_sounds()
    local events = { DAUNTLESS_SOUNDS.sfx_swing, DAUNTLESS_SOUNDS.sfx_swing .. "_husk" }

    for _, alias in ipairs({ "melee_sticky_loop", "equipped_item_passive" }) do
        for _, verb in ipairs({ "play", "stop" }) do
            local event = (DAUNTLESS_SOUNDS[alias]:gsub("%%s", verb))

            events[#events + 1] = event
            events[#events + 1] = event .. "_husk"
        end
    end

    table.sort(events)

    for _, event in ipairs(events) do
        local ok, err = append_lookup("player_character_sounds", event)

        if not ok then
            mod:error("sound lookup %s: %s", event, tostring(err))
        end
    end
end

local function apply_dauntless_sound()
    local ok, aliases = pcall(require, "scripts/settings/sound/player_character_sound_event_aliases")

    if not ok or type(aliases) ~= "table" then
        return
    end

    local on = mod:get("dauntless_sound") == true

    for alias, event in pairs(DAUNTLESS_SOUNDS) do
        local events = type(aliases[alias]) == "table" and aliases[alias].events

        if events then
            events[TEMPLATE] = on and event or rawget(events, SOURCE_TEMPLATE)
        end
    end
end

-- Template ------------------------------------------------------------------------------------------------------------
local state = { template_ok = false, item_ok = false, notes = {} }
local next_poll = 0

-- every chain entry may be one table or a list of tables
local function each_chain_entry(chains, func)
    for key, entry in pairs(chains) do
        if type(entry) == "table" then
            if entry.action_name then
                func(key, entry, chains)
            else
                for _, sub in ipairs(entry) do
                    if type(sub) == "table" and sub.action_name then
                        func(key, sub, chains)
                    end
                end
            end
        end
    end
end

local function has_hierarchy_input(hierarchy, name)
    for _, node in ipairs(hierarchy) do
        if node.input == name then
            return true
        end
    end

    return false
end

local function build_template()
    local melee = WeaponTemplates[SOURCE_TEMPLATE]
    local pistol = WeaponTemplates[PISTOL_TEMPLATE]

    if not melee or not pistol then
        return false
    end

    local WeaponAmmoTemplates = require("scripts/settings/equipment/weapon_handling_templates/weapon_ammo_templates")
    local WeaponTweakTemplateSettings = require("scripts/settings/equipment/weapon_templates/weapon_tweak_template_settings")

    local clone = table.clone(melee)

    clone.name = TEMPLATE

    -- weapon_templates.lua _require_template: action_settings.name = action_name
    for action_name, action_settings in pairs(clone.actions) do
        action_settings.name = action_name
    end

    -- Inputs: reload comes from the laspistol (laspistol_p1_m1.lua:77-86), hierarchy entry as :163-166
    if not clone.action_inputs.reload then
        clone.action_inputs.reload = table.clone(pistol.action_inputs.reload)
    end

    if not has_hierarchy_input(clone.action_input_hierarchy, "reload") then
        clone.action_input_hierarchy[#clone.action_input_hierarchy + 1] = { input = "reload", transition = "stay" }
    end

    -- Shot and reload actions (laspistol clones)
    local shot = table.clone(pistol.actions.action_shoot_hip)

    shot.name = "action_pistol_shot"
    shot.start_input = "special_action"
    shot.allowed_during_sprint = true
    shot.anim_event = nil
    shot.total_time = 0.5
    -- fire_configuration.anim_event stays "attack_shoot" (laspistol_p1_m1.lua:270): the chainsword_laspistol sets have
    -- it; the chain_sword fallback does not, and the has_animation_event guard skips it there
    shot.allowed_chain_actions = {
        combat_ability = { action_name = "combat_ability" },
        wield = { action_name = "action_unwield" },
        reload = { action_name = "action_reload", chain_time = 0.3 },
        special_action = { action_name = "action_pistol_shot", chain_time = 0.225 },
        start_attack = { action_name = "action_melee_start_left", chain_time = 0.2 },
        block = { action_name = "action_block", chain_time = 0.25 },
    }
    shot.recoil_template = nil
    shot.sway_template = nil

    local reload = table.clone(pistol.actions.action_reload)

    reload.name = "action_reload"
    reload.allowed_chain_actions = {
        combat_ability = { action_name = "combat_ability" },
        wield = { action_name = "action_unwield" },
        special_action = { action_name = "action_pistol_shot", chain_time = 2 },
        start_attack = { action_name = "action_melee_start_left", chain_time = 2 },
        block = { action_name = "action_block", chain_time = 2 },
    }

    -- The Chainsword rev (action_toggle_special) goes; special_action now means shot
    clone.actions.action_toggle_special = nil
    clone.actions.action_pistol_shot = shot
    clone.actions.action_reload = reload

    for _, action in pairs(clone.actions) do
        local chains = action.allowed_chain_actions

        if chains then
            each_chain_entry(chains, function(_, entry)
                if entry.action_name == "action_toggle_special" then
                    entry.action_name = "action_pistol_shot"
                end
            end)

            -- reload is reachable from wherever a shot is, at the same time
            local special = chains.special_action

            if special and not chains.reload and action.name ~= "action_pistol_shot" and action.name ~= "action_reload" then
                chains.reload = { action_name = "action_reload", chain_time = special.chain_time }
            end
        end
    end

    -- 0.7.0 (user: permanent special activation, always revved): the chainsword's weapon special class stays, the
    -- tweak data drops active_duration / num_activations (WeaponSpecial.update_active only deactivates on those) and sets
    -- manual_toggle_only (set_wielded_weapon_weapon_special_active, player_unit_weapon_extension.lua:1198, then ignores
    -- every non-manual deactivation); the fixed_update hook below switches it on while the weapon is wielded.
    -- Option off = the 0.1 behaviour (no rev).
    if mod:get("permanent_rev") ~= false then
        -- 0.9.0 (user: remove the non-visual effects of the activated chainsword): the sweeps lose their *_special_active
        -- overrides (damage profile, damage type, sawing stickiness, abort tags, wounds shape), and the fixed_update hook
        -- writes special_active directly, skipping on_special_activation (warp charge) and the on_weapon_special_activate
        -- proc that set_wielded_weapon_weapon_special_active sends.
        clone.weapon_special_tweak_data = {
            keep_active_on_sprint = true,
            keep_active_on_stun = true,
            keep_active_on_vault = true,
            manual_toggle_only = true,
        }
        state.permanent_rev = true

        for _, action in pairs(clone.actions) do
            if type(action) == "table" then
                for _, key in ipairs({ "damage_profile_special_active", "damage_type_special_active",
                    "force_abort_breed_tags_special_active", "wounds_shape_special_active",
                    "hit_stickyness_settings_special_active" }) do
                    action[key] = nil
                end
            end
        end
    else
        clone.weapon_special_class = nil
        clone.weapon_special_tweak_data = nil

        local keywords = {}

        for _, keyword in ipairs(clone.keywords) do
            if keyword ~= "activated" then
                keywords[#keywords + 1] = keyword
            end
        end

        clone.keywords = keywords
    end

    -- 1.0.0 (user: the push should be a cleaving attack like the thunder hammer / heavy eviscerator): action_push (the
    -- block -> push chain, chainsword_p1_m1.lua:1724) becomes a copy of the horizontal heavy (action_right_heavy,
    -- anim heavy_attack_right) with no sawing stickiness and cleave_distribution = big_cleave
    -- (damage_profile_settings.lua:388), scaled by cleave_mult below; its preparsed lookup entries are replaced with the
    -- heavy's further down.
    state.push_swing = false

    if mod:get("push_cleave") ~= false and clone.actions.action_push and clone.actions.action_right_heavy then
        local DamageProfileSettings = require("scripts/settings/damage/damage_profile_settings")
        local swing = table.clone(clone.actions.action_right_heavy)

        swing.name = "action_push"
        swing.start_input = nil
        swing.hit_stickyness_settings = nil
        swing.hit_stickyness_settings_special_active = nil

        if type(swing.damage_profile) == "table" and DamageProfileSettings.big_cleave then
            swing.damage_profile.cleave_distribution = table.clone(DamageProfileSettings.big_cleave)
        end

        -- keep the push attack (stab) reachable from the swing, as from the old push (chainsword_p1_m1.lua:1906)
        swing.allowed_chain_actions = swing.allowed_chain_actions or {}
        swing.allowed_chain_actions.push_follow_up = { action_name = "action_right_light_pushfollow", chain_time = 0.3 }
        clone.actions.action_push = swing
        state.push_swing = true
    end

    -- 0.9.0 (user: boost its cleave by 3x): every damage profile on the cloned actions (the clone is a deep copy, so the
    -- chainsword's own profiles are untouched) gets its cleave_distribution attack/impact values (number or {min, max},
    -- damage_profile_settings.lua:308) multiplied by cleave_mult.
    local cleave_mult = mod:get("cleave_mult") or 3
    local seen = {}

    local function scale(value)
        if type(value) == "number" then
            return value * cleave_mult
        elseif type(value) == "table" then
            local out = {}

            for k, v in pairs(value) do
                out[k] = type(v) == "number" and v * cleave_mult or v
            end

            return out
        end

        return value
    end

    for _, action in pairs(clone.actions) do
        if type(action) == "table" then
            for key, profile in pairs(action) do
                if type(key) == "string" and key:find("^damage_profile") and type(profile) == "table" and not seen[profile]
                    and type(profile.cleave_distribution) == "table" then
                    seen[profile] = true

                    local cleave = table.clone(profile.cleave_distribution)

                    cleave.attack = scale(cleave.attack)
                    cleave.impact = scale(cleave.impact)
                    profile.cleave_distribution = cleave
                end
            end
        end
    end

    -- Retail chainsword + laspistol animation sets (0.3.0). player_unit_animation_state.lua:112 indexes
    -- PlayerUnitAnimationStateMachineSettings by state machine path (QIangIQsMeltagun 0.2.2 found an unlisted path
    -- crashes on spawn), so the new paths get a copy of the donor's entry.
    state.retail_anims = false

    if mod:get("unreleased_anims") == true then
        local ok1, has1 = pcall(Application.can_get_resource, "package", CHAINLAS_SM_1P)
        local ok3, has3 = pcall(Application.can_get_resource, "package", CHAINLAS_SM_3P)

        if ok1 and has1 and ok3 and has3 then
            local SMSettings = require("scripts/settings/animation/player_unit_animation_state_machine_settings")

            for path, donor in pairs({ [CHAINLAS_SM_1P] = clone.anim_state_machine_1p, [CHAINLAS_SM_3P] = clone.anim_state_machine_3p }) do
                -- raw access: the table comes from settings() (player_unit_animation_state_machine_settings.lua:20)
                if not rawget(SMSettings, path) then
                    rawset(SMSettings, path, table.clone(rawget(SMSettings, donor) or { blend_time = 0 }))
                end
            end

            clone.anim_state_machine_1p = CHAINLAS_SM_1P
            clone.anim_state_machine_3p = CHAINLAS_SM_3P
            state.retail_anims = true
        else
            mod:info("chainsword_laspistol animation packages not found: chainsword animations kept")
        end
    end

    -- Pistol handling (laspistol_p1_m1.lua:881-897,904-907): hit spread, suppression, muzzle node, ammunition HUD
    clone.reload_template = pistol.reload_template
    clone.spread_template = pistol.spread_template
    clone.suppression_template = pistol.suppression_template
    clone.recoil_template = nil
    clone.sway_template = nil
    clone.conditional_state_to_action_input = table.clone(pistol.conditional_state_to_action_input)
    clone.no_ammo_delay = pistol.no_ammo_delay
    clone.hud_configuration = { uses_ammunition = true, uses_overheat = false }
    clone.fx_sources = table.clone(clone.fx_sources)
    clone.fx_sources._muzzle = pistol.fx_sources._muzzle
    clone.fx_sources._mag_well = pistol.fx_sources._mag_well

    -- Tweak lookups. Weapon templates are preparsed (weapon_tweak_templates.lua _preparse_templates): every
    -- "<type>_template" field is renamed ("base_<name>" on the template, "<action>_<name>" on an action) and
    -- __base_template_lookup[type][key] = { new_identifier = renamed, base_identifier = real name } is what
    -- WeaponTweakTemplates.create (_build_templates) resolves. The pistol's renamed names copied above only work if the
    -- matching lookup entries come along: base spread/suppression/ammo, and every per-action entry of the two borrowed
    -- actions under their new action names. Damage/explosion lookups need an (empty) entry per action
    -- (_preparse_damage_templates). 0.1.1 crashed in _resolve_template (pairs on nil) without this.
    local template_types = WeaponTweakTemplateSettings.template_types
    local clone_lookup = rawget(clone, "__base_template_lookup")
    local pistol_lookup = rawget(pistol, "__base_template_lookup")
    local BORROWED = { action_shoot_hip = "action_pistol_shot", action_reload = "action_reload" }
    local BASE_TYPES = { [template_types.spread] = true, [template_types.suppression] = true, [template_types.ammo] = true }
    local SKIP_TYPES = { [template_types.recoil] = true, [template_types.sway] = true }

    if not (clone_lookup and pistol_lookup) then
        error("no __base_template_lookup on the chainsword or laspistol template")
    end

    for _, template_type in pairs(template_types) do
        local from = pistol_lookup[template_type]

        if from and not SKIP_TYPES[template_type] then
            local to = clone_lookup[template_type] or {}

            clone_lookup[template_type] = to

            if BASE_TYPES[template_type] and from.base then
                to.base = table.clone(from.base)
            end

            for source_name, target_name in pairs(BORROWED) do
                if from[source_name] then
                    to[target_name] = table.clone(from[source_name])
                end

                if from[source_name .. "_special"] then
                    to[target_name .. "_special"] = table.clone(from[source_name .. "_special"])
                end
            end
        end
    end

    for _, template_type in ipairs({ template_types.damage, template_types.explosion }) do
        local to = clone_lookup[template_type]

        if to then
            to.action_pistol_shot = to.action_pistol_shot or {}
            to.action_reload = to.action_reload or {}
            to.action_toggle_special = nil
        end
    end

    -- 1.1.0 (user: cannot attack after the push attack): the input hierarchy keeps the block -> push branch
    -- (default_melee_action_input_setup.lua:209), which only offers push_follow_up / push_follow_up_early_release /
    -- special_action, so start_attack stayed locked until both buttons were released. The push branch now also takes
    -- start_attack (a copy of the top-level start_attack node) and block.
    if state.push_swing then
        local hierarchy = clone.action_input_hierarchy
        local start_node

        for _, node in ipairs(hierarchy or {}) do
            if node.input == "start_attack" then
                start_node = node
            end
        end

        for _, node in ipairs(hierarchy or {}) do
            if node.input == "block" and type(node.transition) == "table" then
                for _, child in ipairs(node.transition) do
                    if child.input == "push" and type(child.transition) == "table" then
                        local has = {}

                        for _, entry in ipairs(child.transition) do
                            has[entry.input] = true
                        end

                        if start_node and not has.start_attack then
                            child.transition[#child.transition + 1] = table.clone(start_node)
                        end

                        if not has.block then
                            child.transition[#child.transition + 1] = { input = "block", transition = "base" }
                        end
                    end
                end
            end
        end
    end

    if state.push_swing then
        for template_type, entries in pairs(clone_lookup) do
            if type(entries) == "table" then
                local heavy = entries.action_right_heavy

                entries.action_push = heavy and table.clone(heavy) or
                    ((template_type == template_types.damage or template_type == template_types.explosion) and {} or nil)
            end
        end
    end

    clone.ammo_template = pistol.ammo_template                     -- "base_laspistol_p1_m1", resolved via the lookup

    local ammo_base = clone_lookup[template_types.ammo] and clone_lookup[template_types.ammo].base

    if not (ammo_base and WeaponAmmoTemplates[ammo_base.base_identifier]) then
        mod:error("laspistol ammo lookup not found (%s)", tostring(ammo_base and ammo_base.base_identifier))
    end

    WeaponTemplates[TEMPLATE] = clone
    state.template_ours = true

    local ok, index = append_lookup("weapon_templates", TEMPLATE)

    state.template_id = ok and index or nil
    state.aliases = copy_aliases(SOURCE_TEMPLATE, TEMPLATE) + copy_aliases(PISTOL_TEMPLATE, TEMPLATE)
    register_dauntless_sounds()
    apply_dauntless_sound()
    state.template_ok = ok

    return ok
end

local function ensure_template()
    if rawget(WeaponTemplates, TEMPLATE) then
        state.template_ok = true

        return true
    end

    return build_template()
end

-- Items ---------------------------------------------------------------------------------------------------------------
local function find_item(cache, preferred, template)
    local direct = rawget(cache, preferred)

    if direct and direct.weapon_template == template then
        return preferred, direct
    end

    for name, item in pairs(cache) do
        if type(item) == "table" and item.weapon_template == template then
            return name, item
        end
    end
end

local function build_item(cache)
    local source_name, source_item = find_item(cache, SOURCE_ITEM, SOURCE_TEMPLATE)
    local pistol_name, pistol_item = find_item(cache, PISTOL_ITEM, PISTOL_TEMPLATE)

    if not source_item then
        return false, "no " .. SOURCE_TEMPLATE .. " item"
    end

    if not pistol_item then
        return false, "no " .. PISTOL_TEMPLATE .. " item"
    end

    -- Off-hand Laspistol: a clone so the original's data is untouched; its own attachment tree (receiver, barrel...) is kept
    local offhand = table.clone(pistol_item)

    offhand.name = OFFHAND_ITEM
    cache[OFFHAND_ITEM] = offhand

    -- 1.1.0 (user: two magazines, one half inside the other): the laspistol item carries a second magazine for the
    -- reload hand (logged in game: lasgun_pistol_magazine_01 at the mag well and lasgun_pistol_magazine_02 at the origin),
    -- which the reload animation normally moves; the off-hand pistol has no reload animation, so both showed. Of the
    -- attachment slots whose name contains "magazine", only the shortest-named one ("magazine") is kept.
    local slot_names = {}
    local magazines = {}

    local function walk(attachments, depth)
        if type(attachments) ~= "table" or depth > 8 then
            return
        end

        for name, node in pairs(attachments) do
            slot_names[#slot_names + 1] = tostring(name)

            if type(name) == "string" and name:find("magazine") then
                magazines[#magazines + 1] = { parent = attachments, name = name }
            end

            if type(node) == "table" then
                walk(node.children, depth + 1)
            end
        end
    end

    walk(offhand.attachments, 0)

    if #magazines > 1 then
        table.sort(magazines, function(a, b)
            return #a.name < #b.name or (#a.name == #b.name and a.name < b.name)
        end)

        for i = 2, #magazines do
            magazines[i].parent[magazines[i].name] = nil
        end
    end

    mod:info("off-hand laspistol attachment slots: %s", table.concat(slot_names, ", "))

    local item = table.clone(source_item)

    item.name = ITEM
    item.weapon_template = TEMPLATE
    item.archetypes = { "zealot" }
    item.display_name = "loc_qiangiq_chainlaspistol"

    for _, field in ipairs({ "weapon_family_display_name", "weapon_pattern_display_name", "weapon_mark_display_name" }) do
        if type(item[field]) == "table" then
            item[field].loc_id = "loc_qiangiq_chainlaspistol"
        end
    end

    if type(item.attachments) ~= "table" then
        return false, "source item has no attachments"
    end

    -- hang the Laspistol under the first top-level attachment (top-level slot names are sorted by priority, children's are not)
    -- the host must spawn a unit: _attach_hierarchy returns before the children when its item is "" (0.1.2 picked
    -- zzz_shared_material_overrides through next(), so the pistol would never spawn). The chainsword tree has "grip".
    local host_name, host = "grip", item.attachments.grip

    if not (host and type(host.item) == "string" and host.item ~= "") then
        host_name, host = nil, nil

        for name, node in pairs(item.attachments) do
            if type(node) == "table" and type(node.item) == "string" and node.item ~= "" then
                host_name, host = name, node

                break
            end
        end
    end

    if not host then
        return false, "source item has an empty attachment tree"
    end

    host.children = host.children or {}
    host.children[OFFHAND_SLOT] = { item = OFFHAND_ITEM, children = {} }

    -- dependencies: the Chainsword's, the Laspistol's, and what the offline item compile adds for the template
    -- (item_package.lua:239-249; QIangIQsDauntlessArmory found a missing state machine crashes otherwise)
    local deps = item.resource_dependencies or {}

    for resource in pairs(pistol_item.resource_dependencies or {}) do
        deps[resource] = true
    end

    local WeaponTemplateResourceDependencies = require("scripts/utilities/weapon_template_resource_dependencies")

    for _, resource in ipairs(WeaponTemplateResourceDependencies.generate(TEMPLATE)) do
        deps[resource] = true
    end

    item.resource_dependencies = deps

    local ok, index = append_lookup("player_item_names", ITEM)

    if not ok then
        return false, "player_item_names lookup missing"
    end

    cache[ITEM] = item
    state.item_id = index
    state.slot = item.slots and item.slots[1]
    state.notes = { string.format("%s + %s (under %s)", tostring(source_name), tostring(pistol_name), tostring(host_name)) }

    return true
end

local function ensure_item()
    local ok, has_data = pcall(MasterItems.has_data)

    if not ok or not has_data then
        return false
    end

    local cache = MasterItems.get_cached()

    if rawget(cache, ITEM) then
        state.item_ok = true

        return true
    end

    local built, err = build_item(cache)

    if err and err ~= state.last_error then
        state.last_error = err
        mod:error("%s", err)
    end

    state.item_ok = built and rawget(cache, ITEM) ~= nil

    return state.item_ok
end

local function poll()
    if next_poll > os.clock() then
        return
    end

    next_poll = os.clock() + 1

    local before_t, before_i = state.template_ok, state.item_ok
    local ok_t, err_t = pcall(ensure_template)
    local ok_i, err_i = true, nil

    if state.template_ok then
        ok_i, err_i = pcall(ensure_item)
    end

    if not ok_t then
        mod:error("template: %s", tostring(err_t))
    end

    if not ok_i then
        mod:error("item: %s", tostring(err_i))
    end

    if state.template_ok and not before_t then
        mod:info("template %s registered (clone of %s + %s), %s alias entries", TEMPLATE, SOURCE_TEMPLATE, PISTOL_TEMPLATE,
            tostring(state.aliases))
    end

    if state.item_ok and not before_i then
        mod:info("item %s injected (slot %s): %s", ITEM, tostring(state.slot), table.concat(state.notes or {}, "; "))
    end
end

-- Anim event guard: the pistol reload events are not in the chain_sword state machine ---------------------------------
-- Two classes play player anim events: PlayerUnitAnimationExtension (clients, sets self._local_wielded_weapon_template)
-- and AuthoritativePlayerUnitAnimationExtension (whoever hosts: Psykhanium, SoloPlay; it keeps no template field).
-- 0.1.3 guarded only the first, so the host crashed in authoritative_player_unit_animation_extension.lua
-- ("state machine ... does not have an event"). Both inventory_slot_wielded(self, weapon_template) are hooked to note
-- the wielded template, and every anim_event* of both classes is guarded (player_character_state_ledge_vaulting.lua:109
-- uses Unit.has_animation_event the same way).
local skipped_events = {}

local function wielded_ours(self)
    return self.__qiangiq_chainlas_template == TEMPLATE or rawget(self, "_local_wielded_weapon_template") == TEMPLATE
end

local function guard(unit_field)
    return function(func, self, event_name, ...)
        if wielded_ours(self) then
            local unit = self[unit_field]

            if unit and not Unit.has_animation_event(unit, event_name) then
                if not skipped_events[event_name] then
                    skipped_events[event_name] = true
                    mod:info("skipped anim event %s (%s): not in the chain_sword state machine", tostring(event_name),
                        unit_field == "_first_person_unit" and "1p" or "3p")
                end

                return
            end
        end

        return func(self, event_name, ...)
    end
end

for _, class_name in ipairs({ "PlayerUnitAnimationExtension", "AuthoritativePlayerUnitAnimationExtension" }) do
    mod:hook_safe(class_name, "inventory_slot_wielded", function(self, weapon_template)
        self.__qiangiq_chainlas_template = weapon_template and weapon_template.name
    end)

    for _, method in ipairs({ "anim_event", "anim_event_with_variable_float", "anim_event_with_variable_floats",
        "anim_event_with_variable_int" }) do
        mod:hook(class_name, method, guard("_unit"))
    end

    for _, method in ipairs({ "anim_event_1p", "anim_event_with_variable_float_1p", "anim_event_with_variable_floats_1p" }) do
        mod:hook(class_name, method, guard("_first_person_unit"))
    end
end

-- Off-hand Laspistol: re-link the rig to the character's left weapon node --------------------------------------------
local linked = {}              -- laspistol rig unit -> parent it was linked to

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function offhand_rig(names)
    if names then
        for unit, item_name in pairs(names) do
            if item_name == OFFHAND_ITEM and unit_ok(unit) then
                return unit
            end
        end
    end
end

-- Block brace: the chain_sword parry_pose animation brings the left hand up to the blade. No forearm/brace animation
-- exists, so while action_block runs the pistol blends to a second pose (block sliders) meant to put its trigger guard
-- against the blade; the blend is 0.12 s each way.
local BLEND_TIME = 0.12
local block_blend = {}          -- view -> 0..1

local function pose_values(view, prefix)
    return mod:get(prefix .. view .. "_x") or 0, mod:get(prefix .. view .. "_y") or 0, mod:get(prefix .. view .. "_z") or 0,
        mod:get(prefix .. view .. "_pitch") or 0, mod:get(prefix .. view .. "_yaw") or 0, mod:get(prefix .. view .. "_roll") or 0
end

local function blocking(ext)
    local ok, weapon_action = pcall(function()
        local ude = ScriptUnit.has_extension(ext._unit, "unit_data_system")

        return ude and ude:read_component("weapon_action")
    end)

    return ok and weapon_action and weapon_action.template_name == TEMPLATE and weapon_action.current_action_name == "action_block"
end

local function offhand_pose(unit, view, is_blocking, dt)
    local b = block_blend[view] or 0

    b = math.clamp(b + (is_blocking and 1 or -1) * (dt or 0) / BLEND_TIME, 0, 1)
    block_blend[view] = b

    local x0, y0, z0, p0, w0, r0 = pose_values(view, "oh_")
    local x1, y1, z1, p1, w1, r1 = pose_values(view, "block_")
    local x, y, z = math.lerp(x0, x1, b), math.lerp(y0, y1, b), math.lerp(z0, z1, b)
    local pitch, yaw, roll = math.rad(math.lerp(p0, p1, b)), math.rad(math.lerp(w0, w1, b)), math.rad(math.lerp(r0, r1, b))

    Unit.set_local_position(unit, 1, Vector3(x, y, z))
    Unit.set_local_rotation(unit, 1, Quaternion.from_yaw_pitch_roll(yaw, pitch, roll))
end

-- 0.4.0 (user: the pistol must be visible in first person): the chainsword idle keeps the left hand below the view, so in
-- first person the pistol hangs at a fixed point in camera space (lower left, pointing forward; the /chainlas front test
-- showed identity rotation points it forward) plus the 1P sliders, and the left arm is posed onto it with the driver.
local HOLD_BASE = { x = -0.2, y = 0.42, z = -0.2 }

local function hold_on()
    return mod:get("pistol_hold_1p") ~= false
end

local function hold_rotation()
    return Quaternion.from_yaw_pitch_roll(math.rad(mod:get("oh_1p_yaw") or 0), math.rad(mod:get("oh_1p_pitch") or 0),
        math.rad(mod:get("oh_1p_roll") or 0))
end

local function hold_offset()
    return Vector3(HOLD_BASE.x + (mod:get("oh_1p_x") or 0), HOLD_BASE.y + (mod:get("oh_1p_y") or 0),
        HOLD_BASE.z + (mod:get("oh_1p_z") or 0))
end

-- 0.3.3 test (/chainlas front): the 1P pistol hangs 0.4 m in front of the camera node instead of the left hand, to tell
-- "not rendered" from "rendered out of view"
local front_test = false

local function sync_offhand(ext, slot, first_person, parent_override)
    local names = first_person and slot.item_name_by_unit_1p or slot.item_name_by_unit_3p
    local rig = offhand_rig(names)

    if not rig then
        return
    end

    if first_person and front_test then
        local fp = ext._first_person_unit
        local world = ext.__qiangiq_chainlas_world

        if world and unit_ok(fp) and Unit.has_node(fp, "ap_camera_node") then
            if linked[rig] ~= "front" then
                World.unlink_unit(world, rig)
                World.link_unit(world, rig, 1, fp, Unit.node(fp, "ap_camera_node"), World.LINK_MODE_NONE)
                linked[rig] = "front"
            end

            Unit.set_local_position(rig, 1, Vector3(-0.12, 0.4, -0.1))
            Unit.set_local_rotation(rig, 1, Quaternion.identity())
            Unit.set_unit_visibility(rig, true, true)
        end

        return
    end

    local world = ext.__qiangiq_chainlas_world

    local pistol_p, pistol_r

    if parent_override then
        -- (0.7.0 bug: "x and f()" keeps only f's first return, so pistol_r was nil)
        pistol_p, pistol_r = Brace.pistol_pose(ext)
    end

    if first_person and hold_on() and pistol_p then
        -- 0.7.0: the pistol frame the driver's hand was solved onto (Brace apply_hold), relative to the driver root
        if world and linked[rig] ~= parent_override then
            World.unlink_unit(world, rig)
            World.link_unit(world, rig, 1, parent_override, 1, World.LINK_MODE_NONE)
            linked[rig] = parent_override
        end

        Unit.set_local_position(rig, 1, pistol_p)
        Unit.set_local_rotation(rig, 1, pistol_r)
        Unit.set_unit_visibility(rig, slot.hidden_1p == false, true)

        return
    end

    if first_person and hold_on() then
        local fp = ext._first_person_unit

        if not (world and unit_ok(fp) and Unit.has_node(fp, "ap_camera_node")) then
            return
        end

        if linked[rig] ~= "hold" then
            World.unlink_unit(world, rig)
            World.link_unit(world, rig, 1, fp, Unit.node(fp, "ap_camera_node"), World.LINK_MODE_NONE)
            linked[rig] = "hold"
        end

        local o = hold_offset()

        Unit.set_local_position(rig, 1, o)
        Unit.set_local_rotation(rig, 1, Quaternion.from_yaw_pitch_roll(math.rad(mod:get("oh_1p_yaw") or 0),
            math.rad(mod:get("oh_1p_pitch") or 0), math.rad(mod:get("oh_1p_roll") or 0)))
        Unit.set_unit_visibility(rig, slot.hidden_1p == false, true)

        return
    end

    local parent = parent_override or (first_person and ext._first_person_unit or ext._unit)

    if not (world and unit_ok(parent) and Unit.has_node(parent, LEFT_NODE)) then
        return
    end

    if linked[rig] ~= parent then
        World.unlink_unit(world, rig)
        World.link_unit(world, rig, 1, parent, Unit.node(parent, LEFT_NODE), World.LINK_MODE_NONE)
        linked[rig] = parent
    end

    offhand_pose(rig, first_person and "1p" or "3p", blocking(ext), ext.__qiangiq_chainlas_dt)

    local hidden = first_person and slot.hidden_1p or slot.hidden_3p

    Unit.set_unit_visibility(rig, hidden == false, true)
end

-- 0.3.1 (user: the chainsword_laspistol animations hold the sword in an icepick/reverse grip): the sword's root unit
-- gets a rotation about its attach node, default pitch 180 so the blade points up. Only with the retail animations.
-- 0.7.0 (user: in the block the teeth should face forward, not up): while blocking, the first-person sword also turns
-- about its own blade axis (attach node -> fx_sweep node, measured in the sword's frame) by teeth_block degrees,
-- blended like the brace; teeth_idle does the same outside the block.
local rest_rotation = setmetatable({}, { __mode = "k" })   -- sword unit -> QuaternionBox (local rotation as spawned)
local rest_position = setmetatable({}, { __mode = "k" })  -- sword unit -> Vector3Box (local position as spawned)
local blade_axis = setmetatable({}, { __mode = "k" })      -- sword unit -> Vector3Box (blade direction, unit frame)
local teeth_blend = 0

local function sword_axis(slot, unit)
    local box = blade_axis[unit]

    if box then
        return box:unbox()
    end

    for part in pairs(slot.item_name_by_unit_1p or {}) do
        if unit_ok(part) and Unit.has_node(part, "fx_sweep") then
            local sweep = Unit.world_position(part, Unit.node(part, "fx_sweep"))
            local dir = Quaternion.rotate(Quaternion.inverse(Unit.world_rotation(unit, 1)), sweep - Unit.world_position(unit, 1))

            if Vector3.length(dir) > 1e-3 then
                dir = Vector3.normalize(dir)
                blade_axis[unit] = Vector3Box(dir)

                return dir
            end
        end
    end
end

local function grip_correction(slot, ext)
    for view, unit in pairs({ ["1p"] = slot.unit_1p, ["3p"] = slot.unit_3p }) do
        if unit_ok(unit) then
            local base

            if state.retail_anims then
                local pitch = math.rad(mod:get("sword_" .. view .. "_pitch") or 180)
                local yaw = math.rad(mod:get("sword_" .. view .. "_yaw") or 0)
                local roll = math.rad(mod:get("sword_" .. view .. "_roll") or 0)

                base = Quaternion.from_yaw_pitch_roll(yaw, pitch, roll)
            else
                rest_rotation[unit] = rest_rotation[unit] or QuaternionBox(Unit.local_rotation(unit, 1))
                base = rest_rotation[unit]:unbox()
            end

            if view == "1p" then
                local dt = ext.__qiangiq_chainlas_dt or 0

                teeth_blend = math.clamp(teeth_blend + (blocking(ext) and 1 or -1) * dt / BLEND_TIME, 0, 1)

                local w = teeth_blend * teeth_blend * (3 - 2 * teeth_blend)
                local angle = math.lerp(mod:get("teeth_idle") or 0, mod:get("teeth_block") or 90, w)
                local axis = angle ~= 0 and sword_axis(slot, unit)

                if axis then
                    base = Quaternion.multiply(base, Quaternion.axis_angle(axis, math.rad(angle)))
                end
            end

            if view == "1p" then
                -- 1.2.0: follow the driver's block_forward shift (world offset -> the sword's parent space)
                rest_position[unit] = rest_position[unit] or Vector3Box(Unit.local_position(unit, 1))

                local shift = Brace.shift_world(ext)
                local local_p = rest_position[unit]:unbox()

                if shift then
                    local parent_r = Quaternion.multiply(Unit.world_rotation(unit, 1),
                        Quaternion.inverse(Unit.local_rotation(unit, 1)))

                    local_p = local_p + Quaternion.rotate(Quaternion.inverse(parent_r), shift)
                end

                Unit.set_local_position(unit, 1, local_p)
            end

            if state.retail_anims or view == "1p" then
                Unit.set_local_rotation(unit, 1, base)
            end
        end
    end
end

-- 0.8.0 (user: the hand grips the handguard, not the pistol grip): the pistol origin is not at its grip, so the grip
-- point is measured: the attachment unit whose item name contains "grip", nearest the rig root (the sword's own grip
-- is far away in the right hand), in the rig's frame. Fallback 8 cm back from the origin.
local GRIP_FALLBACK = Vector3Box(0, -0.08, 0)
local grip_cache = setmetatable({}, { __mode = "k" })   -- rig -> { point, name, muzzle }

-- 0.9.0: the grip in 0.8.0 did not move in game, so a "grip" part within 3 cm of the origin is ignored (no offset), and
-- the muzzle point (fx_muzzle_01 on any part near the rig) is measured too: it places the brace contact, and when no
-- grip part is found the grip falls back to 18 cm behind the muzzle.
local function pistol_points(slot, rig)
    local cached = grip_cache[rig]

    if cached then
        return cached.point:unbox(), cached.muzzle and cached.muzzle:unbox(), cached.name
    end

    local inv_r, root_p = Quaternion.inverse(Unit.world_rotation(rig, 1)), Unit.world_position(rig, 1)
    local best, best_d, best_name, muzzle

    for unit, item_name in pairs(slot.item_name_by_unit_1p or {}) do
        if unit_ok(unit) and Vector3.length(Unit.world_position(unit, 1) - root_p) < 0.4 then
            if Unit.has_node(unit, "fx_muzzle_01") then
                muzzle = Quaternion.rotate(inv_r, Unit.world_position(unit, Unit.node(unit, "fx_muzzle_01")) - root_p)
            end

            if unit ~= rig and type(item_name) == "string" and item_name:find("grip") then
                local rel = Quaternion.rotate(inv_r, Unit.world_position(unit, 1) - root_p)
                local d = Vector3.length(rel)

                if d > 0.03 and d < 0.3 and (not best_d or d < best_d) then
                    best, best_d, best_name = rel, d, item_name
                end
            end
        end
    end

    if not best then
        best = muzzle and muzzle - Vector3(0, 0.18, 0) or GRIP_FALLBACK:unbox()
        best_name = muzzle and "18 cm behind the muzzle" or "fallback"
    end

    grip_cache[rig] = { point = Vector3Box(best), muzzle = muzzle and Vector3Box(muzzle), name = best_name }

    local parts = {}

    for unit, item_name in pairs(slot.item_name_by_unit_1p or {}) do
        if unit_ok(unit) and Vector3.length(Unit.world_position(unit, 1) - root_p) < 0.4 then
            local rel = Quaternion.rotate(inv_r, Unit.world_position(unit, 1) - root_p)

            parts[#parts + 1] = string.format("%s @ %.3f %.3f %.3f", tostring(item_name), rel.x, rel.y, rel.z)
        end
    end

    mod:info("pistol points: grip %.3f %.3f %.3f (%s), muzzle %s; parts: %s", best.x, best.y, best.z, tostring(best_name),
        muzzle and string.format("%.3f %.3f %.3f", muzzle.x, muzzle.y, muzzle.z) or "none", table.concat(parts, " | "))

    return best, muzzle, best_name
end

local function pistol_grip(slot, rig)
    local point, _, name = pistol_points(slot, rig)

    return point, name
end

local function apply_offhand(ext)
    if not ext._is_local_unit or not ext._equipment then
        return
    end

    local ours

    for _, slot in pairs(ext._equipment) do
        local item = slot.item

        if item and item.name == ITEM then
            ours = slot
        end
    end

    local rig_1p = ours and offhand_rig(ours.item_name_by_unit_1p)
    local grip_point, muzzle_point

    if rig_1p then
        grip_point, muzzle_point = pistol_points(ours, rig_1p)
    end

    local ok, driver = pcall(Brace.update, ext, ours, ours ~= nil and blocking(ext), ext.__qiangiq_chainlas_dt,
        ours ~= nil and hold_on() and hold_offset() or nil, hold_rotation(), grip_point or GRIP_FALLBACK:unbox(), muzzle_point)

    if not ok then
        mod:error("brace update: %s", tostring(driver))
        driver = nil
        pcall(Brace.stop, ext)
    end

    if ours then
        sync_offhand(ext, ours, false)
        sync_offhand(ext, ours, true, driver)
        grip_correction(ours, ext)
    end

    for rig in pairs(linked) do
        if not unit_ok(rig) then
            linked[rig] = nil
        end
    end
end

-- permanent rev: switch the special on whenever our weapon is wielded and it is off
mod:hook_safe(CLASS.PlayerUnitWeaponExtension, "fixed_update", function(self, unit, dt, t)
    if not state.permanent_rev then
        return
    end

    local inventory_component = self._inventory_component
    local weapons = self._weapons
    local weapon = inventory_component and weapons and weapons[inventory_component.wielded_slot]

    if weapon and weapon.weapon_template and weapon.weapon_template.name == TEMPLATE and weapon.inventory_slot_component
        and not weapon.inventory_slot_component.special_active then
        -- direct write: the rev visuals read special_active; no activation proc / warp charge (0.9.0)
        weapon.inventory_slot_component.special_active = true
        weapon.inventory_slot_component.special_active_start_t = t
    end
end)

local tracked = {}

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "init", function(self, extension_init_context)
    self.__qiangiq_chainlas_world = extension_init_context and extension_init_context.world
end)

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "_update_item_visibility", function(self)
    if self._is_local_unit then
        tracked[self] = true
        apply_offhand(self)
    end
end)

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "update", function(self, unit, dt)
    if tracked[self] then
        self.__qiangiq_chainlas_dt = dt
        apply_offhand(self)
    end
end)

mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, "destroy", function(func, self, ...)
    pcall(Brace.stop, self)
    tracked[self] = nil

    return func(self, ...)
end)

mod.update = function()
    poll()
end

-- Zealot unlock list (weapon_unlock_settings.lua; realms_loadout builds its weapon list from it) ----------------------
local function add_to_unlock_list()
    if not mod:get("add_to_unlock_list") then
        return
    end

    local ok, unlocks = pcall(require, "scripts/settings/weapon_unlock/weapon_unlock_settings")
    local zealot = ok and unlocks and unlocks.zealot

    if not zealot then
        mod:error("WeaponUnlockSettings.zealot not found")

        return
    end

    local level = math.floor(mod:get("unlock_level") or 1)

    zealot[level] = zealot[level] or {}

    if not table.find(zealot[level], ITEM) then
        table.insert(zealot[level], ITEM)
    end
end

local function acquire_driver()
    local custom_assets = get_mod("CustomAssets")

    if not custom_assets or not custom_assets.is_api_compatible or not custom_assets.is_api_compatible(1) then
        mod:info("Custom Assets (API 1) not installed: block uses the slider pose, no arm brace")

        return
    end

    for i, d in ipairs(DRIVERS) do
        local ticket = custom_assets.acquire(mod, d.id, function(_, _, load_error)
            if load_error then
                mod:info("brace driver %s not loaded: %s", d.id, tostring(load_error))

                return
            end

            driver_loaded[i] = true
            mod:info("brace driver %s loaded", d.id)
        end, { resident = true, reference_name = d.id })

        if not ticket then
            mod:info("brace driver %s could not be requested (mod not installed?)", d.id)
        end
    end
end

mod.on_all_mods_loaded = function()
    add_to_unlock_list()
    acquire_driver()
end

mod.on_setting_changed = function(setting_id)
    if setting_id == "dauntless_sound" and state.template_ok then
        apply_dauntless_sound()
    end
end

mod.on_unload = function()
    local ok, cache = pcall(MasterItems.get_cached)

    if ok and cache then
        cache[ITEM] = nil
        cache[OFFHAND_ITEM] = nil
    end

    if state.template_ours then
        WeaponTemplates[TEMPLATE] = nil
    end
end

-- Equip without the backend (QIangIQsDauntlessArmory override): only where this client hosts --------------------------
local function local_player()
    local players = Managers.player

    return players and players:local_player_safe(1)
end

local function equipped_item_name(player, slot)
    local unit = player and player.player_unit

    if not unit or not Unit.alive(unit) then
        return nil
    end

    local extension = ScriptUnit.has_extension(unit, "visual_loadout_system")
    local item = extension and extension:item_from_slot(slot)

    return item and item.name
end

local previous = {}

local function override(slot, item_name)
    local player = local_player()
    local sync = Managers.profile_synchronization
    local host = sync and sync:synchronizer_host()

    if not player then
        say("no local player")

        return false
    end

    if not host then
        say("not the host here. Use the Psykhanium, a SoloPlay game or a game you host")

        return false
    end

    host:override_slot(player:peer_id(), player:local_player_id(), slot, item_name)
    say("override_slot(%s, %s) sent", slot, tostring(item_name))

    return true
end

local function debug_offhand()
    local player = local_player()
    local unit = player and player.player_unit
    local ext = unit and ScriptUnit.has_extension(unit, "visual_loadout_system")

    if not (ext and ext._equipment) then
        say("no player unit")

        return
    end

    say("retail animations %s; 1p state machine %s", tostring(state.retail_anims),
        tostring(WeaponTemplates[TEMPLATE] and WeaponTemplates[TEMPLATE].anim_state_machine_1p))
    say("1p unit has %s: %s, 3p unit has %s: %s", LEFT_NODE,
        tostring(unit_ok(ext._first_person_unit) and Unit.has_node(ext._first_person_unit, LEFT_NODE)), LEFT_NODE,
        tostring(unit_ok(ext._unit) and Unit.has_node(ext._unit, LEFT_NODE)))

    for slot_name, slot in pairs(ext._equipment) do
        if slot.item and slot.item.name == ITEM then
            local rig1, rig3 = offhand_rig(slot.item_name_by_unit_1p), offhand_rig(slot.item_name_by_unit_3p)

            say("%s: pistol rig 1p %s (linked %s), 3p %s (linked %s)", slot_name, tostring(rig1 ~= nil),
                tostring(rig1 and linked[rig1] ~= nil), tostring(rig3 ~= nil), tostring(rig3 and linked[rig3] ~= nil))

            if rig1 then
                say("  1p pistol has fx_muzzle_01 (rig): %s, visible %s", tostring(Unit.has_node(rig1, "fx_muzzle_01")),
                    tostring(Unit.is_visible ~= nil and Unit.is_visible(rig1)))

                local pos = Unit.world_position(rig1, 1)
                local fp = ext._first_person_unit

                if unit_ok(fp) and Unit.has_node(fp, "ap_camera_node") then
                    local cam = Unit.world_pose(fp, Unit.node(fp, "ap_camera_node"))
                    local rel = Matrix4x4.transform(Matrix4x4.inverse(cam), pos)

                    say("  1p pistol relative to camera: right %.2f, forward %.2f, up %.2f (m); linked to %s", rel.x, rel.y,
                        rel.z, tostring(linked[rig1]))
                else
                    say("  1p pistol at %s", tostring(pos))
                end
            end

            if rig1 then
                local point, muzzle, name = pistol_points(slot, rig1)

                say("  pistol grip point (pistol axes) %.3f %.3f %.3f from %s; muzzle %s", point.x, point.y, point.z,
                    tostring(name), muzzle and string.format("%.3f %.3f %.3f", muzzle.x, muzzle.y, muzzle.z) or "not found")

                for part, item_name in pairs(slot.item_name_by_unit_1p or {}) do
                    if unit_ok(part) and Vector3.length(Unit.world_position(part, 1) - Unit.world_position(rig1, 1)) < 0.3 then
                        say("  near pistol: %s", tostring(item_name))
                    end
                end
            end

            say("  %s", Brace.debug(ext))
        end
    end
end

mod:command("chainlas", mod:localize("command_chainlas"), function(action)
    action = action or "status"

    if action == "status" then
        say("template %s (id %s), item %s (id %s, slot %s)", tostring(state.template_ok), tostring(state.template_id),
            tostring(state.item_ok), tostring(state.item_id), tostring(state.slot))
    elseif action == "equip" then
        if not (state.template_ok and state.item_ok and state.slot) then
            say("not ready yet (template %s, item %s)", tostring(state.template_ok), tostring(state.item_ok))

            return
        end

        local player = local_player()

        previous[state.slot] = previous[state.slot] or (player and equipped_item_name(player, state.slot))
        override(state.slot, ITEM)
    elseif action == "restore" then
        local any = false

        for slot, item_name in pairs(previous) do
            if item_name and override(slot, item_name) then
                previous[slot] = nil
                any = true
            end
        end

        if not any then
            say("nothing to restore (equip first)")
        end
    elseif action == "debug" then
        debug_offhand()
    elseif action == "front" then
        front_test = not front_test
        table.clear(linked)
        say("1p pistol in front of the camera: %s", tostring(front_test))
    else
        say("usage: /chainlas [status|equip|restore|debug|front]")
    end
end)
