-- QIangIQ's Chainsword & Laspistol 0.2.0: a dual-wield Zealot weapon (Chainsword right hand, Laspistol left hand).
--
-- Nothing is invented: every piece is an existing retail asset or template, listed here with its source.
--   * Swings: chainsword_p1_m1 (weapon_templates/chain_swords/chainsword_p1_m1.lua), cloned whole, so the light/heavy
--     chain, damage, animation state machines (power_sword 3p, chain_sword 1p), sweeps and sounds are the Chainsword's.
--   * Shot: laspistol_p1_m1 action_shoot_hip (laspistol_p1_m1.lua:225-312) cloned as action_pistol_shot, started by the
--     melee "special_action" input (the Chainsword's own special action, action_toggle_special, is replaced; the rev has
--     no use here). Every swing already chains to special_action, so a shot cancels a recovery; the shot chains back
--     into start_attack. The laspistol's hit scan template / damage type are baked into the clone. No recoil.
--   * Reload: laspistol_p1_m1 action_reload (:478), reload template ReloadTemplates.laspistol, ammo template
--     laspistol_p1_m1, conditional_state_to_action_input (:887-896) for the empty-clip auto reload. The chain_sword
--     state machine lacks the pistol reload anim events: Unit.has_animation_event guards them (as QIangIQsDauntlessArmory).
--   * Model: the Laspistol master item is cloned and added as a child attachment of the Chainsword item, so the game
--     spawns, loads (item_package.lua dependency recursion) and cleans it up with the Chainsword. Its rig is then
--     re-linked from the Chainsword to the character's left weapon node "j_leftweaponattach"
--     (player_unit_data_component_config.lua:590, ui_weapon_spawner.lua:339) with LINK_MODE_NONE, the way the
--     QIangIQsDauntlessArmory clip is moved; the fx_sources node "fx_muzzle_01" is found on the pistol's barrel.
--     The orientation in the hand is unknown (no data), so 1P/3P offset sliders are in the options.
--
-- 0.1.1: the live game's (Aussiemon master) weapon templates have no grenade_ability chain entries any more
--   (laspistol_p1_m1.lua action_shoot_hip / action_reload), so cloning them errored "bad argument #1 to 'clone'"
--   and the template never registered. Those entries are gone; checked against the live laspistol/chainsword files.
--
-- 0.1.2: CTD on equip, weapon_tweak_templates.lua:579 pairs(nil): the borrowed pistol fields carry preparsed names
--   ("base_laspistol_p1_m1", "action_shoot_hip_<handling>") whose __base_template_lookup entries were not copied.
--   They are now merged into the clone's lookup (see the Tweak lookups block).
--
-- 0.2.0 (user: the block should rest on the pistol's trigger guard or the forearm, custom animation like the Butterfly
--   Knife / Karambit mods): first-person left arm IK during action_block, see QIangIQsChainLaspistol_brace.lua.
-- 0.2.1 (user: standalone, rely on no other mods): the driver skeleton ships in this mod (Custom/cl_fp_driver).
-- 0.3.0 (user: use the unreleased chainsword + laspistol animations): template uses Fatshark's chainsword_laspistol
--   1p/3p state machines; the pistol shot plays attack_shoot, the reload plays reload_start/middle/end. Brace defaults off.
-- 0.3.2 (user, in game: the unreleased set holds the sword reverse-grip / flat across both hands, wants the default
--   chainsword hold): the unreleased animations are now opt-in (option off by default); chainsword animations again.
-- 0.4.0 (in game: pistol renders but sat 0.43 m left of the camera, out of view; saved settings kept the old defaults):
--   1P pistol held at a fixed camera-space point with the left arm posed onto it; settings renamed (unreleased_anims,
--   block_brace) so stale saved values no longer apply.
--
-- New weapon pattern = QIangIQsDauntlessArmory / QIangIQsShardStaff: template clone into WeaponTemplates + NetworkLookup
-- append + particle/sound alias copy, item clone into MasterItems.get_cached(), equip by override_slot.
-- Author: QIangIQ
local mod = get_mod("QIangIQsChainLaspistol")

local WeaponTemplates = require("scripts/settings/equipment/weapon_templates/weapon_templates")
local MasterItems = require("scripts/backend/master_items")
local NetworkLookup = require("scripts/network_lookup/network_lookup")

local MELEE_ROOT = "content/items/weapons/player/melee/"
local RANGED_ROOT = "content/items/weapons/player/ranged/"

local TEMPLATE = "chainsword_laspistol_p1_m1"
local SOURCE_TEMPLATE = "chainsword_p1_m1"
local PISTOL_TEMPLATE = "laspistol_p1_m1"
local ITEM = MELEE_ROOT .. TEMPLATE
local SOURCE_ITEM = MELEE_ROOT .. SOURCE_TEMPLATE
local PISTOL_ITEM = RANGED_ROOT .. PISTOL_TEMPLATE
local OFFHAND_ITEM = RANGED_ROOT .. "qiangiq_chainlaspistol/offhand_laspistol_01"
local OFFHAND_SLOT = "qiangiq_offhand"
local LEFT_NODE = "j_leftweaponattach"

-- 0.3.0: Fatshark's unreleased chainsword + laspistol animation sets (asset sweep of build 139617; packages and state
-- machines exist in the shipped bundles, no Lua uses them). Their event lists (id32 matched against every string in the
-- game source) hold every chainsword_p1_m1 event plus attack_shoot and the laspistol reload_start/middle/end.
local CHAINLAS_SM_1P = "content/characters/player/human/first_person/animations/chainsword_laspistol"
local CHAINLAS_SM_3P = "content/characters/player/human/third_person/animations/chainsword_laspistol"

mod:add_global_localize_strings({
    loc_qiangiq_chainlaspistol = { en = "Chainsword & Laspistol" },
})

local function say(fmt, ...)
    local text = string.format(fmt, ...)

    mod:echo(text)
    mod:info(text)
end

-- Block brace (first person, QIangIQsKarambit driver method): QIangIQsChainLaspistol_brace.lua -----------------------
-- Standalone (user rule): the skeleton-only driver unit ships in this mod's own Custom/cl_fp_driver, a rename of
-- QIangIQsButterflyKnife's bf_fp_driver build (only name hashes and stream names differ, as in QIangIQsAWP's aw_fp_driver).
local DRIVERS = {
    { id = "QIangIQsChainLaspistol:cl_fp_driver", unit = "content/mods/qiangiq_chainlas/cl_fp_driver" },
}
local driver_loaded = {}

local Brace = mod:io_dofile("QIangIQsChainLaspistol/scripts/mods/QIangIQsChainLaspistol/QIangIQsChainLaspistol_brace")

Brace.setup({
    fp_nodes = mod:io_dofile("QIangIQsChainLaspistol/scripts/mods/QIangIQsChainLaspistol/QIangIQsChainLaspistol_fp_nodes"),
    opt = function(key, default)
        local v = mod:get(key)

        if v == nil then
            return default
        end

        return v
    end,
    driver_path = function()
        for i, d in ipairs(DRIVERS) do
            if driver_loaded[i] then
                return d.unit
            end
        end
    end,
    error = function(text)
        mod:error("%s", text)
    end,
})

-- Network lookups: new names go at the end so no existing id moves (QIangIQsShardStaff append_lookup) ---------------
local function append_lookup(lookup_name, key)
    local lookup = NetworkLookup[lookup_name]

    if not lookup then
        return false, "no lookup"
    end

    local existing = rawget(lookup, key)

    if existing then
        return true, existing
    end

    local index = #lookup + 1

    rawset(lookup, index, key)
    rawset(lookup, key, index)

    return true, index
end

-- Particle / sound aliases keyed by wielded_weapon_template -----------------------------------------------------------
local ALIAS_MODULES = {
    "scripts/settings/particles/player_character_particle_aliases",
    "scripts/settings/sound/player_character_sound_event_aliases",
}

local function alias_keys(root, source, target, seen, counter)
    if type(root) ~= "table" or seen[root] then
        return
    end

    seen[root] = true

    local value = rawget(root, source)

    if value ~= nil and rawget(root, target) == nil then
        root[target] = value
        counter.n = counter.n + 1
    end

    for _, child in pairs(root) do
        if type(child) == "table" then
            alias_keys(child, source, target, seen, counter)
        end
    end
end

local function copy_aliases(source, target)
    local counter = { n = 0 }

    for _, path in ipairs(ALIAS_MODULES) do
        local ok, module = pcall(require, path)

        if ok then
            alias_keys(module, source, target, {}, counter)
        else
            mod:error("alias module %s: %s", path, tostring(module))
        end
    end

    return counter.n
end

-- Template ------------------------------------------------------------------------------------------------------------
local state = { template_ok = false, item_ok = false, notes = {} }
local next_poll = 0

-- every chain entry may be one table or a list of tables
local function each_chain_entry(chains, func)
    for key, entry in pairs(chains) do
        if type(entry) == "table" then
            if entry.action_name then
                func(key, entry, chains)
            else
                for _, sub in ipairs(entry) do
                    if type(sub) == "table" and sub.action_name then
                        func(key, sub, chains)
                    end
                end
            end
        end
    end
end

local function has_hierarchy_input(hierarchy, name)
    for _, node in ipairs(hierarchy) do
        if node.input == name then
            return true
        end
    end

    return false
end

local function build_template()
    local melee = WeaponTemplates[SOURCE_TEMPLATE]
    local pistol = WeaponTemplates[PISTOL_TEMPLATE]

    if not melee or not pistol then
        return false
    end

    local WeaponAmmoTemplates = require("scripts/settings/equipment/weapon_handling_templates/weapon_ammo_templates")
    local WeaponTweakTemplateSettings = require("scripts/settings/equipment/weapon_templates/weapon_tweak_template_settings")

    local clone = table.clone(melee)

    clone.name = TEMPLATE

    -- weapon_templates.lua _require_template: action_settings.name = action_name
    for action_name, action_settings in pairs(clone.actions) do
        action_settings.name = action_name
    end

    -- Inputs: reload comes from the laspistol (laspistol_p1_m1.lua:77-86), hierarchy entry as :163-166
    if not clone.action_inputs.reload then
        clone.action_inputs.reload = table.clone(pistol.action_inputs.reload)
    end

    if not has_hierarchy_input(clone.action_input_hierarchy, "reload") then
        clone.action_input_hierarchy[#clone.action_input_hierarchy + 1] = { input = "reload", transition = "stay" }
    end

    -- Shot and reload actions (laspistol clones)
    local shot = table.clone(pistol.actions.action_shoot_hip)

    shot.name = "action_pistol_shot"
    shot.start_input = "special_action"
    shot.allowed_during_sprint = true
    shot.anim_event = nil
    shot.total_time = 0.5
    -- fire_configuration.anim_event stays "attack_shoot" (laspistol_p1_m1.lua:270): the chainsword_laspistol sets have
    -- it; the chain_sword fallback does not, and the has_animation_event guard skips it there
    shot.allowed_chain_actions = {
        combat_ability = { action_name = "combat_ability" },
        wield = { action_name = "action_unwield" },
        reload = { action_name = "action_reload", chain_time = 0.3 },
        special_action = { action_name = "action_pistol_shot", chain_time = 0.225 },
        start_attack = { action_name = "action_melee_start_left", chain_time = 0.2 },
        block = { action_name = "action_block", chain_time = 0.25 },
    }
    shot.recoil_template = nil
    shot.sway_template = nil

    local reload = table.clone(pistol.actions.action_reload)

    reload.name = "action_reload"
    reload.allowed_chain_actions = {
        combat_ability = { action_name = "combat_ability" },
        wield = { action_name = "action_unwield" },
        special_action = { action_name = "action_pistol_shot", chain_time = 2 },
        start_attack = { action_name = "action_melee_start_left", chain_time = 2 },
        block = { action_name = "action_block", chain_time = 2 },
    }

    -- The Chainsword rev (action_toggle_special) goes; special_action now means shot
    clone.actions.action_toggle_special = nil
    clone.actions.action_pistol_shot = shot
    clone.actions.action_reload = reload

    for _, action in pairs(clone.actions) do
        local chains = action.allowed_chain_actions

        if chains then
            each_chain_entry(chains, function(_, entry)
                if entry.action_name == "action_toggle_special" then
                    entry.action_name = "action_pistol_shot"
                end
            end)

            -- reload is reachable from wherever a shot is, at the same time
            local special = chains.special_action

            if special and not chains.reload and action.name ~= "action_pistol_shot" and action.name ~= "action_reload" then
                chains.reload = { action_name = "action_reload", chain_time = special.chain_time }
            end
        end
    end

    -- Chainsword rev removed: no special class, no "activated" keyword
    clone.weapon_special_class = nil
    clone.weapon_special_tweak_data = nil

    local keywords = {}

    for _, keyword in ipairs(clone.keywords) do
        if keyword ~= "activated" then
            keywords[#keywords + 1] = keyword
        end
    end

    clone.keywords = keywords

    -- Retail chainsword + laspistol animation sets (0.3.0). player_unit_animation_state.lua:112 indexes
    -- PlayerUnitAnimationStateMachineSettings by state machine path (QIangIQsMeltagun 0.2.2 found an unlisted path
    -- crashes on spawn), so the new paths get a copy of the donor's entry.
    state.retail_anims = false

    if mod:get("unreleased_anims") == true then
        local ok1, has1 = pcall(Application.can_get_resource, "package", CHAINLAS_SM_1P)
        local ok3, has3 = pcall(Application.can_get_resource, "package", CHAINLAS_SM_3P)

        if ok1 and has1 and ok3 and has3 then
            local SMSettings = require("scripts/settings/animation/player_unit_animation_state_machine_settings")

            for path, donor in pairs({ [CHAINLAS_SM_1P] = clone.anim_state_machine_1p, [CHAINLAS_SM_3P] = clone.anim_state_machine_3p }) do
                -- raw access: the table comes from settings() (player_unit_animation_state_machine_settings.lua:20)
                if not rawget(SMSettings, path) then
                    rawset(SMSettings, path, table.clone(rawget(SMSettings, donor) or { blend_time = 0 }))
                end
            end

            clone.anim_state_machine_1p = CHAINLAS_SM_1P
            clone.anim_state_machine_3p = CHAINLAS_SM_3P
            state.retail_anims = true
        else
            mod:info("chainsword_laspistol animation packages not found: chainsword animations kept")
        end
    end

    -- Pistol handling (laspistol_p1_m1.lua:881-897,904-907): hit spread, suppression, muzzle node, ammunition HUD
    clone.reload_template = pistol.reload_template
    clone.spread_template = pistol.spread_template
    clone.suppression_template = pistol.suppression_template
    clone.recoil_template = nil
    clone.sway_template = nil
    clone.conditional_state_to_action_input = table.clone(pistol.conditional_state_to_action_input)
    clone.no_ammo_delay = pistol.no_ammo_delay
    clone.hud_configuration = { uses_ammunition = true, uses_overheat = false }
    clone.fx_sources = table.clone(clone.fx_sources)
    clone.fx_sources._muzzle = pistol.fx_sources._muzzle
    clone.fx_sources._mag_well = pistol.fx_sources._mag_well

    -- Tweak lookups. Weapon templates are preparsed (weapon_tweak_templates.lua _preparse_templates): every
    -- "<type>_template" field is renamed ("base_<name>" on the template, "<action>_<name>" on an action) and
    -- __base_template_lookup[type][key] = { new_identifier = renamed, base_identifier = real name } is what
    -- WeaponTweakTemplates.create (_build_templates) resolves. The pistol's renamed names copied above only work if the
    -- matching lookup entries come along: base spread/suppression/ammo, and every per-action entry of the two borrowed
    -- actions under their new action names. Damage/explosion lookups need an (empty) entry per action
    -- (_preparse_damage_templates). 0.1.1 crashed in _resolve_template (pairs on nil) without this.
    local template_types = WeaponTweakTemplateSettings.template_types
    local clone_lookup = rawget(clone, "__base_template_lookup")
    local pistol_lookup = rawget(pistol, "__base_template_lookup")
    local BORROWED = { action_shoot_hip = "action_pistol_shot", action_reload = "action_reload" }
    local BASE_TYPES = { [template_types.spread] = true, [template_types.suppression] = true, [template_types.ammo] = true }
    local SKIP_TYPES = { [template_types.recoil] = true, [template_types.sway] = true }

    if not (clone_lookup and pistol_lookup) then
        error("no __base_template_lookup on the chainsword or laspistol template")
    end

    for _, template_type in pairs(template_types) do
        local from = pistol_lookup[template_type]

        if from and not SKIP_TYPES[template_type] then
            local to = clone_lookup[template_type] or {}

            clone_lookup[template_type] = to

            if BASE_TYPES[template_type] and from.base then
                to.base = table.clone(from.base)
            end

            for source_name, target_name in pairs(BORROWED) do
                if from[source_name] then
                    to[target_name] = table.clone(from[source_name])
                end

                if from[source_name .. "_special"] then
                    to[target_name .. "_special"] = table.clone(from[source_name .. "_special"])
                end
            end
        end
    end

    for _, template_type in ipairs({ template_types.damage, template_types.explosion }) do
        local to = clone_lookup[template_type]

        if to then
            to.action_pistol_shot = to.action_pistol_shot or {}
            to.action_reload = to.action_reload or {}
            to.action_toggle_special = nil
        end
    end

    clone.ammo_template = pistol.ammo_template                     -- "base_laspistol_p1_m1", resolved via the lookup

    local ammo_base = clone_lookup[template_types.ammo] and clone_lookup[template_types.ammo].base

    if not (ammo_base and WeaponAmmoTemplates[ammo_base.base_identifier]) then
        mod:error("laspistol ammo lookup not found (%s)", tostring(ammo_base and ammo_base.base_identifier))
    end

    WeaponTemplates[TEMPLATE] = clone
    state.template_ours = true

    local ok, index = append_lookup("weapon_templates", TEMPLATE)

    state.template_id = ok and index or nil
    state.aliases = copy_aliases(SOURCE_TEMPLATE, TEMPLATE) + copy_aliases(PISTOL_TEMPLATE, TEMPLATE)
    state.template_ok = ok

    return ok
end

local function ensure_template()
    if rawget(WeaponTemplates, TEMPLATE) then
        state.template_ok = true

        return true
    end

    return build_template()
end

-- Items ---------------------------------------------------------------------------------------------------------------
local function find_item(cache, preferred, template)
    local direct = rawget(cache, preferred)

    if direct and direct.weapon_template == template then
        return preferred, direct
    end

    for name, item in pairs(cache) do
        if type(item) == "table" and item.weapon_template == template then
            return name, item
        end
    end
end

local function build_item(cache)
    local source_name, source_item = find_item(cache, SOURCE_ITEM, SOURCE_TEMPLATE)
    local pistol_name, pistol_item = find_item(cache, PISTOL_ITEM, PISTOL_TEMPLATE)

    if not source_item then
        return false, "no " .. SOURCE_TEMPLATE .. " item"
    end

    if not pistol_item then
        return false, "no " .. PISTOL_TEMPLATE .. " item"
    end

    -- Off-hand Laspistol: a clone so the original's data is untouched; its own attachment tree (receiver, barrel...) is kept
    local offhand = table.clone(pistol_item)

    offhand.name = OFFHAND_ITEM
    cache[OFFHAND_ITEM] = offhand

    local item = table.clone(source_item)

    item.name = ITEM
    item.weapon_template = TEMPLATE
    item.archetypes = { "zealot" }
    item.display_name = "loc_qiangiq_chainlaspistol"

    for _, field in ipairs({ "weapon_family_display_name", "weapon_pattern_display_name", "weapon_mark_display_name" }) do
        if type(item[field]) == "table" then
            item[field].loc_id = "loc_qiangiq_chainlaspistol"
        end
    end

    if type(item.attachments) ~= "table" then
        return false, "source item has no attachments"
    end

    -- hang the Laspistol under the first top-level attachment (top-level slot names are sorted by priority, children's are not)
    -- the host must spawn a unit: _attach_hierarchy returns before the children when its item is "" (0.1.2 picked
    -- zzz_shared_material_overrides through next(), so the pistol would never spawn). The chainsword tree has "grip".
    local host_name, host = "grip", item.attachments.grip

    if not (host and type(host.item) == "string" and host.item ~= "") then
        host_name, host = nil, nil

        for name, node in pairs(item.attachments) do
            if type(node) == "table" and type(node.item) == "string" and node.item ~= "" then
                host_name, host = name, node

                break
            end
        end
    end

    if not host then
        return false, "source item has an empty attachment tree"
    end

    host.children = host.children or {}
    host.children[OFFHAND_SLOT] = { item = OFFHAND_ITEM, children = {} }

    -- dependencies: the Chainsword's, the Laspistol's, and what the offline item compile adds for the template
    -- (item_package.lua:239-249; QIangIQsDauntlessArmory found a missing state machine crashes otherwise)
    local deps = item.resource_dependencies or {}

    for resource in pairs(pistol_item.resource_dependencies or {}) do
        deps[resource] = true
    end

    local WeaponTemplateResourceDependencies = require("scripts/utilities/weapon_template_resource_dependencies")

    for _, resource in ipairs(WeaponTemplateResourceDependencies.generate(TEMPLATE)) do
        deps[resource] = true
    end

    item.resource_dependencies = deps

    local ok, index = append_lookup("player_item_names", ITEM)

    if not ok then
        return false, "player_item_names lookup missing"
    end

    cache[ITEM] = item
    state.item_id = index
    state.slot = item.slots and item.slots[1]
    state.notes = { string.format("%s + %s (under %s)", tostring(source_name), tostring(pistol_name), tostring(host_name)) }

    return true
end

local function ensure_item()
    local ok, has_data = pcall(MasterItems.has_data)

    if not ok or not has_data then
        return false
    end

    local cache = MasterItems.get_cached()

    if rawget(cache, ITEM) then
        state.item_ok = true

        return true
    end

    local built, err = build_item(cache)

    if err and err ~= state.last_error then
        state.last_error = err
        mod:error("%s", err)
    end

    state.item_ok = built and rawget(cache, ITEM) ~= nil

    return state.item_ok
end

local function poll()
    if next_poll > os.clock() then
        return
    end

    next_poll = os.clock() + 1

    local before_t, before_i = state.template_ok, state.item_ok
    local ok_t, err_t = pcall(ensure_template)
    local ok_i, err_i = true, nil

    if state.template_ok then
        ok_i, err_i = pcall(ensure_item)
    end

    if not ok_t then
        mod:error("template: %s", tostring(err_t))
    end

    if not ok_i then
        mod:error("item: %s", tostring(err_i))
    end

    if state.template_ok and not before_t then
        mod:info("template %s registered (clone of %s + %s), %s alias entries", TEMPLATE, SOURCE_TEMPLATE, PISTOL_TEMPLATE,
            tostring(state.aliases))
    end

    if state.item_ok and not before_i then
        mod:info("item %s injected (slot %s): %s", ITEM, tostring(state.slot), table.concat(state.notes or {}, "; "))
    end
end

-- Anim event guard: the pistol reload events are not in the chain_sword state machine ---------------------------------
-- Two classes play player anim events: PlayerUnitAnimationExtension (clients, sets self._local_wielded_weapon_template)
-- and AuthoritativePlayerUnitAnimationExtension (whoever hosts: Psykhanium, SoloPlay; it keeps no template field).
-- 0.1.3 guarded only the first, so the host crashed in authoritative_player_unit_animation_extension.lua
-- ("state machine ... does not have an event"). Both inventory_slot_wielded(self, weapon_template) are hooked to note
-- the wielded template, and every anim_event* of both classes is guarded (player_character_state_ledge_vaulting.lua:109
-- uses Unit.has_animation_event the same way).
local skipped_events = {}

local function wielded_ours(self)
    return self.__qiangiq_chainlas_template == TEMPLATE or rawget(self, "_local_wielded_weapon_template") == TEMPLATE
end

local function guard(unit_field)
    return function(func, self, event_name, ...)
        if wielded_ours(self) then
            local unit = self[unit_field]

            if unit and not Unit.has_animation_event(unit, event_name) then
                if not skipped_events[event_name] then
                    skipped_events[event_name] = true
                    mod:info("skipped anim event %s (%s): not in the chain_sword state machine", tostring(event_name),
                        unit_field == "_first_person_unit" and "1p" or "3p")
                end

                return
            end
        end

        return func(self, event_name, ...)
    end
end

for _, class_name in ipairs({ "PlayerUnitAnimationExtension", "AuthoritativePlayerUnitAnimationExtension" }) do
    mod:hook_safe(class_name, "inventory_slot_wielded", function(self, weapon_template)
        self.__qiangiq_chainlas_template = weapon_template and weapon_template.name
    end)

    for _, method in ipairs({ "anim_event", "anim_event_with_variable_float", "anim_event_with_variable_floats",
        "anim_event_with_variable_int" }) do
        mod:hook(class_name, method, guard("_unit"))
    end

    for _, method in ipairs({ "anim_event_1p", "anim_event_with_variable_float_1p", "anim_event_with_variable_floats_1p" }) do
        mod:hook(class_name, method, guard("_first_person_unit"))
    end
end

-- Off-hand Laspistol: re-link the rig to the character's left weapon node --------------------------------------------
local linked = {}              -- laspistol rig unit -> parent it was linked to

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function offhand_rig(names)
    if names then
        for unit, item_name in pairs(names) do
            if item_name == OFFHAND_ITEM and unit_ok(unit) then
                return unit
            end
        end
    end
end

-- Block brace: the chain_sword parry_pose animation brings the left hand up to the blade. No forearm/brace animation
-- exists, so while action_block runs the pistol blends to a second pose (block sliders) meant to put its trigger guard
-- against the blade; the blend is 0.12 s each way.
local BLEND_TIME = 0.12
local block_blend = {}          -- view -> 0..1

local function pose_values(view, prefix)
    return mod:get(prefix .. view .. "_x") or 0, mod:get(prefix .. view .. "_y") or 0, mod:get(prefix .. view .. "_z") or 0,
        mod:get(prefix .. view .. "_pitch") or 0, mod:get(prefix .. view .. "_yaw") or 0, mod:get(prefix .. view .. "_roll") or 0
end

local function blocking(ext)
    local ok, weapon_action = pcall(function()
        local ude = ScriptUnit.has_extension(ext._unit, "unit_data_system")

        return ude and ude:read_component("weapon_action")
    end)

    return ok and weapon_action and weapon_action.template_name == TEMPLATE and weapon_action.current_action_name == "action_block"
end

local function offhand_pose(unit, view, is_blocking, dt)
    local b = block_blend[view] or 0

    b = math.clamp(b + (is_blocking and 1 or -1) * (dt or 0) / BLEND_TIME, 0, 1)
    block_blend[view] = b

    local x0, y0, z0, p0, w0, r0 = pose_values(view, "oh_")
    local x1, y1, z1, p1, w1, r1 = pose_values(view, "block_")
    local x, y, z = math.lerp(x0, x1, b), math.lerp(y0, y1, b), math.lerp(z0, z1, b)
    local pitch, yaw, roll = math.rad(math.lerp(p0, p1, b)), math.rad(math.lerp(w0, w1, b)), math.rad(math.lerp(r0, r1, b))

    Unit.set_local_position(unit, 1, Vector3(x, y, z))
    Unit.set_local_rotation(unit, 1, Quaternion.from_yaw_pitch_roll(yaw, pitch, roll))
end

-- 0.4.0 (user: the pistol must be visible in first person): the chainsword idle keeps the left hand below the view, so in
-- first person the pistol hangs at a fixed point in camera space (lower left, pointing forward; the /chainlas front test
-- showed identity rotation points it forward) plus the 1P sliders, and the left arm is posed onto it with the driver.
local HOLD_BASE = { x = -0.2, y = 0.42, z = -0.2 }

local function hold_on()
    return mod:get("pistol_hold_1p") ~= false
end

local function hold_offset()
    return Vector3(HOLD_BASE.x + (mod:get("oh_1p_x") or 0), HOLD_BASE.y + (mod:get("oh_1p_y") or 0),
        HOLD_BASE.z + (mod:get("oh_1p_z") or 0))
end

-- 0.3.3 test (/chainlas front): the 1P pistol hangs 0.4 m in front of the camera node instead of the left hand, to tell
-- "not rendered" from "rendered out of view"
local front_test = false

local function sync_offhand(ext, slot, first_person, parent_override)
    local names = first_person and slot.item_name_by_unit_1p or slot.item_name_by_unit_3p
    local rig = offhand_rig(names)

    if not rig then
        return
    end

    if first_person and front_test then
        local fp = ext._first_person_unit
        local world = ext.__qiangiq_chainlas_world

        if world and unit_ok(fp) and Unit.has_node(fp, "ap_camera_node") then
            if linked[rig] ~= "front" then
                World.unlink_unit(world, rig)
                World.link_unit(world, rig, 1, fp, Unit.node(fp, "ap_camera_node"), World.LINK_MODE_NONE)
                linked[rig] = "front"
            end

            Unit.set_local_position(rig, 1, Vector3(-0.12, 0.4, -0.1))
            Unit.set_local_rotation(rig, 1, Quaternion.identity())
            Unit.set_unit_visibility(rig, true, true)
        end

        return
    end

    local world = ext.__qiangiq_chainlas_world

    if first_person and hold_on() then
        local fp = ext._first_person_unit

        if not (world and unit_ok(fp) and Unit.has_node(fp, "ap_camera_node")) then
            return
        end

        if linked[rig] ~= "hold" then
            World.unlink_unit(world, rig)
            World.link_unit(world, rig, 1, fp, Unit.node(fp, "ap_camera_node"), World.LINK_MODE_NONE)
            linked[rig] = "hold"
        end

        local o = hold_offset()

        Unit.set_local_position(rig, 1, o)
        Unit.set_local_rotation(rig, 1, Quaternion.from_yaw_pitch_roll(math.rad(mod:get("oh_1p_yaw") or 0),
            math.rad(mod:get("oh_1p_pitch") or 0), math.rad(mod:get("oh_1p_roll") or 0)))
        Unit.set_unit_visibility(rig, slot.hidden_1p == false, true)

        return
    end

    local parent = parent_override or (first_person and ext._first_person_unit or ext._unit)

    if not (world and unit_ok(parent) and Unit.has_node(parent, LEFT_NODE)) then
        return
    end

    if linked[rig] ~= parent then
        World.unlink_unit(world, rig)
        World.link_unit(world, rig, 1, parent, Unit.node(parent, LEFT_NODE), World.LINK_MODE_NONE)
        linked[rig] = parent
    end

    offhand_pose(rig, first_person and "1p" or "3p", blocking(ext), ext.__qiangiq_chainlas_dt)

    local hidden = first_person and slot.hidden_1p or slot.hidden_3p

    Unit.set_unit_visibility(rig, hidden == false, true)
end

-- 0.3.1 (user: the chainsword_laspistol animations hold the sword in an icepick/reverse grip): the sword's root unit
-- gets a rotation about its attach node, default pitch 180 so the blade points up. Only with the retail animations.
local function grip_correction(slot)
    if not state.retail_anims then
        return
    end

    for view, unit in pairs({ ["1p"] = slot.unit_1p, ["3p"] = slot.unit_3p }) do
        if unit_ok(unit) then
            local pitch = math.rad(mod:get("sword_" .. view .. "_pitch") or 180)
            local yaw = math.rad(mod:get("sword_" .. view .. "_yaw") or 0)
            local roll = math.rad(mod:get("sword_" .. view .. "_roll") or 0)

            Unit.set_local_rotation(unit, 1, Quaternion.from_yaw_pitch_roll(yaw, pitch, roll))
        end
    end
end

local function apply_offhand(ext)
    if not ext._is_local_unit or not ext._equipment then
        return
    end

    local ours

    for _, slot in pairs(ext._equipment) do
        local item = slot.item

        if item and item.name == ITEM then
            ours = slot
        end
    end

    local ok, driver = pcall(Brace.update, ext, ours, ours ~= nil and blocking(ext), ext.__qiangiq_chainlas_dt,
        ours ~= nil and hold_on() and hold_offset() or nil)

    if not ok then
        mod:error("brace update: %s", tostring(driver))
        driver = nil
        pcall(Brace.stop, ext)
    end

    if ours then
        sync_offhand(ext, ours, false)
        sync_offhand(ext, ours, true, driver)
        grip_correction(ours)
    end

    for rig in pairs(linked) do
        if not unit_ok(rig) then
            linked[rig] = nil
        end
    end
end

local tracked = {}

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "init", function(self, extension_init_context)
    self.__qiangiq_chainlas_world = extension_init_context and extension_init_context.world
end)

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "_update_item_visibility", function(self)
    if self._is_local_unit then
        tracked[self] = true
        apply_offhand(self)
    end
end)

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "update", function(self, unit, dt)
    if tracked[self] then
        self.__qiangiq_chainlas_dt = dt
        apply_offhand(self)
    end
end)

mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, "destroy", function(func, self, ...)
    pcall(Brace.stop, self)
    tracked[self] = nil

    return func(self, ...)
end)

mod.update = function()
    poll()
end

-- Zealot unlock list (weapon_unlock_settings.lua; realms_loadout builds its weapon list from it) ----------------------
local function add_to_unlock_list()
    if not mod:get("add_to_unlock_list") then
        return
    end

    local ok, unlocks = pcall(require, "scripts/settings/weapon_unlock/weapon_unlock_settings")
    local zealot = ok and unlocks and unlocks.zealot

    if not zealot then
        mod:error("WeaponUnlockSettings.zealot not found")

        return
    end

    local level = math.floor(mod:get("unlock_level") or 1)

    zealot[level] = zealot[level] or {}

    if not table.find(zealot[level], ITEM) then
        table.insert(zealot[level], ITEM)
    end
end

local function acquire_driver()
    local custom_assets = get_mod("CustomAssets")

    if not custom_assets or not custom_assets.is_api_compatible or not custom_assets.is_api_compatible(1) then
        mod:info("Custom Assets (API 1) not installed: block uses the slider pose, no arm brace")

        return
    end

    for i, d in ipairs(DRIVERS) do
        local ticket = custom_assets.acquire(mod, d.id, function(_, _, load_error)
            if load_error then
                mod:info("brace driver %s not loaded: %s", d.id, tostring(load_error))

                return
            end

            driver_loaded[i] = true
            mod:info("brace driver %s loaded", d.id)
        end, { resident = true, reference_name = d.id })

        if not ticket then
            mod:info("brace driver %s could not be requested (mod not installed?)", d.id)
        end
    end
end

mod.on_all_mods_loaded = function()
    add_to_unlock_list()
    acquire_driver()
end

mod.on_unload = function()
    local ok, cache = pcall(MasterItems.get_cached)

    if ok and cache then
        cache[ITEM] = nil
        cache[OFFHAND_ITEM] = nil
    end

    if state.template_ours then
        WeaponTemplates[TEMPLATE] = nil
    end
end

-- Equip without the backend (QIangIQsDauntlessArmory override): only where this client hosts --------------------------
local function local_player()
    local players = Managers.player

    return players and players:local_player_safe(1)
end

local function equipped_item_name(player, slot)
    local unit = player and player.player_unit

    if not unit or not Unit.alive(unit) then
        return nil
    end

    local extension = ScriptUnit.has_extension(unit, "visual_loadout_system")
    local item = extension and extension:item_from_slot(slot)

    return item and item.name
end

local previous = {}

local function override(slot, item_name)
    local player = local_player()
    local sync = Managers.profile_synchronization
    local host = sync and sync:synchronizer_host()

    if not player then
        say("no local player")

        return false
    end

    if not host then
        say("not the host here. Use the Psykhanium, a SoloPlay game or a game you host")

        return false
    end

    host:override_slot(player:peer_id(), player:local_player_id(), slot, item_name)
    say("override_slot(%s, %s) sent", slot, tostring(item_name))

    return true
end

local function debug_offhand()
    local player = local_player()
    local unit = player and player.player_unit
    local ext = unit and ScriptUnit.has_extension(unit, "visual_loadout_system")

    if not (ext and ext._equipment) then
        say("no player unit")

        return
    end

    say("retail animations %s; 1p state machine %s", tostring(state.retail_anims),
        tostring(WeaponTemplates[TEMPLATE] and WeaponTemplates[TEMPLATE].anim_state_machine_1p))
    say("1p unit has %s: %s, 3p unit has %s: %s", LEFT_NODE,
        tostring(unit_ok(ext._first_person_unit) and Unit.has_node(ext._first_person_unit, LEFT_NODE)), LEFT_NODE,
        tostring(unit_ok(ext._unit) and Unit.has_node(ext._unit, LEFT_NODE)))

    for slot_name, slot in pairs(ext._equipment) do
        if slot.item and slot.item.name == ITEM then
            local rig1, rig3 = offhand_rig(slot.item_name_by_unit_1p), offhand_rig(slot.item_name_by_unit_3p)

            say("%s: pistol rig 1p %s (linked %s), 3p %s (linked %s)", slot_name, tostring(rig1 ~= nil),
                tostring(rig1 and linked[rig1] ~= nil), tostring(rig3 ~= nil), tostring(rig3 and linked[rig3] ~= nil))

            if rig1 then
                say("  1p pistol has fx_muzzle_01 (rig): %s, visible %s", tostring(Unit.has_node(rig1, "fx_muzzle_01")),
                    tostring(Unit.is_visible ~= nil and Unit.is_visible(rig1)))

                local pos = Unit.world_position(rig1, 1)
                local fp = ext._first_person_unit

                if unit_ok(fp) and Unit.has_node(fp, "ap_camera_node") then
                    local cam = Unit.world_pose(fp, Unit.node(fp, "ap_camera_node"))
                    local rel = Matrix4x4.transform(Matrix4x4.inverse(cam), pos)

                    say("  1p pistol relative to camera: right %.2f, forward %.2f, up %.2f (m); linked to %s", rel.x, rel.y,
                        rel.z, tostring(linked[rig1]))
                else
                    say("  1p pistol at %s", tostring(pos))
                end
            end

            say("  %s", Brace.debug(ext))
        end
    end
end

mod:command("chainlas", mod:localize("command_chainlas"), function(action)
    action = action or "status"

    if action == "status" then
        say("template %s (id %s), item %s (id %s, slot %s)", tostring(state.template_ok), tostring(state.template_id),
            tostring(state.item_ok), tostring(state.item_id), tostring(state.slot))
    elseif action == "equip" then
        if not (state.template_ok and state.item_ok and state.slot) then
            say("not ready yet (template %s, item %s)", tostring(state.template_ok), tostring(state.item_ok))

            return
        end

        local player = local_player()

        previous[state.slot] = previous[state.slot] or (player and equipped_item_name(player, state.slot))
        override(state.slot, ITEM)
    elseif action == "restore" then
        local any = false

        for slot, item_name in pairs(previous) do
            if item_name and override(slot, item_name) then
                previous[slot] = nil
                any = true
            end
        end

        if not any then
            say("nothing to restore (equip first)")
        end
    elseif action == "debug" then
        debug_offhand()
    elseif action == "front" then
        front_test = not front_test
        table.clear(linked)
        say("1p pistol in front of the camera: %s", tostring(front_test))
    else
        say("usage: /chainlas [status|equip|restore|debug|front]")
    end
end)
