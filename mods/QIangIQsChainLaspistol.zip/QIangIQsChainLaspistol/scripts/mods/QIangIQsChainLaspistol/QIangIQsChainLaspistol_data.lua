local mod = get_mod("QIangIQsChainLaspistol")

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = false,
    options = {
        widgets = {
            { setting_id = "add_to_unlock_list", type = "checkbox", default_value = true },
            { setting_id = "unlock_level", type = "numeric", default_value = 1, range = { 1, 30 }, decimals_number = 0 },
            { setting_id = "pistol_hold_1p", type = "checkbox", default_value = true },
            { setting_id = "unreleased_anims", type = "checkbox", default_value = false },
            {
                setting_id = "group_brace",
                type = "group",
                sub_widgets = {
                    {
                        setting_id = "block_brace",
                        type = "dropdown",
                        default_value = "off",
                        options = {
                            { text = "brace_off", value = "off" },
                            { text = "brace_trigger", value = "trigger" },
                            { text = "brace_forearm", value = "forearm" },
                        },
                    },
                    { setting_id = "brace_along", type = "numeric", default_value = 0.3, range = { 0.05, 0.8 }, decimals_number = 2 },
                    { setting_id = "brace_drop", type = "numeric", default_value = 0.05, range = { -0.1, 0.2 }, decimals_number = 3 },
                },
            },
            {
                setting_id = "group_sword",
                type = "group",
                sub_widgets = {
                    { setting_id = "sword_1p_pitch", type = "numeric", default_value = 180, range = { -180, 180 }, decimals_number = 0 },
                    { setting_id = "sword_1p_yaw", type = "numeric", default_value = 0, range = { -180, 180 }, decimals_number = 0 },
                    { setting_id = "sword_1p_roll", type = "numeric", default_value = 0, range = { -180, 180 }, decimals_number = 0 },
                    { setting_id = "sword_3p_pitch", type = "numeric", default_value = 180, range = { -180, 180 }, decimals_number = 0 },
                    { setting_id = "sword_3p_yaw", type = "numeric", default_value = 0, range = { -180, 180 }, decimals_number = 0 },
                    { setting_id = "sword_3p_roll", type = "numeric", default_value = 0, range = { -180, 180 }, decimals_number = 0 },
                },
            },
            {
                setting_id = "group_1p",
                type = "group",
                sub_widgets = {
                    { setting_id = "oh_1p_x", type = "numeric", default_value = 0, range = { -0.5, 0.5 }, decimals_number = 3 },
                    { setting_id = "oh_1p_y", type = "numeric", default_value = 0, range = { -0.5, 0.5 }, decimals_number = 3 },
                    { setting_id = "oh_1p_z", type = "numeric", default_value = 0, range = { -0.5, 0.5 }, decimals_number = 3 },
                    { setting_id = "oh_1p_pitch", type = "numeric", default_value = 0, range = { -180, 180 }, decimals_number = 0 },
                    { setting_id = "oh_1p_yaw", type = "numeric", default_value = 0, range = { -180, 180 }, decimals_number = 0 },
                    { setting_id = "oh_1p_roll", type = "numeric", default_value = 0, range = { -180, 180 }, decimals_number = 0 },
                },
            },
            {
                setting_id = "group_3p",
                type = "group",
                sub_widgets = {
                    { setting_id = "oh_3p_x", type = "numeric", default_value = 0, range = { -0.5, 0.5 }, decimals_number = 3 },
                    { setting_id = "oh_3p_y", type = "numeric", default_value = 0, range = { -0.5, 0.5 }, decimals_number = 3 },
                    { setting_id = "oh_3p_z", type = "numeric", default_value = 0, range = { -0.5, 0.5 }, decimals_number = 3 },
                    { setting_id = "oh_3p_pitch", type = "numeric", default_value = 0, range = { -180, 180 }, decimals_number = 0 },
                    { setting_id = "oh_3p_yaw", type = "numeric", default_value = 0, range = { -180, 180 }, decimals_number = 0 },
                    { setting_id = "oh_3p_roll", type = "numeric", default_value = 0, range = { -180, 180 }, decimals_number = 0 },
                },
            },
            {
                setting_id = "group_block_1p",
                type = "group",
                sub_widgets = {
                    { setting_id = "block_1p_x", type = "numeric", default_value = 0, range = { -0.5, 0.5 }, decimals_number = 3 },
                    { setting_id = "block_1p_y", type = "numeric", default_value = 0, range = { -0.5, 0.5 }, decimals_number = 3 },
                    { setting_id = "block_1p_z", type = "numeric", default_value = 0, range = { -0.5, 0.5 }, decimals_number = 3 },
                    { setting_id = "block_1p_pitch", type = "numeric", default_value = 0, range = { -180, 180 }, decimals_number = 0 },
                    { setting_id = "block_1p_yaw", type = "numeric", default_value = 0, range = { -180, 180 }, decimals_number = 0 },
                    { setting_id = "block_1p_roll", type = "numeric", default_value = 0, range = { -180, 180 }, decimals_number = 0 },
                },
            },
            {
                setting_id = "group_block_3p",
                type = "group",
                sub_widgets = {
                    { setting_id = "block_3p_x", type = "numeric", default_value = 0, range = { -0.5, 0.5 }, decimals_number = 3 },
                    { setting_id = "block_3p_y", type = "numeric", default_value = 0, range = { -0.5, 0.5 }, decimals_number = 3 },
                    { setting_id = "block_3p_z", type = "numeric", default_value = 0, range = { -0.5, 0.5 }, decimals_number = 3 },
                    { setting_id = "block_3p_pitch", type = "numeric", default_value = 0, range = { -180, 180 }, decimals_number = 0 },
                    { setting_id = "block_3p_yaw", type = "numeric", default_value = 0, range = { -180, 180 }, decimals_number = 0 },
                    { setting_id = "block_3p_roll", type = "numeric", default_value = 0, range = { -180, 180 }, decimals_number = 0 },
                },
            },
        },
    },
}
