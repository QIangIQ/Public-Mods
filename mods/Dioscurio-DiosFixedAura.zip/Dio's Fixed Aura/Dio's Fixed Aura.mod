-- Dio's Fixed Aura: original mod by Seph (Steam: Concoction of Constitution), fixed by Dioscurio.
return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`Aura` encountered an error loading the Darktide Mod Framework.")

		new_mod("Aura", {
			mod_script       = "Dio's Fixed Aura/scripts/mods/Aura/Aura",
			mod_data         = "Dio's Fixed Aura/scripts/mods/Aura/Aura_data",
			mod_localization = "Dio's Fixed Aura/scripts/mods/Aura/Aura_localization",
		})
	end,
	version = "1.0.0",
	packages = {},
}
