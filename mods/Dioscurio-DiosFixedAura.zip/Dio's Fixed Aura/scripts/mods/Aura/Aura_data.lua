local mod = get_mod("Aura")

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
        widgets = {
			{ setting_id = "R", type = "numeric", default_value = 1, range = {0, 1}, decimals_number = 2,},
			{ setting_id = "G", type = "numeric", default_value = 1, range = {0, 1}, decimals_number = 2,},
			{ setting_id = "B", type = "numeric", default_value = 1, range = {0, 1}, decimals_number = 2,},
			{ setting_id = "RaveMode", type = "checkbox", default_value = false, },
			{ setting_id = "Intensity", type = "numeric", default_value = 20, range = {0, 100}, decimals_number = 1,},
			{ setting_id = "FalloffStart", type = "numeric", default_value = 0, range = {0, 800}, decimals_number = 1,},
			{ setting_id = "FalloffEnd", type = "numeric", default_value = 12, range = {0, 800}, decimals_number = 1,},
			{ setting_id = "Shadows", type = "checkbox", default_value = false, },
			{ setting_id = "Height", type = "numeric", default_value = 0.35, range = {-1, 2}, decimals_number = 2,},
		}
	}
}
