
--[[
┌───────────────────────────────────────────────────────────────────────────────────────────┐
│ Mod Name: Aura		                                                                    │
│ Mod Description: Provides a customizable light aura around the player.			        │
│ Mod Author: Seph (Steam: Concoction of Constitution)                                      │
└───────────────────────────────────────────────────────────────────────────────────────────┘
--]]


local mod = get_mod("Aura")


---------------------------


local Promise = require("scripts/foundation/utilities/promise")
local MasterItems = require("scripts/backend/master_items")
local ItemPackage = require("scripts/foundation/managers/package/utilities/item_package")
local d = false

-- Darkness modifier check. The old Managers.loading._loading_host._host path was removed by Fatshark.
local is_darkness = function()
	local circumstance = Managers.state and Managers.state.circumstance
	local name = circumstance and circumstance:circumstance_name()
	return name ~= nil and string.find(name, "darkness") ~= nil
end

mod.enable_light = function(self, light_unit)
	local light = Unit.light(light_unit, 1)
	d = is_darkness()
	if not light then
		return
	end
	Light.set_volumetric_intensity(light, 0.025)
	Light.set_casts_shadows(light, mod:get("Shadows"))
	Light.set_color_filter(light, Vector3(mod:get("R"),mod:get("G"),mod:get("B")))
    Light.set_type(light, "omni")
	-- Light.set_spot_reflector(light, true)
	Light.set_intensity(light, math.clamp(mod:get("Intensity"), 0, d and 30 or 1000)) --default 20
	Light.set_falloff_start(light, math.clamp(mod:get("FalloffStart"), 0, d and 0 or 800)) --default 12
	Light.set_falloff_end(light, math.clamp(math.max(mod:get("FalloffEnd"), mod:get("FalloffStart")), 0, d and 10 or 800)) --default 12
	Light.set_enabled(light, true)
end

mod._loaded_packages = {}

mod.load_item_packages = function(self, item, callback)
	if not item then
		return
	end

	local dependencies = ItemPackage.compile_item_instance_dependencies(item, MasterItems.get_cached(), nil, nil)
	local loading_finished = {}
	for package_name, _ in pairs(dependencies) do
		dependencies[package_name] = true
		loading_finished[package_name] = false
		local load_id = Managers.package:load(package_name, "light_test", function()	loading_finished[package_name] = true	end, true)
		mod._loaded_packages[package_name] = mod._loaded_packages[package_name] or {}
		table.insert(mod._loaded_packages[package_name], load_id)
	end

	if callback then
		Promise.until_value_is_true(function()
			for package, is_loaded in pairs(loading_finished) do
				if is_loaded ~= true then
					return false
				end
			end

			return true
		end):next(callback())
	end
end


mod:hook("WwiseWorld","trigger_resource_event",function(func, s, file_path, ...)
    if file_path == "wwise/events/world/play_phys_metal_hollow_med" then return end
    return func(s, file_path, ...)
end)

mod.light_unit = nil
mod.spawn_light = function()
	if MasterItems.has_data() then
		local battery_item = MasterItems.get_item("content/items/luggable/battery_01_luggable")
		local world = Managers.world:world("level_world")
		local player = Managers.player:local_player_safe(1)
		if player == nil then return end
		local player_unit = player.player_unit
		mod.player_unit = player_unit
		if Unit.is_valid(player_unit) then
			local hand_node = Unit.node(player_unit, "j_lefttoebase")

			mod:load_item_packages(battery_item,  function()
				local pos = Unit.world_position(player_unit, hand_node)
				local rot = Unit.world_rotation(player_unit, hand_node)

				mod.light_unit = World.spawn_unit(world, battery_item.base_unit, pos, rot)

				-- World.link_unit(world, mod.light_unit, 1, player_unit, hand_node)
				Unit.set_local_scale(mod.light_unit, 1, Vector3.one() * 0.001)
				mod:enable_light(mod.light_unit)
			end)
		end
	end
end

mod:command("light", "", function()
	mod:despawn_light()
	mod:spawn_light()
end)


local r = 0
local rInvert = false
local g = 0
local gInvert = false
local b = 0
local bInvert = false

mod.update = function(dt)

	if mod:get("RaveMode") then
		if rInvert then
			r = r - dt
			if r <= 0.05 then
			rInvert = false
			end
		else
			r = r + dt
			if r >= 1 then
			rInvert = true
			end
		end
		
		if bInvert then
			b = b - dt*0.7
			if b <= 0.05 then
			bInvert = false
			end
		else
			b = b + dt*0.7
			if b >= 1 then
			bInvert = true
			end
		end
		
		if gInvert then
			g = g - dt*0.6
			if g <= 0.05 then
			gInvert = false
			end
		else
			g = g + dt*0.6
			if g >= 1 then
			gInvert = true
			end
		end


	  
		mod:set("R", r, true)
		mod:set("G", g, true)
		mod:set("B", b, true)
	  end

	-- Dio fix: follow the player at chest height. The old code added the LOCAL position of node 33
	-- (j_spine2 relative to j_spine1, a few cm) to the root, which put the light about 0.25 m under the
	-- floor while standing; crouching and sliding moved that node enough to bring it above the floor.
	local player = Managers.player and Managers.player:local_player_safe(1)
	local current = player and player.player_unit
	if current and current ~= mod.player_unit and Unit.is_valid(current) then
		mod:despawn_light()
		mod.player_unit = current
		mod:spawn_light()
	end
	if mod.light_unit and Unit.alive(mod.light_unit) and mod.player_unit and Unit.is_valid(mod.player_unit) then
		local pu = mod.player_unit
		local pos = Unit.world_position(pu, 1) + Vector3(0, 0, 1.2)
		if Unit.has_node(pu, "j_spine2") then
			pos = Unit.world_position(pu, Unit.node(pu, "j_spine2"))
		end
		pos = pos + Vector3(0, 0, mod:get("Height") or 0.35)
		Unit.set_local_position(mod.light_unit, 1, pos)
	end
end

local InputUtils = require("scripts/managers/input/input_utils")
local ChatManagerConstants = require("scripts/foundation/managers/chat/chat_manager_constants")
local ChannelTags = ChatManagerConstants.ChannelTag

local getChannel = function(channel_tag)
  local channels = Managers.chat:connected_chat_channels()
  if channels then
      for channel_handle, channel in pairs(channels) do
          if channel.tag == channel_tag then
              return channel, channel_handle
          end
      end
  end
end

mod:command("despawn_light", "", function() mod:despawn_light() end)

mod.despawn_light = function()
	if mod.light_unit and Unit.alive(mod.light_unit) then
		World.destroy_unit(Managers.world:world("level_world"), mod.light_unit)
	end

	mod.light_unit = nil
end

---------------------------

function mod.on_setting_changed()
	mod:set("FalloffEnd", math.max(mod:get("FalloffEnd"), mod:get("FalloffStart")))
	if mod.light_unit == nil or not Unit.is_valid(mod.light_unit) then mod:spawn_light() end
	if Unit.is_valid(mod.light_unit) then 
		local light = Unit.light(mod.light_unit, 1)
		d = is_darkness()
		if not light then
			return
		end
		Light.set_volumetric_intensity(light, 0.025)
		Light.set_casts_shadows(light, mod:get("Shadows"))
		Light.set_color_filter(light, Vector3(mod:get("R"),mod:get("G"),mod:get("B")))
		Light.set_type(light, "omni")
		-- Light.set_spot_reflector(light, true)
		Light.set_intensity(light, math.clamp(mod:get("Intensity"), 0, d and 25 or 1000)) --default 20
		Light.set_falloff_start(light, math.clamp(mod:get("FalloffStart"), 0, d and 0 or 800)) --default 12
		Light.set_falloff_end(light, math.clamp(math.max(mod:get("FalloffEnd"), mod:get("FalloffStart")), 0, d and 10 or 800)) --default 12
		Light.set_enabled(light, true)
	end
end

function mod.on_unload()
	mod:despawn_light()
end

-- Respawn flashlight when weapon is switched, since flashlight is auto-despawned every time that happens
mod:hook_safe("ActionWield", "start", function(self, ...)
    -- mod:despawn_light()
    if mod.light_unit == nil or not Unit.is_valid(mod.light_unit) then mod:spawn_light() end
end)

mod:hook_safe("ActionRangedWield", "start", function(self, ...)
    -- mod:despawn_light()
    if mod.light_unit == nil or not Unit.is_valid(mod.light_unit) then mod:spawn_light() end
end)
 
 