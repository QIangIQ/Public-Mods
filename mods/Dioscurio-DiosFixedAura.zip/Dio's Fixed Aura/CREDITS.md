# Dio's Fixed Aura

Original mod: Aura by Seph (Steam: Concoction of Constitution).
Fixes: Dioscurio.

The original mod did not come with a license file. Seph gave Dioscurio permission to redistribute this fixed version (2026-11-20).

This replaces Seph's Aura: it registers under the same mod id ("Aura"). Remove Seph's original Aura folder and its line in mod_load_order.txt before installing this one.
