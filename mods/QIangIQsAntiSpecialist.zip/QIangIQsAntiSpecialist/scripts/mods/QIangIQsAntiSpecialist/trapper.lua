-- Trapper (renegade_netgunner): dodge across the net path, timed to release from the wind-up sound; push first if close.
-- Facts (Aussiemon e46b8926): renegade_netgunner_actions.lua shoot_net aim_duration 0.8333333333333334, net_speed 20,
-- max_net_distance 14; bt_shoot_net_action.lua aims at the target until release, then the net flies straight;
-- minion_fx_extension.lua sends the wind-up / interrupt / shot sounds to every client with the target unit.
-- Same logic as the auto dodge in QIangIQsTrappers; when that mod is enabled with its dodge on, this module stays quiet.

local mod = get_mod("QIangIQsAntiSpecialist")
local Core = mod.core
local M = { breed = "renegade_netgunner" }

local EVENT_WINDUP = "wwise/events/minions/play_weapon_netgunner_wind_up"
local EVENT_INTERRUPTED = "wwise/events/minions/play_weapon_netgunner_interupted"
local EVENT_SHOOT = "wwise/events/minions/play_weapon_netgunner"
local AIM_DURATION = 0.8333333333333334
local NET_SPEED = 20
local MAX_NET_DISTANCE = 14
local PRIORITY = 30 -- order between the mod's own counters (a design choice, not a game value)

local S = {}
local _deferred_logged = false

function M.refresh()
	S.on = mod:get("trapper_enabled") ~= false
	S.offset = (mod:get("trapper_timing_offset_ms") or 0) / 1000
	S.push = mod:get("trapper_push") ~= false
end

-- QIangIQsTrappers carries the same dodge; never run both.
local function _other_mod_dodges()
	local other = get_mod and get_mod("QIangIQsTrappers")

	if not other or not other:is_enabled() then
		return false
	end

	return other:get("auto_dodge") ~= false
end

local shots = {} -- [trapper unit] = { seen_t, started }

local function _plan(unit, target, t, reactive)
	local me = Core.player()

	if not me then
		return
	end

	if not Core.unit_ok(target) then
		target = Core.target_of(unit)
	end

	if target ~= me then
		return
	end

	if _other_mod_dodges() then
		if not _deferred_logged then
			_deferred_logged = true
			Core.log("Trapper: QIangIQsTrappers is dodging, this module stays off")
		end

		return
	end

	local distance = Vector3.length(Core.flat(Core.position(me) - Core.position(unit)))

	if distance > MAX_NET_DISTANCE + Core.PLAYER_RADIUS then
		return
	end

	-- the server should see the dodge start at release: the aim follows the target until then (bt_shoot_net_action.lua)
	local due = reactive and t or t + AIM_DURATION - Core.reaction_delay() + S.offset
	local p = Core.position(unit)

	shots[unit] = { seen_t = t }

	local dodge = { key = "trapper_dodge_" .. tostring(unit), kind = "dodge", mode = "across", threat = unit,
		lx = p.x, ly = p.y, lz = p.z, due_t = due, priority = PRIORITY, expire_t = due + Core.PRESS_WINDOW(), label = "Trapper dodge" }

	Core.request(dodge)

	if S.push and not reactive and distance <= Core.push_radius(me) then
		local inv = Core.component(me, "inventory")

		-- push only with melee already out: a weapon swap would not finish inside the wind-up
		local delay = Core.push_delay(me)

		if delay and due - t > delay + Core.PUSH_TIME then
			Core.request({ allow_ranged = true, need_hit = true, key = "trapper_push_" .. tostring(unit), kind = "push", threat = unit, interrupt = false,
				due_t = t, priority = PRIORITY - 1, expire_t = t + Core.BLOCK_TIME + Core.PUSH_TIME, label = "Trapper push" })
		end
	end
end

function M.on_wwise(unit, event_name, target, t)
	if not S.on then
		return
	end

	if event_name == EVENT_WINDUP or event_name == EVENT_INTERRUPTED or event_name == EVENT_SHOOT then
		local me = Core.player()

		Core.trace("trapper_sound", { ev_name = event_name:match("[^/]+$"), unit = Core.short(unit), mine = me and target == me and 1 or 0,
			d = me and Vector3.length(Core.flat(Core.position(unit) - Core.position(me))) or -1, rtt = Core.ping() })
	end

	if event_name == EVENT_WINDUP then
		_plan(unit, target, t, false)
	elseif event_name == EVENT_INTERRUPTED then
		Core.cancel("trapper_dodge_" .. tostring(unit))
		shots[unit] = nil
		Core.log("Trapper: wind-up interrupted, dodge cancelled")
	elseif event_name == EVENT_SHOOT then
		-- missed the wind-up (joined late, packet loss): dodge at once
		if not shots[unit] then
			_plan(unit, target, t, true)
		end

		shots[unit] = nil
	end
end

function M.reset()
	for k in pairs(shots) do
		shots[k] = nil
	end

	_deferred_logged = false
end

return M
