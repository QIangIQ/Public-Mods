-- Mutant (cultist_mutant, cultist_mutant_mutator): dodge across its charge.
-- Facts (Aussiemon e46b8926, cultist_mutant_actions.lua and bt_mutant_charger_charge_action.lua):
--   charge speed 8 rising to 12 over 4.5 s; close_distance 5: once close, the mutant records each frame whether its
--   target is dodging, and if it was and the target is off its line (dot < 0.95 within 5 m) it charges past.
--   A dodging target is grabbed only within 0.5 m (dodge_collision_radius); grab dodges get the normal linger (0.25 s
--   for most classes, archetype_dodge_templates.lua). Block and push do nothing against the charge.
--   cultist_mutant_charge_foley.lua: the server sets the game object field trigger_charge_sound to true when the charge
--   is within 20 m of its end; every client reads it.

local mod = get_mod("QIangIQsAntiSpecialist")
local Core = mod.core
local M = {}

local BREEDS = { cultist_mutant = true, cultist_mutant_mutator = true }
local PRIORITY = 35 -- order between the mod's own counters (a design choice, not a game value)
local RANGE = 20 -- the charge sound flag goes up within 20 m (cultist_mutant_charge_foley.lua 18)
local RUN_SPEED = 6 -- breed run_speed, its fastest move outside the charge (cultist_mutant_breed.lua 49)

local S = {}
local handled = setmetatable({}, { __mode = "k" })

function M.refresh()
	S.on = mod:get("mutant_enabled") ~= false
	S.los = mod:get("aggro_los_check") ~= false
	S.dodge_at = mod:get("mutant_dodge_distance") or 5 -- close_distance 5: it records a dodge from here (cultist_mutant_actions.lua 25)
end

function M.update(me, t)
	if not S.on then
		return
	end

	local me_pos = Core.position(me)
	local count, units = Core.enemies_near(me, me_pos, RANGE)
	local rtt = Core.ping()

	for i = 1, count do
		local unit = units[i]

		if Core.unit_ok(unit) and BREEDS[Core.breed_name(unit)] then
			local d, v = Core.track(unit, me_pos, t)
			local h = handled[unit]

			if Core.S.trace then
				Core.sample(unit, Core.breed_name(unit) .. (Core.game_object_field(unit, "trigger_charge_sound") and "+charge_sound" or ""), d, v, t, Core.cached_target(unit, t) == me)
			end

			if h and t - h > 2.1 then -- charge_grab_miss lasts 2.1 s (cultist_mutant_actions.lua 62)
				handled[unit] = nil
				h = nil
			end

			-- charging at me: closing at charge speed, or the charge sound flag is up, and it targets me
			if not h and (v > RUN_SPEED or v > 0 and Core.game_object_field(unit, "trigger_charge_sound")) and Core.cached_target(unit, t) == me then
				local server_d = d - v * Core.reaction_delay()

				-- aggro check like the Trapper's: it is charging me and can see me (same eye ray as its perception,
				-- cultist_mutant_breed.lua 45, 108-114); its charge itself has no line-of-sight condition, so this is
				-- only used to skip a charge that is clearly not coming through (setting aggro_los_check)
				if server_d <= S.dodge_at and not (S.los and Core.minion_sees(unit, me, "j_head", "enemy_aim_target_03", "filter_minion_line_of_sight_check") == false) then
					handled[unit] = t
					local p = Core.position(unit)

					Core.request({ no_camera = true, key = "mutant_" .. tostring(unit), kind = "dodge", mode = "across", threat = unit,
						lx = p.x, ly = p.y, lz = p.z, priority = PRIORITY, due_t = t, expire_t = t + Core.PRESS_WINDOW(), label = "Mutant dodge" })
				end
			end
		end
	end
end

function M.reset()
	for k in pairs(handled) do
		handled[k] = nil
	end
end

return M
