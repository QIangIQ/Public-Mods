-- Pox Hounds (chaos_hound, chaos_armored_hound): push the hound out of its leap, or dodge it.
-- Facts (Aussiemon e46b8926):
--   bt_chaos_hound_leap_action.lua 125-150: while the leap action runs (wind-up included), if the target has pushed and
--   the hound is within 5 m (distance squared < 25), the server applies chaos_hound_push to the hound once (unblockable).
--   The pounce hits a dodging player only within 0.65 m (dodge_collision_radius); dodge linger is 0 against pounce
--   (dodge.lua 116, 155); block does not stop it.
--   chaos_hound_actions.lua: wind-up anim "attack_leap_start" 0.667 s (long leap) or "attack_leap_short" 0.8 s;
--   chaos_hound_settings.lua leap_speed 21; approach speed 10; leap starts under 16 m.
-- Clients receive animation events only as numbers (minion_animation_extension.lua 97-105:
-- index = Unit.animation_event(unit, name), sent with rpc_minion_anim_event; animation_system.lua 115-119).
-- So the wind-up number is learned two ways and saved in the mod's settings:
--   host (solo): Unit.animation_event returns the number for the name, so it is recorded directly;
--   any server: when a leap is seen from the hound's speed, the number that arrived 0.45-1.3 s earlier gets a vote.
-- Until a number is known, the leap is read from the hound's speed (13 m/s or more).

local mod = get_mod("QIangIQsAntiSpecialist")
local Core = mod.core
local M = {}

local BREEDS = { chaos_hound = true, chaos_armored_hound = true }
-- start_duration 0.667 s (long) and start_duration_short 0.8 s (chaos_hound_actions.lua 43-46)
local WINDUP_EVENTS = { attack_leap_start = 0.6666666666666666, attack_leap_short = 0.8 }
local PRIORITY = 40 -- order between the mod's own counters (a design choice, not a game value)
local LEAP_RANGE = 16
local LEAP_SPEED = 21 -- leap_speed (chaos_hound_settings.lua)
local SAVE_KEY = "hound_learned_events"

local S = {}
local handled = setmetatable({}, { __mode = "k" })
local windup_handled = setmetatable({}, { __mode = "k" })
local recent = setmetatable({}, { __mode = "k" }) -- [hound] = { {index, t}, ... } last few anim numbers
local learned = {} -- [breed] = { [index] = windup seconds }
local votes = {} -- [breed] = { [index] = count }

local function _load()
	local saved = mod:get(SAVE_KEY)

	learned = type(saved) == "table" and saved or {}
end

local function _save()
	pcall(mod.set, mod, SAVE_KEY, learned)
end

_load()

function M.refresh()
	S.on = mod:get("hound_enabled") ~= false
	-- faster than the fastest non-leap move: start_move_speed 12 during the long wind-up (chaos_hound_actions.lua 47);
	-- approach, skulk and roam are 10 (93, 159, 218)
	S.leap_speed = mod:get("hound_leap_speed") or 12
	S.push = mod:get("hound_push") ~= false
	S.push_at = mod:get("hound_push_distance") or 5 -- the extra push applies inside 5 m (bt_chaos_hound_leap_action.lua 133)
	S.learn = mod:get("hound_learn_windup") ~= false
	S.los = mod:get("aggro_los_check") ~= false
	-- untuned (no game value exists; set from the tuning log):
	S.vote_extra = (mod:get("untuned_hound_vote_extra_ms") or 100) / 1000
	S.votes_needed = mod:get("untuned_hound_votes_needed") or 3
end

-- keys are strings ("i12") so the saved settings table never turns into an array
local function _known(breed, index)
	return learned[breed] and learned[breed]["i" .. tostring(index)]
end

local function _learn(breed, index, windup, how)
	learned[breed] = learned[breed] or {}

	local key = "i" .. tostring(index)

	if learned[breed][key] == nil then
		learned[breed][key] = windup
		_save()
		Core.log("hound wind-up number %d learned for %s (%s)", index, breed, how)
	end
end

-- Host: the engine call that turns the name into the number the clients get.
local hooked_unit_anim = pcall(mod.hook, mod, Unit, "animation_event", function (func, unit, event_name, ...)
	local index = func(unit, event_name, ...)

	if S.learn and WINDUP_EVENTS[event_name] and type(index) == "number" then
		pcall(function ()
			local breed = Core.breed_name(unit)

			if BREEDS[breed] then
				_learn(breed, index, WINDUP_EVENTS[event_name], "host")
			end
		end)
	end

	return index
end)

M.hooked_host = hooked_unit_anim

local function _on_windup(unit, breed, index, t)
	local me = Core.player()

	-- one reaction per leap; the next leap needs the pounce cooldown, at least 4 s (minion_difficulty_settings.lua 967-973)
	if not me or windup_handled[unit] and t - windup_handled[unit] < 4 then
		return
	end

	if Core.cached_target(unit, t) ~= me then
		return
	end

	-- aggro check like the Trapper's: the hound leaps only with line of sight to its target
	if S.los and Core.minion_sees(unit, me, "j_head", "enemy_aim_target_03", "filter_minion_line_of_sight_check") == false then
		Core.trace("hound_no_los", { unit = Core.short(unit), at = "wind-up" })

		return
	end

	local me_pos = Core.position(me)
	local d = Vector3.length(Core.flat(Core.position(unit) - me_pos))

	if d > LEAP_RANGE + 1 then
		return
	end

	windup_handled[unit] = t

	local rtt = Core.ping()
	local windup = _known(breed, index) or 0.6666666666666666
	local key = "hound_" .. tostring(unit)

	Core.log("hound wind-up seen at %.1f m", d)

	-- the push check runs during the wind-up too, so push now if it is already close
	-- the extra push needs only a push within 5 m, any weapon with a push, no facing (bt_chaos_hound_leap_action.lua 125-150)
	if S.push and Core.push_action(me) and d <= S.push_at then
		handled[unit] = t
		Core.request({ no_camera = true, allow_ranged = true, key = key, kind = "push", threat = unit, interrupt = false, priority = PRIORITY, due_t = t, expire_t = t + Core.BLOCK_TIME + Core.PUSH_TIME, label = "Hound push (wind-up)" })

		return
	end

	-- otherwise be dodging when it arrives: arrival = wind-up + distance / 21 m/s; the dodge lasts 0.4 s
	-- (archetype_dodge_templates.lua 5) and pounce dodges get no linger, so arrival is put in the middle of it
	if not (S.push and Core.push_action(me)) then
		local due = t + windup + d / LEAP_SPEED - Core.reaction_delay() - 0.2
		local p = Core.position(unit)

		handled[unit] = t
		Core.request({ no_camera = true, key = key, kind = "dodge", mode = "across", threat = unit, lx = p.x, ly = p.y, lz = p.z,
			priority = PRIORITY, due_t = due, expire_t = due + Core.PRESS_WINDOW(), label = "Hound dodge (wind-up)" })
	end
end

local function _on_anim(unit, index, t)
	if not S.on or type(index) ~= "number" or not Core.unit_ok(unit) then
		return
	end

	local breed = Core.breed_name(unit)

	if not BREEDS[breed] then
		return
	end

	local list = recent[unit]

	if not list then
		list = {}
		recent[unit] = list
	end

	list[#list + 1] = { index, t }

	local me = Core.player()

	if me then
		local d = Vector3.length(Core.flat(Core.position(unit) - Core.position(me)))

		if d <= LEAP_RANGE then
			Core.trace("anim", { breed = breed, unit = Core.short(unit), idx = index, d = d, mine = Core.cached_target(unit, t) == me and 1 or 0, known = _known(breed, index) and 1 or 0 })
		end
	end

	if #list > 8 then -- memory of the last few numbers per hound (storage size only)
		table.remove(list, 1)
	end

	if _known(breed, index) then
		_on_windup(unit, breed, index, t)
	end
end

mod:hook_require("scripts/extension_systems/animation/animation_system", function (AnimationSystem)
	mod:hook_safe(AnimationSystem, "rpc_minion_anim_event", function (self, channel_id, unit_id, event_index)
		local ok, err = pcall(function ()
			local spawner = Managers.state and Managers.state.unit_spawner
			local unit = spawner and spawner:unit(unit_id)
			local t = Core.time()

			if unit and t and mod:is_enabled() then
				_on_anim(unit, event_index, t)
			end
		end)

		if not ok then
			Core.report("anim hook", err)
		end
	end)
end)

-- A leap seen from speed: the number that came 0.45-1.3 s before it is probably the wind-up.
local function _vote(unit, breed, t)
	if not S.learn or (learned[breed] and next(learned[breed])) then
		return
	end

	local list = recent[unit]

	if not list then
		return
	end

	local v = votes[breed] or { leaps = 0, count = {} }

	votes[breed] = v
	v.leaps = v.leaps + 1

	-- one vote per number per leap
	local seen = {}

	for _, e in ipairs(list) do
		local dt = t - e[2]

		-- wind-up to leap speed is 0.667 s (long) or 0.8 s (short) (chaos_hound_actions.lua 43-44); vote_extra is untuned
		if dt >= 0.6666666666666666 and dt <= 0.8 + S.vote_extra and not seen[e[1]] then
			seen[e[1]] = true
			v.count[e[1]] = (v.count[e[1]] or 0) + 1
		end
	end

	-- adopt only a clear winner (untuned rule): in votes_needed or more leaps, and in more leaps than any other number twice over
	local best, best_n, second_n = nil, 0, 0

	for index, n in pairs(v.count) do
		if n > best_n then
			best, best_n, second_n = index, n, best_n
		elseif n > second_n then
			second_n = n
		end
	end

	if best and best_n >= S.votes_needed and best_n >= 2 * second_n then
		_learn(breed, best, 0.6666666666666666, "learned from " .. best_n .. " of " .. v.leaps .. " leaps")
	end
end

function M.update(me, t)
	if not S.on then
		return
	end

	local me_pos = Core.position(me)
	local count, units = Core.enemies_near(me, me_pos, LEAP_RANGE)
	local rtt = Core.ping()

	for i = 1, count do
		local unit = units[i]
		local breed = Core.unit_ok(unit) and Core.breed_name(unit)

		if BREEDS[breed] then
			local d, v = Core.track(unit, me_pos, t)
			local h = handled[unit]

			Core.sample(unit, breed, d, v, t, Core.cached_target(unit, t) == me)

			if h and t - h > 4 then -- pounce cooldown at least 4 s
				handled[unit] = nil
				h = nil
			end

			-- leaping at me: target is me and it closes in faster than it can run
			if v >= S.leap_speed and Core.cached_target(unit, t) == me
				and not (S.los and Core.minion_sees(unit, me, "j_head", "enemy_aim_target_03", "filter_minion_line_of_sight_check") == false) then
				if not recent[unit] or not recent[unit].voted or t - recent[unit].voted > 2 then
					_vote(unit, breed, t)

					if recent[unit] then
						recent[unit].voted = t
					end
				end

				if not h then
					-- where the server will have it when my input arrives: it is ahead of my view by about one round trip
					local server_d = d - v * Core.reaction_delay()
					local key = "hound_" .. tostring(unit)

					local push_delay = S.push and Core.push_delay(me)

					if push_delay and server_d - v * push_delay <= S.push_at and server_d > 0 then
						handled[unit] = t
						Core.request({ no_camera = true, allow_ranged = true, key = key, kind = "push", threat = unit, interrupt = false, priority = PRIORITY,
							due_t = t, expire_t = t + Core.BLOCK_TIME + Core.PUSH_TIME, label = "Hound push" })
					elseif not push_delay and server_d / v <= 0.2 then -- arrival inside the first half of the 0.4 s dodge
						handled[unit] = t
						local p = Core.position(unit)

						Core.request({ no_camera = true, key = key, kind = "dodge", mode = "across", threat = unit, lx = p.x, ly = p.y, lz = p.z,
							priority = PRIORITY, due_t = t, expire_t = t + Core.PRESS_WINDOW(), label = "Hound dodge" })
					end
				end
			end
		end
	end
end

function M.forget()
	learned = {}
	votes = {}
	_save()
	mod:echo("Hound wind-up numbers forgotten; they will be learned again.")
end

function M.status()
	local parts = {}

	for breed, map in pairs(learned) do
		for key in pairs(map) do
			parts[#parts + 1] = string.format("%s %s", breed, tostring(key):sub(2))
		end
	end

	return #parts > 0 and table.concat(parts, ", ") or "none learned yet"
end

function M.reset()
	for k in pairs(handled) do
		handled[k] = nil
	end

	for k in pairs(windup_handled) do
		windup_handled[k] = nil
	end
end

return M
