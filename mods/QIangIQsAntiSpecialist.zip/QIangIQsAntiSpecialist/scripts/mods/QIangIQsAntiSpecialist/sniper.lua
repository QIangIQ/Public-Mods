-- Sniper (renegade_sniper): dodge once the scope flash shows, inside the game's dodge window.
-- Facts (Aussiemon e46b8926, bt_sniper_shoot_action.lua and renegade_sniper_actions.lua):
--   once the laser has been on the target long enough, the server plays the scope flash and sets
--   dodge_window = shoot_at_t = t + 0.45 + lag compensation (scope_reflection_timing_before_shooting 0.45, :444; :287-288);
--   while t < dodge_window, if the target is dodging (attack_types.ranged), the aim freezes at its last seen position and
--   the hitscan shot goes there (:313-320, 339-374). A dodge before the flash does not count.
--   The flash sound "wwise/events/weapon/play_special_sniper_flash" (:445) is sent only to the target:
--   a remote player gets rpc_trigger_wwise_event with the scope position (:266-269), handled by
--   FxSystem.rpc_trigger_wwise_event on that client; a host player gets it played locally (:270-274).
--   Ranged dodges get no linger unless a buff adds it (dodge.lua 146-161), so the dodge state itself must be on in the window.

local mod = get_mod("QIangIQsAntiSpecialist")
local Core = mod.core
local M = {}

local BREED = "renegade_sniper"
local FLASH_EVENT = "wwise/events/weapon/play_special_sniper_flash"
local PRIORITY = 45 -- order between the mod's own counters (a design choice, not a game value)
local MAX_DISTANCE = 150 -- sniper max_distance (renegade_sniper_actions.lua)

local S = {}
local last_t = -100

function M.refresh()
	S.on = mod:get("sniper_enabled") ~= false
end

-- the nearest sniper that targets me, for the dodge line when the flash comes without a position
local function _sniper_targeting_me(me, t)
	local count, units = Core.enemies_near(me, Core.position(me), MAX_DISTANCE)
	local best, best_d = nil, math.huge

	for i = 1, count do
		local u = units[i]

		if Core.unit_ok(u) and Core.breed_name(u) == BREED and Core.cached_target(u, t) == me then
			local d = Vector3.length(Core.flat(Core.position(u) - Core.position(me)))

			if d < best_d then
				best, best_d = u, d
			end
		end
	end

	return best
end

local function _on_flash(position)
	if not S.on or not mod:is_enabled() then
		return
	end

	local me = Core.player()
	local t = Core.time()

	if not me or not t or t - last_t < 0.45 then
		return
	end

	last_t = t

	local sniper = _sniper_targeting_me(me, t)
	local from = position or sniper and Core.position(sniper)

	Core.trace("sniper_flash", { has_pos = position and 1 or 0, sniper = sniper and Core.short(sniper) or "-", rtt = Core.ping(),
		d = from and Vector3.length(Core.flat(from - Core.position(me))) or -1 })

	if not from then
		Core.log("Sniper flash with no sniper found: no dodge")

		return
	end

	-- dodge at once: the window opens at the flash and the shot comes 0.45 s (plus lag compensation) later
	Core.request({ key = "sniper", kind = "dodge", mode = "across", threat = sniper, lx = from.x, ly = from.y, lz = from.z,
		priority = PRIORITY, due_t = t, expire_t = t + Core.PRESS_WINDOW(), label = "Sniper dodge" })
end

-- client: the flash arrives as rpc_trigger_wwise_event with the scope position
mod:hook_require("scripts/extension_systems/fx/fx_system", function (FxSystem)
	mod:hook_safe(FxSystem, "rpc_trigger_wwise_event", function (self, channel_id, event_id, optional_position)
		local ok, err = pcall(function ()
			local lookup = rawget(_G, "NetworkLookup")
			local name = lookup and lookup.sound_events and lookup.sound_events[event_id]

			if name == FLASH_EVENT then
				_on_flash(optional_position and Vector3(optional_position.x, optional_position.y, optional_position.z) or nil)
			end
		end)

		if not ok then
			Core.report("sniper rpc hook", err)
		end
	end)
end)

-- host: the flash is played straight through WwiseWorld.trigger_resource_event
M.hooked_host = pcall(mod.hook_safe, mod, WwiseWorld, "trigger_resource_event", function (wwise_world, event_name)
	if event_name == FLASH_EVENT then
		local ok, err = pcall(_on_flash, nil)

		if not ok then
			Core.report("sniper host hook", err)
		end
	end
end)

function M.reset()
	last_t = -100
end

return M
