-- QIangIQsAntiSpecialist: counters specials for the local player on any server.
--   Trapper: dodge across the net at release (wind-up sound, ping-timed); push first if close with melee out.
--   Poxburster: push it before it reaches you, then dodge away (idea from AntiBursterPush by josef0464).
--   Pox Hound: push it out of its leap, or dodge it.
--   Mutant: dodge across its charge.
-- Each enemy is its own file; core.lua holds the input, path checks and the dodge and push routines.
-- Mods doing the same job are respected: QIangIQsTrappers' dodge and AntiBursterPush switch the matching module off.

local mod = get_mod("QIangIQsAntiSpecialist")

mod.core = mod:io_dofile("QIangIQsAntiSpecialist/scripts/mods/QIangIQsAntiSpecialist/core")

local Core = mod.core

Core.MinionPerception = require("scripts/utilities/minion_perception")

local modules = {}
local names = { "trapper", "burster", "hound", "mutant", "sniper" }

for _, name in ipairs(names) do
	local ok, m = pcall(mod.io_dofile, mod, "QIangIQsAntiSpecialist/scripts/mods/QIangIQsAntiSpecialist/" .. name)

	if ok and type(m) == "table" then
		modules[name] = m
	else
		mod:error("%s module did not load: %s", name, tostring(m))
	end
end

mod.modules = modules -- for the status commands and the offline harness

local function _refresh()
	Core.refresh()

	for _, m in pairs(modules) do
		pcall(m.refresh)
	end
end

_refresh()

mod.on_setting_changed = _refresh

local function _other_enabled(name)
	local other = get_mod and get_mod(name)

	return other and other:is_enabled() or false
end

local function _reset()
	Core.reset()

	for _, m in pairs(modules) do
		pcall(m.reset)
	end
end

-- Trapper sounds reach every client with the target unit (minion_fx_extension.lua 95-105, 148-154).
mod:hook_require("scripts/extension_systems/fx/minion_fx_extension", function (MinionFxExtension)
	mod:hook_safe(MinionFxExtension, "_trigger_inventory_wwise_event", function (self, event_name, inventory_slot_name, fx_source_name, optional_target_unit)
		local trapper = modules.trapper

		if not trapper or not mod:is_enabled() or type(event_name) ~= "string" then
			return
		end

		local ok, err = pcall(function ()
			local unit = self._unit

			if Core.unit_ok(unit) and Core.breed_name(unit) == trapper.breed then
				local t = Core.time()

				if t then
					trapper.on_wwise(unit, event_name, optional_target_unit, t)
				end
			end
		end)

		if not ok then
			Core.report("wwise hook", err)
		end
	end)
end)

local _skip_burster_logged = false

-- Outcome log: every change of the player's character state or disable, with what disabled them.
local _last_state, _last_disable = nil, nil

local function _watch_outcome(me)
	local cs = Core.component(me, "character_state")
	local ds = Core.component(me, "disabled_character_state")
	local state = cs and cs.state_name
	local disable = ds and ds.disabling_type

	if state ~= _last_state or disable ~= _last_disable then
		local by = ds and ds.disabling_unit
		local by_breed = Core.unit_ok(by) and Core.breed_name(by) or "-"
		local d = Core.unit_ok(by) and Vector3.length(Core.flat(Core.position(me) - Core.position(by))) or -1

		Core.trace("player_state", { state = state or "-", disable = disable or "-", by = by_breed, by_d = d })
		_last_state, _last_disable = state, disable
	end
end

local function _update(dt)
	if not mod:is_enabled() then
		return
	end

	local me = Core.player()
	local t = Core.time()

	if me and t then
		pcall(_watch_outcome, me)
	end

	if me and t and Core.can_act(me) then
		for name, m in pairs(modules) do
			if m.update then
				if name == "burster" and _other_enabled("AntiBursterPush") then
					if not _skip_burster_logged then
						_skip_burster_logged = true
						Core.log("AntiBursterPush is on: Poxburster module stays off")
					end
				else
					local ok, err = pcall(m.update, me, t)

					if not ok then
						Core.report(name, err)
					end
				end
			end
		end
	end

	Core.update()
end

function mod.update(dt)
	local ok, err = pcall(_update, dt)

	if not ok then
		Core.reset()
		Core.report("update", err)
	end
end

mod.on_disabled = _reset
mod.on_unload = _reset

mod.on_game_state_changed = function (status, state_name)
	_reset()
	_skip_burster_logged = false
	_last_state, _last_disable = nil, nil
	Core.trace("game_state", { status = status or "-", state = state_name or "-", rtt = Core.ping() })
end

mod:command("antispecialist_status", "Show which counters are on and what the mod is doing.", function ()
	local parts = {}

	for _, name in ipairs(names) do
		parts[#parts + 1] = string.format("%s %s", name, modules[name] and (mod:get(name .. "_enabled") ~= false and "on" or "off") or "not loaded")
	end

	mod:echo(string.format("%s | busy %s | ping %d ms | input hook %s", table.concat(parts, ", "), tostring(Core.busy()), Core.ping() * 1000, Core.hooked and "ok" or "failed"))

	if modules.hound then
		mod:echo("hound wind-up numbers: " .. modules.hound.status())
	end
end)

mod:command("antispecialist_forget_hounds", "Forget the learned hound wind-up animation numbers (after a game patch).", function ()
	if modules.hound then
		modules.hound.forget()
	end
end)
