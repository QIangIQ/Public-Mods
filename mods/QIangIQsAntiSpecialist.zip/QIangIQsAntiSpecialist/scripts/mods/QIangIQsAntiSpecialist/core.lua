-- QIangIQsAntiSpecialist core: made-up input, path checks, and the dodge and push routines every module uses.
-- Game facts are from Aussiemon/Darktide-Source-Code e46b8926 (see the Datavault note darktide-dodge-direction-rules):
--   Dodge.check: no dodge while sprinting; local move with y <= 0 dodges exactly along it, y > 0 needs |x| > 0.707
--   and then dodges straight sideways; only the walking state starts a dodge.
--   human_unit_input.lua: move = (move_right - move_left, move_forward - move_backward).
--   player_character_state_dodging.lua 394-396: the dodge direction is local and turned by the view every frame.
--   archetype_dodge_templates.lua: 2.5 m in 0.4 s (zealot 2.75 m). Push = block, then attack (action_push).
-- Push timings follow AntiBursterPush by josef0464 (block 0.10 s, push input 0.15 s); this file is written from scratch.

local mod = get_mod("QIangIQsAntiSpecialist")
local Core = {}

-- ---------------------------------------------------------------------------
-- Settings shared by all modules (refreshed by the main script)
-- ---------------------------------------------------------------------------

Core.S = {}

function Core.refresh()
	local S = Core.S

	S.camera_mode = mod:get("camera_mode") or "when_needed"
	S.restore_camera = mod:get("restore_camera") ~= false
	S.ledge = mod:get("ledge_protection") ~= false
	S.max_drop = mod:get("max_drop") or 4 -- warning_height 4 (player_character_constants.lua 878)
	S.body_block = mod:get("body_block_check") ~= false
	S.face_push = mod:get("face_push_target") ~= false
	S.restore_weapon = mod:get("restore_weapon") ~= false
	-- off unless chosen: it taps the ranged weapon to cancel a swing, a forced swap mid-horde
	S.interrupt_swing = mod:get("interrupt_swing") == true
	-- "if_no_push": swap to melee only when the equipped weapon has no push at all; "never": never swap
	S.swap_policy = mod:get("swap_policy") or "if_no_push"
	S.ping = mod:get("ping_compensation") ~= false
	S.debug = mod:get("debug_log") == true
	S.trace = mod:get("trace_log") ~= false
end

-- ---------------------------------------------------------------------------
-- Helpers
-- ---------------------------------------------------------------------------

local _last_error_t = -100

function Core.real_time()
	local tm = Managers.time

	if tm and tm:has_timer("main") then
		return tm:time("main")
	end

	if Application.time_since_launch then
		return Application.time_since_launch()
	end

	return 0
end

function Core.time()
	local tm = Managers.time

	if tm and tm:has_timer("gameplay") then
		return tm:time("gameplay")
	end

	return nil
end

function Core.report(where, err)
	local now = Core.real_time()

	if now - _last_error_t > 10 then
		_last_error_t = now
		mod:error("%s: %s", where, tostring(err))
	end
end

-- Chat message (Debug log setting); every message also goes to the tuning log as ev=note. Defined after Core.trace.

-- Tuning log: one line per event in the game's log, "AntiSpecialist|t=12.345|ev=plan|key=value|...".
-- Read back after a game to replace untuned values with measured ones.
local function _fmt(v)
	if type(v) == "number" then
		return string.format("%.3f", v)
	end

	return tostring(v)
end

function Core.trace(ev, fields)
	if not Core.S.trace then
		return
	end

	local parts = { "AntiSpecialist", "t=" .. _fmt(Core.time() or -1), "ev=" .. ev }

	if fields then
		local keys = {}

		for k in pairs(fields) do
			keys[#keys + 1] = k
		end

		table.sort(keys)

		for _, k in ipairs(keys) do
			parts[#parts + 1] = k .. "=" .. _fmt(fields[k])
		end
	end

	pcall(mod.info, mod, table.concat(parts, "|"))
end

function Core.log(fmt, ...)
	local ok, msg = pcall(string.format, fmt, ...)

	msg = ok and msg or tostring(fmt)

	if Core.S.debug then
		mod:echo("[AntiSpecialist] " .. msg)
	end

	Core.trace("note", { msg = msg:gsub("|", "/") })
end

function Core.short(unit)
	return tostring(unit):sub(-6)
end

-- Movement samples of a special that is after me (or close), at most every 0.1 s per unit.
local _sample_t = setmetatable({}, { __mode = "k" })

function Core.sample(unit, breed, d, v, t, mine)
	if not Core.S.trace then
		return
	end

	local last = _sample_t[unit]

	if last and t - last < 0.1 and t >= last then -- log rate only, not a game value
		return
	end

	_sample_t[unit] = t
	Core.trace("sample", { breed = breed, unit = Core.short(unit), d = d, v = v, mine = mine and 1 or 0 })
end

function Core.unit_ok(unit)
	return type(unit) == "userdata" and Unit.alive(unit)
end

-- Unit.world_position, not POSITION_LOOKUP: in game its entries were stale handles ("Vector3 expected, got userdata",
-- 21,000+ errors in one run, 2026-11-07). See lesson-position-lookup-stale-handle.
function Core.position(unit)
	return Unit.world_position(unit, 1)
end

function Core.flat(v)
	return Vector3(v.x, v.y, 0)
end

local _breed_cache = setmetatable({}, { __mode = "k" })

function Core.breed_name(unit)
	local cached = _breed_cache[unit]

	if cached ~= nil then
		return cached or nil
	end

	local ext = ScriptUnit.has_extension(unit, "unit_data_system")

	if not ext then
		return nil
	end

	local ok, breed = pcall(ext.breed, ext)

	if not ok or not breed then
		return nil -- not ready yet: do not cache
	end

	_breed_cache[unit] = breed.name or false

	return breed.name
end

function Core.component(unit, name)
	local ext = ScriptUnit.has_extension(unit, "unit_data_system")

	return ext and ext:read_component(name) or nil
end

-- Local player, only once a level is running (calling into the player manager earlier can crash the engine,
-- as noted in AntiBursterPush).
function Core.player()
	local pm = Managers.player
	local st = Managers.state

	if not pm or not st or not st.extension then
		return nil, nil
	end

	local player = pm.local_player_safe and pm:local_player_safe(1) or pm:local_player(1)
	local unit = player and player.player_unit

	if not Core.unit_ok(unit) then
		return nil, player
	end

	return unit, player
end

function Core.ping()
	if not Core.S.ping then
		return 0
	end

	local cm = Managers.connection
	local host = cm and cm.host and cm:host()

	if not host or not Network or not Network.ping then
		return 0
	end

	local ok, rtt = pcall(Network.ping, host)

	if not ok or type(rtt) ~= "number" then
		return 0
	end

	return math.max(rtt, 0)
end

-- Fixed step: 1 / tick rate (state_gameplay.lua 32-34; default tick_rate 52, default_game_parameters.lua 17).
function Core.fixed_step()
	local cm = Managers.connection
	local ok, rate = pcall(function ()
		return cm and cm.tick_rate and cm:tick_rate()
	end)

	rate = ok and type(rate) == "number" and rate > 0 and rate or 52

	return 1 / rate
end

-- How far behind the server a reaction lands, from the client's view: what I see is half a round trip old
-- (adaptive_clock_handler_client.lua 88 uses rtt * 0.5), and my input runs on the server half a round trip plus at
-- least BUFFER_MIN = 2 fixed frames later (adaptive_clock_handler_server.lua 4, 58).
function Core.reaction_delay()
	return Core.ping() + 2 * Core.fixed_step()
end

-- Player body radius used by the game for minion contact (player_unit_locomotion_extension.lua 252).
Core.PLAYER_RADIUS = 0.7

-- A minion's contact radius (breed.player_locomotion_constrain_radius, player_unit_locomotion_extension.lua 266).
function Core.body_radius(unit)
	local ext = ScriptUnit.has_extension(unit, "unit_data_system")
	local ok, breed = pcall(function ()
		return ext and ext:breed()
	end)

	return ok and breed and breed.player_locomotion_constrain_radius or Core.PLAYER_RADIUS
end

-- Dodge length: archetype base_distance (archetype_dodge_templates.lua, used at player_character_state_dodging.lua 208)
-- times the largest weapon distance scale 1.1 (weapon_dodge_templates.lua default lerp_perfect).
function Core.dodge_distance(me)
	local ext = ScriptUnit.has_extension(me, "unit_data_system")
	local ok, arch = pcall(function ()
		return ext and ext:archetype()
	end)
	local base = ok and arch and arch.dodge and arch.dodge.base_distance or 2.5

	return base * 1.1
end

-- Push radius of the wielded weapon (action_push.push_radius; read the template as weapon_template.lua 6-8 does).
-- push_attack.lua 33-36: a sphere of that radius about 1 m in front of the player.
local _WeaponTemplate = nil

function Core.push_radius(me)
	if not _WeaponTemplate then
		local ok, wt = pcall(require, "scripts/utilities/weapon/weapon_template")

		_WeaponTemplate = ok and wt or false
	end

	local radius = nil

	if _WeaponTemplate then
		local ok, template = pcall(_WeaponTemplate.current_weapon_template, Core.component(me, "weapon_action"))
		local push = ok and template and template.actions and template.actions.action_push

		radius = push and push.push_radius
	end

	return radius or 2.5 -- combatsword_p1_m1.lua 1126, the most common value
end

function Core.target_of(unit)
	local gsm = Managers.state and Managers.state.game_session
	local spawner = Managers.state and Managers.state.unit_spawner

	if not gsm or not spawner or not Core.MinionPerception then
		return nil
	end

	local ok, session = pcall(gsm.game_session, gsm)
	local ok2, go_id = pcall(spawner.game_object_id, spawner, unit)

	if not ok or not session or not ok2 or not go_id then
		return nil
	end

	local ok3, target = pcall(Core.MinionPerception.target_unit, session, go_id)

	return ok3 and target or nil
end

function Core.physics_world()
	local world = Application.main_world()

	if not world then
		return nil
	end

	local ok, pw = pcall(World.physics_world, world)

	return ok and pw or nil
end

-- Enemies near a point (broadphase works on clients: husk minions have BroadphaseExtension).
local _query = {}

function Core.enemies_near(me_unit, pos, radius)
	local manager = Managers.state and Managers.state.extension
	local side_system = manager and manager:system("side_system")
	local broadphase_system = manager and manager:system("broadphase_system")
	local side = side_system and side_system.side_by_unit[me_unit]
	local broadphase = broadphase_system and broadphase_system.broadphase

	if not side or not broadphase then
		return 0, _query
	end

	local ok, count = pcall(broadphase.query, broadphase, pos, radius, _query, side:relation_side_names("enemy"))

	return ok and count or 0, _query
end


local BLOCK_TIME_FOR_DELAY = 0.10 -- block before a melee push, AntiBursterPush BLOCK_TIME

-- The wielded weapon's push action and the input that starts it.
--   melee: actions.action_push, started by block + attack (default_melee_action_input_setup.lua: push = action_one_pressed
--   while action_two_hold);
--   ranged: the weapon's special action when it is a push (laspistol_p1_m1.lua 929 special_action_name =
--   "action_normal_push", input special_action_push = weapon_extra_pressed, 106-114; flamer_p1_m1.lua 446-451).
function Core.push_action(me)
	if _WeaponTemplate == nil or _WeaponTemplate == false then
		Core.push_radius(me) -- loads the helper
	end

	if not _WeaponTemplate then
		return nil
	end

	local ok, template = pcall(_WeaponTemplate.current_weapon_template, Core.component(me, "weapon_action"))

	if not ok or not template or not template.actions then
		return nil
	end

	local slot = Core.wielded(me)

	if slot == "slot_primary" then
		local push = template.actions.action_push

		return push and push.kind == "push" and push or nil, nil
	end

	local name = template.special_action_name
	local action = name and template.actions[name]

	if action and action.kind == "push" and action.start_input and template.action_inputs then
		local def = template.action_inputs[action.start_input]
		local seq = def and def.input_sequence and def.input_sequence[1]

		return action, seq and seq.input or nil
	end

	return nil
end

function Core.push_delay(me)
	local action, input = Core.push_action(me)

	if not action then
		return nil
	end

	return (input and 0 or BLOCK_TIME_FOR_DELAY) + (action.damage_time or 0)
end

-- Would a push now hit this unit? push_attack.lua 33-80: a sphere of push_radius centred 1 m ahead of the push
-- position (player position + forward x push_offset, action_push.lua 85-86), and the flat angle from the push
-- position to the unit must be within outer_push_rad (any unit closer than 0.99 m flat counts as inside).
-- lead: metres the unit closes in before the push lands on the server (closing speed x delay)
function Core.push_would_hit(me, unit, action, player, lead)
	if not action or not Core.unit_ok(unit) then
		return false
	end

	local o = player and player:get_orientation()
	local yaw = o and o.yaw or 0
	local fwd = Quaternion.forward(Quaternion.from_yaw_pitch_roll(yaw, 0, 0))
	local me_pos = Core.position(me)
	local push_pos = me_pos + fwd * (action.push_offset or 0)
	local centre = push_pos + fwd
	local target = Core.position(unit)

	if lead and lead > 0 then
		local toward = Core.flat(me_pos - target)

		if Vector3.length(toward) > lead then
			target = target + Vector3.normalize(toward) * lead
		end
	end

	if Vector3.length(Core.flat(target - centre)) > (action.push_radius or 2.5) then
		return false
	end

	local flat = Core.flat(target - push_pos)

	if Vector3.length(flat) < 0.99 then
		return true
	end

	local cos_angle = Vector3.dot(Vector3.normalize(flat), fwd)

	return cos_angle >= math.cos(action.outer_push_rad or math.pi)
end

-- Line of sight the way a minion checks it (minion_perception_extension.lua 547-600): from its from_node to the
-- target's to_node, three rays offset sideways by 0, +0.125 and -0.125 m (perception_settings.lua 6-10); any clear
-- ray is sight. Hound and Mutant: j_head to enemy_aim_target_03, filter_minion_line_of_sight_check (breed 44, 108-114).
local LOS_OFFSETS = { 0, 0.125, -0.125 }

local _minion_sees

function Core.minion_sees(unit, target, from_node, to_node, filter)
	-- nil when it cannot be checked; an error never stops the caller
	local ok, result = pcall(_minion_sees, unit, target, from_node, to_node, filter)

	if not ok then
		return nil
	end

	return result
end

_minion_sees = function (unit, target, from_node, to_node, filter)
	local pw = Core.physics_world()

	if not pw or not Core.unit_ok(unit) or not Core.unit_ok(target) then
		return nil
	end

	if not Unit.has_node(unit, from_node) or not Unit.has_node(target, to_node) then
		return nil
	end

	local from = Unit.world_position(unit, Unit.node(unit, from_node))
	local to = Unit.world_position(target, Unit.node(target, to_node))
	local delta = to - from
	local right = Vector3.normalize(Vector3.cross(delta, Vector3.up()))

	for _, off in ipairs(LOS_OFFSETS) do
		local v = delta + Vector3(right.x * off, right.y * off, 0)
		local hit = PhysicsWorld.raycast(pw, from, Vector3.normalize(v), Vector3.length(v), "all", "types", "both", "collision_filter", filter)

		if not hit then
			return true
		end
	end

	return false
end

-- Closing speed toward the player from the unit's networked position (numbers only: a stored Vector3 goes stale).
local _track = setmetatable({}, { __mode = "k" })

function Core.track(unit, me_pos, t)
	local p = Core.position(unit)
	local dx, dy = p.x - me_pos.x, p.y - me_pos.y
	local d = math.sqrt(dx * dx + dy * dy)
	local rec = _track[unit]

	if not rec then
		_track[unit] = { t = t, d = d, v = 0 }

		return d, 0
	end

	local dt = t - rec.t

	-- raw closing speed over at least one fixed step, no smoothing (any smoothing would be an invented value)
	if dt >= Core.fixed_step() then
		rec.v = (rec.d - d) / dt
		rec.t, rec.d = t, d
	elseif dt < 0 then
		rec.t, rec.d, rec.v = t, d, 0
	end

	return d, rec.v
end

function Core.closing_speed(unit)
	local rec = unit and _track[unit]

	return rec and math.max(rec.v, 0) or 0
end

-- MinionPerception.target_unit per unit, looked up at most once per fixed step
local _target_cache = setmetatable({}, { __mode = "k" })

function Core.cached_target(unit, t)
	local c = _target_cache[unit]

	if c and t - c.t < Core.fixed_step() and t >= c.t then
		return c.target
	end

	local target = Core.target_of(unit)

	_target_cache[unit] = { t = t, target = target }

	return target
end

function Core.game_object_field(unit, field)
	local gsm = Managers.state and Managers.state.game_session
	local spawner = Managers.state and Managers.state.unit_spawner

	if not gsm or not spawner then
		return nil
	end

	local ok, session = pcall(gsm.game_session, gsm)
	local ok2, go_id = pcall(spawner.game_object_id, spawner, unit)

	if not ok or not session or not ok2 or not go_id then
		return nil
	end

	local ok3, value = pcall(GameSession.game_object_field, session, go_id, field)

	return ok3 and value or nil
end

function Core.wielded(me)
	local inv = Core.component(me, "inventory")

	return inv and inv.wielded_slot
end

-- states in which the mod may act; anything else (netted, grabbed, knocked down, ladder, minigame ...) means hands off
local ACT_STATES = { walking = true, sprinting = true, dodging = true, sliding = true, jumping = true, falling = true }

function Core.can_act(me)
	local cs = Core.component(me, "character_state")

	return cs and ACT_STATES[cs.state_name] or false, cs and cs.state_name
end

-- ---------------------------------------------------------------------------
-- Made-up input: only for the "Ingame" service, expires on the main clock
-- ---------------------------------------------------------------------------

local inject = {}
local inject_until = 0
local wield_pressed = false
-- Safety limits, not game values (they only stop made-up input from outliving a routine; listed in the reply):
-- the longest routine is a push swap (SWAP_TIMEOUT 1.5 s, AntiBursterPush) plus block 0.10 s and push 0.15 s.
local MAX_INJECT = 1.5 + 0.10 + 0.15

local WIELD_ACTIONS = {
	quick_wield = true, wield_1 = true, wield_2 = true, wield_3 = true, wield_4 = true, wield_5 = true,
	wield_scroll_down = true, wield_scroll_up = true,
}

local function _clear()
	for k in pairs(inject) do
		inject[k] = nil
	end

	inject_until = 0
end

local function _active()
	if inject_until == 0 then
		return false
	end

	if Core.real_time() > inject_until then
		_clear()

		return false
	end

	return true
end

-- Values are set again every frame by the running routine; they lapse shortly after the last set
-- (MAX_INJECT caps one long routine), so nothing stays held if updates stop.
local inject_started = 0

function Core.set(action, value)
	local now = Core.real_time()

	if inject_until == 0 then
		inject_started = now
	end

	inject[action] = value
	inject_until = math.min(now + 3 * Core.fixed_step(), inject_started + MAX_INJECT) -- lapses 3 fixed steps after the last set (safety limit)

	if WIELD_ACTIONS[action] then
		Core.last_own_wield = now
	end
end

-- guarantee_weapon_swap (installed, also a QIangIQsGuaranteeSuite module) replays an unfinished wield request every
-- 0.05 s, and a replay looks like a real press (noted in AntiBursterPush). Presses this soon after our own wield are ignored.
local WIELD_GRACE = 0.35
Core.last_own_wield = -100

local function _wipe_values()
	for k in pairs(inject) do
		inject[k] = nil
	end
end

function Core.set_move(x, y)
	Core.set("move_right", math.max(x, 0))
	Core.set("move_left", math.max(-x, 0))
	Core.set("move_forward", math.max(y, 0))
	Core.set("move_backward", math.max(-y, 0))
	Core.set("sprinting", false)
	Core.set("sprint", false)
end

function Core.clear_input()
	_clear()
end

-- The mod's own wield presses go through `inject`; a real press by the player cancels everything.
local function _input_hook(func, self, action_name)
	-- also while a routine waits with melee out and injects nothing, so a real wield press still cancels it
	if self.type == "Ingame" and (inject_until ~= 0 or Core.busy and Core.busy()) then
		local ok, value = pcall(function ()
			if not _active() then
				return nil
			end

			return inject[action_name]
		end)

		if ok and value ~= nil then
			return value
		end

		if WIELD_ACTIONS[action_name] then
			local raw = func(self, action_name)

			if raw and Core.real_time() - Core.last_own_wield > WIELD_GRACE then
				wield_pressed = true
			end

			return raw
		end
	end

	return func(self, action_name)
end

local hooked, hook_err = pcall(mod.hook, mod, CLASS.InputService, "_get", _input_hook)

Core.hooked = hooked

if not hooked then
	mod:error("could not hook InputService._get: %s", tostring(hook_err))
end

function Core.take_wield_press()
	local w = wield_pressed

	wield_pressed = false

	return w
end

-- ---------------------------------------------------------------------------
-- Path checks
-- ---------------------------------------------------------------------------

-- Sizes from the game: body radius 0.7 (player_unit_locomotion_extension.lua 252); minion contact radius per breed;
-- the dodge length from the archetype; the widest dodge radius among the threats is the hound's 0.65 m
-- (chaos_hound_settings.lua dodge_collision_radius), so a wall closer than 0.7 + 0.65 m stops the dodge too early.
local WALL_CLEAR = Core.PLAYER_RADIUS + 0.65

-- Ground under the path, probed every body radius out to the full dodge length. The ray starts max_drop above the
-- player's feet and reaches max_drop below them; no ground in that range means a drop larger than max_drop.
local function _ground_z(pw, point, base_z)
	local from = Vector3(point.x, point.y, base_z + Core.S.max_drop)
	local hit, position = PhysicsWorld.raycast(pw, from, Vector3.down(), 2 * Core.S.max_drop, "closest", "types", "statics", "collision_filter", "filter_player_mover")

	return hit and position and position.z or nil
end

-- ignore: a unit that may stand in the path (the threat itself when dodging away from it)
function Core.path_safe(me_unit, me_pos, dir, ignore)
	local S = Core.S
	local pw = Core.physics_world()
	local length = Core.dodge_distance(me_unit)

	if not pw then
		return not S.ledge and not S.body_block, "no physics world"
	end

	if S.ledge then
		local step = Core.PLAYER_RADIUS

		while step <= length + 1e-6 do
			local p = me_pos + dir * step
			local z = _ground_z(pw, p, me_pos.z)

			if not z or z < me_pos.z - S.max_drop then
				return false, string.format("ledge at %.1f m", step)
			end

			step = step + Core.PLAYER_RADIUS
		end
	end

	if S.body_block then
		-- one ray at body-radius height (a single height is a choice, not a game value; see the tuning log)
		local hit, _, distance = PhysicsWorld.raycast(pw, me_pos + Vector3(0, 0, Core.PLAYER_RADIUS), dir, length, "closest", "types", "statics", "collision_filter", "filter_player_mover")

		if hit and distance and distance < WALL_CLEAR then
			return false, string.format("wall at %.1f m", distance)
		end

		local count, units = Core.enemies_near(me_unit, me_pos, length + Core.PLAYER_RADIUS)
		local blockers = {}

		for i = 1, count do
			blockers[#blockers + 1] = units[i]
		end

		local pm = Managers.player
		local ok_p, players = pcall(pm.players, pm)

		if ok_p and players then
			for _, player in pairs(players) do
				if player.player_unit ~= me_unit then
					blockers[#blockers + 1] = player.player_unit
				end
			end
		end

		for _, unit in ipairs(blockers) do
			if unit ~= ignore and Core.unit_ok(unit) then
				local rel = Core.flat(Core.position(unit) - me_pos)
				local along = Vector3.dot(rel, dir)
				local reach = Core.PLAYER_RADIUS + Core.body_radius(unit)

				if along > 0 and along < length and Vector3.length(rel - dir * along) < reach then
					return false, string.format("body in the way at %.1f m", along)
				end
			end
		end
	end

	return true
end

-- ---------------------------------------------------------------------------
-- Choosing a dodge direction
-- ---------------------------------------------------------------------------

local function _yaw_basis(yaw)
	local rot = Quaternion.from_yaw_pitch_roll(yaw, 0, 0)

	return Quaternion.right(rot), Quaternion.forward(rot)
end

-- What Dodge.check does with a wanted world direction at this yaw: move x, y, the real world direction, exact?
local function _resolve(dir, yaw)
	local right, forward = _yaw_basis(yaw)
	local x, y = Vector3.dot(dir, right), Vector3.dot(dir, forward)

	if y <= 0 then
		return x, y, dir, true
	end

	if math.abs(x) > 0.707 then
		local sx = x > 0 and 1 or -1

		return sx, 0, right * sx, false
	end

	return nil
end

-- line_from: a point on the threat's line (its position); mode "across" = 90 degrees to the line from it to me,
-- "away" = straight away first, then away-diagonals. Returns x, y, real_dir, new_yaw | nil, reason
-- no_camera: never turn the view (the owner's rule for hound, Poxburster and Mutant)
function Core.choose_dodge(me_unit, player, line_from, mode, ignore, no_camera)
	local S = Core.S
	local me_pos = Core.position(me_unit)
	local away = Core.flat(me_pos - line_from)

	if Vector3.length(away) < 0.01 then
		return nil, "on top of the threat"
	end

	away = Vector3.normalize(away)

	local p1 = Vector3(-away.y, away.x, 0)
	local p2 = -p1
	-- Fallback angle and minimum share are the game's own sideways limit:
	-- Dodge.check dodges straight sideways only when |x| > 0.707 (dodge.lua 70-90).
	local c45 = 0.707
	local candidates, lateral_axis, min_score

	if mode == "away" then
		candidates = { away, away * c45 + p1 * c45, away * c45 + p2 * c45, p1, p2 }
		lateral_axis, min_score = nil, 0 -- never toward it
	else
		candidates = { p1, p2, p1 * c45 + away * c45, p2 * c45 + away * c45 }
		lateral_axis, min_score = p1, c45 - 1e-3
	end

	local orientation = player:get_orientation()
	local yaw = orientation and orientation.yaw or 0
	local reasons = {}

	-- among the first two, the one reachable without a camera turn goes first
	local _, _, _, exact1 = _resolve(candidates[1], yaw)
	local _, _, _, exact2 = _resolve(candidates[2], yaw)

	if not exact1 and exact2 then
		candidates[1], candidates[2] = candidates[2], candidates[1]
	end

	for _, wanted in ipairs(candidates) do
		local x, y, real, exact = _resolve(wanted, yaw)
		local new_yaw = nil

		-- turn the camera whenever the wanted direction cannot be dodged exactly from this view
		if not exact and S.camera_mode == "when_needed" and not no_camera then
			local _, fwd = _yaw_basis(yaw)
			local f_right = Vector3.cross(Vector3.up(), wanted)
			local use_right = Vector3.dot(f_right, fwd) >= Vector3.dot(-f_right, fwd)
			local new_fwd = use_right and f_right or -f_right

			new_yaw = Quaternion.yaw(Quaternion.look(new_fwd, Vector3.up()))
			x, y, real = use_right and 1 or -1, 0, wanted
		end

		if x then
			local score = lateral_axis and math.abs(Vector3.dot(real, lateral_axis)) or Vector3.dot(real, away)

			if score >= min_score then
				local safe, why = Core.path_safe(me_unit, me_pos, real, ignore)

				if safe then
					return x, y, real, new_yaw
				end

				reasons[#reasons + 1] = why
			end
		end
	end

	return nil, table.concat(reasons, ", ")
end

-- ---------------------------------------------------------------------------
-- Routines: one runs at a time; a request with a higher priority can replace one that has not pressed yet
-- ---------------------------------------------------------------------------

-- Dodge routine, in fixed steps (Core.fixed_step):
--   the move goes in one step early: sprinting ends in the same fixed frame that reads move y <= 0
--   (player_character_state_sprinting.lua 383, 286-297), and only walking starts a dodge;
--   dodge is pressed until the dodge state starts, for up to the dodge cooldown (dodge_cooldown 0.2,
--   archetype_dodge_templates.lua) plus 2 steps of input buffer (BUFFER_MIN, adaptive_clock_handler_server.lua 4);
--   the move is held one step after the dodge starts.
local function PRE_MOVE() return Core.fixed_step() end
local function PRESS_WINDOW() return 0.2 + 2 * Core.fixed_step() end
local function HOLD_AFTER_START() return Core.fixed_step() end
-- Push routine timings from AntiBursterPush by josef0464: SWAP_TIMEOUT 1.5, RESTORE_TIMEOUT 1.5, INTERRUPT_TIME 0.12,
-- BLOCK_TIME 0.10, PUSH_TIME 0.15.
local SWAP_TIMEOUT = 1.5
local INTERRUPT_TIME = 0.12
local BLOCK_TIME = 0.10
local PUSH_TIME = 0.15
local RESTORE_TIMEOUT = 1.5
Core.BLOCK_TIME, Core.PUSH_TIME, Core.PRESS_WINDOW = BLOCK_TIME, PUSH_TIME, PRESS_WINDOW

local queue = {} -- pending requests by key
local current = nil
local camera_restore = nil

-- req = { key, kind = "dodge" | "push", due_t, priority, threat (unit), line_from (x, y, z numbers),
--         mode ("across" | "away"), expire_t, label }
function Core.has(key)
	return queue[key] ~= nil or current ~= nil and current.key == key
end

-- after the player cancels with a wield key, no new weapon-swapping push for a while (dodges still run)
local suppress_push_until = -100

function Core.request(req)
	if current and current.key == req.key then
		return
	end

	if req.kind == "push" and (Core.time() or 0) < suppress_push_until then
		return
	end

	queue[req.key] = req
	Core.log("%s planned in %d ms", req.label or req.kind, ((req.due_t or 0) - (Core.time() or 0)) * 1000)
	Core.trace("plan", { what = req.label or req.kind, kind = req.kind, due_in = (req.due_t or 0) - (Core.time() or 0), prio = req.priority, why = req.why or "-" })
end

function Core.cancel(key)
	queue[key] = nil

	if current and current.key == key and not current.pressed then
		current = nil
		Core.clear_input()
	end
end

function Core.busy()
	return current ~= nil
end

local function _restore_camera_now()
	local r = camera_restore

	camera_restore = nil

	if r and r.player then
		local o = r.player:get_orientation()

		r.player:set_orientation(r.yaw, o and o.pitch or 0, o and o.roll or 0)
	end
end

function Core.reset()
	for k in pairs(queue) do
		queue[k] = nil
	end

	current = nil
	pcall(_restore_camera_now)
	Core.clear_input()
	wield_pressed = false
	suppress_push_until = -100 -- a cancel sets it again right after this reset
end

local function _face(player, me, target)
	local delta = Core.flat(Core.position(target) - Core.position(me))

	if Vector3.length(delta) < 0.05 then
		return
	end

	local o = player:get_orientation()
	local yaw = Quaternion.yaw(Quaternion.look(Vector3.normalize(delta), Vector3.up()))

	player:set_orientation(yaw, o and o.pitch or 0, o and o.roll or 0)
end

local function _start_dodge(r, me, player)
	local line_from = Vector3(r.lx, r.ly, r.lz)

	if r.threat and Core.unit_ok(r.threat) then
		line_from = Core.position(r.threat)
	end

	local x, y, real, new_yaw = Core.choose_dodge(me, player, line_from, r.mode, r.threat, r.no_camera)

	if not x then
		Core.log("%s: no safe dodge (%s)", r.label or "dodge", tostring(y))

		return false
	end

	if new_yaw then
		local o = player:get_orientation()

		if Core.S.restore_camera and o then
			r.restore_yaw = o.yaw
		end

		player:set_orientation(new_yaw, o and o.pitch or 0, o and o.roll or 0)
	end

	r.mx, r.my, r.phase = x, y, "move"

	local mp = Core.position(me)

	Core.trace("dodge_chosen", { what = r.label or "dodge", mode = r.mode, x = x, y = y, snap = new_yaw and 1 or 0,
		d = Vector3.length(Core.flat(mp - line_from)), wx = real.x, wy = real.y })

	return true
end

local function _run_dodge(r, t, me, player, state_name)
	local movement = Core.component(me, "movement_state")
	local dodging = movement and movement.is_dodging or state_name == "dodging"

	Core.set_move(r.mx, r.my)

	if r.phase == "move" and t >= r.due_t then
		r.phase = "press"
	end

	if r.phase == "press" then
		if dodging then
			r.phase, r.started_t, r.pressed = "started", t, true
			inject.dodge = nil
			Core.log("%s: dodge started %d ms after plan", r.label or "dodge", (t - r.due_t) * 1000)

			local threat_d = r.threat and Core.unit_ok(r.threat) and Vector3.length(Core.flat(Core.position(me) - Core.position(r.threat))) or -1

			Core.trace("dodge_started", { what = r.label or "dodge", late = t - r.due_t, threat_d = threat_d, rtt = Core.ping() })

			if r.restore_yaw then
				camera_restore = { player = player, yaw = r.restore_yaw, t = t }
			end
		elseif t > r.due_t + PRESS_WINDOW() then
			Core.log("%s: the game refused the dodge", r.label or "dodge")

			return true
		else
			Core.set("dodge", true)
		end
	elseif r.phase == "started" and t > r.started_t + HOLD_AFTER_START() then
		return true
	end

	return false
end

local _wielded = Core.wielded

local function _run_push(r, t, me, player)
	local slot = _wielded(me)

	r.phase = r.phase or "swap"
	r.phase_t = r.phase_t or t

	if r.phase == "swap" then
		if not r.saved then
			r.saved = slot

			if slot ~= "slot_primary" and slot ~= "slot_secondary" then
				Core.log("%s: not holding a weapon, skipped", r.label or "push")

				return true
			end

			r.interrupt = slot == "slot_primary" and Core.S.interrupt_swing and r.interrupt ~= false
		end

		if r.interrupt then
			if t - r.phase_t < INTERRUPT_TIME then
				Core.set("wield_2", true)

				return false
			end

			r.interrupt = false
			r.phase_t = t
		end

		-- a ranged weapon with its own push (laspistol): no swap, push with its input
		local action, input = nil, nil

		if slot == "slot_secondary" and r.allow_ranged and not r.ranged_failed then
			action, input = Core.push_action(me)
		end

		if action and input then
			r.ranged_input, r.ranged_action = input, action
			r.phase, r.phase_t = r.wait_fn and "wait" or "ranged_check", t
		elseif slot == "slot_secondary" and not r.swapping and (Core.S.swap_policy == "never" or r.ranged_failed or Core.push_action(me)) then
			-- equipped weapon first: no swap when it has a push that misses, or when swapping is off
			Core.log("%s: no push with this weapon, no swap", r.label or "push")
			Core.trace("push_skipped", { what = r.label or "push", why = r.ranged_failed and "outside the cone" or "no swap allowed" })

			if r.then_dodge then
				r.then_dodge.due_t = t
				Core.request(r.then_dodge)
			end

			return true
		elseif slot == "slot_primary" then
			-- optional wait with melee out until the threat is close enough (wait_fn), then block
			r.phase, r.phase_t = r.wait_fn and "wait" or "block", t
		elseif t - r.phase_t > SWAP_TIMEOUT then
			Core.log("%s: weapon swap timed out", r.label or "push")
			r.swapping = nil
			r.phase, r.phase_t = "restore", t
		else
			-- the equipped ranged weapon has no push at all: the only swap the mod makes
			r.swapping = true
			Core.set("wield_1", true)

			return false
		end
	end

	if r.phase == "wait" then
		local expected = r.ranged_input and "slot_secondary" or "slot_primary"

		if slot ~= expected then
			r.phase, r.phase_t = "swap", t

			return false
		end

		local ok, ready = pcall(r.wait_fn, t)

		if ok and ready == "abort" or t - r.phase_t > (r.wait_timeout or 10) then -- WAIT_TIMEOUT 10 s, AntiBursterPush
			r.phase, r.phase_t = "restore", t
		elseif ok and ready then
			r.phase, r.phase_t = r.ranged_input and "ranged_check" or "block", t
		end

		return false
	end

	if r.phase == "ranged_check" then
		-- the laspistol push is a narrow cone (laspistol_p1_m1.lua 562-563: 7 and 18 degrees); when the push must land
		-- and it would not, swap to melee instead (the melee push reaches 180 degrees, combatsword_p1_m1.lua 1168)
		local lead = Core.closing_speed(r.threat) * (Core.reaction_delay() + (r.ranged_action.damage_time or 0))

		if r.need_hit and not Core.push_would_hit(me, r.threat, r.ranged_action, player, lead) then
			-- outside the cone: no swap to melee (the owner's rule); the swap phase hands over to the dodge
			r.ranged_failed, r.ranged_input = true, nil
			r.phase, r.phase_t = "swap", t
			Core.trace("ranged_push_skipped", { what = r.label or "push", why = "outside the cone" })
		else
			r.phase, r.phase_t = "ranged_push", t
		end

		return false
	end

	if r.phase == "ranged_push" then
		r.pressed = true
		Core.set(r.ranged_input, true)

		if t - r.phase_t >= PUSH_TIME then
			r.phase = "push_done"
		else
			return false
		end
	end

	if r.phase == "block" then
		Core.set("action_two_hold", true)

		if Core.S.face_push and not r.no_camera and Core.unit_ok(r.threat) then
			_face(player, me, r.threat)
		end

		if t - r.phase_t >= BLOCK_TIME then
			r.phase, r.phase_t = "push", t
		end

		return false
	end

	if r.phase == "push" or r.phase == "push_done" then
		r.pressed = true

		if r.phase == "push" then
			Core.set("action_two_hold", true)
			Core.set("action_one_hold", true)
			Core.set("action_one_pressed", true)

			if Core.S.face_push and not r.no_camera and Core.unit_ok(r.threat) then
				_face(player, me, r.threat)
			end
		end

		if r.phase == "push_done" or t - r.phase_t >= PUSH_TIME then
			Core.log("%s: pushed%s", r.label or "push", r.ranged_input and " (ranged weapon push)" or "")
			Core.trace("pushed", { what = r.label or "push", threat_d = Core.unit_ok(r.threat) and Vector3.length(Core.flat(Core.position(me) - Core.position(r.threat))) or -1,
				took = t - (r.started_at or t), rtt = Core.ping() })

			if r.then_dodge then
				-- dodge straight after the push; the weapon goes back once the dodge is done
				r.then_dodge.due_t = t
				Core.request(r.then_dodge)

				if r.saved ~= "slot_primary" then
					Core.request({ key = r.key .. "_restore", kind = "restore", saved = r.saved, priority = 0, due_t = t + 0.4, expire_t = t + 0.4 + RESTORE_TIMEOUT, label = "weapon back" }) -- after the 0.4 s dodge (archetype_dodge_templates.lua 5)
				end

				return true
			end

			r.phase, r.phase_t = "restore", t
		end

		return false
	end

	if r.phase == "restore" then
		if not Core.S.restore_weapon or not r.saved or r.saved == slot or t - r.phase_t > RESTORE_TIMEOUT then
			return true
		end

		Core.set(r.saved == "slot_secondary" and "wield_2" or "wield_1", true)

		return false
	end

	return true
end

local function _run_restore(r, t, me)
	local slot = _wielded(me)

	r.phase_t = r.phase_t or t
	r.pressed = true

	if not Core.S.restore_weapon or not r.saved or r.saved == slot or t - r.phase_t > RESTORE_TIMEOUT then
		return true
	end

	Core.set(r.saved == "slot_secondary" and "wield_2" or "wield_1", true)

	return false
end

function Core.update()
	local t = Core.time()

	if camera_restore then
		local me = Core.player()
		local movement = me and Core.component(me, "movement_state")
		local cs = me and Core.component(me, "character_state")
		local still = movement and movement.is_dodging or cs and cs.state_name == "dodging"

		-- back once the dodge state has ended; safety cap of two dodge times (0.4 s, archetype_dodge_templates.lua 5)
		if not me or t and (not still and t >= camera_restore.t or t >= camera_restore.t + 0.8) then
			_restore_camera_now()
		end
	end

	if not current and not next(queue) then
		if inject_until ~= 0 then
			_active()
		end

		return
	end

	local me, player = Core.player()

	if not t or not me then
		Core.reset()

		return
	end

	if Core.take_wield_press() and current then
		Core.log("you switched weapons: cancelled")
		Core.reset()
		suppress_push_until = t + 0.4 + WIELD_GRACE -- AntiBursterPush: cooldown 0.4 s after a takeover, plus its 0.35 s wield grace

		return
	end

	local ok_state, state_name = Core.can_act(me)

	if not ok_state then
		Core.reset()

		return
	end

	-- drop expired requests
	for key, r in pairs(queue) do
		if r.expire_t and t > r.expire_t and r ~= current then
			queue[key] = nil
		end
	end

	-- pick the next routine: highest priority whose start time has come; it may replace one that has not pressed
	local best

	for _, r in pairs(queue) do
		local lead = r.kind == "dodge" and PRE_MOVE() or 0

		if r ~= current and t >= (r.due_t or t) - lead and (not best or r.priority > best.priority) then
			best = r
		end
	end

	if best and (not current or not current.pressed and best.priority > current.priority) then
		if current then
			Core.log("%s replaced by %s", current.label or current.kind, best.label or best.kind)
			queue[current.key] = nil

			if current.restore_yaw then
				camera_restore = { player = player, yaw = current.restore_yaw, t = t }
			end

			Core.clear_input()
		end

		current = best
		best.started_at = t
		Core.trace("start", { what = best.label or best.kind, late = t - (best.due_t or t), state = state_name, slot = Core.wielded(me) })

		if best.kind == "dodge" then
			local walking_ok = state_name == "walking" or state_name == "sprinting" or state_name == "dodging"

			if not walking_ok or not _start_dodge(best, me, player) then
				queue[best.key] = nil
				current = nil
			end
		end
	end

	local r = current

	if r then
		local done

		-- the running routine sets every value it wants again this frame
		_wipe_values()

		if r.kind == "dodge" then
			done = _run_dodge(r, t, me, player, state_name)
		elseif r.kind == "restore" then
			done = _run_restore(r, t, me)
		else
			done = _run_push(r, t, me, player)
		end

		if done then
			queue[r.key] = nil
			current = nil
			Core.clear_input()
		end
	end
end

return Core
