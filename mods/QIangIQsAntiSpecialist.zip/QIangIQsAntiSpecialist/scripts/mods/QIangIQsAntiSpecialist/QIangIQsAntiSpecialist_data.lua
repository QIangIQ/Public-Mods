local mod = get_mod("QIangIQsAntiSpecialist")

local function checkbox(id, default)
	return { setting_id = id, type = "checkbox", default_value = default, tooltip = id .. "_tooltip" }
end

local function numeric(id, default, low, high, decimals)
	return { setting_id = id, type = "numeric", default_value = default, range = { low, high }, decimals_number = decimals or 0, tooltip = id .. "_tooltip" }
end

local function group(id, widgets)
	return { setting_id = id, type = "group", sub_widgets = widgets }
end

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			{
				setting_id = "toggle_key",
				type = "keybind",
				default_value = {},
				keybind_trigger = "pressed",
				keybind_type = "mod_toggle",
				tooltip = "toggle_key_tooltip",
			},
			group("group_general", {
				{
					setting_id = "camera_mode",
					type = "dropdown",
					default_value = "when_needed",
					tooltip = "camera_mode_tooltip",
					options = {
						{ text = "camera_never", value = "never" },
						{ text = "camera_when_needed", value = "when_needed" },
					},
				},
				checkbox("restore_camera", true),
				checkbox("ledge_protection", true),
				numeric("max_drop", 4, 1, 7, 1),
				checkbox("body_block_check", true),
				checkbox("face_push_target", true),
				checkbox("interrupt_swing", false),
				{
					setting_id = "swap_policy",
					type = "dropdown",
					default_value = "if_no_push",
					tooltip = "swap_policy_tooltip",
					options = {
						{ text = "swap_if_no_push", value = "if_no_push" },
						{ text = "swap_never", value = "never" },
					},
				},
				checkbox("restore_weapon", true),
				checkbox("ping_compensation", true),
				checkbox("debug_log", false),
				checkbox("trace_log", true),
				checkbox("aggro_los_check", true),
			}),
			group("group_trapper", {
				checkbox("trapper_enabled", true),
				numeric("trapper_timing_offset_ms", 0, -200, 200),
				checkbox("trapper_push", true),
			}),
			group("group_burster", {
				checkbox("burster_enabled", true),
				numeric("burster_detect_range", 8, 4, 15, 1),
				checkbox("burster_pre_swap", false),
				checkbox("burster_dodge_after", true),
			}),
			group("group_hound", {
				checkbox("hound_enabled", true),
				numeric("hound_leap_speed", 12, 10, 21, 1),
				checkbox("hound_push", true),
				numeric("hound_push_distance", 5, 2, 5, 1),
				checkbox("hound_learn_windup", true),
			}),
			group("group_mutant", {
				checkbox("mutant_enabled", true),
				numeric("mutant_dodge_distance", 5, 2, 5, 1),
			}),
			group("group_sniper", {
				checkbox("sniper_enabled", true),
			}),
			group("group_untuned", {
				numeric("untuned_hound_vote_extra_ms", 100, 0, 300),
				numeric("untuned_hound_votes_needed", 3, 2, 8),
			}),
		},
	},
}
