-- Poxburster (chaos_poxwalker_bomber): push it before it reaches you, then dodge away.
-- Idea and push timing from AntiBursterPush by josef0464; written from scratch here. Facts (Aussiemon e46b8926):
--   chaos_poxwalker_bomber_breed.lua 28 always_stagger_on_melee_push = true; run_speed 5 (46)
--   chaos_poxwalker_bomber_actions.lua: lunge when path distance < 6 (enter_lunge_distance) or straight distance < 3;
--   lunge or a melee push sets fuse_timer = t + 1.5 (bt_poxwalker_bomber_approach_action.lua 78, 486)
--   minion_explosion_templates.lua poxwalker_bomber: radius 6, close_radius 3
--   combatsword_p1_m1.lua action_push push_radius 2.5
-- A push does not defuse it: it staggers it back and starts the 1.5 s fuse. Keep moving away after the dodge.

local mod = get_mod("QIangIQsAntiSpecialist")
local Core = mod.core
local M = {}

local BREED = "chaos_poxwalker_bomber"
local PRIORITY = 25 -- order between the mod's own counters (a design choice, not a game value)
local REPUSH = 2.0 -- repush_delay default 2 s, AntiBursterPush
local PUSH_FLOOR = 0.8 -- PUSH_FLOOR 0.8 s, AntiBursterPush
-- a weapon swap takes about 0.5 s (AntiBursterPush README: weapon switch animation about 0.5 s); counted only when the
-- equipped weapon has no push and a swap is the only way
local SWAP_LEAD = 0.5

local S = {}
local pushed_at = setmetatable({}, { __mode = "k" })
local last_push_t = -100
local next_scan_t = 0

function M.refresh()
	S.on = mod:get("burster_enabled") ~= false
	S.detect = mod:get("burster_detect_range") or 8 -- detect_range default 8 m, AntiBursterPush
	S.pre_swap = mod:get("burster_pre_swap") == true -- off by default: it is a swap the moment one is seen
	S.dodge_after = mod:get("burster_dodge_after") ~= false
end

local function _predicted(unit, me_pos, t, rtt)
	local d, v = Core.track(unit, me_pos, t)

	-- the server sees the push about one round trip after the press, plus the 0.1 s block
	return d - math.max(v, 0) * (Core.reaction_delay() + Core.BLOCK_TIME), d, v
end

function M.update(me, t)
	if not S.on or t < next_scan_t then
		return
	end

	next_scan_t = t + 0.10 -- SCAN_INTERVAL 0.10 s, AntiBursterPush

	local me_pos = Core.position(me)
	local count, units = Core.enemies_near(me, me_pos, S.detect)
	local rtt = Core.ping()

	for i = 1, count do
		local unit = units[i]

		if Core.unit_ok(unit) and Core.breed_name(unit) == BREED then
			local predicted, d, v = _predicted(unit, me_pos, t, rtt)
			local mine = Core.cached_target(unit, t) == Core.player()

			Core.sample(unit, BREED, d, v, t, mine)
			local key = "burster_" .. tostring(unit)
			local recent = pushed_at[unit] and t - pushed_at[unit] < REPUSH or t - last_push_t < PUSH_FLOOR

			local push_at = Core.push_radius(me) -- the wielded weapon's push radius (action_push.push_radius)

			-- it targets me, or I am inside its blast radius 6 m whoever it wants (minion_explosion_templates.lua 88-96)
			local needs_swap = Core.push_action(me) == nil
			local lead_pred = needs_swap and predicted - math.max(v, 0) * SWAP_LEAD or predicted

			if not recent and not Core.has(key) and (mine or d < 6) and (v > 0 or d < push_at) then
				local dodge = S.dodge_after and { no_camera = true, key = key .. "_dodge", kind = "dodge", mode = "away", threat = unit,
					lx = 0, ly = 0, lz = 0, priority = PRIORITY + 1, expire_t = t + 10, label = "Poxburster dodge away" } or nil
				local unit_ref = unit

				if lead_pred <= push_at or S.pre_swap then
					Core.request({
						no_camera = true, allow_ranged = true, need_hit = true, key = key, kind = "push", threat = unit, priority = PRIORITY, due_t = t, expire_t = t + 10,
						label = "Poxburster push", then_dodge = dodge, wait_timeout = 10, -- WAIT_TIMEOUT 10 s, AntiBursterPush
						wait_fn = function (now)
							if not Core.unit_ok(unit_ref) then
								return "abort"
							end

							local p = Core.position(unit_ref)
							local m = Core.position(me)
							local pr = _predicted(unit_ref, m, now, Core.ping())

							if pr <= Core.push_radius(me) then
								pushed_at[unit_ref] = now
								last_push_t = now

								return true
							end

							return Vector3.length(Core.flat(p - m)) > S.detect and "abort" or false
						end,
					})
				end
			end
		end
	end
end

function M.reset()
	last_push_t = -100
	next_scan_t = 0
end

return M
