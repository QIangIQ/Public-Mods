return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsAntiSpecialist` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsAntiSpecialist", {
			mod_script       = "QIangIQsAntiSpecialist/scripts/mods/QIangIQsAntiSpecialist/QIangIQsAntiSpecialist",
			mod_data         = "QIangIQsAntiSpecialist/scripts/mods/QIangIQsAntiSpecialist/QIangIQsAntiSpecialist_data",
			mod_localization = "QIangIQsAntiSpecialist/scripts/mods/QIangIQsAntiSpecialist/QIangIQsAntiSpecialist_localization",
		})
	end,
	packages = {},
}
