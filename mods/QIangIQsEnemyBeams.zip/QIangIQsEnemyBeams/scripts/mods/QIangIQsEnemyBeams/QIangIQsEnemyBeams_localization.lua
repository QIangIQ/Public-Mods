return {
	mod_name = {
		en = "QIangIQ's Enemy Beams",
	},
	mod_description = {
		en = "Draws a beam out of every enemy gunner's face so you can see where they are looking, and the flight arc of a hound's pounce while it is in the air. Screen-space lines only (no new world objects). Logs to mods/QIangIQsEnemyBeams/debug.log.",
	},
}
