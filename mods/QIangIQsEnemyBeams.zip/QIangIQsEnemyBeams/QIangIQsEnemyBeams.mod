return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsEnemyBeams` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsEnemyBeams", {
			mod_script       = "QIangIQsEnemyBeams/scripts/mods/QIangIQsEnemyBeams/QIangIQsEnemyBeams",
			mod_data         = "QIangIQsEnemyBeams/scripts/mods/QIangIQsEnemyBeams/QIangIQsEnemyBeams_data",
			mod_localization = "QIangIQsEnemyBeams/scripts/mods/QIangIQsEnemyBeams/QIangIQsEnemyBeams_localization",
		})
	end,
	packages = {},
}
