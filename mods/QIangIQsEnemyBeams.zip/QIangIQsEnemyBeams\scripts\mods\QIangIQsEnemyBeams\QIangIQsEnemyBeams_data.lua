local mod = get_mod("QIangIQsEnemyBeams")

local function checkbox(id, default, title, tooltip)
	return { setting_id = id, type = "checkbox", default_value = default, localize = false, title = title, tooltip = tooltip }
end

local function numeric(id, default, lo, hi, title, tooltip)
	return { setting_id = id, type = "numeric", default_value = default, range = { lo, hi }, decimals_number = 0, localize = false, title = title, tooltip = tooltip }
end

local function opt(text, value)
	return { text = text, value = value, show_widget_localization = false }
end

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			{
				setting_id = "toggle_key",
				type = "keybind",
				default_value = {},
				keybind_trigger = "pressed",
				keybind_type = "function_call",
				function_name = "toggle_beams",
				localize = false,
				title = "Toggle beams (key)",
				tooltip = "Shows or hides every beam and arc.",
			},
			checkbox("show_gunner_beams", true, "Gunner face beams", "A beam out of the face of gunners, riflemen, snipers, shocktroopers, flamers and netgunners."),
			checkbox("show_hound_arcs", true, "Hound pounce arcs", "The flight path of a hound while it is pouncing, plus the path it has flown so far."),
			{
				setting_id = "render_mode",
				type = "dropdown",
				default_value = "world",
				localize = false,
				title = "Drawing",
				tooltip = "World: real lines in the scene (hidden by walls, not on the HUD). HUD: flat screen overlay. If world lines ever crash the game the mod switches itself to HUD on the next start.",
				options = {
					opt("World lines", "world"),
					opt("HUD overlay", "hud"),
				},
			},
			checkbox("show_projected", true, "Projected pounce paths", "Shows every hound's pounce arc toward you while it is still running around, before it leaps."),
			numeric("pounce_range", 25, 5, 60, "Projected arc range (metres)", "Hounds further from you than this get no projected arc."),
			numeric("beam_length", 30, 5, 100, "Beam length (metres)", "How far the face beam reaches."),
			numeric("max_range", 80, 10, 200, "Draw range (metres)", "Enemies further away than this are skipped."),
			numeric("thickness", 3, 1, 8, "Line thickness (pixels)", "Thickness of beams and arcs."),
			{
				setting_id = "beam_source",
				type = "dropdown",
				default_value = "auto",
				localize = false,
				title = "Beam direction",
				tooltip = "auto: learns which way the head bone faces by watching which axis points at you (needs a few gunners in view for a moment, see debug.log), then uses it including up/down. Until learned it uses the body heading. head: the head bone forward axis. body: the body facing, level.",
				options = {
					opt("Auto", "auto"),
					opt("Head bone", "head"),
					opt("Body", "body"),
				},
			},
			numeric("heartbeat_s", 5, 1, 60, "Debug heartbeat (seconds)", "How often a status line is written to debug.log."),
		},
	},
}
