local mod = get_mod("QIangIQsEnemyBeams")

--[[
    ENEMY BEAMS

      * a beam from the face of every enemy gunner along where it is looking;
      * the ballistic arc of a hound's pounce while it is in the air, plus the
        path it has flown.

    By default beams are real scene lines (a LineObject on the level world,
    reset and dispatched each frame from HudElementCrosshair.update). HUD mode
    draws in screen space with Gui.rect (the route proven by QIangIQsSpecialTracer): world points are
    sampled, clipped to the camera's near plane and projected with
    Camera.world_to_screen. No viewports, no world objects, no native calls
    beyond what the tracer already uses.

    Hound pounce arc: the leap is detected from the hound's measured speed
    (the client has no behaviour blackboard); the predicted path integrates
    gravity 13.82 (ChaosHoundSettings) from the current position and velocity.

    Debug: ./../mods/QIangIQsEnemyBeams/debug.log (flushed per line).
--]]

local LOG_PATH = "./../mods/QIangIQsEnemyBeams/debug.log"
local LOG_MAX_BYTES = 512 * 1024

local HOUND_GRAVITY = 13.82
local LEAP_SPEED = 13          -- m/s measured; hounds run at ~9, leap at 21
local LEAP_HOLD = 0.35         -- s the "leaping" flag outlives the speed
local TRAIL_MAX = 40
local MAX_RECTS = 3000
local LAYER = 999
local NEAR = 0.2

local HOUNDS = {
	chaos_hound = true, chaos_armored_hound = true, chaos_hound_mutator = true,
}
local GUNNERS = {
	renegade_gunner = true, cultist_gunner = true, chaos_ogryn_gunner = true,
	renegade_plasma_gunner = true, renegade_rifleman = true, renegade_sniper = true,
	renegade_shocktrooper = true, cultist_shocktrooper = true, renegade_netgunner = true,
	renegade_flamer = true, cultist_flamer = true, renegade_flamer_mutator = true,
}

-- ------------------------------------------------------------- logging --

local log_bytes = 0
local function get_io()
	local mods = rawget(_G, "Mods")
	return mods and mods.lua and mods.lua.io or nil
end

local function dlog(text)
	local line = string.format("[%s] %s\n", tostring(os.date("%H:%M:%S")), text)
	if log_bytes + #line > LOG_MAX_BYTES then
		return
	end
	local io_lib = get_io()
	if not io_lib then
		return
	end
	local f = io_lib.open(LOG_PATH, "a")
	if not f then
		return
	end
	f:write(line)
	f:flush()
	f:close()
	log_bytes = log_bytes + #line
end

local state = {
	hidden = false, frames = 0, errors = 0, last_beat = 0,
	scanned = 0, gunners = 0, hounds = 0, drawn_beams = 0, drawn_arcs = 0, rects = 0,
	first_head = 0,
}
local seen_err = {}
local function derr(tag, err)
	state.errors = state.errors + 1
	local key = tag .. tostring(err)
	if not seen_err[key] and state.errors < 60 then
		seen_err[key] = true
		dlog("ERROR " .. tag .. ": " .. tostring(err))
	end
end

-- ------------------------------------------------------------ geometry --

-- Vector3 values are read into plain numbers immediately; never kept.
local function pos_of(unit, node)
	local ok, x, y, z = pcall(function()
		local v = Unit.world_position(unit, node or 1)
		return v.x, v.y, v.z
	end)
	if ok then return x, y, z end
	return nil
end

local function forward_of(rot)
	local ok, x, y, z = pcall(function()
		local v = Quaternion.forward(rot)
		return v.x, v.y, v.z
	end)
	if ok then return x, y, z end
	return nil
end

local function norm(x, y, z)
	local l = math.sqrt(x * x + y * y + z * z)
	if l < 1e-6 then return nil end
	return x / l, y / l, z / l
end

local function get_cam()
	local lp = Managers.player and Managers.player:local_player_safe(1)
	local vp = lp and lp.viewport_name
	local cm = vp and Managers.state and Managers.state.camera
	if not cm or not cm:has_viewport(vp) then return nil end
	local ok, c = pcall(cm.camera, cm, vp)
	return ok and c or nil
end

local function cam_frame(cam)
	local ok, ox, oy, oz, fx, fy, fz = pcall(function()
		local p = Camera.world_position(cam)
		local f = Quaternion.forward(Camera.world_rotation(cam))
		return p.x, p.y, p.z, f.x, f.y, f.z
	end)
	if ok then return { ox = ox, oy = oy, oz = oz, fx = fx, fy = fy, fz = fz } end
	return nil
end

local function project(cam, x, y, z)
	local ok, sx, sy = pcall(function()
		local s = Camera.world_to_screen(cam, Vector3(x, y, z))
		return s.x, s.y
	end)
	if ok then return sx, sy end
	return nil
end

-- ---------------------------------------------------------------- draw --

local rect_count = 0

local function rect(gui, x, y, w, h, color)
	if rect_count >= MAX_RECTS then return end
	rect_count = rect_count + 1
	Gui.rect(gui, Vector3(x, y, LAYER), Vector2(w, h), color)
end

local function clamp(v, a, b) return v < a and a or (v > b and b or v) end

local function seg2d(gui, x1, y1, x2, y2, th, right, bottom, color)
	local dx, dy = x2 - x1, y2 - y1
	local len = math.sqrt(dx * dx + dy * dy)
	if len < 1e-3 then return end
	local step = th * 0.7
	local n = math.min(math.floor(len / step) + 1, 260)
	for i = 0, n do
		local f = i / n
		local x, y = x1 + dx * f, y1 + dy * f
		if x >= 0 and x <= right and y >= 0 and y <= bottom then
			rect(gui, x - th * 0.5, y - th * 0.5, th, th, color)
		end
	end
end

-- World segment -> clipped to the near plane -> projected -> drawn.
local function seg3d(gui, cam, F, ax, ay, az, bx, by, bz, th, right, bottom, color)
	local da = (ax - F.ox) * F.fx + (ay - F.oy) * F.fy + (az - F.oz) * F.fz
	local db = (bx - F.ox) * F.fx + (by - F.oy) * F.fy + (bz - F.oz) * F.fz
	if da < NEAR and db < NEAR then return end
	if da < NEAR then
		local t = (NEAR - da) / (db - da)
		ax, ay, az = ax + (bx - ax) * t, ay + (by - ay) * t, az + (bz - az) * t
	elseif db < NEAR then
		local t = (NEAR - db) / (da - db)
		bx, by, bz = bx + (ax - bx) * t, by + (ay - by) * t, bz + (az - bz) * t
	end
	local x1, y1 = project(cam, ax, ay, az)
	local x2, y2 = project(cam, bx, by, bz)
	if x1 and x2 then
		seg2d(gui, x1, y1, x2, y2, th, right, bottom, color)
	end
end

-- ----------------------------------------------------- world line object --

-- World mode: a LineObject on the level world, reset and re-dispatched each
-- frame, so beams are real scene lines (hidden by walls, no HUD). HUD mode
-- (fallback) projects the same segments to the screen.
local GUARD_PATH = "./../mods/QIangIQsEnemyBeams/crash_guard.txt"
local world_state = { world = nil, lo = nil, ok = true, stable = 0, armed = false }
local ctx = { world = false }

local function guard_write(text, mode)
	local io_lib = get_io()
	local f = io_lib and io_lib.open(GUARD_PATH, mode or "w")
	if f then f:write(text) f:flush() f:close() end
end

local function guard_read()
	local io_lib = get_io()
	local f = io_lib and io_lib.open(GUARD_PATH, "r")
	if not f then return nil end
	local txt = f:read("*a")
	f:close()
	return txt
end

local function world_destroy()
	local w, lo = world_state.world, world_state.lo
	world_state.world, world_state.lo = nil, nil
	if w and lo then
		pcall(function()
			LineObject.reset(lo)
			LineObject.dispatch(w, lo)
			World.destroy_line_object(w, lo)
		end)
	end
end

local function world_begin()
	local wm = Managers.world
	local w = wm and wm:has_world("level_world") and wm:world("level_world")
	if not w then return false end
	if world_state.world ~= w then
		world_destroy()
		if not world_state.armed then
			guard_write("WORLD_LINES armed " .. os.date("%H:%M:%S") .. "\n")
			world_state.armed = true
		end
		world_state.lo = World.create_line_object(w)
		world_state.world = w
		dlog("line object created on level_world")
	end
	LineObject.reset(world_state.lo)
	return true
end

local function world_end()
	LineObject.dispatch(world_state.world, world_state.lo)
	world_state.stable = world_state.stable + 1
	if world_state.armed == true and world_state.stable == 300 then
		guard_write("CLEAR stable " .. os.date("%H:%M:%S") .. "\n")
		world_state.armed = "cleared"
		dlog("world lines stable for 300 frames, crash guard cleared")
	end
end

local function emit(ax, ay, az, bx, by, bz, th, color)
	if ctx.world then
		local lo = world_state.lo
		local a = Vector3(ax, ay, az)
		local b = Vector3(bx, by, bz)
		LineObject.add_line(lo, color, a, b)
		-- thickness: extra parallel lines offset sideways and up
		local n = math.floor((th or 3) / 2)
		if n > 0 then
			local dx, dy = bx - ax, by - ay
			local l = math.sqrt(dx * dx + dy * dy)
			local px, py = 0, 0
			if l > 1e-4 then px, py = -dy / l, dx / l end
			local off = 0.012 * n
			for _, o in ipairs({ { px * off, py * off, 0 }, { -px * off, -py * off, 0 }, { 0, 0, off }, { 0, 0, -off } }) do
				LineObject.add_line(lo, color, Vector3(ax + o[1], ay + o[2], az + o[3]), Vector3(bx + o[1], by + o[2], bz + o[3]))
			end
		end
	else
		seg3d(ctx.gui, ctx.cam, ctx.F, ax, ay, az, bx, by, bz, th, ctx.right, ctx.bottom, color)
	end
end

-- ------------------------------------------------------------- tracking --

local tracked = {}     -- unit -> { kind, breed, ... }
local last_scan = -10

local function unit_breed(unit)
	local ok, ext = pcall(ScriptUnit.has_extension, unit, "unit_data_system")
	if not ok or not ext or not ext.breed then return nil end
	local ok2, breed = pcall(ext.breed, ext)
	if not ok2 or type(breed) ~= "table" then return nil end
	return breed
end

local function unit_alive(unit)
	if not Unit.alive(unit) then return false end
	local ok, ext = pcall(ScriptUnit.has_extension, unit, "health_system")
	if ok and ext and ext.is_alive then
		local ok2, a = pcall(ext.is_alive, ext)
		if ok2 and a == false then return false end
	end
	return true
end

local function scan(now)
	local ext = Managers.state and Managers.state.extension
	if not ext then return end
	local entities = ext:get_entities("MinionHuskLocomotionExtension")
	if next(entities) == nil then
		entities = ext:get_entities("MinionLocomotionExtension")
	end
	local seen, g, h, n = {}, 0, 0, 0
	for unit in pairs(entities) do
		n = n + 1
		local breed = unit_breed(unit)
		local name = breed and breed.name
		local kind = name and ((HOUNDS[name] and "hound") or (GUNNERS[name] and "gunner"))
		if kind and unit_alive(unit) then
			seen[unit] = true
			local e = tracked[unit]
			if not e then
				e = { kind = kind, breed = name, trail = {}, leaping = false, leap_until = 0 }
				tracked[unit] = e
				dlog(string.format("track %s (%s)", kind, name))
			end
			if kind == "hound" then h = h + 1 else g = g + 1 end
		end
	end
	for unit in pairs(tracked) do
		if not seen[unit] then tracked[unit] = nil end
	end
	state.scanned, state.gunners, state.hounds = n, g, h
end

-- ------------------------------------------------------------ gunners --

local calib = { score = { 0, 0, 0 }, n = 0, done = false }

local function face_dir(unit, source)
	local node
	pcall(function()
		if Unit.has_node(unit, "j_head") then node = Unit.node(unit, "j_head") end
	end)
	local hx, hy, hz = pos_of(unit, node or 1)
	if not hx then return nil end

	local bx, by, bz
	local okb, rot_b = pcall(Unit.world_rotation, unit, 1)
	if okb then bx, by, bz = forward_of(rot_b) end

	local dx, dy, dz
	if (source == "auto" or source == "head") and node and ctx.F then
		-- Head-bone axis calibration: which signed local axis of the head bone
		-- points at the player on average (gunners mostly look at the player).
		local okh, rot_h = pcall(Unit.world_rotation, unit, node)
		local axes
		if okh then
			local oka, ax = pcall(function()
				local f, r, u = Quaternion.forward(rot_h), Quaternion.right(rot_h), Quaternion.up(rot_h)
				return { { f.x, f.y, f.z }, { r.x, r.y, r.z }, { u.x, u.y, u.z } }
			end)
			if oka then axes = ax end
		end
		if axes then
			local tx, ty, tz = ctx.F.ox - hx, ctx.F.oy - hy, (ctx.F.oz - 0.3) - hz
			local tl = math.sqrt(tx * tx + ty * ty + tz * tz)
			if not calib.done and tl > 4 and tl < 35 then
				for k = 1, 3 do
					local v = axes[k]
					calib.score[k] = calib.score[k] + (v[1] * tx + v[2] * ty + v[3] * tz) / tl
				end
				calib.n = calib.n + 1
				if calib.n % 50 == 0 then
					dlog(string.format("calibrating n=%d scores f=%.1f r=%.1f u=%.1f", calib.n, calib.score[1], calib.score[2], calib.score[3]))
				end
				if calib.n >= 150 then
					local best, bk = 0, 1
					for k = 1, 3 do
						if math.abs(calib.score[k]) > best then best, bk = math.abs(calib.score[k]), k end
					end
					calib.k, calib.sign, calib.done = bk, calib.score[bk] >= 0 and 1 or -1, true
					dlog(string.format("calibrated head axis=%s sign=%d (mean dot %.2f)", ({ "forward", "right", "up" })[bk], calib.sign, best / calib.n))
				end
			end
			if calib.done then
				local v = axes[calib.k]
				local ux, uy, uz = norm(v[1] * calib.sign, v[2] * calib.sign, v[3] * calib.sign)
				if ux then return hx, hy, hz, ux, uy, uz end
			end
		end
		source = "body"
	end
	if source == "head" and node then
		local okh, rot_h = pcall(Unit.world_rotation, unit, node)
		if okh then dx, dy, dz = forward_of(rot_h) end
	end

	local used = "body"
	if dx then
		local agree = true
		if source == "auto" and bx then
			local fl = math.sqrt(dx * dx + dy * dy)
			local bl = math.sqrt(bx * bx + by * by)
			if fl > 1e-4 and bl > 1e-4 then
				agree = (dx * bx + dy * by) / (fl * bl) > 0.5
			else
				agree = false
			end
		end
		if agree then used = "head" else dx = nil end
	end
	if not dx then
		if not bx then return nil end
		dx, dy, dz = bx, by, 0
	end
	dx, dy, dz = norm(dx, dy, dz)
	if not dx then return nil end

	if state.first_head < 6 then
		state.first_head = state.first_head + 1
		dlog(string.format("face_dir used=%s head_node=%s dir=(%.2f %.2f %.2f) body=(%s)",
			used, tostring(node), dx, dy, dz, bx and string.format("%.2f %.2f %.2f", bx, by, bz) or "nil"))
	end
	return hx, hy, hz, dx, dy, dz
end

local function draw_gunner(gui, cam, F, unit, right, bottom)
	local hx, hy, hz, dx, dy, dz = face_dir(unit, mod:get("beam_source") or "auto")
	if not hx then return end
	local len = mod:get("beam_length") or 30
	local th = mod:get("thickness") or 3
	-- start slightly in front of the face
	local sx, sy, sz = hx + dx * 0.15, hy + dy * 0.15, hz + dz * 0.15
	local ex, ey, ez = hx + dx * len, hy + dy * len, hz + dz * len
	emit(sx, sy, sz, ex, ey, ez, th, Color(235, 255, 40, 40))
	state.drawn_beams = state.drawn_beams + 1
end

-- ------------------------------------------------------------- hounds --

local function update_hound(unit, e, now)
	local x, y, z = pos_of(unit, 1)
	if not x then return false end
	local p = e.p
	if p and now > p.t then
		local dt = now - p.t
		if dt > 0.5 then
			e.vx, e.vy, e.vz = nil, nil, nil
			e.trail = {}
		else
			local vx, vy, vz = (x - p.x) / dt, (y - p.y) / dt, (z - p.z) / dt
			if e.vx then
				local a = 0.5
				vx, vy, vz = e.vx + (vx - e.vx) * a, e.vy + (vy - e.vy) * a, e.vz + (vz - e.vz) * a
			end
			e.vx, e.vy, e.vz = vx, vy, vz
		end
	end
	e.p = { x = x, y = y, z = z, t = now }
	if e.vx then
		local speed = math.sqrt(e.vx * e.vx + e.vy * e.vy + e.vz * e.vz)
		if speed >= LEAP_SPEED then
			if not e.leaping then
				e.leaping = true
				e.start_z = z
				e.trail = {}
				dlog(string.format("hound leap start speed=%.1f vz=%.1f", speed, e.vz))
			end
			e.leap_until = now + LEAP_HOLD
		elseif e.leaping and now > e.leap_until then
			e.leaping = false
			dlog("hound leap end")
		end
	end
	if e.leaping then
		local tr = e.trail
		tr[#tr + 1] = { x, y, z }
		if #tr > TRAIL_MAX then table.remove(tr, 1) end
	end
	return true
end

local function draw_hound(gui, cam, F, e, right, bottom)
	if not e.p then return end
	local th = mod:get("thickness") or 3
	if not e.leaping then
		-- projected pounce: the ballistic arc (leap speed 21, gravity 13.82)
		-- from the hound to the player's spine, drawn while it runs around
		if not mod:get("show_projected") then return end
		local sx, sy, sz = e.p.x, e.p.y, e.p.z + 0.6
		local dx, dy = F.ox - sx, F.oy - sy
		local d = math.sqrt(dx * dx + dy * dy)
		if d < 1.5 or d > (mod:get("pounce_range") or 25) then return end
		local h = (F.oz - 0.5) - sz
		local v, g = 21, HOUND_GRAVITY
		local disc = v ^ 4 - g * (g * d * d + 2 * h * v * v)
		local tan_t = disc >= 0 and (v * v - math.sqrt(disc)) / (g * d) or 1
		local cos_t = 1 / math.sqrt(1 + tan_t * tan_t)
		local vh = v * cos_t
		local vx, vy, vz = dx / d * vh, dy / d * vh, vh * tan_t
		local x, y, z = sx, sy, sz
		local c = Color(150, 255, 175, 40)
		local dt = d / vh / 24
		for _ = 1, 24 do
			local nx, ny = x + vx * dt, y + vy * dt
			local nz = z + vz * dt - 0.5 * g * dt * dt
			vz = vz - g * dt
			emit(x, y, z, nx, ny, nz, th, c)
			x, y, z = nx, ny, nz
		end
		state.drawn_arcs = state.drawn_arcs + 1
		return
	end
	if not e.vx then return end
	-- path already flown
	local tr = e.trail
	for i = 2, #tr do
		local a, b = tr[i - 1], tr[i]
		emit(a[1], a[2], a[3], b[1], b[2], b[3], th, Color(200, 255, 255, 255))
	end
	-- predicted path: constant horizontal velocity, gravity on vertical
	local x, y, z = e.p.x, e.p.y, e.p.z
	local vx, vy, vz = e.vx, e.vy, e.vz
	local dt = 0.04
	local floor_z = (e.start_z or z) - 0.6
	local arc = Color(240, 255, 175, 40)
	for _ = 1, 45 do
		local nx, ny = x + vx * dt, y + vy * dt
		local nz = z + vz * dt - 0.5 * HOUND_GRAVITY * dt * dt
		vz = vz - HOUND_GRAVITY * dt
		emit(x, y, z, nx, ny, nz, th + 1, arc)
		x, y, z = nx, ny, nz
		if vz < 0 and z <= floor_z then break end
	end
	state.drawn_arcs = state.drawn_arcs + 1
end

-- ------------------------------------------------------------- overlay --

local function overlay(ui_renderer)
	state.frames = state.frames + 1
	local now = os.clock()
	if state.hidden or not mod:get("show_gunner_beams") and not mod:get("show_hound_arcs") then
		if world_state.lo then pcall(world_destroy) end
		return
	end
	local cam = get_cam()
	if not cam then return end
	local F = cam_frame(cam)
	if not F then return end

	if now - last_scan >= 0.25 then
		last_scan = now
		local ok, err = pcall(scan, now)
		if not ok then derr("scan", err) end
	end

	local gui = ui_renderer.gui
	local right, bottom = RESOLUTION_LOOKUP.width, RESOLUTION_LOOKUP.height
	local max_r2 = (mod:get("max_range") or 80) ^ 2
	local want_g, want_h = mod:get("show_gunner_beams"), mod:get("show_hound_arcs")
	rect_count = 0
	state.drawn_beams, state.drawn_arcs = 0, 0
	ctx.gui, ctx.cam, ctx.F, ctx.right, ctx.bottom = gui, cam, F, right, bottom
	ctx.world = false
	if mod:get("render_mode") ~= "hud" and world_state.ok then
		local okb, rb = pcall(world_begin)
		if okb and rb then
			ctx.world = true
		elseif not okb then
			world_state.ok = false
			derr("world_begin", rb)
			dlog("world lines failed, falling back to HUD drawing")
		end
	end

	for unit, e in pairs(tracked) do
		local ok, err = pcall(function()
			if not unit_alive(unit) then tracked[unit] = nil return end
			if e.kind == "hound" then
				if update_hound(unit, e, now) and want_h then
					local dx, dy, dz = e.p.x - F.ox, e.p.y - F.oy, e.p.z - F.oz
					if dx * dx + dy * dy + dz * dz <= max_r2 then
						draw_hound(gui, cam, F, e, right, bottom)
					end
				end
			elseif want_g then
				local x, y, z = pos_of(unit, 1)
				if x then
					local dx, dy, dz = x - F.ox, y - F.oy, z - F.oz
					if dx * dx + dy * dy + dz * dz <= max_r2 then
						draw_gunner(gui, cam, F, unit, right, bottom)
					end
				end
			end
		end)
		if not ok then derr(e.kind, err) end
	end
	if ctx.world then
		local oke, re = pcall(world_end)
		if not oke then
			world_state.ok = false
			derr("world_end", re)
			dlog("world lines failed, falling back to HUD drawing")
		end
	elseif world_state.lo and (state.hidden or mod:get("render_mode") == "hud") then
		pcall(world_destroy)
	end
	state.rects = rect_count

	local beat = mod:get("heartbeat_s") or 5
	if now - state.last_beat >= beat then
		state.last_beat = now
		dlog(string.format("beat frames=%d entities=%d gunners=%d hounds=%d beams=%d arcs=%d rects=%d errors=%d",
			state.frames, state.scanned, state.gunners, state.hounds, state.drawn_beams, state.drawn_arcs, state.rects, state.errors))
	end
end

mod:hook_safe("HudElementCrosshair", "update", function(self, dt, t, ui_renderer)
	if not ui_renderer or not ui_renderer.gui then return end
	local ok, err = pcall(overlay, ui_renderer)
	if not ok then derr("overlay", err) end
end)

-- ------------------------------------------------------------- plumbing --

mod.toggle_beams = function()
	state.hidden = not state.hidden
	if world_state.lo and state.hidden then pcall(world_destroy) end
	mod:notify("Enemy beams %s", state.hidden and "hidden" or "shown")
	dlog("toggle hidden=" .. tostring(state.hidden))
end

mod.on_setting_changed = function(id)
	dlog("setting " .. tostring(id) .. "=" .. tostring(mod:get(id)))
end

mod.on_game_state_changed = function(status, state_name)
	if status == "enter" then
		tracked = {}
		pcall(world_destroy)
		dlog("game state enter " .. tostring(state_name))
	end
end

mod.on_unload = function()
	pcall(world_destroy)
	dlog("unload")
end

mod:command("enemybeams_status", "Enemy Beams: write the current state to debug.log", function()
	dlog(string.format("status frames=%d entities=%d gunners=%d hounds=%d beams=%d arcs=%d rects=%d errors=%d hidden=%s",
		state.frames, state.scanned, state.gunners, state.hounds, state.drawn_beams, state.drawn_arcs, state.rects, state.errors, tostring(state.hidden)))
	mod:echo("Enemy Beams status written to " .. LOG_PATH)
end)

mod:command("enemybeams_recalibrate", "Enemy Beams: relearn which way the head bone faces", function()
	calib.score, calib.n, calib.done, calib.k, calib.sign = { 0, 0, 0 }, 0, false, nil, nil
	mod:echo("Enemy Beams: recalibrating, keep gunners in view")
	dlog("recalibrate requested")
end)

mod:command("enemybeams_log_clear", "Enemy Beams: empty debug.log", function()
	local io_lib = get_io()
	local f = io_lib and io_lib.open(LOG_PATH, "w")
	if f then f:close() end
	log_bytes = 0
	mod:echo("Enemy Beams debug log cleared")
end)

do
	local g = guard_read()
	if g and g:find("WORLD_LINES armed", 1, true) and not g:find("CLEAR", 1, true) then
		world_state.ok = false
		dlog("crash guard: the last run died while world lines were active; using HUD drawing. Delete crash_guard.txt to retry.")
	end
end
dlog("loaded; hook installed on HudElementCrosshair.update")
