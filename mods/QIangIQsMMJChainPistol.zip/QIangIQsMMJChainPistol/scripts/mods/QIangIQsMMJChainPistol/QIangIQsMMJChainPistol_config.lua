-- QIangIQsMMJChainPistol per-weapon data (gen.py spec pistol_chain). Clips are MMJ clip names from pistol_chain\OBJ-Weapond-Pistol com Corrente__12237.
-- Action map sources: Darktide weapon templates (Aussiemon master) via tools\dump_actions.py.
return {
    ranged = true,
    idle = "pistol2-idle",
    templates = { boltpistol_p1_m1 = true, boltpistol_p1_m2 = true },
    shot = { clips = { "pistol2-shot" }, sounds = { "sfx_wp_pistol_shot_01.ogg", "sfx_wp_pistol_shot_03.ogg", "sfx_wp_pistol_shot_04.ogg", "sfx_wp_pistol_shot_05.ogg" } },
    actions = {
        action_wield = { clips = { "pistol2-fastintro" }, over_shot = true, sounds = { "sfx_wp_pistol_intro.ogg" } },
        action_reload = { clips = { "pistol2-reload" }, stretch = true, reload_template = true, over_shot = true, sounds = { "sfx_wp_pistol_upgraded_reload.ogg" } },
    },
}
