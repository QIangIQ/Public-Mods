return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsMMJChainPistol` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsMMJChainPistol", {
            mod_script = "QIangIQsMMJChainPistol/scripts/mods/QIangIQsMMJChainPistol/QIangIQsMMJChainPistol",
            mod_data = "QIangIQsMMJChainPistol/scripts/mods/QIangIQsMMJChainPistol/QIangIQsMMJChainPistol_data",
            mod_localization = "QIangIQsMMJChainPistol/scripts/mods/QIangIQsMMJChainPistol/QIangIQsMMJChainPistol_localization",
        })
    end,
    version = "0.1.1",
    author = "QIangIQ",
    packages = {},
}
