return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsTwinShields` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsTwinShields", {
			mod_script       = "QIangIQsTwinShields/scripts/mods/QIangIQsTwinShields/QIangIQsTwinShields",
			mod_data         = "QIangIQsTwinShields/scripts/mods/QIangIQsTwinShields/QIangIQsTwinShields_data",
			mod_localization = "QIangIQsTwinShields/scripts/mods/QIangIQsTwinShields/QIangIQsTwinShields_localization",
		})
	end,
	packages = {},
}
