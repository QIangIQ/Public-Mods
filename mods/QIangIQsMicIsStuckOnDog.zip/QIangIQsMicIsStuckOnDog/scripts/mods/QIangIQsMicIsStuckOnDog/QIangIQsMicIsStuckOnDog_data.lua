local mod = get_mod("QIangIQsMicIsStuckOnDog")

-- Same dropdown as Dio's Handholder "Audible Disablers" (DiosHandholder_data.lua
-- dio_hound_vocal), with constant barking as the default here.
return {
	name = "QIangIQ's Mic Is Stuck On Dog",
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			{
				setting_id = "hound_vocal",
				type = "dropdown",
				default_value = "spam",
				title = "hound_vocal",
				tooltip = "hound_vocal_tooltip",
				options = {
					{ text = "hound_vocal_off", value = "off" },
					{ text = "hound_vocal_bark", value = "bark" },
					{ text = "hound_vocal_growl", value = "growl" },
					{ text = "hound_vocal_breath", value = "breath" },
					{ text = "hound_vocal_spam", value = "spam" },
				},
			},
		},
	},
}
