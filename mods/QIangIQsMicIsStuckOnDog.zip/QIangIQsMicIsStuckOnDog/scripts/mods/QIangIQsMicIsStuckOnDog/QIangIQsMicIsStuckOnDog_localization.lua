return {
	mod_description = {
		en = "makes them fuckass doggos actually make noise thank god. Hound sounds from Dio's Handholder (Audible Disablers); footstep idea by Seph (CacklingTrapper).",
	},
	hound_vocal = {
		en = "Hounds vocalise while moving",
	},
	hound_vocal_tooltip = {
		en = "Replaces a hound's footstep sound with one of its own vocalisations, so it announces itself continuously while it runs at you instead of only on the leap. Applies to all three hounds - normal, armoured and the mutator variant - each using its own audio.\n\nConstant barking also plays each hound's bark every 0.2 s within 45 m of you, even when it stands still.\n\nIdea and mechanism by Seph (Concoction of Constitution), from CacklingTrapper; options as in Dio's Handholder.\n\nCHANGING BETWEEN BARK / GROWL / BREATH / OFF NEEDS A MOD RELOAD OR GAME RESTART - the breed's sound table is read once, when the game loads it. Constant barking's 0.2 s timer switches on and off immediately.",
	},
	hound_vocal_off = {
		en = "Off (vanilla footsteps)",
	},
	hound_vocal_bark = {
		en = "Bark - loudest",
	},
	hound_vocal_growl = {
		en = "Growl - moderate",
	},
	hound_vocal_breath = {
		en = "Breath - quietest",
	},
	hound_vocal_spam = {
		en = "Constant barking - every 0.2s",
	},
}
