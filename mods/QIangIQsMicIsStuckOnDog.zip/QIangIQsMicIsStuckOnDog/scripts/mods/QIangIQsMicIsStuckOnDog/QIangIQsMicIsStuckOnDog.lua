local mod = get_mod("QIangIQsMicIsStuckOnDog")

-- --------------------------------------------------------------------------
-- Hounds bark constantly
-- --------------------------------------------------------------------------
--
-- Taken from Dio's Handholder, "Audible Disablers" set to "Constant barking -
-- every 0.2s" (DiosHandholder_sounds.lua, and the hound scan in
-- DiosHandholder_tracers.lua). Only that feature is carried over. Handholder's
-- footstep idea is credited there to Seph (Concoction of Constitution),
-- CacklingTrapper.
--
-- Why the old version was silent: it hooked
--   "scripts/settings/breed/breeds/chaos/chaos_hound_sounds.lua"
-- but the game requires that file WITHOUT ".lua"
--   (chaos_hound_breed.lua:90 require("scripts/settings/breed/breeds/chaos/chaos_hound_sounds"))
-- so the hook never matched and nothing changed.
--
-- Setting "hound_vocal" - the same five options as Dio's Handholder
-- (DiosHandholder_data.lua dio_hound_vocal, DiosHandholder_sounds.lua
-- chosen_setting / chosen_key): off, bark, growl, breath, spam.
--
-- Two parts, same as Handholder's constant-bark mode:
--   1. Footstep -> bark: each hound's footstep event is replaced by that
--      hound's own sfx_bark, so it barks on every step while it moves.
--      All three hounds (normal, armoured, mutator) use their own bark.
--      Needs a mod reload / game restart to take effect, because the sound
--      table is read once when the breed loads.
--   2. A bark every 0.2 s at every hound within 45 m of you, whatever the
--      hound is doing - standing still included.
--
-- If Dio's Handholder's own constant-barking option is also on, you will get
-- both at once; turn one of them off.

-- ---------------------------------------------------------------- part 1 --

local HOUND_SOUNDS = {
	"scripts/settings/breed/breeds/chaos/chaos_hound_sounds",
	"scripts/settings/breed/breeds/chaos/chaos_armored_hound_sounds",
	"scripts/settings/breed/breeds/chaos/chaos_hound_mutator_sounds",
}

local VOCALISATIONS = {
	bark = "sfx_bark",
	growl = "sfx_growl",
	breath = "sfx_breath",
}

-- DMF returns nil for a setting never written; "spam" is the default here
-- and must match the widget's default_value.
local function chosen_setting()
	local ok, choice = pcall(mod.get, mod, "hound_vocal")

	if not ok or type(choice) ~= "string" then
		return "spam"
	end

	return choice
end

-- "spam" is a delivery mode, not a sound: its footstep sound is the bark.
local function chosen_key()
	local choice = chosen_setting()

	if choice == "off" then
		return nil
	end

	if choice == "spam" then
		return VOCALISATIONS.bark
	end

	return VOCALISATIONS[choice]
end

local function swap_footstep(sound_data)
	local key = chosen_key()

	if not key or type(sound_data) ~= "table" or type(sound_data.events) ~= "table" then
		return
	end

	local event = sound_data.events[key]

	if type(event) ~= "string" then
		return
	end

	sound_data.events.footstep = event

	if type(sound_data.use_proximity_culling) == "table" then
		sound_data.use_proximity_culling.footstep = false
	end
end

for i = 1, #HOUND_SOUNDS do
	mod:hook_require(HOUND_SOUNDS[i], swap_footstep)
end

-- ---------------------------------------------------------------- part 2 --

local SPAM_INTERVAL = 0.2
local SPAM_RANGE = 45
local SCAN_INTERVAL = 0.25
-- Fallback when a breed's own bark cannot be read (Handholder uses this one
-- event for every hound).
local BARK_EVENT = "wwise/events/minions/play_enemy_chaos_hound_vce_bark"

local HOUNDS = {
	chaos_hound = true,
	chaos_armored_hound = true,
	chaos_hound_mutator = true,
}

local clock = 0
local spam_next_t = 0
local scanned = { hounds = {}, at = -math.huge }
local range_buffer = {}
local event_buffer = {}

local function g(name)
	return rawget(_G, name)
end

local function unit_position(unit)
	local ALIVE = g("ALIVE")
	if not ALIVE or not ALIVE[unit] then
		return nil
	end

	local lookup = g("POSITION_LOOKUP")
	local p = lookup and lookup[unit]
	if p then
		return p
	end

	local Unit = g("Unit")
	if not Unit or not Unit.world_position then
		return nil
	end

	local ok, v = pcall(Unit.world_position, unit, 1)
	return ok and v or nil
end

local function local_player_unit()
	local pm = Managers and Managers.player
	if not pm or not pm.local_player_safe then
		return nil
	end

	-- local_player_safe, not local_player: the latter calls Network.peer_id()
	-- and faults outside a session.
	local ok, p = pcall(pm.local_player_safe, pm, 1)
	return ok and p and p.player_unit or nil
end

local function unit_breed(unit)
	local ScriptUnit = g("ScriptUnit")
	if not ScriptUnit or not ScriptUnit.has_extension then
		return nil
	end

	local ok, ext = pcall(ScriptUnit.has_extension, unit, "unit_data_system")
	if not ok or not ext or not ext.breed then
		return nil
	end

	local ok2, breed = pcall(ext.breed, ext)
	if not ok2 or type(breed) ~= "table" then
		return nil
	end

	return breed
end

-- Each hound's own bark: breed.sounds is the breed's sound table
-- (chaos_hound_breed.lua:90 sounds = require(".../chaos_hound_sounds")),
-- so the armoured and mutator hounds bark with their own voices.
local hound_bark = setmetatable({}, { __mode = "k" })

local function read_player_side(side_system)
	local name = side_system:get_default_player_side_name()

	return side_system:get_side_from_name(name)
end

-- Hounds come from the side system's "enemy"/"special" list, which the game
-- keeps for its own AI.
local function scan()
	local hounds = {}

	local ext = Managers.state and Managers.state.extension
	local side_system = ext and ext:system("side_system")

	if not side_system then
		return hounds
	end

	local ok, side = pcall(read_player_side, side_system)

	if not ok or not side or not side.alive_units_by_tag then
		return hounds
	end

	local ok2, list = pcall(side.alive_units_by_tag, side, "enemy", "special")
	if not ok2 or type(list) ~= "table" then
		return hounds
	end

	local n = list.size or 0
	for i = 1, n do
		local unit = list[i]
		local breed = unit and unit_breed(unit)

		if breed and HOUNDS[breed.name] then
			hounds[#hounds + 1] = unit

			local sounds = breed.sounds
			local event = type(sounds) == "table" and type(sounds.events) == "table" and sounds.events.sfx_bark

			hound_bark[unit] = type(event) == "string" and event or BARK_EVENT
		end
	end

	return hounds
end

local function hounds_in_range(range)
	for i = #range_buffer, 1, -1 do
		range_buffer[i] = nil
		event_buffer[i] = nil
	end

	local Vector3 = g("Vector3")
	local me = local_player_unit()

	if not Vector3 or not me then
		return range_buffer
	end

	local my_pos = unit_position(me)

	if not my_pos then
		return range_buffer
	end

	if clock - scanned.at >= SCAN_INTERVAL then
		scanned.at = clock
		scanned.hounds = scan()
	end

	local list = scanned.hounds

	for i = 1, #list do
		local p = unit_position(list[i])

		if p and Vector3.distance(my_pos, p) <= range then
			range_buffer[#range_buffer + 1] = p
			event_buffer[#range_buffer] = hound_bark[list[i]] or BARK_EVENT
		end
	end

	return range_buffer, event_buffer
end

local function spam_tick()
	if chosen_setting() ~= "spam" then
		return
	end

	if clock < spam_next_t then
		return
	end
	spam_next_t = clock + SPAM_INTERVAL

	local Wwise = g("Wwise")
	local WwiseWorld = g("WwiseWorld")
	local wm = Managers.world

	if not Wwise or not WwiseWorld or not wm or not wm.has_world
		or not wm:has_world("level_world") then
		return
	end

	local ok_w, world = pcall(wm.world, wm, "level_world")

	if not ok_w or not world then
		return
	end

	local ok_ww, wwise_world = pcall(Wwise.wwise_world, world)

	if not ok_ww or not wwise_world then
		return
	end

	local hounds, events = hounds_in_range(SPAM_RANGE)

	for i = 1, #hounds do
		local pos = hounds[i]
		local event = events[i] or BARK_EVENT

		-- Auto source: positional and fire-and-forget, nothing to release
		-- when the hound dies mid-bark.
		pcall(function()
			local source = WwiseWorld.make_auto_source(wwise_world, pos)

			WwiseWorld.trigger_resource_event(wwise_world, event, source)
		end)
	end
end

mod.update = function(dt)
	clock = clock + (dt or 0)
	pcall(spam_tick)
end

mod.on_game_state_changed = function(status, state_name)
	if status == "exit" then
		scanned.hounds = {}
		scanned.at = -math.huge
	end
end
