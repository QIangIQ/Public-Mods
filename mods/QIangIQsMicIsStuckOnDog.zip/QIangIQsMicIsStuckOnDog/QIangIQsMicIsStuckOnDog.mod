return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsMicIsStuckOnDog` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsMicIsStuckOnDog", {
			mod_script       = "QIangIQsMicIsStuckOnDog/scripts/mods/QIangIQsMicIsStuckOnDog/QIangIQsMicIsStuckOnDog",
			mod_data         = "QIangIQsMicIsStuckOnDog/scripts/mods/QIangIQsMicIsStuckOnDog/QIangIQsMicIsStuckOnDog_data",
			mod_localization = "QIangIQsMicIsStuckOnDog/scripts/mods/QIangIQsMicIsStuckOnDog/QIangIQsMicIsStuckOnDog_localization",
		})
	end,
	packages = {},
}
