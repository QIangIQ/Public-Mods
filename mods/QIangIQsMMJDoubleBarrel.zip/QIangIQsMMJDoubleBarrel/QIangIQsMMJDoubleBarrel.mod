return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsMMJDoubleBarrel` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsMMJDoubleBarrel", {
            mod_script = "QIangIQsMMJDoubleBarrel/scripts/mods/QIangIQsMMJDoubleBarrel/QIangIQsMMJDoubleBarrel",
            mod_data = "QIangIQsMMJDoubleBarrel/scripts/mods/QIangIQsMMJDoubleBarrel/QIangIQsMMJDoubleBarrel_data",
            mod_localization = "QIangIQsMMJDoubleBarrel/scripts/mods/QIangIQsMMJDoubleBarrel/QIangIQsMMJDoubleBarrel_localization",
        })
    end,
    version = "0.1.0",
    author = "QIangIQ",
    packages = {},
}
