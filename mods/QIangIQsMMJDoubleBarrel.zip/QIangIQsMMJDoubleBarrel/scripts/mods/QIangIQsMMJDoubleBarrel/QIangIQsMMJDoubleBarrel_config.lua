-- QIangIQsMMJDoubleBarrel per-weapon data (gen.py spec double_barrel). Clips are MMJ clip names from shotgun_double_barrel\OBJ-Weapond-Shotgun Double Barrel__20736.
-- Action map sources: Darktide weapon templates (Aussiemon master) via tools\dump_actions.py.
return {
    ranged = true,
    idle = "Shotgun DoubleBarrel-idle",
    templates = { shotgun_p2_m1 = true, shotgun_p2_m3 = true },
    shot = { clips = { "Shotgun DoubleBarrel-shot", "Shotgun DoubleBarrel-shootOut" }, sounds = { "shotgunDouble.shoot-001.ogg", "shotgunDouble.shoot-002.ogg", "shotgunDouble.shoot-003.ogg" } },
    actions = {
        action_wield = { clips = { "Shotgun DoubleBarrel-fastIntroBerserk" }, over_shot = true, sounds = { "sfx_wp_shotgun_post_intro_01.ogg", "sfx_wp_shotgun_post_intro_02.ogg", "sfx_wp_shotgun_post_intro_03.ogg" } },
        action_reload = { clips = { "Shotgun DoubleBarrel-reload NEW" }, stretch = true, reload_template = true, over_shot = true, sounds = { "sfx_gp_shotgun_reload_double.ogg" } },
    },
}
