return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsSevagothPrime` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsSevagothPrime", {
            mod_script = "QIangIQsSevagothPrime/scripts/mods/QIangIQsSevagothPrime/QIangIQsSevagothPrime",
            mod_data = "QIangIQsSevagothPrime/scripts/mods/QIangIQsSevagothPrime/QIangIQsSevagothPrime_data",
            mod_localization = "QIangIQsSevagothPrime/scripts/mods/QIangIQsSevagothPrime/QIangIQsSevagothPrime_localization",
        })
    end,
    version = "1.0.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
