return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsChainsword2h` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsChainsword2h", {
            mod_script = "QIangIQsChainsword2h/scripts/mods/QIangIQsChainsword2h/QIangIQsChainsword2h",
            mod_data = "QIangIQsChainsword2h/scripts/mods/QIangIQsChainsword2h/QIangIQsChainsword2h_data",
            mod_localization = "QIangIQsChainsword2h/scripts/mods/QIangIQsChainsword2h/QIangIQsChainsword2h_localization",
        })
    end,
    version = "0.1.0",
    author = "QIangIQ",
    packages = {},
}
