-- QIangIQ's 2H Chainsword P2 0.1.0: the unreleased two-handed chainsword p2 (most likely the Dauntless's) as a weapon.
--
-- What is datamined (project file datamine/chainsword2h_p2/2h-chainsword-p2-assets.md, 2026-10-30; node names by id32
-- match, work folder chainsword2h_p2\probe_nodes.txt):
--   * content/weapons/player/melee/2h_chain_sword_p2/attachments/grip_01/grip_01 (d3e22ea298b6eb26): root
--     rp_2h_chain_sword_01, ap_blade_01 at the origin, ap_trigger_01 at z 0.0911, fx_engine, fx_weapon_special.
--   * .../2h_chain_sword_p2/attachments/blade_01/blade_01 (1b9c3bf2766eb78d): root rp_blade_01, fx_block, fx_sawing, 63
--     chain joints (same names as the released body_01 / chain_57_01 joints) and the same script component wiring as the
--     released body_01 (unit strings call_script_component / set_speed / speed), so ChainWeaponEffects' "set_speed"
--     component event spins its chain (scripts/components/chain_sword_spin.lua).
--   * NOT in the files: p2 rig, weapon template, item, animations. The p2/p3 HUD icons are placeholder text images.
--
-- How it is built (QIangIQsPowerAxe 0.2 pattern: template clone + NetworkLookup append + alias copy, item clone into
-- MasterItems.get_cached(), equip by override_slot):
--   * Template chainsword_2h_p2_m1 (the name of the game's own p2 HUD icon) = clone of chainsword_2h_p1_m1 or _m2
--     (setting). Moveset, special, chain speed, fx_sources and both state machines are the released 2H chainsword's, so
--     first AND third person play the game's own 2h_chain_sword animations on the game's own skeletons (nothing foreign
--     to retarget). Every fx source node exists on the p2 parts or the kept trail: _block fx_block / _sticky fx_sawing
--     (blade), _special_active fx_weapon_special / _wielded_idling fx_engine (grip), _sweep fx_sweep (trail_01).
--   * Item = clone of the donor master item (http_cache.db build 139617): rig wpn_2h_chain_sword_chained_rig, grip slot ->
--     body slot -> chain / emblems / trinket hook, plus trail. Here the grip slot holds the p2 grip (attach node
--     rp_2h_chain_sword_chained_rig like the donor grip) and the body slot the p2 blade on the grip's ap_blade_01. The
--     released chain, emblem and trinket parts go: the p2 blade carries its own chain and has no ap_chain_01 /
--     ap_emblem_* / ap_trinket_hook nodes.
--   * Grip alignment: the hand holds the rig where the donor's ap_trigger_01 is (z 0.1116); the p2 grip's is at 0.0911,
--     so the grip is raised by 0.0205 m (QIangIQsCrossbow 0.4.0 grip fix). Render check: chainsword2h_p2\render_cmp.png.
--   * Sounds: the donor's aliases resolve to play/stop_2h_chainsword, _stuck_loop and play_2h_chainsword_swing
--     (player_character_sound_event_aliases.lua). The game banks hold play/stop_dauntless_2h_chainsword, _stuck_loop and
--     play_dauntless_2h_chainsword_swing, each with a _husk twin (Datavault datafile-name-list-2026-10-30). Swapped at
--     local playback only (Datavault technique-local-sound-swap): the looping engine / stuck sounds after
--     resolve_looping_gear_sound, the swing in PlayerUnitFxExtension.trigger_wwise_event. Tying these sounds to p2 is a
--     reading of the names, not proven.
--   * Standalone: needs no other mod; HUD icon and every unit are the game's own.
-- Author: QIangIQ
local mod = get_mod("QIangIQsChainsword2h")

local WeaponTemplates = require("scripts/settings/equipment/weapon_templates/weapon_templates")
local MasterItems = require("scripts/backend/master_items")
local NetworkLookup = require("scripts/network_lookup/network_lookup")

local P2 = "content/weapons/player/melee/2h_chain_sword_p2/attachments/"
local GRIP_UNIT = P2 .. "grip_01/grip_01"
local BLADE_UNIT = P2 .. "blade_01/blade_01"
local ITEM_ROOT = "content/items/weapons/player/melee/"
local PART_ROOT = ITEM_ROOT .. "qiangiq_chainsword2h/"
local GRIP_ITEM = PART_ROOT .. "grip_p2_01"
local BLADE_ITEM = PART_ROOT .. "blade_p2_01"
local RIG_NODE = "rp_2h_chain_sword_chained_rig"
local BLADE_NODE = "ap_blade_01"
-- rig ap_trigger_01 z 0.1116 minus p2 grip ap_trigger_01 z 0.0911 (probe_nodes.txt)
local GRIP_RAISE = 0.0205
local ARCHETYPES = { "zealot", "veteran", "psyker", "adamant" }

local DONORS = { m1 = "chainsword_2h_p1_m1", m2 = "chainsword_2h_p1_m2" }
local MARK = {
    template = "chainsword_2h_p2_m1",
    item = ITEM_ROOT .. "chainsword_2h_p2_m1",
    display = "loc_qiangiq_chainsword2h_p2_m1",
}

mod:add_global_localize_strings({
    loc_qiangiq_chainsword2h_family = { en = "2H Chainsword (datamined)" },
    loc_qiangiq_chainsword2h_p2_m1 = { en = "2H Chainsword P2 (datamined)" },
    loc_qiangiq_chainsword2h_desc = {
        en = "The unreleased two-handed chainsword p2 found in the game files. Uses the released 2H Chainsword's moveset and chain special.",
    },
})

local function say(fmt, ...)
    local text = string.format(fmt, ...)

    mod:echo(text)
    mod:info(text)
end

local function debug(fmt, ...)
    if mod:get("debug") then
        mod:info(fmt, ...)
    end
end

-- Network lookups (QIangIQsShardStaff append_lookup): new names go at the end so no existing id moves -------------
local function append_lookup(lookup_name, key)
    local lookup = NetworkLookup[lookup_name]

    if not lookup then
        return false, "no lookup"
    end

    local existing = rawget(lookup, key)

    if existing then
        return true, existing
    end

    local index = #lookup + 1

    rawset(lookup, index, key)
    rawset(lookup, key, index)

    return true, index
end

-- Particle / sound aliases keyed by wielded_weapon_template (QIangIQsShardStaff alias_template_keys) --------------
local ALIAS_MODULES = {
    "scripts/settings/particles/player_character_particle_aliases",
    "scripts/settings/sound/player_character_sound_event_aliases",
}

local function alias_keys(root, source, target, seen, counter)
    if type(root) ~= "table" or seen[root] then
        return
    end

    seen[root] = true

    local value = rawget(root, source)

    if value ~= nil and rawget(root, target) == nil then
        root[target] = value
        counter.n = counter.n + 1
    end

    for _, child in pairs(root) do
        if type(child) == "table" then
            alias_keys(child, source, target, seen, counter)
        end
    end
end

local function copy_aliases(source, target)
    local counter = { n = 0 }

    for _, path in ipairs(ALIAS_MODULES) do
        local ok, module = pcall(require, path)

        if ok then
            alias_keys(module, source, target, {}, counter)
        else
            mod:error("alias module %s: %s", path, tostring(module))
        end
    end

    return counter.n
end

local function package_found(path)
    local ok, exists = pcall(Application.can_get_resource, "package", path)

    return ok and exists and true or false
end

local function donor_name()
    return DONORS[mod:get("moveset")] or DONORS.m1
end

-- Template ------------------------------------------------------------------------------------------------------------
local function ensure_template()
    if rawget(WeaponTemplates, MARK.template) then
        MARK.template_ok = true
        MARK.official_template = not MARK.template_ours

        return true
    end

    local donor = WeaponTemplates[donor_name()]

    if not donor then
        return false
    end

    local clone = table.clone(donor)

    clone.name = MARK.template

    -- weapon_templates.lua _require_template: action_settings.name = action_name
    for action_name, action_settings in pairs(clone.actions) do
        action_settings.name = action_name
    end

    WeaponTemplates[MARK.template] = clone
    MARK.template_ours = true
    MARK.donor = donor_name()

    local ok, index = append_lookup("weapon_templates", MARK.template)

    MARK.template_id = ok and index or nil
    MARK.aliases = copy_aliases(MARK.donor, MARK.template)
    MARK.template_ok = ok

    return ok
end

-- Items ---------------------------------------------------------------------------------------------------------------
local function find_item(cache, preferred, template)
    local direct = rawget(cache, preferred)

    if direct and direct.weapon_template == template then
        return preferred, direct
    end

    for name, item in pairs(cache) do
        if type(item) == "table" and item.weapon_template == template then
            return name, item
        end
    end
end

-- Only base_unit is kept: Items.base_unit can also read per-breed / first-person variants of the source part
local function only_base_unit(item, unit)
    for key in pairs(item) do
        if type(key) == "string" and key ~= "base_unit" and key:find("^base_unit") then
            item[key] = nil
        end
    end

    item.base_unit = unit
end

local function make_part(cache, name, template_item, unit, attach_node)
    local item = table.clone(template_item)

    only_base_unit(item, unit)
    item.name = name
    item.resource_dependencies = { [unit] = true }
    item.attachments = nil
    item.material_overrides = nil
    item.material_override_items = nil
    item.attach_node = attach_node
    cache[name] = item

    return name
end

-- a tree node with the donor node's flags (leaf_attach_node_override, link_map_mode_override, material fields)
local function fresh_node(node, item_name)
    local out = {}

    for key, value in pairs(node) do
        if key ~= "children" and key ~= "item" then
            out[key] = type(value) == "table" and table.clone(value) or value
        end
    end

    out.item = item_name
    out.children = {}

    return out
end

local function dump_tree(tree, prefix, out)
    for slot_name, node in pairs(tree) do
        if type(node) == "table" then
            local path = prefix .. slot_name

            out[#out + 1] = string.format("%s=%s", path, tostring(node.item))

            if type(node.children) == "table" then
                dump_tree(node.children, path .. "/", out)
            end
        end
    end

    return out
end

local function archetypes_of(source_item)
    local archetypes, seen = {}, {}

    for _, archetype in ipairs(source_item.archetypes or {}) do
        archetypes[#archetypes + 1] = archetype
        seen[archetype] = true
    end

    for _, archetype in ipairs(ARCHETYPES) do
        if mod:get("unlock_" .. archetype) and not seen[archetype] then
            archetypes[#archetypes + 1] = archetype
            seen[archetype] = true
        end
    end

    return archetypes
end

local function build_item(cache)
    local donor = donor_name()
    local source_name, source_item = find_item(cache, ITEM_ROOT .. donor, donor)

    if not source_item then
        return false
    end

    if type(source_item.attachments) ~= "table" then
        return false, "source item has no attachments"
    end

    for _, unit in ipairs({ GRIP_UNIT, BLADE_UNIT }) do
        if not package_found(unit) then
            return false, unit .. " package not found"
        end
    end

    local item = table.clone(source_item)

    item.name = MARK.item
    item.weapon_template = MARK.template
    item.display_name = MARK.display
    item.description = "loc_qiangiq_chainsword2h_desc"
    item.dev_description = nil
    item.archetypes = archetypes_of(source_item)

    for _, field in ipairs({ "weapon_family_display_name", "weapon_pattern_display_name", "weapon_mark_display_name" }) do
        if type(item[field]) == "table" then
            item[field].loc_id = field == "weapon_family_display_name" and "loc_qiangiq_chainsword2h_family" or MARK.display
        end
    end

    if not MARK.tree_logged then
        MARK.tree_logged = true
        mod:info("source tree of %s: %s", tostring(source_name), table.concat(dump_tree(item.attachments, "", {}), "; "))
    end

    -- master item data of chainsword_2h_p1_m1 (http_cache.db, build 139617): grip = 2h_chain_sword_grip_01, grip/body =
    -- 2h_chain_sword_body_01 with chain, emblem_left/right, slot_trinket_1 and trinket_hook under it; trail
    local grip = item.attachments.grip
    local body = grip and type(grip.children) == "table" and grip.children.body

    local function source_of(node)
        return node and type(node.item) == "string" and rawget(cache, node.item)
    end

    local grip_source, body_source = source_of(grip), source_of(body)

    if not (grip_source and body_source) then
        return false, "no grip or grip/body slot in " .. tostring(source_name)
    end

    if not rawget(cache, GRIP_ITEM) then
        make_part(cache, GRIP_ITEM, grip_source, GRIP_UNIT, RIG_NODE)
    end

    if not rawget(cache, BLADE_ITEM) then
        make_part(cache, BLADE_ITEM, body_source, BLADE_UNIT, BLADE_NODE)
    end

    grip.item = GRIP_ITEM
    grip.children = { body = fresh_node(body, BLADE_ITEM) }

    local deps = item.resource_dependencies or {}

    deps[GRIP_UNIT] = true
    deps[BLADE_UNIT] = true

    -- what the offline item compile adds for the weapon template (item_package.lua:239-249): state machines, sounds, effects
    local WeaponTemplateResourceDependencies = require("scripts/utilities/weapon_template_resource_dependencies")

    for _, resource in ipairs(WeaponTemplateResourceDependencies.generate(MARK.template)) do
        deps[resource] = true
    end

    item.resource_dependencies = deps

    local ok, index = append_lookup("player_item_names", MARK.item)

    if not ok then
        return false
    end

    cache[MARK.item] = item
    MARK.item_id = index
    MARK.source_item_name = source_name
    MARK.slot = item.slots and item.slots[1]

    return true
end

local function ensure_item()
    local ok, has_data = pcall(MasterItems.has_data)

    if not ok or not has_data then
        return false
    end

    local cache = MasterItems.get_cached()

    if rawget(cache, MARK.item) and not MARK.dirty then
        MARK.item_ok = true

        return true
    end

    local built, err = build_item(cache)

    if err and err ~= MARK.last_error then
        MARK.last_error = err
        mod:error("%s: %s", MARK.template, err)
    end

    MARK.item_ok = built and rawget(cache, MARK.item) ~= nil

    if MARK.item_ok then
        MARK.dirty = false
    end

    return MARK.item_ok
end

-- Unlock lists (weapon_unlock_settings.lua WeaponUnlockSettings[archetype][level] = { item names }); realms_loadout
-- builds its human weapon list from it
local function add_to_unlock_lists()
    if not mod:get("add_to_unlock_list") then
        return
    end

    local ok, unlocks = pcall(require, "scripts/settings/weapon_unlock/weapon_unlock_settings")

    if not ok or not unlocks then
        mod:error("WeaponUnlockSettings not found")

        return
    end

    local level = math.floor(mod:get("unlock_level") or 1)

    for _, archetype in ipairs(ARCHETYPES) do
        local list = unlocks[archetype]

        if mod:get("unlock_" .. archetype) and list then
            list[level] = list[level] or {}

            if not table.find(list[level], MARK.item) then
                table.insert(list[level], MARK.item)
            end
        end
    end
end

local next_poll = 0

local function poll()
    if next_poll > os.clock() then
        return
    end

    next_poll = os.clock() + 1

    local before_t, before_i = MARK.template_ok, MARK.item_ok
    local ok_t, err_t = pcall(ensure_template)
    local ok_i, err_i = true, nil

    if MARK.template_ok then
        ok_i, err_i = pcall(ensure_item)
    end

    if not ok_t then
        mod:error("template: %s", tostring(err_t))
    end

    if not ok_i then
        mod:error("item: %s", tostring(err_i))
    end

    if MARK.template_ok and not before_t then
        if MARK.official_template then
            mod:info("the game now has its own %s template; using it", MARK.template)
        else
            mod:info("template %s registered (clone of %s), %s alias entries", MARK.template, tostring(MARK.donor), tostring(MARK.aliases))
        end
    end

    if MARK.item_ok and not before_i then
        mod:info("item %s injected (clone of %s, slot %s)", MARK.item, tostring(MARK.source_item_name), tostring(MARK.slot))
    end
end

-- Archetypes can change while the game runs: rebuild the item (equip again to see it). The moveset is read when the
-- template is built, so it needs the mods reloaded (Ctrl+Shift+R) or a restart.
local ITEM_SETTINGS = { unlock_zealot = true, unlock_veteran = true, unlock_psyker = true, unlock_adamant = true }

mod.on_setting_changed = function(setting_id)
    if ITEM_SETTINGS[setting_id] then
        MARK.dirty = true
    end
end

-- Grip alignment ------------------------------------------------------------------------------------------------------
local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function grip_units(names, out)
    if names then
        for unit, item_name in pairs(names) do
            if item_name == GRIP_ITEM and unit_ok(unit) then
                out[#out + 1] = unit
            end
        end
    end

    return out
end

local function place_grip(ext)
    if not ext._equipment then
        return
    end

    local raise = mod:get("align_grip") ~= false and GRIP_RAISE or 0
    local placed = ext.__qiangiq_chainsword2h_raise

    if not placed then
        placed = {}
        ext.__qiangiq_chainsword2h_raise = placed
    end

    for _, slot in pairs(ext._equipment) do
        local item = slot.item

        if item and item.name == MARK.item then
            local units = grip_units(slot.item_name_by_unit_3p, grip_units(slot.item_name_by_unit_1p, {}))

            for _, unit in ipairs(units) do
                if placed[unit] ~= raise then
                    placed[unit] = raise
                    Unit.set_local_position(unit, 1, Vector3(0, 0, raise))
                end
            end
        end
    end
end

local tracked = {}

-- every player unit (own and others with the mod's item) so the grip sits the same in 1p and 3p
mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "_update_item_visibility", function(self)
    tracked[self] = true
    pcall(place_grip, self)
end)

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "update", function(self)
    if tracked[self] then
        pcall(place_grip, self)
    end
end)

mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, "destroy", function(func, self, ...)
    tracked[self] = nil

    return func(self, ...)
end)

-- Dauntless sounds (local playback swap, Datavault technique-local-sound-swap) ---------------------------------------
local SOUND_SWAP = {}

for _, pair in ipairs({
    { "wwise/events/weapon/play_2h_chainsword", "wwise/events/weapon/play_dauntless_2h_chainsword" },
    { "wwise/events/weapon/stop_2h_chainsword", "wwise/events/weapon/stop_dauntless_2h_chainsword" },
    { "wwise/events/weapon/play_2h_chainsword_stuck_loop", "wwise/events/weapon/play_dauntless_2h_chainsword_stuck_loop" },
    { "wwise/events/weapon/stop_2h_chainsword_stuck_loop", "wwise/events/weapon/stop_dauntless_2h_chainsword_stuck_loop" },
    { "wwise/events/weapon/play_2h_chainsword_swing", "wwise/events/weapon/play_dauntless_2h_chainsword_swing" },
}) do
    SOUND_SWAP[pair[1]] = pair[2]
    -- resolve_looping_gear_sound returns names with _husk already appended; every Dauntless event has a _husk twin
    SOUND_SWAP[pair[1] .. "_husk"] = pair[2] .. "_husk"
end

-- The swap happens after the sync RPC has looked up the donor name, so the Dauntless names never reach
-- NetworkLookup.player_character_sounds. They are still appended (sorted, so every client with the mod gets the same
-- ids) in case some path looks one up: an unknown name there is a CTD (Datavault
-- lesson-player-character-sounds-lookup-crash, QIangIQsMeltagun 0.10.1).
do
    local names = {}

    for _, new_name in pairs(SOUND_SWAP) do
        names[#names + 1] = new_name
    end

    table.sort(names)

    for _, name in ipairs(names) do
        append_lookup("player_character_sounds", name)
    end
end

local logged_sounds = {}

local function wields_p2(visual_loadout_extension)
    local properties = visual_loadout_extension and visual_loadout_extension._profile_properties

    return properties and properties.wielded_weapon_template == MARK.template
end

local function swap(event_name)
    local new_name = event_name and SOUND_SWAP[event_name]

    if new_name and not logged_sounds[event_name] then
        logged_sounds[event_name] = true
        debug("sound %s -> %s", event_name, new_name)
    end

    return new_name or event_name
end

mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, "resolve_looping_gear_sound", function(func, self, ...)
    local resolved, event_name, resolved_stop, stop_event_name = func(self, ...)

    if resolved and mod:get("dauntless_sounds") and wields_p2(self) then
        event_name = swap(event_name)
        stop_event_name = swap(stop_event_name)
    end

    return resolved, event_name, resolved_stop, stop_event_name
end)

mod:hook(CLASS.PlayerUnitFxExtension, "trigger_wwise_event", function(func, self, event_name, ...)
    if SOUND_SWAP[event_name] and mod:get("dauntless_sounds") and wields_p2(self._visual_loadout_extension) then
        return func(self, swap(event_name), ...)
    end

    return func(self, event_name, ...)
end)

mod.update = function()
    poll()
end

mod.on_all_mods_loaded = function()
    add_to_unlock_lists()
end

mod.on_unload = function()
    local ok, cache = pcall(MasterItems.get_cached)

    if ok and cache then
        cache[MARK.item] = nil
        cache[GRIP_ITEM] = nil
        cache[BLADE_ITEM] = nil
    end

    if MARK.template_ours then
        WeaponTemplates[MARK.template] = nil
    end
end

-- Equip without the backend (QIangIQsShardStaff override): only where this client hosts ----------------------------
local function local_player()
    local players = Managers.player

    return players and players:local_player_safe(1)
end

local function equipped_item_name(player, slot)
    local unit = player and player.player_unit

    if not unit or not Unit.alive(unit) then
        return nil
    end

    local extension = ScriptUnit.has_extension(unit, "visual_loadout_system")
    local item = extension and extension:item_from_slot(slot)

    return item and item.name
end

local previous = {}

local function override(slot, item_name)
    local player = local_player()
    local sync = Managers.profile_synchronization
    local host = sync and sync:synchronizer_host()

    if not player then
        say("no local player")

        return false
    end

    if not host then
        say("not the host here. Use the Psykhanium, a SoloPlay game or a game you host")

        return false
    end

    host:override_slot(player:peer_id(), player:local_player_id(), slot, item_name)
    say("override_slot(%s, %s) sent", slot, tostring(item_name))

    return true
end

local function status()
    say("%s: template %s (id %s, from %s), item %s (id %s, slot %s)", MARK.template, tostring(MARK.template_ok),
        tostring(MARK.template_id), tostring(MARK.donor), tostring(MARK.item_ok), tostring(MARK.item_id), tostring(MARK.slot))
    say("  grip package found: %s, blade package found: %s, dauntless sounds: %s, grip raise: %s", tostring(package_found(GRIP_UNIT)),
        tostring(package_found(BLADE_UNIT)), tostring(mod:get("dauntless_sounds")), mod:get("align_grip") ~= false and tostring(GRIP_RAISE) or "0")

    if MARK.last_error then
        say("  last error: %s", MARK.last_error)
    end
end

mod:command("chainsword2h", mod:localize("command_chainsword2h"), function(action)
    action = action or "status"

    if action == "status" then
        status()
    elseif action == "equip" then
        if not (MARK.template_ok and MARK.item_ok and MARK.slot) then
            say("%s not ready yet (template %s, item %s)", MARK.template, tostring(MARK.template_ok), tostring(MARK.item_ok))

            return
        end

        local player = local_player()

        previous[MARK.slot] = previous[MARK.slot] or (player and equipped_item_name(player, MARK.slot))
        override(MARK.slot, MARK.item)
    elseif action == "restore" then
        local any = false

        for slot, item_name in pairs(previous) do
            if item_name and override(slot, item_name) then
                previous[slot] = nil
                any = true
            end
        end

        if not any then
            say("nothing to restore (equip first)")
        end
    else
        say("usage: /chainsword2h [status|equip|restore]")
    end
end)
