local mod = get_mod("QIangIQsChainsword2h")

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = false,
    options = {
        widgets = {
            {
                setting_id = "moveset",
                type = "dropdown",
                default_value = "m1",
                options = {
                    { text = "moveset_m1", value = "m1" },
                    { text = "moveset_m2", value = "m2" },
                },
            },
            { setting_id = "dauntless_sounds", type = "checkbox", default_value = true },
            { setting_id = "align_grip", type = "checkbox", default_value = true },
            { setting_id = "add_to_unlock_list", type = "checkbox", default_value = true },
            { setting_id = "unlock_level", type = "numeric", default_value = 1, range = { 1, 30 }, decimals_number = 0 },
            { setting_id = "unlock_zealot", type = "checkbox", default_value = true },
            { setting_id = "unlock_veteran", type = "checkbox", default_value = false },
            { setting_id = "unlock_psyker", type = "checkbox", default_value = false },
            { setting_id = "unlock_adamant", type = "checkbox", default_value = false },
            { setting_id = "debug", type = "checkbox", default_value = false },
        },
    },
}
