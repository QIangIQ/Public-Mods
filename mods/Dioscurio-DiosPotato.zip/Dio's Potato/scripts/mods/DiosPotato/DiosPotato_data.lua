local mod = get_mod("DiosPotato")

-- checkbox and numeric widgets only (same rule as the other Dio mods: older DMF installs choke on the rest)
return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			{ setting_id = "enforce", type = "checkbox", default_value = true, tooltip = "enforce_tooltip" },
			{ setting_id = "lod", type = "numeric", default_value = 0.15, range = { 0.05, 1 }, decimals_number = 2, tooltip = "lod_tooltip" },
			{ setting_id = "particles", type = "numeric", default_value = 0.5, range = { 0.1, 1 }, decimals_number = 2, tooltip = "particles_tooltip" },
			{ setting_id = "no_decals", type = "checkbox", default_value = true, tooltip = "no_decals_tooltip" },
			{ setting_id = "hud_drive", type = "checkbox", default_value = true, tooltip = "hud_drive_tooltip" },
			{ setting_id = "hud_rate", type = "numeric", default_value = 20, range = { 5, 60 }, decimals_number = 0, tooltip = "hud_rate_tooltip" },
		},
	},
}
