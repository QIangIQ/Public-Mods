local mod = get_mod("DiosPotato")

--[[
    Dio's Potato: pins the few frame-rate settings that sit below what the
    options menu and MoreGraphicsOptions allow, and drives UI Throttle.

    WHAT IT TOUCHES
      render_settings.lod_object_multiplier   how early models drop to their
                                              low-poly versions (menu minimum 0.7)
      render_settings.particles_capacity_multiplier
      performance_settings.max_impact_decals  bullet holes   (menu minimum 5)
      performance_settings.max_footstep_decals               (menu minimum 5)
      UI Throttle's refresh rates, if that mod is installed

    Values are written the way the game writes them itself
    (settings_utils.lua set_user_setting): Application.set_user_setting, plus
    Application.set_render_setting for a render value so it applies at once.
    The decal manager re-reads its limits every frame (decal_manager.lua
    _check_new_user_settings), so those need nothing more.

    A value is written only when it differs, so a normal launch does nothing.
    The first value this mod replaces is remembered; /potato_undo puts those
    back and switches the mod's enforcing off.
--]]

local function near(a, b)
	if type(a) == "number" and type(b) == "number" then
		return math.abs(a - b) < 0.0005
	end
	return a == b
end

local changed = {}

local function push(location, key, value)
	local now = Application.user_setting(location, key)
	if near(now, value) then
		return false
	end
	local memo = "orig_" .. key
	if mod:get(memo) == nil and now ~= nil then
		mod:set(memo, now, false)
	end
	Application.set_user_setting(location, key, value)
	if location == "render_settings" then
		Application.set_render_setting(key, tostring(value))
	end
	changed[#changed + 1] = string.format("%s %s -> %s", key, tostring(now), tostring(value))
	return true
end

local THROTTLE_IDS = { "general_hud_fps", "player_buffs_fps", "personal_player_panel_fps", "world_markers_fps", "combat_feed_fps" }

local function push_hud_rate()
	local throttle = get_mod("UIThrottle")
	if not throttle or not mod:get("hud_drive") then
		return false
	end
	local rate = mod:get("hud_rate") or 20
	for i = 1, #THROTTLE_IDS do
		throttle:set(THROTTLE_IDS[i], rate, true)
	end
	-- teammates' panels can run a little slower; they are staggered so they do not all land on one frame
	throttle:set("team_panels_fps", math.max(5, math.floor(rate * 0.75)), true)
	-- marker POSITIONS stay every frame: a healthbar that trails its enemy is worse than a slow one
	throttle:set("world_markers_position_fps", 0, true)
	return true
end

local function apply(announce)
	changed = {}
	if mod:get("enforce") then
		push("render_settings", "lod_object_multiplier", mod:get("lod") or 0.15)
		push("render_settings", "particles_capacity_multiplier", mod:get("particles") or 0.5)
		if mod:get("no_decals") then
			push("performance_settings", "max_impact_decals", 0)
			push("performance_settings", "max_footstep_decals", 0)
		end
		if #changed > 0 then
			Application.save_user_settings()
		end
	end
	if announce or #changed > 0 then
		mod:echo("%s", #changed > 0 and ("Potato set: " .. table.concat(changed, ", ")) or "Potato: nothing to change.")
	end
end

mod.on_all_mods_loaded = function()
	apply(false)
	if not mod:get("hud_seeded") and push_hud_rate() then
		mod:set("hud_seeded", true, false)
	end
end

mod.on_setting_changed = function(id)
	if id == "hud_rate" or id == "hud_drive" then
		push_hud_rate()
	elseif id == "enforce" or id == "lod" or id == "particles" or id == "no_decals" then
		apply(false)
	end
end

mod:command("potato", "Dio's Potato: show the live values and re-apply them", function()
	apply(true)
	mod:echo("%s", string.format("lod %s, particles %s, impact decals %s, footstep decals %s, blood decals %s, ragdolls %s",
		tostring(Application.user_setting("render_settings", "lod_object_multiplier")),
		tostring(Application.user_setting("render_settings", "particles_capacity_multiplier")),
		tostring(Application.user_setting("performance_settings", "max_impact_decals")),
		tostring(Application.user_setting("performance_settings", "max_footstep_decals")),
		tostring(Application.user_setting("performance_settings", "max_blood_decals")),
		tostring(Application.user_setting("performance_settings", "max_ragdolls"))))
	local throttle = get_mod("UIThrottle")
	mod:echo("%s", throttle and ("UI Throttle: HUD at " .. tostring(throttle:get("general_hud_fps")) .. " updates a second")
		or "UI Throttle is not installed, so the HUD rate slider does nothing.")
end)

local UNDO = {
	{ "render_settings", "lod_object_multiplier" },
	{ "render_settings", "particles_capacity_multiplier" },
	{ "performance_settings", "max_impact_decals" },
	{ "performance_settings", "max_footstep_decals" },
}

mod:command("potato_undo", "Dio's Potato: put back the values from before this mod and stop enforcing", function()
	mod:set("enforce", false, false)
	local n = 0
	for i = 1, #UNDO do
		local location, key = UNDO[i][1], UNDO[i][2]
		local old = mod:get("orig_" .. key)
		if old ~= nil then
			Application.set_user_setting(location, key, old)
			if location == "render_settings" then
				Application.set_render_setting(key, tostring(old))
			end
			n = n + 1
		end
	end
	if n > 0 then
		Application.save_user_settings()
	end
	mod:echo("%s", "Potato: restored " .. n .. " values. Enforcing is off.")
end)
