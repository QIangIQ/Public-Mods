return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`Dio's Potato` encountered an error loading the Darktide Mod Framework.")
		new_mod("DiosPotato", {
			mod_script       = "Dio's Potato/scripts/mods/DiosPotato/DiosPotato",
			mod_data         = "Dio's Potato/scripts/mods/DiosPotato/DiosPotato_data",
			mod_localization = "Dio's Potato/scripts/mods/DiosPotato/DiosPotato_localization",
		})
	end,
	version = "1.0.0",
	author = "Dioscurio",
	packages = {},
}
