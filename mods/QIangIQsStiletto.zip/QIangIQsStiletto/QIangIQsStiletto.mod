return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsStiletto` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsStiletto", {
            mod_script = "QIangIQsStiletto/scripts/mods/QIangIQsStiletto/QIangIQsStiletto",
            mod_data = "QIangIQsStiletto/scripts/mods/QIangIQsStiletto/QIangIQsStiletto_data",
            mod_localization = "QIangIQsStiletto/scripts/mods/QIangIQsStiletto/QIangIQsStiletto_localization",
        })
    end,
    version = "1.1.11",
    author = "QIangIQ",
    load_after = { "CustomAssets" },
    packages = {},
}
