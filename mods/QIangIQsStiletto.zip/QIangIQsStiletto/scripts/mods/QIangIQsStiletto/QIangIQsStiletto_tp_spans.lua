-- seconds of each CS2 clip in Custom/st_tp_driver (tp_bake_cs2.py, 461 frames at 30 fps)
return {
    draw = { start = 0.0000, length = 1.0000 },
    light_miss1 = { start = 1.1000, length = 1.1667 },
    light_miss2 = { start = 2.3667, length = 1.1667 },
    heavy_miss1 = { start = 3.6333, length = 1.1667 },
    light_backstab = { start = 4.9000, length = 1.1667 },
    lookat01 = { start = 6.1667, length = 4.0000 },
    lookat02 = { start = 10.2667, length = 5.0000 },
}
