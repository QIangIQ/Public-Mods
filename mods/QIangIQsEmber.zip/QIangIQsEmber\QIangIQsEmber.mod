return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsEmber` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsEmber", {
            mod_script = "QIangIQsEmber/scripts/mods/QIangIQsEmber/QIangIQsEmber",
            mod_data = "QIangIQsEmber/scripts/mods/QIangIQsEmber/QIangIQsEmber_data",
            mod_localization = "QIangIQsEmber/scripts/mods/QIangIQsEmber/QIangIQsEmber_localization",
        })
    end,
    version = "1.9.1",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
