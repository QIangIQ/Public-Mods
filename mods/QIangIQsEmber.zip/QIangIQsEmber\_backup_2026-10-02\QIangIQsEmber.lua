-- QIangIQ's Ember Heirloom: swaps the local player's body for a Custom Assets unit
-- (third person, first-person arms, and menu / operative-select previews).
-- Author: QIangIQ
local mod = get_mod("QIangIQsEmber")

mod.AUTHOR = "QIangIQ"

-- Every piece is its own Custom Assets unit: Custom Assets id = <Mod>:<Custom folder>, unit name =
-- the --asset-path used at compile time. The base is the bare body; each clothing part is a separate
-- unit (and a separate first-person arms unit when it covers the arms) that is spawned and linked the
-- same way, so parts can be switched on and off one by one.
local BODY = "ember_heirloom"
local ARMS = "ember_heirloom_arms"
local function asset_id(name)
    return "QIangIQsEmber:" .. name
end
local function unit_name(name)
    return "content/mods/qiangiq_ember/" .. name
end
local BODY_UNIT = unit_name(BODY)
local ARMS_UNIT = unit_name(ARMS)
-- { id (setting "part_<id>"), body = Custom folder of the third-person unit, arms = folder of the first-person unit or nil,
--   default = false for parts that start switched off, needs = id of a part that must be on as well,
--   glow = slider setting for the part's emissive material, glow_default, color = colour setting,
--   setting = id of another part whose on/off option this part shares (it has no option of its own) }
local PARTS = {

}
local PART_BY_ID = {}
for _, part in ipairs(PARTS) do
    PART_BY_ID[part.id] = part
end
local function part_on(part)
    local on = mod:get("part_" .. (part.setting or part.id))
    if on == nil then
        on = part.default ~= false
    end
    if on and part.needs and PART_BY_ID[part.needs] then
        return part_on(PART_BY_ID[part.needs])
    end
    return on and true or false
end

-- QIangIQ character swap mods: only one model is shown at a time. Turning one on (option,
-- keybind or chat command) switches the others off through their saved "model_enabled" setting
-- (DMFMod:set / DMFMod:get, dmf/modules/core/settings.lua).
local CHARACTER_MODS = { "QIangIQsAnubis", "QIangIQsDominanceAnubis", "QIangIQsEmber", "QIangIQsCitlali", "QIangIQsYvonne", "QIangIQsKulveTaroth" }

-- The model is fitted to one skeleton (human); bodies of the other breed use a different
-- skeleton, so they are left alone. Breed names as keyed in player_character_constants.lua
-- (human / ogryn).
local EXCLUDED_BREEDS = { ogryn = true }

-- player_unit_visual_loadout_extension.lua:205-206 keeps the breed on the extension itself
-- (self._static_profile_properties.breed), so it is known even when this mod is loaded mid-game.
local function ext_breed(ext)
    local props = ext._static_profile_properties
    return (props and props.breed) or ext.__qiangiq_breed
end

local custom_assets = nil
local ready = {} -- [Custom folder] = true once its package is loaded
local function model_on()
    return mod:get("model_enabled") ~= false
end

-- extensions / UI spawners we have touched (weak keys)
local tracked = setmetatable({}, { __mode = "k" })
local tracked_ui = setmetatable({}, { __mode = "k" })

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function local_player()
    local players = Managers.player
    if not players then
        return nil
    end
    local ok, player = pcall(players.local_player_safe, players, 1)
    return ok and player or nil
end

-- slot_body_* / slot_gear_* hold the body parts and cosmetics; weapons live in other slots
local function hide_body_slots(slots, key)
    if not slots then
        return
    end
    local attachments_key = key == "unit_1p" and "attachments_by_unit_1p" or "attachments_by_unit_3p"
    for slot_name, slot in pairs(slots) do
        if string.find(slot_name, "^slot_body_") or string.find(slot_name, "^slot_gear_") then
            local unit = slot[key]
            if unit_ok(unit) then
                Unit.set_unit_visibility(unit, false, true)
                local attachments = slot[attachments_key] and slot[attachments_key][unit]
                if attachments then
                    for i = 1, #attachments do
                        if unit_ok(attachments[i]) then
                            Unit.set_unit_visibility(attachments[i], false, true)
                        end
                    end
                end
            end
        end
    end
end

-- In-game player unit -----------------------------------------------------------

local function is_local_human(ext)
    local player = local_player()
    return player ~= nil and ext._player == player
end

local function delete_unit(unit)
    if unit_ok(unit) then
        local unit_spawner = Managers.state and Managers.state.unit_spawner
        if unit_spawner then
            unit_spawner:mark_for_deletion(unit)
        end
    end
end

local function delete_all(units)
    if units then
        for id, unit in pairs(units) do
            delete_unit(unit)
            units[id] = nil
        end
    end
end

local function despawn(ext)
    delete_unit(ext.__qiangiq_ember_unit)
    delete_unit(ext.__qiangiq_ember_arms)
    ext.__qiangiq_ember_unit = nil
    ext.__qiangiq_ember_arms = nil
    delete_all(ext.__qiangiq_ember_parts)
    delete_all(ext.__qiangiq_ember_part_arms)
end

-- same spawn + link pattern the game uses for gear (visual_loadout_customization.lua)
local function spawn_linked(world, parent, unit_name, is_first_person)
    local unit_spawner = Managers.state and Managers.state.unit_spawner
    if not (world and unit_spawner and unit_ok(parent)) then
        return nil
    end
    local unit = unit_spawner:spawn_unit(unit_name, Unit.world_pose(parent, 1))
    if not unit then
        return nil
    end
    if is_first_person then
        Unit.set_unit_culling(unit, false)
    end
    World.link_unit(world, unit, 1, parent, 1, World.LINK_MODE_NODE_NAME)
    return unit
end

-- Glow slider for the model's emissive layer (nil = the model has none). The layer's material is the
-- compiler's PBR emissive one, whose brightness is its scalar variable "intensity"
-- (pbr_emissive_profile.cpp, id32 0x32f447e5 = "intensity"); set the way the game applies scalar
-- material overrides (visual_loadout_customization.lua:516, Unit.set_scalar_for_materials(unit, name, value, true)).
local GLOW_SETTING = "glow_brightness"
local GLOW_DEFAULT = 1

local function apply_glow(unit)
    if GLOW_SETTING and unit_ok(unit) then
        Unit.set_scalar_for_materials(unit, "intensity", mod:get(GLOW_SETTING) or GLOW_DEFAULT, true)
    end
end

-- Emissive colours offered for parts with a colour option (emissive_color = id32 0xc985395a in the same
-- material; a Vector3 set like visual_loadout_customization.lua:534, Unit.set_vector3_for_materials).
local GLOW_COLORS = {
    cyan = { 0, 0.85, 1 },
    pink = { 1, 0.08, 0.55 },
    green = { 0.15, 1, 0.2 },
    gold = { 1, 0.69, 0.06 },
    purple = { 0.55, 0.15, 1 },
    red = { 1, 0.04, 0.04 },
    white = { 1, 1, 1 },
}

local function apply_part_glow(part, unit)
    if part.glow and unit_ok(unit) then
        Unit.set_scalar_for_materials(unit, "intensity", mod:get(part.glow) or part.glow_default, true)
        local c = part.color and GLOW_COLORS[mod:get(part.color) or "cyan"]
        if c then
            Unit.set_vector3_for_materials(unit, "emissive_color", Vector3(c[1], c[2], c[3]), true)
        end
    end
end

-- Tail size (nil = not offered). Scales are set on the tail's own nodes, the call the game uses to size a
-- unit (ui_profile_spawner.lua:1722, Unit.set_local_scale(unit, node, Vector3)). A bone runs along its
-- local Z (see the physics notes), so X/Y is thickness and Z is length; children inherit it.
local TAIL = nil

local function apply_tail(unit)
    if not (TAIL and unit_ok(unit) and Unit.has_node(unit, TAIL.thick) and Unit.has_node(unit, TAIL.long)) then
        return
    end
    local on = mod:get("tail_custom")
    local thick = on and math.max(mod:get("tail_thickness") or 1, 0.1) or 1
    local long = on and math.max(mod:get("tail_length") or 1, 0.1) or 1
    Unit.set_local_scale(unit, Unit.node(unit, TAIL.thick), Vector3(thick, thick, 1))
    Unit.set_local_scale(unit, Unit.node(unit, TAIL.long), Vector3(1, 1, long))
end

local function apply(ext, first_person_mode)
    if not model_on() then
        despawn(ext)
        return
    end
    local world = ext.__qiangiq_world

    local fp_arms = mod:get("first_person_arms") and true or false
    ext.__qiangiq_ember_fp = first_person_mode and true or false

    if ready[BODY] and not unit_ok(ext.__qiangiq_ember_unit) then
        ext.__qiangiq_ember_unit = spawn_linked(world, ext._unit, BODY_UNIT, false)
    end
    if ready[ARMS] and fp_arms and not unit_ok(ext.__qiangiq_ember_arms) then
        ext.__qiangiq_ember_arms = spawn_linked(world, ext._first_person_unit, ARMS_UNIT, true)
    elseif not fp_arms and ext.__qiangiq_ember_arms then
        delete_unit(ext.__qiangiq_ember_arms)
        ext.__qiangiq_ember_arms = nil
    end

    local body = ext.__qiangiq_ember_unit
    local arms = ext.__qiangiq_ember_arms
    apply_glow(body)
    apply_glow(arms)
    apply_tail(body)
    if unit_ok(body) then
        Unit.set_unit_visibility(body, not first_person_mode, true)
    end
    if unit_ok(arms) then
        Unit.set_unit_visibility(arms, first_person_mode and true or false, true)
    end

    -- clothing parts: spawned next to the body while their option is on, deleted when it is off
    local parts = ext.__qiangiq_ember_parts or {}
    local part_arms = ext.__qiangiq_ember_part_arms or {}
    ext.__qiangiq_ember_parts = parts
    ext.__qiangiq_ember_part_arms = part_arms
    for _, part in ipairs(PARTS) do
        local id = part.id
        local on = part_on(part)
        if on and ready[part.body] and unit_ok(body) and not unit_ok(parts[id]) then
            parts[id] = spawn_linked(world, ext._unit, unit_name(part.body), false)
        elseif not on and parts[id] then
            delete_unit(parts[id])
            parts[id] = nil
        end
        if unit_ok(parts[id]) then
            apply_part_glow(part, parts[id])
            Unit.set_unit_visibility(parts[id], not first_person_mode, true)
        end
        if part.arms then
            local want = on and fp_arms
            if want and ready[part.arms] and unit_ok(arms) and not unit_ok(part_arms[id]) then
                part_arms[id] = spawn_linked(world, ext._first_person_unit, unit_name(part.arms), true)
            elseif not want and part_arms[id] then
                delete_unit(part_arms[id])
                part_arms[id] = nil
            end
            if unit_ok(part_arms[id]) then
                apply_part_glow(part, part_arms[id])
                Unit.set_unit_visibility(part_arms[id], first_person_mode and true or false, true)
            end
        end
    end

    if mod:get("hide_body") then
        if not first_person_mode and unit_ok(body) then
            hide_body_slots(ext._equipment, "unit_3p")
        elseif first_person_mode and unit_ok(arms) then
            hide_body_slots(ext._equipment, "unit_1p")
        end
    end
end

-- Menu previews (operative select, inventory, lobby) --------------------------

local function ui_profile_is_mine(profile)
    if not profile then
        return false
    end
    -- skip previews of characters that belong to someone else (other players, bots)
    local players = Managers.player and Managers.player:players()
    local me = local_player()
    if players and profile.character_id then
        for _, player in pairs(players) do
            if player ~= me and player.character_id and player:character_id() == profile.character_id then
                return false
            end
        end
    end
    return true
end

local function ui_despawn(spawner)
    local unit = spawner.__qiangiq_ember_unit
    spawner.__qiangiq_ember_unit = nil
    spawner.__qiangiq_ember_parent = nil
    if unit_ok(unit) and spawner._world then
        -- same call ui_profile_spawner.lua uses for its own character unit
        World.destroy_unit(spawner._world, unit)
    end
    local parts = spawner.__qiangiq_ember_parts
    if parts then
        for id, part_unit in pairs(parts) do
            if unit_ok(part_unit) and spawner._world then
                World.destroy_unit(spawner._world, part_unit)
            end
            parts[id] = nil
        end
    end
end

local function ui_apply(spawner)
    local data = spawner._character_spawn_data
    if not data or not unit_ok(data.unit_3p) then
        return
    end
    -- ui_profile_spawner.lua:179-180 reads profile.archetype.breed
    local archetype = data.profile and data.profile.archetype
    local excluded = archetype and EXCLUDED_BREEDS[archetype.breed]
    if excluded or not (model_on() and mod:get("menu_previews") and ready[BODY] and ui_profile_is_mine(data.profile)) then
        if spawner.__qiangiq_ember_unit then
            ui_despawn(spawner)
            if spawner._visible then
                spawner:_update_items_visibility()
            end
        end
        return
    end
    if spawner.__qiangiq_ember_parent ~= data.unit_3p then
        ui_despawn(spawner)
    end
    local unit = spawner.__qiangiq_ember_unit
    if not unit_ok(unit) then
        local world = spawner._world
        unit = World.spawn_unit_ex(world, BODY_UNIT, nil, Unit.world_pose(data.unit_3p, 1))
        World.link_unit(world, unit, 1, data.unit_3p, 1, World.LINK_MODE_NODE_NAME)
        spawner.__qiangiq_ember_unit = unit
        spawner.__qiangiq_ember_parent = data.unit_3p
        tracked_ui[spawner] = true
    end
    apply_glow(unit)
    apply_tail(unit)
    Unit.set_unit_visibility(unit, spawner._visible and true or false, true)
    local parts = spawner.__qiangiq_ember_parts or {}
    spawner.__qiangiq_ember_parts = parts
    for _, part in ipairs(PARTS) do
        local id = part.id
        local on = part_on(part)
        if on and ready[part.body] and not unit_ok(parts[id]) then
            local world = spawner._world
            parts[id] = World.spawn_unit_ex(world, unit_name(part.body), nil, Unit.world_pose(data.unit_3p, 1))
            World.link_unit(world, parts[id], 1, data.unit_3p, 1, World.LINK_MODE_NODE_NAME)
        elseif not on and parts[id] then
            if unit_ok(parts[id]) then
                World.destroy_unit(spawner._world, parts[id])
            end
            parts[id] = nil
        end
        if unit_ok(parts[id]) then
            apply_part_glow(part, parts[id])
            Unit.set_unit_visibility(parts[id], spawner._visible and true or false, true)
        end
    end
    if spawner._visible and mod:get("hide_body") then
        hide_body_slots(data.slots, "unit_3p")
    end
end

-- Physics ------------------------------------------------------------------------
-- The model's own physics bones (the avatar's "Phy_*" chains) are in the compiled units as extra nodes
-- that the player's skeleton does not have, so node-name linking leaves them at their rest pose. Each
-- one is driven here as a damped spring: its tip is a point that lags behind where the rest pose puts
-- it and is pulled back, and the bone is turned to point at it. Only engine calls the game's own
-- scripts use: Unit.node / has_node / local_rotation / local_position / world_position /
-- world_rotation / set_local_rotation, Quaternion.multiply / inverse / rotate / axis_angle,
-- Vector3.cross / dot / length.
-- { bone, parent, area, length (m) }, parents first
-- (from the model's armature). A parent that is not in this list is a normal skeleton / helper node.
local JIGGLE_BONES = {
    { "arm_cloth_r_001", "j_rightforearm", "drape", 0.088 },
    { "arm_cloth_r", "j_rightforearm", "drape", 0.073 },
    { "leg_knot_r_001", "j_rightupleg", "cloth", 0.039 },
    { "leg_dangle_l_009", "j_leftupleg", "cloth", 0.058 },
    { "leg_dangle_r_001", "j_rightupleg", "cloth", 0.058 },
    { "leg_knot_l_008", "j_leftupleg", "cloth", 0.038 },
    { "leg_dangle_r_009", "j_rightupleg", "cloth", 0.058 },
    { "leg_knot_l_001", "j_leftupleg", "cloth", 0.039 },
    { "arm_cloth_r_002", "arm_cloth_r_001", "drape", 0.093 },
    { "leg_dangle_l_001", "j_leftupleg", "cloth", 0.058 },
    { "leg_knot_r_008", "j_rightupleg", "cloth", 0.038 },
    { "leg_knot_r_002", "leg_knot_r_001", "cloth", 0.051 },
    { "leg_dangle_l_010", "leg_dangle_l_009", "cloth", 0.061 },
    { "leg_knot_r_009", "leg_knot_r_008", "cloth", 0.050 },
    { "leg_dangle_r_010", "leg_dangle_r_009", "cloth", 0.061 },
    { "leg_dangle_r_002", "leg_dangle_r_001", "cloth", 0.061 },
    { "leg_knot_l_009", "leg_knot_l_008", "cloth", 0.050 },
    { "arm_cloth_r_003", "arm_cloth_r_002", "drape", 0.105 },
    { "leg_knot_l_002", "leg_knot_l_001", "cloth", 0.051 },
    { "leg_dangle_l_002", "leg_dangle_l_001", "cloth", 0.061 },
    { "leg_knot_r_003", "leg_knot_r_002", "cloth", 0.048 },
    { "leg_dangle_r_003", "leg_dangle_r_002", "cloth", 0.059 },
    { "leg_dangle_r_011", "leg_dangle_r_010", "cloth", 0.059 },
    { "arm_cloth_r_004", "arm_cloth_r_003", "drape", 0.109 },
    { "leg_dangle_l_011", "leg_dangle_l_010", "cloth", 0.059 },
    { "leg_dangle_l_003", "leg_dangle_l_002", "cloth", 0.059 },
    { "leg_knot_l_010", "leg_knot_l_009", "cloth", 0.047 },
    { "leg_knot_r_010", "leg_knot_r_009", "cloth", 0.047 },
    { "leg_knot_l_003", "leg_knot_l_002", "cloth", 0.048 },
    { "head_flames_middle_l_001", "j_head", "plume", 0.038 },
    { "head_flames_middle", "j_head", "plume", 0.036 },
    { "leg_dangle_r_004", "leg_dangle_r_003", "cloth", 0.058 },
    { "head_flames_front_001", "j_head", "plume", 0.028 },
    { "head_flames_back_l_001", "j_head", "plume", 0.036 },
    { "leg_knot_r_004", "leg_knot_r_003", "cloth", 0.055 },
    { "arm_cloth_r_005", "arm_cloth_r_004", "drape", 0.105 },
    { "head_flame_middle", "j_head", "plume", 0.045 },
    { "head_flames_back_l", "j_head", "plume", 0.028 },
    { "head_flames_middle_l", "j_head", "plume", 0.031 },
    { "head_flame_back", "j_head", "plume", 0.048 },
    { "head_flame_back_001", "j_head", "plume", 0.048 },
    { "leg_knot_l_004", "leg_knot_l_003", "cloth", 0.055 },
    { "head_flame_front", "j_head", "plume", 0.048 },
    { "head_flame_middle_001", "j_head", "plume", 0.045 },
    { "leg_dangle_l_012", "leg_dangle_l_011", "cloth", 0.058 },
    { "head_flames_middle_r_001", "j_head", "plume", 0.037 },
    { "leg_dangle_l_004", "leg_dangle_l_003", "cloth", 0.058 },
    { "leg_knot_l_011", "leg_knot_l_010", "cloth", 0.054 },
    { "leg_knot_r_011", "leg_knot_r_010", "cloth", 0.054 },
    { "head_flames_back", "j_head", "plume", 0.032 },
    { "head_flames_middle_001", "j_head", "plume", 0.038 },
    { "head_flame_front_001", "j_head", "plume", 0.048 },
    { "head_flames_back_001", "j_head", "plume", 0.034 },
    { "head_flames_back_r", "j_head", "plume", 0.028 },
    { "head_flames_middle_r", "j_head", "plume", 0.031 },
    { "leg_dangle_r_012", "leg_dangle_r_011", "cloth", 0.058 },
    { "head_flames_back_r_001", "j_head", "plume", 0.034 },
    { "head_flames_middle_l_002", "head_flames_middle_l_001", "plume", 0.045 },
    { "arm_cloth_r_006", "arm_cloth_r_005", "drape", 0.076 },
    { "head_flames_middle_002", "head_flames_middle_001", "plume", 0.042 },
    { "leg_knot_r_012", "leg_knot_r_011", "cloth", 0.041 },
    { "head_flames_back_r_002", "head_flames_back_r_001", "plume", 0.035 },
    { "leg_dangle_l_013", "leg_dangle_l_012", "cloth", 0.059 },
    { "head_flames_middle_r_002", "head_flames_middle_r_001", "plume", 0.040 },
    { "leg_dangle_r_005", "leg_dangle_r_004", "cloth", 0.059 },
    { "head_flame_middle_002", "head_flame_middle_001", "plume", 0.045 },
    { "leg_knot_r_005", "leg_knot_r_004", "cloth", 0.042 },
    { "head_flame_back_002", "head_flame_back_001", "plume", 0.048 },
    { "head_flames_back_l_002", "head_flames_back_l_001", "plume", 0.038 },
    { "leg_dangle_r_013", "leg_dangle_r_012", "cloth", 0.059 },
    { "head_flames_front_002", "head_flames_front_001", "plume", 0.029 },
    { "leg_knot_l_005", "leg_knot_l_004", "cloth", 0.041 },
    { "leg_dangle_l_005", "leg_dangle_l_004", "cloth", 0.059 },
    { "head_flame_front_002", "head_flame_front_001", "plume", 0.048 },
    { "head_flames_back_002", "head_flames_back_001", "plume", 0.036 },
    { "leg_knot_l_012", "leg_knot_l_011", "cloth", 0.041 },
    { "head_flames_middle_r_003", "head_flames_middle_r_002", "plume", 0.039 },
    { "head_flames_middle_003", "head_flames_middle_002", "plume", 0.039 },
    { "head_flames_back_003", "head_flames_back_002", "plume", 0.034 },
    { "leg_knot_r_013", "leg_knot_r_012", "cloth", 0.018 },
    { "head_flames_middle_l_003", "head_flames_middle_l_002", "plume", 0.043 },
    { "leg_dangle_l_014", "leg_dangle_l_013", "cloth", 0.058 },
    { "head_flame_back_003", "head_flame_back_002", "plume", 0.048 },
    { "head_flame_middle_003", "head_flame_middle_002", "plume", 0.045 },
    { "head_flames_back_l_003", "head_flames_back_l_002", "plume", 0.035 },
    { "leg_dangle_l_006", "leg_dangle_l_005", "cloth", 0.058 },
    { "arm_cloth_r_007", "arm_cloth_r_006", "drape", 0.059 },
    { "leg_knot_l_006", "leg_knot_l_005", "cloth", 0.018 },
    { "leg_dangle_r_014", "leg_dangle_r_013", "cloth", 0.058 },
    { "head_flames_back_r_003", "head_flames_back_r_002", "plume", 0.036 },
    { "head_flames_front_003", "head_flames_front_002", "plume", 0.028 },
    { "head_flame_front_003", "head_flame_front_002", "plume", 0.048 },
    { "leg_knot_l_013", "leg_knot_l_012", "cloth", 0.018 },
    { "leg_dangle_r_006", "leg_dangle_r_005", "cloth", 0.058 },
    { "leg_knot_r_006", "leg_knot_r_005", "cloth", 0.018 },
    { "head_flame_front_004", "head_flame_front_003", "plume", 0.048 },
    { "arm_cloth_r_008", "arm_cloth_r_007", "drape", 0.048 },
    { "leg_dangle_l_007", "leg_dangle_l_006", "cloth", 0.057 },
    { "head_flames_middle_r_004", "head_flames_middle_r_003", "plume", 0.065 },
    { "leg_dangle_l_015", "leg_dangle_l_014", "cloth", 0.057 },
    { "head_flames_back_r_004", "head_flames_back_r_003", "plume", 0.034 },
    { "head_flames_middle_004", "head_flames_middle_003", "plume", 0.062 },
    { "leg_dangle_r_015", "leg_dangle_r_014", "cloth", 0.057 },
    { "head_flames_front_004", "head_flames_front_003", "plume", 0.025 },
    { "head_flame_back_004", "head_flame_back_003", "plume", 0.048 },
    { "leg_dangle_r_007", "leg_dangle_r_006", "cloth", 0.057 },
    { "head_flames_back_l_004", "head_flames_back_l_003", "plume", 0.030 },
    { "head_flames_middle_l_004", "head_flames_middle_l_003", "plume", 0.051 },
    { "head_flames_back_004", "head_flames_back_003", "plume", 0.031 },
    { "head_flame_middle_004", "head_flame_middle_003", "plume", 0.045 },
    { "head_flames_middle_r_005", "head_flames_middle_r_004", "plume", 0.065 },
    { "head_flames_back_r_005", "head_flames_back_r_004", "plume", 0.025 },
    { "head_flame_front_005", "head_flame_front_004", "plume", 0.048 },
    { "head_flames_front_005", "head_flames_front_004", "plume", 0.023 },
    { "head_flame_middle_005", "head_flame_middle_004", "plume", 0.045 },
    { "head_flames_middle_l_005", "head_flames_middle_l_004", "plume", 0.051 },
    { "head_flames_back_005", "head_flames_back_004", "plume", 0.028 },
    { "arm_cloth_r_009", "arm_cloth_r_008", "drape", 0.055 },
    { "head_flames_middle_005", "head_flames_middle_004", "plume", 0.062 },
    { "head_flame_back_005", "head_flame_back_004", "plume", 0.048 },
    { "head_flames_back_l_005", "head_flames_back_l_004", "plume", 0.023 },
    { "arm_cloth_r_010", "arm_cloth_r_009", "drape", 0.058 },
    { "head_flames_back_r_006", "head_flames_back_r_005", "plume", 0.025 },
    { "head_flames_back_l_006", "head_flames_back_l_005", "plume", 0.023 },
    { "head_flame_back_006", "head_flame_back_005", "plume", 0.048 },
    { "head_flames_back_006", "head_flames_back_005", "plume", 0.028 },
    { "head_flame_front_006", "head_flame_front_005", "plume", 0.048 },
    { "head_flame_middle_006", "head_flame_middle_005", "plume", 0.045 },
    { "arm_cloth_l_001", "j_leftforearm", "drape", 0.088 },
    { "arm_cloth_r_011", "arm_cloth_r_010", "drape", 0.063 },
    { "arm_cloth_l", "j_leftforearm", "drape", 0.073 },
    { "arm_cloth_l_002", "arm_cloth_l_001", "drape", 0.093 },
    { "arm_cloth_r_012", "arm_cloth_r_011", "drape", 0.059 },
    { "arm_cloth_l_003", "arm_cloth_l_002", "drape", 0.105 },
    { "arm_cloth_r_013", "arm_cloth_r_012", "drape", 0.057 },
    { "arm_cloth_r_014", "arm_cloth_r_013", "drape", 0.045 },
    { "arm_cloth_l_004", "arm_cloth_l_003", "drape", 0.109 },
    { "arm_cloth_r_015", "arm_cloth_r_014", "drape", 0.042 },
    { "arm_cloth_l_005", "arm_cloth_l_004", "drape", 0.105 },
    { "arm_cloth_l_006", "arm_cloth_l_005", "drape", 0.076 },
    { "arm_cloth_r_016", "arm_cloth_r_015", "drape", 0.026 },
    { "arm_cloth_l_007", "arm_cloth_l_006", "drape", 0.059 },
    { "arm_cloth_l_008", "arm_cloth_l_007", "drape", 0.048 },
    { "arm_cloth_l_009", "arm_cloth_l_008", "drape", 0.055 },
    { "arm_cloth_l_010", "arm_cloth_l_009", "drape", 0.058 },
    { "arm_cloth_l_011", "arm_cloth_l_010", "drape", 0.063 },
    { "arm_cloth_l_012", "arm_cloth_l_011", "drape", 0.060 },
    { "arm_cloth_l_013", "arm_cloth_l_012", "drape", 0.057 },
    { "arm_cloth_l_014", "arm_cloth_l_013", "drape", 0.045 },
    { "arm_cloth_l_015", "arm_cloth_l_014", "drape", 0.042 },
    { "arm_cloth_l_016", "arm_cloth_l_015", "drape", 0.026 },
}
-- per 60 fps frame: pull = share of the remaining offset removed, drag = share of velocity lost;
-- max_angle = largest swing of one bone from its rest pose (degrees); slider = the option that scales the area.
-- flow = every bone of the chain is its own free point (the chain bends bone by bone and a wave runs down
-- it); without it the bones after the first only follow the first one (one soft lump).
-- carry = share of the character's own travel the points are taken along with (1 = no trailing while running);
-- hang = the area takes part in the "hang" option (rest direction leaned towards straight down);
-- drape = the area always hangs straight down in the world (cloth hung from an arm);
-- total = largest lean of any bone from where it would point if its whole chain were stiff (degrees).
local JIGGLE_GROUPS = {
    breast = { pull = 0.22, drag = 0.16, max_angle = 14, slider = "jiggle_breast" },
    butt = { pull = 0.28, drag = 0.20, max_angle = 10, slider = "jiggle_butt" },
    thigh = { pull = 0.30, drag = 0.22, max_angle = 6, slider = "jiggle_butt" },
    tail = { pull = 0.07, drag = 0.34, max_angle = 32, slider = "jiggle_tail", flow = true, carry = 0.92, total = 50 },
    hair = { pull = 0.05, drag = 0.30, max_angle = 40, slider = "jiggle_hair", flow = true, carry = 0.92, hang = true, total = 45 },
    ear = { pull = 0.25, drag = 0.18, max_angle = 14, slider = "jiggle_ear" },
    drape = { pull = 0.10, drag = 0.40, max_angle = 28, slider = "jiggle_cloth", flow = true, carry = 0.95, drape = true },
    plume = { pull = 0.07, drag = 0.34, max_angle = 30, slider = "jiggle_hair", flow = true, carry = 0.92, total = 30 },
    cloth = { pull = 0.08, drag = 0.36, max_angle = 35, slider = "jiggle_cloth", flow = true, carry = 0.92, hang = true, total = 40 },
}
local jiggle_state = setmetatable({}, { __mode = "k" })
-- options, read once per change instead of every frame
local JIGGLE = { on = true, stiffness = 1, damping = 1, limit = 1, hang = 0, amount = {} }

local function jiggle_read_settings()
    JIGGLE.on = mod:get("jiggle") ~= false
    JIGGLE.stiffness = math.max(mod:get("jiggle_stiffness") or 1, 0.05)
    JIGGLE.damping = math.max(mod:get("jiggle_damping") or 1, 0.05)
    JIGGLE.limit = math.max(mod:get("jiggle_limit") or 1, 0.05)
    JIGGLE.hang = math.max(mod:get("jiggle_hang") or 0, 0)
    for name, g in pairs(JIGGLE_GROUPS) do
        JIGGLE.amount[name] = math.max(mod:get(g.slider) or 1, 0)
    end
end

local function jiggle_init(unit)
    local bones, by_name = {}, {}
    for _, def in ipairs(JIGGLE_BONES) do
        local name, parent_name = def[1], def[2]
        local parent = by_name[parent_name]
        -- usable when the unit has the bone and the node it hangs from (parts only carry what they need)
        if Unit.has_node(unit, name) and (parent or Unit.has_node(unit, parent_name)) then
            local node = Unit.node(unit, name)
            local b = {
                node = node,
                group = def[3],
                parent = parent,
                parent_node = not parent and Unit.node(unit, parent_name) or nil,
                rest = QuaternionBox(Unit.local_rotation(unit, node)),
                lpos = Vector3Box(Unit.local_position(unit, node)),
                -- the bone runs along its own local Z for its length (the compiler writes every node's
                -- local transform as glTF (x, y, z) -> (x, -z, y), and a glTF bone runs along its Y)
                tip = Vector3Box(Vector3(0, 0, def[4])),
            }
            bones[#bones + 1] = b
            by_name[name] = b
        end
    end
    return { bones = bones, active = false }
end

local function jiggle_rest(unit, state)
    for _, b in ipairs(state.bones) do
        Unit.set_local_rotation(unit, b.node, b.rest:unbox())
        b.px = nil
    end
    state.rx = nil
    state.active = false
end

local function jiggle_update(unit, dt)
    if not unit_ok(unit) then
        return
    end
    local state = jiggle_state[unit]
    if not state then
        state = jiggle_init(unit)
        jiggle_state[unit] = state
    end
    if not JIGGLE.on then
        if state.active then
            jiggle_rest(unit, state)
        end
        return
    end
    state.active = true
    local f = math.min(dt or 0.0167, 0.05) * 60
    -- how far the character itself travelled since the last frame (node 1 = the unit's root)
    local root = Unit.world_position(unit, 1)
    local travel = Vector3(0, 0, 0)
    if state.rx then
        travel = root - Vector3(state.rx, state.ry, state.rz)
        if Vector3.length(travel) > 2 then
            travel = Vector3(0, 0, 0)
        end
    end
    state.rx, state.ry, state.rz = root.x, root.y, root.z
    -- ground level under the character (its root is at its feet) and its facing, for draped cloth
    local floor = root.z + 0.02
    local back = Quaternion.forward(Unit.world_rotation(unit, 1))
    for _, b in ipairs(state.bones) do
        local g = JIGGLE_GROUPS[b.group]
        local amount = JIGGLE.amount[b.group] or 1
        local parent = b.parent
        local parent_rot, head, scale
        if parent then
            parent_rot, scale = parent.rot, parent.scale
            head = parent.head + Quaternion.rotate(parent_rot, b.lpos:unbox()) * scale
        else
            parent_rot = Unit.world_rotation(unit, b.parent_node)
            head = Unit.world_position(unit, b.node)
            -- world size of one model unit (characters can be scaled)
            local len = Vector3.length(b.lpos:unbox())
            scale = len > 1e-3 and Vector3.length(head - Unit.world_position(unit, b.parent_node)) / len or 1
            if scale < 1e-4 then
                scale = 1
            end
        end
        local rest_rot = Quaternion.multiply(parent_rot, b.rest:unbox())
        -- where the bone would point if the whole chain above it were stiff
        local rigid_rot = parent and Quaternion.multiply(parent.rigid, b.rest:unbox()) or rest_rot
        local tip_off = Quaternion.rotate(rest_rot, b.tip:unbox()) * scale
        local length = Vector3.length(tip_off)
        local world_rot = rest_rot
        if amount <= 0 then
            b.px = nil -- area switched off: stay on the rest pose
        elseif length > 1e-6 then
            local keep = (1 - math.min(g.drag * JIGGLE.damping, 0.95)) ^ f
            local pull = 1 - (1 - math.min(g.pull * JIGGLE.stiffness / amount, 0.95)) ^ f
            local max_angle = math.min(math.rad(g.max_angle) * amount * JIGGLE.limit, 1.4)
            local rest_dir = tip_off / length
            local rest_tip = head + tip_off
            local flow = g.flow
            -- goal_dir: the direction the bone is pulled towards and limited around
            local goal_dir = rest_dir
            if flow and g.drape then
                -- loose cloth hung from a limb: straight down in the world, whatever the limb does
                -- (its modelled angle to the limb is only right for the pose it was modelled in)
                goal_dir = Vector3(0, 0, -1)
                rest_tip = head + goal_dir * length
            elseif flow and g.hang and JIGGLE.hang > 0 then
                -- lean the direction the bone is pulled towards to straight down (world Z is up)
                local lean = rest_dir + Vector3(0, 0, -JIGGLE.hang)
                local ll = Vector3.length(lean)
                if ll > 1e-4 then
                    goal_dir = lean / ll
                    rest_tip = head + goal_dir * length
                end
            end
            -- a tip kept in the world lags when the body moves. Flowing chains keep every tip in the
            -- world; in the other areas only the bone on a normal skeleton node does, and the bones after
            -- it keep theirs relative to their own head, so they follow the bone before them
            local world_tip = flow or not parent
            local origin = world_tip and Vector3(0, 0, 0) or head
            local p, pp = rest_tip, rest_tip
            if b.px then
                p = origin + Vector3(b.px, b.py, b.pz)
                pp = origin + Vector3(b.qx, b.qy, b.qz)
                if flow then
                    local along = travel * g.carry
                    p, pp = p + along, pp + along
                end
                if Vector3.length(p - rest_tip) > 4 * length + 0.5 then
                    p, pp = rest_tip, rest_tip -- teleported: start over at rest
                end
            end
            local k, q = keep, pull
            if parent and not flow then
                -- a follower, not a second spring
                k, q = keep * 0.35, math.min(pull * 1.6, 0.9)
            end
            local nxt = p + (p - pp) * k + (rest_tip - p) * q
            local dir = nxt - head
            local dl = Vector3.length(dir)
            dir = dl > 1e-6 and dir / dl or goal_dir
            -- keep the swing within max_angle of the goal direction
            local axis = Vector3.cross(goal_dir, dir)
            local al = Vector3.length(axis)
            local angle = math.acos(math.max(-1, math.min(1, Vector3.dot(goal_dir, dir))))
            if al > 1e-6 and angle > max_angle then
                dir = Quaternion.rotate(Quaternion.axis_angle(axis / al, max_angle), goal_dir)
            end
            if g.drape and (head + dir * length).z < floor then
                -- the cloth is longer than the arm is high: what reaches the ground lies on it, trailing
                -- the way it already leans (behind the character when it hangs dead straight)
                local dz = math.max(-length, math.min(length, floor - head.z))
                local flat = math.sqrt(math.max(0, length * length - dz * dz))
                local hx, hy = dir.x, dir.y
                local hn = math.sqrt(hx * hx + hy * hy)
                if hn < 1e-3 then
                    hx, hy, hn = -back.x, -back.y, math.max(math.sqrt(back.x * back.x + back.y * back.y), 1e-3)
                end
                dir = Vector3(hx / hn * flat, hy / hn * flat, dz) / length
            end
            if g.total then
                -- and the whole chain within `total` of its stiff shape: per-bone limits add up along a
                -- long chain, which let the far end fold right over
                local rigid_dir = Quaternion.rotate(rigid_rot, b.tip:unbox())
                local rl = Vector3.length(rigid_dir)
                if rl > 1e-6 then
                    rigid_dir = rigid_dir / rl
                    local total = math.min(math.rad(g.total) * amount * JIGGLE.limit, 3)
                    local ax = Vector3.cross(rigid_dir, dir)
                    local axl = Vector3.length(ax)
                    if axl > 1e-6 and math.acos(math.max(-1, math.min(1, Vector3.dot(rigid_dir, dir)))) > total then
                        dir = Quaternion.rotate(Quaternion.axis_angle(ax / axl, total), rigid_dir)
                    end
                end
            end
            -- turn the bone from its rest direction to that direction
            axis = Vector3.cross(rest_dir, dir)
            al = Vector3.length(axis)
            angle = math.acos(math.max(-1, math.min(1, Vector3.dot(rest_dir, dir))))
            if al > 1e-6 and angle > 1e-5 then
                world_rot = Quaternion.multiply(Quaternion.axis_angle(axis / al, angle), rest_rot)
            elseif angle < 1 then
                dir = rest_dir
            end
            nxt = head + dir * length
            local sp, sn = p - origin, nxt - origin
            b.qx, b.qy, b.qz = sp.x, sp.y, sp.z
            b.px, b.py, b.pz = sn.x, sn.y, sn.z
        end
        Unit.set_local_rotation(unit, b.node, Quaternion.multiply(Quaternion.inverse(parent_rot), world_rot))
        -- kept for this bone's children, this frame only
        b.rot, b.head, b.scale, b.rigid = world_rot, head, scale, rigid_rot
    end
end

-- the body and every clothing part carry their own copy of the bones; each is driven from the same
-- skeleton nodes with the same numbers, so they move together
local function jiggle_all(body, parts, dt)
    jiggle_update(body, dt)
    if parts then
        for _, unit in pairs(parts) do
            jiggle_update(unit, dt)
        end
    end
end

-- Hooks ----------------------------------------------------------------------

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "init", function(self, extension_init_context, unit, extension_init_data)
    self.__qiangiq_world = extension_init_context and extension_init_context.world
    -- player_unit_visual_loadout_extension.lua:81 reads extension_init_data.archetype.breed
    local archetype = extension_init_data and extension_init_data.archetype
    self.__qiangiq_breed = archetype and archetype.breed
end)

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "_update_item_visibility", function(self, first_person_mode)
    if not is_local_human(self) then
        return
    end
    if EXCLUDED_BREEDS[ext_breed(self)] then
        if self.__qiangiq_ember_unit or self.__qiangiq_ember_arms then
            despawn(self)
        end
        return
    end
    tracked[self] = true
    apply(self, first_person_mode)
end)

-- PlayerUnitVisualLoadoutExtension.update = function (self, unit, dt, t)
mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "update", function(self, unit, dt)
    -- the third-person units are hidden in first person, so nothing to move then
    if tracked[self] and self.__qiangiq_ember_unit and not self.__qiangiq_ember_fp then
        jiggle_all(self.__qiangiq_ember_unit, self.__qiangiq_ember_parts, dt)
        apply_tail(self.__qiangiq_ember_unit)
    end
end)

mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, "destroy", function(func, self, ...)
    despawn(self)
    tracked[self] = nil
    return func(self, ...)
end)

mod:hook_safe(CLASS.UIProfileSpawner, "_update_items_visibility", function(self)
    ui_apply(self)
end)

-- UIProfileSpawner.update = function (self, dt, t, input_service)
mod:hook_safe(CLASS.UIProfileSpawner, "update", function(self, dt)
    local data = self._character_spawn_data
    if data and data.is_ready then
        ui_apply(self)
        if self.__qiangiq_ember_unit then
            jiggle_all(self.__qiangiq_ember_unit, self.__qiangiq_ember_parts, dt)
        apply_tail(self.__qiangiq_ember_unit)
        end
    end
end)

mod:hook(CLASS.UIProfileSpawner, "_despawn_current_character_profile", function(func, self, ...)
    ui_despawn(self)
    return func(self, ...)
end)

-- Package loading through Custom Assets --------------------------------------

local function refresh_all()
    for ext in pairs(tracked) do
        if unit_ok(ext._unit) then
            if not model_on() then
                despawn(ext)
            end
            ext:force_update_item_visibility()
        end
    end
    for spawner in pairs(tracked_ui) do
        ui_apply(spawner)
    end
end

local function acquire(name)
    local id = asset_id(name)
    local ticket, err = custom_assets.acquire(mod, id, function(_, _, load_error)
        if load_error then
            mod:error("%s failed to load: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", id, tostring(load_error))
            return
        end
        ready[name] = true
        refresh_all()
    end, { resident = true, reference_name = id })
    if not ticket then
        mod:error("%s could not be requested: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", id, tostring(err))
    end
end

-- Two models of the same group saved "on" (e.g. a newly installed mod, which defaults to on):
-- the later one in CHARACTER_MODS keeps it.
local function resolve_at_load()
    local mine = false
    for _, name in ipairs(CHARACTER_MODS) do
        if name == "QIangIQsEmber" then
            mine = true
        elseif mine then
            local other = get_mod(name)
            if other and other:get("model_enabled") ~= false and model_on() then
                mod:set("model_enabled", false, false)
            end
        end
    end
end

mod.on_all_mods_loaded = function()
    resolve_at_load()
    jiggle_read_settings()
    custom_assets = get_mod("CustomAssets")
    if not custom_assets or not custom_assets.is_api_compatible or not custom_assets.is_api_compatible(1) then
        mod:error("Custom Assets (API 1) is missing. Install it and put it above QIangIQsEmber in mod_load_order.txt.")
        return
    end
    acquire(BODY)
    acquire(ARMS)
    for _, part in ipairs(PARTS) do
        acquire(part.body)
        if part.arms then
            acquire(part.arms)
        end
    end
end

local function switch_others_off()
    for _, name in ipairs(CHARACTER_MODS) do
        if name ~= "QIangIQsEmber" then
            local other = get_mod(name)
            if other and other:get("model_enabled") ~= false then
                other:set("model_enabled", false, true)
            end
        end
    end
end

mod.toggle_model = function()
    local on = not model_on()
    mod:set("model_enabled", on, true)
    mod:echo("Ember Heirloom model %s", on and "on" or "off")
end

mod:command("ember", "Toggle the Ember Heirloom model on your character", function()
    mod.toggle_model()
end)

mod.on_setting_changed = function(setting_id)
    if setting_id == "model_enabled" and model_on() then
        switch_others_off()
    end
    jiggle_read_settings()
    refresh_all()
end

mod.on_disabled = function()
    for ext in pairs(tracked) do
        despawn(ext)
        -- hooks are off now, so this restores the normal body/gear visibility
        if unit_ok(ext._unit) then
            ext:force_update_item_visibility()
        end
    end
    for spawner in pairs(tracked_ui) do
        ui_despawn(spawner)
        if spawner._character_spawn_data and spawner._visible then
            spawner:_update_items_visibility()
        end
    end
end

mod.on_enabled = function()
    refresh_all()
end

mod.on_unload = function()
    for ext in pairs(tracked) do
        despawn(ext)
    end
    for spawner in pairs(tracked_ui) do
        ui_despawn(spawner)
    end
    if custom_assets and custom_assets.release_owner then
        custom_assets.release_owner(mod)
    end
end
