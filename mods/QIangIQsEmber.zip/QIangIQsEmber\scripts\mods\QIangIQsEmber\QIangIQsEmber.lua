-- QIangIQ's Ember Heirloom: swaps the local player's body for a Custom Assets unit
-- (third person, first-person arms, and menu / operative-select previews).
-- Author: QIangIQ
local mod = get_mod("QIangIQsEmber")

-- Cross-client sync ---------------------------------------------------------------
-- QIangIQsModelSync publishes which QIangIQ replacer mods a player has on, with their options, through
-- Vox Manifold (the transport Dio's Wardrobe shares outfits with). No asset data is sent: every client shows
-- the model from its own installed files. While another player's unit is worked on, sync_ctx holds that
-- player's options and opt() answers from them; for my own unit opt() is mod:get().
local SYNC_KEY = "ember"
local SYNC_BOOLS = { "model_enabled", "hide_body", "part_flames", "glow_color_custom", "glow_reactive" }
local SYNC_DEFAULTS = { model_enabled = false, hide_body = true, part_flames = true, glow_color_custom = false, glow_reactive = true }
local SYNC_VALUES = { "flame_brightness", "glow_brightness", "glow_color_r", "glow_color_g", "glow_color_b", "glow_reactive_max", "glow_level", "flame_level", "glow_reactive_peak" }
local SYNC_LAYOUT = #SYNC_BOOLS * 100 + #SYNC_VALUES -- a peer on another version of this mod is not decoded
local sync_ctx = nil
local sync_known = setmetatable({}, { __mode = "k" })   -- other players' extensions this mod has shown something on
local sync_all = setmetatable({}, { __mode = "k" })     -- every visual loadout extension seen
local sync_decoded = setmetatable({}, { __mode = "k" }) -- published array -> options table
local SYNC_FALSE = { __index = function() return false end }
local SYNC_OFF = setmetatable({}, SYNC_FALSE)           -- "everything off": removes what was shown
local sync_extra_import = nil

local function opt(key)
    if sync_ctx then
        return sync_ctx[key]
    end
    return mod:get(key)
end

local function sync_api()
    local hub = get_mod("QIangIQsModelSync")
    return hub and hub.api
end

local function sync_me()
    local players = Managers.player
    if not players then
        return nil
    end
    local ok, player = pcall(players.local_player_safe, players, 1)
    return ok and player or nil
end

-- published array { layout, checkbox bits, value, value, ... [, extra] } -> options by setting id
local function sync_decode(raw)
    local t = sync_decoded[raw]
    if t ~= nil then
        return t
    end
    t = false
    if type(raw) == "table" and raw[1] == SYNC_LAYOUT then
        t = setmetatable({}, SYNC_FALSE)
        local mask = tonumber(raw[2]) or 0
        for i = 1, #SYNC_BOOLS do
            t[SYNC_BOOLS[i]] = mask % 2 >= 1
            mask = math.floor(mask / 2)
        end
        for i = 1, #SYNC_VALUES do
            local v = raw[2 + i]
            if v ~= nil then
                t[SYNC_VALUES[i]] = v
            end
        end
        if sync_extra_import then
            sync_extra_import(t, raw[3 + #SYNC_VALUES])
        end
    end
    sync_decoded[raw] = t
    return t
end

-- whose options apply to this extension: nil = mine, a table = that player's (SYNC_OFF when they publish
-- nothing for this mod)
local function sync_owner(ext)
    sync_all[ext] = true
    local player = ext._player
    if player == nil or player == sync_me() then
        return nil
    end
    local api = sync_api()
    local raw = api and api.peer(SYNC_KEY, player)
    local state = raw and sync_decode(raw)
    if state then
        sync_known[ext] = true
        return state
    end
    return SYNC_OFF
end

-- my own unit, or another player's unit this mod is (or was) showing something on
local function sync_shown(ext)
    local player = ext._player
    return player ~= nil and (player == sync_me() or sync_known[ext] == true)
end

local function sync_pack(...)
    return { n = select("#", ...), ... }
end

-- runs a hook body with the options of the extension's owner
local function sync_wrap(fn, ext_index)
    return function(...)
        local ext = select(ext_index, ...)
        local previous = sync_ctx
        sync_ctx = sync_owner(ext)
        local results = sync_pack(pcall(fn, ...))
        sync_ctx = previous
        if not results[1] then
            error(results[2], 0)
        end
        return unpack(results, 2, results.n)
    end
end

-- The same hook on my own unit's extension and on other players' (husk) extensions. While the mods load, the
-- classes do not exist yet: CLASS.<name> is then only the name and DMF delays the hook ("needs to be delayed"
-- in the log), so the husk class cannot be inspected here. Its methods are taken from
-- player_husk_visual_loadout_extension.lua instead.
local SYNC_HUSK_METHODS = { init = true, update = true, _update_item_visibility = true, destroy = true }

local function vl_hook_safe(method, fn)
    mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, method, sync_wrap(fn, 1))
    if SYNC_HUSK_METHODS[method] then
        mod:hook_safe(CLASS.PlayerHuskVisualLoadoutExtension, method, sync_wrap(fn, 1))
    end
end

local function vl_hook(method, fn)
    mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, method, sync_wrap(fn, 2))
    if SYNC_HUSK_METHODS[method] then
        mod:hook(CLASS.PlayerHuskVisualLoadoutExtension, method, sync_wrap(fn, 2))
    elseif method == "_unequip_item_from_slot" then
        -- a husk has no _unequip_item_from_slot: its unequip arrives as rpc_player_unequip_item_from_slot
        -- (self, channel_id, go_id, slot_id), slot name = NetworkLookup.player_inventory_slot_names[slot_id]
        -- (player_husk_visual_loadout_extension.lua)
        mod:hook(CLASS.PlayerHuskVisualLoadoutExtension, "rpc_player_unequip_item_from_slot", sync_wrap(function(func, self, channel_id, go_id, slot_id, ...)
            local NetworkLookup = require("scripts/network_lookup/network_lookup")
            local slot_name = NetworkLookup.player_inventory_slot_names[slot_id]
            return fn(function()
                return func(self, channel_id, go_id, slot_id)
            end, self, slot_name)
        end, 2))
    end
end
-- ----------------------------------------------------------------------------------

mod.AUTHOR = "QIangIQ"

-- Every piece is its own Custom Assets unit: Custom Assets id = <Mod>:<Custom folder>, unit name =
-- the --asset-path used at compile time. The base is the bare body; each clothing part is a separate
-- unit (and a separate first-person arms unit when it covers the arms) that is spawned and linked the
-- same way, so parts can be switched on and off one by one.
local BODY = "ember_heirloom"
local ARMS = "ember_heirloom_arms"
local function asset_id(name)
    return "QIangIQsEmber:" .. name
end
local function unit_name(name)
    return "content/mods/qiangiq_ember/" .. name
end
local BODY_UNIT = unit_name(BODY)
local ARMS_UNIT = unit_name(ARMS)
-- { id (setting "part_<id>"), body = Custom folder of the third-person unit, arms = folder of the first-person unit or nil,
--   default = false for parts that start switched off, needs = id of a part that must be on as well,
--   glow = slider setting for the part's emissive material, glow_default, color = colour setting,
--   setting = id of another part whose on/off option this part shares (it has no option of its own),
--   when / unless = a checkbox setting that must be on / off for the part to be shown,
--   flame = true for a part whose emissive material takes the flame colour (see apply_part_glow) }
local PARTS = {
    { id = "flames", body = "ember_heirloom_flames", flame = true, glow = "flame_level", glow_default = 60 },
    { id = "haze", body = "ember_heirloom_haze", setting = "flames", unless = "glow_color_custom" },
    { id = "haze_tint", body = "ember_heirloom_haze_tint", setting = "flames", when = "glow_color_custom" },
}
local PART_BY_ID = {}
for _, part in ipairs(PARTS) do
    PART_BY_ID[part.id] = part
end
local function part_on(part)
    local on = opt("part_" .. (part.setting or part.id))
    if on == nil then
        on = part.default ~= false
    end
    if on and part.when and not opt(part.when) then
        return false
    end
    if on and part.unless and opt(part.unless) then
        return false
    end
    if on and part.needs and PART_BY_ID[part.needs] then
        return part_on(PART_BY_ID[part.needs])
    end
    return on and true or false
end

-- QIangIQ character swap mods: only one model is shown at a time. Turning one on (option,
-- keybind or chat command) switches the others off through their saved "model_enabled" setting
-- (DMFMod:set / DMFMod:get, dmf/modules/core/settings.lua).
local CHARACTER_MODS = { "QIangIQsAnubis", "QIangIQsDominanceAnubis", "QIangIQsEmber", "QIangIQsCitlali", "QIangIQsYvonne", "QIangIQsKulveTaroth", "QIangIQsNavia", "QIangIQsZhuangFangyi", "QIangIQsArknightsEmber", "QIangIQsHornet", "QIangIQsAlienQueen", "QIangIQsAnkha", "QIangIQsValkyrHeirloom", "QIangIQsMesaHeirloom", "QIangIQsCitrinePrime", "QIangIQsOctaviaPrime", "QIangIQsOraxia", "QIangIQsSevagothPrime", "QIangIQsVorunaPrime", "QIangIQsWispPrime", "QIangIQsYareliPrime", "QIangIQsMarieGemini", "QIangIQsEleanorGemini", "QIangIQsJade" }

-- The model is fitted to one skeleton (human); bodies of the other breed use a different
-- skeleton, so they are left alone. Breed names as keyed in player_character_constants.lua
-- (human / ogryn).
local EXCLUDED_BREEDS = { ogryn = true }

-- player_unit_visual_loadout_extension.lua:205-206 keeps the breed on the extension itself
-- (self._static_profile_properties.breed), so it is known even when this mod is loaded mid-game.
local function ext_breed(ext)
    local props = ext._static_profile_properties
    return (props and props.breed) or ext.__qiangiq_breed
end

local custom_assets = nil
local ready = {} -- [Custom folder] = true once its package is loaded
local function model_on()
    return opt("model_enabled") ~= false
end

-- extensions / UI spawners we have touched (weak keys)
local tracked = setmetatable({}, { __mode = "k" })
local tracked_ui = setmetatable({}, { __mode = "k" })

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function local_player()
    local players = Managers.player
    if not players then
        return nil
    end
    local ok, player = pcall(players.local_player_safe, players, 1)
    return ok and player or nil
end

-- slot_body_* / slot_gear_* hold the body parts and cosmetics; weapons live in other slots
local function hide_body_slots(slots, key)
    if not slots then
        return
    end
    local attachments_key = key == "unit_1p" and "attachments_by_unit_1p" or "attachments_by_unit_3p"
    for slot_name, slot in pairs(slots) do
        if string.find(slot_name, "^slot_body_") or string.find(slot_name, "^slot_gear_") then
            local unit = slot[key]
            if unit_ok(unit) then
                Unit.set_unit_visibility(unit, false, true)
                local attachments = slot[attachments_key] and slot[attachments_key][unit]
                if attachments then
                    for i = 1, #attachments do
                        if unit_ok(attachments[i]) then
                            Unit.set_unit_visibility(attachments[i], false, true)
                        end
                    end
                end
            end
        end
    end
end

-- In-game player unit -----------------------------------------------------------

local function is_local_human(ext)
    return sync_shown(ext)
end

local function delete_unit(unit)
    if unit_ok(unit) then
        local unit_spawner = Managers.state and Managers.state.unit_spawner
        if unit_spawner then
            unit_spawner:mark_for_deletion(unit)
        end
    end
end

local function delete_all(units)
    if units then
        for id, unit in pairs(units) do
            delete_unit(unit)
            units[id] = nil
        end
    end
end

local function despawn(ext)
    delete_unit(ext.__qiangiq_ember_unit)
    delete_unit(ext.__qiangiq_ember_arms)
    ext.__qiangiq_ember_unit = nil
    ext.__qiangiq_ember_arms = nil
    delete_all(ext.__qiangiq_ember_parts)
    delete_all(ext.__qiangiq_ember_part_arms)
end

local FP_CUSTOM_FOV = true

-- same spawn + link pattern the game uses for gear (visual_loadout_customization.lua)
local function spawn_linked(world, parent, unit_name, is_first_person)
    local unit_spawner = Managers.state and Managers.state.unit_spawner
    if not (world and unit_spawner and unit_ok(parent)) then
        return nil
    end
    local unit = unit_spawner:spawn_unit(unit_name, Unit.world_pose(parent, 1))
    if not unit then
        return nil
    end
    if is_first_person then
        Unit.set_unit_culling(unit, false)
    end
    if is_first_person and FP_CUSTOM_FOV then
        -- 1P items are drawn with the first-person FOV (equipment_component.lua:359). Without this flag the
        -- arms are drawn with the world FOV while the weapon uses the 1P one, so the weapon shows beside the hand.
        Unit.set_shader_pass_flag_for_meshes_in_unit_and_childs(unit, "custom_fov", true)
    end
    World.link_unit(world, unit, 1, parent, 1, World.LINK_MODE_NODE_NAME)
    return unit
end

-- Glow slider for the model's emissive layer (nil = the model has none). The layer's material is the
-- compiler's PBR emissive one, whose brightness is its scalar variable "intensity"
-- (pbr_emissive_profile.cpp, id32 0x32f447e5 = "intensity"); set the way the game applies scalar
-- material overrides (visual_loadout_customization.lua:516, Unit.set_scalar_for_materials(unit, name, value, true)).
local GLOW_SETTING = "glow_level"
local GLOW_DEFAULT = 23 -- %

-- Glow colour for the model's emissive materials (emissive_color, id32 0xc985395a; same call as the parts'
-- colour option below, visual_loadout_customization.lua:534). The exporter bakes emissive_color as (1, 1, 1)
-- when an emission texture is connected, so white = the model as built. Only written while the option is on;
-- turning it off writes white back once.
local GLOW_COLOR = true -- true = the model has the "glow_color_custom" + r / g / b options
local colored = setmetatable({}, { __mode = "k" })

local function custom_glow_color()
    if GLOW_COLOR and opt("glow_color_custom") then
        local r = math.max(opt("glow_color_r") or 1, 0)
        local g = math.max(opt("glow_color_g") or 1, 0)
        local b = math.max(opt("glow_color_b") or 1, 0)
        return r, g, b
    end
    return nil
end

local function apply_glow_color(unit)
    local r, g, b = custom_glow_color()
    if r then
        Unit.set_vector3_for_materials(unit, "emissive_color", Vector3(r, g, b), true)
        colored[unit] = true
    elseif colored[unit] then
        Unit.set_vector3_for_materials(unit, "emissive_color", Vector3(1, 1, 1), true)
        colored[unit] = nil
    end
end

-- Brightness settings are 0-100 %. The engine's response to "intensity" is far from linear: in game 0.1 -> 3 went
-- from barely lit to full and 5 -> 10 looked the same, so 0-100 % maps onto 0-3 along a power curve fitted to
-- those two points (1 % ~ 0.1, 100 % = 3).
local GLOW_MAX = 3
local GLOW_CURVE = 0.74

local function glow_intensity(pct)
    local t = math.max(math.min(pct or 0, 100), 0) / 100
    return GLOW_MAX * t ^ GLOW_CURVE
end

local function apply_glow(unit)
    if GLOW_SETTING and unit_ok(unit) then
        Unit.set_scalar_for_materials(unit, "intensity", glow_intensity(opt(GLOW_SETTING) or GLOW_DEFAULT), true)
        apply_glow_color(unit)
    end
end

-- Flame parts: their emission picture is greyscale, so emissive_color is the flame's colour. It is the custom glow
-- colour while that option is on, otherwise the mean colour of the model's own flame pictures.
local FLAME_COLOR = { 1, 0.861, 0.51 }

-- Emissive colours offered for parts with a colour option (emissive_color = id32 0xc985395a in the same
-- material; a Vector3 set like visual_loadout_customization.lua:534, Unit.set_vector3_for_materials).
local GLOW_COLORS = {
    cyan = { 0, 0.85, 1 },
    pink = { 1, 0.08, 0.55 },
    green = { 0.15, 1, 0.2 },
    gold = { 1, 0.69, 0.06 },
    purple = { 0.55, 0.15, 1 },
    red = { 1, 0.04, 0.04 },
    white = { 1, 1, 1 },
}

local function apply_part_glow(part, unit)
    if part.glow and unit_ok(unit) then
        Unit.set_scalar_for_materials(unit, "intensity", glow_intensity(opt(part.glow) or part.glow_default), true)
        local c = part.color and GLOW_COLORS[opt(part.color) or "cyan"]
        if c then
            Unit.set_vector3_for_materials(unit, "emissive_color", Vector3(c[1], c[2], c[3]), true)
        end
        if part.flame then
            local r, g, b = custom_glow_color()
            if not r then
                r, g, b = FLAME_COLOR[1], FLAME_COLOR[2], FLAME_COLOR[3]
            end
            Unit.set_vector3_for_materials(unit, "emissive_color", Vector3(r, g, b), true)
        end
    end
end

-- Tail size (nil = not offered). Scales are set on the tail's own nodes, the call the game uses to size a
-- unit (ui_profile_spawner.lua:1722, Unit.set_local_scale(unit, node, Vector3)). A bone runs along its
-- local Z (see the physics notes), so X/Y is thickness and Z is length; children inherit it.
local TAIL = nil

local function apply_tail(unit)
    if not (TAIL and unit_ok(unit) and Unit.has_node(unit, TAIL.thick) and Unit.has_node(unit, TAIL.long)) then
        return
    end
    local on = opt("tail_custom")
    local thick = on and math.max(opt("tail_thickness") or 1, 0.1) or 1
    local long = on and math.max(opt("tail_length") or 1, 0.1) or 1
    Unit.set_local_scale(unit, Unit.node(unit, TAIL.thick), Vector3(thick, thick, 1))
    Unit.set_local_scale(unit, Unit.node(unit, TAIL.long), Vector3(1, 1, long))
end

local function apply(ext, first_person_mode)
    if not model_on() then
        despawn(ext)
        return
    end
    local world = ext.__qiangiq_world

    local fp_arms = opt("first_person_arms") and true or false
    ext.__qiangiq_ember_fp = first_person_mode and true or false

    if ready[BODY] and not unit_ok(ext.__qiangiq_ember_unit) then
        ext.__qiangiq_ember_unit = spawn_linked(world, ext._unit, BODY_UNIT, false)
    end
    if ready[ARMS] and fp_arms and not unit_ok(ext.__qiangiq_ember_arms) then
        ext.__qiangiq_ember_arms = spawn_linked(world, ext._first_person_unit, ARMS_UNIT, true)
    elseif not fp_arms and ext.__qiangiq_ember_arms then
        delete_unit(ext.__qiangiq_ember_arms)
        ext.__qiangiq_ember_arms = nil
    end

    local body = ext.__qiangiq_ember_unit
    local arms = ext.__qiangiq_ember_arms
    apply_glow(body)
    apply_glow(arms)
    apply_tail(body)
    if unit_ok(body) then
        Unit.set_unit_visibility(body, not first_person_mode, true)
    end
    if unit_ok(arms) then
        Unit.set_unit_visibility(arms, first_person_mode and true or false, true)
    end

    -- clothing parts: spawned next to the body while their option is on, deleted when it is off
    local parts = ext.__qiangiq_ember_parts or {}
    local part_arms = ext.__qiangiq_ember_part_arms or {}
    ext.__qiangiq_ember_parts = parts
    ext.__qiangiq_ember_part_arms = part_arms
    for _, part in ipairs(PARTS) do
        local id = part.id
        local on = part_on(part)
        if on and ready[part.body] and unit_ok(body) and not unit_ok(parts[id]) then
            parts[id] = spawn_linked(world, ext._unit, unit_name(part.body), false)
        elseif not on and parts[id] then
            delete_unit(parts[id])
            parts[id] = nil
        end
        if unit_ok(parts[id]) then
            apply_part_glow(part, parts[id])
            Unit.set_unit_visibility(parts[id], not first_person_mode, true)
        end
        if part.arms then
            local want = on and fp_arms
            if want and ready[part.arms] and unit_ok(arms) and not unit_ok(part_arms[id]) then
                part_arms[id] = spawn_linked(world, ext._first_person_unit, unit_name(part.arms), true)
            elseif not want and part_arms[id] then
                delete_unit(part_arms[id])
                part_arms[id] = nil
            end
            if unit_ok(part_arms[id]) then
                apply_part_glow(part, part_arms[id])
                Unit.set_unit_visibility(part_arms[id], first_person_mode and true or false, true)
            end
        end
    end

    if opt("hide_body") then
        if not first_person_mode and unit_ok(body) then
            hide_body_slots(ext._equipment, "unit_3p")
        elseif first_person_mode and unit_ok(arms) then
            hide_body_slots(ext._equipment, "unit_1p")
        end
    end
end

-- Menu previews (operative select, inventory, lobby) --------------------------

local function ui_profile_is_mine(profile)
    -- __qiangiq_npc: the companion NPC spawned by QIangIQsCompanionSwap is nobody's character
    if not profile or profile.__qiangiq_npc then
        return false
    end
    -- skip previews of characters that belong to someone else (other players, bots)
    local players = Managers.player and Managers.player:players()
    local me = local_player()
    if players and profile.character_id then
        for _, player in pairs(players) do
            if player ~= me and player.character_id and player:character_id() == profile.character_id then
                return false
            end
        end
    end
    return true
end

local function ui_despawn(spawner)
    local unit = spawner.__qiangiq_ember_unit
    spawner.__qiangiq_ember_unit = nil
    spawner.__qiangiq_ember_parent = nil
    if unit_ok(unit) and spawner._world then
        -- same call ui_profile_spawner.lua uses for its own character unit
        World.destroy_unit(spawner._world, unit)
    end
    local parts = spawner.__qiangiq_ember_parts
    if parts then
        for id, part_unit in pairs(parts) do
            if unit_ok(part_unit) and spawner._world then
                World.destroy_unit(spawner._world, part_unit)
            end
            parts[id] = nil
        end
    end
end

local function ui_apply(spawner)
    local data = spawner._character_spawn_data
    if not data or not unit_ok(data.unit_3p) then
        return
    end
    -- ui_profile_spawner.lua:179-180 reads profile.archetype.breed
    local archetype = data.profile and data.profile.archetype
    local excluded = archetype and EXCLUDED_BREEDS[archetype.breed]
    if excluded or not (model_on() and opt("menu_previews") and ready[BODY] and ui_profile_is_mine(data.profile)) then
        if spawner.__qiangiq_ember_unit then
            ui_despawn(spawner)
            if spawner._visible then
                spawner:_update_items_visibility()
            end
        end
        return
    end
    if spawner.__qiangiq_ember_parent ~= data.unit_3p then
        ui_despawn(spawner)
    end
    local unit = spawner.__qiangiq_ember_unit
    if not unit_ok(unit) then
        local world = spawner._world
        unit = World.spawn_unit_ex(world, BODY_UNIT, nil, Unit.world_pose(data.unit_3p, 1))
        World.link_unit(world, unit, 1, data.unit_3p, 1, World.LINK_MODE_NODE_NAME)
        spawner.__qiangiq_ember_unit = unit
        spawner.__qiangiq_ember_parent = data.unit_3p
        tracked_ui[spawner] = true
    end
    apply_glow(unit)
    apply_tail(unit)
    Unit.set_unit_visibility(unit, spawner._visible and true or false, true)
    local parts = spawner.__qiangiq_ember_parts or {}
    spawner.__qiangiq_ember_parts = parts
    for _, part in ipairs(PARTS) do
        local id = part.id
        local on = part_on(part)
        if on and ready[part.body] and not unit_ok(parts[id]) then
            local world = spawner._world
            parts[id] = World.spawn_unit_ex(world, unit_name(part.body), nil, Unit.world_pose(data.unit_3p, 1))
            World.link_unit(world, parts[id], 1, data.unit_3p, 1, World.LINK_MODE_NODE_NAME)
        elseif not on and parts[id] then
            if unit_ok(parts[id]) then
                World.destroy_unit(spawner._world, parts[id])
            end
            parts[id] = nil
        end
        if unit_ok(parts[id]) then
            apply_part_glow(part, parts[id])
            Unit.set_unit_visibility(parts[id], spawner._visible and true or false, true)
        end
    end
    if spawner._visible and opt("hide_body") then
        hide_body_slots(data.slots, "unit_3p")
    end
end

-- Physics ------------------------------------------------------------------------
-- The model's own physics bones (the avatar's "Phy_*" chains) are in the compiled units as extra nodes
-- that the player's skeleton does not have, so node-name linking leaves them at their rest pose. Each
-- one is driven here as a damped spring: its tip is a point that lags behind where the rest pose puts
-- it and is pulled back, and the bone is turned to point at it. Only engine calls the game's own
-- scripts use: Unit.node / has_node / local_rotation / local_position / world_position /
-- world_rotation / set_local_rotation, Quaternion.multiply / inverse / rotate / axis_angle,
-- Vector3.cross / dot / length.
-- { bone, parent, area, length (m) }, parents first
-- (from the model's armature). A parent that is not in this list is a normal skeleton / helper node.
local JIGGLE_BONES = {
    { "arm_cloth_r", "j_rightforearm", "drape", 0.073 },
    { "arm_cloth_r_001", "j_rightforearm", "drape", 0.088 },
    { "leg_dangle_r_001", "j_rightupleg", "cloth", 0.058 },
    { "leg_knot_r_008", "j_rightupleg", "cloth", 0.038 },
    { "leg_dangle_r_009", "j_rightupleg", "cloth", 0.058 },
    { "leg_knot_l_008", "j_leftupleg", "cloth", 0.038 },
    { "leg_knot_r_001", "j_rightupleg", "cloth", 0.039 },
    { "arm_cloth_r_002", "arm_cloth_r_001", "drape", 0.093 },
    { "leg_knot_l_001", "j_leftupleg", "cloth", 0.039 },
    { "leg_dangle_l_009", "j_leftupleg", "cloth", 0.058 },
    { "leg_dangle_l_001", "j_leftupleg", "cloth", 0.058 },
    { "leg_dangle_l_002", "leg_dangle_l_001", "cloth", 0.061 },
    { "leg_knot_l_002", "leg_knot_l_001", "cloth", 0.051 },
    { "leg_knot_l_009", "leg_knot_l_008", "cloth", 0.050 },
    { "leg_dangle_r_010", "leg_dangle_r_009", "cloth", 0.061 },
    { "leg_dangle_l_010", "leg_dangle_l_009", "cloth", 0.061 },
    { "arm_cloth_r_003", "arm_cloth_r_002", "drape", 0.105 },
    { "leg_dangle_r_002", "leg_dangle_r_001", "cloth", 0.061 },
    { "leg_knot_r_009", "leg_knot_r_008", "cloth", 0.050 },
    { "leg_knot_r_002", "leg_knot_r_001", "cloth", 0.051 },
    { "body_flame_l", "j_spine2", "plume", 0.101 },
    { "leg_knot_l_010", "leg_knot_l_009", "cloth", 0.047 },
    { "body_flame", "j_spine2", "plume", 0.099 },
    { "body_flame_fw", "j_spine2", "plume", 0.132 },
    { "leg_dangle_r_003", "leg_dangle_r_002", "cloth", 0.059 },
    { "body_flame_sw", "j_spine2", "plume", 0.113 },
    { "leg_knot_r_003", "leg_knot_r_002", "cloth", 0.048 },
    { "body_flame_fw_001", "j_spine2", "plume", 0.176 },
    { "leg_dangle_r_011", "leg_dangle_r_010", "cloth", 0.059 },
    { "leg_dangle_l_011", "leg_dangle_l_010", "cloth", 0.059 },
    { "body_flame_001", "j_spine2", "plume", 0.099 },
    { "body_flame_r_001", "j_spine2", "plume", 0.101 },
    { "body_flame_sw_001", "j_spine2", "plume", 0.059 },
    { "leg_knot_l_003", "leg_knot_l_002", "cloth", 0.048 },
    { "arm_cloth_r_004", "arm_cloth_r_003", "drape", 0.109 },
    { "leg_dangle_l_003", "leg_dangle_l_002", "cloth", 0.059 },
    { "body_flame_l_001", "j_spine2", "plume", 0.101 },
    { "body_flame_r", "j_spine2", "plume", 0.101 },
    { "leg_knot_r_010", "leg_knot_r_009", "cloth", 0.047 },
    { "head_flame_back", "j_head", "plume", 0.048 },
    { "head_flames_front_001", "j_head", "plume", 0.028 },
    { "body_flame_r_002", "body_flame_r_001", "plume", 0.101 },
    { "head_flames_middle_001", "j_head", "plume", 0.038 },
    { "head_flames_middle_l", "j_head", "plume", 0.031 },
    { "head_flame_back_001", "j_head", "plume", 0.048 },
    { "leg_knot_l_011", "leg_knot_l_010", "cloth", 0.054 },
    { "leg_knot_r_011", "leg_knot_r_010", "cloth", 0.054 },
    { "head_flames_middle_l_001", "j_head", "plume", 0.038 },
    { "head_flames_back", "j_head", "plume", 0.032 },
    { "leg_knot_r_004", "leg_knot_r_003", "cloth", 0.055 },
    { "leg_dangle_l_012", "leg_dangle_l_011", "cloth", 0.058 },
    { "head_flame_front_001", "j_head", "plume", 0.048 },
    { "head_flames_back_l_001", "j_head", "plume", 0.036 },
    { "head_flame_middle", "j_head", "plume", 0.045 },
    { "leg_dangle_l_004", "leg_dangle_l_003", "cloth", 0.058 },
    { "head_flame_front", "j_head", "plume", 0.048 },
    { "head_flames_middle", "j_head", "plume", 0.036 },
    { "leg_dangle_r_004", "leg_dangle_r_003", "cloth", 0.058 },
    { "head_flames_back_r", "j_head", "plume", 0.028 },
    { "body_flame_l_002", "body_flame_l_001", "plume", 0.101 },
    { "leg_dangle_r_012", "leg_dangle_r_011", "cloth", 0.058 },
    { "head_flames_middle_r", "j_head", "plume", 0.031 },
    { "head_flames_middle_r_001", "j_head", "plume", 0.037 },
    { "leg_knot_l_004", "leg_knot_l_003", "cloth", 0.055 },
    { "head_flames_back_l", "j_head", "plume", 0.028 },
    { "body_flame_002", "body_flame_001", "plume", 0.099 },
    { "head_flames_back_r_001", "j_head", "plume", 0.034 },
    { "arm_cloth_r_005", "arm_cloth_r_004", "drape", 0.105 },
    { "head_flames_back_001", "j_head", "plume", 0.034 },
    { "body_flame_fw_002", "body_flame_fw_001", "plume", 0.076 },
    { "head_flame_middle_001", "j_head", "plume", 0.045 },
    { "body_flame_sw_002", "body_flame_sw_001", "plume", 0.065 },
    { "head_flames_middle_l_002", "head_flames_middle_l_001", "plume", 0.045 },
    { "head_flames_back_002", "head_flames_back_001", "plume", 0.036 },
    { "body_flame_003", "body_flame_002", "plume", 0.099 },
    { "head_flame_back_002", "head_flame_back_001", "plume", 0.048 },
    { "head_flame_front_002", "head_flame_front_001", "plume", 0.048 },
    { "head_flame_middle_002", "head_flame_middle_001", "plume", 0.045 },
    { "body_flame_r_003", "body_flame_r_002", "plume", 0.101 },
    { "body_flame_fw_003", "body_flame_fw_002", "plume", 0.076 },
    { "head_flames_middle_r_002", "head_flames_middle_r_001", "plume", 0.040 },
    { "leg_knot_l_012", "leg_knot_l_011", "cloth", 0.041 },
    { "body_flame_sw_003", "body_flame_sw_002", "plume", 0.079 },
    { "head_flames_back_r_002", "head_flames_back_r_001", "plume", 0.035 },
    { "leg_knot_r_005", "leg_knot_r_004", "cloth", 0.042 },
    { "leg_knot_l_005", "leg_knot_l_004", "cloth", 0.041 },
    { "body_flame_l_003", "body_flame_l_002", "plume", 0.101 },
    { "leg_dangle_r_013", "leg_dangle_r_012", "cloth", 0.059 },
    { "head_flames_front_002", "head_flames_front_001", "plume", 0.029 },
    { "leg_knot_r_012", "leg_knot_r_011", "cloth", 0.041 },
    { "leg_dangle_r_005", "leg_dangle_r_004", "cloth", 0.059 },
    { "head_flames_back_l_002", "head_flames_back_l_001", "plume", 0.038 },
    { "leg_dangle_l_005", "leg_dangle_l_004", "cloth", 0.059 },
    { "head_flames_middle_002", "head_flames_middle_001", "plume", 0.042 },
    { "leg_dangle_l_013", "leg_dangle_l_012", "cloth", 0.059 },
    { "arm_cloth_r_006", "arm_cloth_r_005", "drape", 0.076 },
    { "leg_knot_l_013", "leg_knot_l_012", "cloth", 0.018 },
    { "body_flame_004", "body_flame_003", "plume", 0.099 },
    { "leg_dangle_l_014", "leg_dangle_l_013", "cloth", 0.058 },
    { "head_flame_front_003", "head_flame_front_002", "plume", 0.048 },
    { "leg_dangle_r_006", "leg_dangle_r_005", "cloth", 0.058 },
    { "leg_dangle_l_006", "leg_dangle_l_005", "cloth", 0.058 },
    { "leg_knot_l_006", "leg_knot_l_005", "cloth", 0.018 },
    { "head_flame_back_003", "head_flame_back_002", "plume", 0.048 },
    { "body_flame_r_004", "body_flame_r_003", "plume", 0.101 },
    { "head_flames_middle_l_003", "head_flames_middle_l_002", "plume", 0.043 },
    { "head_flames_back_l_003", "head_flames_back_l_002", "plume", 0.035 },
    { "arm_cloth_r_007", "arm_cloth_r_006", "drape", 0.059 },
    { "head_flames_back_r_003", "head_flames_back_r_002", "plume", 0.036 },
    { "body_flame_l_004", "body_flame_l_003", "plume", 0.101 },
    { "body_flame_fw_004", "body_flame_fw_003", "plume", 0.062 },
    { "head_flames_middle_r_003", "head_flames_middle_r_002", "plume", 0.039 },
    { "head_flames_front_003", "head_flames_front_002", "plume", 0.028 },
    { "body_flame_sw_004", "body_flame_sw_003", "plume", 0.092 },
    { "head_flame_middle_003", "head_flame_middle_002", "plume", 0.045 },
    { "leg_knot_r_006", "leg_knot_r_005", "cloth", 0.018 },
    { "leg_knot_r_013", "leg_knot_r_012", "cloth", 0.018 },
    { "head_flames_middle_003", "head_flames_middle_002", "plume", 0.039 },
    { "leg_dangle_r_014", "leg_dangle_r_013", "cloth", 0.058 },
    { "head_flames_back_003", "head_flames_back_002", "plume", 0.034 },
    { "leg_dangle_l_007", "leg_dangle_l_006", "cloth", 0.057 },
    { "body_flame_005", "body_flame_004", "plume", 0.099 },
    { "arm_cloth_r_008", "arm_cloth_r_007", "drape", 0.048 },
    { "head_flames_middle_r_004", "head_flames_middle_r_003", "plume", 0.065 },
    { "head_flames_front_004", "head_flames_front_003", "plume", 0.025 },
    { "body_flame_fw_005", "body_flame_fw_004", "plume", 0.062 },
    { "head_flames_middle_004", "head_flames_middle_003", "plume", 0.062 },
    { "body_flame_r_005", "body_flame_r_004", "plume", 0.101 },
    { "leg_dangle_l_015", "leg_dangle_l_014", "cloth", 0.057 },
    { "head_flame_middle_004", "head_flame_middle_003", "plume", 0.045 },
    { "body_flame_sw_005", "body_flame_sw_004", "plume", 0.073 },
    { "head_flames_middle_l_004", "head_flames_middle_l_003", "plume", 0.051 },
    { "head_flame_back_004", "head_flame_back_003", "plume", 0.048 },
    { "head_flames_back_r_004", "head_flames_back_r_003", "plume", 0.034 },
    { "head_flame_front_004", "head_flame_front_003", "plume", 0.048 },
    { "leg_dangle_r_015", "leg_dangle_r_014", "cloth", 0.057 },
    { "body_flame_l_005", "body_flame_l_004", "plume", 0.101 },
    { "leg_dangle_r_007", "leg_dangle_r_006", "cloth", 0.057 },
    { "head_flames_back_004", "head_flames_back_003", "plume", 0.031 },
    { "head_flames_back_l_004", "head_flames_back_l_003", "plume", 0.030 },
    { "head_flames_back_l_005", "head_flames_back_l_004", "plume", 0.023 },
    { "head_flames_middle_005", "head_flames_middle_004", "plume", 0.062 },
    { "head_flames_back_005", "head_flames_back_004", "plume", 0.028 },
    { "body_flame_r_006", "body_flame_r_005", "plume", 0.101 },
    { "body_flame_l_006", "body_flame_l_005", "plume", 0.101 },
    { "head_flames_front_005", "head_flames_front_004", "plume", 0.023 },
    { "head_flame_middle_005", "head_flame_middle_004", "plume", 0.045 },
    { "body_flame_sw_006", "body_flame_sw_005", "plume", 0.067 },
    { "body_flame_006", "body_flame_005", "plume", 0.099 },
    { "head_flame_front_005", "head_flame_front_004", "plume", 0.048 },
    { "arm_cloth_r_009", "arm_cloth_r_008", "drape", 0.055 },
    { "head_flames_middle_r_005", "head_flames_middle_r_004", "plume", 0.065 },
    { "head_flames_back_r_005", "head_flames_back_r_004", "plume", 0.025 },
    { "head_flame_back_005", "head_flame_back_004", "plume", 0.048 },
    { "body_flame_fw_006", "body_flame_fw_005", "plume", 0.046 },
    { "head_flames_middle_l_005", "head_flames_middle_l_004", "plume", 0.051 },
    { "body_flame_sw_007", "body_flame_sw_006", "plume", 0.046 },
    { "head_flames_back_l_006", "head_flames_back_l_005", "plume", 0.023 },
    { "body_flame_fw_007", "body_flame_fw_006", "plume", 0.046 },
    { "head_flames_back_006", "head_flames_back_005", "plume", 0.028 },
    { "head_flames_back_r_006", "head_flames_back_r_005", "plume", 0.025 },
    { "head_flame_middle_006", "head_flame_middle_005", "plume", 0.045 },
    { "arm_cloth_r_010", "arm_cloth_r_009", "drape", 0.058 },
    { "head_flame_front_006", "head_flame_front_005", "plume", 0.048 },
    { "head_flame_back_006", "head_flame_back_005", "plume", 0.048 },
    { "arm_cloth_r_011", "arm_cloth_r_010", "drape", 0.063 },
    { "body_flame_sw_008", "body_flame_sw_007", "plume", 0.040 },
    { "body_flame_fw_008", "body_flame_fw_007", "plume", 0.040 },
    { "arm_cloth_l_001", "j_leftforearm", "drape", 0.088 },
    { "arm_cloth_l", "j_leftforearm", "drape", 0.073 },
    { "arm_cloth_r_012", "arm_cloth_r_011", "drape", 0.059 },
    { "body_flame_fw_009", "body_flame_fw_008", "plume", 0.040 },
    { "body_flame_sw_009", "body_flame_sw_008", "plume", 0.056 },
    { "arm_cloth_l_002", "arm_cloth_l_001", "drape", 0.093 },
    { "body_flame_fw_010", "body_flame_fw_009", "plume", 0.029 },
    { "arm_cloth_l_003", "arm_cloth_l_002", "drape", 0.105 },
    { "body_flame_sw_010", "body_flame_sw_009", "plume", 0.043 },
    { "arm_cloth_r_013", "arm_cloth_r_012", "drape", 0.057 },
    { "body_flame_sw_011", "body_flame_sw_010", "plume", 0.031 },
    { "arm_cloth_r_014", "arm_cloth_r_013", "drape", 0.045 },
    { "arm_cloth_l_004", "arm_cloth_l_003", "drape", 0.109 },
    { "body_flame_fw_011", "body_flame_fw_010", "plume", 0.029 },
    { "arm_cloth_l_005", "arm_cloth_l_004", "drape", 0.105 },
    { "arm_cloth_r_015", "arm_cloth_r_014", "drape", 0.042 },
    { "body_flame_fw_012", "body_flame_fw_011", "plume", 0.029 },
    { "body_flame_sw_012", "body_flame_sw_011", "plume", 0.031 },
    { "arm_cloth_r_016", "arm_cloth_r_015", "drape", 0.026 },
    { "arm_cloth_l_006", "arm_cloth_l_005", "drape", 0.076 },
    { "arm_cloth_l_007", "arm_cloth_l_006", "drape", 0.059 },
    { "arm_cloth_l_008", "arm_cloth_l_007", "drape", 0.048 },
    { "arm_cloth_l_009", "arm_cloth_l_008", "drape", 0.055 },
    { "arm_cloth_l_010", "arm_cloth_l_009", "drape", 0.058 },
    { "arm_cloth_l_011", "arm_cloth_l_010", "drape", 0.063 },
    { "arm_cloth_l_012", "arm_cloth_l_011", "drape", 0.060 },
    { "arm_cloth_l_013", "arm_cloth_l_012", "drape", 0.057 },
    { "arm_cloth_l_014", "arm_cloth_l_013", "drape", 0.045 },
    { "arm_cloth_l_015", "arm_cloth_l_014", "drape", 0.042 },
    { "arm_cloth_l_016", "arm_cloth_l_015", "drape", 0.026 },
}
-- per 60 fps frame: pull = share of the remaining offset removed, drag = share of velocity lost;
-- max_angle = largest swing of one bone from its rest pose (degrees); slider = the option that scales the area.
-- flow = every bone of the chain is its own free point (the chain bends bone by bone and a wave runs down
-- it); without it the bones after the first only follow the first one (one soft lump).
-- carry = share of the character's own travel the points are taken along with (1 = no trailing while running);
-- hang = the area takes part in the "hang" option (rest direction leaned towards straight down);
-- drape = the area always hangs straight down in the world (cloth hung from an arm);
-- total = largest lean of any bone from where it would point if its whole chain were stiff (degrees).
-- bend_step = largest difference between the bends of two neighbouring joints of a chain (degrees).
local JIGGLE_GROUPS = {
    breast = { pull = 0.22, drag = 0.16, max_angle = 14, slider = "jiggle_breast" },
    butt = { pull = 0.28, drag = 0.20, max_angle = 10, slider = "jiggle_butt" },
    thigh = { pull = 0.30, drag = 0.22, max_angle = 6, slider = "jiggle_butt" },
    tail = { pull = 0.07, drag = 0.34, max_angle = 32, slider = "jiggle_tail", flow = true, carry = 0.92, total = 50 },
    hair = { pull = 0.05, drag = 0.30, max_angle = 40, slider = "jiggle_hair", flow = true, carry = 0.92, hang = true, total = 45 },
    ear = { pull = 0.25, drag = 0.18, max_angle = 14, slider = "jiggle_ear" },
    drape = { pull = 0.10, drag = 0.40, max_angle = 28, slider = "jiggle_cloth", flow = true, carry = 0.95, drape = true },
    plume = { pull = 0.07, drag = 0.34, max_angle = 30, slider = "jiggle_hair", flow = true, carry = 0.92, total = 30 },
    cloth = { pull = 0.08, drag = 0.36, max_angle = 35, slider = "jiggle_cloth", flow = true, carry = 0.92, hang = true, total = 40 },
}
-- Body collision: capsules along the body (node, node it runs to, radius in metres). Loose chains (hair, tail,
-- plume, cloth, drape) are pushed out of them so they rest on the body instead of passing through it. Only the
-- nodes the unit really has are used, and only the chains that hang free are tested.
local JIGGLE_COLLIDERS = {
    { "j_spine", "j_spine2", 0.13 },
    { "j_spine2", "j_neck", 0.09 },
    { "j_hips", "j_spine", 0.15 },
    { "j_leftupleg", "j_leftleg", 0.10 },
    { "j_rightupleg", "j_rightleg", 0.10 },
    { "j_leftleg", "j_leftfoot", 0.07 },
    { "j_rightleg", "j_rightfoot", 0.07 },
    { "j_leftarm", "j_leftforearm", 0.06 },
    { "j_rightarm", "j_rightforearm", 0.06 },
    { "j_leftforearm", "j_lefthand", 0.05 },
    { "j_rightforearm", "j_righthand", 0.05 },
}
local COLLIDE_GROUPS = { tail = true, hair = true, plume = true, cloth = true, drape = true }
local jiggle_state = setmetatable({}, { __mode = "k" })
-- options, read once per change instead of every frame
local JIGGLE = { on = true, stiffness = 1, damping = 1, limit = 1, hang = 0, amount = {} }

local function jiggle_read_settings()
    JIGGLE.on = opt("jiggle") ~= false
    JIGGLE.stiffness = math.max(opt("jiggle_stiffness") or 1, 0.05)
    JIGGLE.damping = math.max(opt("jiggle_damping") or 1, 0.05)
    JIGGLE.limit = math.max(opt("jiggle_limit") or 1, 0.05)
    JIGGLE.hang = math.max(opt("jiggle_hang") or 0, 0)
    for name, g in pairs(JIGGLE_GROUPS) do
        JIGGLE.amount[name] = math.max(opt(g.slider) or 1, 0)
    end
end

local function jiggle_init(unit)
    local bones, by_name = {}, {}
    for _, def in ipairs(JIGGLE_BONES) do
        local name, parent_name = def[1], def[2]
        local parent = by_name[parent_name]
        -- usable when the unit has the bone and the node it hangs from (parts only carry what they need)
        if Unit.has_node(unit, name) and (parent or Unit.has_node(unit, parent_name)) then
            local node = Unit.node(unit, name)
            local b = {
                node = node,
                group = def[3],
                parent = parent,
                parent_node = not parent and Unit.node(unit, parent_name) or nil,
                rest = QuaternionBox(Unit.local_rotation(unit, node)),
                lpos = Vector3Box(Unit.local_position(unit, node)),
                -- the bone runs along its own local Z for its length (the compiler writes every node's
                -- local transform as glTF (x, y, z) -> (x, -z, y), and a glTF bone runs along its Y)
                tip = Vector3Box(Vector3(0, 0, def[4])),
            }
            bones[#bones + 1] = b
            by_name[name] = b
        end
    end
    local colliders = {}
    for _, def in ipairs(JIGGLE_COLLIDERS) do
        if Unit.has_node(unit, def[1]) and Unit.has_node(unit, def[2]) then
            colliders[#colliders + 1] = { Unit.node(unit, def[1]), Unit.node(unit, def[2]), def[3] }
        end
    end
    return { bones = bones, active = false, colliders = colliders }
end

-- push a point out of every body capsule (a, b, radius in world metres)
local function collide_point(p, segs, pad)
    for i = 1, #segs do
        local s = segs[i]
        local a, ab = s.a, s.ab
        local t = math.max(0, math.min(1, Vector3.dot(p - a, ab) / s.len2))
        local c = a + ab * t
        local d = p - c
        local dl = Vector3.length(d)
        local r = s.r + pad
        if dl < r then
            p = dl > 1e-5 and c + d / dl * r or c + Vector3(0, 0, 1) * r
        end
    end
    return p
end

local function jiggle_rest(unit, state)
    for _, b in ipairs(state.bones) do
        Unit.set_local_rotation(unit, b.node, b.rest:unbox())
        b.px = nil
    end
    state.rx = nil
    state.active = false
end

local function jiggle_update(unit, dt)
    if not unit_ok(unit) then
        return
    end
    local state = jiggle_state[unit]
    if not state then
        state = jiggle_init(unit)
        jiggle_state[unit] = state
    end
    if not JIGGLE.on then
        if state.active then
            jiggle_rest(unit, state)
        end
        return
    end
    state.active = true
    local f = math.min(dt or 0.0167, 0.05) * 60
    -- how far the character itself travelled since the last frame (node 1 = the unit's root)
    local root = Unit.world_position(unit, 1)
    local travel = Vector3(0, 0, 0)
    if state.rx then
        travel = root - Vector3(state.rx, state.ry, state.rz)
        if Vector3.length(travel) > 2 then
            travel = Vector3(0, 0, 0)
        end
    end
    state.rx, state.ry, state.rz = root.x, root.y, root.z
    -- ground level under the character (its root is at its feet) and its facing, for draped cloth
    local floor = root.z + 0.02
    local back = Quaternion.forward(Unit.world_rotation(unit, 1))
    -- body capsules in world space for this frame (the body is posed before the bones are moved)
    local segs = {}
    for _, c in ipairs(state.colliders or {}) do
        local a, e = Unit.world_position(unit, c[1]), Unit.world_position(unit, c[2])
        local ab = e - a
        local l2 = Vector3.dot(ab, ab)
        if l2 > 1e-8 then
            segs[#segs + 1] = { a = a, ab = ab, len2 = l2, r = c[3] }
        end
    end
    for _, b in ipairs(state.bones) do
        local g = JIGGLE_GROUPS[b.group]
        local amount = JIGGLE.amount[b.group] or 1
        local parent = b.parent
        local parent_rot, head, scale
        if parent then
            parent_rot, scale = parent.rot, parent.scale
            head = parent.head + Quaternion.rotate(parent_rot, b.lpos:unbox()) * scale
        else
            parent_rot = Unit.world_rotation(unit, b.parent_node)
            head = Unit.world_position(unit, b.node)
            -- world size of one model unit (characters can be scaled)
            local len = Vector3.length(b.lpos:unbox())
            scale = len > 1e-3 and Vector3.length(head - Unit.world_position(unit, b.parent_node)) / len or 1
            if scale < 1e-4 then
                scale = 1
            end
        end
        local rest_rot = Quaternion.multiply(parent_rot, b.rest:unbox())
        -- where the bone would point if the whole chain above it were stiff
        local rigid_rot = parent and Quaternion.multiply(parent.rigid, b.rest:unbox()) or rest_rot
        local tip_off = Quaternion.rotate(rest_rot, b.tip:unbox()) * scale
        local length = Vector3.length(tip_off)
        local world_rot = rest_rot
        if amount <= 0 then
            b.px = nil -- area switched off: stay on the rest pose
        elseif length > 1e-6 then
            local keep = (1 - math.min(g.drag * JIGGLE.damping, 0.95)) ^ f
            local pull = 1 - (1 - math.min(g.pull * JIGGLE.stiffness / amount, 0.95)) ^ f
            local max_angle = math.min(math.rad(g.max_angle) * amount * JIGGLE.limit, 1.4)
            local rest_dir = tip_off / length
            local rest_tip = head + tip_off
            local flow = g.flow
            -- goal_dir: the direction the bone is pulled towards and limited around
            local goal_dir = rest_dir
            if flow and g.drape then
                -- loose cloth hung from a limb: straight down in the world, whatever the limb does
                -- (its modelled angle to the limb is only right for the pose it was modelled in)
                goal_dir = Vector3(0, 0, -1)
                rest_tip = head + goal_dir * length
            elseif flow and g.hang and JIGGLE.hang > 0 then
                -- lean the direction the bone is pulled towards to straight down (world Z is up)
                local lean = rest_dir + Vector3(0, 0, -JIGGLE.hang)
                local ll = Vector3.length(lean)
                if ll > 1e-4 then
                    goal_dir = lean / ll
                    rest_tip = head + goal_dir * length
                end
            end
            -- a tip kept in the world lags when the body moves. Flowing chains keep every tip in the
            -- world; in the other areas only the bone on a normal skeleton node does, and the bones after
            -- it keep theirs relative to their own head, so they follow the bone before them
            local world_tip = flow or not parent
            local origin = world_tip and Vector3(0, 0, 0) or head
            local p, pp = rest_tip, rest_tip
            if b.px then
                p = origin + Vector3(b.px, b.py, b.pz)
                pp = origin + Vector3(b.qx, b.qy, b.qz)
                if flow then
                    local along = travel * g.carry
                    p, pp = p + along, pp + along
                end
                if Vector3.length(p - rest_tip) > 4 * length + 0.5 then
                    p, pp = rest_tip, rest_tip -- teleported: start over at rest
                end
            end
            local k, q = keep, pull
            if parent and not flow then
                -- a follower, not a second spring
                k, q = keep * 0.35, math.min(pull * 1.6, 0.9)
            end
            local nxt = p + (p - pp) * k + (rest_tip - p) * q
            local dir = nxt - head
            local dl = Vector3.length(dir)
            dir = dl > 1e-6 and dir / dl or goal_dir
            -- keep the swing within max_angle of the goal direction
            local axis = Vector3.cross(goal_dir, dir)
            local al = Vector3.length(axis)
            local angle = math.acos(math.max(-1, math.min(1, Vector3.dot(goal_dir, dir))))
            if al > 1e-6 and angle > max_angle then
                dir = Quaternion.rotate(Quaternion.axis_angle(axis / al, max_angle), goal_dir)
            end
            if g.drape and (head + dir * length).z < floor then
                -- the cloth is longer than the arm is high: what reaches the ground lies on it, trailing
                -- the way it already leans (behind the character when it hangs dead straight)
                local dz = math.max(-length, math.min(length, floor - head.z))
                local flat = math.sqrt(math.max(0, length * length - dz * dz))
                local hx, hy = dir.x, dir.y
                local hn = math.sqrt(hx * hx + hy * hy)
                if hn < 1e-3 then
                    hx, hy, hn = -back.x, -back.y, math.max(math.sqrt(back.x * back.x + back.y * back.y), 1e-3)
                end
                dir = Vector3(hx / hn * flat, hy / hn * flat, dz) / length
            end
            if g.total then
                -- and the whole chain within `total` of its stiff shape: per-bone limits add up along a
                -- long chain, which let the far end fold right over
                local rigid_dir = Quaternion.rotate(rigid_rot, b.tip:unbox())
                local rl = Vector3.length(rigid_dir)
                if rl > 1e-6 then
                    rigid_dir = rigid_dir / rl
                    local total = math.min(math.rad(g.total) * amount * JIGGLE.limit, 3)
                    local ax = Vector3.cross(rigid_dir, dir)
                    local axl = Vector3.length(ax)
                    if axl > 1e-6 and math.acos(math.max(-1, math.min(1, Vector3.dot(rigid_dir, dir)))) > total then
                        dir = Quaternion.rotate(Quaternion.axis_angle(ax / axl, total), rigid_dir)
                    end
                end
            end
            if COLLIDE_GROUPS[b.group] and #segs > 0 then
                -- the tip may not end inside the body: slide it out along the surface, keeping the bone's length
                local tip = head + dir * length
                local out = collide_point(tip, segs, 0.01)
                if out ~= tip then
                    local nd = out - head
                    local nl = Vector3.length(nd)
                    if nl > 1e-6 then
                        dir = nd / nl
                    end
                end
            end
            if flow and g.bend_step and parent and parent.group == b.group and parent.bend_x then
                -- snake-like chains: the bend of a joint (rotation from its goal direction, as axis * angle)
                -- may differ from the bend of the joint before it by at most bend_step, so the curvature
                -- changes gradually along the chain instead of kinking from one bone to the next
                local bax = Vector3.cross(goal_dir, dir)
                local bal = Vector3.length(bax)
                local bang = math.acos(math.max(-1, math.min(1, Vector3.dot(goal_dir, dir))))
                local bend = bal > 1e-6 and bax / bal * bang or Vector3(0, 0, 0)
                local parent_bend = Vector3(parent.bend_x, parent.bend_y, parent.bend_z)
                local diff = bend - parent_bend
                local dl2 = Vector3.length(diff)
                local step = math.rad(g.bend_step) * amount * JIGGLE.limit
                if dl2 > step then
                    bend = parent_bend + diff * (step / dl2)
                    local bl = Vector3.length(bend)
                    if bl > max_angle then
                        bend, bl = bend * (max_angle / bl), max_angle
                    end
                    dir = bl > 1e-6 and Quaternion.rotate(Quaternion.axis_angle(bend / bl, bl), goal_dir) or goal_dir
                end
            end
            if g.bend_step then
                -- this joint's final bend, for the next bone of the chain (this frame only)
                local bax = Vector3.cross(goal_dir, dir)
                local bal = Vector3.length(bax)
                if bal > 1e-6 then
                    local bend = bax / bal * math.acos(math.max(-1, math.min(1, Vector3.dot(goal_dir, dir))))
                    b.bend_x, b.bend_y, b.bend_z = bend.x, bend.y, bend.z
                else
                    b.bend_x, b.bend_y, b.bend_z = 0, 0, 0
                end
            end
            -- turn the bone from its rest direction to that direction
            axis = Vector3.cross(rest_dir, dir)
            al = Vector3.length(axis)
            angle = math.acos(math.max(-1, math.min(1, Vector3.dot(rest_dir, dir))))
            if al > 1e-6 and angle > 1e-5 then
                world_rot = Quaternion.multiply(Quaternion.axis_angle(axis / al, angle), rest_rot)
            elseif angle < 1 then
                dir = rest_dir
            end
            nxt = head + dir * length
            local sp, sn = p - origin, nxt - origin
            b.qx, b.qy, b.qz = sp.x, sp.y, sp.z
            b.px, b.py, b.pz = sn.x, sn.y, sn.z
        end
        Unit.set_local_rotation(unit, b.node, Quaternion.multiply(Quaternion.inverse(parent_rot), world_rot))
        -- kept for this bone's children, this frame only
        b.rot, b.head, b.scale, b.rigid = world_rot, head, scale, rigid_rot
    end
end

-- the body and every clothing part carry their own copy of the bones; each is driven from the same
-- skeleton nodes with the same numbers, so they move together
local function jiggle_all(body, parts, dt)
    jiggle_update(body, dt)
    if parts then
        for _, unit in pairs(parts) do
            jiggle_update(unit, dt)
        end
    end
end

-- Hooks ----------------------------------------------------------------------

vl_hook_safe("init", function(self, extension_init_context, unit, extension_init_data)
    self.__qiangiq_world = extension_init_context and extension_init_context.world
    -- player_unit_visual_loadout_extension.lua:81 reads extension_init_data.archetype.breed
    local archetype = extension_init_data and extension_init_data.archetype
    self.__qiangiq_breed = archetype and archetype.breed
end)

vl_hook_safe("_update_item_visibility", function(self, first_person_mode)
    if not is_local_human(self) then
        return
    end
    if EXCLUDED_BREEDS[ext_breed(self)] then
        if self.__qiangiq_ember_unit or self.__qiangiq_ember_arms then
            despawn(self)
        end
        return
    end
    tracked[self] = true
    apply(self, first_person_mode)
end)

-- PlayerUnitVisualLoadoutExtension.update = function (self, unit, dt, t)
-- Reactive glow: every glowing unit of the model (the body and arms' emissive layer and each glowing part) brightens
-- with the Psyker's peril and the Veteran's plasma gun heat, from its own brightness setting at none to
-- "glow_reactive_peak" at full. Peril: the "warp_charge" component's current_percentage, read as
-- QIangIQsCookedMacroManager does; heat: the "slot_secondary" component's overheat_current_percentage, read as
-- QIangIQsPrototype does (plasmagun_overheat_effects.lua:39,79). Class: player:archetype_name(), as ability_timer.
-- 0 for any other class or when a component cannot be read (pcall).
local REACTIVE_FOLLOW = 0.15 -- share of the way to the new level per 60 fps frame (smooths flicker)
local REACTIVE_SOURCE = { psyker = { "warp_charge", "current_percentage" }, veteran = { "slot_secondary", "overheat_current_percentage" } }

local function reactive_level(ext)
    local player = ext._player
    local ok, archetype = pcall(function()
        return player and player:archetype_name()
    end)
    local source = ok and REACTIVE_SOURCE[archetype]
    local unit = ext._unit
    if not (source and unit_ok(unit)) then
        return 0
    end
    local unit_data_extension = ScriptUnit.has_extension(unit, "unit_data_system")
    if not unit_data_extension then
        return 0
    end
    local ok2, component = pcall(unit_data_extension.read_component, unit_data_extension, source[1])
    local v = ok2 and component and component[source[2]]
    return type(v) == "number" and math.clamp01(v) or 0
end

local function each_glowing_part(ext, fn)
    for _, list in ipairs({ ext.__qiangiq_ember_parts, ext.__qiangiq_ember_part_arms }) do
        if list then
            for id, unit in pairs(list) do
                local part = PART_BY_ID[id]
                if part and part.glow and unit_ok(unit) then
                    fn(part, unit)
                end
            end
        end
    end
end

local function apply_reactive_glow(ext, dt)
    local body, arms = ext.__qiangiq_ember_unit, ext.__qiangiq_ember_arms
    if not opt("glow_reactive") then
        if ext.__qiangiq_ember_rshown then
            -- switched off: back to the plain brightness settings once
            ext.__qiangiq_ember_rshown = nil
            apply_glow(body)
            apply_glow(arms)
            each_glowing_part(ext, apply_part_glow)
        end
        return
    end
    local f = math.min(dt or 0.0167, 0.1) * 60
    local shown = ext.__qiangiq_ember_rshown or 0
    shown = shown + (reactive_level(ext) - shown) * (1 - (1 - REACTIVE_FOLLOW) ^ f)
    ext.__qiangiq_ember_rshown = shown
    local peak = glow_intensity(opt("glow_reactive_peak") or 100)
    local function lifted(own)
        return own + math.max(peak - own, 0) * shown
    end
    if GLOW_SETTING then
        local v = lifted(glow_intensity(opt(GLOW_SETTING) or GLOW_DEFAULT))
        for _, unit in ipairs({ body, arms }) do
            if unit_ok(unit) then
                Unit.set_scalar_for_materials(unit, "intensity", v, true)
            end
        end
    end
    each_glowing_part(ext, function(part, unit)
        Unit.set_scalar_for_materials(unit, "intensity", lifted(glow_intensity(opt(part.glow) or part.glow_default)), true)
    end)
end

vl_hook_safe("update", function(self, unit, dt)
    -- the third-person units are hidden in first person, so nothing to move then
    if tracked[self] and self.__qiangiq_ember_unit and not self.__qiangiq_ember_fp then
        jiggle_all(self.__qiangiq_ember_unit, self.__qiangiq_ember_parts, dt)
        apply_tail(self.__qiangiq_ember_unit)
    end
    if tracked[self] then
        apply_reactive_glow(self, dt)
    end
end)

vl_hook("destroy", function(func, self, ...)
    despawn(self)
    tracked[self] = nil
    return func(self, ...)
end)

mod:hook_safe(CLASS.UIProfileSpawner, "_update_items_visibility", function(self)
    ui_apply(self)
end)

-- UIProfileSpawner.update = function (self, dt, t, input_service)
mod:hook_safe(CLASS.UIProfileSpawner, "update", function(self, dt)
    local data = self._character_spawn_data
    if data and data.is_ready then
        ui_apply(self)
        if self.__qiangiq_ember_unit then
            jiggle_all(self.__qiangiq_ember_unit, self.__qiangiq_ember_parts, dt)
        apply_tail(self.__qiangiq_ember_unit)
        end
    end
end)

mod:hook(CLASS.UIProfileSpawner, "_despawn_current_character_profile", function(func, self, ...)
    ui_despawn(self)
    return func(self, ...)
end)

-- Package loading through Custom Assets --------------------------------------

local function refresh_all()
    for ext in pairs(tracked) do
        if unit_ok(ext._unit) then
            if not model_on() then
                despawn(ext)
            end
            ext:force_update_item_visibility()
        end
    end
    for spawner in pairs(tracked_ui) do
        ui_apply(spawner)
    end
end

local function acquire(name)
    local id = asset_id(name)
    local ticket, err = custom_assets.acquire(mod, id, function(_, _, load_error)
        if load_error then
            mod:error("%s failed to load: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", id, tostring(load_error))
            return
        end
        ready[name] = true
        refresh_all()
    end, { resident = true, reference_name = id })
    if not ticket then
        mod:error("%s could not be requested: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", id, tostring(err))
    end
end

-- Two models of the same group saved "on" (e.g. a newly installed mod, which defaults to on):
-- the later one in CHARACTER_MODS keeps it.
local function resolve_at_load()
    local mine = false
    for _, name in ipairs(CHARACTER_MODS) do
        if name == "QIangIQsEmber" then
            mine = true
        elseif mine then
            local other = get_mod(name)
            if other and other:get("model_enabled") ~= false and model_on() then
                mod:set("model_enabled", false, false)
            end
        end
    end
end

-- Retail parent of the PBR-emissive materials on the body, arms and flames (#ID[e04dba68a38d1429] in their build.json).
-- The assets list it as an external resource that is not a package member, so it only exists while some retail
-- package that holds it is loaded (2026-10-11: emissives rendered magenta). Same fix as ZOMBsMegaPack.lua; the package
-- name is from ResourceLoader's catalog (catalog/resources/material_005.lua: #ID[e04dba68a38d1429] -> packages[593]).
-- The haze / haze_tint sheets use the retail transparent parent #ID[40bc90ba5e9b0852] (their build.json), also external;
-- its only catalog package is a level package (catalog/resources/material_002.lua: #ID[40bc90ba5e9b0852] -> packages[543]).
local EMISSIVE_PARENT_PACKAGES = {
    "content/weapons/player/ranged/bolt_pistol/attachments/sight_01/sight_01",
    "content/levels/ui/expedition/world",
}

local function load_emissive_parent()
    local packages = Managers.package
    if not packages then
        return
    end
    for i = 1, #EMISSIVE_PARENT_PACKAGES do
        local name = EMISSIVE_PARENT_PACKAGES[i]
        if not packages:has_loaded(name) then
            packages:load(name, "QIangIQsEmber_emissive_parent_" .. i, function()
                mod:info("emissive parent package loaded: %s", name)
            end)
        end
    end
end

mod.on_all_mods_loaded = function()
    pcall(load_emissive_parent)
    resolve_at_load()
    jiggle_read_settings()
    custom_assets = get_mod("CustomAssets")
    if not custom_assets or not custom_assets.is_api_compatible or not custom_assets.is_api_compatible(1) then
        mod:error("Custom Assets (API 1) is missing. Install it and put it above QIangIQsEmber in mod_load_order.txt.")
        return
    end
    acquire(BODY)
    acquire(ARMS)
    for _, part in ipairs(PARTS) do
        acquire(part.body)
        if part.arms then
            acquire(part.arms)
        end
    end
end

local function switch_others_off()
    for _, name in ipairs(CHARACTER_MODS) do
        if name ~= "QIangIQsEmber" then
            local other = get_mod(name)
            if other and other:get("model_enabled") ~= false then
                other:set("model_enabled", false, true)
            end
        end
    end
end

mod.toggle_model = function()
    local on = not model_on()
    mod:set("model_enabled", on, true)
    mod:echo("Ember Heirloom model %s", on and "on" or "off")
end

mod:command("ember", "Toggle the Ember Heirloom model on your character", function()
    mod.toggle_model()
end)

mod.on_setting_changed = function(setting_id)
    if setting_id == "model_enabled" and model_on() then
        switch_others_off()
    end
    jiggle_read_settings()
    refresh_all()
end

mod.on_disabled = function()
    for ext in pairs(tracked) do
        despawn(ext)
        -- hooks are off now, so this restores the normal body/gear visibility
        if unit_ok(ext._unit) then
            ext:force_update_item_visibility()
        end
    end
    for spawner in pairs(tracked_ui) do
        ui_despawn(spawner)
        if spawner._character_spawn_data and spawner._visible then
            spawner:_update_items_visibility()
        end
    end
end

mod.on_enabled = function()
    refresh_all()
end

mod.on_unload = function()
    for ext in pairs(tracked) do
        despawn(ext)
    end
    for spawner in pairs(tracked_ui) do
        ui_despawn(spawner)
    end
    if custom_assets and custom_assets.release_owner then
        custom_assets.release_owner(mod)
    end
end


-- Cross-client sync: what this mod publishes about me, and the refresh when anyone's options change ---------
local function sync_applies(info)
    return model_on() and (info.breed == nil or not EXCLUDED_BREEDS[info.breed])
end

local sync_enabled = true
local function sync_changed()
    local api = sync_api()
    if api then
        api.changed()
    end
end

mod.sync_key = SYNC_KEY
-- info = { breed, companion_breed, templates = { [weapon_template] = true } } of my own character (fields nil
-- while I have no unit). Returns the array to publish, or nil when this mod shows nothing on my character.
mod.sync_export = function(info)
    info = info or {}
    if not sync_enabled or not sync_applies(info) then
        return nil
    end
    local mask, bit = 0, 1
    for i = 1, #SYNC_BOOLS do
        local key = SYNC_BOOLS[i]
        local v = mod:get(key)
        if v == nil then
            v = SYNC_DEFAULTS[key]
        end
        if v then
            mask = mask + bit
        end
        bit = bit * 2
    end
    local out = { SYNC_LAYOUT, mask }
    for i = 1, #SYNC_VALUES do
        local v = mod:get(SYNC_VALUES[i])
        if type(v) == "number" then
            v = math.floor(v * 100 + 0.5) / 100
        elseif type(v) ~= "string" then
            v = false -- not set: the reader falls back to its default
        end
        out[2 + i] = v
    end
    return out
end

mod.sync_refresh = function()
    for ext in pairs(sync_all) do
        if ext._unit and Unit.alive(ext._unit) and ext.force_update_item_visibility then
            pcall(ext.force_update_item_visibility, ext)
        end
    end
end

local sync_prev_setting_changed = mod.on_setting_changed
mod.on_setting_changed = function(...)
    if sync_prev_setting_changed then
        sync_prev_setting_changed(...)
    end
    sync_changed()
end

local sync_prev_disabled = mod.on_disabled
mod.on_disabled = function(...)
    sync_enabled = false
    if sync_prev_disabled then
        sync_prev_disabled(...)
    end
    sync_changed()
end

local sync_prev_enabled = mod.on_enabled
mod.on_enabled = function(...)
    sync_enabled = true
    if sync_prev_enabled then
        sync_prev_enabled(...)
    end
    sync_changed()
end
