return {
    mod_name = {
        en = "QIangIQ's Ember Heirloom",
    },
    mod_description = {
        en = "Replaces your own character with the Ember Heirloom model (Custom Assets): third person, first-person arms and menu previews, with physics on the arm banners, leg cloth and head flames. Only one QIangIQ character model is shown at a time. By QIangIQ.",
    },
    model_enabled = {
        en = "Show the Ember Heirloom model",
    },
    model_enabled_description = {
        en = "Turning this on switches the other QIangIQ human character models off. Chat command: /ember",
    },
    hide_body = {
        en = "Hide original body and cosmetics",
    },
    hide_body_description = {
        en = "Hides your character's body, face, hair and gear slots while the model is shown. Weapons stay visible.",
    },
    first_person_arms = {
        en = "Model arms in first person",
    },
    first_person_arms_description = {
        en = "Replaces the first-person arms and gloves with the model's arms (and the arm pieces of the clothing parts that are on).",
    },
    menu_previews = {
        en = "Show in menus (operative select, inventory)",
    },
    menu_previews_description = {
        en = "Shows the model on your own operatives in menu previews. Other players' characters are left alone. Ogryns are never replaced.",
    },
    parts_group = {
        en = "Clothing parts",
    },
    physics_group = {
        en = "Physics",
    },
    jiggle = {
        en = "Physics on",
    },
    jiggle_description = {
        en = "The model's own physics bones swing and settle when you move, jump, dodge or slide (third person and menu previews). Off = everything stays on the rest pose.",
    },
    jiggle_hair = {
        en = "Amount: head flames",
    },
    jiggle_hair_description = {
        en = "1 = as built. Higher = looser and wider swings, lower = tighter. 0 = this area does not move.",
    },
    jiggle_cloth = {
        en = "Amount: clothing and chains",
    },
    jiggle_cloth_description = {
        en = "1 = as built. Higher = looser and wider swings, lower = tighter. 0 = this area does not move.",
    },
    jiggle_stiffness = {
        en = "Stiffness (all areas)",
    },
    jiggle_stiffness_description = {
        en = "How hard everything is pulled back to its rest pose. 1 = as built. Higher = snaps back faster, lower = softer and slower.",
    },
    jiggle_damping = {
        en = "Damping (all areas)",
    },
    jiggle_damping_description = {
        en = "How quickly the wobble dies out. 1 = as built. Higher = settles at once, lower = keeps bouncing longer.",
    },
    jiggle_limit = {
        en = "Swing limit (all areas)",
    },
    jiggle_limit_description = {
        en = "Scales the largest angle a bone may swing away from its rest pose. 1 = as built.",
    },
    glow_brightness = {
        en = "Glow brightness",
    },
    glow_brightness_description = {
        en = "How strongly the model's glowing parts shine. 1 = default (dim), 10 = the original, very bright look, 0 = no glow.",
    },
    jiggle_hang = {
        en = "Hang (hair and clothing)",
    },
    jiggle_hang_description = {
        en = "How strongly hair and loose clothing are drawn straight down instead of keeping their modelled direction when you lean or look up and down. 0 = keep the modelled shape.",
    },
    toggle_keybind = {
        en = "Toggle Ember Heirloom model",
    },
}
