return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsStatTotals` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsStatTotals", {
			mod_script       = "QIangIQsStatTotals/scripts/mods/QIangIQsStatTotals/QIangIQsStatTotals",
			mod_data         = "QIangIQsStatTotals/scripts/mods/QIangIQsStatTotals/QIangIQsStatTotals_data",
			mod_localization = "QIangIQsStatTotals/scripts/mods/QIangIQsStatTotals/QIangIQsStatTotals_localization",
		})
	end,
	packages = {},
}
