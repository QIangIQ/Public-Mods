-- Same element shape as the CombatStats mod's HUD element: HudElementBase, a
-- scenegraph, and widgets from UIWidget.create_definition.
local mod = get_mod("QIangIQsStatTotals")

local UIWorkspaceSettings = require("scripts/settings/ui/ui_workspace_settings")
local UIWidget = require("scripts/managers/ui/ui_widget")

local MAX_ROWS = 72
local PADDING = 10
local LABEL_COLOR = { 255, 225, 225, 225 }
local VALUE_COLOR = { 255, 255, 255, 255 }
local HEADER_COLOR = { 255, 210, 170, 90 }

local function row_definition()
	return UIWidget.create_definition({
		{
			pass_type = "text",
			style_id = "label",
			value_id = "label",
			value = "",
			style = {
				font_size = 16,
				font_type = "proxima_nova_bold",
				text_color = { 255, 225, 225, 225 },
				text_horizontal_alignment = "left",
				text_vertical_alignment = "top",
				offset = { PADDING, 0, 2 },
			},
		},
		{
			pass_type = "text",
			style_id = "value",
			value_id = "value",
			value = "",
			style = {
				font_size = 16,
				font_type = "proxima_nova_bold",
				text_color = { 255, 255, 255, 255 },
				text_horizontal_alignment = "right",
				text_vertical_alignment = "top",
				offset = { -PADDING, 0, 2 },
			},
		},
	}, "box")
end

local widget_definitions = {
	background = UIWidget.create_definition({
		{
			pass_type = "rect",
			style_id = "background",
			style = {
				color = { 153, 0, 0, 0 },
				offset = { 0, 0, 0 },
			},
		},
	}, "box"),
}

for i = 1, MAX_ROWS do
	widget_definitions["row_" .. i] = row_definition()
end

local definitions = {
	scenegraph_definition = {
		screen = UIWorkspaceSettings.screen,
		box = {
			parent = "screen",
			vertical_alignment = "top",
			horizontal_alignment = "left",
			size = { 400, 100 },
			position = { 1480, 120, 55 },
		},
	},
	widget_definitions = widget_definitions,
}

local HudElementQIangIQsStatTotals = class("HudElementQIangIQsStatTotals", "HudElementBase")

HudElementQIangIQsStatTotals.init = function (self, parent, draw_layer, start_scale)
	HudElementQIangIQsStatTotals.super.init(self, parent, draw_layer, start_scale, definitions)

	self._row_widgets = {}

	for i = 1, MAX_ROWS do
		self._row_widgets[i] = self._widgets_by_name["row_" .. i]
		self._row_widgets[i].content.visible = false
	end

	self._next_refresh = 0
	self._num_rows = 0
	self._error_logged = false
end

HudElementQIangIQsStatTotals._apply_settings = function (self)
	self._settings_version = mod.settings_version

	local font_size = mod:get("font_size") or 16

	self._row_height = math.ceil(font_size * 1.3)
	self._font_size = font_size
	self._width = mod:get("box_width") or 400

	self:set_scenegraph_position("box", mod:get("box_x") or 1480, mod:get("box_y") or 120)

	self._widgets_by_name.background.style.background.color[1] = math.floor((mod:get("box_opacity") or 60) * 2.55)

	for i = 1, MAX_ROWS do
		local widget = self._row_widgets[i]

		widget.style.label.font_size = font_size
		widget.style.value.font_size = font_size
		widget.offset[2] = PADDING + (i - 1) * self._row_height
	end

	self._num_rows = -1
	self._next_refresh = 0
end

HudElementQIangIQsStatTotals._refresh = function (self, t)
	local rows, count = mod.build_rows(MAX_ROWS, t)

	for i = 1, MAX_ROWS do
		local widget = self._row_widgets[i]

		if i <= count then
			local row = rows[i]
			local style = widget.style
			local label_color = row.is_header and HEADER_COLOR or LABEL_COLOR

			widget.content.label = row.label
			widget.content.value = row.value
			widget.content.visible = true

			for c = 1, 4 do
				style.label.text_color[c] = label_color[c]
				style.value.text_color[c] = VALUE_COLOR[c]
			end
		else
			widget.content.visible = false
		end
	end

	if count ~= self._num_rows then
		self._num_rows = count

		self:_set_scenegraph_size("box", self._width, PADDING * 2 + count * self._row_height)
	end
end

local function hidden_here()
	if not mod:is_enabled() then
		return true
	end

	local game_mode_manager = Managers.state and Managers.state.game_mode
	local game_mode_name = game_mode_manager and game_mode_manager:game_mode_name()

	if not game_mode_name then
		return true
	end

	return (game_mode_name == "hub" or game_mode_name == "prologue_hub") and not mod:get("show_in_hub")
end

HudElementQIangIQsStatTotals.update = function (self, dt, t, ui_renderer, render_settings, input_service)
	if self._settings_version ~= mod.settings_version then
		self:_apply_settings()
	end

	-- The base update applies any new scenegraph position and size.
	HudElementQIangIQsStatTotals.super.update(self, dt, t, ui_renderer, render_settings, input_service)

	self._hidden = hidden_here()

	if self._hidden or self._failed or t < self._next_refresh then
		return
	end

	self._next_refresh = t + (mod:get("refresh_ms") or 100) / 1000

	local ok, err = pcall(self._refresh, self, t)

	if not ok then
		-- One log line, not one per frame.
		self._failed = true

		mod:error("Stat box stopped: %s", tostring(err))
	end
end

HudElementQIangIQsStatTotals.draw = function (self, dt, t, ui_renderer, render_settings, input_service)
	if self._hidden or self._failed or self._num_rows <= 0 then
		return
	end

	HudElementQIangIQsStatTotals.super.draw(self, dt, t, ui_renderer, render_settings, input_service)
end

return HudElementQIangIQsStatTotals
