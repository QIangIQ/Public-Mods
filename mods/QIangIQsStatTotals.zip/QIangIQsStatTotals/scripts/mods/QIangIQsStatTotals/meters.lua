-- Live meters measured from the game's own networked values, for things no stat
-- describes: toughness actually regained per second, and the combat ability's
-- recharge, including instant restores such as cooldown on a specialist kill.
--
-- Toughness: PlayerHuskToughnessExtension:toughness_damage() reads the game object
-- field "toughness_damage" (player_husk_toughness_extension.lua 29-32, 88-93).
-- Ability: PlayerUnitAbilityExtension:remaining_ability_resource and
-- max_ability_resource (player_unit_ability_extension.lua 1243-1249, 1326), the
-- same calls the game's ability HUD uses (hud_element_player_ability.lua 68).
local Meters = {}

local WINDOW = 1.5
-- An increase this much faster than the recent recharge rate counts as a restore.
local JUMP_FACTOR = 3
-- 2 percent in one sample: faster than any natural recharge between two reads.
local JUMP_MIN_FRACTION = 0.02

local function new_track()
	return { samples = {}, last_restore = nil, last_restore_t = nil }
end

Meters.toughness = new_track()
Meters.ability = new_track()

local function push(track, t, value)
	local samples = track.samples
	local last = samples[#samples]

	if last and t <= last.t then
		return last
	end

	samples[#samples + 1] = { t = t, v = value }

	while #samples > 2 and t - samples[2].t > WINDOW do
		table.remove(samples, 1)
	end

	return last
end

-- Sum of the gains in the window per second, leaving out flagged jumps.
local function rate(track, sign)
	local samples = track.samples

	if #samples < 2 then
		return 0
	end

	local gained, span = 0, samples[#samples].t - samples[1].t

	for i = 2, #samples do
		local step = (samples[i].v - samples[i - 1].v) * sign

		if step > 0 and not samples[i].jump then
			gained = gained + step
		end
	end

	return span > 0 and gained / span or 0
end

Meters.reset = function ()
	Meters.toughness = new_track()
	Meters.ability = new_track()
end

-- Toughness regained per second. Damage taken raises toughness_damage; regen lowers it.
Meters.sample_toughness = function (t, toughness_damage)
	push(Meters.toughness, t, toughness_damage)

	return rate(Meters.toughness, -1)
end

-- Returns percent ready, recharge in percent per second, and the last restore.
Meters.sample_ability = function (t, resource, max_resource)
	local track = Meters.ability
	local before = rate(track, 1)
	local last = push(track, t, resource)

	if last and max_resource > 0 then
		local step = resource - last.v
		local dt = t - last.t
		local expected = before * dt

		if step > JUMP_MIN_FRACTION * max_resource and step > JUMP_FACTOR * math.max(expected, 0) then
			track.samples[#track.samples].jump = true
			track.last_restore = step / max_resource * 100
			track.last_restore_t = t
		end
	end

	local per_second = max_resource > 0 and rate(track, 1) / max_resource * 100 or 0

	return max_resource > 0 and resource / max_resource * 100 or 0, per_second, track.last_restore, track.last_restore_t
end

return Meters
