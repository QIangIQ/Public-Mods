-- No percent signs in any string here: DMF passes localize text through string.format.
local mod = get_mod("QIangIQsStatTotals")

local groups = mod:io_dofile("QIangIQsStatTotals/scripts/mods/QIangIQsStatTotals/stat_lines")

local localization = {
	mod_name = { en = "QIangIQ's Stat Totals" },
	mod_description = { en = "A box on the HUD with your live combined stats: attack, Strength, impact, attack speed, damage reduction, toughness regen and more. Buffs change the numbers as you gain and lose them, summed the way the game sums them. Pick the lines and move the box here. /stattotals_info prints every changed stat to chat." },

	box_x = { en = "Box left edge" },

	box_x_tooltip = { en = "Distance from the left of the screen, on the game's 1920 by 1080 layout." },
	box_y = { en = "Box top edge" },
	box_y_tooltip = { en = "Distance from the top of the screen, on the game's 1920 by 1080 layout." },
	box_width = { en = "Box width" },
	box_width_tooltip = { en = "Widen this if a long label runs into its number." },
	font_size = { en = "Text size" },
	font_size_tooltip = { en = "The rows grow with the text." },
	box_opacity = { en = "Background opacity" },
	box_opacity_tooltip = { en = "0 is no background, 100 is solid black." },
	refresh_ms = { en = "Refresh time in milliseconds" },
	refresh_ms_tooltip = { en = "How often the numbers are read. 0 is every frame." },
	show_headers = { en = "Show section titles" },
	show_headers_tooltip = { en = "Titles such as Attack and Toughness above their lines." },
	hide_unchanged = { en = "Hide lines with no bonus" },
	hide_unchanged_tooltip = { en = "Hides a bonus or reduction line while it sits at zero, so the box only shows what you have now." },
	show_other = { en = "Also list every other changed stat" },
	show_other_tooltip = { en = "Adds any other stat that differs from its base value, under its internal game name. Covers the hundreds of stats that have no line of their own. The box can get long." },
	show_in_hub = { en = "Show in the Mourningstar" },
	show_in_hub_tooltip = { en = "Off shows the box only in missions and the Psykhanium." },

	other_header = { en = "Other changed stats" },
	command_description = { en = "Print every stat that differs from base to chat." },
	no_stats = { en = "No stats to read: your character is not spawned." },
}

for i = 1, #groups do
	local group = groups[i]

	localization[group.id] = { en = group.label }

	for j = 1, #group.lines do
		local line = group.lines[j]
		local id = "line_" .. line.key

		localization[id] = { en = line.label }
		localization[id .. "_tooltip"] = { en = line.tip or ("The game stat " .. line.stat .. " as the game combines it.") }
	end
end

return localization
