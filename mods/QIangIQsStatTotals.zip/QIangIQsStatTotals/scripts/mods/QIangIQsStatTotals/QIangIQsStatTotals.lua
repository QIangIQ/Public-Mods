-- Live combined stat totals in a HUD box.
--
-- The numbers come from the game's own table, buff_extension:stat_buffs(). The
-- game rebuilds that table from your active buffs every fixed frame
-- (buff_extension_base.lua 330-352), adding or multiplying each stat by its type
-- (buff.lua 715-727, buff_settings.lua 691-1054). Your own unit has this table on
-- a client too (player_character_unit_template.lua 556), and server-added buffs
-- arrive through rpc_add_buff (buff_extension_base.lua 1388). So nothing here
-- tracks buffs: gaining and losing them just changes what the table holds.
local mod = get_mod("QIangIQsStatTotals")

local BuffSettings = require("scripts/settings/buff/buff_settings")

local groups = mod:io_dofile("QIangIQsStatTotals/scripts/mods/QIangIQsStatTotals/stat_lines")
local Meters = mod:io_dofile("QIangIQsStatTotals/scripts/mods/QIangIQsStatTotals/meters")

local NameDump = mod:io_dofile("QIangIQsStatTotals/scripts/mods/QIangIQsStatTotals/name_dump")

NameDump.start()

mod.update = function (dt)
	if not NameDump.finished and mod:is_enabled() then
		NameDump.update(dt)
	end
end

mod:register_hud_element({
	class_name = "HudElementQIangIQsStatTotals",
	filename = "QIangIQsStatTotals/scripts/mods/QIangIQsStatTotals/hud_element_stat_totals",
	use_hud_scale = true,
	visibility_groups = {
		"alive",
	},
})

mod.settings_version = 1

mod.on_setting_changed = function ()
	mod.settings_version = mod.settings_version + 1
end

local stat_buff_types = BuffSettings.stat_buff_types
local base_values = BuffSettings.stat_buff_type_base_values
local EPSILON = 0.00005

-- rawget: the table's __index writes the key on a plain read (buff_extension_base.lua 30-37).
local function reader(stat_buffs)
	return function (key)
		local value = rawget(stat_buffs, key)

		if value == nil then
			value = base_values[key]
		end

		return value or 0
	end
end

local function number_or(value, fallback)
	return type(value) == "number" and value or fallback
end

local function toughness_context(ctx, unit, weapon_extension)
	local toughness_extension = ScriptUnit.has_extension(unit, "toughness_system")

	if not toughness_extension or not toughness_extension.toughness_templates then
		return
	end

	local template = toughness_extension:toughness_templates()

	if not template then
		return
	end

	ctx.max_toughness = toughness_extension:max_toughness()
	ctx.toughness_damage = toughness_extension.toughness_damage and toughness_extension:toughness_damage()

	-- player_unit_toughness_extension.lua 134-137. The game picks .moving when
	-- standing still and .still when moving; kept the same here.
	local unit_data_extension = ScriptUnit.has_extension(unit, "unit_data_system")
	local locomotion = unit_data_extension and unit_data_extension:read_component("locomotion")
	local standing_still = locomotion and Vector3.length_squared(locomotion.velocity_current) < 0.001
	local weapon_template = weapon_extension and weapon_extension.toughness_template and weapon_extension:toughness_template()
	local speed_modifier = weapon_template and weapon_template.regeneration_speed_modifier

	ctx.base_regen = standing_still and template.regeneration_speed.moving or template.regeneration_speed.still
	ctx.weapon_regen = number_or(speed_modifier and (standing_still and speed_modifier.moving or speed_modifier.still), 1)
	ctx.base_delay = template.regeneration_delay
	ctx.weapon_delay = number_or(weapon_template and weapon_template.regeneration_delay_modifier, 1)

	-- damage_taken_calculation.lua 231-236: the movement state, the weapon's toughness
	-- value, and the melee value. The game reads movement_state.method (line 48-50).
	local movement_state = unit_data_extension and unit_data_extension:read_component("movement_state")
	local state_modifiers = template.state_damage_modifiers
	local method = movement_state and movement_state.method

	ctx.state_toughness = number_or(state_modifiers and method and state_modifiers[method], 1)
	ctx.weapon_toughness = number_or(weapon_template and weapon_template.toughness_damage_modifier, 1)
	ctx.melee_toughness = number_or(weapon_template and weapon_template.melee_damage_modifier or template.melee_damage_modifier, 1)
	ctx.has_toughness = true
end

local function crit_context(ctx, player, unit, weapon_extension)
	local profile = player:profile()
	local archetype = profile and profile.archetype

	ctx.base_crit = archetype and archetype.base_critical_strike_chance or 0
	ctx.archetype = archetype and archetype.name
	ctx.weapon_crit = 0

	local unit_data_extension = ScriptUnit.has_extension(unit, "unit_data_system")
	local inventory = unit_data_extension and unit_data_extension:read_component("inventory")
	local wielded_slot = inventory and inventory.wielded_slot

	-- slot_primary is the melee slot and slot_secondary the ranged slot (mastery.lua 447-451).
	ctx.wielded_kind = wielded_slot == "slot_primary" and "melee" or wielded_slot == "slot_secondary" and "ranged" or nil

	local handling = weapon_extension and weapon_extension.weapon_handling_template and weapon_extension:weapon_handling_template()
	local critical_strike = handling and handling.critical_strike

	ctx.weapon_crit = number_or(critical_strike and critical_strike.chance_modifier, 0)
end

local function ability_context(ctx, unit, t)
	local ability_extension = ScriptUnit.has_extension(unit, "ability_system")

	if not t or not ability_extension or not ability_extension.remaining_ability_resource then
		return
	end

	local has = ability_extension.has_ability_type and ability_extension:has_ability_type("combat_ability")

	if not has then
		return
	end

	local resource = ability_extension:remaining_ability_resource("combat_ability") or 0
	local max_resource = ability_extension:max_ability_resource("combat_ability") or 0
	local ready, per_second, restore, restore_t = Meters.sample_ability(t, resource, max_resource)
	local charges = ability_extension.remaining_ability_charges and ability_extension:remaining_ability_charges("combat_ability")
	local max_charges = ability_extension.max_ability_charges and ability_extension:max_ability_charges("combat_ability")

	if max_charges and max_charges > 1 then
		ctx.ability_text = string.format("%.0f%% (%d/%d charges)", ready, charges or 0, max_charges)
	else
		ctx.ability_text = ready >= 99.95 and "Ready" or string.format("%.0f%%", ready)
	end

	ctx.ability_rate_text = string.format("%.2f%%/s", per_second)
	ctx.ability_restore_text = restore and string.format("+%.1f%% (%.0fs ago)", restore, t - restore_t) or "None yet"
	ctx.has_ability = true
end

local function format_value(kind, value)
	if kind == "text" then
		return value or ""
	elseif kind == "bonus" then
		return string.format("%+.1f%%", (value - 1) * 100)
	elseif kind == "reduce" then
		return string.format("%.1f%%", (1 - value) * 100)
	elseif kind == "chance" then
		return string.format("%.1f%%", value * 100)
	elseif kind == "per_sec" then
		return string.format("%.2f/s", value)
	elseif kind == "seconds" then
		return string.format("%.2fs", value)
	end

	return (string.format("%.2f", value):gsub("%.?0+$", ""))
end

local function stat_kind(stat)
	local stat_type = stat_buff_types[stat]

	if stat_type == "additive_multiplier" or stat_type == "multiplicative_multiplier" then
		return "bonus"
	end

	return "flat"
end

-- True when a line shows no change, for "Hide lines with no bonus".
local function at_base(kind, value, stat)
	if kind == "bonus" or kind == "reduce" then
		return math.abs(value - 1) < EPSILON
	elseif kind == "flat" and stat then
		return math.abs(value - (base_values[stat] or 0)) < EPSILON
	end

	return false
end

local function local_stat_source()
	local player_manager = Managers.player
	local player = player_manager and player_manager:local_player_safe(1)
	local unit = player and player.player_unit

	if not unit or not Unit.alive(unit) then
		return
	end

	local buff_extension = ScriptUnit.has_extension(unit, "buff_system")
	local stat_buffs = buff_extension and buff_extension:stat_buffs()

	if not stat_buffs then
		return
	end

	return player, unit, stat_buffs, buff_extension
end

local rows = {}
local num_rows = 0
local covered = {}

local function push(label, value, is_header)
	num_rows = num_rows + 1

	local row = rows[num_rows]

	if not row then
		row = {}
		rows[num_rows] = row
	end

	row.label, row.value, row.is_header = label, value, is_header
end

-- Fills the rows for the box. Returns the rows and their count.
mod.build_rows = function (max_rows, t)
	num_rows = 0

	local player, unit, stat_buffs, buff_extension = local_stat_source()

	if not player then
		Meters.reset()

		return rows, 0
	end

	local v = reader(stat_buffs)
	local weapon_extension = ScriptUnit.has_extension(unit, "weapon_system")
	local ctx = {
		wound_keyword = buff_extension:has_keyword("health_segment_breaking_reduce_damage_taken"),
	}

	toughness_context(ctx, unit, weapon_extension)
	crit_context(ctx, player, unit, weapon_extension)
	ability_context(ctx, unit, t)

	if t and ctx.toughness_damage then
		ctx.toughness_measured = Meters.sample_toughness(t, ctx.toughness_damage)
	end

	local show_headers = mod:get("show_headers")
	local hide_unchanged = mod:get("hide_unchanged")
	local show_other = mod:get("show_other")

	if show_other then
		table.clear(covered)
	end

	for i = 1, #groups do
		local group = groups[i]
		local header_pending = show_headers

		for j = 1, #group.lines do
			local line = group.lines[j]

			if mod:get("line_" .. line.key) and (ctx.has_toughness or not line.needs_toughness) and (ctx.has_ability or not line.needs_ability) and (not line.archetype or line.archetype == ctx.archetype) then
				local kind = line.kind or stat_kind(line.stat)
				local value = line.stat and v(line.stat) or line.calc(v, ctx)

				if show_other then
					if line.stat then
						covered[line.stat] = true
					else
						for k = 1, #line.stats do
							covered[line.stats[k]] = true
						end
					end
				end

				if not (hide_unchanged and at_base(kind, value, line.stat)) then
					if header_pending then
						header_pending = false

						push(mod:localize(group.id), "", true)
					end

					push(mod:localize("line_" .. line.key), format_value(kind, value), false)
				end
			end
		end
	end

	if show_other then
		local changed = mod.changed_stats(stat_buffs)
		local header_pending = show_headers

		for i = 1, #changed do
			local stat = changed[i]

			if not covered[stat] then
				if header_pending then
					header_pending = false

					push(mod:localize("other_header"), "", true)
				end

				push(stat, format_value(stat_kind(stat), v(stat)), false)
			end
		end
	end

	if num_rows > max_rows then
		-- Say so instead of dropping lines silently.
		local hidden = num_rows - max_rows + 1
		local last = rows[max_rows]

		last.label, last.value, last.is_header = string.format("%d more lines not shown", hidden), "", true

		return rows, max_rows
	end

	return rows, num_rows
end

-- _modified_stats lists the stats a buff touched this rebuild (buff.lua 730).
mod.changed_stats = function (stat_buffs)
	local v = reader(stat_buffs)
	local modified = rawget(stat_buffs, "_modified_stats")
	local changed = {}

	if modified then
		for stat in pairs(modified) do
			if stat_buff_types[stat] and math.abs(v(stat) - (base_values[stat] or 0)) >= EPSILON then
				changed[#changed + 1] = stat
			end
		end
	end

	table.sort(changed)

	return changed
end

mod:command("stattotals_info", mod:localize("command_description"), function ()
	local player, _, stat_buffs = local_stat_source()

	if not player then
		mod:echo("%s", mod:localize("no_stats"))

		return
	end

	local v = reader(stat_buffs)
	local changed = mod.changed_stats(stat_buffs)

	for i = 1, #changed do
		local stat = changed[i]

		-- The raw value too, so a line can be checked against the game's own number.
		mod:echo("%s", string.format("%s = %s (%.4f)", stat, format_value(stat_kind(stat), v(stat)), v(stat)))
	end

	mod:echo("%s", string.format("%d changed stats", #changed))

	-- The inputs of the passive regen formula, to compare with the measured line.
	local ctx = {}
	local unit = player.player_unit

	toughness_context(ctx, unit, ScriptUnit.has_extension(unit, "weapon_system"))

	if ctx.has_toughness then
		mod:echo("%s", string.format("regen inputs: base %.2f, weapon %.2f, coherency %.2f, coherency x %.2f, extra %.2f, rate x %.2f, percent %.4f, max %.0f",
			ctx.base_regen, ctx.weapon_regen, v("toughness_coherency_regen_rate_modifier"), v("toughness_coherency_regen_rate_multiplier"),
			v("toughness_extra_regen_rate"), v("toughness_regen_rate_modifier") * v("toughness_regen_rate_multiplier"), v("toughness_regen_percent"), ctx.max_toughness))
	end
end)
