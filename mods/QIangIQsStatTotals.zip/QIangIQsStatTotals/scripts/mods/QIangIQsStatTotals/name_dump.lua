-- One-time dump of the English names for talents and blessings, for matching the
-- source lists on the Stat Totals sources page. It only reads and writes one file.
-- Runs once: when the file exists, nothing here does anything.
--
-- Blessing names live in the backend master items, not in the Lua source:
-- trait items are "content/items/traits/..." and carry display_name, as
-- realms_loadout's forge_view_element_trait_inventory.lua:359 reads it.
-- File route as in QIangIQsBackendLog: Mods.lua.io to %APPDATA%\Fatshark\Darktide\.
local mod = get_mod("QIangIQsStatTotals")

local io = Mods and Mods.lua and Mods.lua.io or rawget(_G, "io")
local os = Mods and Mods.lua and Mods.lua.os or rawget(_G, "os")

local FILE_NAME = "qiangiqs_stat_totals_names.json"
local RETRY_SECONDS = 2
local GIVE_UP_SECONDS = 1800

local NameDump = {
	finished = false,
	elapsed = 0,
	next_try = 5,
}

local function target_path()
	local appdata = os and os.getenv and os.getenv("APPDATA")

	return appdata and (appdata .. "\\Fatshark\\Darktide\\" .. FILE_NAME) or nil
end

local function localized(key)
	local localization = Managers.localization

	if type(key) == "string" and localization:exists(key) then
		return localization:localize(key, true)
	end

	return nil
end

-- Text and number fields only, so the file holds no engine values.
local function plain_fields(item)
	local out = {}

	for key, value in pairs(item) do
		local kind = type(value)

		if type(key) == "string" and (kind == "string" or kind == "number" or kind == "boolean") then
			out[key] = value
		end
	end

	return out
end

local function collect_traits(MasterItems)
	local traits = {}

	for id, item in pairs(MasterItems.get_cached()) do
		if type(id) == "string" and string.find(id, "content/items/traits/", 1, true) == 1 and type(item) == "table" then
			local entry = plain_fields(item)

			entry.__id = id
			entry.__english_name = localized(item.display_name)
			traits[#traits + 1] = entry
		end
	end

	return traits
end

local function collect_talents()
	local talents = {}
	local archetypes = require("scripts/settings/ability/archetype_talents/archetype_talents")

	for archetype, list in pairs(archetypes) do
		if type(list) == "table" then
			for talent_id, talent in pairs(list) do
				if type(talent) == "table" and talent.display_name then
					talents[#talents + 1] = {
						archetype = archetype,
						id = talent_id,
						display_name = talent.display_name,
						__english_name = localized(talent.display_name),
					}
				end
			end
		end
	end

	return talents
end

local function write_atomic(path, text)
	local tmp = path .. ".tmp"
	local file = assert(io.open(tmp, "w"))

	file:write(text)
	file:close()

	if os.rename then
		os.remove(path)
		assert(os.rename(tmp, path))
	else
		local final = assert(io.open(path, "w"))

		final:write(text)
		final:close()
	end
end

local function ready(MasterItems)
	local localization = Managers.localization
	local backend = Managers.backend

	return localization and localization:is_ready() and backend and backend.interfaces and backend.interfaces.master_data and MasterItems.has_data()
end

local function try_dump()
	local MasterItems = require("scripts/backend/master_items")

	if not ready(MasterItems) then
		return false
	end

	local traits = collect_traits(MasterItems)

	if #traits == 0 then
		return false
	end

	local talents_ok, talents = pcall(collect_talents)
	local path = target_path()
	local text = cjson.encode({
		language = Managers.localization:language(),
		traits = traits,
		talents = talents_ok and talents or {},
		talents_error = (not talents_ok) and tostring(talents) or nil,
	})

	write_atomic(path, text)
	mod:echo("%s", string.format("Stat Totals saved %d blessing names and %d talent names to %s. Report this line when you see it.", #traits, talents_ok and #talents or 0, FILE_NAME))

	return true
end

NameDump.start = function ()
	local path = target_path()
	local existing = path and io and io.open(path, "r")

	if existing then
		existing:close()
		NameDump.finished = true
	elseif not path or not io then
		NameDump.finished = true
	end
end

NameDump.update = function (dt)
	if NameDump.finished then
		return
	end

	NameDump.elapsed = NameDump.elapsed + dt

	if NameDump.elapsed < NameDump.next_try then
		return
	end

	NameDump.next_try = NameDump.elapsed + RETRY_SECONDS

	local ok, result = pcall(try_dump)

	if not ok then
		-- One log line, then stop. It tries again on the next launch.
		NameDump.finished = true

		mod:error("Name dump stopped: %s", tostring(result))
	elseif result or NameDump.elapsed > GIVE_UP_SECONDS then
		NameDump.finished = true
	end
end

return NameDump
