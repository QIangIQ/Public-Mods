local mod = get_mod("QIangIQsStatTotals")

local groups = mod:io_dofile("QIangIQsStatTotals/scripts/mods/QIangIQsStatTotals/stat_lines")

local function checkbox(id, default)
	return { setting_id = id, type = "checkbox", default_value = default, tooltip = id .. "_tooltip" }
end

local function numeric(id, default, low, high)
	return { setting_id = id, type = "numeric", default_value = default, range = { low, high }, decimals_number = 0, tooltip = id .. "_tooltip" }
end

local widgets = {
	numeric("box_x", 1480, 0, 1920),
	numeric("box_y", 120, 0, 1080),
	numeric("box_width", 400, 200, 800),
	numeric("font_size", 16, 10, 32),
	numeric("box_opacity", 60, 0, 100),
	numeric("refresh_ms", 100, 0, 1000),
	checkbox("show_headers", true),
	checkbox("hide_unchanged", false),
	checkbox("show_other", false),
	checkbox("show_in_hub", false),
}

for i = 1, #groups do
	local group = groups[i]
	local sub_widgets = {}

	for j = 1, #group.lines do
		local line = group.lines[j]

		sub_widgets[j] = checkbox("line_" .. line.key, line.default == true)
	end

	widgets[#widgets + 1] = { setting_id = group.id, type = "group", sub_widgets = sub_widgets }
end

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = { widgets = widgets },
}
