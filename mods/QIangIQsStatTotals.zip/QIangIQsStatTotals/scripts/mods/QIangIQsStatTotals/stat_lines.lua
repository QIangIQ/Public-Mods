-- The lines the box can show. Shared by the data, localization and main files.
-- No percent signs in label or tip: both become DMF localization text, and DMF
-- passes that through string.format.
--
-- A line is one of:
--   stat = "name"   One game stat, shown as the game holds it. The display comes
--                   from BuffSettings.stat_buff_types.
--   calc = function One combined number, built exactly the way the named game
--                   file combines those stats. Every one cites its source.
--
-- Sources are Aussiemon/Darktide-Source-Code master e46b8926 (game 1.13.4).
--
-- Display kinds:
--   bonus   factor around 1, shown as signed percent
--   reduce  damage factor, shown as percent less damage (factor 0.8 is 20.0)
--   chance  0 to 1, shown as percent
--   per_sec amount per second
--   seconds seconds
--   flat    plain number

local function add(v, a, b)
	-- Every additive stat has base 1, so two stats combine as a + b - 1.
	return v(a) + v(b) - 1
end

local function attack_line(key, label, a, b, tip)
	return { key = key, label = label, stats = { a, b }, kind = "bonus", tip = tip, calc = function (v)
		return add(v, a, b)
	end }
end

-- scripts/utilities/attack/damage_calculation.lua 590-610:
--   modifiers = damage_taken_modifier + melee_damage_taken_modifier - 1
--   multipliers = damage_taken_multiplier * ranged * melee * ... * non_warp * ...
--   damage_taken_stat_buffs = modifiers * multipliers
-- The result goes into the hit before toughness and health split it
-- (attack.lua 353, damage_taken_calculation.lua calculate_attack_result).
local function general_factor(v, attack)
	local modifiers = v("damage_taken_modifier")
	local multipliers = v("damage_taken_multiplier") * v("non_warp_damage_taken_multiplier")

	if attack == "melee" then
		modifiers = modifiers + v("melee_damage_taken_modifier") - 1
		multipliers = multipliers * v("melee_damage_taken_multiplier")
	elseif attack == "ranged" then
		multipliers = multipliers * v("ranged_damage_taken_multiplier")
	end

	return modifiers * multipliers
end

-- scripts/utilities/attack/damage_taken_calculation.lua 231-262:
--   damage_modifier = state modifier + attack multiplier * weapon multiplier - 1
--   damage_modifier = damage_modifier * buff multiplier * buff modifier
--   melee hits are then scaled by the attack's value and melee_damage_modifier
-- The melee or ranged buff variants fold in the same way: multipliers multiply,
-- modifiers add. The attack's own values are unknown until a hit, so they count as 1.
local function toughness_factor(v, attack, ctx)
	local modifier = v("toughness_damage_taken_modifier")
	local multiplier = v("toughness_damage_taken_multiplier")

	if attack == "melee" then
		multiplier = multiplier * v("melee_toughness_damage_taken_multiplier")
		modifier = modifier + v("melee_toughness_damage_taken_modifier") - 1
	elseif attack == "ranged" then
		multiplier = multiplier * v("ranged_toughness_damage_taken_multiplier")
		modifier = modifier + v("ranged_toughness_damage_taken_modifier") - 1
	end

	local factor = ((ctx.state_toughness or 1) + (ctx.weapon_toughness or 1) - 1) * multiplier * modifier

	if attack == "melee" then
		factor = factor * (ctx.melee_toughness or 1)
	end

	return math.max(factor, 0)
end

local GENERAL_STATS = { "damage_taken_modifier", "damage_taken_multiplier", "non_warp_damage_taken_multiplier" }
local GENERAL_MELEE = { "damage_taken_modifier", "damage_taken_multiplier", "non_warp_damage_taken_multiplier", "melee_damage_taken_modifier", "melee_damage_taken_multiplier" }
local GENERAL_RANGED = { "damage_taken_modifier", "damage_taken_multiplier", "non_warp_damage_taken_multiplier", "ranged_damage_taken_multiplier" }
local TOUGH_STATS = { "toughness_damage_taken_modifier", "toughness_damage_taken_multiplier" }
local TOUGH_MELEE = { "toughness_damage_taken_modifier", "toughness_damage_taken_multiplier", "melee_toughness_damage_taken_modifier", "melee_toughness_damage_taken_multiplier" }
local TOUGH_RANGED = { "toughness_damage_taken_modifier", "toughness_damage_taken_multiplier", "ranged_toughness_damage_taken_modifier", "ranged_toughness_damage_taken_multiplier" }

local function concat(a, b)
	local out = {}

	for i = 1, #a do
		out[#out + 1] = a[i]
	end

	for i = 1, #b do
		out[#out + 1] = b[i]
	end

	return out
end

local REGEN_STATS = {
	"toughness_regen_rate_modifier",
	"toughness_regen_rate_multiplier",
	"toughness_coherency_regen_rate_modifier",
	"toughness_coherency_regen_rate_multiplier",
	"min_toughness_coherency_regen_rate_modifier",
	"toughness_extra_regen_rate",
	"toughness_regen_percent",
}

-- scripts/extension_systems/toughness/player_unit_toughness_extension.lua 126-163.
-- On a Fatshark server your own unit has PlayerHuskToughnessExtension
-- (player_character_unit_template.lua 641), which runs none of this, so the
-- formula is rebuilt here. Regen disabled states and the delay are left out: this
-- is the rate while regen is running.
local function regen_rate(v, ctx, in_combat)
	local coherency = v("toughness_coherency_regen_rate_modifier")
	local min_coherency = math.max(v("min_toughness_coherency_regen_rate_modifier") - 1, 0)
	local always = coherency > 0 and min_coherency > 0
	local rate = 0

	if not in_combat or always then
		if in_combat then
			coherency = coherency * min_coherency
		end

		coherency = coherency + v("toughness_extra_regen_rate")
		coherency = coherency * v("toughness_coherency_regen_rate_multiplier")
		rate = ctx.base_regen * ctx.weapon_regen * v("toughness_regen_rate_modifier") * v("toughness_regen_rate_multiplier") * coherency
	end

	return rate + v("toughness_regen_percent") * ctx.max_toughness
end

local groups = {
	{
		id = "group_ability",
		label = "Combat ability",
		lines = {
			{
				key = "ability_ready", label = "Ability ready", kind = "text", default = true, stats = {}, needs_ability = true,
				tip = "How full your combat ability is, with charges left. Read from the game, so it moves with every restore.",
				calc = function (_, ctx)
					return ctx.ability_text
				end,
			},
			{
				key = "ability_recharge", label = "Ability recharge now", kind = "text", default = true, stats = {}, needs_ability = true,
				tip = "Percent of the ability regained per second over the last 1.5 seconds, measured. Instant restores are left out of this and shown on the next line.",
				calc = function (_, ctx)
					return ctx.ability_rate_text
				end,
			},
			{
				key = "ability_restore", label = "Last ability restore", kind = "text", default = true, stats = {}, needs_ability = true,
				tip = "The last instant jump in your ability, such as cooldown back from a specialist or elite kill, and how long ago it was.",
				calc = function (_, ctx)
					return ctx.ability_restore_text
				end,
			},
		},
	},
	{
		id = "group_attack",
		label = "Attack",
		lines = {
			attack_line("attack_melee", "Attack bonus melee", "damage", "melee_damage", "Your bonus to all damage plus your melee damage bonus. They add together in the game."),
			attack_line("attack_ranged", "Attack bonus ranged", "damage", "ranged_damage", "Your bonus to all damage plus your ranged damage bonus. They add together in the game."),
			attack_line("strength_melee", "Strength melee", "power_level_modifier", "melee_power_level_modifier", "Your Strength bonus for all attacks plus for melee. They add together, and Strength multiplies attack power."),
			attack_line("strength_ranged", "Strength ranged", "power_level_modifier", "ranged_power_level_modifier", "Your Strength bonus for all attacks plus for ranged. They add together, and Strength multiplies attack power."),
			attack_line("impact_melee", "Impact melee", "impact_modifier", "melee_impact_modifier", "Your impact bonus for all attacks plus for melee. They add together in the game's stagger calculation."),
			attack_line("impact_ranged", "Impact ranged", "impact_modifier", "ranged_impact_modifier", "Your impact bonus for all attacks plus for ranged. They add together in the game's stagger calculation."),
			attack_line("speed_melee", "Attack speed melee", "attack_speed", "melee_attack_speed", "Your attack speed plus melee attack speed. They add together for melee actions."),
			attack_line("speed_ranged", "Attack speed ranged", "attack_speed", "ranged_attack_speed", "Your attack speed plus ranged attack speed. They add together when firing."),
			{
				key = "crit_melee", label = "Crit chance melee", kind = "chance", default = true,
				stats = { "critical_strike_chance", "melee_critical_strike_chance", "critical_strike_chance_to_damage_convert" },
				tip = "Class base chance plus your crit chance stats. Includes the weapon's own crit chance only while a melee weapon is in your hands.",
				calc = function (v, ctx)
					-- scripts/utilities/attack/critical_strike.lua 15-38
					local chance = ctx.base_crit + v("critical_strike_chance") + v("melee_critical_strike_chance") + (ctx.wielded_kind == "melee" and ctx.weapon_crit or 0)

					return math.min(math.max(chance, 0), 1) * (1 - v("critical_strike_chance_to_damage_convert"))
				end,
			},
			{
				key = "crit_ranged", label = "Crit chance ranged", kind = "chance", default = true,
				stats = { "critical_strike_chance", "ranged_critical_strike_chance", "critical_strike_chance_to_damage_convert" },
				tip = "Class base chance plus your crit chance stats. Includes the weapon's own crit chance only while a ranged weapon is in your hands.",
				calc = function (v, ctx)
					-- scripts/utilities/attack/critical_strike.lua 15-38
					local chance = ctx.base_crit + v("critical_strike_chance") + v("ranged_critical_strike_chance") + (ctx.wielded_kind == "ranged" and ctx.weapon_crit or 0)

					return math.min(math.max(chance, 0), 1) * (1 - v("critical_strike_chance_to_damage_convert"))
				end,
			},
			-- damage_calculation.lua, _finesse_boost_damage: critical_damage + ranged + melee - 2
			attack_line("critdmg_melee", "Crit damage melee", "critical_strike_damage", "melee_critical_strike_damage", "Bonus crit damage for all attacks plus for melee."),
			attack_line("critdmg_ranged", "Crit damage ranged", "critical_strike_damage", "ranged_critical_strike_damage", "Bonus crit damage for all attacks plus for ranged."),
			-- damage_calculation.lua, _finesse_boost_damage: weakspot stats add
			attack_line("weak_melee", "Weakspot damage melee", "weakspot_damage", "melee_weakspot_damage", "Bonus weakspot damage for all attacks plus for melee. Leaves out bonuses that depend on the target."),
			attack_line("weak_ranged", "Weakspot damage ranged", "weakspot_damage", "ranged_weakspot_damage", "Bonus weakspot damage for all attacks plus for ranged. Leaves out bonuses that depend on the target."),
			-- damage_calculation.lua 630-660: rending multipliers add, minus their count
			attack_line("rend_melee", "Rending melee", "rending_multiplier", "melee_rending_multiplier", "Rending for all attacks plus for melee. Leaves out rending that depends on the target or hit."),
			attack_line("rend_ranged", "Rending ranged", "rending_multiplier", "ranged_rending_multiplier", "Rending for all attacks plus for ranged. Leaves out rending that depends on the target or hit."),
			{ key = "reload_speed", label = "Reload speed", stat = "reload_speed" },
			{ key = "wield_speed", label = "Weapon swap speed", stat = "wield_speed" },
			{ key = "finesse", label = "Finesse bonus", stat = "finesse_modifier_bonus" },
			{ key = "finesse_melee", label = "Finesse bonus melee", stat = "melee_finesse_modifier_bonus" },
			{ key = "finesse_ranged", label = "Finesse bonus ranged", stat = "ranged_finesse_modifier_bonus" },
		},
	},
	{
		id = "group_targets",
		label = "Damage by target",
		lines = {
			{ key = "vs_elites", label = "Damage vs elites", stat = "damage_vs_elites" },
			{ key = "vs_specials", label = "Damage vs specialists", stat = "damage_vs_specials" },
			{ key = "vs_horde", label = "Damage vs horde", stat = "damage_vs_horde" },
			{ key = "vs_monsters", label = "Damage vs monstrosities", stat = "damage_vs_monsters" },
			{ key = "vs_ogryn", label = "Damage vs Ogryns", stat = "damage_vs_ogryn" },
			{ key = "vs_captains", label = "Damage vs captains", stat = "damage_vs_captains" },
			{ key = "vs_unarmored", label = "Damage vs unarmoured", stat = "unarmored_damage" },
			{ key = "vs_armored", label = "Damage vs flak", stat = "armored_damage" },
			{ key = "vs_resistant", label = "Damage vs unyielding", stat = "resistant_damage" },
			{ key = "vs_berserker", label = "Damage vs maniacs", stat = "berserker_damage" },
			{ key = "vs_super_armor", label = "Damage vs carapace", stat = "super_armor_damage" },
			{ key = "vs_infested", label = "Damage vs infested", stat = "disgustingly_resilient_damage" },
		},
	},
	{
		id = "group_defence",
		label = "Damage reduction",
		lines = {
			{
				key = "dr_general", label = "Damage reduction", kind = "reduce", default = true, stats = GENERAL_STATS,
				tip = "Reduces a hit before it reaches toughness or health, such as the Ogryn dodge reduction. Stats for one attack type or enemy type are left out; melee and ranged have their own lines.",
				calc = function (v)
					return general_factor(v)
				end,
			},
			{
				key = "dr_health_only", label = "Health damage reduction", kind = "reduce", default = true, stats = { "health_segment_damage_taken_multiplier" },
				tip = "Health only, such as Bleed for the Emperor. The game applies it only to a hit that would break a wound, so it is not added into any other line.",
				calc = function (v, ctx)
					-- damage_taken_calculation.lua 387-397: needs the keyword, then multiplies health damage.
					return ctx.wound_keyword and v("health_segment_damage_taken_multiplier") or 1
				end,
			},
			{
				key = "dr_toughness", label = "Toughness damage reduction", kind = "reduce", default = true, stats = TOUGH_STATS,
				tip = "Toughness only, such as Iron Will. Includes your current movement, such as sliding, and your weapon's toughness value, as the game does. It stacks on top of Damage reduction when a hit lands on toughness.",
				calc = function (v, ctx)
					return toughness_factor(v, nil, ctx)
				end,
			},
			{
				key = "dr_combined", label = "Damage and toughness together", kind = "reduce", stats = concat(GENERAL_STATS, TOUGH_STATS),
				tip = "Damage reduction and Toughness damage reduction multiplied, for a hit that lands on toughness.",
				calc = function (v, ctx)
					return general_factor(v) * toughness_factor(v, nil, ctx)
				end,
			},
			{
				key = "dr_combined_melee", label = "Together vs melee", kind = "reduce", stats = concat(GENERAL_MELEE, TOUGH_MELEE),
				tip = "As Damage and toughness together, with the melee only stats and your melee toughness value.",
				calc = function (v, ctx)
					return general_factor(v, "melee") * toughness_factor(v, "melee", ctx)
				end,
			},
			{
				key = "dr_combined_ranged", label = "Together vs ranged", kind = "reduce", stats = concat(GENERAL_RANGED, TOUGH_RANGED),
				tip = "As Damage and toughness together, with the ranged only stats.",
				calc = function (v, ctx)
					return general_factor(v, "ranged") * toughness_factor(v, "ranged", ctx)
				end,
			},
			{
				key = "dr_general_melee", label = "Damage reduction vs melee", kind = "reduce", stats = GENERAL_MELEE,
				tip = "As Damage reduction, with the melee only stats.",
				calc = function (v)
					return general_factor(v, "melee")
				end,
			},
			{
				key = "dr_general_ranged", label = "Damage reduction vs ranged", kind = "reduce", stats = GENERAL_RANGED,
				tip = "As Damage reduction, with the ranged only stats.",
				calc = function (v)
					return general_factor(v, "ranged")
				end,
			},
			{
				key = "dr_toughness_melee", label = "Toughness reduction vs melee", kind = "reduce", stats = TOUGH_MELEE,
				tip = "As Toughness damage reduction, with the melee only stats and your melee toughness value.",
				calc = function (v, ctx)
					return toughness_factor(v, "melee", ctx)
				end,
			},
			{
				key = "dr_toughness_ranged", label = "Toughness reduction vs ranged", kind = "reduce", stats = TOUGH_RANGED,
				tip = "As Toughness damage reduction, with the ranged only stats.",
				calc = function (v, ctx)
					return toughness_factor(v, "ranged", ctx)
				end,
			},
			{
				key = "dr_warp", label = "Reduction vs warp damage", kind = "reduce", stats = { "damage_taken_modifier", "damage_taken_multiplier", "warp_damage_taken_multiplier" },
				tip = "Damage taken stats for warp damage. A negative number means you take more.",
				calc = function (v)
					return v("damage_taken_modifier") * v("damage_taken_multiplier") * v("warp_damage_taken_multiplier")
				end,
			},
		},
	},
	{
		id = "group_toughness",
		label = "Toughness",
		lines = {
			{
				key = "regen_ooc", label = "Toughness regen out of combat", kind = "per_sec", default = true, stats = REGEN_STATS, needs_toughness = true,
				tip = "Toughness per second while regen is running with no enemy in melee slots around you, using the game's formula. Coherency counts, so this is 0 alone without a flat regen buff.",
				calc = function (v, ctx)
					return regen_rate(v, ctx, false)
				end,
			},
			{
				key = "regen_combat", label = "Toughness regen in combat", kind = "per_sec", default = true, stats = REGEN_STATS, needs_toughness = true,
				tip = "Toughness per second with enemies in melee slots around you, using the game's formula. Usually 0 unless a buff allows regen in combat. Both regen lines are always shown, because the combat state is not available on a client.",
				calc = function (v, ctx)
					return regen_rate(v, ctx, true)
				end,
			},
			{
				key = "regen_measured", label = "Toughness regen now", kind = "per_sec", default = true, stats = {}, needs_toughness = true,
				tip = "Toughness actually regained per second over the last 1.5 seconds, measured from the game's toughness value. Counts every source: coherency, talents, kills, blessings. The two formula lines below only count passive coherency regen, which is 0 when you are alone.",
				calc = function (_, ctx)
					return ctx.toughness_measured or 0
				end,
			},
			{
				key = "regen_delay", label = "Toughness regen delay", kind = "seconds", needs_toughness = true, stats = { "toughness_regen_delay_modifier", "toughness_regen_delay_multiplier" },
				tip = "Seconds after damage before coherency regen starts, with your weapon and buffs included.",
				calc = function (v, ctx)
					-- player_unit_toughness_extension.lua 388-392
					return ctx.base_delay * ctx.weapon_delay * v("toughness_regen_delay_modifier") * v("toughness_regen_delay_multiplier")
				end,
			},
			{
				key = "max_toughness", label = "Max toughness", kind = "flat", default = true, needs_toughness = true, stats = { "toughness", "toughness_bonus", "toughness_bonus_flat" },
				tip = "Your maximum toughness right now, read from the game.",
				calc = function (_, ctx)
					return ctx.max_toughness
				end,
			},
			{
				key = "replenish_melee", label = "Toughness on melee kill", kind = "bonus", stats = { "toughness_melee_replenish", "toughness_replenish_modifier", "toughness_replenish_multiplier" },
				tip = "Bonus to toughness regained from melee kills.",
				calc = function (v)
					-- player_unit_toughness_extension.lua 230-233
					return (v("toughness_melee_replenish") + v("toughness_replenish_modifier") - 1) * v("toughness_replenish_multiplier")
				end,
			},
			{
				key = "replenish_all", label = "Toughness regained", kind = "bonus", stats = { "toughness_replenish_modifier", "toughness_replenish_multiplier" },
				tip = "Bonus to toughness regained from any source that counts stats.",
				calc = function (v)
					-- player_unit_toughness_extension.lua 263-264
					return v("toughness_replenish_modifier") * v("toughness_replenish_multiplier")
				end,
			},
		},
	},
	{
		id = "group_other",
		label = "Movement and other",
		lines = {
			{ key = "movement_speed", label = "Movement speed", stat = "movement_speed" },
			{ key = "sprint_speed", label = "Sprint speed", stat = "sprint_movement_speed" },
			{ key = "dodge_distance", label = "Dodge distance", stat = "dodge_distance_modifier" },
			{ key = "extra_dodges", label = "Extra dodges", stat = "extra_consecutive_dodges" },
			{ key = "stamina", label = "Extra stamina", stat = "stamina_modifier" },
			{ key = "stamina_regen", label = "Stamina regen", stat = "stamina_regeneration_modifier" },
			{ key = "stamina_cost", label = "Stamina cost", stat = "stamina_cost_multiplier" },
			{ key = "block_cost", label = "Block cost", stat = "block_cost_multiplier" },
			{ key = "push_cost", label = "Push cost", stat = "push_cost_multiplier" },
			{ key = "max_health", label = "Max health bonus", stat = "max_health_modifier" },
			{ key = "healing", label = "Healing received", stat = "healing_recieved_modifier" },
			{ key = "ability_regen", label = "Ability cooldown regen", stat = "combat_ability_resource_regen_modifier" },
			{ key = "ammo_reserve", label = "Ammo reserve", stat = "ammo_reserve_capacity" },
			{ key = "clip_size", label = "Clip size", stat = "clip_size_modifier" },
			{ key = "ammo_usage", label = "Ammo use", stat = "ammo_usage" },
			{ key = "warp_charge", label = "Peril generated", stat = "warp_charge_amount" },
			{ key = "suppression", label = "Suppression dealt", stat = "suppression_dealt" },
		},
	},
}

-- Skitarii. Game files call the class cryptic. Lines with archetype show only on
-- that class. Stats from cryptic_buff_templates.lua, all named in buff_settings.lua.
groups[#groups + 1] = {
	id = "group_skitarii",
	label = "Skitarii",
	lines = {
		{ key = "skitarii_chordclaw", label = "Chordclaw damage", stat = "cryptic_chordclaw_damage", archetype = "cryptic", default = true },
		{ key = "skitarii_charges", label = "Extra ability charges", stat = "ability_extra_charges", archetype = "cryptic", default = true },
		{ key = "skitarii_electrocuted", label = "Damage vs electrocuted", stat = "damage_vs_electrocuted", archetype = "cryptic", default = true },
		{ key = "skitarii_heavy", label = "Melee heavy damage", stat = "melee_heavy_damage", archetype = "cryptic", default = true },
		{ key = "skitarii_arcs", label = "Arc grenade extra arcs", stat = "arc_grenade_extra_arcs", archetype = "cryptic", default = true },
		{ key = "skitarii_grenades", label = "Extra grenades", stat = "extra_max_amount_of_grenades", archetype = "cryptic", default = true },
		{ key = "skitarii_regen_restored", label = "Ability cooldown restored", stat = "combat_ability_resource_restored_modifier", archetype = "cryptic", default = true },
		{ key = "skitarii_health_cap", label = "Health damage cap per hit", stat = "max_health_damage_taken_per_hit", archetype = "cryptic", default = true },
		{ key = "skitarii_vs_ogryn", label = "Ranged damage vs Ogryns", stat = "ranged_damage_vs_ogryn", archetype = "cryptic" },
		{ key = "skitarii_vs_monsters", label = "Ranged damage vs monstrosities", stat = "ranged_damage_vs_monsters", archetype = "cryptic" },
		{ key = "skitarii_vs_captains", label = "Ranged damage vs captains", stat = "ranged_damage_vs_captains", archetype = "cryptic" },
		{ key = "skitarii_push_impact", label = "Push impact", stat = "push_impact_modifier", archetype = "cryptic" },
		{ key = "skitarii_revive", label = "Revive speed", stat = "revive_speed_modifier", archetype = "cryptic" },
		{ key = "skitarii_corruption", label = "Corruption taken", stat = "corruption_taken_multiplier", archetype = "cryptic" },
		{ key = "skitarii_recoil", label = "Recoil", stat = "recoil_modifier", archetype = "cryptic" },
		{ key = "skitarii_spread", label = "Spread", stat = "spread_modifier", archetype = "cryptic" },
		{ key = "skitarii_cleave", label = "Cleave", stat = "max_hit_mass_attack_modifier", archetype = "cryptic" },
		{ key = "skitarii_melee_cleave", label = "Melee cleave", stat = "max_melee_hit_mass_attack_modifier", archetype = "cryptic" },
		{ key = "skitarii_ranged_cleave", label = "Ranged cleave", stat = "ranged_max_hit_mass_attack_modifier", archetype = "cryptic" },
	},
}

-- The lines asked for by name, shown by default. Crit and max toughness set this
-- in their own entries above.
local DEFAULT_ON = {
	attack_melee = true,
	attack_ranged = true,
	strength_melee = true,
	strength_ranged = true,
	impact_melee = true,
	impact_ranged = true,
	speed_melee = true,
	speed_ranged = true,
}

for i = 1, #groups do
	local lines = groups[i].lines

	for j = 1, #lines do
		local line = lines[j]

		if DEFAULT_ON[line.key] then
			line.default = true
		end
	end
end

return groups
