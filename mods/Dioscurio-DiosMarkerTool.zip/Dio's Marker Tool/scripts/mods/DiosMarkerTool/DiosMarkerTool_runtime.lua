--[[
    Engine reference resolver and unit/position helpers.

    PORTED FROM SlotZones (core/runtime.lua and core/util.lua, author LAUREHTE),
    not called into. Ported rather than referenced so this mod has no runtime
    dependency on SlotZones being installed or enabled.

    WHY THIS FILE EXISTS AT ALL - the bug it fixes:

        local Vector3 = Vector3
        local ScriptUnit = ScriptUnit

    Those two lines at the top of a mod file are the standard Lua
    micro-optimisation and they are fatal in Darktide. Mod files load BEFORE
    the engine populates its globals, so both captured nil - permanently. Every
    call through them then failed inside a pcall and surfaced as "could not
    resolve position", which sent two rounds of debugging at the position logic
    when the problem was that the API was simply absent.

    SlotZones solves it with lazy resolution: rawget(_G, name) on first access,
    cached once found. RitualZones does the same inline. Both work. That is the
    whole difference.

    The helpers below are kept structurally faithful to the originals on
    purpose. Two details in particular look like they could be tidied and must
    not be:

      * valid_vector3 reads v.x / v.y / v.z as FIELDS, each in its own pcall -
        not Vector3.x(v). Field access works on both a Vector3 and a boxed
        position, and a failure on any axis disqualifies the whole vector.

      * unit_is_alive checks type(unit) ~= "userdata" first and falls back to
        the global ALIVE lookup table. A unit that is not userdata cannot be
        passed to Unit.alive at all, and ALIVE is the only thing that can
        answer for it.
--]]

local Runtime = {
	refs = {
		Vector3 = nil,
		Vector3Box = nil,
		Unit = nil,
		ScriptUnit = nil,
		World = nil,
		Quaternion = nil,
	},
}

function Runtime.resolve()
	local refs = Runtime.refs

	if not refs.Vector3 then
		refs.Vector3 = rawget(_G, "Vector3")
	end
	if not refs.Vector3Box then
		refs.Vector3Box = rawget(_G, "Vector3Box")
	end
	if not refs.Unit then
		refs.Unit = rawget(_G, "Unit")
	end
	if not refs.ScriptUnit then
		refs.ScriptUnit = rawget(_G, "ScriptUnit")
	end
	if not refs.World then
		refs.World = rawget(_G, "World")
	end
	if not refs.Quaternion then
		refs.Quaternion = rawget(_G, "Quaternion")
	end

	return refs
end

-- --------------------------------------------------------------------------

local function valid_number(v)
	return type(v) == "number" and v == v and v > -math.huge and v < math.huge
end

local function valid_vector3(v)
	if not v then
		return false
	end

	local ok_x, x = pcall(function()
		return v.x
	end)
	local ok_y, y = pcall(function()
		return v.y
	end)
	local ok_z, z = pcall(function()
		return v.z
	end)

	if not ok_x or not ok_y or not ok_z then
		return false
	end

	return valid_number(x) and valid_number(y) and valid_number(z)
end

Runtime.valid_number = valid_number
Runtime.valid_vector3 = valid_vector3

function Runtime.unit_is_alive(unit)
	local refs = Runtime.resolve()
	local ALIVE = rawget(_G, "ALIVE")

	if type(unit) ~= "userdata" then
		if ALIVE then
			local ok_alive, alive_lookup = pcall(function()
				return ALIVE[unit]
			end)
			return ok_alive and alive_lookup and true or false
		end
		return false
	end

	if not unit or not refs.Unit or not refs.Unit.alive then
		if ALIVE then
			local ok_alive, alive_lookup = pcall(function()
				return ALIVE[unit]
			end)
			if ok_alive and alive_lookup then
				return true
			end
		end
		return false
	end

	local ok, alive = pcall(refs.Unit.alive, unit)
	if ok then
		return alive and true or false
	end

	if ALIVE then
		local ok_alive, alive_lookup = pcall(function()
			return ALIVE[unit]
		end)
		if ok_alive and alive_lookup then
			return true
		end
	end

	return false
end

--[[
    The local player's unit.

    player_unit IS A FIELD, not a method. SlotZones reads
    `local_player.player_unit` and HavocTracker reads `player.player_unit` in
    seven places. Calling it as player:player_unit() is a nil-call, and when
    wrapped in a pcall it returns nil silently - which was the second half of
    the "could not resolve position" bug.

    local_player_safe is preferred where available: local_player calls
    Network.peer_id(), a C function that faults before the network is up, and
    pcall does NOT catch it. That crash was found and fixed in CurioHunter.
--]]
function Runtime.get_local_player_unit()
	local player_manager = Managers and Managers.player
	if not player_manager then
		return nil
	end

	local local_player

	if player_manager.local_player_safe then
		local ok, p = pcall(player_manager.local_player_safe, player_manager, 1)
		local_player = ok and p or nil
	end

	if not local_player and player_manager.local_player then
		local ok, p = pcall(player_manager.local_player, player_manager, 1)
		local_player = ok and p or nil
	end

	return local_player and local_player.player_unit or nil
end

--[[
    Position, four steps, cheapest and most reliable first. Ported from
    Util:get_unit_position (util.lua:156-185).

      1. The unit's own boxed position off an extension - already computed.
      2. POSITION_LOOKUP[unit] - the engine's global table, what Fatshark's own
         code reads.
      3. Unit.world_position(unit, 1) - the direct engine call.
      4. nil.

    Every step is validated, because a vector that cannot be indexed is worse
    than nil: it fails later, somewhere else, with a less obvious message.
--]]
function Runtime.get_unit_position(unit, extension)
	local refs = Runtime.resolve()

	if not unit then
		return nil
	end

	if not Runtime.unit_is_alive(unit) then
		return nil
	end

	if extension and extension.position and extension.position.unbox then
		local ok, pos = pcall(extension.position.unbox, extension.position)
		if ok and pos and valid_vector3(pos) then
			return pos
		end
	end

	local LOOKUP = rawget(_G, "POSITION_LOOKUP")

	if LOOKUP then
		local ok_lookup, lookup_pos = pcall(function()
			return LOOKUP[unit]
		end)
		if ok_lookup and lookup_pos and valid_vector3(lookup_pos) then
			return lookup_pos
		end
	end

	if refs.Unit and refs.Unit.world_position then
		local ok, pos = pcall(refs.Unit.world_position, unit, 1)
		if ok and pos and valid_vector3(pos) then
			return pos
		end
	end

	return nil
end

--[[
    Extension fetch that cannot throw on a missing extension system.
--]]
function Runtime.extension(unit, name)
	local refs = Runtime.resolve()
	local SU = refs.ScriptUnit

	if not SU or not unit or not SU.has_extension then
		return nil
	end

	local ok, has = pcall(SU.has_extension, unit, name)
	if not ok or not has then
		return nil
	end

	local ok2, ext = pcall(SU.extension, unit, name)
	return ok2 and ext or nil
end

return Runtime
