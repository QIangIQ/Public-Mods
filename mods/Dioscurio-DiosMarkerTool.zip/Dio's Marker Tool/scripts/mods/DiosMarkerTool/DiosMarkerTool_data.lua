local mod = get_mod("DiosMarkerTool")

--[[
    Options page.

    NO DEFAULT KEYS ARE BOUND. With 93 mods loaded, claiming a keybind by
    default is an invitation to a silent conflict that presents as "the mod
    does nothing". The user binds these once in mod options.
--]]
return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,

	options = {
		widgets = {
			{
				setting_id  = "group_keys",
				type        = "group",
				sub_widgets = {
					{
						setting_id  = "key_place",
						type        = "keybind",
						default_value = {},
						keybind_global = false,
						keybind_trigger = "pressed",
						keybind_type = "function_call",
						function_name = "kb_place",
						tooltip = "key_place_tooltip",
					},
					{
						setting_id  = "key_cycle",
						type        = "keybind",
						default_value = {},
						keybind_global = false,
						keybind_trigger = "pressed",
						keybind_type = "function_call",
						function_name = "kb_cycle",
						tooltip = "key_cycle_tooltip",
					},
					{
						setting_id  = "key_undo",
						type        = "keybind",
						default_value = {},
						keybind_global = false,
						keybind_trigger = "pressed",
						keybind_type = "function_call",
						function_name = "kb_undo",
						tooltip = "key_undo_tooltip",
					},
					{
						setting_id  = "key_delete",
						type        = "keybind",
						default_value = {},
						keybind_global = false,
						keybind_trigger = "pressed",
						keybind_type = "function_call",
						function_name = "kb_delete",
						tooltip = "key_delete_tooltip",
					},
					{
						setting_id  = "delete_radius",
						type        = "numeric",
						default_value = 5,
						range       = { 1, 20 },
						decimals_number = 1,
						tooltip     = "delete_radius_tooltip",
					},
				},
			},

			{
				setting_id  = "group_recording",
				type        = "group",
				sub_widgets = {
					--[[
						Defaults ON, and this is the one setting worth
						arguing about.

						Boss and monster spawns do not fire on proximity to a
						point. They fire on a 1-D comparison along the main
						path (monster_pacing.lua:672,691):

						  if spawn_travel_distance <= ahead_travel_distance

						A 3-D position has no place in that comparison, so a
						position-only marker renders but cannot predict. The
						distance costs one float and one engine call, and the
						navmesh snap it needs is already being done to get a
						valid position at all.

						Turning this off is supported and the cache format
						allows it. But backfilling later means replaying every
						map you have marked.
					--]]
					{
						setting_id  = "record_distance",
						type        = "checkbox",
						default_value = true,
						tooltip     = "record_distance_tooltip",
					},
				},
			},

			{
				setting_id  = "group_display",
				type        = "group",
				sub_widgets = {
					{
						setting_id  = "show_markers",
						type        = "checkbox",
						default_value = true,
						tooltip     = "show_markers_tooltip",
					},
					{
						setting_id  = "marker_size",
						type        = "numeric",
						default_value = 40,
						range       = { 16, 96 },
						decimals_number = 0,
						tooltip     = "marker_size_tooltip",
					},
					--[[
						Default 110 of 255, not 255.

						The harvested skulls shipped fully opaque and the
						complaint was immediate: "way too big and bright and I
						can't see anything when I'm actually playing". These
						are reference marks sitting behind a fight, so they
						start faint.
					--]]
					{
						setting_id  = "marker_opacity",
						type        = "numeric",
						default_value = 110,
						range       = { 20, 255 },
						decimals_number = 0,
						tooltip     = "marker_opacity_tooltip",
					},
					{
						setting_id  = "show_hud",
						type        = "checkbox",
						default_value = true,
						tooltip     = "show_hud_tooltip",
					},
				},
			},
		},
	},
}
