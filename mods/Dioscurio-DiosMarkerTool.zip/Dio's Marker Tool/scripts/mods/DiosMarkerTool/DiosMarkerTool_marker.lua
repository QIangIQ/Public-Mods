local mod = get_mod("DiosMarkerTool")

--[[
    World marker template for hand-placed markers.

    WHY A TEMPLATE AND NOT A CUSTOM DRAW. An earlier attempt in HavocTracker
    hand-projected world positions to screen space and "never appeared once"
    (HavocTracker_marker.lua:11). HudElementWorldMarkers already does the
    projection, clamping, distance falloff and depth handling correctly, and it
    is what the game itself uses. Register a template and hand it positions.

    The name is deliberately mod-owned so HavocTracker's declutter toggle can
    find and hide these: that gate identifies mod markers by testing the
    template name against the game's own vanilla manifest, so anything not
    shipped by Fatshark is hidden on toggle. A vanilla-looking name would make
    these unhideable.
--]]

local UIWidget = require("scripts/managers/ui/ui_widget")

local template = {}

local DEFAULT_ICON = "content/ui/materials/icons/difficulty/difficulty_skull_uprising"

template.name            = "DiosMarkerTool_manual_marker"
template.size            = { 40, 40 }
template.min_distance    = 0
template.position_offset = { 0, 0, 1.2 }

--[[
    Line of sight OFF.

    A marker recording where a trigger is has to be visible through the wall it
    sits behind, otherwise it cannot tell you anything you did not already know
    by standing there.
--]]
template.check_line_of_sight = false

--[[
    Distance falloff, same reasoning as HavocTracker's.

    An icon sized to read at 10 m is a billboard at 200 m. That is exactly what
    made the boss trigger skulls dominate the screen - "way too big and bright
    and I can't see anything" - so scale down with distance and keep the
    opacity low by default. These are reference marks, not threat warnings.
--]]
--[[
    SCALE AND FADE - THE FIELD NAMES ARE A CONTRACT, AND MINE WERE WRONG.

    The first version of this file set

        scale_settings = { default_scale, min_scale, max_scale,
                           scale_from = 12, scale_to = 160 }

    which is wrong in three separate ways, and the marker would have thrown on
    every single draw. From the engine (hud_element_world_markers.lua:546-584):

        _get_scale = function (self, scale_settings, distance)
            if distance > scale_settings.distance_max then
                return scale_settings.scale_from
            elseif distance < scale_settings.distance_min then
                return scale_settings.scale_to
            ...
            eased = easing_function and easing_function(frac) or frac

        _get_fade = function (self, fade_settings, distance)
            if distance > fade_settings.distance_max then ...
            eased_distance_fade_fraction = easing_function(distance_fade_fraction)

    So:

      1. distance_max and distance_min are REQUIRED and I never set them.
         `distance > nil` is "attempt to compare number with nil" - a throw,
         every frame, for every marker.

      2. scale_from and scale_to are SCALE VALUES (0.4 -> 1), not distances. I
         had put metres in them, so even without the throw the marker would
         have been scaled by 12x to 160x.

      3. fade_settings.easing_function is called UNCONDITIONALLY in the
         interpolating branch - note the asymmetry with _get_scale, which
         guards it. A nil easing function on fade is therefore also a throw.
         min_scale / max_scale / default_scale / min_fade / max_fade are read
         nowhere at all.

    Copied from markers_aio's working templates rather than re-derived, because
    it has clearly already paid for this. math.easeCubic is what it uses for
    both.

    NOTE the inverted distance_min on fade: fading is driven from
    max_distance - evolve*2, so the marker fades OUT as it approaches the far
    limit rather than fading as it gets close.
--]]
local MAX_DISTANCE = 400
local EVOLVE_DISTANCE = 12

template.max_distance = MAX_DISTANCE
template.evolve_distance = EVOLVE_DISTANCE

template.scale_settings = {
	scale_from = 0.45,
	scale_to = 1,
	distance_max = MAX_DISTANCE,
	distance_min = EVOLVE_DISTANCE,
	easing_function = math.easeCubic,
}

template.fade_settings = {
	default_fade = 1,
	fade_from = 0,
	fade_to = 1,
	distance_max = MAX_DISTANCE,
	distance_min = MAX_DISTANCE - EVOLVE_DISTANCE * 2,
	easing_function = math.easeCubic,
}

--[[
    KEEP OFF-SCREEN MARKERS OFF-SCREEN.

    markers_aio offers screen_clamp as an option and defaults it per marker
    type. For an authoring tool it should be false: a clamped marker sits
    pinned to the screen edge, and when you are placing a dozen triggers on one
    map that turns into a ring of icons round the viewport that tells you
    nothing about where anything is. You want to see a marker when you are
    looking at it.
--]]
template.screen_clamp = false

--[[
    Smart tag integration is deliberately NOT enabled.

    markers_aio sets using_smart_tag_system = true with a get_smart_tag_id so
    its markers participate in the game's ping system. These are private
    authoring notes - they should not be pingable, should not be announced to
    the team, and should not occupy a smart tag slot.
--]]

template.create_widget_defintion = function (template_inner, scenegraph_id)
	local size = mod:get("marker_size") or 40

	return UIWidget.create_definition({
		{
			pass_type = "texture",
			style_id  = "icon",
			value_id  = "icon",
			style     = {
				size            = { size, size },
				offset          = { 0, 0, 1 },
				color           = { 255, 255, 255, 255 },
				horizontal_alignment = "center",
				vertical_alignment   = "center",
			},
			visibility_function = function (content)
				return content.icon ~= nil
			end,
		},
		{
			pass_type = "text",
			style_id  = "label",
			value_id  = "label",
			style     = {
				font_size            = 16,
				font_type            = "proxima_nova_bold",
				text_horizontal_alignment = "center",
				text_vertical_alignment   = "top",
				offset               = { 0, size * 0.5, 2 },
				text_color           = { 255, 255, 255, 255 },
				default_text_color   = { 255, 255, 255, 255 },
				size                 = { 180, 24 },
			},
			visibility_function = function (content)
				return content.label ~= nil and content.label ~= ""
			end,
		},
	}, scenegraph_id)
end

--[[
    Colour and opacity are applied per frame from the marker's own data rather
    than baked into the definition, so changing a setting takes effect without
    rebuilding every widget.

    NOTE: this reads marker.data, NOT mod:get. Settings are read once on change
    and cached into the data table by the main script. mod:get on a per-frame
    path is what cost 59 -> 15 fps once already.
--]]
template.on_enter = function (widget, marker)
	local content = widget.content
	local data = marker.data or {}

	content.icon  = data.icon or DEFAULT_ICON
	content.label = data.label

	local style = widget.style
	local colour = data.color or { 200, 200, 200 }
	local alpha = data.alpha or 110

	if style.icon then
		style.icon.color[1] = alpha
		style.icon.color[2] = colour[1]
		style.icon.color[3] = colour[2]
		style.icon.color[4] = colour[3]
	end

	if style.label then
		-- Text stays more readable than the icon: the label carries the
		-- information, the icon is only a position.
		local text_alpha = math.min(255, alpha + 70)
		style.label.text_color[1] = text_alpha
		style.label.default_text_color[1] = text_alpha
	end
end

return template
