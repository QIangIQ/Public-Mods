local mod = get_mod("DiosMarkerTool")

--[[
    Dio's Marker Tool
    =================

    Hand-author trigger locations. Stand where a boss or room trigger is, press
    the drop key, and the position is recorded against that map and written to
    disk once the mission ends.

    WHY THIS EXISTS. Harvesting is passive and can never finish. HavocTracker's
    own harvested_cache.lua says so: "a run rolls 1-3 monsters out of 10-29
    candidates, so this is a sample that grows every time a map is replayed."
    Marking by hand closes that gap directly.

    OWNERSHIP RULE, and it is not negotiable: this mod writes exactly one file,
    its own. It never touches spawn_cache.lua, harvested_cache.lua or
    HavocTracker_user_cache.lua. Two writers on one file is precisely the
    asymmetry that silently destroyed BackstabHitboxDisplay and danger_zone
    settings - the write was durable and the undo was not. HavocTracker reads
    this file and merges it; the arrow only ever points that way.
--]]

--[[
    Engine access goes through the PORTED SlotZones resolver.

    See DiosMarkerTool_runtime.lua for why capturing engine globals at file
    scope is fatal - it was the "could not resolve position" bug. Loaded with
    io_dofile rather than require because require resolves against the game's
    script paths, not the mods directory.
--]]
local RT = nil

local function rt()
	if not RT then
		local ok, m = pcall(function()
			return mod:io_dofile("Dio's Marker Tool/scripts/mods/DiosMarkerTool/DiosMarkerTool_runtime")
		end)
		RT = (ok and type(m) == "table") and m or nil
	end
	return RT
end

local math_min = math.min
local math_sqrt = math.sqrt

-- ---------------------------------------------------------------------------
-- CATEGORIES
-- ---------------------------------------------------------------------------

--[[
    Seeded from the category names the existing caches already use, so output
    merges into HavocTracker without a translation layer. A table, not literals
    scattered through the file, because the cycle key indexes it.
--]]
local CATEGORIES = {
	{ id = "boss_trigger",     color = { 255, 90,  60  } },
	{ id = "room_trigger",     color = { 80,  200, 255 } },
	{ id = "pacing_captains",  color = { 255, 200, 60  } },
	{ id = "pacing_monsters",  color = { 255, 120, 200 } },
	{ id = "pacing_witches",   color = { 180, 120, 255 } },
	{ id = "ambush",           color = { 255, 255, 255 } },
	{ id = "daemonhost",       color = { 120, 255, 140 } },
}

local CATEGORY_BY_ID = {}
for i = 1, #CATEGORIES do
	CATEGORY_BY_ID[CATEGORIES[i].id] = CATEGORIES[i]
end

local active_index = 1

-- ---------------------------------------------------------------------------
-- STATE
-- ---------------------------------------------------------------------------

--[[
    All module state together at the top.

    This is a structural rule in this project, not a style preference. A local
    declared lower down than the function that seeds it turns the seeding write
    into a GLOBAL while readers see an always-nil local. That exact trap has
    bitten HavocTracker more than once.
--]]
local cache = nil            -- { schema = N, maps = { [mission] = { [cat] = {...} } } }
local cache_loaded = false
local cache_dirty = false

local session_order = {}     -- chronological list of { mission, cat, entry } for undo
local current_mission = nil
local current_mode = nil
local placed_this_session = 0

--[[
    Have this mission's existing markers been drawn yet?

    Needed because the mission cannot be identified at StateGameplay enter (see
    the mission identity note), so there is nothing to look markers up by at
    the moment we would naturally draw them.
--]]
local markers_shown = false

-- Key-repeat guards. See the long note in place_marker for why both exist.
local PLACE_COOLDOWN = 0.40
local PLACE_MIN_DIST_SQ = 1.5 * 1.5
local last_place_t = 0
local last_place_x, last_place_y, last_place_z = nil, nil, nil

-- Cycling had the same fault: the log shows it stepping through seven
-- categories in one burst, so a single tap could land anywhere.
local CYCLE_COOLDOWN = 0.25
local last_cycle_t = 0

-- Marker ids handed back by the world marker system, so they can be removed.
local live_markers = {}      -- entry -> marker id

-- Settings mirrored on change. NEVER read mod:get on a per-frame path: table
-- settings are cloned on every read (settings.lua:82-87) and that cost 59 -> 15
-- fps once already.
local cfg = {
	marker_size    = 40,
	marker_opacity = 110,
	show_markers   = true,
	show_hud       = true,
	snap_radius    = 5.0,
	record_distance = true,
}

local function refresh_cfg()
	cfg.marker_size     = mod:get("marker_size") or 40
	cfg.marker_opacity  = mod:get("marker_opacity") or 110
	cfg.show_markers    = mod:get("show_markers") ~= false
	cfg.show_hud        = mod:get("show_hud") ~= false
	cfg.snap_radius     = mod:get("delete_radius") or 5.0
	cfg.record_distance = mod:get("record_distance") ~= false
end

-- ---------------------------------------------------------------------------
-- SANDBOXED io / os
-- ---------------------------------------------------------------------------

--[[
    USE THESE, NEVER THE GLOBALS.

    The game does not expose a usable global `os` or `io` to mods; DMF surfaces
    them as Mods.lua.os and Mods.lua.io. Every file feature in HavocTracker
    written against the plain globals silently did nothing - os.getenv returned
    nil, the path came back nil, and the write no-oped inside its pcall. The
    user cache "never appeared despite hosted runs reporting successful
    recordings". Nothing errored. That is the failure mode to avoid.
--]]
local function sandbox_io()
	return Mods and Mods.lua and Mods.lua.io or nil
end

local function sandbox_os()
	return Mods and Mods.lua and Mods.lua.os or nil
end

--[[
	Compile a string of Lua. Returns chunk, or nil + reason. NEVER throws.

	loadstring is NOT a global in the mod sandbox - DMF keeps its own copy for
	that reason (modules/core/io.lua:12). So the old
	"loadstring and loadstring(text) or load(text)" short-circuited past the nil
	loadstring and called load, which is not a global either: a call on a nil
	value, thrown inside the pcall. This cost a day on HavocTracker, where the
	identical line made the user cache unreadable in-game while loading fine
	everywhere else.

	Probe each candidate and never call one that isn't there.
--]]
local function sandbox_load(text, chunk_name)
	if type(text) ~= "string" then
		return nil, "not a string"
	end

	local lua = Mods and Mods.lua or nil
	local candidates = {
		{ fn = lua and lua.loadstring,   label = "Mods.lua.loadstring" },
		{ fn = lua and lua.load,         label = "Mods.lua.load" },
		{ fn = rawget(_G, "loadstring"), label = "_G.loadstring" },
		{ fn = rawget(_G, "load"),       label = "_G.load" },
	}

	local last = "no loader available"
	for _, c in ipairs(candidates) do
		if type(c.fn) == "function" then
			local ok, chunk, err = pcall(c.fn, text, chunk_name)
			if ok and chunk then
				return chunk
			end
			last = string.format("%s: %s", c.label,
				tostring((not ok and chunk) or err or "returned nil"))
		end
	end

	return nil, last
end

--[[
    Wall clock via the SANDBOXED os.

    `os` is not a global in the mod environment, so os.time() is a nil-index
    error, not a zero. Same trap as os.getenv above.
--]]
local function now_seconds()
	local os_ = sandbox_os()
	if not os_ or not os_.time then
		return 0
	end
	local ok, t = pcall(os_.time)
	return (ok and type(t) == "number") and t or 0
end

local function cache_path()
	local os_ = sandbox_os()
	if not os_ or not os_.getenv then
		return nil
	end

	local ok, base = pcall(os_.getenv, "APPDATA")
	if not ok or not base then
		return nil
	end

	return base .. "/Fatshark/Darktide/DiosMarkerTool_cache.lua"
end

-- ---------------------------------------------------------------------------
-- NAVMESH SNAP
-- ---------------------------------------------------------------------------

local NAV_ABOVE, NAV_BELOW = 2.0, 2.0
local NavQueries = nil

local function resolve_nav_queries()
	if NavQueries then
		return NavQueries
	end

	local ok, t = pcall(require, "scripts/utilities/nav_queries")
	if ok and type(t) == "table" then
		NavQueries = t
	end

	return NavQueries
end

local function snap_to_mesh(nav_world, traverse_logic, position)
	if not nav_world or not position or not NavQueries then
		return nil
	end

	if NavQueries.position_on_mesh_with_outside_position then
		local ok, p = pcall(NavQueries.position_on_mesh_with_outside_position,
			nav_world, traverse_logic, position, NAV_ABOVE, NAV_BELOW, 1, 1)
		if ok and p then
			return p
		end
	end

	if NavQueries.position_on_mesh then
		local ok, p = pcall(NavQueries.position_on_mesh,
			nav_world, position, NAV_ABOVE, NAV_BELOW, traverse_logic)
		if ok and p then
			return p
		end
	end

	return nil
end

--[[
    SNAP BEFORE ANY PATH QUERY. THIS IS THE ONE THAT WASTED THE MOST TIME.

    A player's origin is a point in the AIR above the floor. The main path is
    defined on the navmesh. Query the path with an off-mesh position and it
    throws or returns nil - every time, on every getter. That is the "all three
    failed" pattern HavocTracker's diag log kept showing while the API choice
    was being blamed.

    It is also why hand-placed markers would otherwise float in the ceiling,
    which was a repeated complaint about the harvested ones.

    Four steps, cheapest first. Step 1 costs nothing: the navigation extension
    already caches the last valid mesh position for every unit, so a player
    standing on the floor never touches the query API at all.
--]]
local function position_on_mesh(unit, position)
	resolve_nav_queries()

	-- 1. The unit's own cached navmesh position.
	local R = rt()
	local nav_ext = R and R.extension(unit, "navigation_system")

	if unit and nav_ext then
		if nav_ext.latest_position_on_nav_mesh then
			local ok2, p = pcall(nav_ext.latest_position_on_nav_mesh, nav_ext)
			if ok2 and p then
				return p
			end
		end

		-- 2. Snap through the unit's own nav world and traverse logic.
		local ok3, p = pcall(function()
			local nw = nav_ext.nav_world and nav_ext:nav_world()
			local tl = nav_ext.traverse_logic and nav_ext:traverse_logic()
			return snap_to_mesh(nw, tl, position)
		end)
		if ok3 and p then
			return p
		end
	end

	-- 3. Snap through the manager. client_traverse_logic is the CLIENT-SAFE
	--    variant; a client has no server traverse logic and asking throws.
	local nav_mesh = Managers.state and Managers.state.nav_mesh

	if nav_mesh then
		local ok, p = pcall(function()
			local nw = nav_mesh:nav_world()
			local tl = nav_mesh.client_traverse_logic
				and nav_mesh:client_traverse_logic() or nil
			return snap_to_mesh(nw, tl, position)
		end)
		if ok and p then
			return p
		end
	end

	-- 4. Raw position. Usually fails downstream, but costs nothing to try.
	return position
end

-- ---------------------------------------------------------------------------
-- MAIN PATH TRAVEL DISTANCE
-- ---------------------------------------------------------------------------

local MainPathQueries = nil
local mpq_tried = false

local function resolve_mpq()
	if mpq_tried then
		return MainPathQueries
	end
	mpq_tried = true

	local ok, m = pcall(require, "scripts/utilities/main_path_queries")
	if ok and type(m) == "table" then
		MainPathQueries = m
	end

	return MainPathQueries
end

--[[
    True once the engine has a main path registered for this level.

    Checked before every query because calling into the engine with no
    registered path is a SEGFAULT, not a catchable error.
--]]
local function main_path_ready()
	local m = resolve_mpq()
	if not m or not m.is_main_path_registered then
		return false
	end

	local ok, ready = pcall(m.is_main_path_registered)
	return ok and ready and true or false
end

--[[
    CALL EngineOptimized DIRECTLY. Do not use MainPathQueries.closest_position.

    Two separate reasons, both learned the hard way:

    1. Managers.state.main_path:travel_distance_from_position THROWS ON
       CLIENTS. It delegates to PathTypeLinear._information_from_position
       (path_type_linear.lua:105-118), whose first act is a spawn-point group
       lookup against _nav_spawn_points - and that is only ever populated by
       generate_spawn_points(), which begins `if not self._is_server then
       return end` (main_path_manager.lua:276-279). On a client it is nil, the
       lookup fails, the call throws, and a pcall around it returns nil
       forever. This was silently broken for the entire life of HavocTracker.

    2. MainPathQueries.closest_position, the obvious client-safe wrapper, ends
       with `main_path_node_index = main_path_node_index + 1` executed
       UNCONDITIONALLY. The engine returns nil for that index whenever a
       position does not resolve to one, so the wrapper itself throws. The API
       was fine; the route into it was not.

    EngineOptimized.closest_pos_at_main_path returns:
        closest_position, travel_distance, travel_percentage,
        node_index, segment_index

    We want the second value.
--]]
local function travel_distance(position)
	if not position or not main_path_ready() then
		return nil
	end

	local EO = rawget(_G, "EngineOptimized")

	if EO and EO.closest_pos_at_main_path then
		local ok, _, dist = pcall(EO.closest_pos_at_main_path, position)
		if ok and type(dist) == "number" then
			return dist
		end
	end

	return nil
end

--[[
    Is the main path a single linear route?

    A crossroads-branching main path has NO single scalar travel distance, so
    the query is meaningless there and must not be trusted. Refusing to place a
    marker and saying why is far better than recording a number that means
    nothing and discovering it months later.
--]]
local path_linear = nil

local function path_is_linear()
	if path_linear ~= nil then
		return path_linear
	end

	local main_path = Managers.state and Managers.state.main_path
	if not main_path then
		return true
	end

	local ok, result = pcall(function()
		if main_path.is_linear_path then
			return main_path:is_linear_path()
		end
		return true
	end)

	path_linear = (ok and result ~= false) and true or false
	return path_linear
end

-- ---------------------------------------------------------------------------
-- CACHE LOAD / SAVE
-- ---------------------------------------------------------------------------

local SCHEMA = 2

--[[
    schema = 2 from day one.

    Position-only was the chosen record, with travel distance optional. Setting
    a version now means a later migration that backfills the distance is
    DETECTABLE rather than guessed at from the shape of the data.
--]]

local function empty_cache()
	return { schema = SCHEMA, maps = {} }
end

--[[
    io.open + load, NOT mod:io_dofile.

    io_dofile resolves relative to the mods directory and cannot reach an
    absolute AppData path, so the file has to be read and compiled by hand.

    Validation is deliberately paranoid: this file is hand-editable, so a
    malformed entry must be dropped rather than allowed to error. A broken
    manual cache must never take the mod down with it.
--]]
local function load_cache()
	if cache_loaded then
		return cache
	end
	cache_loaded = true
	cache = empty_cache()

	local path = cache_path()
	if not path then
		mod:echo("[MarkerTool] cannot resolve AppData path - markers will not persist")
		return cache
	end

	--[[
        Repair before reading. Covers the one gap the write dance cannot: the
        process dying between "old file renamed to .bak" and "new file renamed
        into place", which leaves no main file at all.
    --]]
	pcall(recover_backup, path)

	local ok, result = pcall(function()
		local io_ = sandbox_io()
		if not io_ or not io_.open then
			return nil
		end

		local f = io_.open(path, "r")
		if not f then
			return nil
		end

		local text = f:read("*a")
		f:close()

		if not text or text == "" then
			return nil
		end

		--[[
			The cache is a pure data literal with no calls in it, so no sandbox
			env is needed - only a compiler that actually exists. See
			sandbox_load above for why the obvious one-liner threw.
		--]]
		local chunk, load_err = sandbox_load(text, "@DiosMarkerTool_cache")
		if not chunk then
			mod:warning("[DiosMarkerTool] could not compile the cache: %s",
				tostring(load_err))
			return nil
		end

		local ok_run, data = pcall(chunk)
		return ok_run and data or nil
	end)

	if not ok or type(result) ~= "table" or type(result.maps) ~= "table" then
		return cache
	end

	-- Copy across only what validates.
	local kept, dropped = 0, 0

	for mission, cats in pairs(result.maps) do
		if type(mission) == "string" and type(cats) == "table" then
			local out_cats = {}

			for cat, list in pairs(cats) do
				if type(cat) == "string" and type(list) == "table" then
					local out_list = {}

					for i = 1, #list do
						local e = list[i]
						local p = type(e) == "table" and e.p

						if type(p) == "table" and type(p[1]) == "number"
							and type(p[2]) == "number" and type(p[3]) == "number" then
							out_list[#out_list + 1] = {
								p = { p[1], p[2], p[3] },
								d = type(e.d) == "number" and e.d or nil,
								t = type(e.t) == "number" and e.t or nil,
							}
							kept = kept + 1
						else
							dropped = dropped + 1
						end
					end

					if #out_list > 0 then
						out_cats[cat] = out_list
					end
				end
			end

			if next(out_cats) then
				cache.maps[mission] = out_cats
			end
		end
	end

	if dropped > 0 then
		mod:echo(string.format("[MarkerTool] loaded %d markers, dropped %d malformed", kept, dropped))
	end

	return cache
end

local function serialize(out, cache_table)
	out[#out + 1] = "-- Dio's Marker Tool: hand-placed trigger locations.\n"
	out[#out + 1] = "-- HAND-AUTHORED. Not auto-generated - do not delete casually.\n"
	out[#out + 1] = "-- p = navmesh-snapped position, d = main path travel distance, t = unix time.\n"
	out[#out + 1] = string.format("return {\n  schema = %d,\n  maps = {\n", SCHEMA)

	-- Sorted so the file diffs cleanly between sessions rather than reordering
	-- randomly with pairs().
	local missions = {}
	for mission in pairs(cache_table.maps) do
		missions[#missions + 1] = mission
	end
	table.sort(missions)

	for m = 1, #missions do
		local mission = missions[m]
		local cats = cache_table.maps[mission]

		out[#out + 1] = string.format("    [%q] = {\n", mission)

		local names = {}
		for cat in pairs(cats) do
			names[#names + 1] = cat
		end
		table.sort(names)

		for c = 1, #names do
			local cat = names[c]
			local list = cats[cat]

			out[#out + 1] = string.format("      %s = {\n", cat)

			for i = 1, #list do
				local e = list[i]

				if e.d then
					out[#out + 1] = string.format(
						"        { p = { %.4f, %.4f, %.4f }, d = %.4f, t = %d },\n",
						e.p[1], e.p[2], e.p[3], e.d, e.t or 0)
				else
					out[#out + 1] = string.format(
						"        { p = { %.4f, %.4f, %.4f }, t = %d },\n",
						e.p[1], e.p[2], e.p[3], e.t or 0)
				end
			end

			out[#out + 1] = "      },\n"
		end

		out[#out + 1] = "    },\n"
	end

	out[#out + 1] = "  },\n}\n"
end

--[[
    ATOMIC WRITE WITH BACKUP AND ROLLBACK.

    PORTED FROM AnotherScoreboard (AnotherScoreboard_history.lua:685-722,
    write_serialized). My previous version was:

        os.remove(path)          -- Windows rename will not overwrite
        os.rename(tmp, path)

    which has a window between the remove and the rename where the old file is
    already gone and the new one is not in place yet. A crash or a kill there
    loses every hand-placed marker ever recorded - and unlike a harvested
    cache, that data cannot be regenerated by replaying a map.

    AnotherScoreboard does a three-file dance that never leaves the data with
    nowhere to live:

        1. write  path.tmp
        2. verify BOTH the write and the close returned non-nil
        3. recover any .bak left by a previously interrupted write
        4. rename path -> path.bak      (previous good copy preserved)
        5. rename path.tmp -> path
        6. on failure at 5, rename path.bak -> path   (rollback)
        7. remove path.bak

    At every instant, at least one of path / path.bak / path.tmp holds a
    complete file. recover_backup() on load then repairs the one case this
    cannot cover - the process dying between steps 4 and 5.

    Two of their details are worth not "simplifying":

      * file:close() is checked for a NON-NIL return, not truthiness. A
        buffered write can fail at close time, and ignoring that is how a
        truncated file gets promoted over a good one.

      * directory_exists uses os.rename(path, path) - rename-to-self succeeds
        only if the path exists, and code 13 (permission denied) also proves
        existence. Cheaper and more reliable than trying to open a directory.
--]]
local function file_exists(path)
	local io_ = sandbox_io()
	if not io_ or not io_.open then
		return false
	end

	local f = io_.open(path, "r")
	if f then
		f:close()
		return true
	end

	return false
end

local function recover_backup(path)
	local os_ = sandbox_os()
	local backup = path .. ".bak"

	if not file_exists(path) and file_exists(backup) then
		if os_ and os_.rename then
			return pcall(os_.rename, backup, path)
		end
		return false
	end

	return file_exists(path)
end

local function directory_exists(path)
	local os_ = sandbox_os()
	if not os_ or not os_.rename then
		return false
	end

	local ok, _, code = pcall(function()
		return os_.rename(path, path)
	end)

	-- code 13 is permission denied, which still proves the path is there.
	return (ok or code == 13) and true or false
end

--[[
    Ensure the containing directory exists.

    The marker cache sits directly in the Darktide AppData folder, which always
    exists - so this is defensive rather than load-bearing today. It is ported
    anyway because it is the piece that would be missing the moment this writes
    into a subfolder, and discovering that through a silent write failure is
    exactly the failure mode this mod has already hit once.
--]]
local function ensure_directory(dir)
	local os_ = sandbox_os()

	if not dir or directory_exists(dir) then
		return true
	end

	if os_ and os_.execute then
		pcall(os_.execute, 'mkdir "' .. dir .. '"')
		return directory_exists(dir)
	end

	return false
end

local function write_cache()
	local path = cache_path()
	if not path or not cache then
		return false
	end

	local io_ = sandbox_io()
	local os_ = sandbox_os()

	if not io_ or not io_.open or not os_ then
		return false
	end

	local dir = string.match(path, "^(.*)/[^/]+$")
	ensure_directory(dir)

	local tmp = path .. ".tmp"
	local backup = path .. ".bak"

	-- 1 + 2. Write and verify. "w+" matches the original.
	local ok = pcall(function()
		local f = io_.open(tmp, "w+")
		if not f then
			error("cannot open temp file")
		end

		local out = {}
		serialize(out, cache)

		local wrote = f:write(table.concat(out))
		local closed = f:close()

		-- close() returning nil means the buffered write failed. Ignoring it
		-- is how a truncated file gets promoted over a good one.
		if not wrote or closed == nil then
			error("write or close failed")
		end
	end)

	if not ok then
		pcall(function() if os_.remove then os_.remove(tmp) end end)
		return false
	end

	-- 3. Repair a backup left by a previously interrupted write.
	recover_backup(path)
	pcall(function() if os_.remove then os_.remove(backup) end end)

	-- 4. Preserve the current good copy.
	local had_original = file_exists(path)

	if had_original then
		local moved = pcall(function() return os_.rename(path, backup) end)
		if not moved then
			pcall(function() if os_.remove then os_.remove(tmp) end end)
			return false
		end
	end

	-- 5. Promote the new file.
	local promoted = pcall(function() return os_.rename(tmp, path) end)

	if not promoted then
		-- 6. Roll back.
		if had_original then
			pcall(function() os_.rename(backup, path) end)
		end
		pcall(function() if os_.remove then os_.remove(tmp) end end)
		return false
	end

	-- 7.
	if had_original then
		pcall(function() if os_.remove then os_.remove(backup) end end)
	end

	return true
end

--[[
    Flush point.

    NEVER write mid-mission. HavocTracker's equivalent "stalled repeatedly at
    the worst possible moment", and writing immediately caused crashes on
    /restart and on death-autorestart. Placement mutates the in-memory table
    and sets cache_dirty; the file is written once, here, when the mission
    ends - at which point a stall costs nothing because you are already on a
    loading screen.
--]]
local function flush_cache()
	if not cache_dirty then
		return
	end

	if write_cache() then
		cache_dirty = false
		mod:echo(string.format("[MarkerTool] saved %d marker(s)", placed_this_session))
	else
		-- Deliberately loud. Silent write failure is the exact bug that lost
		-- every hosted recording in HavocTracker for weeks.
		mod:echo("[MarkerTool] SAVE FAILED - markers from this run were not written")
	end
end

-- ---------------------------------------------------------------------------
-- MISSION IDENTITY
-- ---------------------------------------------------------------------------

--[[
    Keyed PER MAP, not per seed.

    Trigger candidate locations are static map geometry; the seed only selects
    which of them actually fire. So a marker placed on cm_archives is valid for
    every future run of cm_archives, which is the entire reason this is worth
    doing once by hand.
--]]
--[[
    MISSION IDENTITY - two paths, resolved LAZILY.

    THE BUG THIS REPLACES: "not currently in a mission" in solo play.

    Three separate defects, all mine:

    1. Managers.state.mission DOES NOT RESOLVE during loading or immediately
       after a state change. HavocTracker documents this exactly - it is why
       going Psykhanium -> solo play "took two or three attempts to bind". I
       read it once on StateGameplay enter, got nil, and cached that nil for
       the whole mission.

    2. There was no retry. The previous comment here claimed one existed and
       then did not implement it, which is worse than not having it - it read
       as handled.

    3. The hub was detected with string.find(mission, "hub"). That is the wrong
       test. The hub, Psykhanium and the prologue are all REAL mission
       templates with real names, so gating on the name means guessing from a
       substring. Gate on GAME MODE, which is what actually distinguishes them.

    The fix is Managers.mechanism as a fallback - it still knows the
    destination while Managers.state.mission is coming up - plus resolving on
    demand rather than once. Managers.state is rebuilt wholesale on every state
    transition, so nothing here may cache across a transition; the cache is
    cleared on enter and refilled by the first successful read.
--]]

--[[
    Game modes that are NOT missions.

    Anything unlisted counts as a mission, so a new mission type defaults to
    working rather than defaulting to refusing to place markers.
--]]
local NON_COMBAT = {
	hub = true,
	prologue = true,
	prologue_hub = true,
	shooting_range = true,
	training_grounds = true,
}

local function safe_call(fn, ...)
	if type(fn) ~= "function" then
		return nil
	end
	local ok, result = pcall(fn, ...)
	return ok and result or nil
end

--[[
    MechanismManager.mechanism_data() is `return self._mechanism:mechanism_data()`
    with no guard, so it throws outright between states. Always reached through
    this.
--]]
local function mechanism_data()
	local manager = Managers and Managers.mechanism
	if not manager or not manager._mechanism then
		return {}
	end

	local ok, data = pcall(manager.mechanism_data, manager)
	return (ok and type(data) == "table") and data or {}
end

--- Returns mission key and game mode name, or nil.
local function resolve_mission()
	local mm = Managers and Managers.state and Managers.state.mission

	if mm then
		local key = safe_call(mm.mission_name, mm)
		local template = safe_call(mm.mission, mm)

		if key and template then
			return key, template.game_mode_name
		end
	end

	-- Loading screen or state transition: the mechanism knows the destination
	-- even while the mission manager is still coming up.
	local data = mechanism_data()

	if data.mission_name then
		local Missions = safe_call(require, "scripts/settings/mission/mission_templates")
		local template = Missions and Missions[data.mission_name]
		return data.mission_name, template and template.game_mode_name
	end

	return nil, nil
end

--[[
    Resolve on demand, cache only a SUCCESS.

    current_mission starts nil each mission and is filled by the first call
    that manages to read it - so a placement made after the managers are up
    works even though enter could not resolve anything.
--]]
local function mission_id()
	if current_mission then
		return current_mission
	end

	local key, mode = resolve_mission()

	if key and not NON_COMBAT[mode or ""] then
		current_mission = key
		current_mode = mode
	end

	return current_mission
end

--[[
    Is this a real mission?

    Calls mission_id() rather than reading current_mission, so it retries
    instead of trusting a nil from enter. This is what "not currently in a
    mission" in solo play actually came down to.
--]]
local function in_real_mission()
	return mission_id() ~= nil
end

-- ---------------------------------------------------------------------------
-- PLAYER POSITION
-- ---------------------------------------------------------------------------

--[[
    Player position, snapped to the navmesh.

    Both halves are the ported SlotZones code: get_local_player_unit reads
    player_unit as a FIELD (calling it as a method was half the position bug),
    and get_unit_position runs the four-step cascade with per-step validation.

    Returns three plain NUMBERS, never a Vector3. Vector3 is frame-temporary -
    holding one across frames produced "thousands of Vector3 expected, got
    userdata" errors - and a serialised Vector3Box is not portable, so the
    cache stores numbers.
--]]
local function snapped_player_xyz()
	local R = rt()
	if not R then
		return nil, "runtime module not loaded"
	end

	local unit = R.get_local_player_unit()
	if not unit then
		return nil, "no player unit"
	end

	-- The locomotion extension carries a boxed position, which is step 1 of
	-- the cascade and the cheapest valid answer available.
	local loco = R.extension(unit, "locomotion_system")
	local raw = R.get_unit_position(unit, loco)

	if not raw then
		return nil, "no position"
	end

	local snapped = position_on_mesh(unit, raw) or raw
	local refs = R.resolve()

	if not refs.Vector3 then
		return nil, "Vector3 unavailable"
	end

	local ok, x = pcall(refs.Vector3.x, snapped)
	local ok2, y = pcall(refs.Vector3.y, snapped)
	local ok3, z = pcall(refs.Vector3.z, snapped)

	if not (ok and ok2 and ok3) or not R.valid_number(x) then
		return nil, "position not readable"
	end

	-- The snapped VECTOR is the fourth value; see the note in place_marker.
	return x, y, z, snapped
end

-- ---------------------------------------------------------------------------
-- MARKER RENDERING
-- ---------------------------------------------------------------------------

local MARKER_NAME = "DiosMarkerTool_manual_marker"

local function add_marker(entry, category)
	if not cfg.show_markers or not Managers.event then
		return
	end

	local cat = CATEGORY_BY_ID[category]

	local data = {
		icon  = nil,  -- template default
		label = category,
		color = cat and cat.color or { 200, 200, 200 },
		alpha = cfg.marker_opacity,
	}

	local R = rt()
	local refs = R and R.resolve()

	if not refs or not refs.Vector3 then
		return
	end

	local ok, position = pcall(refs.Vector3, entry.p[1], entry.p[2], entry.p[3])
	if not ok or not position then
		return
	end

	pcall(function()
		Managers.event:trigger("add_world_marker_position",
			MARKER_NAME, position, function (id)
				live_markers[entry] = id
			end, data)
	end)
end

local function remove_marker(entry)
	local id = live_markers[entry]
	if not id or not Managers.event then
		live_markers[entry] = nil
		return
	end

	pcall(function()
		Managers.event:trigger("remove_world_marker", id)
	end)

	live_markers[entry] = nil
end

local function show_all_markers()
	if not cache or not current_mission then
		return
	end

	local cats = cache.maps[current_mission]
	if not cats then
		return
	end

	for category, list in pairs(cats) do
		for i = 1, #list do
			if not live_markers[list[i]] then
				add_marker(list[i], category)
			end
		end
	end
end

local function hide_all_markers()
	for entry in pairs(live_markers) do
		remove_marker(entry)
	end
end

-- ---------------------------------------------------------------------------
-- ACTIONS
-- ---------------------------------------------------------------------------

local function entry_list(mission, category)
	load_cache()

	cache.maps[mission] = cache.maps[mission] or {}
	cache.maps[mission][category] = cache.maps[mission][category] or {}

	return cache.maps[mission][category]
end

local function active_category()
	return CATEGORIES[active_index].id
end

function mod.place_marker()
	if not in_real_mission() then
		mod:echo("[MarkerTool] not in a mission")
		return
	end

	--[[
	    KEY-REPEAT COOLDOWN, checked first: cheapest test, needs no position.

	    The last run recorded 13 markers from about three intended presses -
	    six boss triggers inside one second, each roughly half a metre apart
	    along the direction of travel. The keybind fires repeatedly while held,
	    so walking with it down laid a trail. That made the output actively
	    WRONG rather than merely noisy: seven markers where one trigger exists
	    tells a consumer there are seven triggers.
	--]]
	local t_now = now_seconds()

	if t_now - last_place_t < PLACE_COOLDOWN then
		return
	end

	local x, y, z, snapped = snapped_player_xyz()

	if not x then
		-- y carries the reason when x is nil. Naming the step that failed
		-- turns a dead end into something diagnosable.
		mod:echo(string.format("[MarkerTool] could not resolve your position (%s)", tostring(y)))
		return
	end

	--[[
	    DISTANCE GATE, the second half of the guard.

	    A cooldown alone stops a held key but not a double-tap in one spot; a
	    distance gate alone stops duplicates in one spot but not a held key
	    while sprinting - at 6 m/s a 1.5 m gate still permits four per second.
	    Both together mean a marker needs a fresh press AND real movement.

	    Measured from the last PLACED position, not the last attempt, so a
	    blocked attempt does not drag the reference point along.
	--]]
	if last_place_x then
		local dx, dy, dz = x - last_place_x, y - last_place_y, z - last_place_z

		if dx * dx + dy * dy + dz * dz < PLACE_MIN_DIST_SQ then
			return
		end
	end

	last_place_t = t_now
	last_place_x, last_place_y, last_place_z = x, y, z

	local category = active_category()
	local list = entry_list(current_mission, category)

	local entry = {
		p = { x, y, z },
		t = now_seconds(),
	}

	--[[
	    TRAVEL DISTANCE, with a diagnostic when it fails.

	    Every marker in the last run saved with no `d`, and the echo read
	    "placed" rather than "placed at N.Nm" - silently, with nothing in the
	    log naming the step that gave up. Two guesses at the cause were both
	    wrong, so this reports the reason instead of swallowing it.

	    Queried from the snapped vector directly. The previous version
	    decomposed the position to x,y,z and then rebuilt a Vector3 here purely
	    to make this call - a pointless round-trip and one more candidate cause.

	    A branching main path has no single scalar travel distance, so that is
	    reported rather than recorded as a number that looks fine and predicts
	    nothing.
	--]]
	if cfg.record_distance then
		if not path_is_linear() then
			mod:echo("[MarkerTool] no distance: main path is not linear here")
		elseif not snapped then
			mod:echo("[MarkerTool] no distance: position vector unavailable")
		else
			entry.d = travel_distance(snapped)

			if not entry.d then
				local EO = rawget(_G, "EngineOptimized")

				mod:echo(string.format(
					"[MarkerTool] no distance (registered=%s EO=%s fn=%s)",
					tostring(main_path_ready()),
					tostring(EO ~= nil),
					tostring(EO and EO.closest_pos_at_main_path ~= nil)))
			end
		end
	end

	list[#list + 1] = entry
	session_order[#session_order + 1] = {
		mission = current_mission, category = category, entry = entry,
	}

	cache_dirty = true
	placed_this_session = placed_this_session + 1

	add_marker(entry, category)

	if entry.d then
		mod:echo(string.format("[MarkerTool] %s placed at %.1fm  (%d on this map)",
			category, entry.d, #list))
	else
		mod:echo(string.format("[MarkerTool] %s placed  (%d on this map)",
			category, #list))
	end
end

function mod.cycle_category()
	local t_now = now_seconds()

	if t_now - last_cycle_t < CYCLE_COOLDOWN then
		return
	end
	last_cycle_t = t_now

	active_index = active_index + 1
	if active_index > #CATEGORIES then
		active_index = 1
	end

	mod:echo(string.format("[MarkerTool] active category: %s", active_category()))
end

--[[
    Undo is session-scoped on purpose.

    It walks back the placements made since the game started, not arbitrary
    historical entries. Undoing something recorded weeks ago is what
    delete-nearest is for, and it requires you to physically stand next to it -
    a deliberate safety property for hand-authored data that cannot be
    regenerated.
--]]
function mod.undo_last()
	local n = #session_order
	if n == 0 then
		mod:echo("[MarkerTool] nothing to undo this session")
		return
	end

	local last = session_order[n]
	session_order[n] = nil

	local list = cache and cache.maps[last.mission] and cache.maps[last.mission][last.category]

	if list then
		for i = #list, 1, -1 do
			if list[i] == last.entry then
				table.remove(list, i)
				break
			end
		end

		if #list == 0 then
			cache.maps[last.mission][last.category] = nil
		end
	end

	remove_marker(last.entry)
	cache_dirty = true
	placed_this_session = math_min(placed_this_session, #session_order)

	mod:echo(string.format("[MarkerTool] undone (%s)", last.category))
end

function mod.delete_nearest()
	if not in_real_mission() or not cache then
		mod:echo("[MarkerTool] not in a mission")
		return
	end

	local x, y, z = snapped_player_xyz()
	if not x then
		mod:echo(string.format("[MarkerTool] could not resolve your position (%s)", tostring(y)))
		return
	end

	local cats = cache.maps[current_mission]
	if not cats then
		mod:echo("[MarkerTool] no markers on this map")
		return
	end

	local best, best_cat, best_idx, best_d2 = nil, nil, nil, nil
	local limit = cfg.snap_radius * cfg.snap_radius

	for category, list in pairs(cats) do
		for i = 1, #list do
			local p = list[i].p
			local dx, dy, dz = p[1] - x, p[2] - y, p[3] - z
			local d2 = dx * dx + dy * dy + dz * dz

			if d2 <= limit and (not best_d2 or d2 < best_d2) then
				best, best_cat, best_idx, best_d2 = list[i], category, i, d2
			end
		end
	end

	if not best then
		mod:echo(string.format("[MarkerTool] no marker within %.1fm", cfg.snap_radius))
		return
	end

	table.remove(cats[best_cat], best_idx)
	if #cats[best_cat] == 0 then
		cats[best_cat] = nil
	end

	-- Drop it from the undo list too, or undo would try to remove it twice.
	for i = #session_order, 1, -1 do
		if session_order[i].entry == best then
			table.remove(session_order, i)
			break
		end
	end

	remove_marker(best)
	cache_dirty = true

	mod:echo(string.format("[MarkerTool] deleted %s at %.1fm", best_cat, math_sqrt(best_d2)))
end

function mod.report()
	load_cache()

	if not current_mission then
		mod:echo("[MarkerTool] not in a mission")
		return
	end

	local cats = cache.maps[current_mission]
	if not cats then
		mod:echo(string.format("[MarkerTool] %s: no markers", current_mission))
		return
	end

	mod:echo(string.format("[MarkerTool] %s:", current_mission))

	local names = {}
	for cat in pairs(cats) do
		names[#names + 1] = cat
	end
	table.sort(names)

	for i = 1, #names do
		mod:echo(string.format("  %s: %d", names[i], #cats[names[i]]))
	end
end

-- ---------------------------------------------------------------------------
-- LIFECYCLE
-- ---------------------------------------------------------------------------

--[[
    Register the marker template on the LIVE element.

    DMF has no marker template registry, and the game builds its own table in
    HudElementWorldMarkers.init by requiring each path in
    HudElementWorldMarkersSettings.marker_templates. A mod therefore has to
    inject into the live element's _marker_templates, which is what every other
    mod doing this does.

    Done as a post-hook on init so it survives the element being rebuilt, which
    happens on every mission load.
--]]
local template = nil

local function load_template()
	if template then
		return template
	end

	local ok, t = pcall(function()
		return mod:io_dofile("Dio's Marker Tool/scripts/mods/DiosMarkerTool/DiosMarkerTool_marker")
	end)

	if ok and type(t) == "table" and t.name then
		template = t
	end

	return template
end

--[[
    STRING target, not CLASS.HudElementWorldMarkers.

    DMF defers a hook named by string until the class exists, and logs
    "<class> is now available for previously-delayed hooks" when it does. A
    CLASS.x reference is resolved at load time instead, so if this mod loads
    before the class is registered it silently binds to nil.
--]]
mod:hook_safe("HudElementWorldMarkers", "init", function (self)
	local t = load_template()

	if t and self._marker_templates then
		self._marker_templates[t.name] = t
	end
end)

mod.on_all_mods_loaded = function ()
	refresh_cfg()
	load_cache()
	load_template()
end

mod.on_setting_changed = function (setting_id)
	refresh_cfg()

	--[[
        Rebuild the markers rather than trying to mutate the live ones.

        Size lives in the widget DEFINITION, which is built once per marker
        when the element first sees it, so a size change cannot be applied in
        place. Removing and re-adding is cheap here because this runs on a
        setting change, not per frame.
    --]]
	if setting_id == "show_markers" or setting_id == "marker_size"
		or setting_id == "marker_opacity" then
		hide_all_markers()

		if cfg.show_markers then
			show_all_markers()
		end
	end
end

--[[
    Mission enter and exit.

    DMF assigns these as plain fields, so there must be exactly ONE assignment
    of mod.on_game_state_changed in the mod - a second one silently replaces
    the first.
--]]
mod.on_game_state_changed = function (status, state_name)
	if state_name ~= "StateGameplay" then
		return
	end

	if status == "enter" then
		-- Reset per-mission state. path_linear is per level, so it must be
		-- re-probed rather than carried across.
		--[[
            Cleared, NOT resolved. Managers.state.mission is usually not up yet
            at this exact moment; mission_id() retries on first use and caches
            the success.
        --]]
		current_mission = nil
		current_mode = nil
		path_linear = nil
		session_order = {}
		placed_this_session = 0
		live_markers = {}

		--[[
            Mission name may not resolve yet.

            Managers.state.mission does not resolve during loading, so a single
            read on enter can come back nil. Retried on the first successful
            placement instead of being trusted here.
        --]]
		markers_shown = false
		last_place_t = 0
		last_place_x, last_place_y, last_place_z = nil, nil, nil

	elseif status == "exit" then
		--[[
            THE FLUSH POINT. Guarded, because leaving the Mourningstar exits
            StateGameplay exactly like finishing a mission.
        --]]
		if in_real_mission() then
			flush_cache()
		end

		hide_all_markers()
		markers_shown = false
		last_place_t = 0
		last_place_x, last_place_y, last_place_z = nil, nil, nil
		current_mission = nil
		current_mode = nil
		path_linear = nil
	end
end

--[[
    DEFERRED FIRST DRAW.

    The only per-frame code in this mod, and it switches itself off. Once the
    mission resolves and the markers are drawn, every later frame costs a
    single boolean test.

    Written this way rather than with a timer because the thing being waited on
    is a manager coming up, not a duration - and because a repeating timer that
    never stops is how per-frame cost quietly accumulates in a 93-mod load
    order.
--]]
mod.update = function ()
	if markers_shown or not cfg.show_markers then
		return
	end

	-- No mission yet: the managers are still coming up. Try again next frame.
	if not mission_id() then
		return
	end

	markers_shown = true
	pcall(show_all_markers)
end

-- ---------------------------------------------------------------------------
-- HUD LINE
-- ---------------------------------------------------------------------------

--[[
    One small line, and only when it is relevant.

    Deliberately tiny and dim. The repeated complaint about the harvested
    markers was that they were "way too big and bright and I can't see
    anything", and an authoring tool has even less claim on screen space than a
    tracker does. Nothing is drawn until you have actually used the mod this
    session.
--]]
mod.status_line = function ()
	if not cfg.show_hud or not current_mission then
		return nil
	end

	if placed_this_session == 0 and #session_order == 0 then
		return nil
	end

	local cats = cache and cache.maps[current_mission]
	local total = 0

	if cats then
		for _, list in pairs(cats) do
			total = total + #list
		end
	end

	return string.format("[%s]  %d on map  %d this run",
		active_category(), total, placed_this_session)
end

-- ---------------------------------------------------------------------------
-- KEYBIND TARGETS
-- ---------------------------------------------------------------------------

--[[
    Named functions referenced by keybind widgets in the data file.

    No default keys are bound. With 93 mods loaded, claiming a key by default
    is an invitation to a silent conflict - the user picks them in mod options.
--]]
mod.kb_place  = function () pcall(mod.place_marker) end
mod.kb_cycle  = function () pcall(mod.cycle_category) end
mod.kb_undo   = function () pcall(mod.undo_last) end
mod.kb_delete = function () pcall(mod.delete_nearest) end

mod:command("mtmarkers", "List hand-placed markers on this map", function ()
	pcall(mod.report)
end)

mod:command("mtsave", "Force-write the marker cache now", function ()
	if not cache_dirty then
		mod:echo("[MarkerTool] nothing to save")
		return
	end
	--[[
        Manual escape hatch. The normal path writes on mission exit, but if a
        session is about to be killed - or a write failed once - being able to
        force it beats losing hand-placed data that cannot be regenerated.
    --]]
	flush_cache()
end)
