return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`Dio's Marker Tool` encountered an error loading the Darktide Mod Framework.")

		new_mod("DiosMarkerTool", {
			mod_script       = "Dio's Marker Tool/scripts/mods/DiosMarkerTool/DiosMarkerTool",
			mod_data         = "Dio's Marker Tool/scripts/mods/DiosMarkerTool/DiosMarkerTool_data",
			mod_localization = "Dio's Marker Tool/scripts/mods/DiosMarkerTool/DiosMarkerTool_localization",
		})
	end,
	version = "2.12.24",
	packages = {},
}
