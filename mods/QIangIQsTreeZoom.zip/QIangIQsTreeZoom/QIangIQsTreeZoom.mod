return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsTreeZoom` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsTreeZoom", {
			mod_script       = "QIangIQsTreeZoom/scripts/mods/QIangIQsTreeZoom/QIangIQsTreeZoom",
			mod_data         = "QIangIQsTreeZoom/scripts/mods/QIangIQsTreeZoom/QIangIQsTreeZoom_data",
			mod_localization = "QIangIQsTreeZoom/scripts/mods/QIangIQsTreeZoom/QIangIQsTreeZoom_localization",
		})
	end,
	packages = {},
}
