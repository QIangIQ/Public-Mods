local mod = get_mod("QIangIQsTreeZoom")

local function _numeric(setting_id, default_value, min, max)
	return {
		setting_id = setting_id,
		type = "numeric",
		default_value = default_value,
		range = { min, max },
		tooltip = setting_id .. "_description",
	}
end

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			{
				setting_id = "ctrl_scrolls",
				type = "checkbox",
				default_value = true,
				tooltip = "ctrl_scrolls_description",
			},
			_numeric("zoom_min", 40, 25, 100),
			_numeric("zoom_max", 200, 100, 300),
			_numeric("zoom_speed", 100, 25, 300),
		},
	},
}
