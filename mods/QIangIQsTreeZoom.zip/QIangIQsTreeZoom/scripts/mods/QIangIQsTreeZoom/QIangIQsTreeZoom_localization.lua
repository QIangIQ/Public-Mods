return {
	mod_name = {
		en = "Talent Tree Zoom",
	},
	mod_description = {
		en = "The mouse wheel zooms every talent tree in and out (around the cursor) instead of scrolling it up and down. Drag the background to move around, also sideways. Hold Ctrl to scroll up and down as before. Standalone, client side only.",
	},
	ctrl_scrolls = {
		en = "Ctrl + wheel scrolls",
	},
	ctrl_scrolls_description = {
		en = "While Ctrl is held, the wheel scrolls the tree up and down like the game does.",
	},
	zoom_min = {
		en = "Furthest zoom out (percent)",
	},
	zoom_min_description = {
		en = "How small the tree can get. 100 is the game's size.",
	},
	zoom_max = {
		en = "Closest zoom in (percent)",
	},
	zoom_max_description = {
		en = "How large the tree can get. 100 is the game's size.",
	},
	zoom_speed = {
		en = "Zoom speed (percent)",
	},
	zoom_speed_description = {
		en = "How much one wheel notch zooms. 100 is about 10%% per notch.",
	},
}
