local mod = get_mod("QIangIQsTreeZoom")

-- Mouse wheel zoom for the talent trees. In the talent view (player mode)
-- talent_builder_view.lua _on_input_scroll_axis_changed turns the wheel into
-- an up/down scroll, and node_builder_view_base.lua only lets the
-- background be dragged up and down. The base view already zooms around
-- the cursor outside player mode (_on_input_scroll_axis_changed, _set_zoom
-- clamped to 0.25 .. layout.base_zoom); this mod does the same in player
-- mode with its own limits, and lets a drag move the tree sideways too.
-- Applies to every class tree. Gamepad scrolling is left alone.

local VIEW_PATHS = {
	"scripts/ui/views/node_builder_view_base/node_builder_view_base",
	"scripts/ui/views/talent_builder_view/talent_builder_view",
}

local function _ctrl_held()
	if not mod:get("ctrl_scrolls") then
		return false
	end

	local ok, held = pcall(function ()
		return Keyboard.button(Keyboard.button_index("left ctrl")) > 0.5 or Keyboard.button(Keyboard.button_index("right ctrl")) > 0.5
	end)

	return ok and held
end

local function _limits()
	local low = (mod:get("zoom_min") or 40) / 100
	local high = (mod:get("zoom_max") or 200) / 100

	return math.min(low, 1), math.max(high, 1)
end

-- How far the tree may move sideways from where it opened, in layout units.
local function _pan_range(view)
	local ok, width = pcall(view._background_size, view)
	local screen_width = RESOLUTION_LOOKUP.width / math.max(view._nodes_render_scale or 1, 0.01)

	return math.max((ok and width or 2000) * 0.5, screen_width * 0.5)
end

local function _clamp_x(view, settings)
	local base_x = view._qiangiq_zoom_base_x

	if base_x then
		local range = _pan_range(view)

		settings.x = math.clamp(settings.x, base_x - range, base_x + range)
	end
end

local function _background_settings(view)
	local widget = view._widgets_by_name and view._widgets_by_name.layout_background

	if not widget then
		return
	end

	local scenegraph_id = widget.scenegraph_id
	local x, y = view:_scenegraph_position(scenegraph_id)
	local settings = view:_get_or_create_scenegraph_settings(scenegraph_id, x, y, false)

	view._qiangiq_zoom_base_x = view._qiangiq_zoom_base_x or settings.x

	return settings
end

-- Same maths as NodeBuilderViewBase._on_input_scroll_axis_changed: keep the
-- point under the cursor where it is.
local function _zoom(view, scroll_value, cursor_position)
	local current_zoom = view._current_zoom or 1
	local low, high = _limits()
	local speed = (mod:get("zoom_speed") or 100) / 100
	local zoom = math.clamp(current_zoom + scroll_value * 0.05 * speed, low, high)

	if math.abs(zoom - current_zoom) < 1e-4 then
		return
	end

	local settings = _background_settings(view)

	if not settings then
		return
	end

	view._current_zoom = zoom

	local render_scale = Managers.ui:view_render_scale() * zoom

	view._nodes_render_scale = render_scale
	view:_force_update_scenegraph()

	local cursor_x, cursor_y = cursor_position[1] / render_scale, cursor_position[2] / render_scale
	local zoom_ratio = zoom / current_zoom
	local diff_x, diff_y = cursor_x * zoom_ratio - cursor_x, cursor_y * zoom_ratio - cursor_y

	settings.x = settings.x - diff_x
	_clamp_x(view, settings)

	-- The view's own scroll keeps the overlay scrollbar in step and clamps y.
	if view._scroll_to_height then
		view:_scroll_to_height(settings.y - diff_y)
	else
		settings.y = settings.y - diff_y
	end
end

-- realms_loadout's talent screen is its own class, RealmsLoadoutTalentView
-- (class("RealmsLoadoutTalentView", "TalentBuilderView")). Classes copy their
-- parent's methods when they are created, so hooks on TalentBuilderView miss
-- it when it was created first; its methods are hooked too (by name, so the
-- Mod Framework applies them once the class exists). When it copied a method
-- that was already hooked, the original handed to the hook is
-- TalentBuilderView's hooked method, and the hook passes straight through so
-- nothing runs twice.
local REALMS_VIEW = "RealmsLoadoutTalentView"
local _unpack = unpack or table.unpack
local function _pack(...)
	return { n = select("#", ...), ... }
end

local function _already_hooked(name, func)
	local tbv = CLASSES and CLASSES.TalentBuilderView

	return tbv ~= nil and func == rawget(tbv, name)
end

local function _hook(view_class, name, fn)
	if view_class ~= REALMS_VIEW then
		return mod:hook(view_class, name, fn)
	end

	mod:hook(view_class, name, function (func, self, ...)
		if _already_hooked(name, func) then
			return func(self, ...)
		end

		return fn(func, self, ...)
	end)
end

local function _hook_safe(view_class, name, fn)
	if view_class ~= REALMS_VIEW then
		return mod:hook_safe(view_class, name, fn)
	end

	mod:hook(view_class, name, function (func, self, ...)
		local results = _pack(func(self, ...))

		if not _already_hooked(name, func) then
			local ok, err = pcall(fn, self, ...)

			if not ok then
				mod:error("%s.%s: %s", REALMS_VIEW, name, tostring(err))
			end
		end

		return _unpack(results, 1, results.n)
	end)
end

local function _hook_view(view_class)
	_hook(view_class, "_on_input_scroll_axis_changed", function (func, self, scroll_value, cursor_position, ...)
		local wheel = self._player_mode and cursor_position and scroll_value and scroll_value ~= 0 and self._using_cursor_navigation

		if not wheel or _ctrl_held() then
			return func(self, scroll_value, cursor_position, ...)
		end

		self._is_scrolling = true
		self._tooltip_alpha_multiplier = 0

		local ok, err = pcall(_zoom, self, scroll_value, cursor_position)

		if not ok then
			mod:error("zoom failed: %s", tostring(err))

			return func(self, scroll_value, cursor_position, ...)
		end
	end)

	-- The view drags the background only up and down in player mode
	-- ("if not self._player_mode then scenegraph_settings.x = final_x").
	-- Add the cursor's x movement while the background is dragged, unless a
	-- tree mod pans that tree itself (view._qiangiq_pan_owner set to its
	-- name). This mod claims the flag as "treezoom" otherwise, so other
	-- sideways drags that respect it (QIangIQsScumHook) stand down.
	_hook(view_class, "_handle_scenegraph_coordinates", function (func, self, widget_name, scenegraph_id, input_service, move_input_prefix, render_settings, is_background, ...)
		if self._qiangiq_zoom_panning or not (is_background and self._player_mode) then
			return func(self, widget_name, scenegraph_id, input_service, move_input_prefix, render_settings, is_background, ...)
		end

		local owner = self._qiangiq_pan_owner

		if owner and owner ~= "treezoom" then
			return func(self, widget_name, scenegraph_id, input_service, move_input_prefix, render_settings, is_background, ...)
		end

		self._qiangiq_pan_owner = "treezoom"
		self._qiangiq_zoom_panning = true

		local last = self._dragging_scenegraph_id == scenegraph_id and self._cursor_last_coordinates
		local last_x = last and last[1]
		local ok, handled, finalized = pcall(func, self, widget_name, scenegraph_id, input_service, move_input_prefix, render_settings, is_background, ...)

		self._qiangiq_zoom_panning = nil

		if not ok then
			error(handled, 0)
		end

		local settings = self._saved_scenegraph_settings and self._saved_scenegraph_settings[scenegraph_id]

		if settings then
			self._qiangiq_zoom_base_x = self._qiangiq_zoom_base_x or settings.x

			local current = self._cursor_current_coordinates

			if last_x and current and current[1] ~= last_x then
				settings.x = settings.x + (current[1] - last_x) / math.max(self._nodes_render_scale or 1, 0.01)

				_clamp_x(self, settings)
			end
		end

		return handled, finalized
	end)
end

-- Classes copy their parent's methods when they are created, so both the
-- base class and the talent view are hooked.
for _, path in ipairs(VIEW_PATHS) do
	mod:hook_require(path, _hook_view)
end

_hook_view(REALMS_VIEW)
