-- QIangIQ's Golden Blood Sword: shows a Custom Assets sword in place of the
-- Maccabian Duelling Sword Mk IV (combatsword_p3_m2) and/or the
-- Relic Blade Mk II (powersword_2h_p1_m2), each on its own toggle.
-- Author: QIangIQ
local mod = get_mod("QIangIQsGoldenBloodSword")

-- QIangIQsMeleeArsenal and QIangIQsWarframeArsenal keep per-weapon profiles: when this mod switches a weapon on,
-- both are told (their mod.release_template)
local QIANGIQ_ARSENALS = {
    release_template = function(template)
        for _, name in ipairs({ "QIangIQsMeleeArsenal", "QIangIQsWarframeArsenal" }) do
            local other = get_mod(name)
            if other and other.release_template then
                other.release_template(template)
            end
        end
    end,
}

-- Cross-client sync ---------------------------------------------------------------
-- QIangIQsModelSync publishes which QIangIQ replacer mods a player has on, with their options, through
-- Vox Manifold (the transport Dio's Wardrobe shares outfits with). No asset data is sent: every client shows
-- the model from its own installed files. While another player's unit is worked on, sync_ctx holds that
-- player's options and opt() answers from them; for my own unit opt() is mod:get().
local SYNC_KEY = "gbs"
local SYNC_BOOLS = { "replace_duelling_sword", "replace_relic_blade" }
local SYNC_DEFAULTS = { replace_duelling_sword = true, replace_relic_blade = true }
local SYNC_VALUES = { "duelling_tilt", "relic_tilt" }
local SYNC_LAYOUT = #SYNC_BOOLS * 100 + #SYNC_VALUES -- a peer on another version of this mod is not decoded
local sync_ctx = nil
local sync_known = setmetatable({}, { __mode = "k" })   -- other players' extensions this mod has shown something on
local sync_all = setmetatable({}, { __mode = "k" })     -- every visual loadout extension seen
local sync_decoded = setmetatable({}, { __mode = "k" }) -- published array -> options table
local SYNC_FALSE = { __index = function() return false end }
local SYNC_OFF = setmetatable({}, SYNC_FALSE)           -- "everything off": removes what was shown
local sync_extra_import = nil

local function opt(key)
    if sync_ctx then
        return sync_ctx[key]
    end
    return mod:get(key)
end

local function sync_api()
    local hub = get_mod("QIangIQsModelSync")
    return hub and hub.api
end

local function sync_me()
    local players = Managers.player
    if not players then
        return nil
    end
    local ok, player = pcall(players.local_player_safe, players, 1)
    return ok and player or nil
end

-- published array { layout, checkbox bits, value, value, ... [, extra] } -> options by setting id
local function sync_decode(raw)
    local t = sync_decoded[raw]
    if t ~= nil then
        return t
    end
    t = false
    if type(raw) == "table" and raw[1] == SYNC_LAYOUT then
        t = setmetatable({}, SYNC_FALSE)
        local mask = tonumber(raw[2]) or 0
        for i = 1, #SYNC_BOOLS do
            t[SYNC_BOOLS[i]] = mask % 2 >= 1
            mask = math.floor(mask / 2)
        end
        for i = 1, #SYNC_VALUES do
            local v = raw[2 + i]
            if v ~= nil then
                t[SYNC_VALUES[i]] = v
            end
        end
        if sync_extra_import then
            sync_extra_import(t, raw[3 + #SYNC_VALUES])
        end
    end
    sync_decoded[raw] = t
    return t
end

-- whose options apply to this extension: nil = mine, a table = that player's (SYNC_OFF when they publish
-- nothing for this mod)
local function sync_owner(ext)
    sync_all[ext] = true
    local player = ext._player
    if player == nil or player == sync_me() then
        return nil
    end
    local api = sync_api()
    local raw = api and api.peer(SYNC_KEY, player)
    local state = raw and sync_decode(raw)
    if state then
        sync_known[ext] = true
        return state
    end
    return SYNC_OFF
end

-- my own unit, or another player's unit this mod is (or was) showing something on
local function sync_shown(ext)
    local player = ext._player
    return player ~= nil and (player == sync_me() or sync_known[ext] == true)
end

local function sync_pack(...)
    return { n = select("#", ...), ... }
end

-- runs a hook body with the options of the extension's owner
local function sync_wrap(fn, ext_index)
    return function(...)
        local ext = select(ext_index, ...)
        local previous = sync_ctx
        sync_ctx = sync_owner(ext)
        local results = sync_pack(pcall(fn, ...))
        sync_ctx = previous
        if not results[1] then
            error(results[2], 0)
        end
        return unpack(results, 2, results.n)
    end
end

-- The same hook on my own unit's extension and on other players' (husk) extensions. While the mods load, the
-- classes do not exist yet: CLASS.<name> is then only the name and DMF delays the hook ("needs to be delayed"
-- in the log), so the husk class cannot be inspected here. Its methods are taken from
-- player_husk_visual_loadout_extension.lua instead.
local SYNC_HUSK_METHODS = { init = true, update = true, _update_item_visibility = true, destroy = true }

local function vl_hook_safe(method, fn)
    mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, method, sync_wrap(fn, 1))
    if SYNC_HUSK_METHODS[method] then
        mod:hook_safe(CLASS.PlayerHuskVisualLoadoutExtension, method, sync_wrap(fn, 1))
    end
end

local function vl_hook(method, fn)
    mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, method, sync_wrap(fn, 2))
    if SYNC_HUSK_METHODS[method] then
        mod:hook(CLASS.PlayerHuskVisualLoadoutExtension, method, sync_wrap(fn, 2))
    elseif method == "_unequip_item_from_slot" then
        -- a husk has no _unequip_item_from_slot: its unequip arrives as rpc_player_unequip_item_from_slot
        -- (self, channel_id, go_id, slot_id), slot name = NetworkLookup.player_inventory_slot_names[slot_id]
        -- (player_husk_visual_loadout_extension.lua)
        mod:hook(CLASS.PlayerHuskVisualLoadoutExtension, "rpc_player_unequip_item_from_slot", sync_wrap(function(func, self, channel_id, go_id, slot_id, ...)
            local NetworkLookup = require("scripts/network_lookup/network_lookup")
            local slot_name = NetworkLookup.player_inventory_slot_names[slot_id]
            return fn(function()
                return func(self, channel_id, go_id, slot_id)
            end, self, slot_name)
        end, 2))
    end
end
-- ----------------------------------------------------------------------------------

mod.AUTHOR = "QIangIQ"

local SWORD_ID = "QIangIQsGoldenBloodSword:golden_blood_sword"                -- <Mod>:<Custom folder>
local SWORD_UNIT = "content/mods/qiangiq_golden_blood_sword/golden_blood_sword" -- --asset-path used at compile time

-- item.weapon_template -> setting id (equipment_component.lua reads item.weapon_template)
-- per-weapon tilt of the sword in the plane of the blade's flat, about the hand (degrees;
-- positive = tip away from the body / view centre, negative = towards it)
local TILT_SETTING = {
    combatsword_p3_m2 = "duelling_tilt",
    powersword_2h_p1_m2 = "relic_tilt",
}

-- QIangIQ sword swap mods that target the same weapons: per weapon, only one of them replaces it.
-- Turning a weapon on in one mod switches that weapon off in the others through their saved
-- settings (DMFMod:set / DMFMod:get, dmf/modules/core/settings.lua), as the character mods do.
local SWORD_MODS = { "QIangIQsDiamondSword", "QIangIQsGoldenBloodSword", "QIangIQsBismuthRelicBlade", "QIangIQsSkullRuneblade", "QIangIQsBismuthSword", "QIangIQsButterflyKnife" }
local REPLACE_SETTINGS = { "replace_duelling_sword", "replace_relic_blade" }
local TEMPLATES_BY_SETTING = { replace_duelling_sword = true, replace_relic_blade = true }

local TEMPLATES = {
    combatsword_p3_m2 = "replace_duelling_sword",
    powersword_2h_p1_m2 = "replace_relic_blade",
}

-- The compiled sword is authored with its blade running from local (0,0,0) to (0,1,0)
-- (Stingray forward = +Y), the flat of the blade facing local Z. Handle and pommel sit at -Y.
-- Measured on the model (gsword/prep_gs.py, blade length = 1): blade start = just under the
-- crossguard (source z -0.375), tip at source z -2.75, middle of the grip at source z 0.22 -> y = -0.2506.
local GRIP_Y = -0.2506
local FIT_FRAMES = 10
local fit_generation = 0 -- bumped when a fit setting changes, so every sword refits -- refit for a few frames after spawning so the world poses have settled
-- Which side the tilt leans to is chosen from where the tip ends up relative to the body. In a block, an attack
-- recovery or a sprint jump the body-relative pose briefly flips that choice and the weapon snaps to the wrong angle.
-- Votes (weighted by how clear each frame's choice was) are kept in the blade's own frame and the majority side
-- wins, so brief transient poses are outvoted; a setting change (fit_generation) starts the vote again.
local tilt_votes = {}
local function latch_side(view, blade, chosen, other, weight)
    local fr = Unit.world_rotation(blade, 1)
    local bx, by, bz = Quaternion.right(fr), Quaternion.forward(fr), Quaternion.up(fr)
    local function loc(v)
        return Vector3(Vector3.dot(v, bx), Vector3.dot(v, by), Vector3.dot(v, bz))
    end
    local key = view or "?"
    local vote = tilt_votes[key]
    if not vote or vote.gen ~= fit_generation then
        vote = { gen = fit_generation, sum = Vector3(0, 0, 0) }
        tilt_votes[key] = vote
    end
    vote.sum = vote.sum * 0.97 + (loc(chosen) - loc(other)) * (weight + 0.0001)
    if Vector3.dot(loc(chosen), vote.sum) >= Vector3.dot(loc(other), vote.sum) then
        return chosen
    end
    return other
end

local custom_assets = nil
local ready = false
local mod_on = true
local session_override = {} -- keybind flips, cleared when the setting itself changes

local tracked = setmetatable({}, { __mode = "k" })    -- PlayerUnitVisualLoadoutExtension
local tracked_ui = setmetatable({}, { __mode = "k" }) -- UIProfileSpawner
local tracked_wpn = setmetatable({}, { __mode = "k" }) -- UIWeaponSpawner

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function setting_on(key)
    local override = session_override[key]
    if override ~= nil and not sync_ctx then
        return override
    end
    return opt(key) and true or false
end

local function wants_item(item)
    local key = item and item.weapon_template and TEMPLATES[item.weapon_template]
    return key ~= nil and mod_on and ready and setting_on(key)
end

local function local_player()
    local players = Managers.player
    if not players then
        return nil
    end
    local ok, player = pcall(players.local_player_safe, players, 1)
    return ok and player or nil
end

-- Fitting ---------------------------------------------------------------------

-- the longest attachment box is the blade (both weapons have a separate blade attachment)
local function blade_box(attachments)
    local best_len, best_unit, best_pose, best_ext = 0, nil, nil, nil
    if attachments then
        for i = 1, #attachments do
            local unit = attachments[i]
            if unit_ok(unit) then
                local pose, half_extents = Unit.box(unit)
                if pose and half_extents then
                    local len = math.max(half_extents.x, half_extents.y, half_extents.z)
                    if len > best_len then
                        best_len, best_unit, best_pose, best_ext = len, unit, pose, half_extents
                    end
                end
            end
        end
    end
    return best_unit, best_pose, best_ext
end

local function fmt(v)
    return string.format("(%.3f, %.3f, %.3f)", v.x, v.y, v.z)
end

local last_fit = {} -- per view, for /goldensword debug

-- places the sword (linked to the blade attachment's node 1) along the original blade, in the
-- blade unit's local space. Linking to the blade itself (not the weapon base unit) makes the
-- sword follow any animation the weapon applies to its blade relative to the base.
-- Blade direction = from the blade attachment's own root node (where it is linked onto the
-- hilt) to the centre of its bounding box; this does not depend on how Unit.box orders its
-- half extents. The box axes are only used for the flat of the blade.
local function fit(sword, base, attachments, parent_scale, view, tilt_deg, body_line)
    local blade, pose, ext = blade_box(attachments)
    if not pose or not unit_ok(blade) then
        return false
    end
    local rot = Matrix4x4.rotation(pose)
    local center = Matrix4x4.translation(pose)
    local axes = { Quaternion.right(rot), Quaternion.forward(rot), Quaternion.up(rot) }
    local halves = { ext.x, ext.y, ext.z }
    local max_half = math.max(ext.x, ext.y, ext.z)
    if max_half <= 0 then
        return false
    end

    local origin = Unit.world_position(base, 1)
    local root = Unit.world_position(blade, 1)
    local to_center = center - root
    local dist = math.sqrt(Vector3.length_squared(to_center))
    local dir, source, line_point, far
    if dist > 0.25 * max_half then
        -- v2 direction (confirmed correct in game): blade root -> box centre.
        -- The box pose axes are NOT used for the direction (they put the sword sideways in game).
        local u = to_center * (1 / dist)
        dir = u
        source = "root->centre"
        -- a straight blade is authored along one of its own unit axes; if one of them is within
        -- ~14 degrees of root->centre, use it so an off-centre box does not tilt the thrust line
        local blade_rot = Unit.world_rotation(blade, 1)
        local blade_axes = { Quaternion.right(blade_rot), Quaternion.forward(blade_rot), Quaternion.up(blade_rot) }
        local best, best_axis = 0, nil
        for i = 1, 3 do
            local d = Vector3.dot(blade_axes[i], u)
            if math.abs(d) > best then
                best = math.abs(d)
                best_axis = d < 0 and -blade_axes[i] or blade_axes[i]
            end
        end
        if best_axis and best > 0.97 then
            dir = best_axis
            source = string.format("blade unit axis (%.2f to root->centre)", best)
        end
        line_point = root
        far = Vector3.dot(to_center, dir) + max_half -- root -> tip
    else
        -- root sits inside the blade: fall back to the longest box axis, pointing away from the hilt
        local long = 1
        for i = 2, 3 do
            if halves[i] > halves[long] then
                long = i
            end
        end
        dir = axes[long]
        if Vector3.dot(center - origin, dir) < 0 then
            dir = -dir
        end
        line_point = center - dir * halves[long]
        far = 2 * halves[long]
        source = "box axis"
    end
    local half = far * 0.5

    -- the hand: the weapon base unit is linked at the hand, so its origin projected onto the
    -- blade line is where the weapon is held; never let it sit past the original blade start
    local along = Vector3.dot(origin - line_point, dir)
    if along > 0 then
        along = 0
    end
    local hand = line_point + dir * along
    -- scale so the diamond sword's grip-to-tip matches the original weapon's hand-to-tip
    local reach = far - along
    local s_world = reach / (1 - GRIP_Y)

    -- flat of the blade: the thinnest box axis among those across the blade
    local thin, best_dot = nil, nil
    for i = 1, 3 do
        local d = math.abs(Vector3.dot(axes[i], dir))
        if d < 0.7 and (thin == nil or halves[i] < halves[thin]) then
            thin = i
        end
        if best_dot == nil or d > best_dot then
            best_dot = d
        end
    end
    if not thin then
        return false
    end
    local normal = Vector3.normalize(axes[thin] - dir * Vector3.dot(axes[thin], dir))

    -- optional tilt within the flat's plane, pivoting on the hand
    local tilt_note = "none"
    if tilt_deg and tilt_deg ~= 0 then
        local a = math.rad(math.abs(tilt_deg))
        local side = Vector3.cross(normal, dir)
        local d1 = dir * math.cos(a) + side * math.sin(a)
        local d2 = dir * math.cos(a) - side * math.sin(a)
        local chosen = d1
        if body_line then
            local point, axis = body_line()
            if point and axis then
                local function off_axis(d)
                    local v = hand + d * reach - point
                    local w = v - axis * Vector3.dot(v, axis)
                    return Vector3.length_squared(w)
                end
                local d1_out = off_axis(d1) >= off_axis(d2)
                if tilt_deg > 0 then
                    chosen = d1_out and d1 or d2
                else
                    chosen = d1_out and d2 or d1
                end
                local chose_d1 = (tilt_deg > 0) == d1_out
                chosen = latch_side(view, blade, chose_d1 and d1 or d2, chose_d1 and d2 or d1, math.abs(off_axis(d1) - off_axis(d2)))
            end
        end
        dir = chosen
        tilt_note = string.format("%.0f deg", tilt_deg)
    end

    -- place the diamond sword's grip centre in the hand
    local sword_start = hand - dir * (GRIP_Y * s_world)

    local frame_rot = Unit.world_rotation(blade, 1)
    local bx, by, bz = Quaternion.right(frame_rot), Quaternion.forward(frame_rot), Quaternion.up(frame_rot)
    local function to_local(v)
        return Vector3(Vector3.dot(v, bx), Vector3.dot(v, by), Vector3.dot(v, bz))
    end

    local k = parent_scale and parent_scale > 0 and parent_scale or 1
    local s = s_world / k
    local local_pos = to_local(sword_start - root) * (1 / k)
    local local_dir = to_local(dir)
    Unit.set_local_position(sword, 1, local_pos)
    Unit.set_local_rotation(sword, 1, Quaternion.look(local_dir, to_local(normal)))
    Unit.set_local_scale(sword, 1, Vector3(s, s, s))

    if view then
        last_fit[view] = string.format("%s: dir by %s, half extents %s, box axis dots %.2f/%.2f/%.2f, blade length %.3f, hand-to-tip %.3f, local start %s, local dir %s, thin axis %d, tilt %s",
            view, source, fmt(ext), Vector3.dot(axes[1], dir), Vector3.dot(axes[2], dir), Vector3.dot(axes[3], dir),
            2 * half, reach, fmt(local_pos), fmt(local_dir), thin, tilt_note)
    end
    return true
end

local function hide_originals(base, attachments)
    Unit.set_unit_visibility(base, false, true)
    if attachments then
        for i = 1, #attachments do
            if unit_ok(attachments[i]) then
                Unit.set_unit_visibility(attachments[i], false, true)
            end
        end
    end
end

-- One record per (holder, slot, view): { sword, base, parent (blade unit), frames, count }
-- spawn_fn(parent) -> unit linked to parent node 1, destroy_fn(unit)
local function sync_record(records, key, base, attachments, item, visible, spawn_fn, destroy_fn, parent_scale, first_person, body_line)
    local rec = records[key]
    local want = unit_ok(base) and wants_item(item) and attachments ~= nil and #attachments > 0
    local blade = want and blade_box(attachments) or nil
    if not unit_ok(blade) then
        want = false
    end

    if rec and (not want or rec.base ~= base or rec.parent ~= blade or not unit_ok(rec.sword)) then
        destroy_fn(rec.sword)
        records[key] = nil
        if rec.hid and rec.base == base and unit_ok(base) and visible then
            -- give the original weapon back (recursive visibility also covers its linked attachments)
            Unit.set_unit_visibility(base, true, true)
        end
        rec = nil
    end
    if not want then
        return false
    end

    if not rec then
        local sword = spawn_fn(blade)
        if not sword then
            return false
        end
        if first_person then
            -- same flag the game sets on first-person weapons (equipment_component.lua)
            Unit.set_shader_pass_flag_for_meshes_in_unit_and_childs(sword, "custom_fov", true)
        end
        rec = { sword = sword, base = base, parent = blade, frames = 0, count = -1, fitted = false }
        records[key] = rec
    end

    if rec.count ~= #attachments or rec.gen ~= fit_generation then
        rec.gen = fit_generation
        rec.count = #attachments
        rec.frames = 0
    end
    -- the weapon's world pose is not settled when it spawns (the first fit can be stale until a setting change refits it), so refit about every 20 frames as well
    rec.tick = (rec.tick or 0) + 1
    if rec.frames < FIT_FRAMES or rec.tick % 20 == 0 then
        rec.frames = rec.frames + 1
        local blade_scale = Unit.local_scale(blade, 1)
        local k = (parent_scale or 1) * (blade_scale and blade_scale.x or 1)
        local tilt_key = item and item.weapon_template and TILT_SETTING[item.weapon_template]
        local tilt = tilt_key and opt(tilt_key) or 0
        rec.fitted = fit(rec.sword, base, attachments, k, key, tilt, body_line) or rec.fitted
    end

    if rec.fitted and visible then
        hide_originals(base, attachments)
        rec.hid = true
        Unit.set_unit_visibility(rec.sword, true, true)
    else
        Unit.set_unit_visibility(rec.sword, false, true)
    end
    return true
end

local function clear_records(records, destroy_fn)
    if not records then
        return
    end
    for key, rec in pairs(records) do
        destroy_fn(rec.sword)
        records[key] = nil
    end
end

-- In-game (your own player unit) ------------------------------------------------

local function ingame_spawn(ext, is_first_person)
    return function(parent)
        local world = ext.__qiangiq_gbs_world
        local unit_spawner = Managers.state and Managers.state.unit_spawner
        if not (world and unit_spawner) then
            return nil
        end
        local unit = unit_spawner:spawn_unit(SWORD_UNIT, Unit.world_pose(parent, 1))
        if not unit then
            return nil
        end
        if is_first_person then
            Unit.set_unit_culling(unit, false)
        end
        World.link_unit(world, unit, 1, parent, 1, World.LINK_MODE_NODE_NAME)
        return unit
    end
end

local function ingame_destroy(unit)
    if unit_ok(unit) then
        local unit_spawner = Managers.state and Managers.state.unit_spawner
        if unit_spawner then
            unit_spawner:mark_for_deletion(unit)
        end
    end
end

local function ingame_apply(ext)
    local records = ext.__qiangiq_gbs_records
    if not records then
        records = {}
        ext.__qiangiq_gbs_records = records
    end
    local equipment = ext._equipment
    if not equipment then
        return
    end
    for slot_name, slot in pairs(equipment) do
        local item = slot.item
        if item and item.weapon_template and TEMPLATES[item.weapon_template] or records[slot_name .. ":3p"] or records[slot_name .. ":1p"] then
            local base_3p, base_1p = slot.unit_3p, slot.unit_1p
            local att_3p = base_3p and slot.attachments_by_unit_3p and slot.attachments_by_unit_3p[base_3p]
            local att_1p = base_1p and slot.attachments_by_unit_1p and slot.attachments_by_unit_1p[base_1p]
            -- "body" reference for the tilt direction: the character's vertical axis in third
            -- person, the view direction through the first-person unit in first person
            sync_record(records, slot_name .. ":3p", base_3p, att_3p, item, slot.hidden_3p == false,
                ingame_spawn(ext, false), ingame_destroy, 1, false, function()
                    if unit_ok(ext._unit) then
                        return Unit.world_position(ext._unit, 1), Vector3.up()
                    end
                end)
            sync_record(records, slot_name .. ":1p", base_1p, att_1p, item, slot.hidden_1p == false,
                ingame_spawn(ext, true), ingame_destroy, 1, true, function()
                    local fp = ext._first_person_unit
                    if unit_ok(fp) then
                        return Unit.world_position(fp, 1), Quaternion.forward(Unit.world_rotation(fp, 1))
                    end
                end)
        end
    end
end

local function is_local_human(ext)
    return sync_shown(ext)
end

vl_hook_safe("init", function(self, extension_init_context)
    self.__qiangiq_gbs_world = extension_init_context and extension_init_context.world
end)

vl_hook_safe("_update_item_visibility", function(self)
    if not is_local_human(self) then
        return
    end
    tracked[self] = true
    ingame_apply(self)
end)

vl_hook_safe("update", function(self)
    if tracked[self] then
        ingame_apply(self)
    end
end)

vl_hook("_unequip_item_from_slot", function(func, self, slot_name, ...)
    local records = self.__qiangiq_gbs_records
    if records then
        for _, view in ipairs({ ":3p", ":1p" }) do
            local rec = records[slot_name .. view]
            if rec then
                ingame_destroy(rec.sword)
                records[slot_name .. view] = nil
            end
        end
    end
    return func(self, slot_name, ...)
end)

vl_hook("destroy", function(func, self, ...)
    clear_records(self.__qiangiq_gbs_records, ingame_destroy)
    tracked[self] = nil
    return func(self, ...)
end)

-- Menu previews ---------------------------------------------------------------

local function ui_profile_is_mine(profile)
    -- __qiangiq_npc: the companion NPC spawned by QIangIQsCompanionSwap is nobody's character
    if not profile or profile.__qiangiq_npc then
        return false
    end
    local players = Managers.player and Managers.player:players()
    local me = local_player()
    if players and profile.character_id then
        for _, player in pairs(players) do
            if player ~= me and player.character_id and player:character_id() == profile.character_id then
                return false
            end
        end
    end
    return true
end

local function ui_spawn(world)
    return function(parent)
        -- same calls ui_profile_spawner.lua uses for its own units
        local unit = World.spawn_unit_ex(world, SWORD_UNIT, nil, Unit.world_pose(parent, 1))
        World.link_unit(world, unit, 1, parent, 1, World.LINK_MODE_NODE_NAME)
        return unit
    end
end

local function ui_destroy_fn(world)
    return function(unit)
        if unit_ok(unit) and world then
            World.destroy_unit(world, unit)
        end
    end
end

local function scale_x(unit)
    if unit_ok(unit) then
        local s = Unit.local_scale(unit, 1)
        return s and s.x or 1
    end
    return 1
end

-- operative select / inventory character preview
local function profile_apply(spawner)
    local world = spawner._world
    local records = spawner.__qiangiq_gbs_records
    if not records then
        records = {}
        spawner.__qiangiq_gbs_records = records
    end
    local data = spawner._character_spawn_data
    local allowed = data and data.slots and opt("menu_previews") and ui_profile_is_mine(data.profile)
    if not allowed then
        clear_records(records, ui_destroy_fn(world))
        return
    end
    tracked_ui[spawner] = true
    local k = scale_x(data.unit_3p)
    for slot_name, slot in pairs(data.slots) do
        local item = slot.item
        if item and item.weapon_template and TEMPLATES[item.weapon_template] or records[slot_name] then
            local base = slot.unit_3p
            local att = base and slot.attachments_by_unit_3p and slot.attachments_by_unit_3p[base]
            sync_record(records, slot_name, base, att, item, spawner._visible and slot.hidden_3p == false,
                ui_spawn(world), ui_destroy_fn(world), k, false, function()
                    if unit_ok(data.unit_3p) then
                        return Unit.world_position(data.unit_3p, 1), Vector3.up()
                    end
                end)
        end
    end
end

mod:hook_safe(CLASS.UIProfileSpawner, "_update_items_visibility", function(self)
    profile_apply(self)
end)

mod:hook_safe(CLASS.UIProfileSpawner, "update", function(self)
    local data = self._character_spawn_data
    if data and data.is_ready then
        profile_apply(self)
    elseif self.__qiangiq_gbs_records then
        clear_records(self.__qiangiq_gbs_records, ui_destroy_fn(self._world))
    end
end)

mod:hook(CLASS.UIProfileSpawner, "_despawn_current_character_profile", function(func, self, ...)
    clear_records(self.__qiangiq_gbs_records, ui_destroy_fn(self._world))
    return func(self, ...)
end)

-- weapon inspect / inventory weapon preview
local function weapon_apply(spawner)
    local world = spawner._world
    local records = spawner.__qiangiq_gbs_records
    if not records then
        records = {}
        spawner.__qiangiq_gbs_records = records
    end
    local data = spawner._weapon_spawn_data
    if not (data and opt("menu_previews")) then
        if next(records) ~= nil then
            clear_records(records, ui_destroy_fn(world))
            if data and data.visible and unit_ok(data.item_unit_3p) then
                -- shown the same way ui_weapon_spawner.lua shows it
                Unit.set_unit_visibility(data.item_unit_3p, true, true)
            end
        end
        return
    end
    tracked_wpn[spawner] = true
    local base = data.item_unit_3p
    local att = base and data.attachment_units_3p and data.attachment_units_3p[base]
    local k = scale_x(data.link_unit) * scale_x(base)
    sync_record(records, "weapon", base, att, data.item, data.visible and true or false,
        ui_spawn(world), ui_destroy_fn(world), k, false)
end

mod:hook_safe(CLASS.UIWeaponSpawner, "update", function(self)
    weapon_apply(self)
end)

mod:hook(CLASS.UIWeaponSpawner, "_despawn_current_weapon", function(func, self, ...)
    clear_records(self.__qiangiq_gbs_records, ui_destroy_fn(self._world))
    return func(self, ...)
end)

-- Refresh / toggles ------------------------------------------------------------

local function refresh_all()
    for ext in pairs(tracked) do
        if unit_ok(ext._unit) then
            ingame_apply(ext)
            -- restores the original weapon's visibility when a replacement was switched off
            ext:force_update_item_visibility()
        end
    end
    for spawner in pairs(tracked_ui) do
        profile_apply(spawner)
        if spawner._character_spawn_data and spawner._visible then
            spawner:_update_items_visibility()
        end
    end
    for spawner in pairs(tracked_wpn) do
        weapon_apply(spawner)
    end
end

local function tell_melee_arsenal(key)
    -- QIangIQsMeleeArsenal keeps per-weapon profiles instead of these settings: when this mod
    -- switches a weapon on, Melee Arsenal is told directly (QIangIQsMeleeArsenal.lua, mod.release_template)
    local melee = QIANGIQ_ARSENALS
    if melee and melee.release_template then
        for template, k in pairs(TEMPLATES) do
            if k == key then
                melee.release_template(template)
            end
        end
    end
end

local function switch_others_off(key)
    tell_melee_arsenal(key)
    for _, name in ipairs(SWORD_MODS) do
        if name ~= "QIangIQsGoldenBloodSword" then
            local other = get_mod(name)
            if other and other:get(key) then
                other:set(key, false, true)
            end
        end
    end
end

-- both mods saved "on" for the same weapon (e.g. a newly installed mod): the later one in
-- SWORD_MODS keeps it
local function resolve_at_load()
    local mine = false
    for _, name in ipairs(SWORD_MODS) do
        if name == "QIangIQsGoldenBloodSword" then
            mine = true
        elseif mine then
            local other = get_mod(name)
            for _, key in ipairs(REPLACE_SETTINGS) do
                if other and other:get(key) and opt(key) then
                    mod:set(key, false, false)
                end
            end
        end
    end
end

local function flip(key, label)
    session_override[key] = not setting_on(key)
    if session_override[key] then
        switch_others_off(key)
    end
    refresh_all()
    mod:echo("%s replacement %s", label, session_override[key] and "on" or "off")
end

mod.toggle_duelling_sword = function()
    flip("replace_duelling_sword", "Duelling Sword Mk IV")
end

mod.toggle_relic_blade = function()
    flip("replace_relic_blade", "Relic Blade Mk II")
end

mod:command("goldensword", "Toggle the Golden Blood Sword replacements: /goldensword [duelling|relic|debug]", function(which)
    if which == "debug" then
        local any = false
        for _, line in pairs(last_fit) do
            mod:echo(line)
            any = true
        end
        if not any then
            mod:echo("No sword fitted yet: wield a replaced weapon first.")
        end
        return
    elseif which == "duelling" then
        mod.toggle_duelling_sword()
    elseif which == "relic" then
        mod.toggle_relic_blade()
    else
        mod_on = not mod_on
        refresh_all()
        mod:echo("Golden Blood Sword %s", mod_on and "on" or "off")
    end
end)

mod.on_setting_changed = function(setting_id)
    if setting_id then
        session_override[setting_id] = nil
    end
    if setting_id and TEMPLATES_BY_SETTING[setting_id] and opt(setting_id) then
        switch_others_off(setting_id)
    end
    fit_generation = fit_generation + 1
    refresh_all()
end

-- Package loading through Custom Assets --------------------------------------

mod.on_all_mods_loaded = function()
    resolve_at_load()
    -- the Duelling Sword tilt default became 45: move a saved value over once (DMF keeps saved values
    -- over new defaults), after that the slider is the user's again
    if not mod:get("duelling_tilt_45") then
        mod:set("duelling_tilt", 45, false)
        mod:set("duelling_tilt_45", true, false)
    end
    custom_assets = get_mod("CustomAssets")
    if not custom_assets or not custom_assets.is_api_compatible or not custom_assets.is_api_compatible(1) then
        mod:error("Custom Assets (API 1) is missing. Install it and put it above QIangIQsGoldenBloodSword in mod_load_order.txt.")
        return
    end
    local ticket, err = custom_assets.acquire(mod, SWORD_ID, function(_, _, load_error)
        if load_error then
            mod:error("%s failed to load: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", SWORD_ID, tostring(load_error))
            return
        end
        ready = true
        refresh_all()
    end, { resident = true, reference_name = SWORD_ID })
    if not ticket then
        mod:error("%s could not be requested: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", SWORD_ID, tostring(err))
    end
end

local function remove_all()
    for ext in pairs(tracked) do
        clear_records(ext.__qiangiq_gbs_records, ingame_destroy)
    end
    for spawner in pairs(tracked_ui) do
        clear_records(spawner.__qiangiq_gbs_records, ui_destroy_fn(spawner._world))
    end
    for spawner in pairs(tracked_wpn) do
        clear_records(spawner.__qiangiq_gbs_records, ui_destroy_fn(spawner._world))
    end
end

mod.on_disabled = function()
    remove_all()
    -- hooks are off now, so these restore the original weapon visibility
    for ext in pairs(tracked) do
        if unit_ok(ext._unit) then
            ext:force_update_item_visibility()
        end
    end
    for spawner in pairs(tracked_ui) do
        if spawner._character_spawn_data and spawner._visible then
            spawner:_update_items_visibility()
        end
    end
    for spawner in pairs(tracked_wpn) do
        local data = spawner._weapon_spawn_data
        if data and data.visible and unit_ok(data.item_unit_3p) then
            Unit.set_unit_visibility(data.item_unit_3p, true, true)
        end
    end
end

mod.on_enabled = function()
    refresh_all()
end

mod.on_unload = function()
    remove_all()
    if custom_assets and custom_assets.release_owner then
        custom_assets.release_owner(mod)
    end
end


-- Cross-client sync: what this mod publishes about me, and the refresh when anyone's options change ---------
-- on for a weapon I carry (any switched-on weapon while I have no unit)
local function sync_applies(info)
    for template, key in pairs(TEMPLATES) do
        if setting_on(key) and (info.templates == nil or info.templates[template]) then
            return true
        end
    end
    return false
end

local TEMPLATES_KEYS = {}
for _, key in pairs(TEMPLATES) do
    TEMPLATES_KEYS[key] = true
end

local sync_enabled = true
local function sync_changed()
    local api = sync_api()
    if api then
        api.changed()
    end
end

mod.sync_key = SYNC_KEY
-- info = { breed, companion_breed, templates = { [weapon_template] = true } } of my own character (fields nil
-- while I have no unit). Returns the array to publish, or nil when this mod shows nothing on my character.
mod.sync_export = function(info)
    info = info or {}
    if not sync_enabled or not sync_applies(info) then
        return nil
    end
    local mask, bit = 0, 1
    for i = 1, #SYNC_BOOLS do
        local key = SYNC_BOOLS[i]
        local v = nil
        if TEMPLATES_KEYS[key] then
            v = setting_on(key)
        else
            v = mod:get(key)
        end
        if v == nil then
            v = SYNC_DEFAULTS[key]
        end
        if v then
            mask = mask + bit
        end
        bit = bit * 2
    end
    local out = { SYNC_LAYOUT, mask }
    for i = 1, #SYNC_VALUES do
        local v = mod:get(SYNC_VALUES[i])
        if type(v) == "number" then
            v = math.floor(v * 100 + 0.5) / 100
        elseif type(v) ~= "string" then
            v = false -- not set: the reader falls back to its default
        end
        out[2 + i] = v
    end
    return out
end

mod.sync_refresh = function()
    for ext in pairs(sync_all) do
        if ext._unit and Unit.alive(ext._unit) and ext.force_update_item_visibility then
            pcall(ext.force_update_item_visibility, ext)
        end
    end
end

local sync_prev_setting_changed = mod.on_setting_changed
mod.on_setting_changed = function(...)
    if sync_prev_setting_changed then
        sync_prev_setting_changed(...)
    end
    sync_changed()
end

local sync_prev_disabled = mod.on_disabled
mod.on_disabled = function(...)
    sync_enabled = false
    if sync_prev_disabled then
        sync_prev_disabled(...)
    end
    sync_changed()
end

local sync_prev_enabled = mod.on_enabled
mod.on_enabled = function(...)
    sync_enabled = true
    if sync_prev_enabled then
        sync_prev_enabled(...)
    end
    sync_changed()
end
