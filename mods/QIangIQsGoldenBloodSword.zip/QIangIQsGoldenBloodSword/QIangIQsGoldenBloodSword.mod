return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsGoldenBloodSword` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsGoldenBloodSword", {
            mod_script = "QIangIQsGoldenBloodSword/scripts/mods/QIangIQsGoldenBloodSword/QIangIQsGoldenBloodSword",
            mod_data = "QIangIQsGoldenBloodSword/scripts/mods/QIangIQsGoldenBloodSword/QIangIQsGoldenBloodSword_data",
            mod_localization = "QIangIQsGoldenBloodSword/scripts/mods/QIangIQsGoldenBloodSword/QIangIQsGoldenBloodSword_localization",
        })
    end,
    version = "1.2.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
