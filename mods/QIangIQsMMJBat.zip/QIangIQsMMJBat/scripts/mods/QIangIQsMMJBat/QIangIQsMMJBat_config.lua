-- QIangIQsMMJBat per-weapon data (gen.py spec bat). Clips are MMJ clip names from bat\OBJ-Weapond-Bat lv1__14045.
-- Action map sources: Darktide weapon templates (Aussiemon master) via tools\dump_actions.py.
return {
    ranged = false,
    idle = "bat-idle",
    templates = { powermaul_p1_m1 = true, powermaul_p1_m2 = true },
    actions = {
        action_wield = { clips = { "bat-intro (unsheathe)" } },
        action_melee_start_left = { clips = { "bat-charge-init-v2", "bat-charge-iddle" }, loop_last = true, sounds = { "player.sword.charge_loop03-in.ogg" } },
        action_melee_start_right = { clips = { "bat-charge-init-v2", "bat-charge-iddle" }, loop_last = true, sounds = { "player.sword.charge_loop03-in.ogg" } },
        action_melee_start_left_2 = { clips = { "bat-charge-init-v2", "bat-charge-iddle" }, loop_last = true, sounds = { "player.sword.charge_loop03-in.ogg" } },
        action_melee_start_right_2 = { clips = { "bat-charge-init-v2", "bat-charge-iddle" }, loop_last = true, sounds = { "player.sword.charge_loop03-in.ogg" } },
        action_left_light = { clips = { "bat-attack1" }, sounds = { "batswing c.ogg", "batswing d.ogg", "batswing f.ogg" } },
        action_right_light = { clips = { "bat-attack2" }, sounds = { "batswing c.ogg", "batswing d.ogg", "batswing f.ogg" } },
        action_left_light_2 = { clips = { "bat-attack3" }, sounds = { "batswing c.ogg", "batswing d.ogg", "batswing f.ogg" } },
        action_right_light_2 = { clips = { "bat-attack1" }, sounds = { "batswing c.ogg", "batswing d.ogg", "batswing f.ogg" } },
        action_right_light_pushfollow = { clips = { "bat-attack2" }, sounds = { "batswing c.ogg", "batswing d.ogg", "batswing f.ogg" } },
        action_attack_special_riposte = { clips = { "bat-attack2" }, sounds = { "batswing c.ogg", "batswing d.ogg", "batswing f.ogg" } },
        action_attack_special_riposte_psyker = { clips = { "bat-attack2" }, sounds = { "batswing c.ogg", "batswing d.ogg", "batswing f.ogg" } },
        action_left_heavy = { clips = { "bat-charge-release" }, sounds = { "batswing c.ogg", "batswing d.ogg", "batswing f.ogg" } },
        action_right_heavy = { clips = { "bat-charge-release" }, sounds = { "batswing c.ogg", "batswing d.ogg", "batswing f.ogg" } },
        action_parry_special = { clips = { "bat-deflect 2" } },
        action_parry_special_psyker = { clips = { "bat-deflect 2" } },
        action_push = { clips = { "bat-deflect 2" } },
        action_inspect = { clips = { "bat-reload (spin)" } },
        action_light_4 = { clips = { "bat-attack2" }, sounds = { "batswing c.ogg", "batswing d.ogg", "batswing f.ogg" } },
        action_special_action = { clips = { "bat-charge-release" }, sounds = { "batswing c.ogg", "batswing d.ogg", "batswing f.ogg" } },
    },
}
