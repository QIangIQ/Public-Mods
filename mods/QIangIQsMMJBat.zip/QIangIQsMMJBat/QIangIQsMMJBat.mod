return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsMMJBat` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsMMJBat", {
            mod_script = "QIangIQsMMJBat/scripts/mods/QIangIQsMMJBat/QIangIQsMMJBat",
            mod_data = "QIangIQsMMJBat/scripts/mods/QIangIQsMMJBat/QIangIQsMMJBat_data",
            mod_localization = "QIangIQsMMJBat/scripts/mods/QIangIQsMMJBat/QIangIQsMMJBat_localization",
        })
    end,
    version = "0.1.1",
    author = "QIangIQ",
    packages = {},
}
