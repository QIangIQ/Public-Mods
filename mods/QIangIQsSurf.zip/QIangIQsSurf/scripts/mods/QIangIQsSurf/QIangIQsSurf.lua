local mod = get_mod("QIangIQsSurf")
local MatchmakingConstants = require("scripts/settings/network/matchmaking_constants")
local PlayerMovement = require("scripts/utilities/player_movement")
local Fall = require("scripts/extension_systems/character_state_machine/character_states/utilities/fall")
local HOST_TYPES = MatchmakingConstants.HOST_TYPES

local Layout = mod:io_dofile("QIangIQsSurf/scripts/mods/QIangIQsSurf/surf_layout")
if type(Layout) ~= "table" or type(Layout.chunks) ~= "table" then
    mod:error("surf_layout.lua could not be read; the surf map is unavailable")
    Layout = { chunks = {}, start = { 0, 0, 0 }, start_yaw = 0, teleports = {}, pushes = {}, floor_z = -10 }
end

local UNIT_PREFIX = "content/mods/qiangiq_surf/"
local SPAWNS_PER_FRAME = 6
local BODY_RADIUS = 0.35
local BODY_HEIGHT = 1.7
local MAP_TOP = 440
local OOB_LIMIT = 455
local MAP_HALF = 240

local custom_assets = nil
local tickets = {}
local loaded = {}
local load_state = "idle"
local units = {}
local spawn_queue = nil
local base_box = nil
local return_pos = nil
local release_pending = false
local last_local = nil
local cooldown = 0
local fail_count = 0
local after_load = nil

-- Realms (Realms/docs/README.md, pattern of QIangIQsOgrynRide 1.1.0): the host spawns the map and sends its base to
-- the clients that run this mod. Each client spawns the same map locally (its own prediction needs the collision).
-- A client's teleports run on its predicted unit and, through the host, on the server's copy of that unit.
local RPC_OPEN, RPC_CLOSE, RPC_JOIN, RPC_STATE, RPC_MSG = "surf_open", "surf_close", "surf_join", "surf_state", "surf_msg"
local realms = nil
local network_ready = false
local role = nil
local surfers = {}

local function say(fmt, ...)
    mod:echo("[Surf] " .. string.format(fmt, ...))
end

local function local_player()
    local players = Managers.player
    if not players then
        return nil
    end
    local ok, player = pcall(players.local_player_safe, players, 1)
    return ok and player or nil
end

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function host_only()
    local session = Managers.multiplayer_session
    local host_type = session and session:host_type()
    if host_type == HOST_TYPES.mission_server or host_type == HOST_TYPES.hub_server then
        return false, "official servers are refused"
    end
    local game_session = Managers.state and Managers.state.game_session
    if not (game_session and game_session:is_server()) then
        return false, "you are not the host"
    end
    local game_mode = Managers.state and Managers.state.game_mode
    local mode = game_mode and game_mode:game_mode_name()
    if mode == "hub" or mode == "prologue_hub" then
        return false, "missions only (not the Mourningstar)"
    end
    return true
end

local function normalize_peer(peer_id)
    return string.lower(tostring(peer_id))
end

local function send(rpc_name, recipient, ...)
    if not network_ready then
        return false
    end
    local ok, sent = pcall(realms.network_send, mod, rpc_name, recipient, ...)
    return ok and sent == true
end

local function client_ok()
    local session = Managers.multiplayer_session
    local host_type = session and session:host_type()
    if host_type == HOST_TYPES.mission_server or host_type == HOST_TYPES.hub_server then
        return false, "official servers are refused"
    end
    local connection = Managers.connection
    if not (network_ready and connection and connection:is_client() and realms.network_is_available()) then
        return false, "not a Realms client"
    end
    local game_mode = Managers.state and Managers.state.game_mode
    local mode = game_mode and game_mode:game_mode_name()
    if mode == "hub" or mode == "prologue_hub" then
        return false, "missions only (not the Mourningstar)"
    end
    return true
end

local function host_player_for_peer(peer)
    for _, player in pairs(Managers.player:players()) do
        if player:is_human_controlled() and player:local_player_id() == 1 and normalize_peer(player:peer_id()) == peer then
            return player
        end
    end
end

local function in_surf()
    return base_box ~= nil and return_pos ~= nil and #units > 0
end

mod:hook(Fall, "check_damage", function(func, ...)
    if in_surf() and mod:get("no_fall_damage") ~= false then
        return
    end
    return func(...)
end)

local function despawn_all()
    for _, unit in ipairs(units) do
        if unit_ok(unit) then
            local world = Unit.world(unit)
            if world then
                World.destroy_unit(world, unit)
            end
        end
    end
    units, spawn_queue, base_box, last_local = {}, nil, nil, nil
end

local function release_all()
    if custom_assets and custom_assets.release then
        for _, t in pairs(tickets) do
            custom_assets.release(t)
        end
    end
    tickets, loaded, load_state = {}, {}, "idle"
end

local function set_velocity(player_unit, v)
    local ude = ScriptUnit.has_extension(player_unit, "unit_data_system")
    if ude then
        pcall(function()
            ude:write_component("locomotion").velocity_current = v
        end)
    end
end

local function teleport_local(pos, yaw)
    local player = local_player()
    local player_unit = player and player.player_unit
    if not (unit_ok(player_unit) and base_box) then
        return
    end
    local rot = Quaternion.axis_angle(Vector3.up(), math.rad(yaw or 0))
    local target = base_box:unbox() + Vector3(pos[1], pos[2], pos[3] + 0.1)
    PlayerMovement.teleport(player, target, rot)
    set_velocity(player_unit, Vector3.zero())
    last_local = nil
    cooldown = 0.3
    if role == "client" then
        send(RPC_STATE, "host", true, Vector3.x(target), Vector3.y(target), Vector3.z(target), yaw or 0)
    end
end

local function to_start()
    teleport_local(Layout.start, Layout.start_yaw)
end

local function start_spawning(base)
    local player = local_player()
    local player_unit = player and player.player_unit
    local world = Managers.world and Managers.world:world("level_world")
    if not (unit_ok(player_unit) and world) then
        say("no player unit or level world yet")
        return
    end
    local here = Unit.world_position(player_unit, 1)
    if not return_pos then
        return_pos = Vector3Box(here)
    end
    if #units > 0 and base_box then
        to_start()
        say("back at the start. /surf back to return")
        return
    end
    if base then
        base_box = base
    else
        local reach = OOB_LIMIT - MAP_HALF
        local bx = math.max(-reach, math.min(reach, Vector3.x(here)))
        local by = math.max(-reach, math.min(reach, Vector3.y(here)))
        base_box = Vector3Box(Vector3(bx, by, MAP_TOP - Layout.top_z))
    end
    spawn_queue = {}
    for _, row in ipairs(Layout.chunks) do
        if loaded[row[1]] then
            spawn_queue[#spawn_queue + 1] = row
        end
    end
    say("building the map: %d chunks", #spawn_queue)
end

local function load_map()
    custom_assets = custom_assets or get_mod("CustomAssets")
    if not custom_assets or not custom_assets.is_api_compatible or not custom_assets.is_api_compatible(1) then
        say("Custom Assets (API 1) is missing")
        return
    end
    load_state = "loading"
    local pending = #Layout.chunks
    local failed = 0
    local function done()
        pending = pending - 1
        if pending == 0 then
            load_state = "ready"
            if failed > 0 then
                say("%d chunk(s) failed to load (run CUSTOM_ASSETS_PATCH.bat with the game closed)", failed)
            end
            local f = after_load
            after_load = nil
            if f then
                f()
            end
        end
    end
    for _, row in ipairs(Layout.chunks) do
        local name = row[1]
        local id = "QIangIQsSurf:" .. name
        local t, err = custom_assets.acquire(mod, id, function(_, _, load_error)
            if load_error then
                failed = failed + 1
            else
                loaded[name] = true
            end
            done()
        end, { reference_name = id })
        if t then
            tickets[name] = t
        else
            failed = failed + 1
            mod:info("%s could not be requested: %s", id, tostring(err))
            done()
        end
    end
    say("loading surf_utopia (%d packages)...", #Layout.chunks)
end

local function enter_with(base)
    if load_state == "ready" then
        start_spawning(base)
    elseif load_state == "loading" then
        after_load = function()
            start_spawning(base)
        end
        say("still loading...")
    else
        after_load = function()
            start_spawning(base)
        end
        load_map()
    end
end

local function request_enter()
    local ok, why = host_only()
    if ok then
        role = "host"
        enter_with(nil)
        return
    end
    if client_ok() then
        if role == "client" and in_surf() then
            to_start()
        elseif send(RPC_JOIN, "host") then
            say("asking the host for the surf map...")
        else
            say("the host does not run QIangIQ's Surf")
        end
        return
    end
    say("not available: %s", why)
end

local function client_enter(bx, by, bz)
    if role == "host" or not client_ok() then
        return
    end
    if type(bx) ~= "number" or type(by) ~= "number" or type(bz) ~= "number" then
        return
    end
    role = "client"
    if in_surf() then
        to_start()
        return
    end
    say("the host opened the surf map")
    enter_with(Vector3Box(Vector3(bx, by, bz)))
end

local function go_back()
    local player = local_player()
    local player_unit = player and player.player_unit
    if return_pos and unit_ok(player_unit) then
        local back = return_pos:unbox()
        PlayerMovement.teleport(player, back, Unit.world_rotation(player_unit, 1))
        set_velocity(player_unit, Vector3.zero())
        if role == "client" then
            send(RPC_STATE, "host", false, Vector3.x(back), Vector3.y(back), Vector3.z(back), nil)
        end
        say("back")
    end
    if role == "host" then
        send(RPC_CLOSE, "others")
        surfers = {}
    end
    role = nil
    after_load = nil
    return_pos = nil
    despawn_all()
end

mod.restart = function()
    if in_surf() then
        to_start()
    end
end

local function segment_hits_box(a, b, lo, hi)
    local t0, t1 = 0, 1
    for i = 1, 3 do
        local d = b[i] - a[i]
        if math.abs(d) < 1e-6 then
            if a[i] < lo[i] or a[i] > hi[i] then
                return false
            end
        else
            local u0, u1 = (lo[i] - a[i]) / d, (hi[i] - a[i]) / d
            if u0 > u1 then
                u0, u1 = u1, u0
            end
            t0, t1 = math.max(t0, u0), math.min(t1, u1)
            if t0 > t1 then
                return false
            end
        end
    end
    return true
end

local function inside(p, v)
    local lo, hi = v.min, v.max
    return p[1] >= lo[1] - BODY_RADIUS and p[1] <= hi[1] + BODY_RADIUS and p[2] >= lo[2] - BODY_RADIUS
        and p[2] <= hi[2] + BODY_RADIUS and p[3] >= lo[3] - BODY_HEIGHT and p[3] <= hi[3]
end

local BODY_POINTS = { 0.3, 0.9, 1.5 }

local function point_in_brushes(brushes, x, y, z)
    for _, planes in ipairs(brushes) do
        local inside = true
        for _, pl in ipairs(planes) do
            if pl[1] * x + pl[2] * y + pl[3] * z - pl[4] > BODY_RADIUS then
                inside = false
                break
            end
        end
        if inside then
            return true
        end
    end
    return false
end

local function segment_in_volume(v, a, p)
    if not v.brushes then
        return true
    end
    local dx, dy, dz = p[1] - a[1], p[2] - a[2], p[3] - a[3]
    local steps = math.min(24, math.max(1, math.ceil(math.sqrt(dx * dx + dy * dy + dz * dz) / 0.4)))
    for k = 0, steps do
        local t = k / steps
        local x, y, z = a[1] + dx * t, a[2] + dy * t, a[3] + dz * t
        for _, h in ipairs(BODY_POINTS) do
            if point_in_brushes(v.brushes, x, y, z + h) then
                return true
            end
        end
    end
    return false
end

local function apply_pushes(player_unit, p)
    for _, v in ipairs(Layout.pushes) do
        if inside(p, v) then
            local ude = ScriptUnit.has_extension(player_unit, "unit_data_system")
            local vel = ude and ude:read_component("locomotion").velocity_current
            if vel then
                local dir = Vector3(v.dir[1], v.dir[2], v.dir[3])
                local along = Vector3.dot(vel, dir)
                if along < v.speed then
                    set_velocity(player_unit, vel + dir * (v.speed - along))
                end
            end
        end
    end
end

local function check_volumes(player_unit, p)
    local a = last_local or p
    for _, v in ipairs(Layout.teleports) do
        local lo = { v.min[1] - BODY_RADIUS, v.min[2] - BODY_RADIUS, v.min[3] - BODY_HEIGHT }
        local hi = { v.max[1] + BODY_RADIUS, v.max[2] + BODY_RADIUS, v.max[3] }
        if segment_hits_box(a, p, lo, hi) and segment_in_volume(v, a, p) then
            if v.fail then
                fail_count = fail_count + 1
                to_start()
            else
                teleport_local(v.to, v.yaw)
            end
            return true
        end
    end
    if p[3] < Layout.floor_z then
        to_start()
        return true
    end
    apply_pushes(player_unit, p)
    return false
end

-- Host: push volumes also act on the server's copy of each surfing client (the client pushes its prediction).
local function push_remote()
    local base = base_box:unbox()
    for peer in pairs(surfers) do
        local player = host_player_for_peer(peer)
        local unit = player and player.player_unit
        if unit_ok(unit) then
            local w = Unit.world_position(unit, 1) - base
            apply_pushes(unit, { Vector3.x(w), Vector3.y(w), Vector3.z(w) })
        else
            surfers[peer] = nil
        end
    end
end

local function debug()
    local ok, why = host_only()
    local session = Managers.multiplayer_session
    say("gate: %s%s | host type: %s", tostring(ok), why and (" (" .. why .. ")") or "",
        session and tostring(session:host_type()) or "none")
    local nsurf = 0
    for _ in pairs(surfers) do
        nsurf = nsurf + 1
    end
    say("role: %s | Realms network: %s | surfing clients: %d", tostring(role), tostring(network_ready), nsurf)
    local n = 0
    for _ in pairs(loaded) do
        n = n + 1
    end
    say("load state: %s, chunks loaded %d / %d, spawned %d", load_state, n, #Layout.chunks, #units)
    local player = local_player()
    local player_unit = player and player.player_unit
    if base_box and unit_ok(player_unit) then
        local p = Unit.world_position(player_unit, 1) - base_box:unbox()
        say("position in map: %.1f %.1f %.1f (start %.1f %.1f %.1f)", Vector3.x(p), Vector3.y(p), Vector3.z(p),
            Layout.start[1], Layout.start[2], Layout.start[3])
        local actors = 0
        local mine = {}
        for _, unit in ipairs(units) do
            mine[unit] = true
            local aok, n = pcall(Unit.num_actors, unit)
            actors = actors + (aok and n or 0)
        end
        say("map actors: %d in %d units | fails sent to start: %d", actors, #units, fail_count)
        local world = Unit.world(units[1])
        local pw = world and World.physics_world(world)
        local from = Unit.world_position(player_unit, 1) + Vector3(0, 0, 1.3)
        local dirs = { down = Vector3(0, 0, -1), up = Vector3(0, 0, 1), fwd = Vector3(0, 1, 0), back = Vector3(0, -1, 0),
            left = Vector3(-1, 0, 0), right = Vector3(1, 0, 0) }
        for _, filter in ipairs({ "filter_player_mover", "filter_player_character_shooting_raycast_statics" }) do
            local parts = {}
            for _, name in ipairs({ "down", "up", "fwd", "back", "left", "right" }) do
                local rok, hit, _, dist, _, actor = pcall(PhysicsWorld.raycast, pw, from, dirs[name], 200, "closest",
                    "collision_filter", filter)
                if not rok then
                    parts[#parts + 1] = name .. "=err"
                elseif hit then
                    local own = actor and mine[Actor.unit(actor)]
                    parts[#parts + 1] = string.format("%s=%.1f%s", name, dist or -1, own and "(surf)" or "(other)")
                else
                    parts[#parts + 1] = name .. "=none"
                end
            end
            say("%s: %s", filter, table.concat(parts, " "))
        end
    end
end

mod.update = function(dt)
    if spawn_queue then
        local world = Managers.world and Managers.world:world("level_world")
        if world and base_box then
            local base = base_box:unbox()
            for _ = 1, SPAWNS_PER_FRAME do
                local row = table.remove(spawn_queue)
                if not row then
                    break
                end
                local unit = World.spawn_unit_ex(world, UNIT_PREFIX .. row[1], nil, base + Vector3(row[2], row[3], row[4]),
                    Quaternion.identity())
                if unit then
                    units[#units + 1] = unit
                end
            end
            if #spawn_queue == 0 then
                spawn_queue = nil
                to_start()
                if role == "host" then
                    local b = base_box:unbox()
                    send(RPC_OPEN, "others", Vector3.x(b), Vector3.y(b), Vector3.z(b))
                end
                say("surf_utopia ready (%d chunks). Fail = back to start. /surf back to leave", #units)
            end
        end
        return
    end
    if not in_surf() then
        return
    end
    if role == "host" and next(surfers) then
        push_remote()
    end
    if cooldown > 0 then
        cooldown = cooldown - dt
        return
    end
    local player = local_player()
    local player_unit = player and player.player_unit
    if not unit_ok(player_unit) then
        return
    end
    local w = Unit.world_position(player_unit, 1) - base_box:unbox()
    local p = { Vector3.x(w), Vector3.y(w), Vector3.z(w) }
    if not check_volumes(player_unit, p) then
        last_local = p
    end
end

mod:command("surf", mod:localize("cmd_desc"), function(arg)
    if arg == "back" then
        go_back()
    elseif arg == "restart" then
        mod.restart()
    elseif arg == "debug" then
        debug()
    else
        request_enter()
    end
end)

mod.on_game_state_changed = function(status, state_name)
    if state_name == "StateGameplay" and status == "exit" then
        despawn_all()
        return_pos = nil
        role, surfers, after_load = nil, {}, nil
        if next(tickets) then
            release_pending = true
        end
    elseif state_name == "StateGameplay" and status == "enter" then
        if release_pending then
            release_pending = false
            release_all()
        end
    end
end

mod.on_disabled = function()
    despawn_all()
end

mod.on_unload = function()
    despawn_all()
end

-- ##########################################################
-- Realms messages

local function on_join(sender)
    if role ~= "host" or not in_surf() or spawn_queue then
        send(RPC_MSG, sender, "the host has not opened /surf yet")
        return
    end
    local b = base_box:unbox()
    send(RPC_OPEN, sender, Vector3.x(b), Vector3.y(b), Vector3.z(b))
end

local function on_open(sender, bx, by, bz)
    client_enter(bx, by, bz)
end

local function on_close(sender)
    if role == "client" then
        say("the host closed the surf map")
        go_back()
    end
end

local function finite(v)
    return type(v) == "number" and v == v and math.abs(v) <= OOB_LIMIT
end

local function on_state(sender, inside_map, x, y, z, yaw)
    if not host_only() or not (finite(x) and finite(y) and finite(z)) then
        return
    end
    local player = host_player_for_peer(sender)
    local unit = player and player.player_unit
    if not unit_ok(unit) then
        return
    end
    if inside_map == true then
        if not (role == "host" and in_surf()) then
            return
        end
        surfers[sender] = true
    else
        surfers[sender] = nil
    end
    local rot = type(yaw) == "number" and Quaternion.axis_angle(Vector3.up(), math.rad(yaw)) or Unit.world_rotation(unit, 1)
    PlayerMovement.teleport(player, Vector3(x, y, z), rot)
    set_velocity(unit, Vector3.zero())
end

local function on_msg(sender, text)
    if type(text) == "string" then
        say("host: %s", text)
    end
end

mod.on_all_mods_loaded = function()
    realms = get_mod("Realms")
    if not realms or type(realms.network_register) ~= "function" or type(realms.network_send) ~= "function" then
        realms = nil
        return
    end
    network_ready = true
    local handlers = { [RPC_OPEN] = on_open, [RPC_CLOSE] = on_close, [RPC_JOIN] = on_join, [RPC_STATE] = on_state,
        [RPC_MSG] = on_msg }
    for rpc_name, handler in pairs(handlers) do
        local ok, registered, register_error = pcall(realms.network_register, mod, rpc_name, function(sender_peer_id, ...)
            handler(normalize_peer(sender_peer_id), ...)
        end)
        if not ok or not registered then
            network_ready = false
            mod:info("Realms network registration failed for %s: %s", rpc_name, tostring(ok and register_error or registered))
        end
    end
    if network_ready and type(realms.network_on_peer_left) == "function" then
        pcall(realms.network_on_peer_left, mod, function(peer_id)
            surfers[normalize_peer(peer_id)] = nil
        end)
    end
end
