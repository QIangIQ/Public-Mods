return {
    mod_name = { en = "QIangIQ's Surf Utopia" },
    mod_description = { en = "Personal use only: surf_utopia_v3 (by Murloc, CC BY-NC-ND) converted for Darktide, loaded above the level in any mission you host (SoloPlay or your own Realms session). Realms friends with this mod (same version, patched) are brought along when you open it, or type /surf to join. Every fail sends you back to the start. Use with QIangIQ's Source Movement. /surf, /surf back, /surf restart, /surf debug." },
    cmd_desc = { en = "Surf Utopia: /surf, /surf back, /surf restart, /surf debug, /surf realms" },
    no_fall_damage = { en = "No fall damage while surfing" },
    restart_keybind = { en = "Restart key" },
    restart_keybind_description = { en = "Back to the start of the map." },
}
