local mod = get_mod("QIangIQsSurf")

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = true,
    options = {
        widgets = {
            { setting_id = "no_fall_damage", type = "checkbox", default_value = true },
            {
                setting_id = "restart_keybind",
                type = "keybind",
                default_value = {},
                keybind_trigger = "pressed",
                keybind_type = "function_call",
                function_name = "restart",
            },
        },
    },
}
