return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsSurf` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsSurf", {
            mod_script = "QIangIQsSurf/scripts/mods/QIangIQsSurf/QIangIQsSurf",
            mod_data = "QIangIQsSurf/scripts/mods/QIangIQsSurf/QIangIQsSurf_data",
            mod_localization = "QIangIQsSurf/scripts/mods/QIangIQsSurf/QIangIQsSurf_localization",
        })
    end,
    version = "1.2.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
