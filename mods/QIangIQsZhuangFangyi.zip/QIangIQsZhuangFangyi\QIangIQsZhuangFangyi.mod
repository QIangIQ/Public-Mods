return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsZhuangFangyi` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsZhuangFangyi", {
            mod_script = "QIangIQsZhuangFangyi/scripts/mods/QIangIQsZhuangFangyi/QIangIQsZhuangFangyi",
            mod_data = "QIangIQsZhuangFangyi/scripts/mods/QIangIQsZhuangFangyi/QIangIQsZhuangFangyi_data",
            mod_localization = "QIangIQsZhuangFangyi/scripts/mods/QIangIQsZhuangFangyi/QIangIQsZhuangFangyi_localization",
        })
    end,
    version = "1.1.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
