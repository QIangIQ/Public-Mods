return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsNovitiate` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsNovitiate", {
			mod_script       = "QIangIQsNovitiate/scripts/mods/QIangIQsNovitiate/QIangIQsNovitiate",
			mod_data         = "QIangIQsNovitiate/scripts/mods/QIangIQsNovitiate/QIangIQsNovitiate_data",
			mod_localization = "QIangIQsNovitiate/scripts/mods/QIangIQsNovitiate/QIangIQsNovitiate_localization",
		})
	end,
	packages = {},
}
