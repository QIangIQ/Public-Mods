local mod = get_mod("QIangIQsNovitiate")
local N = mod.nov

-- The Novitiate's look. Two modes (option "visual_mode"):
--   dauntless (default): the datamined Dauntless Battle Sister gear and face,
--     retail units of the game (nothing to install). They are spawned and
--     linked to the player's third person unit by node name, the same way
--     QIangIQsAnubis links its model and the game links gear
--     (visual_loadout_customization.lua), and the stock gear, face and hair
--     are hidden. They have no item definitions (INDEX.md of the datamine: no
--     Lua references them), so they are loaded as packages by unit path.
--   lacrima: the Sister Lacrima model, a Custom Assets unit
--     (QIangIQsNovitiate:lacrima, built by the DMS pipeline). Needs Custom
--     Assets and its patcher; without them the Dauntless look is used.
--
-- Only your own Zealot is changed (human breed), in the game and in the
-- menu previews. Other players do not see it. First person arms are not
-- changed.

local BASE = "content/characters/player/human/"
local DAUNTLESS_UNITS = {
	{ id = "face", path = BASE .. "attachments_base/female/face_dauntless_01/female_face_dauntless_01", option = "dauntless_face" },
	{ id = "hair", path = BASE .. "attachments_base/hair/female/hair_medium_battlesister_a/hair_medium_battlesister_a", option = "visual_hair" },
	{ id = "head", path = BASE .. "attachments_gear/headgear/dauntless_headgear_01/dauntless_headgear_01" },
	{ id = "torso", path = BASE .. "attachments_gear/upperbody/dauntless_upperbody_a/dauntless_upperbody_a_torso" },
	{ id = "arms", path = BASE .. "attachments_gear/upperbody/dauntless_upperbody_a/dauntless_upperbody_a_arms" },
	{ id = "gloves", path = BASE .. "attachments_gear/upperbody/dauntless_upperbody_a/dauntless_upperbody_a_gloves" },
	{ id = "pants", path = BASE .. "attachments_gear/lowerbody/dauntless_lowerbody_a/dauntless_lowerbody_a_pants" },
	{ id = "shoes", path = BASE .. "attachments_gear/lowerbody/dauntless_lowerbody_a/dauntless_lowerbody_a_shoes" },
}

local LACRIMA_ASSET = "QIangIQsNovitiate:lacrima"
local LACRIMA_UNIT = "content/mods/qiangiq_novitiate/lacrima"
local PACKAGE_REFERENCE = "QIangIQsNovitiate"
local EXCLUDED_BREEDS = { ogryn = true }

local state = mod:persistent_table("novitiate_visual_state", {
	loaded = {},
	package_ids = {},
	lacrima_ready = false,
	requested = false,
	lacrima_requested = false,
})

local tracked = setmetatable({}, { __mode = "k" })
local tracked_ui = setmetatable({}, { __mode = "k" })

local function unit_ok(unit)
	return unit ~= nil and Unit.alive(unit)
end

local function local_player()
	local players = Managers.player

	if not players then
		return nil
	end

	local ok, player = pcall(players.local_player_safe, players, 1)

	return ok and player or nil
end

local function mode()
	local value = mod:get("visual_mode") or "dauntless"

	if value == "lacrima" and not state.lacrima_ready then
		return "dauntless"
	end

	return value
end

local function wanted_entries()
	local out = {}

	for _, entry in ipairs(DAUNTLESS_UNITS) do
		local value = entry.option and mod:get(entry.option)
		local on = not entry.option or (entry.id == "face" and value == true) or (entry.id ~= "face" and value ~= false)

		if on and state.loaded[entry.path] then
			out[#out + 1] = entry
		end
	end

	return out
end

-- Is this the local player's Zealot (human)?
local function is_my_zealot(ext)
	local player = ext._player

	if player == nil or player ~= local_player() then
		return false
	end

	local props = ext._static_profile_properties
	local breed = (props and props.breed) or ext.__nov_breed

	if EXCLUDED_BREEDS[breed] then
		return false
	end

	local ok, name = pcall(player.archetype_name, player)

	if not (ok and name == "zealot") then
		return false
	end

	local ok_id, character_id = pcall(player.character_id, player)

	return N.is_novitiate_id(ok_id and character_id or nil)
end

local function delete_unit(unit)
	if unit_ok(unit) then
		local unit_spawner = Managers.state and Managers.state.unit_spawner

		if unit_spawner then
			unit_spawner:mark_for_deletion(unit)
		end
	end
end

local function despawn(ext)
	local units = ext.__nov_units

	if units then
		for id, unit in pairs(units) do
			delete_unit(unit)
			units[id] = nil
		end
	end

	ext.__nov_units = nil
end

-- (2026-10-26: joining the parent's LOD groups, a theory for the floating
-- face, was dropped again. It did not cure the face, and with the far
-- isometric camera in the Mourningstar the whole character vanished.)
local function settle(unit, parent)
end

-- The Dauntless face's jaw, teeth and lips are animated bones of the face
-- unit itself. The game gives every face the state machine named in its
-- face item (key from the mission template, visual_loadout_customization.lua
-- and UIProfileSpawner.assign_face_state_machine); without one the jaw and
-- teeth stay at their rest pose in front of the head. Borrow the state
-- machine of the character's own face item.
local function face_state_machine(unit, face_item, key)
	if not (unit_ok(unit) and type(face_item) == "table" and key) then
		return
	end

	local state_machine = face_item[key]

	if type(state_machine) == "string" and state_machine ~= "" then
		local ok, err = pcall(Unit.set_animation_state_machine, unit, state_machine)

		if not ok then
			mod:info("Novitiate: face state machine %s failed: %s", state_machine, tostring(err))
		end
	end
end

-- Same spawn + link as the game uses for gear (visual_loadout_customization.lua).
local function spawn_linked(world, parent, unit_name)
	local unit_spawner = Managers.state and Managers.state.unit_spawner

	if not (unit_spawner and unit_ok(parent)) then
		return nil
	end

	local unit = unit_spawner:spawn_unit(unit_name, Unit.world_pose(parent, 1))

	if not unit then
		return nil
	end

	world = world or Unit.world(parent)

	World.link_unit(world, unit, 1, parent, 1, World.LINK_MODE_NODE_NAME)
	settle(unit, parent)

	return unit
end

-- Stock pieces replaced by the new look: clothes, face, hair, beard. With
-- the Dauntless face off (option "dauntless_face") the character keeps its own.
local function hidden_slot(slot_name)
	if slot_name == "slot_body_face" then
		return mode() == "lacrima" or mod:get("dauntless_face") == true
	end

	return string.find(slot_name, "^slot_gear_") ~= nil or slot_name == "slot_body_hair" or slot_name == "slot_body_beard"
end


local function hide_stock(slots, key, hide_skin)
	if not slots then
		return
	end

	local attachments_key = key == "unit_1p" and "attachments_by_unit_1p" or "attachments_by_unit_3p"

	for slot_name, slot in pairs(slots) do
		if hidden_slot(slot_name) or (hide_skin and string.find(slot_name, "^slot_body_")) then
			local unit = slot[key]

			if unit_ok(unit) then
				Unit.set_unit_visibility(unit, false, true)

				local attachments = slot[attachments_key] and slot[attachments_key][unit]

				if attachments then
					for i = 1, #attachments do
						if unit_ok(attachments[i]) then
							Unit.set_unit_visibility(attachments[i], false, true)
						end
					end
				end
			end
		end
	end
end

local function desired_units()
	if mode() == "lacrima" then
		return { { id = "lacrima", path = LACRIMA_UNIT } }, true
	end

	return wanted_entries(), false
end

local function apply(ext, first_person_mode)
	local m = mode()

	if m == "off" or not is_my_zealot(ext) then
		despawn(ext)

		return
	end

	local units = ext.__nov_units or {}

	ext.__nov_units = units

	local list, skin_hidden = desired_units()
	local keep = {}

	for _, entry in ipairs(list) do
		keep[entry.id] = true

		if not unit_ok(units[entry.id]) then
			units[entry.id] = spawn_linked(ext.__nov_world, ext._unit, entry.path)

			if entry.id == "face" then
				local slot = ext._equipment and ext._equipment.slot_body_face
				local mission = ext._mission

				face_state_machine(units[entry.id], slot and slot.item, type(mission) == "table" and mission.face_state_machine_key or nil)
			end
		end

		if unit_ok(units[entry.id]) then
			Unit.set_unit_visibility(units[entry.id], not first_person_mode, true)
		end
	end

	for id, unit in pairs(units) do
		if not keep[id] then
			delete_unit(unit)
			units[id] = nil
		end
	end

	if not first_person_mode and next(units) ~= nil then
		hide_stock(ext._equipment, "unit_3p", skin_hidden)
	end
end

-- Menu previews ----------------------------------------------------------------

local function ui_despawn(spawner)
	local units = spawner.__nov_units

	spawner.__nov_units = nil
	spawner.__nov_parent = nil

	if units and spawner._world then
		for _, unit in pairs(units) do
			if unit_ok(unit) then
				World.destroy_unit(spawner._world, unit)
			end
		end
	end
end

local function ui_profile_is_mine(profile)
	if not profile or profile.__qiangiq_npc then
		return false
	end

	local players = Managers.player and Managers.player:players()
	local me = local_player()

	if players and profile.character_id then
		for _, player in pairs(players) do
			if player ~= me and player.character_id and player:character_id() == profile.character_id then
				return false
			end
		end
	end

	return true
end

local function ui_apply(spawner)
	local data = spawner._character_spawn_data

	if not data or not unit_ok(data.unit_3p) then
		return
	end

	local archetype = data.profile and data.profile.archetype
	local ok = archetype and archetype.name == "zealot" and not EXCLUDED_BREEDS[archetype.breed] and ui_profile_is_mine(data.profile) and N.is_novitiate_profile(data.profile) and mode() ~= "off"

	if not ok then
		if spawner.__nov_units then
			ui_despawn(spawner)

			if spawner._visible then
				spawner:_update_items_visibility()
			end
		end

		return
	end

	if spawner.__nov_parent ~= data.unit_3p then
		ui_despawn(spawner)
	end

	local units = spawner.__nov_units or {}

	spawner.__nov_units = units
	spawner.__nov_parent = data.unit_3p
	tracked_ui[spawner] = true

	local list, skin_hidden = desired_units()
	local keep = {}
	local world = spawner._world

	for _, entry in ipairs(list) do
		keep[entry.id] = true

		if not unit_ok(units[entry.id]) then
			local unit = World.spawn_unit_ex(world, entry.path, nil, Unit.world_pose(data.unit_3p, 1))

			World.link_unit(world, unit, 1, data.unit_3p, 1, World.LINK_MODE_NODE_NAME)
			settle(unit, data.unit_3p)

			if entry.id == "face" then
				local loadout = data.profile and data.profile.loadout

				face_state_machine(unit, loadout and loadout.slot_body_face, spawner.__nov_face_key)
			end

			units[entry.id] = unit
		end

		Unit.set_unit_visibility(units[entry.id], spawner._visible and true or false, true)
	end

	for id, unit in pairs(units) do
		if not keep[id] then
			if unit_ok(unit) then
				World.destroy_unit(world, unit)
			end

			units[id] = nil
		end
	end

	if spawner._visible and next(units) ~= nil then
		hide_stock(data.slots, "unit_3p", skin_hidden)
	end
end

-- Hooks --------------------------------------------------------------------------

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "init", function (self, extension_init_context, unit, extension_init_data)
	local archetype = extension_init_data and extension_init_data.archetype

	self.__nov_world = extension_init_context and extension_init_context.world
	self.__nov_breed = archetype and archetype.breed
end)

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "_update_item_visibility", function (self, first_person_mode)
	tracked[self] = true
	apply(self, first_person_mode)
end)

mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, "destroy", function (func, self, ...)
	despawn(self)
	tracked[self] = nil

	return func(self, ...)
end)

mod:hook_safe(CLASS.UIProfileSpawner, "_update_items_visibility", function (self)
	ui_apply(self)
end)

mod:hook_safe(CLASS.UIProfileSpawner, "update", function (self)
	local data = self._character_spawn_data

	if data and data.is_ready then
		ui_apply(self)
	end
end)

mod:hook_safe(CLASS.UIProfileSpawner, "assign_face_state_machine", function (self, face_state_machine_key)
	self.__nov_face_key = face_state_machine_key

	local data = self._character_spawn_data
	local units = self.__nov_units
	local loadout = data and data.profile and data.profile.loadout

	if units and units.face and loadout then
		face_state_machine(units.face, loadout.slot_body_face, face_state_machine_key)
	end
end)

mod:hook(CLASS.UIProfileSpawner, "_despawn_current_character_profile", function (func, self, ...)
	ui_despawn(self)

	return func(self, ...)
end)

-- Loading ------------------------------------------------------------------------

local function refresh_all()
	for ext in pairs(tracked) do
		if unit_ok(ext._unit) then
			ext:force_update_item_visibility()
		end
	end

	for spawner in pairs(tracked_ui) do
		ui_apply(spawner)
	end
end

local function request_dauntless()
	if state.requested or not Managers.package then
		return
	end

	state.requested = true

	for _, entry in ipairs(DAUNTLESS_UNITS) do
		local path = entry.path
		local ok, id = pcall(Managers.package.load, Managers.package, path, PACKAGE_REFERENCE, function ()
			state.loaded[path] = true
			refresh_all()
		end, true)

		if ok then
			state.package_ids[#state.package_ids + 1] = id
		else
			mod:error("Novitiate: loading %s failed: %s", path, tostring(id))
		end
	end
end

local function request_lacrima()
	if state.lacrima_requested then
		return
	end

	local custom_assets = get_mod("CustomAssets")

	if not custom_assets or not custom_assets.is_api_compatible or not custom_assets.is_api_compatible(1) then
		mod:info("Novitiate: Custom Assets (API 1) is not available, the Lacrima look is off and Dauntless is used")

		return
	end

	state.lacrima_requested = true

	local ticket, err = custom_assets.acquire(mod, LACRIMA_ASSET, function (_, _, load_error)
		if load_error then
			mod:error("%s failed to load: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", LACRIMA_ASSET, tostring(load_error))

			return
		end

		state.lacrima_ready = true
		refresh_all()
	end, { resident = true, reference_name = LACRIMA_ASSET })

	if not ticket then
		mod:error("%s could not be requested: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", LACRIMA_ASSET, tostring(err))
	end
end

N.on_loaded[#N.on_loaded + 1] = function ()
	request_dauntless()

	if mod:get("visual_mode") == "lacrima" then
		request_lacrima()
	end
end

N.on_update[#N.on_update + 1] = function ()
	if not state.requested then
		request_dauntless()
	end
end

N.on_setting[#N.on_setting + 1] = function (setting_id)
	if setting_id == "visual_mode" and mod:get("visual_mode") == "lacrima" then
		request_lacrima()
	end

	if setting_id == "visual_mode" or setting_id == "visual_hair" or setting_id == "dauntless_face" then
		refresh_all()
	end
end

N.on_roster_changed[#N.on_roster_changed + 1] = function ()
	refresh_all()
end

N.visual_status = function ()
	local loaded = 0

	for _ in pairs(state.loaded) do
		loaded = loaded + 1
	end

	return string.format("Novitiate look: %s (Dauntless units loaded %d/%d, Lacrima %s)", tostring(mod:get("visual_mode") or "dauntless"), loaded, #DAUNTLESS_UNITS, state.lacrima_ready and "ready" or "not loaded")
end

mod.on_disabled = function ()
	for ext in pairs(tracked) do
		despawn(ext)

		if unit_ok(ext._unit) then
			ext:force_update_item_visibility()
		end
	end

	for spawner in pairs(tracked_ui) do
		ui_despawn(spawner)
	end
end

mod.on_unload = function ()
	for ext in pairs(tracked) do
		despawn(ext)
	end

	for spawner in pairs(tracked_ui) do
		ui_despawn(spawner)
	end

	for _, id in ipairs(state.package_ids) do
		pcall(Managers.package.release, Managers.package, id)
	end

	state.package_ids = {}
	state.loaded = {}
	state.requested = false

	local custom_assets = get_mod("CustomAssets")

	if custom_assets and custom_assets.release_owner then
		custom_assets.release_owner(mod)
	end
end
