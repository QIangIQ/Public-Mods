local mod = get_mod("QIangIQsNovitiate")
local N = mod.nov

-- Novitiate emblem in other mods' texts (2026-10-26, "change for all mods").
-- Many mods write the class as a font glyph inside a text, next to the
-- character's name: "<zealot glyph> Saint-Celestine" (who_are_you, TeamKills,
-- GlobalStore, true_level and others). A font glyph cannot become a texture,
-- so every text pass is wrapped: when its text holds the Zealot glyph and the
-- name of one of your Novitiates, the glyph is drawn as spaces and the
-- emblem is drawn in its place with a texture pass of its own. Only that
-- draw call sees the changed text; the mod's own content is left alone.
-- Glyphs drawn as a separate text (no name in the same string) are not
-- touched here; those spots are handled one by one (nov_icons, the
-- scoreboard, the character switcher).

local UIPasses = require("scripts/managers/ui/ui_passes")
local UIRenderer = require("scripts/managers/ui/ui_renderer")
local UISettings = require("scripts/settings/ui/ui_settings")

local UI_BASE = "content/ui/materials/base/ui_default_base"
local SPACES = "      "

local names = {}

-- Names of Novitiate characters, collected wherever their profiles pass
-- through (nov_loadout sees every profile the game builds).
N.note_novitiate_name = function (name, is_novitiate)
	if type(name) == "string" and name ~= "" then
		names[name] = is_novitiate and true or nil
	end
end

local function _symbol()
	local icons = UISettings.archetype_font_icon

	return icons and icons.zealot
end

local function _novitiate_name_in(text)
	for name in pairs(names) do
		if string.find(text, name, 1, true) then
			return true
		end
	end

	return false
end

local function _width(ui_renderer, text, style)
	if text == "" then
		return 0
	end

	local ok, width = pcall(UIRenderer.text_size, ui_renderer, text, style.font_type, style.font_size or 16)

	return ok and tonumber(width) or 0
end

local function _texture_pass(pass)
	local texture_pass = pass.__nov_emblem_pass

	if not texture_pass then
		texture_pass = {
			value_id = "texture",
			style_id = "texture",
		}
		texture_pass.data = UIPasses.texture.init(texture_pass)
		pass.__nov_emblem_pass = texture_pass
		pass.__nov_emblem_style = {
			color = { 255, 255, 255, 255 },
			material_values = {},
		}
		pass.__nov_emblem_content = { texture = UI_BASE }
	end

	return texture_pass, pass.__nov_emblem_style, pass.__nov_emblem_content
end

local function _draw_emblem(pass, ui_renderer, ui_style, text, glyph_start, position, size, emblem)
	local font_size = ui_style.font_size or 16
	local first_line = string.match(text, "^([^\n]*)") or text

	if glyph_start > #first_line then
		return
	end

	local line_width = _width(ui_renderer, first_line, ui_style)
	local before_width = _width(ui_renderer, string.sub(first_line, 1, glyph_start - 1), ui_style)
	local icon = math.floor(font_size + 0.5)
	local align = ui_style.text_horizontal_alignment or "left"
	local valign = ui_style.text_vertical_alignment or "top"
	local x = position[1]
	local y = position[2]
	local width = size and size[1] or line_width
	local height = size and size[2] or font_size

	if align == "center" then
		x = x + (width - line_width) / 2
	elseif align == "right" then
		x = x + width - line_width
	end

	local _, lines = string.gsub(text, "\n", "\n")
	local block = (lines + 1) * font_size * 1.2

	if valign == "center" then
		y = y + (height - block) / 2 + (font_size * 1.2 - icon) / 2
	elseif valign == "bottom" then
		y = y + height - block + (font_size * 1.2 - icon) / 2
	else
		y = y + (font_size * 1.2 - icon) / 2
	end

	local texture_pass, style, content = _texture_pass(pass)
	local text_color = ui_style.text_color

	style.material_values.texture_map = emblem

	if text_color then
		style.color[1] = text_color[1]
		style.color[2] = text_color[2]
		style.color[3] = text_color[3]
		style.color[4] = text_color[4]
	end

	UIPasses.texture.draw(texture_pass, ui_renderer, style, content, Vector3(x + before_width, y, position[3] + 1), Vector2(icon, icon))
end

-- The originals are kept on the pass table, so a mod reload wraps them
-- again instead of wrapping the previous wrapper.
local text_draw = rawget(UIPasses.text, "__nov_original_draw") or UIPasses.text.draw
local text_destroy = rawget(UIPasses.text, "__nov_original_destroy") or UIPasses.text.destroy

UIPasses.text.__nov_original_draw = text_draw
UIPasses.text.__nov_original_destroy = text_destroy

UIPasses.text.draw = function (pass, ui_renderer, ui_style, ui_content, position, size, ...)
	local value_id = pass.data and pass.data.value_id or pass.value_id
	local text = value_id and ui_content[value_id]
	local symbol = next(names) ~= nil and type(text) == "string" and _symbol()
	local s, e

	if symbol then
		s, e = string.find(text, symbol, 1, true)
	end

	if not s or not _novitiate_name_in(text) then
		return text_draw(pass, ui_renderer, ui_style, ui_content, position, size, ...)
	end

	local emblem = N.class_icon_texture and N.class_icon_texture("emblem")

	if not emblem then
		return text_draw(pass, ui_renderer, ui_style, ui_content, position, size, ...)
	end

	local replaced = string.sub(text, 1, s - 1) .. SPACES .. string.sub(text, e + 1)

	ui_content[value_id] = replaced

	local ok, err = pcall(text_draw, pass, ui_renderer, ui_style, ui_content, position, size, ...)

	ui_content[value_id] = text

	if not ok then
		error(err, 0)
	end

	local drawn, draw_err = pcall(_draw_emblem, pass, ui_renderer, ui_style, replaced, s, position, size, emblem)

	if not drawn and not pass.__nov_emblem_error then
		pass.__nov_emblem_error = true
		mod:error("Novitiate glyph emblem: %s", tostring(draw_err))
	end
end

UIPasses.text.destroy = function (pass, ui_renderer, ...)
	local texture_pass = pass.__nov_emblem_pass

	if texture_pass then
		pcall(UIPasses.texture.destroy, texture_pass, ui_renderer)
		pass.__nov_emblem_pass = nil
	end

	return text_destroy(pass, ui_renderer, ...)
end
