local mod = get_mod("QIangIQsNovitiate")
local N = mod.nov

-- Solo loadout for Novitiates (option "solo_unlock"). A new Novitiate is a
-- fresh level 1 Zealot on the backend, so the inventory locks the curio
-- slots (Trust Level 8/16/24) and every item above level 1, also in the
-- Realms local loadout (realms_loadout reads the same profile.current_level).
-- With the option on, Novitiate profiles show and count as level 30 with 30
-- talent points on this machine. Nothing is sent to the backend: on Fatshark
-- servers the real level still applies.
--
-- Also guards a crash to desktop (2026-10-26): realms_loadout's curio forge
-- builds preview items with empty resource_dependencies, so the icon
-- renderer spawned content/weapons/player/attachments/devices/
-- devices_chained_rig without loading it ("Unit not found"). Items with no
-- dependencies get their master item's dependencies and their own units.

local ProfileUtils = require("scripts/utilities/profile_utils")
local ItemPackage = require("scripts/foundation/managers/package/utilities/item_package")
local MasterItems = require("scripts/backend/master_items")

local SOLO_LEVEL = 30
local SOLO_TALENT_POINTS = 30

local function _archetype_name(profile)
	local archetype = profile.archetype

	if type(archetype) == "table" then
		return archetype.name
	end

	return archetype
end

local function _wanted(profile)
	return type(profile) == "table" and mod:get("solo_unlock") ~= false and _archetype_name(profile) == "zealot" and N.is_novitiate_id(profile.character_id)
end

-- Raise (or restore) one profile in place, so views that hold it see it.
local function _apply(profile)
	if type(profile) ~= "table" then
		return
	end

	if N.note_novitiate_name then
		-- Names for nov_glyphs, whatever the solo_unlock option says.
		N.note_novitiate_name(profile.name, _archetype_name(profile) == "zealot" and N.is_novitiate_id(profile.character_id))
	end

	if _wanted(profile) then
		if profile.__nov_real_level == nil then
			profile.__nov_real_level = profile.current_level or 1
			profile.__nov_real_talent_points = profile.talent_points or 0
		end

		if (profile.current_level or 1) < SOLO_LEVEL then
			mod:info("Novitiate solo loadout: %s shown as level %d (real level %s)", tostring(profile.character_id), SOLO_LEVEL, tostring(profile.__nov_real_level))
		end

		profile.current_level = math.max(profile.__nov_real_level, SOLO_LEVEL)
		profile.talent_points = math.max(profile.__nov_real_talent_points, SOLO_TALENT_POINTS)
	elseif profile.__nov_real_level ~= nil then
		profile.current_level = profile.__nov_real_level
		profile.talent_points = profile.__nov_real_talent_points
		profile.__nov_real_level = nil
		profile.__nov_real_talent_points = nil
	end
end

N.apply_solo_level = _apply

mod:hook(ProfileUtils, "character_to_profile", function (func, ...)
	local profile = func(...)

	_apply(profile)

	return profile
end)

mod:hook(ProfileUtils, "backend_profile_data_to_profile", function (func, ...)
	local profile = func(...)

	_apply(profile)

	return profile
end)

local function _player_profile()
	local player_manager = Managers.player
	local player = player_manager and player_manager:local_player_safe(1)
	local ok, profile = pcall(function ()
		return player and player:profile()
	end)

	return ok and profile or nil
end

local function _main_menu_profiles()
	local ui_manager = Managers.ui
	local view = ui_manager and ui_manager:view_instance("main_menu_view")

	if not view then
		return
	end

	_apply(view._selected_profile)

	for name, widget in pairs(view._widgets_by_name or {}) do
		if string.find(name, "^character_slot_") and widget.content then
			_apply(widget.content.profile)
		end
	end
end

local function _refresh()
	_apply(_player_profile())
	pcall(_main_menu_profiles)
end

local poll_t = 0

N.on_update[#N.on_update + 1] = function (dt, t)
	poll_t = poll_t - (dt or 0)

	if poll_t > 0 then
		return
	end

	poll_t = 1

	_apply(_player_profile())
end

N.on_roster_changed[#N.on_roster_changed + 1] = _refresh

N.on_setting[#N.on_setting + 1] = function (setting_id)
	if setting_id == "solo_unlock" or setting_id == "roster_scope" then
		_refresh()
	end
end

-- Crash guard ------------------------------------------------------------------

local function _merge_units(deps, item)
	local keys = { "base_unit", "base_unit_1p", "resource" }

	for i = 1, #keys do
		local unit = item[keys[i]]

		if type(unit) == "string" and unit ~= "" then
			deps[unit] = true
		end
	end
end

mod:hook(ItemPackage, "compile_item_instance_dependencies", function (func, item, items_dictionary, out_result, ...)
	if type(item) == "table" then
		local deps = item.resource_dependencies

		if type(deps) ~= "table" or next(deps) == nil then
			local fixed = {}
			local ok, master = pcall(MasterItems.get_item, item.name)

			if ok and type(master) == "table" and type(master.resource_dependencies) == "table" then
				for dependency, _ in pairs(master.resource_dependencies) do
					fixed[dependency] = true
				end
			end

			_merge_units(fixed, item)

			if next(fixed) ~= nil then
				local copy = table.shallow_copy(item)

				copy.resource_dependencies = fixed

				return func(copy, items_dictionary, out_result, ...)
			end
		end
	end

	return func(item, items_dictionary, out_result, ...)
end)
