local mod = get_mod("QIangIQsNovitiate")
local N = mod.nov

-- The Novitiate talent tree. Replaces the Zealot layout while it is wanted
-- and the character in use is a Novitiate (nov_roster.lua)
-- (same technique as QIangIQsPoE2Tree and QIangIQsMartyrdom): the official
-- start, tactical, aura and ability nodes stay (cloned) in an arc over the
-- start node because the class loadout comes from them (character_sheet.lua
-- class_loadout). Below the start node the tree is built like the official
-- ones: mirrored sections joined by hub nodes and horizontal bars, in three
-- lanes of two disciplines, left to right:
--
--   close range:  Zeal (melee offence), Pyre (fire, burning)
--                 with the Penitent Pyre ability
--   support:      Aegis (guard, mitigation), Resolve (health, sustain,
--                 coherency) with the Deflect ability
--   ranged:       Penance (chain, control, mobility), Judgement (ranged
--                 offence) with the Chain Hook ability
--
-- Neighbouring disciplines share seam nodes with hybrid stats and two coded
-- synergy notables. Links have no direction, so builds can grow up, down
-- and sideways. Every discipline has
-- 5 notables and a keystone on the bottom row. The talent string stores
-- nodes by index (talent_layout_parser.lua pack_backend_data), so
-- layout.version changes while this tree is on and builds of the official
-- tree are dropped.
--
-- Gameplay runs where the game runs talents: on the host. On Fatshark's
-- mission servers nothing here runs and the tree is the official one.

local BuffSettings = require("scripts/settings/buff/buff_settings")
local BuffTemplates = require("scripts/settings/buff/buff_templates")
local ArchetypeTalents = require("scripts/settings/ability/archetype_talents/archetype_talents")

local stat_buffs = BuffSettings.stat_buffs

local LAYOUT_PATH = "scripts/ui/views/talent_builder_view/layouts/zealot_tree"
local VERSION_OFFSET = 2500
local ICON_STAT = "content/ui/textures/frames/talents/circular_small_frame"
local ICON_PATH = "content/ui/textures/icons/talents/zealot/"
local AUGMENT_GRADIENT = "content/ui/textures/color_ramps/class_node_colors/zealot_01"
local HUB_TYPES = {
	ability = true,
	aura = true,
	start = true,
	tactical = true,
}

-- ####################################################################
-- Stats: key -> label, kind. Kinds: A additive multiplier (0.03 = +3%),
-- M multiplicative multiplier (0.95 = 5% less), P value shown as percent
-- points, F plain value. Types as buff_settings.lua stat_buff_types.
-- ####################################################################

local STATS = {
	ability_extra_charges = { "Ability Charge", "F" },
	attack_speed = { "Attack Speed", "A" },
	backstab_damage = { "Backstab Damage", "A" },
	block_cost_multiplier = { "Block Cost", "M" },
	burning_damage = { "Burning Damage", "A" },
	coherency_radius_modifier = { "Coherency Radius", "A" },
	combat_ability_resource_regen_modifier = { "Ability Cooldown Rate", "A" },
	critical_strike_chance = { "Critical Hit Chance", "P" },
	critical_strike_damage = { "Critical Hit Damage", "A" },
	damage_taken_multiplier = { "Damage Taken", "M" },
	damage_vs_burning = { "Damage vs Burning Enemies", "A" },
	damage_vs_elites = { "Damage vs Elites", "A" },
	damage_vs_horde = { "Damage vs Hordes", "A" },
	damage_vs_monsters = { "Damage vs Monstrosities", "A" },
	damage_vs_specials = { "Damage vs Specialists", "A" },
	damage_vs_staggered = { "Damage vs Staggered Enemies", "A" },
	dodge_distance_modifier = { "Dodge Distance", "A" },
	flanking_damage = { "Flanking Damage", "A" },
	healing_recieved_modifier = { "Healing Received", "A" },
	impact_modifier = { "Impact", "A" },
	max_health_modifier = { "Maximum Health", "A" },
	melee_attack_speed = { "Melee Attack Speed", "A" },
	melee_critical_strike_chance = { "Melee Critical Hit Chance", "P" },
	melee_damage = { "Melee Damage", "A" },
	melee_damage_taken_multiplier = { "Melee Damage Taken", "M" },
	melee_heavy_damage = { "Heavy Melee Damage", "A" },
	melee_weakspot_damage = { "Melee Weak Spot Damage", "A" },
	movement_speed = { "Movement Speed", "A" },
	push_cost_multiplier = { "Push Stamina Cost", "M" },
	ammo_reserve_capacity = { "Ammo Reserve", "A" },
	ranged_attack_speed = { "Ranged Attack Speed", "A" },
	ranged_critical_strike_chance = { "Ranged Critical Hit Chance", "P" },
	ranged_critical_strike_damage = { "Ranged Critical Hit Damage", "A" },
	ranged_damage = { "Ranged Damage", "A" },
	ranged_damage_far = { "Ranged Damage at Long Range", "A" },
	ranged_impact_modifier = { "Ranged Impact", "A" },
	ranged_weakspot_damage = { "Ranged Weak Spot Damage", "A" },
	recoil_modifier = { "Recoil", "A" },
	reload_speed = { "Reload Speed", "A" },
	spread_modifier = { "Spread", "A" },
	suppression_dealt = { "Suppression", "A" },
	ranged_damage_taken_multiplier = { "Ranged Damage Taken", "M" },
	revive_speed_modifier = { "Revive Speed", "A" },
	sprint_movement_speed = { "Sprint Speed", "A" },
	stamina_modifier = { "Stamina", "F" },
	stamina_regeneration_modifier = { "Stamina Regeneration", "A" },
	toughness_bonus = { "Toughness", "A" },
	toughness_damage_taken_multiplier = { "Toughness Damage Taken", "M" },
	toughness_melee_replenish = { "Toughness from Melee", "A" },
	toughness_regen_rate_modifier = { "Toughness Regeneration", "A" },
	toughness_replenish_modifier = { "Toughness Replenished", "A" },
	wield_speed = { "Weapon Swap Speed", "A" },
}

local function _num(x)
	local text = string.format("%.1f", x)

	return (string.gsub(text, "%.0$", ""))
end

-- One line of text for a stat value. A negative A/P value is a drawback.
local function _stat_line(stat, value)
	local def = STATS[stat]
	local label = def and def[1] or stat
	local kind = def and def[2] or "A"

	if kind == "M" then
		local delta = (1 - value) * 100

		if delta >= 0 then
			return string.format("-%s%% %s", _num(delta), label)
		end

		return string.format("+%s%% %s", _num(-delta), label)
	elseif kind == "F" then
		return string.format("%s%s %s", value >= 0 and "+" or "", _num(value), label)
	end

	return string.format("%s%s%% %s", value >= 0 and "+" or "", _num(value * 100), label)
end

-- ####################################################################
-- Lane data
-- ####################################################################

-- Minor pool entries: { name, stat, value }. Notables: { name, stats, text?,
-- proc? }. Keystone: { name, stats, text }.
local LANES = {
	{
		key = "pen",
		name = "Penance",
		ability = "hook",
		minors = {
			{ "Pilgrim's Stride", "movement_speed", 0.02 },
			{ "Chain-Wrought Blows", "damage_vs_elites", 0.03 },
			{ "Penitent Iron", "toughness_bonus", 0.04 },
			{ "Scourge Swing", "attack_speed", 0.02 },
			{ "Binding Mercy", "impact_modifier", 0.06 },
			{ "Chain-Shot", "ranged_impact_modifier", 0.06 },
		},
		notables = {
			{ "Rattling Links", { { "damage_vs_staggered", 0.12 }, { "impact_modifier", 0.1 } } },
			{ "Penitent Gait", { { "movement_speed", 0.05 }, { "sprint_movement_speed", 0.06 } } },
			{ "Dragged to Judgement", { { "damage_vs_specials", 0.15 }, { "damage_vs_monsters", 0.1 } } },
			{ "Barbed Faith", { { "melee_critical_strike_chance", 0.06 }, { "critical_strike_damage", 0.1 } } },
			{ "Quickened Penance", {}, nil, "quickened_penance", "On using a combat ability: +20% Movement Speed and +12% Attack Speed for 6 seconds." },
		},
		keystone = { "Warden of Chains", { { "combat_ability_resource_regen_modifier", 0.35 }, { "ability_extra_charges", 1 }, { "max_health_modifier", -0.15 } } },
	},
	{
		key = "aeg",
		name = "Aegis",
		ability = "deflect",
		minors = {
			{ "Shielded Hymn", "toughness_bonus", 0.04 },
			{ "Steadfast Prayer", "damage_taken_multiplier", 0.98 },
			{ "Guarded Stance", "block_cost_multiplier", 0.95 },
			{ "Hardy Vigil", "max_health_modifier", 0.03 },
			{ "Mended Resolve", "toughness_melee_replenish", 0.05 },
			{ "Bastion Breath", "stamina_modifier", 0.5 },
		},
		notables = {
			{ "Shield of Faith", { { "melee_damage_taken_multiplier", 0.92 }, { "toughness_bonus", 0.1 } } },
			{ "Bulwark Litany", { { "block_cost_multiplier", 0.8 }, { "stamina_modifier", 2 } } },
			{ "Unflinching", { { "toughness_damage_taken_multiplier", 0.9 }, { "ranged_damage_taken_multiplier", 0.92 } } },
			{ "Absolution", {}, nil, "absolution", "Melee kills restore 5% of your toughness." },
			{ "Martyr's Patience", { { "toughness_regen_rate_modifier", 0.2 }, { "push_cost_multiplier", 0.8 } } },
		},
		keystone = { "Aegis Incarnate", { { "damage_taken_multiplier", 0.8 }, { "combat_ability_resource_regen_modifier", 0.25 }, { "movement_speed", -0.1 } } },
	},
	{
		key = "pyr",
		name = "Pyre",
		ability = "pyre",
		minors = {
			{ "Kindled Hands", "damage_vs_burning", 0.04 },
			{ "Searing Faith", "burning_damage", 0.06 },
			{ "Ember Strikes", "melee_damage", 0.02 },
			{ "Quick Flame", "attack_speed", 0.015 },
			{ "Ashen Skin", "toughness_bonus", 0.03 },
			{ "Cinder Step", "movement_speed", 0.015 },
		},
		notables = {
			{ "Kindled Wrath", { { "damage_vs_burning", 0.2 }, { "burning_damage", 0.15 } } },
			{ "Cinder Walk", { { "movement_speed", 0.06 }, { "toughness_regen_rate_modifier", 0.1 } } },
			{ "Ash and Ember", {}, nil, "ash_and_ember", "Killing an elite or specialist restores 8% toughness and gives +20% Damage vs Burning Enemies for 8 seconds." },
			{ "Pyrolatry", { { "burning_damage", 0.3 }, { "damage_vs_horde", 0.08 } } },
			{ "Sear", { { "melee_critical_strike_chance", 0.08 }, { "critical_strike_damage", 0.1 } } },
		},
		keystone = { "Pillar of Fire", { { "damage_vs_burning", 0.35 }, { "combat_ability_resource_regen_modifier", 0.3 }, { "toughness_bonus", -0.1 } } },
	},
	{
		key = "res",
		name = "Resolve",
		minors = {
			{ "Hardy Pilgrim", "max_health_modifier", 0.03 },
			{ "Tended Wounds", "healing_recieved_modifier", 0.05 },
			{ "Second Wind", "toughness_regen_rate_modifier", 0.05 },
			{ "Quick Aid", "revive_speed_modifier", 0.06 },
			{ "Stout Heart", "damage_taken_multiplier", 0.985 },
			{ "Wide Congregation", "coherency_radius_modifier", 0.05 },
		},
		notables = {
			{ "Iron Constitution", { { "max_health_modifier", 0.1 }, { "toughness_bonus", 0.05 } } },
			{ "Mend the Faithful", { { "healing_recieved_modifier", 0.2 }, { "revive_speed_modifier", 0.2 } } },
			{ "Sermon of Haste", { { "combat_ability_resource_regen_modifier", 0.15 }, { "coherency_radius_modifier", 0.2 } } },
			{ "Litany's Aftermath", {}, nil, "litany_aftermath", "On using a combat ability: -15% Damage Taken and +25% Toughness Replenished for 6 seconds." },
			{ "Last Stand", { { "toughness_replenish_modifier", 0.2 }, { "toughness_melee_replenish", 0.1 } } },
		},
		keystone = { "Undying Zeal", { { "max_health_modifier", 0.25 }, { "toughness_bonus", 0.15 }, { "attack_speed", -0.05 } } },
	},
	{
		key = "zea",
		name = "Zeal",
		minors = {
			{ "Righteous Blows", "melee_damage", 0.03 },
			{ "Quick Devotion", "attack_speed", 0.015 },
			{ "Keen Eye", "melee_critical_strike_chance", 0.015 },
			{ "Reaper's Prayer", "damage_vs_horde", 0.04 },
			{ "Precise Fury", "melee_weakspot_damage", 0.04 },
			{ "Cutting Edge", "backstab_damage", 0.05 },
		},
		notables = {
			{ "Righteous Fury", { { "melee_damage", 0.1 }, { "attack_speed", 0.04 } } },
			{ "Executioner", { { "damage_vs_elites", 0.12 }, { "melee_weakspot_damage", 0.15 } } },
			{ "Bloodied Hymn", {}, nil, "bloodied_hymn", "Killing an elite gives +15% Attack Speed for 6 seconds." },
			{ "Dead-Eye Faith", {}, nil, "dead_eye_faith", "Weak spot kills give +15% Critical Hit Chance for 4 seconds." },
			{ "Flank the Heretic", { { "backstab_damage", 0.25 }, { "flanking_damage", 0.15 } } },
		},
		keystone = { "Fanatic", { { "melee_damage", 0.2 }, { "attack_speed", 0.1 }, { "toughness_bonus", -0.2 } } },
	},
	{
		key = "dom",
		name = "Judgement",
		minors = {
			{ "Sanctified Shot", "ranged_damage", 0.03 },
			{ "Swift Rounds", "reload_speed", 0.05 },
			{ "Hallowed Sights", "ranged_weakspot_damage", 0.05 },
			{ "Measured Fire", "spread_modifier", -0.06 },
			{ "Deep Satchel", "ammo_reserve_capacity", 0.05 },
			{ "Firm Grip", "recoil_modifier", -0.06 },
		},
		notables = {
			{ "Inquisitorial Volley", { { "ranged_damage", 0.1 }, { "ranged_attack_speed", 0.05 } } },
			{ "Penitent Marksman", { { "ranged_weakspot_damage", 0.15 }, { "ranged_critical_strike_chance", 0.05 } } },
			{ "Purging Rounds", { { "ranged_damage_far", 0.12 }, { "suppression_dealt", 0.2 } } },
			{ "Swift Judgement", { { "reload_speed", 0.15 }, { "wield_speed", 0.1 } } },
			{ "Heretic's Bane", { { "ranged_critical_strike_damage", 0.15 }, { "ammo_reserve_capacity", 0.1 } } },
		},
		keystone = { "Inquisitor's Verdict", { { "ranged_damage", 0.2 }, { "ranged_weakspot_damage", 0.2 }, { "melee_damage", -0.1 } } },
	},
}

-- Zealot icons the current zealot_tree.lua uses, for notables and keystones
-- without a coded proc.
local NOTABLE_ICONS = {
	"zealot_damage_vs_elites",
	"zealot_toughness_in_melee",
	"zealot_improved_sprint",
	"zealot_backstab_damage",
	"zealot_dodge_improvements",
	"zealot_hits_grant_stacking_damage",
	"zealot_reduced_damage_on_wound",
	"zealot_heal_part_of_damage_taken",
	"zealot_always_in_coherency",
	"zealot_crits_grant_cd",
	"zealot_damage_after_heavy_attack",
	"zealot_cleave_impact_post_push",
	"zealot_increased_damage_vs_resilient",
	"zealot_toughness_on_dodge",
}
local KEYSTONE_ICONS = {
	pen = "zealot_keystone_quickness",
	aeg = "zealot_keystone_martyrdom",
	pyr = "zealot_fire_and_fury",
	res = "zealot_resist_death",
	zea = "zealot_keystone_fanatic_rage",
	dom = "zealot_shared_fanatic_rage",
}

-- ####################################################################
-- Synergy and hybrid data: where two neighbouring disciplines meet
-- ####################################################################

-- Bands from left to right, in three lanes of two like the official trees:
--   close range (Zeal, Pyre) with Penitent Pyre,
--   support (Aegis, Resolve) with Deflect,
--   ranged (Penance, Judgement) with Chain Hook.
-- Each neighbouring pair shares a seam of hybrid nodes; the seams hold the
-- coded synergy notables (nov_passives.lua).
local BAND_ORDER = { "zea", "pyr", "aeg", "res", "pen", "dom" }

-- Seam k sits between BAND_ORDER[k] and BAND_ORDER[k + 1]. Minors: { name,
-- stat, value, stat, value }. Synergies: proc keys with their text.
local SEAMS = {
	-- Zeal | Pyre (inside the close range lane)
	{
		minors = {
			{ "Ember Edge", "melee_damage", 0.015, "damage_vs_burning", 0.03 },
			{ "Ashen Fervour", "attack_speed", 0.01, "burning_damage", 0.04 },
			{ "Kindled Strike", "melee_critical_strike_chance", 0.01, "damage_vs_burning", 0.02 },
		},
		synergies = {
			{ "burning_zeal", "Killing a burning enemy gives +8% Attack Speed and +10% Melee Damage for 6 seconds." },
			{ "searing_edge", "Melee critical hits set the target on fire (2 stacks of burning)." },
		},
	},
	-- Pyre | Aegis (close range meets support)
	{
		minors = {
			{ "Ashen Guard", "burning_damage", 0.04, "block_cost_multiplier", 0.97 },
			{ "Smouldering Hide", "toughness_bonus", 0.02, "damage_vs_burning", 0.03 },
			{ "Censer Stance", "damage_taken_multiplier", 0.99, "burning_damage", 0.03 },
		},
		synergies = {
			{ "sermon_of_ash", "On using a combat ability, every enemy within 5 metres catches fire (3 stacks of burning)." },
			{ "chained_guard", "Push hits give +15% Damage vs Staggered Enemies and +20% Impact for 5 seconds." },
		},
	},
	-- Aegis | Resolve (inside the support lane)
	{
		minors = {
			{ "Scarred Guard", "max_health_modifier", 0.02, "block_cost_multiplier", 0.97 },
			{ "Patient Flesh", "toughness_regen_rate_modifier", 0.04, "damage_taken_multiplier", 0.99 },
			{ "Steadfast Body", "healing_recieved_modifier", 0.04, "toughness_bonus", 0.02 },
		},
		synergies = {
			{ "flesh_as_bulwark", "Perfect blocks restore 6% toughness and give -8% Damage Taken for 4 seconds." },
			{ "scar_tissue", "When your toughness breaks: -20% Damage Taken and +50% Toughness Regeneration for 5 seconds." },
		},
	},
	-- Resolve | Penance (support meets ranged)
	{
		minors = {
			{ "Pilgrim's Mercy", "healing_recieved_modifier", 0.04, "movement_speed", 0.01 },
			{ "Tethered Faith", "coherency_radius_modifier", 0.04, "impact_modifier", 0.03 },
			{ "Bound in Prayer", "toughness_regen_rate_modifier", 0.04, "damage_vs_staggered", 0.03 },
		},
		synergies = {
			{ "shackled_shield", "On using a combat ability: -40% Block Cost, -40% Push Stamina Cost and +20% Impact for 8 seconds." },
			{ "watchful_penitent", "Killing an elite or specialist with a ranged attack restores 8% toughness and gives +20% Coherency Radius and +15% Toughness Replenished for 5 seconds." },
		},
	},
	-- Penance | Judgement (inside the ranged lane)
	{
		minors = {
			{ "Barbed Rounds", "ranged_damage", 0.015, "damage_vs_staggered", 0.03 },
			{ "Hunter's Pace", "movement_speed", 0.01, "reload_speed", 0.03 },
			{ "Dragged Aim", "impact_modifier", 0.03, "ranged_weakspot_damage", 0.03 },
		},
		synergies = {
			{ "scourge_of_the_bound", "Killing a staggered enemy gives +10% Attack Speed and +10% Movement Speed for 4 seconds." },
			{ "marked_for_judgement", "Ranged weak spot hits give +12% Ranged Damage and +10% Reload Speed for 5 seconds." },
		},
	},
}

-- ####################################################################
-- Geometry: stacked mirrored sections, like the official trees
-- ####################################################################

-- Laid out by hand from measurements of the six official class trees
-- (talent_builder_view/layouts/*_tree.lua): they are mirror-symmetric
-- (about 95% of nodes have a mirror twin), made of stacked sections joined
-- by single hub nodes, with long horizontal bars across the lanes, three
-- lane clusters at the bottom ending in keystones, and links that are
-- mostly vertical, 45 degree or horizontal, about 150 apart. This tree is
-- bigger than theirs and links its lanes more: connector nodes sit in the
-- gaps between the lane clusters and a column runs down each outer edge.
--
-- Here, top to bottom:
--   crown:  a mirrored cluster under the start node, closing on one hub;
--   bar:    the hub fans out to the three lane heads on a horizontal bar;
--   middle: one cluster per lane, each ending on its combat ability
--           (Penitent Pyre left, Deflect centre, Chain Hook right) with
--           its augments fanned beneath;
--   bar:    a second horizontal bar, reached past the abilities through
--           the seam nodes, so no ability stands in the way;
--   bottom: one cluster per lane with the two keystones of its disciplines.
--
-- Positions are offsets from the start node; the right half mirrors the
-- left. Codes: z p a r n d discipline minor (Zeal, Pyre, Aegis, Resolve,
-- Penance, Judgement), upper case a notable of that discipline, 1-5 a seam
-- minor between two disciplines (seam k sits between BAND_ORDER[k] and
-- BAND_ORDER[k + 1]), 6 7 8 9 0 a synergy notable of seam 1 2 3 4 5,
-- $ a keystone (left to right in BAND_ORDER), @ an ability, + an augment
-- (ability, index). The list order is the node order of the talent string.
-- Links have no direction, so builds grow up, down and sideways.

local CX = 1500
local START_Y = 560
local RING_RADIUS = 250

local LAYOUT = {
	{ "k1", -240, 110, "p" },
	{ "c1", 0, 110, "3" },
	{ "k1'", 240, 110, "n" },
	{ "k2", -370, 220, "Z" },
	{ "k3", -120, 220, "A" },
	{ "k3'", 120, 220, "R" },
	{ "k2'", 370, 220, "D" },
	{ "k7", -490, 330, "z" },
	{ "k4", -240, 330, "P" },
	{ "c2", 0, 330, "8" },
	{ "k4'", 240, 330, "N" },
	{ "k7'", 490, 330, "d" },
	{ "k5", -370, 440, "z" },
	{ "k6", -120, 440, "a" },
	{ "k6'", 120, 440, "r" },
	{ "k5'", 370, 440, "d" },
	{ "c3", 0, 550, "3" },
	{ "h1", -600, 660, "1" },
	{ "s1", -300, 660, "7" },
	{ "h0", 0, 660, "3" },
	{ "s1'", 300, 660, "9" },
	{ "h1'", 600, 660, "5" },
	{ "mo1", -750, 770, "z" },
	{ "mi1", -450, 770, "P" },
	{ "g1", -345, 770, "2" },
	{ "cm1", -120, 770, "a" },
	{ "cm1'", 120, 770, "r" },
	{ "g1'", 345, 770, "4" },
	{ "mi1'", 450, 770, "N" },
	{ "mo1'", 750, 770, "d" },
	{ "mo2", -750, 880, "Z" },
	{ "mc2", -600, 880, "6" },
	{ "mi2", -450, 880, "p" },
	{ "cm2", -240, 880, "A" },
	{ "cm3", 0, 880, "3" },
	{ "cm2'", 240, 880, "R" },
	{ "mi2'", 450, 880, "n" },
	{ "mc2'", 600, 880, "0" },
	{ "mo2'", 750, 880, "D" },
	{ "fo1", -890, 935, "z" },
	{ "fo1'", 890, 935, "d" },
	{ "mo3", -750, 990, "z" },
	{ "mi3", -450, 990, "P" },
	{ "g2", -345, 990, "2" },
	{ "cm4", -120, 990, "a" },
	{ "cm4'", 120, 990, "r" },
	{ "g2'", 345, 990, "4" },
	{ "mi3'", 450, 990, "N" },
	{ "mo3'", 750, 990, "d" },
	{ "fo2", -890, 1045, "z" },
	{ "fo2'", 890, 1045, "d" },
	{ "mo4", -750, 1100, "Z" },
	{ "mc4", -600, 1100, "1" },
	{ "mi4", -450, 1100, "p" },
	{ "cm5", -240, 1100, "A" },
	{ "cm6", 0, 1100, "3" },
	{ "cm5'", 240, 1100, "R" },
	{ "mi4'", 450, 1100, "n" },
	{ "mc4'", 600, 1100, "5" },
	{ "mo4'", 750, 1100, "D" },
	{ "mo5", -750, 1210, "z" },
	{ "mt", -600, 1210, "1" },
	{ "mi5", -450, 1210, "p" },
	{ "cm7", -240, 1210, "a" },
	{ "cmt", 0, 1210, "3" },
	{ "cm7'", 240, 1210, "r" },
	{ "mi5'", 450, 1210, "n" },
	{ "mt'", 600, 1210, "5" },
	{ "mo5'", 750, 1210, "d" },
	{ "pl", -600, 1320, "@", "pyre" },
	{ "pc", 0, 1320, "@", "deflect" },
	{ "pl'", 600, 1320, "@", "hook" },
	{ "ah0", 435, 1415, "+", "hook", 1 },
	{ "ah4", 765, 1415, "+", "hook", 5 },
	{ "ap0", -715, 1416, "+", "pyre", 1 },
	{ "ap2", -485, 1416, "+", "pyre", 3 },
	{ "fo3", -890, 1430, "z" },
	{ "fo3'", 890, 1430, "d" },
	{ "ad0", -96, 1435, "+", "deflect", 1 },
	{ "ad1", 96, 1435, "+", "deflect", 2 },
	{ "ap1", -600, 1470, "+", "pyre", 2 },
	{ "ah1", 505, 1485, "+", "hook", 2 },
	{ "ah3", 695, 1485, "+", "hook", 4 },
	{ "ah2", 600, 1510, "+", "hook", 3 },
	{ "b1", -600, 1650, "1" },
	{ "bs", -300, 1650, "7" },
	{ "b0", 0, 1650, "3" },
	{ "bs'", 300, 1650, "9" },
	{ "b1'", 600, 1650, "5" },
	{ "lo1", -770, 1760, "z" },
	{ "li1", -430, 1760, "p" },
	{ "co1", -120, 1760, "a" },
	{ "co1'", 120, 1760, "r" },
	{ "li1'", 430, 1760, "n" },
	{ "lo1'", 770, 1760, "d" },
	{ "g3", -335, 1815, "2" },
	{ "g3'", 335, 1815, "4" },
	{ "lo2", -770, 1870, "Z" },
	{ "lc2", -600, 1870, "1" },
	{ "li2", -430, 1870, "P" },
	{ "co2", -240, 1870, "A" },
	{ "cc2", 0, 1870, "8" },
	{ "co2'", 240, 1870, "R" },
	{ "li2'", 430, 1870, "N" },
	{ "lc2'", 600, 1870, "5" },
	{ "lo2'", 770, 1870, "D" },
	{ "fb1", -910, 1980, "z" },
	{ "lo3", -770, 1980, "z" },
	{ "li3", -430, 1980, "p" },
	{ "co3", -120, 1980, "a" },
	{ "co3'", 120, 1980, "r" },
	{ "li3'", 430, 1980, "n" },
	{ "lo3'", 770, 1980, "d" },
	{ "fb1'", 910, 1980, "d" },
	{ "g4", -335, 2035, "2" },
	{ "g4'", 335, 2035, "4" },
	{ "lo4", -770, 2090, "Z" },
	{ "lc4", -600, 2090, "6" },
	{ "li4", -430, 2090, "P" },
	{ "co4", -240, 2090, "A" },
	{ "cc4", 0, 2090, "3" },
	{ "co4'", 240, 2090, "R" },
	{ "li4'", 430, 2090, "N" },
	{ "lc4'", 600, 2090, "0" },
	{ "lo4'", 770, 2090, "D" },
	{ "fb2", -910, 2200, "z" },
	{ "lo5", -770, 2200, "z" },
	{ "li5", -430, 2200, "p" },
	{ "co5", -120, 2200, "a" },
	{ "co5'", 120, 2200, "r" },
	{ "li5'", 430, 2200, "n" },
	{ "lo5'", 770, 2200, "d" },
	{ "fb2'", 910, 2200, "d" },
	{ "g5", -335, 2255, "2" },
	{ "g5'", 335, 2255, "4" },
	{ "lo6", -770, 2310, "z" },
	{ "lc6", -600, 2310, "1" },
	{ "li6", -430, 2310, "p" },
	{ "co6", -240, 2310, "a" },
	{ "cc6", 0, 2310, "3" },
	{ "co6'", 240, 2310, "r" },
	{ "li6'", 430, 2310, "n" },
	{ "lc6'", 600, 2310, "5" },
	{ "lo6'", 770, 2310, "d" },
	{ "ko", -770, 2450, "$" },
	{ "ki", -430, 2450, "$" },
	{ "kc", -160, 2450, "$" },
	{ "kc'", 160, 2450, "$" },
	{ "ki'", 430, 2450, "$" },
	{ "ko'", 770, 2450, "$" },
}

-- Augments are not listed: each one links to its ability only.
local LINKS = {
	{ "S", "k1" }, { "S", "c1" }, { "S", "k1'" }, { "k1", "k2" }, { "k1", "k3" },
	{ "k1", "k4" }, { "c1", "k3" }, { "c1", "k3'" }, { "k1'", "k3'" }, { "k1'", "k2'" },
	{ "k1'", "k4'" }, { "k2", "k7" }, { "k2", "k4" }, { "k2", "k5" }, { "k3", "k3'" },
	{ "k3", "k4" }, { "k3", "c2" }, { "k3'", "c2" }, { "k3'", "k4'" }, { "k2'", "k4'" },
	{ "k2'", "k7'" }, { "k2'", "k5'" }, { "k7", "k5" }, { "k4", "k5" }, { "k4", "k6" },
	{ "c2", "c3" }, { "k4'", "k6'" }, { "k4'", "k5'" }, { "k7'", "k5'" }, { "k5", "h1" },
	{ "k6", "k6'" }, { "k6", "c3" }, { "k6", "s1" }, { "k6'", "c3" }, { "k6'", "s1'" },
	{ "k5'", "h1'" }, { "c3", "s1" }, { "c3", "h0" }, { "c3", "s1'" }, { "h1", "s1" },
	{ "h1", "mo1" }, { "h1", "mi1" }, { "h1", "mc2" }, { "s1", "h0" }, { "s1", "g1" },
	{ "h0", "s1'" }, { "h0", "cm1" }, { "h0", "cm1'" }, { "h0", "cm3" }, { "s1'", "h1'" },
	{ "s1'", "g1'" }, { "h1'", "mi1'" }, { "h1'", "mo1'" }, { "h1'", "mc2'" },
	{ "mo1", "mo2" }, { "mo1", "fo1" }, { "mi1", "g1" }, { "mi1", "mi2" },
	{ "g1", "cm1" }, { "g1", "cm2" }, { "cm1", "cm2" }, { "cm1", "cm3" },
	{ "cm1'", "g1'" }, { "cm1'", "cm3" }, { "cm1'", "cm2'" }, { "g1'", "mi1'" },
	{ "g1'", "cm2'" }, { "mi1'", "mi2'" }, { "mo1'", "mo2'" }, { "mo1'", "fo1'" },
	{ "mo2", "mc2" }, { "mo2", "mo3" }, { "mc2", "mi2" }, { "mc2", "mo3" },
	{ "mc2", "mi3" }, { "mi2", "cm2" }, { "mi2", "mi3" }, { "cm2", "cm4" },
	{ "cm3", "cm4" }, { "cm3", "cm4'" }, { "cm2'", "mi2'" }, { "cm2'", "cm4'" },
	{ "mi2'", "mc2'" }, { "mi2'", "mi3'" }, { "mc2'", "mo2'" }, { "mc2'", "mi3'" },
	{ "mc2'", "mo3'" }, { "mo2'", "mo3'" }, { "fo1", "fo2" }, { "fo1'", "fo2'" },
	{ "mo3", "mo4" }, { "mo3", "mc4" }, { "mi3", "g2" }, { "mi3", "mc4" },
	{ "mi3", "mi4" }, { "g2", "cm4" }, { "g2", "mi4" }, { "cm4", "cm4'" },
	{ "cm4", "cm5" }, { "cm4", "cm6" }, { "cm4'", "g2'" }, { "cm4'", "cm6" },
	{ "cm4'", "cm5'" }, { "g2'", "mi3'" }, { "g2'", "mi4'" }, { "mi3'", "mi4'" },
	{ "mi3'", "mc4'" }, { "mo3'", "mc4'" }, { "mo3'", "mo4'" }, { "fo2", "mo4" },
	{ "fo2", "fo3" }, { "fo2'", "mo4'" }, { "fo2'", "fo3'" }, { "mo4", "mc4" },
	{ "mo4", "mo5" }, { "mo4", "mt" }, { "mc4", "mi4" }, { "mi4", "cm5" },
	{ "mi4", "mt" }, { "mi4", "mi5" }, { "cm5", "cm7" }, { "cm5", "cmt" },
	{ "cm6", "cmt" }, { "cm5'", "mi4'" }, { "cm5'", "cmt" }, { "cm5'", "cm7'" },
	{ "mi4'", "mc4'" }, { "mi4'", "mi5'" }, { "mi4'", "mt'" }, { "mc4'", "mo4'" },
	{ "mo4'", "mt'" }, { "mo4'", "mo5'" }, { "mo5", "mt" }, { "mt", "mi5" },
	{ "mt", "pl" }, { "mi5", "bs" }, { "cm7", "cmt" }, { "cm7", "bs" }, { "cmt", "cm7'" },
	{ "cmt", "pc" }, { "cm7'", "bs'" }, { "mi5'", "mt'" }, { "mi5'", "bs'" },
	{ "mt'", "mo5'" }, { "mt'", "pl'" }, { "fo3", "b1" }, { "fo3'", "b1'" },
	{ "b1", "bs" }, { "b1", "lo1" }, { "b1", "li1" }, { "b1", "lc2" }, { "bs", "b0" },
	{ "bs", "g3" }, { "b0", "bs'" }, { "b0", "co1" }, { "b0", "co1'" }, { "b0", "cc2" },
	{ "bs'", "b1'" }, { "bs'", "g3'" }, { "b1'", "li1'" }, { "b1'", "lo1'" },
	{ "b1'", "lc2'" }, { "lo1", "lo2" }, { "li1", "g3" }, { "li1", "li2" },
	{ "co1", "g3" }, { "co1", "co2" }, { "co1", "cc2" }, { "co1'", "g3'" },
	{ "co1'", "cc2" }, { "co1'", "co2'" }, { "li1'", "g3'" }, { "li1'", "li2'" },
	{ "lo1'", "lo2'" }, { "g3", "li2" }, { "g3", "co2" }, { "g3'", "co2'" },
	{ "g3'", "li2'" }, { "lo2", "lc2" }, { "lo2", "fb1" }, { "lo2", "lo3" },
	{ "lc2", "li2" }, { "lc2", "lo3" }, { "lc2", "li3" }, { "li2", "li3" },
	{ "co2", "co3" }, { "cc2", "co3" }, { "cc2", "co3'" }, { "cc2", "cc4" },
	{ "co2'", "co3'" }, { "li2'", "lc2'" }, { "li2'", "li3'" }, { "lc2'", "lo2'" },
	{ "lc2'", "li3'" }, { "lc2'", "lo3'" }, { "lo2'", "lo3'" }, { "lo2'", "fb1'" },
	{ "fb1", "lo4" }, { "lo3", "lo4" }, { "lo3", "lc4" }, { "li3", "g4" },
	{ "li3", "lc4" }, { "li3", "li4" }, { "co3", "co3'" }, { "co3", "g4" },
	{ "co3", "co4" }, { "co3", "cc4" }, { "co3'", "g4'" }, { "co3'", "cc4" },
	{ "co3'", "co4'" }, { "li3'", "g4'" }, { "li3'", "li4'" }, { "li3'", "lc4'" },
	{ "lo3'", "lc4'" }, { "lo3'", "lo4'" }, { "fb1'", "lo4'" }, { "g4", "li4" },
	{ "g4", "co4" }, { "g4'", "co4'" }, { "g4'", "li4'" }, { "lo4", "lc4" },
	{ "lo4", "fb2" }, { "lo4", "lo5" }, { "lc4", "li4" }, { "lc4", "lc6" },
	{ "li4", "li5" }, { "co4", "co5" }, { "cc4", "co5" }, { "cc4", "co5'" },
	{ "cc4", "cc6" }, { "co4'", "co5'" }, { "li4'", "lc4'" }, { "li4'", "li5'" },
	{ "lc4'", "lo4'" }, { "lc4'", "lc6'" }, { "lo4'", "lo5'" }, { "lo4'", "fb2'" },
	{ "fb2", "ko" }, { "lo5", "lo6" }, { "lo5", "lc6" }, { "li5", "g5" },
	{ "li5", "lc6" }, { "li5", "li6" }, { "co5", "g5" }, { "co5", "co6" },
	{ "co5", "cc6" }, { "co5'", "g5'" }, { "co5'", "cc6" }, { "co5'", "co6'" },
	{ "li5'", "g5'" }, { "li5'", "li6'" }, { "li5'", "lc6'" }, { "lo5'", "lc6'" },
	{ "lo5'", "lo6'" }, { "fb2'", "ko'" }, { "g5", "co6" }, { "g5", "ki" },
	{ "g5'", "co6'" }, { "g5'", "ki'" }, { "lo6", "lc6" }, { "lo6", "ko" },
	{ "lc6", "li6" }, { "li6", "ki" }, { "co6", "kc" }, { "cc6", "kc" }, { "cc6", "kc'" },
	{ "co6'", "kc'" }, { "li6'", "lc6'" }, { "li6'", "ki'" }, { "lc6'", "lo6'" },
	{ "lo6'", "ko'" },
}

local CODE_LANES = { z = "zea", p = "pyr", a = "aeg", r = "res", n = "pen", d = "dom" }
local CODE_SEAMS = { ["1"] = 1, ["2"] = 2, ["3"] = 3, ["4"] = 4, ["5"] = 5 }
local CODE_SYNERGIES = { ["6"] = 1, ["7"] = 2, ["8"] = 3, ["9"] = 4, ["0"] = 5 }

-- The lane each combat ability sits in.
local POD_BANDS = { hook = "pen", deflect = "aeg", pyre = "pyr" }

local function _band_index(key)
	for i, k in ipairs(BAND_ORDER) do
		if k == key then
			return i
		end
	end
end

local function _polar(cy, theta, r)
	local th = math.rad(theta)

	return CX + r * math.sin(th), cy - r * math.cos(th)
end

-- ####################################################################
-- Build the node list (pure data: ids, positions, links, text, stats)
-- ####################################################################

local function _round(x)
	return math.floor(x * 1000 + 0.5) / 1000
end

-- Deeper nodes give more.
local function _tier_scale(y)
	if y < 500 then
		return 1
	elseif y < 1300 then
		return 1.25
	end

	return 1.5
end

local function _scaled(stat, value, scale)
	local def = STATS[stat]

	if def and def[2] == "M" then
		return _round(1 - (1 - value) * scale)
	elseif def and def[2] == "F" then
		return math.floor(value * scale * 2 + 0.5) / 2
	end

	return _round(value * scale)
end

local function _describe(stats, text)
	local lines = {}

	for i = 1, #stats do
		lines[#lines + 1] = _stat_line(stats[i][1], stats[i][2])
	end

	if text then
		lines[#lines + 1] = text
	end

	return table.concat(lines, "\n")
end

local function _link(a, b)
	if a == b or a.linked[b.id] then
		return
	end

	a.linked[b.id] = true
	b.linked[a.id] = true
	a.links[#a.links + 1] = b.id
	b.links[#b.links + 1] = a.id
end

local function _lane(key)
	for _, lane in ipairs(LANES) do
		if lane.key == key then
			return lane
		end
	end
end

local function _build_data()
	local nodes, by_id, by_key = {}, {}, {}

	local function add(node)
		node.links = {}
		node.linked = {}
		nodes[#nodes + 1] = node
		by_id[node.id] = node

		return node
	end

	local start = add({ id = "start", kind = "start", x = CX, y = START_Y })

	by_key.S = start

	local counts = { minor = {}, notable = {}, seam = {}, synergy = {} }
	local keystones = 0

	local function next_count(group, key)
		counts[group][key] = (counts[group][key] or 0) + 1

		return counts[group][key]
	end

	for _, entry in ipairs(LAYOUT) do
		local key, dx, dy, code = entry[1], entry[2], entry[3], entry[4]
		local scale = _tier_scale(dy)
		local lower = string.lower(code)
		local node

		if code == "@" then
			local pod = N.abilities[entry[5]]

			node = {
				id = pod.node,
				kind = "ability",
				talent = pod.talent,
				icon = pod.icon,
				exclusive_group = "combat",
				lane = POD_BANDS[entry[5]],
			}
		elseif code == "+" then
			local augment = N.abilities[entry[5]].augments[entry[6]]

			node = {
				id = augment.node,
				kind = "augment",
				talent = augment.talent,
				icon = augment.icon,
				lane = POD_BANDS[entry[5]],
				pod = entry[5],
			}
		elseif code == "$" then
			keystones = keystones + 1

			local lane = _lane(BAND_ORDER[keystones])
			local k = lane.keystone
			local stats = {}

			for i = 1, #k[2] do
				stats[i] = { k[2][i][1], k[2][i][2] }
			end

			node = {
				kind = "keystone",
				name = k[1],
				stats = stats,
				icon = ICON_PATH .. KEYSTONE_ICONS[lane.key],
				exclusive_group = "keystone",
				lane = lane.key,
			}
		elseif CODE_SYNERGIES[code] then
			local seam = CODE_SYNERGIES[code]
			local entry_data = SEAMS[seam].synergies[next_count("synergy", seam)]
			local proc = N.procs[entry_data[1]]

			node = {
				kind = "notable",
				synergy = true,
				name = proc and proc.name or entry_data[1],
				stats = {},
				text = entry_data[2],
				proc = entry_data[1],
				icon = proc and proc.icon or (ICON_PATH .. NOTABLE_ICONS[1]),
				lane = "syn",
				seam = seam,
			}
		elseif CODE_SEAMS[code] then
			local seam = CODE_SEAMS[code]
			local pool = SEAMS[seam].minors
			local m = pool[(next_count("seam", seam) - 1) % #pool + 1]

			node = {
				kind = "minor",
				name = m[1],
				stats = { { m[2], _scaled(m[2], m[3], scale) }, { m[4], _scaled(m[4], m[5], scale) } },
				icon = ICON_STAT,
				lane = "syn",
				seam = seam,
			}
		elseif code ~= lower then
			local lane = _lane(CODE_LANES[lower])
			local index = next_count("notable", lane.key)
			local n = lane.notables[index]
			local stats = {}

			for i = 1, #n[2] do
				stats[i] = { n[2][i][1], _scaled(n[2][i][1], n[2][i][2], 1) }
			end

			node = {
				kind = "notable",
				name = n[1],
				stats = stats,
				text = n[5],
				proc = n[4],
				icon = (n[4] and N.procs[n[4]] and N.procs[n[4]].icon) or (ICON_PATH .. NOTABLE_ICONS[((_band_index(lane.key) * 5 + index) % #NOTABLE_ICONS) + 1]),
				lane = lane.key,
			}
		else
			local lane = _lane(CODE_LANES[lower])
			local pool = lane.minors[(next_count("minor", lane.key) - 1) % #lane.minors + 1]

			node = {
				kind = "minor",
				name = pool[1],
				stats = { { pool[2], _scaled(pool[2], pool[3], scale) } },
				icon = ICON_STAT,
				lane = lane.key,
			}
		end

		node.id = node.id or string.format("%s_%03d", node.lane, #nodes)
		node.x, node.y = CX + dx, START_Y + dy
		by_key[key] = add(node)
	end

	for _, pair in ipairs(LINKS) do
		_link(by_key[pair[1]], by_key[pair[2]])
	end

	-- Augments link to their ability only.
	for _, node in ipairs(nodes) do
		if node.kind == "augment" then
			_link(node, by_id[N.abilities[node.pod].node])
		end
	end

	for _, node in ipairs(nodes) do
		node.linked = nil
	end

	local min_x, max_x, max_y = CX, CX, START_Y

	for _, node in ipairs(nodes) do
		min_x = math.min(min_x, node.x)
		max_x = math.max(max_x, node.x)
		max_y = math.max(max_y, node.y)
	end

	return {
		nodes = nodes,
		by_id = by_id,
		start = start,
		cy = START_Y,
		height = max_y + 420,
		half_width = math.max(CX - min_x, max_x - CX),
	}
end

N.tree_geometry = {
	CX = CX,
}

-- ####################################################################
-- Registration: one talent + one buff per generated node
-- ####################################################################

local DATA = _build_data()
local LOC_TEXT = {}

local function _talent_name(id)
	return "qiangiq_nov_t_" .. id
end

local function _template_name(id)
	return "qiangiq_nov_b_" .. id
end

local function _widget_name(id)
	return "node_qiangiq_nov_" .. id
end

-- The widget name of any node (the ability pods keep the names their
-- modules registered).
local function _node_widget(node)
	if node.kind == "ability" or node.kind == "augment" then
		return node.id
	end

	return _widget_name(node.id)
end

local function _value_scale()
	return (mod:get("value_scale") or 100) / 100
end

local function _fill_template(template, node, scale)
	local buffs = template.stat_buffs

	for key in pairs(buffs) do
		buffs[key] = nil
	end

	for i = 1, #node.stats do
		local stat, value = node.stats[i][1], node.stats[i][2]
		local key = rawget(stat_buffs, stat)
		local def = STATS[stat]

		if key then
			if def and def[2] == "M" then
				buffs[key] = 1 + (value - 1) * scale
			else
				buffs[key] = value * scale
			end
		else
			mod:error("Unknown stat buff %s on Novitiate node %s", tostring(stat), node.id)
		end
	end
end

local state = mod:persistent_table("novitiate_tree_state", {
	registered = false,
	host_type = nil,
	saved = nil,
})

local function _register()
	if state.registered then
		return
	end

	local talents = ArchetypeTalents.zealot
	local non_predicted = rawget(BuffTemplates, "NON_PREDICTED")
	local scale = _value_scale()

	-- Coded passives first (fixed order), then every node in build order:
	-- every client appends the lookup names in the same order.
	local proc_keys = {}

	for key in pairs(N.procs) do
		proc_keys[#proc_keys + 1] = key
	end

	table.sort(proc_keys)

	for _, key in ipairs(proc_keys) do
		local proc = N.procs[key]
		local names = {}

		for name in pairs(proc.templates) do
			names[#names + 1] = name
		end

		table.sort(names)

		for _, name in ipairs(names) do
			BuffTemplates[name] = proc.templates[name]

			if non_predicted then
				non_predicted[name] = name
			end

			N.append_lookup("buff_templates", name)
		end
	end

	for _, node in ipairs(DATA.nodes) do
		if node.kind == "minor" or node.kind == "notable" or node.kind == "keystone" then
			local talent_name = _talent_name(node.id)
			local template_name = _template_name(node.id)
			local proc = node.proc and N.procs[node.proc]

			if proc then
				node.proc_passive = proc.passive
			end

			local template = {
				class_name = "buff",
				name = template_name,
				predicted = false,
				stat_buffs = {},
			}

			_fill_template(template, node, scale)

			BuffTemplates[template_name] = template

			if non_predicted then
				non_predicted[template_name] = template_name
			end

			local description = _describe(node.stats, node.text)

			LOC_TEXT["loc_" .. talent_name .. "_name"] = node.name
			LOC_TEXT["loc_" .. talent_name .. "_desc"] = description

			talents[talent_name] = {
				description = "loc_" .. talent_name .. "_desc",
				display_name = "loc_" .. talent_name .. "_name",
				icon = node.icon,
				name = talent_name,
				passive = {
					buff_template_name = proc and proc.passive or template_name,
					identifier = template_name,
				},
			}

			N.append_lookup("buff_templates", template_name)
			N.append_lookup("archetype_talent_names", talent_name)
			N.append_lookup("talent_node_names", _widget_name(node.id))
		end
	end

	state.registered = true
end

_register()
N.add_loc_text(LOC_TEXT)

local function _refresh_templates()
	if not state.registered then
		return
	end

	local scale = _value_scale()

	for _, node in ipairs(DATA.nodes) do
		if node.kind == "minor" or node.kind == "notable" or node.kind == "keystone" then
			local template = rawget(BuffTemplates, _template_name(node.id))

			if template then
				_fill_template(template, node, scale)
			end
		end
	end
end

-- ####################################################################
-- Mode: which tree is in use
-- ####################################################################

-- QIangIQsLegacyTalents replaces layout.nodes when its legacy tree is on,
-- and keeps both tables in its toggle record (mode_toggle.lua). Same lookup
-- as QIangIQsPoE2Tree _legacy_record. Optional: without that mod there is
-- nothing to detect.
local function _legacy_record()
	local legacy_mod = get_mod("QIangIQsLegacyTalents")

	if not legacy_mod then
		return nil
	end

	local legacy_state = legacy_mod:persistent_table("legacy_state")
	local toggle = legacy_state and legacy_state.toggle

	if not toggle or not toggle.tables then
		return nil
	end

	local layout = require(LAYOUT_PATH)

	for i = 1, toggle.count do
		if toggle.tables[i] == layout and toggle.keys[i] == "nodes" then
			return toggle, i
		end
	end

	return nil
end

local function _legacy_zealot_active()
	local toggle = _legacy_record()

	return toggle ~= nil and toggle.active == true
end

local function _official_nodes()
	local toggle, i = _legacy_record()

	if toggle then
		return toggle.vanilla[i]
	end

	return require(LAYOUT_PATH).nodes
end

-- Same host types as QIangIQsMartyrdom _wanted.
local function _wanted(host_type)
	if mod:get("tree_enabled") == false then
		return false
	end

	if host_type == "mission_server" then
		return false
	elseif host_type == "player" or host_type == "singleplay" or host_type == "singleplay_backend_session" then
		return true
	end

	-- hub_server, or no connection yet (main menu).
	return mod:get("tree_in_hub") ~= false
end

local function _is_active()
	return _wanted(state.host_type) and N.current_is_novitiate() and not _legacy_zealot_active()
end

N.tree_active = _is_active

-- ####################################################################
-- Tree (reversible)
-- ####################################################################

local hub_y = DATA.cy
local background_height = DATA.height

-- Arc slots over the start node, left to right (0 = straight up). The web
-- hangs below the start node, so the official nodes never block it.
local RING_ANGLES = { -112, -84, -56, -28, 0, 28, 56, 84, 112 }

local function _build_nodes(official)
	local nodes = {}
	local hub = {}
	local start_node = nil

	for i = 1, #official do
		local node = official[i]

		if HUB_TYPES[node.type] then
			local copy = table.clone(node)

			hub[#hub + 1] = copy

			if node.type == "start" then
				start_node = copy
			end
		end
	end

	if not start_node then
		return nil
	end

	local ring = {}

	for i = 1, #hub do
		if hub[i] ~= start_node then
			ring[#ring + 1] = hub[i]
		end
	end

	local TYPE_ORDER = { tactical = 1, aura = 2, ability = 3 }

	table.sort(ring, function (a, b)
		local ta, tb = TYPE_ORDER[a.type] or 9, TYPE_ORDER[b.type] or 9

		if ta ~= tb then
			return ta < tb
		end

		return a.x < b.x
	end)

	local start_children = {}

	start_node.x = CX
	start_node.y = hub_y
	start_node.parents = {}
	nodes[#nodes + 1] = start_node

	for i = 1, #ring do
		local node = ring[i]
		local x, y = _polar(hub_y, RING_ANGLES[i] or (i * 40), RING_RADIUS)

		node.x = x
		node.y = y
		node.parents = { start_node.widget_name }
		node.children = {}
		start_children[#start_children + 1] = node.widget_name
		nodes[#nodes + 1] = node
	end

	local widget_of = {}

	for _, data in ipairs(DATA.nodes) do
		if data.kind ~= "start" then
			widget_of[data.id] = _node_widget(data)
		end
	end

	widget_of.start = start_node.widget_name

	for _, data in ipairs(DATA.nodes) do
		if data.kind ~= "start" then
			local neighbours = {}

			for _, id in ipairs(data.links) do
				neighbours[#neighbours + 1] = widget_of[id]
			end

			local requirements = {
				all_parents_chosen = false,
				children_unlock_points = 1,
				min_points_spent = 0,
			}
			local node = {
				children = table.clone(neighbours),
				cost = 1,
				icon = data.icon,
				max_points = 1,
				parents = neighbours,
				requirements = requirements,
				widget_name = widget_of[data.id],
				x = data.x,
				y = data.y,
			}

			if data.kind == "ability" then
				node.type = "ability"
				node.talent = data.talent
				node.target_slot = "slot_combat_ability"
				requirements.exclusive_group = "combat"
			elseif data.kind == "augment" then
				node.type = "ability_modifier"
				node.talent = data.talent
				node.gradient_color = AUGMENT_GRADIENT
			elseif data.kind == "keystone" then
				node.type = "keystone"
				node.talent = _talent_name(data.id)
				requirements.exclusive_group = "keystone"
			elseif data.kind == "notable" then
				node.type = "default"
				node.talent = _talent_name(data.id)
			else
				node.type = "stat"
				node.talent = _talent_name(data.id)
			end

			-- The lane roots hang off the start node.
			for _, id in ipairs(data.links) do
				if id == "start" then
					start_children[#start_children + 1] = node.widget_name
				end
			end

			nodes[#nodes + 1] = node
		end
	end

	start_node.children = start_children

	return nodes
end

local function _apply_tree()
	if state.saved then
		return
	end

	local layout = require(LAYOUT_PATH)
	local official = _official_nodes()

	if type(layout) ~= "table" or type(official) ~= "table" then
		return
	end

	local nodes = _build_nodes(official)

	if not nodes then
		mod:error("The Zealot tree has no start node, the Novitiate tree is not applied")

		return
	end

	state.saved = {
		background_height = layout.background_height,
		node_points = layout.node_points,
		nodes = layout.nodes,
		talent_points = layout.talent_points,
		version = layout.version,
	}

	layout.nodes = nodes
	layout.version = (layout.version or 0) + VERSION_OFFSET
	layout.background_height = background_height
	layout.node_points = mod:get("tree_points") or 70
end

local function _revert_tree()
	local saved = state.saved

	if not saved then
		return
	end

	local layout = require(LAYOUT_PATH)

	layout.nodes = saved.nodes
	layout.version = saved.version
	layout.background_height = saved.background_height
	layout.node_points = saved.node_points
	layout.talent_points = saved.talent_points

	state.saved = nil
end

local function _reset_localization_cache()
	local localization_manager = Managers.localization

	if localization_manager and localization_manager.reset_cache then
		localization_manager:reset_cache()
	end
end

local function _refresh_mode()
	if _is_active() then
		_apply_tree()
	else
		_revert_tree()
	end

	_refresh_templates()
	_reset_localization_cache()
end

local function _set_host_type(host_type)
	state.host_type = host_type

	_refresh_mode()
end

-- Same hooks as QIangIQsPoE2Tree: the host type is known when the
-- connection is set, before profiles are synced.
mod:hook_require("scripts/managers/multiplayer/connection_manager", function (ConnectionManager)
	mod:hook(ConnectionManager, "set_connection_client", function (func, self, connection_client, ...)
		local ok, host_type = pcall(function ()
			return connection_client:host_type()
		end)

		if ok then
			_set_host_type(host_type)
		end

		return func(self, connection_client, ...)
	end)

	mod:hook(ConnectionManager, "set_connection_host", function (func, self, connection_host, ...)
		local ok, host_type = pcall(function ()
			return connection_host:host_type()
		end)

		if ok then
			_set_host_type(host_type)
		end

		return func(self, connection_host, ...)
	end)
end)

-- The view counts points against profile.talent_points in the player view
-- (talent_builder_view.lua _max_layout_points) and against the layout's
-- node_points otherwise (node_builder_view_base.lua).
local function _tree_shown(view)
	if not state.saved then
		return false
	end

	local layout = view.get_active_layout and view:get_active_layout()

	return layout ~= nil and layout == require(LAYOUT_PATH)
end

-- name -> node lookups (the stock ones scan the whole node list).
local node_maps = setmetatable({}, { __mode = "k" })

local function _node_map(layout)
	local nodes = layout.nodes
	local entry = node_maps[layout]

	if not entry or entry.nodes ~= nodes or entry.count ~= #nodes then
		local map = {}

		for i = 1, #nodes do
			map[nodes[i].widget_name] = nodes[i]
		end

		entry = { nodes = nodes, count = #nodes, map = map }
		node_maps[layout] = entry
	end

	return entry.map
end

-- The stock widget creation rebuilds the whole scenegraph once per node
-- (O(n^2)). Collect the definitions first and build the scenegraph once
-- before the first refresh (found with QIangIQsPoE2Tree, where it froze the
-- game past the 15 s watchdog).
local function _finish_deferred(self)
	if not self.__nov_deferred then
		return
	end

	self.__nov_deferred = nil
	self._add_scenegraph_definition = nil
	self._refresh_all_nodes = nil

	local UIScenegraph = require("scripts/managers/ui/ui_scenegraph")

	self._ui_scenegraph = UIScenegraph.init_scenegraph(self._definitions.scenegraph_definition, self._nodes_render_scale)
	self:apply_active_background_size()
	self:_force_update_scenegraph()
end

-- realms_loadout's talent screen is its own class, RealmsLoadoutTalentView
-- (class("RealmsLoadoutTalentView", "TalentBuilderView")). Classes copy their
-- parent's methods when they are created, so hooks on TalentBuilderView miss
-- it when it was created first; its methods are hooked too (by name, so the
-- Mod Framework applies them once the class exists). When it copied a method
-- that was already hooked, the original handed to the hook is
-- TalentBuilderView's hooked method, and the hook passes straight through so
-- nothing runs twice.
local REALMS_VIEW = "RealmsLoadoutTalentView"
local _unpack = unpack or table.unpack
local function _pack(...)
	return { n = select("#", ...), ... }
end

local function _already_hooked(name, func)
	local tbv = CLASSES and CLASSES.TalentBuilderView

	return tbv ~= nil and func == rawget(tbv, name)
end

local function _hook(view_class, name, fn)
	if view_class ~= REALMS_VIEW then
		return mod:hook(view_class, name, fn)
	end

	mod:hook(view_class, name, function (func, self, ...)
		if _already_hooked(name, func) then
			return func(self, ...)
		end

		return fn(func, self, ...)
	end)
end

local function _hook_safe(view_class, name, fn)
	if view_class ~= REALMS_VIEW then
		return mod:hook_safe(view_class, name, fn)
	end

	mod:hook(view_class, name, function (func, self, ...)
		local results = _pack(func(self, ...))

		if not _already_hooked(name, func) then
			local ok, err = pcall(fn, self, ...)

			if not ok then
				mod:error("%s.%s: %s", REALMS_VIEW, name, tostring(err))
			end
		end

		return _unpack(results, 1, results.n)
	end)
end

-- Dragging sideways: how far the tree can be dragged either way.
local PAN_RANGE = DATA.half_width + 400

local function _hook_points(view_class)
	_hook(view_class, "_max_layout_points", function (func, self, ...)
		if _tree_shown(self) then
			return mod:get("tree_points") or 70
		end

		return func(self, ...)
	end)

	_hook(view_class, "_create_node_widgets", function (func, self, ...)
		if not _tree_shown(self) then
			self._nov_pan_owner = nil

			return func(self, ...)
		end

		self._nov_pan_owner = true
		self._nov_pan_base_x = nil
		self.__nov_deferred = true
		self._add_scenegraph_definition = function (view, name, definition)
			view._definitions.scenegraph_definition[name] = definition
		end
		self._refresh_all_nodes = function (view, ...)
			_finish_deferred(view)

			return view:_refresh_all_nodes(...)
		end

		local ok, err = pcall(func, self, ...)

		_finish_deferred(self)

		if not ok then
			error(err)
		end

		-- Open on the centre of the tree.
		if self._scroll_to_height then
			local scale = Managers.ui:view_render_scale() * (self._current_zoom or 1)

			self:_scroll_to_height(-(hub_y - RESOLUTION_LOOKUP.height / scale * 0.5))
		end
	end)

	_hook(view_class, "_node_by_name", function (func, self, name)
		if _tree_shown(self) then
			return _node_map(self:get_active_layout())[name]
		end

		return func(self, name)
	end)

	_hook(view_class, "active_layout_node_by_name", function (func, self, name)
		if _tree_shown(self) then
			return _node_map(self:get_active_layout())[name]
		end

		return func(self, name)
	end)

	-- node_builder_view_base.lua _handle_scenegraph_coordinates drags the
	-- background only up and down in the talent view ("if not
	-- self._player_mode then scenegraph_settings.x = final_x"). While the
	-- background is dragged, the cursor's x difference is added to x, within
	-- PAN_RANGE of where the tree opened (as QIangIQsPoE2Tree).
	_hook(view_class, "_handle_scenegraph_coordinates", function (func, self, widget_name, scenegraph_id, input_service, move_input_prefix, render_settings, is_background, ...)
		if is_background and self._player_mode then
			-- Other sideways drags (QIangIQsTreeZoom, QIangIQsScumHook) stand
			-- down while this tree owns the flag.
			if _tree_shown(self) then
				self._qiangiq_pan_owner = "novitiate"
			elseif self._qiangiq_pan_owner == "novitiate" then
				self._qiangiq_pan_owner = nil
			end
		end

		if self._nov_panning or not (is_background and self._player_mode and _tree_shown(self)) then
			return func(self, widget_name, scenegraph_id, input_service, move_input_prefix, render_settings, is_background, ...)
		end

		self._nov_panning = true

		local last = self._dragging_scenegraph_id == scenegraph_id and self._cursor_last_coordinates
		local last_x = last and last[1]
		local ok, handled, finalized = pcall(func, self, widget_name, scenegraph_id, input_service, move_input_prefix, render_settings, is_background, ...)

		self._nov_panning = nil

		if not ok then
			error(handled, 0)
		end

		local saved = self._saved_scenegraph_settings
		local settings = saved and saved[scenegraph_id]

		if settings then
			self._nov_pan_base_x = self._nov_pan_base_x or settings.x

			local current = self._cursor_current_coordinates

			if last_x and current and current[1] ~= last_x then
				local base_x = self._nov_pan_base_x
				local diff_x = (current[1] - last_x) / self._nodes_render_scale

				settings.x = math.clamp(settings.x + diff_x, base_x - PAN_RANGE, base_x + PAN_RANGE)
			end
		end

		return handled, finalized
	end)
end

-- Classes copy their parent's methods when they are created, so both the
-- base class and the Talent view are hooked.
mod:hook_require("scripts/ui/views/node_builder_view_base/node_builder_view_base", _hook_points)
mod:hook_require("scripts/ui/views/talent_builder_view/talent_builder_view", _hook_points)
_hook_points(REALMS_VIEW)

N.on_setting[#N.on_setting + 1] = function (setting_id)
	if setting_id == "tree_points" and state.saved then
		require(LAYOUT_PATH).node_points = mod:get("tree_points") or 70
	end

	_refresh_mode()
end

-- A different character, or a character marked or unmarked (nov_roster.lua).
N.on_roster_changed[#N.on_roster_changed + 1] = function ()
	if _is_active() ~= (state.saved ~= nil) then
		_refresh_mode()
	end
end

N.on_loaded[#N.on_loaded + 1] = function ()
	_refresh_mode()

	if _legacy_zealot_active() then
		mod:warning("The legacy Zealot tree from QIangIQsLegacyTalents is on, so the Novitiate tree is off. Turn off its Zealot option to use the Novitiate tree.")
	end
end

_refresh_mode()

N.tree_status = function ()
	return string.format("Novitiate tree: %s (host type %s, Novitiate character %s, tree edits %s, %d nodes, legacy Zealot tree %s)", _is_active() and "on" or "off", tostring(state.host_type), N.current_is_novitiate() and "yes" or "no", state.saved and "applied" or "not applied", #DATA.nodes, _legacy_zealot_active() and "on" or "off")
end

N.tree_data = DATA
