local mod = get_mod("QIangIQsNovitiate")
local N = mod.nov

-- Inventory key opens the Realms loadout kit (2026-10-27, option
-- "inventory_opens_rl"). realms_loadout keeps its kit apart from the
-- official inventory, which still shows the backend's level 1 gear for a new
-- Novitiate; its workspace only opens with /rl or its own keybind. For your
-- Novitiates, opening the official inventory (I key, the Mourningstar
-- terminal) opens the RL workspace instead. Nothing else is touched: other
-- characters, inspecting other players, read-only views and realms_loadout's
-- own official handoffs (its bypass flag) open the official view as before,
-- and so does every case where the workspace refuses to open (realms_loadout
-- off or not installed, workspace not available). No dependency: the RL
-- router is only looked up when present.

local OFFICIAL_INVENTORY_VIEW_NAME = "inventory_background_view"

local function _rl_router()
	local rl = get_mod("realms_loadout")

	if not rl or not rl:is_enabled() or rl._realms_official_open_bypass then
		return nil
	end

	return rl._workspace_router
end

local function _wanted(context)
	if mod:get("inventory_opens_rl") == false or not N.current_is_novitiate or not N.current_is_novitiate() then
		return false
	end

	local player = Managers.player and Managers.player:local_player_safe(1)

	if not player then
		return false
	end

	if context and ((context.player and context.player ~= player) or context.is_readonly == true or context.__nov_native) then
		return false
	end

	local ok, profile = pcall(function ()
		return player:profile()
	end)

	return ok and N.is_novitiate_profile(profile) or false
end

local redirecting = false

mod:hook(CLASS.UIManager, "open_view", function (func, self, view_name, transition_time, close_previous, close_all, close_transition_time, context, settings_override)
	if view_name == OFFICIAL_INVENTORY_VIEW_NAME and not redirecting then
		local router = _rl_router()

		if router and router.open and _wanted(context) then
			redirecting = true

			local ok, opened = pcall(router.open, "equipment")

			redirecting = false

			if ok and opened then
				return
			end

			if not ok then
				mod:warning("Novitiate: the Realms loadout workspace did not open (%s); opening the official inventory.", tostring(opened))
			end
		end
	end

	return func(self, view_name, transition_time, close_previous, close_all, close_transition_time, context, settings_override)
end)
