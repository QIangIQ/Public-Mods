local mod = get_mod("QIangIQsNovitiate")
local N = mod.nov

-- Coded passives for the Novitiate notables: procs that add a short timed
-- buff or restore toughness. Patterns are the Zealot's own
-- (zealot_buff_templates.lua): a server-side proc_buff whose proc_func adds a
-- timed buff with add_internally_controlled_buff, e.g.
-- zealot_elite_kills_empowers -> zealot_elite_kills_empowers_effect.
--
-- N.procs[key] = { name, description, templates = { [buff_name] = template } }
-- where templates[1] is the passive the talent carries.

local BuffSettings = require("scripts/settings/buff/buff_settings")
local CheckProcFunctions = require("scripts/settings/buff/helper_functions/check_proc_functions")
local FixedFrame = require("scripts/utilities/fixed_frame")

local proc_events = BuffSettings.proc_events
local stat_buffs = BuffSettings.stat_buffs
local keywords = BuffSettings.keywords

local ICON_PATH = "content/ui/textures/icons/talents/zealot/"
local HUD_ICON_PATH = "content/ui/textures/icons/buffs/hud/zealot/"

N.procs = {}

local function _timed(name, duration, stats, hud_icon)
	local template = {
		class_name = "buff",
		duration = duration,
		hud_icon = hud_icon and (HUD_ICON_PATH .. hud_icon) or nil,
		hud_icon_gradient_map = "content/ui/textures/color_ramps/talent_default",
		hud_priority = 4,
		max_stacks = 1,
		name = name,
		predicted = false,
		refresh_duration_on_stack = true,
		stat_buffs = {},
	}

	for stat, value in pairs(stats) do
		template.stat_buffs[stat_buffs[stat]] = value
	end

	return template
end

-- Burning: the "flamer_assault" stacks Penitent Pyre applies (nov_pyre.lua).
local BURNING_BUFF = "flamer_assault"
local MAX_BURN_STACKS = 12

local function _is_burning(unit)
	local buff_extension = unit and ScriptUnit.has_extension(unit, "buff_system")

	if not buff_extension then
		return false
	end

	if keywords and keywords.burning and buff_extension.has_keyword and buff_extension:has_keyword(keywords.burning) then
		return true
	end

	return buff_extension.current_stacks ~= nil and buff_extension:current_stacks(BURNING_BUFF) > 0
end

local function _burn(target_unit, owner_unit, stacks, t)
	if not target_unit or not HEALTH_ALIVE[target_unit] then
		return
	end

	local buff_extension = ScriptUnit.has_extension(target_unit, "buff_system")

	if not buff_extension then
		return
	end

	local to_add = math.min(MAX_BURN_STACKS - buff_extension:current_stacks(BURNING_BUFF), stacks)

	if to_add > 0 then
		buff_extension:add_internally_controlled_buff_with_stacks(BURNING_BUFF, to_add, t, "owner_unit", owner_unit)
	else
		buff_extension:refresh_duration_of_stacking_buff(BURNING_BUFF, t)
	end
end

-- Every enemy within radius of unit gets stacks of burning (broadphase query
-- as zealot_toughness_regen_in_melee in zealot_buff_templates.lua).
local _burst_results = {}

local function _burn_around(unit, radius, stacks, t)
	local position = POSITION_LOOKUP[unit]
	local extension_manager = Managers.state.extension
	local broadphase_system = extension_manager and extension_manager:system("broadphase_system")
	local side_system = extension_manager and extension_manager:system("side_system")
	local side = side_system and side_system.side_by_unit[unit]

	if not position or not broadphase_system or not side then
		return
	end

	local broadphase = broadphase_system.broadphase

	table.clear(_burst_results)

	local num_hits = broadphase.query(broadphase, position, radius, _burst_results, side:relation_side_names("enemy"))

	for i = 1, num_hits do
		_burn(_burst_results[i], unit, stacks, t)
	end
end

N.is_burning = _is_burning
N.burn = _burn

local function _burning_kill(params)
	return params.attack_result == "died" and _is_burning(params.attacked_unit)
end

-- def: key, name, icon, event, check, timed = { duration, stats, hud_icon },
-- toughness (fraction restored on proc), effect (function (params, unit, t),
-- server only), cooldown (seconds between procs)
local function _proc(def)
	local passive_name = "qiangiq_nov_p_" .. def.key
	local timed_name = "qiangiq_nov_e_" .. def.key
	local templates = {}

	templates[passive_name] = {
		class_name = "proc_buff",
		max_stacks = 1,
		name = passive_name,
		predicted = false,
		proc_events = {
			[proc_events[def.event]] = 1,
		},
		check_proc_func = def.check,
		start_func = function (template_data, template_context)
			template_data.buff_extension = ScriptUnit.extension(template_context.unit, "buff_system")
		end,
		proc_func = function (params, template_data, template_context, t)
			if not template_context.is_server then
				return
			end

			local now = t or FixedFrame.get_latest_fixed_time()

			if def.cooldown then
				if template_data.next_proc and now < template_data.next_proc then
					return
				end

				template_data.next_proc = now + def.cooldown
			end

			if def.effect then
				def.effect(params, template_context.unit, now)
			end

			if def.timed then
				template_data.buff_extension:add_internally_controlled_buff(timed_name, now)
			end

			if def.toughness then
				local Toughness = require("scripts/utilities/toughness/toughness")

				Toughness.replenish_percentage(template_context.unit, def.toughness, false, "qiangiq_novitiate")
			end
		end,
	}

	if def.timed then
		templates[timed_name] = _timed(timed_name, def.timed.duration, def.timed.stats, def.timed.hud_icon)
	end

	N.procs[def.key] = {
		name = def.name,
		icon = ICON_PATH .. def.icon,
		passive = passive_name,
		templates = templates,
	}
end

_proc({
	key = "bloodied_hymn",
	name = "Bloodied Hymn",
	icon = "zealot_elite_kills_empowers",
	event = "on_kill",
	check = CheckProcFunctions.on_elite_kill,
	timed = { duration = 6, stats = { attack_speed = 0.15 }, hud_icon = "zealot_elite_kills_empowers" },
})

_proc({
	key = "dead_eye_faith",
	name = "Dead-Eye Faith",
	icon = "zealot_crits_rend",
	event = "on_kill",
	check = CheckProcFunctions.on_weakspot_kill,
	timed = { duration = 4, stats = { critical_strike_chance = 0.15 }, hud_icon = "zealot_weakspot_damage_reduction" },
})

_proc({
	key = "absolution",
	name = "Absolution",
	icon = "zealot_toughness_on_heavy_kills",
	event = "on_kill",
	check = CheckProcFunctions.on_melee_kill,
	toughness = 0.05,
})

_proc({
	key = "quickened_penance",
	name = "Quickened Penance",
	icon = "zealot_attack_speed_post_ability",
	event = "on_combat_ability",
	check = CheckProcFunctions.always,
	timed = { duration = 6, stats = { movement_speed = 0.2, attack_speed = 0.12 }, hud_icon = "zealot_toughness_in_melee" },
})

_proc({
	key = "litany_aftermath",
	name = "Litany's Aftermath",
	icon = "zealot_channel_grants_toughness_damage_reduction",
	event = "on_combat_ability",
	check = CheckProcFunctions.always,
	timed = { duration = 6, stats = { damage_taken_multiplier = 0.85, toughness_replenish_modifier = 0.25 }, hud_icon = "zealot_weakspot_damage_reduction" },
})

_proc({
	key = "ash_and_ember",
	name = "Ash and Ember",
	icon = "zealot_cleansing_flame",
	event = "on_kill",
	check = CheckProcFunctions.on_elite_or_special_kill,
	timed = { duration = 8, stats = { damage_vs_burning = 0.2 }, hud_icon = "zealot_elite_kills_empowers" },
	toughness = 0.08,
})

-- ####################################################################
-- Synergy passives: the notables where two disciplines of the tree meet.
-- ####################################################################

-- Aegis | Resolve
_proc({
	key = "flesh_as_bulwark",
	name = "Flesh as Bulwark",
	icon = "zealot_toughness_on_heavy_kills",
	event = "on_perfect_block",
	check = CheckProcFunctions.always,
	toughness = 0.06,
	timed = { duration = 4, stats = { damage_taken_multiplier = 0.92 }, hud_icon = "zealot_weakspot_damage_reduction" },
})

_proc({
	key = "scar_tissue",
	name = "Scar Tissue",
	icon = "zealot_reduced_damage_on_wound",
	event = "on_player_toughness_broken",
	check = CheckProcFunctions.always,
	timed = { duration = 5, stats = { damage_taken_multiplier = 0.8, toughness_regen_rate_modifier = 0.5 }, hud_icon = "zealot_weakspot_damage_reduction" },
})

-- Pyre | Aegis (Chained Guard) and Resolve | Penance (Shackled Shield)
_proc({
	key = "chained_guard",
	name = "Chained Guard",
	icon = "zealot_cleave_impact_post_push",
	event = "on_push_hit",
	check = CheckProcFunctions.always,
	timed = { duration = 5, stats = { damage_vs_staggered = 0.15, impact_modifier = 0.2 }, hud_icon = "zealot_toughness_in_melee" },
})

_proc({
	key = "shackled_shield",
	name = "Shackled Shield",
	icon = "zealot_dodge_improvements",
	event = "on_combat_ability",
	check = CheckProcFunctions.always,
	timed = { duration = 8, stats = { block_cost_multiplier = 0.6, push_cost_multiplier = 0.6, impact_modifier = 0.2 }, hud_icon = "zealot_toughness_in_melee" },
})

-- Penance | Judgement
_proc({
	key = "scourge_of_the_bound",
	name = "Scourge of the Bound",
	icon = "zealot_damage_after_heavy_attack",
	event = "on_kill",
	check = CheckProcFunctions.on_staggered_kill,
	timed = { duration = 4, stats = { attack_speed = 0.1, movement_speed = 0.1 }, hud_icon = "zealot_elite_kills_empowers" },
})

-- Zeal | Pyre
_proc({
	key = "burning_zeal",
	name = "Burning Zeal",
	icon = "zealot_fire_and_fury",
	event = "on_hit",
	check = _burning_kill,
	timed = { duration = 6, stats = { attack_speed = 0.08, melee_damage = 0.1 }, hud_icon = "zealot_elite_kills_empowers" },
})

_proc({
	key = "searing_edge",
	name = "Searing Edge",
	icon = "zealot_cleansing_flame",
	event = "on_hit",
	check = CheckProcFunctions.on_melee_crit_hit,
	effect = function (params, unit, t)
		_burn(params.attacked_unit, unit, 2, t)
	end,
})

-- Pyre | Aegis
_proc({
	key = "sermon_of_ash",
	name = "Sermon of Ash",
	icon = "zealot_channel_grants_toughness_damage_reduction",
	event = "on_combat_ability",
	check = CheckProcFunctions.always,
	effect = function (params, unit, t)
		_burn_around(unit, 5, 3, t)
	end,
})

-- Resolve | Penance
_proc({
	key = "watchful_penitent",
	name = "Watchful Penitent",
	icon = "zealot_always_in_coherency",
	event = "on_kill",
	check = CheckProcFunctions.on_elite_or_special_ranged_kill,
	toughness = 0.08,
	timed = { duration = 5, stats = { coherency_radius_modifier = 0.2, toughness_replenish_modifier = 0.15 }, hud_icon = "zealot_toughness_in_melee" },
})

-- Penance | Judgement
_proc({
	key = "marked_for_judgement",
	name = "Marked for Judgement",
	icon = "zealot_damage_vs_elites",
	event = "on_hit",
	check = CheckProcFunctions.on_weakspot_hit_ranged,
	timed = { duration = 5, stats = { ranged_damage = 0.12, reload_speed = 0.1 }, hud_icon = "zealot_elite_kills_empowers" },
})
