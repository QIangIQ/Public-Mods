local mod = get_mod("QIangIQsNovitiate")
local N = mod.nov

-- Penitent Pyre: the Novitiate's own combat ability. Instant cast like the
-- stance abilities (the zealot_invisibility template adds
-- ability_template_tweak_data.buff_to_add, as Deflect does). For DURATION
-- seconds the Novitiate burns: every TICK seconds each enemy within RADIUS
-- metres gets burning stacks (the "flamer_assault" buff, added with
-- add_internally_controlled_buff_with_stacks the way zealot_resist_death_fire
-- adds it in zealot_buff_templates.lua), enemies that hit the Novitiate in
-- melee burn too, and burning enemies near the Novitiate restore toughness.
-- Burning enemies take extra damage (damage_vs_burning) and the Novitiate
-- moves a little faster.
--
-- Enemy lookup is the broadphase query zealot_toughness_regen_in_melee uses
-- (zealot_buff_templates.lua). All of the damage and healing runs on the
-- server; clients only see the buff.

local BuffSettings = require("scripts/settings/buff/buff_settings")
local BuffTemplates = require("scripts/settings/buff/buff_templates")
local PlayerAbilities = require("scripts/settings/ability/player_abilities/player_abilities")
local ArchetypeTalents = require("scripts/settings/ability/archetype_talents/archetype_talents")
local AttackSettings = require("scripts/settings/damage/attack_settings")

local attack_results = AttackSettings.attack_results
local attack_types = AttackSettings.attack_types
local proc_events = BuffSettings.proc_events
local stat_buffs = BuffSettings.stat_buffs

local DURATION = 12
local COOLDOWN = 45
local RADIUS = 6
local WIDE_RADIUS = 9
local TICK = 0.5
local STACKS_PER_TICK = 2
local MAX_ENEMY_STACKS = 12
local MELEE_ATTACKER_STACKS = 3
local TOUGHNESS_PER_ENEMY = 0.01
local TOUGHNESS_MAX_ENEMIES = 5
local FEED_MULTIPLIER = 3
local HEAL_PER_SECOND = 0.02
local HEAL_MIN_ENEMIES = 3
local BURNING_BUFF = "flamer_assault"

local TALENT_NAME = "qiangiq_nov_pyre"
local ABILITY_NAME = "qiangiq_nov_pyre"
local BUFF_NAME = "qiangiq_nov_pyre_stance"
local NODE_NAME = "node_qiangiq_nov_pyre"
local LOC_NAME = "loc_qiangiq_nov_pyre"
local LOC_DESCRIPTION = "loc_qiangiq_nov_pyre_description"

local ICON_PATH = "content/ui/textures/icons/talents/zealot/"
local NODE_ICON = ICON_PATH .. "zealot_cleansing_flame"
local BUFF_HUD_ICON = "content/ui/textures/icons/buffs/hud/zealot/zealot_toughness_in_melee"
local ABILITY_ICON = "content/ui/materials/icons/abilities/ultimate/default"

-- Zealot's own Resist Death sounds (zealot_buff_templates.lua, zealot_resist_death),
-- the same ones Deflect plays.
local LOOP_START = "wwise/events/player/play_ability_zealot_maniac_resist_death_on"
local LOOP_STOP = "wwise/events/player/play_ability_zealot_maniac_resist_death_off"

local AUGMENTS = {
	{
		key = "wide",
		talent = "qiangiq_nov_pyre_wide",
		node = "node_qiangiq_nov_pyre_wide",
		icon = ICON_PATH .. "zealot_fire_and_fury",
	},
	{
		key = "feed",
		talent = "qiangiq_nov_pyre_feed",
		node = "node_qiangiq_nov_pyre_feed",
		icon = ICON_PATH .. "zealot_toughness_on_heavy_kills",
	},
	{
		key = "heart",
		talent = "qiangiq_nov_pyre_heart",
		node = "node_qiangiq_nov_pyre_heart",
		icon = ICON_PATH .. "zealot_resist_death_healing",
	},
}

for _, augment in ipairs(AUGMENTS) do
	augment.loc_name = "loc_" .. augment.talent
	augment.loc_description = "loc_" .. augment.talent .. "_description"
	augment.mod_name_key = "pyre_augment_" .. augment.key .. "_name"
	augment.mod_description_key = "pyre_augment_" .. augment.key .. "_description"
end

local AUGMENT_WIDE = AUGMENTS[1].talent
local AUGMENT_FEED = AUGMENTS[2].talent
local AUGMENT_HEART = AUGMENTS[3].talent

local state = mod:persistent_table("nov_pyre_state", {
	registered = false,
})

local function _has_buff(unit, template_name)
	local buff_extension = unit and ScriptUnit.has_extension(unit, "buff_system")

	return buff_extension ~= nil and buff_extension.has_buff_using_buff_template ~= nil and buff_extension:has_buff_using_buff_template(template_name)
end

local function _burn(target_unit, owner_unit, stacks, t)
	if not HEALTH_ALIVE[target_unit] then
		return false
	end

	local buff_extension = ScriptUnit.has_extension(target_unit, "buff_system")

	if not buff_extension then
		return false
	end

	local to_add = math.min(MAX_ENEMY_STACKS - buff_extension:current_stacks(BURNING_BUFF), stacks)

	if to_add > 0 then
		buff_extension:add_internally_controlled_buff_with_stacks(BURNING_BUFF, to_add, t, "owner_unit", owner_unit)
	else
		buff_extension:refresh_duration_of_stacking_buff(BURNING_BUFF, t)
	end

	return true
end

local function _buff_template()
	return {
		class_name = "proc_buff",
		duration = DURATION,
		hud_icon = BUFF_HUD_ICON,
		hud_icon_gradient_map = "content/ui/textures/color_ramps/talent_ability",
		hud_priority = 4,
		predicted = true,
		unique_buff_id = BUFF_NAME,
		stat_buffs = {
			[stat_buffs.movement_speed] = 0.1,
			[stat_buffs.damage_vs_burning] = 0.25,
		},
		proc_events = {
			[proc_events.on_player_hit_received] = 1,
		},
		check_proc_func = function (params, template_data, template_context)
			local attacking_unit = params.attacking_unit

			return params.attack_type == attack_types.melee and attacking_unit ~= nil and HEALTH_ALIVE[attacking_unit] and true or false
		end,
		proc_func = function (params, template_data, template_context, t)
			if not template_context.is_server then
				return
			end

			_burn(params.attacking_unit, template_context.unit, MELEE_ATTACKER_STACKS, t)
		end,
		start_func = function (template_data, template_context)
			if not template_context.is_server then
				return
			end

			local unit = template_context.unit
			local broadphase_system = Managers.state.extension:system("broadphase_system")
			local side_system = Managers.state.extension:system("side_system")
			local side = side_system.side_by_unit[unit]

			template_data.broadphase = broadphase_system.broadphase
			template_data.results = {}
			template_data.enemy_side_names = side:relation_side_names("enemy")
			template_data.next_tick = 0
		end,
		update_func = function (template_data, template_context, dt, t)
			if not template_context.is_server or not template_data.broadphase then
				return
			end

			if t < template_data.next_tick then
				return
			end

			template_data.next_tick = t + TICK

			local unit = template_context.unit
			local position = POSITION_LOOKUP[unit]

			if not position then
				return
			end

			local radius = _has_buff(unit, AUGMENT_WIDE) and WIDE_RADIUS or RADIUS
			local results = template_data.results

			table.clear(results)

			local num_hits = template_data.broadphase.query(template_data.broadphase, position, radius, results, template_data.enemy_side_names)
			local burning = 0

			for i = 1, num_hits do
				if _burn(results[i], unit, STACKS_PER_TICK, t) then
					burning = burning + 1
				end
			end

			if burning == 0 then
				return
			end

			local Toughness = require("scripts/utilities/toughness/toughness")
			local per_enemy = TOUGHNESS_PER_ENEMY * (_has_buff(unit, AUGMENT_FEED) and FEED_MULTIPLIER or 1)

			Toughness.replenish_percentage(unit, per_enemy * math.min(burning, TOUGHNESS_MAX_ENEMIES), false, "ability_stance")

			if burning >= HEAL_MIN_ENEMIES and _has_buff(unit, AUGMENT_HEART) then
				local Health = require("scripts/utilities/health")
				local health_extension = ScriptUnit.has_extension(unit, "health_system")
				local max_health = health_extension and health_extension:max_health()

				if max_health and max_health > 0 then
					Health.add(unit, max_health * HEAL_PER_SECOND * TICK, "leech")
				end
			end
		end,
		player_effects = {
			looping_wwise_start_event = LOOP_START,
			looping_wwise_stop_event = LOOP_STOP,
		},
	}
end

local function _ability()
	-- Same fields as Deflect's ability (zealot_abilities.lua zealot_invisibility).
	return {
		ability_group = ABILITY_NAME,
		ability_template = "zealot_invisibility",
		cooldown = COOLDOWN,
		hud_icon = NODE_ICON,
		icon = ABILITY_ICON,
		max_charges = 1,
		name = ABILITY_NAME,
		resource_cost_per_charge = COOLDOWN,
		resource_regen_per_second = 1,
		usage_cost_type = "charges",
		ability_template_tweak_data = {
			buff_to_add = BUFF_NAME,
		},
		archetypes = {
			"zealot",
		},
	}
end

local function _resource_strings()
	local out = {}

	for _, name in ipairs({ LOOP_START, LOOP_STOP }) do
		if Application.can_get_resource("package", name) then
			out[#out + 1] = name
		end
	end

	return out
end

local function _talent(ability)
	local stealth = rawget(ArchetypeTalents.zealot, "zealot_stealth")

	return {
		description = LOC_DESCRIPTION,
		display_name = LOC_NAME,
		icon = NODE_ICON,
		is_main_ability = true,
		large_icon = stealth and stealth.large_icon or nil,
		name = "Penitent Pyre",
		format_values = {
			duration = { format_type = "number", value = DURATION },
			cooldown = { format_type = "number", value = COOLDOWN },
			radius = { format_type = "number", value = RADIUS },
		},
		player_ability = {
			ability_type = "combat_ability",
			ability = ability,
		},
		qiangiq_resources = _resource_strings(),
	}
end

local function _register_data()
	if state.registered then
		return
	end

	BuffTemplates[BUFF_NAME] = _buff_template()
	BuffTemplates[BUFF_NAME].name = BUFF_NAME

	local predicted_lookup = rawget(BuffTemplates, "PREDICTED")

	if predicted_lookup then
		predicted_lookup[BUFF_NAME] = BUFF_NAME
	end

	local ability = _ability()

	PlayerAbilities[ABILITY_NAME] = ability
	ArchetypeTalents.zealot[TALENT_NAME] = _talent(ability)

	N.append_lookup("archetype_talent_names", TALENT_NAME)
	N.append_lookup("talent_node_names", NODE_NAME)
	N.append_lookup("buff_templates", BUFF_NAME)
	N.append_lookup("player_abilities", ABILITY_NAME)

	for _, augment in ipairs(AUGMENTS) do
		-- Marker buff checked by the stance: no duration, no HUD icon.
		BuffTemplates[augment.talent] = {
			name = augment.talent,
			class_name = "buff",
			predicted = false,
		}

		ArchetypeTalents.zealot[augment.talent] = {
			description = augment.loc_description,
			display_name = augment.loc_name,
			icon = augment.icon,
			name = augment.talent,
			passive = {
				buff_template_name = augment.talent,
				identifier = augment.talent,
			},
		}

		N.append_lookup("archetype_talent_names", augment.talent)
		N.append_lookup("talent_node_names", augment.node)
		N.append_lookup("buff_templates", augment.talent)
	end

	state.registered = true
end

_register_data()

local loc_keys = {
	[LOC_NAME] = "pyre_talent_name",
	[LOC_DESCRIPTION] = "pyre_talent_description",
}

for _, augment in ipairs(AUGMENTS) do
	loc_keys[augment.loc_name] = augment.mod_name_key
	loc_keys[augment.loc_description] = augment.mod_description_key
end

N.add_loc(loc_keys)

N.abilities.pyre = {
	talent = TALENT_NAME,
	node = NODE_NAME,
	icon = NODE_ICON,
	augments = AUGMENTS,
}
