local mod = get_mod("QIangIQsNovitiate")

local function _numeric(setting_id, default_value, min, max, decimals)
	return {
		setting_id = setting_id,
		type = "numeric",
		default_value = default_value,
		range = { min, max },
		decimals_number = decimals or 0,
		tooltip = setting_id .. "_description",
	}
end

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = false,
	options = {
		widgets = {
			{
				setting_id = "roster_scope",
				type = "dropdown",
				default_value = "marked",
				tooltip = "roster_scope_description",
				options = {
					{ text = "roster_scope_marked", value = "marked" },
					{ text = "roster_scope_all", value = "all_zealots" },
				},
			},
			{
				setting_id = "toggle_novitiate_keybind",
				type = "keybind",
				default_value = { "f8" },
				keybind_trigger = "pressed",
				keybind_type = "function_call",
				function_name = "toggle_novitiate_character",
				tooltip = "toggle_novitiate_keybind_description",
			},
			{
				setting_id = "solo_unlock",
				type = "checkbox",
				default_value = true,
				tooltip = "solo_unlock_description",
			},
			{
				setting_id = "class_icons",
				type = "checkbox",
				default_value = true,
				tooltip = "class_icons_description",
			},
			{
				setting_id = "visual_mode",
				type = "dropdown",
				default_value = "dauntless",
				tooltip = "visual_mode_description",
				options = {
					{ text = "visual_mode_dauntless", value = "dauntless" },
					{ text = "visual_mode_lacrima", value = "lacrima" },
					{ text = "visual_mode_off", value = "off" },
				},
			},
			{
				setting_id = "visual_hair",
				type = "checkbox",
				default_value = true,
				tooltip = "visual_hair_description",
			},
			{
				setting_id = "dauntless_face",
				type = "checkbox",
				default_value = true,
				tooltip = "dauntless_face_description",
			},
			{
				setting_id = "inventory_opens_rl",
				type = "checkbox",
				default_value = true,
				tooltip = "inventory_opens_rl_description",
			},
			{
				setting_id = "tree_enabled",
				type = "checkbox",
				default_value = true,
				tooltip = "tree_enabled_description",
			},
			{
				setting_id = "tree_in_hub",
				type = "checkbox",
				default_value = true,
				tooltip = "tree_in_hub_description",
			},
			_numeric("tree_points", 70, 1, 300),
			_numeric("value_scale", 100, 5, 200),
			_numeric("arm_hold_time", 0.12, 0, 0.3, 2),
			_numeric("arm_follow_time", 0.3, 0.2, 0.55, 2),
			_numeric("hook_hand_angle", 45, -90, 90),
			_numeric("grapple_reel_speed", 12, 2, 40),
			_numeric("grapple_pull", 30, 5, 80),
			_numeric("grapple_max_speed", 22, 10, 50),
			_numeric("grapple_gravity", 100, 0, 100),
			_numeric("grapple_jump_height", 0, 0, 10, 1),
		},
	},
}
