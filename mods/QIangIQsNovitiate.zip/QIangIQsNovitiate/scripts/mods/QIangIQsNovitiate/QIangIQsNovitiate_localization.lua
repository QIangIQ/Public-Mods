return {
	archetype_novitiate = {
		en = "Novitiate",
	},
	roster_scope = {
		en = "Novitiate characters",
	},
	roster_scope_description = {
		en = "Which Zealots are Novitiates. Marked: only Zealots you mark on the character select screen (keybind below); they show as Novitiate on the character list and get the Novitiate tree and look, other Zealots keep the official tree and their builds. Every Zealot: all of them, as before.",
	},
	roster_scope_marked = {
		en = "Marked Zealots only",
	},
	roster_scope_all = {
		en = "Every Zealot",
	},
	toggle_novitiate_keybind = {
		en = "Mark as Novitiate",
	},
	toggle_novitiate_keybind_description = {
		en = "On the character select screen, marks the selected Zealot as a Novitiate, or unmarks it.",
	},
	roster_marked = {
		en = "%s is now a Novitiate.",
	},
	roster_unmarked = {
		en = "%s is a Zealot again.",
	},
	roster_no_selection = {
		en = "Select a Zealot on the character select screen first.",
	},
	roster_not_zealot = {
		en = "Only a Zealot can be a Novitiate.",
	},
	roster_scope_all_hint = {
		en = "The Novitiate characters option is set to every Zealot, so marks have no effect until it is set to marked Zealots only.",
	},
	arm_follow_time = {
		en = "Thrown arm (seconds into the throw)",
	},
	arm_follow_time_description = {
		en = "The pose the left arm keeps after the throw while the chain is out. Just after the release (0.25) the arm is out in front.",
	},
	arm_hold_time = {
		en = "Held arm (seconds into the throw)",
	},
	arm_hold_time_description = {
		en = "Where the left arm stops while you hold the hook: lower values hold it lower, before the wind-up gets high. The throw releases at 0.25.",
	},
	command_description = {
		en = "Shows whether the Novitiate tree and look are on.",
	},
	deflect_augment_horde_kill_description = {
		en = "While Deflect is active, any horde or roamer enemy whose melee attack you deflect dies instantly. Elites, specialists and bosses are not affected.",
	},
	deflect_augment_horde_kill_name = {
		en = "Deflect: Cull the Masses",
	},
	deflect_augment_toughness_description = {
		en = "While Deflect is active, you regenerate 30%% of your maximum toughness every second.",
	},
	deflect_augment_toughness_name = {
		en = "Deflect: Unbroken Faith",
	},
	deflect_talent_description = {
		en = "Plant your feet and raise a perfect guard for {duration:%%s} seconds. You cannot move, dodge, jump or sprint, but every enemy melee attack from any direction is parried and deals 40%% of the attacker's max health back to it, or 20%% for bosses, and staggers it as hard as the game allows.\n\nWhile active you take 60%% less ranged damage, cannot be knocked back, staggered or launched, Trapper nets and Pox Hound pounces miss you, and any Mutant that tries to grab you is killed. You can still attack.\n\nCooldown: {cooldown:%%s} seconds.",
	},
	deflect_talent_name = {
		en = "Deflect",
	},
	grapple_gravity = {
		en = "Grapple: gravity on the rope (percent)",
	},
	grapple_gravity_description = {
		en = "Gravity while you are tied on, in percent of the game's (11.82 m/s²). Lower: you float and swing longer.",
	},
	grapple_jump_height = {
		en = "Grapple: jump off height (m)",
	},
	grapple_jump_height_description = {
		en = "Jumping lets go of the rope. This adds a hop of this height as you let go. 0: no hop. The game's own jump is about 0.7 m.",
	},
	grapple_max_speed = {
		en = "Grapple: top speed (m/s)",
	},
	grapple_max_speed_description = {
		en = "Your speed is capped at this while tied on.",
	},
	grapple_pull = {
		en = "Grapple: pull towards the boss (m/s²)",
	},
	grapple_pull_description = {
		en = "How hard the rope pulls you in while it is longer than 3.5 m. Higher: you fly in faster.",
	},
	grapple_reel_speed = {
		en = "Grapple: reel-in speed (m/s)",
	},
	grapple_reel_speed_description = {
		en = "How fast the rope shortens towards the boss or Ogryn you are tied to, down to 3.5 m.",
	},
	hook_augment_charges_description = {
		en = "Chain Hook has {charges:%%s} charges.",
	},
	hook_augment_charges_name = {
		en = "Chain Hook: Spare Hooks",
	},
	hook_augment_extra_targets_description = {
		en = "Chain Hook holds {extra_targets:%%s} more enemies. It keeps flying until it has caught 3 enemies, reaches its full range, hits a wall or is reeled in, then snaps back with all of them.",
	},
	hook_augment_extra_targets_name = {
		en = "Chain Hook: Gang Hook",
	},
	hook_augment_fast_description = {
		en = "Chain Hook flies out at {speed:%%s} metres a second and snaps back at {return_speed:%%s}: twice as fast.",
	},
	hook_augment_fast_name = {
		en = "Chain Hook: Fast Hook",
	},
	hook_augment_grapple_description = {
		en = "Chain Hook also latches onto Ogryns and bosses when it is empty. Instead of pulling them in, it ties you to them: you are lifted into the air and pulled in on a rope that reels in at {reel_speed:%%s} metres a second (set in the mod options), keeping your air control so you can strafe and swing around them. The rope follows them as they move. Jump or press again to let go; it lets go by itself after {tether_time:%%s} seconds.",
	},
	hook_augment_grapple_name = {
		en = "Chain Hook: Grapple",
	},
	hook_augment_toughness_description = {
		en = "Gain {toughness:%%s} toughness for every enemy Chain Hook catches.",
	},
	hook_augment_toughness_name = {
		en = "Chain Hook: Tough Haul",
	},
	hook_hand_angle = {
		en = "Hook angle in the hand (degrees)",
	},
	hook_hand_angle_description = {
		en = "0: the hook carries on straight up from the forearm. Higher tilts it forward, negative tilts it back.",
	},
	hook_talent_description = {
		en = "Hold to hold the hook out: the enemy it would catch is outlined. Let go (or just tap) to throw it up to {range:%%s} metres where you are aiming, at {speed:%%s} metres a second. It stops early at a wall.\n\nThe first enemy it touches is caught and stunned, unless it is a boss, a captain or an Ogryn. The hook then snaps back at {return_speed:%%s} metres a second and drops the enemy right in front of you, staggered.\n\nPress again while the hook flies out to reel it in early, with whatever it holds. That press costs no charge.\n\nCharges: {charges:%%s}. Cooldown: {cooldown:%%s} seconds per charge.",
	},
	hook_talent_name = {
		en = "Chain Hook",
	},
	mod_description = {
		en = "Novitiate: a Zealot-based class with its own look, talent tree and three combat abilities. The default look is the datamined Dauntless Battle Sister fit; an option swaps in Sister Lacrima. You mark which of your Zealots are Novitiates on the character select screen (F8 by default); they show as Novitiate on the character list, the rest stay normal Zealots. The tree has 150 nodes in mirrored sections like the official trees, with three lanes: close range (Zeal, Pyre), support (Aegis, Resolve) and ranged (Penance, Judgement), below the Zealot's own start, blitz, aura and ability nodes. Abilities: Chain Hook (throw a chain, pull enemies in), Deflect (plant your feet, parry and reflect melee) and Penitent Pyre (burn everything near you). The tree and abilities run where the game runs talents locally (host, Psykhanium, solo play); on Fatshark's mission servers the normal Zealot tree is used. Everyone in a game that uses them needs this mod. Standalone: Custom Assets is only needed for the Lacrima model.",
	},
	mod_name = {
		en = "QIangIQs Novitiate",
	},
	pyre_augment_feed_description = {
		en = "While Penitent Pyre is active, burning enemies restore three times as much toughness.",
	},
	pyre_augment_feed_name = {
		en = "Penitent Pyre: Feed the Flame",
	},
	pyre_augment_heart_description = {
		en = "While Penitent Pyre is active and at least three enemies are burning near you, you heal 2%% of your maximum health every second.",
	},
	pyre_augment_heart_name = {
		en = "Penitent Pyre: Ember Heart",
	},
	pyre_augment_wide_description = {
		en = "Penitent Pyre burns enemies within 9 metres instead of 6.",
	},
	pyre_augment_wide_name = {
		en = "Penitent Pyre: Wide Pyre",
	},
	pyre_talent_description = {
		en = "Set yourself alight for {duration:%%s} seconds. Every half second, every enemy within {radius:%%s} metres catches fire (up to 12 stacks of the same burning the Flamer applies), and every enemy that hits you in melee burns too. Burning enemies take 25%% more damage from you, you move 10%% faster, and each burning enemy near you restores 1%% of your toughness per tick (up to five enemies).\n\nCooldown: {cooldown:%%s} seconds.",
	},
	pyre_talent_name = {
		en = "Penitent Pyre",
	},
	tree_enabled = {
		en = "Novitiate talent tree",
	},
	tree_enabled_description = {
		en = "Replace the Zealot talent tree with the Novitiate tree where the game runs talents locally. Off: the official Zealot tree. The talent string is different between the two, so builds of one are dropped in the other.",
	},
	tree_in_hub = {
		en = "Novitiate tree in the Mourningstar",
	},
	tree_in_hub_description = {
		en = "Show the Novitiate tree in the hub and the main menu so you can build it. Off: only inside games where the game runs talents locally.",
	},
	tree_points = {
		en = "Novitiate talent points",
	},
	tree_points_description = {
		en = "How many points you can spend in the Novitiate tree (the official Zealot tree has about 30). Changing it applies at once.",
	},
	value_scale = {
		en = "Node strength (percent)",
	},
	value_scale_description = {
		en = "Scales every generated stat node: 100 is as listed in the node text, lower is weaker. Applies to buffs added from then on; node text keeps the 100 percent values.",
	},
	class_icons = {
		en = "Novitiate class icons",
	},
	class_icons_description = {
		en = "Show the Novitiate's own class symbol (HUD name, character list, talent banner) and talent tree start coin instead of the Zealot's. Needs Custom Assets and its patcher.",
	},
	solo_unlock = {
		en = "Solo loadout: level 30",
	},
	solo_unlock_description = {
		en = "Novitiate characters count as level 30 with 30 talent points on this PC, so all curio slots and every weapon are open in the inventory and the Realms loadout. Nothing is sent to the backend; Fatshark servers still use the real level.",
	},
	dauntless_face = {
		en = "Dauntless face",
	},
	dauntless_face_description = {
		en = "Use the Dauntless face with the Dauntless look. It borrows your own face's animations for its jaw and teeth. Off keeps your character's own face.",
	},
	inventory_opens_rl = {
		en = "Inventory opens Realms loadout",
	},
	inventory_opens_rl_description = {
		en = "On a Novitiate, the inventory key and the inventory terminal open your Realms loadout kit (the /rl workspace) instead of the official inventory, which only has the backend's level 1 gear. Needs realms_loadout; without it the official inventory opens.",
	},
	visual_hair = {
		en = "Show hair",
	},
	visual_hair_description = {
		en = "Show the Dauntless hair unit with the Dauntless look.",
	},
	visual_mode = {
		en = "Look",
	},
	visual_mode_dauntless = {
		en = "Dauntless (default)",
	},
	visual_mode_description = {
		en = "Dauntless: the datamined Dauntless Battle Sister gear on your Zealot (default). Lacrima: the Sister Lacrima model (needs Custom Assets and its patcher). Off: the normal Zealot look. Human characters only.",
	},
	visual_mode_lacrima = {
		en = "Sister Lacrima",
	},
	visual_mode_off = {
		en = "Off",
	},
}
