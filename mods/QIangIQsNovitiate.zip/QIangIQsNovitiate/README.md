# QIangIQsNovitiate

A Zealot-based class variant: own look, own talent tree, three combat abilities.

**Honest scope.** A brand-new archetype cannot be added from a mod: the backend owns characters and
archetypes and NetworkLookup is built at boot. Novitiate is the Zealot with a different look, tree and
abilities, active where the game runs talents locally (host, Psykhanium, solo play). On Fatshark's mission
servers the official Zealot tree is used and nothing here runs. Everyone in a game that uses the tree or
abilities needs the mod.

## What it adds
- **Novitiate characters** (nov_roster.lua): on the character select screen, select a Zealot and press the
  "Mark as Novitiate" keybind (F8 by default). It then shows as **Novitiate** on the character list and its
  details, and only marked Zealots get the Novitiate tree and look; other Zealots keep the official tree and
  their builds. Option "Novitiate characters" can switch back to every Zealot. A real new class slot is not
  possible from a mod (the backend owns characters), so create a Zealot and mark it.
- **Tree** (nov_tree.lua): 151 nodes in mirrored sections like the official trees (official Zealot: 83), below
  the Zealot's own start node, with the official blitz, aura and ability nodes in an arc above it (all
  optional). A hand-laid mirrored layout: crown, lane bars, three middle clusters ending in the abilities,
  a second bar and three bottom clusters with the keystones, with connector nodes between the lanes. Three
  lanes like the official trees, two disciplines each:
  - close range (left): Zeal, Pyre, with Penitent Pyre;
  - support (middle): Aegis, Resolve (incl. coherency and ability cooldown), with Deflect;
  - ranged (right): Penance, Judgement (ranged damage, reload, weak spots), with Chain Hook.
  Every node links to the nearest node above (often two), many to their row neighbours, some skip a row and
  cross other links; links have no direction, so builds grow up, down and sideways. Nodes on discipline
  borders are seam nodes (two stats, one from each side) with 10 coded synergy notables (two per seam, incl.
  the lane-crossing seams Pyre|Aegis and Resolve|Penance). 30 discipline notables (6 coded procs), 6
  keystones (one allowed) alone on the bottom row, 6 combat abilities (3 official + 3 in the web) with 10
  augments. Point budget option (default 70). Drag sideways to pan.
  Builds saved with earlier versions of the tree are dropped (layout version changed).
- **Chain Hook** (nov_hook.lua): vendored from QIangIQsScumHook, moved to the Zealot. Five augments.
- **Deflect** (nov_deflect.lua): vendored from QIangIQsZealotDeflect. Two augments.
- **Penitent Pyre** (nov_pyre.lua): new. 12 s, burns enemies within 6 m (flamer_assault stacks), burns melee
  attackers, +25% damage vs burning, +10% move speed, toughness per burning enemy. Augments: Wide Pyre,
  Feed the Flame, Ember Heart.
- **Look** (nov_visual.lua): default = datamined Dauntless Battle Sister gear, face and hair (retail units,
  nothing to install); option "Sister Lacrima" (Custom Assets unit, needs the patcher).

## Standalone
No required dependencies. Optional: Custom Assets (Lacrima model), QIangIQsScumHook + Custom Assets (Roadhog
hook head; otherwise the chain's own spear head).

## Status
Harness-checked only (loads against stubs, tree geometry and links validated). **Not tested in game.**
Known limits: Dauntless gear is female-fitted, other players do not see the look, Chain Hook's left-arm
animation on a Zealot is unverified, Martyrdom and the legacy Zealot tree conflict (warned).
