return {
    mod_name = {
        en = "QIangIQ's Halo Gallery",
    },
    mod_description = {
        en = "Shows Warframe halo / signa models (taken from your own Warframe install) behind your head or back, one at a time, picked from a list, each with its own saved position, turn and size. Works on the game's own characters and on the QIangIQ character models. Personal use only. By QIangIQ.",
    },
    enabled = {
        en = "Show the halo / signa",
    },
    enabled_description = {
        en = "Chat command: /halo (on / off for this session), /halo next, /halo prev, /halo <number>, /halo <part of a name>.",
    },
    item = {
        en = "Halo / signa",
    },
    item_description = {
        en = "Which halo / signa is shown. The sliders below belong to the halo / signa picked here and are saved for it.",
    },
    item_x = {
        en = "Move right / left (cm)",
    },
    item_x_description = {
        en = "Moves this halo / signa to your right (+) or left (-).",
    },
    item_y = {
        en = "Move forward / back (cm)",
    },
    item_y_description = {
        en = "Moves this halo / signa forward (+) or back (-).",
    },
    item_z = {
        en = "Move up / down (cm)",
    },
    item_z_description = {
        en = "Moves this halo / signa up (+) or down (-).",
    },
    item_yaw = {
        en = "Turn (degrees)",
    },
    item_yaw_description = {
        en = "Turns this halo / signa about the vertical.",
    },
    item_pitch = {
        en = "Tilt (degrees)",
    },
    item_pitch_description = {
        en = "Tilts this halo / signa forward / back.",
    },
    item_roll = {
        en = "Roll (degrees)",
    },
    item_roll_description = {
        en = "Rolls this halo / signa to the side.",
    },
    item_scale = {
        en = "Size",
    },
    item_scale_description = {
        en = "1 = its Warframe size.",
    },
    reset_item = {
        en = "Reset this halo / signa",
    },
    reset_item_description = {
        en = "Puts this halo / signa's position, turn and size back to the default.",
    },
    menu_previews = {
        en = "Show in menus (operative previews)",
    },
    menu_previews_description = {
        en = "Also shows it on your own operatives in menu previews.",
    },
    physics_group = {
        en = "Physics",
    },
    jiggle = {
        en = "Physics on",
    },
    jiggle_description = {
        en = "Cloth physics on the halo / signa's own Warframe cloth bones (items that have them; up to 32 bones each).",
    },
    jiggle_cloth = {
        en = "Amount",
    },
    jiggle_cloth_description = {
        en = "1 = as built. Higher = looser and wider swings, lower = tighter. 0 = does not move.",
    },
    jiggle_stiffness = {
        en = "Stiffness",
    },
    jiggle_stiffness_description = {
        en = "How hard the cloth is pulled back to its rest pose. 1 = as built. Higher = snaps back faster, lower = softer and slower.",
    },
    jiggle_damping = {
        en = "Damping",
    },
    jiggle_damping_description = {
        en = "How quickly the wobble dies out. 1 = as built. Higher = settles at once, lower = keeps bouncing longer.",
    },
    jiggle_limit = {
        en = "Swing limit",
    },
    jiggle_limit_description = {
        en = "Scales the largest angle a bone may swing away from its rest pose. 1 = as built.",
    },
    jiggle_hang = {
        en = "Hang",
    },
    jiggle_hang_description = {
        en = "How strongly the cloth is drawn straight down instead of keeping its modelled direction when you lean or look up and down. 0 = keep the modelled shape.",
    },
    next_keybind = {
        en = "Next halo / signa",
    },
    prev_keybind = {
        en = "Previous halo / signa",
    },
    toggle_keybind = {
        en = "On / off for this session",
    },
    halo_barosigna = {
        en = "Baro Signa",
    },
    halo_baruukdeluxeiihalo = {
        en = "Baruuk Deluxe II Halo",
    },
    halo_choirframehalo = {
        en = "Choir Frame Halo",
    },
    halo_dexvineshalo = {
        en = "Dex Vines Halo",
    },
    halo_dex2026lotushalo = {
        en = "Dex2026 Lotus Halo",
    },
    halo_duelistsigna = {
        en = "Duelist Signa",
    },
    halo_evilbarosekhara = {
        en = "Evil Baro Sekhara",
    },
    halo_gaussdeluxeiisigna = {
        en = "Gauss Deluxe II Signa",
    },
    halo_grendeldeluxeiisigna = {
        en = "Grendel Deluxe II Signa",
    },
    halo_heirloomemberhalo = {
        en = "Heirloom Ember Halo",
    },
    halo_heirloomfrosthalo = {
        en = "Heirloom Frost Halo",
    },
    halo_heirloommaghalo = {
        en = "Heirloom Mag Halo",
    },
    halo_heirloommesasigna = {
        en = "Heirloom Mesa Signa",
    },
    halo_heirloomrhinohalo = {
        en = "Heirloom Rhino Halo",
    },
    halo_heirloomvalkyrhalo = {
        en = "Heirloom Valkyr Halo",
    },
    halo_nightmare = {
        en = "Nightmare",
    },
    halo_qtcccatsigna = {
        en = "QTCC Cat Signa",
    },
    halo_swachetasigna = {
        en = "SW Acheta Signa",
    },
    halo_swcenturiosigna = {
        en = "SW Centurio Signa",
    },
    halo_swzamariusigna = {
        en = "SW Zamariu Signa",
    },
    halo_tntemplesigna = {
        en = "Tn Temple Signa",
    },
}
