return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsHaloGallery` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsHaloGallery", {
            mod_script = "QIangIQsHaloGallery/scripts/mods/QIangIQsHaloGallery/QIangIQsHaloGallery",
            mod_data = "QIangIQsHaloGallery/scripts/mods/QIangIQsHaloGallery/QIangIQsHaloGallery_data",
            mod_localization = "QIangIQsHaloGallery/scripts/mods/QIangIQsHaloGallery/QIangIQsHaloGallery_localization",
        })
    end,
    version = "1.1.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
