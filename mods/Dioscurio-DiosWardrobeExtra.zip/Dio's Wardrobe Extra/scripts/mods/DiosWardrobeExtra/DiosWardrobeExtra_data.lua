local mod = get_mod("DiosWardrobeExtra")

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
    widgets =
    {
      {
        setting_id    = "use_enemy_gear",
        title    = "use_enemy_gear_loc",
        type          = "checkbox",
        default_value = true,
      },
      {
        setting_id    = "use_infected_gear",
        title    = "use_infected_gear_loc",
        type          = "checkbox",
        default_value = false,
      },
      {
        setting_id    = "use_pox_gear",
        title    = "use_pox_gear_loc",
        type          = "checkbox",
        default_value = false,
      },
    },
	},
}
