local mod = get_mod("DiosWardrobeExtra")
local wardrobe = get_mod("DiosWardrobe")

local Promise = require("scripts/foundation/utilities/promise")
local MasterItems = require("scripts/backend/master_items")

mod.shorten_item_name = function(self, name)
  if not name then
    return "<nil>"
  end

  if name == "" then
    return name
  end

  local t = string.split(name, "/")

  return t[#t]
end

string.contains_any = function(str, ...)
  local t = {...}

  for k, v in pairs(t) do
    if string.find(str, v) then
      return true
    end
  end

  return false
end

mod:hook(wardrobe, "fetch_all_gear", function(func)
	return Promise.until_true(MasterItems.has_data):next(function()
		local items = {}

		local use_enemy_gear = mod:get("use_enemy_gear")
		local use_infected_gear = mod:get("use_infected_gear")
		local use_pox_gear = mod:get("use_pox_gear")

		for k, item in pairs(MasterItems.get_cached()) do
      --                                                                                        crash
			local skip = string.contains_any(k, "attachment_base", "/faces/", "attachments_default", "npc_emora_brahms_lowerbody")

			if not skip then
				local item_c = table.clone(item)

        -- enemy gear
        if use_enemy_gear and string.starts_with(k, "content/items/characters/minions/") then
          local short_name = mod:shorten_item_name(k)

          local use_item = false
          local ogryn = false

          if string.contains_any(k, "chaos_traitor_guard/attachments_gear", "chaos_cultists/attachments_gear") then
            use_item = true
          end
          if string.find(k, "chaos_ogryn/attachments_gear") then
            use_item = true
            ogryn = true
          end
          if string.find(k, "chaos_poxwalker/attachments_gear") then
            use_item = use_pox_gear
          end
          if string.find(k, "chaos_poxwalker/attachments_gear") then
            use_item = use_pox_gear
          end
          if string.find(short_name, "attachments_gear/newly_infected_") then
            use_item = use_infected_gear
          end

          if use_item then
            item_c["breeds"] = { ogryn and "ogryn" or "human"	}

            local skip_minion_item = string.contains_any(short_name, "decal", "_fx")

            if not skip_minion_item then
              if string.contains_any(short_name, "helmet", "hood", "goggle", "head", "mask", "_hat_") then
                item_c["slots"] = {"slot_gear_head"}
              elseif string.find(short_name, "lowerbody") then
                item_c["slots"] = {"slot_gear_lowerbody"}
              else
                item_c["slots"] = {"slot_gear_upperbody"}
              end
            end
          end
        end

				items[#items+1] = item_c
			end
		end

		return items
	end)
end)

mod.on_setting_changed = function(setting_name)
  -- update available item list when adding/removing enemy gears from the available attachments
  wardrobe:fetch_avaiable_attachment_per_slot_per_breed()
end
