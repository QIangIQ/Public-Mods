return {
	mod_name =
	{
		en = "Dio's Wardrobe Extra",
	},
	mod_description =
	{
		en = "Addon for Dio's Wardrobe - add more attachments",
	},
	use_enemy_gear_loc =
	{
		en = "Use enemy gear attachments",
	},
	use_infected_gear_loc =
	{
		en = "Use infested gear attachments",
	},
	use_pox_gear_loc =
	{
		en = "Use poxwalker gear attachments",
	},
}
