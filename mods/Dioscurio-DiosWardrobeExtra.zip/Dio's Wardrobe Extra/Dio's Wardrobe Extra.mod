return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`DiosWardrobeExtra` encountered an error loading the Darktide Mod Framework.")

		new_mod("DiosWardrobeExtra", {
			mod_script       = "Dio's Wardrobe Extra/scripts/mods/DiosWardrobeExtra/DiosWardrobeExtra",
			mod_data         = "Dio's Wardrobe Extra/scripts/mods/DiosWardrobeExtra/DiosWardrobeExtra_data",
			mod_localization = "Dio's Wardrobe Extra/scripts/mods/DiosWardrobeExtra/DiosWardrobeExtra_localization",
		})
	end,
	version = "1.0.0",
	packages = {},
}
