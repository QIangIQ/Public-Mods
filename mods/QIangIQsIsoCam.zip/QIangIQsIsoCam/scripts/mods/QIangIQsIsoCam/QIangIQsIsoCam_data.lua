local mod = get_mod("QIangIQsIsoCam")

local function numeric(id, default, lo, hi, decimals, title, tooltip)
	return { setting_id = id, type = "numeric", default_value = default, range = { lo, hi }, decimals_number = decimals, localize = false, title = title, tooltip = tooltip }
end

local function checkbox(id, default, title, tooltip)
	return { setting_id = id, type = "checkbox", default_value = default, localize = false, title = title, tooltip = tooltip }
end

local function keybind(id, fn, title, tooltip)
	return { setting_id = id, type = "keybind", default_value = {}, keybind_trigger = "pressed", keybind_type = "function_call", function_name = fn, localize = false, title = title, tooltip = tooltip }
end

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			keybind("toggle_key", "kb_toggle_iso", "Toggle isometric camera (key)", "Switches between the isometric camera and the normal camera during a mission."),
			keybind("assist_key", "kb_toggle_assist", "Toggle aim assist (key)", "Turns the aim assist on or off."),
			keybind("center_key", "kb_center_cursor", "Recentre aim cursor (key)", "Puts the aim cursor back in front of your character."),
			keybind("mode_key", "kb_toggle_mode", "Toggle camera mode (key)", "Switches between a fixed heading and a camera that follows your view."),
			checkbox("iso_on", true, "Isometric camera on", "Fixed camera looking down at your character."),
			{ setting_id = "camera_mode", type = "dropdown", default_value = "fixed", localize = false, title = "Camera heading", tooltip = "Fixed: the camera never rotates, the mouse moves an aim cursor, WASD follow the screen and shift sprints in any direction. Follows view: the camera turns with your view like the normal camera, the mouse turns you, W is always up the screen and S down.", options = { { text = "Fixed", value = "fixed", show_widget_localization = false }, { text = "Follows my view", value = "follow", show_widget_localization = false } } },
			checkbox("wall_hide", true, "Hide walls between camera and player", "Casts a cone of rays from the camera to a disc around your character and hides the level pieces they hit, so you stay visible in small rooms and corners."),
			numeric("see_through_radius", 1.4, 0.5, 4, 1, "Wall hide cone width (metres)", "Radius of the disc around your character that the cone covers. Wider hides more of the surroundings."),
			checkbox("fps_audio", true, "First-person audio", "Sound is heard from your character instead of from the camera."),
			checkbox("cam_relative_move", true, "Move relative to the screen", "W moves up the screen, D moves right, no matter where your character faces. Turn off to keep Darktide's normal movement."),
			checkbox("assist_on", true, "Aim assist", "Pulls your aim onto enemies near the cursor."),
			{ setting_id = "assist_target", type = "dropdown", default_value = "head", localize = false, title = "Aim assist target", tooltip = "Which part of the enemy the assist pulls your aim onto.", options = { { text = "Head", value = "head", show_widget_localization = false }, { text = "Torso", value = "torso", show_widget_localization = false } } },
			numeric("assist_radius", 2.2, 0.5, 6, 1, "Aim assist radius (metres)", "How close to the cursor, measured on the ground, an enemy must be to be picked."),
			numeric("assist_strength", 0.85, 0, 1, 2, "Aim assist strength", "0 = no pull, 1 = aim locks fully onto the enemy's torso."),
			numeric("assist_snap", 22, 5, 60, 0, "Aim assist snap speed", "How fast the aim slides onto the enemy. Higher is snappier."),
			numeric("distance", 14, 6, 40, 1, "Camera distance (metres)", "How far the camera sits from your character."),
			numeric("pitch", 52, 20, 85, 0, "Camera angle (degrees down)", "35 is a flat isometric look, 85 is almost straight down."),
			numeric("yaw", 45, 0, 359, 0, "Camera heading (degrees)", "Which compass direction the camera looks toward. It never changes during play."),
			numeric("fov", 38, 15, 70, 0, "Camera field of view", "A narrow field of view with a long distance looks closest to true isometric."),
			numeric("target_height", 1.0, 0, 3, 1, "Look-at height (metres)", "Height above your feet that stays in the centre of the screen."),
			numeric("cursor_sens", 0.6, 0.1, 3, 2, "Cursor speed", "How fast the mouse moves the aim cursor across the screen."),
			numeric("aim_height", 1.2, 0.5, 1.8, 1, "Aim height (metres)", "Height above your feet of the flat plane your cursor aims along."),
		},
	},
}
