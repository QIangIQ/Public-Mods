local mod = get_mod("QIangIQsIsoCam")

--[[
	Isometric top-down camera + cursor aim + aim assist.

	Camera : CameraManager._update_camera_properties is hooked and the pose of the follow camera is
	         replaced with a heading/pitch at a distance from the followed unit (the local player, a
	         spectated player, or the dead-camera position). RootCamera.use_collision is forced off.
	         Fixed mode keeps one heading; follow mode uses the player's own view yaw as the heading.
	Walls  : a cone of rays from the camera to a disc around the player is cast against statics and the
	         units hit are hidden with Unit.set_unit_visibility until they stop blocking the view.
	Aim    : (fixed mode, missions) DefaultPlayerOrientation.pre_update runs normally, the mouse look
	         delta becomes movement of a virtual cursor, then yaw/pitch are overwritten so the character
	         looks at the cursor point on a ground plane.
	Assist : broadphase enemy query around the aim point, aimed at "enemy_aim_target_02".
	Move   : InputService "move" is rotated so W/A/S/D follow the screen (fixed mode), also in the hub.
	Reticle: Crosshair.position puts the game's crosshair on the aim point.
]]

local PI = math.pi
local TAU = PI * 2
local CURSOR_LIMIT = 0.92
local AIM_NODE = "enemy_aim_target_02"
local HEAD_NODE = "enemy_aim_target_03"
local SCAN_INTERVAL = 0.08
local HIDE_HOLD = 0.4
local HIT_IDX_DISTANCE = 2
local HIT_IDX_ACTOR = 4
local MAX_HIDE_EXTENT = 40
local HIT_CLEARANCE = 0.3

local cfg = {}
local iso = {
	active = false, -- true on frames where the camera hook replaced the pose
	is_local = false, -- true when that pose follows the local player's own unit
	forced_3p = false,
	failed = false,
	cam_x = 0, cam_y = 0, cam_z = 0,
	tx = 0, ty = 0, tz = 0,
	basis = nil,
	cam_heading = 0,
	aim_yaw = 0,
	cx = 0,
	cy = 0.25,
	ox = 0, oy = 0, oz = 0,
	lock = nil,
	has_aim = false,
	ax = 0, ay = 0, az = 0,
	in_hub = false,
	own_unit = nil,
}
local broadphase_results = {}
local dbg = { scans = 0, rays = 0, rows = 0, hid = 0, big = 0, floor = 0, no_unit = 0, last_log = 0, err = 0 }
local hidden = {}
local last_scan = 0
local scan_offsets = {}

do
	scan_offsets[1] = { 0, 0 }

	for i = 0, 7 do
		local a = i / 8 * TAU

		scan_offsets[#scan_offsets + 1] = { math.cos(a), math.sin(a) }
	end

	for i = 0, 3 do
		local a = i / 4 * TAU + PI / 8

		scan_offsets[#scan_offsets + 1] = { math.cos(a) * 0.5, math.sin(a) * 0.5 }
	end
end

local function refresh_settings()
	cfg.iso_on = mod:get("iso_on")
	cfg.follow = mod:get("camera_mode") == "follow"
	cfg.cam_relative_move = mod:get("cam_relative_move")
	cfg.assist_on = mod:get("assist_on")
	cfg.aim_head = mod:get("assist_target") ~= "torso"
	cfg.assist_radius = mod:get("assist_radius")
	cfg.assist_strength = mod:get("assist_strength")
	cfg.assist_snap = mod:get("assist_snap")
	cfg.distance = mod:get("distance")
	cfg.pitch = math.rad(mod:get("pitch"))
	cfg.yaw = math.rad(mod:get("yaw"))
	cfg.fov = math.rad(mod:get("fov"))
	cfg.target_height = mod:get("target_height")
	cfg.cursor_sens = mod:get("cursor_sens")
	cfg.aim_height = mod:get("aim_height")
	cfg.see_through = mod:get("wall_hide")
	cfg.fps_audio = mod:get("fps_audio")
	cfg.see_through_radius = mod:get("see_through_radius")
end
refresh_settings()

mod.on_setting_changed = function(id)
	refresh_settings()
end

local function wrap_pi(a)
	return (a + PI) % TAU - PI
end

local function local_player()
	return Managers.player and Managers.player:local_player(1)
end

local function in_world()
	local game_mode_manager = Managers.state and Managers.state.game_mode
	local name = game_mode_manager and game_mode_manager:game_mode_name()

	iso.in_hub = name == "hub" or name == "prologue_hub"

	return name ~= nil
end

local function wanted()
	return cfg.iso_on and not iso.failed
end

local function input_wanted()
	if not (wanted() and iso.active) then
		return false
	end

	return not (Managers.input and Managers.input:cursor_active())
end

local function set_forced_third_person(unit, value)
	local extension = ScriptUnit.has_extension(unit, "first_person_system")

	if extension then
		extension._force_third_person_mode = value
	end
end

-- -------------------------------------------------------------- wall hiding --

local function unhide_all()
	for unit in pairs(hidden) do
		if ALIVE[unit] then
			pcall(Unit.set_unit_visibility, unit, true, true)
		end
	end

	table.clear(hidden)
end

local function scan_walls(camera_manager)
	local now = Managers.time:time("main")

	if now - last_scan < SCAN_INTERVAL then
		return
	end

	last_scan = now

	local physics_world = camera_manager._physics_world

	if not physics_world then
		return
	end

	local camera_position = Vector3(iso.cam_x, iso.cam_y, iso.cam_z)
	local target = Vector3(iso.tx, iso.ty, iso.tz)
	local b = iso.basis
	local right = Vector3(b[4], b[5], b[6])
	local up = Vector3(b[7], b[8], b[9])
	local radius = cfg.see_through_radius
	local floor_z = iso.tz - cfg.target_height + 0.25

	for i = 1, #scan_offsets do
		local offset = scan_offsets[i]
		local point = target + right * (offset[1] * radius) + up * (offset[2] * radius)
		local to_point = point - camera_position
		local distance = Vector3.length(to_point)

		if distance > 1 then
			local direction = Vector3.normalize(to_point)
			local hits, num_hits = PhysicsWorld.raycast(physics_world, camera_position, direction, distance - HIT_CLEARANCE, "all", "types", "both", "collision_filter", "filter_player_character_shooting_raycast_statics")

			dbg.rays = dbg.rays + 1

			if hits and num_hits and num_hits > 0 then
				for j = 1, num_hits do
					local hit = hits[j]
					local actor = hit and hit[HIT_IDX_ACTOR]
					local unit = actor and Actor.unit(actor)

					dbg.rows = dbg.rows + 1

					if not unit then
						dbg.no_unit = dbg.no_unit + 1
					elseif ALIVE[unit] and not (unit == iso.own_unit) then
						if hidden[unit] then
							hidden[unit] = now + HIDE_HOLD
						else
							local hit_position = hit[1]
							local ok, _, extents = pcall(Unit.box, unit)
							local too_big = ok and extents and math.max(extents.x, extents.y, extents.z) > MAX_HIDE_EXTENT

							if too_big then
								dbg.big = dbg.big + 1
							elseif hit_position and hit_position.z <= floor_z then
								dbg.floor = dbg.floor + 1
							else
								Unit.set_unit_visibility(unit, false, true)

								hidden[unit] = now + HIDE_HOLD
								dbg.hid = dbg.hid + 1
							end
						end
					end
				end
			end
		end
	end

	dbg.scans = dbg.scans + 1

	if now - dbg.last_log > 3 then
		dbg.last_log = now

		local count = 0

		for _ in pairs(hidden) do
			count = count + 1
		end

		mod:info("wall hide: scans=%d rays=%d rows=%d newly_hidden=%d hidden_now=%d skipped_big=%d skipped_floor=%d no_unit=%d", dbg.scans, dbg.rays, dbg.rows, dbg.hid, count, dbg.big, dbg.floor, dbg.no_unit)
	end

	for unit, expire in pairs(hidden) do
		if not ALIVE[unit] then
			hidden[unit] = nil
		elseif expire < now then
			Unit.set_unit_visibility(unit, true, true)

			hidden[unit] = nil
		end
	end
end

-- ------------------------------------------------------------------ camera --

local function fail(tag, err)
	iso.failed = true
	iso.active = false
	mod:error("QIangIQsIsoCam disabled itself after an error in %s: %s", tag, tostring(err))
	mod:notify("Isometric camera hit an error and switched itself off (see console log).")
end

local function restore_camera()
	if iso.forced_3p then
		iso.forced_3p = false

		local player = local_player()
		local unit = player and player.player_unit

		if unit and ALIVE[unit] then
			set_forced_third_person(unit, false)
		end
	end

	unhide_all()

	iso.active = false
	iso.is_local = false
	iso.has_aim = false
end

local function apply_camera(camera_manager, camera_nodes, camera_data, viewport_name)
	iso.active = false
	iso.is_local = false

	local player = local_player()

	if not player or viewport_name ~= player.viewport_name or not in_world() then
		return
	end

	local top = camera_nodes[#camera_nodes]
	local node = top and top.node

	if not node then
		return
	end

	local own_unit = player.player_unit
	local own_alive = own_unit and ALIVE[own_unit]
	local root_unit, root_object = node:root_unit()
	local base

	if root_unit and ALIVE[root_unit] then
		if not ScriptUnit.has_extension(root_unit, "first_person_system") then
			return
		end

		base = Unit.world_position(root_unit, root_object or 1)
	elseif not root_unit and not own_alive and node._root_position then
		base = node._root_position:unbox()
	end

	if not base then
		return
	end

	local is_local = own_alive and root_unit == own_unit

	iso.own_unit = own_unit

	if is_local then
		set_forced_third_person(own_unit, true)

		iso.forced_3p = true
	end

	local heading = cfg.yaw

	if cfg.follow and is_local then
		heading = iso.aim_yaw
	end

	local target = base + Vector3(0, 0, cfg.target_height)
	local rotation = Quaternion.from_yaw_pitch_roll(heading, -cfg.pitch, 0)
	local forward = Quaternion.forward(rotation)
	local position = target - forward * cfg.distance

	camera_data.position = position
	camera_data.rotation = rotation
	camera_data.vertical_fov = cfg.fov

	-- Quaternion/Vector3 values are temporaries in the engine, so keep plain numbers
	local right, up = Quaternion.right(rotation), Quaternion.up(rotation)

	iso.basis = { forward.x, forward.y, forward.z, right.x, right.y, right.z, up.x, up.y, up.z }
	iso.cam_x, iso.cam_y, iso.cam_z = position.x, position.y, position.z
	iso.tx, iso.ty, iso.tz = target.x, target.y, target.z
	iso.cam_heading = heading
	iso.is_local = is_local and true or false
	iso.active = true

	if cfg.see_through then
		local ok, err = pcall(scan_walls, camera_manager)

		if not ok then
			cfg.see_through = false
			unhide_all()
			mod:error("QIangIQsIsoCam turned wall hiding off after an error: %s", tostring(err))
		end
	end
end

mod:hook(CLASS.CameraManager, "_update_camera_properties", function(func, self, camera, shadow_cull_camera, camera_nodes, camera_data, viewport_name)
	if wanted() then
		local ok, err = pcall(apply_camera, self, camera_nodes, camera_data, viewport_name)

		if not ok then
			fail("camera", err)
			restore_camera()
		elseif not iso.active and next(hidden) then
			unhide_all()
		end
	elseif iso.forced_3p or iso.active or next(hidden) then
		pcall(restore_camera)
	end

	return func(self, camera, shadow_cull_camera, camera_nodes, camera_data, viewport_name)
end)

-- First-person style audio: the sound listener sits at the character instead of the far-away camera.
mod:hook(CLASS.CameraManager, "listener_pose", function(func, self, viewport_name)
	if cfg.fps_audio and iso.active and wanted() then
		local player = local_player()

		if player and viewport_name == player.viewport_name then
			return Matrix4x4.from_quaternion_position(Quaternion.from_yaw_pitch_roll(iso.cam_heading, 0, 0), Vector3(iso.tx, iso.ty, iso.tz))
		end
	end

	return func(self, viewport_name)
end)

mod:hook_require("scripts/managers/camera/cameras/root_camera", function(RootCamera)
	mod:hook(RootCamera, "use_collision", function(func, self)
		if iso.active then
			return false
		end

		return func(self)
	end)
end)

-- Other camera mods (Perspectives) rewrite _force_third_person_mode on their own events; answering the
-- mode query directly keeps the full 3rd-person body and equipment shown whatever they do.
mod:hook_require("scripts/extension_systems/first_person/player_unit_first_person_extension", function(PlayerUnitFirstPersonExtension)
	mod:hook(PlayerUnitFirstPersonExtension, "_update_first_person_mode", function(func, self, t)
		if self._is_local_unit and iso.active and wanted() then
			return false, false
		end

		return func(self, t)
	end)
end)

-- Spectating: show the followed player's full body instead of first-person arms.
mod:hook_require("scripts/extension_systems/first_person/player_husk_first_person_extension", function(PlayerHuskFirstPersonExtension)
	mod:hook(PlayerHuskFirstPersonExtension, "_update_first_person_mode", function(func, self, t)
		if self._is_first_person_spectated and iso.active and wanted() then
			return false, false
		end

		return func(self, t)
	end)
end)

mod:hook(CLASS.MissionManager, "force_third_person_mode", function(func, self)
	local request_3p = func(self)

	if wanted() then
		return true
	end

	return request_3p
end)

-- --------------------------------------------------------------------- aim --

local function find_target(unit, px, py, pz)
	local extension_manager = Managers.state.extension
	local side_system = extension_manager:system("side_system")
	local side = side_system.side_by_unit[unit]

	if not side then
		return nil
	end

	local enemy_side_names = side:relation_side_names("enemy")
	local broadphase = extension_manager:system("broadphase_system").broadphase
	local radius = cfg.assist_radius

	table.clear(broadphase_results)

	local num_results = broadphase.query(broadphase, Vector3(px, py, pz), radius + 2, broadphase_results, enemy_side_names)
	local best_unit, best_score, bx, by, bz

	for i = 1, num_results do
		local enemy = broadphase_results[i]

		if HEALTH_ALIVE[enemy] then
			local pos

			if cfg.aim_head and Unit.has_node(enemy, HEAD_NODE) then
				pos = Unit.world_position(enemy, Unit.node(enemy, HEAD_NODE))
			elseif Unit.has_node(enemy, AIM_NODE) then
				pos = Unit.world_position(enemy, Unit.node(enemy, AIM_NODE))
			else
				pos = Unit.world_position(enemy, 1) + Vector3(0, 0, 1)
			end

			local dx, dy = pos.x - px, pos.y - py
			local distance = math.sqrt(dx * dx + dy * dy)
			local score = enemy == iso.lock and distance * 0.6 or distance

			if distance <= radius * 1.6 and score <= radius and (not best_score or score < best_score) then
				best_unit, best_score, bx, by, bz = enemy, score, pos.x, pos.y, pos.z
			end
		end
	end

	return best_unit, bx, by, bz
end

local function update_aim(orientation_self, orientation, previous_yaw, previous_pitch, dt)
	local player = orientation_self._player
	local unit = player.player_unit

	if not unit or not iso.basis then
		return
	end

	local camera = Managers.state.camera:camera(player.viewport_name)
	local vertical_fov = Camera.vertical_fov(camera)
	local half_v = vertical_fov * 0.5
	local aspect = RESOLUTION_LOOKUP.width / RESOLUTION_LOOKUP.height
	local tan_v = math.tan(half_v)
	local tan_h = tan_v * aspect

	local look_right = wrap_pi(previous_yaw - orientation.yaw)
	local look_up = wrap_pi(orientation.pitch - previous_pitch)

	iso.cx = math.clamp(iso.cx + look_right * cfg.cursor_sens / (half_v * aspect), -CURSOR_LIMIT, CURSOR_LIMIT)
	iso.cy = math.clamp(iso.cy + look_up * cfg.cursor_sens / half_v, -CURSOR_LIMIT, CURSOR_LIMIT)

	local b = iso.basis
	local kx, ky = iso.cx * tan_h, iso.cy * tan_v
	local dir_x = b[1] + b[4] * kx + b[7] * ky
	local dir_y = b[2] + b[5] * kx + b[8] * ky
	local dir_z = b[3] + b[6] * kx + b[9] * ky

	if dir_z > -0.001 then
		return
	end

	local feet = Unit.world_position(unit, 1)
	local plane_z = feet.z + cfg.aim_height
	local t = (plane_z - iso.cam_z) / dir_z
	local px, py = iso.cam_x + dir_x * t, iso.cam_y + dir_y * t

	local target_ox, target_oy, target_oz = 0, 0, 0
	local lock

	if cfg.assist_on and cfg.assist_strength > 0 then
		local target, tx, ty, tz = find_target(unit, px, py, plane_z)

		if target then
			lock = target
			target_ox = (tx - px) * cfg.assist_strength
			target_oy = (ty - py) * cfg.assist_strength
			target_oz = (tz - plane_z) * cfg.assist_strength
		end
	end

	iso.lock = lock

	local blend = 1 - math.exp(-cfg.assist_snap * dt)

	iso.ox = iso.ox + (target_ox - iso.ox) * blend
	iso.oy = iso.oy + (target_oy - iso.oy) * blend
	iso.oz = iso.oz + (target_oz - iso.oz) * blend

	local ax, ay, az = px + iso.ox, py + iso.oy, plane_z + iso.oz
	local origin = orientation_self._first_person_component.position
	local dx, dy, dz = ax - origin.x, ay - origin.y, az - origin.z
	local flat = math.sqrt(dx * dx + dy * dy)

	iso.ax, iso.ay, iso.az = ax, ay, az
	iso.has_aim = true

	local yaw = previous_yaw

	if flat > 0.15 then
		yaw = math.atan2(-dx, dy)
	end

	local pitch = math.clamp(math.atan2(dz, flat), orientation_self._min_pitch, orientation_self._max_pitch)
	orientation.yaw = math.mod_two_pi(yaw)
	orientation.pitch = math.mod_two_pi(pitch)
	orientation.roll = 0
	iso.aim_yaw = orientation.yaw
end

mod:hook_require("scripts/extension_systems/first_person/character_state_orientation/default_player_orientation", function(DefaultPlayerOrientation)
	mod:hook(DefaultPlayerOrientation, "pre_update", function(func, self, main_t, main_dt, input, sensitivity_modifier, rotation_contraints)
		local orientation = self._orientation
		local previous_yaw, previous_pitch = orientation.yaw, orientation.pitch

		func(self, main_t, main_dt, input, sensitivity_modifier, rotation_contraints)

		if self._player ~= local_player() then
			return
		end

		if not input_wanted() then
			iso.has_aim = false

			return
		end

		if cfg.follow then
			iso.aim_yaw = orientation.yaw
			iso.has_aim = false

			return
		end

		local ok, err = pcall(update_aim, self, orientation, previous_yaw, previous_pitch, main_dt)

		if not ok then
			fail("aim", err)
			restore_camera()
		end
	end)
end)

-- The hub has no aiming; only track the view yaw so screen-relative movement / follow mode work.
mod:hook_require("scripts/extension_systems/first_person/character_state_orientation/hub_player_orientation", function(HubPlayerOrientation)
	mod:hook(HubPlayerOrientation, "pre_update", function(func, self, ...)
		func(self, ...)

		if self._player == local_player() then
			iso.aim_yaw = self._orientation.yaw
			iso.has_aim = false
		end
	end)
end)

-- Put the game's own crosshair on the aim point instead of 50 m down the character's line of sight.
mod:hook_require("scripts/ui/utilities/crosshair", function(Crosshair)
	mod:hook(Crosshair, "position", function(func, dt, t, ui_hud, ui_renderer, current_x, current_y, pivot_position)
		if not (iso.has_aim and input_wanted()) then
			return func(dt, t, ui_hud, ui_renderer, current_x, current_y, pivot_position)
		end

		local player_camera = ui_hud:player_camera()

		if not player_camera then
			return func(dt, t, ui_hud, ui_renderer, current_x, current_y, pivot_position)
		end

		local screen = Camera.world_to_screen(player_camera, Vector3(iso.ax, iso.ay, iso.az))
		local inverse_scale = ui_renderer.inverse_scale

		return (screen.x - pivot_position[1]) * inverse_scale, (screen.y - pivot_position[2]) * inverse_scale
	end)
end)

-- -------------------------------------------------------------------- move --

local function input_hook(func, self, action_name)
	local value = func(self, action_name)

	if action_name == "move" and cfg.cam_relative_move and not cfg.follow and iso.is_local and input_wanted() then
		local angle = iso.cam_heading - iso.aim_yaw
		local c, s = math.cos(angle), math.sin(angle)

		return Vector3(value.x * c - value.y * s, value.x * s + value.y * c, value.z)
	end

	return value
end

mod:hook(CLASS.InputService, "_get", input_hook)
mod:hook(CLASS.InputService, "_get_simulate", input_hook)

-- ---------------------------------------------------------------- plumbing --

local function in_menu()
	return Managers.input and Managers.input:cursor_active()
end

mod.kb_toggle_iso = function()
	if in_menu() then
		return
	end

	iso.failed = false
	mod:set("iso_on", not mod:get("iso_on"))
	refresh_settings()
	mod:notify("Isometric camera %s", cfg.iso_on and "on" or "off")
end

mod.kb_toggle_assist = function()
	if in_menu() then
		return
	end

	mod:set("assist_on", not mod:get("assist_on"))
	refresh_settings()
	mod:notify("Aim assist %s", cfg.assist_on and "on" or "off")
end

mod.kb_toggle_mode = function()
	if in_menu() then
		return
	end

	mod:set("camera_mode", cfg.follow and "fixed" or "follow")
	refresh_settings()
	mod:notify("Isometric camera: %s", cfg.follow and "follows your view" or "fixed heading")
end

mod:command("iso_debug", "Isometric camera: print wall-hide counters", function()
	mod:echo("wall hide: on=%s scans=%d rays=%d rows=%d newly_hidden=%d skipped_big=%d skipped_floor=%d no_unit=%d active=%s", tostring(cfg.see_through), dbg.scans, dbg.rays, dbg.rows, dbg.hid, dbg.big, dbg.floor, dbg.no_unit, tostring(iso.active))
end)

mod.kb_center_cursor = function()
	iso.cx, iso.cy = 0, 0.25
	iso.ox, iso.oy, iso.oz = 0, 0, 0
end

mod.on_disabled = function()
	pcall(restore_camera)
end

mod.on_unload = function()
	pcall(restore_camera)
end

mod.on_game_state_changed = function(status)
	if status == "enter" then
		iso.cx, iso.cy = 0, 0.25
		iso.ox, iso.oy, iso.oz = 0, 0, 0
		iso.lock = nil
		iso.active = false
		iso.is_local = false
		iso.has_aim = false
		iso.forced_3p = false
		table.clear(hidden)
	end
end
