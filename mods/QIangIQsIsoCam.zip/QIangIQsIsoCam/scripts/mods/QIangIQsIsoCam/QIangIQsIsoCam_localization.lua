return {
	mod_name = {
		en = "QIangIQ's Isometric Camera",
	},
	mod_description = {
		en = "Fixed-angle isometric top-down camera that never rotates and always keeps you centred (Project Zomboid style). The mouse moves an aim cursor on the ground instead of turning the camera, WASD moves relative to the screen, and an optional aim assist pulls the aim onto enemies near the cursor.",
	},
}
