return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsIsoCam` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsIsoCam", {
			mod_script       = "QIangIQsIsoCam/scripts/mods/QIangIQsIsoCam/QIangIQsIsoCam",
			mod_data         = "QIangIQsIsoCam/scripts/mods/QIangIQsIsoCam/QIangIQsIsoCam_data",
			mod_localization = "QIangIQsIsoCam/scripts/mods/QIangIQsIsoCam/QIangIQsIsoCam_localization",
		})
	end,
	packages = {},
}
