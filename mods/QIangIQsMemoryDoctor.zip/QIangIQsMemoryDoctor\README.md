# QIangIQs Memory Doctor

One Lua garbage-collector manager for Darktide, combining:

- **FpsDoctor** (1.3.1) - time-budgeted incremental GC, smooth cleaning spread over frames, frame-headroom back-off, pacer, periodic/threshold/adaptive cleans, FPS & heap overlay, per-mission leak verdict.
- **SMOG Cleaner** - heap-% pressure ladder, convenient-moment cleans, cinematic/loading safety, the analogue / digital / advanced HUDs and notices (renderers reused), unclean-shutdown notice, `--lua-heap-mb-size` detection.
- **MemLeakFix** (我是派蒙啊) - fixed pause/stepmul tuning, available as its own mode.

Modes: Off, Map only, Balanced, Pacer, Adaptive, Aggressive (default), MemLeakFix, Extreme, Custom.

Commands: `/memclean`, `/memstats`, `/memmode <mode>`. Keys: F5 clean now, F6 overlay, F8 HUD (press again within 3 s to cycle formats).

Do not run together with FpsDoctor, SMOG or MemLeakFix.

Only the Lua heap can be cleaned from a mod; engine memory (textures, units, audio) is not reachable from Lua.
