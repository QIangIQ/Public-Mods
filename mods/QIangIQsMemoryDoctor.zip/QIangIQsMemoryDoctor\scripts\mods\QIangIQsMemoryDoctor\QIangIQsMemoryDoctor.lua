local mod = get_mod("QIangIQsMemoryDoctor")

-- ==========================================================================
-- QIangIQs Memory Doctor
-- ==========================================================================
-- One Lua garbage-collector manager built from three mods:
--
--   FpsDoctor 1.3.1   time-budgeted incremental GC, smooth "drain" collects
--                     spread over frames, frame-headroom back-off, the pacer,
--                     periodic / threshold / adaptive collects, the FPS &
--                     heap overlay, per-mission leak verdict, floor drift.
--   SMOG Cleaner      heap-%-driven pressure ladder (70 gentle / 80 high /
--                     boosted / 85 warn / 90 & 95 collect), collects at
--                     convenient moments (map start/exit after the debrief,
--                     hub, sanctuary, activity start), cinematic / loading
--                     blocking, low-yield detection, growth-spike collect,
--                     the three HUDs + notices, unclean-shutdown notice,
--                     --lua-heap-mb-size detection.
--   MemLeakFix        fixed pause / stepmul tuning (its own "MemLeakFix" mode).
--
-- Everything the three did is done here by ONE owner of setpause/setstepmul,
-- so they no longer overwrite each other, and the engine's original values
-- are captured once and restored on disable/unload (FpsDoctor apply_tuning /
-- restore_default_gc, SMOG apply_gc_tuning / restore_gc_tuning).
--
-- Scope: collectgarbage() works on the Lua heap only. Engine memory
-- (textures, units, audio) is not reachable from Lua; the advanced HUD shows
-- process memory for comparison (SMOG, Memory.usage).
--
-- Do not run this together with FpsDoctor, SMOG or MemLeakFix - they tune
-- the same collector. A warning is printed if any of them is enabled.

local Managers = Managers
local collectgarbage = collectgarbage
local math_abs, math_floor, math_max, math_min = math.abs, math.floor, math.max, math.min
local string_format = string.format
local tostring, tonumber, type, pcall, rawget = tostring, tonumber, type, pcall, rawget
local table_sort = table.sort

local dmf = get_mod("DMF")

-- ------------------------------------------------------------------ modes --
-- Each mode is a full parameter set. "custom" reads every slider directly.
-- Values for balanced / pacer / aggressive are FpsDoctor's MODE_PRESETS and
-- PACER_* constants; adaptive is SMOG's behaviour; memleakfix is MemLeakFix's
-- defaults (pause_time 1 -> setpause 10, step_mul 5 -> setstepmul 500).
local MODES = {
	off = {},
	map_only = { map_collects = true },
	balanced = { tune = true, pause = 150, stepmul = 200, budget_us = 1000, map_collects = true },
	pacer = { tune = true, pause = 400, stepmul = 100, budget_us = 500, pacer = true, pacer_headroom_mb = 24,
		map_collects = true, threshold_percent = 95 },
	adaptive = { ladder = true, moments = true, map_collects = true, growth_percent = 15 },
	aggressive = { tune = true, pause = 150, stepmul = 300, budget_us = 1500, periodic_minutes = 10,
		threshold_percent = 85, adaptive_trigger = true, ladder = true, moments = true, map_collects = true,
		growth_percent = 15, double_collect = true },
	memleakfix = { tune = true, pause = 10, stepmul = 500 },
	extreme = { tune = true, pause = 100, stepmul = 400, budget_us = 3000, pacer = true, pacer_headroom_mb = 0,
		periodic_minutes = 3, threshold_percent = 60, adaptive_trigger = true, ladder = true, moments = true,
		map_collects = true, growth_percent = 8, double_collect = true },
}

local MODE_ORDER = { "off", "map_only", "balanced", "pacer", "adaptive", "aggressive", "memleakfix", "extreme", "custom" }

-- ------------------------------------------------------------- constants --
local PAUSE_FRAME_S = 0.5 -- FpsDoctor: frames longer than this are a pause, not a hitch
local SAMPLE_MAX = 1000
local DRAIN_STEP_KB, DRAIN_MAX_STEPS, GC_DRAIN_MAX_FRAMES, FALLBACK_STEP_KB = 32, 24, 1800, 256
local PACER_STEP_KB, PACER_MAX_STEPS = 16, 8
local IDLE_BUDGET_MULT = 3 -- FpsDoctor: more GC work allowed outside gameplay
local SPIKE_MULT = 1.5 -- FpsDoctor PACER_SPIKE_MULT / SMOG transient_frame_spike_multiplier
local SOFT_THRESHOLD_FRAC, ADAPTIVE_RATE_MB_MIN = 0.75, 8.0
local EMERGENCY_COOLDOWN_S, EMERGENCY_REARM_MB, PERIODIC_MIN_GROWTH_MB = 60, 64, 32
local LEAK_WATCH_MB, LEAK_LIKELY_MB = 120, 300
local GC_HITCH_ATTRIB_MS = 5
-- SMOG ladder
local LADDER_GENTLE, LADDER_LEAVE, LADDER_EXIT_HIGH = 70, 68, 78
local LADDER_HIGH, LADDER_WARN, LADDER_NINETY, LADDER_NINETYFIVE = 80, 85, 90, 95
local HIGH_DELAY_S, BOOST_DELAY_S = 5, 25
local HIGH_PAUSE, HIGH_STEPMUL, BOOST_PAUSE, BOOST_STEPMUL = 80, 500, 65, 700
local GENTLE_STEP_KB, GENTLE_MAX_STEPS, GENTLE_BUDGET_S = 16, 8, 0.0005
local STAGED_STEP_KB, STAGED_MAX_STEPS, STAGED_BUDGET_S = 32, 16, 0.001
local GROWTH_WINDOW_S = 30
local HUB_CLEAN_DELAY_S, EXIT_CLEAN_DELAY_S, CONVENIENT_COOLDOWN_S = 180, 2, 5
local MANUAL_COOLDOWN_S = 3

-- ------------------------------------------------------------------- cfg --
local cfg = {}
local CFG_KEYS = {
	"gc_mode", "heap_size_mb", "cleaning_permitted",
	"c_pause", "c_stepmul", "c_budget_us", "c_pacer", "c_pacer_headroom_mb", "c_periodic_minutes",
	"c_threshold_percent", "c_adaptive_trigger", "c_ladder", "c_moments", "c_growth_percent", "c_double_collect",
	"smooth_collect", "respect_headroom", "block_cinematics", "clean_on_exit", "hub_clean",
	"sanctuary_clean", "activity_clean",
	"show_overlay", "show_fps", "show_low", "show_frame_ms", "show_heap", "show_mission", "show_hitch",
	"show_gc_mode", "anchor", "pos_x", "pos_y", "overlay_scale", "opacity_text", "opacity_bg", "hitch_ms",
	"auto_reset", "auto_reset_minutes",
	"notifications", "notification_y_axis", "hud_x_axis", "hud_y_axis", "chat_level",
}

local P = {} -- the active parameter set

local function refresh_cfg()
	for i = 1, #CFG_KEYS do
		cfg[CFG_KEYS[i]] = mod:get(CFG_KEYS[i])
	end

	local mode = cfg.gc_mode or "aggressive"
	local preset = MODES[mode]

	for k in pairs(P) do
		P[k] = nil
	end

	if preset then
		for k, v in pairs(preset) do
			P[k] = v
		end
	else -- custom
		P.tune = true
		P.pause = cfg.c_pause or 150
		P.stepmul = cfg.c_stepmul or 300
		P.budget_us = cfg.c_budget_us or 1500
		P.pacer = cfg.c_pacer == true
		P.pacer_headroom_mb = cfg.c_pacer_headroom_mb or 24
		P.periodic_minutes = cfg.c_periodic_minutes or 0
		P.threshold_percent = cfg.c_threshold_percent or 0
		P.adaptive_trigger = cfg.c_adaptive_trigger == true
		P.ladder = cfg.c_ladder == true
		P.moments = cfg.c_moments == true
		P.map_collects = true
		P.growth_percent = cfg.c_growth_percent or 0
		P.double_collect = cfg.c_double_collect == true
	end

	P.mode = mode
	mod._smog_hud_x_axis = tonumber(cfg.hud_x_axis) or 10
	mod._smog_hud_y_axis = tonumber(cfg.hud_y_axis) or 30
	mod._smog_notification_y_axis = tonumber(cfg.notification_y_axis) or 85
end

-- --------------------------------------------------------------- clock --
local _clock = nil

local function resolve_clock()
	if _clock == nil then
		local lua_os = rawget(_G, "Mods") and Mods.lua and Mods.lua.os
		_clock = (lua_os and lua_os.clock) or (rawget(_G, "os") and os.clock) or false
	end

	return _clock
end

local elapsed = 0

-- ------------------------------------------------------------ heap size --
-- SMOG_data.lua detect_heap_size_mb: --lua-heap-mb-size from the launch args.
local function detect_heap_size_mb()
	local size = 1024

	if Application and Application.argv then
		local ok, args = pcall(function()
			return { Application.argv() }
		end)

		if ok and args then
			for i = 1, #args do
				local arg = tostring(args[i])
				local value = tonumber(arg:match("^%-%-lua%-heap%-mb%-size=(%d+)$"))

				if not value and arg == "--lua-heap-mb-size" then
					value = tonumber(args[i + 1])
				end

				if value and value > 0 then
					size = value
				end
			end
		end
	end

	return math_floor(size + 0.5)
end

local detected_heap_mb = detect_heap_size_mb()

-- One line in the console log with the game's real launch arguments (Application.argv, as
-- parameter_resolver.lua reads them), so it can be checked whether --lua-heap-mb-size reached the game:
-- Steam launch options only reach the program Steam starts, not a launcher started on its own.
do
	local ok, args = pcall(function()
		return { Application.argv() }
	end)
	local parts = {}
	if ok and args then
		for i = 1, #args do
			parts[i] = tostring(args[i])
		end
	end
	local line = #parts > 0 and table.concat(parts, " ") or "?"

	mod:info("Launch arguments: %s", line)
	mod:info("Lua heap size from launch arguments: %d MB%s", detected_heap_mb,
		line:find("lua%-heap%-mb%-size") and "" or " (no --lua-heap-mb-size: engine default)")
end

local function heap_size_mb()
	local override = tonumber(cfg.heap_size_mb) or 0

	return override > 0 and override or detected_heap_mb
end

mod.detected_heap_mb = detected_heap_mb

local function live_mb()
	return (collectgarbage("count") or 0) / 1024
end

local function percent_of(mb)
	local size = heap_size_mb()

	return size > 0 and mb / size * 100 or 0
end

-- ------------------------------------------------------------- stats --
local stats = { fps = 0, avg_fps = 0, low_fps = 0, frame_ms = 0, heap_mb = 0, heap_rate = 0 }
local samples, sample_count, sample_idx = {}, 0, 1
local low_scratch, low_scratch_n = {}, 0
local one_sec, win_time, win_frames, last_heap_kb = 0, 0, 0, nil
local peak_heap_mb, floor_heap_mb = 0, 0
local mission_start_heap_mb, mission_baseline_pending = 0, false
local mission_hitches, mission_gc_hitches = 0, 0
local reset_acc = 0
local gc_frame_ms = 0
local smoothed_frame_s = 1 / 60
local frame_spike = false
local in_gameplay = false
local prev_map_floor_mb = 0

local function compute_low_fps()
	local n = sample_count

	if n < 10 then
		return 0
	end

	for i = 1, n do
		low_scratch[i] = samples[i]
	end

	for i = n + 1, low_scratch_n do
		low_scratch[i] = nil
	end

	low_scratch_n = n
	table_sort(low_scratch)

	local idx = math_min(math_max(math_floor(n * 0.99), 1), n)
	local dt99 = low_scratch[idx]

	return dt99 and dt99 > 0 and 1 / dt99 or 0
end

local function reset_diagnostics()
	local heap = live_mb()

	sample_count, sample_idx = 0, 1
	mission_hitches, mission_gc_hitches = 0, 0
	peak_heap_mb, mission_start_heap_mb = heap, heap
	mission_baseline_pending = false
	stats.low_fps, stats.heap_rate = 0, 0
	last_heap_kb = collectgarbage("count")
	win_time, win_frames, one_sec, reset_acc = 0, 0, 0, 0
	mod._md_overlay_dirty = true
end

-- ------------------------------------------------------------- notices --
-- Feeds SMOG's notice renderer (MD_Cont.lua draw_notice via
-- mod._smog_get_notification). Also echoes to chat unless silent.
local notice = { text = nil, tail = nil, good = true, green = false, red = false, expiry = 0 }
local sticky = { text = nil, red = false }
local notice_state = {}

local function update_notification_active()
	mod._smog_notification_active = sticky.text ~= nil or notice.text ~= nil
end

local function notify(text, good, tail, green, force)
	if not force and cfg.notifications == false then
		return
	end

	notice.text, notice.tail = text, tail
	notice.good, notice.green = good ~= false, green == true
	notice.expiry = elapsed + (force and 6 or 5)
	update_notification_active()
end

local function set_sticky(text, red)
	sticky.text, sticky.red = text, red == true
	update_notification_active()
end

local function clear_sticky()
	sticky.text = nil
	update_notification_active()
end

mod._smog_get_notification = function()
	if sticky.text then
		notice_state.text, notice_state.tail = sticky.text, nil
		notice_state.green_text, notice_state.red_text, notice_state.good = false, sticky.red, false
		notice_state.fade_seconds, notice_state.remaining = 1, 3600

		return notice_state
	end

	if not notice.text or notice.expiry <= elapsed then
		notice.text = nil
		update_notification_active()

		return nil
	end

	notice_state.text, notice_state.tail = notice.text, notice.tail
	notice_state.green_text, notice_state.red_text, notice_state.good = notice.green, false, notice.good
	notice_state.fade_seconds, notice_state.remaining = 1, notice.expiry - elapsed

	return notice_state
end

-- Chat output. DMF formats every echo/info text (logging.lua log_message ->
-- safe_format), so finished text is always passed as an argument ("%s") -
-- a literal "%" in it would otherwise make DMF drop the message.
-- Levels: "all" = everything, "important" (default) = results you asked
-- for, warnings and problems, "none" = console log only.
local CHAT_RANK = { none = 0, important = 1, all = 2 }

local function chat_allows(level)
	local wanted = CHAT_RANK[cfg.chat_level or "important"] or 1

	return (CHAT_RANK[level] or 2) <= wanted
end

local function chat(level, text)
	mod:info("%s", text)

	if chat_allows(level) then
		mod:echo("%s", "[MemoryDoctor] " .. text)
	end
end

local function say(level, fmt, ...)
	chat(level, string_format(fmt, ...))
end

-- ------------------------------------------------------------- context --
-- SMOG refresh_context_snapshot: no collections during cinematics,
-- cutscenes, loading, mission intro/outro and the lobby; the HUD is hidden
-- there too. The end-of-mission screens are allowed.
local context = { hud_allowed = false, collection_allowed = true, exit_cinematic_active = false, debrief_active = false }

mod._smog_context_snapshot = context

local function view_active(ui, name)
	return ui and ui.view_active and ui:view_active(name) == true or false
end

local function blocked_text(value)
	if value == nil then
		return false
	end

	local text = tostring(value)

	return text:find("[Ll]oading") ~= nil or text:find("[Cc]inematic") ~= nil or text:find("[Cc]utscene") ~= nil
		or text:find("[Vv]alkyrie") ~= nil or text:find("[Bb]riefing") ~= nil
end

local function read_context()
	local ui = Managers and Managers.ui
	local gmm = Managers and Managers.state and Managers.state.game_mode
	local cinematic = Managers and Managers.state and Managers.state.cinematic
	local cinematic_active = cinematic and cinematic.cinematic_active and cinematic:cinematic_active() == true or false
	local blocked_view = view_active(ui, "cinematic_view") or view_active(ui, "cutscene_view") or view_active(ui, "loading_view")
		or view_active(ui, "mission_intro_view") or view_active(ui, "mission_outro_view") or view_active(ui, "lobby_view")
	local debrief = view_active(ui, "end_view") or view_active(ui, "end_player_view")
	local ui_state = ui and ui.get_current_state_name and ui:get_current_state_name() or nil
	local name, state

	if gmm then
		if gmm.game_mode_name then
			name = gmm:game_mode_name()
		end

		if gmm.game_mode_state then
			state = gmm:game_mode_state()
		end
	end

	local transition = ui_state == "StateLoading" or ui_state == "GameplayStateInit" or ui_state == "StateExitToMainMenu"
		or ui_state == "StateMissionServerExit" or blocked_text(ui_state) or blocked_text(name)
		or state == "leaving_game" or state == "done" or blocked_text(state)

	context.hud_allowed = gmm ~= nil and not cinematic_active and not blocked_view and not transition

	if cinematic_active or blocked_view then
		context.collection_allowed = false
	elseif debrief then
		context.collection_allowed = true
	else
		context.collection_allowed = not transition
	end

	context.exit_cinematic_active = cinematic_active or view_active(ui, "cinematic_view") or view_active(ui, "cutscene_view")
		or view_active(ui, "mission_outro_view")
	context.debrief_active = debrief
	context.game_mode_name = name
end

local context_acc = 0

-- SMOG read_immediate_context_values: the two cheap checks run every frame,
-- so a cinematic or loading screen blocks cleaning on its first frame
-- instead of up to 0.2 s later.
local function immediate_blocked()
	local cinematic = Managers and Managers.state and Managers.state.cinematic
	local ui = Managers and Managers.ui
	local ui_state = ui and ui.get_current_state_name and ui:get_current_state_name() or nil

	return cinematic and cinematic.cinematic_active and cinematic:cinematic_active() == true
		or ui_state == "StateLoading" or ui_state == "GameplayStateInit" or ui_state == "StateExitToMainMenu"
		or ui_state == "StateMissionServerExit" or blocked_text(ui_state)
end

local function refresh_context(force, dt)
	context_acc = context_acc + (dt or 0)

	if not force and context_acc < 0.2 then
		local ok, blocked = pcall(immediate_blocked)

		if not ok or blocked then
			context.hud_allowed, context.collection_allowed = false, false
		end

		return
	end

	context_acc = 0

	local ok = pcall(read_context)

	if not ok then
		context.hud_allowed, context.collection_allowed, context.exit_cinematic_active = false, false, true
	end
end

local function collection_allowed()
	if cfg.cleaning_permitted == false or P.mode == "off" then
		return false
	end

	if cfg.block_cinematics == false then
		return true
	end

	return context.collection_allowed
end

-- --------------------------------------------------------------- tuning --
local tuned, tuned_pause, tuned_stepmul = false, nil, nil
local orig_pause, orig_stepmul = nil, nil

local function apply_tuning(pause, stepmul)
	if tuned and tuned_pause == pause and tuned_stepmul == stepmul then
		return
	end

	-- Lua 5.1 setpause/setstepmul return the previous value; capture the real
	-- defaults on first tune (FpsDoctor apply_tuning).
	local ok_p, prev_p = pcall(collectgarbage, "setpause", pause)
	local ok_s, prev_s = pcall(collectgarbage, "setstepmul", stepmul)

	if orig_pause == nil then
		orig_pause = ok_p and type(prev_p) == "number" and prev_p > 0 and prev_p or 200
		orig_stepmul = ok_s and type(prev_s) == "number" and prev_s > 0 and prev_s or 200
	end

	pcall(collectgarbage, "restart")

	tuned, tuned_pause, tuned_stepmul = true, pause, stepmul
	mod:info("GC tuned: pause=%d stepmul=%d", pause, stepmul)
end

local function restore_tuning()
	if not tuned then
		return
	end

	pcall(collectgarbage, "setpause", orig_pause or 200)
	pcall(collectgarbage, "setstepmul", orig_stepmul or 200)
	pcall(collectgarbage, "restart")

	tuned, tuned_pause, tuned_stepmul = false, nil, nil
	mod:info("GC restored: pause=%d stepmul=%d", orig_pause or 200, orig_stepmul or 200)
end

-- ----------------------------------------------------- ladder (SMOG) --
local ladder_state = "normal" -- normal / gentle / waiting / high / boosted
local ladder_wait_t, ladder_boost_elapsed = nil, 0
local warn_cycle, ninety_done, ninetyfive_done = false, false, false

-- The tuning the collector should have right now: the ladder can only make
-- it MORE aggressive than the mode's own tuning, never less.
local function wanted_tuning()
	local pause = P.tune and P.pause or nil
	local stepmul = P.tune and P.stepmul or nil

	if P.ladder and (ladder_state == "high" or ladder_state == "boosted") then
		local lp = ladder_state == "boosted" and BOOST_PAUSE or HIGH_PAUSE
		local ls = ladder_state == "boosted" and BOOST_STEPMUL or HIGH_STEPMUL

		pause = pause and math_min(pause, lp) or lp
		stepmul = stepmul and math_max(stepmul, ls) or ls
	end

	return pause, stepmul
end

local function sync_tuning()
	if P.mode == "off" or cfg.cleaning_permitted == false or (cfg.block_cinematics ~= false and not context.collection_allowed) then
		-- SMOG restores its tuning while collection is blocked; the mode's
		-- base tuning (MemLeakFix / FpsDoctor behaviour) stays.
		local pause, stepmul = P.tune and P.pause or nil, P.tune and P.stepmul or nil

		if P.mode ~= "off" and cfg.cleaning_permitted ~= false and pause then
			apply_tuning(pause, stepmul)
		else
			restore_tuning()
		end

		return
	end

	local pause, stepmul = wanted_tuning()

	if pause then
		apply_tuning(pause, stepmul)
	else
		restore_tuning()
	end
end

-- -------------------------------------------------------- GC work units --
local drain_active, drain_reason, drain_before_mb, drain_frames = false, nil, 0, 0
local pacer_resume_mb, emergency_floor_mb = 0, 0

local function headroom_scale()
	-- FpsDoctor headroom_scale: 1 when the frame is at/under the expected
	-- time, ramping to 0 at SPIKE_MULT.
	if cfg.respect_headroom == false or not in_gameplay or stats.fps <= 0 then
		return 1
	end

	local expected = 1000 / stats.fps

	if expected <= 0 then
		return 1
	end

	local ratio = stats.frame_ms / expected

	if ratio <= 1 then
		return 1
	end

	local t = math_min(math_max((ratio - 1) / (SPIKE_MULT - 1), 0), 1)

	return 1 - t
end

local function spiking()
	return cfg.respect_headroom ~= false and in_gameplay and frame_spike
end

-- Budgeted incremental steps. Returns finished (a GC cycle completed).
local function budgeted_steps(step_kb, max_steps, budget_s, scale_by_headroom)
	local clock = resolve_clock()

	if scale_by_headroom then
		local scale = headroom_scale()

		max_steps = math_max(1, math_floor(max_steps * scale + 0.5))
		budget_s = budget_s * scale
	end

	if not in_gameplay then
		budget_s = budget_s * IDLE_BUDGET_MULT
	end

	if not clock then
		return collectgarbage("step", FALLBACK_STEP_KB)
	end

	local t0 = clock()
	local steps, finished = 0, false

	repeat
		finished = collectgarbage("step", step_kb)
		steps = steps + 1
	until finished or steps >= max_steps or clock() - t0 >= budget_s

	gc_frame_ms = gc_frame_ms + (clock() - t0) * 1000

	return finished
end

local function set_floor(mb)
	floor_heap_mb = mb
	emergency_floor_mb = mb
	pacer_resume_mb = mb + (P.pacer_headroom_mb or 24)
	stats.heap_mb = mb
	last_heap_kb = mb * 1024
end

-- SMOG low-yield tracking: two collects in a row above 70% that free almost
-- nothing while the post-collect floor keeps rising = memory is really held
-- (not garbage); routine collects are then skipped until it changes.
local last_post_mb, last_low_yield, routine_suppressed = nil, false, false

local function track_yield(before_mb, after_mb)
	local size = heap_size_mb()
	local seventy = size * 0.7

	if before_mb < seventy or after_mb < seventy then
		last_post_mb, last_low_yield, routine_suppressed = nil, false, false

		return
	end

	local low = before_mb - after_mb < math_max(size * 0.01, 8)
	local rising = last_post_mb and after_mb >= last_post_mb + math_max(size * 0.005, 4)

	if not low then
		routine_suppressed = false
	end

	if low and last_low_yield and rising and not routine_suppressed then
		routine_suppressed = true
		notify("Heap stays high after cleaning - memory is held, not garbage", false)
		say("important", "Collects above 70%% free almost nothing and the floor keeps rising: this memory is in use. Routine collects paused until it changes.")
	end

	last_post_mb, last_low_yield = after_mb, low
end

local function full_collect(reason, routine)
	if routine and routine_suppressed then
		return false
	end

	local clock = resolve_clock()
	local t0 = clock and clock()
	local before = live_mb()

	collectgarbage("collect")

	if P.double_collect then
		-- FpsDoctor collects twice at map boundaries: the second pass frees
		-- what the first pass's finalizers released.
		collectgarbage("collect")
	end

	if t0 then
		gc_frame_ms = gc_frame_ms + (clock() - t0) * 1000
	end

	local after = live_mb()

	set_floor(after)
	track_yield(before, after)
	mod:info("GC collect (%s): %.1f -> %.1f MB", reason, before, after)

	if reason == "manual" then
		notify(string_format("Cleaned %.0f%%", math_max(percent_of(before) - percent_of(after), 0)), true,
			string_format(" (%.1f MB -> %.1f MB)", before, after), true, true)
	end

	-- Manual cleans already show an on-screen result; routine ones are "all".
	chat(reason == "manual" and "important" or "all", string_format("GC (%s): %.0f -> %.0f MB", reason, before, after))

	return true
end

local function begin_drain(reason)
	drain_active, drain_reason, drain_before_mb, drain_frames = true, reason, live_mb(), 0
end

local function finish_drain(completed)
	drain_active = false

	local after = live_mb()
	local is_map_start = drain_reason == "map_start"

	if completed or is_map_start then
		set_floor(after)
	end

	if is_map_start and mission_baseline_pending then
		mission_start_heap_mb = after
		mission_baseline_pending = false

		if prev_map_floor_mb > 0 then
			say("all", "Floor drift since last map: %+.0f MB", after - prev_map_floor_mb)
		end

		prev_map_floor_mb = after
	end

	track_yield(drain_before_mb, after)
	mod:info("GC drain (%s): %.1f -> %.1f MB (%s)", tostring(drain_reason), drain_before_mb, after,
		completed and "complete" or "incomplete")

	if completed or is_map_start then
		chat("all", string_format("GC (%s): %.0f -> %.0f MB", tostring(drain_reason), drain_before_mb, after))
	else
		chat("all", string_format("GC (%s): incomplete, ~%.0f MB (will retry)", tostring(drain_reason), after))
	end

	drain_reason = nil
end

local function tick_drain()
	if not drain_active or spiking() then
		return
	end

	drain_frames = drain_frames + 1

	local budget_s = (P.budget_us or 1000) / 1e6
	local finished = budgeted_steps(DRAIN_STEP_KB, DRAIN_MAX_STEPS, budget_s, drain_reason ~= "map_start")

	if finished or drain_frames >= GC_DRAIN_MAX_FRAMES then
		finish_drain(finished)
	end
end

-- A collect request: smooth (spread over frames) in gameplay when enabled,
-- otherwise a full collect this frame (FpsDoctor request_collect).
local function request_collect(reason, routine)
	if not collection_allowed() then
		return false
	end

	if routine and routine_suppressed then
		return false
	end

	if cfg.smooth_collect ~= false and in_gameplay and reason ~= "manual" and reason ~= "ladder_95" then
		if not drain_active then
			begin_drain(reason)
		end

		return true
	end

	return full_collect(reason, routine)
end

local function tick_pacer()
	if not P.pacer or drain_active or spiking() or not collection_allowed() then
		return
	end

	if pacer_resume_mb > 0 and live_mb() < pacer_resume_mb then
		return
	end

	if budgeted_steps(PACER_STEP_KB, PACER_MAX_STEPS, (P.budget_us or 500) / 1e6, true) then
		set_floor(live_mb())
	end
end

-- ------------------------------------------------------- ladder ticks --
local function set_ladder(next_state)
	if ladder_state == next_state then
		return
	end

	local previous = ladder_state

	ladder_state = next_state

	if next_state == "waiting" then
		ladder_wait_t, ladder_boost_elapsed = elapsed, 0
	elseif next_state == "high" then
		ladder_wait_t, ladder_boost_elapsed = nil, 0
		notify("Heap stayed above 80% - cleaning harder", false)
	elseif next_state == "boosted" then
		notify("Heap still rising - maximum incremental cleaning", false)
	else
		ladder_wait_t, ladder_boost_elapsed = nil, 0

		if previous == "high" or previous == "boosted" or previous == "waiting" then
			warn_cycle, ninety_done, ninetyfive_done = false, false, false
			clear_sticky()

			if previous ~= "waiting" then
				notify("Heap back under 80%", true)
			end
		end
	end

	sync_tuning()
end

local function tick_ladder(dt, check_due)
	if not P.ladder then
		if ladder_state ~= "normal" then
			set_ladder("normal")
		end

		return false
	end

	local pct = percent_of(live_mb())

	if pct < LADDER_LEAVE then
		set_ladder("normal")
	elseif (ladder_state == "waiting" or ladder_state == "high" or ladder_state == "boosted") and pct < LADDER_EXIT_HIGH then
		set_ladder("gentle")
	elseif ladder_state == "normal" or ladder_state == "gentle" then
		if check_due and pct >= LADDER_HIGH then
			set_ladder("waiting")
		elseif check_due and pct >= LADDER_GENTLE and ladder_state == "normal" then
			set_ladder("gentle")
		end
	elseif ladder_state == "waiting" then
		if ladder_wait_t and elapsed - ladder_wait_t >= HIGH_DELAY_S then
			set_ladder("high")
		end
	elseif ladder_state == "high" then
		ladder_boost_elapsed = ladder_boost_elapsed + dt

		if ladder_boost_elapsed >= BOOST_DELAY_S then
			set_ladder("boosted")
		end
	end

	if check_due then
		if pct >= LADDER_WARN and not warn_cycle then
			warn_cycle = true
			set_sticky(string_format("Lua heap at %.0f%% - press your clean key or type /memclean", pct), false)
			mod._smog_hud_visible = true
		end

		if not collection_allowed() then
			-- cinematic / loading / cleaning off: warn only, collect later
		elseif pct >= LADDER_NINETYFIVE and not ninetyfive_done then
			ninetyfive_done, ninety_done = true, true
			set_sticky(string_format("Lua heap at %.0f%% - forced clean. Consider leaving to the hub.", pct), true)
			full_collect("ladder_95", false)

			return true
		elseif pct >= LADDER_NINETY and warn_cycle and not ninety_done then
			ninety_done = true
			request_collect("ladder_90", false)

			return true
		end
	end

	if not drain_active and collection_allowed() and not spiking() then
		if ladder_state == "gentle" or ladder_state == "waiting" then
			budgeted_steps(GENTLE_STEP_KB, GENTLE_MAX_STEPS, GENTLE_BUDGET_S, true)
		elseif ladder_state == "high" or ladder_state == "boosted" then
			budgeted_steps(STAGED_STEP_KB, STAGED_MAX_STEPS, STAGED_BUDGET_S, true)
		end
	end

	return false
end

-- ------------------------------------------ periodic / threshold / growth --
local periodic_acc, emergency_cooldown, growth_acc, growth_sample_mb = 0, 0, 0, nil

local function tick_triggers(dt, check_due)
	if drain_active or not collection_allowed() then
		return
	end

	local live = live_mb()

	if emergency_cooldown > 0 then
		emergency_cooldown = emergency_cooldown - dt
	end

	local periodic = tonumber(P.periodic_minutes) or 0

	if periodic > 0 then
		periodic_acc = periodic_acc + dt

		if periodic_acc >= periodic * 60 then
			periodic_acc = 0

			if live >= floor_heap_mb + PERIODIC_MIN_GROWTH_MB then
				emergency_cooldown = EMERGENCY_COOLDOWN_S
				request_collect("periodic", true)

				return
			end
		end
	end

	-- Growth spike (SMOG growth_collect_due): heap grew by growth_percent of
	-- the heap size within 30 s while above 35%.
	local growth = tonumber(P.growth_percent) or 0

	if growth > 0 and check_due then
		growth_acc = growth_acc + 1

		if growth_acc >= GROWTH_WINDOW_S then
			local previous = growth_sample_mb or live
			local delta_pct = (live - previous) / heap_size_mb() * 100

			growth_sample_mb, growth_acc = live, 0

			if percent_of(live) > 35 and delta_pct >= growth then
				notify("Heap growth spike - cleaning", false)
				request_collect("growth", false)

				return
			end
		end
	end

	if emergency_cooldown > 0 or live < emergency_floor_mb + EMERGENCY_REARM_MB then
		return
	end

	local threshold_pct = tonumber(P.threshold_percent) or 0

	if threshold_pct > 0 then
		local threshold_mb = heap_size_mb() * threshold_pct / 100

		if live >= threshold_mb then
			emergency_cooldown = EMERGENCY_COOLDOWN_S
			request_collect("threshold", true)
		elseif P.adaptive_trigger and live >= threshold_mb * SOFT_THRESHOLD_FRAC and stats.heap_rate >= ADAPTIVE_RATE_MB_MIN then
			-- FpsDoctor adaptive: 75% of the threshold while growing >= 8 MB/min.
			emergency_cooldown = EMERGENCY_COOLDOWN_S
			request_collect("adaptive", true)
		end
	end
end

-- ------------------------------------------------- convenient moments --
-- SMOG schedule_convenient_clean / gameplay-exit clean.
local scheduled = {} -- reason -> seconds left
local exit_pending, exit_wait_debrief, exit_debrief_seen, exit_delay = false, false, false, nil
local last_convenient_t = -math.huge
local previous_mode_name, previous_safe_zone = nil, nil
local hub_visit = "unseen"

local function is_hub(name)
	return name == "hub" or name == "prologue_hub" or name == "hub_singleplay"
end

local function is_activity(name)
	return name == "training_grounds" or name == "shooting_range" or name == "survival" or name == "expedition"
end

local function schedule(reason, delay)
	if P.moments or reason == "map_start" then
		scheduled[reason] = delay
	end
end

local function convenient_collect(reason)
	if elapsed - last_convenient_t < CONVENIENT_COOLDOWN_S then
		return false
	end

	if request_collect(reason, true) then
		last_convenient_t = elapsed

		return true
	end

	return false
end

local function in_safe_zone()
	local gmm = Managers and Managers.state and Managers.state.game_mode
	local ok, game_mode = pcall(function()
		return gmm and gmm:game_mode()
	end)

	if ok and game_mode and game_mode.in_safe_zone then
		local ok2, result = pcall(game_mode.in_safe_zone, game_mode)

		if ok2 then
			return result == true
		end
	end

	return nil
end

local function check_transitions()
	local name = context.game_mode_name

	if name ~= previous_mode_name then
		if P.moments and cfg.activity_clean ~= false and previous_mode_name and is_activity(previous_mode_name) then
			exit_pending, exit_wait_debrief, exit_delay = true, false, nil
		end

		if is_hub(name) then
			if hub_visit == "unseen" and cfg.hub_clean ~= false then
				hub_visit = "waiting"
				schedule("hub", HUB_CLEAN_DELAY_S)
			end
		else
			if hub_visit == "waiting" then
				hub_visit = "expired"
			end

			scheduled.hub = nil

			if cfg.activity_clean ~= false and is_activity(name) then
				schedule("activity_start", 1)
			end
		end

		previous_mode_name = name
	end

	local safe = in_safe_zone()

	if safe ~= nil and previous_safe_zone ~= nil and safe and not previous_safe_zone and cfg.sanctuary_clean ~= false then
		schedule("sanctuary", 1)
	end

	if safe ~= nil then
		previous_safe_zone = safe
	end
end

local function tick_moments(dt)
	local did = false

	for reason, left in pairs(scheduled) do
		left = left - dt

		if left <= 0 then
			scheduled[reason] = nil

			if not did then
				if reason == "hub" then
					if hub_visit == "waiting" and is_hub(context.game_mode_name) and convenient_collect("hub") then
						hub_visit = "completed"
						did = true
					end
				elseif reason == "map_start" then
					if not drain_active and collection_allowed() then
						mission_baseline_pending = true
						mission_start_heap_mb = live_mb()

						if cfg.smooth_collect ~= false then
							begin_drain("map_start")
						else
							full_collect("map_start", false)
							mission_start_heap_mb = live_mb()
							mission_baseline_pending = false
						end

						did = true
					else
						scheduled.map_start = 1 -- blocked (cinematic/loading): retry
					end
				else
					did = convenient_collect(reason)
				end
			end
		else
			scheduled[reason] = left
		end
	end

	-- Gameplay exit: wait for the end-of-mission screens to close, then clean.
	if exit_pending and not did then
		if exit_wait_debrief and not exit_debrief_seen then
			if context.debrief_active then
				exit_debrief_seen = true
			end
		elseif exit_wait_debrief and context.debrief_active then
			-- still on the debrief
		elseif context.exit_cinematic_active then
			exit_delay = nil
		elseif exit_delay == nil then
			exit_delay = EXIT_CLEAN_DELAY_S
		else
			exit_delay = exit_delay - dt

			if exit_delay <= 0 then
				exit_pending = false

				did = convenient_collect("map_exit")
			end
		end
	end

	return did
end

-- ------------------------------------------------------------ overlay --
-- FpsDoctor overlay (draw_overlay_inner / rebuild_lines), drawn into a
-- screen gui of the live level world, revalidated every frame.
local Overlay = {}

do
	local Gui, World, Vector2, Vector3, Color = Gui, World, Vector2, Vector3, Color
	local _gui, _gui_world, _font_path = nil, nil, nil
	local lines, lr, lg, lb, line_count = {}, {}, {}, {}, 0
	local panel_text_w, rebuild_acc, built_font_px = 0, 0, 0
	local fail_cooldown = 0
	local cache = {}

	local function level_world()
		local wm = Managers.world

		if wm and wm:has_world("level_world") then
			return wm:world("level_world")
		end

		return nil
	end

	local function ensure_gui()
		local world = level_world()

		if not world then
			_gui, _gui_world, _font_path = nil, nil, nil

			return nil
		end

		if _gui and _gui_world == world then
			return _gui
		end

		_gui = World.create_screen_gui(world, "immediate")
		_gui_world = world
		_font_path = nil

		return _gui
	end

	local function ensure_font()
		if _font_path then
			return _font_path
		end

		local data = Managers.font and Managers.font:data_by_type("arial")

		_font_path = data and data.path

		return _font_path
	end

	function Overlay.release()
		_gui, _gui_world, _font_path = nil, nil, nil
	end

	local function push(s, r, g, b)
		line_count = line_count + 1
		lines[line_count], lr[line_count], lg[line_count], lb[line_count] = s, r, g, b
	end

	local function text_w(gui, text, font, size)
		local ok, mn, mx = pcall(Gui.slug_text_extents, gui, text, font, size)

		if ok and mn and mx then
			return mx[1] - mn[1]
		end

		return #text * size * 0.55
	end

	local function rebuild(gui, font, px)
		line_count = 0

		if cfg.show_fps ~= false then
			push(string_format("FPS %d  (avg %d)", math_floor(stats.fps + 0.5), math_floor(stats.avg_fps + 0.5)), 235, 235, 235)
		end

		if cfg.show_low ~= false then
			local warn = stats.low_fps > 0 and stats.avg_fps > 0 and stats.low_fps < stats.avg_fps * 0.7

			push(string_format("1%% low  %d fps", math_floor(stats.low_fps + 0.5)), warn and 255 or 175, warn and 215 or 175, warn and 90 or 175)
		end

		if cfg.show_frame_ms ~= false then
			push(string_format("frame  %.1f ms", stats.frame_ms), 175, 175, 175)
		end

		if cfg.show_heap ~= false then
			local rate = stats.heap_rate
			local r, g, b = 150, 230, 150

			if rate >= 5 then
				r, g, b = 255, 90, 90
			elseif rate >= 1.5 then
				r, g, b = 255, 215, 90
			end

			push(string_format("Lua heap %.0f / %d MB (%.0f%%)  %s%.1f MB/min", stats.heap_mb, heap_size_mb(),
				percent_of(stats.heap_mb), rate >= 0 and "+" or "", rate), r, g, b)
		end

		if cfg.show_mission ~= false then
			local delta = mission_start_heap_mb > 0 and stats.heap_mb - mission_start_heap_mb or 0
			local r, g, b = 150, 230, 150

			if delta >= LEAK_LIKELY_MB then
				r, g, b = 255, 90, 90
			elseif delta >= LEAK_WATCH_MB then
				r, g, b = 255, 215, 90
			end

			push(string_format("peak %.0f  floor %.0f  d-mission %s%.0f MB", peak_heap_mb, floor_heap_mb, delta >= 0 and "+" or "", delta), r, g, b)
		end

		if cfg.show_hitch ~= false then
			local s = mission_gc_hitches > 0 and string_format("hitch %d (%d gc)  (>%d ms)", mission_hitches, mission_gc_hitches, cfg.hitch_ms or 50)
				or string_format("hitch %d  (>%d ms)", mission_hitches, cfg.hitch_ms or 50)

			push(s, mission_hitches > 0 and 255 or 175, mission_hitches > 0 and 215 or 175, mission_hitches > 0 and 90 or 175)
		end

		if cfg.show_gc_mode ~= false then
			local extra = P.ladder and ladder_state ~= "normal" and ("  ladder: " .. ladder_state) or ""

			push("GC mode: " .. tostring(P.mode) .. extra .. (drain_active and "  (cleaning)" or ""), 175, 175, 175)
		end

		local maxw = 0

		for i = 1, line_count do
			maxw = math_max(maxw, text_w(gui, lines[i], font, px))
		end

		panel_text_w = maxw
	end

	local function draw_inner(dt)
		local gui = ensure_gui()
		local font = gui and ensure_font()

		if not gui or not font then
			return
		end

		local r = RESOLUTION_LOOKUP
		local scale = r and r.scale or 1
		local sw, sh = r and r.width or 1920, r and r.height or 1080
		local s = scale * (cfg.overlay_scale or 100) / 100
		local px = math_max(8, math_floor(9 * s + 0.5))

		rebuild_acc = rebuild_acc + dt

		if mod._md_overlay_dirty or rebuild_acc >= 0.25 or px ~= built_font_px then
			rebuild(gui, font, px)
			built_font_px, rebuild_acc, mod._md_overlay_dirty = px, 0, false

			local line_h, pad = math_floor(13 * s + 0.5), math_floor(4 * s + 0.5)
			local anchor = cfg.anchor or "top_left"
			local right = anchor == "top_right" or anchor == "bottom_right"
			local bottom = anchor == "bottom_left" or anchor == "bottom_right"
			local mx = math_floor((cfg.pos_x or 24) * scale + 0.5)
			local my = math_floor((cfg.pos_y or 24) * scale + 0.5)

			cache.line_h, cache.pad = line_h, pad
			cache.panel_w, cache.panel_h = panel_text_w + pad * 2, line_count * line_h + pad * 2
			cache.x = right and sw - cache.panel_w - mx or mx
			cache.y = bottom and sh - my - line_count * line_h or my
			cache.a_text = math_floor(255 * (cfg.opacity_text or 100) / 100 + 0.5)
			cache.a_bg = math_floor(255 * (cfg.opacity_bg or 60) / 100 + 0.5)
		end

		if line_count == 0 then
			return
		end

		Gui.rect(gui, Vector3(cache.x - cache.pad, cache.y - cache.pad, 899), Vector2(cache.panel_w, cache.panel_h), Color(cache.a_bg, 12, 12, 12))

		for i = 1, line_count do
			Gui.slug_text(gui, lines[i], font, px, Vector3(cache.x, cache.y + cache.line_h * (i - 1), 900), nil, Color(cache.a_text, lr[i], lg[i], lb[i]))
		end
	end

	function Overlay.draw(dt)
		if fail_cooldown > 0 then
			fail_cooldown = fail_cooldown - 1

			return
		end

		local ok, err = pcall(draw_inner, dt)

		if not ok then
			Overlay.release()
			fail_cooldown = 120
			mod:error("overlay draw failed, backing off 120 frames: %s", tostring(err))
		end
	end
end

-- -------------------------------------------------------- SMOG HUD data --
mod._smog_hud_visible = mod._smog_hud_visible == true
mod._smog_hud_format = mod:get("_md_hud_format") or "analogue"

if mod._smog_hud_format ~= "analogue" and mod._smog_hud_format ~= "digital" and mod._smog_hud_format ~= "advanced_digital" then
	mod._smog_hud_format = "analogue"
end

mod._smog_heap_size_mb = detected_heap_mb

local hud_rev = 1
local advanced = {
	revision = 1, process_mb = 0, process_peak_mb = 0, process_growth_mb_per_min = 0,
	lua_growth_mb_per_min = 0, lua_peak_mb = 0, lua_share_percent = 0, pressure = "NORMAL",
}

mod._smog_advanced_hud_state = advanced

local adv_acc, adv_growth_acc, adv_growth_elapsed, adv_growth_lua, adv_growth_proc = 2, 0, 0, nil, nil

local function read_process_mb()
	if not Memory or not Memory.usage then
		return nil
	end

	local ok, usage = pcall(Memory.usage, "B")
	local used = ok and type(usage) == "table" and tonumber(usage.used_memory)

	return used and used >= 0 and used / 1048576 or nil
end

local function update_hud_sample(dt)
	local mb = live_mb()

	mod._smog_heap_size_mb = heap_size_mb()
	mod._smog_hud_sample_mb = mb
	mod._smog_hud_sample_percent = percent_of(mb)
	hud_rev = hud_rev + 1
	mod._smog_hud_sample_revision = hud_rev

	if mb > advanced.lua_peak_mb then
		advanced.lua_peak_mb = mb
	end

	if mod._smog_hud_format ~= "advanced_digital" then
		return
	end

	-- SMOG advanced.update: process memory every 2 s, growth every 30 s.
	adv_acc = adv_acc + dt
	adv_growth_acc = adv_growth_acc + dt
	adv_growth_elapsed = adv_growth_elapsed + dt

	if adv_acc >= 2 then
		adv_acc = 0

		local proc = read_process_mb()

		if proc then
			advanced.process_mb = proc
			advanced.process_peak_mb = math_max(advanced.process_peak_mb, proc)
			advanced.lua_share_percent = proc > 0 and mb / proc * 100 or 0

			if adv_growth_proc == nil then
				adv_growth_proc, adv_growth_lua, adv_growth_elapsed = proc, mb, 0
			end
		end
	end

	if adv_growth_acc >= 30 and adv_growth_proc and adv_growth_elapsed > 0 then
		adv_growth_acc = 0
		advanced.lua_growth_mb_per_min = (mb - adv_growth_lua) * 60 / adv_growth_elapsed
		advanced.process_growth_mb_per_min = (advanced.process_mb - adv_growth_proc) * 60 / adv_growth_elapsed
		adv_growth_lua, adv_growth_proc, adv_growth_elapsed = mb, advanced.process_mb, 0
	end

	local lua_pressure = ladder_state ~= "normal" or percent_of(mb) >= 70
	local game_pressure = advanced.process_growth_mb_per_min - math_max(advanced.lua_growth_mb_per_min, 0) >= 256
	local pressure = lua_pressure and game_pressure and "MIXED" or lua_pressure and "LUA" or game_pressure and "GAME" or "NORMAL"

	advanced.pressure = pressure
	advanced.revision = advanced.revision + 1
end

-- ----------------------------------------------- unclean shutdown note --
-- SMOG mark_unclean_start: if the last session did not shut down cleanly
-- while the heap was high, say so once.
local function save_settings()
	if dmf and dmf.save_unsaved_settings_to_file then
		pcall(dmf.save_unsaved_settings_to_file)
	end
end

do
	local previous_clean = mod:get("_md_clean_shutdown")
	local previous_percent = tonumber(mod:get("_md_last_heap_percent")) or 0

	if previous_clean == false then
		if previous_percent >= 80 then
			mod:echo("%s", string_format("[MemoryDoctor] The last session ended unexpectedly with the Lua heap at %d%% or more - it may have run out of Lua memory.", previous_percent))
		else
			mod:echo("%s", "[MemoryDoctor] The last session ended unexpectedly while the Lua heap was below 80% - probably not a Lua memory crash.")
		end
	end

	mod:set("_md_clean_shutdown", false)
	save_settings()
end

local persisted_state = nil

local function persist_heap_state()
	local state = percent_of(live_mb()) >= 80 and 80 or 0

	if persisted_state ~= state then
		persisted_state = state
		mod:set("_md_last_heap_percent", state)
		save_settings()
	end
end

-- -------------------------------------------------------------- HUD reg --
local hud_ok = mod:register_hud_element({
	class_name = "HudElementMemDoctorController",
	filename = "QIangIQsMemoryDoctor/scripts/mods/QIangIQsMemoryDoctor/MD_Cont",
	use_hud_scale = true,
	visibility_groups = {
		"dead", "alive", "communication_wheel", "tactical_overlay", "player_in_danger_zone",
		"emote_wheel", "in_hub_view", "in_view", "popup",
	},
})

if hud_ok ~= true then
	mod:error("HUD element registration failed")
end

-- --------------------------------------------------------------- update --
local check_acc, hud_acc = 0, 0

function mod.update(dt)
	if not mod:is_enabled() or type(dt) ~= "number" or dt <= 0 then
		return
	end

	elapsed = elapsed + dt

	if dt > PAUSE_FRAME_S then
		gc_frame_ms = 0

		return
	end

	local gc_prev_ms = gc_frame_ms

	gc_frame_ms = 0

	-- frame stats (FpsDoctor)
	stats.fps = stats.fps <= 0 and 1 / dt or stats.fps * 0.9 + (1 / dt) * 0.1
	stats.frame_ms = dt * 1000

	local frame_dt = math_min(dt, 0.1)

	frame_spike = frame_dt > math_max(smoothed_frame_s, 0.001) * SPIKE_MULT
	smoothed_frame_s = smoothed_frame_s * 0.9 + frame_dt * 0.1

	if stats.frame_ms > (cfg.hitch_ms or 50) then
		mission_hitches = mission_hitches + 1

		if gc_prev_ms >= GC_HITCH_ATTRIB_MS then
			mission_gc_hitches = mission_gc_hitches + 1
		end
	end

	samples[sample_idx] = dt
	sample_idx = sample_idx % SAMPLE_MAX + 1
	sample_count = math_min(sample_count + 1, SAMPLE_MAX)

	one_sec, win_time, win_frames = one_sec + dt, win_time + dt, win_frames + 1

	local check_due = false

	if one_sec >= 1 then
		stats.avg_fps = win_time > 0 and win_frames / win_time or 0
		win_time, win_frames = 0, 0
		stats.low_fps = compute_low_fps()

		local heap_kb = collectgarbage("count")

		stats.heap_mb = heap_kb / 1024
		peak_heap_mb = math_max(peak_heap_mb, stats.heap_mb)

		if last_heap_kb then
			stats.heap_rate = stats.heap_rate * 0.7 + ((heap_kb - last_heap_kb) / 1024) / one_sec * 60 * 0.3
		end

		last_heap_kb = heap_kb
		one_sec = 0
		check_due = true
		persist_heap_state()
	end

	if cfg.auto_reset then
		reset_acc = reset_acc + dt

		if reset_acc >= (cfg.auto_reset_minutes or 10) * 60 then
			reset_diagnostics()
		end
	else
		reset_acc = 0
	end

	refresh_context(false, dt)

	if check_due then
		check_transitions()
	end

	sync_tuning()

	local acted = tick_moments(dt)

	if not acted then
		acted = tick_ladder(dt, check_due)
	end

	if not acted then
		tick_triggers(dt, check_due)
	end

	tick_drain()
	tick_pacer()

	hud_acc = hud_acc + dt

	if hud_acc >= ((mod._smog_hud_visible or ladder_state ~= "normal") and 0.5 or 1) then
		update_hud_sample(hud_acc)
		hud_acc = 0
	end

	if cfg.show_overlay and in_gameplay then
		Overlay.draw(dt)
	end
end

function mod.on_game_state_changed(status, state_name)
	if not mod:is_enabled() or state_name ~= "StateGameplay" then
		return
	end

	refresh_context(true)

	if status == "enter" then
		in_gameplay = true
		mission_hitches, mission_gc_hitches = 0, 0
		sample_count, sample_idx, win_time, win_frames, one_sec = 0, 1, 0, 0, 0
		periodic_acc, emergency_floor_mb, growth_acc, growth_sample_mb = 0, 0, 0, nil
		stats.heap_rate = 0
		last_heap_kb = collectgarbage("count")
		mission_start_heap_mb = live_mb()
		mission_baseline_pending = false
		mod._md_overlay_dirty = true

		if P.map_collects and P.mode ~= "off" then
			scheduled.map_start = 1
		end

		if exit_pending then
			exit_debrief_seen = true -- a new map started: the debrief is over
		end
	elseif status == "exit" then
		in_gameplay = false

		if mission_start_heap_mb > 0 and not mission_baseline_pending then
			local cur = live_mb()
			local net = cur - mission_start_heap_mb
			local verdict = net >= LEAK_LIKELY_MB and "likely leak" or net >= LEAK_WATCH_MB and "watch (growing)" or "stable"

			-- A stable mission is routine; a growing one is worth a chat line.
			say(verdict == "stable" and "all" or "important", "Mission heap: %.0f -> %.0f MB (%+.0f) -- %s", mission_start_heap_mb, cur, net, verdict)
		end

		if P.map_collects and cfg.clean_on_exit ~= false and P.mode ~= "off" then
			exit_pending, exit_wait_debrief, exit_debrief_seen, exit_delay = true, true, false, nil
		end

		Overlay.release()
	end
end

-- ------------------------------------------------------------ settings --
local function reset_runtime()
	drain_active, drain_reason = false, nil
	periodic_acc, emergency_cooldown, emergency_floor_mb = 0, 0, 0
	routine_suppressed, last_post_mb, last_low_yield = false, nil, false

	for k in pairs(scheduled) do
		scheduled[k] = nil
	end

	exit_pending = false
	pacer_resume_mb = floor_heap_mb + (P.pacer_headroom_mb or 24)
	ladder_state = "normal"
	warn_cycle, ninety_done, ninetyfive_done = false, false, false
	clear_sticky()
end

function mod.on_setting_changed(setting_id)
	refresh_cfg()
	mod._md_overlay_dirty = true

	if setting_id == "gc_mode" or setting_id == "cleaning_permitted" then
		reset_runtime()
		sync_tuning()

		if setting_id == "gc_mode" then
			say("important", "GC mode: %s", tostring(P.mode))
		end
	end
end

function mod.on_all_mods_loaded()
	local others = {}

	for _, name in ipairs({ "FpsDoctor", "SMOG", "MemLeakFix" }) do
		local other = get_mod(name)

		if other and other.is_enabled and other:is_enabled() then
			others[#others + 1] = name
		end
	end

	if #others > 0 then
		mod:echo("%s", "[MemoryDoctor] Also enabled: " .. table.concat(others, ", ") .. ". They tune the same Lua collector - disable them or remove them from mod_load_order.txt.")
	end
end

local function shutdown()
	restore_tuning()
	Overlay.release()
	reset_runtime()
	mod._smog_hud_visible = false
	mod:set("_md_clean_shutdown", true)
	mod:set("_md_last_heap_percent", percent_of(live_mb()) >= 80 and 80 or 0)
	save_settings()
end

function mod.on_disabled()
	shutdown()
end

function mod.on_unload()
	shutdown()
end

function mod.on_enabled()
	refresh_cfg()
	mod:set("_md_clean_shutdown", false)
	save_settings()
end

-- ------------------------------------------------------ keys & commands --
local next_manual_t = 0

function mod.manual_clear()
	refresh_context(true)

	if cfg.cleaning_permitted == false then
		notify("Cleaning is turned off in the settings", false, nil, false, true)

		return
	end

	if not context.collection_allowed and cfg.block_cinematics ~= false then
		return
	end

	if elapsed < next_manual_t then
		return
	end

	next_manual_t = elapsed + MANUAL_COOLDOWN_S

	if warn_cycle then
		ninety_done = true
		clear_sticky()
	end

	drain_active = false
	full_collect("manual", false)
end

function mod.toggle_overlay()
	mod:set("show_overlay", not cfg.show_overlay, true)
end

function mod.reset_stats()
	reset_diagnostics()
	say("important", "Diagnostics reset (peak, hitches, lows).")
end

-- SMOG toggle_hud: press = show/hide; press again within 3 s = next format
-- (analogue -> digital -> advanced digital -> hidden).
local last_hud_key_t = nil

function mod.toggle_hud()
	local rapid = last_hud_key_t ~= nil and elapsed - last_hud_key_t <= 3

	last_hud_key_t = elapsed

	local function set_format(format)
		mod._smog_hud_format = format
		mod:set("_md_hud_format", format)
		save_settings()
	end

	if rapid then
		if mod._smog_hud_visible then
			if mod._smog_hud_format == "analogue" then
				set_format("digital")
			elseif mod._smog_hud_format == "digital" then
				set_format("advanced_digital")
			else
				mod._smog_hud_visible = false

				return
			end
		else
			set_format("analogue")
		end

		mod._smog_hud_visible = true
	else
		mod._smog_hud_visible = not mod._smog_hud_visible
	end

	refresh_context(true)
	update_hud_sample(0)
end

mod:command("memclean", "Memory Doctor: clean the Lua heap now", function()
	mod.manual_clear()
end)

mod:command("memstats", "Memory Doctor: print Lua heap and GC state", function()
	local mb = live_mb()

	mod:echo("%s", string_format("[MemoryDoctor] mode %s | heap %.0f / %d MB (%.0f%%) | floor %.0f | peak %.0f | %+.1f MB/min | ladder %s | pause %s stepmul %s",
		tostring(P.mode), mb, heap_size_mb(), percent_of(mb), floor_heap_mb, peak_heap_mb, stats.heap_rate, ladder_state,
		tostring(tuned_pause or orig_pause or "default"), tostring(tuned_stepmul or orig_stepmul or "default")))
end)

mod:command("memmode", "Memory Doctor: set GC mode (" .. table.concat(MODE_ORDER, ", ") .. ")", function(mode)
	for i = 1, #MODE_ORDER do
		if MODE_ORDER[i] == mode then
			mod:set("gc_mode", mode, true)

			return
		end
	end

	mod:echo("%s", "[MemoryDoctor] modes: " .. table.concat(MODE_ORDER, ", "))
end)

refresh_cfg()
refresh_context(true)
update_hud_sample(0)
set_floor(live_mb())
reset_diagnostics()

-- test hooks
mod._md_test = {
	P = P, cfg = cfg, context = context, stats = stats, refresh_cfg = refresh_cfg,
	state = function()
		return { ladder = ladder_state, drain = drain_active, drain_reason = drain_reason, tuned_pause = tuned_pause,
			tuned_stepmul = tuned_stepmul, orig_pause = orig_pause, floor = floor_heap_mb, scheduled = scheduled,
			exit_pending = exit_pending, suppressed = routine_suppressed }
	end,
	set_in_gameplay = function(v) in_gameplay = v end,
}
