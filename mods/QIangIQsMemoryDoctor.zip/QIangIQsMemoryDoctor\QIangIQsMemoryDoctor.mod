return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsMemoryDoctor` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsMemoryDoctor", {
			mod_script       = "QIangIQsMemoryDoctor/scripts/mods/QIangIQsMemoryDoctor/QIangIQsMemoryDoctor",
			mod_data         = "QIangIQsMemoryDoctor/scripts/mods/QIangIQsMemoryDoctor/QIangIQsMemoryDoctor_data",
			mod_localization = "QIangIQsMemoryDoctor/scripts/mods/QIangIQsMemoryDoctor/QIangIQsMemoryDoctor_localization",
		})
	end,
	packages = {},
	version = "1.0.0",
}
