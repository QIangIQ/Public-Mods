local mod = get_mod("QIangIQsMemoryDoctor")

local function checkbox(id, default)
	return { setting_id = id, type = "checkbox", default_value = default, title = id, tooltip = id .. "_desc" }
end

local function numeric(id, default, low, high)
	return { setting_id = id, type = "numeric", default_value = default, range = { low, high }, decimals_number = 0, title = id, tooltip = id .. "_desc" }
end

local function keybind(id, default, fn, global)
	return {
		setting_id = id, type = "keybind", default_value = default, title = id, tooltip = id .. "_desc",
		keybind_trigger = "pressed", keybind_type = "function_call", function_name = fn, keybind_global = global,
	}
end

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			{
				setting_id = "gc_mode",
				type = "dropdown",
				default_value = "aggressive",
				title = "gc_mode",
				tooltip = "gc_mode_desc",
				options = {
					{ text = "gc_mode_off", value = "off" },
					{ text = "gc_mode_map_only", value = "map_only" },
					{ text = "gc_mode_balanced", value = "balanced" },
					{ text = "gc_mode_pacer", value = "pacer" },
					{ text = "gc_mode_adaptive", value = "adaptive" },
					{ text = "gc_mode_aggressive", value = "aggressive" },
					{ text = "gc_mode_memleakfix", value = "memleakfix" },
					{ text = "gc_mode_extreme", value = "extreme" },
					{ text = "gc_mode_custom", value = "custom" },
				},
			},
			checkbox("cleaning_permitted", true),
			keybind("manual_clear_key", { "f5" }, "manual_clear", true),
			numeric("heap_size_mb", 0, 0, 8192),
			{
				setting_id = "group_custom",
				type = "group",
				title = "group_custom",
				sub_widgets = {
					numeric("c_pause", 100, 10, 400),
					numeric("c_stepmul", 400, 100, 2000),
					numeric("c_budget_us", 2000, 100, 8000),
					checkbox("c_pacer", true),
					numeric("c_pacer_headroom_mb", 0, 0, 256),
					numeric("c_periodic_minutes", 5, 0, 60),
					numeric("c_threshold_percent", 70, 0, 99),
					checkbox("c_adaptive_trigger", true),
					checkbox("c_ladder", true),
					checkbox("c_moments", true),
					numeric("c_growth_percent", 10, 0, 50),
					checkbox("c_double_collect", true),
				},
			},
			{
				setting_id = "group_behaviour",
				type = "group",
				title = "group_behaviour",
				sub_widgets = {
					checkbox("smooth_collect", true),
					checkbox("respect_headroom", true),
					checkbox("block_cinematics", true),
					checkbox("clean_on_exit", true),
					checkbox("hub_clean", true),
					checkbox("sanctuary_clean", true),
					checkbox("activity_clean", true),
					{
						setting_id = "chat_level",
						type = "dropdown",
						default_value = "important",
						title = "chat_level",
						tooltip = "chat_level_desc",
						options = {
							{ text = "chat_level_all", value = "all" },
							{ text = "chat_level_important", value = "important" },
							{ text = "chat_level_none", value = "none" },
						},
					},
				},
			},
			{
				setting_id = "group_overlay",
				type = "group",
				title = "group_overlay",
				sub_widgets = {
					checkbox("show_overlay", false),
					keybind("toggle_overlay_key", { "f6" }, "toggle_overlay"),
					{
						setting_id = "anchor",
						type = "dropdown",
						default_value = "top_left",
						title = "anchor",
						tooltip = "anchor_desc",
						options = {
							{ text = "anchor_top_left", value = "top_left" },
							{ text = "anchor_top_right", value = "top_right" },
							{ text = "anchor_bottom_left", value = "bottom_left" },
							{ text = "anchor_bottom_right", value = "bottom_right" },
						},
					},
					numeric("pos_x", 24, 0, 600),
					numeric("pos_y", 24, 0, 600),
					numeric("overlay_scale", 100, 50, 300),
					numeric("opacity_text", 100, 10, 100),
					numeric("opacity_bg", 60, 0, 100),
					checkbox("show_fps", true),
					checkbox("show_low", true),
					checkbox("show_frame_ms", true),
					checkbox("show_heap", true),
					checkbox("show_mission", true),
					checkbox("show_hitch", true),
					numeric("hitch_ms", 50, 20, 200),
					checkbox("show_gc_mode", true),
					keybind("reset_stats_key", {}, "reset_stats"),
					checkbox("auto_reset", false),
					numeric("auto_reset_minutes", 10, 1, 60),
				},
			},
			{
				setting_id = "group_hud",
				type = "group",
				title = "group_hud",
				sub_widgets = {
					keybind("show_hud_key", { "f8" }, "toggle_hud", true),
					numeric("hud_x_axis", 10, 0, 100),
					numeric("hud_y_axis", 30, 0, 100),
					checkbox("notifications", true),
					numeric("notification_y_axis", 85, 0, 100),
				},
			},
		},
	},
}
