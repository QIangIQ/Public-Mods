return {
	mod_name = {
		en = "QIangIQ's Memory Doctor",
	},
	mod_description = {
		en = "One Lua garbage-collector manager combining FpsDoctor (budgeted GC, smooth cleaning, FPS/heap overlay, leak verdict), SMOG Cleaner (heap-%% pressure ladder, convenient-moment cleaning, cinematic/loading safety, 3 HUDs) and MemLeakFix (fixed GC tuning), plus an Extreme mode. /memclean cleans now, /memstats prints the state, /memmode <mode> switches mode. Disable FpsDoctor, SMOG and MemLeakFix while using this.",
	},
	gc_mode = {
		en = "GC mode",
	},
	gc_mode_desc = {
		en = "Off: never cleans, game defaults.\nMap only: cleans at map start/exit only.\nBalanced (FpsDoctor): light tuning + map cleans.\nPacer (FpsDoctor): lazy collector + small budgeted steps each frame once the heap grows 24 MB past its floor.\nAdaptive (SMOG): heap-%% ladder - 70%% gentle steps, 80%% harder tuning, 85%% warning, 90/95%% forced cleans - plus convenient-moment cleans.\nAggressive: FpsDoctor aggressive + SMOG ladder and moments, cleans every 10 min, at 85%% heap and on growth spikes.\nMemLeakFix: pause 10 / stepmul 500, nothing else.\nExtreme: collector never rests (pause 100, stepmul 400), budgeted cleaning every frame, full clean every 3 min, at 60%% heap and on 8%% growth spikes, ladder, moments, double collects. Most memory freed, most CPU used.\nCustom: uses the Custom sliders.",
	},
	gc_mode_off = {
		en = "Off",
	},
	gc_mode_map_only = {
		en = "Map only",
	},
	gc_mode_balanced = {
		en = "Balanced (FpsDoctor)",
	},
	gc_mode_pacer = {
		en = "Pacer (FpsDoctor)",
	},
	gc_mode_adaptive = {
		en = "Adaptive (SMOG)",
	},
	gc_mode_aggressive = {
		en = "Aggressive",
	},
	gc_mode_memleakfix = {
		en = "MemLeakFix (fixed tuning)",
	},
	gc_mode_extreme = {
		en = "Extreme (most aggressive)",
	},
	gc_mode_custom = {
		en = "Custom",
	},
	cleaning_permitted = {
		en = "Cleaning permitted",
	},
	cleaning_permitted_desc = {
		en = "Off: no cleaning or GC tuning at all; the overlay and HUD keep working.",
	},
	manual_clear_key = {
		en = "Clean now key",
	},
	manual_clear_key_desc = {
		en = "Full collect right now (3 s cooldown). Same as /memclean. Blocked during cinematics and loading.",
	},
	heap_size_mb = {
		en = "Lua heap size (MB, 0 = auto)",
	},
	heap_size_mb_desc = {
		en = "Used for every %% threshold. 0 reads --lua-heap-mb-size from the game's launch options (1024 if not set).",
	},
	group_custom = {
		en = "Custom mode sliders",
	},
	c_pause = {
		en = "GC pause",
	},
	c_pause_desc = {
		en = "How long the collector waits before a new cycle, in %% of the heap left after the last one. 100 = starts again at once (never rests); below 100 = even more eager (MemLeakFix used 10); 200 = game default.",
	},
	c_stepmul = {
		en = "GC step multiplier",
	},
	c_stepmul_desc = {
		en = "How much work each automatic collector step does. Higher = cycles finish faster but each step costs more. 200 = game default.",
	},
	c_budget_us = {
		en = "Per-frame GC budget (microseconds)",
	},
	c_budget_us_desc = {
		en = "Time the mod's own incremental cleaning may use per frame. 1000 = 1 ms. Scaled down automatically on heavy frames.",
	},
	c_pacer = {
		en = "Clean a little every frame",
	},
	c_pacer_desc = {
		en = "Budgeted incremental steps every frame once the heap is above its floor plus the headroom below.",
	},
	c_pacer_headroom_mb = {
		en = "Per-frame cleaning headroom (MB)",
	},
	c_pacer_headroom_mb_desc = {
		en = "Heap growth past the last clean floor before per-frame cleaning starts. 0 = always.",
	},
	c_periodic_minutes = {
		en = "Full clean every (minutes, 0 = off)",
	},
	c_periodic_minutes_desc = {
		en = "Periodic full clean, skipped if the heap grew less than 32 MB since the last one.",
	},
	c_threshold_percent = {
		en = "Clean at heap %% (0 = off)",
	},
	c_threshold_percent_desc = {
		en = "Full clean when the heap reaches this %% of the Lua heap size (60 s cooldown).",
	},
	c_adaptive_trigger = {
		en = "Early clean when heap grows fast",
	},
	c_adaptive_trigger_desc = {
		en = "Clean at 75%% of the threshold above when the heap is growing 8 MB/min or more (FpsDoctor adaptive).",
	},
	c_ladder = {
		en = "SMOG pressure ladder",
	},
	c_ladder_desc = {
		en = "70%% gentle steps, 80%% for 5 s harder tuning (pause 80 / stepmul 500), 25 s later boosted (65 / 700), 85%% warning, 90%% and 95%% forced cleans.",
	},
	c_moments = {
		en = "Clean at convenient moments",
	},
	c_moments_desc = {
		en = "Hub (3 min after arriving), entering a sanctuary, Psykanium/Mortis/Expedition start and exit, and after the end-of-mission screens.",
	},
	c_growth_percent = {
		en = "Growth spike clean (%% of heap per 30 s, 0 = off)",
	},
	c_growth_percent_desc = {
		en = "Clean when the heap grew by this %% of the heap size within 30 s while above 35%% (SMOG used 15).",
	},
	c_double_collect = {
		en = "Double collect",
	},
	c_double_collect_desc = {
		en = "Run every full clean twice: the second pass frees what the first pass released (FpsDoctor does this at map exit).",
	},
	group_behaviour = {
		en = "Behaviour",
	},
	smooth_collect = {
		en = "Smooth cleaning in missions",
	},
	smooth_collect_desc = {
		en = "Spread automatic full cleans over several frames with a time budget instead of one hitch (FpsDoctor drain). The 95%% emergency and manual cleans are always instant.",
	},
	respect_headroom = {
		en = "Back off on heavy frames",
	},
	respect_headroom_desc = {
		en = "Scale the mod's own GC work down as a frame gets heavier and skip it on frame spikes (FpsDoctor + SMOG).",
	},
	block_cinematics = {
		en = "Never clean during cinematics/loading",
	},
	block_cinematics_desc = {
		en = "No cleaning or ladder tuning during cinematics, cutscenes, loading, mission intro/outro or the lobby (SMOG).",
	},
	clean_on_exit = {
		en = "Clean after leaving a mission",
	},
	clean_on_exit_desc = {
		en = "Full clean 2 s after the end-of-mission screens close.",
	},
	hub_clean = {
		en = "Clean in the Mourningstar",
	},
	hub_clean_desc = {
		en = "One clean 3 minutes after arriving in the hub (needs 'convenient moments').",
	},
	sanctuary_clean = {
		en = "Clean when entering a sanctuary",
	},
	sanctuary_clean_desc = {
		en = "Clean when the team enters a safe zone (needs 'convenient moments').",
	},
	activity_clean = {
		en = "Clean at activity start/exit",
	},
	activity_clean_desc = {
		en = "Psykanium, Mortis Trials and Expeditions (needs 'convenient moments').",
	},
	group_overlay = {
		en = "FPS / heap overlay (FpsDoctor)",
	},
	show_overlay = {
		en = "Show overlay",
	},
	show_overlay_desc = {
		en = "FPS, 1%% low, frame time, Lua heap and growth, per-mission change, hitches and GC state.",
	},
	toggle_overlay_key = {
		en = "Toggle overlay key",
	},
	toggle_overlay_key_desc = {
		en = "Show/hide the overlay.",
	},
	anchor = {
		en = "Anchor",
	},
	anchor_desc = {
		en = "Screen corner the overlay is placed in.",
	},
	anchor_top_left = {
		en = "Top left",
	},
	anchor_top_right = {
		en = "Top right",
	},
	anchor_bottom_left = {
		en = "Bottom left",
	},
	anchor_bottom_right = {
		en = "Bottom right",
	},
	pos_x = {
		en = "Offset X",
	},
	pos_x_desc = {
		en = "Distance from the corner.",
	},
	pos_y = {
		en = "Offset Y",
	},
	pos_y_desc = {
		en = "Distance from the corner.",
	},
	overlay_scale = {
		en = "Overlay scale %%",
	},
	overlay_scale_desc = {
		en = "Text size.",
	},
	opacity_text = {
		en = "Text opacity %%",
	},
	opacity_text_desc = {
		en = "Text opacity.",
	},
	opacity_bg = {
		en = "Background opacity %%",
	},
	opacity_bg_desc = {
		en = "Panel opacity.",
	},
	show_fps = {
		en = "Show FPS",
	},
	show_fps_desc = {
		en = "Current and 1-second average FPS.",
	},
	show_low = {
		en = "Show 1%% low",
	},
	show_low_desc = {
		en = "1%% low FPS over the last 1000 frames (yellow when under 70%% of the average).",
	},
	show_frame_ms = {
		en = "Show frame time",
	},
	show_frame_ms_desc = {
		en = "Last frame in ms.",
	},
	show_heap = {
		en = "Show Lua heap",
	},
	show_heap_desc = {
		en = "Heap MB, %% of the heap size and growth in MB/min.",
	},
	show_mission = {
		en = "Show mission memory",
	},
	show_mission_desc = {
		en = "Peak, floor after the last clean, and change since the mission started (yellow +120 MB, red +300 MB).",
	},
	show_hitch = {
		en = "Show hitches",
	},
	show_hitch_desc = {
		en = "Frames over the hitch threshold this mission, and how many followed GC work.",
	},
	hitch_ms = {
		en = "Hitch threshold (ms)",
	},
	hitch_ms_desc = {
		en = "Frames longer than this count as a hitch.",
	},
	show_gc_mode = {
		en = "Show GC mode",
	},
	show_gc_mode_desc = {
		en = "Mode, ladder state and whether a clean is running.",
	},
	reset_stats_key = {
		en = "Reset stats key",
	},
	reset_stats_key_desc = {
		en = "Reset peak, hitches and lows.",
	},
	auto_reset = {
		en = "Auto reset stats",
	},
	auto_reset_desc = {
		en = "Reset the overlay stats every N minutes.",
	},
	auto_reset_minutes = {
		en = "Auto reset every (minutes)",
	},
	auto_reset_minutes_desc = {
		en = "Interval for the automatic reset.",
	},
	group_hud = {
		en = "Heap HUD & notices (SMOG)",
	},
	show_hud_key = {
		en = "Show HUD key",
	},
	show_hud_key_desc = {
		en = "Press to show/hide. Press again within 3 s to cycle: gauge -> digital -> advanced (process memory, GC vs game pressure) -> hidden.",
	},
	hud_x_axis = {
		en = "HUD X %%",
	},
	hud_x_axis_desc = {
		en = "Horizontal position.",
	},
	hud_y_axis = {
		en = "HUD Y %%",
	},
	hud_y_axis_desc = {
		en = "Vertical position.",
	},
	notifications = {
		en = "Automatic notices",
	},
	notifications_desc = {
		en = "On-screen notices for ladder changes and automatic cleans. Warnings at 85%% and above always show.",
	},
	notification_y_axis = {
		en = "Notice Y %%",
	},
	notification_y_axis_desc = {
		en = "Vertical position of notices.",
	},
	chat_level = {
		en = "Chat messages",
	},
	chat_level_desc = {
		en = "All: every clean, map drift and mission summary.\nImportant: only what you asked for (manual clean, stats, mode change) and problems (heap not freeing, growing missions).\nNone: nothing in chat - everything still goes to the console log.",
	},
	chat_level_all = {
		en = "All",
	},
	chat_level_important = {
		en = "Important only",
	},
	chat_level_none = {
		en = "None",
	},
}
