return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsOctaviaPrime` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsOctaviaPrime", {
            mod_script = "QIangIQsOctaviaPrime/scripts/mods/QIangIQsOctaviaPrime/QIangIQsOctaviaPrime",
            mod_data = "QIangIQsOctaviaPrime/scripts/mods/QIangIQsOctaviaPrime/QIangIQsOctaviaPrime_data",
            mod_localization = "QIangIQsOctaviaPrime/scripts/mods/QIangIQsOctaviaPrime/QIangIQsOctaviaPrime_localization",
        })
    end,
    version = "1.0.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
