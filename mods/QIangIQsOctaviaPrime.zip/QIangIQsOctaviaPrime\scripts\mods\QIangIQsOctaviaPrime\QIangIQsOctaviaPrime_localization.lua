return {
    mod_name = {
        en = "QIangIQ's Octavia Prime",
    },
    mod_description = {
        en = "Replaces your own human character with Octavia Prime (Warframe, taken from your own game install) as a Custom Assets model: third person, first-person arms and menu previews, with physics on her skirts, hair, plume and earrings. Only one QIangIQ human character model is shown at a time. Personal use only. By QIangIQ.",
    },
    model_enabled = {
        en = "Show the Octavia Prime model",
    },
    model_enabled_description = {
        en = "Turning this on switches the other QIangIQ human character models off. Chat command: /octaviaprime",
    },
    hide_body = {
        en = "Hide original body and cosmetics",
    },
    hide_body_description = {
        en = "Hides your character's body, face, hair and gear slots while the model is shown. Weapons stay visible.",
    },
    first_person_arms = {
        en = "Model arms in first person",
    },
    first_person_arms_description = {
        en = "Replaces the first-person arms and gloves with the model's arms.",
    },
    menu_previews = {
        en = "Show in menus (operative select, inventory)",
    },
    menu_previews_description = {
        en = "Shows the model on your own operatives in menu previews. Other players' characters are left alone. Ogryns are never replaced.",
    },
    physics_group = {
        en = "Physics",
    },
    jiggle = {
        en = "Physics on",
    },
    jiggle_description = {
        en = "Physics on the model's her skirts, hair, plume and earrings.",
    },
    jiggle_hair = {
        en = "Amount: hair",
    },
    jiggle_hair_description = {
        en = "1 = as built. Higher = looser and wider swings, lower = tighter. 0 = this area does not move.",
    },
    jiggle_hair_gravity = {
        en = "Hair gravity",
    },
    jiggle_hair_gravity_description = {
        en = "How strongly the hair is drawn straight down instead of keeping its modelled direction. 0 = keep the modelled shape, 0.4 = as built. Replaces \"Hang\" for the hair.",
    },
    jiggle_cloth = {
        en = "Amount: clothing and chains",
    },
    jiggle_cloth_description = {
        en = "1 = as built. Higher = looser and wider swings, lower = tighter. 0 = this area does not move.",
    },
    jiggle_stiffness = {
        en = "Stiffness (all areas except the tail)",
    },
    jiggle_stiffness_description = {
        en = "How hard everything is pulled back to its rest pose. 1 = as built. Higher = snaps back faster, lower = softer and slower.",
    },
    jiggle_damping = {
        en = "Damping (all areas except the tail)",
    },
    jiggle_damping_description = {
        en = "How quickly the wobble dies out. 1 = as built. Higher = settles at once, lower = keeps bouncing longer.",
    },
    jiggle_limit = {
        en = "Swing limit (all areas except the tail)",
    },
    jiggle_limit_description = {
        en = "Scales the largest angle a bone may swing away from its rest pose. 1 = as built.",
    },
    jiggle_hang = {
        en = "Hang (clothing)",
    },
    jiggle_hang_description = {
        en = "How strongly loose clothing is drawn straight down instead of keeping its modelled direction when you lean or look up and down. 0 = keep the modelled shape. Hair and tail have their own gravity settings.",
    },
    toggle_keybind = {
        en = "Toggle Octavia Prime model",
    },
}
