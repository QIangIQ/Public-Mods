return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsVorunaPrime` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsVorunaPrime", {
            mod_script = "QIangIQsVorunaPrime/scripts/mods/QIangIQsVorunaPrime/QIangIQsVorunaPrime",
            mod_data = "QIangIQsVorunaPrime/scripts/mods/QIangIQsVorunaPrime/QIangIQsVorunaPrime_data",
            mod_localization = "QIangIQsVorunaPrime/scripts/mods/QIangIQsVorunaPrime/QIangIQsVorunaPrime_localization",
        })
    end,
    version = "1.0.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
