return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsWarframeArsenal` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsWarframeArsenal", {
            mod_script = "QIangIQsWarframeArsenal/scripts/mods/QIangIQsWarframeArsenal/QIangIQsWarframeArsenal",
            mod_data = "QIangIQsWarframeArsenal/scripts/mods/QIangIQsWarframeArsenal/QIangIQsWarframeArsenal_data",
            mod_localization = "QIangIQsWarframeArsenal/scripts/mods/QIangIQsWarframeArsenal/QIangIQsWarframeArsenal_localization",
        })
    end,
    version = "1.0.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
