return {
    mod_name = {
        en = "QIangIQ's Warframe Arsenal",
    },
    mod_description = {
        en = "Shows Warframe weapons (from your own Warframe install, personal use; Custom Assets) in place of Darktide weapons: Masseter, Fragor and Volnus Prime on the Bully Club, Corufell and Guandao Prime on the force staffs, Viktor's Rapier on the Duelling Sword, Argo & Vel on the Arbitrator shield and maul, Okina, Nami Skyla and Ninkondi Prime on the shivs and transonic blades, Dual Furis Incarnon on the autopistols, and more. Each weapon has its own profile: on/off, model, length, grip, spin, tilt and flip. /wfarsenal which lists them. By QIangIQ.",
    },
    staff_selection = {
        en = "Weapon",
    },
    staff_selection_description = {
        en = "The weapon (by weapon template) whose profile the settings below show and change.",
    },
    ogryn_club_p2_m1 = {
        en = "ogryn_club_p2_m1",
    },
    ogryn_club_p2_m2 = {
        en = "ogryn_club_p2_m2",
    },
    ogryn_club_p2_m3 = {
        en = "ogryn_club_p2_m3",
    },
    ogryn_pickaxe_2h_p1_m1 = {
        en = "ogryn_pickaxe_2h_p1_m1",
    },
    ogryn_pickaxe_2h_p1_m2 = {
        en = "ogryn_pickaxe_2h_p1_m2",
    },
    ogryn_pickaxe_2h_p1_m3 = {
        en = "ogryn_pickaxe_2h_p1_m3",
    },
    thunderhammer_2h_p1_m1 = {
        en = "thunderhammer_2h_p1_m1",
    },
    thunderhammer_2h_p1_m2 = {
        en = "thunderhammer_2h_p1_m2",
    },
    combatsword_p3_m1 = {
        en = "combatsword_p3_m1",
    },
    combatsword_p3_m2 = {
        en = "combatsword_p3_m2",
    },
    combatsword_p3_m3 = {
        en = "combatsword_p3_m3",
    },
    powermaul_shield_p1_m1 = {
        en = "powermaul_shield_p1_m1",
    },
    powermaul_shield_p1_m2 = {
        en = "powermaul_shield_p1_m2",
    },
    dual_shivs_p1_m1 = {
        en = "dual_shivs_p1_m1",
    },
    dual_shivs_p1_m2 = {
        en = "dual_shivs_p1_m2",
    },
    transonic_sword_transonic_knife_p1_m1 = {
        en = "transonic_sword_transonic_knife_p1_m1",
    },
    forcestaff_p1_m1 = {
        en = "Voidblast Force Staff",
    },
    forcestaff_p2_m1 = {
        en = "Inferno Force Staff",
    },
    forcestaff_p3_m1 = {
        en = "Electrokinetic Force Staff",
    },
    forcestaff_p4_m1 = {
        en = "Voidstrike Force Staff",
    },
    dual_autopistols_p1_m1 = {
        en = "dual_autopistols_p1_m1",
    },
    autopistol_p1_m1 = {
        en = "autopistol_p1_m1",
    },
    current_weapon = {
        en = "Select equipped weapon",
    },
    current_weapon_description = {
        en = "Tick to pick the weapon you are holding (melee or force staff) in the list.",
    },
    profile_enabled = {
        en = "Replace this weapon",
    },
    profile_enabled_description = {
        en = "Show a Warframe weapon in place of the selected weapon.",
    },
    profile_spear = {
        en = "Model",
    },
    profile_spear_description = {
        en = "Random = a new random model each game session (the reroll keybind or /wfarsenal reroll picks another). Or pick one model for this weapon. Argo & Vel and Nami Skyla Prime put their second piece in the left hand on two-handed weapons.",
    },
    spear_random = {
        en = "Random each session",
    },
    spear_wf_masseter_prime = {
        en = "Masseter Prime",
    },
    spear_wf_fragor_prime = {
        en = "Fragor Prime",
    },
    spear_wf_volnus_prime = {
        en = "Volnus Prime",
    },
    spear_wf_corufell_prime = {
        en = "Corufell Prime",
    },
    spear_wf_guandao_prime = {
        en = "Guandao Prime",
    },
    spear_wf_viktor_rapier = {
        en = "Viktor's Rapier",
    },
    spear_wf_argo_mace = {
        en = "Argo & Vel",
    },
    spear_wf_okina_prime = {
        en = "Okina Prime",
    },
    spear_wf_nami_skyla_sword = {
        en = "Nami Skyla Prime",
    },
    spear_wf_ninkondi_prime = {
        en = "Ninkondi Prime",
    },
    spear_wf_furis_incarnon = {
        en = "Dual Furis Incarnon",
    },
    profile_scale = {
        en = "Length (x original weapon)",
    },
    profile_scale_description = {
        en = "1 = same length as the weapon it replaces (pommel to tip). The hand stays on the same point.",
    },
    profile_grip = {
        en = "Grip location",
    },
    profile_grip_description = {
        en = "Where the hand holds it, in model lengths. 0 = the same point as on the original weapon. Positive = nearer the tip, negative = nearer the pommel.",
    },
    profile_roll = {
        en = "Spin around the length (degrees)",
    },
    profile_roll_description = {
        en = "Turns the model around its own length, e.g. to turn the cutting edge or the flat of the blade.",
    },
    profile_tilt = {
        en = "Tilt (degrees)",
    },
    profile_tilt_description = {
        en = "Leans the model about the hand, in the plane of the blade's flat side.",
    },
    profile_flip = {
        en = "Flip end to end",
    },
    profile_flip_description = {
        en = "Use this if the tip points the wrong way (towards the pommel of the original weapon).",
    },
    reset_weapon = {
        en = "Reset selected weapon",
    },
    reset_weapon_description = {
        en = "Tick to put the selected weapon's profile back to the defaults (not replaced).",
    },
    reset_all = {
        en = "Reset all weapons",
    },
    reset_all_description = {
        en = "Tick to put every weapon's profile back to the defaults (none replaced).",
    },
    glow_brightness = {
        en = "Glow brightness",
    },
    glow_brightness_description = {
        en = "Not used by the Warframe models yet (no glow layers).",
    },
    menu_previews = {
        en = "Show in menus (inventory, operative previews)",
    },
    menu_previews_description = {
        en = "Also swaps the weapons in menu previews of your own operatives and in the weapon inspect view (one model over the whole weapon there).",
    },
    toggle_staff_keybind = {
        en = "Toggle Warframe Arsenal replacement",
    },
    reroll_spear_keybind = {
        en = "Reroll model",
    },
    reroll_spear_keybind_description = {
        en = "A new random model for the weapon you are holding, for the rest of the session. A weapon set to a fixed model goes back to random.",
    },
}
