return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsAutoplay` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsAutoplay", {
			mod_script       = "QIangIQsAutoplay/scripts/mods/QIangIQsAutoplay/QIangIQsAutoplay",
			mod_data         = "QIangIQsAutoplay/scripts/mods/QIangIQsAutoplay/QIangIQsAutoplay_data",
			mod_localization = "QIangIQsAutoplay/scripts/mods/QIangIQsAutoplay/QIangIQsAutoplay_localization",
		})
	end,
	packages = {},
}
