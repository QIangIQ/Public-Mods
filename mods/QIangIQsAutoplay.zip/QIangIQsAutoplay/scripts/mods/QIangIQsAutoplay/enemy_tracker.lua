--[[
    enemy_tracker.lua  (shared service, always on while in a mission)

    Vendored and adapted from two of QIangIQ's mods; credit to both:
      * QIangIQsGeneralEnemyTracker: event-based tracking. Spawn from
        UnitSpawnerManager._add_network_unit, death from
        MinionDeathManager.set_dead, plus a per-frame purge of dead units,
        per-breed unit lists.
      * QIangIQsSpecialTracer: KIND_BY_BREED classification, the boss/elite
        fallback, the "hazard" filter, the centre-of-mass lookup order
        (HitZone.hit_zone_center_of_mass -> Unit.box centre -> POSITION_LOOKUP)
        and the get_entities("MinionHuskLocomotionExtension") scan, used here
        once to seed units that spawned before the mod loaded.

    Game source (Darktide 1.13.4, Aussiemon/Darktide-Source-Code):
      UnitSpawnerManager._add_network_unit   scripts/foundation/managers/unit_spawner/unit_spawner_manager.lua:697
        (called by spawn_husk_unit at :836 on clients BEFORE the unit's
         extensions exist at :837, so breeds are read one frame later from
         a pending queue)
      MinionDeathManager.set_dead            scripts/managers/minion/minion_death_manager.lua:160
        (clients reach it through rpc_minion_set_dead, :257-263)
      Breed.unit_breed_or_nil / is_minion    scripts/utilities/breed.lua:109 / :46
      HitZone.hit_zone_center_of_mass        scripts/utilities/attack/hit_zone.lua:96
]]

local mod = get_mod("QIangIQsAutoplay")

local Breed   = require("scripts/utilities/breed")
local HitZone = require("scripts/utilities/attack/hit_zone")

local tracker = {
	units   = {},   -- unit -> { breed_name, kind, display_name }
	by_breed = {},  -- breed_name -> { [unit] = true }
	count   = 0,
	pending = {},   -- unit -> tries left (spawned, extensions not ready yet)
	seeded  = false,
}

-- From QIangIQsSpecialTracer.lua (KIND_BY_BREED).
local KIND_BY_BREED = {
	renegade_netgunner = "trapper",
	chaos_hound = "hound",
	chaos_armored_hound = "hound",
	chaos_hound_mutator = "hound",
	chaos_poxwalker_bomber = "bomber",
	cultist_flamer = "flamer",
	renegade_flamer = "flamer",
	renegade_flamer_mutator = "flamer",
	cultist_grenadier = "grenadier",
	renegade_grenadier = "grenadier",
	cultist_mutant = "mutant",
	cultist_mutant_mutator = "mutant",
	renegade_sniper = "sniper",
}
tracker.KIND_BY_BREED = KIND_BY_BREED

-- QIangIQsSpecialTracer kind_of(), extended with "other" so every minion is
-- tracked (the tracer only kept specials, elites and bosses).
local function kind_of(breed)
	local name = breed.name
	local kind = name and KIND_BY_BREED[name]
	if kind then return kind end
	if name and name:find("hazard") then return nil end
	if breed.is_boss then return "boss" end
	local tags = breed.tags
	if tags and tags.elite then return "elite" end
	if tags and tags.special then return "special" end
	return "other"
end
tracker.kind_of = kind_of

local function add_unit(unit, breed)
	if tracker.units[unit] then return end
	local kind = kind_of(breed)
	if not kind then return end
	local name = breed.name or "unknown"
	tracker.units[unit] = { breed_name = name, kind = kind, display_name = breed.display_name }
	local set = tracker.by_breed[name]
	if not set then
		set = {}
		tracker.by_breed[name] = set
	end
	set[unit] = true
	tracker.count = tracker.count + 1
end

local function remove_unit(unit)
	tracker.pending[unit] = nil
	local entry = tracker.units[unit]
	if not entry then return end
	tracker.units[unit] = nil
	local set = tracker.by_breed[entry.breed_name]
	if set then set[unit] = nil end
	tracker.count = tracker.count - 1
end

-- Returns the breed when the unit is a minion, false when it is something
-- else, nil when its unit_data_system extension is not there yet.
local function minion_breed(unit)
	local ok, breed = pcall(Breed.unit_breed_or_nil, unit)
	if not ok then return false end
	if breed == nil then return nil end
	if Breed.is_minion(breed) then return breed end
	return false
end

local function is_alive(unit)
	if not Unit.alive(unit) then return false end
	local health_alive = rawget(_G, "HEALTH_ALIVE")
	if health_alive and not health_alive[unit] then return false end
	return true
end

function tracker.init(tuning)
	tracker.T = tuning
end

function tracker.reset()
	tracker.units = {}
	tracker.by_breed = {}
	tracker.count = 0
	tracker.pending = {}
	tracker.seeded = false
end

-- One-off scan for units that already existed (mod reload mid-mission).
-- Pattern from QIangIQsSpecialTracer scan_entities().
local function seed()
	local ext = Managers.state and Managers.state.extension
	if not ext or not ext.get_entities then return false end
	local any = false
	for _, name in ipairs({ "MinionHuskLocomotionExtension", "MinionLocomotionExtension" }) do
		local ok, entities = pcall(ext.get_entities, ext, name)
		if ok and type(entities) == "table" then
			for unit in pairs(entities) do
				any = true
				if is_alive(unit) then
					local breed = minion_breed(unit)
					if breed then add_unit(unit, breed) end
				end
			end
		end
	end
	return any
end

function tracker.update(dt, t)
	if not tracker.seeded then
		tracker.seeded = seed()
	end

	for unit, tries in pairs(tracker.pending) do
		if not Unit.alive(unit) then
			tracker.pending[unit] = nil
		else
			local breed = minion_breed(unit)
			if breed then
				tracker.pending[unit] = nil
				if is_alive(unit) then add_unit(unit, breed) end
			elseif breed == false or tries <= 1 then
				tracker.pending[unit] = nil
			else
				tracker.pending[unit] = tries - 1
			end
		end
	end

	-- Purge (QIangIQsGeneralEnemyTracker clean_dead_units, method [2]).
	for unit in pairs(tracker.units) do
		if not is_alive(unit) then remove_unit(unit) end
	end
end

-- Centre of mass, lookup order from QIangIQsSpecialTracer read_com().
-- Returns an engine Vector3 (valid this frame only) or nil.
function tracker.center_of_mass(unit)
	local ok, p = pcall(HitZone.hit_zone_center_of_mass, unit, "center_mass", true)
	if ok and p then return p end
	local okb, pose = pcall(Unit.box, unit, true)
	if okb and pose then
		local okt, c = pcall(Matrix4x4.translation, pose)
		if okt and c then return c end
	end
	local lookup = rawget(_G, "POSITION_LOOKUP")
	return lookup and lookup[unit] or nil
end

-- Hooks ---------------------------------------------------------------

mod:hook_safe(CLASS.UnitSpawnerManager, "_add_network_unit", function(self, unit, game_object_id, is_husk)
	if unit then tracker.pending[unit] = tracker.T and tracker.T("tracker_pending_frames") or 1 end
end)

mod:hook_safe(CLASS.MinionDeathManager, "set_dead", function(self, unit)
	if unit then remove_unit(unit) end
end)

return tracker
