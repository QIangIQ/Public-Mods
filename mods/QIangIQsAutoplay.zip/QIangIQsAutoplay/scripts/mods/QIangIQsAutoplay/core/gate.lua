--[[
    gate.lua: hard gate. Gameplay modules run only when Gate.mission() is ok:
      psykhanium     game mode "shooting_range" or "training_grounds"
                     (GAME onboarding_mission_templates.lua:60-61, 90-91)
      solo-local     host type singleplay (MODS SoloPlay.lua:31-44, HOST_TYPES from
                     GAME scripts/settings/network/matchmaking_constants.lua:5)
      solo-private   private session (GAME party_immaterium_manager.lua:1057) with one human
                     (GAME player_manager.lua:427 human_players)
      private-all    private session and every other human is a party member whose
                     presence carries a fresh AP1 value (sync.lua)
    A public matchmade mission never passes, even with one human: strangers can hot-join.
    The "psykhanium" mission (game mode "survival", GAME horde_mission_templates.lua:4-6)
    can matchmake, so it falls under the solo/private rules, not the exemption.

    Hub-side modules (ready, vote, start, end screen) use Gate.party(): every
    party member advertises AP1 (or the party is just me).
]]

local Gate = { last = { ok = false, kind = "none", reason = "not evaluated" }, last_party = { ok = false, reason = "" } }

local Sync
local HOST_TYPES

function Gate.init(sync)
	Sync = sync
end

-- Looked up when first needed, from files the game already loaded (never require():
-- see Api.loaded in core/api.lua).
local function host_types()
	if HOST_TYPES then return HOST_TYPES end
	local path = "scripts/settings/network/matchmaking_constants"
	local MC = package.loaded[path]
	if type(MC) ~= "table" then
		local store = rawget(_G, "Mods") and Mods.require_store and Mods.require_store[path]
		MC = store and store[#store]
	end
	HOST_TYPES = type(MC) == "table" and MC.HOST_TYPES or nil
	return HOST_TYPES
end

local PSYKHANIUM_MODES = { shooting_range = true, training_grounds = true }

function Gate.game_mode_name()
	local gm = Managers.state and Managers.state.game_mode
	if gm and gm.game_mode_name then
		local ok, name = pcall(gm.game_mode_name, gm)
		if ok then return name end
	end
	return nil
end

function Gate.mission_name()
	local mm = Managers.state and Managers.state.mission
	if mm and mm.mission_name then
		local ok, name = pcall(mm.mission_name, mm)
		if ok then return name end
	end
	return nil
end

local function host_type()
	local ms = Managers.multiplayer_session
	if ms and ms.host_type then
		local ok, ht = pcall(ms.host_type, ms)
		if ok then return ht end
	end
	return nil
end

local function is_private()
	local pim = Managers.party_immaterium
	if pim and pim.is_in_private_session then
		local ok, v = pcall(pim.is_in_private_session, pim)
		return ok and v or false
	end
	return false
end

local function humans()
	local pm = Managers.player
	if not pm or not pm.human_players then return {} end
	local ok, list = pcall(pm.human_players, pm)
	if not ok or type(list) ~= "table" then return {} end
	local out = {}
	for _, p in pairs(list) do out[#out + 1] = p end
	return out
end
Gate.humans = humans

local function set(ok, kind, reason)
	local l = Gate.last
	l.ok, l.kind, l.reason = ok, kind, reason
	return ok, kind, reason
end

function Gate.mission()
	local mode = Gate.game_mode_name()
	if mode and PSYKHANIUM_MODES[mode] then
		return set(true, "psykhanium", "game mode " .. mode)
	end
	local ht = host_type()
	local HT = host_types()
	if HT and ht ~= nil and ht == HT.singleplay then
		return set(true, "solo-local", "singleplay host")
	end
	if not is_private() then
		return set(false, "blocked", "not a private session (public matches never pass)")
	end
	local list = humans()
	if #list <= 1 then
		return set(true, "solo-private", "private session, one human")
	end
	local me = Managers.player:local_player_safe(1)
	for i = 1, #list do
		local p = list[i]
		if p ~= me then
			local okid, id = pcall(p.account_id, p)
			if not okid or not id then
				return set(false, "blocked", "a human has no account id")
			end
			if not Sync.peer_ok(id) then
				local okn, name = pcall(p.name, p)
				return set(false, "blocked", ("human %s has no Autoplay handshake"):format(okn and tostring(name) or tostring(id)))
			end
		end
	end
	return set(true, "private-all", ("private, %d humans all run Autoplay"):format(#list))
end

function Gate.party()
	local members = Sync.members()
	local me = Sync.my_account_id()
	local others = 0
	for i = 1, #members do
		local m = members[i]
		local okid, id = pcall(m.account_id, m)
		if okid and id and id ~= me then
			others = others + 1
			if not Sync.peer_ok(id) then
				Gate.last_party.ok, Gate.last_party.reason = false, "party member " .. tostring(id) .. " has no Autoplay handshake"
				return false, Gate.last_party.reason
			end
		end
	end
	Gate.last_party.ok, Gate.last_party.reason = true, ("party ok (%d others)"):format(others)
	return true, Gate.last_party.reason, others
end

return Gate
