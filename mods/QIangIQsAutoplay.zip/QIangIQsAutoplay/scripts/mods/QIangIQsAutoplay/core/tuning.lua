--[[
    tuning.lua: the ONLY place numbers live (no-invent rule).

    Every entry is either
      { id = "x", value = <number or {x,y,z}>, src = "file:line or mod" }
    or
      { id = "x", untuned = true, default = n, min = a, max = b, decimals = d, desc = "..." }

    Untuned entries become DMF numeric settings titled "UNTUNED: no source - <id>".
    Their min/max are only UI slider bounds, not tuning.
    Structural constants (0, 1, -1, array indices, math.pi) are not tuning
    and are allowed in code; tools/lint_numbers.py enforces that.

    Groups live in tuning/<group>.lua so each module family owns its file.
]]

local mod = get_mod("QIangIQsAutoplay")
local BASE = "QIangIQsAutoplay/scripts/mods/QIangIQsAutoplay/tuning/"

local GROUPS = { "core", "hub", "ortus", "movement", "combat", "support" }

local Tuning = { entries = {}, by_id = {}, groups = GROUPS, errors = {} }

local function bad(msg)
	Tuning.errors[#Tuning.errors + 1] = msg
end

for gi = 1, #GROUPS do
	local group = GROUPS[gi]
	local ok, list = pcall(mod.io_dofile, mod, BASE .. group)
	if not ok or type(list) ~= "table" then
		bad(("group %s failed to load: %s"):format(group, tostring(list)))
	else
		for i = 1, #list do
			local e = list[i]
			e.group = group
			if type(e.id) ~= "string" then
				bad(("group %s entry %d has no id"):format(group, i))
			elseif Tuning.by_id[e.id] then
				bad(("duplicate tuning id %s"):format(e.id))
			elseif e.untuned then
				if type(e.default) ~= "number" or type(e.min) ~= "number" or type(e.max) ~= "number" then
					bad(("untuned %s needs default/min/max"):format(e.id))
				else
					Tuning.by_id[e.id] = e
					Tuning.entries[#Tuning.entries + 1] = e
				end
			else
				if e.value == nil or type(e.src) ~= "string" or e.src == "" then
					bad(("tuning %s has no value or no src"):format(e.id))
				else
					Tuning.by_id[e.id] = e
					Tuning.entries[#Tuning.entries + 1] = e
				end
			end
		end
	end
end

function Tuning.setting_id(e)
	return "u_" .. e.id
end

function Tuning.get(id)
	local e = Tuning.by_id[id]
	if not e then
		error("unknown tuning id " .. tostring(id))
	end
	if e.untuned then
		local v = mod:get(Tuning.setting_id(e))
		if type(v) ~= "number" then v = e.default end
		return v
	end
	return e.value
end

-- Cited positions are stored as {x, y, z}; returns a fresh Vector3.
function Tuning.vec(id)
	local v = Tuning.get(id)
	return Vector3(v[1], v[2], v[3]) -- struct: x,y,z index
end

function Tuning.widgets()
	local subs = {}
	for i = 1, #Tuning.entries do
		local e = Tuning.entries[i]
		if e.untuned then
			subs[#subs + 1] = {
				setting_id = Tuning.setting_id(e),
				type = "numeric",
				localize = false,
				title = "UNTUNED: no source - " .. e.id,
				tooltip = (e.desc or "") .. "\nSlider bounds are UI limits only. Group: " .. e.group,
				default_value = e.default,
				range = { e.min, e.max },
				decimals_number = e.decimals or 0,
			}
		end
	end
	return subs
end

setmetatable(Tuning, { __call = function(_, id) return Tuning.get(id) end })

return Tuning
