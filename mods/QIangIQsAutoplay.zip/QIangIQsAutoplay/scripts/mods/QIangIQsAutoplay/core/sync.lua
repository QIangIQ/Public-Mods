--[[
    sync.lua: "every human runs QIangIQsAutoplay" handshake and loop-state sync
    over backend presence keys.

    Copied (standalone) from Vox Manifold, the transport QIangIQsSyncChannel uses:
      publish: hook PresenceEntryMyself.create_key_values and add our key
               (Vox Manifold presence.lua:201-233); push with
               Managers.presence:_update_my_presence(white_list) (presence.lua:235-263)
      read:    member:presence():_key_value_string(key) (presence.lua:265-315)
      members: Managers.party_immaterium:all_members() (presence.lua:325-340)
    The game itself sends partial white_lists (GAME presence_manager.lua:141-144),
    so keys merge on the backend instead of erasing each other.
    Our own key name (not Vox's "vm_" prefix) so the two never collide.

    The create_key_values hook itself is installed by the core file (one hook
    per method rule); it calls Sync.contribute.
]]

local mod = get_mod("QIangIQsAutoplay")

local KEY = "qiapv1"
local PROTO = "AP1"

local Sync = {
	key = KEY,
	mine = {},           -- field -> string
	encoded = nil,       -- last value pushed
	dirty = true,
	since_push = math.huge,
	since_poll = math.huge,
	peers = {},          -- account_id -> { fields, raw, seen_t, name }
	now = 0,
	push_count = 0,
	last_error = nil,
}

local T, Log

function Sync.init(tuning, log)
	T, Log = tuning, log
end

local function encode(fields)
	local keys = {}
	for k in pairs(fields) do keys[#keys + 1] = k end
	table.sort(keys)
	local parts = { PROTO }
	for i = 1, #keys do
		parts[#parts + 1] = keys[i] .. "=" .. tostring(fields[keys[i]])
	end
	return table.concat(parts, ";")
end

local function decode(raw)
	if type(raw) ~= "string" then return nil end
	local out, first = {}, true
	for part in raw:gmatch("[^;]+") do
		if first then
			if part ~= PROTO then return nil end
			first = false
		else
			local k, v = part:match("^([^=]+)=(.*)$")
			if k then out[k] = v end
		end
	end
	if first then return nil end
	return out
end
Sync.decode = decode

function Sync.set(field, value)
	local v = tostring(value)
	if Sync.mine[field] ~= v then
		Sync.mine[field] = v
		Sync.dirty = true
	end
end

-- Called from the core's PresenceEntryMyself.create_key_values hook.
function Sync.contribute(key_values, white_list)
	if type(key_values) ~= "table" then return end
	if white_list and not white_list[KEY] then return end
	if Sync.encoded ~= nil then
		key_values[KEY] = Sync.encoded
	end
end

local function push()
	local presence = Managers.presence
	if not presence or type(presence._update_my_presence) ~= "function" then
		Sync.last_error = "Managers.presence._update_my_presence missing"
		return false
	end
	-- _update_my_presence only sends while the stream exists (GAME presence_manager.lua:386-388);
	-- the stream itself starts with the full key set incl. ours (presence_manager.lua:278).
	if not presence._my_presence_stream then
		Sync.last_error = "presence stream not started yet"
		return false
	end
	local ok, err = pcall(presence._update_my_presence, presence, { [KEY] = true })
	if not ok then
		Sync.last_error = tostring(err)
		return false
	end
	Sync.push_count = Sync.push_count + 1
	Sync.last_error = nil
	return true
end

function Sync.my_account_id()
	local pim = Managers.party_immaterium
	local me = pim and pim.get_myself and pim:get_myself()
	if me and me.account_id then
		local ok, id = pcall(me.account_id, me)
		if ok then return id end
	end
	local p = Managers.player and Managers.player:local_player_safe(1)
	return p and p.account_id and p:account_id() or nil
end

function Sync.members()
	local pim = Managers.party_immaterium
	if not pim or type(pim.all_members) ~= "function" then return {} end
	local ok, members = pcall(pim.all_members, pim)
	if not ok or type(members) ~= "table" then return {} end
	local out = {}
	for i = 1, #members do out[i] = members[i] end
	return out
end

local function read_member(member)
	local okp, entry = pcall(member.presence, member)
	if not okp or not entry then return nil end
	if type(entry.is_myself) == "function" then
		local okm, me = pcall(entry.is_myself, entry)
		if okm and me then return nil, true end
	end
	if type(entry._key_value_string) ~= "function" then return nil end
	local ok, raw = pcall(entry._key_value_string, entry, KEY)
	if not ok then return nil end
	return raw
end

local function poll()
	local members = Sync.members()
	local present = {}
	for i = 1, #members do
		local m = members[i]
		local okid, id = pcall(m.account_id, m)
		if okid and id then
			local raw, is_me = read_member(m)
			if not is_me then
				present[id] = true
				local p = Sync.peers[id] or { seen_t = -math.huge }
				p.member = m
				p.raw = raw
				local fields = decode(raw)
				if fields then
					p.fields = fields
					if p.last_raw ~= raw then
						p.last_raw = raw
						if Log then Log.write("sync", "debug", "peer %s -> %s", tostring(id), tostring(raw)) end
					end
					p.seen_t = Sync.now
				end
				Sync.peers[id] = p
			end
		end
	end
	for id in pairs(Sync.peers) do
		if not present[id] then
			if Log then Log.write("sync", "info", "peer %s left the party", tostring(id)) end
			Sync.peers[id] = nil
		end
	end
end

function Sync.update(dt, t)
	Sync.now = t or (Sync.now + dt)
	Sync.since_push = Sync.since_push + dt
	Sync.since_poll = Sync.since_poll + dt
	-- Re-push periodically too: a push can be lost (no stream yet, backend hiccup).
	local due = Sync.dirty or Sync.since_push >= T("presence_repush_s")
	if due and Sync.since_push >= T("presence_min_interval_s") then
		local enc = encode(Sync.mine)
		if #enc > T("presence_max_bytes") then
			Sync.last_error = "presence value too long: " .. #enc
			if Log then Log.write("sync", "error", "%s", Sync.last_error) end
			Sync.since_push = 0
		else
			Sync.encoded = enc
			Sync.since_push = 0
			if push() then
				Sync.dirty = false
				if Log then Log.write("sync", "debug", "pushed %s", enc) end
			end
		end
	end
	if Sync.since_poll >= T("presence_poll_s") then
		Sync.since_poll = 0
		poll()
	end
end

-- Party changed (event party_immaterium_other_members_updated, as Vox Manifold.lua:617-631): push again.
function Sync.force()
	Sync.dirty = true
	Sync.since_push = math.huge
	Sync.since_poll = math.huge
end

-- Peer with a fresh, valid AP1 value?
function Sync.peer_ok(account_id)
	local p = Sync.peers[account_id]
	if not p or not p.fields then return false end
	return (Sync.now - p.seen_t) <= T("peer_stale_s")
end

function Sync.peer_count()
	local n = 0
	for _ in pairs(Sync.peers) do n = n + 1 end
	return n
end

-- Clears our key on the backend (master off / unload).
function Sync.retract()
	-- An empty value overwrites the key (keys merge, so leaving it out would keep the old one).
	Sync.mine = {}
	Sync.encoded = ""
	Sync.dirty = false
	push()
end

return Sync
