--[[
    log.lua: per-module log files, a log level setting and an in-memory ring
    buffer for /autoplay_dump.
    File writing pattern copied from QIangIQsEnemyBeams.lua:47-71 (Mods.lua.io,
    open/append/flush/close per line, byte cap).
]]

local mod = get_mod("QIangIQsAutoplay")

local DIR = "./../mods/QIangIQsAutoplay/"
local LEVELS = { error = 1, warn = 2, info = 3, debug = 4 } -- struct: level enum
local NAMES = { "ERROR", "WARN", "INFO", "DEBUG" }

local Log = { ring = {}, ring_head = 0, ring_count = 0, bytes = {} }

local T -- set by Log.init

function Log.init(tuning)
	T = tuning
end

local function get_io()
	local mods = rawget(_G, "Mods")
	return mods and mods.lua and mods.lua.io or nil
end

local function level_now()
	return LEVELS[mod:get("log_level") or "info"] or LEVELS.info
end

local function ring_push(line)
	local size = T and T("ring_size") or 1
	Log.ring_head = (Log.ring_head % size) + 1
	Log.ring[Log.ring_head] = line
	if Log.ring_count < size then Log.ring_count = Log.ring_count + 1 end
end

local function file_write(module_name, line)
	local io_lib = get_io()
	if not io_lib then return end
	local cap = T and T("log_max_bytes") or 0
	local used = Log.bytes[module_name] or 0
	if used + #line > cap then return end
	local f = io_lib.open(DIR .. "log_" .. module_name .. ".log", "a")
	if not f then return end
	f:write(line)
	f:flush()
	f:close()
	Log.bytes[module_name] = used + #line
end

function Log.write(module_name, level, fmt, ...)
	local lv = LEVELS[level] or LEVELS.info
	local ok, msg = pcall(string.format, fmt, ...)
	if not ok then msg = tostring(fmt) end
	local line = ("[%s] %-5s %-14s %s\n"):format(tostring(os.date("%H:%M:%S")), NAMES[lv], module_name, msg)
	ring_push(line)
	if lv <= level_now() then
		file_write(module_name, line)
	end
	if lv == LEVELS.error then
		mod:error("[%s] %s", module_name, msg)
	end
end

-- Ring in chronological order.
function Log.lines()
	local out = {}
	local size = T and T("ring_size") or 1
	local n = Log.ring_count
	local start = Log.ring_head - n + 1
	for i = 0, n - 1 do
		local idx = ((start + i - 1) % size) + 1
		out[#out + 1] = Log.ring[idx]
	end
	return out
end

function Log.dump()
	local io_lib = get_io()
	local lines = Log.lines()
	if not io_lib then return nil, #lines end
	local path = DIR .. "dump_" .. tostring(os.time()) .. ".log"
	local f = io_lib.open(path, "w")
	if not f then return nil, #lines end
	for i = 1, #lines do f:write(lines[i]) end
	f:flush()
	f:close()
	return path, #lines
end

function Log.clear_files(module_names)
	local io_lib = get_io()
	if not io_lib then return end
	for i = 1, #module_names do
		local f = io_lib.open(DIR .. "log_" .. module_names[i] .. ".log", "w")
		if f then f:close() end
		Log.bytes[module_names[i]] = 0
	end
end

return Log
