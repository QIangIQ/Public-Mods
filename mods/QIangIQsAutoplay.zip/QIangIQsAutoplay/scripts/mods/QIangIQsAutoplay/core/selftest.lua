--[[
    selftest.lua: checks that every hook target and API the mod relies on exists.
    run_static: at load and on /autoplay_selftest (requires game script modules and checks methods).
    run_runtime: at gameplay enter and on /autoplay_selftest (managers, nav A* probe, module probes).
    Results go to log_selftest.log and the panel header.
]]

local Selftest = {}
local mod, T, Log, Api

function Selftest.init(m, tuning, log, api)
	mod, T, Log, Api = m, tuning, log, api
end

-- { path or CLASS name, method, where it is used }
local HOOK_TARGETS = {
	{ "scripts/managers/player/player_game_states/human_input_handler", "_parse_input", "input layer" },
	{ "scripts/utilities/aim_assist", "apply_aim_assist", "aim layer" },
	{ "scripts/managers/presence/presence_entry_myself", "create_key_values", "presence handshake" },
	{ "scripts/managers/game_mode/game_modes/game_mode_coop_complete_objective", "rpc_client_set_local_player_orientation", "teleport signal" },
	{ "scripts/extension_systems/fx/minion_fx_extension", "_trigger_inventory_wwise_event", "wwise_minion event" },
	{ "scripts/extension_systems/animation/animation_system", "rpc_minion_anim_event", "minion_anim_event" },
	{ "CLASS.LobbyView", "on_enter", "lobby_enter event" },
	{ "CLASS.LobbyView", "_set_own_player_ready_status", "auto_ready" },
	{ "CLASS.EndView", "on_enter", "end_view_enter" },
	{ "CLASS.EndView", "update", "end_view_update" },
	{ "scripts/settings/voting/voting_templates/mission_vote_matchmaking_immaterium", "on_started", "vote_started" },
	{ "CLASS.UnitSpawnerManager", "_add_network_unit", "enemy tracker spawn" },
	{ "CLASS.MinionDeathManager", "set_dead", "enemy tracker death" },
	{ "scripts/managers/presence/presence_manager", "_update_my_presence", "presence push" },
	{ "scripts/managers/party_immaterium/party_immaterium_manager", "wanted_mission_selected", "start_mission" },
	{ "scripts/managers/party_immaterium/party_immaterium_manager", "is_in_private_session", "gate" },
	{ "scripts/managers/party_immaterium/party_immaterium_manager", "all_members", "sync" },
	{ "scripts/managers/party_immaterium/party_immaterium_manager", "num_other_members", "start_mission" },
	{ "scripts/managers/party_immaterium/party_immaterium_manager", "are_all_members_in_hub", "start_mission" },
	{ "scripts/managers/multiplayer/multiplayer_session_manager", "leave", "end_skip / ortus leave fallback" },
	{ "scripts/managers/multiplayer/multiplayer_session_manager", "host_type", "gate" },
	{ "scripts/extension_systems/interaction/interactor_extension", "focus_unit", "interaction" },
	{ "scripts/managers/nav_mesh/nav_mesh_manager", "client_traverse_logic", "auto_path" },
}

local GLOBALS = {
	{ "GwNavAStar", { "create", "start", "processing_finished", "path_found", "node_count", "node_at_index", "destroy" } },
	{ "GwNavQueries", { "triangle_from_position", "raycast" } },
	{ "Level", { "units" } },
	{ "Unit", { "is_a", "has_node", "node", "world_position", "alive" } },
	{ "PhysicsWorld", { "raycast" } },
	{ "Network", { "pack_unpack" } },
}

local function record(ok, fmt, ...)
	local s = mod.state.selftest
	local msg = (fmt):format(...)
	if ok then s.ok = s.ok + 1 else s.fail = s.fail + 1 end
	s.lines[#s.lines + 1] = (ok and "OK   " or "FAIL ") .. msg
	Log.write("selftest", ok and "info" or "warn", "%s %s", ok and "OK  " or "FAIL", msg)
end

local function pending(why, fmt, ...)
	local s = mod.state.selftest
	local msg = (fmt):format(...)
	s.pending = (s.pending or 0) + 1
	s.lines[#s.lines + 1] = "WAIT " .. msg .. " (" .. why .. ")"
	Log.write("selftest", "info", "WAIT %s (%s)", msg, why)
end

local function resolve(target)
	local cls = target:match("^CLASS%.(.+)$")
	if cls then
		local C = rawget(_G, "CLASS")
		return C and C[cls] or nil
	end
	-- Never require() here: a require that fails during mod load leaves a marker in
	-- package.loaded, and the game's own later require of that file then dies with
	-- "loop or previous error loading module" (crash seen 2026-11-06, animation_system).
	-- Only look at files the game has already loaded.
	local loaded = package.loaded[target]
	if type(loaded) == "table" then return loaded end
	local store = rawget(_G, "Mods") and Mods.require_store and Mods.require_store[target]
	if store and #store > 0 then return store[#store] end
	return nil, "not loaded yet"
end

function Selftest.run_static()
	local s = mod.state.selftest
	s.ok, s.fail, s.pending, s.lines, s.ran = 0, 0, 0, {}, true
	for i = 1, #HOOK_TARGETS do
		local h = HOOK_TARGETS[i]
		local obj, why = resolve(h[1])
		if not obj and why then
			pending(why, "%s.%s (%s)", h[1], h[2], h[3]) -- struct: tuple index
		else
			local fn = obj and obj[h[2]] -- struct: tuple index
			record(type(fn) == "function", "%s.%s (%s)", h[1], h[2], h[3]) -- struct: tuple index
		end
	end
	for i = 1, #GLOBALS do
		local g = GLOBALS[i]
		local tbl = rawget(_G, g[1])
		for j = 1, #g[2] do -- struct: tuple index
			record(tbl ~= nil and tbl[g[2][j]] ~= nil, "%s.%s", g[1], g[2][j]) -- struct: tuple index
		end
	end
	for i = 1, #T.errors do
		record(false, "tuning: %s", T.errors[i])
	end
	for i = 1, #mod.MODULE_ORDER do
		local name = mod.MODULE_ORDER[i]
		record(mod.modules_by_name[name] ~= nil, "module %s loaded", name)
	end
end

function Selftest.run_runtime()
	record(Managers.presence ~= nil, "Managers.presence")
	record(Managers.party_immaterium ~= nil, "Managers.party_immaterium")
	record(Managers.data_service ~= nil and Managers.data_service.mission_board ~= nil, "Managers.data_service.mission_board")
	if mod.state.where == "mission" then
		local nw = Api.nav()
		record(nw ~= nil, "client nav world")
		local p = Api.local_player()
		local unit = p and p.player_unit
		if nw and unit and Api.alive(unit) then
			local pos = Api.position(unit)
			local h, err = Api.nav_request(pos, pos)
			record(h ~= nil, "client A* start (%s)", tostring(err or "ok"))
			if h then
				-- Only proves create/start work on a client; whether a path comes back
				-- is logged by auto_path on its first real request.
				Api.nav_cancel(h)
			end
		end
	end
	for i = 1, #mod.modules do
		local m = mod.modules[i]
		if m.selftest then
			local ok, res, msg = pcall(m.selftest, Api)
			record(ok and res and true or false, "module %s probe: %s", m.name, tostring(ok and msg or res))
		end
	end
end

return Selftest
