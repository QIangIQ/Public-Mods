--[[
    api.lua: helpers every module may call. Modules get this table as `api`.
    Modules never call mod:hook; they subscribe to core events with api.on().

    Helpers marked AS are copied from QIangIQsAntiSpecialist core.lua (lines given);
    TK from QIangIQsTarkAccount aim_snap.lua.

    Positions handed between frames are plain {x, y, z} tables (api.box /
    api.unbox): a stored engine Vector3 goes stale (vault lesson-stored-vector3-goes-stale).
]]

local Api = { shared = {}, events = {} }

local T, Log, Tracker, Gate

function Api.init(tuning, log, tracker, gate)
	T, Log, Tracker, Gate = tuning, log, tracker, gate
	Api.T = tuning
	Api.tracker = tracker
	Api.gate = gate
end

-- A game file the game itself has already loaded, or nil. Never require() from the
-- mod: a require that fails leaves a marker in package.loaded and the game's own
-- later require of the same file dies ("loop or previous error", crash 2026-11-06).
function Api.loaded(path)
	local m = package.loaded[path]
	if type(m) == "table" then return m end
	local store = rawget(_G, "Mods") and Mods.require_store and Mods.require_store[path]
	if store and #store > 0 then return store[#store] end
	return nil
end

local LAZY = {
	MinionPerception = "scripts/utilities/minion_perception",
	WeaponTemplate = "scripts/utilities/weapon/weapon_template",
}
setmetatable(Api, { __index = function(t, k)
	local path = LAZY[k]
	if not path then return nil end
	local m = Api.loaded(path)
	if m then rawset(t, k, m) end
	return m
end })

-- Logging ---------------------------------------------------------------

function Api.log(module_name, level, fmt, ...)
	Log.write(module_name, level, fmt, ...)
end

-- Module status shown in the panel; logs once per change of decision.
function Api.status(st, state, target, decision, reason)
	st.state, st.target = state, target
	if st.decision ~= decision or st.reason ~= reason then
		st.decision, st.reason = decision, reason
		if st.name then
			Log.write(st.name, "info", "%s | target=%s | %s | %s", tostring(state), tostring(target), tostring(decision), tostring(reason))
		end
	end
end

-- Events ------------------------------------------------------------------
-- Core fires: "wwise_minion"(unit, event_name, target_unit), "minion_anim_event"(unit, index),
-- "teleported"(yaw, pitch), "lobby_enter"(view), "vote_started"(voting_id), "end_view_enter"(view),
-- "end_view_update"(view, dt), "mission_board_init"(view), "gameplay_enter", "gameplay_exit",
-- "emergency_stop", "master"(on).

-- The core sets Api._current to the module whose init() is running, so every
-- subscription has an owner and the core can gate delivery per module.
function Api.on(event, fn)
	local list = Api.events[event]
	if not list then
		list = {}
		Api.events[event] = list
	end
	list[#list + 1] = { fn = fn, owner = Api._current }
end

-- Single-step support for /autoplay_step (Ortus loop).
Api.step_tokens = 0
function Api.step_mode()
	return get_mod("QIangIQsAutoplay"):get("ortus_step_mode") and true or false
end
function Api.take_step()
	if not Api.step_mode() then return true end
	if Api.step_tokens > 0 then
		Api.step_tokens = Api.step_tokens - 1
		return true
	end
	return false
end

-- Time ----------------------------------------------------------------------

-- AS core.lua:41-63
function Api.real_time()
	local tm = Managers.time
	if tm and tm:has_timer("main") then return tm:time("main") end
	return 0
end

function Api.time()
	local tm = Managers.time
	if tm and tm:has_timer("gameplay") then return tm:time("gameplay") end
	return nil
end

-- AS core.lua:717-727 (fixed step = 1 / tick rate)
function Api.fixed_step()
	local cm = Managers.connection
	local ok, rate = pcall(function() return cm and cm.tick_rate and cm:tick_rate() end)
	rate = ok and type(rate) == "number" and rate > 0 and rate or T("tick_rate_default")
	return 1 / rate
end

-- AS core.lua:696-715
function Api.ping()
	local cm = Managers.connection
	local host = cm and cm.host and cm:host()
	if not host or not Network or not Network.ping then return 0 end
	local ok, rtt = pcall(Network.ping, host)
	if not ok or type(rtt) ~= "number" then return 0 end
	return math.max(rtt, 0)
end

-- AS core.lua:732-734: what I see is half a round trip old, my input lands
-- half a round trip plus BUFFER_MIN fixed frames later.
function Api.reaction_delay()
	return Api.ping() + T("input_buffer_frames") * Api.fixed_step()
end

-- Vectors -----------------------------------------------------------------------

function Api.box(v)
	if not v then return nil end
	return { x = v.x, y = v.y, z = v.z }
end

function Api.unbox(b)
	if not b then return nil end
	return Vector3(b.x, b.y, b.z)
end

function Api.flat_dist(a, b)
	local dx, dy = a.x - b.x, a.y - b.y
	return math.sqrt(dx * dx + dy * dy)
end

function Api.dist(a, b)
	local dx, dy, dz = a.x - b.x, a.y - b.y, a.z - b.z
	return math.sqrt(dx * dx + dy * dy + dz * dz)
end

-- Units ------------------------------------------------------------------------

-- AS core.lua:144-146
function Api.unit_ok(unit)
	return type(unit) == "userdata" and Unit.alive(unit)
end

function Api.alive(unit)
	local ha = rawget(_G, "HEALTH_ALIVE")
	return Api.unit_ok(unit) and (not ha or ha[unit]) and true or false
end

-- AS core.lua:148-152
function Api.position(unit)
	local lookup = rawget(_G, "POSITION_LOOKUP")
	return lookup and lookup[unit] or Unit.world_position(unit, 1)
end

-- AS core.lua:184-188
function Api.component(unit, name)
	local ext = ScriptUnit.has_extension(unit, "unit_data_system")
	return ext and ext:read_component(name) or nil
end

function Api.breed_name(unit)
	local info = Tracker and Tracker.units[unit]
	if info then return info.breed_name end
	local ext = ScriptUnit.has_extension(unit, "unit_data_system")
	if not ext then return nil end
	local ok, breed = pcall(ext.breed, ext)
	return ok and breed and breed.name or nil
end

-- character_state.state_name (GAME player_unit_status.lua:9-21)
function Api.character_state(unit)
	local cs = Api.component(unit, "character_state")
	return cs and cs.state_name or nil
end

-- AS core.lua:902-908
local ACT_STATES = { walking = true, sprinting = true, dodging = true, sliding = true, jumping = true, falling = true }
function Api.can_act(unit)
	local s = Api.character_state(unit)
	return s and ACT_STATES[s] or false, s
end

-- AS core.lua:895-899
function Api.wielded(unit)
	local inv = Api.component(unit, "inventory")
	return inv and inv.wielded_slot
end

function Api.weapon_template(unit)
	if not Api.WeaponTemplate then return nil end
	local ok, tpl = pcall(Api.WeaponTemplate.current_weapon_template, Api.component(unit, "weapon_action"))
	return ok and tpl or nil
end

-- AS core.lua:776-794
function Api.target_of(unit)
	local gsm = Managers.state and Managers.state.game_session
	local spawner = Managers.state and Managers.state.unit_spawner
	if not gsm or not spawner or not Api.MinionPerception then return nil end
	local ok, session = pcall(gsm.game_session, gsm)
	local ok2, go_id = pcall(spawner.game_object_id, spawner, unit)
	if not ok or not session or not ok2 or not go_id then return nil end
	local ok3, target = pcall(Api.MinionPerception.target_unit, session, go_id)
	return ok3 and target or nil
end

-- AS core.lua:875-893
function Api.game_object_field(unit, field)
	local gsm = Managers.state and Managers.state.game_session
	local spawner = Managers.state and Managers.state.unit_spawner
	if not gsm or not spawner then return nil end
	local ok, session = pcall(gsm.game_session, gsm)
	local ok2, go_id = pcall(spawner.game_object_id, spawner, unit)
	if not ok or not session or not ok2 or not go_id then return nil end
	local ok3, value = pcall(GameSession.game_object_field, session, go_id, field)
	return ok3 and value or nil
end

-- AS core.lua:830-856: closing speed toward a point, numbers only.
local _track = setmetatable({}, { __mode = "k" })
function Api.track(unit, me_pos, t)
	local p = Api.position(unit)
	local dx, dy = p.x - me_pos.x, p.y - me_pos.y
	local d = math.sqrt(dx * dx + dy * dy)
	local rec = _track[unit]
	if not rec then
		_track[unit] = { t = t, d = d, v = 0 }
		return d, 0
	end
	local dt = t - rec.t
	if dt >= Api.fixed_step() then
		rec.v = (rec.d - d) / dt
		rec.t, rec.d = t, d
	elseif dt < 0 then
		rec.t, rec.d, rec.v = t, d, 0
	end
	return d, rec.v
end

-- Enemies tracked by the shared tracker: unit -> { breed_name, kind, display_name }.
function Api.enemies()
	return Tracker and Tracker.units or {}
end

-- AS core.lua:811-828 (broadphase works on clients)
local _query = {}
function Api.enemies_near(me_unit, pos, radius)
	local manager = Managers.state and Managers.state.extension
	local side_system = manager and manager:system("side_system")
	local broadphase_system = manager and manager:system("broadphase_system")
	local side = side_system and side_system.side_by_unit[me_unit]
	local broadphase = broadphase_system and broadphase_system.broadphase
	if not side or not broadphase then return 0, _query end
	local ok, count = pcall(broadphase.query, broadphase, pos, radius, _query, side:relation_side_names("enemy"))
	return ok and count or 0, _query
end

-- Camera / orientation -----------------------------------------------------------

function Api.local_player()
	local pm = Managers.player
	if not pm or not pm.local_player_safe then return nil end
	local ok, p = pcall(pm.local_player_safe, pm, 1)
	return ok and p or nil
end

-- HumanPlayer.get_orientation returns the _orientation TABLE {yaw, pitch, roll}
-- (GAME human_player.lua:184-186). Returns three numbers.
function Api.orientation()
	local p = Api.local_player()
	if not p or not p.get_orientation then return nil end
	local ok, o = pcall(p.get_orientation, p)
	if not ok or type(o) ~= "table" then return nil end
	return o.yaw, o.pitch, o.roll
end

-- First person unit position (GAME player_unit_first_person_extension.lua:567)
function Api.eye_position(unit)
	local fp = ScriptUnit.has_extension(unit, "first_person_system")
	if not fp then return nil end
	local ok, fpu = pcall(fp.first_person_unit, fp)
	if not ok or not fpu then return nil end
	return Unit.world_position(fpu, 1)
end

-- TK aim_snap.lua:257-262 (yaw = atan2(-d.x, d.y))
function Api.yaw_pitch_to(from, to)
	local d = Vector3.normalize(to - from)
	return math.atan2(-d.x, d.y), math.asin(math.clamp(d.z, -1, 1))
end

-- World direction -> move input {x = right, y = forward} for the current yaw.
-- Inverse of the yaw convention above: forward = (-sin yaw, cos yaw), right = (cos yaw, sin yaw).
function Api.move_toward(dir_x, dir_y)
	local yaw = Api.orientation()
	if not yaw then return nil end
	local len = math.sqrt(dir_x * dir_x + dir_y * dir_y)
	if len <= 0 then return { x = 0, y = 0 } end
	dir_x, dir_y = dir_x / len, dir_y / len
	local fx, fy = -math.sin(yaw), math.cos(yaw)
	local rx, ry = math.cos(yaw), math.sin(yaw)
	return { x = dir_x * rx + dir_y * ry, y = dir_x * fx + dir_y * fy }
end

-- Physics / LOS -----------------------------------------------------------------

-- TK aim_snap.lua:234-240
function Api.physics_world()
	local cam = Managers.state and Managers.state.camera
	local world = cam and cam._world
	if not world then return nil end
	local ok, pw = pcall(World.physics_world, world)
	return ok and pw or nil
end

-- TK aim_snap.lua:242-255
local LOS_FILTER = "filter_player_character_shooting_raycast_statics"
function Api.has_los(from, to)
	local pw = Api.physics_world()
	if not pw then return false end
	local delta = to - from
	local dist = Vector3.length(delta)
	if dist < T("los_min_dist_m") then return true end
	local sample = dist - T("los_backoff_m")
	if sample <= 0 then return true end
	local hit = PhysicsWorld.raycast(pw, from, delta / dist, sample, "any", "types", "statics", "collision_filter", LOS_FILTER)
	return not hit
end

-- Interaction -------------------------------------------------------------------

-- InteractorExtension.focus_unit (GAME interactor_extension.lua:817)
function Api.focus_unit(player_unit)
	local ext = ScriptUnit.has_extension(player_unit, "interactor_system")
	if not ext then return nil end
	local ok, u = pcall(ext.focus_unit, ext)
	return ok and u or nil
end

-- The usable target the engine selected: interaction component target_unit/state/type
-- (GAME player_unit_data_component_config.lua:1019-1027). focus_unit only ever holds
-- NON-usable units (GAME interactor_extension.lua:472-480), so presses must check this instead.
function Api.interaction(player_unit)
	local ic = Api.component(player_unit, "interaction")
	if not ic then return nil end
	return ic.target_unit, ic.state, ic.type
end

-- Max interaction distance = detection_radius + sphere_offset (GAME interactor_extension.lua:686-691).
function Api.interact_range()
	return T("interact_detection_radius") + T("interact_sphere_offset")
end

function Api.interactee(unit)
	return ScriptUnit.has_extension(unit, "interactee_system")
end

-- Navigation (client nav world: GAME gameplay_init_step_nav_world.lua:30, nav_mesh_manager.lua:579-589)
-- A* on a client is unverified in the game source; the self-test probes it.

function Api.nav()
	local nm = Managers.state and Managers.state.nav_mesh
	if not nm then return nil end
	local okw, nw = pcall(nm.nav_world, nm)
	local okt, tl = pcall(nm.client_traverse_logic, nm)
	if not okw or not nw then return nil end
	return nw, okt and tl or nil
end

-- NavQueries.position_on_mesh (GAME nav_queries.lua:8-25)
function Api.on_mesh(pos, above, below)
	local nw, tl = Api.nav()
	if not nw then return nil end
	above, below = above or T("nav_check_above"), below or T("nav_check_below")
	local ok, alt
	if tl then
		ok, alt = pcall(GwNavQueries.triangle_from_position, nw, pos, above, below, tl)
	else
		ok, alt = pcall(GwNavQueries.triangle_from_position, nw, pos, above, below)
	end
	if ok and alt then return Vector3(pos.x, pos.y, alt) end
	return nil
end

-- A* request: GwNavAStar.create/start/processing_finished/path_found/node_count/node_at_index
-- (GAME payload_extension.lua:348, 445, 498-510).
function Api.nav_request(from, to)
	local nw, tl = Api.nav()
	if not nw then return nil, "no nav world" end
	local ok, astar = pcall(GwNavAStar.create)
	if not ok or not astar then return nil, "GwNavAStar.create failed" end
	local ok2, err = pcall(GwNavAStar.start, astar, nw, from, to, tl)
	if not ok2 then
		pcall(GwNavAStar.destroy, astar)
		return nil, "GwNavAStar.start failed: " .. tostring(err)
	end
	return { astar = astar }
end

-- Returns "pending" | "found", nodes | "failed", reason
function Api.nav_poll(h)
	if not h or not h.astar then return "failed", "no request" end
	local ok, done = pcall(GwNavAStar.processing_finished, h.astar)
	if not ok then
		Api.nav_cancel(h)
		return "failed", "processing_finished error"
	end
	if not done then return "pending" end
	local okf, found = pcall(GwNavAStar.path_found, h.astar)
	if not okf or not found then
		Api.nav_cancel(h)
		return "failed", "no path"
	end
	local nodes = {}
	local okc, n = pcall(GwNavAStar.node_count, h.astar)
	if okc and n then
		for i = 1, n do
			local okn, p = pcall(GwNavAStar.node_at_index, h.astar, i)
			if okn and p then nodes[#nodes + 1] = Api.box(p) end
		end
	end
	Api.nav_cancel(h)
	return "found", nodes
end

function Api.nav_cancel(h)
	if h and h.astar then
		pcall(GwNavAStar.destroy, h.astar)
		h.astar = nil
	end
end

-- Other mods doing the same job ----------------------------------------------------
-- Returns true when mod `name` is enabled and (if given) its setting is truthy.
function Api.other_mod_active(name, setting)
	local other = get_mod(name)
	if not other then return false end
	local ok, enabled = pcall(other.is_enabled, other)
	if not ok or not enabled then return false end
	if setting == nil then return true end
	local ok2, v = pcall(other.get, other, setting)
	return ok2 and v and v ~= 0 and true or false
end

return Api
