--[[
    panel.lua: on-screen debug panel. One line per module: switch, state, target,
    last decision and the reason.
    Own screen gui on level_world, re-validated every call because a gui dies with
    its world (FpsDoctor pattern, as in 0.1.0); top-left origin, y down (vault
    lesson-screen-gui-origin-conflicting-notes). pcall-guarded; a failure turns the
    panel off until reload.
]]

local Panel = { gui = nil, world = nil, font = nil, failed = false }

local mod, T, Log, Gate, Sync

local FALLBACK_FONT = "content/ui/fonts/proxima_nova_bold" -- QIangIQsCoherencyZone FONT (from 0.1.0)

function Panel.init(m, tuning, log, gate, sync)
	mod, T, Log, Gate, Sync = m, tuning, log, gate, sync
end

local function level_world()
	local wm = Managers.world
	if wm and wm:has_world("level_world") then return wm:world("level_world") end
	return nil
end

local function ensure_gui()
	local world = level_world()
	if not world then
		Panel.gui, Panel.world = nil, nil
		return nil
	end
	if Panel.gui and Panel.world == world then return Panel.gui end
	Panel.gui = World.create_screen_gui(world, "immediate")
	Panel.world = world
	return Panel.gui
end

local function get_font()
	if Panel.font then return Panel.font end
	local fm = Managers.font
	local data = fm and fm:data_by_type("arial")
	Panel.font = (data and data.path) or FALLBACK_FONT
	return Panel.font
end

local function short(s)
	s = tostring(s or "-")
	local max = T("panel_field_chars")
	if #s > max then s = s:sub(1, max) end
	return s
end

local function module_line(m)
	local sw
	if m.runtime_off then sw = "ERR"
	elseif not mod:get(m.setting) then sw = "off"
	elseif m.blocked then sw = "BLK"
	else sw = "ON" end
	local st = m.st
	if sw == "BLK" then
		return ("%-13s %-3s %s"):format(m.name, sw, short(m.blocked)), sw
	end
	return ("%-13s %-3s %s | %s | %s | %s"):format(m.name, sw, short(st.state), short(st.target), short(st.decision), short(st.reason)), sw
end

local COLOURS = {
	head = { 255, 255, 220, 120 },  -- struct: RGBA colour
	ON = { 255, 120, 255, 120 },    -- struct: RGBA colour
	off = { 255, 150, 150, 150 },   -- struct: RGBA colour
	BLK = { 255, 255, 190, 90 },    -- struct: RGBA colour
	ERR = { 255, 255, 90, 90 },     -- struct: RGBA colour
	bg = { 150, 10, 10, 10 },       -- struct: RGBA colour
}

local function colour(key)
	local c = COLOURS[key] or COLOURS.off
	return Color(c[1], c[2], c[3], c[4]) -- struct: RGBA components
end

local function draw()
	local gui = ensure_gui()
	if not gui then return end
	local state = mod.state
	local lines = {}
	lines[#lines + 1] = { ("Autoplay %s  master %s  where %s  gate %s: %s"):format(mod.VERSION,
		state.master and "ON" or "off", state.where, Gate.last.kind, Gate.last.reason), "head" }
	lines[#lines + 1] = { ("party %s  peers %d  sync %s  aim %s  selftest %d ok / %d fail"):format(
		Gate.last_party.reason ~= "" and Gate.last_party.reason or "-", Sync.peer_count(),
		Sync.last_error or "ok", state.aim_block or (state.aim_owner or "-"),
		state.selftest.ok, state.selftest.fail), "head" }
	local only_on = mod:get("panel_only_enabled")
	for i = 1, #mod.modules do
		local m = mod.modules[i]
		if not only_on or mod:get(m.setting) or m.runtime_off then
			local text, sw = module_line(m)
			lines[#lines + 1] = { text, sw }
		end
	end

	local x, y = T("panel_x"), T("panel_y")
	local size, line_h, width = T("panel_font"), T("panel_line_h"), T("panel_width")
	local pad = line_h / (1 + 1) -- struct: half a line of padding
	Gui.rect(gui, Vector3(x - pad, y - pad, T("panel_layer")), Vector2(width, line_h * #lines + pad * (1 + 1)), colour("bg")) -- struct: padding both sides
	local font = get_font()
	for i = 1, #lines do
		Gui.slug_text(gui, lines[i][1], font, size, Vector3(x, y + (i - 1) * line_h, T("panel_layer") + 1), nil, colour(lines[i][2])) -- struct: text one layer above the panel
	end
end

function Panel.reset()
	Panel.gui, Panel.world = nil, nil
end

function Panel.draw_safe()
	if Panel.failed or not mod.state.in_gameplay or not mod:get("show_overlay") then return end
	local ok, err = pcall(draw)
	if not ok then
		Panel.failed = true
		Panel.gui, Panel.world = nil, nil
		Log.write("core", "error", "panel disabled until reload: %s", tostring(err))
	end
end

return Panel
