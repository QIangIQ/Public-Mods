-- Support tuning: lib_interact, revive, medicae, pickups, chests (see core/tuning.lua for the entry format).

-- Abbreviations: BX = scripts/extension_systems/behavior/bot_behavior_extension.lua
--                BG = scripts/extension_systems/group/bot_group.lua
--                PER = scripts/extension_systems/perception/bot_perception_extension.lua
--                BC = scripts/extension_systems/behavior/utilities/conditions/bt_bot_conditions.lua
-- Every id carries the prefix sup_ so it cannot collide with another group.
-- Reused from the core group (not redefined here): interact_retry_s, move_to_flat_eps, interact_detection_radius, interact_sphere_offset.
return {
	-- Interaction reach for an Ogryn (humans use api.interact_range()) --------------------------------
	{ id = "sup_ogryn_detection_radius", value = 1.7, src = "GAME scripts/settings/interaction/interaction_settings.lua:7 (ogryn_detection_radius)" },
	{ id = "sup_ogryn_sphere_offset", value = 1.5, src = "GAME scripts/settings/interaction/interaction_settings.lua:8 (ogryn_sphere_offset)" },

	-- Approach geometry -------------------------------------------------------------------------------
	{ id = "sup_direct_move_m", value = 3.2, src = "GAME scripts/extension_systems/behavior/utilities/conditions/bt_bot_conditions.lua:280 (can_loot max_distance): inside this range a bot interacts without pathing; here we walk straight instead of using shared.nav_goal, and it is the nav_goal tolerance" },
	{ id = "sup_stand_off_m", value = 1, src = "GAME scripts/extension_systems/behavior/bot_behavior_extension.lua:809 (ally: target + normalize(self - target)), :749-750 (ammo), :722-723 (station): the bot stands one normalised vector (1 m) from the target" },
	{ id = "sup_ledge_back_off_m", value = 0.5, src = "GAME scripts/extension_systems/behavior/bot_behavior_extension.lua:797 (ledge rescue: stand 0.5 m behind the hanging ally along its flat forward)" },

	-- Retry policy (no bot source for giving up: the bot just retries every try_again_time) ------------
	{ id = "sup_max_attempts", untuned = true, default = 3, min = 1, max = 10, decimals = 0,
		desc = "Failed press/approach attempts on one target before it is skipped. Bots never give up (they re-press every interact_retry_s), so no source." },
	{ id = "sup_blacklist_s", untuned = true, default = 30, min = 1, max = 300, decimals = 0,
		desc = "Seconds a target is skipped after sup_max_attempts failures or a failed path. No source." },

	-- Revive / rescue (bot_perception_extension) -------------------------------------------------------
	{ id = "sup_aid_monster_self_sq", value = 12, src = "GAME scripts/extension_systems/perception/bot_perception_extension.lua:343 (ALLOWED_AID_MIN_RANGE_MONSTER_TARGETING_SELF_SQ): no aid while a monster that targets you is closer than sqrt of this (squared metres)" },
	{ id = "sup_aid_monster_ally_m", value = 3.5, src = "GAME scripts/extension_systems/perception/bot_perception_extension.lua:344 (ALLOWED_AID_MIN_RANGE_MONSTER_ALLY_BASE)" },
	{ id = "sup_aid_monster_current_ally_m", value = 1, src = "GAME scripts/extension_systems/perception/bot_perception_extension.lua:345 (..._CURRENT_ALLY_BASE, used while already helping that ally)" },
	{ id = "sup_aid_monster_targeting_add_m", value = 1.4, src = "GAME scripts/extension_systems/perception/bot_perception_extension.lua:346 (..._TARGETING_ALLY_MODIFIER)" },
	{ id = "sup_aid_min_ally_health", value = 0.5, src = "GAME scripts/extension_systems/perception/bot_perception_extension.lua:347 (MIN_ALLY_HEALTH_TO_CONSIDER_MONSTERS)" },
	{ id = "sup_proximity_enemy_m", value = 5, src = "GAME scripts/extension_systems/perception/bot_perception_extension.lua:8 (IN_PROXIMITY_DISTANCE): radius of 'enemies in proximity' for the ledge threat check and the combat ammo threshold" },
	{ id = "sup_ally_stickiness_m", value = 3, src = "GAME scripts/extension_systems/group/bot_group.lua:303,318 (ALLY_AID_PRIORITY_STICKINESS_DISTANCE): switch ally only if another is this much closer" },

	-- Health station (bot_behavior_extension _update_health_stations) -------------------------------------
	{ id = "sup_station_need_base", value = 0.66, src = "GAME scripts/extension_systems/behavior/bot_behavior_extension.lua:301 (DAMAGE_TAKEN_VALUE_REQUIRED)" },
	{ id = "sup_station_need_floor", value = 0.25, src = "GAME scripts/extension_systems/behavior/bot_behavior_extension.lua:304 (TIME_IN_PROIXMITY_DAMAGE_TAKEN_VALUE_REQUIRED)" },
	{ id = "sup_station_ramp_s", value = 20, src = "GAME scripts/extension_systems/behavior/bot_behavior_extension.lua:303 (TIME_IN_PROXIMITY_MAX_T)" },
	{ id = "sup_station_prox_sq", value = 5625, src = "GAME scripts/extension_systems/behavior/bot_behavior_extension.lua:305,327 (PROXIMITY_DISTANCE; compared as distance*distance where distance is already squared, see health_station_system.lua:170-184)" },
	{ id = "sup_station_max_dist_sq", value = 400, src = "GAME scripts/extension_systems/behavior/bot_behavior_extension.lua:652,720 (HEALTH_STATION_MAX_DISTANCE_SQUARED, compared with the squared distance)" },
	{ id = "sup_queue_ratio", value = 2, src = "GAME scripts/extension_systems/behavior/bot_behavior_extension.lua:371 (another human counts in the station queue when my damage value < theirs * 2)" },
	{ id = "sup_perm_damage_weight", value = 3, src = "GAME scripts/extension_systems/behavior/bot_behavior_extension.lua:302,359 (HEALTH_VALUE_PER_PERMANTENT_DAMAGE)" },

	-- Pickups ------------------------------------------------------------------------------------------
	{ id = "sup_ammo_need", value = 0.75, src = "GAME scripts/extension_systems/behavior/bot_behavior_extension.lua:245 (NEEDS_AMMO_PERCENTAGE)" },
	{ id = "sup_ammo_need_combat", value = 0.1, src = "GAME scripts/extension_systems/behavior/bot_behavior_extension.lua:246 (NEEDS_AMMO_PERCENTAGE_COMBAT, used while the bot has a target; here: an enemy within sup_proximity_enemy_m)" },
	{ id = "sup_ammo_range_m", value = 5, src = "GAME scripts/extension_systems/group/bot_group.lua:1232 (AMMO_MAX_DISTANCE)" },
	{ id = "sup_ammo_stickiness_m", value = 2.5, src = "GAME scripts/extension_systems/group/bot_group.lua:1234 (AMMO_STICKINESS)" },
	{ id = "sup_health_pickup_range_m", value = 10, src = "GAME scripts/extension_systems/group/bot_group.lua:1235 (HEALTH_DEPLOYABLE_MAX_DISTANCE; trigger = healable damage > 0, bot_behavior_extension.lua:292). Bots never actually take it (allowed_to_take_health_pickup is only ever false, BX:131)" },
	{ id = "sup_grenade_range_sq", value = 400, src = "GAME scripts/extension_systems/group/bot_group.lua:1370 (MULE_PICKUP_MAX_DISTANCE_SQ, the bots' grenade/potion pickup range; mule pickups are inactive in the stock game, so this is an analogue)" },

	-- Chests: bots never open them (bots.md section 9), nothing to copy ----------------------------------
	{ id = "sup_chest_range_m", untuned = true, default = 10, min = 1, max = 60, decimals = 1,
		desc = "Open chests (interaction type chest, GAME interaction_templates.lua:27-35) within this many metres. Bots never open chests, so no source." },
}
