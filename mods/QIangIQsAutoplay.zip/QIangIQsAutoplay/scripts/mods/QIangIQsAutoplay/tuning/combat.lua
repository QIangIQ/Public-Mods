-- combat tuning (see core/tuning.lua for the entry format).

-- Owners: auto_melee (melee_*), auto_shoot (shoot_*), reload_swap (reload_*), abilities (ability_*, grenade_*).
local BT = "GAME scripts/extension_systems/behavior/trees/bot/bot_behavior_tree.lua"
local BC = "GAME scripts/extension_systems/behavior/utilities/conditions/bt_bot_conditions.lua"
local MEL = "GAME scripts/extension_systems/behavior/nodes/actions/bot/bt_bot_melee_action.lua"
local SWITCH = "GAME scripts/extension_systems/behavior/nodes/actions/bot/bt_bot_inventory_switch_action.lua"
local SEL = "GAME scripts/utilities/bot_target_selection.lua"
local SELT = "GAME scripts/extension_systems/perception/target_selection_templates/bot_target_selection_template.lua"
local PER = "GAME scripts/extension_systems/perception/bot_perception_extension.lua"
local TK = "MODS QIangIQsTarkAccount/scripts/mods/QIangIQsTarkAccount/aim_core.lua"

return {
	-- auto_melee: melee-or-ranged choice (bot target score, distance/LOS/stickiness terms only)
	{ id = "melee_dist_weight", value = 3, src = SEL .. ":181 (DEFAULT_MELEE_DISTANCE_WEIGHT)" },
	{ id = "melee_dist_no_weight_m", value = 8, src = SEL .. ":182 (MELEE_DISTANCE_NO_WEIGHT)" },
	{ id = "melee_dist_max_weight_m", value = 3, src = SEL .. ":182 (MELEE_DISTANCE_MAX_WEIGHT)" },
	{ id = "melee_ranged_dist_weight", value = 1, src = SEL .. ":192 (DEFAULT_RANGED_DISTANCE_WEIGHT)" },
	{ id = "melee_ranged_no_weight_m", value = 4, src = SEL .. ":193 (RANGED_DISTANCE_NO_WEIGHT)" },
	{ id = "melee_ranged_max_weight_m", value = 6, src = SEL .. ":193 (RANGED_DISTANCE_MAX_WEIGHT)" },
	{ id = "melee_los_weight", value = 1, src = SEL .. ":203 (DEFAULT_LINE_OF_SIGHT_WEIGHT)" },
	{ id = "melee_current_target_weight", value = 0.2, src = SEL .. ":169 (DEFAULT_CURRENT_TARGET_WEIGHT)" },
	{ id = "melee_eval_s", value = 0.3, src = SELT .. ":89 (target_enemy_reevaluation_t = t + 0.3)" },

	-- auto_melee: reach, aim, push, wield
	{ id = "melee_attack_range_m", value = 2.5, src = MEL .. ":269 (DEFAULT_MAXIMAL_MELEE_RANGE)" },
	{ id = "melee_hitbox_radius_m", value = 0.5, src = MEL .. ":321 (DEFAULT_ENEMY_HITBOX_RADIUS_APPROXIMATION)" },
	{ id = "melee_z_min_m", value = -1.5, src = BC .. ":397 (z_offset > -1.5)" },
	{ id = "melee_z_max_m", value = 2, src = BC .. ":397 (z_offset < 2)" },
	{ id = "melee_proximity_radius_m", value = 5, src = PER .. ":8 (IN_PROXIMITY_DISTANCE)" },
	{ id = "melee_low_stamina", value = 1, src = MEL .. ":471 (low_stamina = current_stamina <= 1)" },
	{ id = "melee_wield_first_s", value = 0.3, src = SWITCH .. ":9 (TIME_TO_FIRST_EVALUATE)" },
	{ id = "melee_wield_interval_s", value = 0.25, src = SWITCH .. ":10 (CONSECUTIVE_EVALUATE_INTERVAL)" },
	{ id = "melee_push_block_s", value = 0.10, src = "MODS QIangIQsAntiSpecialist/scripts/mods/QIangIQsAntiSpecialist/core.lua:759 (BLOCK_TIME, from AntiBursterPush)" },
	{ id = "melee_push_press_s", value = 0.15, src = "MODS QIangIQsAntiSpecialist/scripts/mods/QIangIQsAntiSpecialist/core.lua:760 (PUSH_TIME, from AntiBursterPush)" },
	{ id = "melee_light_window_s", value = 0.2, src = "GAME scripts/settings/equipment/weapon_templates/default_melee_action_input_setup.lua:35 (light_attack time_window)" },

	-- auto_melee: no source (client proxies / implementation choices)
	{ id = "melee_hold_steps", untuned = true, default = 2, min = 1, max = 8, decimals = 0,
		desc = "Light attack: action_one_hold stays down this many fixed steps (the hold is capped at the 0.2 s light-attack window; 0.25 s would be a heavy attack)." },
	{ id = "melee_release_steps", untuned = true, default = 2, min = 1, max = 8, decimals = 0,
		desc = "Light attack: action_one_hold is held false this many fixed steps between swings." },
	{ id = "melee_block_range_m", untuned = true, default = 2.5, min = 0.5, max = 8, decimals = 1,
		desc = "Client stand-in for the server-only num_melee_attackers(): an enemy that targets you and is closer than this counts as an attacker. Hold block while any does." },
	{ id = "melee_block_retreat_tolerance_mps", untuned = true, default = 0.5, min = 0, max = 5, decimals = 1,
		desc = "An attacker counts unless it moves away from you faster than this (closing speed above minus this value)." },
	{ id = "melee_block_hold_s", untuned = true, default = 0.3, min = 0, max = 2, decimals = 2,
		desc = "Keep blocking this long after the last attacker was seen (bot attack flag leads the hit by 0.2-0.5 s: bt_melee_attack_action.lua:114-117)." },
	{ id = "melee_push_gap_s", untuned = true, default = 0.6, min = 0, max = 3, decimals = 2,
		desc = "Minimum time between pushes (the bot reads whether the push input is available; a client cannot)." },

	-- auto_shoot: TarkAccount picker
	{ id = "shoot_max_range_m", value = 40, src = TK .. ":565 (max_range default 40.0)" },
	{ id = "shoot_max_angle_deg", value = 30, src = TK .. ":566 (max_angle_deg default 30.0)" },
	{ id = "shoot_angle_weight", value = 10, src = TK .. ":293 (locality = (1 - angle/max_angle) * 10.0 + ...)" },
	{ id = "shoot_min_dist_m", value = 0.1, src = TK .. ":437 (distance > 0.1)" },
	{ id = "shoot_skip_horde", value = 1, src = "MODS QIangIQsTarkAccount/scripts/mods/QIangIQsTarkAccount/QIangIQsTarkAccount_data.lua:186-188 (skip_horde default_value true; 1 = on)" },
	{ id = "shoot_shield_arc_cos", value = 0.82, src = TK .. ":379 (BULWARK_ARC_COS)" },

	-- auto_shoot: bot fire rule
	{ id = "shoot_retarget_s", value = 0.3, src = SELT .. ":89 (target re-evaluation every 0.3 s)" },
	{ id = "shoot_aim_time_s", value = 0.2, src = "GAME scripts/extension_systems/behavior/nodes/actions/bot/bt_bot_shoot_action.lua:21 (AIM_TIME)" },
	{ id = "shoot_ammo_pct", value = 0.5, src = BT .. ":134 (ammo_percentage = 0.5, normal combat)" },
	{ id = "shoot_ammo_pct_priority", value = 0, src = BT .. ":96 (ammo_percentage = 0, priority target)" },
	{ id = "shoot_overheat_limit", value = 0.9, src = BT .. ":97 and :135 (overheat_limit = 0.9)" },
	{ id = "shoot_wield_first_s", value = 0.3, src = SWITCH .. ":9 (TIME_TO_FIRST_EVALUATE)" },
	{ id = "shoot_wield_interval_s", value = 0.25, src = SWITCH .. ":10 (CONSECUTIVE_EVALUATE_INTERVAL)" },
	{ id = "shoot_press_interval_s", untuned = true, default = 0.1, min = 0.02, max = 1, decimals = 2,
		desc = "While firing, action_one_pressed is pulsed this often so semi-auto weapons keep shooting (action_one_hold stays down)." },

	{ id = "shoot_warp_limit", untuned = true, default = 0.8, min = 0.2, max = 1, decimals = 2,
		desc = "Stop firing once warp charge (peril) is at or above this fraction. Force staffs and warp weapons have no ammo or overheat value, so the bot limits do not stop them. For reference the default archetype template has critical_threshold 0.8 (GAME archetype_warp_charge_templates.lua:11), the psyker one 0.97 (:38)." },

	-- reload_swap
	{ id = "reload_vent_start_min", value = 0.5, src = BT .. ":161 (start_min_percentage)" },
	{ id = "reload_vent_start_max", value = 0.99, src = BT .. ":160 (start_max_percentage)" },
	{ id = "reload_vent_stop", value = 0.1, src = BT .. ":162 (stop_percentage)" },
	{ id = "reload_press_interval_s", untuned = true, default = 0.3, min = 0.05, max = 2, decimals = 2,
		desc = "Minimum time between weapon_reload presses while the clip is empty (the bot re-queues the input when consumed)." },

	-- abilities: copied
	{ id = "ability_veteran_radius_m", value = 9, src = "GAME scripts/settings/talent/talent_settings_veteran.lua:199 (veteran_3.combat_ability.radius)" },
	{ id = "ability_proximity_radius_m", value = 5, src = PER .. ":8 (IN_PROXIMITY_DISTANCE)" },
	{ id = "ability_proximity_max", value = 10, src = PER .. ":10 (MAX_PROXIMITY_ENEMIES)" },
	{ id = "ability_relic_max_distance_m", value = 10, src = BC .. ":8 (max_distance_sq = 100)" },
	{ id = "ability_relic_challenge_threshold", value = 1.75, src = BC .. ":9 (challenge_threshold)" },
	{ id = "ability_relic_targeting_multiplier", value = 1.25, src = BC .. ":10 (targeting_multiplier)" },

	-- abilities: no source
	{ id = "ability_eval_s", untuned = true, default = 0.3, min = 0.05, max = 3, decimals = 2,
		desc = "How often the ability and grenade triggers are evaluated." },
	{ id = "ability_retry_s", untuned = true, default = 1, min = 0.2, max = 10, decimals = 1,
		desc = "Pause after any ability or grenade press before the next one may start." },
	{ id = "ability_aim_wait_s", untuned = true, default = 0.5, min = 0.1, max = 3, decimals = 2,
		desc = "Aimed abilities and grenades: how long to wait for the aim layer before pressing anyway." },
	{ id = "ability_relic_wait_s", untuned = true, default = 1.5, min = 0.3, max = 5, decimals = 1,
		desc = "Zealot relic: how long to wait for the relic to be wielded before the second (channel) press is dropped." },
	{ id = "ability_restore_wait_s", untuned = true, default = 1.5, min = 0.3, max = 5, decimals = 1,
		desc = "After an aborted grenade or relic sequence: how long to keep pressing the wield key of the weapon that was out before." },
	{ id = "ability_other_enabled", untuned = true, default = 1, min = 0, max = 1, decimals = 0,
		desc = "1 = also use combat abilities other than the veteran stance and zealot relic (the game bots never do). 0 = bot-faithful." },
	{ id = "ability_other_radius_m", untuned = true, default = 6, min = 2, max = 20, decimals = 1,
		desc = "Other combat abilities: enemies inside this radius are counted." },
	{ id = "ability_other_min_enemies", untuned = true, default = 3, min = 1, max = 20, decimals = 0,
		desc = "Other combat abilities: use when at least this many enemies are inside the radius." },
	{ id = "ability_other_toughness_frac", untuned = true, default = 0.3, min = 0, max = 1, decimals = 2,
		desc = "Other combat abilities: also use with one enemy in the radius once your toughness fraction is at or below this." },
	{ id = "grenade_enabled", untuned = true, default = 1, min = 0, max = 1, decimals = 0,
		desc = "1 = throw grenades by the cluster rule below (the game bots never throw grenades). 0 = never." },
	{ id = "grenade_min_range_m", untuned = true, default = 6, min = 2, max = 30, decimals = 1,
		desc = "Grenade: nearest allowed distance to the cluster centre." },
	{ id = "grenade_max_range_m", untuned = true, default = 20, min = 5, max = 60, decimals = 1,
		desc = "Grenade: farthest allowed distance to the cluster centre." },
	{ id = "grenade_cluster_radius_m", untuned = true, default = 4, min = 1, max = 12, decimals = 1,
		desc = "Grenade: enemies within this radius of the cluster centre are counted." },
	{ id = "grenade_min_enemies", untuned = true, default = 3, min = 1, max = 30, decimals = 0,
		desc = "Grenade: throw when at least this many enemies are in the cluster and the centre is in line of sight." },
	{ id = "grenade_hold_s", untuned = true, default = 0.3, min = 0.05, max = 2, decimals = 2,
		desc = "Grenade: how long action_one is held (aim) before it is released (throw)." },
	{ id = "grenade_aim_lift_m", untuned = true, default = 1, min = 0, max = 6, decimals = 1,
		desc = "Grenade: the aim point is lifted this many metres above the cluster centre (the throw arcs; the real arc is not modelled)." },
	{ id = "grenade_timeout_s", untuned = true, default = 4, min = 1, max = 10, decimals = 1,
		desc = "Grenade: the whole wield, aim and throw sequence is abandoned after this long." },
}
