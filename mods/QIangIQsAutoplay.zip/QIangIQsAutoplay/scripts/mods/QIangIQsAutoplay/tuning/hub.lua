-- Hub-side tuning (ready, vote, end screen, mission start).
return {
	{ id = "end_skip_s", value = 0.2, src = "MODS BornReady/scripts/mods/BornReady/BornReady_data.lua:58 (end_skip_time default)" },
	{ id = "start_retry_s", untuned = true, default = 10, min = 2, max = 120, decimals = 0,
		desc = "Seconds before start_mission may send another queue request after one did not lead to a lobby." },
}
