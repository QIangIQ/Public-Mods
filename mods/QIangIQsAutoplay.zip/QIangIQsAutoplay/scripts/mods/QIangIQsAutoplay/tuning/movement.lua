-- movement tuning: auto_path, auto_dodge, trapper_dodge, dog_push, burster_push, mutant_dodge, lib_dodge.

-- AS = QIangIQsAntiSpecialist/scripts/mods/QIangIQsAntiSpecialist ; core ids (move_to_flat_eps etc.) live in tuning/core.lua.
local AS = "MODS QIangIQsAntiSpecialist "
return {
	-- Dodge geometry and timing (lib_dodge) ---------------------------------------------------
	{ id = "dodge_player_radius_m", value = 0.7, src = AS .. "core.lua:251 (Core.PLAYER_RADIUS; GAME player_unit_locomotion_extension.lua 252)" },
	{ id = "dodge_default_distance_m", value = 2.5, src = "GAME scripts/settings/dodge/archetype_dodge_templates.lua:4 (default_distance); AS core.lua:270 fallback" },
	{ id = "dodge_distance_scale", value = 1.1, src = AS .. "core.lua:272 (largest weapon distance scale, weapon_dodge_templates default)" },
	{ id = "dodge_time_s", value = 0.4, src = "GAME scripts/settings/dodge/archetype_dodge_templates.lua:5 (default_time)" },
	{ id = "dodge_cooldown_s", value = 0.2, src = AS .. "core.lua:753 (PRESS_WINDOW = 0.2 + 2 steps; GAME weapon_dodge_templates.lua:156 dodge_cooldown)" },
	{ id = "dodge_pre_move_steps", value = 1, src = AS .. "core.lua:752 (PRE_MOVE = 1 fixed step)" },
	{ id = "dodge_hold_after_steps", value = 1, src = AS .. "core.lua:754 (HOLD_AFTER_START = 1 fixed step)" },
	{ id = "dodge_min_lateral", value = 0.707, src = AS .. "core.lua:686 (c45; GAME dodge.lua 70-90 sideways limit |x| > 0.707)" },
	{ id = "dodge_lateral_slack", value = 0.001, src = AS .. "core.lua:694 (min_score = c45 - 1e-3)" },
	{ id = "dodge_on_top_m", value = 0.01, src = AS .. "core.lua:676 (threat closer than 0.01 m: no direction)" },
	{ id = "dodge_wall_extra_m", value = 0.65, src = AS .. "core.lua:563 (WALL_CLEAR = radius + 0.65, hound dodge_collision_radius)" },
	{ id = "dodge_max_drop_m", value = 4, src = AS .. "core.lua:25 (max_drop default 4; QIangIQsAntiSpecialist_data.lua:42)" },
	{ id = "dodge_priority_trapper", value = 30, src = AS .. "trapper.lua:17 (PRIORITY, design choice)" },
	{ id = "dodge_priority_burster", value = 25, src = AS .. "burster.lua:15 (PRIORITY, design choice)" },
	{ id = "dodge_priority_hound", value = 40, src = AS .. "hound.lua:23 (PRIORITY, design choice)" },
	{ id = "dodge_priority_mutant", value = 35, src = AS .. "mutant.lua:15 (PRIORITY, design choice)" },
	{ id = "dodge_priority_generic", untuned = true, default = 20, min = 0, max = 100, decimals = 0,
		desc = "Order of the generic auto-dodge among the defence modules (AS counters use 25 to 40; higher wins the shared defence claim)." },

	-- Push routine (lib_dodge) ----------------------------------------------------------------
	{ id = "push_block_s", value = 0.10, src = AS .. "core.lua:759 (BLOCK_TIME)" },
	{ id = "push_press_s", value = 0.15, src = AS .. "core.lua:760 (PUSH_TIME)" },
	{ id = "push_interrupt_s", value = 0.12, src = AS .. "core.lua:758 (INTERRUPT_TIME)" },
	{ id = "push_swap_timeout_s", value = 1.5, src = AS .. "core.lua:757 (SWAP_TIMEOUT)" },
	{ id = "push_restore_timeout_s", value = 1.5, src = AS .. "core.lua:761 (RESTORE_TIMEOUT)" },
	{ id = "push_wait_timeout_s", value = 10, src = AS .. "burster.lua:71 (wait_timeout, WAIT_TIMEOUT 10 s of AntiBursterPush)" },
	{ id = "push_radius_default_m", value = 2.5, src = AS .. "core.lua:295 (fallback push radius, combatsword_p1_m1.lua 1126)" },
	{ id = "push_face_min_m", value = 0.05, src = AS .. "core.lua:831 (no turn when the threat is closer than 0.05 m)" },

	-- Trapper (trapper_dodge) -----------------------------------------------------------------
	{ id = "trap_aim_duration_s", value = 0.8333333333333334, src = AS .. "trapper.lua:14 (AIM_DURATION)" },
	{ id = "trap_net_max_distance_m", value = 14, src = AS .. "trapper.lua:16 (MAX_NET_DISTANCE)" },

	-- Hound (dog_push) ------------------------------------------------------------------------
	{ id = "hound_leap_range_m", value = 16, src = AS .. "hound.lua:24 (LEAP_RANGE)" },
	{ id = "hound_leap_speed_ms", value = 21, src = AS .. "hound.lua:25 (LEAP_SPEED; GAME specials/chaos_hound_settings.lua:12 leap_speed)" },
	{ id = "hound_trigger_speed_ms", value = 12, src = AS .. "hound.lua:51 (hound_leap_speed default; _data.lua:64)" },
	{ id = "hound_push_distance_m", value = 5, src = AS .. "hound.lua:53 (hound_push_distance default; _data.lua:66)" },
	{ id = "hound_cooldown_s", value = 4, src = AS .. "hound.lua:100 and :265 (pounce cooldown at least 4 s)" },
	{ id = "hound_windup_long_s", value = 0.6666666666666666, src = AS .. "hound.lua:22 (attack_leap_start; GAME chaos_hound_actions.lua:43 start_duration)" },
	{ id = "hound_windup_short_s", value = 0.8, src = AS .. "hound.lua:22 (attack_leap_short; GAME chaos_hound_actions.lua:44 start_duration_short)" },
	{ id = "hound_arrival_s", value = 0.2, src = AS .. "hound.lua:134 and :289 (arrival in the middle of the 0.4 s dodge)" },
	{ id = "hound_margin_m", value = 1, src = AS .. "hound.lua:111 and :124 (LEAP_RANGE + 1, push_radius + 1)" },
	{ id = "hound_vote_extra_s", untuned = true, default = 0.1, min = 0, max = 0.3, decimals = 2,
		desc = "Slack added to the short wind-up when matching an anim number to a leap (AS marks 100 ms untuned, _data.lua:74)." },
	{ id = "hound_votes_needed", untuned = true, default = 3, min = 2, max = 8, decimals = 0,
		desc = "Leaps that must agree before an anim number is taken as the wind-up (AS marks 3 untuned, _data.lua:75)." },
	{ id = "hound_vote_margin", untuned = true, default = 2, min = 1, max = 5, decimals = 0,
		desc = "The winning anim number needs this many times the votes of the runner-up (AS uses 2 without a source, hound.lua:238)." },

	-- Poxburster (burster_push) ---------------------------------------------------------------
	{ id = "burst_detect_m", value = 8, src = AS .. "burster.lua:26 (detect_range default 8 m, AntiBursterPush)" },
	{ id = "burst_scan_s", value = 0.10, src = AS .. "burster.lua:43 (SCAN_INTERVAL)" },
	{ id = "burst_repush_s", value = 2.0, src = AS .. "burster.lua:16 (REPUSH)" },
	{ id = "burst_push_floor_s", value = 0.8, src = AS .. "burster.lua:17 (PUSH_FLOOR)" },
	{ id = "burst_blast_m", value = 6, src = AS .. "burster.lua:63 (blast radius 6 m, minion_explosion_templates.lua 88-96)" },

	-- Mutant (mutant_dodge) -------------------------------------------------------------------
	{ id = "mutant_range_m", value = 20, src = AS .. "mutant.lua:16 (RANGE)" },
	{ id = "mutant_run_speed_ms", value = 6, src = AS .. "mutant.lua:17 (RUN_SPEED, cultist_mutant_breed.lua 49)" },
	{ id = "mutant_dodge_m", value = 5, src = AS .. "mutant.lua:24 (mutant_dodge_distance default; _data.lua:71)" },
	{ id = "mutant_rearm_s", value = 2.1, src = AS .. "mutant.lua:47 (charge_grab_miss lasts 2.1 s)" },

	-- Generic dodge (auto_dodge) --------------------------------------------------------------
	{ id = "adodge_melee_reach_m", value = 3.5, src = "GAME scripts/settings/breed/breed_actions/cultist/cultist_melee_actions.lua:529 (melee_attack weapon_reach; other breeds 3 to 5.25, per-breed reach UNVERIFIED)" },
	{ id = "adodge_rearm_s", value = 2, src = "GAME scripts/extension_systems/behavior/nodes/actions/bot/bt_bot_melee_action.lua:498-499 (DODGE_CHECK_RANDOM_RANGE {0.5, 2}, upper bound used)" },
	{ id = "adodge_fail_cooldown_s", value = 0.1, src = "GAME scripts/extension_systems/behavior/nodes/actions/bot/bt_bot_melee_action.lua:506 (DODGE_CHECK_FAIL_COOLDOWN)" },
	{ id = "adodge_flamer_range_m", value = 20, src = "GAME scripts/settings/specials/cultist_flamer_settings.lua:9 (range)" },
	{ id = "adodge_flamer_rearm_s", value = 2, src = "GAME scripts/settings/breed/breed_actions/cultist/cultist_flamer_actions.lua:262 (shoot aoe_bot_threat_duration)" },

	-- Path following (auto_path) --------------------------------------------------------------
	{ id = "path_ramp_start_s", value = 0.25, src = "GAME scripts/extension_systems/navigation/bot_navigation_extension.lua:217 (TIME_UNTIL_RAMP_THRESHOLD)" },
	{ id = "path_flat_max_m", value = 0.2, src = "GAME scripts/extension_systems/navigation/bot_navigation_extension.lua:218 (MAX_FLAT_THRESHOLD)" },
	{ id = "path_ramp_time_s", value = 0.25, src = "GAME scripts/extension_systems/navigation/bot_navigation_extension.lua:219 (RAMP_TIME)" },
	{ id = "path_z_below_m", value = 0.35, src = "GAME scripts/extension_systems/navigation/bot_navigation_extension.lua:237 (distance_z > -0.35)" },
	{ id = "path_z_above_m", value = 0.5, src = "GAME scripts/extension_systems/navigation/bot_navigation_extension.lua:237 (distance_z < 0.5)" },
	{ id = "path_scale_dist_sq", value = 0.010000000000000002, src = "GAME scripts/extension_systems/input/bot_unit_input.lua:139 (MOVE_SCALE_START_DIST_SQ)" },
	{ id = "path_scale_factor", value = 99.995, src = "GAME scripts/extension_systems/input/bot_unit_input.lua:140 (MOVE_SCALE_FACTOR)" },
	{ id = "path_scale_min", value = 5e-05, src = "GAME scripts/extension_systems/input/bot_unit_input.lua:141 (MOVE_SCALE_MIN)" },
	{ id = "path_stall_speed_ms", value = 0.2, src = "GAME scripts/extension_systems/input/bot_unit_input.lua:142 (STUCK_JUMP_SPEED_THRESHOLD)" },
	{ id = "path_stall_window_s", untuned = true, default = 1.5, min = 0.5, max = 10, decimals = 1,
		desc = "Seconds the character may move slower than the stall speed before the path is rebuilt. No source for the duration." },
	{ id = "path_max_repaths", untuned = true, default = 3, min = 0, max = 20, decimals = 0,
		desc = "Re-paths allowed per goal after stalls before the goal is reported failed. No source." },
	{ id = "path_request_timeout_s", untuned = true, default = 3, min = 0.5, max = 30, decimals = 1,
		desc = "Seconds a client A* request may stay pending before it counts as failed (a client A* may never finish). No source." },
}
