-- Core tuning. Paths: GAME = aussiemon_src (Darktide 1.13.4); MODS = mods\ folder.
return {
	-- Aim layer (copied from QIangIQsTarkAccount aim_snap.lua)
	{ id = "aim_speed_deg_per_sec", value = 600, src = "MODS QIangIQsTarkAccount_data.lua:112-113 (lock_speed_deg_per_sec default)" },
	{ id = "aim_pitch_limit_pi_frac", value = 0.45, src = "MODS QIangIQsTarkAccount aim_snap.lua:83-84 (= PlayerOrientationSettings.default)" },
	{ id = "los_backoff_m", value = 0.15, src = "MODS QIangIQsTarkAccount aim_snap.lua:36 (LOS_BACKOFF)" },
	{ id = "los_min_dist_m", value = 0.05, src = "MODS QIangIQsTarkAccount aim_snap.lua:247 (has_los: dist < 0.05 -> visible)" },
	{ id = "aim_on_target_deg", untuned = true, default = 2, min = 0.1, max = 20, decimals = 1,
		desc = "Angle error under which an aim request counts as 'on target' (fire allowed)." },

	-- Logging (copied from QIangIQsEnemyBeams)
	{ id = "log_max_bytes", value = 524288, src = "MODS QIangIQsEnemyBeams.lua:25 (LOG_MAX_BYTES = 512 * 1024)" },
	{ id = "ring_size", untuned = true, default = 400, min = 50, max = 5000,
		desc = "Lines kept in the in-memory ring buffer for /autoplay_dump." },

	-- Presence sync (copied from Vox Manifold / QIangIQsSyncChannel)
	{ id = "presence_min_interval_s", value = 2.0, src = "MODS Vox Manifold.lua:16 (MIN_INTERVAL)" },
	{ id = "presence_max_bytes", value = 250, src = "MODS Vox Manifold.lua:18 (MAX_VALUE_BYTES)" },
	{ id = "presence_poll_s", value = 0.5, src = "MODS QIangIQsSyncChannel.lua:34 (peer poll)" },
	{ id = "presence_repush_s", untuned = true, default = 30, min = 2, max = 600, desc = "Re-publish the handshake this often even when nothing changed (a push can be lost)." },
	{ id = "peer_stale_s", untuned = true, default = 20, min = 4, max = 120,
		desc = "A peer whose presence value has not been readable for this long counts as gone." },

	-- Interaction (GAME)
	{ id = "interact_detection_radius", value = 1.3, src = "GAME scripts/settings/interaction/interaction_settings.lua:9" },
	{ id = "interact_sphere_offset", value = 1.2, src = "GAME scripts/settings/interaction/interaction_settings.lua:10" },
	{ id = "interact_retry_s", value = 3, src = "GAME bt_bot_interact_action.lua:7 (try_again_time)" },

	-- Timing (GAME, as used by QIangIQsAntiSpecialist core.lua:717-734)
	{ id = "tick_rate_default", value = 52, src = "GAME scripts/foundation/utilities/parameters/default_game_parameters.lua:17" },
	{ id = "input_buffer_frames", value = 2, src = "GAME adaptive_clock_handler_server.lua:4 (BUFFER_MIN)" },

	-- Test travel (GAME training_grounds_options_view.lua)
	{ id = "psykhanium_danger", value = 1, src = "GAME training_grounds_options_view.lua:130 (danger level fallback when no stepper: or 1)" },

	-- Navigation (GAME)
	{ id = "nav_check_above", value = 0.75, src = "GAME payload_extension.lua:18 (NAV_MESH_CHECK_ABOVE)" },
	{ id = "nav_check_below", value = 0.5, src = "GAME payload_extension.lua:19 (NAV_MESH_CHECK_BELOW)" },
	{ id = "nav_default_above", value = 30, src = "GAME scripts/utilities/nav_queries.lua:5 (DEFAULT_NAV_ABOVE)" },
	{ id = "nav_default_below", value = 30, src = "GAME scripts/utilities/nav_queries.lua:5 (DEFAULT_NAV_BELOW)" },
	{ id = "move_to_flat_eps", value = 0.05, src = "GAME scripts/settings/bot/bot_settings.lua:4 (flat_move_to_epsilon)" },
	{ id = "move_to_z_eps", value = 0.3, src = "GAME scripts/settings/bot/bot_settings.lua:6 (z_move_to_epsilon)" },

	-- Enemy tracker
	{ id = "tracker_pending_frames", untuned = true, default = 30, min = 1, max = 600,
		desc = "Frames to wait for a newly spawned husk's breed before giving up (0.1.0 used 30, uncited)." },

	-- Teleport confirmation
	{ id = "teleport_jump_m", untuned = true, default = 10, min = 1, max = 200, decimals = 1,
		desc = "Position jump in one frame that confirms the orientation RPC was a teleport." },
	{ id = "teleport_confirm_s", untuned = true, default = 2, min = 0.1, max = 10, decimals = 1,
		desc = "Max time between the orientation RPC and the position jump for them to count as one teleport." },
	{ id = "panel_field_chars", untuned = true, default = 40, min = 8, max = 200, desc = "Panel: max characters per field." },
	{ id = "panel_layer", untuned = true, default = 899, min = 1, max = 2000, desc = "Panel draw layer (0.1.0 used 899/900)." },

	-- Panel layout (no source: UI only)
	{ id = "panel_x", untuned = true, default = 24, min = 0, max = 3000, desc = "Panel left edge, pixels." },
	{ id = "panel_y", untuned = true, default = 260, min = 0, max = 2000, desc = "Panel top edge, pixels." },
	{ id = "panel_font", untuned = true, default = 14, min = 8, max = 40, desc = "Panel font size." },
	{ id = "panel_line_h", untuned = true, default = 18, min = 8, max = 60, desc = "Panel line height, pixels." },
	{ id = "panel_width", untuned = true, default = 760, min = 200, max = 3000, desc = "Panel width, pixels." },
}
