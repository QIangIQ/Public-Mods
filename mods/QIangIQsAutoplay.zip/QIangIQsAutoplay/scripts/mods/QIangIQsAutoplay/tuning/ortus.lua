-- Ortus (Karnak twins, km_enforcer_twins) gold loop tuning.

return {
	{ id = "bell_right_pos", value = { 225.127, -161.508, 5.386 }, src = "DM section 6: Bell R nurgle_bell_02 instance 2426e935dc272efd (RIGHT inferred from geometry)" },
	{ id = "bell_left_pos", value = { 223.764, -164.087, 5.385 }, src = "DM section 6: Bell L nurgle_bell_02 instance ba6acfa7f993e710" },
	{ id = "elevator_pos", value = { -210.029, -27.54, 21.995 }, src = "DM section 3: civilian_elevator_6x6m_01_001 (sub-level enforcer_elevator)" },
	{ id = "elevator_moved_m", value = 0.3, src = "GAME scripts/settings/bot/bot_settings.lua:6 (z_move_to_epsilon) reused as 'elevator moved' threshold" },

	-- Step timeouts (no source: how long each step may take is not in any file)
	{ id = "ortus_timeout_hub_s", untuned = true, default = 300, min = 10, max = 3600, desc = "HUB_WAIT: max wait for party, peers and mission id." },
	{ id = "ortus_timeout_start_s", untuned = true, default = 90, min = 10, max = 600, desc = "START: max wait from queue request to the lobby/mission." },
	{ id = "ortus_timeout_lobby_s", untuned = true, default = 240, min = 10, max = 1200, desc = "LOBBY: max wait from queue to the twins mission running." },
	{ id = "ortus_timeout_spawn_s", untuned = true, default = 120, min = 5, max = 600, desc = "SPAWN: max wait for a live, controllable player unit." },
	{ id = "ortus_timeout_bell_s", untuned = true, default = 90, min = 5, max = 600, desc = "BELL: max time to find, reach and shoot the right bell." },
	{ id = "ortus_timeout_teleport_s", untuned = true, default = 90, min = 5, max = 600, desc = "TELEPORT: max wait for the server teleport after the bell." },
	{ id = "ortus_timeout_path_s", untuned = true, default = 240, min = 10, max = 1200, desc = "ELEVATOR PATH: max time to reach the elevator." },
	{ id = "ortus_timeout_elevator_s", untuned = true, default = 60, min = 5, max = 600, desc = "ELEVATOR USE: max time to start the elevator." },
	{ id = "ortus_timeout_die_s", untuned = true, default = 900, min = 10, max = 3600, desc = "DIE: max wait for death / mission end before stop (or leave, if enabled)." },
	{ id = "ortus_timeout_end_s", untuned = true, default = 180, min = 10, max = 1200, desc = "END: max wait to get back to the hub." },

	-- Bell shooting (no source)
	{ id = "bell_fire_hold_s", untuned = true, default = 0.15, min = 0.02, max = 2, decimals = 2, desc = "Fire button hold per shot at the bell." },
	{ id = "bell_fire_gap_s", untuned = true, default = 0.35, min = 0.02, max = 3, decimals = 2, desc = "Pause between shots at the bell." },
	{ id = "bell_approach_tol_m", untuned = true, default = 15, min = 2, max = 60, decimals = 1, desc = "No line of sight to the bell: walk (auto_path) until this close, then retry." },
	{ id = "wield_retry_s", untuned = true, default = 1, min = 0.1, max = 5, decimals = 1, desc = "Seconds between wield_2 presses while waiting for the ranged weapon." },
	{ id = "elevator_aim_up_m", untuned = true, default = 1, min = 0, max = 4, decimals = 2, desc = "Aim this far above the elevator unit origin when looking for its interaction focus." },
}
