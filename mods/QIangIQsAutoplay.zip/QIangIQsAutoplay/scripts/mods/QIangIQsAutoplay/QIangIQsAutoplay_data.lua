local mod = get_mod("QIangIQsAutoplay")

-- Keybind widgets follow QIangIQsTarkAccount_data.lua (type "keybind",
-- keybind_type "function_call"). Every module toggle defaults to false.
-- Module titles come from the module files; UNTUNED numeric settings come
-- from the tuning registry (core/tuning.lua).

local BASE = "QIangIQsAutoplay/scripts/mods/QIangIQsAutoplay/"

local LOOP = { "ortus_loop", "start_mission", "auto_ready", "auto_vote", "end_skip", "fast_hub" }
local HAVOC = {
	"auto_path", "auto_dodge", "trapper_dodge", "dog_push", "burster_push", "mutant_dodge",
	"auto_melee", "auto_shoot", "reload_swap", "abilities",
	"medicae", "pickups", "chests", "revive",
}
local TEST = { "hold_forward" }

local function module_widget(name)
	local ok, m = pcall(mod.io_dofile, mod, BASE .. "modules/" .. name)
	local title = (ok and type(m) == "table" and m.title) or ("Module: " .. name)
	local tip = (ok and type(m) == "table" and m.description) or ("module file " .. name .. ".lua did not load")
	return {
		setting_id = "module_" .. name,
		type = "checkbox",
		default_value = false,
		localize = false,
		title = title,
		tooltip = tip,
	}
end

local function group(setting_id, names, extra)
	local subs = {}
	for i = 1, #names do subs[#subs + 1] = module_widget(names[i]) end
	if extra then
		for i = 1, #extra do subs[#subs + 1] = extra[i] end
	end
	return { setting_id = setting_id, type = "group", sub_widgets = subs }
end

local untuned = {}
local okT, T = pcall(mod.io_dofile, mod, BASE .. "core/tuning")
if okT and T then untuned = T.widgets() end

local widgets = {
	{
		setting_id      = "master_toggle_key",
		type            = "keybind",
		default_value   = {},
		keybind_trigger = "pressed",
		keybind_type    = "function_call",
		function_name   = "toggle_master",
	},
	{
		setting_id      = "emergency_stop_key",
		type            = "keybind",
		default_value   = {},
		keybind_trigger = "pressed",
		keybind_type    = "function_call",
		function_name   = "emergency_stop",
	},
	{
		setting_id  = "debug_group",
		type        = "group",
		sub_widgets = {
			{ setting_id = "show_overlay", type = "checkbox", default_value = true },
			{ setting_id = "panel_only_enabled", type = "checkbox", default_value = false },
			{
				setting_id = "log_level",
				type = "dropdown",
				default_value = "info",
				options = {
					localize = false,
					{ text = "error", value = "error" },
					{ text = "warn", value = "warn" },
					{ text = "info", value = "info" },
					{ text = "debug", value = "debug" },
				},
			},
		},
	},
	group("loop_group", LOOP, {
		{ setting_id = "ortus_step_mode", type = "checkbox", default_value = false },
		{ setting_id = "ortus_leave_on_timeout", type = "checkbox", default_value = false },
	}),
	group("havoc_group", HAVOC),
	group("test_group", TEST),
}

if #untuned > 0 then
	widgets[#widgets + 1] = { setting_id = "untuned_group", type = "group", sub_widgets = untuned }
end

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = { widgets = widgets },
}
