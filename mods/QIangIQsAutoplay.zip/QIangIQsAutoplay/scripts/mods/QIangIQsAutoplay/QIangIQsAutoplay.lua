local mod = get_mod("QIangIQsAutoplay")

--[[
    QIangIQs Autoplay 0.2.0 (core)

    Layers (Darktide 1.13.4 source, aussiemon_src):
      INPUT  hook_safe HumanInputHandler._parse_input (human_input_handler.lua:232): overwrite
             the input cache after the original; the same cache is sent to the server
             (rpc_player_input_array, :346) and read for local prediction
             (human_unit_input.lua:21-31). From 0.1.0.
      AIM    hook AimAssist.apply_aim_assist (aim_assist.lua:38, called from
             default_player_orientation.lua:79): return eased yaw/pitch toward the winning
             aim request. Maths copied from QIangIQsTarkAccount aim_snap.lua:377-519.
      EVENTS one hook per game method (DMF keeps one hook per mod and method), fanned out to
             module subscribers with per-module pcall and gating.

    Safety:
      - master toggle is never saved (OFF at every load); emergency stop key; every module OFF by default.
      - every injected input, aim, and hub action checks: master -> module toggle -> gate -> conflicts.
      - a module error is logged and switches that module off for the session (runtime flag,
        the saved setting is untouched).
]]

local VERSION = "0.2.1"
local BASE = "QIangIQsAutoplay/scripts/mods/QIangIQsAutoplay/"

local T = mod:io_dofile(BASE .. "core/tuning")
local Log = mod:io_dofile(BASE .. "core/log")
Log.init(T)
local enemy_tracker = mod:io_dofile(BASE .. "enemy_tracker")
enemy_tracker.init(T)
local Sync = mod:io_dofile(BASE .. "core/sync")
Sync.init(T, Log)
local Gate = mod:io_dofile(BASE .. "core/gate")
Gate.init(Sync)
local Api = mod:io_dofile(BASE .. "core/api")
Api.init(T, Log, enemy_tracker, Gate)

mod.T, mod.Log, mod.Sync, mod.Gate, mod.api, mod.enemy_tracker = T, Log, Sync, Gate, Api, enemy_tracker
mod.VERSION = VERSION

for i = 1, #T.errors do
	Log.write("core", "error", "tuning: %s", T.errors[i])
end

-- Module list, highest priority first. Per input field the first writer wins.
local MODULE_ORDER = {
	-- defence
	"trapper_dodge", "mutant_dodge", "dog_push", "burster_push", "auto_dodge",
	-- team support that must not be interrupted by attacks
	"revive",
	-- Ortus gold loop (bell aim/fire, elevator interaction)
	"ortus_loop",
	-- combat
	"auto_melee", "auto_shoot", "reload_swap", "abilities",
	-- support
	"medicae", "pickups", "chests",
	-- movement executor (consumes shared.nav_goal)
	"auto_path",
	-- hub side
	"auto_ready", "auto_vote", "start_mission", "end_skip", "fast_hub",
	-- test
	"hold_forward",
}
mod.MODULE_ORDER = MODULE_ORDER

local modules = {}
local by_name = {}
mod.modules, mod.modules_by_name = modules, by_name

local HUB_GAME_MODES = { hub = true, prologue_hub = true } -- hub game mode names (MODS SoloPlay.lua:333)

-- REQUEST FIELDS -> game input actions (GAME input_handler_settings.lua:6-50)
local HELD = {
	action_one_hold = "action_one_hold", action_two_hold = "action_two_hold",
	weapon_reload_hold = "weapon_reload_hold", interact_hold = "interact_hold",
	combat_ability_hold = "combat_ability_hold", grenade_ability_hold = "grenade_ability_hold",
	jump_held = "jump_held", sprinting = "sprinting", crouching = "crouching",
	weapon_extra_hold = "weapon_extra_hold",
}
local PRESSED = {
	jump = "jump", dodge = "dodge",
	action_one_pressed = "action_one_pressed", action_one_release = "action_one_release",
	action_two_pressed = "action_two_pressed", action_two_release = "action_two_release",
	weapon_reload = "weapon_reload_pressed", interact = "interact_pressed",
	combat_ability = "combat_ability_pressed", combat_ability_release = "combat_ability_release",
	grenade_ability = "grenade_ability_pressed", grenade_ability_release = "grenade_ability_release",
	wield_1 = "wield_1", wield_2 = "wield_2", wield_3 = "wield_3", wield_4 = "wield_4", wield_5 = "wield_5",
	quick_wield = "quick_wield",
}
mod.REQUEST_HELD, mod.REQUEST_PRESSED = HELD, PRESSED

-- State ---------------------------------------------------------------

local state = {
	master = false,        -- never persisted: OFF at every load
	merged = { move = nil, held = {}, pressed = {}, aim = nil, aim_owner = nil },
	latched = {},
	in_gameplay = false,
	where = "none",        -- "mission" | "hub" | "none"
	injected_frames = 0,
	aim_error = math.huge,
	aim_owner = nil,
	aim_block = nil,       -- reason the aim layer refuses (conflict), or nil
	last_pos = nil,        -- boxed position, previous frame
	jump_t = nil,          -- main time of the last big position jump
	rpc_t = nil,           -- main time of the last orientation RPC
	selftest = { ran = false, ok = 0, fail = 0, lines = {} },
	t = 0,
}
mod.state = state

local function clear_requests()
	state.merged.move = nil
	state.merged.held = {}
	state.merged.pressed = {}
	state.merged.aim = nil
	state.merged.aim_owner = nil
	state.latched = {}
	for i = 1, #modules do modules[i].req = {} end
end

-- Module loading ------------------------------------------------------

local function module_enabled(m)
	return mod:get(m.setting) and true or false
end

local function conflict_of(m)
	if not m.conflicts then return nil end
	for i = 1, #m.conflicts do
		local c = m.conflicts[i]
		if Api.other_mod_active(c.mod, c.setting) then
			return ("%s %s is on%s"):format(c.mod, tostring(c.setting or ""), c.why and (": " .. c.why) or "")
		end
	end
	return nil
end

local function disable_module(m, err)
	m.runtime_off = tostring(err)
	m.req = {}
	m.st.state, m.st.decision, m.st.reason = "ERROR", "switched off", tostring(err)
	Log.write(m.name, "error", "module error, switched off for this session: %s", tostring(err))
	if m.reset then pcall(m.reset, Api, m.st) end
end

for i = 1, #MODULE_ORDER do
	local name = MODULE_ORDER[i]
	local ok, m = pcall(mod.io_dofile, mod, BASE .. "modules/" .. name)
	if ok and type(m) == "table" and m.update then
		m.name = m.name or name
		m.where = m.where or "mission"
		m.req = {}
		m.st = { name = m.name, state = "idle", target = "-", decision = "-", reason = "-" }
		modules[#modules + 1] = m
		by_name[m.name] = m
		if m.init then
			Api._current = m
			local oki, err = pcall(m.init, Api, m.st)
			Api._current = nil
			if not oki then disable_module(m, "init: " .. tostring(err)) end
		end
	else
		Log.write("core", "warn", "module %s not loaded: %s", name, tostring(m))
	end
end

-- Event dispatch ------------------------------------------------------

local LIFECYCLE = { gameplay_enter = true, gameplay_exit = true, emergency_stop = true, master = true, mission_ready = true }
-- Hub events need more than the party gate (hard gate: never act in a public queue/lobby/end screen):
--   lobby/vote: only while a PRIVATE queue sent by start_mission (or followed by the Ortus loop) is in flight
--   end screen: only if the last mission frame passed the mission gate (sticky)
local QUEUE_EVENTS = { lobby_enter = true, vote_started = true }
local END_EVENTS = { end_view_enter = true, end_view_update = true }
local HUB_EVENTS = { lobby_enter = true, vote_started = true, end_view_enter = true, end_view_update = true }

-- Can module m act right now (for an event of kind `kind`: "mission" or "hub")?
local function may_act(m, kind)
	if not state.master then return false, "master off" end
	if not module_enabled(m) then return false, "module off" end
	if m.runtime_off then return false, "error: " .. m.runtime_off end
	local c = conflict_of(m)
	if c then return false, "conflict: " .. c end
	if kind == "hub" then
		local ok, why = Gate.party()
		if not ok then return false, "party gate: " .. why end
		return true
	end
	if not Gate.last.ok then return false, "gate: " .. Gate.last.reason end
	return true
end
mod.may_act = may_act
-- For async callbacks (promises) in modules: re-check before acting.
Api.may_act = function(name, kind)
	local m = by_name[name]
	if not m then return false, "unknown module" end
	return may_act(m, kind or "mission")
end

local function fire(event, ...)
	local list = Api.events[event]
	if not list then return end
	local kind = HUB_EVENTS[event] and "hub" or "mission"
	for i = 1, #list do
		local sub = list[i]
		local m = sub.owner
		local allowed = true
		if m and not LIFECYCLE[event] then
			allowed = may_act(m, kind)
			if allowed and QUEUE_EVENTS[event] and not Api.shared.private_queue then
				allowed = false
				Log.write(m.name, "info", "%s ignored: no private queue in flight", event)
			end
			if allowed and END_EVENTS[event] and not state.last_mission_gate_ok then
				allowed = false
				if event == "end_view_enter" then Log.write(m.name, "info", "end screen ignored: last mission did not pass the gate") end
			end
		end
		if allowed and not (m and m.runtime_off) then
			local ok, err = pcall(sub.fn, ...)
			if not ok then
				if m then disable_module(m, ("event %s: %s"):format(event, tostring(err)))
				else Log.write("core", "error", "event %s: %s", event, tostring(err)) end
			end
		end
	end
end
mod.fire = fire

-- Master / emergency --------------------------------------------------

local function reset_all(reason)
	clear_requests()
	for i = 1, #modules do
		local m = modules[i]
		if m.reset then
			local ok, err = pcall(m.reset, Api, m.st)
			if not ok then Log.write(m.name, "error", "reset failed: %s", tostring(err)) end
		end
	end
	Api.shared.nav_goal = nil
	Api.shared.nav_status = nil
	Api.shared.defending_until = nil
	Api.shared.interact_owner = nil
	Api.shared.interact_scan = nil
	Api.shared.start_request = nil
	Api.shared.private_queue = nil
	Log.write("core", "info", "reset: %s", reason)
end

mod.toggle_master = function()
	state.master = not state.master
	if not state.master then reset_all("master off") end
	Sync.set("m", state.master and 1 or 0)
	fire("master", state.master)
	Log.write("core", "info", "master %s", state.master and "ON" or "off")
	mod:echo(("[Autoplay] master %s"):format(state.master and "ON" or "off"))
end

mod.emergency_stop = function()
	state.master = false
	Sync.set("m", 0)
	fire("emergency_stop")
	reset_all("EMERGENCY STOP")
	mod:echo("[Autoplay] EMERGENCY STOP: master off, all module input dropped, Ortus loop reset")
end

-- Context -------------------------------------------------------------

local function build_ctx(dt, t)
	local player = Api.local_player()
	local unit = player and player.player_unit
	if unit and not Api.alive(unit) then unit = nil end
	local yaw, pitch = Api.orientation()
	local ctx = {
		dt = dt, t = t, gt = Api.time(),
		player = player, unit = unit,
		yaw = yaw, pitch = pitch,
		gate_kind = Gate.last.kind,
		aim_owner = state.aim_owner, aim_error = state.aim_error,
		shared = Api.shared, where = state.where,
		game_mode = Gate.game_mode_name(), mission = Gate.mission_name(),
	}
	if unit then
		ctx.pos = Api.position(unit)
		ctx.eye = Api.eye_position(unit) or ctx.pos
		ctx.can_act, ctx.state = Api.can_act(unit)
		ctx.wielded = Api.wielded(unit)
	end
	return ctx
end

-- Arbiter: modules are in priority order, first writer wins per field.
local function arbitrate(active_modules)
	local merged = state.merged
	merged.move, merged.aim, merged.aim_owner = nil, nil, nil
	merged.held, merged.pressed = {}, {}
	for i = 1, #active_modules do
		local m = active_modules[i]
		local req = m.req
		if req.move and merged.move == nil then merged.move = req.move end
		if req.aim and req.aim.pos and merged.aim == nil then
			merged.aim, merged.aim_owner = req.aim, m.name
		end
		for field, action in pairs(HELD) do
			if req[field] ~= nil and merged.held[action] == nil then merged.held[action] = req[field] and true or false end
		end
		for field, action in pairs(PRESSED) do
			if req[field] and not merged.pressed[action] then merged.pressed[action] = true end
		end
	end
	for action in pairs(merged.pressed) do state.latched[action] = true end
end

-- Teleport confirmation: orientation RPC and a position jump within the window.
local function check_teleport(ctx)
	if not ctx.unit or not ctx.pos then
		state.last_pos = nil
		return
	end
	if state.last_pos then
		local jump = Api.dist(ctx.pos, state.last_pos)
		if jump >= T("teleport_jump_m") then
			state.jump_t = ctx.t
			Log.write("core", "info", "position jump %.1f m (%.1f, %.1f, %.1f) -> (%.1f, %.1f, %.1f)",
				jump, state.last_pos.x, state.last_pos.y, state.last_pos.z, ctx.pos.x, ctx.pos.y, ctx.pos.z)
		end
	end
	state.last_pos = Api.box(ctx.pos)
	local window = T("teleport_confirm_s")
	if state.rpc_t and state.jump_t and math.abs(state.rpc_t - state.jump_t) <= window then
		Log.write("core", "info", "teleport confirmed (orientation RPC + position jump) at (%.2f, %.2f, %.2f)", ctx.pos.x, ctx.pos.y, ctx.pos.z)
		state.rpc_t, state.jump_t = nil, nil
		fire("teleported")
	else
		if state.rpc_t and ctx.t - state.rpc_t > window then
			Log.write("core", "debug", "orientation RPC without a position jump (not a teleport)")
			state.rpc_t = nil
		end
		if state.jump_t and ctx.t - state.jump_t > window then
			state.jump_t = nil
		end
	end
end

local function where_now()
	if not state.in_gameplay then return "none" end
	local gm = Gate.game_mode_name()
	if gm == nil or HUB_GAME_MODES[gm] then return "hub" end
	return "mission"
end

local selftest -- forward

mod.update = function(dt, t)
	state.t = t
	state.where = where_now()

	if state.in_gameplay then
		local ok, err = pcall(enemy_tracker.update, dt, t)
		if not ok then Log.write("core", "error", "enemy_tracker: %s", tostring(err)) end
	end

	local oks, errs = pcall(Sync.update, dt, t)
	if not oks then Log.write("sync", "error", "%s", tostring(errs)) end

	if state.where == "mission" then
		Gate.mission()
		state.last_mission_gate_ok = Gate.last.ok
	else
		local l = Gate.last
		l.ok, l.kind, l.reason = false, "none", "not in a mission"
	end

	-- Aim layer refuses while another mod drives the same function.
	if Api.other_mod_active("QIangIQsTarkAccount", "enabled") then
		state.aim_block = "QIangIQsTarkAccount aim is enabled (same AimAssist hook)"
	else
		state.aim_block = nil
	end

	local ctx = build_ctx(dt, t)
	pcall(check_teleport, ctx)

	-- First frame in a mission with a live player unit: managers exist now.
	if state.where == "mission" and ctx.unit and not state.mission_ready then
		state.mission_ready = true
		Log.write("core", "info", "mission ready: game mode %s, mission %s, gate %s (%s)",
			tostring(ctx.game_mode), tostring(ctx.mission), Gate.last.kind, Gate.last.reason)
		Api.shared.private_queue = nil -- the queue led somewhere; a new one must be sent next time
		selftest.run_static() -- game scripts are loaded by now
		selftest.run_runtime()
		fire("mission_ready")
	end

	local active = {}
	for i = 1, #modules do
		local m = modules[i]
		m.req = {}
		local runs_here = (m.where == "both") or (m.where == state.where)
		if runs_here then
			local kind = (state.where == "mission") and "mission" or "hub"
			local allowed, why = may_act(m, kind)
			if allowed then
				local ok, err = pcall(m.update, dt, t, ctx, m.req, m.st, Api)
				if ok then
					active[#active + 1] = m
				else
					disable_module(m, err)
				end
			else
				m.blocked = why
			end
			if allowed then m.blocked = nil end
		else
			m.blocked = "runs in " .. m.where
		end
	end

	if state.master and state.where == "mission" and Gate.last.ok then
		arbitrate(active)
	else
		clear_requests()
	end

	if mod.draw_panel_safe then mod.draw_panel_safe() end
end

-- Injection (from 0.1.0) ------------------------------------------------

local function clamp01(v)
	if v < 0 then return 0 end
	if v > 1 then return 1 end
	return v
end

local function inject(handler, input_cache, index)
	local lookup = handler._action_lookup
	if not lookup then return end
	local merged = state.merged
	local wrote = false

	local move = merged.move
	if move then
		local x, y = move.x or 0, move.y or 0
		local values = {
			move_forward = clamp01(y), move_backward = clamp01(-y),
			move_right = clamp01(x), move_left = clamp01(-x),
		}
		-- Same packing the original applies (GAME human_input_handler.lua:274-283).
		local type_index = handler._pack_unpack_action_to_network_type_index or {}
		for action, v in pairs(values) do
			local ci = lookup[action]
			if ci and input_cache[ci] then
				local nti = type_index[action]
				input_cache[ci][index] = nti and Network.pack_unpack(nti, v) or v
			end
		end
		wrote = true
	end

	for action, v in pairs(merged.held) do
		local ci = lookup[action]
		if ci and input_cache[ci] then
			input_cache[ci][index] = v
			wrote = true
		end
	end

	for action in pairs(state.latched) do
		local ci = lookup[action]
		if ci and input_cache[ci] then
			input_cache[ci][index] = true
			wrote = true
		end
	end
	state.latched = {}

	if wrote then state.injected_frames = state.injected_frames + 1 end
end

mod:hook_require("scripts/managers/player/player_game_states/human_input_handler", function(HumanInputHandler)
	mod:hook_safe(HumanInputHandler, "_parse_input", function(self, input_cache, input_service, index)
		if not state.master or state.where ~= "mission" or not Gate.last.ok then return end
		local lp = Api.local_player()
		if lp and self._player and self._player ~= lp then return end
		local ok, err = pcall(inject, self, input_cache, index)
		if not ok then
			state.master = false
			reset_all("injection failed")
			Log.write("core", "error", "injection failed, master turned off: %s", tostring(err))
		end
	end)
end)

-- Aim layer (QIangIQsTarkAccount aim_snap.lua:377-519, linear easing) ---------------

local TWO_PI = math.pi * 2 -- struct: full turn

local function wrap_delta(a, b) -- TK aim_snap.lua:89-93
	local d = (b - a) % TWO_PI
	if d > math.pi then d = d - TWO_PI end
	return d
end

mod:hook_require("scripts/utilities/aim_assist", function(AimAssist)
	mod:hook(AimAssist, "apply_aim_assist", function(func, main_t, main_dt, input, targeting_data,
			aim_assist_ramp_component, weapon_action_component, yaw, pitch, position,
			combat_ability_action_component, grenade_ability_action_component)
		local orig_yaw, orig_pitch = func(main_t, main_dt, input, targeting_data,
			aim_assist_ramp_component, weapon_action_component, yaw, pitch, position,
			combat_ability_action_component, grenade_ability_action_component)

		local aim = state.merged.aim
		if not state.master or state.where ~= "mission" or not Gate.last.ok or not aim or state.aim_block then
			state.aim_owner, state.aim_error = nil, math.huge
			return orig_yaw, orig_pitch
		end

		local ok, ny, np = pcall(function()
			local target = Vector3(aim.pos.x, aim.pos.y, aim.pos.z)
			local wy, wp = Api.yaw_pitch_to(position, target)
			local limit = math.pi * T("aim_pitch_limit_pi_frac")
			local cur_yaw = wrap_delta(0, orig_yaw)
			local cur_pitch = wrap_delta(0, orig_pitch)
			wp = math.clamp(wp, -limit, limit)
			local dyaw = wrap_delta(cur_yaw, wy)
			local dpitch = wp - cur_pitch
			local speed = aim.speed or T("aim_speed_deg_per_sec")
			local max_step = math.rad(speed) * main_dt
			local new_yaw = cur_yaw + math.clamp(dyaw, -max_step, max_step)
			local new_pitch = math.clamp(cur_pitch + math.clamp(dpitch, -max_step, max_step), -limit, limit)
			local ry, rp = wrap_delta(new_yaw, wy), wp - new_pitch
			state.aim_error = math.sqrt(ry * ry + rp * rp)
			state.aim_owner = state.merged.aim_owner
			return new_yaw % TWO_PI, new_pitch % TWO_PI
		end)
		if not ok then
			Log.write("core", "error", "aim layer: %s", tostring(ny))
			return orig_yaw, orig_pitch
		end
		return ny, np
	end)
end)

-- Event hooks (one per method) ---------------------------------------------------------

-- Presence handshake (Vox Manifold presence.lua:201-233 pattern).
mod:hook_require("scripts/managers/presence/presence_entry_myself", function(PresenceEntryMyself)
	mod:hook(PresenceEntryMyself, "create_key_values", function(func, self, white_list, ...)
		local key_values = func(self, white_list, ...)
		local ok, err = pcall(Sync.contribute, key_values, white_list)
		if not ok then Log.write("sync", "error", "contribute: %s", tostring(err)) end
		return key_values
	end)
end)

-- Teleport signal: the concrete game mode class of km_enforcer_twins
-- (GAME watertown_mission_templates.lua:179-184 game_mode_name "coop_complete_objective");
-- class() copies GameModeBase.rpc_client_set_local_player_orientation (game_mode_base.lua:193).
mod:hook_require("scripts/managers/game_mode/game_modes/game_mode_coop_complete_objective", function(GameModeCoopCompleteObjective)
	mod:hook_safe(GameModeCoopCompleteObjective, "rpc_client_set_local_player_orientation", function()
		state.rpc_t = state.t
		Log.write("core", "info", "orientation RPC received")
	end)
end)

-- Minion inventory sounds reach every client with the target unit (MODS QIangIQsAntiSpecialist.lua:58-83).
mod:hook_require("scripts/extension_systems/fx/minion_fx_extension", function(MinionFxExtension)
	mod:hook_safe(MinionFxExtension, "_trigger_inventory_wwise_event", function(self, event_name, inventory_slot_name, fx_source_name, optional_target_unit)
		if not state.master or type(event_name) ~= "string" then return end
		fire("wwise_minion", self._unit, event_name, optional_target_unit)
	end)
end)

-- Minion animation event indices (GAME animation_system.lua:115-119).
mod:hook_require("scripts/extension_systems/animation/animation_system", function(AnimationSystem)
	mod:hook_safe(AnimationSystem, "rpc_minion_anim_event", function(self, channel_id, unit_id, event_index)
		if not state.master then return end
		local spawner = Managers.state and Managers.state.unit_spawner
		if not spawner then return end
		local ok, unit = pcall(spawner.unit, spawner, unit_id)
		if ok and unit then fire("minion_anim_event", unit, event_index) end
	end)
end)

-- Hub side (MODS BornReady.lua:42-88).
mod:hook_safe(CLASS.LobbyView, "on_enter", function(self)
	fire("lobby_enter", self)
end)

mod:hook_safe(CLASS.EndView, "on_enter", function(self)
	fire("end_view_enter", self)
end)

mod:hook_safe(CLASS.EndView, "update", function(self, dt)
	fire("end_view_update", self, dt)
end)

-- The vote hook wraps: a module that takes the vote sets handled = true and the
-- popup is skipped, as BornReady does (BornReady.lua:79-88).
mod:hook_require("scripts/settings/voting/voting_templates/mission_vote_matchmaking_immaterium", function(template)
	mod:hook(template, "on_started", function(func, voting_id, ...)
		local result = { handled = false }
		fire("vote_started", voting_id, result)
		if result.handled then return end
		return func(voting_id, ...)
	end)
end)

-- Game state ----------------------------------------------------------------------------

mod.on_game_state_changed = function(status, state_name)
	-- DMF also fires this for every gameplay init sub-state (vault lesson-game-state-substates-refire).
	if state_name ~= "StateGameplay" then return end
	state.in_gameplay = status == "enter"
	enemy_tracker.reset()
	state.last_pos, state.jump_t, state.rpc_t = nil, nil, nil
	state.mission_ready = false
	if status == "enter" then
		fire("gameplay_enter")
	else
		clear_requests()
		Api.shared.nav_goal, Api.shared.nav_status, Api.shared.defending_until = nil, nil, nil
		fire("gameplay_exit")
		if mod.panel_reset then mod.panel_reset() end
	end
end

mod.on_disabled = function()
	state.master = false
	reset_all("mod disabled")
	pcall(Sync.retract)
end

mod.on_unload = function()
	state.master = false
	reset_all("unload")
	local em = Managers and Managers.event
	if em then pcall(em.unregister, em, mod, "party_immaterium_other_members_updated") end
end

-- Re-publish the handshake when the party changes (as Vox Manifold.lua:629-633 does).
mod.ap_on_party = function()
	Sync.force()
	Log.write("sync", "info", "party changed: re-publishing")
end

mod.on_all_mods_loaded = function()
	local em = Managers and Managers.event
	if em then
		local ok, err = pcall(em.register, em, mod, "party_immaterium_other_members_updated", "ap_on_party")
		if not ok then Log.write("sync", "error", "event register failed: %s", tostring(err)) end
	end
end

-- Debug: panel, self-test, commands ---------------------------------------------------------

local Panel = mod:io_dofile(BASE .. "core/panel")
Panel.init(mod, T, Log, Gate, Sync)
selftest = mod:io_dofile(BASE .. "core/selftest")
selftest.init(mod, T, Log, Api)
selftest.run_static()

mod.draw_panel_safe = Panel.draw_safe
mod.panel_reset = Panel.reset

Sync.set("v", VERSION)
Sync.set("m", 0)

mod:command("autoplay_status", "Print QIangIQs Autoplay state.", function()
	mod:echo(("[Autoplay %s] master=%s where=%s gate=%s (%s) peers=%d injected=%d selftest ok=%d fail=%d wait=%d"):format(
		VERSION, tostring(state.master), state.where, Gate.last.kind, Gate.last.reason,
		Sync.peer_count(), state.injected_frames, state.selftest.ok, state.selftest.fail, state.selftest.pending or 0))
end)

mod:command("autoplay_dump", "Write the ring buffer to a dump file in the mod folder.", function()
	local path, n = Log.dump()
	mod:echo(("[Autoplay] dumped %d lines to %s"):format(n, tostring(path or "(io unavailable)")))
end)

mod:command("autoplay_step", "Single-step the Ortus loop (needs 'Ortus: single-step mode').", function()
	Api.step_tokens = Api.step_tokens + 1
	mod:echo(("[Autoplay] step token added (%d pending)"):format(Api.step_tokens))
end)

mod:command("autoplay_selftest", "Check every hook target and runtime probe.", function()
	selftest.run_static()
	selftest.run_runtime()
	mod:echo(("[Autoplay] self-test: %d ok, %d failed, %d not loaded yet (details in log_selftest.log)"):format(state.selftest.ok, state.selftest.fail, state.selftest.pending or 0))
end)

mod:command("autoplay_log_clear", "Empty all Autoplay log files.", function()
	local names = { "core", "sync", "selftest" }
	for i = 1, #modules do names[#names + 1] = modules[i].name end
	Log.clear_files(names)
	mod:echo("[Autoplay] log files cleared")
end)

mod:command("autoplay_mission", "Set the Ortus mission id: /autoplay_mission <36-char id> | clear | show", function(arg)
	if arg == "clear" then
		mod:set("ortus_mission_id", "", false)
	elseif arg and #arg == 36 then -- struct: backend mission ids are 36-char UUIDs (MODS ManyMoreTry.lua:300-302)
		mod:set("ortus_mission_id", arg, false)
	end
	mod:echo("[Autoplay] Ortus mission id: " .. tostring(mod:get("ortus_mission_id")))
end)

-- Test travel: start the Psykhanium shooting range the way the hub terminal does
-- (GAME training_grounds_options_view.lua:120-160, mission name from training_grounds_view_definitions.lua:960).
mod:command("autoplay_psykhanium", "Start the Psykhanium shooting range (from the hub).", function()
	local ok, err = pcall(function()
		local DangerSettings = require("scripts/settings/difficulty/danger_settings")
		local GameModeSettings = require("scripts/settings/game_mode/game_mode_settings")
		local Missions = require("scripts/settings/mission/mission_templates")
		local danger = DangerSettings.danger_levels[T("psykhanium_danger")]
		local mechanism_context = { mission_name = "tg_shooting_range", challenge_level = danger and danger.challenge or T("psykhanium_danger") }
		local mission_settings = Missions[mechanism_context.mission_name]
		local game_mode_settings = GameModeSettings[mission_settings.game_mode_name]
		if game_mode_settings.host_singleplay then
			Managers.multiplayer_session:reset("Hosting training grounds singleplayer mission")
			Managers.multiplayer_session:boot_singleplayer_session()
		end
		if Managers.connection:is_host() then
			Managers.connection:reset_seed()
		end
		Managers.mechanism:change_mechanism(mission_settings.mechanism_name, mechanism_context)
		Managers.mechanism:trigger_event("all_players_ready")
	end)
	Log.write("core", ok and "info" or "error", "autoplay_psykhanium: %s", ok and "started" or tostring(err))
	if not ok then mod:echo("[Autoplay] Psykhanium start failed: " .. tostring(err)) end
end)

Log.write("core", "info", "QIangIQsAutoplay %s loaded, %d modules", VERSION, #modules)

return mod
