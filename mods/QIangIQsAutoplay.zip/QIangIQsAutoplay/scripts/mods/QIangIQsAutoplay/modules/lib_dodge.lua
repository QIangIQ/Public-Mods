--[[
    lib_dodge.lua: shared dodge / push helpers. NOT a module (the core skips lib_* files);
    modules load it with
        local H = get_mod("QIangIQsAutoplay"):io_dofile("QIangIQsAutoplay/scripts/mods/QIangIQsAutoplay/modules/lib_dodge")
    Stateless: every function takes `api` (and ctx / st where it needs them).

    Copied (logic only, the input path is replaced by per-frame `req` fields) from
        AS = QIangIQsAntiSpecialist core.lua   (dodge direction choice 645-740, path checks 556-640,
                                                dodge routine 752-754 / 899-906, push routine 757-1012)
        TR = QIangIQsTrappers_dodge.lua        (DODGE_STATES :663, same path checks)
    Every number is a tuning id (tuning/movement.lua).

    Shared claim (new blackboard keys, documented in the module report):
        shared.defending_owner  name of the module whose routine runs, nil when none
        shared.defending_prio   its priority (higher wins)
        shared.defending_pressed true once the routine has pressed something it cannot take back
        shared.defending_until  gameplay time, as the contract says
]]

local H = {}

-- TR QIangIQsTrappers_dodge.lua:663: states from which a dodge can start ("dodging" so a started dodge is seen)
local DODGE_STATES = { walking = true, sprinting = true, dodging = true }

function H.dodge_state_ok(ctx)
	return DODGE_STATES[ctx.state] or false
end

-- MinionPerception target per unit, looked up at most once per fixed step (AS core.lua:858-873)
local _target_cache = setmetatable({}, { __mode = "k" })

function H.cached_target(api, unit, gt)
	local c = _target_cache[unit]
	if c and gt >= c.t and gt - c.t < api.fixed_step() then return c.target end
	local target = api.target_of(unit)
	_target_cache[unit] = { t = gt, target = target }
	return target
end

-- Lets pressing dodge run from one fixed step before the press until the cooldown plus the input buffer have passed.
function H.press_window(api)
	return api.T("dodge_cooldown_s") + api.T("input_buffer_frames") * api.fixed_step()
end

-- Archetype dodge length times the largest weapon scale (AS core.lua:263-273)
function H.dodge_distance(api, unit)
	local ext = ScriptUnit.has_extension(unit, "unit_data_system")
	local ok, arch = pcall(function() return ext and ext:archetype() end)
	local base = ok and arch and arch.dodge and arch.dodge.base_distance or api.T("dodge_default_distance_m")
	return base * api.T("dodge_distance_scale")
end

-- Push radius of the wielded weapon (AS core.lua:753-774)
function H.push_radius(api, unit)
	local tpl = api.weapon_template(unit)
	local push = tpl and tpl.actions and tpl.actions.action_push
	return push and push.push_radius or api.T("push_radius_default_m")
end

-- A minion's contact radius (AS core.lua:254-261)
local function body_radius(api, unit)
	local ext = ScriptUnit.has_extension(unit, "unit_data_system")
	local ok, breed = pcall(function() return ext and ext:breed() end)
	return ok and breed and breed.player_locomotion_constrain_radius or api.T("dodge_player_radius_m")
end

-- Shared claim ---------------------------------------------------------------------------------

-- True when this module may start a routine now: no claim, an expired claim, its own claim, or a
-- higher priority than a holder that has not pressed anything yet (AS core.lua:1085 replacement rule).
function H.can_claim(api, name, prio, gt)
	local sh = api.shared
	if sh.defending_owner == nil or sh.defending_owner == name then return true end
	if (sh.defending_until or 0) <= gt then return true end
	return prio > (sh.defending_prio or 0) and not sh.defending_pressed
end

-- Take or keep the claim; keeps defending_until at the later of the old and the new value.
function H.claim(api, name, prio, gt, pressed)
	if not H.can_claim(api, name, prio, gt) then return false end
	local sh = api.shared
	sh.defending_owner, sh.defending_prio = name, prio
	sh.defending_pressed = pressed and true or false
	sh.defending_until = math.max(sh.defending_until or 0, gt + api.T("dodge_time_s"))
	return true
end

function H.release(api, name)
	local sh = api.shared
	if sh.defending_owner == name then
		sh.defending_owner, sh.defending_prio, sh.defending_pressed = nil, nil, false
	end
end

-- Direction choice -----------------------------------------------------------------------------

local function yaw_basis(yaw)
	local rot = Quaternion.from_yaw_pitch_roll(yaw, 0, 0)
	return Quaternion.right(rot), Quaternion.forward(rot)
end

-- ctx.yaw as a number. HumanPlayer.get_orientation returns the table { yaw, pitch, roll } (GAME human_player.lua:187-189),
-- so a core that passes the table through is tolerated here.
function H.yaw_of(ctx)
	local y = ctx.yaw
	if type(y) == "table" then y = y.yaw end
	return type(y) == "number" and y or nil
end

-- World direction (dx, dy) -> move input { x = right, y = forward } for the current yaw; nil without a yaw.
-- Same maths as api.move_toward, with the yaw taken from H.yaw_of.
function H.move_toward(ctx, dx, dy)
	local yaw = H.yaw_of(ctx)
	if not yaw then return nil end
	local len = math.sqrt(dx * dx + dy * dy)
	if len <= 0 then return { x = 0, y = 0 } end
	dx, dy = dx / len, dy / len
	local right, forward = yaw_basis(yaw)
	return { x = dx * right.x + dy * right.y, y = dx * forward.x + dy * forward.y }
end

-- What Dodge.check does with a wanted world direction {x, y} at this yaw (AS core.lua:644-659):
-- returns move x, move y, the real world direction {x, y}, exact? or nil when the game would not dodge.
function H.resolve(api, dir, yaw)
	local right, forward = yaw_basis(yaw)
	local x = dir.x * right.x + dir.y * right.y
	local y = dir.x * forward.x + dir.y * forward.y
	if y <= 0 then return x, y, dir, true end
	if math.abs(x) > api.T("dodge_min_lateral") then
		local sx = x > 0 and 1 or -1
		return sx, 0, { x = right.x * sx, y = right.y * sx }, false
	end
	return nil
end

-- Ledge, wall and body checks along a flat direction {x, y} (AS core.lua:556-640).
-- ignore: a unit that may stand in the path (the threat itself when dodging away from it).
function H.path_safe(api, ctx, dir, ignore)
	local T = api.T
	local unit, pos = ctx.unit, ctx.pos
	local pw = api.physics_world()
	if not pw then return false, "no physics world" end
	local length = H.dodge_distance(api, unit)
	local radius = T("dodge_player_radius_m")
	local max_drop = T("dodge_max_drop_m")

	-- ground under the path, probed every body radius out to the dodge length
	local steps = math.floor(length / radius + 1e-6) -- struct: float tolerance on the step count
	for i = 1, steps do
		local from = Vector3(pos.x + dir.x * radius * i, pos.y + dir.y * radius * i, pos.z + max_drop)
		local hit, position = PhysicsWorld.raycast(pw, from, Vector3(0, 0, -1), 2 * max_drop, "closest", "types", "statics", "collision_filter", "filter_player_mover") -- struct: ray spans max_drop above to max_drop below the feet
		local z = hit and position and position.z or nil
		if not z or z < pos.z - max_drop then
			return false, string.format("ledge at %.1f m", radius * i)
		end
	end

	-- one ray at body-radius height (AS core.lua:600-606)
	local wall_dir = Vector3(dir.x, dir.y, 0)
	local hit, _, distance = PhysicsWorld.raycast(pw, pos + Vector3(0, 0, radius), wall_dir, length, "closest", "types", "statics", "collision_filter", "filter_player_mover")
	if hit and distance and distance < radius + T("dodge_wall_extra_m") then
		return false, string.format("wall at %.1f m", distance)
	end

	-- bodies: copy the shared broadphase buffer first (api.enemies_near returns one table for every caller)
	local blockers = {}
	local count, units = api.enemies_near(unit, pos, length + radius)
	for i = 1, count do blockers[#blockers + 1] = units[i] end
	local pm = Managers.player
	local ok_p, players = pcall(pm.players, pm)
	if ok_p and players then
		for _, player in pairs(players) do
			if player.player_unit ~= unit then blockers[#blockers + 1] = player.player_unit end
		end
	end
	for _, other in ipairs(blockers) do
		if other ~= ignore and api.unit_ok(other) then
			local p = api.position(other)
			local rx, ry = p.x - pos.x, p.y - pos.y
			local along = rx * dir.x + ry * dir.y
			if along > 0 and along < length then
				local sx, sy = rx - dir.x * along, ry - dir.y * along
				if math.sqrt(sx * sx + sy * sy) < radius + body_radius(api, other) then
					return false, string.format("body in the way at %.1f m", along)
				end
			end
		end
	end
	return true
end

-- Pick a dodge direction (AS core.lua:1163-1232 with camera_mode "never": no camera turn is made here,
-- the core aim layer owns the camera; candidates are the ones the game can dodge from the current view).
-- from: {x, y} a point on the threat's line; mode "across" (90 degrees to the line from it to me, then
-- away-diagonals) or "away" (straight away first). Returns { x, y, dir, exact } or nil, reason.
function H.choose(api, ctx, from, mode, ignore)
	local T = api.T
	local pos = ctx.pos
	local ax, ay = pos.x - from.x, pos.y - from.y
	local len = math.sqrt(ax * ax + ay * ay)
	if len < T("dodge_on_top_m") then return nil, "on top of the threat" end
	ax, ay = ax / len, ay / len
	local away = { x = ax, y = ay }
	local p1 = { x = -ay, y = ax }
	local p2 = { x = ay, y = -ax }
	local c45 = T("dodge_min_lateral")
	local function mix(a, sa, b, sb) return { x = a.x * sa + b.x * sb, y = a.y * sa + b.y * sb } end

	local first, second, rest, lateral, min_score
	if mode == "away" then
		first, second = away, mix(away, c45, p1, c45)
		rest = { mix(away, c45, p2, c45), p1, p2 }
		lateral, min_score = nil, 0 -- never toward it
	else
		first, second = p1, p2
		rest = { mix(p1, c45, away, c45), mix(p2, c45, away, c45) }
		lateral, min_score = p1, c45 - T("dodge_lateral_slack")
	end

	local yaw = H.yaw_of(ctx) or 0
	-- among the first two, the one reachable without a camera turn goes first
	local _, _, _, exact1 = H.resolve(api, first, yaw)
	local _, _, _, exact2 = H.resolve(api, second, yaw)
	if not exact1 and exact2 then first, second = second, first end

	local list = { first, second }
	for i = 1, #rest do list[#list + 1] = rest[i] end

	local reasons = {}
	for _, wanted in ipairs(list) do
		local x, y, real, exact = H.resolve(api, wanted, yaw)
		if x then
			local score
			if lateral then
				score = math.abs(real.x * lateral.x + real.y * lateral.y)
			else
				score = real.x * ax + real.y * ay
			end
			if score >= min_score then
				local safe, why = H.path_safe(api, ctx, real, ignore)
				if safe then return { x = x, y = y, dir = real, exact = exact } end
				reasons[#reasons + 1] = why
			end
		end
	end
	return nil, table.concat(reasons, ", ")
end

-- Dodge routine (per-frame form of AS core.lua:1342-1377) ---------------------------------------

-- spec: { from = {x, y}, mode = "across" | "away", ignore = unit, due = gameplay time, label = string }
function H.dodge_new(api, ctx, spec)
	local c, why = H.choose(api, ctx, spec.from, spec.mode, spec.ignore)
	if not c then return nil, why end
	return { kind = "dodge", dir = c.dir, mx = c.x, my = c.y, phase = "move", due = spec.due or ctx.gt,
		label = spec.label or "dodge", exact = c.exact }
end

-- Sets req for this frame. Returns done, result ("done" | "refused").
function H.dodge_step(api, r, ctx, req)
	local gt = ctx.gt
	-- the camera may have been turned by the aim layer since the choice: resolve the same world direction again
	local yaw = H.yaw_of(ctx)
	if yaw then
		local x, y = H.resolve(api, r.dir, yaw)
		if x then r.mx, r.my = x, y end
	end
	req.move = { x = r.mx, y = r.my }
	req.sprinting = false -- sprinting ends in the fixed frame that reads move y <= 0 (AS core.lua:746-748)

	local movement = api.component(ctx.unit, "movement_state")
	local dodging = (movement and movement.is_dodging) or ctx.state == "dodging"

	if r.phase == "move" and gt >= r.due then r.phase = "press" end

	if r.phase == "press" then
		if dodging then
			-- stop pressing the moment it starts so a latched press cannot start a second dodge
			r.phase, r.started = "started", gt
			r.pressed = true
		elseif gt > r.due + H.press_window(api) then
			return true, "refused"
		else
			req.dodge = true
		end
	elseif r.phase == "started" and gt > r.started + api.T("dodge_hold_after_steps") * api.fixed_step() then
		return true, "done"
	end
	return false
end

-- Push routine (per-frame form of AS core.lua:1381-1500) -----------------------------------------

-- spec: { threat = unit, interrupt = bool (default true: cancel a swing with wield_2 first),
--         wait_fn = function(gt, ctx) -> true | "abort" | false (wait with melee out until ready),
--         then_dodge = { mode = "away" | "across", label = string } (dodge straight after the push),
--         face = bool (default true), label = string }
function H.push_new(api, ctx, spec)
	return { kind = "push", phase = "swap", phase_t = ctx.gt, threat = spec.threat, wait_fn = spec.wait_fn,
		wait_timeout = spec.wait_timeout or api.T("push_wait_timeout_s"), want_interrupt = spec.interrupt ~= false,
		then_dodge = spec.then_dodge, face = spec.face ~= false, label = spec.label or "push" }
end

-- Aim at the threat at eye height, so only the yaw turns (AS _face, core.lua:828-838)
local function face(api, ctx, req, r)
	if not r.face or not ctx.eye or not api.unit_ok(r.threat) then return end
	local p = api.position(r.threat)
	if api.flat_dist(p, ctx.pos) < api.T("push_face_min_m") then return end
	req.aim = { pos = { x = p.x, y = p.y, z = ctx.eye.z } }
end

-- Returns done, result.
function H.push_step(api, r, ctx, req)
	local T = api.T
	local gt, slot = ctx.gt, ctx.wielded
	if api.unit_ok(r.threat) then
		local p = api.position(r.threat)
		r.threat_pos = { x = p.x, y = p.y }
	end

	if r.phase == "swap" then
		if not r.saved then
			r.saved = slot
			if slot ~= "slot_primary" and slot ~= "slot_secondary" then return true, "not holding a weapon" end
			r.interrupt = slot == "slot_primary" and r.want_interrupt
		end
		if r.interrupt then
			if gt - r.phase_t < T("push_interrupt_s") then
				req.wield_2 = true
				return false
			end
			r.interrupt = false
			r.phase_t = gt
		end
		if slot == "slot_primary" then
			r.phase, r.phase_t = r.wait_fn and "wait" or "block", gt
		elseif gt - r.phase_t > T("push_swap_timeout_s") then
			r.phase, r.phase_t = "restore", gt
		else
			req.wield_1 = true
			return false
		end
	end

	if r.phase == "wait" then
		if slot ~= "slot_primary" then
			r.phase, r.phase_t = "swap", gt
			return false
		end
		local ready = r.wait_fn(gt, ctx)
		if ready == "abort" or gt - r.phase_t > r.wait_timeout then
			r.phase, r.phase_t = "restore", gt
		elseif ready then
			r.phase, r.phase_t = "block", gt
		end
		return false
	end

	if r.phase == "block" then
		req.action_two_hold = true
		face(api, ctx, req, r)
		if gt - r.phase_t >= T("push_block_s") then r.phase, r.phase_t = "push", gt end
		return false
	end

	if r.phase == "push" then
		r.pressed = true
		req.action_two_hold = true
		req.action_one_hold = true
		req.action_one_pressed = true
		face(api, ctx, req, r)
		if gt - r.phase_t >= T("push_press_s") then
			if r.then_dodge and r.threat_pos and H.dodge_state_ok(ctx) then
				local d = H.dodge_new(api, ctx, { from = r.threat_pos, mode = r.then_dodge.mode, ignore = r.threat,
					due = gt, label = r.then_dodge.label })
				if d then
					r.sub, r.phase, r.phase_t = d, "dodge", gt
					return false
				end
			end
			r.phase, r.phase_t = "restore", gt
		end
		return false
	end

	if r.phase == "dodge" then
		if H.dodge_step(api, r.sub, ctx, req) then r.phase, r.phase_t = "restore", gt end
		return false
	end

	if r.phase == "restore" then
		if not r.saved or r.saved == slot or gt - r.phase_t > T("push_restore_timeout_s") then
			return true, "pushed"
		end
		if r.saved == "slot_secondary" then req.wield_2 = true else req.wield_1 = true end
		return false
	end
	return true, "done"
end

-- Routine runner (one routine per module, kept in st.routine) --------------------------------------

-- Drops the running routine and the claim.
function H.drop(api, st, name)
	st.routine = nil
	H.release(api, name)
end

-- Module reset hook helper.
function H.reset(api, st, name)
	H.drop(api, st, name)
end

-- Starts a routine. kind "dodge" | "push"; spec as for dodge_new / push_new; on_done(r, result) optional.
-- Returns true, or false, reason, retry (retry = true when only busy / another module holds the claim).
function H.begin(api, st, ctx, name, prio, kind, spec, on_done)
	local gt = ctx.gt
	if st.routine then return false, "busy", true end
	if not H.can_claim(api, name, prio, gt) then return false, "another defence is active", true end
	local r, why
	if kind == "dodge" then
		if not H.dodge_state_ok(ctx) then return false, "cannot dodge in state " .. tostring(ctx.state), true end
		r, why = H.dodge_new(api, ctx, spec)
	else
		if not ctx.can_act then return false, "cannot act in state " .. tostring(ctx.state), true end
		r = H.push_new(api, ctx, spec)
	end
	if not r then return false, why, false end
	r.on_done = on_done
	H.claim(api, name, prio, gt, false)
	st.routine = r
	return true
end

-- Runs the routine one frame. Returns true while it is still running.
function H.run(api, st, ctx, req, name, prio)
	local r = st.routine
	if not r then return false end
	local gt = ctx.gt
	-- the module was not stepped for a while (checkbox off, conflict, gate): do not resume an old press
	if gt and r.last_gt and gt - r.last_gt > H.press_window(api) then
		api.status(st, "idle", r.label, "dropped", "stale routine")
		H.drop(api, st, name)
		return false
	end
	r.last_gt = gt
	if not gt or not ctx.can_act then
		api.status(st, "idle", r.label, "aborted", "cannot act in state " .. tostring(ctx.state))
		H.drop(api, st, name)
		return false
	end
	if not H.claim(api, name, prio, gt, r.pressed) then
		api.status(st, "idle", r.label, "yielded", "a higher-priority defence took over")
		H.drop(api, st, name)
		return false
	end
	local done, result
	if r.kind == "dodge" then
		done, result = H.dodge_step(api, r, ctx, req)
	else
		done, result = H.push_step(api, r, ctx, req)
	end
	if done then
		api.status(st, "idle", r.label, "finished", result)
		if r.on_done then r.on_done(r, result) end
		H.drop(api, st, name)
		return false
	end
	api.status(st, "active", r.label, r.kind, r.phase)
	return true
end

return H
