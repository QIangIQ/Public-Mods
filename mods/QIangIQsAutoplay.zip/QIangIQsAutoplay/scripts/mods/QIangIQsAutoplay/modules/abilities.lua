--[[
    abilities: combat ability and grenade (blitz) use.

    What the game bots do (GAME bt_bot_conditions.lua:59-100): only two ability templates are ever
    activated, the veteran stance (template "veteran_combat_ability") and the zealot relic.
    The grenade node never fires for stock grenades (bot_behavior_tree.lua:52-57).
    Copied where the data is client-visible, everything else UNTUNED:

      Veteran (conditions :42-57): fires when the bot target is a special or elite. Client mapping:
        a tracked special/elite breed (tags.special or tags.elite) inside the shout radius 9
        (GAME talent_settings_veteran.lua:199, veteran_3.combat_ability.radius).
      Zealot relic (conditions :7-40): sums breed.challenge_rating of enemies within 10 m (distance
        squared <= 100) taken from the 5 m proximity list (max 10 units, bot_perception_extension.lua:8,10),
        x1.25 when the enemy targets me; fires at >= 1.75. api.target_of replaces the server-only
        blackboard perception.target_unit. The bot's own check reads the template name from the ability
        component, which is "none" for the relic (zealot_abilities.lua:37-52 has no ability_template), so the bot
        itself probably never reaches it. Here the relic is detected through equipped_abilities.combat_ability.
        Press 1 = combat_ability (wields the relic, slot_combat_ability); press 2 = combat_ability again
        (relic action input "channel" = wielded_input_pressed, zealot_relic.lua:11-18). UNVERIFIED in game.
      Every other combat ability: generic crowd rule, all numbers UNTUNED. The press is made when the
        core aim layer reports this module as the aim owner and the aim error is small (dash/charge style
        abilities go where you look), or after ability_aim_wait_s.
      Grenade ability: generic cluster rule, UNTUNED. Sequence from the grenade template
        (weapon_template_generators/grenade_weapon_template_generator.lua:9-31): grenade_ability (wield),
        action_one_pressed (aim_hold), hold, then action_one_hold false (aim_released) throws.

    Ability ready = component enabled, not active, num_charges > 0
    (PlayerUnitAbilityExtension.can_use_ability / remaining_ability_charges, player_unit_ability_extension.lua:610-723;
    component fields player_unit_data_component_config.lua:1042-1056).
    Presses are made only while ctx.wielded is slot_primary or slot_secondary, so nothing is cancelled.
    Holds off while ctx.gt < shared.defending_until. The relic and grenade slots are entered by the game
    itself through the ability inputs. The only wield press is the restore after an aborted sequence
    (grenade or relic still in hand): wield_1 / wield_2 of the slot that was out before.
    shared.ability_aim = { t } is written while an aimed sequence runs; auto_melee and auto_shoot then
    write no req.aim (they outrank this module in the core order, so the aim layer would hand them the aim).
]]

local Breeds = require("scripts/settings/breed/breeds")

local SLOT_MELEE, SLOT_RANGED, SLOT_NONE = "slot_primary", "slot_secondary", "slot_unarmed"
local SLOT_COMBAT, SLOT_GRENADE = "slot_combat_ability", "slot_grenade_ability"
local VETERAN_TEMPLATE = "veteran_combat_ability"
local RELIC = "zealot_relic"
local MODULE = "abilities"

local A, T

local function defending(ctx)
	local until_t = ctx.shared.defending_until
	return until_t ~= nil and ctx.gt ~= nil and ctx.gt < until_t
end

local function ready(unit, name)
	local c = A.component(unit, name)
	return (c and c.enabled and not c.active and c.num_charges > 0) and true or false
end

local function tags_of(unit)
	local b = Breeds[A.breed_name(unit)]
	return b and b.tags or nil, b
end

local function toughness_fraction(unit)
	local ext = ScriptUnit.has_extension(unit, "toughness_system")
	if ext and ext.current_toughness_percent then return ext:current_toughness_percent() end
	return 1
end

-- Nearest alive enemy inside radius (position table), and the count.
local function nearest_in(ctx, radius)
	local count, list = A.enemies_near(ctx.unit, ctx.pos, radius)
	local best, best_d2, best_unit = nil, math.huge, nil
	local me = ctx.pos
	for i = 1, count do
		local u = list[i]
		if A.alive(u) then
			local p = A.position(u)
			local dx, dy, dz = p.x - me.x, p.y - me.y, p.z - me.z
			local d2 = dx * dx + dy * dy + dz * dz
			if d2 < best_d2 then best, best_d2, best_unit = p, d2, u end
		end
	end
	return best, best_unit, count
end

local function veteran_trigger(ctx)
	local count, list = A.enemies_near(ctx.unit, ctx.pos, T("ability_veteran_radius_m"))
	for i = 1, count do
		local u = list[i]
		if A.alive(u) then
			local tags = tags_of(u)
			if tags and (tags.special or tags.elite) then return true, A.breed_name(u) end
		end
	end
	return false
end

local function relic_trigger(ctx)
	local count, list = A.enemies_near(ctx.unit, ctx.pos, T("ability_proximity_radius_m"))
	count = math.min(count, T("ability_proximity_max"))
	local max_d = T("ability_relic_max_distance_m")
	local max_d2 = max_d * max_d
	local me = ctx.pos
	local total = 0
	for i = 1, count do
		local u = list[i]
		if A.alive(u) then
			local p = A.position(u)
			local dx, dy, dz = p.x - me.x, p.y - me.y, p.z - me.z
			if dx * dx + dy * dy + dz * dz <= max_d2 then
				local _, breed = tags_of(u)
				local rating = breed and breed.challenge_rating or 0
				if A.target_of(u) == ctx.unit then rating = rating * T("ability_relic_targeting_multiplier") end
				total = total + rating
				if total >= T("ability_relic_challenge_threshold") then return true end
			end
		end
	end
	return false
end

local function generic_trigger(ctx)
	local pos, _, count = nearest_in(ctx, T("ability_other_radius_m"))
	if pos == nil then return false end
	if count >= T("ability_other_min_enemies") then return true, pos end
	if toughness_fraction(ctx.unit) <= T("ability_other_toughness_frac") then return true, pos end
	return false
end

-- Best cluster centre for a grenade: the tracked enemy with most neighbours inside the cluster radius.
local function grenade_target(ctx)
	local me = ctx.pos
	local min_r, max_r = T("grenade_min_range_m"), T("grenade_max_range_m")
	local cluster = T("grenade_cluster_radius_m")
	local c2 = cluster * cluster
	local cands = {}
	for u in pairs(A.enemies()) do
		if A.alive(u) then
			local p = A.position(u)
			local dx, dy, dz = p.x - me.x, p.y - me.y, p.z - me.z
			local d = math.sqrt(dx * dx + dy * dy + dz * dz)
			if d <= max_r then cands[#cands + 1] = { unit = u, p = p, d = d } end
		end
	end
	local best, best_n = nil, 0
	for i = 1, #cands do
		local ci = cands[i]
		if ci.d >= min_r then
			local n = 0
			for j = 1, #cands do
				local cj = cands[j]
				local dx, dy, dz = cj.p.x - ci.p.x, cj.p.y - ci.p.y, cj.p.z - ci.p.z
				if dx * dx + dy * dy + dz * dz <= c2 then n = n + 1 end
			end
			if n > best_n then best, best_n = ci, n end
		end
	end
	if best and best_n >= T("grenade_min_enemies") and A.has_los(ctx.eye, best.p) then
		return best.p, best_n
	end
	return nil
end

-- Sequence abort: a grenade or relic left in hand is put away again (wield_1 / wield_2 of the slot
-- that was out before). This is the only place this module presses a wield key.
local function abort(st, ctx, t)
	local seq = st.seq
	st.seq = nil
	st.next_t = t + T("ability_retry_s")
	if seq and seq.restore and (ctx.wielded == SLOT_GRENADE or ctx.wielded == SLOT_COMBAT) then
		st.seq = { kind = "restore", t0 = t, slot = seq.restore, timeout = T("ability_restore_wait_s"), next_t = t }
	end
end

local function stop(st)
	st.seq = nil
end

return {
	name = MODULE,
	setting = "module_abilities",
	title = "Combat: abilities and grenades",
	description = "Uses the combat ability and the grenade by rules: veteran stance and zealot relic copy the game bot conditions, every other ability and the grenade use untuned crowd rules you can adjust.",
	conflicts = {
		{ mod = "QIangIQsGuaranteeSuite", setting = "ag_enabled", why = "Ability God in the Guarantee Suite already casts abilities by toughness, health or peril (this setting defaults to on there)" },
		{ mod = "QIangIQsAutoQuell", setting = "auto_ability", why = "Auto Quell presses the combat ability when a psyker overloads" },
	},

	init = function(api, st)
		A, T = api, api.T
	end,

	reset = function(api, st)
		stop(st)
		if api.shared.ability_aim == st.aim_tbl then api.shared.ability_aim = nil end
	end,

	update = function(dt, t, ctx, req, st, api)
		A, T = api, api.T
		local shared = ctx.shared
		local unit = ctx.unit
		if not st.aim_tbl then st.aim_tbl = { t = 0 } end
		if not unit or not ctx.can_act or not ctx.gt or not ctx.eye or not ctx.pos then
			stop(st)
			return api.status(st, "idle", nil, "wait", "no unit or cannot act")
		end
		if defending(ctx) then
			if st.seq and st.seq.kind ~= "restore" then abort(st, ctx, t) end
			return api.status(st, "hold-off", nil, "wait", "defensive routine running")
		end

		local seq = st.seq
		local fs = api.fixed_step()

		-- sequences in progress ------------------------------------------------
		if seq then
			if seq.kind == "restore" then
				if ctx.wielded == seq.slot or t - seq.t0 > seq.timeout then
					st.seq = nil
					return api.status(st, "idle", nil, "done", "weapon restored")
				end
				if t >= seq.next_t then
					if seq.slot == SLOT_RANGED then req.wield_2 = true else req.wield_1 = true end
					seq.next_t = t + T("melee_wield_interval_s")
				end
				return api.status(st, "restore", nil, "wield", "putting the weapon back after an aborted sequence")
			end
			if t - seq.t0 > seq.timeout then
				abort(st, ctx, t)
				return api.status(st, "idle", nil, "abort", seq.kind .. " sequence timed out")
			end
			if seq.kind == "combat_aim" then
				req.aim = { pos = api.box(seq.pos) }
				st.aim_tbl.t = ctx.t
				shared.ability_aim = st.aim_tbl
				local aimed = ctx.aim_owner == MODULE and ctx.aim_error ~= nil and ctx.aim_error <= math.rad(T("aim_on_target_deg"))
				if aimed then
					req.combat_ability = true
					st.seq = nil
					st.next_t = t + T("ability_retry_s")
					return api.status(st, "cast", nil, "combat_ability", "aimed")
				end
				if t - seq.t0 >= T("ability_aim_wait_s") then
					-- the aim layer never reached the target (another module owns the aim): do not cast blind
					abort(st, ctx, t)
					return api.status(st, "idle", nil, "abort", "aim not reached in time")
				end
				return api.status(st, "aim", nil, "aim for ability", "waiting for aim")
			elseif seq.kind == "relic_channel" then
				if ctx.wielded == SLOT_COMBAT then
					req.combat_ability = true
					st.seq = nil
					st.next_t = t + T("ability_retry_s")
					return api.status(st, "cast", nil, "combat_ability", "relic channel press")
				end
				return api.status(st, "wait", nil, "wait", "relic not wielded yet")
			elseif seq.kind == "grenade" then
				if seq.phase == "wield" then
					if ctx.wielded == SLOT_GRENADE then seq.phase, seq.pt = "aim", t end
					return api.status(st, "wait", nil, "grenade", "grenade wield, aim and throw sequence")
				end
				req.aim = { pos = api.box(seq.pos) }
				st.aim_tbl.t = ctx.t
				shared.ability_aim = st.aim_tbl
				if seq.phase == "aim" then
					local aimed = ctx.aim_owner == MODULE and ctx.aim_error ~= nil and ctx.aim_error <= math.rad(T("aim_on_target_deg"))
					if aimed then
						seq.phase, seq.pt, seq.pressed = "hold", t, false
					elseif t - seq.pt >= T("ability_aim_wait_s") then
						abort(st, ctx, t)
						return api.status(st, "idle", nil, "abort", "aim not reached in time, grenade put away")
					end
					return api.status(st, "aim", nil, "grenade", "grenade wield, aim and throw sequence")
				elseif seq.phase == "hold" then
					req.action_one_hold = true
					if not seq.pressed then
						req.action_one_pressed = true
						seq.pressed = true
					end
					if t - seq.pt >= math.max(T("grenade_hold_s"), fs) then seq.phase, seq.pt = "release", t end
					return api.status(st, "throw", nil, "grenade", "grenade wield, aim and throw sequence")
				else
					req.action_one_hold = false
					if ctx.wielded ~= SLOT_GRENADE then
						st.seq = nil
						st.next_t = t + T("ability_retry_s")
						return api.status(st, "idle", nil, "done", "grenade thrown")
					end
					return api.status(st, "throw", nil, "grenade", "grenade wield, aim and throw sequence")
				end
			end
		end

		-- idle: start something ------------------------------------------------
		if t < (st.next_t or 0) or t < (st.next_eval or 0) then return end
		local w = ctx.wielded
		if w ~= SLOT_MELEE and w ~= SLOT_RANGED and w ~= SLOT_NONE then return end
		st.next_eval = t + T("ability_eval_s")

		-- combat ability
		if ready(unit, "combat_ability") then
			local cba = api.component(unit, "combat_ability_action")
			local tname = cba and cba.template_name or "none"
			local eq = api.component(unit, "equipped_abilities")
			local eq_name = eq and eq.combat_ability or "none"
			if tname == VETERAN_TEMPLATE then
				local fire, who = veteran_trigger(ctx)
				if fire then
					req.combat_ability = true
					st.next_t = t + T("ability_retry_s")
					return api.status(st, "cast", who, "combat_ability", "veteran stance: special or elite near (BC:51)")
				end
			elseif eq_name == RELIC then
				if relic_trigger(ctx) then
					req.combat_ability = true
					st.seq = { kind = "relic_channel", t0 = t, timeout = T("ability_relic_wait_s"), restore = w }
					return api.status(st, "cast", nil, "combat_ability", "zealot relic: challenge rating reached (BC:7-40)")
				end
			elseif tname ~= "none" or eq_name ~= "none" then
				if T("ability_other_enabled") > 0 then
					local fire, pos = generic_trigger(ctx)
					if fire then
						st.seq = { kind = "combat_aim", t0 = t, timeout = T("ability_aim_wait_s") + fs + fs, pos = api.box(pos), restore = w }
						return api.status(st, "aim", eq_name, "aim for ability", "generic crowd rule (untuned)")
					end
				end
			end
		end

		-- grenade
		if T("grenade_enabled") > 0 and ready(unit, "grenade_ability") then
			local pos, n = grenade_target(ctx)
			if pos then
				local lifted = { x = pos.x, y = pos.y, z = pos.z + T("grenade_aim_lift_m") }
				req.grenade_ability = true
				st.seq = { kind = "grenade", phase = "wield", t0 = t, pt = t, pos = lifted, timeout = T("grenade_timeout_s"), restore = w }
				return api.status(st, "cast", nil, "grenade_ability", "cluster of " .. tostring(n) .. " (untuned rule)")
			end
		end

		return api.status(st, "idle", nil, "wait", "no ability trigger")
	end,
}
