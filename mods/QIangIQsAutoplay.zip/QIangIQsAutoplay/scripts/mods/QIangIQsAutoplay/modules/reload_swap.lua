--[[
    reload_swap: reload an empty clip and vent a hot weapon on the ranged slot.

    WIELD OWNERSHIP: this module presses NO wield key. auto_melee owns wield_1,
    auto_shoot owns wield_2. When the ranged weapon has to be out for a reload or a vent
    this module publishes shared.reload_want = { t, why } and auto_shoot wields it.
    The melee/ranged swap rule itself lives in auto_melee (choice) and auto_shoot (wield_2).

    Rules (GAME bots):
      reload: not while the target is melee type (bt_bot_conditions.lua:450); clip percentage <= 0
              and reserve percentage > 0 (:457). The bot re-queues "reload" when consumed and
              evaluates every tick (bt_bot_reload_action.lua:21-31); here it is pressed at most every
              reload_press_interval_s (UNTUNED) and never while a reload action is running.
      vent:   bt_bot_conditions.lua:462-482 with the args from bot_behavior_tree.lua:157-163:
              start when overheat (low threshold) is in [0.5, 0.99], keep venting until it is below 0.1.
              The bot vents from its follow branch, i.e. when it is not shooting; here: when the
              ranged claim is not live, or when overheat is at or above the shoot limit 0.9.
      Venting a plasma gun is the input "vent" = weapon_extra_hold (GAME plasmagun_p1_m1.lua:104-113),
      not the reload input. The core's held-field list (CONTRACT) has no weapon_extra_hold:
      this module sets req.weapon_extra_hold and needs the core to map it (input_handler_settings.lua:6-22).
    Force-staff quelling (weapon_reload_hold) is NOT touched: that is QIangIQsAutoQuell's job.
]]

local Ammo = require("scripts/utilities/ammo")
local Overheat = require("scripts/utilities/overheat")

local SLOT_RANGED = "slot_secondary"
local NOT_EQUIPPED = "not_equipped"

local A, T

local function defending(ctx)
	local until_t = ctx.shared.defending_until
	return until_t ~= nil and ctx.gt ~= nil and ctx.gt < until_t
end

local function live(claim, prev)
	return claim ~= nil and claim.t >= prev
end

local function stop(st, shared)
	st.venting = false
	if shared and shared.reload_want == st.want_tbl then shared.reload_want = nil end
end

return {
	name = "reload_swap",
	setting = "module_reload_swap",
	title = "Combat: reload and vent",
	description = "Reloads an empty ranged weapon and vents an overheating one, using the game bot rules. Never presses a wield key: it asks auto_shoot to bring the ranged weapon out.",
	conflicts = {},

	init = function(api, st)
		A, T = api, api.T
		st.want_tbl = { t = 0, why = "" }
	end,

	reset = function(api, st)
		stop(st, api.shared)
	end,

	update = function(dt, t, ctx, req, st, api)
		A, T = api, api.T
		local shared = ctx.shared
		local unit = ctx.unit
		local prev = st.prev_t or ctx.t
		st.prev_t = ctx.t
		if not st.want_tbl then st.want_tbl = { t = 0, why = "" } end

		if not unit or not ctx.can_act or not ctx.gt then
			stop(st, shared)
			return api.status(st, "idle", nil, "wait", "no unit or cannot act")
		end
		if defending(ctx) then
			return api.status(st, "hold-off", nil, "wait", "defensive routine running")
		end
		if live(shared.melee_claim, prev) then
			stop(st, shared)
			return api.status(st, "idle", nil, "wait", "melee target: no reload (bt_bot_conditions.lua:450)")
		end
		local inv = A.component(unit, "inventory")
		if not inv or inv.slot_secondary == NOT_EQUIPPED then
			stop(st, shared)
			return api.status(st, "idle", nil, "wait", "no ranged weapon")
		end

		-- vent decision
		local heat = Overheat.slot_percentage(unit, SLOT_RANGED, "low_threshold")
		if st.venting then
			st.venting = heat >= T("reload_vent_stop")
		else
			local engaged = live(shared.ranged_claim, prev) and heat < T("shoot_overheat_limit")
			st.venting = heat >= T("reload_vent_start_min") and heat <= T("reload_vent_start_max") and not engaged
		end

		-- reload decision
		local clip = Ammo.current_slot_clip_percentage(unit, SLOT_RANGED)
		local reserve = Ammo.current_slot_percentage(unit, SLOT_RANGED)
		local needs_reload = clip <= 0 and reserve > 0

		if not st.venting and not needs_reload then
			if shared.reload_want == st.want_tbl then shared.reload_want = nil end
			return api.status(st, "idle", nil, "wait", "nothing to do")
		end

		local why = st.venting and "vent" or "reload"
		if ctx.wielded ~= SLOT_RANGED then
			local want = st.want_tbl
			want.t, want.why = ctx.t, why
			shared.reload_want = want
			return api.status(st, "wait", nil, "ask ranged weapon", why .. ": ranged weapon not out")
		end
		if shared.reload_want == st.want_tbl then shared.reload_want = nil end

		if st.venting then
			req.weapon_extra_hold = true
			return api.status(st, "vent", nil, "vent", "overheat above vent start, venting until below stop")
		end

		local wa = A.component(unit, "weapon_action")
		local action = wa and wa.current_action_name
		if type(action) == "string" and action:find("reload", 1, true) then
			return api.status(st, "reload", nil, "reloading", "reload action running")
		end
		if t >= (st.next_press_t or 0) then
			req.weapon_reload = true
			st.next_press_t = t + T("reload_press_interval_s")
		end
		return api.status(st, "reload", nil, "weapon_reload", "clip empty, reserve left")
	end,
}
