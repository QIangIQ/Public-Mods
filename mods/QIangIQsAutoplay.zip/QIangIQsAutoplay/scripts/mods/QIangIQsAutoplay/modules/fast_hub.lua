--[[
    Return to the hub fast.
    - Leaves the end screen at once (BornReady.lua:29-34 leave("skip_end_of_round"), no countdown).
    - The hub-server preconnect is InstantHub's (InstantHub.lua:1761-1851 mission-end
      preconnection). It needs a hub reservation latched at the title screen
      (InstantHub.lua:1341-1402) and about 1000 lines of preload code, so it is NOT
      ported. When InstantHub is enabled with preconnect_hub_server on, it runs alongside;
      the panel says which.
]]
return {
	name = "fast_hub",
	setting = "module_fast_hub",
	title = "Loop: fast return to hub",
	description = "Leaves the end screen immediately. Hub preconnect comes from InstantHub if it is installed and on (not ported).",
	where = "hub",
	init = function(api, st)
		api.on("end_view_enter", function()
			api.shared.left_end_view = nil
			local ih = api.other_mod_active("InstantHub", "preconnect_hub_server")
			local reason = ih and "InstantHub preconnect active" or "no preconnect (InstantHub off; not ported)"
			if Managers.ui and Managers.ui:view_active("end_view") then
				api.shared.left_end_view = true
				Managers.multiplayer_session:leave("skip_end_of_round")
				api.status(st, "left", "end_view", "leave now", reason)
			else
				api.status(st, "waiting", "end_view", "end_view not active yet", reason)
				st.pending = true
			end
		end)
		api.on("end_view_update", function()
			if st.pending and not api.shared.left_end_view and Managers.ui:view_active("end_view") then
				st.pending = nil
				api.shared.left_end_view = true
				Managers.multiplayer_session:leave("skip_end_of_round")
				api.status(st, "left", "end_view", "leave now", "end_view became active")
			end
		end)
	end,
	reset = function(api, st) st.pending = nil end,
	update = function(dt, t, ctx, req, st, api)
		if st.state == "idle" then api.status(st, "idle", "-", "waiting", "no end screen") end
	end,
}
