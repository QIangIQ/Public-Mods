--[[
    auto_path: walks the character to shared.nav_goal along a client-side nav mesh path.
    Reads   shared.nav_goal   = { pos = {x,y,z}, tol = metres or nil, owner = "<module>" }
    Writes  shared.nav_status = { state = "idle|pathing|moving|arrived|failed", reason = string, owner = ... }

    The path comes from api.nav_request / api.nav_poll (GwNavAStar on the client nav world). That A* is
    UNVERIFIED on a client (no source path creates one, research client.md section 1). When the request
    cannot be made, never finishes, or finds no path, the state is "failed" with the reason and the module
    does NOT walk toward the goal blind.

    Following: a node counts as reached by the bot rule (GAME bot_navigation_extension.lua:216-247):
    the character has passed it (dot product test), or it is inside a flat threshold that starts at
    move_to_flat_eps and ramps up to path_flat_max_m once the character lingers near the node, inside the
    z window. Input is move only, relative to the current yaw (api.move_toward); this module never aims.
    The last node scales the move input down near the goal (GAME bot_unit_input.lua:139-141, 322-325).
    Stall: moving slower than path_stall_speed_ms for path_stall_window_s rebuilds the path
    (window and repath count UNTUNED: no source).
]]

local mod = get_mod("QIangIQsAutoplay")
local H = mod:io_dofile("QIangIQsAutoplay/scripts/mods/QIangIQsAutoplay/modules/lib_dodge")

local NAME = "auto_path"

local function set_status(st, api, goal, state, reason)
	local ns = api.shared.nav_status
	if not ns or ns.state ~= state or ns.reason ~= reason or ns.owner ~= (goal and goal.owner) then
		api.shared.nav_status = { state = state, reason = reason, owner = goal and goal.owner }
	end
	api.status(st, state, goal and goal.owner, state, reason)
end

local function clear(api, st)
	if st.handle then api.nav_cancel(st.handle) end
	st.handle, st.nodes, st.idx, st.prev = nil, nil, nil, nil
	st.close_t, st.stall, st.goal, st.state = nil, nil, nil, nil
	st.repaths = 0
end

local function fail(st, api, goal, reason)
	if st.handle then api.nav_cancel(st.handle) end
	st.handle, st.nodes, st.idx = nil, nil, nil
	st.state, st.fail_reason = "failed", reason
	set_status(st, api, goal, "failed", reason)
end

-- GAME bot_navigation_extension.lua:222-247 (BotNavigationExtension._goal_reached)
local function node_reached(api, st, pos, node, prev, gt)
	local T = api.T
	local rx, ry, rz = node.x - pos.x, node.y - pos.y, node.z - pos.z
	local px, py, pz = node.x - prev.x, node.y - prev.y, node.z - prev.z
	local passed = rx * px + ry * py + rz * pz < 0
	local flat = math.sqrt(rx * rx + ry * ry)
	local base, top = T("move_to_flat_eps"), T("path_flat_max_m")
	local threshold = base
	if st.close_t then
		local ramp_speed = (top - base) / T("path_ramp_time_s")
		threshold = math.max(base, math.min(top, base + (gt - st.close_t - T("path_ramp_start_s")) * ramp_speed))
	end
	local at_goal = flat < threshold and rz > -T("path_z_below_m") and rz < T("path_z_above_m")
	local reached = passed or at_goal
	if reached then
		st.close_t = nil
	elseif flat < top and not st.close_t then
		st.close_t = gt
	end
	return reached
end

return {
	name = NAME,
	setting = "module_auto_path",
	title = "Navigation: walk to the nav goal",
	description = "Walks to shared.nav_goal on a client-side nav mesh path. Reports failed when the client cannot build a path; never walks blind.",

	init = function(api, st)
		st.repaths = 0
	end,

	reset = function(api, st)
		clear(api, st)
		api.shared.nav_status = { state = "idle", reason = "reset" }
	end,

	update = function(dt, t, ctx, req, st, api)
		local T = api.T
		local shared = api.shared
		local goal = shared.nav_goal
		local gt, pos = ctx.gt, ctx.pos

		-- no goal: idle
		if not goal or not goal.pos then
			if st.goal or st.handle then clear(api, st) end
			if not shared.nav_status or shared.nav_status.state ~= "idle" then
				shared.nav_status = { state = "idle", reason = "no goal" }
			end
			api.status(st, "idle", nil, "idle", "no goal")
			return
		end
		if not gt or not pos or not ctx.unit then return end

		-- new goal: start over
		local gp = goal.pos
		local g = st.goal
		if not g or g.x ~= gp.x or g.y ~= gp.y or g.z ~= gp.z then
			clear(api, st)
			st.goal = { x = gp.x, y = gp.y, z = gp.z }
			st.state = "pathing"
		end

		if st.state == "failed" then
			set_status(st, api, goal, "failed", st.fail_reason or "failed")
			return
		end

		-- arrival: goal.tol is a 3D distance, without it the bot epsilons (flat and z)
		local dx, dy, dz = gp.x - pos.x, gp.y - pos.y, gp.z - pos.z
		local flat = math.sqrt(dx * dx + dy * dy)
		local arrived
		if goal.tol then
			arrived = api.dist(pos, gp) <= goal.tol
		else
			arrived = flat <= T("move_to_flat_eps") and math.abs(dz) <= T("move_to_z_eps")
		end
		if arrived then
			if st.handle then api.nav_cancel(st.handle) end
			st.handle, st.nodes, st.idx, st.stall = nil, nil, nil, nil
			st.state = "arrived"
			set_status(st, api, goal, "arrived", string.format("%.2f m from goal", flat))
			return
		end
		if st.state == "arrived" then st.state = "pathing" end

		-- request a path
		if st.state == "pathing" and not st.handle then
			local from = api.on_mesh(pos) or pos
			local to = api.unbox(gp)
			to = api.on_mesh(to) or to
			local h, err = api.nav_request(from, to)
			if not h then
				fail(st, api, goal, err or "nav_request failed")
				return
			end
			st.handle, st.request_t = h, gt
		end

		if st.handle then
			local res, a = api.nav_poll(st.handle)
			if res == "pending" then
				if gt - st.request_t > T("path_request_timeout_s") then
					fail(st, api, goal, "A* request still pending (client A* unverified)")
					return
				end
				set_status(st, api, goal, "pathing", "waiting for A*")
				return
			elseif res == "failed" then
				st.handle = nil
				fail(st, api, goal, tostring(a))
				return
			end
			-- found
			st.handle = nil
			if not a or #a == 0 then
				fail(st, api, goal, "A* returned an empty path")
				return
			end
			st.nodes, st.idx, st.prev = a, 1, api.box(pos)
			st.close_t, st.stall, st.state = nil, nil, "moving"
		end

		if st.state ~= "moving" or not st.nodes then return end

		-- advance past the nodes that are reached
		local nodes = st.nodes
		while st.idx <= #nodes and node_reached(api, st, pos, nodes[st.idx], st.prev, gt) do
			st.prev = nodes[st.idx]
			st.idx = st.idx + 1
		end
		if st.idx > #nodes then
			-- end of the path: the goal must be inside the flat reach, else the path stopped short of it
			if flat <= (goal.tol or T("path_flat_max_m")) then
				st.nodes, st.state = nil, "arrived"
				set_status(st, api, goal, "arrived", string.format("path end, %.2f m from goal", flat))
			else
				fail(st, api, goal, string.format("path ended %.2f m from the goal", flat))
			end
			return
		end

		-- nothing to push while unable to act or while a defence routine owns the movement
		if not ctx.can_act or (shared.defending_until and shared.defending_until > gt) then
			st.stall = nil
			set_status(st, api, goal, "moving", "paused: " .. tostring(ctx.state))
			return
		end

		-- stall detection
		local ref = st.stall
		if not ref then
			st.stall = { x = pos.x, y = pos.y, t = gt }
		elseif gt - ref.t >= T("path_stall_window_s") then
			local moved = math.sqrt((pos.x - ref.x) * (pos.x - ref.x) + (pos.y - ref.y) * (pos.y - ref.y))
			st.stall = { x = pos.x, y = pos.y, t = gt }
			if moved < T("path_stall_speed_ms") * (gt - ref.t) then
				st.repaths = st.repaths + 1
				if st.repaths > T("path_max_repaths") then
					fail(st, api, goal, "stalled, re-path limit reached")
				else
					st.nodes, st.idx, st.state = nil, nil, "pathing"
					set_status(st, api, goal, "pathing", "stalled, re-pathing")
				end
				return
			end
		end

		-- move toward the current node
		local node = nodes[st.idx]
		local mx, my = node.x - pos.x, node.y - pos.y
		local mv = H.move_toward(ctx, mx, my) -- yaw taken as a number even if ctx.yaw is the orientation table
		if not mv then return end
		if st.idx == #nodes then
			local dsq = mx * mx + my * my
			if dsq < T("path_scale_dist_sq") then
				local scale = T("path_scale_factor") * dsq + T("path_scale_min")
				mv.x, mv.y = mv.x * scale, mv.y * scale
			end
		end
		req.move = mv
		set_status(st, api, goal, "moving", string.format("node %d of %d", st.idx, #nodes))
	end,
}
