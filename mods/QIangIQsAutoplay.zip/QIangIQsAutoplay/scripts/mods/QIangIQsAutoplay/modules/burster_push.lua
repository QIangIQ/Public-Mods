--[[
    burster_push: push a Poxburster away, then dodge away from it.
    Detection: every burst_scan_s, a chaos_poxwalker_bomber inside burst_detect_m that targets the local
    player (or is inside its blast radius), and that is closing in or already inside push range.
    Action: swap to melee if needed (cancelling a swing first), wait with melee out until the bomber is
    inside push range as the server will see it, block, push, dodge away, put the weapon back.
    Copied from QIangIQsAntiSpecialist burster.lua:14-95 (timings from AntiBursterPush) and core.lua:1381-1500.
]]

local mod = get_mod("QIangIQsAutoplay")
local H = mod:io_dofile("QIangIQsAutoplay/scripts/mods/QIangIQsAutoplay/modules/lib_dodge")

local NAME = "burster_push"
local BREED = "chaos_poxwalker_bomber" -- AS burster.lua:14

return {
	name = NAME,
	setting = "module_burster_push",
	title = "Havoc: push Poxbursters",
	description = "Pushes a Poxburster before it reaches you, then dodges away from the blast.",
	conflicts = {
		{ mod = "QIangIQsAntiSpecialist", setting = "burster_enabled", why = "AntiSpecialist already pushes Poxbursters" },
		{ mod = "AntiBursterPush", why = "AntiBursterPush already pushes Poxbursters (AS QIangIQsAntiSpecialist.lua:121)" },
	},

	init = function(api, st)
		st.pushed_at = setmetatable({}, { __mode = "k" })
		st.last_push = nil
		st.next_scan = 0
		st.scratch = {}
	end,

	reset = function(api, st)
		st.pushed_at = setmetatable({}, { __mode = "k" })
		st.last_push = nil
		st.next_scan = 0
		H.reset(api, st, NAME)
	end,

	update = function(dt, t, ctx, req, st, api)
		local T = api.T
		local gt, me = ctx.gt, ctx.unit
		if not gt or not me then return end
		local prio = T("dodge_priority_burster")

		if H.run(api, st, ctx, req, NAME, prio) then return end
		if st.routine or gt < st.next_scan then return end
		st.next_scan = gt + T("burst_scan_s")

		local detect = T("burst_detect_m")
		local count, units = api.enemies_near(me, ctx.pos, detect)
		local list = st.scratch
		for i = 1, count do list[i] = units[i] end
		for i = count + 1, #list do list[i] = nil end

		local push_at = H.push_radius(api, me)
		local delay = api.reaction_delay()
		local pick, pick_d
		for i = 1, count do
			local unit = list[i]
			if api.unit_ok(unit) and api.breed_name(unit) == BREED then
				local d, v = api.track(unit, ctx.pos, gt)
				local mine = H.cached_target(api, unit, gt) == me
				local seen = st.pushed_at[unit]
				local recent = (seen and gt - seen < T("burst_repush_s"))
					or (st.last_push and gt - st.last_push < T("burst_push_floor_s"))
				-- it targets me, or I am inside its blast radius whoever it wants (AS burster.lua:63)
				if not recent and (mine or d < T("burst_blast_m")) and (v > 0 or d < push_at) and (not pick or d < pick_d) then
					pick, pick_d = unit, d
				end
			end
		end
		if not pick then return end

		-- where the server will see it when the push lands: one reaction delay plus the block time ahead
		local function predicted(unit, now, pos)
			local d, v = api.track(unit, pos, now)
			return d - math.max(v, 0) * (delay + T("push_block_s"))
		end
		local function wait_fn(now, c)
			if not api.unit_ok(pick) then return "abort" end
			local pr = predicted(pick, now, c.pos)
			if pr <= H.push_radius(api, c.unit) then
				st.pushed_at[pick] = now
				st.last_push = now
				return true
			end
			return api.flat_dist(api.position(pick), c.pos) > detect and "abort" or false
		end

		local ok, why = H.begin(api, st, ctx, NAME, prio, "push", {
			threat = pick, wait_fn = wait_fn, label = "Poxburster push",
			then_dodge = { mode = "away", label = "Poxburster dodge away" },
		})
		if ok then
			api.status(st, "active", BREED, "push then dodge", "Poxburster closing")
		else
			api.status(st, "idle", BREED, "not started", tostring(why))
		end
	end,
}
