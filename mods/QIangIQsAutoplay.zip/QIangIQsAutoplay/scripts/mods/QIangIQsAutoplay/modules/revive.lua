--[[
    revive: walk to a downed / netted / ledge-hanging / hogtied ally (human or bot) and help.
    Copied from the stock bot AI (GAME = aussiemon_src, scripts/ relative):
      who needs help   bot_perception_extension.lua:472-528 (_calculate_ally_need_type): knocked_down, ledge, netted,
                       hogtied, each utility 100 (:466), so the nearest ally wins (distance priority, :429-433).
                       On a client the same four cases are read from the ally's PlayerInteracteeExtension:
                       interaction_type() = revive / remove_net / pull_up / rescue
                       (player_interactee_extension.lua, interactions/*_interaction.lua interactee_condition_func,
                       which read the ally's character_state and ledge_hanging_character_state).
      order            bot_behavior_tree.lua:12-35: revive, remove_net, pull_up, rescue (only matters for a tie).
      safety           monster near the ally or targeting you: bot_perception_extension.lua:343-347, 398-423;
                       ledge rescue is refused while an enemy within proximity targets you:
                       bt_bot_conditions.lua:111-136, :268. "Monster" = tracker kind boss (client-visible stand-in).
      approach         1 m from the ally (bot_behavior_extension.lua:809), ledge: 0.5 m behind (:797).
      input            interact_pressed once, then interact_hold every frame (bot_unit_input.lua:62-70), re-press every
                       3 s (bt_bot_interact_action.lua:7,69-77); lib_interact does this.
      hold times       revive 3 s, rescue 3 s, pull_up 3 s, remove_net 1 s (interaction_templates.lua:331,360,274,302);
                       shown as information only, the server decides the duration (buffs scale it).
    Not copied: "bots only help bots when no enemy is near, no priority target and toughness >= 0.2" (bot-to-bot rule,
    bot_perception_extension.lua:481-493) and "skip if someone else already helps" (covered by interactor can_interact).
]]

local NAME = "revive"
local Lib

local KINDS = { revive = true, remove_net = true, pull_up = true, rescue = true }
local WHAT = { revive = "knocked down", remove_net = "netted", pull_up = "ledge", rescue = "hogtied" }

local why_not = nil

-- Monster / threat checks (see header). Returns true when it is safe to go to this ally.
local function safe(e, ctx, api, a)
	local T = api.T
	local ally_hp = Lib.health(e.unit)
	why_not = nil
	for unit, info in pairs(api.enemies()) do
		if info.kind == "boss" and api.unit_ok(unit) then
			local mpos = api.position(unit)
			local target = api.target_of(unit)
			if target == ctx.unit then
				local dm = api.dist(ctx.pos, mpos)
				if dm * dm < T("sup_aid_monster_self_sq") then
					why_not = "boss targets me close by"
					return false
				end
			end
			if ally_hp and ally_hp > T("sup_aid_min_ally_health") then
				local rng = (a.unit == e.unit) and T("sup_aid_monster_current_ally_m") or T("sup_aid_monster_ally_m")
				if target == e.unit then rng = rng + T("sup_aid_monster_targeting_add_m") end
				if api.dist(e.pos, mpos) < rng then
					why_not = "boss next to ally"
					return false
				end
			end
		end
	end
	if e.kind == "pull_up" then
		local n, q = api.enemies_near(ctx.unit, ctx.pos, T("sup_proximity_enemy_m"))
		for i = 1, n do
			if api.target_of(q[i]) == ctx.unit then
				why_not = "enemy targets me (ledge)"
				return false
			end
		end
	end
	return true
end

-- Ledge: stand 0.5 m behind the hanging ally along its flat forward (bot_behavior_extension.lua:793-797).
local function ledge_goal(api, e)
	local rot = Unit.local_rotation(e.unit, 1)
	local fwd = Vector3.normalize(Vector3.flat(Quaternion.forward(rot)))
	return e.pos - fwd * api.T("sup_ledge_back_off_m")
end

return {
	name = NAME,
	setting = "module_revive",
	title = "Support: revive and rescue allies",
	description = "Walks to a knocked down, netted, ledge-hanging or hogtied ally (human or bot) and revives, frees, pulls up or rescues them, in the bots' order and with their safety checks.",
	init = function(api, st)
		Lib = get_mod("QIangIQsAutoplay"):io_dofile("QIangIQsAutoplay/scripts/mods/QIangIQsAutoplay/modules/lib_interact")
		st.ix = Lib.new(NAME)
	end,
	reset = function(api, st)
		if Lib and st.ix then Lib.release(api, st.ix) end
	end,
	update = function(dt, t, ctx, req, st, api)
		local a = st.ix
		if Lib.defending(ctx) then
			Lib.release(api, a)
			api.status(st, "yield", "-", "wait", "dodge or push running")
			return
		end
		if not Lib.usable(ctx) then
			Lib.release(api, a)
			api.status(st, "idle", "-", "wait", "cannot act: " .. tostring(ctx.state))
			return
		end

		why_not = nil
		local e = Lib.nearest(api, ctx, a, 0, KINDS, api.T("sup_ally_stickiness_m"), function(c)
			return safe(c, ctx, api, a)
		end)
		if not e then
			Lib.release(api, a)
			if why_not then
				api.status(st, "idle", "-", "wait", "ally needs help but " .. why_not)
			else
				api.status(st, "idle", "-", "none", "no ally needs help")
			end
			return
		end

		local opts = { aim_node = "j_head" }
		if e.kind == "pull_up" then opts.goal = ledge_goal(api, e) end
		-- hold time is information only (the server decides); read before drive() in case the unit goes away
		local hold = ("hold %.1f s"):format(e.ext:interaction_length())
		local target = ("%s %s, %.1f m"):format(WHAT[e.kind], tostring(api.breed_name(e.unit)), e.d)
		local res, progress = Lib.drive(ctx, req, api, a, e.unit, e.kind, opts)
		if res == "hold" and progress then target = target .. (", done %.2f"):format(progress) end
		api.status(st, "REVIVE", target, res, hold)
	end,
}
