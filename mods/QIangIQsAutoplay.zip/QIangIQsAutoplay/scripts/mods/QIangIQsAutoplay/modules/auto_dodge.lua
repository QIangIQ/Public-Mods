--[[
    auto_dodge: generic dodge against threats the specific modules do not cover.
    Signals (all client-visible): api.enemies() kind, api.target_of(unit) == local player,
    api.track closing speed, flat distance.
      elite   - a melee elite that targets me, closes in and is inside its reach  -> dodge across
      flamer  - a flamer that targets me inside its range                        -> dodge across, once per
                                                                                    beam duration
    Trapper, hound, bomber and mutant kinds are left to trapper_dodge / dog_push / burster_push / mutant_dodge.
    Not covered: grenadiers, snipers, plasma gunners, bosses (no client-visible timing signal found:
    their threat timing lives in the server behaviour tree).
    Gating copied from the bot melee dodge (GAME bt_bot_melee_action.lua:497-506): one check per
    adodge_rearm_s per threat, a failed check retries after adodge_fail_cooldown_s.
]]

local mod = get_mod("QIangIQsAutoplay")
local H = mod:io_dofile("QIangIQsAutoplay/scripts/mods/QIangIQsAutoplay/modules/lib_dodge")

local NAME = "auto_dodge"

return {
	name = NAME,
	setting = "module_auto_dodge",
	title = "Havoc: generic auto-dodge",
	description = "Dodges across when an elite closes inside melee reach or a flamer targets you, for threats the specific dodge modules do not cover.",

	init = function(api, st)
		st.next_check = setmetatable({}, { __mode = "k" })
		st.scratch = {}
	end,

	reset = function(api, st)
		st.next_check = setmetatable({}, { __mode = "k" })
		H.reset(api, st, NAME)
	end,

	update = function(dt, t, ctx, req, st, api)
		local T = api.T
		local gt, me = ctx.gt, ctx.unit
		if not gt or not me then return end
		local prio = T("dodge_priority_generic")

		if H.run(api, st, ctx, req, NAME, prio) then return end

		local reach, flame = T("adodge_melee_reach_m"), T("adodge_flamer_range_m")
		local count, units = api.enemies_near(me, ctx.pos, math.max(reach, flame))
		local list = st.scratch
		for i = 1, count do list[i] = units[i] end
		for i = count + 1, #list do list[i] = nil end

		local tracked = api.enemies()
		local pick, pick_kind, pick_d
		for i = 1, count do
			local unit = list[i]
			local info = api.unit_ok(unit) and tracked[unit]
			local kind = info and info.kind
			if (kind == "elite" or kind == "flamer") and gt >= (st.next_check[unit] or 0) then
				local d, v = api.track(unit, ctx.pos, gt)
				local hit = false
				if kind == "elite" then
					hit = d <= reach and v > 0
				else
					hit = d <= flame
				end
				if hit and H.cached_target(api, unit, gt) == me and (not pick or d < pick_d) then
					pick, pick_kind, pick_d = unit, kind, d
				end
			end
		end
		if not pick then return end

		local p = api.position(pick)
		local ok, why, retry = H.begin(api, st, ctx, NAME, prio, "dodge",
			{ from = { x = p.x, y = p.y }, mode = "across", ignore = pick, due = gt, label = "Dodge " .. pick_kind })
		local name = api.breed_name(pick)
		if ok then
			st.next_check[pick] = gt + (pick_kind == "flamer" and T("adodge_flamer_rearm_s") or T("adodge_rearm_s"))
			api.status(st, "active", name, "dodge", pick_kind .. " threat at " .. string.format("%.1f m", pick_d))
		elseif not retry then
			st.next_check[pick] = gt + T("adodge_fail_cooldown_s")
			api.status(st, "idle", name, "no safe dodge", tostring(why))
		end
	end,
}
