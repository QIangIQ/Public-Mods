--[[
    auto_melee: melee target choice, aim, light attacks, block and push.

    WIELD OWNERSHIP (shared by the three combat modules):
      auto_melee   owns wield_1 (slot_primary)
      auto_shoot   owns wield_2 (slot_secondary)
      reload_swap  presses no wield; it asks auto_shoot through shared.reload_want
    Each only presses a wield key while ctx.wielded is slot_primary, slot_secondary
    or slot_unarmed, so a relic channel, a grenade aim or a carried item is never cancelled.

    shared keys written here (documented in the report):
      shared.melee_claim = { unit, t }   refreshed every frame while a melee target is held.
        auto_shoot and reload_swap treat it as live when claim.t >= their own previous frame time.

    shared.ability_aim (written by abilities) is read: while live, no req.aim is written here.

    Melee-or-ranged choice: the bot's own target score (GAME bot_target_selection.lua melee
    distance weight 181-190, ranged distance weight 192-201, line of sight 203-215, current
    target 169; the winner rule is bot_target_selection_template.lua:78 "ranged score <
    melee score -> melee"). The slot weight, priority/opportunity weights and gestalt weights
    of that score are server-side bot state and are NOT reproduced: only the distance, line
    of sight and stickiness terms are.

    Block: the bot blocks while attack_intensity:num_melee_attackers() > 0 (GAME
    bt_bot_melee_action.lua:388-396). That counter is server-only, so the client proxy is
    "an enemy that targets me (api.target_of), is inside the contact range and is not
    retreating". Its thresholds are UNTUNED.

    Push: bt_bot_melee_action.lua:465-495 (in reach, push available, breed pushable,
    outnumbered, stamina > 1). "Push available" is not readable on a client; a cooldown
    (UNTUNED) stands in. Block 0.10 s then push 0.15 s: QIangIQsAntiSpecialist core.lua:759-760.

    Light attack: action_one_hold true, then false within 0.2 s
    (GAME default_melee_action_input_setup.lua:29-37). A hold of 0.25 s would be a heavy attack.
]]

local Breeds = require("scripts/settings/breed/breeds")
local Ammo = require("scripts/utilities/ammo")
local Stamina = require("scripts/utilities/attack/stamina")

local SLOT_MELEE, SLOT_RANGED, SLOT_NONE = "slot_primary", "slot_secondary", "slot_unarmed"
local NOT_EQUIPPED = "not_equipped"
local AIM_NODE = "j_spine" -- GAME bt_bot_melee_action.lua:253 default melee aim node
-- Specials whose attack is not a melee swing: they do not count as a blocking threat.
local NON_MELEE_KIND = { trapper = true, sniper = true, flamer = true, grenadier = true }

local A, T

-- GAME foundation/utilities/math.lua:62 math.ilerp (clamped)
local function ilerp(from, to, v)
	local lo, hi = math.min(from, to), math.max(from, to)
	if v < lo then v = lo elseif v > hi then v = hi end
	return (v - from) / (to - from)
end

local function tags_of(info)
	local b = info and Breeds[info.breed_name]
	return b and b.tags or nil
end

local function is_witch(info)
	local tags = tags_of(info)
	return tags and tags.witch and true or false
end

local function aim_point(unit)
	if Unit.has_node(unit, AIM_NODE) then
		return Unit.world_position(unit, Unit.node(unit, AIM_NODE))
	end
	return A.position(unit)
end

local function defending(ctx)
	local until_t = ctx.shared.defending_until
	return until_t ~= nil and ctx.gt ~= nil and ctx.gt < until_t
end

local function ranged_usable(unit)
	local inv = A.component(unit, "inventory")
	if not inv or inv.slot_secondary == NOT_EQUIPPED then return false end
	return Ammo.current_slot_clip_percentage(unit, SLOT_RANGED) > 0 or Ammo.current_slot_percentage(unit, SLOT_RANGED) > 0
end

-- Returns best melee candidate unit and whether the bot rule says "melee type".
local function evaluate(ctx, st)
	local me = ctx.pos
	local m_no, m_max = T("melee_dist_no_weight_m"), T("melee_dist_max_weight_m")
	local r_no, r_max = T("melee_ranged_no_weight_m"), T("melee_ranged_max_weight_m")
	local m_no2, m_max2 = m_no * m_no, m_max * m_max
	local r_no2, r_max2 = r_no * r_no, r_max * r_max
	local best_m, best_m_score = nil, 0
	local best_r, best_r_score = nil, 0
	for unit, info in pairs(A.enemies()) do
		if A.alive(unit) and not is_witch(info) then
			local p = A.position(unit)
			local dx, dy, dz = p.x - me.x, p.y - me.y, p.z - me.z
			local d2 = dx * dx + dy * dy + dz * dz
			local mw = T("melee_dist_weight") * ilerp(m_no2, m_max2, d2)
			if mw > 0 then
				if unit == st.target then mw = mw + T("melee_current_target_weight") end
				if mw > best_m_score then best_m, best_m_score = unit, mw end
			end
			local rw = T("melee_ranged_dist_weight") * ilerp(r_no2, r_max2, d2)
			if unit == st.ranged_unit then rw = rw + T("melee_current_target_weight") end
			if best_r == nil or rw > best_r_score then best_r, best_r_score = unit, rw end
		end
	end
	st.ranged_unit = best_r
	if not best_m then return nil, false end
	if best_r and ranged_usable(ctx.unit) then
		-- line of sight is evaluated for the best ranged candidate only (cost); the rest is approximated
		if A.has_los(ctx.eye, aim_point(best_r)) then best_r_score = best_r_score + T("melee_los_weight") end
	else
		best_r_score = 0
	end
	return best_m, best_r_score < best_m_score
end

local function threat_count(ctx, t)
	local me = ctx.pos
	local r = T("melee_block_range_m")
	local r2 = r * r
	local zmin, zmax = T("melee_z_min_m"), T("melee_z_max_m")
	local tol = T("melee_block_retreat_tolerance_mps")
	local n = 0
	for u, info in pairs(A.enemies()) do
		if not NON_MELEE_KIND[info.kind] and A.alive(u) then
			local p = A.position(u)
			local dx, dy, dz = p.x - me.x, p.y - me.y, p.z - me.z
			if dx * dx + dy * dy + dz * dz <= r2 and dz > zmin and dz < zmax and A.target_of(u) == ctx.unit then
				local _, v = A.track(u, me, t)
				if v > -tol then n = n + 1 end
			end
		end
	end
	return n
end

-- GAME bt_bot_melee_action.lua:465-481: breed known, not a monster
local function pushable(info)
	local tags = tags_of(info)
	return tags ~= nil and not tags.monster
end

-- GAME bt_bot_melee_action.lua:467-471 (the bot passes the target unit there; the player unit is meant)
local function stamina_now(unit)
	local ude = ScriptUnit.has_extension(unit, "unit_data_system")
	if not ude then return nil end
	local arch = ude:archetype()
	local current = Stamina.current_and_max_value(unit, ude:read_component("stamina"), arch.stamina)
	return current
end

local function stop(st, shared)
	st.phase = nil
	st.target = nil
	st.claimed = false
	st.threat_until = nil
	if shared and shared.melee_claim == st.claim_tbl then shared.melee_claim = nil end
end

return {
	name = "auto_melee",
	setting = "module_auto_melee",
	title = "Combat: auto melee",
	description = "Picks a melee target the way the game bots do, wields the melee weapon, turns to the target, swings light attacks in reach, blocks and pushes when enemies are on you.",
	conflicts = {},

	init = function(api, st)
		A, T = api, api.T
		st.claim_tbl = { unit = nil, t = 0 }
	end,

	reset = function(api, st)
		stop(st, api.shared)
	end,

	update = function(dt, t, ctx, req, st, api)
		A, T = api, api.T
		local shared = ctx.shared
		local unit = ctx.unit
		local prev = st.prev_t or ctx.t
		st.prev_t = ctx.t
		if not st.claim_tbl then st.claim_tbl = { unit = nil, t = 0 } end

		if not unit or not ctx.can_act or not ctx.gt or not ctx.eye or not ctx.pos then
			stop(st, shared)
			return api.status(st, "idle", nil, "wait", "no unit or cannot act")
		end
		if defending(ctx) then
			st.phase = nil
			return api.status(st, "hold-off", nil, "wait", "defensive routine running")
		end

		-- target choice, every melee_eval_s (bot_target_selection_template.lua:89) or when the target died
		if st.next_eval == nil or t >= st.next_eval or (st.target ~= nil and not A.alive(st.target)) then
			local best, claim = evaluate(ctx, st)
			st.target = claim and best or nil
			st.next_eval = t + T("melee_eval_s")
		end
		local target = st.target
		if not target then
			stop(st, shared)
			return api.status(st, "idle", nil, "wait", "no melee-type target")
		end

		if not st.claimed then
			st.claimed = true
			st.wield_next_t = t + T("melee_wield_first_s")
		end
		local claim = st.claim_tbl
		claim.unit, claim.t = target, ctx.t
		shared.melee_claim = claim

		local info = A.enemies()[target]
		local label = info and info.breed_name or "?"
		local aimp = aim_point(target)

		-- aim only with a weapon slot out (never over a grenade or relic aim) and not while abilities aims
		local w = ctx.wielded
		local weapon_out = w == SLOT_MELEE or w == SLOT_RANGED or w == SLOT_NONE
		local ability_aim = shared.ability_aim
		if weapon_out and not (ability_aim ~= nil and ability_aim.t >= prev) then
			req.aim = { pos = A.box(aimp) }
		end

		if w ~= SLOT_MELEE then
			st.phase = nil
			if (w == SLOT_RANGED or w == SLOT_NONE) and t >= st.wield_next_t then
				req.wield_1 = true
				st.wield_next_t = t + T("melee_wield_interval_s")
			end
			return api.status(st, "wield", label, "wield_1", "melee target, melee weapon not out")
		end

		local me = ctx.pos
		local ox, oy, oz = aimp.x - me.x, aimp.y - me.y, aimp.z - me.z
		local reach = T("melee_attack_range_m") + T("melee_hitbox_radius_m")
		local in_reach = (ox * ox + oy * oy + oz * oz) < reach * reach and oz > T("melee_z_min_m") and oz < T("melee_z_max_m")

		if threat_count(ctx, t) > 0 then st.threat_until = t + T("melee_block_hold_s") end
		local defend = st.threat_until ~= nil and t < st.threat_until

		local fs = A.fixed_step()

		-- push routine in progress: block, then push, never interrupted
		if st.phase == "push_block" then
			req.action_two_hold = true
			if t - st.phase_t >= math.max(T("melee_push_block_s"), fs) then
				st.phase, st.phase_t, st.press_sent = "push", t, false
			end
			return api.status(st, "push", label, "push", "blocking before the push")
		elseif st.phase == "push" then
			req.action_two_hold = true
			req.action_one_hold = true
			if not st.press_sent then
				req.action_one_pressed = true
				st.press_sent = true
			end
			if t - st.phase_t >= math.max(T("melee_push_press_s"), fs) then
				st.phase = nil
				st.push_ready_t = t + T("melee_push_gap_s")
			end
			return api.status(st, "push", label, "push", "block + action_one_pressed")
		end

		if defend then
			local outnumbered = A.enemies_near(unit, me, T("melee_proximity_radius_m")) > 1
			local stamina = stamina_now(unit)
			local can_push = in_reach and outnumbered and pushable(info) and stamina ~= nil
				and stamina > T("melee_low_stamina") and t >= (st.push_ready_t or 0)
			req.action_two_hold = true
			if can_push then
				st.phase, st.phase_t = "push_block", t
				return api.status(st, "push", label, "push", "outnumbered, in reach, stamina ok")
			end
			st.phase = nil
			return api.status(st, "block", label, "block", "melee attacker on me (client proxy)")
		end

		if in_reach then
			local hold_s = math.min(math.max(T("melee_hold_steps") * fs, fs), T("melee_light_window_s"))
			local release_s = math.max(T("melee_release_steps") * fs, fs)
			if st.phase ~= "hold" and st.phase ~= "release" then
				st.phase, st.phase_t = "hold", t
			end
			if st.phase == "hold" then
				req.action_one_hold = true
				if t - st.phase_t >= hold_s then st.phase, st.phase_t = "release", t end
			else
				req.action_one_hold = false
				if t - st.phase_t >= release_s then st.phase, st.phase_t = "hold", t end
			end
			return api.status(st, "attack", label, "light attack", "target in reach")
		end

		st.phase = nil
		return api.status(st, "aim", label, "face target", "target out of reach (movement is another module)")
	end,
}
