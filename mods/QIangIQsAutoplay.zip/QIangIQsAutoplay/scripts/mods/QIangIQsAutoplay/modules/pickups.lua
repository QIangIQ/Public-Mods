--[[
    pickups: walk to ammo / health / grenade pickups and take them. Copied from the bot AI (GAME scripts/ relative):
      ammo      trigger _update_ammo bot_behavior_extension.lua:262-281 (BX): total reserve ammo % < 0.75 (:245), or < 0.1
                (:246) while the bot has a target; here "has a target" = an enemy within 5 m (bot_perception_extension.lua:8,
                api.enemies_near). Total ammo % = sum(current_ammunition_reserve) / sum(max_ammunition_reserve) over the
                weapon slots (scripts/utilities/ammo.lua:404-426). Range 5 m (bot_group.lua:1232), stickiness 2.5 m (:1234).
                Whether a pile can be used (your ammo is not full) is answered by interactor can_interact
                (ammunition_interaction.lua interactor_condition_func).
                Not done: "only the player with the lowest ammo % fetches it" (BX:262-281 compares with every human):
                a client cannot rely on the other players' slot components, and a human autoplay should not wait for a bot.
      health    trigger _update_health_deployables BX:285-299: damage_taken - permanent_damage_taken > 0. Range 10 m
                (bot_group.lua:1235). Interaction type "health" (interaction_templates.lua:94-102, heals only when damaged:
                health_interaction.lua). Bots never act on it (BX:131), so this is the bots' numbers without the bots' bug.
      grenade   interaction type "grenade" (interaction_templates.lua:85-93; usable only when grenade charges are not full:
                grenade_interaction.lua). Bots have no grenade rule; the only grenade-slot range is the mule pickup range
                400 m^2 (bot_group.lua:1370), used as an analogue.
      approach  1 m from the pickup (bot_behavior_extension.lua:749-750).
    Skipped on purpose: pocketable (swaps your slot item), deployable_marker (its condition is always false).
]]

local NAME = "pickups"
local Lib

local KINDS = { ammunition = true, grenade = true, health = true }

-- Ammo % over the weapon slots (GAME scripts/utilities/ammo.lua:404-426).
local function ammo_percentage(unit, api)
	local vl = ScriptUnit.has_extension(unit, "visual_loadout_system")
	local cfg = vl and vl:slot_configuration_by_type("weapon")
	if not cfg then return 1 end
	local cur, max = 0, 0
	for slot_name in pairs(cfg) do
		local c = api.component(unit, slot_name)
		if c then
			cur = cur + c.current_ammunition_reserve
			max = max + c.max_ammunition_reserve
		end
	end
	if max > 0 then return cur / max end
	return 1
end

return {
	name = NAME,
	setting = "module_pickups",
	title = "Support: pick up ammo, health and grenades",
	description = "Walks to ammo (when under 75 percent, 10 percent with an enemy within 5 m), health (when you have healable damage) and grenade pickups nearby and takes them, using the bots' ranges.",
	init = function(api, st)
		Lib = get_mod("QIangIQsAutoplay"):io_dofile("QIangIQsAutoplay/scripts/mods/QIangIQsAutoplay/modules/lib_interact")
		st.ix = Lib.new(NAME)
	end,
	reset = function(api, st)
		if Lib and st.ix then Lib.release(api, st.ix) end
	end,
	update = function(dt, t, ctx, req, st, api)
		local T = api.T
		local a = st.ix
		if Lib.defending(ctx) then
			Lib.release(api, a)
			api.status(st, "yield", "-", "wait", "dodge or push running")
			return
		end
		if not Lib.usable(ctx) then
			Lib.release(api, a)
			api.status(st, "idle", "-", "wait", "cannot act: " .. tostring(ctx.state))
			return
		end
		if Lib.held_by_higher(api, ctx, NAME) then
			Lib.release(api, a)
			api.status(st, "idle", "-", "wait", "another support module is interacting")
			return
		end

		local ammo = ammo_percentage(ctx.unit, api)
		local enemies = api.enemies_near(ctx.unit, ctx.pos, T("sup_proximity_enemy_m"))
		local need = enemies > 0 and T("sup_ammo_need_combat") or T("sup_ammo_need")
		local _, _, dmg, perm = Lib.health(ctx.unit)
		local healable = (dmg or 0) - (perm or 0)

		local radius = math.max(T("sup_ammo_range_m"), T("sup_health_pickup_range_m"), math.sqrt(T("sup_grenade_range_sq")))

		local function accept(e)
			if e.kind == "ammunition" then
				return e.d <= T("sup_ammo_range_m") and ammo < need
			elseif e.kind == "health" then
				return e.d <= T("sup_health_pickup_range_m") and healable > 0
			end
			return e.d * e.d < T("sup_grenade_range_sq")
		end

		local e = Lib.nearest(api, ctx, a, radius, KINDS, T("sup_ammo_stickiness_m"), accept)
		if not e then
			Lib.release(api, a)
			api.status(st, "idle", ("ammo %.2f (needs < %.2f)"):format(ammo, need), "none", "no pickup wanted in range")
			return
		end

		local target = ("%s, %.1f m, ammo %.2f"):format(e.kind, e.d, ammo)
		local res = Lib.drive(ctx, req, api, a, e.unit, e.kind)
		api.status(st, "PICKUP", target, res, e.kind)
	end,
}
