--[[
    dog_push: meet a Pox Hound's leap with a push, or a dodge when melee is not out.
    Detection (two paths, both client-visible):
      speed path  - a chaos_hound / chaos_armored_hound inside the leap range that targets the local
                    player (api.target_of) and closes in at leap speed (api.track). Works with nothing learned.
      wind-up path - minion_anim_event(unit, index): once an anim number is known to be the leap wind-up
                    (learned in memory by voting on the speed path, as AS does) the reaction starts at the
                    wind-up instead of at the leap.
    Action: melee out and the hound inside the push distance -> push (block 0.10 s, push 0.15 s);
    otherwise dodge across its line so that it arrives in the middle of the dodge.
    Copied from QIangIQsAntiSpecialist hound.lua:20-300.
]]

local mod = get_mod("QIangIQsAutoplay")
local H = mod:io_dofile("QIangIQsAutoplay/scripts/mods/QIangIQsAutoplay/modules/lib_dodge")

local NAME = "dog_push"
local BREEDS = { chaos_hound = true, chaos_armored_hound = true } -- AS hound.lua:20

-- keys are strings ("i12") so a saved table could never turn into an array (AS hound.lua:47)
local function windup_of(st, breed, index)
	local l = st.learned[breed]
	return l and l["i" .. tostring(index)]
end

local function learn(api, st, breed, index, windup, how)
	st.learned[breed] = st.learned[breed] or {}
	local key = "i" .. tostring(index)
	if st.learned[breed][key] == nil then
		st.learned[breed][key] = windup
		api.log(NAME, "info", "hound wind-up number %d learned for %s (%s)", index, breed, how)
	end
end

-- A leap seen from speed: the number that came a wind-up earlier is probably the wind-up (AS hound.lua:205-244)
local function vote(api, st, unit, breed, gt)
	local T = api.T
	if st.learned[breed] and next(st.learned[breed]) then return end
	local list = st.recent[unit]
	if not list then return end
	local v = st.votes[breed]
	if not v then
		v = { leaps = 0, count = {} }
		st.votes[breed] = v
	end
	v.leaps = v.leaps + 1

	local lo = T("hound_windup_long_s")
	local hi = T("hound_windup_short_s") + T("hound_vote_extra_s")
	local seen = {} -- one vote per number per leap
	for _, e in ipairs(list) do
		local dt = gt - e.t
		if dt >= lo and dt <= hi and not seen[e.index] then
			seen[e.index] = true
			v.count[e.index] = (v.count[e.index] or 0) + 1
		end
	end

	local best, best_n, second_n = nil, 0, 0
	for index, n in pairs(v.count) do
		if n > best_n then
			best, best_n, second_n = index, n, best_n
		elseif n > second_n then
			second_n = n
		end
	end
	if best and best_n >= T("hound_votes_needed") and best_n >= T("hound_vote_margin") * second_n then
		learn(api, st, breed, best, lo, "learned from " .. best_n .. " of " .. v.leaps .. " leaps")
	end
end

local function on_anim(api, st, unit, index)
	if not st.live or type(index) ~= "number" or not api.unit_ok(unit) then return end
	local breed = api.breed_name(unit)
	if not BREEDS[breed] then return end
	local t = api.time()
	if not t then return end
	local list = st.recent[unit]
	if not list then
		list = {}
		st.recent[unit] = list
	end
	list[#list + 1] = { index = index, t = t }
	if #list > 8 then table.remove(list, 1) end -- struct: memory of the last few numbers per hound (storage size only, AS hound.lua:446)
	local windup = windup_of(st, breed, index)
	if windup then st.windups[unit] = { t = t, windup = windup } end
end

return {
	name = NAME,
	setting = "module_dog_push",
	title = "Havoc: push or dodge Pox Hounds",
	description = "Pushes a leaping Pox Hound when melee is out and it is close, else dodges across its line.",
	conflicts = {
		{ mod = "QIangIQsAntiSpecialist", setting = "hound_enabled", why = "AntiSpecialist already handles Pox Hounds" },
	},

	init = function(api, st)
		st.handled = setmetatable({}, { __mode = "k" })
		st.windup_handled = setmetatable({}, { __mode = "k" })
		st.recent = setmetatable({}, { __mode = "k" })
		st.voted = setmetatable({}, { __mode = "k" })
		st.learned, st.votes = {}, {}
		st.windups, st.pending = {}, {}
		st.scratch = {}
		api.on("minion_anim_event", function(unit, event_index)
			on_anim(api, st, unit, event_index)
		end)
	end,

	-- learned wind-up numbers are kept (in memory) across resets; everything per-fight is dropped
	reset = function(api, st)
		st.live = false
		st.handled = setmetatable({}, { __mode = "k" })
		st.windup_handled = setmetatable({}, { __mode = "k" })
		st.recent = setmetatable({}, { __mode = "k" })
		st.voted = setmetatable({}, { __mode = "k" })
		st.windups, st.pending = {}, {}
		H.reset(api, st, NAME)
	end,

	update = function(dt, t, ctx, req, st, api)
		local T = api.T
		local gt, me = ctx.gt, ctx.unit
		st.live = true
		if not gt or not me then return end
		local prio = T("dodge_priority_hound")
		local busy = H.run(api, st, ctx, req, NAME, prio)
		local melee = ctx.wielded == "slot_primary"
		local delay = api.reaction_delay()

		local function push(unit, label)
			local ok, why, retry = H.begin(api, st, ctx, NAME, prio, "push", { threat = unit, interrupt = false, label = label })
			if ok then
				st.handled[unit] = gt
				busy = true
				api.status(st, "active", api.breed_name(unit), "push", label)
			end
			return ok
		end
		local function dodge(unit, due, label)
			local p = api.position(unit)
			local ok, why, retry = H.begin(api, st, ctx, NAME, prio, "dodge",
				{ from = { x = p.x, y = p.y }, mode = "across", ignore = unit, due = due, label = label })
			if ok then
				st.handled[unit] = gt
				busy = true
				api.status(st, "active", api.breed_name(unit), "dodge", label)
			elseif not retry then
				st.handled[unit] = gt
				api.status(st, "idle", api.breed_name(unit), "no safe dodge", tostring(why))
			end
			return ok, retry
		end

		-- wind-up path: an anim number known to be the leap wind-up (AS hound.lua:96-141)
		for unit, w in pairs(st.windups) do
			st.windups[unit] = nil
			local seen = st.windup_handled[unit]
			if api.unit_ok(unit) and not (seen and gt - seen < T("hound_cooldown_s")) and H.cached_target(api, unit, gt) == me then
				local d = api.flat_dist(api.position(unit), ctx.pos)
				if d <= T("hound_leap_range_m") + T("hound_margin_m") then
					st.windup_handled[unit] = gt
					api.log(NAME, "info", "hound wind-up seen at %.1f m", d)
					if melee and d <= T("hound_push_distance_m") and d <= H.push_radius(api, me) + T("hound_margin_m") then
						if not busy then push(unit, "Hound push (wind-up)") end
					elseif not melee then
						-- arrival = wind-up + distance / leap speed, put in the middle of the dodge (AS hound.lua:134)
						local due = gt + w.windup + d / T("hound_leap_speed_ms") - delay - T("hound_arrival_s")
						st.pending[unit] = { due = due, expire = due + H.press_window(api) }
						st.handled[unit] = gt
					end
				end
			end
		end

		-- dodges planned from a wind-up
		for unit, p in pairs(st.pending) do
			if not api.unit_ok(unit) or gt > p.expire then
				st.pending[unit] = nil
			elseif not busy and gt >= p.due - T("dodge_pre_move_steps") * api.fixed_step() then
				local ok, retry = dodge(unit, p.due, "Hound dodge (wind-up)")
				if ok or not retry then st.pending[unit] = nil end
			end
		end

		-- speed path (AS hound.lua:246-300). Copy the shared broadphase buffer first.
		local count, units = api.enemies_near(me, ctx.pos, T("hound_leap_range_m"))
		local list = st.scratch
		for i = 1, count do list[i] = units[i] end
		for i = count + 1, #list do list[i] = nil end

		local pick, pick_kind, pick_d
		for i = 1, count do
			local unit = list[i]
			local breed = api.unit_ok(unit) and api.breed_name(unit)
			if BREEDS[breed] then
				local d, v = api.track(unit, ctx.pos, gt)
				local h = st.handled[unit]
				if h and gt - h > T("hound_cooldown_s") then -- pounce cooldown
					st.handled[unit] = nil
					h = nil
				end
				-- leaping at me: it targets me and closes in faster than it can run
				if v >= T("hound_trigger_speed_ms") and H.cached_target(api, unit, gt) == me then
					local voted = st.voted[unit]
					if not voted or gt - voted > T("hound_cooldown_s") then
						vote(api, st, unit, breed, gt)
						st.voted[unit] = gt
					end
					if not h then
						-- where the server will have it when my input arrives
						local server_d = d - v * delay
						local kind
						if melee and server_d - v * T("push_block_s") <= T("hound_push_distance_m") and server_d > 0 then
							kind = "push"
						elseif not melee and server_d / v <= T("hound_arrival_s") then
							kind = "dodge" -- arrival inside the first half of the dodge
						end
						if kind and (not pick or server_d < pick_d) then pick, pick_kind, pick_d = unit, kind, server_d end
					end
				end
			end
		end

		if pick and not busy then
			if pick_kind == "push" then
				push(pick, "Hound push")
			else
				dodge(pick, gt, "Hound dodge")
			end
		end
	end,
}
