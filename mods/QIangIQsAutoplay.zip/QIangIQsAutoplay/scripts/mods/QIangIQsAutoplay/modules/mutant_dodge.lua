--[[
    mutant_dodge: dodge the Mutant's charge.
    Detection: a cultist_mutant / cultist_mutant_mutator within range that targets the local player
    (api.target_of) and closes in faster than its run speed (api.track), or closes in while its
    "trigger_charge_sound" game-object field is up (api.game_object_field). Dodge when the position
    the server will see is inside the dodge distance.
    Copied from QIangIQsAntiSpecialist mutant.lua:14-66.
]]

local mod = get_mod("QIangIQsAutoplay")
local H = mod:io_dofile("QIangIQsAutoplay/scripts/mods/QIangIQsAutoplay/modules/lib_dodge")

local NAME = "mutant_dodge"
local BREEDS = { cultist_mutant = true, cultist_mutant_mutator = true } -- AS mutant.lua:14

return {
	name = NAME,
	setting = "module_mutant_dodge",
	title = "Havoc: dodge Mutant charge",
	description = "Dodges sideways when a Mutant charges at you, detected from its closing speed and charge sound flag.",
	conflicts = {
		{ mod = "QIangIQsAntiSpecialist", setting = "mutant_enabled", why = "AntiSpecialist already dodges Mutant charges" },
	},

	init = function(api, st)
		st.handled = setmetatable({}, { __mode = "k" })
		st.scratch = {}
	end,

	reset = function(api, st)
		st.handled = setmetatable({}, { __mode = "k" })
		H.reset(api, st, NAME)
	end,

	update = function(dt, t, ctx, req, st, api)
		local T = api.T
		local gt, me = ctx.gt, ctx.unit
		if not gt or not me then return end
		local prio = T("dodge_priority_mutant")

		if H.run(api, st, ctx, req, NAME, prio) then return end

		-- copy the shared broadphase buffer: choosing a dodge queries it again
		local count, units = api.enemies_near(me, ctx.pos, T("mutant_range_m"))
		local list = st.scratch
		for i = 1, count do list[i] = units[i] end
		for i = count + 1, #list do list[i] = nil end

		local pick, pick_d
		local delay = api.reaction_delay()
		for i = 1, count do
			local unit = list[i]
			if api.unit_ok(unit) and BREEDS[api.breed_name(unit)] then
				local d, v = api.track(unit, ctx.pos, gt)
				local h = st.handled[unit]
				if h and gt - h > T("mutant_rearm_s") then
					st.handled[unit] = nil
					h = nil
				end
				-- charging at me: closing at charge speed, or the charge sound flag is up, and it targets me
				if not h and (v > T("mutant_run_speed_ms") or (v > 0 and api.game_object_field(unit, "trigger_charge_sound")))
					and H.cached_target(api, unit, gt) == me then
					local server_d = d - v * delay
					if server_d <= T("mutant_dodge_m") and (not pick or d < pick_d) then
						pick, pick_d = unit, d
					end
				end
			end
		end
		if not pick then return end

		local p = api.position(pick)
		local ok, why, retry = H.begin(api, st, ctx, NAME, prio, "dodge",
			{ from = { x = p.x, y = p.y }, mode = "across", ignore = pick, due = gt, label = "Mutant dodge" })
		if ok then
			st.handled[pick] = gt
			api.status(st, "active", api.breed_name(pick), "dodge", "charge closing inside dodge distance")
		elseif not retry then
			st.handled[pick] = gt
			api.status(st, "idle", api.breed_name(pick), "no safe dodge", tostring(why))
		end
	end,
}
