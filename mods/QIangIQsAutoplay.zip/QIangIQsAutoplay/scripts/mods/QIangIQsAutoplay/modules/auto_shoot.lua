--[[
    auto_shoot: ranged target pick, aim, fire.

    WIELD OWNERSHIP: auto_shoot owns wield_2 (slot_secondary). auto_melee owns wield_1.
    reload_swap presses no wield and asks for the ranged weapon through shared.reload_want.
    wield_2 is only pressed while ctx.wielded is slot_primary or slot_unarmed.

    shared keys: reads shared.ability_aim (abilities) and shared.melee_claim (auto_melee) and shared.reload_want (reload_swap);
    writes shared.ranged_claim = { unit, t } while a ranged target is held and the bot
    ammo/overheat rule passes. A claim is live when claim.t >= the reader's previous frame time.

    Target picker copied from QIangIQsTarkAccount aim_core.lua (pick_best_target 419-473):
      candidates need a head position (j_head node, else HitZone center of mass "head"),
      distance in (0.1, max_range 40], in front of the camera, angle <= max_angle 30 deg,
      horde trash skipped (skip_horde default true), shield facing me skipped (cos > 0.82),
      score = (1 - angle/max_angle) * 10 + (1 - distance/max_range)  (aim_core.lua:293),
      line of sight (statics raycast, api.has_los) only tested for candidates that beat the best.
    Deviation: candidates come from the shared tracker (api.enemies()), not side.enemy_units_lookup.
    NOT ported: aim_targeting.best_zone_for (damage-profile x armour zone choice); head only.

    Fire rule = the game bot's (bot_behavior_tree.lua:94-99, 131-137; bt_bot_shoot_action.lua:21):
    reserve ammo above 0.5 (0 for specials/elites/bosses), overheat below 0.9 (low threshold;
    critical threshold for priority targets), 0.2 s aim time. Added by this mod: fire only while
    ctx.aim_owner == "auto_shoot", the target is the one aimed at last frame, ctx.aim_error is
    under aim_on_target_deg, line of sight is clear and the clip is not empty.
    action_one_hold stays down while firing; action_one_pressed is pulsed for semi-auto weapons.
]]

local Breeds = require("scripts/settings/breed/breeds")
local HitZone = require("scripts/utilities/attack/hit_zone")
local Ammo = require("scripts/utilities/ammo")
local Overheat = require("scripts/utilities/overheat")

local SLOT_MELEE, SLOT_RANGED, SLOT_NONE = "slot_primary", "slot_secondary", "slot_unarmed"
local NOT_EQUIPPED = "not_equipped"
local HEAD_NODE = "j_head" -- TK aim_core.lua:22 HEAD_NODE_NAME
local MODULE = "auto_shoot"

local A, T

local function defending(ctx)
	local until_t = ctx.shared.defending_until
	return until_t ~= nil and ctx.gt ~= nil and ctx.gt < until_t
end

local function live(claim, prev)
	return claim ~= nil and claim.t >= prev
end

local function head_pos(unit)
	if Unit.has_node(unit, HEAD_NODE) then
		return Unit.world_position(unit, Unit.node(unit, HEAD_NODE))
	end
	return HitZone.hit_zone_center_of_mass(unit, "head")
end

-- TK aim_core.lua:379-396 (_shield_blocks_snap)
local function shield_blocks(unit, eye)
	local sx = ScriptUnit.has_extension(unit, "shield_system")
	if not sx or not sx:is_blocking() then return false end
	local forward = Quaternion.forward(Unit.local_rotation(unit, 1))
	local to_cam = Vector3.normalize(eye - Unit.world_position(unit, 1))
	return Vector3.dot(forward, to_cam) > T("shoot_shield_arc_cos")
end

-- TK aim_core.lua:326-331 _is_horde_trash (+ _has_priority_tag :321-323)
local function is_horde_trash(tags)
	if not tags or not tags.horde then return false end
	return not (tags.elite or tags.special or tags.monster or tags.captain)
end

-- Returns best unit, its head position, whether it is a priority target.
local function pick_target(ctx)
	local eye = ctx.eye
	local max_range = T("shoot_max_range_m")
	local max_angle = math.rad(T("shoot_max_angle_deg"))
	local min_dist = T("shoot_min_dist_m")
	local angle_weight = T("shoot_angle_weight")
	local skip_horde = T("shoot_skip_horde") > 0
	-- camera forward from yaw/pitch (inverse of api.yaw_pitch_to: yaw = atan2(-x, y))
	local cp = math.cos(ctx.pitch)
	local fx, fy, fz = -math.sin(ctx.yaw) * cp, math.cos(ctx.yaw) * cp, math.sin(ctx.pitch)
	local best_score, best_unit, best_head, best_priority = -math.huge, nil, nil, false
	for unit, info in pairs(A.enemies()) do
		if A.alive(unit) then
			local breed = Breeds[info.breed_name]
			local tags = breed and breed.tags
			if not (tags and tags.witch) and not (skip_horde and is_horde_trash(tags)) then
				local head = head_pos(unit)
				if head then
					local dx, dy, dz = head.x - eye.x, head.y - eye.y, head.z - eye.z
					local dist = math.sqrt(dx * dx + dy * dy + dz * dz)
					if dist > min_dist and dist <= max_range then
						local dot = (fx * dx + fy * dy + fz * dz) / dist
						if dot > 0 then
							local angle = math.acos(math.min(dot, 1))
							if angle <= max_angle then
								local score = (1 - angle / max_angle) * angle_weight + (1 - dist / max_range)
								if score > best_score and not shield_blocks(unit, eye) and A.has_los(eye, head) then
									best_score, best_unit, best_head = score, unit, head
									best_priority = info.kind ~= "other"
								end
							end
						end
					end
				end
			end
		end
	end
	return best_unit, best_head, best_priority
end

-- Bot ammo / overheat rule. Returns ok, reason.
local function ranged_ok(unit, priority)
	local inv = A.component(unit, "inventory")
	if not inv or inv.slot_secondary == NOT_EQUIPPED then return false, "no ranged weapon" end
	local floor = priority and T("shoot_ammo_pct_priority") or T("shoot_ammo_pct")
	if not (Ammo.current_slot_percentage(unit, SLOT_RANGED) > floor) then return false, "reserve ammo at or below " .. tostring(floor) end
	local limit_type = priority and "critical_threshold" or "low_threshold"
	if not (Overheat.slot_percentage(unit, SLOT_RANGED, limit_type) < T("shoot_overheat_limit")) then return false, "overheated" end
	-- psyker staffs and warp weapons: no ammo or overheat component applies, peril does (AbilityGod reads the same component)
	local wc = A.component(unit, "warp_charge")
	if wc and wc.current_percentage >= T("shoot_warp_limit") then return false, "warp charge at limit" end
	return true, "ok"
end

local function stop(st, shared)
	st.target = nil
	st.aimed = nil
	st.claimed = false
	if shared and shared.ranged_claim == st.claim_tbl then shared.ranged_claim = nil end
end

return {
	name = MODULE,
	setting = "module_auto_shoot",
	title = "Combat: auto shoot",
	description = "Picks a ranged target with the QIangIQsTarkAccount rules, aims at its head, wields the ranged weapon and fires when aimed, using the game bots ammo and overheat limits.",
	conflicts = {
		{ mod = "QIangIQsTarkAccount", setting = "enabled", why = "TarkAccount hooks the same aim function and also picks targets" },
	},

	init = function(api, st)
		A, T = api, api.T
		st.claim_tbl = { unit = nil, t = 0 }
	end,

	reset = function(api, st)
		stop(st, api.shared)
	end,

	update = function(dt, t, ctx, req, st, api)
		A, T = api, api.T
		local shared = ctx.shared
		local unit = ctx.unit
		local prev = st.prev_t or ctx.t
		st.prev_t = ctx.t
		if not st.claim_tbl then st.claim_tbl = { unit = nil, t = 0 } end

		if not unit or not ctx.can_act or not ctx.gt or not ctx.eye or not ctx.yaw or not ctx.pitch then
			stop(st, shared)
			return api.status(st, "idle", nil, "wait", "no unit or cannot act")
		end
		if defending(ctx) then
			st.aimed = nil
			return api.status(st, "hold-off", nil, "wait", "defensive routine running")
		end
		if live(shared.melee_claim, prev) then
			stop(st, shared)
			return api.status(st, "yield", nil, "wait", "melee target held by auto_melee")
		end
		local wielded = ctx.wielded
		if wielded ~= SLOT_MELEE and wielded ~= SLOT_RANGED and wielded ~= SLOT_NONE then
			st.aimed = nil
			return api.status(st, "wait", nil, "wait", "another slot is in use: " .. tostring(wielded))
		end

		-- target pick: every shoot_retarget_s (bot_target_selection_template.lua:89), or when the target is gone
		local target = st.target
		if t >= (st.next_pick or 0) or (target ~= nil and not A.alive(target)) then
			local best, _, priority = pick_target(ctx)
			if best ~= target then st.target_since = t end
			st.target, st.priority = best, priority
			st.next_pick = t + T("shoot_retarget_s")
			target = best
		end

		local reload_live = live(shared.reload_want, prev)
		local ok, why = ranged_ok(unit, st.priority)

		-- wield_2: a usable target, or reload_swap needs the weapon out
		local want_weapon = (target ~= nil and ok) or reload_live
		if want_weapon and not st.claimed then
			st.claimed = true
			st.wield_next_t = t + T("shoot_wield_first_s")
		elseif not want_weapon then
			st.claimed = false
		end
		if want_weapon and wielded ~= SLOT_RANGED then
			st.aimed = nil
			if t >= st.wield_next_t then
				req.wield_2 = true
				st.wield_next_t = t + T("shoot_wield_interval_s")
			end
			return api.status(st, "wield", nil, "wield_2", "ranged weapon wanted (target or reload) and not out")
		end

		if target == nil then
			stop(st, shared)
			return api.status(st, "idle", nil, "wait", "no target in the cone")
		end
		local info = A.enemies()[target]
		local label = info and info.breed_name or "?"
		if wielded ~= SLOT_RANGED then
			return api.status(st, "idle", label, "wait", "ranged weapon not out (" .. why .. ")")
		end

		local head = head_pos(target)
		if not head then
			st.target = nil
			return api.status(st, "idle", label, "wait", "no head position")
		end

		local claim = st.claim_tbl
		if not ok then
			-- bot rule failed (ammo / overheat / warp): no claim, no aim, no fire
			if shared.ranged_claim == claim then shared.ranged_claim = nil end
			st.aimed = nil
			return api.status(st, "idle", label, "hold fire", why)
		end
		claim.unit, claim.t = target, ctx.t
		shared.ranged_claim = claim

		local ability_aim = shared.ability_aim
		if ability_aim ~= nil and ability_aim.t >= prev then
			st.aimed = nil
			return api.status(st, "yield", label, "wait", "abilities is aiming")
		end
		req.aim = { pos = A.box(head) }
		local aimed_last = st.aimed == target
		st.aimed = target

		if Ammo.current_slot_clip_percentage(unit, SLOT_RANGED) <= 0 then
			return api.status(st, "aim", label, "hold fire", "clip empty (reload_swap reloads)")
		end
		if t - (st.target_since or t) < T("shoot_aim_time_s") then
			return api.status(st, "aim", label, "hold fire", "aim time")
		end
		if ctx.aim_owner ~= MODULE or not aimed_last then
			return api.status(st, "aim", label, "hold fire", "aim not owned by auto_shoot yet (owner " .. tostring(ctx.aim_owner) .. ")")
		end
		if ctx.aim_error == nil or ctx.aim_error > math.rad(T("aim_on_target_deg")) then
			return api.status(st, "aim", label, "hold fire", "aim error above aim_on_target_deg")
		end
		if not A.has_los(ctx.eye, head) then
			return api.status(st, "aim", label, "hold fire", "no line of sight")
		end

		req.action_one_hold = true
		if t >= (st.next_press_t or 0) then
			req.action_one_pressed = true
			st.next_press_t = t + T("shoot_press_interval_s")
		end
		return api.status(st, "fire", label, "fire", "on target")
	end,
}
