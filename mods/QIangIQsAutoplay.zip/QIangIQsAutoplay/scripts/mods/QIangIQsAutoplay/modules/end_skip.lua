-- Skip the end-of-mission screen. Copied from BornReady.lua:29-69: on EndView enter
-- start a countdown of end_skip_time, then Managers.multiplayer_session:leave("skip_end_of_round")
-- while end_view is active. Hooks live in the core.
local function skip(api, st, why)
	if api.shared.left_end_view then return end
	if Managers.ui and Managers.ui:view_active("end_view") then
		api.shared.left_end_view = true
		Managers.multiplayer_session:leave("skip_end_of_round")
		api.status(st, "left", "end_view", "leave(skip_end_of_round)", why)
	end
end

return {
	name = "end_skip",
	setting = "module_end_skip",
	title = "Loop: skip end screen",
	description = "Leaves the end-of-mission screen after the BornReady delay.",
	where = "hub",
	conflicts = { { mod = "BornReady", setting = "autoskip", why = "BornReady already skips it" } },
	skip = skip,
	init = function(api, st)
		api.on("end_view_enter", function()
			api.shared.left_end_view = nil
			st.eom = api.T("end_skip_s")
			api.status(st, "countdown", "end_view", "wait", "end screen opened")
		end)
		api.on("end_view_update", function(view, dt)
			if not st.eom then return end
			st.eom = st.eom - dt
			if st.eom <= 0 then
				st.eom = nil
				skip(api, st, "countdown done")
			end
		end)
	end,
	reset = function(api, st) st.eom = nil end,
	update = function(dt, t, ctx, req, st, api)
		if st.state == "idle" then api.status(st, "idle", "-", "waiting", "no end screen") end
	end,
}
