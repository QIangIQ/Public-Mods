--[[
    medicae: use a health station (interaction type health_station, hold 3 s: GAME scripts/settings/interaction/
    interaction_templates.lua:113-125) when your own damage is high enough. Copied from the bot AI,
    scripts/extension_systems/behavior/bot_behavior_extension.lua (BX):
      need       _update_health_stations BX:307-380. total_damage_value = (1 - health%) + max(permanent_damage% * 3, 0)
                 (BX:359, grimoire term dropped: a client cannot cheaply see which players carry one, so num_grims = 0).
                 The bot goes when required < total_damage_value, required = 0.66 (BX:301) ramping linearly to 0.25
                 (BX:304) over 20 s (BX:303) of time spent near a station (BX:322-336).
                 "Near" is BX:327: distance * distance < 5625 where distance is the SQUARED distance to the closest
                 station (perception _select_next_health_station returns health_station_system.lua:170-184 squared
                 distance), so the stock bot effectively ramps only within about 8.7 m. Ported as written.
      go         BX:720: queue number <= station charges and squared distance < 400 (about 20 m).
                 Queue number = 1 + number of OTHER humans with total_damage_value * 2 > mine (BX:361-376).
      skip       game mode "survival" = Psykhanium (BX:320).
      own health GAME player_unit_health_extension.lua:139,166 / player_husk_health_extension.lua:73,100
                 (current_health_percent, permanent_damage_taken_percent) through the unit's health_system.
      approach   stand at station position minus its forward (BX:721-723); Matrix4x4.forward(Unit.world_pose(unit, 1)).
    Station type string: the unit template passes no interaction_type to InteracteeExtension
    (health_station_unit_template.lua:24-27); the level Interactable component sets it (components/interactable.lua:20,76),
    option "health_station" (interactable.lua:367-402). Unverified in a live level.
    Whether the station can be used (charges, you are damaged) is answered by interactor can_interact
    (health_station_interaction.lua interactor_condition_func).
]]

local NAME = "medicae"
local Lib

local KINDS = { health_station = true }

-- total_damage_value of BX:359 with no grimoires.
local function damage_value(api, unit)
	local hp, perm = Lib.health(unit)
	if not hp then return nil end
	return (1 - hp) + math.max(perm * api.T("sup_perm_damage_weight"), 0)
end

return {
	name = NAME,
	setting = "module_medicae",
	title = "Support: use health stations",
	description = "Walks to a medicae station and uses it when you are hurt enough, with the bots' threshold (0.66 of damage, falling to 0.25 the longer you stay near a station).",
	init = function(api, st)
		Lib = get_mod("QIangIQsAutoplay"):io_dofile("QIangIQsAutoplay/scripts/mods/QIangIQsAutoplay/modules/lib_interact")
		st.ix = Lib.new(NAME)
		st.prox_t = 0
	end,
	reset = function(api, st)
		if Lib and st.ix then Lib.release(api, st.ix) end
		st.prox_t = 0
	end,
	update = function(dt, t, ctx, req, st, api)
		local T = api.T
		local a = st.ix
		if Lib.defending(ctx) then
			Lib.release(api, a)
			api.status(st, "yield", "-", "wait", "dodge or push running")
			return
		end
		if not Lib.usable(ctx) then
			Lib.release(api, a)
			api.status(st, "idle", "-", "wait", "cannot act: " .. tostring(ctx.state))
			return
		end
		if Lib.held_by_higher(api, ctx, NAME) then
			Lib.release(api, a)
			api.status(st, "idle", "-", "wait", "another support module is interacting")
			return
		end
		if ctx.game_mode == "survival" then
			Lib.release(api, a)
			api.status(st, "idle", "-", "skip", "survival mode: bots skip health stations (BX:320)")
			return
		end

		local value = damage_value(api, ctx.unit)
		if not value then
			Lib.release(api, a)
			api.status(st, "idle", "-", "wait", "no health extension")
			return
		end

		-- Time near a station (BX:322-336): squared distance of the closest station, squared again as the bot does.
		local list = Lib.scan(ctx, api, math.sqrt(T("sup_station_prox_sq")))
		local nearest_d2
		for i = 1, #list do
			local e = list[i]
			if e.kind == "health_station" and (nearest_d2 == nil or e.d * e.d < nearest_d2) then
				nearest_d2 = e.d * e.d
			end
		end
		if nearest_d2 and nearest_d2 * nearest_d2 < T("sup_station_prox_sq") then
			st.prox_t = st.prox_t + dt
		else
			st.prox_t = 0
		end
		local base, floor = T("sup_station_need_base"), T("sup_station_need_floor")
		local frac = math.min(math.max(st.prox_t / T("sup_station_ramp_s"), 0), 1)
		local required = base - (base - floor) * frac

		local committed = a.kind == "health_station" and a.pressed_t ~= nil
		if not committed and value <= required then
			Lib.release(api, a)
			api.status(st, "idle", ("damage %.2f, needs > %.2f"):format(value, required), "none", "not hurt enough for a station")
			return
		end

		local function accept(e)
			if committed then return true end
			if e.d * e.d >= T("sup_station_max_dist_sq") then return false end
			local sx = ScriptUnit.has_extension(e.unit, "health_station_system")
			local charges = sx and sx:charge_amount() or 0
			local queue = 1
			for _, p in pairs(Managers.player:human_players()) do
				local hu = p.player_unit
				if hu and hu ~= ctx.unit and api.alive(hu) then
					local hv = damage_value(api, hu)
					if hv and value < hv * T("sup_queue_ratio") then queue = queue + 1 end
				end
			end
			return queue <= charges
		end

		local e = Lib.nearest(api, ctx, a, math.sqrt(T("sup_station_max_dist_sq")), KINDS, 0, accept)
		if not e then
			Lib.release(api, a)
			api.status(st, "idle", ("damage %.2f > %.2f"):format(value, required), "none", "no usable station in range")
			return
		end

		local pose = Unit.world_pose(e.unit, 1)
		local goal = e.pos - Matrix4x4.forward(pose)
		local hold = ("station hold %.1f s, server decides"):format(e.ext:interaction_length())
		local target = ("health station, %.1f m, damage %.2f > %.2f"):format(e.d, value, required)
		local res, progress = Lib.drive(ctx, req, api, a, e.unit, e.kind, { goal = goal })
		if res == "hold" and progress then target = target .. (", done %.2f"):format(progress) end
		api.status(st, "MEDICAE", target, res, hold)
	end,
}
