-- Auto yes-vote on the matchmaking vote. Copied from BornReady.lua:79-88
-- (cast_vote(voting_id, "yes") instead of showing the popup). The hook lives in the core.
return {
	name = "auto_vote",
	setting = "module_auto_vote",
	title = "Loop: vote yes",
	description = "Votes yes on the 'start matchmaking' vote and skips its popup (BornReady logic).",
	where = "hub",
	conflicts = { { mod = "BornReady", setting = "automatch", why = "BornReady already votes" } },
	init = function(api, st)
		api.on("vote_started", function(voting_id, result)
			Managers.voting:cast_vote(voting_id, "yes")
			result.handled = true
			api.status(st, "voted", tostring(voting_id), "yes", "matchmaking vote started")
		end)
	end,
	update = function(dt, t, ctx, req, st, api)
		if st.state == "idle" then api.status(st, "idle", "-", "waiting", "no vote") end
	end,
}
