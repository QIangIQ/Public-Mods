--[[
    chests: open chests in range. Bots never do (research bots.md section 9: no chest node in the bot tree,
    bt_bot_conditions.lua:279-299 can_loot only knows health_deployable / ammo_pickup / mule_pickup), so the range
    is UNTUNED (sup_chest_range_m).
    Interaction type "chest": GAME scripts/settings/interaction/interaction_templates.lua:27-35 (duration 0, class chest);
    ChestInteraction.interactor_condition_func is true only while the chest is not open (interactions/chest_interaction.lua).
    A locked chest has a block text (chest_extension.lua on_gameplay_post_init) so interactor can_interact refuses it.
    Approach distance 1 m: same offset the bots use for pickups (bot_behavior_extension.lua:749-750).
]]

local NAME = "chests"
local Lib

local KINDS = { chest = true }

return {
	name = NAME,
	setting = "module_chests",
	title = "Support: open chests",
	description = "Walks to unlocked chests within range and opens them. The range has no bot source and is an UNTUNED setting.",
	init = function(api, st)
		Lib = get_mod("QIangIQsAutoplay"):io_dofile("QIangIQsAutoplay/scripts/mods/QIangIQsAutoplay/modules/lib_interact")
		st.ix = Lib.new(NAME)
	end,
	reset = function(api, st)
		if Lib and st.ix then Lib.release(api, st.ix) end
	end,
	update = function(dt, t, ctx, req, st, api)
		local a = st.ix
		if Lib.defending(ctx) then
			Lib.release(api, a)
			api.status(st, "yield", "-", "wait", "dodge or push running")
			return
		end
		if not Lib.usable(ctx) then
			Lib.release(api, a)
			api.status(st, "idle", "-", "wait", "cannot act: " .. tostring(ctx.state))
			return
		end
		if Lib.held_by_higher(api, ctx, NAME) then
			Lib.release(api, a)
			api.status(st, "idle", "-", "wait", "another support module is interacting")
			return
		end

		local e = Lib.nearest(api, ctx, a, api.T("sup_chest_range_m"), KINDS, 0)
		if not e then
			Lib.release(api, a)
			api.status(st, "idle", "-", "none", "no closed chest in range")
			return
		end

		local target = ("chest, %.1f m"):format(e.d)
		local res = Lib.drive(ctx, req, api, a, e.unit, e.kind)
		api.status(st, "CHEST", target, res, "open")
	end,
}
