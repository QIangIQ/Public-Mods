--[[
    Ortus (Karnak twins, km_enforcer_twins) gold loop.

    HUB_WAIT -> START -> LOBBY -> SPAWN -> BELL -> TELEPORT -> PATH -> ELEVATOR -> DIE -> END -> HUB_WAIT
    Any step timeout, a peer leaving, master off or the emergency stop -> STOPPED (or IDLE).

    Sources:
    - Bells: twins_datamine REPORT.md section 6. Both are nurgle_bell_02 prop-health units;
      RIGHT = instance 2426e935dc272efd at (225.127, -161.508, 5.386), LEFT = ba6acfa7f993e710.
      Which is "right" was INFERRED from geometry (report); the choice is logged every run.
      Aim node c_bell_01 (from the bell .unit strings). Damage is server-side
      (GAME prop_health_extension.lua:228-270); the client reads replicated health (:161-165),
      so a health drop is logged as "hit registered".
    - Teleport: server flow FlowCallbacks.teleport_team_to_locations (GAME flow_callbacks.lua:2781-2830);
      the client sees rpc_client_set_local_player_orientation plus a position jump (core "teleported" event).
    - Elevator: civilian_elevator_6x6m_01_001 at (-210.029, -27.54, 21.995), prompt
      loc_interactable_elevator_controls, objective objective_km_enforcer_twins_elevator
      (GAME km_enforcer_objective_template.lua:62-65). Interact range 1.3 + 1.2 m
      (GAME interaction_settings.lua:9-10); press once then hold, re-press every 3 s like bots
      (GAME bt_bot_interact_action.lua:7).
    - "Die": no file describes how; the loop waits for death or mission end, with an optional
      leave fallback: Managers.multiplayer_session:leave("leave_mission") (GAME mechanism_adventure.lua:509).
    - Mission start: shared.start_request -> start_mission module (ManyMoreTry logic, private).
      Mission id: /autoplay_mission <id>, or captured from mechanism_data.backend_mission_id when a
      twins mission starts (ManyMoreTry.lua:67-80).
]]

local MISSION = "km_enforcer_twins"
local BELL_RESOURCE = "content/environment/artsets/imperial/nurgle/props/misc/nurgle_bell_02"
local BELL_NODE = "c_bell_01"
local ELEVATOR_RESOURCE = "content/environment/gameplay/moveable_platforms/civilian/civilian_elevator_6x6m_01"

local STEP_CODE = {
	IDLE = "I", HUB_WAIT = "H", START = "Q", LOBBY = "L", SPAWN = "S", BELL = "B",
	TELEPORT = "T", PATH = "P", ELEVATOR = "E", DIE = "D", END = "X", STOPPED = "Z",
}
local TIMEOUT = {
	HUB_WAIT = "ortus_timeout_hub_s", START = "ortus_timeout_start_s", LOBBY = "ortus_timeout_lobby_s",
	SPAWN = "ortus_timeout_spawn_s", BELL = "ortus_timeout_bell_s", TELEPORT = "ortus_timeout_teleport_s",
	PATH = "ortus_timeout_path_s", ELEVATOR = "ortus_timeout_elevator_s", DIE = "ortus_timeout_die_s",
	END = "ortus_timeout_end_s",
}

local mod = get_mod("QIangIQsAutoplay")

local function set_sync(api, st)
	local Sync = mod.Sync
	Sync.set("s", STEP_CODE[st.step] or "?")
	Sync.set("n", st.loops or 0)
	Sync.set("o", (mod:get("module_ortus_loop") and mod.state.master) and 1 or 0)
end

local function go(api, st, ctx_t, step, reason)
	if step ~= "STOPPED" and step ~= "IDLE" and not api.take_step() then
		st.pending = { step = step, reason = reason }
		return
	end
	st.pending = nil
	api.log("ortus_loop", "info", "%s -> %s (%s)", tostring(st.step), step, reason)
	st.step, st.step_t, st.step_reason = step, ctx_t, reason
	st.sub = {}
	set_sync(api, st)
end

local function stop(api, st, ctx_t, reason)
	if st.step == "STOPPED" then return end
	api.shared.nav_goal = (api.shared.nav_goal and api.shared.nav_goal.owner == "ortus_loop") and nil or api.shared.nav_goal
	api.shared.start_request = nil
	go(api, st, ctx_t, "STOPPED", reason)
	api.log("ortus_loop", "warn", "loop stopped: %s", reason)
end

-- Units with a given resource among entities of an extension class (no World.units sweep:
-- vault lesson-world-units-sweep-crash). Fallback: Level.units(level, true)
-- (GAME unit_spawner_manager.lua:846), also safe per the same lesson.
local function find_units(resource, extension_class)
	local out, seen = {}, {}
	local ext = Managers.state and Managers.state.extension
	if ext and ext.get_entities and extension_class then
		local ok, ents = pcall(ext.get_entities, ext, extension_class)
		if ok and type(ents) == "table" then
			for unit in pairs(ents) do
				local okis, is = pcall(Unit.is_a, unit, resource)
				if okis and is and not seen[unit] then
					seen[unit] = true
					out[#out + 1] = unit
				end
			end
		end
	end
	if #out == 0 then
		local mm = Managers.state and Managers.state.mission
		local okl, level = pcall(function() return mm and mm:mission_level() end)
		if okl and level then
			local oku, units = pcall(Level.units, level, true)
			if oku and type(units) == "table" then
				for i = 1, #units do
					local unit = units[i]
					local okis, is = pcall(Unit.is_a, unit, resource)
					if okis and is and not seen[unit] then
						seen[unit] = true
						out[#out + 1] = unit
					end
				end
			end
		end
	end
	return out
end

local function nearest(units, pos)
	local best, best_d
	for i = 1, #units do
		local d = Vector3.distance(Unit.world_position(units[i], 1), pos)
		if not best_d or d < best_d then best, best_d = units[i], d end
	end
	return best, best_d
end

local function bell_aim_point(bell)
	if Unit.has_node(bell, BELL_NODE) then
		return Unit.world_position(bell, Unit.node(bell, BELL_NODE)), BELL_NODE
	end
	return Unit.world_position(bell, 1), "unit origin"
end

local function health_of(unit)
	local h = ScriptUnit.has_extension(unit, "health_system")
	if not h or not h.current_health then return nil end
	local ok, v = pcall(h.current_health, h)
	return ok and v or nil
end

-- Peers that run the loop (o=1). Returns list of account ids (strings), and whether all are in step set.
local function loop_peers()
	local out = {}
	for id, p in pairs(mod.Sync.peers) do
		if mod.Sync.peer_ok(id) and p.fields and p.fields.o == "1" then out[#out + 1] = tostring(id) end
	end
	return out
end

-- Peers still in the party whose last known value has the loop on (no staleness check).
local function present_loop_peers()
	local n = 0
	for _, p in pairs(mod.Sync.peers) do
		if p.fields and p.fields.o ~= "0" then n = n + 1 end
	end
	return n
end

local function i_am_starter(peers)
	local me = tostring(mod.Sync.my_account_id())
	for i = 1, #peers do
		if peers[i] < me then return false end
	end
	return true
end

-- Steps -------------------------------------------------------------------------------

local S = {}

function S.IDLE(dt, t, ctx, req, st, api)
	api.status(st, "IDLE", "-", "arming", "module on")
	if ctx.where == "mission" then
		if ctx.mission == MISSION then
			go(api, st, t, "SPAWN", "armed inside the twins mission (test entry, no peer check)")
		else
			go(api, st, t, "STOPPED", "armed inside another mission: start from the hub")
		end
	else
		go(api, st, t, "HUB_WAIT", "armed outside a mission")
	end
end

function S.HUB_WAIT(dt, t, ctx, req, st, api)
	if ctx.where == "mission" then
		if ctx.mission == MISSION then
			go(api, st, t, "SPAWN", "already in the twins mission")
		else
			api.status(st, "HUB_WAIT", tostring(ctx.mission), "wait", "in another mission")
		end
		return
	end
	local id = mod:get("ortus_mission_id")
	if type(id) ~= "string" or #id == 0 then
		api.status(st, "HUB_WAIT", "-", "wait", "no mission id: /autoplay_mission <id> or play the twins mission once")
		return
	end
	local peers = loop_peers()
	if #peers < 1 then
		api.status(st, "HUB_WAIT", id, "wait", "need another party member with the Ortus loop on (private match)")
		return
	end
	st.peers_at_start = #peers
	if not i_am_starter(peers) then
		api.status(st, "HUB_WAIT", id, "follower", "the peer with the lowest account id starts")
		for pid, p in pairs(mod.Sync.peers) do
			local s = p.fields and p.fields.s
			if s == STEP_CODE.START or s == STEP_CODE.LOBBY then
				api.shared.private_queue = { t = t, by = "ortus follower" }
				go(api, st, t, "LOBBY", "starter " .. tostring(pid) .. " queued the mission")
				return
			end
		end
		return
	end
	if not mod:get("module_start_mission") then
		api.status(st, "HUB_WAIT", id, "wait", "turn on 'Loop: start mission'")
		return
	end
	api.shared.start_request = { id = id, owner = "ortus_loop" }
	api.shared.start_status = nil
	go(api, st, t, "START", "queue request sent")
end

function S.START(dt, t, ctx, req, st, api)
	local ss = api.shared.start_status
	if ss and ss.state == "failed" then
		stop(api, st, t, "start failed: " .. tostring(ss.reason))
		return
	end
	if ctx.where ~= "hub" then
		go(api, st, t, "LOBBY", "left the hub")
		return
	end
	api.status(st, "START", "start_mission", "wait", ss and ss.state or "requested")
end

function S.LOBBY(dt, t, ctx, req, st, api)
	if ctx.where == "mission" then
		if ctx.mission == MISSION then
			go(api, st, t, "SPAWN", "twins mission loaded")
		else
			stop(api, st, t, "loaded a different mission: " .. tostring(ctx.mission))
		end
		return
	end
	if not mod:get("module_auto_ready") and not api.other_mod_active("BornReady", "autoready") then
		api.status(st, "LOBBY", "-", "wait", "ready up yourself (auto_ready off)")
	else
		api.status(st, "LOBBY", "-", "wait", "waiting for the mission to load")
	end
end

function S.SPAWN(dt, t, ctx, req, st, api)
	if ctx.unit and ctx.can_act then
		st.humans_at_start = #mod.Gate.humans()
		go(api, st, t, "BELL", "player unit ready")
		return
	end
	api.status(st, "SPAWN", "-", "wait", "no controllable player unit (" .. tostring(ctx.state) .. ")")
end

function S.BELL(dt, t, ctx, req, st, api)
	local sub = st.sub
	if not ctx.unit then
		api.status(st, "BELL", "-", "wait", "no player unit")
		return
	end
	if not sub.bell then
		local right, left = api.T.vec("bell_right_pos"), api.T.vec("bell_left_pos")
		local tol = Vector3.distance(right, left) / (1 + 1) -- struct: half the distance between the two cited bells
		local bells = find_units(BELL_RESOURCE, "PropHealthExtension")
		local unit, d = nearest(bells, right)
		local lunit, ld = nearest(bells, left)
		api.log("ortus_loop", "info", "bell scan: %d nurgle_bell_02 units; nearest to RIGHT pos %.2f m, to LEFT pos %s m; tolerance %.2f m",
			#bells, d or -1, ld and ("%.2f"):format(ld) or "-", tol)
		if not unit or d > tol then
			stop(api, st, t, ("right bell not found within %.2f m of the cited position"):format(tol))
			return
		end
		if lunit == unit then
			stop(api, st, t, "right and left bell resolve to the same unit")
			return
		end
		local p = Unit.world_position(unit, 1)
		api.log("ortus_loop", "info", "CHOICE: right bell = unit at (%.2f, %.2f, %.2f) [cited 2426e935dc272efd]; left bell %s; RIGHT was inferred from geometry",
			p.x, p.y, p.z, lunit and "found" or "not found")
		sub.bell = unit
		st.teleport_seen = nil
		sub.health = health_of(unit)
		sub.next_fire = t
	end
	local bell = sub.bell
	if st.teleport_seen then
		go(api, st, t, "TELEPORT", "teleport happened while shooting")
		return
	end
	if not Unit.alive(bell) then
		go(api, st, t, "TELEPORT", "bell unit gone")
		return
	end
	local hp = health_of(bell)
	if hp and sub.health and hp < sub.health then
		sub.hits = (sub.hits or 0) + 1
		api.log("ortus_loop", "info", "bell hit registered: health %.1f -> %.1f (hit %d)", sub.health, hp, sub.hits)
	end
	sub.health = hp or sub.health

	local aim_pos, node = bell_aim_point(bell)
	if not api.has_los(ctx.eye, aim_pos) then
		if not mod:get("module_auto_path") then
			stop(api, st, t, "no line of sight to the bell and auto_path is off")
			return
		end
		local ns = api.shared.nav_status
		if ns and ns.owner == "ortus_loop" and ns.state == "failed" then
			stop(api, st, t, "path toward the bell failed: " .. tostring(ns.reason))
			return
		end
		if not sub.ground then
			-- The bell hangs above the floor; project onto the navmesh with the game's default
			-- search window (GAME nav_queries.lua:5).
			local g = api.on_mesh(aim_pos, api.T("nav_default_above"), api.T("nav_default_below"))
			if not g then
				stop(api, st, t, "no navmesh below the bell")
				return
			end
			sub.ground = api.box(g)
			api.log("ortus_loop", "info", "bell approach goal on navmesh (%.2f, %.2f, %.2f)", g.x, g.y, g.z)
		end
		api.shared.nav_goal = { pos = sub.ground, tol = api.T("bell_approach_tol_m"), owner = "ortus_loop" }
		api.status(st, "BELL", "right bell", "approach", "no line of sight from here")
		return
	end
	if api.shared.nav_goal and api.shared.nav_goal.owner == "ortus_loop" then api.shared.nav_goal = nil end

	req.aim = { pos = api.box(aim_pos) }
	if ctx.wielded ~= "slot_secondary" then
		if not sub.wield_t or t - sub.wield_t >= api.T("wield_retry_s") then
			req.wield_2 = true
			sub.wield_t = t
		end
		api.status(st, "BELL", "right bell", "wield ranged", "wielded " .. tostring(ctx.wielded))
		return
	end
	local on_target = ctx.aim_owner == "ortus_loop" and ctx.aim_error <= math.rad(api.T("aim_on_target_deg"))
	if not on_target then
		api.status(st, "BELL", "right bell (" .. node .. ")", "aiming", ("error %.1f deg"):format(math.deg(ctx.aim_error)))
		return
	end
	-- Fire pattern: hold, then release gap (both UNTUNED).
	if not sub.fire_until and t >= sub.next_fire then
		sub.fire_until = t + api.T("bell_fire_hold_s")
		sub.shots = (sub.shots or 0) + 1
		req.action_one_pressed = true
	end
	if sub.fire_until then
		if t < sub.fire_until then
			req.action_one_hold = true
		else
			sub.fire_until = nil
			req.action_one_hold = false
			req.action_one_release = true
			sub.next_fire = t + api.T("bell_fire_gap_s")
		end
	end
	api.status(st, "BELL", "right bell (" .. node .. ")", "fire", ("shots %d, hits %d"):format(sub.shots or 0, sub.hits or 0))
end

function S.TELEPORT(dt, t, ctx, req, st, api)
	if st.teleport_seen then
		st.teleport_seen = nil
		go(api, st, t, "PATH", "teleport confirmed")
		return
	end
	api.status(st, "TELEPORT", "-", "wait", "waiting for teleport_team_to_locations")
end

function S.PATH(dt, t, ctx, req, st, api)
	if not mod:get("module_auto_path") then
		stop(api, st, t, "auto_path module is off (no blind walking)")
		return
	end
	local goal = api.T.vec("elevator_pos")
	local g = api.shared.nav_goal
	if not g or g.owner ~= "ortus_loop" then
		api.shared.nav_goal = { pos = api.box(goal), tol = api.interact_range(), owner = "ortus_loop" }
		api.shared.nav_status = nil
	end
	local ns = api.shared.nav_status
	if ns and ns.owner == "ortus_loop" then
		if ns.state == "arrived" then
			api.shared.nav_goal = nil
			go(api, st, t, "ELEVATOR", "arrived at the elevator")
			return
		elseif ns.state == "failed" then
			stop(api, st, t, "path to elevator failed: " .. tostring(ns.reason))
			return
		end
	end
	local d = ctx.pos and api.dist(ctx.pos, goal) or -1
	api.status(st, "PATH", "elevator", ns and ns.state or "requested", ("%.1f m to go"):format(d))
end

function S.ELEVATOR(dt, t, ctx, req, st, api)
	local sub = st.sub
	if not ctx.unit then
		api.status(st, "ELEVATOR", "-", "wait", "no player unit")
		return
	end
	if not sub.elevator then
		local cited = api.T.vec("elevator_pos")
		local units = find_units(ELEVATOR_RESOURCE, "InteracteeExtension")
		local unit, d = nearest(units, cited)
		if not unit then
			stop(api, st, t, "elevator unit not found")
			return
		end
		sub.elevator = unit
		sub.start_z = Unit.world_position(unit, 1).z
		local ie = api.interactee(unit)
		local okt, itype = pcall(function() return ie and ie:interaction_type() end)
		api.log("ortus_loop", "info", "elevator: %d candidates, nearest %.2f m from cited pos, interaction_type=%s",
			#units, d, tostring(okt and itype or "?"))
	end
	local unit = sub.elevator
	local p = Unit.world_position(unit, 1)
	if math.abs(p.z - sub.start_z) > api.T("elevator_moved_m") then
		go(api, st, t, "DIE", "elevator is moving")
		return
	end
	local ie = api.interactee(unit)
	if sub.pressed and ie then
		local oka, active = pcall(ie.active, ie)
		if oka and active == false then
			go(api, st, t, "DIE", "elevator interaction no longer active")
			return
		end
	end
	local aim = Vector3(p.x, p.y, p.z + api.T("elevator_aim_up_m"))
	req.aim = { pos = api.box(aim) }
	local d = api.dist(ctx.pos, p)
	-- The engine's selected usable target is in the interaction component, not focus_unit
	-- (GAME interactor_extension.lua:472-480, player_unit_data_component_config.lua:1019-1027).
	local target, istate = api.interaction(ctx.unit)
	if target ~= unit then
		-- Not selected yet: step closer (inside the detection radius, GAME interaction_settings.lua:9).
		if api.flat_dist(ctx.pos, p) > api.T("interact_detection_radius") then
			req.move = api.move_toward(p.x - ctx.pos.x, p.y - ctx.pos.y)
		end
		api.status(st, "ELEVATOR", "elevator", "seek target", ("selected=%s state=%s, %.1f m"):format(tostring(target), tostring(istate), d))
		return
	end
	if not sub.pressed or t - sub.pressed >= api.T("interact_retry_s") then
		req.interact = true
		sub.pressed = t
	end
	req.interact_hold = true
	api.status(st, "ELEVATOR", "elevator", "interact", ("holding, %.1f m"):format(d))
end

function S.DIE(dt, t, ctx, req, st, api)
	if ctx.state == "dead" then
		go(api, st, t, "END", "player dead")
		return
	end
	api.status(st, "DIE", "-", "wait", "waiting for death or mission end (" .. tostring(ctx.state) .. ")")
end

function S.END(dt, t, ctx, req, st, api)
	if ctx.where == "hub" then
		st.loops = (st.loops or 0) + 1
		api.log("ortus_loop", "info", "loop %d complete", st.loops)
		go(api, st, t, "HUB_WAIT", "back in the hub")
		return
	end
	api.status(st, "END", "-", "wait", "returning to the hub")
end

function S.STOPPED(dt, t, ctx, req, st, api)
	api.status(st, "STOPPED", "-", "stopped", tostring(st.step_reason))
end

local function on_timeout(api, st, t)
	local id = TIMEOUT[st.step]
	if not id or not st.step_t then return false end
	if t - st.step_t <= api.T(id) then return false end
	if st.step == "DIE" and mod:get("ortus_leave_on_timeout") then
		api.log("ortus_loop", "warn", "DIE timed out: leaving the mission (leave_mission)")
		Managers.multiplayer_session:leave("leave_mission")
		go(api, st, t, "END", "left after DIE timeout")
		return true
	end
	stop(api, st, t, st.step .. " timed out after " .. api.T(id) .. " s")
	api.shared.private_queue = nil
	return true
end

return {
	name = "ortus_loop",
	setting = "module_ortus_loop",
	title = "Loop: Ortus (Karnak twins) gold loop",
	description = "Hub -> private twins mission -> shoot the right bell -> teleport -> elevator -> die -> repeat. Needs a second party member running Autoplay with this loop on.",
	where = "both",
	init = function(api, st)
		st.step, st.sub, st.loops = "IDLE", {}, 0
		api.on("teleported", function()
			if st.step == "TELEPORT" or st.step == "BELL" then
				st.teleport_seen = true
				api.log("ortus_loop", "info", "teleport seen during %s", st.step)
			end
		end)
		api.on("mission_ready", function()
			if not mod:get("module_ortus_loop") then return end
			if mod.Gate.mission_name() ~= MISSION then return end
			-- Capture the backend mission id like ManyMoreTry.lua:67-80.
			local mech = Managers.mechanism and Managers.mechanism._mechanism
			local data = mech and mech._mechanism_data
			if data and data.backend_mission_id then
				mod:set("ortus_mission_id", data.backend_mission_id, false)
				api.log("ortus_loop", "info", "captured twins mission id %s", tostring(data.backend_mission_id))
			end
		end)
		api.on("gameplay_exit", function()
			if st.step == "DIE" or st.step == "ELEVATOR" or st.step == "PATH" or st.step == "TELEPORT" or st.step == "BELL" or st.step == "SPAWN" then
				go(api, st, api.real_time(), "END", "left the mission during " .. st.step)
			end
		end)
		local function to_idle(why)
			st.step, st.sub, st.pending = "IDLE", {}, nil
			api.log("ortus_loop", "info", "reset to IDLE: %s", why)
			set_sync(api, st)
		end
		api.on("emergency_stop", function() to_idle("emergency stop") end)
		api.on("master", function(on) if not on then to_idle("master off") end end)
	end,
	reset = function(api, st)
		st.step, st.sub, st.pending = "IDLE", {}, nil
		if api.shared.nav_goal and api.shared.nav_goal.owner == "ortus_loop" then api.shared.nav_goal = nil end
	end,
	update = function(dt, t, ctx, req, st, api)
		set_sync(api, st)
		if st.pending then
			if api.take_step() then
				local p = st.pending
				st.pending = nil
				go(api, st, t, p.step, p.reason)
			else
				api.status(st, st.step, "-", "single-step", "waiting for /autoplay_step -> " .. tostring(st.pending.step))
				return
			end
		end
		if on_timeout(api, st, t) then return end
		-- A peer leaving stops the loop (both clients publish their step over presence).
		if st.peers_at_start and st.step ~= "STOPPED" and st.step ~= "IDLE" and st.step ~= "HUB_WAIT" then
			-- "left" = no longer a party member (Sync.poll drops it), "off" = o=0. Staleness is not
			-- used here: presence can lag through long loading screens.
			if present_loop_peers() < st.peers_at_start then
				stop(api, st, t, "the second player left or turned the loop off")
				return
			end
			if ctx.where == "mission" and st.humans_at_start and #mod.Gate.humans() < st.humans_at_start then
				stop(api, st, t, "a human left the mission")
				return
			end
		end
		local fn = S[st.step]
		if fn then fn(dt, t, ctx, req, st, api) end
	end,
}
