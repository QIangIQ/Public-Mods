-- Test module: only sets move forward, to prove that injected input reaches
-- the server (the character should walk forward on its own while the master
-- toggle and this module are both on). Off by default.
return {
	name = "hold_forward",
	setting = "module_hold_forward",
	title = "Test: hold forward",
	description = "Test module. Only presses move forward, to prove input injection reaches the server.",
	update = function(dt, t, ctx, req)
		if not ctx.player_unit then return end
		req.move = { x = 0, y = 1 }
	end,
}
