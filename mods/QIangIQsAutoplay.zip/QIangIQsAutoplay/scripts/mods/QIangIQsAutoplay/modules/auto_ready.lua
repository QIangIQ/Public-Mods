-- Auto-ready in the lobby. Copied from BornReady.lua:72-77 (LobbyView.on_enter ->
-- self:_set_own_player_ready_status(true)). The hook lives in the core.
return {
	name = "auto_ready",
	setting = "module_auto_ready",
	title = "Loop: auto-ready in lobby",
	description = "Marks you ready when the mission lobby opens (BornReady logic). Needs every party member to run Autoplay.",
	where = "hub",
	conflicts = { { mod = "BornReady", setting = "autoready", why = "BornReady already readies you" } },
	init = function(api, st)
		api.on("lobby_enter", function(view)
			view:_set_own_player_ready_status(true)
			api.status(st, "lobby", "self", "ready", "lobby opened")
		end)
	end,
	update = function(dt, t, ctx, req, st, api)
		if st.state == "idle" then api.status(st, "idle", "-", "waiting", "no lobby open") end
	end,
}
