--[[
    lib_interact.lua: shared interaction helper for revive / medicae / pickups / chests. NOT a module
    (the core's MODULE_ORDER does not list it). Modules load it in init with
        Lib = get_mod("QIangIQsAutoplay"):io_dofile("QIangIQsAutoplay/scripts/mods/QIangIQsAutoplay/modules/lib_interact")
    Every io_dofile returns a fresh copy, so nothing is kept in upvalues across modules: shared state lives in api.shared.

    How a client finds and uses an interactable (all GAME paths relative to scripts/):
      candidates  Managers.state.extension:system("interactee_system"):unit_to_extension_map()
                  (foundation/managers/extension/extension_system_base.lua:90). Units are InteracteeExtension
                  (pickups, chests, health stations: extension_systems/interaction/interactee_extension.lua) or
                  PlayerInteracteeExtension (players and bots: player_interactee_extension.lua; its
                  interaction_type() returns revive / remove_net / pull_up / rescue from the ally's character state).
                  Both have active() (interactee_extension.lua:262, player_interactee_extension.lua active) and
                  interaction_type() (interactee_extension.lua:266). Type strings are the template keys
                  (interaction_templates.lua, loop at the end sets template.type = key).
      validity    ScriptUnit.extension(me, "interactor_system"):can_interact(unit, type)
                  (interactor_extension.lua:752; bots use the same call, bt_bot_conditions.lua:293). It covers ammo
                  full, grenades full, health full, chest open or locked, station without charges, someone else
                  already using the target.
      focus       The engine picks the target in InteractorExtension.fixed_update (interactor_extension.lua:176-190):
                  direct raycast first (:451), then a cone test (:540). A target that CAN be used is written to the
                  `interaction` component (target_unit, type, state; player_unit_data_component_config.lua:1019-1027);
                  InteractorExtension.focus_unit (api.focus_unit) only holds a seen unit that can NOT be used
                  (interactor_extension.lua:217-224, :472-480). So this lib presses when
                  interaction.target_unit == unit and interaction.state == "waiting_to_interact", not on api.focus_unit.
      press       `interact` (one fixed frame) together with `interact_hold` on the same frame: _check_current_state
                  (:302-366) enters is_interacting and tests hold_required and not holding in the same step.
                  Keep interact_hold and the aim every frame while is_interacting. Durations: interaction_templates.lua.
      retry       if the press did not take within interact_retry_s: one frame without hold, then press again
                  (bt_bot_interact_action.lua:7,69-77).
      shared keys added (documented in the module report):
                  shared.interact_owner = { name, t }  one interaction at a time; priority revive > medicae > pickups > chests
                  shared.interact_scan  = { t, me, radius, list }  per-frame candidate cache
]]

local Lib = {}

-- Owner priority, highest first. Positions in this array are the only "numbers" used for ranking.
local ORDER = { "revive", "medicae", "pickups", "chests" }

-- Interaction type strings (interaction_templates.lua keys) this lib cares about.
local ALLY_KINDS = { revive = true, remove_net = true, pull_up = true, rescue = true }
local KINDS = {
	revive = true, remove_net = true, pull_up = true, rescue = true,
	health_station = true, ammunition = true, grenade = true, health = true, chest = true,
}
Lib.ALLY_KINDS = ALLY_KINDS

local function rank(name)
	for i = 1, #ORDER do
		if ORDER[i] == name then return i end
	end
	return #ORDER + 1
end

-- Per-module work state (create once in init).
function Lib.new(name)
	return { name = name, phase = "idle", tries = 0, bad = setmetatable({}, { __mode = "k" }) }
end

-- True while a dodge / push routine runs (CONTRACT: shared.defending_until, gameplay clock).
function Lib.defending(ctx)
	local limit = ctx.shared.defending_until
	return ctx.gt ~= nil and limit ~= nil and ctx.gt < limit
end

-- The character can start an interaction, or is in the interacting state (not in api ACT_STATES).
function Lib.usable(ctx)
	return ctx.unit ~= nil and ctx.pos ~= nil and ((ctx.can_act and true) or ctx.state == "interacting")
end

-- Drop nav goal, lock and target of this module.
function Lib.release(api, a)
	local sh = api.shared
	local g = sh.nav_goal
	if g and g.owner == a.name then sh.nav_goal = nil end
	local rec = sh.interact_owner
	if rec and rec.name == a.name then sh.interact_owner = nil end
	a.phase, a.unit, a.kind, a.pressed_t, a.nav_unit, a.nav_t, a.near_t, a.tries = "idle", nil, nil, nil, nil, nil, nil, 0
end

-- A higher-priority module of this family currently holds the interaction.
function Lib.held_by_higher(api, ctx, name)
	local rec = api.shared.interact_owner
	if not rec or rec.name == name then return false end
	if ctx.t - rec.t > api.T("interact_retry_s") then return false end
	return rank(rec.name) < rank(name)
end

local function claim(api, ctx, name)
	local sh = api.shared
	local rec = sh.interact_owner
	if rec and rec.name ~= name then
		local fresh = ctx.t - rec.t <= api.T("interact_retry_s")
		if fresh and rank(rec.name) < rank(name) then return false end
	end
	if rec and rec.name == name then
		rec.t = ctx.t
	else
		sh.interact_owner = { name = name, t = ctx.t }
	end
	return true
end

-- Scan ----------------------------------------------------------------------------------------------

-- Active interactees of the kinds above, within `radius` metres (ally kinds ignore the radius).
-- Cached per frame in api.shared.interact_scan; entries are { unit, kind, ext, pos, d }.
function Lib.scan(ctx, api, radius)
	local sh = api.shared
	local c = sh.interact_scan
	if c and c.t == ctx.t and c.me == ctx.unit and c.radius >= radius then return c.list end
	local list = {}
	local mgr = Managers.state and Managers.state.extension
	local sys = mgr and mgr:system("interactee_system")
	local map = sys and sys:unit_to_extension_map()
	if map then
		local me, pos = ctx.unit, ctx.pos
		local r2 = radius * radius
		for unit, ext in pairs(map) do
			if unit ~= me and ext:active() and api.unit_ok(unit) then
				local kind = ext:interaction_type()
				if KINDS[kind] then
					local p = api.position(unit)
					local dx, dy, dz = p.x - pos.x, p.y - pos.y, p.z - pos.z
					local d2 = dx * dx + dy * dy + dz * dz
					if ALLY_KINDS[kind] or d2 <= r2 then
						list[#list + 1] = { unit = unit, kind = kind, ext = ext, pos = p, d = math.sqrt(d2) }
					end
				end
			end
		end
	end
	sh.interact_scan = { t = ctx.t, me = ctx.unit, radius = radius, list = list }
	return list
end

-- Interactor says this target can be used now (see header).
function Lib.can(ctx, unit, kind)
	local ix = ScriptUnit.has_extension(ctx.unit, "interactor_system")
	return ix ~= nil and ix:can_interact(unit, kind) and true or false
end

-- Max interaction distance (GAME interactor_extension.lua:686-691; Ogryn values interactor_extension.lua:106-113).
function Lib.reach(api, ctx)
	if api.breed_name(ctx.unit) == "ogryn" then
		return api.T("sup_ogryn_detection_radius") + api.T("sup_ogryn_sphere_offset")
	end
	return api.interact_range()
end

function Lib.blocked(a, unit, t)
	local rec = a.bad[unit]
	return rec ~= nil and t < rec.untl
end

local function mark(a, unit, untl)
	a.bad[unit] = { untl = untl }
end

-- Nearest usable candidate of `kinds` (set of type strings). `stick` metres are subtracted from the current
-- target's distance so it is kept (GAME bot_group.lua:303-318 / :1269 stickiness). accept(e) is optional.
function Lib.nearest(api, ctx, a, radius, kinds, stick, accept)
	local list = Lib.scan(ctx, api, radius)
	local best, best_score
	for i = 1, #list do
		local e = list[i]
		if kinds[e.kind] and (ALLY_KINDS[e.kind] or e.d <= radius) and not Lib.blocked(a, e.unit, ctx.t)
			and (not accept or accept(e)) and Lib.can(ctx, e.unit, e.kind) then
			local score = e.d
			if a.unit == e.unit then score = score - stick end
			if not best or score < best_score then best, best_score = e, score end
		end
	end
	return best
end

-- Health of a player unit (works for the local unit and husks):
-- GAME player_unit_health_extension.lua:139,150,158,166 and player_husk_health_extension.lua:73,84,92,100.
-- Returns current_health_percent, permanent_damage_taken_percent, damage_taken, permanent_damage_taken (nil without extension).
function Lib.health(unit)
	local he = ScriptUnit.has_extension(unit, "health_system")
	if not he then return nil end
	return he:current_health_percent(), he:permanent_damage_taken_percent(), he:damage_taken(), he:permanent_damage_taken()
end

-- Drive ----------------------------------------------------------------------------------------------

local function aim_point(api, unit, node)
	if node and Unit.has_node(unit, node) then
		return api.box(Unit.world_position(unit, Unit.node(unit, node)))
	end
	return api.box(api.position(unit))
end

local function give_up(api, a, unit, ctx)
	mark(a, unit, ctx.t + api.T("sup_blacklist_s"))
	Lib.release(api, a)
	return "gave_up"
end

local function fail_once(api, a, unit, ctx)
	a.tries = a.tries + 1
	if a.tries >= api.T("sup_max_attempts") then return true end
	return false
end

-- Path towards the target through shared.nav_goal (auto_path consumes it). Only set when free or ours.
local function nav_step(ctx, api, a, unit, goal_pos)
	local T = api.T
	local sh = api.shared
	local g = sh.nav_goal
	if g and g.owner ~= a.name then return "nav_busy" end
	if a.nav_unit ~= unit or (g == nil and ctx.t - a.nav_t >= T("interact_retry_s")) then
		sh.nav_goal = { pos = api.box(goal_pos), tol = T("sup_direct_move_m"), owner = a.name }
		a.nav_unit, a.nav_t = unit, ctx.t
		return "nav"
	end
	local ns = sh.nav_status
	local mine = ns and ns.owner == a.name
	if mine and ns.state == "failed" then return "nav_failed" end
	if ctx.t - a.nav_t > T("interact_retry_s") and (not mine or ns.state == "idle") then return "nav_failed" end
	return "nav"
end

-- One frame of work on `unit` of type `kind`.
-- opts.aim_node  skeleton node to aim at (default: unit root)
-- opts.goal      Vector3 to walk to instead of the unit position (station front, ledge back)
-- Returns a result string (and a progress number for "hold"):
--   preempted | nav | nav_busy | approach | press | hold | settle | retry | reset | done | gone | gave_up | wait
function Lib.drive(ctx, req, api, a, unit, kind, opts)
	local T = api.T
	local sh = api.shared
	opts = opts or {}

	if not claim(api, ctx, a.name) then
		Lib.release(api, a)
		return "preempted"
	end

	if a.unit ~= unit or a.kind ~= kind then
		local g = sh.nav_goal
		if g and g.owner == a.name then sh.nav_goal = nil end
		a.unit, a.kind, a.phase = unit, kind, "go"
		a.pressed_t, a.nav_unit, a.nav_t, a.near_t, a.tries = nil, nil, nil, nil, 0
	end

	local comp = api.component(ctx.unit, "interaction")
	if not comp then return "wait" end

	local ext = api.interactee(unit)
	local valid = api.unit_ok(unit) and ext ~= nil and ext:active() and Lib.can(ctx, unit, kind)

	-- Target gone, used up or no longer usable: success when we had pressed, otherwise just gone.
	if not valid then
		local pressed = a.pressed_t ~= nil
		if pressed then mark(a, unit, ctx.t + T("interact_retry_s")) end
		Lib.release(api, a)
		return pressed and "done" or "gone"
	end

	local interacting = comp.state == "is_interacting" and comp.target_unit == unit
	local chosen = comp.state == "waiting_to_interact" and comp.target_unit == unit and comp.type == kind
	local pos = api.position(unit)
	local d = api.dist(ctx.pos, pos)
	local aim = { pos = aim_point(api, unit, opts.aim_node) }

	if interacting then
		a.phase = "hold"
		a.pressed_t = a.pressed_t or ctx.t
		local g = sh.nav_goal
		if g and g.owner == a.name then sh.nav_goal = nil end
		req.aim = aim
		local progress
		if ctx.gt and comp.start_time and comp.start_time ~= 0 and comp.duration and comp.duration > 0 then
			local elapsed = ctx.gt - comp.start_time
			progress = elapsed / comp.duration
			if elapsed > comp.duration + T("interact_retry_s") then
				-- overran its duration: release for one frame, then press again (bt_bot_interact_action.lua:69-77)
				a.pressed_t, a.phase = nil, "go"
				if fail_once(api, a, unit, ctx) then return give_up(api, a, unit, ctx) end
				return "reset"
			end
		end
		req.interact_hold = true
		return "hold", progress
	end

	if a.pressed_t then
		req.aim = aim
		if ctx.t - a.pressed_t < T("interact_retry_s") then
			req.interact_hold = true
			return "settle"
		end
		a.pressed_t, a.phase = nil, "go"
		if fail_once(api, a, unit, ctx) then return give_up(api, a, unit, ctx) end
		return "retry"
	end

	if d > T("sup_direct_move_m") then
		local r = nav_step(ctx, api, a, unit, opts.goal or pos)
		if r == "nav_failed" then return give_up(api, a, unit, ctx) end
		return r
	end

	local g = sh.nav_goal
	if g and g.owner == a.name then sh.nav_goal = nil end
	a.nav_unit = nil
	req.aim = aim

	if chosen then
		req.interact = true
		req.interact_hold = true
		a.pressed_t, a.phase = ctx.t, "hold"
		return "press"
	end

	local target = opts.goal or pos
	local dx, dy = target.x - ctx.pos.x, target.y - ctx.pos.y
	local flat = math.sqrt(dx * dx + dy * dy)
	local stop = opts.goal and T("move_to_flat_eps") or T("sup_stand_off_m")
	if flat > stop then req.move = api.move_toward(dx, dy) end

	-- Close enough but the engine never selected it: count the failure after interact_retry_s.
	if d <= Lib.reach(api, ctx) then
		a.near_t = a.near_t or ctx.t
		if ctx.t - a.near_t >= T("interact_retry_s") then
			a.near_t = ctx.t
			if fail_once(api, a, unit, ctx) then return give_up(api, a, unit, ctx) end
		end
	end
	return "approach"
end

return Lib
