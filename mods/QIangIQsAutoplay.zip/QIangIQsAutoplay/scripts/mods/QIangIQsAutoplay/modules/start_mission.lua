--[[
    Start a mission by backend id as a PRIVATE match. Copied from ManyMoreTry.lua:
      fetch: Managers.data_service.mission_board:fetch_mission(id):next(...):catch(...)  (:323-337)
      go_match: level check, all members in hub (are_all_members_in_hub, :210-221), private needs at
             least one other member (num_other_members, :259-268), then
             Managers.party_immaterium:wanted_mission_selected(id, private, BackendUtilities.prefered_mission_region) (:270)
    Difference: private is forced true (the hard gate needs a private session) instead of being read
    from the mission-board save data (MMT get_private_option).
    Requests come from shared.start_request = { id = "<36-char id>", owner = "<module>" } (the Ortus loop).
]]
local BackendUtilities = require("scripts/foundation/managers/backend/utilities/backend_utilities")

return {
	name = "start_mission",
	setting = "module_start_mission",
	title = "Loop: start mission (private)",
	description = "Queues the saved mission as a private match when the Ortus loop asks for it (ManyMoreTry logic).",
	where = "hub",
	reset = function(api, st)
		st.busy, st.last_try = nil, nil
		api.shared.start_request, api.shared.start_status = nil, nil
	end,
	update = function(dt, t, ctx, req, st, api)
		local rq = api.shared.start_request
		if not rq then
			api.status(st, "idle", "-", "waiting", "no start request")
			return
		end
		if st.busy then
			api.status(st, "fetching", rq.id, "wait", "mission board fetch pending")
			return
		end
		if st.last_try and t - st.last_try < api.T("start_retry_s") then
			api.status(st, "cooldown", rq.id, "wait", "retry cooldown")
			return
		end
		local pim = Managers.party_immaterium
		if not pim:are_all_members_in_hub() then
			api.status(st, "waiting", rq.id, "wait", "not all members in hub")
			return
		end
		if GameParameters.prod_like_backend and pim:num_other_members() < 1 then
			api.shared.start_status = { state = "failed", reason = "private match needs another party member (ManyMoreTry.lua:259-268)" }
			api.shared.start_request = nil
			api.status(st, "failed", rq.id, "refused", api.shared.start_status.reason)
			return
		end
		st.busy, st.last_try = true, t
		api.status(st, "fetching", rq.id, "fetch_mission", "requested by " .. tostring(rq.owner))
		Managers.data_service.mission_board:fetch_mission(rq.id):next(function(data)
			st.busy = nil
			local ok, why = api.may_act("start_mission", "hub")
			if not ok then
				api.status(st, "aborted", rq.id, "no queue", why)
				return
			end
			if not data or not data.mission then
				api.shared.start_status = { state = "failed", reason = "mission board returned no mission" }
				api.shared.start_request = nil
				api.status(st, "failed", rq.id, "no mission", "fetch returned nothing")
				return
			end
			local required = data.mission.requiredLevel or 0
			local player = Managers.player:local_player(1)
			local profile = player and player:profile()
			local level = profile and profile.current_level or 0
			if level < required then
				api.shared.start_status = { state = "failed", reason = "character level too low" }
				api.shared.start_request = nil
				api.status(st, "failed", rq.id, "level", "character level too low")
				return
			end
			pim:wanted_mission_selected(rq.id, true, BackendUtilities.prefered_mission_region)
			api.shared.private_queue = { t = t, by = "start_mission" }
			api.shared.start_status = { state = "queued", reason = "wanted_mission_selected(private)" }
			api.shared.start_request = nil
			api.status(st, "queued", rq.id, "wanted_mission_selected", "private = true")
		end):catch(function(e)
			st.busy = nil
			local code = e and e.code
			api.shared.start_status = { state = "failed", reason = "fetch_mission error " .. tostring(code) }
			api.shared.start_request = nil
			api.status(st, "failed", rq.id, "fetch error", tostring(code))
		end)
	end,
}
