--[[
    trapper_dodge: dodge the Trapper's net.
    Detection: the wwise_minion event (MinionFxExtension._trigger_inventory_wwise_event) of a
    renegade_netgunner that targets the local player: wind-up sound -> dodge due at
    wind-up time + aim duration - reaction delay; "interrupted" cancels; a net shot with no wind-up seen
    dodges at once.
    Copied from QIangIQsAntiSpecialist trapper.lua:9-117 and QIangIQsTrappers_dodge.lua:338-454
    (event names, plan timing, push first when the melee weapon is out and the net is far enough away).
]]

local mod = get_mod("QIangIQsAutoplay")
local H = mod:io_dofile("QIangIQsAutoplay/scripts/mods/QIangIQsAutoplay/modules/lib_dodge")

local NAME = "trapper_dodge"
local BREED = "renegade_netgunner" -- AS trapper.lua:9
local EVENT_WINDUP = "wwise/events/minions/play_weapon_netgunner_wind_up" -- AS trapper.lua:11
local EVENT_INTERRUPTED = "wwise/events/minions/play_weapon_netgunner_interupted" -- AS trapper.lua:12
local EVENT_SHOOT = "wwise/events/minions/play_weapon_netgunner" -- AS trapper.lua:13

-- plan.phase: "wait" (dodge not yet started) | "active" (routine running) | "done"
local function schedule(api, st, unit, target_hint, t, reactive)
	local T = api.T
	local me = st.me
	if not me then return end
	local target = target_hint
	if not api.unit_ok(target) then target = api.target_of(unit) end
	if target ~= me then return end

	local d = api.flat_dist(api.position(unit), api.position(me))
	if d > T("trap_net_max_distance_m") + T("dodge_player_radius_m") then return end -- AS trapper.lua:67

	-- the server should see the dodge start at release; my input lands reaction_delay later (AS trapper.lua:72)
	local press = reactive and t or t + T("trap_aim_duration_s") - api.reaction_delay()

	local existing = st.plans[unit]
	if existing and existing.phase ~= "done" then
		if reactive and existing.phase == "wait" then existing.press = math.min(existing.press, press) end
		return
	end

	local plan = { unit = unit, seen = t, press = press, phase = "wait", d = d,
		expire = press + H.press_window(api) }
	st.plans[unit] = plan

	-- push first: melee already out, the net still far away in time (AS trapper.lua:84-91)
	if not reactive and d <= H.push_radius(api, me) and api.wielded(me) == "slot_primary"
		and press - t > T("push_block_s") + T("push_press_s") then
		plan.push = true
	end
end

local function on_wwise(api, st, unit, event_name, target_unit)
	if not st.live then return end
	if event_name ~= EVENT_WINDUP and event_name ~= EVENT_INTERRUPTED and event_name ~= EVENT_SHOOT then return end
	if not api.unit_ok(unit) or api.breed_name(unit) ~= BREED then return end
	local t = api.time()
	if not t then return end
	if event_name == EVENT_WINDUP then
		st.plans[unit] = nil
		schedule(api, st, unit, target_unit, t, false)
	elseif event_name == EVENT_INTERRUPTED then
		local plan = st.plans[unit]
		if plan and plan.phase == "wait" then
			plan.phase = "done"
			plan.push = false
			api.log(NAME, "info", "wind-up interrupted, dodge cancelled")
		end
	else
		-- the wind-up was missed (joined late, packet loss): dodge now (TR dodge.lua:439-446)
		local plan = st.plans[unit]
		if not plan or (plan.phase == "done" and not plan.started) then
			schedule(api, st, unit, target_unit, t, true)
		end
	end
end

return {
	name = NAME,
	setting = "module_trapper_dodge",
	title = "Havoc: dodge Trapper nets",
	description = "Dodges a Trapper net sideways, timed from its wind-up sound; pushes first when melee is out and the Trapper is close.",
	conflicts = {
		{ mod = "QIangIQsAntiSpecialist", setting = "trapper_enabled", why = "AntiSpecialist already dodges Trapper nets" },
		{ mod = "QIangIQsTrappers", setting = "auto_dodge", why = "Trappers already dodges nets" },
	},

	init = function(api, st)
		st.plans = {}
		api.on("wwise_minion", function(unit, event_name, target_unit)
			on_wwise(api, st, unit, event_name, target_unit)
		end)
	end,

	reset = function(api, st)
		st.live, st.me = false, nil
		st.plans = {}
		H.reset(api, st, NAME)
	end,

	update = function(dt, t, ctx, req, st, api)
		local T = api.T
		local gt, me = ctx.gt, ctx.unit
		st.live, st.me = true, me
		if not gt or not me then return end

		-- plans stay on record (as AS shots[] and TR plans do) so the net shot sound that arrives after the
		-- dodge cannot trigger a second, reactive dodge; the next wind-up replaces the record
		for unit, p in pairs(st.plans) do
			if not api.unit_ok(unit) then
				st.plans[unit] = nil
			elseif p.phase == "active" and not st.routine then
				p.phase = "done"
			elseif p.phase == "wait" and gt > p.expire then
				p.phase = "done"
			end
		end

		if H.run(api, st, ctx, req, NAME, T("dodge_priority_trapper")) then return end

		-- start the push first, then the earliest dodge that is due
		local best
		for _, p in pairs(st.plans) do
			if p.phase == "wait" then
				if p.push and not st.routine then
					p.push = false
					local ok, why, retry = H.begin(api, st, ctx, NAME, T("dodge_priority_trapper"), "push",
						{ threat = p.unit, interrupt = false, label = "Trapper push" })
					if ok then
						api.status(st, "active", BREED, "push first", "melee out, Trapper close")
						return
					end
					api.log(NAME, "debug", "push not started: %s", tostring(why))
				end
				if gt >= p.press - T("dodge_pre_move_steps") * api.fixed_step() and (not best or p.press < best.press) then
					best = p
				end
			end
		end
		if not best then return end

		if gt > best.expire then
			best.phase = "done"
			api.status(st, "idle", BREED, "missed", "dodge window passed")
			return
		end
		local p = api.position(best.unit)
		local ok, why, retry = H.begin(api, st, ctx, NAME, T("dodge_priority_trapper"), "dodge",
			{ from = { x = p.x, y = p.y }, mode = "across", ignore = best.unit, due = best.press, label = "Trapper dodge" },
			function(r, result) best.started = r.started ~= nil end)
		if ok then
			best.phase = "active"
			api.status(st, "active", BREED, "dodge", "net wind-up")
		elseif not retry then
			best.phase = "done"
			api.status(st, "idle", BREED, "no safe dodge", tostring(why))
		end
	end,
}
