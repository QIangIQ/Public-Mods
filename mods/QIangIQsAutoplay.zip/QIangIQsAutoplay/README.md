# QIangIQs Autoplay 0.2.1

Status: built 2026-11-06. LuaJIT syntax check, number lint, citation check and a mock harness pass. **Untested in game.**

## Safety
- Master toggle (key) is never saved: OFF at every game start. Emergency stop (key): master off, all input dropped, Ortus loop reset.
- Every module is OFF by default and has its own checkbox.
- Hard gate (checked every frame and on every hooked event):
  - Psykhanium: game modes `shooting_range` / `training_grounds`.
  - Solo: SoloPlay local host, or a private session with one human.
  - Private session where every other human is in your party and advertises the Autoplay handshake (presence key `qiapv1`).
  - Public matchmade missions never pass, even alone (strangers can hot-join).
  - Hub-side actions (ready, vote, start, end screen) need every party member to advertise the handshake.
- A module that throws is logged and switched off for the session (your saved setting is not changed).
- Modules refuse to run while another installed mod does the same job (BornReady auto-ready/vote/skip, QIangIQsAntiSpecialist / QIangIQsTrappers dodges, QIangIQsTarkAccount aim). The panel shows `BLK` and the reason.

## Ortus gold loop (Karnak twins, km_enforcer_twins)
Needs two players, both running Autoplay with master ON and "Loop: Ortus" ON (a private match needs another party member: ManyMoreTry.lua:259-268).
1. Set the mission id once: play the twins mission (the id is captured), or `/autoplay_mission <36-char id>`.
2. Turn on: Loop: Ortus, start mission, auto-ready, vote yes, skip end screen / fast return, and Havoc: auto-path.
3. The player with the lowest account id queues the private match; the other follows.
4. In the mission: find the RIGHT bell (logged with both candidates; "right" is inferred from geometry), aim at node `c_bell_01`, fire until the server teleport, walk to the elevator with auto-path (fails instead of walking blind if no path), use the elevator, wait for death or mission end, back to the hub, repeat.
- Every step has a timeout (UNTUNED settings). The loop stops if the other player leaves or turns the loop off.
- Single-step: turn on "Ortus: single-step mode", then `/autoplay_step` advances one step.
- "Die": no source says how; the loop waits. Optional "leave mission if the DIE step times out".

## Debug
- Panel (top-left): master, where, gate and reason, party gate, peers, aim owner, self-test counts; one line per module: `name ON|off|BLK|ERR state | target | decision | reason`.
- Log files in this folder: `log_<module>.log` (level setting), `/autoplay_dump` writes the ring buffer to `dump_<time>.log`, `/autoplay_log_clear`.
- `/autoplay_selftest` checks every hook target and game function; `/autoplay_status`.

## No-invent rule
Every number lives in `scripts/mods/QIangIQsAutoplay/tuning/*.lua` with a source (game file:line or another mod), or is a setting titled "UNTUNED: no source - <id>". `tools/lint_numbers.py` (in the build folder) fails on any other literal. See REPORT.md for the full value table.

## 0.2.1 (2026-11-06)
- Fixed a game crash on the first gameplay load: the load-time self-test called `require()` on game files inside `pcall`. One failed (`animation_system`), which left a marker in `package.loaded`; the game's own later `require` of that file then stopped with "loop or previous error loading module". The mod now never calls `require()` on game files: the self-test and the lazy lookups only read files the game has already loaded. The static self-test runs again on the first mission frame. A file that is not loaded yet shows as WAIT, not FAIL.
- New command `/autoplay_psykhanium` starts the Psykhanium shooting range from the hub, the same way the hub terminal does (game training_grounds_options_view.lua:120-160).
