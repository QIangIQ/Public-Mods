-- QIangIQsMMJKatana per-weapon data (gen.py spec katana). Clips are MMJ clip names from katana\OBJ-Weapond-Katana__22715.
-- Action map sources: Darktide weapon templates (Aussiemon master) via tools\dump_actions.py.
return {
    ranged = false,
    idle = "katana-idle",
    templates = { combatsword_p3_m1 = true, combatsword_p3_m2 = true, combatsword_p3_m3 = true },
    actions = {
        action_wield = { clips = { "katana-intro (unsheathe)" } },
        action_melee_start_left = { clips = { "katana-charge-init-v2", "katana-charge-iddle" }, loop_last = true, sounds = { "sfx_gp_wp_katana_charge_grab_01.ogg", "sfx_gp_wp_katana_charge_grab_02.ogg", "sfx_gp_wp_katana_charge_grab_03.ogg" } },
        action_melee_start_right = { clips = { "katana-charge-init-v2", "katana-charge-iddle" }, loop_last = true, sounds = { "sfx_gp_wp_katana_charge_grab_01.ogg", "sfx_gp_wp_katana_charge_grab_02.ogg", "sfx_gp_wp_katana_charge_grab_03.ogg" } },
        action_melee_start_left_2 = { clips = { "katana-charge-init-v2", "katana-charge-iddle" }, loop_last = true, sounds = { "sfx_gp_wp_katana_charge_grab_01.ogg", "sfx_gp_wp_katana_charge_grab_02.ogg", "sfx_gp_wp_katana_charge_grab_03.ogg" } },
        action_melee_start_right_2 = { clips = { "katana-charge-init-v2", "katana-charge-iddle" }, loop_last = true, sounds = { "sfx_gp_wp_katana_charge_grab_01.ogg", "sfx_gp_wp_katana_charge_grab_02.ogg", "sfx_gp_wp_katana_charge_grab_03.ogg" } },
        action_left_light = { clips = { "katana-attack1" }, sounds = { "sfx_gp_wp_katana_swing_01.ogg", "sfx_gp_wp_katana_swing_02.ogg", "sfx_gp_wp_katana_swing_03.ogg", "sfx_gp_wp_katana_swing_04.ogg", "sfx_gp_wp_katana_swing_05.ogg" } },
        action_right_light = { clips = { "katana-attack2" }, sounds = { "sfx_gp_wp_katana_swing_01.ogg", "sfx_gp_wp_katana_swing_02.ogg", "sfx_gp_wp_katana_swing_03.ogg", "sfx_gp_wp_katana_swing_04.ogg", "sfx_gp_wp_katana_swing_05.ogg" } },
        action_left_light_2 = { clips = { "katana-attack3" }, sounds = { "sfx_gp_wp_katana_swing_01.ogg", "sfx_gp_wp_katana_swing_02.ogg", "sfx_gp_wp_katana_swing_03.ogg", "sfx_gp_wp_katana_swing_04.ogg", "sfx_gp_wp_katana_swing_05.ogg" } },
        action_right_light_2 = { clips = { "katana-attack1" }, sounds = { "sfx_gp_wp_katana_swing_01.ogg", "sfx_gp_wp_katana_swing_02.ogg", "sfx_gp_wp_katana_swing_03.ogg", "sfx_gp_wp_katana_swing_04.ogg", "sfx_gp_wp_katana_swing_05.ogg" } },
        action_right_light_pushfollow = { clips = { "katana-attack2" }, sounds = { "sfx_gp_wp_katana_swing_01.ogg", "sfx_gp_wp_katana_swing_02.ogg", "sfx_gp_wp_katana_swing_03.ogg", "sfx_gp_wp_katana_swing_04.ogg", "sfx_gp_wp_katana_swing_05.ogg" } },
        action_attack_special_riposte = { clips = { "katana-attack2" }, sounds = { "sfx_gp_wp_katana_swing_01.ogg", "sfx_gp_wp_katana_swing_02.ogg", "sfx_gp_wp_katana_swing_03.ogg", "sfx_gp_wp_katana_swing_04.ogg", "sfx_gp_wp_katana_swing_05.ogg" } },
        action_attack_special_riposte_psyker = { clips = { "katana-attack2" }, sounds = { "sfx_gp_wp_katana_swing_01.ogg", "sfx_gp_wp_katana_swing_02.ogg", "sfx_gp_wp_katana_swing_03.ogg", "sfx_gp_wp_katana_swing_04.ogg", "sfx_gp_wp_katana_swing_05.ogg" } },
        action_left_heavy = { clips = { "katana-charge-release" }, sounds = { "player.sword.chargeRelease 01.ogg", "player.sword.chargeRelease 02.ogg" } },
        action_right_heavy = { clips = { "katana-charge-release" }, sounds = { "player.sword.chargeRelease 01.ogg", "player.sword.chargeRelease 02.ogg" } },
        action_parry_special = { clips = { "katana-deflect 2" }, sounds = { "player.sword.deflect01.ogg", "player.sword.deflect02.ogg", "player.sword.deflect03.ogg" } },
        action_parry_special_psyker = { clips = { "katana-deflect 2" }, sounds = { "player.sword.deflect01.ogg", "player.sword.deflect02.ogg", "player.sword.deflect03.ogg" } },
        action_push = { clips = { "katana-deflect 2" } },
        action_inspect = { clips = { "katana-reload (cleaning)" }, sounds = { "sfx_wp_katana_reload.ogg" } },
    },
}
