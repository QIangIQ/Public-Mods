return {
    mod_name = {
        en = "QIangIQ's MMJ Katana",
    },
    mod_description = {
        en = "Replaces the Duelling Sword with Mullet Mad Jack's katana: MMJ's own sprites and clips in first person (unsheathe, three-hit combo, charged slash, deflect, cleaning) with its sounds. Visual only: the weapon still works as before. Contains Mullet Mad Jack art and audio: personal use only.",
    },
    command_desc = { en = "MMJ Katana status (add flip to turn the sprite rotation round)" },
    replace_combatsword_p3_m1 = { en = "Replace Duelling Sword (combatsword_p3_m1)" },
    replace_combatsword_p3_m2 = { en = "Replace Duelling Sword (combatsword_p3_m2)" },
    replace_combatsword_p3_m3 = { en = "Replace Duelling Sword (combatsword_p3_m3)" },
    third_person = { en = "Third person: your character" },
    third_person_others = { en = "Third person: other players" },
    third_person_hide = { en = "Hide the weapon" },
    third_person_retail = { en = "Show the weapon" },
    sounds = { en = "MMJ sounds" },
    volume = { en = "Sound volume (%%)" },
    layout = { en = "Screen layout" },
    mmj_fov = { en = "MMJ weapon camera field of view (degrees)" },
    size = { en = "Size (%%)" },
    offset_x = { en = "Move right (cm)" },
    offset_y = { en = "Move up (cm)" },
    smear_cap = { en = "Fade sprites bigger than this share of the screen (%%, 0 = off)" },
}
