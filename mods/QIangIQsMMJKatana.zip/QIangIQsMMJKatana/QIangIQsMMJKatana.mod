return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsMMJKatana` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsMMJKatana", {
            mod_script = "QIangIQsMMJKatana/scripts/mods/QIangIQsMMJKatana/QIangIQsMMJKatana",
            mod_data = "QIangIQsMMJKatana/scripts/mods/QIangIQsMMJKatana/QIangIQsMMJKatana_data",
            mod_localization = "QIangIQsMMJKatana/scripts/mods/QIangIQsMMJKatana/QIangIQsMMJKatana_localization",
        })
    end,
    version = "0.1.0",
    author = "QIangIQ",
    packages = {},
}
