-- QIangIQ's Skull Runeblade: shows a Custom Assets sword (traced from reference screenshots) in place of any
-- melee weapon that is switched on in its per-weapon profile (size, tilt, roll and grip position per weapon).
-- Author: QIangIQ
local mod = get_mod("QIangIQsSkullRuneblade")

-- QIangIQsMeleeArsenal and QIangIQsWarframeArsenal keep per-weapon profiles: when this mod switches a weapon on,
-- both are told (their mod.release_template)
local QIANGIQ_ARSENALS = {
    release_template = function(template)
        for _, name in ipairs({ "QIangIQsMeleeArsenal", "QIangIQsWarframeArsenal" }) do
            local other = get_mod(name)
            if other and other.release_template then
                other.release_template(template)
            end
        end
    end,
}

-- Cross-client sync ---------------------------------------------------------------
-- QIangIQsModelSync publishes which QIangIQ replacer mods a player has on, with their options, through
-- Vox Manifold (the transport Dio's Wardrobe shares outfits with). No asset data is sent: every client shows
-- the model from its own installed files. While another player's unit is worked on, sync_ctx holds that
-- player's options and opt() answers from them; for my own unit opt() is mod:get().
local SYNC_KEY = "srb"
local SYNC_BOOLS = { "replace_duelling_sword", "replace_relic_blade", "skull_fog" }
local SYNC_DEFAULTS = { replace_duelling_sword = false, replace_relic_blade = false, skull_fog = true }
local SYNC_VALUES = { "glow_brightness", "hilt_glow" }
local SYNC_LAYOUT = #SYNC_BOOLS * 100 + #SYNC_VALUES -- a peer on another version of this mod is not decoded
local sync_ctx = nil
local sync_known = setmetatable({}, { __mode = "k" })   -- other players' extensions this mod has shown something on
local sync_all = setmetatable({}, { __mode = "k" })     -- every visual loadout extension seen
local sync_decoded = setmetatable({}, { __mode = "k" }) -- published array -> options table
local SYNC_FALSE = { __index = function() return false end }
local SYNC_OFF = setmetatable({}, SYNC_FALSE)           -- "everything off": removes what was shown
local sync_extra_import = nil

local function opt(key)
    if sync_ctx then
        return sync_ctx[key]
    end
    return mod:get(key)
end

local function sync_api()
    local hub = get_mod("QIangIQsModelSync")
    return hub and hub.api
end

local function sync_me()
    local players = Managers.player
    if not players then
        return nil
    end
    local ok, player = pcall(players.local_player_safe, players, 1)
    return ok and player or nil
end

-- published array { layout, checkbox bits, value, value, ... [, extra] } -> options by setting id
local function sync_decode(raw)
    local t = sync_decoded[raw]
    if t ~= nil then
        return t
    end
    t = false
    if type(raw) == "table" and raw[1] == SYNC_LAYOUT then
        t = setmetatable({}, SYNC_FALSE)
        local mask = tonumber(raw[2]) or 0
        for i = 1, #SYNC_BOOLS do
            t[SYNC_BOOLS[i]] = mask % 2 >= 1
            mask = math.floor(mask / 2)
        end
        for i = 1, #SYNC_VALUES do
            local v = raw[2 + i]
            if v ~= nil then
                t[SYNC_VALUES[i]] = v
            end
        end
        if sync_extra_import then
            sync_extra_import(t, raw[3 + #SYNC_VALUES])
        end
    end
    sync_decoded[raw] = t
    return t
end

-- whose options apply to this extension: nil = mine, a table = that player's (SYNC_OFF when they publish
-- nothing for this mod)
local function sync_owner(ext)
    sync_all[ext] = true
    local player = ext._player
    if player == nil or player == sync_me() then
        return nil
    end
    local api = sync_api()
    local raw = api and api.peer(SYNC_KEY, player)
    local state = raw and sync_decode(raw)
    if state then
        sync_known[ext] = true
        return state
    end
    return SYNC_OFF
end

-- my own unit, or another player's unit this mod is (or was) showing something on
local function sync_shown(ext)
    local player = ext._player
    return player ~= nil and (player == sync_me() or sync_known[ext] == true)
end

local function sync_pack(...)
    return { n = select("#", ...), ... }
end

-- runs a hook body with the options of the extension's owner
local function sync_wrap(fn, ext_index)
    return function(...)
        local ext = select(ext_index, ...)
        local previous = sync_ctx
        sync_ctx = sync_owner(ext)
        local results = sync_pack(pcall(fn, ...))
        sync_ctx = previous
        if not results[1] then
            error(results[2], 0)
        end
        return unpack(results, 2, results.n)
    end
end

-- The same hook on my own unit's extension and on other players' (husk) extensions. While the mods load, the
-- classes do not exist yet: CLASS.<name> is then only the name and DMF delays the hook ("needs to be delayed"
-- in the log), so the husk class cannot be inspected here. Its methods are taken from
-- player_husk_visual_loadout_extension.lua instead.
local SYNC_HUSK_METHODS = { init = true, update = true, _update_item_visibility = true, destroy = true }

local function vl_hook_safe(method, fn)
    mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, method, sync_wrap(fn, 1))
    if SYNC_HUSK_METHODS[method] then
        mod:hook_safe(CLASS.PlayerHuskVisualLoadoutExtension, method, sync_wrap(fn, 1))
    end
end

local function vl_hook(method, fn)
    mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, method, sync_wrap(fn, 2))
    if SYNC_HUSK_METHODS[method] then
        mod:hook(CLASS.PlayerHuskVisualLoadoutExtension, method, sync_wrap(fn, 2))
    elseif method == "_unequip_item_from_slot" then
        -- a husk has no _unequip_item_from_slot: its unequip arrives as rpc_player_unequip_item_from_slot
        -- (self, channel_id, go_id, slot_id), slot name = NetworkLookup.player_inventory_slot_names[slot_id]
        -- (player_husk_visual_loadout_extension.lua)
        mod:hook(CLASS.PlayerHuskVisualLoadoutExtension, "rpc_player_unequip_item_from_slot", sync_wrap(function(func, self, channel_id, go_id, slot_id, ...)
            local NetworkLookup = require("scripts/network_lookup/network_lookup")
            local slot_name = NetworkLookup.player_inventory_slot_names[slot_id]
            return fn(function()
                return func(self, channel_id, go_id, slot_id)
            end, self, slot_name)
        end, 2))
    end
end
-- ----------------------------------------------------------------------------------

mod.AUTHOR = "QIangIQ"

local SWORD_ID = "QIangIQsSkullRuneblade:skull_runeblade_long"                -- <Mod>:<Custom folder>
local SWORD_UNIT = "content/mods/qiangiq_skull_runeblade/skull_runeblade_long" -- --asset-path used at compile time

-- Melee weapon templates that can be replaced: the list of QIangIQsCookedMacroManager's
-- "melee_weapon_selection" dropdown (QIangIQsCookedMacroManager_data.lua), without its global entry.
local MELEE_LIST = {
    "chainaxe_p1_m1",
    "chainaxe_p1_m2",
    "chainsword_p1_m1",
    "chainsword_p1_m2",
    "chainsword_2h_p1_m1",
    "chainsword_2h_p1_m2",
    "combataxe_p1_m1",
    "combataxe_p1_m2",
    "combataxe_p1_m3",
    "combataxe_p2_m1",
    "combataxe_p2_m2",
    "combataxe_p2_m3",
    "combataxe_p3_m1",
    "combataxe_p3_m2",
    "combataxe_p3_m3",
    "ogryn_combatblade_p1_m1",
    "ogryn_combatblade_p1_m2",
    "ogryn_combatblade_p1_m3",
    "combatknife_p1_m1",
    "combatknife_p1_m2",
    "combatsword_p1_m1",
    "combatsword_p1_m2",
    "combatsword_p1_m3",
    "combatsword_p2_m1",
    "combatsword_p2_m2",
    "combatsword_p2_m3",
    "combatsword_p3_m1",
    "combatsword_p3_m2",
    "combatsword_p3_m3",
    "forcesword_p1_m1",
    "forcesword_p1_m2",
    "forcesword_p1_m3",
    "forcesword_2h_p1_m1",
    "forcesword_2h_p1_m2",
    "ogryn_gauntlet_p1_m1",
    "ogryn_club_p1_m1",
    "ogryn_club_p1_m2",
    "ogryn_club_p1_m3",
    "ogryn_club_p2_m1",
    "ogryn_club_p2_m2",
    "ogryn_club_p2_m3",
    "ogryn_pickaxe_2h_p1_m1",
    "ogryn_pickaxe_2h_p1_m2",
    "ogryn_pickaxe_2h_p1_m3",
    "ogryn_powermaul_p1_m1",
    "ogryn_powermaul_slabshield_p1_m1",
    "powermaul_p1_m1",
    "powermaul_p1_m2",
    "powermaul_shield_p1_m1",
    "powermaul_shield_p1_m2",
    "powermaul_p2_m1",
    "powermaul_2h_p1_m1",
    "powersword_p1_m1",
    "powersword_p1_m2",
    "powersword_p2_m1",
    "powersword_p2_m2",
    "powersword_2h_p1_m1",
    "powersword_2h_p1_m2",
    "thunderhammer_2h_p1_m1",
    "thunderhammer_2h_p1_m2",
    "saw_p1_m1",
    "crowbar_p1_m1",
    "dual_shivs_p1_m1",
    "dual_shivs_p1_m2",
    "transonic_sword_transonic_knife_p1_m1",
    "powermaul_p3_m1",
    "powersword_p3_m1",
}
local MELEE_SET = {}
for i = 1, #MELEE_LIST do
    MELEE_SET[MELEE_LIST[i]] = true
end
local DEFAULT_WEAPON = "powersword_2h_p1_m2"

-- One profile per weapon template, kept in the saved table "profiles" (as CookedMacroManager keeps its
-- per-weapon table in "bind_data"); the widgets with these ids show the profile of the selected weapon.
--   profile_enabled: replace this weapon
--   profile_scale:   size factor
--   profile_tilt:    degrees in the plane of the blade's flat, about the hand (positive = tip away from the
--                    body / view centre, negative = towards it)
--   profile_roll:    degrees about the blade's own length (180 turns the cutting edge to the other side)
--   profile_grip:    shifts the hand along the handle, in blade lengths
local PROFILE_TEMPLATE = {
    profile_enabled = false,
    profile_scale = 1,
    profile_tilt = 0,
    profile_roll = 0,
    profile_grip = 0,
}
local profiles = nil

-- QIangIQ sword swap mods that target the same weapons: per weapon, only one of them replaces it.
-- Turning a weapon on in one mod switches that weapon off in the others through their saved
-- settings (DMFMod:set / DMFMod:get, dmf/modules/core/settings.lua), as the character mods do.
local SWORD_MODS = { "QIangIQsDiamondSword", "QIangIQsGoldenBloodSword", "QIangIQsBismuthRelicBlade", "QIangIQsSkullRuneblade", "QIangIQsBismuthSword", "QIangIQsButterflyKnife" }
local REPLACE_SETTINGS = { "replace_duelling_sword", "replace_relic_blade" }
local TEMPLATES_BY_SETTING = { replace_duelling_sword = true, replace_relic_blade = true }

-- these two keep their own on/off settings: the other QIangIQ sword mods read and write them
local TEMPLATES = {
    combatsword_p3_m2 = "replace_duelling_sword",
    powersword_2h_p1_m2 = "replace_relic_blade",
}

-- The compiled sword is authored with its blade running from local (0,0,0) to (0,1,0)
-- (Stingray forward = +Y), the flat of the blade facing local Z. Handle and pommel sit at -Y.
-- Measured on the model (gsword/prep_gs.py, blade length = 1): blade start = just under the
-- crossguard (source z -0.375), tip at source z -2.75, middle of the grip at source z 0.22 -> y = -0.2506.
-- haze between the notch rim and the skull: its own small unit (alpha-blended material), linked to the sword.
-- Kept apart from the sword so that the sword still shows if this unit cannot be loaded.
local FOG_ID = "QIangIQsSkullRuneblade:skull_runeblade_fog"
local FOG_UNIT = "content/mods/qiangiq_skull_runeblade/skull_runeblade_fog"
local fog_ready = false

local GRIP_Y = -0.1181
-- world size per model unit, kept from v1.0 (reach / 1.1588 for a 68.85-unit model); the blade is now 112.22 units
local REACH_SCALE = 1.1606 -- v1.6: blade 92.60 units (was 112.22 at 1.4066), same world size per unit
local FIT_FRAMES = 10
local fit_generation = 0 -- bumped when a fit setting changes, so every sword refits -- refit for a few frames after spawning so the world poses have settled
-- Which side the tilt leans to is chosen from where the tip ends up relative to the body. In a block, an attack
-- recovery or a sprint jump the body-relative pose briefly flips that choice and the weapon snaps to the wrong angle.
-- Votes (weighted by how clear each frame's choice was) are kept in the blade's own frame and the majority side
-- wins, so brief transient poses are outvoted; a setting change (fit_generation) starts the vote again.
local tilt_votes = {}
local function latch_side(view, blade, chosen, other, weight)
    local fr = Unit.world_rotation(blade, 1)
    local bx, by, bz = Quaternion.right(fr), Quaternion.forward(fr), Quaternion.up(fr)
    local function loc(v)
        return Vector3(Vector3.dot(v, bx), Vector3.dot(v, by), Vector3.dot(v, bz))
    end
    local key = view or "?"
    local vote = tilt_votes[key]
    if not vote or vote.gen ~= fit_generation then
        vote = { gen = fit_generation, sum = Vector3(0, 0, 0) }
        tilt_votes[key] = vote
    end
    vote.sum = vote.sum * 0.97 + (loc(chosen) - loc(other)) * (weight + 0.0001)
    if Vector3.dot(loc(chosen), vote.sum) >= Vector3.dot(loc(other), vote.sum) then
        return chosen
    end
    return other
end

local custom_assets = nil
local ready = false
local mod_on = true
local session_override = {} -- keybind flips, cleared when the setting itself changes

local tracked = setmetatable({}, { __mode = "k" })    -- PlayerUnitVisualLoadoutExtension
local tracked_ui = setmetatable({}, { __mode = "k" }) -- UIProfileSpawner
local tracked_wpn = setmetatable({}, { __mode = "k" }) -- UIWeaponSpawner

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

-- destroys the haze (if any) and then the sword of one record
local function destroy_rec(rec, destroy_fn)
    if rec.fog then
        destroy_fn(rec.fog)
        rec.fog = nil
    end
    destroy_fn(rec.sword)
end

local function setting_on(key)
    local override = session_override[key]
    if override ~= nil and not sync_ctx then
        return override
    end
    return opt(key) and true or false
end

local function profile_for(template, create)
    if sync_ctx then
        -- another player's sword: the profile they published for that weapon
        local list = rawget(sync_ctx, "__profiles")
        return list and list[template] or PROFILE_TEMPLATE
    end
    if not profiles then
        return PROFILE_TEMPLATE
    end
    local p = profiles[template]
    if not p and create then
        p = table.clone(PROFILE_TEMPLATE)
        profiles[template] = p
    end
    return p or PROFILE_TEMPLATE
end

local function template_on(template)
    if not template or not MELEE_SET[template] then
        return false
    end
    local key = TEMPLATES[template]
    if key then
        return setting_on(key)
    end
    return profile_for(template).profile_enabled and true or false
end

local function wants_item(item)
    return item ~= nil and mod_on and ready and template_on(item.weapon_template)
end

local function local_player()
    local players = Managers.player
    if not players then
        return nil
    end
    local ok, player = pcall(players.local_player_safe, players, 1)
    return ok and player or nil
end

-- Fitting ---------------------------------------------------------------------

-- the longest attachment box is the blade (both weapons have a separate blade attachment)
local function blade_box(attachments)
    local best_len, best_unit, best_pose, best_ext = 0, nil, nil, nil
    if attachments then
        for i = 1, #attachments do
            local unit = attachments[i]
            if unit_ok(unit) then
                local pose, half_extents = Unit.box(unit)
                if pose and half_extents then
                    local len = math.max(half_extents.x, half_extents.y, half_extents.z)
                    if len > best_len then
                        best_len, best_unit, best_pose, best_ext = len, unit, pose, half_extents
                    end
                end
            end
        end
    end
    return best_unit, best_pose, best_ext
end

local function fmt(v)
    return string.format("(%.3f, %.3f, %.3f)", v.x, v.y, v.z)
end

local last_fit = {} -- per view, for /skullblade debug

-- places the sword (linked to the blade attachment's node 1) along the original blade, in the
-- blade unit's local space. Linking to the blade itself (not the weapon base unit) makes the
-- sword follow any animation the weapon applies to its blade relative to the base.
-- Blade direction = from the blade attachment's own root node (where it is linked onto the
-- hilt) to the centre of its bounding box; this does not depend on how Unit.box orders its
-- half extents. The box axes are only used for the flat of the blade.
local function fit(sword, base, attachments, parent_scale, view, profile, body_line)
    local blade, pose, ext = blade_box(attachments)
    if not pose or not unit_ok(blade) then
        return false
    end
    profile = profile or PROFILE_TEMPLATE
    local tilt_deg = profile.profile_tilt or 0
    local roll_deg = profile.profile_roll or 0
    local rot = Matrix4x4.rotation(pose)
    local center = Matrix4x4.translation(pose)
    local axes = { Quaternion.right(rot), Quaternion.forward(rot), Quaternion.up(rot) }
    local halves = { ext.x, ext.y, ext.z }
    local max_half = math.max(ext.x, ext.y, ext.z)
    if max_half <= 0 then
        return false
    end

    local origin = Unit.world_position(base, 1)
    local root = Unit.world_position(blade, 1)
    local to_center = center - root
    local dist = math.sqrt(Vector3.length_squared(to_center))
    local dir, source, line_point, far
    if dist > 0.25 * max_half then
        -- v2 direction (confirmed correct in game): blade root -> box centre.
        -- The box pose axes are NOT used for the direction (they put the sword sideways in game).
        local u = to_center * (1 / dist)
        dir = u
        source = "root->centre"
        -- a straight blade is authored along one of its own unit axes; if one of them is within
        -- ~14 degrees of root->centre, use it so an off-centre box does not tilt the thrust line
        local blade_rot = Unit.world_rotation(blade, 1)
        local blade_axes = { Quaternion.right(blade_rot), Quaternion.forward(blade_rot), Quaternion.up(blade_rot) }
        local best, best_axis = 0, nil
        for i = 1, 3 do
            local d = Vector3.dot(blade_axes[i], u)
            if math.abs(d) > best then
                best = math.abs(d)
                best_axis = d < 0 and -blade_axes[i] or blade_axes[i]
            end
        end
        if best_axis and best > 0.97 then
            dir = best_axis
            source = string.format("blade unit axis (%.2f to root->centre)", best)
        end
        line_point = root
        far = Vector3.dot(to_center, dir) + max_half -- root -> tip
    else
        -- root sits inside the blade: fall back to the longest box axis, pointing away from the hilt
        local long = 1
        for i = 2, 3 do
            if halves[i] > halves[long] then
                long = i
            end
        end
        dir = axes[long]
        if Vector3.dot(center - origin, dir) < 0 then
            dir = -dir
        end
        line_point = center - dir * halves[long]
        far = 2 * halves[long]
        source = "box axis"
    end
    local half = far * 0.5

    -- the hand: the weapon base unit is linked at the hand, so its origin projected onto the
    -- blade line is where the weapon is held; never let it sit past the original blade start
    local along = Vector3.dot(origin - line_point, dir)
    if along > 0 then
        along = 0
    end
    local hand = line_point + dir * along
    -- scale so the diamond sword's grip-to-tip matches the original weapon's hand-to-tip
    local reach = far - along
    local s_world = reach * REACH_SCALE * (profile.profile_scale or 1)

    -- flat of the blade: the thinnest box axis among those across the blade
    local thin, best_dot = nil, nil
    for i = 1, 3 do
        local d = math.abs(Vector3.dot(axes[i], dir))
        if d < 0.7 and (thin == nil or halves[i] < halves[thin]) then
            thin = i
        end
        if best_dot == nil or d > best_dot then
            best_dot = d
        end
    end
    if not thin then
        return false
    end
    local normal = Vector3.normalize(axes[thin] - dir * Vector3.dot(axes[thin], dir))

    -- optional tilt within the flat's plane, pivoting on the hand
    local tilt_note = "none"
    if tilt_deg and tilt_deg ~= 0 then
        local a = math.rad(math.abs(tilt_deg))
        local side = Vector3.cross(normal, dir)
        local d1 = dir * math.cos(a) + side * math.sin(a)
        local d2 = dir * math.cos(a) - side * math.sin(a)
        local chosen = d1
        if body_line then
            local point, axis = body_line()
            if point and axis then
                local function off_axis(d)
                    local v = hand + d * reach - point
                    local w = v - axis * Vector3.dot(v, axis)
                    return Vector3.length_squared(w)
                end
                local d1_out = off_axis(d1) >= off_axis(d2)
                if tilt_deg > 0 then
                    chosen = d1_out and d1 or d2
                else
                    chosen = d1_out and d2 or d1
                end
                local chose_d1 = (tilt_deg > 0) == d1_out
                chosen = latch_side(view, blade, chose_d1 and d1 or d2, chose_d1 and d2 or d1, math.abs(off_axis(d1) - off_axis(d2)))
            end
        end
        dir = chosen
        tilt_note = string.format("%.0f deg", tilt_deg)
    end

    -- roll about the blade's own length (after the tilt, so the tilt direction does not change with it)
    if roll_deg ~= 0 then
        local a = math.rad(roll_deg)
        normal = Vector3.normalize(normal * math.cos(a) + Vector3.cross(dir, normal) * math.sin(a))
    end

    -- place the sword's grip centre in the hand
    local sword_start = hand - dir * ((GRIP_Y + (profile.profile_grip or 0)) * s_world)

    local frame_rot = Unit.world_rotation(blade, 1)
    local bx, by, bz = Quaternion.right(frame_rot), Quaternion.forward(frame_rot), Quaternion.up(frame_rot)
    local function to_local(v)
        return Vector3(Vector3.dot(v, bx), Vector3.dot(v, by), Vector3.dot(v, bz))
    end

    local k = parent_scale and parent_scale > 0 and parent_scale or 1
    local s = s_world / k
    local local_pos = to_local(sword_start - root) * (1 / k)
    local local_dir = to_local(dir)
    Unit.set_local_position(sword, 1, local_pos)
    Unit.set_local_rotation(sword, 1, Quaternion.look(local_dir, to_local(normal)))
    Unit.set_local_scale(sword, 1, Vector3(s, s, s))

    if view then
        last_fit[view] = string.format("%s: dir by %s, half extents %s, box axis dots %.2f/%.2f/%.2f, blade length %.3f, hand-to-tip %.3f, local start %s, local dir %s, thin axis %d, tilt %s",
            view, source, fmt(ext), Vector3.dot(axes[1], dir), Vector3.dot(axes[2], dir), Vector3.dot(axes[3], dir),
            2 * half, reach, fmt(local_pos), fmt(local_dir), thin, tilt_note) .. string.format(", roll %.0f, scale %.2f, grip %.2f", roll_deg, profile.profile_scale or 1, profile.profile_grip or 0)
    end
    return true
end

local function hide_originals(base, attachments)
    Unit.set_unit_visibility(base, false, true)
    if attachments then
        for i = 1, #attachments do
            if unit_ok(attachments[i]) then
                Unit.set_unit_visibility(attachments[i], false, true)
            end
        end
    end
end

-- One record per (holder, slot, view): { sword, base, parent (blade unit), frames, count }
-- spawn_fn(parent) -> unit linked to parent node 1, destroy_fn(unit)
local function sync_record(records, key, base, attachments, item, visible, spawn_fn, destroy_fn, parent_scale, first_person, body_line)
    local rec = records[key]
    local want = unit_ok(base) and wants_item(item) and attachments ~= nil and #attachments > 0
    local blade = want and blade_box(attachments) or nil
    if not unit_ok(blade) then
        want = false
    end

    if rec and (not want or rec.base ~= base or rec.parent ~= blade or not unit_ok(rec.sword)) then
        destroy_rec(rec, destroy_fn)
        records[key] = nil
        if rec.hid and rec.base == base and unit_ok(base) and visible then
            -- give the original weapon back (recursive visibility also covers its linked attachments)
            Unit.set_unit_visibility(base, true, true)
        end
        rec = nil
    end
    if not want then
        return false
    end

    if not rec then
        local sword = spawn_fn(blade)
        if not sword then
            return false
        end
        if first_person then
            -- same flag the game sets on first-person weapons (equipment_component.lua)
            Unit.set_shader_pass_flag_for_meshes_in_unit_and_childs(sword, "custom_fov", true)
        end
        rec = { sword = sword, base = base, parent = blade, frames = 0, count = -1, fitted = false }
        records[key] = rec
    end

    -- haze unit: spawned with the same function as the sword, linked to the sword's root node, no offset of its own
    local want_fog = fog_ready and opt("skull_fog") and true or false
    if want_fog and not rec.fog_failed and not unit_ok(rec.fog) then
        local ok, fog = pcall(spawn_fn, rec.sword, FOG_UNIT)
        if ok and unit_ok(fog) then
            Unit.set_local_position(fog, 1, Vector3(0, 0, 0))
            Unit.set_local_rotation(fog, 1, Quaternion.identity())
            Unit.set_local_scale(fog, 1, Vector3(1, 1, 1))
            if first_person then
                Unit.set_shader_pass_flag_for_meshes_in_unit_and_childs(fog, "custom_fov", true)
            end
            rec.fog = fog
        else
            rec.fog = nil
            rec.fog_failed = true
        end
    elseif not want_fog and rec.fog then
        destroy_fn(rec.fog)
        rec.fog = nil
    end

    if rec.count ~= #attachments or rec.gen ~= fit_generation then
        rec.gen = fit_generation
        rec.count = #attachments
        rec.frames = 0
    end
    -- the weapon's world pose is not settled when it spawns (the first fit can be stale until a setting change refits it), so refit about every 20 frames as well
    rec.tick = (rec.tick or 0) + 1
    if rec.frames < FIT_FRAMES or rec.tick % 20 == 0 then
        rec.frames = rec.frames + 1
        local blade_scale = Unit.local_scale(blade, 1)
        local k = (parent_scale or 1) * (blade_scale and blade_scale.x or 1)
        local profile = profile_for(item and item.weapon_template)
        local glow = (opt("glow_brightness") or 3) * 2 -- v1.7: runes, eyes and halo twice as bright per slider step (built at 6)
        local hilt_glow = opt("hilt_glow") or 1
        -- one material slot at a time: Unit.set_scalar_for_material(unit, slot, variable, value), as in ammo_display.lua:85 and syringe_case_color.lua:74
        pcall(Unit.set_scalar_for_material, rec.sword, "skull_runeblade_glow", "intensity", glow)
        pcall(Unit.set_scalar_for_material, rec.sword, "skull_runeblade_halo_a", "intensity", glow / 3)
        pcall(Unit.set_scalar_for_material, rec.sword, "skull_runeblade_halo_b", "intensity", glow / 3)
        pcall(Unit.set_scalar_for_material, rec.sword, "skull_runeblade_inner", "intensity", hilt_glow)
        rec.fitted = fit(rec.sword, base, attachments, k, key, profile, body_line) or rec.fitted
    end

    if rec.fitted and visible then
        hide_originals(base, attachments)
        rec.hid = true
        Unit.set_unit_visibility(rec.sword, true, true)
        if unit_ok(rec.fog) then
            Unit.set_unit_visibility(rec.fog, true, true)
        end
    else
        Unit.set_unit_visibility(rec.sword, false, true)
        if unit_ok(rec.fog) then
            Unit.set_unit_visibility(rec.fog, false, true)
        end
    end
    return true
end

local function clear_records(records, destroy_fn)
    if not records then
        return
    end
    for key, rec in pairs(records) do
        destroy_rec(rec, destroy_fn)
        records[key] = nil
    end
end

-- In-game (your own player unit) ------------------------------------------------

local function ingame_spawn(ext, is_first_person)
    return function(parent, unit_name)
        local world = ext.__qiangiq_srb_world
        local unit_spawner = Managers.state and Managers.state.unit_spawner
        if not (world and unit_spawner) then
            return nil
        end
        local unit = unit_spawner:spawn_unit(unit_name or SWORD_UNIT, Unit.world_pose(parent, 1))
        if not unit then
            return nil
        end
        if is_first_person then
            Unit.set_unit_culling(unit, false)
        end
        World.link_unit(world, unit, 1, parent, 1, World.LINK_MODE_NODE_NAME)
        return unit
    end
end

local function ingame_destroy(unit)
    if unit_ok(unit) then
        local unit_spawner = Managers.state and Managers.state.unit_spawner
        if unit_spawner then
            unit_spawner:mark_for_deletion(unit)
        end
    end
end

local function ingame_apply(ext)
    local records = ext.__qiangiq_srb_records
    if not records then
        records = {}
        ext.__qiangiq_srb_records = records
    end
    local equipment = ext._equipment
    if not equipment then
        return
    end
    for slot_name, slot in pairs(equipment) do
        local item = slot.item
        if item and item.weapon_template and MELEE_SET[item.weapon_template] or records[slot_name .. ":3p"] or records[slot_name .. ":1p"] then
            local base_3p, base_1p = slot.unit_3p, slot.unit_1p
            local att_3p = base_3p and slot.attachments_by_unit_3p and slot.attachments_by_unit_3p[base_3p]
            local att_1p = base_1p and slot.attachments_by_unit_1p and slot.attachments_by_unit_1p[base_1p]
            -- "body" reference for the tilt direction: the character's vertical axis in third
            -- person, the view direction through the first-person unit in first person
            sync_record(records, slot_name .. ":3p", base_3p, att_3p, item, slot.hidden_3p == false,
                ingame_spawn(ext, false), ingame_destroy, 1, false, function()
                    if unit_ok(ext._unit) then
                        return Unit.world_position(ext._unit, 1), Vector3.up()
                    end
                end)
            sync_record(records, slot_name .. ":1p", base_1p, att_1p, item, slot.hidden_1p == false,
                ingame_spawn(ext, true), ingame_destroy, 1, true, function()
                    local fp = ext._first_person_unit
                    if unit_ok(fp) then
                        return Unit.world_position(fp, 1), Quaternion.forward(Unit.world_rotation(fp, 1))
                    end
                end)
        end
    end
end

local function is_local_human(ext)
    return sync_shown(ext)
end

vl_hook_safe("init", function(self, extension_init_context)
    self.__qiangiq_srb_world = extension_init_context and extension_init_context.world
end)

vl_hook_safe("_update_item_visibility", function(self)
    if not is_local_human(self) then
        return
    end
    tracked[self] = true
    ingame_apply(self)
end)

vl_hook_safe("update", function(self)
    if tracked[self] then
        ingame_apply(self)
    end
end)

vl_hook("_unequip_item_from_slot", function(func, self, slot_name, ...)
    local records = self.__qiangiq_srb_records
    if records then
        for _, view in ipairs({ ":3p", ":1p" }) do
            local rec = records[slot_name .. view]
            if rec then
                destroy_rec(rec, ingame_destroy)
                records[slot_name .. view] = nil
            end
        end
    end
    return func(self, slot_name, ...)
end)

vl_hook("destroy", function(func, self, ...)
    clear_records(self.__qiangiq_srb_records, ingame_destroy)
    tracked[self] = nil
    return func(self, ...)
end)

-- Menu previews ---------------------------------------------------------------

local function ui_profile_is_mine(profile)
    -- __qiangiq_npc: the companion NPC spawned by QIangIQsCompanionSwap is nobody's character
    if not profile or profile.__qiangiq_npc then
        return false
    end
    local players = Managers.player and Managers.player:players()
    local me = local_player()
    if players and profile.character_id then
        for _, player in pairs(players) do
            if player ~= me and player.character_id and player:character_id() == profile.character_id then
                return false
            end
        end
    end
    return true
end

local function ui_spawn(world)
    return function(parent, unit_name)
        -- same calls ui_profile_spawner.lua uses for its own units
        local unit = World.spawn_unit_ex(world, unit_name or SWORD_UNIT, nil, Unit.world_pose(parent, 1))
        World.link_unit(world, unit, 1, parent, 1, World.LINK_MODE_NODE_NAME)
        return unit
    end
end

local function ui_destroy_fn(world)
    return function(unit)
        if unit_ok(unit) and world then
            World.destroy_unit(world, unit)
        end
    end
end

local function scale_x(unit)
    if unit_ok(unit) then
        local s = Unit.local_scale(unit, 1)
        return s and s.x or 1
    end
    return 1
end

-- operative select / inventory character preview
local function profile_apply(spawner)
    local world = spawner._world
    local records = spawner.__qiangiq_srb_records
    if not records then
        records = {}
        spawner.__qiangiq_srb_records = records
    end
    local data = spawner._character_spawn_data
    local allowed = data and data.slots and opt("menu_previews") and ui_profile_is_mine(data.profile)
    if not allowed then
        clear_records(records, ui_destroy_fn(world))
        return
    end
    tracked_ui[spawner] = true
    local k = scale_x(data.unit_3p)
    for slot_name, slot in pairs(data.slots) do
        local item = slot.item
        if item and item.weapon_template and MELEE_SET[item.weapon_template] or records[slot_name] then
            local base = slot.unit_3p
            local att = base and slot.attachments_by_unit_3p and slot.attachments_by_unit_3p[base]
            sync_record(records, slot_name, base, att, item, spawner._visible and slot.hidden_3p == false,
                ui_spawn(world), ui_destroy_fn(world), k, false, function()
                    if unit_ok(data.unit_3p) then
                        return Unit.world_position(data.unit_3p, 1), Vector3.up()
                    end
                end)
        end
    end
end

mod:hook_safe(CLASS.UIProfileSpawner, "_update_items_visibility", function(self)
    profile_apply(self)
end)

mod:hook_safe(CLASS.UIProfileSpawner, "update", function(self)
    local data = self._character_spawn_data
    if data and data.is_ready then
        profile_apply(self)
    elseif self.__qiangiq_srb_records then
        clear_records(self.__qiangiq_srb_records, ui_destroy_fn(self._world))
    end
end)

mod:hook(CLASS.UIProfileSpawner, "_despawn_current_character_profile", function(func, self, ...)
    clear_records(self.__qiangiq_srb_records, ui_destroy_fn(self._world))
    return func(self, ...)
end)

-- weapon inspect / inventory weapon preview
local function weapon_apply(spawner)
    local world = spawner._world
    local records = spawner.__qiangiq_srb_records
    if not records then
        records = {}
        spawner.__qiangiq_srb_records = records
    end
    local data = spawner._weapon_spawn_data
    if not (data and opt("menu_previews")) then
        if next(records) ~= nil then
            clear_records(records, ui_destroy_fn(world))
            if data and data.visible and unit_ok(data.item_unit_3p) then
                -- shown the same way ui_weapon_spawner.lua shows it
                Unit.set_unit_visibility(data.item_unit_3p, true, true)
            end
        end
        return
    end
    tracked_wpn[spawner] = true
    local base = data.item_unit_3p
    local att = base and data.attachment_units_3p and data.attachment_units_3p[base]
    local k = scale_x(data.link_unit) * scale_x(base)
    sync_record(records, "weapon", base, att, data.item, data.visible and true or false,
        ui_spawn(world), ui_destroy_fn(world), k, false)
end

mod:hook_safe(CLASS.UIWeaponSpawner, "update", function(self)
    weapon_apply(self)
end)

mod:hook(CLASS.UIWeaponSpawner, "_despawn_current_weapon", function(func, self, ...)
    clear_records(self.__qiangiq_srb_records, ui_destroy_fn(self._world))
    return func(self, ...)
end)

-- Refresh / toggles ------------------------------------------------------------

local function refresh_all()
    for ext in pairs(tracked) do
        if unit_ok(ext._unit) then
            ingame_apply(ext)
            -- restores the original weapon's visibility when a replacement was switched off
            ext:force_update_item_visibility()
        end
    end
    for spawner in pairs(tracked_ui) do
        profile_apply(spawner)
        if spawner._character_spawn_data and spawner._visible then
            spawner:_update_items_visibility()
        end
    end
    for spawner in pairs(tracked_wpn) do
        weapon_apply(spawner)
    end
end

local function tell_melee_arsenal(key)
    -- QIangIQsMeleeArsenal keeps per-weapon profiles instead of these settings: when this mod
    -- switches a weapon on, Melee Arsenal is told directly (QIangIQsMeleeArsenal.lua, mod.release_template)
    local melee = QIANGIQ_ARSENALS
    if melee and melee.release_template then
        for template, k in pairs(TEMPLATES) do
            if k == key then
                melee.release_template(template)
            end
        end
    end
end

local function switch_others_off(key)
    tell_melee_arsenal(key)
    for _, name in ipairs(SWORD_MODS) do
        if name ~= "QIangIQsSkullRuneblade" then
            local other = get_mod(name)
            if other and other:get(key) then
                other:set(key, false, true)
            end
        end
    end
end

-- both mods saved "on" for the same weapon (e.g. a newly installed mod): the later one in
-- SWORD_MODS keeps it
local function resolve_at_load()
    local mine = false
    for _, name in ipairs(SWORD_MODS) do
        if name == "QIangIQsSkullRuneblade" then
            mine = true
        elseif mine then
            local other = get_mod(name)
            for _, key in ipairs(REPLACE_SETTINGS) do
                if other and other:get(key) and opt(key) then
                    mod:set(key, false, false)
                end
            end
        end
    end
end

local function flip(key, label)
    session_override[key] = not setting_on(key)
    if session_override[key] then
        switch_others_off(key)
    end
    refresh_all()
    mod:echo("%s replacement %s", label, session_override[key] and "on" or "off")
end

mod.toggle_duelling_sword = function()
    flip("replace_duelling_sword", "Duelling Sword Mk IV")
end

mod.toggle_relic_blade = function()
    flip("replace_relic_blade", "Relic Blade Mk II")
end

mod:command("skullblade", "Toggle the Skull Runeblade replacements: /skullblade [duelling|relic|debug]", function(which)
    if which == "debug" then
        local any = false
        for _, line in pairs(last_fit) do
            mod:echo(line)
            any = true
        end
        if not any then
            mod:echo("No sword fitted yet: wield a replaced weapon first.")
        end
        return
    elseif which == "duelling" then
        mod.toggle_duelling_sword()
    elseif which == "relic" then
        mod.toggle_relic_blade()
    else
        mod_on = not mod_on
        refresh_all()
        mod:echo("Skull Runeblade %s", mod_on and "on" or "off")
    end
end)

-- Per-weapon profiles (the selection logic follows QIangIQsCookedMacroManager.lua, mod.on_setting_changed) ----

-- template name of the equipped melee weapon, read as CookedMacroManager's mod.get_equipped("MELEE") does
local function equipped_melee()
    local player = local_player()
    local player_unit = player and player.player_unit
    local weapon_extension = player_unit and ScriptUnit.has_extension(player_unit, "weapon_system")
    local weapons = weapon_extension and weapon_extension._weapons
    local weapon = weapons and weapons.slot_primary
    local weapon_template = weapon and weapon.weapon_template
    return weapon_template and weapon_template.name
end

local function selected_weapon()
    local sel = opt("weapon_selection")
    return sel and MELEE_SET[sel] and sel or DEFAULT_WEAPON
end

-- puts the selected weapon's profile into the widgets
local function show_profile(template)
    local p = profile_for(template)
    for key, default in pairs(PROFILE_TEMPLATE) do
        local value = p[key]
        if value == nil then
            value = default
        end
        mod:set(key, value, false)
    end
    local legacy = TEMPLATES[template]
    if legacy then
        mod:set("profile_enabled", opt(legacy) and true or false, false)
    end
end

local function load_profiles()
    profiles = opt("profiles")
    if type(profiles) ~= "table" then
        -- first run of v1.6: carry over the old global size / grip and the two per-weapon tilts
        profiles = {}
        local size, grip = opt("model_size") or 1, opt("grip_shift") or 0
        local relic = table.clone(PROFILE_TEMPLATE)
        relic.profile_scale, relic.profile_grip, relic.profile_tilt = size, grip, opt("relic_tilt") or 0
        profiles.powersword_2h_p1_m2 = relic
        local duelling = table.clone(PROFILE_TEMPLATE)
        duelling.profile_scale, duelling.profile_grip = size, grip
        local duelling_tilt = opt("duelling_tilt")
        duelling.profile_tilt = duelling_tilt == nil and 45 or duelling_tilt
        profiles.combatsword_p3_m2 = duelling
        mod:set("profiles", profiles, false)
    end
    -- the two on/off settings no longer have widgets of their own, so they have no default either
    if opt("replace_relic_blade") == nil then
        mod:set("replace_relic_blade", true, false)
    end
    if opt("replace_duelling_sword") == nil then
        mod:set("replace_duelling_sword", false, false)
    end
    show_profile(selected_weapon())
end

-- called by QIangIQsMeleeArsenal when it switches this weapon on: the profile here goes off
mod.release_template = function(template)
    if TEMPLATES[template] then
        if opt(TEMPLATES[template]) then
            mod:set(TEMPLATES[template], false, true)
        end
        return
    end
    if profiles and profiles[template] and profiles[template].profile_enabled then
        profiles[template].profile_enabled = false
        mod:set("profiles", profiles, false)
        if selected_weapon() == template then
            mod:set("profile_enabled", false, false)
        end
        fit_generation = fit_generation + 1
        refresh_all()
        mod:echo("%s is now shown by Melee Arsenal: switched off here.", template)
    end
end

mod.on_setting_changed = function(setting_id)
    if setting_id then
        session_override[setting_id] = nil
    end
    local sel = selected_weapon()
    if setting_id == "weapon_selection" then
        show_profile(sel)
    elseif setting_id == "current_weapon" then
        if opt("current_weapon") then
            local equipped = equipped_melee()
            if equipped and MELEE_SET[equipped] then
                mod:set("weapon_selection", equipped, false)
                show_profile(equipped)
            else
                mod:echo("No listed melee weapon is equipped right now.")
            end
            mod:set("current_weapon", false, false)
        end
    elseif setting_id == "reset_weapon" then
        if opt("reset_weapon") then
            if profiles then
                profiles[sel] = table.clone(PROFILE_TEMPLATE)
                mod:set("profiles", profiles, false)
            end
            if TEMPLATES[sel] then
                mod:set(TEMPLATES[sel], false, false)
            end
            show_profile(sel)
            mod:set("reset_weapon", false, false)
        end
    elseif setting_id == "reset_all" then
        if opt("reset_all") then
            profiles = {}
            mod:set("profiles", profiles, false)
            for _, key in ipairs(REPLACE_SETTINGS) do
                mod:set(key, false, false)
            end
            show_profile(sel)
            mod:set("reset_all", false, false)
        end
    elseif setting_id and PROFILE_TEMPLATE[setting_id] ~= nil then
        if profiles then
            local p = profile_for(sel, true)
            p[setting_id] = opt(setting_id)
            mod:set("profiles", profiles, false)
        end
        local legacy = TEMPLATES[sel]
        if setting_id == "profile_enabled" and not legacy and opt("profile_enabled") then
            local melee = QIANGIQ_ARSENALS
            if melee and melee.release_template then
                melee.release_template(sel)
            end
        end
        if setting_id == "profile_enabled" and legacy then
            local on = opt("profile_enabled") and true or false
            mod:set(legacy, on, false)
            session_override[legacy] = nil
            if on then
                switch_others_off(legacy)
            end
        end
    elseif setting_id and TEMPLATES_BY_SETTING[setting_id] then
        -- switched from another QIangIQ sword mod or a keybind
        if opt(setting_id) then
            switch_others_off(setting_id)
        end
        if TEMPLATES[sel] == setting_id then
            mod:set("profile_enabled", opt(setting_id) and true or false, false)
        end
    end
    fit_generation = fit_generation + 1
    refresh_all()
end

-- Package loading through Custom Assets --------------------------------------

mod.on_all_mods_loaded = function()
    resolve_at_load()
    load_profiles()
    custom_assets = get_mod("CustomAssets")
    if not custom_assets or not custom_assets.is_api_compatible or not custom_assets.is_api_compatible(1) then
        mod:error("Custom Assets (API 1) is missing. Install it and put it above QIangIQsSkullRuneblade in mod_load_order.txt.")
        return
    end
    local ticket, err = custom_assets.acquire(mod, SWORD_ID, function(_, _, load_error)
        if load_error then
            mod:error("%s failed to load: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", SWORD_ID, tostring(load_error))
            return
        end
        ready = true
        refresh_all()
    end, { resident = true, reference_name = SWORD_ID })
    if not ticket then
        mod:error("%s could not be requested: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", SWORD_ID, tostring(err))
    end
    -- the haze is optional: without it the sword is shown as before
    local fog_ticket, fog_err = custom_assets.acquire(mod, FOG_ID, function(_, _, load_error)
        if load_error then
            mod:warning("%s failed to load, the sword is shown without the skull haze: %s", FOG_ID, tostring(load_error))
            return
        end
        fog_ready = true
        refresh_all()
    end, { resident = true, reference_name = FOG_ID })
    if not fog_ticket then
        mod:warning("%s could not be requested, the sword is shown without the skull haze: %s", FOG_ID, tostring(fog_err))
    end
end

local function remove_all()
    for ext in pairs(tracked) do
        clear_records(ext.__qiangiq_srb_records, ingame_destroy)
    end
    for spawner in pairs(tracked_ui) do
        clear_records(spawner.__qiangiq_srb_records, ui_destroy_fn(spawner._world))
    end
    for spawner in pairs(tracked_wpn) do
        clear_records(spawner.__qiangiq_srb_records, ui_destroy_fn(spawner._world))
    end
end

mod.on_disabled = function()
    remove_all()
    -- hooks are off now, so these restore the original weapon visibility
    for ext in pairs(tracked) do
        if unit_ok(ext._unit) then
            ext:force_update_item_visibility()
        end
    end
    for spawner in pairs(tracked_ui) do
        if spawner._character_spawn_data and spawner._visible then
            spawner:_update_items_visibility()
        end
    end
    for spawner in pairs(tracked_wpn) do
        local data = spawner._weapon_spawn_data
        if data and data.visible and unit_ok(data.item_unit_3p) then
            Unit.set_unit_visibility(data.item_unit_3p, true, true)
        end
    end
end

mod.on_enabled = function()
    refresh_all()
end

mod.on_unload = function()
    remove_all()
    if custom_assets and custom_assets.release_owner then
        custom_assets.release_owner(mod)
    end
end


-- Cross-client sync: what this mod publishes about me, and the refresh when anyone's options change ---------
local function sync_carried(info)
    local list = {}
    for i = 1, #MELEE_LIST do
        local template = MELEE_LIST[i]
        if template_on(template) and (info.templates == nil or info.templates[template]) then
            list[#list + 1] = template
        end
    end
    return list
end

local function sync_applies(info)
    return #sync_carried(info) > 0
end

-- the per-weapon profiles of the weapons I carry travel as an extra element: { [template] = { scale, tilt, roll, grip } }
sync_extra_import = function(t, extra)
    local list = {}
    if type(extra) == "table" then
        for template, v in pairs(extra) do
            if type(template) == "string" and type(v) == "table" then
                list[template] = {
                    profile_enabled = true,
                    profile_scale = tonumber(v[1]) or 1,
                    profile_tilt = tonumber(v[2]) or 0,
                    profile_roll = tonumber(v[3]) or 0,
                    profile_grip = tonumber(v[4]) or 0,
                }
            end
        end
    end
    rawset(t, "__profiles", list)
end

local TEMPLATES_KEYS = {}
for _, key in pairs(TEMPLATES) do
    TEMPLATES_KEYS[key] = true
end

local sync_enabled = true
local function sync_changed()
    local api = sync_api()
    if api then
        api.changed()
    end
end

mod.sync_key = SYNC_KEY
-- info = { breed, companion_breed, templates = { [weapon_template] = true } } of my own character (fields nil
-- while I have no unit). Returns the array to publish, or nil when this mod shows nothing on my character.
mod.sync_export = function(info)
    info = info or {}
    if not sync_enabled or not sync_applies(info) then
        return nil
    end
    local mask, bit = 0, 1
    for i = 1, #SYNC_BOOLS do
        local key = SYNC_BOOLS[i]
        local v = nil
        if TEMPLATES_KEYS[key] then
            v = setting_on(key)
        else
            v = mod:get(key)
        end
        if v == nil then
            v = SYNC_DEFAULTS[key]
        end
        if v then
            mask = mask + bit
        end
        bit = bit * 2
    end
    local out = { SYNC_LAYOUT, mask }
    for i = 1, #SYNC_VALUES do
        local v = mod:get(SYNC_VALUES[i])
        if type(v) == "number" then
            v = math.floor(v * 100 + 0.5) / 100
        elseif type(v) ~= "string" then
            v = false -- not set: the reader falls back to its default
        end
        out[2 + i] = v
    end
    local extra, carried = {}, sync_carried(info)
    for i = 1, math.min(#carried, 2) do
        local p = profile_for(carried[i])
        local function r(v, default)
            return math.floor((tonumber(v) or default) * 100 + 0.5) / 100
        end
        extra[carried[i]] = { r(p.profile_scale, 1), r(p.profile_tilt, 0), r(p.profile_roll, 0), r(p.profile_grip, 0) }
    end
    out[3 + #SYNC_VALUES] = extra
    return out
end

mod.sync_refresh = function()
    for ext in pairs(sync_all) do
        if ext._unit and Unit.alive(ext._unit) and ext.force_update_item_visibility then
            pcall(ext.force_update_item_visibility, ext)
        end
    end
end

local sync_prev_setting_changed = mod.on_setting_changed
mod.on_setting_changed = function(...)
    if sync_prev_setting_changed then
        sync_prev_setting_changed(...)
    end
    sync_changed()
end

local sync_prev_disabled = mod.on_disabled
mod.on_disabled = function(...)
    sync_enabled = false
    if sync_prev_disabled then
        sync_prev_disabled(...)
    end
    sync_changed()
end

local sync_prev_enabled = mod.on_enabled
mod.on_enabled = function(...)
    sync_enabled = true
    if sync_prev_enabled then
        sync_prev_enabled(...)
    end
    sync_changed()
end

-- QIangIQsArmoryVis: stowed-weapon copies (see QIangIQsArmoryVis/README.md). Armory Vis calls apply every frame
-- and clear once per copy with `holder` (one table per character and stowed slot: _unit, _player, _ext,
-- _slot_name) and `equipment` ({ [slot_name] = slot-like table of the copy, hidden_3p false while shown }).
-- The in-game apply above runs on the holder as it runs on a loadout extension.
mod.armory_vis = {
    apply = function(holder, world, equipment)
        holder.__qiangiq_srb_world = world
        holder._equipment = equipment
        ingame_apply(holder)
    end,
    clear = function(holder)
        clear_records(holder.__qiangiq_srb_records, ingame_destroy)
        holder.__qiangiq_srb_records = nil
    end,
}
