return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsSkullRuneblade` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsSkullRuneblade", {
            mod_script = "QIangIQsSkullRuneblade/scripts/mods/QIangIQsSkullRuneblade/QIangIQsSkullRuneblade",
            mod_data = "QIangIQsSkullRuneblade/scripts/mods/QIangIQsSkullRuneblade/QIangIQsSkullRuneblade_data",
            mod_localization = "QIangIQsSkullRuneblade/scripts/mods/QIangIQsSkullRuneblade/QIangIQsSkullRuneblade_localization",
        })
    end,
    version = "1.8.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
