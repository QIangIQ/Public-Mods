local localizations = {
    mod_name = {
        en = "QIangIQ's Skull Runeblade",
    },
    mod_description = {
        en = "Shows QIangIQ's skull runeblade (rebuilt from reference screenshots, Custom Assets) in place of any melee weapon you switch on. Each weapon has its own profile: on/off, size, tilt, rotation and grip position. By QIangIQ.",
    },
    weapon_selection = {
        en = "Weapon to set up",
    },
    weapon_selection_description = {
        en = "The settings below (replace, size, tilt, roll, grip) belong to the weapon chosen here. Every weapon keeps its own values.",
    },
    current_weapon = {
        en = "Jump to the equipped melee weapon",
    },
    current_weapon_description = {
        en = "Selects the melee weapon you are carrying right now (in a mission or the hub), then switches itself off again.",
    },
    profile_enabled = {
        en = "Replace this weapon with the Skull Runeblade",
    },
    profile_scale = {
        en = "Size (this weapon)",
    },
    profile_scale_description = {
        en = "Scales the whole sword about the hand. 1 = sized from this weapon's own reach.",
    },
    profile_tilt = {
        en = "Tilt (this weapon, degrees)",
    },
    profile_tilt_description = {
        en = "Turns the sword in the plane of its flat side, pivoting on the hand. Positive = tip away from your body / view centre, negative = towards it.",
    },
    profile_roll = {
        en = "Rotation about the blade (this weapon, degrees)",
    },
    profile_roll_description = {
        en = "Turns the sword about its own length. 180 puts the cutting edge on the other side, for weapons where the edge would face you.",
    },
    profile_grip = {
        en = "Grip position (this weapon)",
    },
    profile_grip_description = {
        en = "Moves the point of the sword that sits in the hand, in blade lengths. Positive = hold nearer the guard and blade, negative = hold nearer the pommel. The handle runs from about 0.11 to -0.11 around the default.",
    },
    reset_weapon = {
        en = "Reset this weapon",
    },
    reset_weapon_description = {
        en = "Puts the chosen weapon back to: not replaced, size 1, tilt 0, rotation 0, grip 0.",
    },
    reset_all = {
        en = "Reset all weapons",
    },
    glow_brightness = {
        en = "Rune and skull glow brightness",
    },
    glow_brightness_description = {
        en = "Brightness of the green runes, the skull's eyes and the soft glow around the skull. 0 = no glow, 3 = as built (twice as bright as before v1.7).",
    },
    hilt_glow = {
        en = "Hilt glow brightness",
    },
    hilt_glow_description = {
        en = "Brightness of the faint glow of the gold parts of guard, handle and pommel, separate from the blade. 0 = none, 1 = as built (far below the runes).",
    },
    skull_fog = {
        en = "Skull haze",
    },
    skull_fog_description = {
        en = "Thin green haze in the notch between the rim and the skull. See-through; it is lit by the surroundings and does not glow on its own.",
    },
    menu_previews = {
        en = "Show in menus (inventory, operative previews)",
    },
    menu_previews_description = {
        en = "Also swaps the weapon in menu previews of your own operatives and in the weapon inspect view.",
    },
    toggle_duelling_keybind = {
        en = "Toggle Duelling Sword replacement",
    },
    toggle_relic_keybind = {
        en = "Toggle Relic Blade replacement",
    },
}

-- Names for the weapon dropdown, built from the game's own strings the way
-- QIangIQsCookedMacroManager_localization.lua builds them (pattern, mark, family); the template id is the fallback.
local MELEE_LIST = {
    "chainaxe_p1_m1",
    "chainaxe_p1_m2",
    "chainsword_p1_m1",
    "chainsword_p1_m2",
    "chainsword_2h_p1_m1",
    "chainsword_2h_p1_m2",
    "combataxe_p1_m1",
    "combataxe_p1_m2",
    "combataxe_p1_m3",
    "combataxe_p2_m1",
    "combataxe_p2_m2",
    "combataxe_p2_m3",
    "combataxe_p3_m1",
    "combataxe_p3_m2",
    "combataxe_p3_m3",
    "ogryn_combatblade_p1_m1",
    "ogryn_combatblade_p1_m2",
    "ogryn_combatblade_p1_m3",
    "combatknife_p1_m1",
    "combatknife_p1_m2",
    "combatsword_p1_m1",
    "combatsword_p1_m2",
    "combatsword_p1_m3",
    "combatsword_p2_m1",
    "combatsword_p2_m2",
    "combatsword_p2_m3",
    "combatsword_p3_m1",
    "combatsword_p3_m2",
    "combatsword_p3_m3",
    "forcesword_p1_m1",
    "forcesword_p1_m2",
    "forcesword_p1_m3",
    "forcesword_2h_p1_m1",
    "forcesword_2h_p1_m2",
    "ogryn_gauntlet_p1_m1",
    "ogryn_club_p1_m1",
    "ogryn_club_p1_m2",
    "ogryn_club_p1_m3",
    "ogryn_club_p2_m1",
    "ogryn_club_p2_m2",
    "ogryn_club_p2_m3",
    "ogryn_pickaxe_2h_p1_m1",
    "ogryn_pickaxe_2h_p1_m2",
    "ogryn_pickaxe_2h_p1_m3",
    "ogryn_powermaul_p1_m1",
    "ogryn_powermaul_slabshield_p1_m1",
    "powermaul_p1_m1",
    "powermaul_p1_m2",
    "powermaul_shield_p1_m1",
    "powermaul_shield_p1_m2",
    "powermaul_p2_m1",
    "powermaul_2h_p1_m1",
    "powersword_p1_m1",
    "powersword_p1_m2",
    "powersword_p2_m1",
    "powersword_p2_m2",
    "powersword_2h_p1_m1",
    "powersword_2h_p1_m2",
    "thunderhammer_2h_p1_m1",
    "thunderhammer_2h_p1_m2",
    "saw_p1_m1",
    "crowbar_p1_m1",
    "dual_shivs_p1_m1",
    "dual_shivs_p1_m2",
    "transonic_sword_transonic_knife_p1_m1",
    "powermaul_p3_m1",
    "powersword_p3_m1",
}
for i = 1, #MELEE_LIST do
    local weapon = MELEE_LIST[i]
    local name = weapon
    local ok, localized = pcall(function()
        local family = Localize("loc_weapon_family_" .. weapon)
        local pattern = Localize("loc_weapon_pattern_" .. weapon)
        if not pattern or string.find(pattern, "unlocalized") then
            pattern = Localize("loc_weapon_pattern_" .. weapon:gsub("_m%d+", "_m1"))
        end
        local mark = Localize("loc_weapon_mark_" .. weapon)
        return family and pattern and mark and string.format("%s %s %s", pattern, mark, family)
    end)
    if ok and localized and not string.find(localized, "unlocalized") then
        name = localized
    end
    localizations[weapon] = { en = name }
end

return localizations
