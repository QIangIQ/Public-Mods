return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsOrdis` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsOrdis", {
            mod_script = "QIangIQsOrdis/scripts/mods/QIangIQsOrdis/QIangIQsOrdis",
            mod_data = "QIangIQsOrdis/scripts/mods/QIangIQsOrdis/QIangIQsOrdis_data",
            mod_localization = "QIangIQsOrdis/scripts/mods/QIangIQsOrdis/QIangIQsOrdis_localization",
        })
    end,
    version = "1.0.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
