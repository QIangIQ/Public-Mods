return {
    mod_name = {
        en = "QIangIQ's Ordis",
    },
    mod_description = {
        en = "Shows Ordis (Warframe, taken from your own game install) in place of your own companion servo-skull: the Ordis figure or the Ordis owl plush. Personal use only. By QIangIQ.",
    },
    replace_skull = {
        en = "Replace your servo-skull with Ordis",
    },
    replace_skull_description = {
        en = "Companion breed companion_servo_skull, your own companion only. Turning this on switches QIangIQ's Paimon off. Chat command: /ordis",
    },
    ordis_model = {
        en = "Model",
    },
    ordis_model_description = {
        en = "Which Ordis model is shown.",
    },
    ordis_model_figure = {
        en = "Ordis figure (with cape cloths)",
    },
    ordis_model_plush = {
        en = "Ordis owl plush",
    },
    ordis_size = {
        en = "Size (x servo-skull)",
    },
    ordis_size_description = {
        en = "Ordis' height as a multiple of the servo-skull's largest dimension.",
    },
    ordis_height = {
        en = "Height offset (x servo-skull)",
    },
    ordis_height_description = {
        en = "Moves Ordis up (+) or down (-), in servo-skull sizes. 0 = centred on the skull.",
    },
    ordis_turn = {
        en = "Turn (degrees)",
    },
    ordis_turn_description = {
        en = "Turns Ordis left/right relative to the direction the servo-skull faces.",
    },
    menu_previews = {
        en = "Show in menus (operative previews)",
    },
    menu_previews_description = {
        en = "Also swaps the servo-skull shown with your own operatives in menu previews.",
    },
    toggle_keybind = {
        en = "Toggle Ordis",
    },
}
