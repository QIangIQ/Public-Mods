return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsBoltgunChainsword` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsBoltgunChainsword", {
            mod_script = "QIangIQsBoltgunChainsword/scripts/mods/QIangIQsBoltgunChainsword/QIangIQsBoltgunChainsword",
            mod_data = "QIangIQsBoltgunChainsword/scripts/mods/QIangIQsBoltgunChainsword/QIangIQsBoltgunChainsword_data",
            mod_localization = "QIangIQsBoltgunChainsword/scripts/mods/QIangIQsBoltgunChainsword/QIangIQsBoltgunChainsword_localization",
        })
    end,
    version = "0.1.0",
    author = "QIangIQ",
    packages = {},
}
