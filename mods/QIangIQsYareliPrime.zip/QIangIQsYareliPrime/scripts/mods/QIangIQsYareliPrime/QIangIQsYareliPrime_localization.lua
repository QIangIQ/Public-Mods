return {
    mod_name = {
        en = "QIangIQ's Yareli Prime",
    },
    mod_description = {
        en = "Replaces your own human character with Yareli Prime (Warframe, taken from your own game install) as a Custom Assets model: third person, first-person arms and menu previews, with physics on her skirts, fins, frills and helmet tail. Only one QIangIQ human character model is shown at a time. Personal use only. By QIangIQ.",
    },
    model_enabled = {
        en = "Show the Yareli Prime model",
    },
    model_enabled_description = {
        en = "Turning this on switches the other QIangIQ human character models off. Chat command: /yareliprime",
    },
    hide_body = {
        en = "Hide original body and cosmetics",
    },
    hide_body_description = {
        en = "Hides your character's body, face, hair and gear slots while the model is shown. Weapons stay visible.",
    },
    first_person_arms = {
        en = "Model arms in first person",
    },
    first_person_arms_description = {
        en = "Replaces the first-person arms and gloves with the model's arms.",
    },
    menu_previews = {
        en = "Show in menus (operative select, inventory)",
    },
    menu_previews_description = {
        en = "Shows the model on your own operatives in menu previews. Other players' characters are left alone. Ogryns are never replaced.",
    },
    physics_group = {
        en = "Physics",
    },
    jiggle = {
        en = "Physics on",
    },
    jiggle_description = {
        en = "Physics on the model's her skirts, fins, frills and helmet tail.",
    },
    jiggle_cloth = {
        en = "Amount: clothing and chains",
    },
    jiggle_cloth_description = {
        en = "1 = as built. Higher = looser and wider swings, lower = tighter. 0 = this area does not move.",
    },
    jiggle_stiffness = {
        en = "Stiffness (all areas except the tail)",
    },
    jiggle_stiffness_description = {
        en = "How hard everything is pulled back to its rest pose. 1 = as built. Higher = snaps back faster, lower = softer and slower.",
    },
    jiggle_damping = {
        en = "Damping (all areas except the tail)",
    },
    jiggle_damping_description = {
        en = "How quickly the wobble dies out. 1 = as built. Higher = settles at once, lower = keeps bouncing longer.",
    },
    jiggle_limit = {
        en = "Swing limit (all areas except the tail)",
    },
    jiggle_limit_description = {
        en = "Scales the largest angle a bone may swing away from its rest pose. 1 = as built.",
    },
    jiggle_hang = {
        en = "Hang (clothing)",
    },
    jiggle_hang_description = {
        en = "How strongly loose clothing is drawn straight down instead of keeping its modelled direction when you lean or look up and down. 0 = keep the modelled shape. Hair and tail have their own gravity settings.",
    },
    board_group = {
        en = "Board (Prime Merulina)",
    },
    board_on = {
        en = "Ride her board",
    },
    board_on_description = {
        en = "Yareli Prime's board (Prime Merulina, from your Warframe install): she rides it in her riding stance with its soft side-to-side sway (both from her Warframe board idle). Only her look changes.",
    },
    board_scale = {
        en = "Board size",
    },
    board_scale_description = {
        en = "1 = its size in Warframe (about 1.9 m wide, 4.8 m with the tails).",
    },
    board_height = {
        en = "Riding height (m)",
    },
    board_height_description = {
        en = "Height of the deck above the ground; she is lifted onto it by the same amount (her weapons follow). 0.6 = the board's underside just above the floor at size 1.",
    },
    board_yaw = {
        en = "Board facing (degrees)",
    },
    board_yaw_description = {
        en = "Turns the board under her. 0 = nose forward, 90 = sideways like a surf stance.",
    },
    board_pitch = {
        en = "Board tilt (degrees)",
    },
    board_pitch_description = {
        en = "Tilts the nose up (+) or down (-).",
    },
    board_roll = {
        en = "Board roll (degrees)",
    },
    board_roll_description = {
        en = "Rolls the board to the right (+) or left (-).",
    },
    board_x = {
        en = "Board shift right / left (cm)",
    },
    board_x_description = {
        en = "Moves the board to her right (+) or left (-).",
    },
    board_y = {
        en = "Board shift forward / back (cm)",
    },
    board_y_description = {
        en = "Moves the board forward (+) or back (-) under her.",
    },
    board_camera = {
        en = "Raise my camera with her",
    },
    board_camera_description = {
        en = "First person: your view rises by the riding height. Shots and melee still start at your normal eye height; the crosshair is moved to where they land.",
    },
    toggle_keybind = {
        en = "Toggle Yareli Prime model",
    },
}
