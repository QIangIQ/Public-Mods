local mod = get_mod("QIangIQsYareliPrime")

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = true,
    options = {
        widgets = {
            {
                setting_id = "model_enabled",
                type = "checkbox",
                default_value = false,
            },
            {
                setting_id = "hide_body",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "first_person_arms",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "menu_previews",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "physics_group",
                type = "group",
                sub_widgets = {
                    {
                        setting_id = "jiggle",
                        type = "checkbox",
                        default_value = true,
                    },
                    {
                        setting_id = "jiggle_cloth",
                        type = "numeric",
                        default_value = 1,
                        range = { 0, 3 },
                        decimals_number = 2,
                    },
                    {
                        setting_id = "jiggle_stiffness",
                        type = "numeric",
                        default_value = 1,
                        range = { 0.25, 3 },
                        decimals_number = 2,
                    },
                    {
                        setting_id = "jiggle_damping",
                        type = "numeric",
                        default_value = 1,
                        range = { 0.25, 3 },
                        decimals_number = 2,
                    },
                    {
                        setting_id = "jiggle_limit",
                        type = "numeric",
                        default_value = 1,
                        range = { 0.25, 3 },
                        decimals_number = 2,
                    },
                    {
                        setting_id = "jiggle_hang",
                        type = "numeric",
                        default_value = 0.15,
                        range = { 0, 1 },
                        decimals_number = 2,
                    },
                },
            },
            {
                setting_id = "board_group",
                type = "group",
                sub_widgets = {
                    {
                        setting_id = "board_on",
                        type = "checkbox",
                        default_value = false,
                    },
                    {
                        setting_id = "board_scale",
                        type = "numeric",
                        default_value = 1,
                        range = { 0.2, 2 },
                        decimals_number = 2,
                    },
                    {
                        setting_id = "board_height",
                        type = "numeric",
                        default_value = 0.6,
                        range = { 0, 1.5 },
                        decimals_number = 2,
                    },
                    {
                        setting_id = "board_yaw",
                        type = "numeric",
                        default_value = 0,
                        range = { -180, 180 },
                        decimals_number = 0,
                    },
                    {
                        setting_id = "board_pitch",
                        type = "numeric",
                        default_value = 0,
                        range = { -90, 90 },
                        decimals_number = 0,
                    },
                    {
                        setting_id = "board_roll",
                        type = "numeric",
                        default_value = 0,
                        range = { -90, 90 },
                        decimals_number = 0,
                    },
                    {
                        setting_id = "board_x",
                        type = "numeric",
                        default_value = 0,
                        range = { -60, 60 },
                        decimals_number = 0,
                    },
                    {
                        setting_id = "board_y",
                        type = "numeric",
                        default_value = 0,
                        range = { -100, 100 },
                        decimals_number = 0,
                    },
                    {
                        setting_id = "board_camera",
                        type = "checkbox",
                        default_value = false,
                    },
                },
            },
            {
                setting_id = "toggle_keybind",
                type = "keybind",
                default_value = {},
                keybind_trigger = "pressed",
                keybind_type = "function_call",
                function_name = "toggle_model",
            },
        },
    },
}
