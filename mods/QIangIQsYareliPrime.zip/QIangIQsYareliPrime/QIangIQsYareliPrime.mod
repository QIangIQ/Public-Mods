return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsYareliPrime` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsYareliPrime", {
            mod_script = "QIangIQsYareliPrime/scripts/mods/QIangIQsYareliPrime/QIangIQsYareliPrime",
            mod_data = "QIangIQsYareliPrime/scripts/mods/QIangIQsYareliPrime/QIangIQsYareliPrime_data",
            mod_localization = "QIangIQsYareliPrime/scripts/mods/QIangIQsYareliPrime/QIangIQsYareliPrime_localization",
        })
    end,
    version = "1.0.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
