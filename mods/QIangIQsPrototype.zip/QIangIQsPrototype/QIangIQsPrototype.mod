return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsPrototype` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsPrototype", {
            mod_script = "QIangIQsPrototype/scripts/mods/QIangIQsPrototype/QIangIQsPrototype",
            mod_data = "QIangIQsPrototype/scripts/mods/QIangIQsPrototype/QIangIQsPrototype_data",
            mod_localization = "QIangIQsPrototype/scripts/mods/QIangIQsPrototype/QIangIQsPrototype_localization",
        })
    end,
    version = "1.3.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
