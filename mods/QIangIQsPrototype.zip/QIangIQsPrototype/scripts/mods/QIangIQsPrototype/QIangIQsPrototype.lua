-- QIangIQ's Prototype: shows a Custom Assets model in place of the
-- M35 Magnacore Mk II Plasma Gun (weapon template plasmagun_p1_m1).
-- Author: QIangIQ
local mod = get_mod("QIangIQsPrototype")

-- Cross-client sync ---------------------------------------------------------------
-- QIangIQsModelSync publishes which QIangIQ replacer mods a player has on, with their options, through
-- Vox Manifold (the transport Dio's Wardrobe shares outfits with). No asset data is sent: every client shows
-- the model from its own installed files. While another player's unit is worked on, sync_ctx holds that
-- player's options and opt() answers from them; for my own unit opt() is mod:get().
local SYNC_KEY = "proto"
local SYNC_BOOLS = { "replace_weapon", "flip_model" }
local SYNC_DEFAULTS = { replace_weapon = true, flip_model = false }
local SYNC_VALUES = { "model_size", "model_roll", "model_slide", "glow_idle", "glow_hot" }
local SYNC_LAYOUT = #SYNC_BOOLS * 100 + #SYNC_VALUES -- a peer on another version of this mod is not decoded
local sync_ctx = nil
local sync_known = setmetatable({}, { __mode = "k" })   -- other players' extensions this mod has shown something on
local sync_all = setmetatable({}, { __mode = "k" })     -- every visual loadout extension seen
local sync_decoded = setmetatable({}, { __mode = "k" }) -- published array -> options table
local SYNC_FALSE = { __index = function() return false end }
local SYNC_OFF = setmetatable({}, SYNC_FALSE)           -- "everything off": removes what was shown
local sync_extra_import = nil

local function opt(key)
    if sync_ctx then
        return sync_ctx[key]
    end
    return mod:get(key)
end

local function sync_api()
    local hub = get_mod("QIangIQsModelSync")
    return hub and hub.api
end

local function sync_me()
    local players = Managers.player
    if not players then
        return nil
    end
    local ok, player = pcall(players.local_player_safe, players, 1)
    return ok and player or nil
end

-- published array { layout, checkbox bits, value, value, ... [, extra] } -> options by setting id
local function sync_decode(raw)
    local t = sync_decoded[raw]
    if t ~= nil then
        return t
    end
    t = false
    if type(raw) == "table" and raw[1] == SYNC_LAYOUT then
        t = setmetatable({}, SYNC_FALSE)
        local mask = tonumber(raw[2]) or 0
        for i = 1, #SYNC_BOOLS do
            t[SYNC_BOOLS[i]] = mask % 2 >= 1
            mask = math.floor(mask / 2)
        end
        for i = 1, #SYNC_VALUES do
            local v = raw[2 + i]
            if v ~= nil then
                t[SYNC_VALUES[i]] = v
            end
        end
        if sync_extra_import then
            sync_extra_import(t, raw[3 + #SYNC_VALUES])
        end
    end
    sync_decoded[raw] = t
    return t
end

-- whose options apply to this extension: nil = mine, a table = that player's (SYNC_OFF when they publish
-- nothing for this mod)
local function sync_owner(ext)
    sync_all[ext] = true
    local player = ext._player
    if player == nil or player == sync_me() then
        return nil
    end
    local api = sync_api()
    local raw = api and api.peer(SYNC_KEY, player)
    local state = raw and sync_decode(raw)
    if state then
        sync_known[ext] = true
        return state
    end
    return SYNC_OFF
end

-- my own unit, or another player's unit this mod is (or was) showing something on
local function sync_shown(ext)
    local player = ext._player
    return player ~= nil and (player == sync_me() or sync_known[ext] == true)
end

local function sync_pack(...)
    return { n = select("#", ...), ... }
end

-- runs a hook body with the options of the extension's owner
local function sync_wrap(fn, ext_index)
    return function(...)
        local ext = select(ext_index, ...)
        local previous = sync_ctx
        sync_ctx = sync_owner(ext)
        local results = sync_pack(pcall(fn, ...))
        sync_ctx = previous
        if not results[1] then
            error(results[2], 0)
        end
        return unpack(results, 2, results.n)
    end
end

-- The same hook on my own unit's extension and on other players' (husk) extensions. While the mods load, the
-- classes do not exist yet: CLASS.<name> is then only the name and DMF delays the hook ("needs to be delayed"
-- in the log), so the husk class cannot be inspected here. Its methods are taken from
-- player_husk_visual_loadout_extension.lua instead.
local SYNC_HUSK_METHODS = { init = true, update = true, _update_item_visibility = true, destroy = true }

local function vl_hook_safe(method, fn)
    mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, method, sync_wrap(fn, 1))
    if SYNC_HUSK_METHODS[method] then
        mod:hook_safe(CLASS.PlayerHuskVisualLoadoutExtension, method, sync_wrap(fn, 1))
    end
end

local function vl_hook(method, fn)
    mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, method, sync_wrap(fn, 2))
    if SYNC_HUSK_METHODS[method] then
        mod:hook(CLASS.PlayerHuskVisualLoadoutExtension, method, sync_wrap(fn, 2))
    elseif method == "_unequip_item_from_slot" then
        -- a husk has no _unequip_item_from_slot: its unequip arrives as rpc_player_unequip_item_from_slot
        -- (self, channel_id, go_id, slot_id), slot name = NetworkLookup.player_inventory_slot_names[slot_id]
        -- (player_husk_visual_loadout_extension.lua)
        mod:hook(CLASS.PlayerHuskVisualLoadoutExtension, "rpc_player_unequip_item_from_slot", sync_wrap(function(func, self, channel_id, go_id, slot_id, ...)
            local NetworkLookup = require("scripts/network_lookup/network_lookup")
            local slot_name = NetworkLookup.player_inventory_slot_names[slot_id]
            return fn(function()
                return func(self, channel_id, go_id, slot_id)
            end, self, slot_name)
        end, 2))
    end
end
-- ----------------------------------------------------------------------------------

mod.AUTHOR = "QIangIQ"

local STAFF_ID = "QIangIQsPrototype:prototype"                  -- <Mod>:<Custom folder>
local STAFF_UNIT = "content/mods/qiangiq_prototype/prototype" -- --asset-path used at compile time

-- item.weapon_template -> setting id (equipment_component.lua reads item.weapon_template)
local TEMPLATES = {
    plasmagun_p1_m1 = "replace_weapon",
}

-- Emissive layer over the 4 receiver lights and the barrel core beam (v1.3). Slot names = the glTF
-- material names, set one slot at a time as in ammo_display.lua:85 (confirmed in game on the Skull Runeblade).
local GLOW_SLOTS = { "prototype_glow", "prototype_glow_core" }
local GLOW_BAKED = 2       -- intensity compiled into both glow materials (= glow_idle default)
local HEAT_FOLLOW = 0.3    -- share of the gap to the current heat closed per frame

local FIT_FRAMES = 10
local fit_generation = 0 -- bumped when a setting changes, so every staff refits

local custom_assets = nil
local ready = false
local mod_on = true
local session_override = {} -- keybind flips, cleared when the setting itself changes

local tracked = setmetatable({}, { __mode = "k" })    -- PlayerUnitVisualLoadoutExtension
local tracked_ui = setmetatable({}, { __mode = "k" }) -- UIProfileSpawner
local tracked_wpn = setmetatable({}, { __mode = "k" }) -- UIWeaponSpawner

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function setting_on(key)
    local override = session_override[key]
    if override ~= nil and not sync_ctx then
        return override
    end
    return opt(key) and true or false
end

local function wants_item(item)
    local key = item and item.weapon_template and TEMPLATES[item.weapon_template]
    return key ~= nil and mod_on and ready and setting_on(key)
end

local function local_player()
    local players = Managers.player
    if not players then
        return nil
    end
    local ok, player = pcall(players.local_player_safe, players, 1)
    return ok and player or nil
end

-- Fitting ---------------------------------------------------------------------
-- Only what proved reliable in game for the Diamond Sword is used: Unit.box centres
-- (Matrix4x4.translation), the largest box half-extent, unit origins and units' own world axes.
-- Box pose rotations are never used.

local function fmt(v)
    return string.format("(%.3f, %.3f, %.3f)", v.x, v.y, v.z)
end

local last_fit = {} -- per view, for /prototype debug
local last_glow = nil -- my own glow, for /prototype debug

-- pieces of the original staff: every attachment (and the base) with a measurable box
local function staff_parts(base, attachments)
    local parts = {}
    local function add(unit)
        if unit_ok(unit) then
            local pose, ext = Unit.box(unit)
            if pose and ext then
                local half = math.max(ext.x, ext.y, ext.z)
                if half > 0.005 then
                    parts[#parts + 1] = { center = Matrix4x4.translation(pose), half = half }
                end
            end
        end
    end
    add(base)
    if attachments then
        for i = 1, #attachments do
            add(attachments[i])
        end
    end
    return parts
end

-- Direction: from the hand (weapon base unit origin, where the weapon is linked to the hand) to
-- the piece farthest from it (muzzle), snapped to one of the weapon base unit's own axes when
-- within ~14 degrees. Reach = the farthest extent of any piece along that line.
-- The model is authored with its grip at the origin, +Y towards the muzzle (tip at y = 1) and
-- +Z up, so: grip on the hand, uniform scale = reach of the original weapon x size setting.
local function fit(staff, base, attachments, parent_scale, view)
    local parts = staff_parts(base, attachments)
    if #parts == 0 then
        return false
    end
    local origin = Unit.world_position(base, 1)
    local far_d, far_c = 0, nil
    for i = 1, #parts do
        local d = Vector3.length_squared(parts[i].center - origin)
        if d > far_d then
            far_d, far_c = d, parts[i].center
        end
    end
    if not far_c or far_d < 0.0001 then
        return false
    end
    local dir = Vector3.normalize(far_c - origin)
    local source = "hand->farthest piece"
    local base_rot = Unit.world_rotation(base, 1)
    local base_axes = { Quaternion.right(base_rot), Quaternion.forward(base_rot), Quaternion.up(base_rot) }
    local best, best_axis = 0, nil
    for i = 1, 3 do
        local d = Vector3.dot(base_axes[i], dir)
        if math.abs(d) > best then
            best = math.abs(d)
            best_axis = d < 0 and -base_axes[i] or base_axes[i]
        end
    end
    if best_axis and best > 0.97 then
        dir = best_axis
        source = string.format("base unit axis (%.2f to hand->farthest)", best)
    end

    local reach = 0
    for i = 1, #parts do
        reach = math.max(reach, Vector3.dot(parts[i].center - origin, dir) + parts[i].half)
    end
    if reach <= 0 then
        return false
    end
    if opt("flip_model") then
        dir = -dir
    end
    local s_world = reach * (opt("model_size") or 1)
    local grip = origin + dir * (reach * (opt("model_slide") or 0))

    -- "up" of the model: the weapon base unit's up axis (its right axis if the weapon points along up)
    local ref = base_axes[3]
    if math.abs(Vector3.dot(ref, dir)) > 0.9 then
        ref = base_axes[1]
    end
    local up = Vector3.normalize(ref - dir * Vector3.dot(ref, dir))
    local roll = math.rad(opt("model_roll") or 0)
    if roll ~= 0 then
        local side = Vector3.cross(dir, up)
        up = up * math.cos(roll) + side * math.sin(roll)
    end

    local bx, by, bz = base_axes[1], base_axes[2], base_axes[3]
    local function to_local(v)
        return Vector3(Vector3.dot(v, bx), Vector3.dot(v, by), Vector3.dot(v, bz))
    end
    local k = parent_scale and parent_scale > 0 and parent_scale or 1
    local s = s_world / k
    local local_pos = to_local(grip - origin) * (1 / k)
    local local_dir = to_local(dir)
    Unit.set_local_position(staff, 1, local_pos)
    Unit.set_local_rotation(staff, 1, Quaternion.look(local_dir, to_local(up)))
    Unit.set_local_scale(staff, 1, Vector3(s, s, s))

    if view then
        last_fit[view] = string.format("%s: %d pieces, dir by %s, reach %.3f, local grip %s, local dir %s, local up %s",
            view, #parts, source, reach, fmt(local_pos), fmt(local_dir), fmt(to_local(up)))
    end
    return true
end

-- Heat of the weapon in a slot, 0..1: the slot's inventory component, as plasmagun_overheat_effects.lua:39,79
-- reads it. Also replicated for other players (player_husk_data_component_config.lua, slot_secondary).
local function slot_heat(player_unit, slot_name)
    if not unit_ok(player_unit) then
        return 0
    end
    local unit_data_extension = ScriptUnit.has_extension(player_unit, "unit_data_system")
    if not unit_data_extension then
        return 0
    end
    local ok, component = pcall(unit_data_extension.read_component, unit_data_extension, slot_name)
    local heat = ok and component and component.overheat_current_percentage
    return type(heat) == "number" and math.clamp01(heat) or 0
end

-- intensity of both glow slots: glow_idle at no heat, glow_hot at full heat
local function apply_glow(rec, heat)
    local shown = rec.heat_shown or 0
    shown = shown + ((heat or 0) - shown) * HEAT_FOLLOW
    rec.heat_shown = shown
    local idle = opt("glow_idle") or GLOW_BAKED
    local hot = opt("glow_hot") or 25
    local value = idle + (hot - idle) * shown
    if rec.glow_set and math.abs(value - rec.glow_set) < 0.01 then
        return
    end
    rec.glow_set = value
    local set = 0
    for i = 1, #GLOW_SLOTS do
        if pcall(Unit.set_scalar_for_material, rec.sword, GLOW_SLOTS[i], "intensity", value) then
            set = set + 1
        end
    end
    if not sync_ctx then
        last_glow = string.format("glow: heat %.2f (shown %.2f), intensity %.2f, %d/%d slots set",
            heat or 0, shown, value, set, #GLOW_SLOTS)
    end
end

local function hide_originals(base, attachments)
    Unit.set_unit_visibility(base, false, true)
    if attachments then
        for i = 1, #attachments do
            if unit_ok(attachments[i]) then
                Unit.set_unit_visibility(attachments[i], false, true)
            end
        end
    end
end

-- One record per (holder, slot, view): { sword = staff unit, base, frames, count }
-- spawn_fn(parent) -> unit linked to parent node 1, destroy_fn(unit)
local function sync_record(records, key, base, attachments, item, visible, spawn_fn, destroy_fn, parent_scale, first_person, heat)
    local rec = records[key]
    local want = unit_ok(base) and wants_item(item) and attachments ~= nil

    if rec and (not want or rec.base ~= base or not unit_ok(rec.sword)) then
        destroy_fn(rec.sword)
        records[key] = nil
        if rec.hid and rec.base == base and unit_ok(base) and visible then
            -- give the original weapon back (recursive visibility also covers its linked attachments)
            Unit.set_unit_visibility(base, true, true)
        end
        rec = nil
    end
    if not want then
        return false
    end

    if not rec then
        local staff = spawn_fn(base)
        if not staff then
            return false
        end
        if first_person then
            -- same flag the game sets on first-person weapons (equipment_component.lua)
            Unit.set_shader_pass_flag_for_meshes_in_unit_and_childs(staff, "custom_fov", true)
        end
        rec = { sword = staff, base = base, frames = 0, count = -1, fitted = false }
        records[key] = rec
    end

    if rec.count ~= #attachments or rec.gen ~= fit_generation then
        rec.gen = fit_generation
        rec.count = #attachments
        rec.frames = 0
        rec.glow_set = nil
    end
    apply_glow(rec, heat)
    if rec.frames < FIT_FRAMES then
        rec.frames = rec.frames + 1
        local base_scale = Unit.local_scale(base, 1)
        local k = (parent_scale or 1) * (base_scale and base_scale.x or 1)
        rec.fitted = fit(rec.sword, base, attachments, k, key) or rec.fitted
    end

    if rec.fitted and visible then
        hide_originals(base, attachments)
        rec.hid = true
        Unit.set_unit_visibility(rec.sword, true, true)
    else
        Unit.set_unit_visibility(rec.sword, false, true)
    end
    return true
end

local function clear_records(records, destroy_fn)
    if not records then
        return
    end
    for key, rec in pairs(records) do
        destroy_fn(rec.sword)
        records[key] = nil
    end
end

-- In-game (your own player unit) ------------------------------------------------

local function ingame_spawn(ext, is_first_person)
    return function(parent)
        local world = ext.__qiangiq_proto_world
        local unit_spawner = Managers.state and Managers.state.unit_spawner
        if not (world and unit_spawner) then
            return nil
        end
        local unit = unit_spawner:spawn_unit(STAFF_UNIT, Unit.world_pose(parent, 1))
        if not unit then
            return nil
        end
        if is_first_person then
            Unit.set_unit_culling(unit, false)
        end
        World.link_unit(world, unit, 1, parent, 1, World.LINK_MODE_NODE_NAME)
        return unit
    end
end

local function ingame_destroy(unit)
    if unit_ok(unit) then
        local unit_spawner = Managers.state and Managers.state.unit_spawner
        if unit_spawner then
            unit_spawner:mark_for_deletion(unit)
        end
    end
end

local function ingame_apply(ext)
    local records = ext.__qiangiq_proto_records
    if not records then
        records = {}
        ext.__qiangiq_proto_records = records
    end
    local equipment = ext._equipment
    if not equipment then
        return
    end
    for slot_name, slot in pairs(equipment) do
        local item = slot.item
        if item and item.weapon_template and TEMPLATES[item.weapon_template] or records[slot_name .. ":3p"] or records[slot_name .. ":1p"] then
            local base_3p, base_1p = slot.unit_3p, slot.unit_1p
            local att_3p = base_3p and slot.attachments_by_unit_3p and slot.attachments_by_unit_3p[base_3p]
            local att_1p = base_1p and slot.attachments_by_unit_1p and slot.attachments_by_unit_1p[base_1p]
            local heat = slot_heat(ext._unit, slot_name)
            sync_record(records, slot_name .. ":3p", base_3p, att_3p, item, slot.hidden_3p == false,
                ingame_spawn(ext, false), ingame_destroy, 1, false, heat)
            sync_record(records, slot_name .. ":1p", base_1p, att_1p, item, slot.hidden_1p == false,
                ingame_spawn(ext, true), ingame_destroy, 1, true, heat)
        end
    end
end

local function is_local_human(ext)
    return sync_shown(ext)
end

vl_hook_safe("init", function(self, extension_init_context)
    self.__qiangiq_proto_world = extension_init_context and extension_init_context.world
end)

vl_hook_safe("_update_item_visibility", function(self)
    if not is_local_human(self) then
        return
    end
    tracked[self] = true
    ingame_apply(self)
end)

vl_hook_safe("update", function(self)
    if tracked[self] then
        ingame_apply(self)
    end
end)

vl_hook("_unequip_item_from_slot", function(func, self, slot_name, ...)
    local records = self.__qiangiq_proto_records
    if records then
        for _, view in ipairs({ ":3p", ":1p" }) do
            local rec = records[slot_name .. view]
            if rec then
                ingame_destroy(rec.sword)
                records[slot_name .. view] = nil
            end
        end
    end
    return func(self, slot_name, ...)
end)

vl_hook("destroy", function(func, self, ...)
    clear_records(self.__qiangiq_proto_records, ingame_destroy)
    tracked[self] = nil
    return func(self, ...)
end)

-- Menu previews ---------------------------------------------------------------

local function ui_profile_is_mine(profile)
    -- __qiangiq_npc: the companion NPC spawned by QIangIQsCompanionSwap is nobody's character
    if not profile or profile.__qiangiq_npc then
        return false
    end
    local players = Managers.player and Managers.player:players()
    local me = local_player()
    if players and profile.character_id then
        for _, player in pairs(players) do
            if player ~= me and player.character_id and player:character_id() == profile.character_id then
                return false
            end
        end
    end
    return true
end

local function ui_spawn(world)
    return function(parent)
        -- same calls ui_profile_spawner.lua uses for its own units
        local unit = World.spawn_unit_ex(world, STAFF_UNIT, nil, Unit.world_pose(parent, 1))
        World.link_unit(world, unit, 1, parent, 1, World.LINK_MODE_NODE_NAME)
        return unit
    end
end

local function ui_destroy_fn(world)
    return function(unit)
        if unit_ok(unit) and world then
            World.destroy_unit(world, unit)
        end
    end
end

local function scale_x(unit)
    if unit_ok(unit) then
        local s = Unit.local_scale(unit, 1)
        return s and s.x or 1
    end
    return 1
end

-- operative select / inventory character preview
local function profile_apply(spawner)
    local world = spawner._world
    local records = spawner.__qiangiq_proto_records
    if not records then
        records = {}
        spawner.__qiangiq_proto_records = records
    end
    local data = spawner._character_spawn_data
    local allowed = data and data.slots and opt("menu_previews") and ui_profile_is_mine(data.profile)
    if not allowed then
        clear_records(records, ui_destroy_fn(world))
        return
    end
    tracked_ui[spawner] = true
    local k = scale_x(data.unit_3p)
    for slot_name, slot in pairs(data.slots) do
        local item = slot.item
        if item and item.weapon_template and TEMPLATES[item.weapon_template] or records[slot_name] then
            local base = slot.unit_3p
            local att = base and slot.attachments_by_unit_3p and slot.attachments_by_unit_3p[base]
            sync_record(records, slot_name, base, att, item, spawner._visible and slot.hidden_3p == false,
                ui_spawn(world), ui_destroy_fn(world), k, false)
        end
    end
end

mod:hook_safe(CLASS.UIProfileSpawner, "_update_items_visibility", function(self)
    profile_apply(self)
end)

mod:hook_safe(CLASS.UIProfileSpawner, "update", function(self)
    local data = self._character_spawn_data
    if data and data.is_ready then
        profile_apply(self)
    elseif self.__qiangiq_proto_records then
        clear_records(self.__qiangiq_proto_records, ui_destroy_fn(self._world))
    end
end)

mod:hook(CLASS.UIProfileSpawner, "_despawn_current_character_profile", function(func, self, ...)
    clear_records(self.__qiangiq_proto_records, ui_destroy_fn(self._world))
    return func(self, ...)
end)

-- weapon inspect / inventory weapon preview
local function weapon_apply(spawner)
    local world = spawner._world
    local records = spawner.__qiangiq_proto_records
    if not records then
        records = {}
        spawner.__qiangiq_proto_records = records
    end
    local data = spawner._weapon_spawn_data
    if not (data and opt("menu_previews")) then
        if next(records) ~= nil then
            clear_records(records, ui_destroy_fn(world))
            if data and data.visible and unit_ok(data.item_unit_3p) then
                -- shown the same way ui_weapon_spawner.lua shows it
                Unit.set_unit_visibility(data.item_unit_3p, true, true)
            end
        end
        return
    end
    tracked_wpn[spawner] = true
    local base = data.item_unit_3p
    local att = base and data.attachment_units_3p and data.attachment_units_3p[base]
    local k = scale_x(data.link_unit)
    sync_record(records, "weapon", base, att, data.item, data.visible and true or false,
        ui_spawn(world), ui_destroy_fn(world), k, false)
end

mod:hook_safe(CLASS.UIWeaponSpawner, "update", function(self)
    weapon_apply(self)
end)

mod:hook(CLASS.UIWeaponSpawner, "_despawn_current_weapon", function(func, self, ...)
    clear_records(self.__qiangiq_proto_records, ui_destroy_fn(self._world))
    return func(self, ...)
end)

-- Refresh / toggles ------------------------------------------------------------

local function refresh_all()
    for ext in pairs(tracked) do
        if unit_ok(ext._unit) then
            ingame_apply(ext)
            -- restores the original weapon's visibility when a replacement was switched off
            ext:force_update_item_visibility()
        end
    end
    for spawner in pairs(tracked_ui) do
        profile_apply(spawner)
        if spawner._character_spawn_data and spawner._visible then
            spawner:_update_items_visibility()
        end
    end
    for spawner in pairs(tracked_wpn) do
        weapon_apply(spawner)
    end
end

local function flip(key, label)
    session_override[key] = not setting_on(key)
    refresh_all()
    mod:echo("%s replacement %s", label, session_override[key] and "on" or "off")
end

mod.toggle_weapon = function()
    flip("replace_weapon", "Prototype")
end

mod:command("prototype", "Toggle the Prototype replacement: /prototype [debug]", function(which)
    if which == "debug" then
        local any = false
        for _, line in pairs(last_fit) do
            mod:echo(line)
            any = true
        end
        if not any then
            mod:echo("Nothing fitted yet: wield the M35 Magnacore Mk II Plasma Gun first.")
        end
        if last_glow then
            mod:echo(last_glow)
        end
        return
    end
    mod.toggle_weapon()
end)

mod.on_setting_changed = function(setting_id)
    if setting_id then
        session_override[setting_id] = nil
    end
    fit_generation = fit_generation + 1
    refresh_all()
end

-- Package loading through Custom Assets --------------------------------------

mod.on_all_mods_loaded = function()
    custom_assets = get_mod("CustomAssets")
    if not custom_assets or not custom_assets.is_api_compatible or not custom_assets.is_api_compatible(1) then
        mod:error("Custom Assets (API 1) is missing. Install it and put it above QIangIQsPrototype in mod_load_order.txt.")
        return
    end
    local ticket, err = custom_assets.acquire(mod, STAFF_ID, function(_, _, load_error)
        if load_error then
            mod:error("%s failed to load: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", STAFF_ID, tostring(load_error))
            return
        end
        ready = true
        refresh_all()
    end, { resident = true, reference_name = STAFF_ID })
    if not ticket then
        mod:error("%s could not be requested: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", STAFF_ID, tostring(err))
    end
end

local function remove_all()
    for ext in pairs(tracked) do
        clear_records(ext.__qiangiq_proto_records, ingame_destroy)
    end
    for spawner in pairs(tracked_ui) do
        clear_records(spawner.__qiangiq_proto_records, ui_destroy_fn(spawner._world))
    end
    for spawner in pairs(tracked_wpn) do
        clear_records(spawner.__qiangiq_proto_records, ui_destroy_fn(spawner._world))
    end
end

mod.on_disabled = function()
    remove_all()
    -- hooks are off now, so these restore the original weapon visibility
    for ext in pairs(tracked) do
        if unit_ok(ext._unit) then
            ext:force_update_item_visibility()
        end
    end
    for spawner in pairs(tracked_ui) do
        if spawner._character_spawn_data and spawner._visible then
            spawner:_update_items_visibility()
        end
    end
    for spawner in pairs(tracked_wpn) do
        local data = spawner._weapon_spawn_data
        if data and data.visible and unit_ok(data.item_unit_3p) then
            Unit.set_unit_visibility(data.item_unit_3p, true, true)
        end
    end
end

mod.on_enabled = function()
    refresh_all()
end

mod.on_unload = function()
    remove_all()
    if custom_assets and custom_assets.release_owner then
        custom_assets.release_owner(mod)
    end
end


-- Cross-client sync: what this mod publishes about me, and the refresh when anyone's options change ---------
-- on for a weapon I carry (any switched-on weapon while I have no unit)
local function sync_applies(info)
    for template, key in pairs(TEMPLATES) do
        if setting_on(key) and (info.templates == nil or info.templates[template]) then
            return true
        end
    end
    return false
end

local TEMPLATES_KEYS = {}
for _, key in pairs(TEMPLATES) do
    TEMPLATES_KEYS[key] = true
end

local sync_enabled = true
local function sync_changed()
    local api = sync_api()
    if api then
        api.changed()
    end
end

mod.sync_key = SYNC_KEY
-- info = { breed, companion_breed, templates = { [weapon_template] = true } } of my own character (fields nil
-- while I have no unit). Returns the array to publish, or nil when this mod shows nothing on my character.
mod.sync_export = function(info)
    info = info or {}
    if not sync_enabled or not sync_applies(info) then
        return nil
    end
    local mask, bit = 0, 1
    for i = 1, #SYNC_BOOLS do
        local key = SYNC_BOOLS[i]
        local v = nil
        if TEMPLATES_KEYS[key] then
            v = setting_on(key)
        else
            v = mod:get(key)
        end
        if v == nil then
            v = SYNC_DEFAULTS[key]
        end
        if v then
            mask = mask + bit
        end
        bit = bit * 2
    end
    local out = { SYNC_LAYOUT, mask }
    for i = 1, #SYNC_VALUES do
        local v = mod:get(SYNC_VALUES[i])
        if type(v) == "number" then
            v = math.floor(v * 100 + 0.5) / 100
        elseif type(v) ~= "string" then
            v = false -- not set: the reader falls back to its default
        end
        out[2 + i] = v
    end
    return out
end

mod.sync_refresh = function()
    for ext in pairs(sync_all) do
        if ext._unit and Unit.alive(ext._unit) and ext.force_update_item_visibility then
            pcall(ext.force_update_item_visibility, ext)
        end
    end
end

local sync_prev_setting_changed = mod.on_setting_changed
mod.on_setting_changed = function(...)
    if sync_prev_setting_changed then
        sync_prev_setting_changed(...)
    end
    sync_changed()
end

local sync_prev_disabled = mod.on_disabled
mod.on_disabled = function(...)
    sync_enabled = false
    if sync_prev_disabled then
        sync_prev_disabled(...)
    end
    sync_changed()
end

local sync_prev_enabled = mod.on_enabled
mod.on_enabled = function(...)
    sync_enabled = true
    if sync_prev_enabled then
        sync_prev_enabled(...)
    end
    sync_changed()
end

-- QIangIQsArmoryVis: stowed-weapon copies (see QIangIQsArmoryVis/README.md). Armory Vis calls apply every frame
-- and clear once per copy with `holder` (one table per character and stowed slot: _unit, _player, _ext,
-- _slot_name) and `equipment` ({ [slot_name] = slot-like table of the copy, hidden_3p false while shown }).
-- The in-game apply above runs on the holder as it runs on a loadout extension.
mod.armory_vis = {
    apply = function(holder, world, equipment)
        holder.__qiangiq_proto_world = world
        holder._equipment = equipment
        ingame_apply(holder)
    end,
    clear = function(holder)
        clear_records(holder.__qiangiq_proto_records, ingame_destroy)
        holder.__qiangiq_proto_records = nil
    end,
}
