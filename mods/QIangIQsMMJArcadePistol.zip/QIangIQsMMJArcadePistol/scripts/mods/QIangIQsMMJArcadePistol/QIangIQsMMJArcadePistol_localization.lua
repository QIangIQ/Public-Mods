return {
    mod_name = {
        en = "QIangIQ's MMJ Arcade Pistol",
    },
    mod_description = {
        en = "Replaces the Needle Pistol with Mullet Mad Jack's arcade toy pistol: MMJ's sprites and clips in first person with its sounds. Visual only: the weapon still works as before. Contains Mullet Mad Jack art and audio: personal use only.",
    },
    command_desc = { en = "MMJ Arcade Pistol status (add flip to turn the sprite rotation round)" },
    replace_needlepistol_p1_m1 = { en = "Replace Needle Pistol (needlepistol_p1_m1)" },
    replace_needlepistol_p1_m2 = { en = "Replace Needle Pistol (needlepistol_p1_m2)" },
    replace_needlepistol_p1_m3 = { en = "Replace Needle Pistol (needlepistol_p1_m3)" },
    third_person = { en = "Third person: your character" },
    third_person_others = { en = "Third person: other players" },
    third_person_hide = { en = "Hide the weapon" },
    third_person_retail = { en = "Show the weapon" },
    sounds = { en = "MMJ sounds" },
    volume = { en = "Sound volume (%%)" },
    layout = { en = "Screen layout" },
    mmj_fov = { en = "MMJ weapon camera field of view (degrees)" },
    size = { en = "Size (%%)" },
    offset_x = { en = "Move right (cm)" },
    offset_y = { en = "Move up (cm)" },
    smear_cap = { en = "Fade sprites bigger than this share of the screen (%%, 0 = off)" },
}
