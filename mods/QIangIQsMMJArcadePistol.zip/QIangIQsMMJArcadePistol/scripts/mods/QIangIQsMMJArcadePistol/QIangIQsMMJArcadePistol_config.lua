-- QIangIQsMMJArcadePistol per-weapon data (gen.py spec arcade_pistol). Clips are MMJ clip names from arcade_pistol\OBJ-Weapond-ArcadePistol__10612.
-- Action map sources: Darktide weapon templates (Aussiemon master) via tools\dump_actions.py.
return {
    ranged = true,
    idle = "pistol-idle_arcade",
    templates = { needlepistol_p1_m1 = true, needlepistol_p1_m2 = true, needlepistol_p1_m3 = true },
    shot = { clips = { "pistol-shot_arcade" }, sounds = { "sfx_wp_pistol_shot_01.ogg", "sfx_wp_pistol_shot_03.ogg", "sfx_wp_pistol_shot_04.ogg", "sfx_wp_pistol_shot_05.ogg" } },
    actions = {
        action_wield = { clips = { "pistol- introfast-arcade" }, over_shot = true, sounds = { "sfx_wp_pistol_intro.ogg" } },
        action_reload = { clips = { "pistol-reload_arcade" }, stretch = true, reload_template = true, over_shot = true, sounds = { "sfx_wp_pistol_reload_b.ogg" } },
    },
}
