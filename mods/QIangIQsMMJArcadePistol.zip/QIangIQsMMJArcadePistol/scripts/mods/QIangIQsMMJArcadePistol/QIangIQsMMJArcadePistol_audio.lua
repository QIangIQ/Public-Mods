-- Ogg playback without other mods: SimpleAudio's XAudio2 + FFmpeg runtime ships renamed in this mod's bin folder
-- (bin/mmjarcadepistol-audio-runtime.dll), the same way QIangIQsBell and QIangIQsDauntlessFalchion carry it. Wwise only plays
-- events from the game's banks, so MMJ.s finger gun sounds go through this runtime.
local Audio = {}

local ffi = rawget(_G, "Mods") and Mods.lua and Mods.lua.ffi
local BIN = "..\\mods\\QIangIQsMMJArcadePistol\\bin\\"
local DIR = "..\\mods\\QIangIQsMMJArcadePistol\\assets\\audio\\"
local DEPENDENCIES = { "avutil-60.dll", "swresample-6.dll", "swscale-9.dll", "avcodec-62.dll", "avformat-62.dll", "avfilter-11.dll" }
local RUNTIME = "mmjarcadepistol-audio-runtime.dll"
local ERR_SIZE = 2048

local persist
local log = function() end
local err_buf

local function path_of(rel)
	return ((DIR .. rel):gsub("/", "\\"))
end

function Audio.setup(persist_table, log_fn)
	persist = persist_table
	log = log_fn or log
end

local function runtime()
	if persist.audio_rt then
		return persist.audio_rt
	end

	if persist.audio_failed or not ffi then
		return nil
	end

	-- one runtime for every QIangIQs MMJ weapon mod (see the assets module): reuse a registered one
	local shared = rawget(_G, "__qiangiq_mmj_runtimes")

	if shared and shared.audio then
		persist.audio_rt = shared.audio

		return persist.audio_rt
	end

	local ok, err = pcall(function()
		-- same declarations as SimpleAudio's runtime/native.lua (same guard type, so either mod may declare them first)
		if not pcall(ffi.typeof, "SimpleAudioRuntime_CDEF") then
			ffi.cdef([[
				typedef struct { int unused; } SimpleAudioRuntime_CDEF;
				int SimpleAudioRuntime_Initialize(char* error_buffer, int error_buffer_size);
				int SimpleAudioRuntime_Play(const char* path, const char* filters, double volume_gain, double pos, double duration, int loop_count, int spatial, double source_x, double source_y, double source_z, double listener_x, double listener_y, double listener_z, double listener_front_x, double listener_front_y, double listener_front_z, double listener_top_x, double listener_top_y, double listener_top_z, char* error_buffer, int error_buffer_size);
				int SimpleAudioRuntime_FileInfo(const char* path, int* sample_rate, int* channels, double* duration, long long* bit_rate, char* error_buffer, int error_buffer_size);
				int SimpleAudioRuntime_SetPosition(int play_id, double volume_gain, double source_x, double source_y, double source_z, double listener_x, double listener_y, double listener_z, double listener_front_x, double listener_front_y, double listener_front_z, double listener_top_x, double listener_top_y, double listener_top_z, char* error_buffer, int error_buffer_size);
				int SimpleAudioRuntime_Stop(int play_id);
				void SimpleAudioRuntime_StopAll(void);
				int SimpleAudioRuntime_IsPlaying(int play_id);
				int SimpleAudioRuntime_PollEvent(int* event_type, int* play_id, char* message_buffer, int message_buffer_size);
				void SimpleAudioRuntime_Shutdown(void);
			]])
		end

		-- kept referenced so they are never unloaded; loaded from bin first so the runtime's imports resolve
		persist.audio_deps = persist.audio_deps or {}

		for _, name in ipairs(DEPENDENCIES) do
			if not persist.audio_deps[name] then
				local loaded, lib = pcall(ffi.load, BIN .. name)

				if loaded then
					persist.audio_deps[name] = lib
				end
			end
		end

		local rt = ffi.load(BIN .. RUNTIME)
		local buf = ffi.new("char[?]", ERR_SIZE)

		if rt.SimpleAudioRuntime_Initialize(buf, ERR_SIZE) == 0 then
			error(ffi.string(buf))
		end

		persist.audio_rt = rt
		shared = rawget(_G, "__qiangiq_mmj_runtimes") or {}
		shared.audio = rt
		rawset(_G, "__qiangiq_mmj_runtimes", shared)
	end)

	if not ok then
		persist.audio_failed = tostring(err)
		log("audio: runtime unavailable (" .. persist.audio_failed .. "); voice lines are off")

		return nil
	end

	log("audio: runtime ready")

	return persist.audio_rt
end

local function user_setting(a, b)
	local ok, v = pcall(Application.user_setting, a, b)

	return ok and v or nil
end

-- volume_pct: this mod's own slider; scaled by the game's master and sfx sliders like the Falchion module
local function gain(volume_pct)
	local master = (user_setting("sound_settings", "option_master_slider") or 100) / 100
	local sfx = (user_setting("sound_settings", "options_sfx_slider") or 100) / 100

	return math.max(0, master * sfx * (volume_pct or 100) / 100)
end

-- Seconds of audio in assets/audio/<rel>, or nil.
function Audio.duration(rel)
	local rt = runtime()

	if not rt then
		return nil
	end

	persist.audio_durations = persist.audio_durations or {}

	local cached = persist.audio_durations[rel]

	if cached ~= nil then
		return cached or nil
	end

	err_buf = err_buf or ffi.new("char[?]", ERR_SIZE)

	local sr, ch, dur, br = ffi.new("int[1]"), ffi.new("int[1]"), ffi.new("double[1]"), ffi.new("long long[1]")
	local ok = rt.SimpleAudioRuntime_FileInfo(path_of(rel), sr, ch, dur, br, err_buf, ERR_SIZE)
	-- same contract as SimpleAudio's file_info: 0 = error, a negative duration = unknown
	local value = ok ~= 0 and tonumber(dur[0]) >= 0 and tonumber(dur[0]) or false

	if not value then
		log("audio: file info " .. rel .. ": " .. ffi.string(err_buf))
	end

	persist.audio_durations[rel] = value

	return value or nil
end

local function play_raw(rt, rel, filters, volume_gain, loop_count)
	err_buf = err_buf or ffi.new("char[?]", ERR_SIZE)

	return rt.SimpleAudioRuntime_Play(path_of(rel), filters, volume_gain, 0, -1, loop_count or 0, 0,
		0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, err_buf, ERR_SIZE)
end

-- Plays assets/audio/<rel>, non-spatial. Returns a play id or nil.
-- boost_db: extra loudness through an FFmpeg filter with a limiter (SimpleAudio's "filters" field), so a quiet clip
-- gets louder without clipping. If the filter is refused, plays again without it at a plain gain.
-- loop: true loops until stopped.
function Audio.play(rel, volume_pct, boost_db, loop)
	local rt = runtime()

	if not rt then
		return nil
	end

	local loop_count = loop and -1 or 0
	local id

	if boost_db and boost_db > 0 then
		id = play_raw(rt, rel, string.format("volume=%.1fdB,alimiter=limit=0.95", boost_db), gain(volume_pct), loop_count)

		if id <= 0 then
			log("audio: boost filter refused for " .. rel .. ": " .. ffi.string(err_buf) .. " (playing without it)")
			id = play_raw(rt, rel, nil, gain(volume_pct) * 10 ^ (boost_db / 20), loop_count)
		end
	else
		id = play_raw(rt, rel, nil, gain(volume_pct), loop_count)
	end

	if id <= 0 then
		log("audio: play " .. rel .. ": " .. ffi.string(err_buf))
		return nil
	end

	return id
end

-- Music: played "spatial" with the source straight ahead of the listener, only so SimpleAudioRuntime_SetPosition can
-- change its volume while it plays (SimpleAudio's own set_position path); the position itself never moves.
-- Returns a play id or nil. volume_pct is the mod's slider (master and sfx applied like every other sound).
function Audio.play_music(rel, volume_pct, start_fraction)
	local rt = runtime()

	if not rt then
		return nil
	end

	err_buf = err_buf or ffi.new("char[?]", ERR_SIZE)

	local id = rt.SimpleAudioRuntime_Play(path_of(rel), nil, gain(volume_pct) * (start_fraction or 0), 0, -1, -1, 1,
		0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, err_buf, ERR_SIZE)

	if id <= 0 then
		log("audio: music " .. rel .. ": " .. ffi.string(err_buf))
		return nil
	end

	return id
end

-- fraction 0..1 of the slider volume, for fades
function Audio.set_music_volume(id, volume_pct, fraction)
	local rt = persist.audio_rt

	if not (id and rt) then
		return false
	end

	err_buf = err_buf or ffi.new("char[?]", ERR_SIZE)

	return rt.SimpleAudioRuntime_SetPosition(id, gain(volume_pct) * fraction, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1,
		err_buf, ERR_SIZE) ~= 0
end

function Audio.is_playing(id)
	local rt = persist.audio_rt

	return id and rt and rt.SimpleAudioRuntime_IsPlaying(id) ~= 0 or false
end

function Audio.stop(id)
	local rt = persist.audio_rt

	if id and rt then
		rt.SimpleAudioRuntime_Stop(id)
	end
end

function Audio.warm()
	runtime()
end

return Audio
