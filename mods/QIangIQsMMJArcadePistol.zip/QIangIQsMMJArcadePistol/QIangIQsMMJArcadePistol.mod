return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsMMJArcadePistol` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsMMJArcadePistol", {
            mod_script = "QIangIQsMMJArcadePistol/scripts/mods/QIangIQsMMJArcadePistol/QIangIQsMMJArcadePistol",
            mod_data = "QIangIQsMMJArcadePistol/scripts/mods/QIangIQsMMJArcadePistol/QIangIQsMMJArcadePistol_data",
            mod_localization = "QIangIQsMMJArcadePistol/scripts/mods/QIangIQsMMJArcadePistol/QIangIQsMMJArcadePistol_localization",
        })
    end,
    version = "0.1.0",
    author = "QIangIQ",
    packages = {},
}
