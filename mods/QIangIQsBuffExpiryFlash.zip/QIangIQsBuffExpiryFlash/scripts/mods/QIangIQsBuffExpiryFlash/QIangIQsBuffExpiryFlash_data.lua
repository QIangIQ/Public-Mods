local mod = get_mod("QIangIQsBuffExpiryFlash")
local LIST = mod:io_dofile("QIangIQsBuffExpiryFlash/scripts/mods/QIangIQsBuffExpiryFlash/QIangIQsBuffExpiryFlash_list")

local GROUPS = {
	{ id = "veteran", title = "Veteran" },
	{ id = "zealot", title = "Zealot" },
	{ id = "psyker", title = "Psyker" },
	{ id = "ogryn", title = "Ogryn" },
	{ id = "adamant", title = "Arbites" },
	{ id = "broker", title = "Hive Scum" },
	{ id = "cryptic", title = "Cryptic (class id in the game source)" },
	{ id = "blessing", title = "Blessings" },
	{ id = "custom", title = "Legacy Talents, Martyrdom and Novitiate" },
}
local TRIGGER = {
	swap = "Swap", push = "Push", special = "Special", block = "Block", dodge = "Dodge", reload = "Reload",
	ability = "Ability", stimm = "Stimm", tag = "Tag", sprint = "Sprint", attack = "Attack",
}

-- DMF treats a percent sign as a format character (vault: lesson-dmf-localization-percent).
local function _safe(text)
	return (string.gsub(text, "%%", " pct"))
end

-- Talent names are the game's own strings. Same call as Flux_data.lua:97.
local function _name(entry)
	if entry.loc and rawget(_G, "Localize") then
		local ok, text = pcall(Localize, entry.loc)

		if ok and type(text) == "string" and text ~= "" and string.sub(text, 1, 1) ~= "<" then
			return text
		end
	end

	return entry.title
end

local function _first_stat(entry)
	return string.match(entry.stat, "^[%w_]+") or "no stat"
end

local function _checkbox(entry)
	return {
		setting_id = entry.id,
		type = "checkbox",
		default_value = entry.default,
		localize = false,
		title = _safe(_name(entry) .. " [" .. (TRIGGER[entry.trigger] or entry.trigger) .. ": " .. _first_stat(entry) .. "]"),
		tooltip = _safe(entry.stat .. "\nDuration: " .. entry.duration .. "\nSource: " .. entry.source .. "\nBuffs: " .. table.concat(entry.templates, ", ")),
	}
end

local function _group(group)
	local sub = {}

	for i = 1, #LIST do
		if LIST[i].group == group.id then
			sub[#sub + 1] = _checkbox(LIST[i])
		end
	end

	return {
		setting_id = "group_" .. group.id,
		type = "group",
		localize = false,
		title = group.title,
		tooltip = "Entries that a plain attack or hit refreshes (heavy attack, sweep, melee stagger) start off, because they would flash constantly.",
		sub_widgets = sub,
	}
end

local function _numeric(id, default, low, high, decimals, title, tooltip)
	return { setting_id = id, type = "numeric", default_value = default, range = { low, high }, decimals_number = decimals, localize = false, title = title, tooltip = tooltip }
end

local widgets = {
	{
		setting_id = "group_look",
		type = "group",
		localize = false,
		title = "Flash",
		tooltip = "How the warning looks.",
		sub_widgets = {
			{ setting_id = "test_key", type = "keybind", default_value = {}, keybind_trigger = "pressed", keybind_type = "function_call", function_name = "test_flash", localize = false, title = "Test flash (key)", tooltip = "Shows a test warning in a mission." },
			{
				setting_id = "text_style", type = "dropdown", default_value = "word", localize = false, title = "Text", tooltip = "Short word such as CLEAVE!! or SPEED!!, taken from the buff's stat, or the talent name.",
				options = {
					{ text = "Short word", value = "word", show_widget_localization = false },
					{ text = "Talent name", value = "name", show_widget_localization = false },
				},
			},
			_numeric("font_size", 56, 24, 140, 0, "Text size", "Size of the warning word."),
			_numeric("text_x", -350, -900, 900, 0, "Text X", "Left and right from screen centre. Spidey Sense puts its warnings at -350."),
			_numeric("text_y", 0, -500, 500, 0, "Text Y", "Up (negative) and down from screen centre."),
			_numeric("flash_seconds", 2.5, 0.5, 6, 1, "Flash length (seconds)", "How long the warning stays."),
			_numeric("flash_rate", 4, 1, 10, 0, "Flashes per second", "How fast it pulses."),
			_numeric("max_alpha", 100, 20, 100, 0, "Brightness", "Peak opacity, 20 to 100."),
			{
				setting_id = "flash_color", type = "dropdown", default_value = "red", localize = false, title = "Colour", tooltip = "Colour of the word and screen edges.",
				options = {
					{ text = "Red", value = "red", show_widget_localization = false },
					{ text = "Amber", value = "amber", show_widget_localization = false },
					{ text = "White", value = "white", show_widget_localization = false },
					{ text = "Cyan", value = "cyan", show_widget_localization = false },
				},
			},
			{ setting_id = "edge_flash", type = "checkbox", default_value = true, localize = false, title = "Flash the screen edges", tooltip = "Adds a pulsing border around the screen." },
			_numeric("edge_thickness", 16, 4, 60, 0, "Edge thickness", "Border width in UI pixels (1080p scale)."),
			{ setting_id = "sound_on", type = "checkbox", default_value = true, localize = false, title = "Warning sound", tooltip = "Plays a game sound with the flash. Only you hear it." },
			{
				setting_id = "sound_event", type = "dropdown", default_value = "wwise/events/weapon/play_plasmagun_overheat_intensity_01", localize = false, title = "Sound", tooltip = "All are the game's own sounds. If a sound stays silent, its sound bank is not loaded: pick another.",
				options = {
					{ text = "Plasma gun overheat, high", value = "wwise/events/weapon/play_plasmagun_overheat_intensity_01", show_widget_localization = false },
					{ text = "Plasma gun overheat, critical", value = "wwise/events/weapon/play_plasmagun_overheat_intensity_02", show_widget_localization = false },
					{ text = "Ability off cooldown", value = "wwise/events/ui/play_hud_ability_off_cooldown", show_widget_localization = false },
					{ text = "Timer running out", value = "wwise/events/ui/play_expeditions_hud_notification_timer_sml_running_out", show_widget_localization = false },
				},
			},
			{ setting_id = "flash_early", type = "checkbox", default_value = false, localize = false, title = "Also flash when a buff ends early", tooltip = "Off: flashes only when the timer runs out. On: also flashes when a buff ends early, for example Weapon Specialist ranged when you swap away (conditional_exit_func), or when stealth breaks." },
		},
	},
}

for i = 1, #GROUPS do
	widgets[#widgets + 1] = _group(GROUPS[i])
end

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = { widgets = widgets },
}
