return {
	mod_name = {
		en = "QIangIQs Buff Expiry Flash",
	},
	mod_description = {
		en = "Flashes a big warning word, with an optional sound, when a talent or blessing attack buff you triggered with an action runs out: weapon swap, push, special action, block, dodge, reload or combat ability. Pick the buffs in the groups below.",
	},
}
