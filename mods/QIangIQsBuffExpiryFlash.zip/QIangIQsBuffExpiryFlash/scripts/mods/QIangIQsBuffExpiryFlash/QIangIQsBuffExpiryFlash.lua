-- QIangIQsBuffExpiryFlash: flashes when a chosen action-triggered attack buff runs out.
-- Buff list: QIangIQsBuffExpiryFlash_list.lua (generated from the game source).
local mod = get_mod("QIangIQsBuffExpiryFlash")
local FixedFrame = require("scripts/utilities/fixed_frame")
local PlayerUnitStatus = require("scripts/utilities/attack/player_unit_status")

local DIR = "QIangIQsBuffExpiryFlash/scripts/mods/QIangIQsBuffExpiryFlash/QIangIQsBuffExpiryFlash_"
local LIST = mod:io_dofile(DIR .. "list")
local Tracker = mod:io_dofile(DIR .. "tracker")

local MAX_FLASHES = 4
local COLORS = {
	red = { 230, 30, 30 },
	amber = { 255, 170, 0 },
	white = { 255, 255, 255 },
	cyan = { 0, 220, 255 },
}

local flashes = {}
local visible = {}
local tracked_unit = nil
local clock = 0
local last_sound = -10

local function _label(entry)
	if entry.loc and rawget(_G, "Localize") then
		local ok, text = pcall(Localize, entry.loc)

		if ok and type(text) == "string" and text ~= "" and string.sub(text, 1, 1) ~= "<" then
			return text
		end
	end

	return entry.title
end

local function _add_flash(key, text)
	for i = 1, #flashes do
		if flashes[i].key == key then
			flashes[i].started = clock

			return
		end
	end

	if #flashes >= MAX_FLASHES then
		table.remove(flashes, 1)
	end

	flashes[#flashes + 1] = { key = key, text = text, started = clock }
end

-- Same call as audible_ability_recharge.lua:6-10. Plays on this client only.
-- pcall: an event whose sound bank is not loaded must not break the mod.
local function _play_sound()
	if mod:get("sound_on") ~= true or clock - last_sound < 0.25 then
		return
	end

	last_sound = clock

	local world = Managers.world and Managers.world:has_world("level_world") and Managers.world:world("level_world")
	local wwise_world = world and Managers.world:wwise_world(world)

	if wwise_world then
		pcall(WwiseWorld.trigger_resource_event, wwise_world, mod:get("sound_event"))
	end
end

local tracker = Tracker.new(function (entry)
	local text = mod:get("text_style") == "name" and _label(entry) or (entry.word .. "!!")

	_add_flash(entry.id, text)
	_play_sound()
end)

local function _rebuild()
	local tracked = {}

	for i = 1, #LIST do
		local entry = LIST[i]

		if mod:get(entry.id) then
			for j = 1, #entry.templates do
				tracked[entry.templates[j]] = entry
			end
		end
	end

	tracker:set_tracked(tracked)

	tracker.flash_early = mod:get("flash_early") == true
end

local function _local_unit()
	local manager = Managers.player
	local player = manager and manager:local_player_safe(1)
	local unit = player and player.player_unit

	return unit and ALIVE[unit] and unit or nil
end

local function _is_down(unit)
	local unit_data = ScriptUnit.has_extension(unit, "unit_data_system")
	local state = unit_data and unit_data:read_component("character_state")

	return not state or PlayerUnitStatus.is_knocked_down(state) or PlayerUnitStatus.is_hogtied(state) or PlayerUnitStatus.is_dead(state)
end

mod.update = function (dt)
	clock = clock + dt

	local unit = _local_unit()

	if unit ~= tracked_unit then
		tracked_unit = unit

		tracker:reset()
	end

	if not unit then
		return
	end

	-- Many buffs drop at once when downed; that is not a timer running out.
	if _is_down(unit) then
		tracker:reset()

		return
	end

	local buff_extension = ScriptUnit.has_extension(unit, "buff_system")

	if buff_extension then
		tracker:update(buff_extension:buffs(), clock, FixedFrame.get_latest_fixed_time())
	end
end

-- Called by the HUD element -----------------------------------------------

mod.flash_color = function ()
	return COLORS[mod:get("flash_color")] or COLORS.red
end

mod.visible_flashes = function ()
	local seconds = mod:get("flash_seconds") or 2.5

	for i = #flashes, 1, -1 do
		if clock - flashes[i].started > seconds then
			table.remove(flashes, i)
		end
	end

	for i = 1, MAX_FLASHES do
		visible[i] = flashes[i]
	end

	return visible
end

mod.flash_alpha = function (flash)
	local rate = mod:get("flash_rate") or 4

	return 0.2 + 0.8 * math.abs(math.cos((clock - flash.started) * math.pi * rate))
end

mod.test_flash = function ()
	_add_flash("test", "CLEAVE!!")
	_play_sound()
end

-- Lifecycle ---------------------------------------------------------------

mod:register_hud_element({
	class_name = "HudElementQIangIQsBuffExpiryFlash",
	filename = DIR .. "hud",
	use_hud_scale = false,
	visibility_groups = { "alive" },
})

mod.on_all_mods_loaded = function ()
	_rebuild()
end

mod.on_enabled = function ()
	_rebuild()
end

mod.on_setting_changed = function (setting_id)
	if setting_id == "text_x" or setting_id == "text_y" or setting_id == "edge_thickness" or setting_id == "font_size" then
		mod.hud_settings_dirty = true
	else
		_rebuild()
	end
end

mod.on_game_state_changed = function ()
	tracker:reset()

	tracked_unit = nil
	flashes = {}
end

_rebuild()
