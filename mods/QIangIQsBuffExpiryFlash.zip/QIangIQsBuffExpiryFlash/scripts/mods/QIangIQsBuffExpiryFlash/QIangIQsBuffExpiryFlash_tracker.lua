-- Watches the local player's buff list by template name. Polling, because:
-- the HUD buff events fire only for buffs with an icon (buff.lua:862 has_hud),
-- proc buffs with active_duration are never removed, they only go inactive
-- (proc_buff.lua:78 _is_proc_active), and stacked buffs lose one stack at a time
-- (buff_extension_base.lua:635 _remove_buff).
-- No engine calls in here, so the harness can run it.
local GRACE = 0.1 -- seconds a buff must stay gone, so a same-moment refresh does not flash
local NEAR_END = 0.15 -- duration_progress at or below this counts as ran out on its timer

local Tracker = {}

Tracker.__index = Tracker

Tracker.new = function (on_expire)
	return setmetatable({ tracked = {}, states = {}, ready_states = {}, seen = {}, on_expire = on_expire, flash_early = false }, Tracker)
end

-- tracked: template name -> entry from the buff list
Tracker.set_tracked = function (self, tracked)
	self.tracked = tracked

	for name in pairs(self.states) do
		if not tracked[name] then
			self.states[name] = nil
		end
	end

	for name in pairs(self.ready_states) do
		if not tracked[name] then
			self.ready_states[name] = nil
		end
	end
end

Tracker.reset = function (self)
	for name in pairs(self.states) do
		self.states[name] = nil
	end

	for name in pairs(self.ready_states) do
		self.ready_states[name] = nil
	end
end

local function _progress(buff)
	local template = buff:template()

	-- A template with no timer of its own (a next-hit buff) has no meaningful progress.
	if not template.duration and not template.active_duration and not template.duration_func then
		return nil
	end

	return buff:duration_progress()
end

-- fixed_t: FixedFrame.get_latest_fixed_time(), for is_cooling_down (proc_buff.lua:146)
Tracker.update = function (self, buffs, t, fixed_t)
	local tracked, states, seen = self.tracked, self.states, self.seen
	local ready_states = self.ready_states

	for name in pairs(seen) do
		seen[name] = nil
	end

	for i = 1, #buffs do
		local buff = buffs[i]
		local name = buff:template_name()
		local entry = tracked[name]

		if entry and entry.mode == "ready" then
			-- The boost is on while off cooldown, so the moment to report is the cooldown ending.
			local cooling = buff.is_cooling_down and buff:is_cooling_down(fixed_t) or false

			if ready_states[name] and not cooling then
				self.on_expire(entry, name)
			end

			ready_states[name] = cooling
		elseif entry then
			local active = true

			if buff.is_proc_active then
				active = buff:is_proc_active()
			end

			if active then
				seen[name] = true

				local state = states[name]

				if not state then
					state = {}
					states[name] = state
				end

				state.gone_at = nil
				state.progress = _progress(buff)
			end
		end
	end

	for name, state in pairs(states) do
		if not seen[name] then
			if not state.gone_at then
				state.gone_at = t
			elseif t - state.gone_at >= GRACE then
				local progress = state.progress

				states[name] = nil

				if self.flash_early or not progress or progress <= NEAR_END then
					self.on_expire(tracked[name], name)
				end
			end
		end
	end
end

return Tracker
