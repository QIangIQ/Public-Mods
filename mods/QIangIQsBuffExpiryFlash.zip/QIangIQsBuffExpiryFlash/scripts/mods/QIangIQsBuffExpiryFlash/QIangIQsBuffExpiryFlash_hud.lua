local mod = get_mod("QIangIQsBuffExpiryFlash")

require("scripts/ui/hud/elements/hud_element_base")

local UIFontSettings = require("scripts/managers/ui/ui_font_settings")
local UIWidget = require("scripts/managers/ui/ui_widget")
local UIWorkspaceSettings = require("scripts/settings/ui/ui_workspace_settings")

local Hud = class("HudElementQIangIQsBuffExpiryFlash", "HudElementBase")

local MAX_ROWS = 4
local ROW_W, ROW_H = 1000, 200
local EDGES = { "edge_top", "edge_bottom", "edge_left", "edge_right" }

local function _scenegraph()
	local graph = {
		screen = UIWorkspaceSettings.screen,
		column = {
			parent = "screen",
			vertical_alignment = "center",
			horizontal_alignment = "center",
			size = { ROW_W, 10 },
			position = { 0, 0, 200 },
		},
		edge_top = { parent = "screen", vertical_alignment = "top", horizontal_alignment = "center", size = { 1920, 16 }, position = { 0, 0, 190 } },
		edge_bottom = { parent = "screen", vertical_alignment = "bottom", horizontal_alignment = "center", size = { 1920, 16 }, position = { 0, 0, 190 } },
		edge_left = { parent = "screen", vertical_alignment = "center", horizontal_alignment = "left", size = { 16, 1080 }, position = { 0, 0, 190 } },
		edge_right = { parent = "screen", vertical_alignment = "center", horizontal_alignment = "right", size = { 16, 1080 }, position = { 0, 0, 190 } },
	}

	for i = 1, MAX_ROWS do
		graph["row_" .. i] = {
			parent = "column",
			vertical_alignment = "top",
			horizontal_alignment = "center",
			size = { ROW_W, ROW_H },
			position = { 0, 0, 1 },
		}
	end

	return graph
end

local function _edge(id)
	return UIWidget.create_definition({
		{ pass_type = "rect", style_id = "bar", style = { color = { 0, 255, 255, 255 } } },
	}, id)
end

local function _widgets()
	local text_style = table.clone(UIFontSettings.hud_body)

	text_style.font_type = "machine_medium"
	text_style.font_size = 56
	text_style.drop_shadow = true
	text_style.text_horizontal_alignment = "center"
	text_style.text_vertical_alignment = "center"
	text_style.text_color = { 0, 255, 255, 255 }
	text_style.offset = { 0, 0, 2 }

	local widgets = {}

	for i = 1, #EDGES do
		widgets[EDGES[i]] = _edge(EDGES[i])
	end

	for i = 1, MAX_ROWS do
		widgets["row_" .. i] = UIWidget.create_definition({
			{ pass_type = "text", style_id = "text", value_id = "text", value = "", style = text_style },
		}, "row_" .. i)
	end

	return widgets
end

Hud.init = function (self, parent, draw_layer, start_scale)
	Hud.super.init(self, parent, draw_layer, start_scale, {
		scenegraph_definition = _scenegraph(),
		widget_definitions = _widgets(),
	})

	self:_apply_settings()
end

Hud._apply_settings = function (self)
	self:set_scenegraph_position("column", mod:get("text_x") or -350, mod:get("text_y") or 0)

	local font_size = mod:get("font_size") or 56
	local spacing = font_size * 1.2

	-- Rows are tall and the text is centred in them, so the first word sits on the chosen spot.
	for i = 1, MAX_ROWS do
		self:set_scenegraph_position("row_" .. i, 0, (i - 1) * spacing - ROW_H * 0.5)

		self._widgets_by_name["row_" .. i].style.text.font_size = font_size
	end

	local thick = mod:get("edge_thickness") or 16

	self:_set_scenegraph_size("edge_top", 1920, thick)
	self:_set_scenegraph_size("edge_bottom", 1920, thick)
	self:_set_scenegraph_size("edge_left", thick, 1080)
	self:_set_scenegraph_size("edge_right", thick, 1080)
end

local function _paint(color, alpha, r, g, b)
	color[1], color[2], color[3], color[4] = alpha, r, g, b
end

Hud.update = function (self, dt, t, ui_renderer, render_settings, input_service)
	Hud.super.update(self, dt, t, ui_renderer, render_settings, input_service)

	if mod.hud_settings_dirty then
		mod.hud_settings_dirty = false

		self:_apply_settings()
	end

	local widgets = self._widgets_by_name
	local alpha_max = (mod:get("max_alpha") or 100) * 2.55
	local rgb = mod.flash_color()
	local edge_alpha = 0
	local flashes = mod.visible_flashes()

	for i = 1, MAX_ROWS do
		local widget = widgets["row_" .. i]
		local flash = flashes[i]

		if flash then
			local alpha = mod.flash_alpha(flash) * alpha_max

			edge_alpha = math.max(edge_alpha, alpha)
			widget.content.text = flash.text
			widget.visible = true

			_paint(widget.style.text.text_color, alpha, rgb[1], rgb[2], rgb[3])
		else
			widget.visible = false
		end
	end

	local show_edges = edge_alpha > 0 and mod:get("edge_flash") == true

	for i = 1, #EDGES do
		local widget = widgets[EDGES[i]]

		widget.visible = show_edges

		if show_edges then
			_paint(widget.style.bar.color, edge_alpha, rgb[1], rgb[2], rgb[3])
		end
	end
end

return Hud
