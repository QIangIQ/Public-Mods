return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsBuffExpiryFlash` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsBuffExpiryFlash", {
			mod_script       = "QIangIQsBuffExpiryFlash/scripts/mods/QIangIQsBuffExpiryFlash/QIangIQsBuffExpiryFlash",
			mod_data         = "QIangIQsBuffExpiryFlash/scripts/mods/QIangIQsBuffExpiryFlash/QIangIQsBuffExpiryFlash_data",
			mod_localization = "QIangIQsBuffExpiryFlash/scripts/mods/QIangIQsBuffExpiryFlash/QIangIQsBuffExpiryFlash_localization",
		})
	end,
	packages = {},
}
