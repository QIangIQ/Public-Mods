return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsTalentHeat` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsTalentHeat", {
			mod_script       = "QIangIQsTalentHeat/scripts/mods/QIangIQsTalentHeat/QIangIQsTalentHeat",
			mod_data         = "QIangIQsTalentHeat/scripts/mods/QIangIQsTalentHeat/QIangIQsTalentHeat_data",
			mod_localization = "QIangIQsTalentHeat/scripts/mods/QIangIQsTalentHeat/QIangIQsTalentHeat_localization",
		})
	end,
	packages = {},
}
