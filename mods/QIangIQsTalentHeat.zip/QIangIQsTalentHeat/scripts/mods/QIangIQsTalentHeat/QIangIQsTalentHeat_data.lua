local mod = get_mod("QIangIQsTalentHeat")

local function checkbox(id, default, title, tooltip)
	return { setting_id = id, type = "checkbox", default_value = default, localize = false, title = title, tooltip = tooltip }
end

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			{
				setting_id = "toggle_key",
				type = "keybind",
				default_value = {},
				keybind_trigger = "pressed",
				keybind_type = "function_call",
				function_name = "toggle_heat",
				localize = false,
				title = "Toggle overlay (key)",
				tooltip = "Shows or hides the heat overlay without opening the menu.",
			},
			checkbox("heat_on", true, "Overlay on", "Master switch for the heatmap overlay."),
			checkbox("show_field", true, "Hotspot field", "Contour-style colour field behind the tree (blue = weak areas, red = excellent areas)."),
			checkbox("replace_bg", true, "Replace background", "Hides the game's tree background so the heatmap is the background."),
			checkbox("show_lobby", true, "Lobby heat", "Shows each player's build heat next to their level and Havoc info on the pre-mission screen."),
			checkbox("show_ingame", true, "In-mission heat", "Shows each player's build heat after their name on the in-mission team panels."),
			checkbox("show_score", true, "Heat score", "Shows the build heat score on the tree screen."),
			{
				setting_id = "score_side",
				type = "dropdown",
				default_value = "right",
				localize = false,
				title = "Score panel position",
				tooltip = "Where the live heat score panel sits on the talent screen.",
				options = {
					{ text = "Left side", value = "left", show_widget_localization = false },
					{ text = "Right side", value = "right", show_widget_localization = false },
					{ text = "Top banner", value = "top", show_widget_localization = false },
				},
			},
			{
				setting_id = "field_alpha",
				type = "numeric",
				default_value = 100,
				range = { 10, 100 },
				decimals_number = 0,
				localize = false,
				title = "Field opacity (%)",
				tooltip = "How strong the hotspot field is drawn.",
			},
		},
	},
}
