local mod = get_mod("QIangIQsTalentHeat")

-- Heatmap overlay on the talent trees (all archetypes). Ratings come from the
-- user's talent value assessment export (QIangIQsTalentHeat_ratings.lua, keyed
-- "talent@x,y" with rounded layout coordinates, same keys the page used).
--
-- Hooks (same class pair as QIangIQsPoE2Tree: classes copy parent methods, so
-- both the base view and the Talent view are hooked, with a re-entry guard):
--   _draw_node_widgets  draws the hotspot field and the node tints before the
--                       node widgets, inside the nodes render pass
--                       (node_builder_view_base.lua draw_layout)
--   draw                draws the build heat score in the overlay pass
--
-- Score: excellent 3, good 2, conditional 1.5, neutral 1, weak 0, summed over
-- the picked nodes (start node excluded); maximum is 3 per picked node.

local UIRenderer = require("scripts/managers/ui/ui_renderer")
local UIWidget = require("scripts/managers/ui/ui_widget")
local ButtonPassTemplates = require("scripts/ui/pass_templates/button_pass_templates")

local RATINGS = mod:io_dofile("QIangIQsTalentHeat/scripts/mods/QIangIQsTalentHeat/QIangIQsTalentHeat_ratings")

local WEIGHT = { e = 3, g = 2, c = 1.5, n = 1, w = 0 }
local NAME = { e = "excellent", g = "good", c = "conditional", n = "neutral", w = "weak" }
-- ARGB; ratings tint the node squares
local TINT = {
	e = { 255, 255, 72, 40 },
	g = { 255, 255, 170, 30 },
	c = { 255, 190, 90, 255 },
	n = { 255, 120, 130, 140 },
	w = { 255, 50, 130, 255 },
}

local BANDS = 15
local CELL = 6
local SIGMA = 105
local REACH2 = (SIGMA * 4) ^ 2
local FIELD_Z = -7
local BACKDROP = { 255, 12, 16, 38 }
local LEVELS = 5
local STOPS = {
	{ 0.0, 30, 60, 200 },
	{ 0.25, 0, 190, 230 },
	{ 0.45, 60, 200, 70 },
	{ 0.62, 250, 230, 40 },
	{ 0.8, 255, 140, 20 },
	{ 1.0, 230, 20, 20 },
}

local BAND_COLOR = {}

do
	for b = 0, BANDS - 1 do
		local p = (b + 0.5) / BANDS
		local lo, hi = STOPS[1], STOPS[#STOPS]

		for i = 1, #STOPS - 1 do
			if p >= STOPS[i][1] and p <= STOPS[i + 1][1] then
				lo, hi = STOPS[i], STOPS[i + 1]

				break
			end
		end

		local f = (p - lo[1]) / math.max(hi[1] - lo[1], 0.0001)

		BAND_COLOR[b] = {
			lo[2] + (hi[2] - lo[2]) * f,
			lo[3] + (hi[3] - lo[3]) * f,
			lo[4] + (hi[4] - lo[4]) * f,
		}
	end
end

-- Fallback when the game's x/y differ from the layout the ratings were made on:
-- match by talent id alone (only when every rating for that id agrees).
local BY_TALENT = {}

do
	local conflict = {}

	for key, code in pairs(RATINGS) do
		local talent = key:match("^(.-)@")

		if talent and talent ~= "null" then
			if BY_TALENT[talent] and BY_TALENT[talent] ~= code then
				conflict[talent] = true
			end

			BY_TALENT[talent] = code
		end
	end

	for talent in pairs(conflict) do
		BY_TALENT[talent] = nil
	end
end

local function _key(node)
	return string.format("%s@%d,%d", node.talent or "null", math.floor(node.x + 0.5), math.floor(node.y + 0.5))
end

local reported = {}

local function _report(where, err)
	if not reported[where] then
		reported[where] = true
		mod:error("%s failed: %s", where, tostring(err))
	end
end

-- Per layout: widget name -> node and rating, plus the run-length encoded field.
local function _build_field(rated, min_x, min_y, max_x, max_y)
	local pad = SIGMA * 3
	local x0, y0 = min_x - pad, min_y - pad
	local cols = math.ceil((max_x - min_x + 2 * pad) / CELL)
	local rows = math.ceil((max_y - min_y + 2 * pad) / CELL)
	local bands, alphas = {}, {}

	for r = 0, rows - 1 do
		local gy = y0 + (r + 0.5) * CELL
		local brow, arow = {}, {}

		for c = 0, cols - 1 do
			local gx = x0 + (c + 0.5) * CELL
			local num, den = 0, 0

			for i = 1, #rated do
				local n = rated[i]
				local dx, dy = gx - n.x, gy - n.y
				local d2 = dx * dx + dy * dy

				if d2 < REACH2 then
					local k = math.exp(-d2 / (2 * SIGMA * SIGMA))

					num = num + k * n.w
					den = den + k
				end
			end

			if den > 0.02 then
				brow[c] = math.min(BANDS - 1, math.max(0, math.floor(num / den / 3 * BANDS)))
				arow[c] = math.max(1, math.min(LEVELS, math.ceil(den / 0.8 * LEVELS)))
			end
		end

		bands[r], alphas[r] = brow, arow
	end

	-- colour terraces as horizontal runs
	local runs = {}

	for r = 0, rows - 1 do
		local run_start, run_key, run_band, run_alpha

		local function flush(c_end)
			if run_start then
				runs[#runs + 1] = { x0 + run_start * CELL, y0 + r * CELL, (c_end - run_start) * CELL, run_band, run_alpha }
			end

			run_start = nil
		end

		for c = 0, cols - 1 do
			local band, alpha = bands[r][c], alphas[r][c]
			local key = band and (band * 10 + alpha)

			if key and key == run_key then
				-- run continues
			else
				flush(c)

				if key then
					run_start, run_key, run_band, run_alpha = c, key, band, alpha
				end
			end
		end

		flush(cols)
	end

	-- contour lines: thin strokes along the boundary between differing bands
	-- (every third boundary is an index contour, drawn thicker and darker)
	local lines = {}

	local function boundary(a, b)
		if a and b and a ~= b then
			return math.max(a, b) % 3 == 0 and 2 or 1
		end
	end

	for r = 0, rows - 2 do
		local start, kind

		for c = 0, cols do
			local k = c < cols and boundary(bands[r][c], bands[r + 1][c]) or nil

			if k ~= kind then
				if kind then
					lines[#lines + 1] = { x0 + start * CELL, y0 + (r + 1) * CELL, (c - start) * CELL, 0, kind }
				end

				start, kind = c, k
			end
		end
	end

	for c = 0, cols - 2 do
		local start, kind

		for r = 0, rows do
			local k = r < rows and boundary(bands[r][c], bands[r][c + 1]) or nil

			if k ~= kind then
				if kind then
					lines[#lines + 1] = { x0 + (c + 1) * CELL, y0 + start * CELL, 0, (r - start) * CELL, kind }
				end

				start, kind = r, k
			end
		end
	end

	return runs, lines
end

local function _cache_for(self)
	local layout = self.get_active_layout and self:get_active_layout()

	if not layout or not layout.nodes then
		return nil
	end

	local cache = self.__heat_cache

	if cache and cache.layout == layout and cache.count == #layout.nodes then
		return cache
	end

	local by_name, rated = {}, {}
	local min_x, min_y, max_x, max_y = math.huge, math.huge, -math.huge, -math.huge

	for i = 1, #layout.nodes do
		local node = layout.nodes[i]
		local code = node.type ~= "start" and (RATINGS[_key(node)] or (node.talent and BY_TALENT[node.talent])) or nil

		by_name[node.widget_name] = { node = node, code = code }

		if code then
			rated[#rated + 1] = { x = node.x, y = node.y, w = WEIGHT[code] }
			min_x, min_y = math.min(min_x, node.x), math.min(min_y, node.y)
			max_x, max_y = math.max(max_x, node.x), math.max(max_y, node.y)
		end
	end

	cache = { layout = layout, count = #layout.nodes, by_name = by_name, rated = #rated }

	if #rated > 0 then
		cache.runs, cache.lines = _build_field(rated, min_x, min_y, max_x, max_y)
	end

	self.__heat_cache = cache

	local unmatched = {}

	for i = 1, #layout.nodes do
		local node = layout.nodes[i]

		if node.type ~= "start" and not by_name[node.widget_name].code and #unmatched < 6 then
			unmatched[#unmatched + 1] = _key(node)
		end
	end

	mod:info("layout built: %d nodes, %d rated, unmatched sample: %s", #layout.nodes, #rated, table.concat(unmatched, "; "))

	return cache
end

local function _widget_pos(self, widget)
	local pos = self:_scenegraph_world_position(widget.scenegraph_id)
	local w, h = self:_scenegraph_size(widget.scenegraph_id)

	return pos[1], pos[2], w or 0, h or 0
end

local function _draw_overlay(self, ui_renderer, screen_height, inverse_scale)
	local cache = _cache_for(self)
	local widgets = self._node_widgets

	if not self.__heat_logged then
		self.__heat_logged = true
		mod:info("overlay draw: cache %s, widgets %s, rated %s", tostring(cache ~= nil), tostring(widgets and #widgets), tostring(cache and cache.rated))
	end

	if not cache or not widgets or cache.rated == 0 then
		return
	end

	-- Fit layout coordinates to scenegraph positions from the widest and
	-- tallest pair of rated node widgets (position = origin + layout * scale).
	local ax, bx, ay, by

	for i = 1, #widgets do
		local entry = cache.by_name[widgets[i].name]

		if entry and entry.code then
			local node = entry.node

			if not ax or node.x < ax.node.x then ax = { node = node, widget = widgets[i] } end
			if not bx or node.x > bx.node.x then bx = { node = node, widget = widgets[i] } end
			if not ay or node.y < ay.node.y then ay = { node = node, widget = widgets[i] } end
			if not by or node.y > by.node.y then by = { node = node, widget = widgets[i] } end
		end
	end

	if not ax then
		return
	end

	local axp, _, aw, ah = _widget_pos(self, ax.widget)
	local bxp = _widget_pos(self, bx.widget)
	local _, ayp = _widget_pos(self, ay.widget)
	local _, byp = _widget_pos(self, by.widget)
	local sx = bx.node.x - ax.node.x > 1 and (bxp - axp) / (bx.node.x - ax.node.x) or 1
	local sy = by.node.y - ay.node.y > 1 and (byp - ayp) / (by.node.y - ay.node.y) or 1
	local ox = axp + aw * 0.5 - ax.node.x * sx
	local oy = ayp + ah * 0.5 - ay.node.y * sy

	local width_limit = RESOLUTION_LOOKUP.width * inverse_scale
	local height_limit = screen_height * inverse_scale

	if mod:get("show_field") then
		local alpha_pct = (mod:get("field_alpha") or 55) / 100
		local size = Vector3(0, 0, 0)

		-- Solid backdrop under the field: the heatmap replaces the screen background.
		if mod:get("replace_bg") then
			UIRenderer.draw_rect(ui_renderer, Vector3(-50, -50, FIELD_Z), Vector3(width_limit + 100, height_limit + 100, 0), BACKDROP)
		end

		local runs = cache.runs or {}
		local cell_h = CELL * sy

		for i = 1, #runs do
			local run = runs[i]
			local px, py = ox + run[1] * sx, oy + run[2] * sy
			local w = run[3] * sx

			if py + cell_h > 0 and py < height_limit and px + w > 0 and px < width_limit then
				local c = BAND_COLOR[run[4]]
				local a = 255 * alpha_pct * (run[5] / LEVELS)

				size[1], size[2] = w + 1, cell_h + 1
				UIRenderer.draw_rect(ui_renderer, Vector3(px, py, FIELD_Z), size, { a, c[1], c[2], c[3] })
			end
		end

		local lines = cache.lines or {}
		local line_size = Vector3(0, 0, 0)

		for i = 1, #lines do
			local ln = lines[i]
			local px, py = ox + ln[1] * sx, oy + ln[2] * sy
			local major = ln[5] == 2
			local t = (major and 2.6 or 1.4) * math.max(sx, sy)
			local w, h = ln[3] * sx, ln[4] * sy

			if w == 0 then
				w = t
				px = px - t * 0.5
			else
				h = t
				py = py - t * 0.5
			end

			if py + h > 0 and py < height_limit and px + w > 0 and px < width_limit then
				line_size[1], line_size[2] = w, h
				UIRenderer.draw_rect(ui_renderer, Vector3(px, py, FIELD_Z + 1), line_size, major and { 235, 6, 8, 20 } or { 150, 6, 8, 20 })
			end
		end
	end
end

local function _score(self)
	local cache = _cache_for(self)
	-- current game: widget name -> tier (0/1+); older source: _points_spent_on_node_widgets
	local spent = self._node_widget_tiers or self._points_spent_on_node_widgets

	if not cache or not spent then
		return nil
	end

	local total, picked = 0, 0
	local counts = { e = 0, g = 0, c = 0, n = 0, w = 0 }

	for widget_name, points in pairs(spent) do
		local entry = cache.by_name[widget_name]

		if type(points) == "number" and points > 0 and entry and entry.code then
			total = total + WEIGHT[entry.code]
			picked = picked + 1
			counts[entry.code] = counts[entry.code] + 1
		end
	end

	return total, picked * 3, picked, counts
end

local ORDER = { "e", "g", "c", "n", "w" }
local LABEL = { e = "Excellent", g = "Good", c = "Conditional", n = "Neutral", w = "Weak" }

local function _heat_color(p)
	local best = BAND_COLOR[math.min(BANDS - 1, math.max(0, math.floor(p * BANDS)))]

	return { 255, best[1], best[2], best[3] }
end

-- Live stats panel, redrawn every frame from the points currently spent. Drawn
-- inside the nodes render pass (where the field and rings are known to show),
-- converting screen pixels to that pass's units with inverse_scale.
local function _draw_panel(self, ui_renderer, inverse_scale)
	local total, max, picked, counts = _score(self)

	if not total then
		return
	end

	local k = (RESOLUTION_LOOKUP.height / 1080) * (inverse_scale or 1)
	local frac = max > 0 and total / max or 0
	local pct = math.floor(frac * 100 + 0.5)
	local side = mod:get("score_side") or "right"
	local w, h = 400, 290
	local x, y = 60, 230

	if side == "right" then
		x = RESOLUTION_LOOKUP.width / (RESOLUTION_LOOKUP.height / 1080) - w - 60
	elseif side == "top" then
		x, y = (RESOLUTION_LOOKUP.width / (RESOLUTION_LOOKUP.height / 1080) - w) * 0.5, 20
		h = 120
	end

	local z = 20

	if not self.__heat_panel_logged then
		self.__heat_panel_logged = true
		mod:info("panel: total %s max %s picked %s side %s at %s,%s k %s screen %sx%s", tostring(total), tostring(max), tostring(picked), side, tostring(x), tostring(y), tostring(k), tostring(RESOLUTION_LOOKUP.width), tostring(RESOLUTION_LOOKUP.height))
	end

	local function rect(rx, ry, rw, rh, color, dz)
		UIRenderer.draw_rect(ui_renderer, Vector3(rx * k, ry * k, z + (dz or 0)), Vector3(rw * k, rh * k, 0), color)
	end

	local function text(str, size, px, py, color)
		UIRenderer.draw_text(ui_renderer, str, size * k, "proxima_nova_bold", Vector3(px * k, py * k, z + 3), Vector2((w - 40) * k, (size + 8) * k), color, {})
	end

	rect(x, y, w, h, { 225, 8, 10, 16 })
	rect(x, y, w, 3, { 255, 230, 170, 60 }, 1)
	text("BUILD HEAT", 22, x + 20, y + 14, { 255, 200, 200, 200 })
	text(string.format("%.1f / %d", total, max), 44, x + 20, y + 40, _heat_color(frac))
	text(string.format("%d%%   %d nodes", pct, picked), 20, x + 20, y + 92, { 255, 200, 200, 200 })

	local bar_w = w - 40

	rect(x + 20, y + 122, bar_w, 12, { 255, 40, 44, 52 }, 1)
	rect(x + 20, y + 122, math.max(2, bar_w * frac), 12, _heat_color(frac), 2)

	if side ~= "top" then
		for i = 1, #ORDER do
			local code = ORDER[i]
			local row_y = y + 150 + (i - 1) * 26
			local t = TINT[code]

			rect(x + 20, row_y + 4, 16, 16, { 255, t[2], t[3], t[4] }, 2)
			text(string.format("%s  x%d", LABEL[code], counts[code]), 20, x + 46, row_y, { 255, 220, 220, 220 })
			text(string.format("%.1f", counts[code] * WEIGHT[code]), 20, x + w - 90, row_y, { 255, 170, 170, 170 })
		end
	end
end

local function _hook_points(view_class)
	mod:hook(view_class, "_draw_node_widgets", function (func, self, ui_renderer, screen_height, inverse_scale, ...)
		if self.__heat_in or not mod:get("heat_on") then
			return func(self, ui_renderer, screen_height, inverse_scale, ...)
		end

		self.__heat_in = true

		local ok, err = pcall(_draw_overlay, self, ui_renderer, screen_height, inverse_scale)

		if not ok then
			_report("overlay", err)
		end

		local ok2, err2 = pcall(func, self, ui_renderer, screen_height, inverse_scale, ...)

		if ok2 and mod:get("show_score") then
			local ok3, err3 = pcall(_draw_panel, self, ui_renderer, inverse_scale)

			if not ok3 then
				_report("panel", err3)
			elseif not self.__heat_score_logged then
				self.__heat_score_logged = true
				mod:info("score panel drawn")
			end
		end

		self.__heat_in = nil

		if not ok2 then
			error(err2)
		end
	end)
end

local HIDE = { layout_background = true, archetype_middle_coin = true }

local function _hook_layout(view_class)
	mod:hook(view_class, "draw_layout", function (func, self, dt, t, input_service, layer, ...)
		local hidden

		if mod:get("heat_on") and mod:get("show_field") and mod:get("replace_bg") and self._layout_node_widgets then
			hidden = {}

			for i = 1, #self._layout_node_widgets do
				local widget = self._layout_node_widgets[i]

				if HIDE[widget.name] and widget.visible ~= false then
					widget.visible = false
					hidden[#hidden + 1] = widget
				end
			end
		end

		local ok, err = pcall(func, self, dt, t, input_service, layer, ...)

		if hidden then
			for i = 1, #hidden do
				hidden[i].visible = true
			end
		end

		if not ok then
			error(err)
		end
	end)

	-- The field sits above the game's own background, so the connection lines
	-- are drawn a few layers higher to stay visible on top of it.
	mod:hook(view_class, "_draw_layout_node_connections", function (func, self, dt, t, input_service, ui_renderer, render_settings, ...)
		if not mod:get("heat_on") or not mod:get("show_field") or not render_settings then
			return func(self, dt, t, input_service, ui_renderer, render_settings, ...)
		end

		local old_layer = render_settings.start_layer

		render_settings.start_layer = (old_layer or 0) + 5

		local ok, err = pcall(func, self, dt, t, input_service, ui_renderer, render_settings, ...)

		render_settings.start_layer = old_layer

		if not ok then
			error(err)
		end
	end)
end

mod.toggle_heat = function ()
	mod:set("heat_on", not mod:get("heat_on"))
end

-- "Post heat to chat" button under ShareTalents' Copy / Paste buttons. Same
-- widget pattern as ShareTalents (info_banner scenegraph, terminal_button_small);
-- it hangs off info_banner with the offset of a third stacked button so it works
-- with or without ShareTalents.
local BUTTON = "__qiangiqs_heat_post"

local function _post_heat(view)
	local total, max, picked, counts = _score(view)

	if not total then
		mod:echo("%s", "Talent Heat: no rated build on this screen.")

		return
	end

	local layout = view:get_active_layout()
	local archetype = layout and layout.archetype_name or "build"
	local pct = max > 0 and math.floor(total / max * 100 + 0.5) or 0

	mod:echo("%s", string.format("Talent Heat (%s): %.1f / %d (%d%%) - %d nodes: %d excellent, %d good, %d conditional, %d neutral, %d weak", archetype, total, max, pct, picked, counts.e, counts.g, counts.c, counts.n, counts.w))
end

mod:hook_require("scripts/ui/views/talent_builder_view/talent_builder_view_definitions", function (definitions)
	if definitions.widget_definitions[BUTTON] then
		return
	end

	definitions.widget_definitions[BUTTON] = UIWidget.create_definition(ButtonPassTemplates.terminal_button_small, BUTTON, {
		text = mod:localize("post_heat_button"),
	})
	definitions.overlay_scenegraph_definition[BUTTON] = {
		parent = "info_banner",
		vertical_alignment = "bottom",
		horizontal_alignment = "center",
		size = { 200, 36 },
		position = { 0, 38 + 84, 20 },
	}
end)

_hook_button = function (view_class)
	mod:hook_safe(view_class, "on_enter", function (self)
		local widget = self._widgets_by_name[BUTTON]

		if widget then
			widget.content.hotspot.pressed_callback = function ()
				local ok, err = pcall(_post_heat, self)

				if not ok then
					_report("post button", err)
				end
			end
		end
	end)

	mod:hook_safe(view_class, "_update_button_statuses", function (self)
		local widget = self._widgets_by_name[BUTTON]

		if widget then
			widget.content.hotspot.disabled = self:_is_handling_popup_window() or self._input_blocked
		end
	end)

	mod:hook(view_class, "_allowed_node_input", function (func, self, ...)
		local widget = self._widgets_by_name[BUTTON]

		if widget and widget.content.hotspot.is_hover then
			return false
		end

		return func(self, ...)
	end)
end

-- One callback only: the Mod Framework keeps a single hook_require callback per
-- mod and file, so a second call replaces the first.
mod:hook_require("scripts/ui/views/talent_builder_view/talent_builder_view", function (view_class)
	_hook_layout(view_class)
	_hook_points(view_class)
	_hook_button(view_class)
end)

-- Pre-mission lobby: a heat segment next to each player's level / Havoc info.
-- Same approach as current_havoc (elements/lobby.lua): splice a text segment into
-- the lobby panel's character_name. Other players' builds are known by talent
-- name only (profile.talents), so the lobby heat is summed per talent id from
-- QIangIQsTalentHeat_talents.lua instead of per tree node.
local TALENT_WEIGHTS = mod:io_dofile("QIangIQsTalentHeat/scripts/mods/QIangIQsTalentHeat/QIangIQsTalentHeat_talents")

local function _profile_heat(profile)
	local talents = profile and profile.talents

	if type(talents) ~= "table" then
		return nil
	end

	local preferred = profile.archetype and profile.archetype.name
	local best_total, best_count = 0, 0

	for archetype, weights in pairs(TALENT_WEIGHTS) do
		local total, count = 0, 0

		for talent, points in pairs(talents) do
			local w = weights[talent]

			if w and (type(points) ~= "number" or points > 0) then
				total = total + w
				count = count + 1
			end
		end

		if count > best_count or (count == best_count and archetype == preferred and count > 0) then
			best_total, best_count = total, count
		end
	end

	if best_count == 0 then
		return nil
	end

	return best_total, best_count * 3, best_count
end

local function _lobby_segment(total, max)
	local frac = max > 0 and total / max or 0
	local c = _heat_color(frac)

	return string.format("{#color(%d,%d,%d)}[Heat %d/%d]{#reset()}", math.floor(c[2]), math.floor(c[3]), math.floor(c[4]), math.floor(total + 0.5), max)
end

local function _splice_segment(text, segment)
	local nl = text:find("\n", 1, true)
	local first, rest = text, ""

	if nl then
		first, rest = text:sub(1, nl - 1), text:sub(nl)
	end

	local dash = first:find(" - ", 1, true)

	if dash then
		first = first:sub(1, dash - 1) .. " " .. segment .. first:sub(dash)
	else
		first = first .. " " .. segment
	end

	return first .. rest
end

local function _remove_segment(text, segment)
	local s, e = text:find(segment, 1, true)

	if not s then
		return text
	end

	if s > 1 and text:sub(s - 1, s - 1) == " " then
		s = s - 1
	end

	return text:sub(1, s - 1) .. text:sub(e + 1)
end

mod:hook_safe("LobbyView", "update", function (self)
	if not mod:is_enabled() or not mod:get("heat_on") or not mod:get("show_lobby") then
		return
	end

	local spawn_slots = self._spawn_slots

	if not spawn_slots then
		return
	end

	for i = 1, #spawn_slots do
		local slot = spawn_slots[i]
		local widget = slot and slot.panel_widget
		local content = widget and widget.content
		local text = content and content.character_name

		if slot and slot.occupied and slot.profile and text and text ~= "" then
			if slot.__heat_profile ~= slot.profile then
				slot.__heat_profile = slot.profile

				local total, max = _profile_heat(slot.profile)

				slot.__heat_segment = total and _lobby_segment(total, max) or nil
			end

			local segment = slot.__heat_segment
			local old = widget.__heat_applied

			if old and old ~= segment then
				text = _remove_segment(text, old)
			end

			if segment and not text:find(segment, 1, true) then
				text = _splice_segment(text, segment)
			end

			widget.__heat_applied = segment
			content.character_name = text
		end
	end
end)

-- In-mission team panels: heat segment after each player's name, permanently.
mod:hook_require("scripts/ui/hud/elements/player_panel_base/hud_element_player_panel_base", function (panel_class)
	mod:hook(panel_class, "_set_player_name", function (func, self, name, current_level)
		if mod:is_enabled() and mod:get("heat_on") and mod:get("show_ingame") and type(name) == "string" then
			local player = self._player
			local profile = player and player.profile and player:profile()
			local ok, total, max = pcall(_profile_heat, profile)

			if ok and total then
				name = name .. " " .. _lobby_segment(total, max)
			end
		end

		return func(self, name, current_level)
	end)
end)
