return {
	mod_name = {
		en = "QIangIQs Talent Heat",
	},
	mod_description = {
		en = "Heatmap overlay on every talent tree. Each node is tinted by your own rating (excellent, good, conditional, neutral, weak), a contour field behind the tree shows hotspots, and a build heat score (points out of the maximum) is shown on the tree screen.",
	},
	post_heat_button = {
		en = "Post heat to chat",
	},
}
