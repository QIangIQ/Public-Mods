return {
	mod_name = {
		en = "QIangIQs Talent Heat",
	},
	mod_description = {
		en = "Heatmap overlay on every talent tree. Each node is tinted by your own rating (excellent, good, conditional, neutral, weak), a contour field behind the tree shows hotspots, and a build heat score is shown on the tree screen, in the lobby, on team panels and over each player's head. Heat is shown as a percentage: raw score 50 = 0 percent, 85 = 100 percent (set points adjustable).",
	},
	post_heat_button = {
		en = "Post heat to chat",
	},
}
