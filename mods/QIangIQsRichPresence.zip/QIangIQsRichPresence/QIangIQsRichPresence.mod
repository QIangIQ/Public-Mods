return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsRichPresence` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsRichPresence", {
			mod_script       = "QIangIQsRichPresence/scripts/mods/QIangIQsRichPresence/QIangIQsRichPresence",
			mod_data         = "QIangIQsRichPresence/scripts/mods/QIangIQsRichPresence/QIangIQsRichPresence_data",
			mod_localization = "QIangIQsRichPresence/scripts/mods/QIangIQsRichPresence/QIangIQsRichPresence_localization",
		})
	end,
	packages = {},
}
