return {
	mod_name = {
		en = "QIangIQs Rich Presence",
	},
	mod_description = {
		en = "Shows your mission, difficulty, class and level on Discord. Needs no DLLs. Reads True Level, Havoc ranks above 40, the Novitiate class, custom titles and custom maps.",
	},
	havoc_rank_shown = {
		en = "Havoc rank shown",
	},
	havoc_rank_shown_tooltip = {
		en = "Shows this Havoc rank on Discord during any mission. 0 uses the mission's real difficulty. Only changes the Discord text, not the mission.",
	},
	show_name = {
		en = "Show character name",
	},
	show_name_tooltip = {
		en = "Put your character name on the Discord status line.",
	},
	show_level = {
		en = "Show level",
	},
	show_level_tooltip = {
		en = "Put your level on the Discord status line. Uses True Level when that mod is on, including its custom display levels.",
	},
	show_title = {
		en = "Show title",
	},
	show_title_tooltip = {
		en = "Put your equipped title after your character on Discord, including titles picked in QIangIQs Custom Titles such as Atoman Remorae Vanguard.",
	},
	show_modifiers = {
		en = "Show mission modifiers",
	},
	show_modifiers_tooltip = {
		en = "List Havoc and mission conditions. Discord allows 128 characters per line, so those that do not fit go in the map image tooltip.",
	},
	show_solo_tag = {
		en = "Show Solo tag",
	},
	show_solo_tag_tooltip = {
		en = "Add Solo to the mission line in a SoloPlay local game.",
	},
	offer_join = {
		en = "Offer Join on Discord",
	},
	offer_join_tooltip = {
		en = "Let Discord offer a Join for your party. This shares your party id and Fatshark account id with whoever joins. Never offered in a SoloPlay game or a private session.",
	},
	debug_logging = {
		en = "Debug logging",
	},
	debug_logging_tooltip = {
		en = "Write the presence lines and Discord connection events to the console log when they change.",
	},
	joining = {
		en = "Joining party from Discord invite...",
	},
	join_refused = {
		en = "Could not join from the Discord invite.",
	},
	join_failed = {
		en = "Could not join that party. It may be private, full or in a mission.",
	},
}
