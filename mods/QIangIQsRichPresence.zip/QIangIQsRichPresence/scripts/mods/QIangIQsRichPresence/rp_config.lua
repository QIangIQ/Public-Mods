-- Edit this file to change the Discord app and its art. DMF has no text-entry
-- setting, so these values live here rather than in the mod options menu.

local config = {}

-- The Discord application the presence appears under. Discord shows the app's
-- name ("Warhammer 40,000; Darktide") and resolves art keys against it.
-- This default is the app TzeentchRichPresence 0.1.1 ships with; it belongs to
-- that mod's author. To use your own art, create an app at
-- discord.com/developers/applications and put its id here.
config.application_id = "1530377227470897152"

-- Art keys uploaded to that app, read 2026-11-05 from
-- discord.com/api/v10/oauth2/applications/<id>/assets. A key not listed here
-- would show no picture, so anything else falls back to mission_default.
config.mission_keys = {
	cm_archives = true, cm_habs = true, cm_raid = true, core_research = true,
	dm_forge = true, dm_propaganda = true, dm_rise = true, dm_stockpile = true,
	exp_wastes = true, fm_armoury = true, fm_cargo = true, fm_resurgence = true,
	hm_cartel = true, hm_complex = true, hm_strain = true, hub_ship = true,
	km_enforcer = true, km_enforcer_twins = true, km_heresy = true, km_station = true,
	lm_cooling = true, lm_rails = true, lm_scavenge = true,
	op_no_mans_land = true, op_train = true, psykhanium = true,
}

config.mission_fallback = "mission_default"

config.class_keys = {
	adamant = true, broker = true, cryptic = true, ogryn = true,
	psyker = true, veteran = true, zealot = true,
}

-- Your own art for custom content. A value is an art key on the app above or a
-- full https image URL (Discord accepted a URL over the pipe on 2026-11-05).
-- Example: bell_vt2 = "https://example.com/bell.png"
config.mission_images = {}

-- Example: novitiate = "https://example.com/novitiate.png"
config.class_images = {}

return config
