-- Text helpers. Pure Lua: no game calls, so the harness can test them directly.

local text = {}

-- Measured against Discord on 2026-11-05: details, state, large_text and
-- small_text each accept 2 to 128 and reject the WHOLE activity outside that.
-- The count is UTF-16 units, not bytes: 128 CJK characters passed and 129 failed;
-- 14 ASCII + 57 emoji (128 units) passed and 14 ASCII + 58 emoji (130 units) failed.
text.MAX_UNITS = 128
text.MIN_UNITS = 2

local function sequence(byte)
	if byte < 0x80 then
		return 1, 1
	elseif byte < 0xC0 then
		-- Stray continuation byte: step over it rather than stall.
		return 1, 1
	elseif byte < 0xE0 then
		return 2, 1
	elseif byte < 0xF0 then
		return 3, 1
	end

	-- 4-byte UTF-8 is outside the BMP, so UTF-16 needs a surrogate pair.
	return 4, 2
end

function text.units(value)
	local count, i, length = 0, 1, #value

	while i <= length do
		local bytes, units = sequence(value:byte(i))

		count = count + units
		i = i + bytes
	end

	return count
end

--- Trims to max_units without splitting a character or surrogate pair.
function text.clip(value, max_units)
	local count, i, length = 0, 1, #value

	while i <= length do
		local bytes, units = sequence(value:byte(i))

		if count + units > max_units then
			return value:sub(1, i - 1)
		end

		count = count + units
		i = i + bytes
	end

	return value
end

--- Removes what Discord would show literally or as boxes: Stingray markup such
--- as {#color(255,50,50)}, the game's private-use class glyphs (U+E000-U+F8FF),
--- and control characters.
function text.clean(value)
	if type(value) ~= "string" then
		return nil
	end

	local cleaned = value:gsub("{#.-}", "")

	cleaned = cleaned:gsub("\238[\128-\191][\128-\191]", "")
	cleaned = cleaned:gsub("\239[\128-\163][\128-\191]", "")
	cleaned = cleaned:gsub("[%z\1-\31\127]", " ")
	cleaned = cleaned:gsub("%s+", " ")
	cleaned = cleaned:match("^%s*(.-)%s*$")

	return cleaned ~= "" and cleaned or nil
end

--- A value safe for a 2-128 field, or nil. nil means "leave the field out",
--- since one invalid field makes Discord reject the entire activity.
function text.field(value)
	local cleaned = text.clean(value)

	if not cleaned then
		return nil
	end

	cleaned = text.clip(cleaned, text.MAX_UNITS):match("^(.-)%s*$")

	if text.units(cleaned) < text.MIN_UNITS then
		return nil
	end

	return cleaned
end

--- Fills one line from pieces in order and stops at the first that does not
--- fit, returning the line and the first unused index. Stopping (not skipping)
--- keeps the order stable, so the text does not flip between refreshes.
function text.fill(pieces, first, separator)
	local line = nil
	local i = first

	while pieces[i] do
		local candidate = line and (line .. separator .. pieces[i]) or pieces[i]

		if text.units(candidate) > text.MAX_UNITS then
			break
		end

		line = candidate
		i = i + 1
	end

	return line, i
end

--- "reduce_toughness" -> "Reduce Toughness". For ids with no localization.
function text.humanize(name)
	if type(name) ~= "string" or name == "" then
		return nil
	end

	local words = {}

	for word in name:gmatch("[^_]+") do
		words[#words + 1] = word:sub(1, 1):upper() .. word:sub(2)
	end

	return table.concat(words, " ")
end

local ESCAPES = {
	['"'] = '\\"',
	["\\"] = "\\\\",
	["\b"] = "\\b",
	["\f"] = "\\f",
	["\n"] = "\\n",
	["\r"] = "\\r",
	["\t"] = "\\t",
}

function text.json_string(value)
	local escaped = value:gsub('[%z\1-\31"\\]', function (char)
		return ESCAPES[char] or string.format("\\u%04x", char:byte())
	end)

	return '"' .. escaped .. '"'
end

return text
