-- Turns a gather snapshot into the Discord activity. Deterministic: the same
-- game state must give the same JSON, or the duplicate check cannot work.

local mod = get_mod("QIangIQsRichPresence")
local config = mod:io_dofile("QIangIQsRichPresence/scripts/mods/QIangIQsRichPresence/rp_config")
local text = mod:io_dofile("QIangIQsRichPresence/scripts/mods/QIangIQsRichPresence/rp_text")

local build = {}

local SEP = " \194\183 " -- middle dot, UTF-8
local JOIN_VERSION = "tzrp1" -- the same secret layout as TzeentchRichPresence, so both mods can join each other
local JOIN_SEP = "|"
local MAX_ID_BYTES = 128 -- partyId and joinSecret, discord-rpc include/discord_rpc.h:35,40

-- Fading Light only restates the Havoc rank.
local SKIP_CIRCUMSTANCE = {
	default = true,
	mutator_highest_difficulty = true,
	mutator_increased_difficulty = true,
}

--- Game localization, or nil. This calls localize directly and does not ask
--- LocalizationManager:exists first: DMF's add_global_localize_strings only hooks
--- "localize" (dmf/modules/core/localization.lua:95), so exists() is false for
--- modded names like loc_mission_name_bell_vt2 and the map would lose its name.
--- A missing key comes back as "<key>", the same test QIangIQsUltraHavoc_data uses.
local function loc(key)
	if type(key) ~= "string" or key == "" then
		return nil
	end

	local manager = Managers and Managers.localization

	if not manager then
		return nil
	end

	local ok, value = pcall(manager.localize, manager, key)

	if not ok or type(value) ~= "string" or value == "" or value:sub(1, 1) == "<" then
		return nil
	end

	return value
end

local function require_safe(path)
	local ok, value = pcall(require, path)

	return ok and value or nil
end

local function circumstance_template(name)
	if type(name) ~= "string" or SKIP_CIRCUMSTANCE[name] then
		return nil
	end

	local templates = require_safe("scripts/settings/circumstance/circumstance_templates")

	return templates and templates[name] or nil
end

local function is_maelstrom(name)
	local template = circumstance_template(name)
	local icon = template and template.ui and template.ui.icon

	return type(icon) == "string" and icon:find("circumstances/maelstrom", 1, true) ~= nil
end

local function circumstance_label(name)
	local template = circumstance_template(name)
	local label = template and template.ui and loc(template.ui.display_name)

	if label and is_maelstrom(name) then
		local code = label:gsub("^Maelstrom Mission%s+", "")

		if code ~= "" and code ~= label then
			return "Maelstrom " .. code
		end
	end

	return label
end

--- Returns the tier text and the circumstance it used up, if any.
local function get_tier(snapshot)
	-- The options slider. Display only: 0 means use the mission's real difficulty.
	local shown = snapshot.in_mission and tonumber(mod:get("havoc_rank_shown"))

	if shown and shown >= 1 then
		return "Havoc " .. string.format("%d", shown), nil
	end

	if snapshot.havoc and snapshot.havoc.rank then
		return "Havoc " .. tostring(snapshot.havoc.rank), nil
	end

	if is_maelstrom(snapshot.circumstance) then
		return circumstance_label(snapshot.circumstance) or "Maelstrom", snapshot.circumstance
	end

	return loc(snapshot.difficulty_loc), nil
end

local function get_modifiers(snapshot, used)
	local pieces, seen = {}, {}

	if used then
		seen[used] = true
	end

	local function add(name)
		if name and not seen[name] then
			seen[name] = true
			pieces[#pieces + 1] = circumstance_label(name)
		end
	end

	if snapshot.havoc then
		for _, name in ipairs(snapshot.havoc.circumstances) do
			add(name)
		end
	end

	add(snapshot.circumstance)

	return pieces
end

local function get_headline(snapshot, tier)
	local map = loc(snapshot.mission_loc)

	if not map and snapshot.in_mission then
		map = text.humanize(snapshot.mission_key)
	end

	if map then
		return tier and (tier .. SEP .. map) or map, map
	end

	local presence = require_safe("scripts/settings/presence/presence_settings")
	local settings = presence and presence.settings and snapshot.activity_id and presence.settings[snapshot.activity_id]

	return settings and loc(settings.hud_localization) or "In the Mourningstar", nil
end

--- "Calvin - Novitiate 293970"; each part can be switched off in the options.
local function get_player_line(player)
	if not player then
		return nil
	end

	local class_label = text.clean(player.custom_class_label)

	if not class_label then
		local archetypes = require_safe("scripts/settings/archetype/archetypes")
		local archetype = archetypes and archetypes[player.archetype]

		class_label = archetype and loc(archetype.archetype_name) or text.humanize(player.archetype)
	end

	local name = mod:get("show_name") ~= false and text.clean(player.name) or nil
	local level = mod:get("show_level") ~= false and tonumber(player.level) or nil
	local class_part = class_label

	if class_part and level then
		class_part = string.format("%s %d", class_part, level)
	end

	if name and class_part then
		return name .. " - " .. class_part
	end

	return class_part or name
end

local function mission_image(key)
	local custom = key and config.mission_images[key]

	if custom then
		return custom
	end

	return key and config.mission_keys[key] and key or config.mission_fallback
end

local function class_image(player)
	if not player then
		return nil
	end

	local custom = player.custom_class and config.class_images[player.custom_class]

	if custom then
		return custom
	end

	-- A custom class built on a retail class uses that class's icon. No fallback
	-- key exists on this app ("class_default" is not among its uploaded assets).
	return config.class_keys[player.archetype] and player.archetype or nil
end

local function join_secret(snapshot)
	if mod:get("offer_join") == false then
		return nil, "turned off"
	end

	local party, player = snapshot.party, snapshot.player

	if not party.id or not party.joinable_id then
		return nil, "no party id"
	end

	if not player or type(player.account_id) ~= "string" or player.account_id == "" then
		return nil, "no account id yet"
	end

	if not snapshot.joinable then
		return nil, "not joinable (solo, loading, or private session)"
	end

	if party.size >= party.max then
		return nil, "party full"
	end

	local secret = JOIN_VERSION .. JOIN_SEP .. party.id .. JOIN_SEP .. player.account_id

	if #secret > MAX_ID_BYTES then
		return nil, "secret too long"
	end

	return secret, "joinable"
end

--- snapshot + start time -> activity table.
function build.activity(snapshot, start_time)
	local tier, used = get_tier(snapshot)
	local headline, map = get_headline(snapshot, tier)
	local pieces = { text.field(headline) }

	if not pieces[1] then
		return nil
	end

	if snapshot.solo and snapshot.in_mission and mod:get("show_solo_tag") ~= false then
		pieces[#pieces + 1] = "Solo"
	end

	if mod:get("show_modifiers") ~= false then
		for _, modifier in ipairs(get_modifiers(snapshot, used)) do
			pieces[#pieces + 1] = text.clean(modifier)
		end
	end

	-- Discord's 128 limit is per field and cannot be raised, so what does not fit
	-- on the visible line continues in the map image's hover text.
	local details, next_piece = text.fill(pieces, 1, SEP)
	local overflow = text.fill(pieces, next_piece, SEP)
	local player_line = text.field(get_player_line(snapshot.player))
	local title = mod:get("show_title") ~= false and snapshot.player and text.clean(snapshot.player.title) or nil
	local state_line = player_line

	-- The title goes after the character only if all of it fits in the 128.
	if title and player_line then
		state_line = text.fill({ player_line, title }, 1, SEP)
	elseif title then
		state_line = text.field(title)
	end
	local party = snapshot.party
	local secret, join_reason = join_secret(snapshot)
	local party_id = party.id

	if party_id and #party_id > MAX_ID_BYTES then
		party_id = nil
	end

	return {
		details = details,
		state = state_line,
		large_image = mission_image(snapshot.mission_key),
		large_text = text.field(overflow or map or headline),
		small_image = class_image(snapshot.player),
		small_text = text.field(title and player_line and (title .. SEP .. player_line) or player_line),
		party_id = party_id or ("qrp-" .. tostring(start_time)),
		party_size = party.size,
		party_max = party.max,
		join_secret = secret,
		join_reason = join_reason,
		start_time = start_time,
	}
end

--- The SET_ACTIVITY "activity" object, in a fixed key order. Hover text goes out
--- only with its image, and Discord refuses buttons alongside a join secret
--- (error 5005, measured 2026-11-05), so this mod sends no buttons.
function build.encode(activity)
	local json = text.json_string
	local parts = { '"details":' .. json(activity.details) }

	if activity.state then
		parts[#parts + 1] = '"state":' .. json(activity.state)
	end

	parts[#parts + 1] = string.format('"timestamps":{"start":%d}', activity.start_time)

	local assets = { '"large_image":' .. json(activity.large_image) }

	if activity.large_text then
		assets[#assets + 1] = '"large_text":' .. json(activity.large_text)
	end

	if activity.small_image then
		assets[#assets + 1] = '"small_image":' .. json(activity.small_image)

		if activity.small_text then
			assets[#assets + 1] = '"small_text":' .. json(activity.small_text)
		end
	end

	parts[#parts + 1] = '"assets":{' .. table.concat(assets, ",") .. "}"
	parts[#parts + 1] = string.format('"party":{"id":%s,"size":[%d,%d]}', json(activity.party_id), activity.party_size,
		activity.party_max)

	if activity.join_secret then
		parts[#parts + 1] = '"secrets":{"join":' .. json(activity.join_secret) .. "}"
	end

	return "{" .. table.concat(parts, ",") .. "}"
end

--- Secret -> party_id, account_id, or nil.
function build.parse_secret(secret)
	if type(secret) ~= "string" then
		return nil, nil
	end

	local version, party_id, account_id = secret:match("^([^|]+)|([^|]+)|([^|]+)$")

	if version ~= JOIN_VERSION then
		return nil, nil
	end

	return party_id, account_id
end

return build
