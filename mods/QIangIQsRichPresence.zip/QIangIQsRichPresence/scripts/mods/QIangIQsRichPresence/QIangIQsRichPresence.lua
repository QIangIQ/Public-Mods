-- QIangIQsRichPresence
-- Discord Rich Presence with no DLL: talks to the Discord client over its local
-- pipe (rp_pipe.lua). Written after reading TzeentchRichPresence 0.1.1 for how to
-- read the game state; standalone, every other mod is optional (rp_gather.lua).

local mod = get_mod("QIangIQsRichPresence")

local config = mod:io_dofile("QIangIQsRichPresence/scripts/mods/QIangIQsRichPresence/rp_config")
local pipe = mod:io_dofile("QIangIQsRichPresence/scripts/mods/QIangIQsRichPresence/rp_pipe")
local gather = mod:io_dofile("QIangIQsRichPresence/scripts/mods/QIangIQsRichPresence/rp_gather")
local build = mod:io_dofile("QIangIQsRichPresence/scripts/mods/QIangIQsRichPresence/rp_build")

local REFRESH_INTERVAL = 2
local PUMP_INTERVAL = 0.25

local store = mod:persistent_table("qrp")
local lua_os = rawget(_G, "Mods") and Mods.lua and Mods.lua.os or os

store.state = store.state or pipe.new_state()
store.session_start = store.session_start or lua_os.time()
store.nonce = store.nonce or 0

local state = store.state
local ffi_module = rawget(_G, "Mods") and Mods.lua and Mods.lua.ffi
local available, unavailable_reason = pipe.setup(ffi_module)

local pump_elapsed = 0
local refresh_elapsed = REFRESH_INTERVAL

if not available then
	mod:error("Rich presence is off: %s", tostring(unavailable_reason))
end

local function debug_line(message)
	if mod:get("debug_logging") then
		mod:info("%s", tostring(message):gsub("%%", "%%%%"))
	end
end

local function next_nonce()
	store.nonce = store.nonce + 1

	return "qrp" .. store.nonce
end

local function send_activity(activity_json)
	-- A pid is required: Discord clears the activity when that process exits.
	local args = string.format('{"pid":%d', pipe.process_id())

	if activity_json then
		args = args .. ',"activity":' .. activity_json
	end

	return pipe.send(state, string.format('{"cmd":"SET_ACTIVITY","args":%s},"nonce":"%s"}', args, next_nonce()))
end

local function refresh()
	if state.status ~= "ready" then
		return
	end

	local activity = build.activity(gather.snapshot(), store.match_start or store.session_start)

	if not activity then
		return
	end

	local line = tostring(activity.details) .. " | " .. tostring(activity.state)

	if line ~= store.last_line then
		store.last_line = line
		debug_line(line)
	end

	if activity.join_reason ~= store.last_join_reason then
		store.last_join_reason = activity.join_reason
		debug_line("join: " .. tostring(activity.join_reason))
	end

	-- Only send on a change: this runs every 2 seconds and Discord rate limits.
	local json = build.encode(activity)

	if json ~= store.last_json and send_activity(json) then
		store.last_json = json
	end
end

local function accept_join(secret)
	local party_id, account_id = build.parse_secret(secret)
	local social = Managers and Managers.data_service and Managers.data_service.social

	if not party_id or not social then
		mod:echo(mod:localize("join_refused"))

		return
	end

	local called, can_join = pcall(social.local_player_can_join_party, social)

	if called and can_join == false then
		mod:echo(mod:localize("join_refused"))

		return
	end

	local ok, promise = pcall(social.join_party, social, party_id, account_id)

	if not ok then
		mod:echo(mod:localize("join_refused"))
		debug_line("join_party threw: " .. tostring(promise))

		return
	end

	mod:echo(mod:localize("joining"))

	if promise and promise.catch then
		promise:catch(function (reason)
			mod:echo(mod:localize("join_failed"))
			debug_line("join failed: " .. tostring(reason))
		end)
	end
end

local function handle_message(payload)
	local ok, message = pcall(cjson.decode, payload)

	if not ok or type(message) ~= "table" then
		return
	end

	if message.evt == "READY" then
		pipe.mark_ready(state)
		store.last_json = nil
		refresh_elapsed = REFRESH_INTERVAL
		debug_line("Discord ready")
		pipe.send(state, string.format('{"cmd":"SUBSCRIBE","evt":"ACTIVITY_JOIN","nonce":"%s"}', next_nonce()))
	elseif message.evt == "ACTIVITY_JOIN" then
		local data = message.data

		if type(data) == "table" then
			accept_join(data.secret)
		end
	elseif message.evt == "ERROR" then
		-- Not retried: the duplicate check in refresh() is what would resend it,
		-- and the same text would be refused again. Always logged, once per text.
		local data = type(message.data) == "table" and message.data or {}
		local text = tostring(data.message)

		if text ~= store.last_error then
			store.last_error = text
			mod:info("Discord refused a request: %s", text:gsub("%%", "%%%%"))
		end
	end
end

local function pump(dt)
	local messages, notes = pipe.pump(state, dt, config.application_id)

	if notes then
		for _, note in ipairs(notes) do
			debug_line(note)
		end

		if state.status == "closed" then
			store.last_json = nil
		end
	end

	if messages then
		for _, payload in ipairs(messages) do
			handle_message(payload)
		end
	end
end

local function stop()
	if available and state.handle then
		if state.status == "ready" then
			send_activity(nil)
		end

		pipe.close(state, false)
	end

	state.status = "closed"
	state.retry_in = 0
	store.last_json = nil
end

mod:hook_safe(CLASS.StateGameplay, "on_enter", function ()
	store.match_start = lua_os.time()
end)

mod:hook_safe(CLASS.StateGameplay, "on_exit", function ()
	store.match_start = nil
end)

function mod.update(dt)
	-- DMF calls update even while the mod is switched off.
	if not available or not mod:is_enabled() then
		return
	end

	dt = dt or 0
	pump_elapsed = pump_elapsed + dt
	refresh_elapsed = refresh_elapsed + dt

	if pump_elapsed >= PUMP_INTERVAL then
		local elapsed = pump_elapsed

		pump_elapsed = 0

		local ok, reason = pcall(pump, elapsed)

		if not ok and reason ~= store.last_failure then
			store.last_failure = reason
			mod:info("pipe step failed: %s", tostring(reason):gsub("%%", "%%%%"))
		end
	end

	if refresh_elapsed >= REFRESH_INTERVAL then
		refresh_elapsed = 0

		local ok, reason = pcall(refresh)

		if not ok and reason ~= store.last_failure then
			store.last_failure = reason
			mod:info("presence refresh failed: %s", tostring(reason):gsub("%%", "%%%%"))
		end
	end
end

function mod.on_disabled()
	stop()
end

-- on_unload (exit_game), dmf/modules/core/events.lua:23. A hot reload keeps the
-- connection: reopening it would make Discord hold READY for about 30 s.
function mod.on_unload(exit_game)
	if exit_game then
		stop()
	end
end
