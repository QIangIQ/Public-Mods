-- Reads the game and the player's other mods into a plain table. Knows nothing
-- about Discord. Nothing is cached: Managers.state is rebuilt on every game
-- state change, and True Level values can change on /tl_reload.
--
-- Which game calls to use and why comes from reading TzeentchRichPresence 0.1.1
-- (presence/gather.lua); the mod integrations are from the installed mods' code.

local gather = {}

local MAX_PARTY = 4

-- Real mission templates that are not missions, so game mode decides.
local NON_COMBAT_GAME_MODES = {
	hub = true,
	prologue = true,
	prologue_hub = true,
	shooting_range = true,
	training_grounds = true,
}

local function safe(fn, ...)
	if type(fn) ~= "function" then
		return nil
	end

	local ok, value = pcall(fn, ...)

	-- Not `ok and value or nil`: callers test for an explicit false.
	if ok then
		return value
	end

	return nil
end

local function enabled_mod(name)
	local found = get_mod and get_mod(name)

	if found and safe(found.is_enabled, found) then
		return found
	end

	return nil
end

local function state_manager(name)
	local state = Managers and Managers.state

	return state and state[name] or nil
end

local function mechanism_data()
	-- mechanism_data() has no guard and errors between game states.
	local manager = Managers and Managers.mechanism

	if not manager or not manager._mechanism then
		return {}
	end

	return safe(manager.mechanism_data, manager) or {}
end

local function get_mission()
	local manager = state_manager("mission")

	if manager then
		local key = safe(manager.mission_name, manager)
		local template = safe(manager.mission, manager)

		if key and template then
			return key, template.mission_name, template.game_mode_name
		end
	end

	-- Loading screens: the mechanism knows where we are headed.
	local key = mechanism_data().mission_name

	if key then
		local templates = safe(require, "scripts/settings/mission/mission_templates")
		local template = templates and templates[key]

		return key, template and template.mission_name, template and template.game_mode_name
	end

	return nil, nil, nil
end

local function get_difficulty_loc()
	local manager = state_manager("difficulty")
	local index = manager and safe(manager.get_initial_resistance, manager)

	index = tonumber(index or mechanism_data().resistance)

	local settings = safe(require, "scripts/settings/difficulty/danger_settings")
	local danger = index and settings and settings[index]

	return danger and danger.display_name or nil
end

--- The rank is read from the mission's own data and never compared to a limit,
--- so any rank works. QIangIQsUltraHavoc (mission_setup.patch_havoc_data) and
--- HavocAscension write theirs into field 2 of this same data, up to their
--- max_rank setting, and QIangIQsUltraHavoc/scaling.lua reads data.havoc_rank too.
local function get_havoc()
	local manager = state_manager("difficulty")
	local parsed = manager and safe(manager.get_parsed_havoc_data, manager)

	if parsed and parsed.havoc_rank then
		return { rank = parsed.havoc_rank, circumstances = parsed.circumstances or {} }
	end

	-- Before gameplay only the raw string exists:
	-- mission;rank;theme;faction;circumstances;modifiers;challenge;resistance
	local raw = mechanism_data().havoc_data

	if type(raw) ~= "string" or raw == "" then
		return nil
	end

	local fields = {}

	for field in (raw .. ";"):gmatch("(.-);") do
		fields[#fields + 1] = field
	end

	local rank = tonumber(fields[2])

	if not rank then
		return nil
	end

	local circumstances = {}

	for name in (fields[5] or ""):gmatch("[^:]+") do
		circumstances[#circumstances + 1] = name
	end

	return { rank = rank, circumstances = circumstances }
end

local function get_circumstance()
	local manager = state_manager("circumstance")
	local name = manager and safe(manager.circumstance_name, manager)

	return name or mechanism_data().circumstance_name
end

--- true_level: get_true_levels(character_id) returns (levels, is_me). A custom
--- display level replaces current_level and sets additional_level = nil
--- (_with_fake, true_level.lua:93), so it comes through this same read, and
--- /tl_reload shows up on the next refresh because nothing is cached here.
local function get_level(profile)
	local true_level = enabled_mod("true_level")

	if true_level and profile.character_id then
		local ok, levels, is_me = pcall(true_level.get_true_levels, profile.character_id)

		if ok and is_me and type(levels) == "table" and levels.current_level then
			return levels.current_level + (levels.additional_level or 0)
		end
	end

	return profile.current_level
end

--- QIangIQsNovitiate is a Zealot underneath (nov_roster.lua:51), so
--- archetype_name() says "zealot". N.is_novitiate_profile is the mod's own test,
--- and mod.nov is public (QIangIQsNovitiate.lua:29).
local function get_custom_class(profile)
	local novitiate = enabled_mod("QIangIQsNovitiate")
	local helpers = novitiate and novitiate.nov

	if helpers and safe(helpers.is_novitiate_profile, profile) then
		return "novitiate", safe(novitiate.localize, novitiate, "archetype_novitiate")
	end

	return nil, nil
end

--- The equipped title, as the game shows it, without colour. Read through
--- ProfileUtils.character_title_no_color (scripts/utilities/profile_utils.lua) at
--- call time, so QIangIQsCustomTitles' hook on it applies: its locally chosen
--- Carcharodon Gargantua or Atoman Remorae Vanguard (QIangIQsCustomTitles.lua:282-288)
--- comes back here like any real title. Without that mod it is the backend title.
local function get_title(profile)
	local profile_utils = safe(require, "scripts/utilities/profile_utils")

	if not profile_utils then
		return nil
	end

	local title = safe(profile_utils.character_title_no_color, profile)

	if type(title) ~= "string" or title == "" then
		title = safe(profile_utils.character_title, profile)
	end

	return type(title) == "string" and title ~= "" and title or nil
end

local function get_player()
	local manager = Managers and Managers.player

	if not manager then
		return nil
	end

	-- local_player_safe: the unsafe one access-violates during boot, and pcall
	-- cannot catch that (noted in TzeentchRichPresence's gather.lua).
	local player = safe(manager.local_player_safe, manager, 1)
	local profile = player and safe(player.profile, player)

	if not profile or not profile.archetype then
		return nil
	end

	local name = safe(player.name, player)
	local archetype = safe(player.archetype_name, player)

	if not name or not archetype then
		return nil
	end

	local custom_class, custom_class_label = get_custom_class(profile)

	return {
		name = name,
		archetype = archetype,
		custom_class = custom_class,
		custom_class_label = custom_class_label,
		level = get_level(profile),
		title = get_title(profile),
		account_id = safe(player.account_id, player),
	}
end

local function get_party(in_mission)
	local manager = Managers and Managers.presence
	local myself = manager and safe(manager.presence_entry_myself, manager)
	local size = 0

	if myself then
		size = in_mission and safe(myself.num_mission_members, myself) or 0

		if size == 0 then
			size = safe(myself.num_party_members, myself) or 0
		end
	end

	-- The Fatshark party id: Discord groups people who publish the same id, and
	-- it is half of what a joiner needs.
	local immaterium = Managers and Managers.party_immaterium
	local id = immaterium and safe(immaterium.party_id, immaterium)
	local joinable_id = type(id) == "string" and #id >= 2

	if not joinable_id then
		id = mechanism_data().session_id
	end

	return {
		id = type(id) == "string" and #id >= 2 and id or nil,
		joinable_id = joinable_id,
		size = math.min(math.max(size, 1), MAX_PARTY),
		max = MAX_PARTY,
	}
end

--- A Join that cannot work leaves a spinner in the other person's chat which
--- no call can cancel, so advertise only when it can be honoured.
local function get_joinable(solo)
	if solo then
		return false
	end

	local social = Managers and Managers.data_service and Managers.data_service.social

	if social and safe(social.local_player_is_joinable, social) == false then
		return false
	end

	local party = Managers and Managers.party_immaterium

	return not (party and safe(party.is_in_private_session, party) == true)
end

local function get_activity_id()
	local manager = Managers and Managers.presence

	if not manager then
		return nil
	end

	local id = safe(manager.activity_id, manager)

	if id then
		return id
	end

	local myself = safe(manager.presence_entry_myself, manager)

	return myself and safe(myself.activity_id, myself) or nil
end

function gather.snapshot()
	local mission_key, mission_loc, game_mode = get_mission()
	local in_mission = mission_key ~= nil and game_mode ~= nil and not NON_COMBAT_GAME_MODES[game_mode]

	-- These managers hold stale defaults in the hub, so only read them in a mission.
	local difficulty_loc, havoc, circumstance

	if in_mission then
		difficulty_loc = get_difficulty_loc()
		havoc = get_havoc()
		circumstance = get_circumstance()
	end

	local solo_mod = enabled_mod("SoloPlay")
	local solo = solo_mod ~= nil and safe(solo_mod.is_soloplay) == true

	return {
		in_mission = in_mission,
		mission_key = mission_key,
		mission_loc = mission_loc,
		difficulty_loc = difficulty_loc,
		havoc = havoc,
		circumstance = circumstance,
		player = get_player(),
		party = get_party(in_mission),
		activity_id = get_activity_id(),
		solo = solo,
		joinable = get_joinable(solo),
	}
end

return gather
