-- Talks to the running Discord client over its local named pipe, with kernel32
-- calls only, so the mod ships no DLL.
--
-- Protocol from Discord's own discord-rpc source (github.com/discord/discord-rpc):
--   src/connection_win.cpp:35-50  pipe \\?\pipe\discord-ipc-0 to -9, opened with
--                                 GENERIC_READ|GENERIC_WRITE and OPEN_EXISTING
--   src/connection_win.cpp:111    PeekNamedPipe before ReadFile
--   src/rpc_connection.h:17-27    frame = uint32 opcode, uint32 length, payload;
--                                 Handshake 0, Frame 1, Close 2, Ping 3, Pong 4
--   src/rpc_connection.cpp:6,47   handshake {"v":1,"client_id":"..."}
--   src/rpc_connection.cpp:120    Ping is answered with Pong
--
-- This runs on the game thread, so nothing here may wait: no WaitNamedPipe, and
-- ReadFile only for bytes PeekNamedPipe has already reported.

local pipe = {}

local OP_HANDSHAKE, OP_FRAME, OP_CLOSE, OP_PING, OP_PONG = 0, 1, 2, 3, 4
local GENERIC_READ_WRITE = 0xC0000000
local OPEN_EXISTING = 3
local READ_CHUNK = 4096
local MAX_FRAME = 64 * 1024 -- MaxRpcFrameSize, src/rpc_connection.h:8
-- Measured 2026-11-05 with a separate test client: a new connection right after
-- another closes gets READY only after about 30 s. Giving up sooner restarts that
-- wait, so this must be longer. Nothing blocks while waiting.
local HANDSHAKE_TIMEOUT = 45

-- discord-rpc backs off from 0.5 s to 60 s (src/discord_rpc.cpp:72-73). Opening
-- the pipe costs a syscall on the game thread, so this starts higher.
local RETRY_MIN = 5
local RETRY_MAX = 60

local ffi, C, read_buffer, number_buffer

local function u32_bytes(value)
	return string.char(value % 256, math.floor(value / 256) % 256, math.floor(value / 65536) % 256,
		math.floor(value / 16777216) % 256)
end

local function u32_read(data, at)
	local a, b, c, d = data:byte(at, at + 3)

	return a + b * 256 + c * 65536 + d * 16777216
end

--- Binds the FFI. Returns false, reason when it is not available.
--- The asm names are private aliases, so a different declaration of the same
--- Windows function in another mod cannot collide with these. The pcall(typeof)
--- guard is there because ffi.cdef throws on a repeat after a hot reload.
function pipe.setup(ffi_module)
	if not ffi_module then
		return false, "no FFI (Mods.lua.ffi is missing)"
	end

	ffi = ffi_module

	if not pcall(ffi.typeof, "QRP_CDEF_1") then
		local ok, reason = pcall(ffi.cdef, [[
			typedef struct { int unused; } QRP_CDEF_1;
			void* qrp_CreateFileA(const char* name, unsigned long access, unsigned long share,
				void* security, unsigned long disposition, unsigned long flags, void* template_file) __asm__("CreateFileA");
			int qrp_WriteFile(void* file, const char* data, unsigned long size, unsigned long* written,
				void* overlapped) __asm__("WriteFile");
			int qrp_ReadFile(void* file, char* data, unsigned long size, unsigned long* got,
				void* overlapped) __asm__("ReadFile");
			int qrp_PeekNamedPipe(void* file, void* data, unsigned long size, unsigned long* got,
				unsigned long* available, unsigned long* left) __asm__("PeekNamedPipe");
			int qrp_CloseHandle(void* file) __asm__("CloseHandle");
			unsigned long qrp_GetCurrentProcessId(void) __asm__("GetCurrentProcessId");
		]])

		if not ok then
			return false, "ffi.cdef failed: " .. tostring(reason)
		end
	end

	-- ffi.C resolves kernel32 on Windows; ModPerformanceMonitor relies on the
	-- same for QueryPerformanceCounter. No ffi.load at file scope:
	-- Dio's Sorter documents that as what killed another mod.
	local ok, reason = pcall(function ()
		return C or ffi.C.qrp_GetCurrentProcessId()
	end)

	if not ok then
		return false, "kernel32 not reachable: " .. tostring(reason)
	end

	C = ffi.C
	read_buffer = read_buffer or ffi.new("char[?]", READ_CHUNK)
	number_buffer = number_buffer or ffi.new("unsigned long[1]")

	return true
end

function pipe.process_id()
	return C and tonumber(C.qrp_GetCurrentProcessId()) or 0
end

--- state is a table kept in a persistent_table so the handle survives a reload.
function pipe.new_state()
	return { status = "closed", retry_in = 0, retry_delay = RETRY_MIN, inbox = "" }
end

local function is_invalid(handle)
	return handle == nil or tonumber(ffi.cast("intptr_t", handle)) == -1
end

function pipe.close(state, backoff)
	if state.handle then
		C.qrp_CloseHandle(state.handle)
		state.handle = nil
	end

	local was = state.status

	state.status = "closed"
	state.inbox = ""

	if backoff then
		state.retry_in = state.retry_delay
		state.retry_delay = math.min(state.retry_delay * 2, RETRY_MAX)
	end

	return was
end

local function write_frame(state, opcode, payload)
	local frame = u32_bytes(opcode) .. u32_bytes(#payload) .. payload

	number_buffer[0] = 0

	local ok = C.qrp_WriteFile(state.handle, frame, #frame, number_buffer, nil) ~= 0

	return ok and tonumber(number_buffer[0]) == #frame
end

--- Sends one JSON command. Only valid once the connection is ready.
function pipe.send(state, json)
	if state.status ~= "ready" then
		return false
	end

	if not write_frame(state, OP_FRAME, json) then
		pipe.close(state, true)

		return false
	end

	return true
end

local function open(state, application_id)
	for index = 0, 9 do
		local handle = C.qrp_CreateFileA("\\\\?\\pipe\\discord-ipc-" .. index, GENERIC_READ_WRITE, 0, nil,
			OPEN_EXISTING, 0, nil)

		if not is_invalid(handle) then
			state.handle = handle
			state.inbox = ""

			if write_frame(state, OP_HANDSHAKE, '{"v":1,"client_id":"' .. application_id .. '"}') then
				state.status = "handshake"
				state.handshake_age = 0

				return true
			end

			pipe.close(state, false)
		end
	end

	return false
end

local function read_available(state)
	number_buffer[0] = 0

	if C.qrp_PeekNamedPipe(state.handle, nil, 0, nil, number_buffer, nil) == 0 then
		return false
	end

	local available = tonumber(number_buffer[0])

	while available > 0 do
		local want = math.min(available, READ_CHUNK)

		number_buffer[0] = 0

		if C.qrp_ReadFile(state.handle, read_buffer, want, number_buffer, nil) == 0 then
			return false
		end

		local got = tonumber(number_buffer[0])

		if got <= 0 then
			return false
		end

		state.inbox = state.inbox .. ffi.string(read_buffer, got)
		available = available - got
	end

	return true
end

--- Call regularly. Returns an array of decoded message strings, a list of
--- connection notes for the log, or nils. Never blocks.
function pipe.pump(state, dt, application_id)
	local notes

	local function note(message)
		notes = notes or {}
		notes[#notes + 1] = message
	end

	if state.status == "closed" then
		state.retry_in = state.retry_in - dt

		if state.retry_in > 0 then
			return nil, nil
		end

		if not open(state, application_id) then
			state.retry_in = state.retry_delay
			state.retry_delay = math.min(state.retry_delay * 2, RETRY_MAX)

			return nil, nil
		end

		note("pipe opened, handshake sent")
	end

	if not read_available(state) then
		note("pipe lost")
		pipe.close(state, true)

		return nil, notes
	end

	local messages

	while #state.inbox >= 8 do
		local opcode = u32_read(state.inbox, 1)
		local length = u32_read(state.inbox, 5)

		if length > MAX_FRAME then
			note("oversized frame, reconnecting")
			pipe.close(state, true)

			return messages, notes
		end

		if #state.inbox < 8 + length then
			break
		end

		local payload = state.inbox:sub(9, 8 + length)

		state.inbox = state.inbox:sub(9 + length)

		if opcode == OP_FRAME then
			messages = messages or {}
			messages[#messages + 1] = payload
		elseif opcode == OP_PING then
			if not write_frame(state, OP_PONG, payload) then
				note("pong failed")
				pipe.close(state, true)

				return messages, notes
			end
		elseif opcode == OP_CLOSE then
			note("Discord closed the connection: " .. payload)
			pipe.close(state, true)

			return messages, notes
		end
	end

	if state.status == "handshake" then
		state.handshake_age = state.handshake_age + dt

		if state.handshake_age > HANDSHAKE_TIMEOUT then
			note("no READY from Discord")
			pipe.close(state, true)
		end
	end

	return messages, notes
end

--- The caller saw the READY event.
function pipe.mark_ready(state)
	state.status = "ready"
	state.retry_delay = RETRY_MIN
end

return pipe
