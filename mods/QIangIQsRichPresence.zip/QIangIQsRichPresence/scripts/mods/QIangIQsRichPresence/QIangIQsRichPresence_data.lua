local mod = get_mod("QIangIQsRichPresence")

-- Highest rank on the slider. Change this number to go higher.
local HAVOC_SLIDER_MAX = 80

local function checkbox(id, default)
	return { setting_id = id, type = "checkbox", default_value = default, tooltip = id .. "_tooltip" }
end

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			{
				setting_id = "havoc_rank_shown",
				type = "numeric",
				default_value = 0,
				range = { 0, HAVOC_SLIDER_MAX },
				decimals_number = 0,
				step_size_value = 1,
				tooltip = "havoc_rank_shown_tooltip",
			},
			checkbox("show_name", true),
			checkbox("show_level", true),
			checkbox("show_title", true),
			checkbox("show_modifiers", true),
			checkbox("show_solo_tag", true),
			checkbox("offer_join", true),
			checkbox("debug_logging", false),
		},
	},
}
