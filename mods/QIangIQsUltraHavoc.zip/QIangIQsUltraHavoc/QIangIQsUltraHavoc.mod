return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsUltraHavoc` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsUltraHavoc", {
			mod_script       = "QIangIQsUltraHavoc/scripts/mods/QIangIQsUltraHavoc/QIangIQsUltraHavoc",
			mod_data         = "QIangIQsUltraHavoc/scripts/mods/QIangIQsUltraHavoc/QIangIQsUltraHavoc_data",
			mod_localization = "QIangIQsUltraHavoc/scripts/mods/QIangIQsUltraHavoc/QIangIQsUltraHavoc_localization",
		})
	end,
	packages = {},
}
