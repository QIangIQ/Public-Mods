return {
    mod_name = {
        en = "QIangIQ's Ultra Havoc",
        ru = "QIangIQ's Ultra Havoc",
    },
    mod_description = {
        en = "Havoc ranks 41-80 for local and Realms games. Every rank above 40 adds enemy health, upgrades trash into elites, brings more specials and monstrosities, and keeps every vanilla Havoc modifier growing past its rank-40 maximum. Needs Solo Play; the host is the only one who needs this mod.",
        ru = "Ранги Havoc 41-80 для локальных игр и Realms. Каждый ранг выше 40 добавляет врагам здоровье, меняет трэш на элиту и добавляет спецов и боссов. Нужен Solo Play; мод требуется только хосту.",
    },

    -- Options: ranks
    max_rank = {
        en = "Maximum Havoc rank",
        ru = "Максимальный ранг Havoc",
    },
    max_rank_tooltip = {
        en = "Upper end of the Havoc rank slider in the Local Game window. 40 is vanilla; 50 is what this mod was originally balanced around. Ranks 51-80 keep adding the same amount per rank.",
        ru = "Верхняя граница ползунка ранга Havoc в окне Local Game. 40 — ваниль, 50 — то, под что мод сбалансирован.",
    },
    rank_override = {
        en = "Rank override",
        ru = "Принудительный ранг",
    },
    rank_override_tooltip = {
        en = "0 means the Local Game slider decides. Any other value forces that rank on every local Havoc launch, which is the fallback if the slider is still capped at 40.",
        ru = "0 — ранг берётся с ползунка Local Game. Любое другое значение задаёт ранг принудительно — это запасной путь, если ползунок остался ограничен 40.",
    },

    -- Options: scaling
    scaling_group = {
        en = "Scaling per rank above 40",
        ru = "Прирост за каждый ранг выше 40",
    },
    unit_percent_per_rank = {
        en = "%% per rank",
        ru = "%% за ранг",
    },
    hp_per_level = {
        en = "Enemy health",
        ru = "Здоровье врагов",
    },
    hp_per_level_tooltip = {
        en = "Extra health for every enemy, on top of the modifiers the Havoc rank already grants. 2.5 per rank means +25%% health at rank 50 and +100%% at rank 80.",
        ru = "Дополнительное здоровье всем врагам поверх модификаторов самого Havoc. 2.5 за ранг — это +25%% на 50-м.",
    },
    extend_vanilla = {
        en = "Extend vanilla Havoc modifiers past rank 40",
        ru = "Extend vanilla Havoc modifiers past rank 40",
    },
    extend_vanilla_tooltip = {
        en = "Every vanilla Havoc value keeps climbing above rank 40 by its own average tier step: enemy health, monstrosity count, alive specials, elite and ogryn density, horde rate, terror event points, melee power, ammo, and the player toughness, regen, health, vent and enemy attack-speed and permanent-damage buffs.",
        ru = "Every vanilla Havoc value keeps climbing above rank 40 by its own average tier step.",
    },
    ranks_per_step = {
        en = "Ranks per extra vanilla tier",
        ru = "Ranks per extra vanilla tier",
    },
    ranks_per_step_tooltip = {
        en = "How many ranks above 40 add one more vanilla tier step. 5 means 8 extra steps at rank 80; lower is harsher. Growth is continuous, every rank adds a fraction.",
        ru = "How many ranks above 40 add one more vanilla tier step.",
    },
    trash_per_level = {
        en = "Trash upgraded to elites",
        ru = "Меньше трэша",
    },
    trash_per_level_tooltip = {
        en = "Share of trash roamers (riflemen, melee, assault) turned into matching elites. 5 per rank means half of them at rank 50 and all of them from rank 60. Nothing is removed: poxwalkers and hordes keep their full numbers.",
        ru = "Режет рядовых стрелков и ближников в патрулях, орды поксуокеров и прочий мусор. 5 за ранг — вдвое меньше трэша на 50-м. Часть вырезанного идёт не в ноль, а в апгрейд до элиты.",
    },
    elite_per_level = {
        en = "More elites",
        ru = "Больше элиты",
    },
    elite_per_level_tooltip = {
        en = "Gunners, executors, berzerkers and shocktroopers. 5 per rank means +50%% elites at rank 50 and +200%% at rank 80; applied to the elites inside every horde.",
        ru = "Ганнеры, экзекуторы, берсерки, шоктруперы. 5 за ранг — +50%% элиты на 50-м; элита берётся из трэш-спавнов, поэтому общее число врагов не раздувается.",
    },
    special_per_level = {
        en = "More specials",
        ru = "Больше спецов",
    },
    special_per_level_tooltip = {
        en = "Snipers, grenadiers, hounds, trappers, mutants and flamers - the specials pacing timer is shortened by this much. 2.5 per rank means +25%% specials at rank 50 and +75%% at rank 80.",
        ru = "Снайперы, гренадёры, собаки, трапперы, мутанты, огнемётчики — таймер спавна спецов сокращается на эту долю. 2.5 за ранг — +25%% спецов на 50-м.",
    },
    boss_per_level = {
        en = "More monstrosities",
        ru = "Больше боссов",
    },
    boss_per_level_tooltip = {
        en = "Raises both the guaranteed monstrosity count and the chance of the weakened ones that The Emperors Fading Light injects. 1.5 per rank means +15%% at rank 50 and +60%% at rank 80.",
        ru = "Поднимает и гарантированное число монстров, и шанс ослабленных, которых подсыпает The Emperors Fading Light. 1.5 за ранг — +15%% на 50-м.",
    },

    -- Options: conditions
    conditions_group = {
        en = "Extra Havoc conditions",
        ru = "Дополнительные условия Havoc",
    },
    condition_none = {
        en = "None",
        ru = "Нет",
    },
    extra_condition_1 = {
        en = "Extra condition 1",
        ru = "Доп. условие 1",
    },
    extra_condition_2 = {
        en = "Extra condition 2",
        ru = "Доп. условие 2",
    },
    extra_condition_3 = {
        en = "Extra condition 3",
        ru = "Доп. условие 3",
    },
    extra_condition_4 = {
        en = "Extra condition 4",
        ru = "Доп. условие 4",
    },
    extra_condition_tooltip = {
        en = "Adds up to four more conditions to the mission, on top of whatever the Local Game window picked. All of them take effect; four is a hard ceiling only for what the UI can list - the tactical overlay and the lobby have exactly four slots and a fifth entry crashes them for everyone in the session - so a condition that finds no free slot is applied without an icon instead: it affects the mission, it is simply not listed anywhere.",
        ru = "Добавляет к миссии до четырёх условий сверх выбранных в окне Local Game. Работают все; четыре — жёсткий потолок только для показа: в Tab-оверлее и в лобби ровно четыре слота, пятая запись роняет игру у всех в сессии. Поэтому условие, которому не хватило слота, применяется без значка: на миссию влияет, но нигде не показывается.",
    },
    fading_light = {
        en = "The Emperors Fading Light",
        ru = "The Emperors Fading Light",
    },
    fading_light_tooltip = {
        en = "Overrides the difficulty condition the Local Game window picked. Tier III does not exist in the game: it runs tier II and adds the extra scaling levels configured below, plus tighter horde pacing.",
        ru = "Перекрывает difficulty condition, выбранный в окне Local Game. Третьей ступени в игре нет: она запускает вторую и добавляет указанное ниже число уровней прироста плюс более частые орды.",
    },
    fading_light_auto = {
        en = "As set in Local Game",
        ru = "Как в окне Local Game",
    },
    fading_light_1 = {
        en = "I",
        ru = "I",
    },
    fading_light_2 = {
        en = "II",
        ru = "II",
    },
    fading_light_3 = {
        en = "III (modded)",
        ru = "III (от мода)",
    },
    fading_light_levels = {
        en = "Tier III strength",
        ru = "Сила третьей ступени",
    },
    fading_light_levels_tooltip = {
        en = "How many extra ranks worth of scaling tier III is worth. 3 makes rank 40 with tier III roughly as heavy as rank 43 with tier II.",
        ru = "Скольким дополнительным рангам прироста равна третья ступень. 3 — это ранг 40 с третьей ступенью примерно как ранг 43 со второй.",
    },

    -- Options: extra rules
    extras_group = {
        en = "Extra rules",
        ru = "Дополнительные правила",
    },
    remove_bruisers = {
        en = "Remove Scab and Dreg Bruisers",
        ru = "Убрать Scab и Dreg Bruiser",
    },
    remove_bruisers_tooltip = {
        en = "The shield-carrying trash (renegade_vanguard / cultist_vanguard) never spawns; a plain melee enemy of the same faction takes its place, so enemy density stays the same.",
        ru = "Трэш со щитами (renegade_vanguard / cultist_vanguard) не спавнится вообще — вместо него встаёт обычный ближник той же фракции, плотность боя не меняется.",
    },

    -- Options: power outages
    blackout_group = {
        en = "Power outages",
        ru = "Отключения света",
    },
    blackout_enabled = {
        en = "Enable power outages",
        ru = "Включить отключения света",
    },
    blackout_enabled_tooltip = {
        en = "A few times per mission the level's lights go out for a while and toxic gas seeps out of the floor. The gas stops when the lights come back. Works in any local or Realms mission, at any rank.",
        ru = "Несколько раз за миссию свет на уровне гаснет на какое-то время, и из пола начинает идти ядовитый газ. Со светом газ прекращается. Работает в любой локальной миссии и в Realms, на любом ранге.",
    },
    blackout_count_min = {
        en = "Outages per mission: minimum",
        ru = "Отключений за миссию: минимум",
    },
    blackout_count_max = {
        en = "Outages per mission: maximum",
        ru = "Отключений за миссию: максимум",
    },
    blackout_count_tooltip = {
        en = "How many outages a mission rolls. The first one comes 1.5-4 minutes in, the rest are spread 2.5-7 minutes apart.",
        ru = "Сколько отключений выпадает на миссию. Первое — через 1.5–4 минуты после старта, остальные с промежутком 2.5–7 минут.",
    },
    blackout_duration_min = {
        en = "Outage length: minimum",
        ru = "Длительность: минимум",
    },
    blackout_duration_max = {
        en = "Outage length: maximum",
        ru = "Длительность: максимум",
    },
    blackout_duration_tooltip = {
        en = "How long the lights stay out. Each outage rolls a length between these two values.",
        ru = "Сколько держится темнота. Для каждого отключения длительность бросается между этими значениями.",
    },
    blackout_gas = {
        en = "Gas during outages",
        ru = "Газ во время отключений",
    },
    blackout_gas_tooltip = {
        en = "Seeps the same toxic gas the pox gas condition uses, but not tied to the level's gas vents. Turn off for a plain blackout.",
        ru = "Пускает тот же ядовитый газ, что и условие с pox gas, но без привязки к расставленным на карте вентиляциям. Выключить — будет просто темнота.",
    },
    gas_per_wave = {
        en = "Gas patches per wave",
        ru = "Пятен газа за волну",
    },
    gas_per_wave_tooltip = {
        en = "New gas patches seeded around the team every 8 seconds while the lights are out.",
        ru = "Сколько новых пятен газа появляется вокруг команды каждые 8 секунд, пока нет света.",
    },
    gas_limit = {
        en = "Gas patches at once",
        ru = "Пятен газа одновременно",
    },
    gas_limit_tooltip = {
        en = "Upper limit on live gas patches. Gas is drawn per grid cell, so this is the FPS knob - raise it carefully.",
        ru = "Верхний предел живых пятен газа. Газ рисуется по ячейкам сетки, так что это главный рычаг по FPS — поднимать осторожно.",
    },
    gas_patch_size = {
        en = "Gas patch size",
        ru = "Размер пятна газа",
    },
    gas_patch_size_tooltip = {
        en = "Grid cells a single patch may spread over. Vanilla gas clouds use up to 250; this defaults far lower because several patches are alive at once.",
        ru = "Сколько ячеек может занять одно пятно. У ванильных облаков газа до 250; здесь по умолчанию сильно меньше, потому что пятен несколько сразу.",
    },
    unit_seconds = {
        en = "s",
        ru = "с",
    },
    notify_conditions_hidden = {
        en = "Havoc shows 4 conditions at most - %d applied without an icon",
        ru = "Havoc показывает максимум 4 условия — %d работает без значка",
    },
    notify_blackout_start = {
        en = "Power supply failing",
        ru = "Питание пропало",
    },
    notify_blackout_end = {
        en = "Power restored",
        ru = "Питание восстановлено",
    },

    -- Options: misc
    debug_log = {
        en = "Log what the mod changes",
        ru = "Писать в лог, что мод поменял",
    },
    debug_log_tooltip = {
        en = "Writes every horde the mod rescales and the roamer tally to the console log. Use it to tell this mod's doing from another mod's: a spawn with no line here was not touched.",
        ru = "Пишет в лог каждую орду, которую мод пересчитал, и итог по патрулям. Нужно, чтобы отличить работу этого мода от чужой: спавн, по которому строки нет, мод не трогал.",
    },
    announce = {
        en = "Announce on mission start",
        ru = "Сообщать при старте миссии",
    },
    announce_tooltip = {
        en = "Shows a short notification with the rank the mission actually started at.",
        ru = "Короткое уведомление с рангом, на котором реально стартовала миссия.",
    },

    -- Runtime
    notify_active = {
        en = "Havoc rank %s - enemies at +%s%% health",
        ru = "Havoc ранг %s — враги с +%s%% здоровья",
    },
    command_description = {
        en = "show the QIangIQsUltraHavoc scaling for the current or next mission",
        ru = "показать прирост QIangIQsUltraHavoc для текущей или следующей миссии",
    },
    report_rank = {
        en = "QIangIQsUltraHavoc %s: rank %s (%s)",
        ru = "QIangIQsUltraHavoc %s: ранг %s (%s)",
    },
    report_conditions = {
        en = "Conditions: %d of 4 - %s",
        ru = "Условий: %d из 4 — %s",
    },
    report_conditions_over = {
        en = "Conditions: %d, which is over the limit of 4 - the tactical overlay will crash: %s",
        ru = "Условий: %d, это больше предела в 4 — Tab-оверлей упадёт: %s",
    },
    report_source_mission = {
        en = "running mission",
        ru = "текущая миссия",
    },
    report_source_override = {
        en = "rank override",
        ru = "принудительный ранг",
    },
    report_source_slider = {
        en = "Local Game slider",
        ru = "ползунок Local Game",
    },
    expand_map_pool = {
        en = "All maps in the Havoc roll",
        ru = "All maps in the Havoc roll",
    },
    expand_map_pool_tooltip = {
        en = "The random Havoc roll (Solo Play dice / regenerate) picks from every map Solo Play's Havoc mission list offers, not only the game's Havoc maps. A new map rolled with a theme it has no variant for gets no theme. Chat: /ultra_havoc_maps lists the pool.",
        ru = "The random Havoc roll (Solo Play dice / regenerate) picks from every map Solo Play's Havoc mission list offers, not only the game's Havoc maps. A new map rolled with a theme it has no variant for gets no theme. Chat: /ultra_havoc_maps lists the pool.",
    },
    map_pool_operations = {
        en = "Include operation maps",
        ru = "Include operation maps",
    },
    map_pool_operations_tooltip = {
        en = "Adds Rolling Steel (op_train) and No Man's Land (op_no_mans_land) to Solo Play's Havoc mission dropdown and to the Havoc roll. Reopen the Solo Play window after changing. /ultra_havoc_maps shows what the game reports for both.",
        ru = "Adds Rolling Steel (op_train) and No Man's Land (op_no_mans_land) to Solo Play's Havoc mission dropdown and to the Havoc roll. Reopen the Solo Play window after changing. /ultra_havoc_maps shows what the game reports for both.",
    },
    operations_mode_check = {
        en = "Operation maps: require the Havoc game mode",
        ru = "Operation maps: require the Havoc game mode",
    },
    operations_mode_check_tooltip = {
        en = "On: an operation map is only offered if the game runs it in the same game mode as a regular Havoc map. Off: offered anyway. It may fail to load or behave oddly, because the map was not built for Havoc.",
        ru = "On: an operation map is only offered if the game runs it in the same game mode as a regular Havoc map. Off: offered anyway. It may fail to load or behave oddly, because the map was not built for Havoc.",
    },
    operations_intro_release = {
        en = "Operation maps: release the start area",
        ru = "Operation maps: release the start area",
    },
    operations_intro_release_tooltip = {
        en = "Experimental. When you host an operation map (No Man's Land, Rolling Steel) and its intro did not finish 8 seconds after the start, sends the intro's finished signal to the map so the landing Thunderhawk stops blocking the start area. Manual: /ultra_havoc_release_intro",
        ru = "Experimental. When you host an operation map (No Man's Land, Rolling Steel) and its intro did not finish 8 seconds after the start, sends the intro's finished signal to the map so the landing Thunderhawk stops blocking the start area. Manual: /ultra_havoc_release_intro",
    },
    command_release_intro_description = {
        en = "Host: send the intro's finished signal to the map (use if stuck at the start of an operation map)",
        ru = "Host: send the intro's finished signal to the map (use if stuck at the start of an operation map)",
    },
    train_havoc_timer = {
        en = "Rolling Steel: longer Havoc timer",
        ru = "Rolling Steel: longer Havoc timer",
    },
    train_havoc_timer_tooltip = {
        en = "In Havoc, the Rolling Steel locomotive timer uses the minutes below instead of the game's 550 seconds (about 9 minutes). Outside Havoc the game's timer is kept. Set by the host.",
        ru = "In Havoc, the Rolling Steel locomotive timer uses the minutes below instead of the game's 550 seconds (about 9 minutes). Outside Havoc the game's timer is kept. Set by the host.",
    },
    train_havoc_minutes = {
        en = "Rolling Steel Havoc timer (minutes)",
        ru = "Rolling Steel Havoc timer (minutes)",
    },
    train_havoc_minutes_tooltip = {
        en = "Length of the locomotive timer in Havoc. Applies from the next Rolling Steel mission.",
        ru = "Length of the locomotive timer in Havoc. Applies from the next Rolling Steel mission.",
    },
    map_pool_new_only = {
        en = "Roll only maps outside the Havoc list",
        ru = "Roll only maps outside the Havoc list",
    },
    map_pool_new_only_tooltip = {
        en = "With the option above on: roll only maps the game never uses for Havoc (for example No Man's Land or the train mission if they are in the list).",
        ru = "With the option above on: roll only maps the game never uses for Havoc (for example No Man's Land or the train mission if they are in the list).",
    },
    command_hp_description = {
        en = "show what the minions standing in the mission are actually worth",
        ru = "показать фактическое здоровье миньонов в текущей миссии",
    },
    hp_not_hosting = {
        en = "No mission being hosted here - minion health is the host's to answer for.",
        ru = "Миссия здесь не хостится — за здоровье миньонов отвечает хост.",
    },
    hp_nothing_alive = {
        en = "Nothing alive to measure right now.",
        ru = "Сейчас нечего измерять — живых миньонов нет.",
    },
    hp_report = {
        en = "Health, actual/base: %s",
        ru = "Здоровье, факт/база: %s",
    },
    boss_health_percent = {
        en = "Boss health above rank 40 (percent)",
        ru = "Boss health above rank 40 (percent)",
    },
    boss_health_percent_tooltip = {
        en = "Only at Havoc ranks above 40. Health of every enemy with a boss health bar (monstrosities, Daemonhost, captains, the twins) as a percentage of what it would otherwise have. 100 = unchanged, 50 = half, 200 = double. Applies to enemies spawned after the change.",
        ru = "Only at Havoc ranks above 40. Health of every enemy with a boss health bar (monstrosities, Daemonhost, captains, the twins) as a percentage of what it would otherwise have. 100 = unchanged, 50 = half, 200 = double. Applies to enemies spawned after the change.",
    },
    twin_packs = {
        en = "Twin packs",
        ru = "Twin packs",
    },
    twin_packs_tooltip = {
        en = "When the Fading Light condition spawns the twin lieutenants, spawn extra pairs at high ranks. Off: always one pair (2 total).",
        ru = "When the Fading Light condition spawns the twin lieutenants, spawn extra pairs at high ranks. Off: always one pair (2 total).",
    },
    twin_four_rank = {
        en = "Rank for 2 pairs (4 twins)",
        ru = "Rank for 2 pairs (4 twins)",
    },
    twin_four_rank_tooltip = {
        en = "From this Havoc rank on, the twins come as 2 pairs.",
        ru = "From this Havoc rank on, the twins come as 2 pairs.",
    },
    twin_six_rank = {
        en = "Rank for 3 pairs (6 twins)",
        ru = "Rank for 3 pairs (6 twins)",
    },
    twin_six_rank_tooltip = {
        en = "From this Havoc rank on, the twins come as 3 pairs.",
        ru = "From this Havoc rank on, the twins come as 3 pairs.",
    },
    ammo_override = {
        en = "Set ammo from pickups",
        ru = "Set ammo from pickups",
    },
    ammo_override_tooltip = {
        en = "On: ammo pickups give the amount set below, replacing the Havoc ammo reduction. Off: the game's (and this mod's rank) value is used.",
        ru = "On: ammo pickups give the amount set below, replacing the Havoc ammo reduction. Off: the game's (and this mod's rank) value is used.",
    },
    ammo_pickup_percent = {
        en = "Ammo from pickups (percent of normal)",
        ru = "Ammo from pickups (percent of normal)",
    },
    ammo_pickup_percent_tooltip = {
        en = "100 = normal (no Havoc reduction). 50 = half. 0 = pickups give no ammo. 200 = double. Small clips normally give 15 and large clips 50 of your max reserve.",
        ru = "100 = normal (no Havoc reduction). 50 = half. 0 = pickups give no ammo. 200 = double. Small clips normally give 15 and large clips 50 of your max reserve.",
    },
    growth_group = {
        en = "Vanilla modifier growth past rank 40",
    },
    grow_modify_elite_health = {
        en = "Elite health growth",
    },
    grow_modify_elite_health_tooltip = {
        en = "How fast elite health keeps growing past rank 40, as percent of the game's own tier step. 100 = normal, 0 = stays at the rank 40 value, 300 = triple speed. Needs 'Extend vanilla Havoc modifiers past rank 40' on.",
    },
    grow_modify_special_health = {
        en = "Special health growth",
    },
    grow_modify_special_health_tooltip = {
        en = "How fast special health keeps growing past rank 40, as percent of the game's own tier step. 100 = normal, 0 = stays at the rank 40 value, 300 = triple speed. Needs 'Extend vanilla Havoc modifiers past rank 40' on.",
    },
    grow_modify_monster_health = {
        en = "Monstrosity health growth",
    },
    grow_modify_monster_health_tooltip = {
        en = "How fast monstrosity health keeps growing past rank 40, as percent of the game's own tier step. 100 = normal, 0 = stays at the rank 40 value, 300 = triple speed. Needs 'Extend vanilla Havoc modifiers past rank 40' on.",
    },
    grow_add_num_monsters = {
        en = "Extra monstrosities growth",
    },
    grow_add_num_monsters_tooltip = {
        en = "How fast extra monstrosities keeps growing past rank 40, as percent of the game's own tier step. 100 = normal, 0 = stays at the rank 40 value, 300 = triple speed. Needs 'Extend vanilla Havoc modifiers past rank 40' on.",
    },
    grow_modify_horde_health = {
        en = "Horde health growth",
    },
    grow_modify_horde_health_tooltip = {
        en = "How fast horde health keeps growing past rank 40, as percent of the game's own tier step. 100 = normal, 0 = stays at the rank 40 value, 300 = triple speed. Needs 'Extend vanilla Havoc modifiers past rank 40' on.",
    },
    grow_modify_horde_hit_mass = {
        en = "Horde hit mass growth",
    },
    grow_modify_horde_hit_mass_tooltip = {
        en = "How fast horde hit mass keeps growing past rank 40, as percent of the game's own tier step. 100 = normal, 0 = stays at the rank 40 value, 300 = triple speed. Needs 'Extend vanilla Havoc modifiers past rank 40' on.",
    },
    grow_add_max_alive_specials = {
        en = "Max specials alive growth",
    },
    grow_add_max_alive_specials_tooltip = {
        en = "How fast max specials alive keeps growing past rank 40, as percent of the game's own tier step. 100 = normal, 0 = stays at the rank 40 value, 300 = triple speed. Needs 'Extend vanilla Havoc modifiers past rank 40' on.",
    },
    grow_add_more_elites = {
        en = "More elites growth",
    },
    grow_add_more_elites_tooltip = {
        en = "How fast more elites keeps growing past rank 40, as percent of the game's own tier step. 100 = normal, 0 = stays at the rank 40 value, 300 = triple speed. Needs 'Extend vanilla Havoc modifiers past rank 40' on.",
    },
    grow_add_more_ogryns = {
        en = "More ogryns growth",
    },
    grow_add_more_ogryns_tooltip = {
        en = "How fast more ogryns keeps growing past rank 40, as percent of the game's own tier step. 100 = normal, 0 = stays at the rank 40 value, 300 = triple speed. Needs 'Extend vanilla Havoc modifiers past rank 40' on.",
    },
    grow_ammo_pickup_modifier = {
        en = "Ammo pickup reduction growth",
    },
    grow_ammo_pickup_modifier_tooltip = {
        en = "How fast ammo pickup reduction keeps growing past rank 40, as percent of the game's own tier step. 100 = normal, 0 = stays at the rank 40 value, 300 = triple speed. Needs 'Extend vanilla Havoc modifiers past rank 40' on.",
    },
    grow_horde_spawn_rate_modifier = {
        en = "Horde spawn rate growth",
    },
    grow_horde_spawn_rate_modifier_tooltip = {
        en = "How fast horde spawn rate keeps growing past rank 40, as percent of the game's own tier step. 100 = normal, 0 = stays at the rank 40 value, 300 = triple speed. Needs 'Extend vanilla Havoc modifiers past rank 40' on.",
    },
    grow_terror_event_point_modifier = {
        en = "Terror event strength growth",
    },
    grow_terror_event_point_modifier_tooltip = {
        en = "How fast terror event strength keeps growing past rank 40, as percent of the game's own tier step. 100 = normal, 0 = stays at the rank 40 value, 300 = triple speed. Needs 'Extend vanilla Havoc modifiers past rank 40' on.",
    },
    grow_melee_minion_power_level_modifier = {
        en = "Enemy melee power growth",
    },
    grow_melee_minion_power_level_modifier_tooltip = {
        en = "How fast enemy melee power keeps growing past rank 40, as percent of the game's own tier step. 100 = normal, 0 = stays at the rank 40 value, 300 = triple speed. Needs 'Extend vanilla Havoc modifiers past rank 40' on.",
    },
    grow_melee_attack_speed = {
        en = "Enemy melee attack speed growth",
    },
    grow_melee_attack_speed_tooltip = {
        en = "How fast enemy melee attack speed keeps growing past rank 40, as percent of the game's own tier step. 100 = normal, 0 = stays at the rank 40 value, 300 = triple speed. Needs 'Extend vanilla Havoc modifiers past rank 40' on.",
    },
    grow_ranged_attack_speed = {
        en = "Enemy ranged attack speed and shots growth",
    },
    grow_ranged_attack_speed_tooltip = {
        en = "How fast enemy ranged attack speed and shots keeps growing past rank 40, as percent of the game's own tier step. 100 = normal, 0 = stays at the rank 40 value, 300 = triple speed. Needs 'Extend vanilla Havoc modifiers past rank 40' on.",
    },
    grow_melee_permanent_damage = {
        en = "Permanent damage from melee growth",
    },
    grow_melee_permanent_damage_tooltip = {
        en = "How fast permanent damage from melee keeps growing past rank 40, as percent of the game's own tier step. 100 = normal, 0 = stays at the rank 40 value, 300 = triple speed. Needs 'Extend vanilla Havoc modifiers past rank 40' on.",
    },
    grow_toughness = {
        en = "Player toughness reduction growth",
    },
    grow_toughness_tooltip = {
        en = "How fast player toughness reduction keeps growing past rank 40, as percent of the game's own tier step. 100 = normal, 0 = stays at the rank 40 value, 300 = triple speed. Needs 'Extend vanilla Havoc modifiers past rank 40' on.",
    },
    grow_toughness_regen = {
        en = "Player toughness regen reduction growth",
    },
    grow_toughness_regen_tooltip = {
        en = "How fast player toughness regen reduction keeps growing past rank 40, as percent of the game's own tier step. 100 = normal, 0 = stays at the rank 40 value, 300 = triple speed. Needs 'Extend vanilla Havoc modifiers past rank 40' on.",
    },
    grow_max_health = {
        en = "Player max health reduction growth",
    },
    grow_max_health_tooltip = {
        en = "How fast player max health reduction keeps growing past rank 40, as percent of the game's own tier step. 100 = normal, 0 = stays at the rank 40 value, 300 = triple speed. Needs 'Extend vanilla Havoc modifiers past rank 40' on.",
    },
    grow_vent_speed = {
        en = "Peril build-up speed growth",
    },
    grow_vent_speed_tooltip = {
        en = "How fast peril build-up speed keeps growing past rank 40, as percent of the game's own tier step. 100 = normal, 0 = stays at the rank 40 value, 300 = triple speed. Needs 'Extend vanilla Havoc modifiers past rank 40' on.",
    },
    limits_group = {
        en = "Safety limits",
    },
    limit_ammo_floor = {
        en = "Lowest ammo pickup value (percent)",
    },
    limit_ammo_floor_tooltip = {
        en = "Ammo pickups never drop below this share of normal from rank scaling. 5 = the previous fixed limit. 0 lets pickups reach zero.",
    },
    limit_toughness = {
        en = "Most toughness removed",
    },
    limit_toughness_tooltip = {
        en = "Largest toughness reduction the rank scaling can reach. 90 = the previous fixed limit. 100 can remove all base toughness of some classes.",
    },
    limit_toughness_regen = {
        en = "Most toughness regen removed (percent)",
    },
    limit_toughness_regen_tooltip = {
        en = "Largest toughness regen reduction. 100 = no regen at all (previous limit).",
    },
    limit_max_health = {
        en = "Most max health removed (percent)",
    },
    limit_max_health_tooltip = {
        en = "Largest max health reduction. 90 = keep 10 percent max health (previous limit).",
    },
    limit_permanent_damage = {
        en = "Highest permanent damage share (percent)",
    },
    limit_permanent_damage_tooltip = {
        en = "Largest share of melee damage that becomes permanent. 100 = all of it (previous limit).",
    },
    fl3_horde_travel_distance = {
        en = "Tier III horde spacing",
    },
    fl3_horde_travel_distance_tooltip = {
        en = "With Fading Light III: how far (meters) the team must travel before the next horde may come. 30 = previous value. Lower = more hordes.",
    },
    twin_pairs_mid = {
        en = "Pairs at the first rank",
    },
    twin_pairs_mid_tooltip = {
        en = "How many twin pairs spawn from 'Rank for 2 pairs' on.",
    },
    twin_pairs_high = {
        en = "Pairs at the second rank",
    },
    twin_pairs_high_tooltip = {
        en = "How many twin pairs spawn from 'Rank for 3 pairs' on.",
    },
    ammo_small_clip_percent = {
        en = "Small clip (percent)",
    },
    ammo_small_clip_percent_tooltip = {
        en = "Extra multiplier for small ammo clips only. 100 = no change.",
    },
    ammo_large_clip_percent = {
        en = "Large clip (percent)",
    },
    ammo_large_clip_percent_tooltip = {
        en = "Extra multiplier for large ammo clips only. 100 = no change.",
    },
    ammo_crate_percent = {
        en = "Ammo crate (percent)",
    },
    ammo_crate_percent_tooltip = {
        en = "Extra multiplier for deployed ammo crates only. 100 = no change; above 100 still fills to full at most.",
    },
    blackout_first_min = {
        en = "First outage earliest (seconds)",
    },
    blackout_first_min_tooltip = {
        en = "Earliest time after mission start for the first outage. Previous value 90.",
    },
    blackout_first_max = {
        en = "First outage latest (seconds)",
    },
    blackout_first_max_tooltip = {
        en = "Latest time after mission start for the first outage. Previous value 240.",
    },
    blackout_gap_min = {
        en = "Gap between outages, shortest (seconds)",
    },
    blackout_gap_min_tooltip = {
        en = "Previous value 150.",
    },
    blackout_gap_max = {
        en = "Gap between outages, longest (seconds)",
    },
    blackout_gap_max_tooltip = {
        en = "Previous value 420.",
    },
    gas_wave_interval = {
        en = "Seconds between gas waves",
    },
    gas_wave_interval_tooltip = {
        en = "During an outage with gas on. Previous value 8.",
    },
    gas_distance_min = {
        en = "Gas closest distance (meters)",
    },
    gas_distance_min_tooltip = {
        en = "Previous value 5.",
    },
    gas_distance_max = {
        en = "Gas farthest distance (meters)",
    },
    gas_distance_max_tooltip = {
        en = "Previous value 18.",
    },
    blackout_lights_per_frame = {
        en = "Lights switched per frame",
    },
    blackout_lights_per_frame_tooltip = {
        en = "How fast the lights go out and come back. Higher is faster but heavier on the host. Previous value 25.",
    },
    pacing_enemy_cap = {
        en = "Game enemy cap",
    },
    pacing_enemy_cap_tooltip = {
        en = "The game stops spawning hordes, roamers, specials and monstrosities while more than this many enemies exist. 145 = the game's own limit (no change). Higher allows bigger fights but costs performance; clients also have to handle every enemy.",
    },
    report_inactive = {
        en = "No extra scaling: this is a stock Havoc rank.",
        ru = "Прироста нет: это обычный ранг Havoc.",
    },
    report_factors = {
        en = "+%d%% health, %d%% trash upgraded, +%d%% horde elites, +%d%% specials, +%d%% monstrosities",
        ru = "+%d%% здоровья, -%d%% трэша, +%d%% элиты, +%d%% спецов, +%d%% боссов",
    },
}
