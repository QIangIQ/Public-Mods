local mod = get_mod("QIangIQsUltraHavoc")

-- --------------------------------------------------------------------------
-- Rolling Steel (op_train): longer locomotive timer in Havoc
-- --------------------------------------------------------------------------
--
-- The run-wide timer is objective_flash_train_reach_locomotive, a "timed"
-- objective with duration_by_difficulty = { 825, 770, 660, 583, 550 }
-- (op_train_objective_template.lua:6-24). MissionObjectiveTimed._get_duration
-- picks the entry for Managers.state.difficulty:get_initial_challenge()
-- (mission_objective_timed.lua:18-36); Solo Play's Havoc runs at challenge 5
-- from rank 21 up, so Havoc gets 550 s (about 9 minutes).
-- Objective names come from the template keys (mission_objective_templates.lua:13-14).
--
-- In Havoc only, that one objective gets the slider's minutes instead. Every
-- other objective, and Rolling Steel outside Havoc, keeps the game's value.
-- The host's timer is the one that ends the run; a client without this mod
-- may show the game's own duration in the timer text.

local MissionObjectiveTimed = require("scripts/extension_systems/mission_objective/utilities/mission_objective_timed")

local TRAIN_TIMER = "objective_flash_train_reach_locomotive"
local DEFAULT_MINUTES = 30

local function in_havoc()
	local difficulty = Managers.state and Managers.state.difficulty

	if not difficulty or not difficulty.get_parsed_havoc_data then
		return false
	end

	local ok, data = pcall(difficulty.get_parsed_havoc_data, difficulty)

	return ok and data ~= nil
end

mod:hook(MissionObjectiveTimed, "_get_duration", function (func, self, mission_objective_data)
	local duration = func(self, mission_objective_data)

	if type(mission_objective_data) ~= "table" or mission_objective_data.name ~= TRAIN_TIMER then
		return duration
	end

	if mod:get("train_havoc_timer") == false or not in_havoc() then
		return duration
	end

	local minutes = tonumber(mod:get("train_havoc_minutes")) or DEFAULT_MINUTES
	local seconds = math.max(60, minutes * 60)

	mod:info("Rolling Steel Havoc timer: %d s (game: %s s)", seconds, tostring(duration))

	return seconds
end)
