local mod = get_mod("QIangIQsUltraHavoc")
local scaling = mod.scaling

local GameModeExtensionHavoc = require("scripts/managers/game_mode/game_mode_extensions/game_mode_extension_havoc")
local HordeManager = require("scripts/managers/horde/horde_manager")
local PacingManager = require("scripts/managers/pacing/pacing_manager")
local RoamerPacing = require("scripts/managers/pacing/roamer_pacing/roamer_pacing")
local SpecialsPacing = require("scripts/managers/pacing/specials_pacing/specials_pacing")

local run = scaling.run

-- Every manager hooked here (pacing, hordes, minion spawning) is created only
-- when `is_server` is true in gameplay_init_step_managers.lua, so these hooks
-- never run on a Realms client - only the host reshapes the mission.

-- --------------------------------------------------------------------------
-- Enemy health
-- --------------------------------------------------------------------------

-- The vanilla implementation only answers for elites, specials, monsters and
-- horde breeds; the extra rank bonus applies to every minion, roamers included.
--
-- Ported from HavocAscension 2 (spawn_scaling.lua:22-47, author Huesos):
-- What comes back here is a share, not a multiplier: MinionSpawnManager turns
-- it into one by adding it to 1, and every vanilla Havoc modifier is summed the
-- same way. Adding this mod's share alongside them would measure the bonus
-- against BASE health - an elite already carrying vanilla's +50% would gain a
-- sixth rather than a quarter. So the rank builds on what the vanilla modifiers
-- leave standing: the two shares multiply rather than add. A Mauler at 3700
-- base with +50% is 5550 at rank 40 and 6937 at rank 50. Trash reads the same
-- either way, because vanilla gives it nothing to build on.
-- One case is approximate (HavocAscension's note): a caller may pass its own
-- health modifier in (specials pacing does for weakened monstrosities) and the
-- game adds that on top, so those few spawns end up slightly above.
--
-- Boss health slider (local edit): above rank 40 only, every breed with a boss
-- health bar - breed.boss_display_name, set on monstrosities (beast of Nurgle,
-- Daemonhost, ...), captains and the twins (e.g. chaos_beast_of_nurgle_breed.lua:83,
-- renegade_captain_breed.lua:79, renegade_twin_captain_breed.lua:81) - gets its
-- final share multiplied by boss_health_percent / 100. 100 = unchanged.
local function boss_multiplier(breed, factors)
    if not factors or not factors.active or type(breed) ~= "table" or breed.boss_display_name == nil then
        return 1
    end

    local percent = tonumber(mod:get("boss_health_percent")) or 100

    return math.max(percent, 1) / 100
end

mod:hook(GameModeExtensionHavoc, "get_minion_health_modifier", function (func, self, breed)
    local base = func(self, breed)
    local factors = scaling.factors()
    local boss = boss_multiplier(breed, factors)

    if (not factors or factors.hp <= 0) and boss == 1 then
        return base
    end

    local hp = factors and factors.hp > 0 and factors.hp or 0

    return (1 + (base or 0)) * (1 + hp) * boss - 1
end)

-- --------------------------------------------------------------------------
-- Monstrosities
-- --------------------------------------------------------------------------

-- MonsterPacing reads `add_num_monsters` once while generating the mission's
-- monster spawns, so adding to it here is the whole "more bosses" knob for
-- full-strength monstrosities.
local vanilla_extension = mod.vanilla_extension

local function mission_rank(extension_self)
    local rank = extension_self and extension_self._current_rank

    if rank == nil then
        local difficulty = Managers.state and Managers.state.difficulty
        local data = difficulty and difficulty:get_parsed_havoc_data()

        rank = data and data.havoc_rank
    end

    return tonumber(rank)
end

mod:hook(GameModeExtensionHavoc, "get_modifier_value", function (func, self, name)
    local value = func(self, name)

    -- Local edit: every numeric vanilla modifier keeps climbing past rank 40.
    local rank = mission_rank(self)

    if rank then
        value = vanilla_extension.numeric(name, value, rank)
    end

    if name ~= "add_num_monsters" then
        return value
    end

    local factors = scaling.factors()
    if not factors or factors.boss_up <= 0 then
        return value
    end

    local bonus = scaling.monster_bonus(value, factors)
    if bonus <= 0 then
        return value
    end

    return (value or 0) + bonus
end)

-- The weakened monstrosities that "The Emperors Fading Light" injects through
-- the specials pacing roll their own spawn chance; scale that chance instead of
-- the count. The config table is shared game settings data, so it is cloned.
mod:hook(SpecialsPacing, "set_monster_spawn_config", function (func, self, monster_spawn_config)
    local factors = scaling.factors()

    if factors and factors.boss_up > 0 and type(monster_spawn_config) == "table" then
        local scaled = table.clone(monster_spawn_config)
        local multiplier = 1 + factors.boss_up

        if type(scaled.chance_to_spawn_monster) == "number" then
            scaled.chance_to_spawn_monster = math.min(scaled.chance_to_spawn_monster * multiplier, 1)
        end

        if type(scaled.chance_to_spawn_monster_event) == "number" then
            scaled.chance_to_spawn_monster_event = math.min(scaled.chance_to_spawn_monster_event * multiplier, 1)
        end

        monster_spawn_config = scaled
    end

    return func(self, monster_spawn_config)
end)

-- --------------------------------------------------------------------------
-- Specials
-- --------------------------------------------------------------------------

-- Every specials slot gets its timer through this one function, both on setup
-- and on every respawn, so shortening the timer here raises the number of
-- specials a mission produces by the same proportion.
mod:hook(SpecialsPacing, "_setup_specials_slot", function (func, self, specials_slots, specials_slot, template, timer_modifier, ...)
    local factors = scaling.factors()

    if factors and factors.special_up > 0 and type(timer_modifier) == "number" then
        timer_modifier = timer_modifier / (1 + factors.special_up)
    end

    return func(self, specials_slots, specials_slot, template, timer_modifier, ...)
end)

-- --------------------------------------------------------------------------
-- Roamers
-- --------------------------------------------------------------------------

--- What a roamer slot ends up as after the vanilla limit pass.
-- @param breed_name string breed the pack asked for
-- @param replaced string|table|nil|false vanilla replacement result
-- @param faction string|nil zone faction
-- @return string|nil class of the breed that will actually spawn
local function final_class(breed_name, replaced, faction)
    if type(replaced) == "string" then
        return scaling.classify(replaced)
    end

    if type(replaced) == "table" then
        local by_faction = replaced[faction] or replaced.renegade or replaced.cultist
        return by_faction and scaling.classify(by_faction[1]) or nil
    end

    return scaling.classify(breed_name)
end

-- Roamer packs are the bulk of both the trash and the elites in a mission, and
-- this is the one function the generator asks before it commits a slot. It can
-- answer three ways, all of which are reused here: keep the breed (nil), swap it
-- (breed name) or drop the slot entirely (false, true).
--
-- Instead of rolling dice per roamer, the two targets are tracked as debts:
-- every trash roamer adds `trash_cut` to the trash debt, every elite roamer adds
-- `elite_up` to the elite debt, and a whole unit of debt is paid off by removing
-- or upgrading one trash roamer. Over a mission that lands on exactly the
-- requested percentages rather than near them, and a promotion pays off both
-- debts at once because it removes a trash unit and adds an elite one.
mod:hook(RoamerPacing, "_limit_roamer_breeds", function (func, self, breed_name, limit_settings, faction, tag_limits)
    local factors = scaling.factors()

    if not factors then
        return func(self, breed_name, limit_settings, faction, tag_limits)
    end

    -- Local edit ("impossible" mode): nothing is ever removed. trash_cut is now
    -- the share of trash roamers promoted into elites; a trash breed without a
    -- promotion (poxwalkers) simply stays. The debt keeps the share exact over
    -- a mission, as in the original.
    if scaling.classify(breed_name) == "trash" then
        run.trash_debt = run.trash_debt + factors.trash_cut

        if run.trash_debt >= 1 then
            run.trash_debt = run.trash_debt - 1

            local promoted = scaling.promote(breed_name, faction)

            if promoted then
                run.promoted = run.promoted + 1

                return promoted
            end
        end
    end

    local replaced, should_skip_roamer = func(self, breed_name, limit_settings, faction, tag_limits)

    return replaced, should_skip_roamer
end)

-- --------------------------------------------------------------------------
-- Hordes
-- --------------------------------------------------------------------------

local SCALE_BY_CLASS = {
    -- Local edit: horde trash is no longer cut; hordes only gain elites and specials.
    elite = function (factors) return 1 + factors.elite_up end,
    special = function (factors) return 1 + factors.special_up end,
}

--- Scale one `{min, max}` amount, keeping the average at `amount * scale`.
-- @param amount table
-- @param scale number
-- @return table
local function scale_amount(amount, scale)
    local low = scaling.probabilistic_round((amount[1] or 0) * scale)
    local high = scaling.probabilistic_round((amount[2] or amount[1] or 0) * scale)

    if high < low then
        high = low
    end

    return { low, high }
end

--- Copy a horde composition with per-class amounts scaled.
-- @param composition table `{ breeds = { { name, amount = { min, max } }, ... } }`
-- @param factors table
-- @return table composition to spawn (the original when nothing changes)
local function scale_composition(composition, factors)
    local breeds = type(composition) == "table" and composition.breeds
    if type(breeds) ~= "table" then
        return composition
    end

    local scaled_breeds, changed = {}, false

    for i = 1, #breeds do
        local breed_data = breeds[i]
        local scale_function = SCALE_BY_CLASS[scaling.classify(breed_data.name)]
        local scale = scale_function and scale_function(factors)

        if scale and scale ~= 1 and type(breed_data.amount) == "table" then
            local copy = table.clone(breed_data)
            copy.amount = scale_amount(breed_data.amount, scale)
            scaled_breeds[i] = copy
            changed = true
        else
            scaled_breeds[i] = breed_data
        end
    end

    if not changed then
        return composition
    end

    -- Opt-in, because this fires on every horde in the mission. It is the
    -- answer to "did the mod touch this spawn": no line, no change.
    if mod:get("debug_log") then
        local changes = {}

        for i = 1, #breeds do
            local before, after = breeds[i].amount, scaled_breeds[i].amount

            if after ~= before then
                changes[#changes + 1] = string.format("%s %s-%s to %s-%s", tostring(breeds[i].name),
                    tostring(before[1]), tostring(before[2] or before[1]), tostring(after[1]), tostring(after[2]))
            end
        end

        if #changes > 0 then
            mod:info("Horde rescaled: %s", table.concat(changes, ", "))
        end
    end

    local scaled = table.clone(composition)
    scaled.breeds = scaled_breeds

    return scaled
end

-- Single choke point for every horde in the game: pacing hordes, trickle
-- hordes, coordinated strikes, roamer-triggered hordes and terror event hordes
-- all go through HordeManager.horde with a resolved composition.
mod:hook(HordeManager, "horde", function (func, self, horde_type, horde_template_name, side_id, target_side_id, composition, ...)
    local factors = scaling.factors()

    if factors then
        composition = scale_composition(composition, factors)
    end

    return func(self, horde_type, horde_template_name, side_id, target_side_id, composition, ...)
end)

-- --------------------------------------------------------------------------
-- Mission start
-- --------------------------------------------------------------------------

-- Local edit: raise the vanilla tier buffs before any player or minion gets
-- them. on_gameplay_init is where the Havoc extension reads its data and
-- registers the spawn callbacks that add these buffs.
mod:hook(GameModeExtensionHavoc, "on_gameplay_init", function (func, self, ...)
    local difficulty = Managers.state and Managers.state.difficulty
    local data = difficulty and difficulty:get_parsed_havoc_data()
    local rank = data and tonumber(data.havoc_rank)

    if rank then
        vanilla_extension.apply_buffs(rank)
    else
        vanilla_extension.restore_buffs()
    end

    return func(self, ...)
end)

-- Runs once per mission on the host, after the pacing template has been set up
-- and before spawn points are generated.
mod:hook_safe(PacingManager, "on_gameplay_post_init", function (self, level_name)
    local factors = scaling.factors()

    if not factors then
        return
    end

    if mod:get("fading_light") == "3" and type(self.add_pacing_modifiers) == "function" then
        -- Same knob "havoc_mutator_more_hordes_02" uses: hordes stop waiting for
        -- the team to cover ground before the next one is allowed.
        self:add_pacing_modifiers({
            required_horde_travel_distance = mod:get("fl3_horde_travel_distance") or 30,
        })
    end

    if mod:get("announce") then
        local rank = run.data and run.data.havoc_rank or "?"
        mod:notify("%s", mod:localize("notify_active", tostring(rank), tostring(math.round(factors.hp * 100))))
    end

    -- Roamers are generated inside the call we just let through, so the tally
    -- is final by now.
    if mod:get("debug_log") then
        mod:info("Roamers: %d trash upgraded to elites", run.promoted)
    end
end)
