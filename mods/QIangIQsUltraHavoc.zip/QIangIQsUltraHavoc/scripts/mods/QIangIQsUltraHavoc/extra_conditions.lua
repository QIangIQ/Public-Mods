local mod = get_mod("QIangIQsUltraHavoc")

local CircumstanceTemplates = require("scripts/settings/circumstance/circumstance_templates")
local MutatorManager = require("scripts/managers/mutator/mutator_manager")

local extra_conditions = {}

-- A Havoc mission can carry four conditions and no more: both UIs that list
-- them are built from four widget slots (see mission_setup). Conditions that do
-- not fit are not thrown away - their mutators are loaded straight into the
-- mission instead, so the condition is in play, it just has no icon anywhere.
--
-- That works because a circumstance's mutators do not need the circumstance:
-- MutatorManager._load_mutators only constructs them, and nothing activates
-- them afterwards (no Havoc mutator template sets activate_on_load). Their
-- effect comes from init - MutatorMinionNurgleBlessing and MutatorModifyPacing
-- push their settings into the pacing manager there - and from the spawn
-- callbacks, which MutatorManager forwards to every loaded mutator regardless
-- of whether it is active.
--
-- Loading happens on the host only. Everything these mutators do to gameplay is
-- server side (buffs the server puts on minions, pacing, breed replacement) and
-- replicates normally; a purely cosmetic mutator like the rotten armour visual
-- override would only dress up the host's minions, which is the one thing a
-- Realms guest can end up seeing differently.

local pending = {}

--- Remember conditions that did not fit the mission's four slots.
-- @param names table list of circumstance names
function extra_conditions.remember(names)
    pending = {}

    for i = 1, #names do
        pending[i] = names[i]
    end
end

--- @return table the conditions waiting to be applied (for tests and reports)
function extra_conditions.pending()
    return pending
end

--- Load one circumstance's mutators into the running mission.
-- @param mutator_manager table
-- @param name string circumstance name
-- @param level userdata|nil
-- @param themes table|nil
-- @return boolean whether anything was loaded
local function apply_condition(mutator_manager, name, level, themes)
    local template = CircumstanceTemplates[name]
    local mutators = template and template.mutators

    if type(mutators) ~= "table" then
        mod:warning("Condition %q has no mutators to apply", tostring(name))

        return false
    end

    local applied = false

    for i = 1, #mutators do
        local mutator_name = mutators[i]
        local ok, mutator = pcall(mutator_manager.load_mutator_from_name, mutator_manager, mutator_name)

        if not ok then
            mod:error("Could not load mutator %q: %s", tostring(mutator_name), tostring(mutator))
        elseif mutator then
            applied = true

            -- The manager already walked its own list by the time we get here,
            -- so the fresh mutator has to be told about post init itself -
            -- MutatorModifyPacing does its work in exactly that callback.
            pcall(mutator.on_gameplay_post_init, mutator, level, themes)
        end
    end

    return applied
end

-- Runs once per mission, after the mutators the mission came with are built and
-- before spawn points are generated, so a mutator loaded here still receives
-- on_spawn_points_generated from the manager's own pass.
mod:hook_safe(MutatorManager, "on_gameplay_post_init", function (self, level, themes)
    if #pending == 0 then
        return
    end

    local waiting = pending

    pending = {}

    if not self._is_server then
        return
    end

    local difficulty_manager = Managers.state and Managers.state.difficulty

    if not difficulty_manager or not difficulty_manager:get_parsed_havoc_data() then
        return
    end

    local applied = {}

    for i = 1, #waiting do
        if apply_condition(self, waiting[i], level, themes) then
            applied[#applied + 1] = waiting[i]
        end
    end

    if #applied > 0 then
        mod:info("Applied %d condition(s) without a UI slot: %s", #applied, table.concat(applied, ", "))
    end
end)

return extra_conditions
