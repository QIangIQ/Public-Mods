local mod = get_mod("QIangIQsUltraHavoc")

-- --------------------------------------------------------------------------
-- Spawner mutators on maps without spawn-point data
-- --------------------------------------------------------------------------
--
-- Two Havoc mutators place their enemies at prebaked, per-map points:
--   mutator_monster_spawner     chaos rituals   (havoc_circumstance_template.lua:171,
--                                                havoc_mutator_local_settings.lua:527-531)
--   mutator_monster_havoc_twins Fading Light twins (havoc_circumstance_template.lua:204, 227,
--                                                havoc_mutator_local_settings.lua:569-573)
-- Both use MutatorSpawnerLocationSources.prebaked_mission_locations(), which
-- reads MutatorMonsterSpawnerSettings.default_locations[mission]. That table
-- (mutator_monster_spawner_settings.lua:5) only lists the regular Havoc maps.
-- On any other map (No Man's Land, Rolling Steel) the lookup is nil and the
-- game raises "No spawn points defined in MutatorMonsterSpawnerSettings for
-- category default_locations in mission op_no_mans_land" while the mission
-- loads (crash log 2026-09-27 06:52).
--
-- Fix: while MutatorManager loads its mutators on such a map, these two names
-- resolve to a no-op marker on the base mutator class - the same shape as
-- mutator_single_twin (mutator_modify_pacing_templates.lua:724-726) and the
-- Warp rift marker in QIangIQsCustomModifierOne. The real templates are put
-- back right after, so every other map is untouched. The map simply has no
-- rituals and no twins.

local MutatorManager = require("scripts/managers/mutator/mutator_manager")
local MutatorTemplates = require("scripts/settings/mutator/mutator_templates")
local MutatorMonsterSpawnerSettings = require("scripts/settings/mutator/mutator_monster_spawner_settings")

local PREBAKED_MUTATORS = {
	"mutator_monster_spawner",
	"mutator_monster_havoc_twins",
}

local function mission_name()
	local mission_manager = Managers.state and Managers.state.mission

	if not mission_manager or not mission_manager.mission_name then
		return nil
	end

	local ok, name = pcall(mission_manager.mission_name, mission_manager)

	return ok and name or nil
end

local function has_prebaked_points(name)
	local locations = MutatorMonsterSpawnerSettings.default_locations

	return type(locations) == "table" and locations[name] ~= nil
end

mod:hook(MutatorManager, "_load_mutators", function (func, self, circumstance_name, ...)
	local name = mission_name()

	if not name or has_prebaked_points(name) then
		return func(self, circumstance_name, ...)
	end

	local saved = {}

	for i = 1, #PREBAKED_MUTATORS do
		local mutator_name = PREBAKED_MUTATORS[i]

		if MutatorTemplates[mutator_name] then
			saved[mutator_name] = MutatorTemplates[mutator_name]
			MutatorTemplates[mutator_name] = {
				name = mutator_name,
				class = "scripts/managers/mutator/mutators/mutator_base",
			}
		end
	end

	local ok, err = pcall(func, self, circumstance_name, ...)

	for mutator_name, template in pairs(saved) do
		MutatorTemplates[mutator_name] = template
	end

	if next(saved) then
		mod:info("%s has no prebaked spawn points: chaos rituals and Fading Light twins skipped on this map", tostring(name))
	end

	if not ok then
		error(err, 0)
	end
end)
