local mod = get_mod("QIangIQsUltraHavoc")

-- --------------------------------------------------------------------------
-- Operation maps: release the mission start when the intro never finishes
-- --------------------------------------------------------------------------
--
-- EXPERIMENTAL. Report 2026-09-27: on No Man's Land hosted locally, a
-- Thunderhawk that is not drawn blocks the team inside the start area.
--
-- What the game does (full decompiled source, Aussiemon/Darktide-Source-Code 1.12.5):
--   * The mission has an intro cinematic: operations_mission_templates.lua:108-111
--     cinematics.intro_abc = { "c_cam" }.
--   * On a local host (HOST_TYPES.player / singleplay) the intro is requested
--     straight from on_gameplay_post_init (cinematic_scene_system.lua:160-170).
--   * When the intro finishes, _cinematic_played sends the flow event
--     "lua_cinematic_played_server" to the intro's scene units - the origin in
--     the cinematic level and the destination in the mission level
--     (cinematic_scene_system.lua:213-246). Level flow reacts to that event.
--   * If the intro cannot play, _play_cutscene only triggers the
--     "intro_cinematic_played" event and never sends that flow event
--     (cinematic_scene_system.lua:318-340); play_cutscene marks the intro as
--     played either way (lines 298-301).
-- In the logs, hosted runs of the map mostly never load the intro camera level
-- (c_cam_no_mans_land). The assumption this module tests - that the start
-- area is released by that flow event - is not visible in Lua (level flow is
-- compiled level data).
--
-- What this does, on the host only: if the intro has not finished a few
-- seconds after the mission starts, it sends that same flow event to the
-- same scene units, found the same way the game finds them
-- (_initialize_sub_cinematics, cinematic_scene_system.lua:411-437).
-- Automatic on operation maps (mission_type "operations"); anywhere with
-- /ultra_havoc_release_intro.

local CinematicSceneSystem = require("scripts/extension_systems/cinematic_scene/cinematic_scene_system")
local CinematicSceneSettings = require("scripts/settings/cinematic_scene/cinematic_scene_settings")

local INTRO = CinematicSceneSettings.CINEMATIC_NAMES.intro_abc
local FLOW_EVENT = "lua_cinematic_played_server"
local AUTO_DELAY = 8

local M = {}

local state = {
	intro_done = false,
	timer = nil,
	released = false,
}

-- The game's own "intro finished" path: remember it so nothing is sent twice.
mod:hook_safe(CinematicSceneSystem, "_cinematic_played", function (self, cinematic_name)
	if cinematic_name == INTRO and self._cinematics_left_to_play == 0 then
		state.intro_done = true
	end
end)

local function cinematic_system()
	local extension_manager = Managers.state and Managers.state.extension

	return extension_manager and extension_manager:system("cinematic_scene_system") or nil
end

local function is_server()
	local game_session = Managers.state and Managers.state.game_session

	if not game_session then
		return false
	end

	local ok, server = pcall(game_session.is_server, game_session)

	return ok and server == true
end

local function current_mission()
	local mission_manager = Managers.state and Managers.state.mission

	return mission_manager and mission_manager:mission() or nil
end

--- Send the intro's "played" flow event to its scene units.
-- @return number units the event was sent to, string|nil reason
function M.release()
	if not is_server() then
		return 0, "only the host can do this"
	end

	local system = cinematic_system()

	if not system then
		return 0, "no cinematic system in this mission"
	end

	local sub_cinematics = system._cinematics and system._cinematics[INTRO]

	if type(sub_cinematics) ~= "table" or #sub_cinematics == 0 then
		return 0, "this mission has no intro cinematic"
	end

	local setups = system:_initialize_sub_cinematics(INTRO, sub_cinematics)
	local sent = 0

	for i = 1, #sub_cinematics do
		local setup = setups[sub_cinematics[i]]

		if setup then
			local units = { setup.scene_unit_origin, setup.scene_unit_destination }

			for j = 1, 2 do
				local unit = units[j]

				if unit and Unit.alive(unit) then
					Unit.flow_event(unit, FLOW_EVENT)
					sent = sent + 1
				end
			end
		end
	end

	state.released = true

	if sent == 0 then
		return 0, "no intro scene units found in the level"
	end

	return sent, nil
end

function M.update(dt)
	if not state.timer or state.released or state.intro_done then
		return
	end

	state.timer = state.timer - dt

	if state.timer > 0 then
		return
	end

	state.timer = nil

	local mission = current_mission()

	if not mission or mission.mission_type ~= "operations" or mod:get("operations_intro_release") == false then
		return
	end

	local sent, reason = M.release()

	if sent > 0 then
		mod:info("Intro did not finish on this operation map - sent %s to %d scene unit(s)", FLOW_EVENT, sent)
	else
		mod:info("Intro release skipped: %s", tostring(reason))
	end
end

function M.on_mission_start()
	state.intro_done = false
	state.released = false
	state.timer = AUTO_DELAY
end

function M.on_mission_end()
	state.timer = nil
end

function M.command()
	local sent, reason = M.release()

	if sent > 0 then
		mod:echo("Sent %s to %d intro scene unit(s).", FLOW_EVENT, sent)
	else
		mod:echo("Nothing sent: %s", tostring(reason))
	end
end

return M
