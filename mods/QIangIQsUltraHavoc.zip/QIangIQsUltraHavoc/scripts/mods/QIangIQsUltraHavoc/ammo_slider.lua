local mod = get_mod("QIangIQsUltraHavoc")

-- --------------------------------------------------------------------------
-- Ammo gained from pickups, on a slider
-- --------------------------------------------------------------------------
--
-- Every ammo pickup asks the difficulty manager for one multiplier when it is
-- picked up (ammunition_interaction.lua:53-58, get_ammo_modifier). The pickups
-- multiply their share by it:
--   small clip  15 of max reserve * modifier  (small_clip_pickup.lua)
--   large clip  50 of max reserve * modifier  (large_clip_pickup.lua)
--   ammo crate  full reserve + clip * modifier (ammo_cache_deployable_pickup.lua)
-- Havoc normally sets it once per mission from ammo_pickup_modifier
-- (game_mode_extension_havoc.lua:101-105); outside Havoc it stays 1
-- (difficulty_manager.lua:15). With the override on, the slider value is
-- returned instead, in every mission this game hosts.

local DifficultyManager = require("scripts/managers/difficulty/difficulty_manager")

mod:hook(DifficultyManager, "get_ammo_modifier", function (func, self, ...)
    if not mod:get("ammo_override") then
        return func(self, ...)
    end

    local percent = tonumber(mod:get("ammo_pickup_percent")) or 100

    return math.max(percent, 0) / 100
end)

-- Per pickup type, on top of the value above (or the game's own value when the
-- override is off). Ammo.add_ammo_using_pickup_data (ammo.lua) calls each
-- pickup's ammo_amount_func with pickup_data.modifier, which the ammunition
-- interaction set just before (ammunition_interaction.lua:54-58). The modifier
-- is scaled for that one call and put back afterwards.
local Ammo = require("scripts/utilities/ammo")

local PER_TYPE = {
    small_clip = "ammo_small_clip_percent",
    large_clip = "ammo_large_clip_percent",
    ammo_cache_deployable = "ammo_crate_percent",
}

mod:hook(Ammo, "add_ammo_using_pickup_data", function (func, unit, pickup_data, ...)
    local setting_id = type(pickup_data) == "table" and PER_TYPE[pickup_data.name]
    local percent = setting_id and tonumber(mod:get(setting_id))

    if not percent or percent == 100 then
        return func(unit, pickup_data, ...)
    end

    local original = pickup_data.modifier

    pickup_data.modifier = (original or 1) * math.max(percent, 0) / 100

    local result = func(unit, pickup_data, ...)

    pickup_data.modifier = original

    return result
end)
