local mod = get_mod("QIangIQsUltraHavoc")

-- Difficulty conditions are offered separately by the "Fading Light" setting,
-- so they are not listed as free-form extra conditions.
local FADING_LIGHT_CIRCUMSTANCES = {
    mutator_increased_difficulty = true,
    mutator_highest_difficulty = true,
}

--- Build the list of Havoc conditions that can be added to a mission.
-- Read from the live game data rather than hardcoded, so conditions added by a
-- patch show up on their own and renamed ones disappear instead of crashing the
-- mission on load. Entries whose mutators no longer exist are dropped for the
-- same reason.
-- @return table DMF dropdown options
local function condition_options()
    local options = {
        localize = false,
        { text = mod:localize("condition_none"), value = "none" },
    }

    local loaded, havoc_circumstances = pcall(require, "scripts/settings/circumstance/templates/havoc_circumstance_template")
    local mutators_loaded, mutator_templates = pcall(require, "scripts/settings/mutator/mutator_templates")

    if not loaded or type(havoc_circumstances) ~= "table" then
        mod:warning("Could not read the Havoc condition list from the game")

        return options
    end

    local entries = {}

    for name, template in pairs(havoc_circumstances) do
        local mutators = type(template) == "table" and template.mutators
        local usable = type(mutators) == "table" and not FADING_LIGHT_CIRCUMSTANCES[name]

        if usable and mutators_loaded and type(mutator_templates) == "table" then
            for i = 1, #mutators do
                if not mutator_templates[mutators[i]] then
                    usable = false
                    break
                end
            end
        end

        if usable then
            local text = name
            local display_name = template.ui and template.ui.display_name

            if display_name then
                local localized = Localize(display_name)

                if type(localized) == "string" and localized ~= "" and string.sub(localized, 1, 1) ~= "<" then
                    text = localized
                end
            end

            entries[#entries + 1] = { text = text, value = name }
        end
    end

    table.sort(entries, function (a, b)
        return a.text < b.text
    end)

    for i = 1, #entries do
        options[#options + 1] = entries[i]
    end

    return options
end

--- One of the extra-condition dropdowns.
-- Each gets its own option table: they are identical in content, but DMF keeps
-- per-widget state on the table it is handed.
-- @param setting_id string
-- @return table DMF dropdown widget
local function extra_condition_widget(setting_id)
    return {
        setting_id = setting_id,
        type = "dropdown",
        default_value = "none",
        options = condition_options(),
        tooltip = "extra_condition_tooltip",
    }
end

--- A per-rank percentage slider.
-- @param setting_id string
-- @param default number
-- @return table DMF numeric widget
local function per_level_widget(setting_id, default)
    return {
        setting_id = setting_id,
        type = "numeric",
        default_value = default,
        range = { 0, 25 },
        decimals_number = 1,
        step_size_value = 0.5,
        unit_text = "unit_percent_per_rank",
        tooltip = setting_id .. "_tooltip",
    }
end

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = true,
    options = {
        widgets = {
            {
                setting_id = "max_rank",
                type = "numeric",
                default_value = 80,
                range = { 40, 80 },
                decimals_number = 0,
                step_size_value = 1,
                tooltip = "max_rank_tooltip",
            },
            {
                setting_id = "rank_override",
                type = "numeric",
                default_value = 0,
                range = { 0, 80 },
                decimals_number = 0,
                step_size_value = 1,
                tooltip = "rank_override_tooltip",
            },
            {
                setting_id = "scaling_group",
                type = "group",
                sub_widgets = {
                    per_level_widget("hp_per_level", 2.5),
                    per_level_widget("trash_per_level", 5),
                    per_level_widget("elite_per_level", 5),
                    per_level_widget("special_per_level", 2.5),
                    per_level_widget("boss_per_level", 1.5),
                    {
                        setting_id = "extend_vanilla",
                        type = "checkbox",
                        default_value = true,
                        tooltip = "extend_vanilla_tooltip",
                    },
                    {
                        setting_id = "ranks_per_step",
                        type = "numeric",
                        default_value = 5,
                        range = { 1, 10 },
                        decimals_number = 0,
                        step_size_value = 1,
                        tooltip = "ranks_per_step_tooltip",
                    },
                },
            },
            {
                setting_id = "growth_group",
                type = "group",
                sub_widgets = {
                    {
                        setting_id = "grow_modify_elite_health",
                        type = "numeric",
                        default_value = 100,
                        range = { 0, 300 },
                        decimals_number = 0,
                        step_size_value = 5,
                        tooltip = "grow_modify_elite_health_tooltip",
                    },
                    {
                        setting_id = "grow_modify_special_health",
                        type = "numeric",
                        default_value = 100,
                        range = { 0, 300 },
                        decimals_number = 0,
                        step_size_value = 5,
                        tooltip = "grow_modify_special_health_tooltip",
                    },
                    {
                        setting_id = "grow_modify_monster_health",
                        type = "numeric",
                        default_value = 100,
                        range = { 0, 300 },
                        decimals_number = 0,
                        step_size_value = 5,
                        tooltip = "grow_modify_monster_health_tooltip",
                    },
                    {
                        setting_id = "grow_add_num_monsters",
                        type = "numeric",
                        default_value = 100,
                        range = { 0, 300 },
                        decimals_number = 0,
                        step_size_value = 5,
                        tooltip = "grow_add_num_monsters_tooltip",
                    },
                    {
                        setting_id = "grow_modify_horde_health",
                        type = "numeric",
                        default_value = 100,
                        range = { 0, 300 },
                        decimals_number = 0,
                        step_size_value = 5,
                        tooltip = "grow_modify_horde_health_tooltip",
                    },
                    {
                        setting_id = "grow_modify_horde_hit_mass",
                        type = "numeric",
                        default_value = 100,
                        range = { 0, 300 },
                        decimals_number = 0,
                        step_size_value = 5,
                        tooltip = "grow_modify_horde_hit_mass_tooltip",
                    },
                    {
                        setting_id = "grow_add_max_alive_specials",
                        type = "numeric",
                        default_value = 100,
                        range = { 0, 300 },
                        decimals_number = 0,
                        step_size_value = 5,
                        tooltip = "grow_add_max_alive_specials_tooltip",
                    },
                    {
                        setting_id = "grow_add_more_elites",
                        type = "numeric",
                        default_value = 100,
                        range = { 0, 300 },
                        decimals_number = 0,
                        step_size_value = 5,
                        tooltip = "grow_add_more_elites_tooltip",
                    },
                    {
                        setting_id = "grow_add_more_ogryns",
                        type = "numeric",
                        default_value = 100,
                        range = { 0, 300 },
                        decimals_number = 0,
                        step_size_value = 5,
                        tooltip = "grow_add_more_ogryns_tooltip",
                    },
                    {
                        setting_id = "grow_ammo_pickup_modifier",
                        type = "numeric",
                        default_value = 100,
                        range = { 0, 300 },
                        decimals_number = 0,
                        step_size_value = 5,
                        tooltip = "grow_ammo_pickup_modifier_tooltip",
                    },
                    {
                        setting_id = "grow_horde_spawn_rate_modifier",
                        type = "numeric",
                        default_value = 100,
                        range = { 0, 300 },
                        decimals_number = 0,
                        step_size_value = 5,
                        tooltip = "grow_horde_spawn_rate_modifier_tooltip",
                    },
                    {
                        setting_id = "grow_terror_event_point_modifier",
                        type = "numeric",
                        default_value = 100,
                        range = { 0, 300 },
                        decimals_number = 0,
                        step_size_value = 5,
                        tooltip = "grow_terror_event_point_modifier_tooltip",
                    },
                    {
                        setting_id = "grow_melee_minion_power_level_modifier",
                        type = "numeric",
                        default_value = 100,
                        range = { 0, 300 },
                        decimals_number = 0,
                        step_size_value = 5,
                        tooltip = "grow_melee_minion_power_level_modifier_tooltip",
                    },
                    {
                        setting_id = "grow_melee_attack_speed",
                        type = "numeric",
                        default_value = 100,
                        range = { 0, 300 },
                        decimals_number = 0,
                        step_size_value = 5,
                        tooltip = "grow_melee_attack_speed_tooltip",
                    },
                    {
                        setting_id = "grow_ranged_attack_speed",
                        type = "numeric",
                        default_value = 100,
                        range = { 0, 300 },
                        decimals_number = 0,
                        step_size_value = 5,
                        tooltip = "grow_ranged_attack_speed_tooltip",
                    },
                    {
                        setting_id = "grow_melee_permanent_damage",
                        type = "numeric",
                        default_value = 100,
                        range = { 0, 300 },
                        decimals_number = 0,
                        step_size_value = 5,
                        tooltip = "grow_melee_permanent_damage_tooltip",
                    },
                    {
                        setting_id = "grow_toughness",
                        type = "numeric",
                        default_value = 100,
                        range = { 0, 300 },
                        decimals_number = 0,
                        step_size_value = 5,
                        tooltip = "grow_toughness_tooltip",
                    },
                    {
                        setting_id = "grow_toughness_regen",
                        type = "numeric",
                        default_value = 100,
                        range = { 0, 300 },
                        decimals_number = 0,
                        step_size_value = 5,
                        tooltip = "grow_toughness_regen_tooltip",
                    },
                    {
                        setting_id = "grow_max_health",
                        type = "numeric",
                        default_value = 100,
                        range = { 0, 300 },
                        decimals_number = 0,
                        step_size_value = 5,
                        tooltip = "grow_max_health_tooltip",
                    },
                    {
                        setting_id = "grow_vent_speed",
                        type = "numeric",
                        default_value = 100,
                        range = { 0, 300 },
                        decimals_number = 0,
                        step_size_value = 5,
                        tooltip = "grow_vent_speed_tooltip",
                    },
                },
            },
            {
                setting_id = "limits_group",
                type = "group",
                sub_widgets = {
                    {
                        setting_id = "limit_ammo_floor",
                        type = "numeric",
                        default_value = 5,
                        range = { 0, 40 },
                        decimals_number = 0,
                        step_size_value = 1,
                        tooltip = "limit_ammo_floor_tooltip",
                    },
                    {
                        setting_id = "limit_toughness",
                        type = "numeric",
                        default_value = 90,
                        range = { 45, 100 },
                        decimals_number = 0,
                        step_size_value = 1,
                        tooltip = "limit_toughness_tooltip",
                    },
                    {
                        setting_id = "limit_toughness_regen",
                        type = "numeric",
                        default_value = 100,
                        range = { 50, 100 },
                        decimals_number = 0,
                        step_size_value = 5,
                        tooltip = "limit_toughness_regen_tooltip",
                    },
                    {
                        setting_id = "limit_max_health",
                        type = "numeric",
                        default_value = 90,
                        range = { 35, 95 },
                        decimals_number = 0,
                        step_size_value = 1,
                        tooltip = "limit_max_health_tooltip",
                    },
                    {
                        setting_id = "limit_permanent_damage",
                        type = "numeric",
                        default_value = 100,
                        range = { 30, 100 },
                        decimals_number = 0,
                        step_size_value = 5,
                        tooltip = "limit_permanent_damage_tooltip",
                    },
                },
            },
            {
                setting_id = "conditions_group",
                type = "group",
                sub_widgets = {
                    extra_condition_widget("extra_condition_1"),
                    extra_condition_widget("extra_condition_2"),
                    extra_condition_widget("extra_condition_3"),
                    extra_condition_widget("extra_condition_4"),
                    {
                        setting_id = "fading_light",
                        type = "dropdown",
                        default_value = "auto",
                        options = {
                            { text = "fading_light_auto", value = "auto" },
                            { text = "fading_light_1", value = "1" },
                            { text = "fading_light_2", value = "2" },
                            { text = "fading_light_3", value = "3" },
                        },
                        tooltip = "fading_light_tooltip",
                    },
                    {
                        setting_id = "fading_light_levels",
                        type = "numeric",
                        default_value = 3,
                        range = { 0, 10 },
                        decimals_number = 0,
                        step_size_value = 1,
                        tooltip = "fading_light_levels_tooltip",
                    },
                    {
                        setting_id = "fl3_horde_travel_distance",
                        type = "numeric",
                        default_value = 30,
                        range = { 0, 100 },
                        decimals_number = 0,
                        step_size_value = 5,
                        tooltip = "fl3_horde_travel_distance_tooltip",
                    },
                },
            },
            {
                setting_id = "extras_group",
                type = "group",
                sub_widgets = {
                    {
                        setting_id = "expand_map_pool",
                        type = "checkbox",
                        default_value = true,
                        tooltip = "expand_map_pool_tooltip",
                    },
                    {
                        setting_id = "map_pool_operations",
                        type = "checkbox",
                        default_value = true,
                        tooltip = "map_pool_operations_tooltip",
                    },
                    {
                        setting_id = "operations_mode_check",
                        type = "checkbox",
                        default_value = true,
                        tooltip = "operations_mode_check_tooltip",
                    },
                    {
                        setting_id = "operations_intro_release",
                        type = "checkbox",
                        default_value = true,
                        tooltip = "operations_intro_release_tooltip",
                    },
                    {
                        setting_id = "train_havoc_timer",
                        type = "checkbox",
                        default_value = true,
                        tooltip = "train_havoc_timer_tooltip",
                    },
                    {
                        setting_id = "train_havoc_minutes",
                        type = "numeric",
                        default_value = 30,
                        range = { 5, 60 },
                        decimals_number = 0,
                        step_size_value = 1,
                        tooltip = "train_havoc_minutes_tooltip",
                    },
                    {
                        setting_id = "map_pool_new_only",
                        type = "checkbox",
                        default_value = false,
                        tooltip = "map_pool_new_only_tooltip",
                    },
                    {
                        setting_id = "boss_health_percent",
                        type = "numeric",
                        default_value = 100,
                        range = { 10, 500 },
                        decimals_number = 0,
                        step_size_value = 5,
                        tooltip = "boss_health_percent_tooltip",
                    },
                    {
                        setting_id = "remove_bruisers",
                        type = "checkbox",
                        default_value = false,
                        tooltip = "remove_bruisers_tooltip",
                    },
                    {
                        setting_id = "pacing_enemy_cap",
                        type = "numeric",
                        default_value = 145,
                        range = { 145, 1000 },
                        decimals_number = 0,
                        step_size_value = 5,
                        tooltip = "pacing_enemy_cap_tooltip",
                    },
                    {
                        setting_id = "twin_packs",
                        type = "checkbox",
                        default_value = true,
                        tooltip = "twin_packs_tooltip",
                    },
                    {
                        setting_id = "twin_four_rank",
                        type = "numeric",
                        default_value = 50,
                        range = { 41, 80 },
                        decimals_number = 0,
                        step_size_value = 1,
                        tooltip = "twin_four_rank_tooltip",
                    },
                    {
                        setting_id = "twin_six_rank",
                        type = "numeric",
                        default_value = 65,
                        range = { 41, 80 },
                        decimals_number = 0,
                        step_size_value = 1,
                        tooltip = "twin_six_rank_tooltip",
                    },
                    {
                        setting_id = "twin_pairs_mid",
                        type = "numeric",
                        default_value = 2,
                        range = { 1, 5 },
                        decimals_number = 0,
                        step_size_value = 1,
                        tooltip = "twin_pairs_mid_tooltip",
                    },
                    {
                        setting_id = "twin_pairs_high",
                        type = "numeric",
                        default_value = 3,
                        range = { 1, 5 },
                        decimals_number = 0,
                        step_size_value = 1,
                        tooltip = "twin_pairs_high_tooltip",
                    },
                    {
                        setting_id = "ammo_override",
                        type = "checkbox",
                        default_value = false,
                        tooltip = "ammo_override_tooltip",
                        sub_widgets = {
                            {
                                setting_id = "ammo_pickup_percent",
                                type = "numeric",
                                default_value = 100,
                                range = { 0, 300 },
                                decimals_number = 0,
                                step_size_value = 5,
                                tooltip = "ammo_pickup_percent_tooltip",
                            },
                            {
                                setting_id = "ammo_small_clip_percent",
                                type = "numeric",
                                default_value = 100,
                                range = { 0, 300 },
                                decimals_number = 0,
                                step_size_value = 5,
                                tooltip = "ammo_small_clip_percent_tooltip",
                            },
                            {
                                setting_id = "ammo_large_clip_percent",
                                type = "numeric",
                                default_value = 100,
                                range = { 0, 300 },
                                decimals_number = 0,
                                step_size_value = 5,
                                tooltip = "ammo_large_clip_percent_tooltip",
                            },
                            {
                                setting_id = "ammo_crate_percent",
                                type = "numeric",
                                default_value = 100,
                                range = { 0, 300 },
                                decimals_number = 0,
                                step_size_value = 5,
                                tooltip = "ammo_crate_percent_tooltip",
                            },
                        },
                    },
                },
            },
            {
                setting_id = "blackout_group",
                type = "group",
                sub_widgets = {
                    {
                        setting_id = "blackout_enabled",
                        type = "checkbox",
                        default_value = false,
                        tooltip = "blackout_enabled_tooltip",
                    },
                    {
                        setting_id = "blackout_count_min",
                        type = "numeric",
                        default_value = 2,
                        range = { 1, 8 },
                        decimals_number = 0,
                        step_size_value = 1,
                        tooltip = "blackout_count_tooltip",
                    },
                    {
                        setting_id = "blackout_count_max",
                        type = "numeric",
                        default_value = 4,
                        range = { 1, 8 },
                        decimals_number = 0,
                        step_size_value = 1,
                        tooltip = "blackout_count_tooltip",
                    },
                    {
                        setting_id = "blackout_duration_min",
                        type = "numeric",
                        default_value = 120,
                        range = { 30, 600 },
                        decimals_number = 0,
                        step_size_value = 10,
                        unit_text = "unit_seconds",
                        tooltip = "blackout_duration_tooltip",
                    },
                    {
                        setting_id = "blackout_duration_max",
                        type = "numeric",
                        default_value = 300,
                        range = { 30, 900 },
                        decimals_number = 0,
                        step_size_value = 10,
                        unit_text = "unit_seconds",
                        tooltip = "blackout_duration_tooltip",
                    },
                    {
                        setting_id = "blackout_gas",
                        type = "checkbox",
                        default_value = true,
                        tooltip = "blackout_gas_tooltip",
                    },
                    {
                        setting_id = "gas_per_wave",
                        type = "numeric",
                        default_value = 2,
                        range = { 1, 6 },
                        decimals_number = 0,
                        step_size_value = 1,
                        tooltip = "gas_per_wave_tooltip",
                    },
                    {
                        setting_id = "gas_limit",
                        type = "numeric",
                        default_value = 6,
                        range = { 1, 20 },
                        decimals_number = 0,
                        step_size_value = 1,
                        tooltip = "gas_limit_tooltip",
                    },
                    {
                        setting_id = "gas_patch_size",
                        type = "numeric",
                        default_value = 20,
                        range = { 5, 80 },
                        decimals_number = 0,
                        step_size_value = 5,
                        tooltip = "gas_patch_size_tooltip",
                    },
                    {
                        setting_id = "blackout_first_min",
                        type = "numeric",
                        default_value = 90,
                        range = { 10, 600 },
                        decimals_number = 0,
                        step_size_value = 10,
                        tooltip = "blackout_first_min_tooltip",
                    },
                    {
                        setting_id = "blackout_first_max",
                        type = "numeric",
                        default_value = 240,
                        range = { 10, 900 },
                        decimals_number = 0,
                        step_size_value = 10,
                        tooltip = "blackout_first_max_tooltip",
                    },
                    {
                        setting_id = "blackout_gap_min",
                        type = "numeric",
                        default_value = 150,
                        range = { 30, 900 },
                        decimals_number = 0,
                        step_size_value = 10,
                        tooltip = "blackout_gap_min_tooltip",
                    },
                    {
                        setting_id = "blackout_gap_max",
                        type = "numeric",
                        default_value = 420,
                        range = { 30, 1200 },
                        decimals_number = 0,
                        step_size_value = 10,
                        tooltip = "blackout_gap_max_tooltip",
                    },
                    {
                        setting_id = "gas_wave_interval",
                        type = "numeric",
                        default_value = 8,
                        range = { 2, 60 },
                        decimals_number = 0,
                        step_size_value = 1,
                        tooltip = "gas_wave_interval_tooltip",
                    },
                    {
                        setting_id = "gas_distance_min",
                        type = "numeric",
                        default_value = 5,
                        range = { 1, 40 },
                        decimals_number = 0,
                        step_size_value = 1,
                        tooltip = "gas_distance_min_tooltip",
                    },
                    {
                        setting_id = "gas_distance_max",
                        type = "numeric",
                        default_value = 18,
                        range = { 2, 60 },
                        decimals_number = 0,
                        step_size_value = 1,
                        tooltip = "gas_distance_max_tooltip",
                    },
                    {
                        setting_id = "blackout_lights_per_frame",
                        type = "numeric",
                        default_value = 25,
                        range = { 5, 200 },
                        decimals_number = 0,
                        step_size_value = 5,
                        tooltip = "blackout_lights_per_frame_tooltip",
                    },
                },
            },
            {
                setting_id = "debug_log",
                type = "checkbox",
                default_value = false,
                tooltip = "debug_log_tooltip",
            },
            {
                setting_id = "announce",
                type = "checkbox",
                default_value = true,
                tooltip = "announce_tooltip",
            },
        },
    },
}
