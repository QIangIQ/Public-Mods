local mod = get_mod("QIangIQsUltraHavoc")

-- --------------------------------------------------------------------------
-- Bots with an empty ranged slot
-- --------------------------------------------------------------------------
--
-- Crash logs 2026-09-28 00:39 and 2026-09-27 23:05 (op_no_mans_land, hosted
-- with bots): right after the bots spawn their profiles are synced again
-- ("Player Profile Begin Sync-Change" for bots 2-7, abilities unequipped). For
-- a moment a bot's slot_secondary holds no item, and the bot brain's
-- should_vent_overheat condition (bt_bot_conditions.lua:1068-1077) calls
-- Overheat.slot_percentage (overheat.lua:254) -> Overheat.configuration, which
-- indexes the nil weapon template (overheat.lua:272) - error, crash:
--   locals: slot_name = "slot_secondary"; weapon_template = nil; slot_item = nil
--
-- The overheat source is not in the provided dump, so its body is left alone.
-- Only a call that raises is answered, and with 0: "no heat", so the bot does
-- not try to vent a weapon it is not holding. Every call that works returns
-- exactly what the game returned. Bot brains run on the host only.

local Overheat = require("scripts/utilities/overheat")

local reported = false

-- LuaJIT (5.1) has no table.pack; same return capture as DMF hooks.lua
-- (get_return_values + unpack(values, 1, num_values)).
local function capture(...)
	return select("#", ...), { ... }
end

mod:hook(Overheat, "slot_percentage", function (func, ...)
	local n, results = capture(pcall(func, ...))

	if results[1] then
		return unpack(results, 2, n)
	end

	if not reported then
		reported = true

		mod:info("Overheat.slot_percentage failed (empty weapon slot during a profile change) - answering 0: %s", tostring(results[2]))
	end

	return 0
end)
