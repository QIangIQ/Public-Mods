local mod = get_mod("QIangIQsUltraHavoc")

-- --------------------------------------------------------------------------
-- Havoc map pool: every mission for the random Havoc roll
-- --------------------------------------------------------------------------
--
-- Solo Play's random Havoc roll (the dice button, and HavocConditionManager's
-- regenerate) is SoloPlay mod.gen_havoc_data (SoloPlay havoc.lua:13-81). It
-- picks the map from the game's short list HavocSettings.missions[theme]
-- (havoc.lua:52-53; the lists are havoc_settings.lua:37-97), so maps like
-- No Man's Land or the train mission are never rolled.
--
-- Solo Play's own manual "Havoc mission" dropdown already offers every map
-- that passes this test (SoloPlaySettings.lua:158-159):
--     mission.mechanism_name == "adventure"
--     and mission.game_mode_name == "coop_complete_objective"
--     and mission.mission_type ~= "operations"
--     and not the twins mission km_enforcer_twins (SoloPlaySettings.lua:17, 27-29)
-- with hub/onboarding/training_grounds objectives skipped (SoloPlaySettings.lua:19-23, 167).
-- This module rolls from that same set, built from the game's MissionTemplates
-- at runtime, so no mission name is hard-coded here.
--
-- Themes (darkness, ventilation purge, toxic gas) need the map's own theme
-- variant, and only the maps in HavocSettings.missions[theme] have one. When a
-- rolled map is not in the rolled theme's list, the theme is dropped
-- (theme_circumstance = "default", the value havoc.lua:19 starts with).

local HavocSettings = require("scripts/settings/havoc_settings")

local TWINS_MISSION = "km_enforcer_twins"

-- Operation maps by id, from ChaosWastesAtHome chain.lua:33-37 (ids confirmed
-- there against the localization export). SoloPlay's filter drops
-- mission_type "operations"; with "Include operation maps" on, these two skip
-- only that check. They still have to be adventure + coop_complete_objective,
-- the game mode Havoc runs on.
local OPERATION_MAPS = {
	op_train = true, -- Rolling Steel
	op_no_mans_land = true, -- No Man's Land
}
local OBJECTIVES_DENYLIST = {
	hub = true,
	onboarding = true,
	training_grounds = true,
}

local M = {}

local pool_cache

--- The operation maps that may be offered, with the reason each one is not.
-- A map needs a template with a level (ChaosWastesAtHome chain.lua:46 checks
-- mission.level too) and, unless the mode check is switched off, the same
-- mechanism and game mode as a regular Havoc map.
-- @return table names, table reasons[name]
function M.operation_maps()
	local names, reasons = {}, {}

	if mod:get("map_pool_operations") == false then
		for name in pairs(OPERATION_MAPS) do
			reasons[name] = "option off"
		end

		return names, reasons
	end

	local ok, MissionTemplates = pcall(require, "scripts/settings/mission/mission_templates")
	local check_mode = mod:get("operations_mode_check") ~= false

	for name in pairs(OPERATION_MAPS) do
		local mission = ok and type(MissionTemplates) == "table" and MissionTemplates[name]

		if type(mission) ~= "table" then
			reasons[name] = "not in this game version"
		elseif mission.level == nil then
			reasons[name] = "template has no level"
		elseif check_mode and (mission.mechanism_name ~= "adventure" or mission.game_mode_name ~= "coop_complete_objective") then
			reasons[name] = string.format("game mode %s / mechanism %s (turn off the mode check to allow)", tostring(mission.game_mode_name), tostring(mission.mechanism_name))
		else
			names[#names + 1] = name
		end
	end

	table.sort(names)

	return names, reasons
end

--- Every mission Solo Play's Havoc dropdown accepts, sorted by name.
function M.invalidate()
	pool_cache = nil
end

function M.full_pool()
	if pool_cache then
		return pool_cache
	end

	local ok, MissionTemplates = pcall(require, "scripts/settings/mission/mission_templates")

	if not ok or type(MissionTemplates) ~= "table" then
		return nil
	end

	local pool = {}

	for name, mission in pairs(MissionTemplates) do
		if type(mission) == "table" and not OBJECTIVES_DENYLIST[mission.objectives or ""]
			and mission.mechanism_name == "adventure"
			and mission.game_mode_name == "coop_complete_objective"
			and mission.mission_type ~= "operations"
			and name ~= TWINS_MISSION then
			pool[#pool + 1] = name
		end
	end

	local operations = M.operation_maps()

	for i = 1, #operations do
		pool[#pool + 1] = operations[i]
	end

	table.sort(pool)

	pool_cache = pool

	return pool
end

local function vanilla_set()
	local set = {}

	for _, missions in pairs(HavocSettings.missions) do
		for i = 1, #missions do
			set[missions[i]] = true
		end
	end

	return set
end

local function theme_of(theme_circumstance)
	for theme, circumstances in pairs(HavocSettings.circumstances_per_theme) do
		for i = 1, #circumstances do
			if circumstances[i] == theme_circumstance then
				return theme
			end
		end
	end

	return nil
end

local function contains(list, value)
	for i = 1, #list do
		if list[i] == value then
			return true
		end
	end

	return false
end

--- Replace the rolled map with one from the full pool.
function M.reroll(data)
	if type(data) ~= "table" or not mod:get("expand_map_pool") then
		return data
	end

	local pool = M.full_pool()

	if not pool or #pool == 0 then
		return data
	end

	local candidates = pool

	if mod:get("map_pool_new_only") then
		local vanilla = vanilla_set()

		candidates = {}

		for i = 1, #pool do
			if not vanilla[pool[i]] then
				candidates[#candidates + 1] = pool[i]
			end
		end

		if #candidates == 0 then
			candidates = pool
		end
	end

	data.mission = candidates[math.random(1, #candidates)]

	local theme = theme_of(data.theme_circumstance)

	if theme and not contains(HavocSettings.missions[theme] or {}, data.mission) then
		data.theme_circumstance = "default"
	end

	if mod:get("debug_log") then
		mod:info("Havoc map pool: rolled %s (theme %s)", tostring(data.mission), tostring(data.theme_circumstance))
	end

	return data
end

-- Solo Play's "Havoc mission" dropdown is built from
-- SoloPlaySettings.order.havoc_missions (make_options.lua:95-107), which
-- SoloPlaySettings.lua fills with its filter (lines 158-164) and which drops
-- mission_type "operations". The settings file is not a shared module: each
-- Solo Play file runs it again through mod:io_dofile (SoloPlay.lua:16,
-- make_options.lua:2, soloplay_mod_view.lua:11), and the view files run again
-- on every open (they load through DMF's io require path, require.lua:67-70,
-- which also skips hook_require). So the hook sits on Solo Play's own
-- io_dofile and adds the operation maps to every fresh copy. DMF sets the hook
-- on the object passed (hooks.lua:206-211), i.e. only Solo Play's mod object.
local SOLOPLAY_SETTINGS_PATH = "SoloPlay/scripts/mods/SoloPlay/SoloPlaySettings"

local function add_to_soloplay_settings(settings)
	local order = settings.order and settings.order.havoc_missions
	local loc = settings.loc and settings.loc.missions

	if type(order) ~= "table" then
		return
	end

	local present = {}

	for i = 1, #order do
		present[order[i]] = true
	end

	local ok, MissionTemplates = pcall(require, "scripts/settings/mission/mission_templates")
	local names = M.operation_maps()

	for i = 1, #names do
		local name = names[i]

		if not present[name] then
			order[#order + 1] = name

			-- Same display-name rule as SoloPlaySettings.lua:138-141.
			if type(loc) == "table" and not loc[name] then
				local mission = ok and MissionTemplates[name]
				local lok, display = pcall(Localize, mission and mission.mission_name or name)

				loc[name] = (lok and type(display) == "string" and string.sub(display, 1, 1) ~= "<") and display or name
			end
		end
	end
end

function M.install()
	local soloplay = get_mod("SoloPlay")

	if not soloplay or type(soloplay.gen_havoc_data) ~= "function" then
		return
	end

	mod:hook(soloplay, "io_dofile", function (func, self, path, ...)
		local result = func(self, path, ...)

		if path == SOLOPLAY_SETTINGS_PATH and type(result) == "table" then
			local ok, err = pcall(add_to_soloplay_settings, result)

			if not ok then
				mod:error("could not add operation maps to Solo Play: %s", tostring(err))
			end
		end

		return result
	end)

	-- Same hook style as mission_setup.lua on gen_havoc_mission_context.
	mod:hook(soloplay, "gen_havoc_data", function (func, ...)
		local data = func(...)
		local ok, result = pcall(M.reroll, data)

		if not ok then
			mod:error("Havoc map pool skipped: %s", tostring(result))

			return data
		end

		return result
	end)
end

--- Chat report: the full pool and which maps are new.
function M.report()
	local pool = M.full_pool()

	if not pool then
		mod:echo("Havoc map pool: mission list not available yet")

		return
	end

	local vanilla = vanilla_set()
	local new = {}

	for i = 1, #pool do
		if not vanilla[pool[i]] then
			new[#new + 1] = pool[i]
		end
	end

	mod:echo("Havoc map pool (%s): %d maps, %d not in the game's Havoc list", mod:get("expand_map_pool") and "on" or "off", #pool, #new)
	mod:echo("Added: %s", #new > 0 and table.concat(new, ", ") or "none")

	local ok, MissionTemplates = pcall(require, "scripts/settings/mission/mission_templates")
	local _, reasons = M.operation_maps()

	for name in pairs(OPERATION_MAPS) do
		local mission = ok and type(MissionTemplates) == "table" and MissionTemplates[name]
		local status = reasons[name] and ("not offered: " .. reasons[name]) or "offered in the dropdown and the roll"

		if type(mission) ~= "table" then
			mod:echo("%s: %s", name, status)
		else
			mod:echo("%s: game mode %s, mechanism %s, type %s - %s", name, tostring(mission.game_mode_name), tostring(mission.mechanism_name), tostring(mission.mission_type), status)
		end
	end
end

return M
