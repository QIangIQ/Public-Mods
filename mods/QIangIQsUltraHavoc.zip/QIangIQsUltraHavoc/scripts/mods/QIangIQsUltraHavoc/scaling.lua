local mod = get_mod("QIangIQsUltraHavoc")

local Breeds = require("scripts/settings/breed/breeds")

local scaling = {}

-- Vanilla Havoc tops out at rank 40. Everything below is defined as a delta on
-- top of a normal rank-40 run: rank 41 is "rank 40 plus one level of our curve".
scaling.BASE_RANK = 40

-- Average of `num_spawns.monsters` in the havoc monster pacing template at the
-- top challenge entry ({1, 2}). Needed because the pacing layer only spawns a
-- whole number of monstrosities, so "+X% monstrosities" has to be turned into
-- "+N spawns, sometimes +1 more".
local BASE_MONSTER_SPAWNS = 1.5

-- Per-level values as they are stored in the mod options (in percent).
local PERCENT_SETTINGS = {
    hp         = { id = "hp_per_level",      default = 2.5 },
    trash_cut  = { id = "trash_per_level",   default = 5 },
    elite_up   = { id = "elite_per_level",   default = 5 },
    special_up = { id = "special_per_level", default = 2.5 },
    boss_up    = { id = "boss_per_level",    default = 1.5 },
}

-- Trash breeds that may be upgraded into an elite instead of being culled.
-- Taken from the game's own `extra_replacement` entries in
-- scripts/settings/roamer/havoc_roamer_limits.lua, so the promotions are the
-- ones Fatshark already uses for these breeds at high Havoc ranks.
-- Poxwalkers are deliberately absent: they are never promoted (and, in this local edit, never culled either).
local PROMOTIONS = {
    renegade_rifleman = {
        renegade = { "renegade_gunner" },
        cultist = { "cultist_gunner" },
    },
    renegade_melee = {
        renegade = { "renegade_executor" },
        cultist = { "cultist_berzerker" },
    },
    renegade_assault = {
        renegade = { "renegade_gunner", "renegade_berzerker", "renegade_shocktrooper", "renegade_executor" },
        cultist = { "cultist_gunner", "cultist_berzerker", "cultist_shocktrooper" },
    },
    cultist_melee = {
        renegade = { "renegade_executor" },
        cultist = { "cultist_berzerker" },
    },
    cultist_assault = {
        renegade = { "renegade_gunner", "renegade_berzerker", "renegade_shocktrooper" },
        cultist = { "cultist_gunner", "cultist_berzerker", "cultist_shocktrooper" },
    },
}

-- State of the current mission. `data` is the parsed havoc data table, which is
-- rebuilt per mission, so comparing identity is enough to detect a new run.
local run = {
    data = nil,
    factors = nil,
    elite_debt = 0,
    trash_debt = 0,
    monster_bonus = nil,
    culled = 0,
    promoted = 0,
}
scaling.run = run

-- --------------------------------------------------------------------------
-- Breed classification
-- --------------------------------------------------------------------------

local _class_cache = {}

--- Bucket a breed into the four groups the scaling talks about.
-- Classification is tag based, so cultist/renegade variants and breeds added by
-- a future patch land in the right bucket without a hardcoded list.
-- @param breed_name string
-- @return string|nil one of "trash", "elite", "special", "monster"
local function classify(breed_name)
    if type(breed_name) ~= "string" then
        return nil
    end

    local cached = _class_cache[breed_name]
    if cached ~= nil then
        return cached or nil
    end

    local result = false
    local breed = Breeds[breed_name]
    local tags = breed and breed.tags

    if tags and tags.minion then
        if tags.monster or tags.captain then
            result = "monster"
        elseif tags.elite then
            result = "elite"
        elseif tags.special or tags.interrupter then
            result = "special"
        elseif tags.roamer or tags.horde or tags.poxwalker then
            result = "trash"
        end
    end

    _class_cache[breed_name] = result
    return result or nil
end
scaling.classify = classify

--- Pick the elite a trash roamer should be promoted into.
-- @param breed_name string trash breed about to be spawned
-- @param faction string|nil "renegade" or "cultist" (zone faction)
-- @return string|nil elite breed name, nil when this breed has no promotion
function scaling.promote(breed_name, faction)
    local promotions = PROMOTIONS[breed_name]
    if not promotions then
        return nil
    end

    local candidates = promotions[faction] or promotions.renegade or promotions.cultist
    if not candidates then
        return nil
    end

    -- Drop anything the current game build no longer ships, so a renamed breed
    -- degrades into "no promotion" instead of a nil breed lookup on spawn.
    local valid = {}
    for i = 1, #candidates do
        local name = candidates[i]
        if Breeds[name] and classify(name) == "elite" then
            valid[#valid + 1] = name
        end
    end

    if #valid == 0 then
        return nil
    end

    return valid[math.random(1, #valid)]
end

-- --------------------------------------------------------------------------
-- Factors
-- --------------------------------------------------------------------------

--- Read a per-level option and turn it into a fraction.
-- @param key string key of PERCENT_SETTINGS
-- @return number
local function percent_option(key)
    local entry = PERCENT_SETTINGS[key]
    local value = mod:get(entry.id)

    if type(value) ~= "number" then
        value = entry.default
    end

    return value * 0.01
end

--- Round a fractional amount to a whole number, keeping the average intact.
-- 0.75 becomes 1 three times out of four and 0 once.
-- @param value number
-- @return number
function scaling.probabilistic_round(value)
    if type(value) ~= "number" or value <= 0 then
        return 0
    end

    local whole = math.floor(value)
    local remainder = value - whole

    if remainder > 0 and math.random() < remainder then
        whole = whole + 1
    end

    return whole
end

--- Build the scaling factors for a Havoc rank.
-- @param rank number havoc rank of the mission
-- @return table factors, always non-nil; `active` is false below rank 41
function scaling.compute(rank)
    local levels = math.floor(math.max((tonumber(rank) or 0) - scaling.BASE_RANK, 0))

    -- "The Emperors Fading Light III" does not exist in the game, so it is
    -- expressed as extra levels of this mod's own curve on top of tier II.
    local bonus_levels = 0
    if mod:get("fading_light") == "3" then
        local configured = mod:get("fading_light_levels")
        bonus_levels = type(configured) == "number" and configured or 3
    end

    local effective = levels + bonus_levels

    if effective <= 0 then
        return {
            active = false,
            levels = 0,
            effective_levels = 0,
        }
    end

    return {
        active = true,
        levels = levels,
        effective_levels = effective,
        hp = percent_option("hp") * effective,
        -- Local edit: trash is no longer culled but promoted into elites (see
        -- spawn_scaling), so the author's 90% cap is gone. 1.0 means every
        -- promotable trash roamer becomes an elite.
        trash_cut = math.min(percent_option("trash_cut") * effective, 1),
        elite_up = percent_option("elite_up") * effective,
        special_up = percent_option("special_up") * effective,
        boss_up = percent_option("boss_up") * effective,
    }
end

--- Forget the current mission's state.
function scaling.reset()
    run.data = nil
    run.factors = nil
    run.elite_debt = 0
    run.trash_debt = 0
    run.monster_bonus = nil
    run.culled = 0
    run.promoted = 0
end

--- Scaling factors for the mission that is running right now.
-- Cheap enough to call from spawn hooks: the parsed havoc data table is created
-- once per mission, so the factors are only recomputed when it changes.
-- @return table|nil nil outside a Havoc mission and below rank 41
function scaling.factors()
    local state = Managers.state
    local difficulty = state and state.difficulty
    local data = difficulty and difficulty:get_parsed_havoc_data()

    if not data then
        if run.data then
            scaling.reset()
        end

        return nil
    end

    if run.data ~= data then
        scaling.reset()

        run.data = data
        run.factors = scaling.compute(data.havoc_rank)

        if run.factors.active then
            mod:info(
                "Havoc rank %s (%d extra levels): +%d%% HP, -%d%% trash, +%d%% elites, +%d%% specials, +%d%% monstrosities",
                tostring(data.havoc_rank),
                run.factors.effective_levels,
                math.round(run.factors.hp * 100),
                math.round(run.factors.trash_cut * 100),
                math.round(run.factors.elite_up * 100),
                math.round(run.factors.special_up * 100),
                math.round(run.factors.boss_up * 100)
            )
        end
    end

    local factors = run.factors
    if factors and factors.active then
        return factors
    end

    return nil
end

--- Whole extra monstrosities for this mission, rolled once and then reused.
-- @param base number|nil value the vanilla `add_num_monsters` modifier returned
-- @param factors table
-- @return number
function scaling.monster_bonus(base, factors)
    if run.monster_bonus == nil then
        run.monster_bonus = scaling.probabilistic_round(((base or 0) + BASE_MONSTER_SPAWNS) * factors.boss_up)
    end

    return run.monster_bonus
end

return scaling
