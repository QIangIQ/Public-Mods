local mod = get_mod("QIangIQsUltraHavoc")
local scaling = mod.scaling

local soloplay_view = {}

-- Widget the rank slider was last raised on. Solo Play registers its view
-- through DMF's require path, which means the view file is executed again on
-- every open and any hook placed on the view class is overwritten. Patching the
-- live widget instead survives that, and re-patching is driven from update().
local patched_widget = nil

--- Raise Solo Play's Havoc rank slider past its built-in cap of 40.
-- The slider blueprint reads `min_value`, `max_value` and `explode_function`
-- from `content.entry` on every frame, so swapping them in is enough; only
-- `content.step_size` is precomputed and has to be refreshed as well.
-- @param view table the live SoloPlayModView instance
-- @param max_rank number
-- @return boolean whether the slider was patched
local function patch_rank_slider(view, max_rank)
    local widget = view._havoc_difficulty_slider_widget
    local content = widget and widget.content
    local entry = content and content.entry

    if not entry or type(entry.explode_function) ~= "function" or type(entry.max_value) ~= "number" then
        return false
    end

    if widget == patched_widget and entry.max_value == max_rank then
        return true
    end

    local min_value = entry.min_value or 1
    local step_size = entry.step_size_value or 1
    local value_range = max_rank - min_value

    if value_range <= 0 then
        return false
    end

    entry.max_value = max_rank
    entry.explode_function = function (normalized_value)
        local exploded_value = min_value + normalized_value * value_range

        return math.round(exploded_value / step_size) * step_size
    end

    content.step_size = step_size / value_range
    patched_widget = widget

    return true
end

--- Called every frame; cheap no-op unless the Solo Play window is open.
function soloplay_view.update()
    local max_rank = mod:get("max_rank")

    if type(max_rank) ~= "number" or max_rank <= scaling.BASE_RANK then
        return
    end

    local ui_manager = Managers.ui

    if not ui_manager or not ui_manager.view_instance then
        return
    end

    local view = ui_manager:view_instance("soloplay_mod_view")

    if not view then
        patched_widget = nil

        return
    end

    patch_rank_slider(view, math.floor(max_rank))
end

--- Drop the cached widget so the next open re-patches from scratch.
function soloplay_view.invalidate()
    patched_widget = nil
end

return soloplay_view
