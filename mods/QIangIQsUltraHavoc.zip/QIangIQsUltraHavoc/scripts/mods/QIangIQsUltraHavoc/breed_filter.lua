local mod = get_mod("QIangIQsUltraHavoc")

local Breeds = require("scripts/settings/breed/breeds")
local MinionSpawnManager = require("scripts/managers/minion/minion_spawn_manager")

-- Scab and Dreg Bruisers - the shield-carrying trash - are renegade_vanguard
-- and cultist_vanguard internally (game_object_type "minion_shield_melee",
-- spawn_inventory_slot "slot_shield"). They are swapped for the plain melee
-- trash of the same faction rather than dropped, because a spawn request has to
-- come back with a unit: roamer packs, hordes and terror events all expect one.
-- Enemy density therefore stays exactly as the mission intended, only the
-- shields are gone.
local BRUISER_REPLACEMENTS = {
    renegade_vanguard = "renegade_melee",
    cultist_vanguard = "cultist_melee",
}

local replacements = nil

--- Build the replacement table once, dropping anything this game build lacks.
local function valid_replacements()
    if replacements then
        return replacements
    end

    replacements = {}

    for breed_name, replacement in pairs(BRUISER_REPLACEMENTS) do
        if Breeds[breed_name] and Breeds[replacement] then
            replacements[breed_name] = replacement
        else
            mod:warning("Breed %q or its replacement %q is missing in this build", breed_name, replacement)
        end
    end

    return replacements
end

-- The single point where every minion spawn resolves its breed - the game's own
-- breed-swapping mutators (armored infected, maelstrom poxwalkers) work through
-- exactly this function. MinionSpawnManager is server-only, so a Realms guest
-- never runs it.
mod:hook(MinionSpawnManager, "replacement_breed", function (func, self, breed_name)
    local replacement = func(self, breed_name)

    if not mod:get("remove_bruisers") then
        return replacement
    end

    return valid_replacements()[replacement or breed_name] or replacement
end)
