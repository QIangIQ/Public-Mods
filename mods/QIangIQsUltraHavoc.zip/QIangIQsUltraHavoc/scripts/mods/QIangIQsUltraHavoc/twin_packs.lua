local mod = get_mod("QIangIQsUltraHavoc")

-- --------------------------------------------------------------------------
-- Twin (Rinda / Karnak) packs at high ranks
-- --------------------------------------------------------------------------
--
-- In Havoc the twins come from the Fading Light difficulty conditions
-- (havoc_circumstance_template.lua:204 and 227 load "mutator_monster_havoc_twins").
-- That mutator (havoc_mutator_local_settings.lua:569-591) triggers the injection
-- template "havoc_twins" (mutator_monster_spawner_injection_templates.lua:8-43),
-- which rolls once (80 percent) and then spawns one renegade_twin_captain and one
-- renegade_twin_captain_two, aggroed, with their toughness reset.
--
-- This wraps that template: when the game's own roll spawns the pair, extra
-- pairs are spawned at the same spot with the exact same calls. So a pair that
-- did not spawn still does not spawn, and the group is always whole pairs.

local TEMPLATE_PATH = "scripts/settings/mutator/mutator_monster_spawner_injection/mutator_monster_spawner_injection_templates"
local BREED_NAMES = {
    "renegade_twin_captain",
    "renegade_twin_captain_two",
}

local function current_rank()
    local difficulty = Managers.state and Managers.state.difficulty
    local data = difficulty and difficulty:get_parsed_havoc_data()

    return data and tonumber(data.havoc_rank) or nil
end

local function pairs_for_rank(rank)
    if not rank or not mod:get("twin_packs") then
        return 1
    end

    local six_rank = mod:get("twin_six_rank") or 65
    local four_rank = mod:get("twin_four_rank") or 50

    if rank >= six_rank then
        return mod:get("twin_pairs_high") or 3
    elseif rank >= four_rank then
        return mod:get("twin_pairs_mid") or 2
    end

    return 1
end

-- Same spawn calls as the game's loop (injection templates lines 17-39).
local function spawn_extra_pair(spawn_position, ahead_target_unit, side_id)
    local minion_spawn_manager = Managers.state.minion_spawn

    for i = 1, #BREED_NAMES do
        local param_table = minion_spawn_manager:request_param_table()

        param_table.optional_aggro_state = "aggroed"
        param_table.optional_target_unit = ahead_target_unit

        local spawned_unit = minion_spawn_manager:spawn_minion(BREED_NAMES[i], spawn_position, Quaternion.identity(), side_id, param_table)
        local toughness_extension = spawned_unit and ScriptUnit.has_extension(spawned_unit, "toughness_system")

        if toughness_extension then
            toughness_extension:set_toughness_damage(0, true)
        end
    end
end

mod:hook_require(TEMPLATE_PATH, function (templates)
    local twins = templates and templates.havoc_twins

    if not twins or twins.__qiangiq_twin_packs then
        return
    end

    local original_spawn = twins.spawn

    twins.spawn = function (template, spawn_position, ahead_target_unit, side_id)
        local minion_spawn_manager = Managers.state and Managers.state.minion_spawn
        local before = minion_spawn_manager and minion_spawn_manager:total_allocated_num_enemies() or 0

        original_spawn(template, spawn_position, ahead_target_unit, side_id)

        local spawned = minion_spawn_manager and minion_spawn_manager:total_allocated_num_enemies() > before

        if not spawned then
            return
        end

        local rank = current_rank()
        local extra = pairs_for_rank(rank) - 1

        for _ = 1, extra do
            local ok, err = pcall(spawn_extra_pair, spawn_position, ahead_target_unit, side_id)

            if not ok then
                mod:error("extra twin pair skipped: %s", tostring(err))

                break
            end
        end

        if extra > 0 and mod:get("debug_log") then
            mod:info("Twins: rank %s, %d pairs spawned", tostring(rank), extra + 1)
        end
    end

    twins.__qiangiq_twin_packs = true
end)
