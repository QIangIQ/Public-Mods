local mod = get_mod("QIangIQsUltraHavoc")

-- --------------------------------------------------------------------------
-- Beyond-40 curve (local edit for the "impossible but gradual" H41-H80 setup)
-- --------------------------------------------------------------------------
--
-- Vanilla Havoc reaches its last modifier tier at rank 40. This file keeps every
-- vanilla Havoc value growing past that point, one "virtual tier" at a time,
-- using each value's OWN vanilla step size:
--
--     step  = (tier 5 value - tier 1 value) / (number of tiers - 1)
--     value = current value + step * (rank - 40) / ranks_per_step
--
-- The tier values are the game's, from scripts/settings/havoc_settings.lua
-- (modifier_templates, lines 105-429) and scripts/settings/buff/havoc_buff_templates.lua
-- (lines 2171-2596). The growth is continuous per rank, so every rank is a
-- little harder than the last, with no jumps.
--
-- The only numbers not taken from the game are the safety limits (min/max),
-- which stop a value from crossing into nonsense (negative ammo, no maximum
-- health, more than 100% permanent damage). They are marked LIMIT below.

local extension = {}

local BASE_RANK = 40

-- Numeric Havoc modifiers, read through GameModeExtensionHavoc.get_modifier_value.
-- tiers = the game's own values per tier (havoc_settings.lua).
local NUMERIC = {
	modify_elite_health = { tiers = { 0.1, 0.15, 0.2, 0.25, 0.5 } },
	modify_special_health = { tiers = { 0.1, 0.15, 0.2, 0.25, 0.5 } },
	modify_monster_health = { tiers = { 0.1, 0.2, 0.3, 0.4, 0.7 } },
	add_num_monsters = { tiers = { 1, 1, 2, 3, 3 }, integer = true },
	modify_horde_health = { tiers = { 0.1, 0.15, 0.2, 0.25, 0.3 } },
	modify_horde_hit_mass = { tiers = { 0.4, 0.8, 1, 1.5, 1.7 } },
	add_max_alive_specials = { tiers = { 2, 3, 4, 5, 6 }, integer = true },
	add_more_elites = { tiers = { 0.15, 0.35, 0.5, 0.75, 1 } },
	add_more_ogryns = { tiers = { 0.15, 0.25, 0.45, 0.65, 0.8 } },
	ammo_pickup_modifier = { tiers = { 0.85, 0.65, 0.5, 0.45, 0.4 }, min = 0.05, min_setting = "limit_ammo_floor", min_scale = 0.01 }, -- LIMIT (slider)
	horde_spawn_rate_modifier = { tiers = { 0.2, 0.4, 0.6, 0.8, 1, 1.2, 1.4 } },
	terror_event_point_modifier = { tiers = { 0.3, 0.4, 0.5, 0.6, 0.85 } },
	melee_minion_power_level_modifier = { tiers = { 0.1, 0.2, 0.3, 0.4, 0.5 } },
}

-- Buff-based Havoc modifiers. New buff templates would need network lookup
-- entries, so instead the stat values inside the game's existing tier buffs are
-- raised for the mission and restored afterwards. Every tier of a family gets
-- the same increase, so whatever tier SoloPlay picked keeps growing too.
local BUFF_FAMILIES = {
	{
		growth = "grow_melee_attack_speed",
		names = { "havoc_melee_attack_speed_01", "havoc_melee_attack_speed_02", "havoc_melee_attack_speed_03", "havoc_melee_attack_speed_04", "havoc_melee_attack_speed_05" },
		stats = { melee_attack_speed = { tiers = { 0.2, 0.35, 0.5, 0.75, 1 } } },
	},
	{
		growth = "grow_ranged_attack_speed",
		names = { "havoc_ranged_attack_speed_01", "havoc_ranged_attack_speed_02", "havoc_ranged_attack_speed_03", "havoc_ranged_attack_speed_04", "havoc_ranged_attack_speed_05" },
		stats = {
			ranged_attack_speed = { tiers = { 0.1, 0.15, 0.2, 0.25, 0.3 } },
			minion_num_shots_modifier = { tiers = { 1.25, 1.5, 1.75, 2, 2.25 } },
		},
	},
	{
		growth = "grow_melee_permanent_damage",
		names = { "havoc_melee_permanent_damage_01", "havoc_melee_permanent_damage_02", "havoc_melee_permanent_damage_03", "havoc_melee_permanent_damage_04", "havoc_melee_permanent_damage_05" },
		stats = { permanent_damage_ratio = { tiers = { 0.1, 0.15, 0.2, 0.25, 0.3 }, max = 1, max_setting = "limit_permanent_damage", max_scale = 0.01 } }, -- LIMIT (slider)
	},
	{
		growth = "grow_toughness",
		names = { "havoc_toughness_modifier_1", "havoc_toughness_modifier_2", "havoc_toughness_modifier_3", "havoc_toughness_modifier_4", "havoc_toughness_modifier_5" },
		stats = { toughness = { tiers = { -10, -15, -30, -40, -45 }, min = -90, min_setting = "limit_toughness", min_scale = -1 } }, -- LIMIT (slider)
	},
	{
		growth = "grow_toughness_regen",
		names = { "havoc_toughness_regen_modifier_1", "havoc_toughness_regen_modifier_2", "havoc_toughness_regen_modifier_3", "havoc_toughness_regen_modifier_4", "havoc_toughness_regen_modifier_5" },
		stats = { toughness_regen_rate_modifier = { tiers = { -0.15, -0.2, -0.3, -0.4, -0.5 }, min = -1, min_setting = "limit_toughness_regen", min_scale = -0.01 } }, -- LIMIT (slider)
	},
	{
		growth = "grow_max_health",
		names = { "havoc_health_modifier_1", "havoc_health_modifier_2", "havoc_health_modifier_3", "havoc_health_modifier_4", "havoc_health_modifier_5" },
		stats = { max_health_modifier = { tiers = { -0.15, -0.2, -0.25, -0.3, -0.35 }, min = -0.9, min_setting = "limit_max_health", min_scale = -0.01 } }, -- LIMIT (slider)
	},
	{
		growth = "grow_vent_speed",
		names = { "havoc_vent_speed_reduction_1", "havoc_vent_speed_reduction_2", "havoc_vent_speed_reduction_3", "havoc_vent_speed_reduction_4", "havoc_vent_speed_reduction_5" },
		stats = { vent_warp_charge_speed = { tiers = { 1.15, 1.35, 1.5, 1.75, 1.85 } } },
	},
}

local function step_of(entry)
	local tiers = entry.tiers

	return (tiers[#tiers] - tiers[1]) / (#tiers - 1)
end

-- Slider: how fast one value grows past rank 40, in percent of its vanilla
-- step (100 = the game's own tier step, 0 = frozen at the rank-40 value).
local function growth(setting_id)
	local value = setting_id and mod:get(setting_id)

	if type(value) ~= "number" then
		return 1
	end

	return math.max(value, 0) / 100
end

-- Limits come from sliders when one is set up for the entry (min_setting /
-- max_setting, converted with *_scale); the numbers in the tables are the
-- fallbacks.
local function limit(entry, key)
	local setting_id = entry[key .. "_setting"]
	local value = setting_id and mod:get(setting_id)

	if type(value) == "number" then
		return value * entry[key .. "_scale"]
	end

	return entry[key]
end

local function clamp(entry, value)
	local minimum = limit(entry, "min")
	local maximum = limit(entry, "max")

	if minimum and value < minimum then
		value = minimum
	end

	if maximum and value > maximum then
		value = maximum
	end

	return value
end

--- Virtual tiers past rank 40 (fractional, grows every rank).
-- @param rank number
-- @return number
function extension.steps(rank)
	if not mod:get("extend_vanilla") then
		return 0
	end

	local levels = (tonumber(rank) or 0) - BASE_RANK

	if levels <= 0 then
		return 0
	end

	local per_step = mod:get("ranks_per_step")

	if type(per_step) ~= "number" or per_step < 1 then
		per_step = 5
	end

	return levels / per_step
end

--- Extend one numeric Havoc modifier. Values the mission does not use (nil)
-- stay nil, so modifiers switched off in SoloPlay remain off.
-- @param name string
-- @param value number|nil value the game returned
-- @param rank number
-- @return number|nil
function extension.numeric(name, value, rank)
	local entry = NUMERIC[name]

	if not entry or type(value) ~= "number" then
		return value
	end

	local steps = extension.steps(rank)

	if steps <= 0 then
		return value
	end

	local extended = clamp(entry, value + step_of(entry) * growth("grow_" .. name) * steps)

	if entry.integer then
		extended = math.floor(extended)
	end

	return extended
end

-- Original stat values, captured once per template so repeated missions never
-- stack on top of an already raised value.
local originals = {}
local applied_rank

local function buff_templates()
	local ok, templates = pcall(require, "scripts/settings/buff/havoc_buff_templates")

	return ok and templates or nil
end

--- Raise the tier buffs for this mission's rank (idempotent).
-- @param rank number
function extension.apply_buffs(rank)
	local templates = buff_templates()

	if not templates then
		return
	end

	local steps = extension.steps(rank)

	for _, family in ipairs(BUFF_FAMILIES) do
		for _, template_name in ipairs(family.names) do
			local template = templates[template_name]
			local stat_buffs = template and template.stat_buffs

			if stat_buffs then
				local saved = originals[template_name]

				if not saved then
					saved = {}

					for stat, value in pairs(stat_buffs) do
						saved[stat] = value
					end

					originals[template_name] = saved
				end

				for stat, entry in pairs(family.stats) do
					local original = saved[stat]

					if type(original) == "number" then
						stat_buffs[stat] = steps > 0 and clamp(entry, original + step_of(entry) * growth(family.growth) * steps) or original
					end
				end
			end
		end
	end

	applied_rank = steps > 0 and rank or nil
end

--- Put every tier buff back to the game's values.
function extension.restore_buffs()
	local templates = buff_templates()

	if not templates then
		return
	end

	for template_name, saved in pairs(originals) do
		local template = templates[template_name]
		local stat_buffs = template and template.stat_buffs

		if stat_buffs then
			for stat, value in pairs(saved) do
				stat_buffs[stat] = value
			end
		end
	end

	applied_rank = nil
end

--- @return number|nil rank the buffs are currently raised for
function extension.applied_rank()
	return applied_rank
end

extension.NUMERIC = NUMERIC
extension.BUFF_FAMILIES = BUFF_FAMILIES

return extension
