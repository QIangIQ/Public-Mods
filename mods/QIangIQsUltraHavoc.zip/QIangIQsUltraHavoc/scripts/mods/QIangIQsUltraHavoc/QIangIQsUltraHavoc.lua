local mod = get_mod("QIangIQsUltraHavoc")

mod._info = {
    title   = "QIangIQsUltraHavoc",
    author  = "Huesos (original Havoc Ascension); QIangIQ edit",
    date    = "2026/09/19",
    version = "1.3.6-h80-maps",
}
mod:info("Version %s", mod._info.version)

-- Havoc ranks 41-80 for local and Realms games, on top of Solo Play.
-- (Local edit: extended from 41-50 to 41-80. Ranks 51-80 use the same
-- constant per-rank steps as 41-50; see scaling.compute. Only the rank
-- limits changed.)
--
-- The game's own Havoc curve stops at rank 40: HavocModifierConfig has 40
-- entries and every modifier already sits at its highest tier there. So the
-- extra ranks are not more modifier tiers - they are a separate, additive
-- reshaping of the mission that this mod applies on the host:
--
--   +2.5% enemy health      per rank above 40
--   -5%   trash             per rank (roamer riflemen/melee, poxwalker hordes)
--   +5%   elites            per rank (gunners, executors, berzerkers, ...)
--   +2.5% specials          per rank (snipers, grenadiers, hounds, ...)
--   +1.5% monstrosities     per rank (full strength and weakened)
--
-- plus up to two extra Havoc conditions on the mission, and an optional third
-- tier of "The Emperors Fading Light".
--
-- Two rules that stand on their own and work at any rank:
--   * Scab and Dreg Bruisers (the shield trash) can be taken out of the game.
--   * Power outages: a few times per mission the lights die for a couple of
--     minutes and toxic gas seeps out of the floor until they come back.
--
-- Nothing here changes the network protocol: the rank travels inside the
-- havoc_data string Solo Play already builds, and every spawn-side hook lives
-- in a manager the game only creates on the server. A Realms client without
-- this mod joins a rank-50 mission without noticing anything unusual.

mod.scaling = mod:io_dofile("QIangIQsUltraHavoc/scripts/mods/QIangIQsUltraHavoc/scaling")
mod.vanilla_extension = mod:io_dofile("QIangIQsUltraHavoc/scripts/mods/QIangIQsUltraHavoc/vanilla_extension")
mod.extra_conditions = mod:io_dofile("QIangIQsUltraHavoc/scripts/mods/QIangIQsUltraHavoc/extra_conditions")

local mission_setup = mod:io_dofile("QIangIQsUltraHavoc/scripts/mods/QIangIQsUltraHavoc/mission_setup")
local soloplay_view = mod:io_dofile("QIangIQsUltraHavoc/scripts/mods/QIangIQsUltraHavoc/soloplay_view")
local blackout = mod:io_dofile("QIangIQsUltraHavoc/scripts/mods/QIangIQsUltraHavoc/blackout")

mod:io_dofile("QIangIQsUltraHavoc/scripts/mods/QIangIQsUltraHavoc/spawn_scaling")
mod:io_dofile("QIangIQsUltraHavoc/scripts/mods/QIangIQsUltraHavoc/breed_filter")
mod:io_dofile("QIangIQsUltraHavoc/scripts/mods/QIangIQsUltraHavoc/twin_packs")
mod:io_dofile("QIangIQsUltraHavoc/scripts/mods/QIangIQsUltraHavoc/ammo_slider")
mod:io_dofile("QIangIQsUltraHavoc/scripts/mods/QIangIQsUltraHavoc/enemy_cap")
local havoc_map_pool = mod:io_dofile("QIangIQsUltraHavoc/scripts/mods/QIangIQsUltraHavoc/havoc_map_pool")
mod:io_dofile("QIangIQsUltraHavoc/scripts/mods/QIangIQsUltraHavoc/spawner_map_guard")
mod:io_dofile("QIangIQsUltraHavoc/scripts/mods/QIangIQsUltraHavoc/bot_overheat_guard")
local intro_release = mod:io_dofile("QIangIQsUltraHavoc/scripts/mods/QIangIQsUltraHavoc/intro_release")
mod:io_dofile("QIangIQsUltraHavoc/scripts/mods/QIangIQsUltraHavoc/train_timer")

mod.blackout = blackout

mod.on_all_mods_loaded = function ()
    mission_setup.install()
    havoc_map_pool.install()
end

-- Anything driven from update() runs every frame, so a single bad state would
-- otherwise fill the chat with the same error sixty times a second. Each part
-- gets a few strikes and is then left alone until the game restarts.
local MAX_UPDATE_FAILURES = 3
local update_failures = {}

--- @param key string identifies the part in the log and in the strike count
-- @param update function
-- @param on_give_up function|nil cleanup to run when the part is switched off
local function guarded_update(key, update, on_give_up)
    local failures = update_failures[key] or 0

    if failures > MAX_UPDATE_FAILURES then
        return
    end

    local ok, err = pcall(update)

    if ok then
        return
    end

    failures = failures + 1
    update_failures[key] = failures

    mod:error("%s update failed: %s", key, tostring(err))

    if failures > MAX_UPDATE_FAILURES then
        mod:error("%s switched off until the game restarts", key)

        if on_give_up then
            pcall(on_give_up)
        end
    end
end

mod.update = function (dt)
    guarded_update("Solo Play view", soloplay_view.update)
    guarded_update("Power outages", blackout.update, blackout.abort)
    guarded_update("Intro release", function () intro_release.update(dt) end)
end

-- Local edit: never leave raised tier buffs behind for the hub or a normal mission.
mod.on_game_state_changed = function (status, state)
    if state == "GameplayStateRun" and status == "exit" then
        mod.vanilla_extension.restore_buffs()
        intro_release.on_mission_end()
    elseif state == "GameplayStateRun" and status == "enter" then
        intro_release.on_mission_start()
    end
end

mod.on_disabled = function ()
    mod.vanilla_extension.restore_buffs()
end

mod.on_setting_changed = function (setting_id)
    if setting_id == "map_pool_operations" or setting_id == "operations_mode_check" then
        havoc_map_pool.invalidate()
    end

    if setting_id == "max_rank" then
        mission_setup.extend_modifier_config()
        soloplay_view.invalidate()
    end
end

--- Report what the mod would do, or is doing right now.
local function report()
    local scaling = mod.scaling
    local soloplay = get_mod("SoloPlay")

    -- Refreshes the cached mission state, so leaving a mission is noticed here
    -- too and the report does not describe the previous run.
    scaling.factors()

    local run = scaling.run
    local rank = run.data and run.data.havoc_rank
    local source = mod:localize("report_source_mission")

    if not rank then
        local override = mod:get("rank_override")

        if type(override) == "number" and override > 0 then
            rank = override
            source = mod:localize("report_source_override")
        elseif soloplay then
            rank = soloplay:get("havoc_difficulty")
            source = mod:localize("report_source_slider")
        end

        rank = math.clamp(rank or scaling.BASE_RANK, 1, mission_setup.max_rank())
    end

    local factors = run.factors or scaling.compute(rank)

    mod:echo("%s", mod:localize("report_rank", mod._info.version, tostring(rank), source))

    -- The list the tactical overlay will walk. More than four slots is a crash
    -- waiting for the first Tab press, so it is worth saying out loud.
    local circumstances = run.data and run.data.circumstances

    if circumstances then
        local key = #circumstances > 4 and "report_conditions_over" or "report_conditions"

        mod:echo("%s", mod:localize(key, #circumstances, table.concat(circumstances, ", ")))
    end

    if not factors.active then
        mod:echo("%s", mod:localize("report_inactive"))

        return
    end

    mod:echo("%s", mod:localize(
        "report_factors",
        math.round(factors.hp * 100),
        math.round(factors.trash_cut * 100),
        math.round(factors.elite_up * 100),
        math.round(factors.special_up * 100),
        math.round(factors.boss_up * 100)
    ))
end

mod:command("ultra_havoc", mod:localize("command_description"), report)

mod:command("ultra_havoc_maps", "List the Havoc map pool", function ()
    havoc_map_pool.report()
end)

-- Ported from HavocAscension 2 (HavocAscension.lua:192-254, report_health).
-- Prints what the minions standing in the mission are actually worth: actual
-- max health against the difficulty manager's base, per breed. Host only -
-- minion_spawn exists on the server alone.
local function report_health()
    local state = Managers.state
    local minion_spawn = state and state.minion_spawn
    local difficulty = state and state.difficulty

    if not minion_spawn or not difficulty then
        mod:echo("%s", mod:localize("hp_not_hosting"))

        return
    end

    local ok, minions = pcall(minion_spawn.spawned_minions, minion_spawn)

    if not ok or type(minions) ~= "table" then
        mod:echo("%s", mod:localize("hp_not_hosting"))

        return
    end

    local seen, lines = {}, {}

    for i = 1, #minions do
        local unit = minions[i]

        if ALIVE[unit] then
            local unit_data = ScriptUnit.has_extension(unit, "unit_data_system")
            local health_extension = ScriptUnit.has_extension(unit, "health_system")
            local breed = unit_data and unit_data:breed()
            local name = breed and breed.name

            if name and health_extension and not seen[name] then
                local base = difficulty:get_minion_max_health(name)
                local actual = health_extension:max_health()

                seen[name] = true

                if base and base > 0 then
                    lines[#lines + 1] = string.format("%s %d/%d (x%.2f)", name, actual, base, actual / base)
                else
                    lines[#lines + 1] = string.format("%s %d", name, actual)
                end
            end
        end
    end

    if #lines == 0 then
        mod:echo("%s", mod:localize("hp_nothing_alive"))

        return
    end

    mod:echo("%s", mod:localize("hp_report", table.concat(lines, ", ")))
end

mod:command("ultra_havoc_hp", mod:localize("command_hp_description"), report_health)

mod:command("ultra_havoc_release_intro", mod:localize("command_release_intro_description"), function ()
    intro_release.command()
end)
