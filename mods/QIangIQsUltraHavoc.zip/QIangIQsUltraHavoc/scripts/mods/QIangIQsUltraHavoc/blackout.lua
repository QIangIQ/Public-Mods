local mod = get_mod("QIangIQsUltraHavoc")

local LiquidArea = require("scripts/extension_systems/liquid_area/utilities/liquid_area")
local LiquidAreaTemplates = require("scripts/settings/liquid_area/liquid_area_templates")

local blackout = {}

-- Power outage: a few times per mission the level's lights die for a couple of
-- minutes and toxic gas starts seeping out of the floor. When the lights come
-- back the gas stops.
--
-- Lights: LightControllerExtension:set_enabled(false, false) is the same path a
-- level uses for its own scripted blackouts (LightController.disable_lights) -
-- on the server it also sends rpc_light_controller_set_enabled to every client,
-- so Realms guests see the same darkness. This kills the level's controllable
-- lights, which is what the "Lights Out" theme switches off through light
-- groups; baked lighting, emissive materials and skyboxes stay as they are, so
-- it is a blackout, not a byte-identical copy of Power Supply Interruption.
--
-- Gas: LiquidArea.try_create spawns the same networked liquid unit the toxic
-- gas circumstance uses for its clouds, so it damages and replicates like
-- vanilla pox gas - it just is not tied to the level's placed gas vents.

-- Game modes an outage may happen in. An allow list rather than a block list:
-- the Mourningstar, the Psykhanium and the prologue also run locally with a
-- pacing manager, and a mode name this list has never heard of is far more
-- likely to be another of those than a real mission.
local MISSION_GAME_MODES = {
    coop_complete_objective = true,
    survival = true,
    expedition = true,
}

-- Lights toggled per frame. A level holds hundreds of light units and each one
-- costs an RPC, so the switch is spread over a few frames; it also reads as the
-- lights dying in a wave rather than all at once.
local LIGHTS_PER_FRAME = 25

local GAS_WAVE_INTERVAL = 8
local GAS_MIN_DISTANCE = 5
local GAS_MAX_DISTANCE = 18

-- Seconds before the first outage and between outages. Not exposed: the useful
-- knobs are how many outages happen and how long they last.
local FIRST_DELAY_RANGE = { 90, 240 }
local GAP_RANGE = { 150, 420 }

-- Local edit: the timings above are the defaults of sliders now.
local function setting_number(setting_id, default)
    local value = mod:get(setting_id)

    return type(value) == "number" and value or default
end

local function setting_range(min_id, max_id, defaults)
    local low = setting_number(min_id, defaults[1])
    local high = math.max(setting_number(max_id, defaults[2]), low)

    return low, high
end

local run = {
    mission = nil,
    events_left = 0,
    next_at = nil,
    ends_at = nil,
    switched = {},
    cursor = 0,
    restoring = false,
    gas_units = {},
    next_gas_at = 0,
    failed = false,
}
blackout.run = run

--- Reset everything without touching the world (used when a mission ends).
local function forget()
    run.mission = nil
    run.events_left = 0
    run.next_at = nil
    run.ends_at = nil
    run.switched = {}
    run.cursor = 0
    run.restoring = false
    run.gas_units = {}
    run.next_gas_at = 0
    run.failed = false
end

--- The game mode manager, when we are hosting an actual mission.
-- @return table|nil
local function hosting_mission()
    local state = Managers.state

    -- Managers.state.pacing only exists on the server (gameplay_init_step_managers).
    if not state or not state.pacing or not state.game_mode or not state.extension then
        return nil
    end

    if not MISSION_GAME_MODES[state.game_mode:game_mode_name()] then
        return nil
    end

    -- Managers and timer come from different gameplay init steps, and the timer
    -- is dropped before the managers on the way out, so there are frames on
    -- both ends where the mission looks live but "gameplay" does not exist.
    -- TimeManager:time indexes the timer without checking.
    if not Managers.time or not Managers.time:has_timer("gameplay") then
        return nil
    end

    return state.game_mode
end

--- @return table|nil the light controller system, nil if unavailable
local function light_system()
    local extension_manager = Managers.state and Managers.state.extension

    if not extension_manager then
        return nil
    end

    local ok, system = pcall(extension_manager.system, extension_manager, "light_controller_system")

    if not ok or not system or not system.unit_to_extension_map then
        return nil
    end

    return system
end

--- Collect the level lights that are currently on.
-- Units are stored rather than extensions: a destructible lamp can be removed
-- mid-blackout, and the map is the only thing that knows it is gone.
local function collect_lit_units(system)
    local units = {}

    for unit, extension in pairs(system:unit_to_extension_map()) do
        if extension.is_enabled and extension:is_enabled() then
            units[#units + 1] = unit
        end
    end

    return units
end

--- Toggle a slice of the snapshot, one frame's worth.
-- @return boolean whether the whole snapshot has been processed
local function process_lights()
    local system = light_system()

    if not system then
        run.cursor = #run.switched

        return true
    end

    local map = system:unit_to_extension_map()
    local is_enabled = run.restoring
    local last = math.min(run.cursor + setting_number("blackout_lights_per_frame", LIGHTS_PER_FRAME), #run.switched)

    for i = run.cursor + 1, last do
        local unit = run.switched[i]
        local extension = map[unit]

        if extension and ALIVE[unit] then
            local is_deterministic = false
            local ok, err = pcall(extension.set_enabled, extension, is_enabled, is_deterministic)

            if not ok and not run.failed then
                run.failed = true

                mod:error("Could not switch a level light: %s", tostring(err))
            end
        end
    end

    run.cursor = last

    return last >= #run.switched
end

--- Drop gas patches that already died on their own.
local function prune_gas()
    local units = run.gas_units

    for i = #units, 1, -1 do
        if not ALIVE[units[i]] then
            table.remove(units, i)
        end
    end
end

--- Seed a few gas patches around the players.
local function spawn_gas_wave()
    if not mod:get("blackout_gas") then
        return
    end

    local nav_mesh_manager = Managers.state.nav_mesh
    local nav_world = nav_mesh_manager and nav_mesh_manager:nav_world()
    local template = LiquidAreaTemplates.toxic_gas

    if not nav_world or not template then
        return
    end

    prune_gas()

    local limit = mod:get("gas_limit") or 6

    if #run.gas_units >= limit then
        return
    end

    -- Vector3 values live in the engine's per-frame temp buffer, which is
    -- rewound around system updates (Script.set_temp_byte_count in
    -- extension_manager.lua). A vector held in POSITION_LOOKUP can therefore be
    -- dead memory by the time a mod update callback runs - it is still
    -- userdata, it is just no longer a Vector3, and arithmetic on it throws.
    -- Ask the unit for its position instead: that allocates a fresh one here.
    local units = {}

    for _, player in pairs(Managers.player and Managers.player:players() or {}) do
        local player_unit = player.player_unit

        if player_unit and ALIVE[player_unit] and Unit.alive(player_unit) then
            units[#units + 1] = player_unit
        end
    end

    if #units == 0 then
        return
    end

    local per_wave = math.min(mod:get("gas_per_wave") or 2, limit - #run.gas_units)
    local max_liquid = mod:get("gas_patch_size") or 20

    for _ = 1, per_wave do
        local origin = Unit.world_position(units[math.random(1, #units)], 1)
        local angle = math.random() * math.pi * 2
        local distance = math.random_range(setting_range("gas_distance_min", "gas_distance_max", { GAS_MIN_DISTANCE, GAS_MAX_DISTANCE }))
        local position = Vector3(
            Vector3.x(origin) + math.cos(angle) * distance,
            Vector3.y(origin) + math.sin(angle) * distance,
            Vector3.z(origin)
        )
        local not_on_other_liquids = true
        local ok, unit = pcall(LiquidArea.try_create, position, Vector3(0, 0, 1), nav_world, template, nil, max_liquid, not_on_other_liquids)

        if ok and unit then
            run.gas_units[#run.gas_units + 1] = unit
        elseif not ok and not run.failed then
            run.failed = true

            mod:error("Could not create a gas patch: %s", tostring(unit))
        end
    end
end

--- Remove every gas patch this mod created.
local function clear_gas()
    local unit_spawner = Managers.state and Managers.state.unit_spawner

    if unit_spawner then
        for i = 1, #run.gas_units do
            local unit = run.gas_units[i]

            if ALIVE[unit] then
                pcall(unit_spawner.mark_for_deletion, unit_spawner, unit)
            end
        end
    end

    run.gas_units = {}
end

--- Put the level back the way we found it in one go.
-- Used when the option is switched off mid-mission: staggering the restore over
-- frames is pointless there, and leaving a level permanently dark is worse than
-- a one-frame burst of RPCs.
local function restore_now()
    local system = light_system()

    if system then
        local map = system:unit_to_extension_map()

        for i = 1, #run.switched do
            local unit = run.switched[i]
            local extension = map[unit]

            if extension and ALIVE[unit] then
                local is_deterministic = false

                pcall(extension.set_enabled, extension, true, is_deterministic)
            end
        end
    end

    clear_gas()
end

--- @param t number gameplay time
local function start_outage(t)
    local system = light_system()

    if not system then
        mod:warning("No light controller system in this mission - outage skipped")

        run.events_left = 0

        return
    end

    local minimum = mod:get("blackout_duration_min") or 120
    local maximum = math.max(mod:get("blackout_duration_max") or 300, minimum)

    run.switched = collect_lit_units(system)
    run.cursor = 0
    run.restoring = false
    run.ends_at = t + math.random_range(minimum, maximum)
    run.next_at = nil
    run.next_gas_at = t

    mod:info("Power outage: %d lights out for %d seconds", #run.switched, run.ends_at - t)

    if mod:get("announce") then
        mod:notify("%s", mod:localize("notify_blackout_start"))
    end
end

--- @param t number gameplay time
local function end_outage(t)
    run.cursor = 0
    run.restoring = true
    run.ends_at = nil

    clear_gas()

    run.events_left = run.events_left - 1

    if run.events_left > 0 then
        run.next_at = t + math.random_range(setting_range("blackout_gap_min", "blackout_gap_max", GAP_RANGE))
    end

    if mod:get("announce") then
        mod:notify("%s", mod:localize("notify_blackout_end"))
    end
end

--- Called every frame.
function blackout.update()
    if not mod:get("blackout_enabled") then
        if run.mission then
            -- Switched off in the middle of an outage: give the level its
            -- lights back instead of leaving it dark for the rest of the run.
            if hosting_mission() then
                restore_now()
            end

            forget()
        end

        return
    end

    local game_mode = hosting_mission()

    if not game_mode then
        if run.mission then
            forget()
        end

        return
    end

    local t = Managers.time and Managers.time:time("gameplay")

    if not t then
        return
    end

    if run.mission ~= game_mode then
        forget()

        run.mission = game_mode

        local minimum = mod:get("blackout_count_min") or 2
        local maximum = math.max(mod:get("blackout_count_max") or 4, minimum)

        run.events_left = math.random(minimum, maximum)
        run.next_at = t + math.random_range(setting_range("blackout_first_min", "blackout_first_max", FIRST_DELAY_RANGE))

        mod:info("Power outages this mission: %d, first at %d seconds", run.events_left, run.next_at)
    end

    if run.cursor < #run.switched then
        if process_lights() and run.restoring then
            run.switched = {}
            run.cursor = 0
            run.restoring = false
        end

        return
    end

    if run.ends_at then
        if t >= run.ends_at then
            end_outage(t)
        elseif t >= run.next_gas_at then
            run.next_gas_at = t + setting_number("gas_wave_interval", GAS_WAVE_INTERVAL)

            spawn_gas_wave()
        end

        return
    end

    if run.next_at and run.events_left > 0 and t >= run.next_at then
        start_outage(t)
    end
end

--- True while the lights are out.
function blackout.is_active()
    return run.ends_at ~= nil
end

--- Give the level back its lights and forget everything.
-- Called when update() has failed repeatedly and is about to be switched off
-- for the session, so a broken outage cannot leave a mission permanently dark.
function blackout.abort()
    if run.mission and hosting_mission() then
        restore_now()
    end

    forget()
end

return blackout
