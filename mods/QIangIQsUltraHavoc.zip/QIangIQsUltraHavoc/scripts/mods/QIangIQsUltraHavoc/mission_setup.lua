local mod = get_mod("QIangIQsUltraHavoc")
local scaling = mod.scaling

local CircumstanceTemplates = require("scripts/settings/circumstance/circumstance_templates")
local extra_conditions = mod.extra_conditions
local Havoc = require("scripts/utilities/havoc")
local HavocModifierConfig = require("scripts/settings/havoc/havoc_modifier_config")

local mission_setup = {}

-- Number of ranks the game itself defines modifiers for.
local VANILLA_RANKS = #HavocModifierConfig

-- Difficulty condition ("The Emperors Fading Light") per mod option value.
-- Tier III is not a game circumstance: it reuses tier II and adds extra levels
-- of this mod's own curve, so that Realms clients without the mod still parse
-- the mission the same way the host does.
local FADING_LIGHT_CIRCUMSTANCE = {
    ["1"] = "mutator_increased_difficulty",
    ["2"] = "mutator_highest_difficulty",
    ["3"] = "mutator_highest_difficulty",
}

local ALL_FADING_LIGHT_CIRCUMSTANCES = {
    mutator_increased_difficulty = true,
    mutator_highest_difficulty = true,
}

local EXTRA_CONDITION_SETTINGS = {
    "extra_condition_1",
    "extra_condition_2",
    "extra_condition_3",
    "extra_condition_4",
}

-- Hard ceiling, not a preference. Both UIs that list a Havoc mission's
-- conditions are built from exactly four widget slots - icon_01..icon_04 in
-- hud_element_tactical_overlay_definitions, havoc_circumstance_01..04 in the
-- lobby view - and both index them straight from the condition list. A fifth
-- condition is a nil style and a crash the moment anyone opens the tactical
-- overlay, on every machine in the session, not just the host's.
--
-- Vanilla never gets close: max_circumstances is 2, plus an optional theme and
-- an optional difficulty condition. The Local Game window already exposes all
-- four slots, so the four extra conditions below fill the ones left on "None"
-- and whatever is left over is handed to extra_conditions, which loads its
-- mutators into the mission directly - in play, just without an icon.
--
-- So the ceiling on conditions a mission *runs* is four plus however many of
-- the mod's own four found no slot; the ceiling on conditions it *lists* is
-- four, and that one is not negotiable.
local MAX_CIRCUMSTANCES = 4

--- Highest rank the mod is configured to allow.
-- @return number
function mission_setup.max_rank()
    local configured = mod:get("max_rank")

    if type(configured) ~= "number" or configured < scaling.BASE_RANK then
        return 80
    end

    return math.floor(configured)
end

--- Give ranks above 40 a modifier set, so the vanilla generator can be asked
-- about them. Rank 40 already sits at the maximum tier of every modifier, so
-- the extra ranks are copies of it; what makes them harder is this mod's own
-- scaling, not another modifier tier. Without this, SoloPlay crashes the moment
-- its rank slider passes 40, because HavocModifierConfig[41] is nil.
function mission_setup.extend_modifier_config()
    local top_rank = mission_setup.max_rank()
    local template = HavocModifierConfig[VANILLA_RANKS]

    if not template then
        return
    end

    for rank = VANILLA_RANKS + 1, top_rank do
        HavocModifierConfig[rank] = table.clone(template)
    end

    for rank = top_rank + 1, #HavocModifierConfig do
        HavocModifierConfig[rank] = nil
    end
end

--- Whether a circumstance can safely be added to a mission.
-- MutatorManager dereferences every circumstance in the havoc data without a
-- nil check, so an unknown name is a crash on mission load.
-- @param name string|nil
-- @return boolean
local function is_valid_circumstance(name)
    return type(name) == "string" and name ~= "" and name ~= "none" and CircumstanceTemplates[name] ~= nil
end

--- Rewrite the `havoc_data` string SoloPlay hands to the mechanism.
-- Format is `mission;rank;theme;faction;circumstances;modifiers;challenge;resistance`,
-- with circumstances and modifiers colon separated (see scripts/utilities/havoc.lua).
-- @param data string
-- @return string
function mission_setup.patch_havoc_data(data)
    -- string.split drops empty fields, which would shift every index when a
    -- mission has no circumstances at all; fixed_split keeps them.
    local fields = { string.fixed_split(data, ";") }

    if #fields < 8 then
        mod:warning("Unexpected havoc data layout, left untouched: %s", tostring(data))

        return data
    end

    local rank = tonumber(fields[2]) or scaling.BASE_RANK
    local override = mod:get("rank_override")

    if type(override) == "number" and override > 0 then
        rank = override
    end

    fields[2] = tostring(math.floor(math.clamp(rank, 1, mission_setup.max_rank())))

    local circumstances, seen = {}, {}
    local fading_light = mod:get("fading_light")
    local forced = FADING_LIGHT_CIRCUMSTANCE[fading_light]

    for _, name in ipairs(string.split(fields[5] or "", ":")) do
        local replaced_by_force = forced and ALL_FADING_LIGHT_CIRCUMSTANCES[name]

        if not seen[name] and not replaced_by_force and is_valid_circumstance(name) then
            seen[name] = true
            circumstances[#circumstances + 1] = name
        end
    end

    if forced and not seen[forced] and is_valid_circumstance(forced) then
        seen[forced] = true
        circumstances[#circumstances + 1] = forced
    end

    local dropped = {}

    for _, setting_id in ipairs(EXTRA_CONDITION_SETTINGS) do
        local name = mod:get(setting_id)

        if not seen[name] and is_valid_circumstance(name) then
            if #circumstances < MAX_CIRCUMSTANCES then
                seen[name] = true
                circumstances[#circumstances + 1] = name
            else
                dropped[#dropped + 1] = name
            end
        elseif type(name) == "string" and name ~= "none" and not CircumstanceTemplates[name] then
            mod:warning("Unknown circumstance %q in %s, skipped", tostring(name), setting_id)
        end
    end

    -- The window itself can hand us four already; anything the game generated
    -- beyond that would crash the same UIs, so it is cut here too.
    for i = #circumstances, MAX_CIRCUMSTANCES + 1, -1 do
        dropped[#dropped + 1] = circumstances[i]
        circumstances[i] = nil
    end

    -- No UI slot left, so these are pushed straight into the mission instead.
    extra_conditions.remember(dropped)

    if #dropped > 0 then
        mod:warning("Havoc shows at most %d conditions, applying without a slot: %s", MAX_CIRCUMSTANCES, table.concat(dropped, ", "))
        mod:notify("%s", mod:localize("notify_conditions_hidden", #dropped))
    end

    fields[5] = table.concat(circumstances, ":")

    return table.concat(fields, ";")
end

-- Safety net one level below the string. Whatever built the havoc data - an
-- older version of this mod, a session carried over, another mod - a mission
-- must never end up carrying more than four conditions, because the first Tab
-- press walks that list against four widget slots. Every machine parses the
-- data for itself, so this also covers a guest whose host lacks the mod.
mod:hook(Havoc, "parse_data", function (func, data)
    local parsed = func(data)
    local circumstances = parsed and parsed.circumstances

    if type(circumstances) == "table" and #circumstances > MAX_CIRCUMSTANCES then
        mod:warning("Mission carries %d conditions, trimming to %d to keep the tactical overlay alive",
            #circumstances, MAX_CIRCUMSTANCES)

        for i = #circumstances, MAX_CIRCUMSTANCES + 1, -1 do
            circumstances[i] = nil
        end
    end

    return parsed
end)

--- Hook SoloPlay so every local Havoc launch goes through patch_havoc_data.
-- SoloPlay builds the whole mission context in one function and it is the only
-- caller of it, so this is the single place a local Havoc mission is described.
-- @return boolean whether the hook was installed
function mission_setup.install()
    mission_setup.extend_modifier_config()

    local soloplay = get_mod("SoloPlay")

    if not soloplay or type(soloplay.gen_havoc_mission_context) ~= "function" then
        mod:warning("Solo Play was not found - local Havoc missions cannot be launched or extended without it")

        return false
    end

    mod:hook(soloplay, "gen_havoc_mission_context", function (func)
        local mission_context = func()

        if type(mission_context) == "table" and type(mission_context.havoc_data) == "string" then
            mission_context.havoc_data = mission_setup.patch_havoc_data(mission_context.havoc_data)
        end

        return mission_context
    end)

    return true
end

return mission_setup
