local mod = get_mod("QIangIQsUltraHavoc")

-- --------------------------------------------------------------------------
-- Game-wide enemy cap for pacing spawns
-- --------------------------------------------------------------------------
--
-- pacing_manager.lua:442-480: PacingManager.spawn_type_enabled refuses every
-- pacing spawn type (hordes, roamers, specials, monsters; terror events are
-- checked by their own path) once Managers.state.minion_spawn:
-- total_allocated_num_enemies() is above HARD_ALLOCATED_LIMIT = 145.
-- That limit is a file-local, so this replaces the function with the game's own
-- body, unchanged except that the limit comes from the slider. At the default
-- (145) it behaves exactly like the game.

local PacingManager = require("scripts/managers/pacing/pacing_manager")

local VANILLA_LIMIT = 145

mod:hook(PacingManager, "spawn_type_enabled", function (func, self, spawn_type)
    local limit = tonumber(mod:get("pacing_enemy_cap")) or VANILLA_LIMIT

    if limit == VANILLA_LIMIT then
        return func(self, spawn_type)
    end

    if self._disabled and spawn_type ~= "terror_events" then
        return false, "pacing_is_disabled"
    end

    local total_allocated_num_enemies = Managers.state.minion_spawn:total_allocated_num_enemies()

    if total_allocated_num_enemies > limit then
        return false, "Hard_allocated_limit_reached"
    end

    local challenge_rating_thresholds = self._challenge_rating_thresholds
    local challenge_rating_threshold = challenge_rating_thresholds[spawn_type]
    local total_challenge_rating = self._total_challenge_rating

    if challenge_rating_threshold and challenge_rating_threshold < total_challenge_rating then
        return false, "disabled_by_challenge_rating"
    end

    if self._paused_spawn_types[spawn_type] then
        return false, "paused"
    end

    if not self._allowed_spawn_types or not self._allowed_spawn_types[spawn_type] and not self._heat_pacing:active() then
        return false, "not_allowed"
    end

    if self._heat_pacing:active() then
        local current_heat_stage_settings = self._heat_pacing:current_stage_settings()
        local allowed_spawn_types = current_heat_stage_settings.allowed_spawn_types

        if not allowed_spawn_types[spawn_type] then
            return false, "disabled_by_heat_stage"
        end
    end

    return true
end)
