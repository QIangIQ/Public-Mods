# QIangIQsCustomModifierOne

Restores the unfinished purple-stimm splitting modifier from Darktide's Havoc
code ("Illusions" / "Warp rift") for **SoloPlay** offline games.

Affected enemies glow purple. When one dies it releases a small purple burst
and two lesser enemies appear beside it, already aggroed on its target.

## Install

1. Extract the `QIangIQsCustomModifierOne` folder into your `mods` folder.
2. Add `QIangIQsCustomModifierOne` to `mods/mod_load_order.txt`.
   * To also get **"Warp rift"** as a selectable condition in SoloPlay /
     Havoc Condition Manager, put it **above `SoloPlay`**. SoloPlay hides any
     condition whose mutators are missing when it loads.
   * For "Every SoloPlay mission" mode, the load order doesn't matter.
3. Requires SoloPlay. Works alongside Havoc Condition Manager and Havoc Enemy Director.

## Options

| Option | Default | What it does |
|---|---|---|
| Activation | Every SoloPlay mission | Every mission / only with the "Warp rift" condition / off. Applies from the next mission. |
| Split chance (%) | 100 | Chance that each eligible enemy spawns purple. 100 = every eligible enemy splits. |
| Chain splitting | On | On = the game's own behaviour: copies that can split again always do. Off = copies never split. |
| Allow monster and captain splits | Off | Beast of Nurgle, Daemonhost, Chaos Spawn, Plague Ogryn, renegade Captain. |
| Stop splitting above this many enemies | 240 | No copies are queued at or above this number alive + queued. |
| Purple gas burst on split | On | Off skips the purple/pink gas burst, its sound and tiny push when an enemy splits (optimization). Enemies still split. |
| Guard missing split effect | On | If the purple explosion particle isn't loaded, show nothing instead of crashing. |

## What splits into what

This is the game's own `TWIN_SPLIT_BREED_LIST`
(`scripts/settings/buff/mutator_buff_templates.lua`, lines 294–324). Each breed
on the left dies into **two** of the breed on the right. Only these breeds can split.

```
chaos_beast_of_nurgle  -> chaos_ogryn_bulwark      (monster option)
chaos_daemonhost       -> chaos_spawn              (monster option)
chaos_hound            -> chaos_hound_mutator
chaos_ogryn_bulwark    -> renegade_berzerker
chaos_ogryn_executor   -> renegade_executor
chaos_ogryn_gunner     -> renegade_gunner
chaos_plague_ogryn     -> chaos_ogryn_executor     (monster option)
chaos_poxwalker_bomber -> renegade_executor
chaos_spawn            -> cultist_mutant           (monster option)
cultist_assault        -> chaos_newly_infected
cultist_berzerker      -> cultist_melee
cultist_flamer         -> cultist_shocktrooper
cultist_grenadier      -> renegade_gunner
cultist_gunner         -> cultist_assault
cultist_melee          -> chaos_poxwalker
cultist_mutant         -> cultist_berzerker
cultist_shocktrooper   -> cultist_assault
renegade_assault       -> chaos_newly_infected
renegade_berzerker     -> renegade_melee
renegade_captain       -> chaos_daemonhost         (monster option)
renegade_executor      -> renegade_melee
renegade_flamer        -> renegade_shocktrooper
renegade_grenadier     -> renegade_gunner
renegade_gunner        -> renegade_rifleman
renegade_melee         -> chaos_newly_infected
renegade_netgunner     -> renegade_berzerker
renegade_rifleman      -> chaos_newly_infected
renegade_shocktrooper  -> renegade_assault
renegade_sniper        -> renegade_gunner
```

Chains end at `chaos_newly_infected`, `chaos_poxwalker` and `chaos_hound_mutator`.

## How it works

The split logic itself is not rewritten. The mod reconnects pieces that already
ship in the game and supplies the two definitions the game never provides.

**Used as-is from the game**
* Buff `mutator_stimmed_minion_purple`: `mutator_buff_templates.lua` 326–377 (split on death, purple eyes, explosion)
* Class `MutatorPurpleStimmed`: `mutator_purple_stimmed.lua` (spawn queue, aggroed copies)
* Explosion `purple_stimmed_explosion`: `minion_explosion_templates.lua` 367–392
* Per-breed chance roll `random_spawn_buff_templates`: `mutator_base.lua` `_on_minion_unit_spawned`

**Added, because the game references them but never defines them**
* Mutator `mutator_stimmed_minions_purple`: the buff looks it up at `mutator_buff_templates.lua` line 361. It is laid out like the game's own Havoc buff mutators (`mutator_havoc_templates.lua` 71–80).
* Mutator `mutator_duplicating_enemies`: loaded by circumstance `mutator_havoc_duplicating_enemies` ("Warp rift", `havoc_circumstance_template.lua` 71–83, title at `havoc_settings.lua` 1000–1003). It is a marker on `mutator_base`, like `mutator_single_twin`.

**Safety changes, following patterns from the uploaded mods**
* No split during mission cleanup, only on the server, and only on actual death. This follows SoloPlay's `_skip_stop_on_extension_destroyed` in `workarounds/havoc.lua`.
* Loads through the game's `load_mutator_from_name` after the other mutators load, like HavocConditionManager's `condition_compatibility.lua`.
* Particle guard scoped to the split only, adapted from ChaosWastesAtHome's `particle_guard.lua`.
* Gas toggle: skips only the `Explosion.create_explosion` call with `purple_stimmed_explosion` made by the split (`mutator_buff_templates.lua` line 372), after the copies are queued (line 364).
* The spawn queue can't overflow the game's 256-slot ring buffer (`mutator_purple_stimmed.lua` line 9). The enemy cap default of 240 is Havoc Enemy Director's default `total_cap`.

## Known limits

* The game's rule: an enemy only splits if the unit it was targeting is still alive (`mutator_buff_templates.lua` line 359). Enemies killed before they have a target don't split.
* Splitting only happens when you are the host (SoloPlay). It never runs in online games.
* This hasn't been tested in-game yet, only against the game's Lua with a mock harness.
