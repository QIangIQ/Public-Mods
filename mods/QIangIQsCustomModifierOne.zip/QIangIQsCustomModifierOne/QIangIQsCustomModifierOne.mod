return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsCustomModifierOne` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsCustomModifierOne", {
			mod_script       = "QIangIQsCustomModifierOne/scripts/mods/QIangIQsCustomModifierOne/QIangIQsCustomModifierOne",
			mod_data         = "QIangIQsCustomModifierOne/scripts/mods/QIangIQsCustomModifierOne/QIangIQsCustomModifierOne_data",
			mod_localization = "QIangIQsCustomModifierOne/scripts/mods/QIangIQsCustomModifierOne/QIangIQsCustomModifierOne_localization",
		})
	end,
	packages = {},
}
