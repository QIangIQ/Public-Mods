return {
	mod_name = {
		en = "QIangIQ's Custom Modifier One",
	},
	mod_description = {
		en = "Restores the unfinished purple-stimm \"Illusions\" / \"Warp rift\" modifier for SoloPlay. Affected enemies glow purple and split into two lesser enemies when they die. Changes to chance and monster options apply immediately; activation mode applies from the next mission.",
	},
	activation_mode = {
		en = "Activation",
	},
	activation_mode_description = {
		en = "Every SoloPlay mission: always active in your own offline games.\nWarp rift condition only: active only when the \"Warp rift\" condition is selected (needs this mod above SoloPlay in the load order).\nOff: never active.",
	},
	activation_always = {
		en = "Every SoloPlay mission",
	},
	activation_warp_rift = {
		en = "Warp rift condition only",
	},
	activation_off = {
		en = "Off",
	},
	split_chance = {
		en = "Split chance (percent)",
	},
	split_chance_description = {
		en = "Chance for each eligible enemy to spawn purple-stimmed. 100 = every eligible enemy splits on death.",
	},
	chain_splits = {
		en = "Chain splitting",
	},
	chain_splits_description = {
		en = "On (game's own behaviour): copies that can split again always do, down the chain until poxwalkers, newly infected or mutator hounds.\nOff: copies never split.",
	},
	allow_monster_splits = {
		en = "Allow monster and captain splits",
	},
	allow_monster_splits_description = {
		en = "Lets Beast of Nurgle, Daemonhost, Chaos Spawn, Plague Ogryn and renegade Captains split (Captain splits into two Daemonhosts). Heavy; off by default.",
	},
	max_enemies = {
		en = "Stop splitting above this many enemies",
	},
	max_enemies_description = {
		en = "No new copies are queued while this many enemies are alive or queued.",
	},
	split_death_gas = {
		en = "Purple gas burst on split",
	},
	split_death_gas_description = {
		en = "On (game's own behaviour): each split plays the purple/pink gas burst, its gas sound and a tiny push.\nOff (optimization): the burst is skipped; enemies still split. Applies immediately.",
	},
	guard_split_vfx = {
		en = "Guard missing split effect",
	},
	guard_split_vfx_description = {
		en = "If the purple explosion effect is not loaded in the current mission, render nothing instead of crashing.",
	},
}
