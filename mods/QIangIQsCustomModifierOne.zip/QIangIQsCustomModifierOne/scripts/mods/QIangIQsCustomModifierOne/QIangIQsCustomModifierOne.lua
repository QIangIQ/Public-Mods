-- QIangIQsCustomModifierOne
--
-- Reconnects the pieces of the unfinished "Illusions" / "Warp rift" Havoc
-- modifier that already ship in the game, and fills in the two definitions
-- the public source never provides. Nothing here re-implements the split
-- itself: the native buff and the native mutator class do the work.
--
-- Shipped in the game (used as-is):
--   buff   mutator_stimmed_minion_purple        scripts/settings/buff/mutator_buff_templates.lua:326-377
--   class  MutatorPurpleStimmed                 scripts/managers/mutator/mutators/mutator_purple_stimmed.lua
--   fx     purple_stimmed_explosion             scripts/settings/damage/explosion_templates/minion_explosion_templates.lua:367
--   roll   random_spawn_buff_templates          scripts/managers/mutator/mutators/mutator_base.lua (_on_minion_unit_spawned)
--
-- Missing in the game (defined here):
--   mutator "mutator_stimmed_minions_purple"    looked up by the buff at mutator_buff_templates.lua:361
--   mutator "mutator_duplicating_enemies"       loaded by circumstance "mutator_havoc_duplicating_enemies"
--                                               (havoc_circumstance_template.lua:71-83, UI title "Warp rift")

local mod = get_mod("QIangIQsCustomModifierOne")

-- SoloPlay is looked up when needed, not at load: this mod is meant to load
-- ABOVE SoloPlay (so SoloPlay sees the Warp rift mutator when it builds its
-- condition list), and at that point get_mod("SoloPlay") is still nil.
local function soloplay()
	return get_mod("SoloPlay")
end

mod.on_all_mods_loaded = function ()
	if not soloplay() then
		mod:error("SoloPlay is required and must be enabled")
	end
end

local BuffSettings = require("scripts/settings/buff/buff_settings")
local MatchmakingConstants = require("scripts/settings/network/matchmaking_constants")
local MutatorManager = require("scripts/managers/mutator/mutator_manager")
local MutatorPurpleStimmed = require("scripts/managers/mutator/mutators/mutator_purple_stimmed")
local MutatorTemplates = require("scripts/settings/mutator/mutator_templates")
local HOST_TYPES = MatchmakingConstants.HOST_TYPES

local PURPLE_MUTATOR = "mutator_stimmed_minions_purple"
local PURPLE_BUFF = "mutator_stimmed_minion_purple"
local WARP_RIFT_MUTATOR = "mutator_duplicating_enemies"
-- MINION_QUEUE_RING_BUFFER_SIZE in mutator_purple_stimmed.lua:9. The ring
-- buffer has no overflow check, so writing past it overwrites unread spawns.
local SPAWN_QUEUE_SIZE = 256
local DEFAULT_MAX_ENEMIES = 1000 -- raised from 240 (HavocEnemyDirector planner.lua default total_cap)

-- Keys of TWIN_SPLIT_BREED_LIST, mutator_buff_templates.lua:294-324. The table
-- is local to that file, so it is copied here. Only these breeds can split;
-- the buff's stop_func does nothing for any other breed.
local SPLIT_SOURCES = {
	"chaos_beast_of_nurgle",
	"chaos_daemonhost",
	"chaos_hound",
	"chaos_ogryn_bulwark",
	"chaos_ogryn_executor",
	"chaos_ogryn_gunner",
	"chaos_plague_ogryn",
	"chaos_poxwalker_bomber",
	"chaos_spawn",
	"cultist_assault",
	"cultist_berzerker",
	"cultist_flamer",
	"cultist_grenadier",
	"cultist_gunner",
	"cultist_melee",
	"cultist_mutant",
	"cultist_shocktrooper",
	"renegade_assault",
	"renegade_berzerker",
	"renegade_captain",
	"renegade_executor",
	"renegade_flamer",
	"renegade_grenadier",
	"renegade_gunner",
	"renegade_melee",
	"renegade_netgunner",
	"renegade_rifleman",
	"renegade_shocktrooper",
	"renegade_sniper",
}

-- Entries whose split produces a monster or that are a monster/captain
-- themselves (lines 295, 296, 301, 303, 314). Off by default.
local MONSTER_SOURCES = {
	chaos_beast_of_nurgle = true,
	chaos_daemonhost = true,
	chaos_plague_ogryn = true,
	chaos_spawn = true,
	renegade_captain = true,
}

-- Shared by reference with the mutator template, so option changes apply to
-- the running mission: MutatorBase reads breed_chances on every spawn.
local breed_chances = {}

local function refresh_breed_chances()
	table.clear(breed_chances)

	local chance = math.min(math.max((mod:get("split_chance") or 100) / 100, 0), 1)
	local allow_monsters = mod:get("allow_monster_splits")

	for _, breed_name in ipairs(SPLIT_SOURCES) do
		if allow_monsters or not MONSTER_SOURCES[breed_name] then
			breed_chances[breed_name] = chance
		end
	end
end

refresh_breed_chances()

-- Same shape as the native Havoc buff mutators (e.g. mutator_bolstering_minions,
-- mutator_havoc_templates.lua:71-80), on the class the buff expects.
local purple_template = {
	name = PURPLE_MUTATOR,
	class = "scripts/managers/mutator/mutators/mutator_purple_stimmed",
	random_spawn_buff_templates = {
		buffs = {
			PURPLE_BUFF,
		},
		ignored_buff_keyword = BuffSettings.keywords.stimmed,
		breed_chances = breed_chances,
	},
}

-- Marker only, like mutator_single_twin (mutator_modify_pacing_templates.lua:724-726).
-- Its presence tells the loader below that "Warp rift" was selected.
local warp_rift_template = {
	name = WARP_RIFT_MUTATOR,
	class = "scripts/managers/mutator/mutators/mutator_base",
}

-- Never replace a definition the game itself may ship in a later patch.
mod:hook_require("scripts/settings/mutator/mutator_templates", function (templates)
	if templates[PURPLE_MUTATOR] == nil then
		templates[PURPLE_MUTATOR] = purple_template
	end

	if templates[WARP_RIFT_MUTATOR] == nil then
		templates[WARP_RIFT_MUTATOR] = warp_rift_template
	end
end)

-- How the split is reached in the game:
--   The purple buff has keyword despawn_on_death (mutator_buff_templates.lua:332).
--   MinionDeathManager.die (minion_death_manager.lua:65-75) sees that keyword and
--   calls despawn_minion instead of killing the unit, so the unit is deleted
--   while still "alive". The buff's stop_func then only runs from extension
--   teardown (extension_destroyed = true, buff.lua:843-848,
--   buff_extension_base.lua:137-142), by which time the blackboard it reads may
--   already be gone. The same teardown also happens at mission cleanup and on
--   any other despawn, where a split must NOT happen.
-- So the native stop_func is run once, from MinionDeathManager.die, before the
-- despawn, while the unit, its position and its blackboard are intact. All
-- other stop_func calls for units already handled become no-ops.
local split_handled = setmetatable({}, { __mode = "k" })
local native_purple_stop_func

local function run_native_split(unit)
	split_handled[unit] = true

	local mutator_manager = Managers.state and Managers.state.mutator

	-- The native function indexes this mutator without a nil check (line 361-364).
	if not native_purple_stop_func or not mutator_manager or not mutator_manager:mutator(PURPLE_MUTATOR) then
		return
	end

	mod._in_split = true

	local ok, err = pcall(native_purple_stop_func, {}, { unit = unit, is_server = true }, false)

	mod._in_split = false

	if not ok then
		mod:error("split skipped: %s", tostring(err))
	end
end

mod:hook_require("scripts/settings/buff/mutator_buff_templates", function (templates)
	local template = templates[PURPLE_BUFF]

	if not template or template.__warp_rift_modified then
		return
	end

	native_purple_stop_func = template.stop_func

	template.stop_func = function (template_data, template_context, extension_destroyed)
		local unit = template_context.unit

		-- Already split at death, or torn down without dying (cleanup, other
		-- despawns): nothing to do. Same intent as SoloPlay's
		-- _skip_stop_on_extension_destroyed (workarounds/havoc.lua).
		if split_handled[unit] or extension_destroyed or not template_context.is_server then
			return
		end

		-- Normal death path, if the keyword was ever absent: health reached zero
		-- and conditional_exit_func (line 378-384) ended the buff.
		if not HEALTH_ALIVE[unit] then
			run_native_split(unit)
		end
	end
	template.__warp_rift_modified = true
end)

local MinionDeathManager = require("scripts/managers/minion/minion_death_manager")

mod:hook(MinionDeathManager, "die", function (func, self, unit, ...)
	if self._is_server and not split_handled[unit] then
		local blackboard = BLACKBOARDS[unit]
		local death_component = blackboard and blackboard.death
		local buff_extension = ScriptUnit.has_extension(unit, "buff_system")

		if blackboard and not (death_component and death_component.is_dead) and buff_extension
			and buff_extension:has_buff_using_buff_template(PURPLE_BUFF) then
			run_native_split(unit)
		end
	end

	return func(self, unit, ...)
end)

-- Same singleplay test as SoloPlay's is_soloplay (SoloPlay.lua:28-41). The
-- game-mode part of it may not exist yet while mutators load, so fall back to
-- the host type alone in that window.
local function soloplay_authority()
	-- Never in the Mourningstar hub.
	local game_mode_manager = Managers.state and Managers.state.game_mode
	if game_mode_manager and game_mode_manager:game_mode_name() == "hub" then
		return false
	end

	-- Hosting a Realms game: the session host type is HOST_TYPES.player there
	-- (Realms connection_host.lua:641-642), so SoloPlay's singleplay test fails.
	-- Same host test as realms_loadout talents/session.lua:31-40.
	local session = Managers.multiplayer_session
	if session and session:host_type() == HOST_TYPES.player then
		local connection = Managers.connection

		return connection ~= nil and connection:is_host() and true or false
	end

	local solo = soloplay()

	if not solo then
		return false
	end

	if solo.has_local_gameplay_authority then
		return solo.has_local_gameplay_authority() and true or false
	end

	if Managers.state and Managers.state.game_mode then
		return solo.is_soloplay()
	end

	local session = Managers.multiplayer_session

	return session ~= nil and session:host_type() == HOST_TYPES.singleplay
end

-- Load once per mission through the native single-mutator loader, after the
-- circumstance mutators (same approach as HavocConditionManager
-- condition_compatibility.lua:41-59).
mod:hook_safe(MutatorManager, "_load_mutators", function (self)
	if not self._is_server or self._mutators[PURPLE_MUTATOR] or MutatorTemplates[PURPLE_MUTATOR] ~= purple_template then
		return
	end

	local mode = mod:get("activation_mode") or "always"

	if mode == "off" then
		return
	end

	local warp_rift_selected = self._mutators[WARP_RIFT_MUTATOR] ~= nil
	local wanted = warp_rift_selected or mode == "always" and soloplay_authority()

	if not wanted then
		return
	end

	refresh_breed_chances()
	self:load_mutator_from_name(PURPLE_MUTATOR)
	mod:info("loaded %s (%s)", PURPLE_MUTATOR, warp_rift_selected and "Warp rift condition" or "always on")
end)

local function is_ours(mutator)
	return mutator._template == purple_template
end

-- Mark spawns made by the split queue, so copies can skip the chance roll
-- when chain splitting is off. Flag handling follows HavocEnemyDirector
-- runtime.lua emit(): always reset, then rethrow.
mod:hook(MutatorPurpleStimmed, "update", function (func, self, dt, t)
	if not is_ours(self) then
		return func(self, dt, t)
	end

	mod._spawning_copy = true

	local ok, err = pcall(func, self, dt, t)

	mod._spawning_copy = false

	if not ok then
		error(err, 0)
	end
end)

mod:hook(MutatorPurpleStimmed, "_on_minion_unit_spawned", function (func, self, unit)
	if is_ours(self) and mod._spawning_copy and not mod:get("chain_splits") then
		return
	end

	return func(self, unit)
end)

mod:hook(MutatorPurpleStimmed, "add_split_spawn", function (func, self, position, rotation, breed_name, buff_to_add, target_unit)
	if not is_ours(self) then
		return func(self, position, rotation, breed_name, buff_to_add, target_unit)
	end

	local queued = self._spawn_queue_size or 0

	if queued >= SPAWN_QUEUE_SIZE - 1 then
		return
	end

	local minion_spawn_manager = Managers.state and Managers.state.minion_spawn
	local max_enemies = mod:get("max_enemies") or DEFAULT_MAX_ENEMIES

	if minion_spawn_manager and minion_spawn_manager:total_allocated_num_enemies() + queued >= max_enemies then
		return
	end

	if not mod:get("chain_splits") then
		buff_to_add = nil
	end

	return func(self, position, rotation, breed_name, buff_to_add, target_unit)
end)

-- Optional purple/pink gas burst on split (optimization toggle).
-- The native split (mutator_buff_templates.lua:337-377) calls
-- Explosion.create_explosion with ExplosionTemplates.purple_stimmed_explosion
-- once per copy (line 372) and ignores the return value. That template
-- (minion_explosion_templates.lua:367-385) carries the purple gas vfx, the
-- grenade-gas sfx and a 0.2 radius, power level 0 chaos_hound_push.
-- With the setting off, only that call, only during a split, is skipped;
-- the copies are still queued by add_split_spawn before it (line 364).
local Explosion = require("scripts/utilities/attack/explosion")
local ExplosionTemplates = require("scripts/settings/damage/explosion_templates")

mod:hook(Explosion, "create_explosion", function (func, world, physics_world, position, rotation, unit, explosion_template, ...)
	if mod._in_split and mod:get("split_death_gas") == false
		and explosion_template == ExplosionTemplates.purple_stimmed_explosion then
		return
	end

	return func(world, physics_world, position, rotation, unit, explosion_template, ...)
end)

-- The split explosion uses content/fx/particles/enemies/purple_stimmed_explosion
-- (minion_explosion_templates.lua:386), which may not be loaded outside Havoc.
-- Scoped version of ChaosWastesAtHome particle_guard.lua: only while a split
-- runs, a missing effect renders nothing instead of crashing.
local world_api = rawget(_G, "World")
local missing_effects = {}

if world_api and world_api.create_particles then
	mod:hook(world_api, "create_particles", function (func, world, effect_name, ...)
		if not mod._in_split or not mod:get("guard_split_vfx") then
			return func(world, effect_name, ...)
		end

		local ok, id = pcall(func, world, effect_name, ...)

		if ok then
			return id
		end

		mod._swallowed_particles = true

		if not missing_effects[effect_name] then
			missing_effects[effect_name] = true

			mod:info("particle effect not loaded, rendering nothing: %s", tostring(effect_name))
		end

		return nil
	end)

	local FALSE_ON_NIL = {
		are_particles_playing = true,
		has_particles_material = true,
	}
	local ID_FUNCTIONS = {
		"stop_spawning_particles",
		"destroy_particles",
		"link_particles",
		"move_particles",
		"set_particles_variable",
		"set_particles_material_vector",
		"set_particles_material_scalar",
		"are_particles_playing",
		"set_particles_use_custom_fov",
		"set_particles_emit_rate_multiplier",
		"set_particles_surface_effect",
		"has_particles_material",
		"set_particles_life_time",
	}

	for _, name in ipairs(ID_FUNCTIONS) do
		if world_api[name] then
			local returns_false = FALSE_ON_NIL[name]

			mod:hook(world_api, name, function (func, world, id, ...)
				if id == nil and mod._swallowed_particles then
					if returns_false then
						return false
					end

					return nil
				end

				return func(world, id, ...)
			end)
		end
	end
end

mod.on_setting_changed = function (setting_id)
	refresh_breed_chances()
end

mod.on_game_state_changed = function (status, state)
	if state == "GameplayStateRun" and status == "exit" then
		mod._in_split = false
		mod._spawning_copy = false
	end
end
