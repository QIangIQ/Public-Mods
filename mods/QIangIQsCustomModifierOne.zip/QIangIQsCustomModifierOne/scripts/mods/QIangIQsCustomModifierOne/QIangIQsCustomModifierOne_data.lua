local mod = get_mod("QIangIQsCustomModifierOne")

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			{
				setting_id    = "activation_mode",
				type          = "dropdown",
				default_value = "always",
				options = {
					{ text = "activation_always",    value = "always" },
					{ text = "activation_warp_rift", value = "warp_rift" },
					{ text = "activation_off",       value = "off" },
				},
			},
			{
				setting_id    = "split_chance",
				type          = "numeric",
				default_value = 100,
				range         = { 0, 100 },
			},
			{
				setting_id    = "chain_splits",
				type          = "checkbox",
				default_value = true,
			},
			{
				setting_id    = "allow_monster_splits",
				type          = "checkbox",
				default_value = false,
			},
			{
				setting_id    = "max_enemies",
				type          = "numeric",
				default_value = 1000,
				range         = { 20, 1000 },
			},
			{
				setting_id    = "split_death_gas",
				type          = "checkbox",
				default_value = true,
			},
			{
				setting_id    = "guard_split_vfx",
				type          = "checkbox",
				default_value = true,
			},
		},
	},
}
