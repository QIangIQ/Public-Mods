return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsOraxia` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsOraxia", {
            mod_script = "QIangIQsOraxia/scripts/mods/QIangIQsOraxia/QIangIQsOraxia",
            mod_data = "QIangIQsOraxia/scripts/mods/QIangIQsOraxia/QIangIQsOraxia_data",
            mod_localization = "QIangIQsOraxia/scripts/mods/QIangIQsOraxia/QIangIQsOraxia_localization",
        })
    end,
    version = "1.0.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
