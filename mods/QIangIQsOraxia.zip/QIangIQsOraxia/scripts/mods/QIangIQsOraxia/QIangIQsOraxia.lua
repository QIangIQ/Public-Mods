-- QIangIQ's Oraxia: swaps the local player's body for a Custom Assets unit
-- (third person, first-person arms, and menu / operative-select previews).
-- Author: QIangIQ
local mod = get_mod("QIangIQsOraxia")

-- Cross-client sync ---------------------------------------------------------------
-- QIangIQsModelSync publishes which QIangIQ replacer mods a player has on, with their options, through
-- Vox Manifold (the transport Dio's Wardrobe shares outfits with). No asset data is sent: every client shows
-- the model from its own installed files. While another player's unit is worked on, sync_ctx holds that
-- player's options and opt() answers from them; for my own unit opt() is mod:get().
local SYNC_KEY = "oraxia"
local SYNC_BOOLS = { "model_enabled", "hide_body", "part_legs", "spider_walls", "spider_curl", "float_form", "float_legs_still" }
local SYNC_DEFAULTS = { model_enabled = false, hide_body = true, part_legs = true, spider_walls = true, spider_curl = true, float_form = false, float_legs_still = true }
local SYNC_VALUES = { "spider_scale", "spider_distance", "spider_step_time", "spider_snappiness", "spider_min_ground", "spider_cocoon_time", "spider_foot_depth", "float_height", "float_lean", "float_leg_tuck", "spider_front_reach", "spider_front_spread", "spider_back_reach" }
local SYNC_LAYOUT = #SYNC_BOOLS * 100 + #SYNC_VALUES -- a peer on another version of this mod is not decoded
local sync_ctx = nil
local sync_known = setmetatable({}, { __mode = "k" })   -- other players' extensions this mod has shown something on
local sync_all = setmetatable({}, { __mode = "k" })     -- every visual loadout extension seen
local sync_decoded = setmetatable({}, { __mode = "k" }) -- published array -> options table
local SYNC_FALSE = { __index = function() return false end }
local SYNC_OFF = setmetatable({}, SYNC_FALSE)           -- "everything off": removes what was shown
local sync_extra_import = nil

local function opt(key)
    if sync_ctx then
        return sync_ctx[key]
    end
    return mod:get(key)
end

local function sync_api()
    local hub = get_mod("QIangIQsModelSync")
    return hub and hub.api
end

local function sync_me()
    local players = Managers.player
    if not players then
        return nil
    end
    local ok, player = pcall(players.local_player_safe, players, 1)
    return ok and player or nil
end

-- published array { layout, checkbox bits, value, value, ... [, extra] } -> options by setting id
local function sync_decode(raw)
    local t = sync_decoded[raw]
    if t ~= nil then
        return t
    end
    t = false
    if type(raw) == "table" and raw[1] == SYNC_LAYOUT then
        t = setmetatable({}, SYNC_FALSE)
        local mask = tonumber(raw[2]) or 0
        for i = 1, #SYNC_BOOLS do
            t[SYNC_BOOLS[i]] = mask % 2 >= 1
            mask = math.floor(mask / 2)
        end
        for i = 1, #SYNC_VALUES do
            local v = raw[2 + i]
            if v ~= nil then
                t[SYNC_VALUES[i]] = v
            end
        end
        if sync_extra_import then
            sync_extra_import(t, raw[3 + #SYNC_VALUES])
        end
    end
    sync_decoded[raw] = t
    return t
end

-- whose options apply to this extension: nil = mine, a table = that player's (SYNC_OFF when they publish
-- nothing for this mod)
local function sync_owner(ext)
    sync_all[ext] = true
    local player = ext._player
    if player == nil or player == sync_me() then
        return nil
    end
    local api = sync_api()
    local raw = api and api.peer(SYNC_KEY, player)
    local state = raw and sync_decode(raw)
    if state then
        sync_known[ext] = true
        return state
    end
    return SYNC_OFF
end

-- my own unit, or another player's unit this mod is (or was) showing something on
local function sync_shown(ext)
    local player = ext._player
    return player ~= nil and (player == sync_me() or sync_known[ext] == true)
end

local function sync_pack(...)
    return { n = select("#", ...), ... }
end

-- runs a hook body with the options of the extension's owner
local function sync_wrap(fn, ext_index)
    return function(...)
        local ext = select(ext_index, ...)
        local previous = sync_ctx
        sync_ctx = sync_owner(ext)
        local results = sync_pack(pcall(fn, ...))
        sync_ctx = previous
        if not results[1] then
            error(results[2], 0)
        end
        return unpack(results, 2, results.n)
    end
end

-- The same hook on my own unit's extension and on other players' (husk) extensions. While the mods load, the
-- classes do not exist yet: CLASS.<name> is then only the name and DMF delays the hook ("needs to be delayed"
-- in the log), so the husk class cannot be inspected here. Its methods are taken from
-- player_husk_visual_loadout_extension.lua instead.
local SYNC_HUSK_METHODS = { init = true, update = true, _update_item_visibility = true, destroy = true }

local function vl_hook_safe(method, fn)
    mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, method, sync_wrap(fn, 1))
    if SYNC_HUSK_METHODS[method] then
        mod:hook_safe(CLASS.PlayerHuskVisualLoadoutExtension, method, sync_wrap(fn, 1))
    end
end

local function vl_hook(method, fn)
    mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, method, sync_wrap(fn, 2))
    if SYNC_HUSK_METHODS[method] then
        mod:hook(CLASS.PlayerHuskVisualLoadoutExtension, method, sync_wrap(fn, 2))
    elseif method == "_unequip_item_from_slot" then
        -- a husk has no _unequip_item_from_slot: its unequip arrives as rpc_player_unequip_item_from_slot
        -- (self, channel_id, go_id, slot_id), slot name = NetworkLookup.player_inventory_slot_names[slot_id]
        -- (player_husk_visual_loadout_extension.lua)
        mod:hook(CLASS.PlayerHuskVisualLoadoutExtension, "rpc_player_unequip_item_from_slot", sync_wrap(function(func, self, channel_id, go_id, slot_id, ...)
            local NetworkLookup = require("scripts/network_lookup/network_lookup")
            local slot_name = NetworkLookup.player_inventory_slot_names[slot_id]
            return fn(function()
                return func(self, channel_id, go_id, slot_id)
            end, self, slot_name)
        end, 2))
    end
end
-- ----------------------------------------------------------------------------------

mod.AUTHOR = "QIangIQ"

-- Every piece is its own Custom Assets unit: Custom Assets id = <Mod>:<Custom folder>, unit name =
-- the --asset-path used at compile time. The base is the bare body; each clothing part is a separate
-- unit (and a separate first-person arms unit when it covers the arms) that is spawned and linked the
-- same way, so parts can be switched on and off one by one.
local BODY = "oraxia"
local ARMS = "oraxia_arms"
local function asset_id(name)
    return "QIangIQsOraxia:" .. name
end
local function unit_name(name)
    return "content/mods/qiangiq_oraxia/" .. name
end
local BODY_UNIT = unit_name(BODY)
local ARMS_UNIT = unit_name(ARMS)
-- { id (setting "part_<id>"), body = Custom folder of the third-person unit, arms = folder of the first-person unit or nil,
--   default = false for parts that start switched off, needs = id of a part that must be on as well,
--   glow = slider setting for the part's emissive material, glow_default, color = colour setting,
--   setting = id of another part whose on/off option this part shares (it has no option of its own),
--   when / unless = a checkbox setting that must be on / off for the part to be shown,
--   flame = true for a part whose emissive material takes the flame colour (see apply_part_glow) }
local PARTS = {
    { id = "legs", fp_visible = true, body = "oraxia_legs", glow = "gold_glow_level", glow_default = 46 },
}
local PART_BY_ID = {}
for _, part in ipairs(PARTS) do
    PART_BY_ID[part.id] = part
end
local function part_on(part)
    local on = opt("part_" .. (part.setting or part.id))
    if on == nil then
        on = part.default ~= false
    end
    if on and part.when and not opt(part.when) then
        return false
    end
    if on and part.unless and opt(part.unless) then
        return false
    end
    if on and part.needs and PART_BY_ID[part.needs] then
        return part_on(PART_BY_ID[part.needs])
    end
    return on and true or false
end

-- QIangIQ character swap mods: only one model is shown at a time. Turning one on (option,
-- keybind or chat command) switches the others off through their saved "model_enabled" setting
-- (DMFMod:set / DMFMod:get, dmf/modules/core/settings.lua).
local CHARACTER_MODS = { "QIangIQsAnubis", "QIangIQsDominanceAnubis", "QIangIQsEmber", "QIangIQsCitlali", "QIangIQsYvonne", "QIangIQsKulveTaroth", "QIangIQsNavia", "QIangIQsZhuangFangyi", "QIangIQsArknightsEmber", "QIangIQsHornet", "QIangIQsAlienQueen", "QIangIQsAnkha", "QIangIQsValkyrHeirloom", "QIangIQsMesaHeirloom", "QIangIQsCitrinePrime", "QIangIQsOctaviaPrime", "QIangIQsOraxia", "QIangIQsSevagothPrime", "QIangIQsVorunaPrime", "QIangIQsWispPrime", "QIangIQsYareliPrime", "QIangIQsMarieGemini", "QIangIQsEleanorGemini", "QIangIQsJade" }

-- The model is fitted to one skeleton (human); bodies of the other breed use a different
-- skeleton, so they are left alone. Breed names as keyed in player_character_constants.lua
-- (human / ogryn).
local EXCLUDED_BREEDS = { ogryn = true }

-- player_unit_visual_loadout_extension.lua:205-206 keeps the breed on the extension itself
-- (self._static_profile_properties.breed), so it is known even when this mod is loaded mid-game.
local function ext_breed(ext)
    local props = ext._static_profile_properties
    return (props and props.breed) or ext.__qiangiq_breed
end

local custom_assets = nil
local ready = {} -- [Custom folder] = true once its package is loaded
local function model_on()
    return opt("model_enabled") ~= false
end

-- extensions / UI spawners we have touched (weak keys)
local tracked = setmetatable({}, { __mode = "k" })
local tracked_ui = setmetatable({}, { __mode = "k" })

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function local_player()
    local players = Managers.player
    if not players then
        return nil
    end
    local ok, player = pcall(players.local_player_safe, players, 1)
    return ok and player or nil
end

-- slot_body_* / slot_gear_* hold the body parts and cosmetics; weapons live in other slots
local function hide_body_slots(slots, key)
    if not slots then
        return
    end
    local attachments_key = key == "unit_1p" and "attachments_by_unit_1p" or "attachments_by_unit_3p"
    for slot_name, slot in pairs(slots) do
        if string.find(slot_name, "^slot_body_") or string.find(slot_name, "^slot_gear_") then
            local unit = slot[key]
            if unit_ok(unit) then
                Unit.set_unit_visibility(unit, false, true)
                local attachments = slot[attachments_key] and slot[attachments_key][unit]
                if attachments then
                    for i = 1, #attachments do
                        if unit_ok(attachments[i]) then
                            Unit.set_unit_visibility(attachments[i], false, true)
                        end
                    end
                end
            end
        end
    end
end

-- In-game player unit -----------------------------------------------------------

local function is_local_human(ext)
    return sync_shown(ext)
end

local function delete_unit(unit)
    if unit_ok(unit) then
        local unit_spawner = Managers.state and Managers.state.unit_spawner
        if unit_spawner then
            unit_spawner:mark_for_deletion(unit)
        end
    end
end

local function delete_all(units)
    if units then
        for id, unit in pairs(units) do
            delete_unit(unit)
            units[id] = nil
        end
    end
end

local FLOAT_RELEASE -- set by the floating form code below
local function despawn(ext)
    if FLOAT_RELEASE then
        FLOAT_RELEASE(ext)
    end
    delete_unit(ext.__qiangiq_oraxia_unit)
    delete_unit(ext.__qiangiq_oraxia_arms)
    ext.__qiangiq_oraxia_unit = nil
    ext.__qiangiq_oraxia_arms = nil
    delete_all(ext.__qiangiq_oraxia_parts)
    delete_all(ext.__qiangiq_oraxia_part_arms)
end

local FP_CUSTOM_FOV = false

-- same spawn + link pattern the game uses for gear (visual_loadout_customization.lua)
local function spawn_linked(world, parent, unit_name, is_first_person)
    local unit_spawner = Managers.state and Managers.state.unit_spawner
    if not (world and unit_spawner and unit_ok(parent)) then
        return nil
    end
    local unit = unit_spawner:spawn_unit(unit_name, Unit.world_pose(parent, 1))
    if not unit then
        return nil
    end
    if is_first_person then
        Unit.set_unit_culling(unit, false)
    end
    if is_first_person and FP_CUSTOM_FOV then
        -- 1P items are drawn with the first-person FOV (equipment_component.lua:359). Without this flag the
        -- arms are drawn with the world FOV while the weapon uses the 1P one, so the weapon shows beside the hand.
        Unit.set_shader_pass_flag_for_meshes_in_unit_and_childs(unit, "custom_fov", true)
    end
    World.link_unit(world, unit, 1, parent, 1, World.LINK_MODE_NODE_NAME)
    return unit
end

-- Glow slider for the model's emissive layer (nil = the model has none). The layer's material is the
-- compiler's PBR emissive one, whose brightness is its scalar variable "intensity"
-- (pbr_emissive_profile.cpp, id32 0x32f447e5 = "intensity"); set the way the game applies scalar
-- material overrides (visual_loadout_customization.lua:516, Unit.set_scalar_for_materials(unit, name, value, true)).
local GLOW_SETTING = "gold_glow_level"
local GLOW_DEFAULT = 46 -- %

-- Glow colour for the model's emissive materials (emissive_color, id32 0xc985395a; same call as the parts'
-- colour option below, visual_loadout_customization.lua:534). The exporter bakes emissive_color as (1, 1, 1)
-- when an emission texture is connected, so white = the model as built. Only written while the option is on;
-- turning it off writes white back once.
local GLOW_COLOR = false -- true = the model has the "glow_color_custom" + r / g / b options
-- the colour the emissive material was built with (written back when the option is turned off)
local GLOW_BASE = { 1, 1, 1 }
local colored = setmetatable({}, { __mode = "k" })

local function custom_glow_color()
    if GLOW_COLOR and opt("glow_color_custom") then
        local r = math.max(opt("glow_color_r") or GLOW_BASE[1], 0)
        local g = math.max(opt("glow_color_g") or GLOW_BASE[2], 0)
        local b = math.max(opt("glow_color_b") or GLOW_BASE[3], 0)
        return r, g, b
    end
    return nil
end

local function apply_glow_color(unit)
    local r, g, b = custom_glow_color()
    if r then
        Unit.set_vector3_for_materials(unit, "emissive_color", Vector3(r, g, b), true)
        colored[unit] = true
    elseif colored[unit] then
        Unit.set_vector3_for_materials(unit, "emissive_color", Vector3(GLOW_BASE[1], GLOW_BASE[2], GLOW_BASE[3]), true)
        colored[unit] = nil
    end
end

-- Brightness settings are 0-100 %. The engine's response to "intensity" is far from linear: in game 0.1 -> 3 went
-- from barely lit to full and 5 -> 10 looked the same, so 0-100 % maps onto 0-3 along a power curve fitted to
-- those two points (1 % ~ 0.1, 100 % = 3).
local GLOW_MAX = 3
local GLOW_CURVE = 0.74

local function glow_intensity(pct)
    local t = math.max(math.min(pct or 0, 100), 0) / 100
    return GLOW_MAX * t ^ GLOW_CURVE
end

local function apply_glow(unit)
    if GLOW_SETTING and unit_ok(unit) then
        Unit.set_scalar_for_materials(unit, "intensity", glow_intensity(opt(GLOW_SETTING) or GLOW_DEFAULT), true)
        apply_glow_color(unit)
    end
end

-- Flame parts: their emission picture is greyscale, so emissive_color is the flame's colour. It is the custom glow
-- colour while that option is on, otherwise the mean colour of the model's own flame pictures.
local FLAME_COLOR = { 1, 1, 1 }

-- Emissive colours offered for parts with a colour option (emissive_color = id32 0xc985395a in the same
-- material; a Vector3 set like visual_loadout_customization.lua:534, Unit.set_vector3_for_materials).
local GLOW_COLORS = {
    cyan = { 0, 0.85, 1 },
    pink = { 1, 0.08, 0.55 },
    green = { 0.15, 1, 0.2 },
    gold = { 1, 0.69, 0.06 },
    purple = { 0.55, 0.15, 1 },
    red = { 1, 0.04, 0.04 },
    white = { 1, 1, 1 },
}

local function apply_part_glow(part, unit)
    if part.glow and unit_ok(unit) then
        Unit.set_scalar_for_materials(unit, "intensity", glow_intensity(opt(part.glow) or part.glow_default), true)
        local c = part.color and GLOW_COLORS[opt(part.color) or "cyan"]
        if c then
            Unit.set_vector3_for_materials(unit, "emissive_color", Vector3(c[1], c[2], c[3]), true)
        end
        if part.flame then
            local r, g, b = custom_glow_color()
            if not r then
                r, g, b = FLAME_COLOR[1], FLAME_COLOR[2], FLAME_COLOR[3]
            end
            Unit.set_vector3_for_materials(unit, "emissive_color", Vector3(r, g, b), true)
        end
    end
end

-- Tail size (nil = not offered). Scales are set on the tail's own nodes, the call the game uses to size a
-- unit (ui_profile_spawner.lua:1722, Unit.set_local_scale(unit, node, Vector3)). A bone runs along its
-- local Z (see the physics notes), so X/Y is thickness and Z is length; children inherit it.
local TAIL = nil

local function apply_tail(unit)
    if not (TAIL and unit_ok(unit) and Unit.has_node(unit, TAIL.thick) and Unit.has_node(unit, TAIL.long)) then
        return
    end
    local on = opt("tail_custom")
    local thick = on and math.max(opt("tail_thickness") or 1, 0.1) or 1
    local long = on and math.max(opt("tail_length") or 1, 0.1) or 1
    Unit.set_local_scale(unit, Unit.node(unit, TAIL.thick), Vector3(thick, thick, 1))
    Unit.set_local_scale(unit, Unit.node(unit, TAIL.long), Vector3(1, 1, long))
end

-- Body proportions: a uniform scale on the model's own soft-body bones (the physics bones the breasts, butt and
-- thighs are weighted to), set with the same call as the tail size. Their children and every vertex weighted to
-- them scale around the bone's head. Clothing parts carry the same bones and are scaled the same way.
-- { setting, { bones } }
local SHAPE = {
}

local function apply_shape(unit)
    if not unit_ok(unit) then
        return
    end
    for _, row in ipairs(SHAPE) do
        local v = math.max(opt(row[1]) or 1, 0.1)
        local scale = Vector3(v, v, v)
        for _, name in ipairs(row[2]) do
            if Unit.has_node(unit, name) then
                Unit.set_local_scale(unit, Unit.node(unit, name), scale)
            end
        end
    end
end

local function apply_shape_all(body, parts)
    apply_shape(body)
    if parts then
        for _, unit in pairs(parts) do
            apply_shape(unit)
            apply_tail(unit) -- a tail that is its own part carries the tail bones
        end
    end
end

-- Her own legs in the form: the thigh / shin / foot directions of her real ability-4 hover idle, decoded from the
-- Warframe extract (wfanim.py; bone mapping j_*upleg <- LEG1, j_*leg <- LEG2, j_*foot <- LEG3 as wf_retarget.py)
-- baked from Powers/Oraxia/GroundIdleRifle_anim.fbx (her ability-4 hover idle, 1.90 s loop), 8 keys:
-- l / r: thigh, shin and foot directions in the body frame { right, forward, up } of the root;
-- la / ra: upper arm, forearm and hand (wrist -> middle knuckle) directions in the torso frame { right, forward, up }
-- (up = hips -> chest, right = left -> right shoulder); hip = hip height offset (m) around its mean
local FLOAT_POSE = { period = 1.900, keys = {
    { hip = -0.070,
      l = { { -0.032, 0.696, -0.718 }, { 0.060, -0.720, -0.692 }, { 0.008, -0.515, -0.857 } },
      r = { { 0.165, 0.240, -0.957 }, { -0.182, -0.320, -0.930 }, { -0.060, -0.212, -0.976 } },
      la = { { 0.166, 0.950, -0.266 }, { 0.655, 0.537, 0.531 }, { 0.872, 0.486, -0.054 } },
      ra = { { 0.650, 0.210, -0.731 }, { -0.631, 0.425, 0.649 }, { -0.004, 0.994, 0.105 } },
    },
    { hip = -0.049,
      l = { { -0.012, 0.674, -0.739 }, { 0.031, -0.762, -0.646 }, { -0.019, -0.518, -0.855 } },
      r = { { 0.151, 0.230, -0.961 }, { -0.151, -0.363, -0.920 }, { 0.023, -0.281, -0.959 } },
      la = { { 0.169, 0.925, -0.341 }, { 0.652, 0.574, 0.495 }, { 0.872, 0.485, -0.064 } },
      ra = { { 0.622, 0.120, -0.774 }, { -0.600, 0.529, 0.600 }, { -0.005, 0.997, 0.082 } },
    },
    { hip = 0.004,
      l = { { 0.023, 0.592, -0.805 }, { -0.013, -0.774, -0.633 }, { -0.082, -0.528, -0.845 } },
      r = { { 0.121, 0.188, -0.975 }, { -0.148, -0.334, -0.931 }, { 0.047, -0.286, -0.957 } },
      la = { { 0.174, 0.861, -0.478 }, { 0.632, 0.662, 0.404 }, { 0.872, 0.483, -0.084 } },
      ra = { { 0.554, -0.025, -0.832 }, { -0.539, 0.697, 0.473 }, { -0.007, 0.999, 0.034 } },
    },
    { hip = 0.055,
      l = { { 0.040, 0.492, -0.869 }, { -0.049, -0.766, -0.641 }, { -0.108, -0.508, -0.854 } },
      r = { { 0.085, 0.123, -0.989 }, { -0.176, -0.274, -0.945 }, { 0.021, -0.264, -0.964 } },
      la = { { 0.189, 0.812, -0.552 }, { 0.597, 0.739, 0.313 }, { 0.871, 0.480, -0.106 } },
      ra = { { 0.469, -0.092, -0.879 }, { -0.464, 0.789, 0.402 }, { -0.009, 1.000, -0.016 } },
    },
    { hip = 0.071,
      l = { { 0.039, 0.432, -0.901 }, { -0.052, -0.750, -0.660 }, { -0.073, -0.476, -0.876 } },
      r = { { 0.059, 0.084, -0.995 }, { -0.202, -0.227, -0.953 }, { -0.020, -0.233, -0.972 } },
      la = { { 0.204, 0.808, -0.552 }, { 0.581, 0.744, 0.330 }, { 0.871, 0.478, -0.117 } },
      ra = { { 0.413, -0.086, -0.907 }, { -0.403, 0.783, 0.474 }, { -0.010, 0.999, -0.040 } },
    },
    { hip = 0.043,
      l = { { 0.035, 0.452, -0.891 }, { -0.017, -0.732, -0.681 }, { -0.058, -0.467, -0.882 } },
      r = { { 0.059, 0.103, -0.993 }, { -0.202, -0.229, -0.952 }, { -0.045, -0.213, -0.976 } },
      la = { { 0.213, 0.851, -0.480 }, { 0.587, 0.668, 0.457 }, { 0.871, 0.480, -0.108 } },
      ra = { { 0.431, 0.022, -0.902 }, { -0.408, 0.638, 0.653 }, { -0.009, 1.000, -0.020 } },
    },
    { hip = -0.004,
      l = { { 0.020, 0.536, -0.844 }, { 0.026, -0.710, -0.704 }, { -0.030, -0.472, -0.881 } },
      r = { { 0.095, 0.162, -0.982 }, { -0.179, -0.286, -0.941 }, { -0.046, -0.231, -0.972 } },
      la = { { 0.219, 0.915, -0.340 }, { 0.596, 0.568, 0.567 }, { 0.872, 0.483, -0.086 } },
      ra = { { 0.511, 0.226, -0.829 }, { -0.480, 0.390, 0.786 }, { -0.007, 1.000, 0.030 } },
    },
    { hip = -0.049,
      l = { { -0.010, 0.637, -0.771 }, { 0.056, -0.693, -0.718 }, { -0.007, -0.488, -0.873 } },
      r = { { 0.143, 0.219, -0.965 }, { -0.167, -0.334, -0.928 }, { -0.045, -0.242, -0.969 } },
      la = { { 0.198, 0.948, -0.248 }, { 0.625, 0.520, 0.582 }, { 0.872, 0.485, -0.064 } },
      ra = { { 0.603, 0.293, -0.742 }, { -0.575, 0.314, 0.755 }, { -0.005, 0.997, 0.081 } },
    },
} }

-- arm poses (torso frame { right, forward, up }: upper arm, forearm, wrist -> middle knuckle), 8 keys per clip, looped;
-- baked from the Warframe extract with wfanim.py (scratchpad bake_arms.py)
local FLOAT_ARM_POSES = {
    rifle = { -- Powers/Oraxia/GroundIdleRifle_anim.fbx
        period = 1.900, keys = {
            { la = { { 0.166, 0.950, -0.266 }, { 0.655, 0.537, 0.531 }, { 0.872, 0.486, -0.054 } }, ra = { { 0.650, 0.210, -0.731 }, { -0.631, 0.425, 0.649 }, { -0.004, 0.994, 0.105 } } },
            { la = { { 0.169, 0.925, -0.341 }, { 0.652, 0.574, 0.495 }, { 0.872, 0.485, -0.064 } }, ra = { { 0.622, 0.120, -0.774 }, { -0.600, 0.529, 0.600 }, { -0.005, 0.997, 0.082 } } },
            { la = { { 0.174, 0.861, -0.478 }, { 0.632, 0.662, 0.404 }, { 0.872, 0.483, -0.084 } }, ra = { { 0.554, -0.025, -0.832 }, { -0.539, 0.697, 0.473 }, { -0.007, 0.999, 0.034 } } },
            { la = { { 0.189, 0.812, -0.552 }, { 0.597, 0.739, 0.313 }, { 0.871, 0.480, -0.106 } }, ra = { { 0.469, -0.092, -0.879 }, { -0.464, 0.789, 0.402 }, { -0.009, 1.000, -0.016 } } },
            { la = { { 0.204, 0.808, -0.552 }, { 0.581, 0.744, 0.330 }, { 0.871, 0.478, -0.117 } }, ra = { { 0.413, -0.086, -0.907 }, { -0.403, 0.783, 0.474 }, { -0.010, 0.999, -0.040 } } },
            { la = { { 0.213, 0.851, -0.480 }, { 0.587, 0.668, 0.457 }, { 0.871, 0.480, -0.108 } }, ra = { { 0.431, 0.022, -0.902 }, { -0.408, 0.638, 0.653 }, { -0.009, 1.000, -0.020 } } },
            { la = { { 0.219, 0.915, -0.340 }, { 0.596, 0.568, 0.567 }, { 0.872, 0.483, -0.086 } }, ra = { { 0.511, 0.226, -0.829 }, { -0.480, 0.390, 0.786 }, { -0.007, 1.000, 0.030 } } },
            { la = { { 0.198, 0.948, -0.248 }, { 0.625, 0.520, 0.582 }, { 0.872, 0.485, -0.064 } }, ra = { { 0.603, 0.293, -0.742 }, { -0.575, 0.314, 0.755 }, { -0.005, 0.997, 0.081 } } },
        } },
    crossed = { -- Emotes/Generic/DigitalSwagIdle_anim.fbx
        period = 2.000, keys = {
            { la = { { -0.163, 0.640, -0.751 }, { 0.968, 0.247, -0.051 }, { 0.959, 0.153, -0.238 } }, ra = { { -0.023, 0.729, -0.684 }, { -0.926, -0.370, 0.076 }, { -0.745, -0.667, 0.026 } } },
            { la = { { -0.163, 0.641, -0.750 }, { 0.967, 0.252, -0.045 }, { 0.959, 0.155, -0.236 } }, ra = { { -0.021, 0.734, -0.679 }, { -0.927, -0.369, 0.072 }, { -0.745, -0.667, 0.019 } } },
            { la = { { -0.163, 0.645, -0.747 }, { 0.966, 0.256, -0.034 }, { 0.959, 0.158, -0.233 } }, ra = { { -0.025, 0.743, -0.669 }, { -0.927, -0.366, 0.076 }, { -0.745, -0.667, 0.008 } } },
            { la = { { -0.162, 0.646, -0.745 }, { 0.967, 0.252, -0.029 }, { 0.959, 0.159, -0.233 } }, ra = { { -0.040, 0.758, -0.651 }, { -0.923, -0.378, 0.076 }, { -0.745, -0.667, 0.005 } } },
            { la = { { -0.163, 0.634, -0.756 }, { 0.969, 0.246, -0.033 }, { 0.959, 0.155, -0.236 } }, ra = { { -0.058, 0.765, -0.641 }, { -0.915, -0.396, 0.076 }, { -0.745, -0.667, 0.019 } } },
            { la = { { -0.163, 0.616, -0.771 }, { 0.969, 0.242, -0.043 }, { 0.959, 0.149, -0.241 } }, ra = { { -0.069, 0.760, -0.646 }, { -0.909, -0.410, 0.078 }, { -0.744, -0.667, 0.039 } } },
            { la = { { -0.164, 0.616, -0.771 }, { 0.969, 0.239, -0.054 }, { 0.959, 0.147, -0.242 } }, ra = { { -0.060, 0.749, -0.660 }, { -0.911, -0.406, 0.076 }, { -0.744, -0.667, 0.046 } } },
            { la = { { -0.164, 0.628, -0.761 }, { 0.969, 0.240, -0.058 }, { 0.959, 0.148, -0.241 } }, ra = { { -0.040, 0.737, -0.675 }, { -0.918, -0.391, 0.071 }, { -0.744, -0.667, 0.040 } } },
        } },
    crossed_loose = { -- Menu/Idles/Pacifist/AgileIdleThrowingVariant_anim.fbx
        period = 7.400, keys = {
            { la = { { -0.595, 0.579, -0.557 }, { -0.143, 0.965, -0.219 }, { -0.252, 0.373, 0.893 } }, ra = { { 0.388, -0.271, -0.881 }, { 0.210, 0.466, -0.859 }, { 0.170, 0.610, -0.774 } } },
            { la = { { -0.839, 0.464, -0.285 }, { -0.531, 0.758, 0.378 }, { -0.312, 0.062, 0.948 } }, ra = { { -0.107, 0.666, -0.738 }, { -0.653, 0.453, 0.608 }, { -0.777, 0.353, 0.520 } } },
            { la = { { -0.191, 0.744, -0.640 }, { 0.957, 0.169, 0.237 }, { 0.907, 0.378, 0.186 } }, ra = { { -0.292, 0.499, -0.816 }, { -0.766, 0.373, -0.523 }, { -0.722, 0.461, -0.516 } } },
            { la = { { 0.125, 0.526, -0.841 }, { 0.908, 0.396, -0.137 }, { 0.650, 0.664, -0.369 } }, ra = { { -0.157, 0.482, -0.862 }, { -0.787, 0.366, -0.497 }, { -0.724, 0.226, -0.652 } } },
            { la = { { 0.081, 0.793, -0.603 }, { 0.997, 0.058, -0.057 }, { 0.919, 0.390, 0.055 } }, ra = { { -0.082, 0.476, -0.876 }, { -0.953, 0.209, -0.220 }, { -0.930, 0.242, -0.276 } } },
            { la = { { 0.317, 0.937, -0.146 }, { 0.975, -0.153, 0.163 }, { 0.966, 0.053, 0.253 } }, ra = { { 0.566, 0.771, -0.292 }, { -0.143, 0.930, 0.339 }, { 0.159, 0.980, 0.123 } } },
            { la = { { -0.377, 0.921, 0.095 }, { 0.697, 0.054, 0.715 }, { 0.602, 0.143, 0.785 } }, ra = { { 0.217, 0.821, -0.528 }, { -0.759, 0.605, 0.241 }, { -0.564, 0.116, 0.818 } } },
            { la = { { -0.865, -0.356, -0.353 }, { -0.694, 0.577, -0.430 }, { -0.550, 0.833, 0.058 } }, ra = { { 0.067, -0.523, -0.850 }, { 0.390, 0.220, -0.894 }, { 0.846, 0.210, -0.491 } } },
        } },
    behind = { -- Menu/Idles/Priest/NobleIdleUnarmed_anim.fbx
        period = 2.967, keys = {
            { la = { { -0.269, -0.535, -0.801 }, { 0.770, -0.132, -0.624 }, { 0.860, -0.079, -0.504 } }, ra = { { 0.352, -0.462, -0.814 }, { -0.802, -0.161, -0.575 }, { -0.759, 0.034, -0.650 } } },
            { la = { { -0.271, -0.536, -0.800 }, { 0.769, -0.118, -0.628 }, { 0.865, -0.080, -0.496 } }, ra = { { 0.350, -0.460, -0.816 }, { -0.803, -0.159, -0.574 }, { -0.760, 0.037, -0.648 } } },
            { la = { { -0.276, -0.533, -0.800 }, { 0.771, -0.117, -0.626 }, { 0.871, -0.084, -0.484 } }, ra = { { 0.348, -0.471, -0.811 }, { -0.803, -0.153, -0.576 }, { -0.761, 0.037, -0.647 } } },
            { la = { { -0.278, -0.539, -0.795 }, { 0.770, -0.137, -0.624 }, { 0.870, -0.089, -0.484 } }, ra = { { 0.347, -0.485, -0.803 }, { -0.803, -0.155, -0.575 }, { -0.761, 0.030, -0.648 } } },
            { la = { { -0.274, -0.545, -0.792 }, { 0.762, -0.159, -0.627 }, { 0.867, -0.088, -0.491 } }, ra = { { 0.350, -0.488, -0.800 }, { -0.804, -0.159, -0.573 }, { -0.761, 0.024, -0.649 } } },
            { la = { { -0.269, -0.545, -0.794 }, { 0.754, -0.169, -0.635 }, { 0.863, -0.082, -0.498 } }, ra = { { 0.353, -0.479, -0.804 }, { -0.805, -0.158, -0.572 }, { -0.760, 0.025, -0.650 } } },
            { la = { { -0.267, -0.542, -0.797 }, { 0.752, -0.164, -0.638 }, { 0.862, -0.078, -0.501 } }, ra = { { 0.356, -0.467, -0.810 }, { -0.806, -0.157, -0.571 }, { -0.759, 0.030, -0.651 } } },
            { la = { { -0.268, -0.534, -0.802 }, { 0.764, -0.146, -0.629 }, { 0.861, -0.077, -0.503 } }, ra = { { 0.354, -0.462, -0.813 }, { -0.804, -0.157, -0.574 }, { -0.759, 0.034, -0.651 } } },
        } },
    hips = { -- Emotes/Generic/VictoryIdle_anim.fbx
        period = 3.333, keys = {
            { la = { { -0.538, -0.459, -0.706 }, { 0.032, 0.583, -0.812 }, { 0.426, 0.414, -0.804 } }, ra = { { 0.531, 0.183, -0.827 }, { 0.458, 0.230, -0.859 }, { 0.386, 0.837, -0.387 } } },
            { la = { { -0.601, -0.414, -0.683 }, { -0.068, 0.558, -0.827 }, { 0.166, 0.588, -0.792 } }, ra = { { 0.568, 0.233, -0.790 }, { 0.567, 0.234, -0.790 }, { 0.389, 0.918, -0.075 } } },
            { la = { { -0.543, -0.452, -0.708 }, { 0.034, 0.607, -0.794 }, { 0.286, 0.569, -0.771 } }, ra = { { 0.490, 0.189, -0.851 }, { 0.401, 0.249, -0.882 }, { 0.363, 0.909, -0.205 } } },
            { la = { { -0.484, -0.487, -0.727 }, { 0.108, 0.644, -0.757 }, { 0.505, 0.430, -0.748 } }, ra = { { 0.477, 0.155, -0.865 }, { 0.314, 0.261, -0.913 }, { 0.344, 0.826, -0.446 } } },
            { la = { { -0.537, -0.460, -0.707 }, { 0.034, 0.582, -0.812 }, { 0.428, 0.413, -0.804 } }, ra = { { 0.533, 0.182, -0.826 }, { 0.460, 0.229, -0.858 }, { 0.387, 0.837, -0.387 } } },
            { la = { { -0.680, -0.404, -0.612 }, { -0.140, 0.552, -0.822 }, { 0.097, 0.576, -0.812 } }, ra = { { 0.637, 0.238, -0.733 }, { 0.636, 0.239, -0.734 }, { 0.372, 0.927, -0.049 } } },
            { la = { { -0.676, -0.430, -0.598 }, { -0.066, 0.594, -0.802 }, { 0.184, 0.543, -0.820 } }, ra = { { 0.609, 0.200, -0.768 }, { 0.522, 0.255, -0.814 }, { 0.344, 0.924, -0.169 } } },
            { la = { { -0.598, -0.470, -0.649 }, { 0.034, 0.632, -0.774 }, { 0.418, 0.400, -0.816 } }, ra = { { 0.575, 0.165, -0.801 }, { 0.416, 0.262, -0.871 }, { 0.362, 0.834, -0.415 } } },
        } },
    noble = { -- Menu/Idles/Oraxia/NobleIdleUnarmed_anim.fbx
        period = 3.967, keys = {
            { la = { { -0.427, -0.040, -0.903 }, { -0.795, 0.471, -0.382 }, { -0.884, 0.336, -0.326 } }, ra = { { 0.444, -0.046, -0.895 }, { 0.706, 0.631, -0.321 }, { 0.924, 0.336, -0.181 } } },
            { la = { { -0.447, -0.001, -0.894 }, { -0.754, 0.545, -0.366 }, { -0.886, 0.423, -0.188 } }, ra = { { 0.493, 0.002, -0.870 }, { 0.649, 0.699, -0.300 }, { 0.906, 0.423, -0.031 } } },
            { la = { { -0.492, 0.026, -0.870 }, { -0.756, 0.550, -0.354 }, { -0.896, 0.437, -0.085 } }, ra = { { 0.459, 0.034, -0.888 }, { 0.622, 0.701, -0.349 }, { 0.899, 0.437, -0.008 } } },
            { la = { { -0.531, 0.006, -0.847 }, { -0.781, 0.557, -0.282 }, { -0.907, 0.420, 0.043 } }, ra = { { 0.389, 0.012, -0.921 }, { 0.598, 0.711, -0.369 }, { 0.908, 0.420, 0.005 } } },
            { la = { { -0.564, -0.011, -0.826 }, { -0.808, 0.541, -0.233 }, { -0.922, 0.371, 0.113 } }, ra = { { 0.334, -0.010, -0.942 }, { 0.601, 0.699, -0.387 }, { 0.928, 0.371, -0.014 } } },
            { la = { { -0.582, 0.005, -0.813 }, { -0.825, 0.491, -0.281 }, { -0.925, 0.349, 0.152 } }, ra = { { 0.317, 0.006, -0.948 }, { 0.615, 0.648, -0.450 }, { 0.937, 0.349, -0.000 } } },
            { la = { { -0.572, 0.023, -0.820 }, { -0.808, 0.413, -0.419 }, { -0.931, 0.322, -0.170 } }, ra = { { 0.367, 0.024, -0.930 }, { 0.640, 0.566, -0.520 }, { 0.915, 0.323, -0.241 } } },
            { la = { { -0.489, -0.016, -0.872 }, { -0.795, 0.421, -0.437 }, { -0.866, 0.287, -0.408 } }, ra = { { 0.404, -0.016, -0.915 }, { 0.687, 0.572, -0.447 }, { 0.889, 0.288, -0.357 } } },
        } },
    agile = { -- Menu/Idles/Oraxia/AgileIdleUnarmed_anim.fbx
        period = 2.967, keys = {
            { la = { { -0.333, -0.454, -0.827 }, { -0.409, 0.633, -0.658 }, { -0.554, 0.820, -0.145 } }, ra = { { 0.129, -0.744, -0.656 }, { 0.726, 0.210, -0.655 }, { 0.590, 0.759, -0.276 } } },
            { la = { { -0.285, -0.394, -0.874 }, { -0.504, 0.552, -0.664 }, { -0.593, 0.798, -0.107 } }, ra = { { 0.235, -0.694, -0.681 }, { 0.792, 0.247, -0.558 }, { 0.616, 0.785, -0.069 } } },
            { la = { { -0.229, -0.309, -0.923 }, { -0.595, 0.433, -0.677 }, { -0.597, 0.802, -0.014 } }, ra = { { 0.421, -0.612, -0.669 }, { 0.879, 0.276, -0.389 }, { 0.755, 0.654, 0.048 } } },
            { la = { { -0.250, -0.323, -0.913 }, { -0.601, 0.362, -0.712 }, { -0.692, 0.721, -0.019 } }, ra = { { 0.542, -0.572, -0.616 }, { 0.920, 0.223, -0.322 }, { 0.814, 0.579, 0.039 } } },
            { la = { { -0.313, -0.408, -0.858 }, { -0.541, 0.398, -0.741 }, { -0.797, 0.598, -0.079 } }, ra = { { 0.552, -0.558, -0.620 }, { 0.908, 0.144, -0.393 }, { 0.851, 0.518, -0.089 } } },
            { la = { { -0.320, -0.467, -0.824 }, { -0.501, 0.502, -0.706 }, { -0.789, 0.591, -0.168 } }, ra = { { 0.488, -0.551, -0.676 }, { 0.846, 0.085, -0.527 }, { 0.859, 0.433, -0.275 } } },
            { la = { { -0.271, -0.469, -0.841 }, { -0.481, 0.597, -0.642 }, { -0.652, 0.724, -0.224 } }, ra = { { 0.364, -0.601, -0.712 }, { 0.775, 0.102, -0.623 }, { 0.810, 0.423, -0.406 } } },
            { la = { { -0.303, -0.461, -0.834 }, { -0.424, 0.649, -0.631 }, { -0.540, 0.824, -0.172 } }, ra = { { 0.197, -0.705, -0.681 }, { 0.731, 0.188, -0.656 }, { 0.705, 0.574, -0.416 } } },
        } },
}

-- Oraxia's floating form: on with float_form, lifted by float_height, legs from her hover idle (tucked by
-- float_leg_tuck), lean float_lean, arm pose float_arms_pose while unarmed, camera with float_camera
local FLOAT_CFG = { on_opt = "float_form", height_opt = "float_height", height_default = 0.6, lean_opt = "float_lean",
    lean_default = 25, lean_moving = 0, tuck_opt = "float_leg_tuck", tuck_default = 15, legs_still_opt = "float_legs_still",
    legs_still_default = true, camera_opt = "float_camera", arms = true, arms_opt = "float_arms_pose", sway = false,
    hover_moving = false }

-- Floating form (user request 2026-10-04: "an alternate version of oraxia, where she is elevated a little bit off the
-- floor and is in her ability 4 form, where she is reliant on her spider legs to move around"). Option float_form.
-- v3 (user: "weapons do not sync with height"): a skeleton-only driver unit (<body>_driver, the full human
-- third-person skeleton incl. j_*weaponattach and ap_* nodes, DMS\work\mmduild_driver.py) is linked to the player
-- by its root (door.lua:170) and every frame copies the player's nodes (local rotation / position), with j_hips raised
-- and her own legs posed. Her body and part units are linked to the driver by node name (as QIangIQsEmotes' dances,
-- note 32), and the game's third-person item units (slot.unit_3p, not body / gear) are unlinked and linked to the
-- driver at the node the game used (visual_loadout_customization.lua:257-340: breed_attach_node / attach_node,
-- link_map_mode / skip_link_children), and linked back to the player before the driver is deleted.
-- v4 (user): her forward lean (float_lean, default 25 degrees from upright = 65 above the ground; her clips: walk 19,
-- jog 18, sprint 36, hover idle 6.5), arms and hip rotation held while moving (FLOAT_STEADY), no up-and-down motion
-- while moving (steady hip height, no step dip, hover bob only while standing). Height 0.6 m is her clip value (hips
-- 1.52-1.66 m in the hover idle, about 0.6 m above her normal stance). Not checked in game: the relinked weapons.
local FLOAT_NODES = {
    "j_aim_target", "j_foot_grounded", "j_hips_transform", "j_hips_ref", "j_hips", "j_leftupleg", "j_left_foot_pv",
    "j_leftleg", "j_leftfoot", "j_lefttoebase", "j_leftlegroll1", "j_leftuplegroll1", "j_rightupleg",
    "j_right_foot_pv", "j_rightleg", "j_rightfoot", "j_righttoebase", "j_rightlegroll1", "j_rightuplegroll1",
    "j_spine", "j_spine1", "j_spine2", "j_leftshoulder", "j_leftarm", "j_leftforearm", "j_lefthand",
    "j_lefthandthumb1", "j_lefthandthumb2", "j_lefthandthumb3", "j_leftinhandindex", "j_lefthandindex1",
    "j_lefthandindex2", "j_lefthandindex3", "j_leftinhandmiddle", "j_lefthandmiddle1", "j_lefthandmiddle2",
    "j_lefthandmiddle3", "j_leftinhandpinky", "j_lefthandpinky1", "j_lefthandpinky2", "j_lefthandpinky3",
    "j_leftinhandring", "j_lefthandring1", "j_lefthandring2", "j_lefthandring3", "j_leftweaponattach",
    "ap_anim_01_offhand", "ap_anim_02_offhand", "ap_anim_03_offhand", "ap_anim_04_offhand", "ap_anim_05_offhand",
    "ap_anim_06_offhand", "ap_anim_07_offhand", "ap_anim_08_offhand", "ap_anim_09_offhand", "ap_anim_10_offhand",
    "ap_bullet_01_offhand", "ap_bullet_02_offhand", "ap_magazine_01_offhand", "ap_magazine_02_offhand",
    "ap_recharge_01_offhand", "ap_recharge_02_offhand", "ap_recharge_03_offhand", "ap_release_01_offhand",
    "ap_release_02_offhand", "ap_release_03_offhand", "ap_release_04_offhand", "ap_safety_01_offhand",
    "ap_safety_02_offhand", "ap_sight_01_offhand", "ap_sight_02_offhand", "ap_stock_01_offhand",
    "ap_stock_02_offhand", "ap_trigger_01_offhand", "ap_trigger_02_offhand", "ap_underbarrel_01_offhand",
    "j_trail_01_offhand", "j_trail_02_offhand", "j_trail_03_offhand", "j_trail_04_offhand", "j_leftforearmroll1",
    "j_leftforearmroll2", "j_leftarmroll1", "j_neck", "j_head", "j_rightshoulder", "j_rightarm", "j_rightforearm",
    "j_righthand", "j_righthandthumb1", "j_righthandthumb2", "j_righthandthumb3", "j_rightinhandindex",
    "j_righthandindex1", "j_righthandindex2", "j_righthandindex3", "j_rightinhandmiddle", "j_righthandmiddle1",
    "j_righthandmiddle2", "j_righthandmiddle3", "j_rightinhandpinky", "j_righthandpinky1", "j_righthandpinky2",
    "j_righthandpinky3", "j_rightinhandring", "j_righthandring1", "j_righthandring2", "j_righthandring3",
    "j_rightweaponattach", "ap_anim_01", "ap_anim_02", "ap_anim_03", "ap_anim_04", "ap_anim_05", "ap_anim_06",
    "ap_anim_07", "ap_anim_08", "ap_anim_09", "ap_anim_10", "ap_bullet_01", "ap_bullet_02", "ap_magazine_01",
    "ap_magazine_02", "ap_recharge_01", "ap_recharge_02", "ap_recharge_03", "ap_release_01", "ap_release_02",
    "ap_release_03", "ap_release_04", "ap_safety_01", "ap_safety_02", "ap_sight_01", "ap_sight_02", "ap_stock_01",
    "ap_stock_02", "ap_trigger_01", "ap_trigger_02", "ap_underbarrel_01", "j_trail_01", "j_trail_02", "j_trail_03",
    "j_trail_04", "j_rightforearmroll1", "j_rightforearmroll2", "j_rightarmroll1", "j_backchestplate",
    "j_frontchestplate", "j_left_foot_ik_transform", "j_left_foot_anim_ref", "j_left_foot_ik_orient_transform",
    "j_left_foot_ik_orient_ref", "j_left_foot_ik", "j_left_hand_ik_transform", "j_left_hand_ik", "j_left_hand_pv",
    "j_right_foot_ik_transform", "j_right_foot_anim_ref", "j_right_foot_ik_orient_transform",
    "j_right_foot_ik_orient_ref", "j_right_foot_ik", "j_right_hand_ik_transform", "j_right_hand_ik",
    "j_right_hand_pv", "j_hub_head_aim", "j_hub_torso_aim",
}
local FLOAT_HIPS_PARENT = "j_hips_transform" -- bones.json parent of j_hips
-- Held steady while she moves and no weapon action runs (user: "when sprinting and walking her arms move as if her
-- legs were walking"): the hips' rotation and every node under the shoulders (bones.json) keep the pose they had
-- while she last stood still; attacks, reloads and the like (weapon_action component, current_action_name not
-- "none", as chain_weapon_effects.lua:137) play live.
local FLOAT_STEADY = {
    -- v7 (user: "shoulder torso and arms still sway/rotate left and right for walking and sprinting"): the hip
    -- transform, spine and neck are held too
    j_hips_transform = true, j_spine = true, j_spine1 = true, j_spine2 = true, j_neck = true,
    j_hips = true, j_leftshoulder = true, j_leftarm = true, j_leftforearm = true, j_lefthand = true,
    j_lefthandthumb1 = true, j_lefthandthumb2 = true, j_lefthandthumb3 = true, j_leftinhandindex = true,
    j_lefthandindex1 = true, j_lefthandindex2 = true, j_lefthandindex3 = true, j_leftinhandmiddle = true,
    j_lefthandmiddle1 = true, j_lefthandmiddle2 = true, j_lefthandmiddle3 = true, j_leftinhandpinky = true,
    j_lefthandpinky1 = true, j_lefthandpinky2 = true, j_lefthandpinky3 = true, j_leftinhandring = true,
    j_lefthandring1 = true, j_lefthandring2 = true, j_lefthandring3 = true, j_leftweaponattach = true,
    ap_anim_01_offhand = true, ap_anim_02_offhand = true, ap_anim_03_offhand = true, ap_anim_04_offhand = true,
    ap_anim_05_offhand = true, ap_anim_06_offhand = true, ap_anim_07_offhand = true, ap_anim_08_offhand = true,
    ap_anim_09_offhand = true, ap_anim_10_offhand = true, ap_bullet_01_offhand = true, ap_bullet_02_offhand = true,
    ap_magazine_01_offhand = true, ap_magazine_02_offhand = true, ap_recharge_01_offhand = true,
    ap_recharge_02_offhand = true, ap_recharge_03_offhand = true, ap_release_01_offhand = true,
    ap_release_02_offhand = true, ap_release_03_offhand = true, ap_release_04_offhand = true,
    ap_safety_01_offhand = true, ap_safety_02_offhand = true, ap_sight_01_offhand = true, ap_sight_02_offhand = true,
    ap_stock_01_offhand = true, ap_stock_02_offhand = true, ap_trigger_01_offhand = true,
    ap_trigger_02_offhand = true, ap_underbarrel_01_offhand = true, j_trail_01_offhand = true,
    j_trail_02_offhand = true, j_trail_03_offhand = true, j_trail_04_offhand = true, j_leftforearmroll1 = true,
    j_leftforearmroll2 = true, j_leftarmroll1 = true, j_rightshoulder = true, j_rightarm = true,
    j_rightforearm = true, j_righthand = true, j_righthandthumb1 = true, j_righthandthumb2 = true,
    j_righthandthumb3 = true, j_rightinhandindex = true, j_righthandindex1 = true, j_righthandindex2 = true,
    j_righthandindex3 = true, j_rightinhandmiddle = true, j_righthandmiddle1 = true, j_righthandmiddle2 = true,
    j_righthandmiddle3 = true, j_rightinhandpinky = true, j_righthandpinky1 = true, j_righthandpinky2 = true,
    j_righthandpinky3 = true, j_rightinhandring = true, j_righthandring1 = true, j_righthandring2 = true,
    j_righthandring3 = true, j_rightweaponattach = true, ap_anim_01 = true, ap_anim_02 = true, ap_anim_03 = true,
    ap_anim_04 = true, ap_anim_05 = true, ap_anim_06 = true, ap_anim_07 = true, ap_anim_08 = true, ap_anim_09 = true,
    ap_anim_10 = true, ap_bullet_01 = true, ap_bullet_02 = true, ap_magazine_01 = true, ap_magazine_02 = true,
    ap_recharge_01 = true, ap_recharge_02 = true, ap_recharge_03 = true, ap_release_01 = true, ap_release_02 = true,
    ap_release_03 = true, ap_release_04 = true, ap_safety_01 = true, ap_safety_02 = true, ap_sight_01 = true,
    ap_sight_02 = true, ap_stock_01 = true, ap_stock_02 = true, ap_trigger_01 = true, ap_trigger_02 = true,
    ap_underbarrel_01 = true, j_trail_01 = true, j_trail_02 = true, j_trail_03 = true, j_trail_04 = true,
    j_rightforearmroll1 = true, j_rightforearmroll2 = true, j_rightarmroll1 = true,
}
-- her arms while unarmed (Mourningstar; user: "arms are straight down in mourningstar instead of crossed or tucked"):
-- the arm pose of the same hover idle (both hands in front of her chest, the left reaching across), weight 0..1
-- (inventory component wielded_slot == "slot_unarmed", as player_character_state_hogtied.lua:74)

local FLOAT_ARMS = {
    la = { "j_leftshoulder", "j_leftarm", "j_leftforearm", "j_lefthand", "j_lefthandmiddle1" },
    ra = { "j_rightshoulder", "j_rightarm", "j_rightforearm", "j_righthand", "j_righthandmiddle1" },
}
local FLOAT_CHAIN = {
    l = { "j_leftupleg", "j_leftleg", "j_leftfoot", "j_lefttoebase" },
    r = { "j_rightupleg", "j_rightleg", "j_rightfoot", "j_righttoebase" },
}
local FLOAT_MAP = setmetatable({}, { __mode = "k" }) -- unit -> { player, list of { node, player node, rest, leg } }

local function float_on()
    return opt(FLOAT_CFG.on_opt) == true
end

local function float_num(key, default)
    return key and tonumber(opt(key)) or default
end

local FLOAT_DRIVER = BODY .. "_driver"

-- Raised first-person camera (option float_camera, default off; user: "move the player camera up to match the
-- height ... keeping my cam up high"). The first-person camera tree's "up_translation" node (camera_settings.lua
-- player_first_person, class ScalableZAxisCamera) lifts the camera straight up by z_offset (1) x
-- scale_function(character_height) (scalable_z_axis_camera.lua:17-21); its scale_function is wrapped to add the
-- lift, read from a field on the node so a mod reload keeps working. The trees are rebuilt with
-- camera_handler:on_reload(), as Perspectives (CameraTree.lua _refresh_camera_trees, Utils.lua get_camera_handler).
-- Only the view moves: aim and shots still start at the game's first-person position. DynamicCrosshair (installed)
-- draws the crosshair where the real shot ray hits (Camera.world_to_screen of shoot position + direction x range), so
-- while the camera is raised its "Reposition During" option is set to "both" (0) and put back afterwards.
local FloatCameraSettings = require("scripts/settings/camera/camera_settings")
local float_dc_prev -- DynamicCrosshair perspectives_reposition before we changed it

local function float_camera_node()
    local tree = FloatCameraSettings.player_first_person
    local up = tree and tree[1] and tree[1]._node
    return up and up.name == "up_translation" and up.scale_function and up or nil
end

-- the lift each mod asked for this frame, kept on the camera node as { v = lift, at = os.clock() }; only entries
-- renewed within the last half second count, so a lift from a model that is no longer driven (other character, mod
-- reloaded, unit gone without a release) runs out on its own (2026-10-05: the camera stayed raised on other models)
local function float_lift_of(up)
    local top = 0
    local lifts = up and up.__qiangiq_lifts
    if lifts then
        local now = os.clock()
        for _, e in pairs(lifts) do
            if type(e) == "table" and e.v and e.at and now - e.at < 0.5 then
                top = math.max(top, e.v)
            end
        end
    end
    return top
end

local function float_camera_install()
    local up = float_camera_node()
    if not up or up.__qiangiq_float == 2 then
        return
    end
    -- version 2 (2026-10-05): the game's own function is kept once; a version-1 wrapper (a fixed lift field) is replaced
    up.__qiangiq_orig_scale = up.__qiangiq_orig_scale or (up.__qiangiq_float and function(height)
        return height -- camera_settings.lua player_first_person up_translation: scale_function returns height
    end) or up.scale_function
    local orig = up.__qiangiq_orig_scale
    up.scale_function = function(height)
        local top = 0
        local lifts = up.__qiangiq_lifts
        if lifts then
            local now = os.clock()
            for _, e in pairs(lifts) do
                if type(e) == "table" and e.v and e.at and now - e.at < 0.5 then
                    top = math.max(top, e.v)
                end
            end
        end
        return orig(height) + top
    end
    up.__qiangiq_float = 2
    local plr = Managers and Managers.player and Managers.player:local_player_safe(1)
    local handler = plr and plr.camera_handler
    if handler and handler.on_reload then
        handler:on_reload()
    end
end
float_camera_install()

local float_true_root -- Vector3Box: the first-person root before the lift (the real eye), set each frame
local float_world -- the gameplay world (for the crosshair raycast)

-- First-person arms and weapon rise with the camera: after the game places the first-person unit
-- (player_unit_first_person_extension.lua:412-442, root at the player + eye height), its root is moved up by the same
-- lift, as ViewModelTweaker offsets the view model (hook on update_unit_position, Unit.set_local_position on node 1,
-- World.update_unit_and_children). The camera does not move with it: FirstPersonAnimationCamera only adds the
-- ap_camera_node's local pose inside that unit (first_person_animation_camera.lua:35-45).
-- Registered by every mod that carries this code (2026-10-05: a "registered once" flag on the shared camera node
-- outlived a DMF mod reload, which removes the hooks, so the camera rose without the arms); the first hook to run in a
-- frame (same t, same unit) lifts, the others skip.
mod:hook_safe(CLASS.PlayerUnitFirstPersonExtension, "update_unit_position", function(self, unit, dt, t)
    local up = float_camera_node()
    local lift = float_lift_of(up)
    if lift <= 0.001 or not (self._is_local_unit and self._player and self._player:is_human_controlled()) then
        return
    end
    local fp = self._first_person_unit
    if unit_ok(fp) and not (up.__qiangiq_fp_t == t and up.__qiangiq_fp_unit == fp) then
        up.__qiangiq_fp_t, up.__qiangiq_fp_unit = t, fp
        up.__qiangiq_true_root = Vector3Box(Unit.local_position(fp, 1)) -- shared: the crosshair may be another mod's
        Unit.set_local_position(fp, 1, Unit.local_position(fp, 1) + Vector3(0, 0, lift))
        World.update_unit_and_children(self._world, fp)
    end
end)

-- /<model>_fp: where the first-person pieces are (2026-10-05: her first-person arms looked stretched, the weapons not in
-- her hands). Prints the lift, the camera and first-person root heights, and per arm node the game's first-person
-- node against the same node of her arms unit (they should be the same point: linked by node name).
mod:command(string.lower(string.gsub(mod:get_name(), "^QIangIQs", "")) .. "_fp", "First-person arm / camera positions (debug)", function()
    local plr = Managers.player and Managers.player:local_player_safe(1)
    local pu = plr and plr.player_unit
    if not unit_ok(pu) then
        mod:echo("no player unit")
        return
    end
    local fpx = ScriptUnit.has_extension(pu, "first_person_system")
    local vl = ScriptUnit.has_extension(pu, "visual_loadout_system")
    local fp = fpx and fpx:first_person_unit()
    local up = float_camera_node()
    local cam = Managers.state.camera and Managers.state.camera:camera_position(plr.viewport_name)
    local function f(v)
        return v and string.format("(%.2f %.2f %.2f)", v.x, v.y, v.z) or "-"
    end
    mod:echo("lift %.3f  player %s  fp root %s  camera %s", float_lift_of(up), f(Unit.world_position(pu, 1)),
        f(unit_ok(fp) and Unit.world_position(fp, 1)), f(cam))
    if unit_ok(fp) and Unit.has_node(fp, "ap_camera_node") then
        mod:echo("fp ap_camera_node %s", f(Unit.world_position(fp, Unit.node(fp, "ap_camera_node"))))
    end
    if not (vl and unit_ok(fp)) then
        return
    end
    for k, arms in pairs(vl) do
        if type(k) == "string" and string.find(k, "^__qiangiq_.+_arms$") and unit_ok(arms) then
            for _, n in ipairs({ "j_rightshoulder", "j_rightforearm", "j_righthand", "j_lefthand" }) do
                if Unit.has_node(fp, n) and Unit.has_node(arms, n) then
                    local a1 = Unit.world_position(fp, Unit.node(fp, n))
                    local a2 = Unit.world_position(arms, Unit.node(arms, n))
                    mod:echo("%s %s: game %s  arms %s  off %.3f", k, n, f(a1), f(a2), Vector3.length(a2 - a1))
                end
            end
            mod:echo("%s root %s, parent of arms = fp unit? %s", k, f(Unit.world_position(arms, 1)),
                tostring(Unit.world_position(arms, 1) == Unit.world_position(fp, 1)))
        end
    end
end)

local function float_camera_set(lift)
    local up = float_camera_node()
    if up then
        -- several mods carry this code (Oraxia, Yareli Prime): each keeps its own lift here, the camera and the
        -- first-person arms use the largest (2026-10-05: both mods lifted the arms, so they sat twice as high)
        up.__qiangiq_lifts = up.__qiangiq_lifts or {}
        up.__qiangiq_lifts[mod:get_name()] = { v = lift, at = os.clock() }
    end
    local dc = get_mod("DynamicCrosshair")
    if dc then
        -- v9: no longer switched (the crosshair hook below does the work); put back if an older version changed it
        if float_dc_prev ~= nil then
            dc:set("perspectives_reposition", float_dc_prev, true)
            float_dc_prev = nil
        end
    end
end

-- Crosshair with the raised camera (user 2026-10-05: "do not lower camera to fit melee, instead ... move the crosshair to
-- display where I'm looking properly while still staying up high"). Shots and melee sweeps start at the game's
-- first-person position (action_shoot.lua:448 shooting_position, action_sweep.lua:310 / 490 reference_position =
-- first_person_component.position), the real eye, which the lift does not move. DynamicCrosshair takes its shot origin
-- from the first-person unit's root (Unit.world_position(first_person_unit, 1)), which the lift raises with the arms,
-- so it would show the raised ray. While the lift is on, this hook (registered after DynamicCrosshair's, so it is the
-- outer one: DMF calls the last registered hook first, hooks.lua get_hook_chain) puts the crosshair where DynamicCrosshair
-- would with the real eye: the same recoil / sway turn of the first-person rotation, the same raycast (50 m, "all",
-- filter_debug_unit_selector, nearest hit beyond 1 m) and the same projection
-- (Camera.world_to_screen of the player camera, minus the pivot, lerped at 35 / s). Without DynamicCrosshair it does the
-- same on its own.
local FloatRecoil = require("scripts/utilities/recoil")
local FloatSway = require("scripts/utilities/sway")
local float_xhair_hooked = false

local function float_xhair_position(ui_hud, ui_renderer, current_x, current_y, pivot_position, dt)
    local exts = ui_hud and ui_hud:player_extensions()
    local camera = ui_hud and ui_hud:player_camera()
    local unit_data, weapon, fpx = exts and exts.unit_data, exts and exts.weapon, exts and exts.first_person
    local up = float_camera_node()
    local true_root = up and up.__qiangiq_true_root
    local world = up and up.__qiangiq_world
    if not (camera and unit_data and weapon and fpx and true_root and world) then
        return nil
    end
    local fp_unit = fpx:first_person_unit()
    if not unit_ok(fp_unit) then
        return nil
    end
    local rot = Unit.world_rotation(fp_unit, 1)
    rot = FloatRecoil.apply_weapon_recoil_rotation(weapon:recoil_template(), unit_data:read_component("recoil"),
        unit_data:read_component("movement_state"), unit_data:read_component("locomotion"),
        unit_data:read_component("inair_state"), rot)
    rot = FloatSway.apply_sway_rotation(weapon:sway_template(), unit_data:read_component("sway"), rot)
    local pos, dir = true_root:unbox(), Quaternion.forward(rot)
    local range = 50
    local physics_world = World.physics_world(world)
    local hits = physics_world and PhysicsWorld.raycast(physics_world, pos, dir, 50, "all", "collision_filter",
        "filter_debug_unit_selector")
    if hits then
        for i = 1, #hits do
            local hit = hits[i]
            local distance, actor = hit[2], hit[4]
            local u = actor and Actor.unit(actor)
            if u and distance > 1 and distance < range then
                range = distance
            end
        end
    end
    local screen = Camera.world_to_screen(camera, pos + dir * range)
    local tx, ty = screen.x - pivot_position[1], screen.y - pivot_position[2]
    local s, inv = ui_renderer.scale, ui_renderer.inverse_scale
    local k = math.min(35 * dt, 1)
    return math.lerp(current_x * s, tx, k) * inv, math.lerp(current_y * s, ty, k) * inv
end

mod:hook_safe(CLASS.HudElementCrosshair, "init", function()
    if float_xhair_hooked then
        return
    end
    float_xhair_hooked = true
    local Crosshair = require("scripts/ui/utilities/crosshair")
    mod:hook(Crosshair, "position", function(func, dt, t, ui_hud, ui_renderer, current_x, current_y, pivot_position)
        local x, y = func(dt, t, ui_hud, ui_renderer, current_x, current_y, pivot_position)
        local up = float_camera_node()
        if not (up and float_lift_of(up) > 0.001) or up.__qiangiq_xhair_t == t then
            return x, y -- no lift, or another mod's copy of this hook already placed it this frame
        end
        up.__qiangiq_xhair_t = t
        local ok, nx, ny = pcall(float_xhair_position, ui_hud, ui_renderer, current_x, current_y, pivot_position, dt)
        if ok and nx then
            return nx, ny
        end
        return x, y
    end)
end)


-- same as spawn_linked, but linked by the root only (door.lua:170) so Lua drives the skeleton
local function spawn_float(world, parent, unit_name)
    local unit_spawner = Managers.state and Managers.state.unit_spawner
    if not (world and unit_spawner and unit_ok(parent)) then
        return nil
    end
    local unit = unit_spawner:spawn_unit(unit_name, Unit.world_pose(parent, 1))
    if not unit then
        return nil
    end
    World.link_unit(world, unit, 1, parent, 1)
    return unit
end

-- her units spawned onto the driver, registered at spawn (weak keys): all of them are unlinked before the driver
-- is deleted (in game 2026-10-05: "still has children attached ... before destroying the unit", her body was left
-- standing in its bind pose where the driver had been; the list used to be filled only while driving)
local function float_kid(ext, unit)
    if unit and ext.__qiangiq_oraxia_float_driver then
        ext.__qiangiq_oraxia_float_kids = ext.__qiangiq_oraxia_float_kids or setmetatable({}, { __mode = "k" })
        ext.__qiangiq_oraxia_float_kids[unit] = true
    end
    return unit
end

-- parent for her units: the driver while the floating form is on (spawned on demand), else the player
local function float_parent(ext)
    if not float_on() then
        return ext._unit
    end
    if not unit_ok(ext.__qiangiq_oraxia_float_driver) and ready[FLOAT_DRIVER] then
        ext.__qiangiq_oraxia_float_driver = spawn_float(ext.__qiangiq_world, ext._unit, unit_name(FLOAT_DRIVER))
    end
    -- QIangIQsArmoryVis hangs the stowed weapons on this unit (its Holster.host), so they rise with her
    ext.__qiangiq_body_host = ext.__qiangiq_oraxia_float_driver
    return ext.__qiangiq_oraxia_float_driver
end

-- where the game linked an item's third-person unit (visual_loadout_customization.lua:257-340)
local function float_item_link(slot, parent)
    local item = slot.item
    if not item then
        return nil
    end
    local node = (item.breed_attach_node and slot.breed_name and item.breed_attach_node[slot.breed_name]) or item.attach_node
    local index
    if tonumber(node) ~= nil then
        index = tonumber(node) == 1 and 1 or nil -- other numeric nodes differ between the player and the driver
    elseif node then
        index = Unit.has_node(parent, node) and Unit.node(parent, node) or nil
    else
        index = 1
    end
    local mode
    if World[item.link_map_mode] then
        mode = World[item.link_map_mode]
    elseif slot.skip_link_children and not item.force_link_children then
        mode = World.LINK_MODE_NONE
    else
        mode = World.LINK_MODE_NODE_NAME
    end
    return index, mode
end

-- only item slots are moved onto the driver, by the game's own slot_type (player_character_constants.lua
-- slot_configuration): weapons, pocketables, devices, abilities. Not body / gear / companion gear (its unit_3p is the
-- companion itself), luggables (the game links those, see above), vfx / prop slots, or the player unit itself
-- (2026-10-05: her body was left standing where the driver spawned while the player ran on; a slot pointing at the
-- player would make the player a child of the driver)
local FloatSlots = require("scripts/settings/player_character/player_character_constants")
local FLOAT_SLOT_TYPES = { weapon = true, pocketable = true, device = true, ability = true }

local function float_slot_type(slot_name)
    local conf = FloatSlots and FloatSlots.slot_configuration and FloatSlots.slot_configuration[slot_name]
    return conf and conf.slot_type
end

local function float_item_slots(ext, fn)
    local slots = ext._equipment
    if not slots then
        return
    end
    for slot_name, slot in pairs(slots) do
        -- never units the game links itself: slots that reuse a world unit (use_existing_unit_3p, the luggable slot,
        -- player_character_constants.lua:614) are linked to the player by Luggable.link_to_player_unit
        -- (luggable.lua:108-114) without an unlink first; one moved to the driver crashed the game on pickup
        -- ("already linked to a different unit", 2026-10-05)
        local kind = FLOAT_SLOT_TYPES[float_slot_type(slot_name)]
        if kind and not slot.use_existing_unit_3p and slot.parent_unit_3p == ext._unit and unit_ok(slot.unit_3p)
            and slot.unit_3p ~= ext._unit then
            fn(slot)
        end
    end
end

-- the game's third-person items onto the driver (each unit once)
local function float_link_items(ext)
    local driver = ext.__qiangiq_oraxia_float_driver
    if not unit_ok(driver) then
        return
    end
    local links = ext.__qiangiq_oraxia_float_links or {}
    ext.__qiangiq_oraxia_float_links = links
    local world = ext.__qiangiq_world
    float_item_slots(ext, function(slot)
        local u = slot.unit_3p
        if links[u] == nil then
            local index, mode = float_item_link(slot, driver)
            if index then
                World.unlink_unit(world, u)
                World.link_unit(world, u, 1, driver, index, mode)
                links[u] = slot
            else
                links[u] = false -- left on the player
            end
        end
    end)
end

-- back onto the player, then the driver goes (called first thing in despawn)
FLOAT_RELEASE = function(ext)
    local world = ext.__qiangiq_world
    local links = ext.__qiangiq_oraxia_float_links
    if links then
        for u, slot in pairs(links) do
            if slot and unit_ok(u) and unit_ok(ext._unit) then
                local index, mode = float_item_link(slot, ext._unit)
                World.unlink_unit(world, u)
                World.link_unit(world, u, 1, ext._unit, index or 1, mode)
            end
        end
    end
    ext.__qiangiq_oraxia_float_links = nil
    if ext.__qiangiq_oraxia_float_st then
        ext.__qiangiq_oraxia_float_st.cam = 0
    end
    if ext._player ~= nil and ext._player == sync_me() then
        float_camera_set(0) -- the camera is mine only (another player's Oraxia must not touch it)
    end
    -- her units hang on the driver: unlink them first ("still has children attached to it" when the driver went)
    local kids = ext.__qiangiq_oraxia_float_kids
    if kids then
        for u in pairs(kids) do
            if unit_ok(u) then
                World.unlink_unit(world, u)
            end
        end
    end
    ext.__qiangiq_oraxia_float_kids = nil
    -- QIangIQsArmoryVis' stowed weapons hang on the driver too: back onto the player first
    if ext.__qiangiq_body_host == ext.__qiangiq_oraxia_float_driver then
        ext.__qiangiq_body_host = nil
    end
    local armory_vis = get_mod("QIangIQsArmoryVis")
    if armory_vis and armory_vis.release_host then
        armory_vis.release_host(ext)
    end
    if unit_ok(ext.__qiangiq_oraxia_float_driver) then
        delete_unit(ext.__qiangiq_oraxia_float_driver)
    end
    ext.__qiangiq_oraxia_float_driver = nil
end

local function apply(ext, first_person_mode)
    if not model_on() then
        despawn(ext)
        return
    end
    local world = ext.__qiangiq_world

    -- switching the floating form respawns the units (they are linked differently)
    if ext.__qiangiq_oraxia_float ~= float_on() then
        despawn(ext)
        ext.__qiangiq_oraxia_float = float_on()
    end
    local fp_arms = opt("first_person_arms") and true or false
    ext.__qiangiq_oraxia_fp = first_person_mode and true or false

    if ready[BODY] and not unit_ok(ext.__qiangiq_oraxia_unit) then
        ext.__qiangiq_oraxia_unit = float_kid(ext, spawn_linked(world, float_parent(ext), BODY_UNIT, false))
    end
    if ready[ARMS] and fp_arms and not unit_ok(ext.__qiangiq_oraxia_arms) then
        ext.__qiangiq_oraxia_arms = spawn_linked(world, ext._first_person_unit, ARMS_UNIT, true)
    elseif not fp_arms and ext.__qiangiq_oraxia_arms then
        delete_unit(ext.__qiangiq_oraxia_arms)
        ext.__qiangiq_oraxia_arms = nil
    end

    local body = ext.__qiangiq_oraxia_unit
    local arms = ext.__qiangiq_oraxia_arms
    apply_glow(body)
    apply_glow(arms)
    apply_tail(body)
    if unit_ok(body) then
        Unit.set_unit_visibility(body, not first_person_mode, true)
    end
    if unit_ok(arms) then
        Unit.set_unit_visibility(arms, first_person_mode and true or false, true)
    end

    -- clothing parts: spawned next to the body while their option is on, deleted when it is off
    local parts = ext.__qiangiq_oraxia_parts or {}
    local part_arms = ext.__qiangiq_oraxia_part_arms or {}
    ext.__qiangiq_oraxia_parts = parts
    ext.__qiangiq_oraxia_part_arms = part_arms
    for _, part in ipairs(PARTS) do
        local id = part.id
        local on = part_on(part)
        if on and ready[part.body] and unit_ok(body) and not unit_ok(parts[id]) then
            parts[id] = float_kid(ext, spawn_linked(world, float_parent(ext), unit_name(part.body), false))
        elseif not on and parts[id] then
            delete_unit(parts[id])
            parts[id] = nil
        end
        if unit_ok(parts[id]) then
            apply_part_glow(part, parts[id])
            Unit.set_unit_visibility(parts[id], not first_person_mode or part.fp_visible == true, true)
        end
        if part.arms then
            local want = on and fp_arms
            if want and ready[part.arms] and unit_ok(arms) and not unit_ok(part_arms[id]) then
                part_arms[id] = spawn_linked(world, ext._first_person_unit, unit_name(part.arms), true)
            elseif not want and part_arms[id] then
                delete_unit(part_arms[id])
                part_arms[id] = nil
            end
            if unit_ok(part_arms[id]) then
                apply_part_glow(part, part_arms[id])
                Unit.set_unit_visibility(part_arms[id], first_person_mode and true or false, true)
            end
        end
    end

    if opt("hide_body") then
        if not first_person_mode and unit_ok(body) then
            hide_body_slots(ext._equipment, "unit_3p")
        elseif first_person_mode and unit_ok(arms) then
            hide_body_slots(ext._equipment, "unit_1p")
        end
    end
end

-- Menu previews (operative select, inventory, lobby) --------------------------

local function ui_profile_is_mine(profile)
    -- __qiangiq_npc: the companion NPC spawned by QIangIQsCompanionSwap is nobody's character
    if not profile or profile.__qiangiq_npc then
        return false
    end
    -- skip previews of characters that belong to someone else (other players, bots)
    local players = Managers.player and Managers.player:players()
    local me = local_player()
    if players and profile.character_id then
        for _, player in pairs(players) do
            if player ~= me and player.character_id and player:character_id() == profile.character_id then
                return false
            end
        end
    end
    return true
end

local function ui_despawn(spawner)
    local unit = spawner.__qiangiq_oraxia_unit
    spawner.__qiangiq_oraxia_unit = nil
    spawner.__qiangiq_oraxia_parent = nil
    if unit_ok(unit) and spawner._world then
        -- same call ui_profile_spawner.lua uses for its own character unit
        World.destroy_unit(spawner._world, unit)
    end
    local parts = spawner.__qiangiq_oraxia_parts
    if parts then
        for id, part_unit in pairs(parts) do
            if unit_ok(part_unit) and spawner._world then
                World.destroy_unit(spawner._world, part_unit)
            end
            parts[id] = nil
        end
    end
end

local function ui_apply(spawner)
    local data = spawner._character_spawn_data
    if not data or not unit_ok(data.unit_3p) then
        return
    end
    -- ui_profile_spawner.lua:179-180 reads profile.archetype.breed
    local archetype = data.profile and data.profile.archetype
    local excluded = archetype and EXCLUDED_BREEDS[archetype.breed]
    if excluded or not (model_on() and opt("menu_previews") and ready[BODY] and ui_profile_is_mine(data.profile)) then
        if spawner.__qiangiq_oraxia_unit then
            ui_despawn(spawner)
            if spawner._visible then
                spawner:_update_items_visibility()
            end
        end
        return
    end
    if spawner.__qiangiq_oraxia_parent ~= data.unit_3p then
        ui_despawn(spawner)
    end
    local unit = spawner.__qiangiq_oraxia_unit
    if not unit_ok(unit) then
        local world = spawner._world
        unit = World.spawn_unit_ex(world, BODY_UNIT, nil, Unit.world_pose(data.unit_3p, 1))
        World.link_unit(world, unit, 1, data.unit_3p, 1, World.LINK_MODE_NODE_NAME)
        spawner.__qiangiq_oraxia_unit = unit
        spawner.__qiangiq_oraxia_parent = data.unit_3p
        tracked_ui[spawner] = true
    end
    apply_glow(unit)
    apply_tail(unit)
    Unit.set_unit_visibility(unit, spawner._visible and true or false, true)
    local parts = spawner.__qiangiq_oraxia_parts or {}
    spawner.__qiangiq_oraxia_parts = parts
    for _, part in ipairs(PARTS) do
        local id = part.id
        local on = part_on(part)
        if on and ready[part.body] and not unit_ok(parts[id]) then
            local world = spawner._world
            parts[id] = World.spawn_unit_ex(world, unit_name(part.body), nil, Unit.world_pose(data.unit_3p, 1))
            World.link_unit(world, parts[id], 1, data.unit_3p, 1, World.LINK_MODE_NODE_NAME)
        elseif not on and parts[id] then
            if unit_ok(parts[id]) then
                World.destroy_unit(spawner._world, parts[id])
            end
            parts[id] = nil
        end
        if unit_ok(parts[id]) then
            apply_part_glow(part, parts[id])
            Unit.set_unit_visibility(parts[id], spawner._visible and true or false, true)
        end
    end
    if spawner._visible and opt("hide_body") then
        hide_body_slots(data.slots, "unit_3p")
    end
end

-- Physics ------------------------------------------------------------------------
-- The model's own physics bones (the avatar's "Phy_*" chains) are in the compiled units as extra nodes
-- that the player's skeleton does not have, so node-name linking leaves them at their rest pose. Each
-- one is driven here as a damped spring: its tip is a point that lags behind where the rest pose puts
-- it and is pulled back, and the bone is turned to point at it. Only engine calls the game's own
-- scripts use: Unit.node / has_node / local_rotation / local_position / world_position /
-- world_rotation / set_local_rotation, Quaternion.multiply / inverse / rotate / axis_angle,
-- Vector3.cross / dot / length.
-- { bone, parent, area, length (m) }, parents first
-- (from the fitted armature). A parent that is not in this list is a normal skeleton / helper node.
local JIGGLE_BONES = {
    { "game_c1_cloth29_lllegsnewcloth", "j_spine", "cloth", 0.100 },
    { "game_c1_cloth31_lllegsnewcloth", "game_c1_cloth29_lllegsnewcloth", "cloth", 0.412 },
    { "game_c1_cloth34_lllegsnewcloth", "game_c1_cloth31_lllegsnewcloth", "cloth", 0.466 },
    { "game_c1_cloth66", "j_spine", "cloth", 0.078 },
    { "game_c1_cloth67", "game_c1_cloth66", "cloth", 0.089 },
    { "game_c1_cloth68", "game_c1_cloth67", "cloth", 0.088 },
    { "game_c1_cloth70", "game_c1_cloth68", "cloth", 0.091 },
    { "game_c1_cloth71", "game_c1_cloth70", "cloth", 0.093 },
    { "game_c1_cloth73", "game_c1_cloth71", "cloth", 0.104 },
    { "game_c1_cloth74", "game_c1_cloth73", "cloth", 0.105 },
    { "game_c1_cloth76", "game_c1_cloth74", "cloth", 0.114 },
    { "game_c1_cloth77", "game_c1_cloth76", "cloth", 0.121 },
    { "game_c1_cloth17_lllegsnewcloth", "j_hips", "cloth", 0.090 },
    { "game_c1_cloth19_lllegsnewcloth", "game_c1_cloth17_lllegsnewcloth", "cloth", 0.434 },
    { "game_c1_cloth22_lllegsnewcloth", "game_c1_cloth19_lllegsnewcloth", "cloth", 0.452 },
    { "game_c1_cloth1_afronthipcloth", "j_hips", "cloth", 0.047 },
    { "game_c1_cloth8_afronthipcloth", "game_c1_cloth1_afronthipcloth", "cloth", 0.062 },
    { "game_c1_cloth6_afronthipcloth", "game_c1_cloth8_afronthipcloth", "cloth", 0.060 },
    { "game_c1_cloth5_afronthipcloth", "game_c1_cloth6_afronthipcloth", "cloth", 0.061 },
    { "game_c1_cloth3_afronthipcloth", "game_c1_cloth5_afronthipcloth", "cloth", 0.053 },
    { "game_c1_cloth2_afronthipcloth", "game_c1_cloth3_afronthipcloth", "cloth", 0.057 },
    { "game_c1_cloth12_afronthipcloth", "game_c1_cloth2_afronthipcloth", "cloth", 0.057 },
    { "game_c1_cloth11_afronthipcloth", "game_c1_cloth12_afronthipcloth", "cloth", 0.071 },
    { "game_c1_cloth41_lllegsnewcloth", "j_hips", "cloth", 0.090 },
    { "game_c1_cloth43_lllegsnewcloth", "game_c1_cloth41_lllegsnewcloth", "cloth", 0.434 },
    { "game_c1_cloth46_lllegsnewcloth", "game_c1_cloth43_lllegsnewcloth", "cloth", 0.452 },
}
-- per 60 fps frame: pull = share of the remaining offset removed, drag = share of velocity lost;
-- max_angle = largest swing of one bone from its rest pose (degrees); slider = the option that scales the area.
-- flow = every bone of the chain is its own free point (the chain bends bone by bone and a wave runs down
-- it); without it the bones after the first only follow the first one (one soft lump).
-- carry = share of the character's own travel the points are taken along with (1 = no trailing while running);
-- hang = the area takes part in the "hang" option (rest direction leaned towards straight down);
-- drape = the area always hangs straight down in the world (cloth hung from an arm);
-- total = largest lean of any bone from where it would point if its whole chain were stiff (degrees).
-- bend_step = largest difference between the bends of two neighbouring joints of a chain (degrees).
-- segments = the chain is simulated as this many long segments (each one spring point, like a chain of a few
-- long bones) and their bend is spread smoothly over its bones. For chains of many short bones: one free point
-- per short bone let every joint flip from side to side every frame while running.
-- own = prefix of the area's own settings (<own>_stiffness, _damping, _limit, _gravity, _trail, _segments),
-- used instead of the settings for all areas. hang_slider = the area's own "hang" (gravity) setting.
local JIGGLE_GROUPS = {
    breast = { pull = 0.22, drag = 0.16, max_angle = 14, slider = "jiggle_breast" },
    butt = { pull = 0.28, drag = 0.20, max_angle = 10, slider = "jiggle_butt" },
    thigh = { pull = 0.30, drag = 0.22, max_angle = 6, slider = "jiggle_butt" },
    tail = { pull = 0.07, drag = 0.34, max_angle = 32, slider = "jiggle_tail", flow = true, carry = 0.92, total = 50, own = "tail_phys", segments = 6, gravity = 0.3 },
    hair = { pull = 0.05, drag = 0.30, max_angle = 40, slider = "jiggle_hair", flow = true, carry = 0.92, hang = true, total = 45, hang_slider = "jiggle_hair_gravity", gravity = 0.4 },
    ear = { pull = 0.25, drag = 0.18, max_angle = 14, slider = "jiggle_ear" },
    drape = { pull = 0.10, drag = 0.40, max_angle = 28, slider = "jiggle_cloth", flow = true, carry = 0.95, drape = true },
    plume = { pull = 0.07, drag = 0.34, max_angle = 30, slider = "jiggle_hair", flow = true, carry = 0.92, total = 30 },
    cloth = { pull = 0.08, drag = 0.36, max_angle = 35, slider = "jiggle_cloth", flow = true, carry = 0.92, hang = true, total = 40 },
}
-- this model's own values
JIGGLE_GROUPS.cloth.pull = 0.06
JIGGLE_GROUPS.cloth.drag = 0.5
JIGGLE_GROUPS.cloth.max_angle = 6
JIGGLE_GROUPS.cloth.total = 10
JIGGLE_GROUPS.cloth.carry = 0.98
local jiggle_state = setmetatable({}, { __mode = "k" })
-- options, read once per change instead of every frame
local JIGGLE = { on = true, stiffness = 1, damping = 1, limit = 1, hang = 0, amount = {}, tune = {}, layout = 0 }

local function jiggle_read_settings()
    JIGGLE.on = opt("jiggle") ~= false
    JIGGLE.stiffness = math.max(opt("jiggle_stiffness") or 1, 0.05)
    JIGGLE.damping = math.max(opt("jiggle_damping") or 1, 0.05)
    JIGGLE.limit = math.max(opt("jiggle_limit") or 1, 0.05)
    JIGGLE.hang = math.max(opt("jiggle_hang") or 0, 0)
    JIGGLE.lift = math.rad(opt("shape_breast_lift") or 0)
    local layout = 0
    for name, g in pairs(JIGGLE_GROUPS) do
        JIGGLE.amount[name] = math.max(opt(g.slider) or 1, 0)
        -- the values each area uses: the settings for all areas, or the area's own
        local t = { stiffness = JIGGLE.stiffness, damping = JIGGLE.damping, limit = JIGGLE.limit, hang = JIGGLE.hang, trail = 1, segments = g.segments }
        if g.hang_slider then
            t.hang = math.max(opt(g.hang_slider) or g.gravity or JIGGLE.hang, 0)
        end
        if g.own then
            t.stiffness = math.max(opt(g.own .. "_stiffness") or 1, 0.05)
            t.damping = math.max(opt(g.own .. "_damping") or 1, 0.05)
            t.limit = math.max(opt(g.own .. "_limit") or 1, 0.05)
            t.hang = math.max(opt(g.own .. "_gravity") or g.gravity or 0, 0)
            t.trail = math.max(opt(g.own .. "_trail") or 1, 0)
            if g.segments then
                t.segments = math.max(math.floor((opt(g.own .. "_segments") or g.segments) + 0.5), 1)
                layout = layout * 17 + t.segments
            end
        end
        JIGGLE.tune[name] = t
    end
    -- a new segment count rebuilds every unit's chains
    JIGGLE.layout = layout
end

local function jiggle_init(unit)
    local bones, by_name = {}, {}
    for _, def in ipairs(JIGGLE_BONES) do
        local name, parent_name = def[1], def[2]
        local parent = by_name[parent_name]
        -- usable when the unit has the bone and the node it hangs from (parts only carry what they need)
        if Unit.has_node(unit, name) and (parent or Unit.has_node(unit, parent_name)) then
            local node = Unit.node(unit, name)
            local b = {
                node = node,
                group = def[3],
                parent = parent,
                parent_node = not parent and Unit.node(unit, parent_name) or nil,
                rest = QuaternionBox(Unit.local_rotation(unit, node)),
                lpos = Vector3Box(Unit.local_position(unit, node)),
                -- the bone runs along its own local Z for its length (the compiler writes every node's
                -- local transform as glTF (x, y, z) -> (x, -z, y), and a glTF bone runs along its Y)
                tip = Vector3Box(Vector3(0, 0, def[4])),
                len = def[4],
            }
            bones[#bones + 1] = b
            by_name[name] = b
        end
    end
    -- segment chains: one unbranched chain per group, hanging from a skeleton node, parents first
    local chains = {}
    for group, g in pairs(JIGGLE_GROUPS) do
        local nseg = JIGGLE.tune[group] and JIGGLE.tune[group].segments or g.segments
        if nseg and nseg > 0 then
            local list, ok = {}, true
            for _, b in ipairs(bones) do
                if b.group == group then
                    if (#list == 0 and b.parent) or (#list > 0 and b.parent ~= list[#list]) then
                        ok = false
                    end
                    list[#list + 1] = b
                end
            end
            if ok and #list >= 2 then
                -- split by length into segments; each bone's place along the chain (model metres)
                local total_len = 0
                for _, b in ipairs(list) do
                    b.arc = total_len + b.len * 0.5
                    total_len = total_len + b.len
                end
                local n = math.min(nseg, #list)
                local segs = {}
                for _, b in ipairs(list) do
                    local k = math.min(math.floor(b.arc / total_len * n) + 1, n)
                    local seg = segs[k]
                    if not seg then
                        seg = { first = #list + 1, last = 0, len = 0, start = math.huge }
                        segs[k] = seg
                    end
                    b.chain = true
                end
                local idx = {}
                for i, b in ipairs(list) do
                    local k = math.min(math.floor(b.arc / total_len * n) + 1, n)
                    local seg = segs[k]
                    seg.first = math.min(seg.first, i)
                    seg.last = math.max(seg.last, i)
                    seg.len = seg.len + b.len
                    seg.start = math.min(seg.start, b.arc - b.len * 0.5)
                end
                local packed = {}
                for k = 1, n do
                    if segs[k] then
                        local seg = segs[k]
                        seg.centre = seg.start + seg.len * 0.5
                        packed[#packed + 1] = seg
                    end
                end
                chains[#chains + 1] = { group = group, bones = list, segs = packed }
            end
        end
    end
    local free = {}
    for _, b in ipairs(bones) do
        if not b.chain then
            free[#free + 1] = b
        end
    end
    return { bones = free, chains = chains, active = false, layout = JIGGLE.layout }
end

local function jiggle_rest(unit, state)
    for _, b in ipairs(state.bones) do
        Unit.set_local_rotation(unit, b.node, b.rest:unbox())
        b.px = nil
    end
    for _, chain in ipairs(state.chains) do
        for _, b in ipairs(chain.bones) do
            Unit.set_local_rotation(unit, b.node, b.rest:unbox())
        end
        for _, seg in ipairs(chain.segs) do
            seg.px = nil
        end
    end
    state.rx = nil
    state.active = false
end

-- a segment chain (group with `segments`) has physics of its own: a chain of a few long, straight segments,
-- each turned about its head like one long flowing bone (spring point at its end with pull, drag, carry,
-- max_angle around its rest direction, total around the stiff chain's direction). The bones only show it:
-- each segment's turn is spread over its bones as a bend that blends into the neighbouring segments' bends,
-- so the tail curves smoothly. What the bones do is never read back into the simulation.
local function jiggle_chain(unit, chain, travel, f)
    local g = JIGGLE_GROUPS[chain.group]
    local amount = JIGGLE.amount[chain.group] or 1
    local bones, segs = chain.bones, chain.segs
    local first = bones[1]
    local parent_rot = Unit.world_rotation(unit, first.parent_node)
    local head = Unit.world_position(unit, first.node)
    local len = Vector3.length(first.lpos:unbox())
    local scale = len > 1e-3 and Vector3.length(head - Unit.world_position(unit, first.parent_node)) / len or 1
    if scale < 1e-4 then
        scale = 1
    end
    if amount <= 0 then
        for _, b in ipairs(bones) do
            Unit.set_local_rotation(unit, b.node, b.rest:unbox())
        end
        for _, seg in ipairs(segs) do
            seg.px = nil
        end
        return
    end
    local tune = JIGGLE.tune[chain.group] or JIGGLE
    local keep = (1 - math.min(g.drag * tune.damping, 0.95)) ^ f
    local pull = 1 - (1 - math.min(g.pull * tune.stiffness / amount, 0.95)) ^ f
    local max_angle = math.min(math.rad(g.max_angle) * amount * tune.limit, 1.4)
    local total = g.total and math.min(math.rad(g.total) * amount * tune.limit, 3)
    local carry = 1 - (1 - g.carry) * (tune.trail or 1)
    local hang = tune.hang or 0
    -- gravity: the direction a segment is pulled towards, leaned towards straight down (world Z is up)
    local function lean(d)
        if hang <= 0 then
            return d
        end
        local l = d + Vector3(0, 0, -hang)
        local ll = Vector3.length(l)
        return ll > 1e-4 and l / ll or d
    end
    -- the segments: rest shape under what the segments above do, and the stiff chain's direction
    local bends = {}
    local rot, h = parent_rot, head
    local rigid_rot, rigid_h = parent_rot, head
    for k, seg in ipairs(segs) do
        local r, hh, seg_head = rot, h, nil
        local rr, rh, rigid_head = rigid_rot, rigid_h, nil
        for i = seg.first, seg.last do
            local b = bones[i]
            if i > 1 then
                hh = hh + Quaternion.rotate(r, b.lpos:unbox()) * scale
                rh = rh + Quaternion.rotate(rr, b.lpos:unbox()) * scale
            end
            seg_head = seg_head or hh
            rigid_head = rigid_head or rh
            r = Quaternion.multiply(r, b.rest:unbox())
            rr = Quaternion.multiply(rr, b.rest:unbox())
        end
        local tip = bones[seg.last].tip:unbox()
        local rest_tip = hh + Quaternion.rotate(r, tip) * scale
        local chord = rest_tip - seg_head
        local length = Vector3.length(chord)
        local turn_q
        local bend = Vector3(0, 0, 0)
        if length > 1e-6 then
            local rest_dir = chord / length
            local goal_dir = lean(rest_dir)
            local goal_tip = seg_head + goal_dir * length
            local p, pp = goal_tip, goal_tip
            if seg.px then
                p = Vector3(seg.px, seg.py, seg.pz)
                pp = Vector3(seg.qx, seg.qy, seg.qz)
                local along = travel * carry
                p, pp = p + along, pp + along
                if Vector3.length(p - goal_tip) > 4 * length + 0.5 then
                    p, pp = goal_tip, goal_tip -- teleported: start over at rest
                end
            end
            local nxt = p + (p - pp) * keep + (goal_tip - p) * pull
            local dir = nxt - seg_head
            local dl = Vector3.length(dir)
            dir = dl > 1e-6 and dir / dl or goal_dir
            local axis = Vector3.cross(goal_dir, dir)
            local al = Vector3.length(axis)
            local angle = math.acos(math.max(-1, math.min(1, Vector3.dot(goal_dir, dir))))
            if al > 1e-6 and angle > max_angle then
                dir = Quaternion.rotate(Quaternion.axis_angle(axis / al, max_angle), goal_dir)
            end
            if total then
                local rd = rh + Quaternion.rotate(rr, tip) * scale - rigid_head
                local rl = Vector3.length(rd)
                if rl > 1e-6 then
                    rd = lean(rd / rl)
                    local ax = Vector3.cross(rd, dir)
                    local axl = Vector3.length(ax)
                    if axl > 1e-6 and math.acos(math.max(-1, math.min(1, Vector3.dot(rd, dir)))) > total then
                        dir = Quaternion.rotate(Quaternion.axis_angle(ax / axl, total), rd)
                    end
                end
            end
            axis = Vector3.cross(rest_dir, dir)
            al = Vector3.length(axis)
            angle = math.acos(math.max(-1, math.min(1, Vector3.dot(rest_dir, dir))))
            if al > 1e-6 and angle > 1e-5 then
                turn_q = Quaternion.axis_angle(axis / al, angle)
                bend = axis / al * angle
            else
                dir = rest_dir
            end
            local e = seg_head + dir * length
            seg.qx, seg.qy, seg.qz = p.x, p.y, p.z
            seg.px, seg.py, seg.pz = e.x, e.y, e.z
        end
        bends[k] = bend / seg.len
        -- the next segment hangs from this one turned as one piece about its head
        if turn_q then
            rot = Quaternion.multiply(turn_q, r)
            h = seg_head + Quaternion.rotate(turn_q, hh - seg_head)
        else
            rot, h = r, hh
        end
        rigid_rot, rigid_h = rr, rh
    end
    -- the bones: bend per model metre taken between the segment centres, so the curve has no kinks
    local n = #segs
    local k = 1
    rot, h = parent_rot, head
    for i, b in ipairs(bones) do
        while i > segs[k].last do
            k = k + 1
        end
        local seg = segs[k]
        local d = bends[k]
        if b.arc < seg.centre and k > 1 then
            local t = (b.arc - segs[k - 1].centre) / (seg.centre - segs[k - 1].centre)
            d = bends[k - 1] * (1 - t) + d * t
        elseif b.arc > seg.centre and k < n then
            local t = (b.arc - seg.centre) / (segs[k + 1].centre - seg.centre)
            d = d * (1 - t) + bends[k + 1] * t
        end
        local turn = d * b.len
        local ta = Vector3.length(turn)
        local world_rot = Quaternion.multiply(rot, b.rest:unbox())
        if ta > 1e-6 then
            world_rot = Quaternion.multiply(Quaternion.axis_angle(turn / ta, ta), world_rot)
        end
        Unit.set_local_rotation(unit, b.node, Quaternion.multiply(Quaternion.inverse(rot), world_rot))
        rot = world_rot
    end
end

local function jiggle_update(unit, dt)
    if not unit_ok(unit) then
        return
    end
    local state = jiggle_state[unit]
    if state and state.layout ~= JIGGLE.layout then
        jiggle_rest(unit, state)
        state = nil
    end
    if not state then
        state = jiggle_init(unit)
        jiggle_state[unit] = state
    end
    if not JIGGLE.on then
        if state.active then
            jiggle_rest(unit, state)
        end
        return
    end
    state.active = true
    local f = math.min(dt or 0.0167, 0.05) * 60
    -- how far the character itself travelled since the last frame (node 1 = the unit's root)
    local root = Unit.world_position(unit, 1)
    local travel = Vector3(0, 0, 0)
    if state.rx then
        travel = root - Vector3(state.rx, state.ry, state.rz)
        if Vector3.length(travel) > 2 then
            travel = Vector3(0, 0, 0)
        end
    end
    state.rx, state.ry, state.rz = root.x, root.y, root.z
    -- ground level under the character (its root is at its feet) and its facing, for draped cloth
    local floor = root.z + 0.02
    local back = Quaternion.forward(Unit.world_rotation(unit, 1))
    for _, b in ipairs(state.bones) do
        local g = JIGGLE_GROUPS[b.group]
        local amount = JIGGLE.amount[b.group] or 1
        local tune = JIGGLE.tune[b.group] or JIGGLE
        local parent = b.parent
        local parent_rot, head, scale
        if parent then
            parent_rot, scale = parent.rot, parent.scale
            head = parent.head + Quaternion.rotate(parent_rot, b.lpos:unbox()) * scale
        else
            parent_rot = Unit.world_rotation(unit, b.parent_node)
            head = Unit.world_position(unit, b.node)
            -- world size of one model unit (characters can be scaled)
            local len = Vector3.length(b.lpos:unbox())
            scale = len > 1e-3 and Vector3.length(head - Unit.world_position(unit, b.parent_node)) / len or 1
            if scale < 1e-4 then
                scale = 1
            end
        end
        local rest_rot = Quaternion.multiply(parent_rot, b.rest:unbox())
        if b.group == "breast" and not parent and JIGGLE.lift and JIGGLE.lift ~= 0 then
            -- breast lift: the rest direction turned towards world up (Z is up) about the axis across bone and up
            local d = Quaternion.rotate(rest_rot, b.tip:unbox())
            local ax = Vector3.cross(d, Vector3(0, 0, 1))
            local axl = Vector3.length(ax)
            if axl > 1e-4 then
                rest_rot = Quaternion.multiply(Quaternion.axis_angle(ax / axl, JIGGLE.lift), rest_rot)
            end
        end
        -- where the bone would point if the whole chain above it were stiff
        local rigid_rot = parent and Quaternion.multiply(parent.rigid, b.rest:unbox()) or rest_rot
        local tip_off = Quaternion.rotate(rest_rot, b.tip:unbox()) * scale
        local length = Vector3.length(tip_off)
        local world_rot = rest_rot
        if amount <= 0 then
            b.px = nil -- area switched off: stay on the rest pose
        elseif length > 1e-6 then
            local keep = (1 - math.min(g.drag * tune.damping, 0.95)) ^ f
            local pull = 1 - (1 - math.min(g.pull * tune.stiffness / amount, 0.95)) ^ f
            local max_angle = math.min(math.rad(g.max_angle) * amount * tune.limit, 1.4)
            local rest_dir = tip_off / length
            local rest_tip = head + tip_off
            local flow = g.flow
            -- goal_dir: the direction the bone is pulled towards and limited around
            local goal_dir = rest_dir
            if flow and g.drape then
                -- loose cloth hung from a limb: straight down in the world, whatever the limb does
                -- (its modelled angle to the limb is only right for the pose it was modelled in)
                goal_dir = Vector3(0, 0, -1)
                rest_tip = head + goal_dir * length
            elseif flow and g.hang and tune.hang > 0 then
                -- lean the direction the bone is pulled towards to straight down (world Z is up)
                local lean = rest_dir + Vector3(0, 0, -tune.hang)
                local ll = Vector3.length(lean)
                if ll > 1e-4 then
                    goal_dir = lean / ll
                    rest_tip = head + goal_dir * length
                end
            end
            -- a tip kept in the world lags when the body moves. Flowing chains keep every tip in the
            -- world; in the other areas only the bone on a normal skeleton node does, and the bones after
            -- it keep theirs relative to their own head, so they follow the bone before them
            local world_tip = flow or not parent
            local origin = world_tip and Vector3(0, 0, 0) or head
            local p, pp = rest_tip, rest_tip
            if b.px then
                p = origin + Vector3(b.px, b.py, b.pz)
                pp = origin + Vector3(b.qx, b.qy, b.qz)
                if flow then
                    local along = travel * (1 - (1 - g.carry) * (tune.trail or 1))
                    p, pp = p + along, pp + along
                end
                if Vector3.length(p - rest_tip) > 4 * length + 0.5 then
                    p, pp = rest_tip, rest_tip -- teleported: start over at rest
                end
            end
            local k, q = keep, pull
            if parent and not flow then
                -- a follower, not a second spring
                k, q = keep * 0.35, math.min(pull * 1.6, 0.9)
            end
            local nxt = p + (p - pp) * k + (rest_tip - p) * q
            local dir = nxt - head
            local dl = Vector3.length(dir)
            dir = dl > 1e-6 and dir / dl or goal_dir
            -- keep the swing within max_angle of the goal direction
            local axis = Vector3.cross(goal_dir, dir)
            local al = Vector3.length(axis)
            local angle = math.acos(math.max(-1, math.min(1, Vector3.dot(goal_dir, dir))))
            if al > 1e-6 and angle > max_angle then
                dir = Quaternion.rotate(Quaternion.axis_angle(axis / al, max_angle), goal_dir)
            end
            if g.drape and (head + dir * length).z < floor then
                -- the cloth is longer than the arm is high: what reaches the ground lies on it, trailing
                -- the way it already leans (behind the character when it hangs dead straight)
                local dz = math.max(-length, math.min(length, floor - head.z))
                local flat = math.sqrt(math.max(0, length * length - dz * dz))
                local hx, hy = dir.x, dir.y
                local hn = math.sqrt(hx * hx + hy * hy)
                if hn < 1e-3 then
                    hx, hy, hn = -back.x, -back.y, math.max(math.sqrt(back.x * back.x + back.y * back.y), 1e-3)
                end
                dir = Vector3(hx / hn * flat, hy / hn * flat, dz) / length
            end
            if g.total then
                -- and the whole chain within `total` of its stiff shape: per-bone limits add up along a
                -- long chain, which let the far end fold right over
                local rigid_dir = Quaternion.rotate(rigid_rot, b.tip:unbox())
                local rl = Vector3.length(rigid_dir)
                if rl > 1e-6 then
                    rigid_dir = rigid_dir / rl
                    local total = math.min(math.rad(g.total) * amount * tune.limit, 3)
                    local ax = Vector3.cross(rigid_dir, dir)
                    local axl = Vector3.length(ax)
                    if axl > 1e-6 and math.acos(math.max(-1, math.min(1, Vector3.dot(rigid_dir, dir)))) > total then
                        dir = Quaternion.rotate(Quaternion.axis_angle(ax / axl, total), rigid_dir)
                    end
                end
            end
            if flow and g.bend_step and parent and parent.group == b.group and parent.bend_x then
                -- snake-like chains: the bend of a joint (rotation from its goal direction, as axis * angle)
                -- may differ from the bend of the joint before it by at most bend_step, so the curvature
                -- changes gradually along the chain instead of kinking from one bone to the next
                local bax = Vector3.cross(goal_dir, dir)
                local bal = Vector3.length(bax)
                local bang = math.acos(math.max(-1, math.min(1, Vector3.dot(goal_dir, dir))))
                local bend = bal > 1e-6 and bax / bal * bang or Vector3(0, 0, 0)
                local parent_bend = Vector3(parent.bend_x, parent.bend_y, parent.bend_z)
                local diff = bend - parent_bend
                local dl2 = Vector3.length(diff)
                local step = math.rad(g.bend_step) * amount * tune.limit
                if dl2 > step then
                    bend = parent_bend + diff * (step / dl2)
                    local bl = Vector3.length(bend)
                    if bl > max_angle then
                        bend, bl = bend * (max_angle / bl), max_angle
                    end
                    dir = bl > 1e-6 and Quaternion.rotate(Quaternion.axis_angle(bend / bl, bl), goal_dir) or goal_dir
                end
            end
            if g.bend_step then
                -- this joint's final bend, for the next bone of the chain (this frame only)
                local bax = Vector3.cross(goal_dir, dir)
                local bal = Vector3.length(bax)
                if bal > 1e-6 then
                    local bend = bax / bal * math.acos(math.max(-1, math.min(1, Vector3.dot(goal_dir, dir))))
                    b.bend_x, b.bend_y, b.bend_z = bend.x, bend.y, bend.z
                else
                    b.bend_x, b.bend_y, b.bend_z = 0, 0, 0
                end
            end
            -- turn the bone from its rest direction to that direction
            axis = Vector3.cross(rest_dir, dir)
            al = Vector3.length(axis)
            angle = math.acos(math.max(-1, math.min(1, Vector3.dot(rest_dir, dir))))
            if al > 1e-6 and angle > 1e-5 then
                world_rot = Quaternion.multiply(Quaternion.axis_angle(axis / al, angle), rest_rot)
            elseif angle < 1 then
                dir = rest_dir
            end
            nxt = head + dir * length
            local sp, sn = p - origin, nxt - origin
            b.qx, b.qy, b.qz = sp.x, sp.y, sp.z
            b.px, b.py, b.pz = sn.x, sn.y, sn.z
        end
        Unit.set_local_rotation(unit, b.node, Quaternion.multiply(Quaternion.inverse(parent_rot), world_rot))
        -- kept for this bone's children, this frame only
        b.rot, b.head, b.scale, b.rigid = world_rot, head, scale, rigid_rot
    end
    for _, chain in ipairs(state.chains) do
        jiggle_chain(unit, chain, travel, f)
    end
end

-- the body and every clothing part carry their own copy of the bones; each is driven from the same
-- skeleton nodes with the same numbers, so they move together
local function jiggle_all(body, parts, dt)
    jiggle_update(body, dt)
    if parts then
        for _, unit in pairs(parts) do
            jiggle_update(unit, dt)
        end
    end
end

-- Oraxia's spider legs (gen_mods2 inserts this for models with spider_legs): procedural stepping.
-- Each leg (5 bones from the hips, game_<l|r>2_leg<a|b>1..5) keeps its foot planted on a ground point. The four
-- home points form a square around her (front-left, front-right, back-left, back-right; user request with the
-- reference video, 2026-10-04). The legs move in diagonal pairs: when a home point has drifted more than
-- SPIDER.step from its foot, that leg's pair lifts both feet and arcs them to their new points while the other pair
-- stays planted, so two feet are always on the ground. The chain reaches the foot with FABRIK, then every bone is
-- turned from its rest direction to its new direction (rest pose = the modelled pose, knees keep their bend side).
-- Options (mod settings, read every frame): spider_scale (leg size), spider_distance (square size), spider_step_time
-- (seconds per step), spider_snappiness (0 smooth .. 1 snaps out and in), spider_min_ground (seconds a pair stays
-- planted before it may step again), spider_walls (a foot whose point is blocked by a wall plants on the wall),
-- spider_curl (legs close around her in a cocoon when her combat ability starts, spider_cocoon_time seconds; read as Dio's Mercy Skins does:
-- unit_data_system components "combat_ability_action".current_action_name and "combat_ability".active).
-- Calls: PhysicsWorld.raycast against level geometry only ("types", "statics", "filter_player_mover", as the falling
-- player's ground check, player_character_state_falling.lua:52; until 2026-10-05 "both" + "filter_ground_material_check"
-- (material_query.lua:21), which also hit enemies: in crowds the feet planted on them, curled up and jumped around),
-- World.physics_world as scripts/components/bot_jump_assist.lua:52; Unit / Quaternion / Vector3 calls of notes 00.
local SPIDER = {
    span = 0.30,        -- default of the spider_distance slider (1x the footholds below)
    -- Footholds and gait from her own ability-4 clips in the Warframe extract (Powers/Oraxia, decoded with
    -- wfanim.py; leg reach to the tip 3.72 m there, all values below are shares of the leg length):
    --   GroundIdleRifle: front legs (A) out 1.50 m and 0.55 m ahead of the hips, back legs (B) out 0.86 m and
    --   2.10 m behind.  WalkForward (0.97 s cycle at 5.5 m/s): diagonal pairs (front-left + back-right, then
    --   front-right + back-left), each pair in the air half the cycle; a foot lands about speed x stance / 2 ahead
    --   of its idle spot; the swing lifts the foot up to 1.4 m (0.38) with the peak at 40 % of the swing; the
    --   knee joint (3) rises about 0.75 m (0.2) during the swing; the hips dip 0.1 m while a pair is up.
    front_out = 0.40, front_fwd = 0.15,
    back_out = 0.23, back_fwd = -0.56,
    lift_max = 0.38,    -- highest swing, share of the leg length
    lift_per_m = 0.25,  -- swing height per metre of step (5.5 m step -> 1.4 m)
    swing_knee = 0.20,  -- knee rise at mid-swing, share of the leg length
    step = 0.11,        -- a pair steps when a home point drifted this share of the leg length from its foot
    settle = 0.03,      -- threshold while standing still (feet settle into the square)
    step_time = 0.45,   -- seconds per step (one pair's swing, half her 0.97 s walk cycle)
    lift = 0.03,        -- smallest swing height (settling steps), share of the leg length
    arch_up = 0.15,     -- apex above the hip, share of the leg length (8.6 m legs: 1.3 m, a bit above her head as
                        -- the user asked; her clips have it at shoulder height, 0.27 m above the hips of a 3.7 m leg)
    arch_out = 0.20,    -- apex out toward the foot, share of the leg length
    probe = 3.0,        -- raycast from this far above the home point, twice as far down
}
-- prefix, diagonal pair, side (x: -1 left), front / back (y: +1 front; the character faces its root's +y)
local SPIDER_LEGS = {
    { "game_l2_lega", 1, -1, 1 }, { "game_r2_legb", 1, 1, -1 },
    { "game_r2_lega", 2, 1, 1 }, { "game_l2_legb", 2, -1, -1 },
}

-- Cocoon on ability (user request 2026-10-04): it shields her face and torso. The upper pair (A legs) comes from above
-- and behind her head and crosses in front of her face just above eye level; the lower pair (B legs) comes round her
-- sides at the waist and crosses in front of her torso below eye level. The gap between them (about 1.3-1.95 m,
-- eyes at ~1.65 m) is the slit she sees through in first person. The legs shrink to COCOON.scale while closed so
-- they wrap tightly. Body frame: x right, y forward, z up from her root.
local COCOON = {
    scale = 0.45,
    -- per pair: apex, foot, segment-1 direction, arc bulge (share of the leg length); x is mirrored per side
    upper = { apex = { 0.40, -0.20, 2.30 }, foot = { -0.10, 0.42, 1.90 }, d1 = { 0.25, -0.35, 1.0 }, bulge = { 0.0, 0.10, 0.06 } },
    lower = { apex = { 0.62, 0.05, 1.05 }, foot = { -0.10, 0.42, 1.38 }, d1 = { 1.0, -0.3, 0.1 }, bulge = { 0.10, 0.06, -0.05 } },
}

-- View cocoon (user's first-person sketch and notes, 2026-10-04): each leg folds into a hairpin across the view. The
-- two long segments do the covering: segment 2 runs from past one screen edge to the fold, segment 3 comes back past
-- the same edge, and the hook (segments 4, 5) carries on out of the view. Two legs above the eyes, two below, and the
-- slit between them at eye level. Screen coordinates: sx -1..1 = left..right edge, sy -1..1 = bottom..top, taken at
-- the depth COCOON_VIEW_DIST in front of the camera (first_person component position / rotation); the strands get the
-- length they need (per-bone scale), so they span the view at that distance. FOV taken as 97 x 65 degrees
-- (assumed, not read from the game).
local COCOON_VIEW_DIST = 0.45
local COCOON_TAN_X, COCOON_TAN_Y = 1.13, 0.637
local COCOON_VIEW = {
    upper_left = { start = { -1.35, 0.95 }, fold = { 0.85, 0.88 }, back = { -1.35, 0.78 } },
    upper_right = { start = { 1.35, 0.70 }, fold = { -0.85, 0.64 }, back = { 1.35, 0.56 } },
    lower_left = { start = { -1.35, -0.42 }, fold = { 0.85, -0.50 }, back = { -1.35, -0.58 } },
    lower_right = { start = { 1.35, -0.68 }, fold = { -0.85, -0.76 }, back = { 1.35, -0.86 } },
}

local SPIDER_STATE = setmetatable({}, { __mode = "k" }) -- per legs unit

local function v_norm(v)
    local l = Vector3.length(v)
    return l > 1e-6 and v * (1 / l) or Vector3(0, 0, 1)
end

local function q_from_to(a, b)
    local d = math.max(-1, math.min(1, Vector3.dot(a, b)))
    local axis = Vector3.cross(a, b)
    if Vector3.length(axis) < 1e-6 then
        return Quaternion.axis_angle(Vector3(0, 0, 1), d < 0 and math.pi or 0)
    end
    return Quaternion.axis_angle(v_norm(axis), math.acos(d))
end

local function spider_init(unit)
    local legs = {}
    for _, def in ipairs(SPIDER_LEGS) do
        local prefix, pair = def[1], def[2]
        local leg = { pair = pair, sx = def[3], sy = def[4], bones = {} }
        for i = 1, 5 do
            local name = prefix .. i
            if not Unit.has_node(unit, name) then
                leg = nil
                break
            end
            local node = Unit.node(unit, name)
            leg.bones[i] = { node = node, rest = QuaternionBox(Unit.local_rotation(unit, node)) }
        end
        if leg then
            -- bone 1 hangs from the hips (bones.json: parent j_hips); part units keep their bones' parents
            if not Unit.has_node(unit, "j_hips") then
                leg = nil
            end
        end
        if leg then
            leg.hip_node = Unit.node(unit, "j_hips")
            -- child offsets give each bone's rest direction and length; the last bone has no child: its length
            -- is taken equal to the bone before it
            local total = 0
            for i = 1, 5 do
                local b = leg.bones[i]
                local off = i < 5 and Unit.local_position(unit, leg.bones[i + 1].node) or nil
                if off then
                    b.dir = Vector3Box(v_norm(off))
                    b.len = Vector3.length(off)
                else
                    b.dir = Vector3Box(Vector3(0, 0, 1))
                    b.len = leg.bones[i - 1].len
                end
                total = total + b.len
            end
            leg.total = total
            legs[#legs + 1] = leg
        end
    end
    return legs
end

local function spider_ground(physics_world, p)
    local from = p + Vector3(0, 0, SPIDER.probe)
    local hit, pos = PhysicsWorld.raycast(physics_world, from, Vector3(0, 0, -1), SPIDER.probe * 2, "closest",
        "types", "statics", "collision_filter", "filter_player_mover")
    if hit and pos then
        return pos
    end
    return Vector3(p.x, p.y, p.z)
end

local function fabrik(P, L, first, last, root, target, iters)
    -- joints P[first..last+1] with fixed P[first] = root, segment lengths L[first..last]
    local reach = 0
    for i = first, last do
        reach = reach + L[i]
    end
    if Vector3.length(target - root) > reach * 0.999 then
        target = root + v_norm(target - root) * (reach * 0.999)
    end
    for _ = 1, iters do
        P[last + 1] = target
        for i = last, first, -1 do
            P[i] = P[i + 1] + v_norm(P[i] - P[i + 1]) * L[i]
        end
        P[first] = root
        for i = first, last do
            P[i + 1] = P[i] + v_norm(P[i + 1] - P[i]) * L[i]
        end
    end
end

local function spider_solve(unit, leg, target, sc, curl, cc)
    -- arch like a spider leg (Oraxia's card art): segment 1 leaves the hip mostly upward (out of her back), segment 2
    -- climbs to an apex above her head; segments 3-5 come down from the apex to the foot, seeded on a convex arc.
    -- cc (cocoon, blended in by curl): its own apex, segment-1 direction and arc bulge (body-frame vectors)
    local P, L = {}, {}
    for i = 1, 5 do
        P[i] = Unit.world_position(unit, leg.bones[i].node)
        L[i] = leg.bones[i].len * sc
    end
    local total = leg.total * sc
    local root = P[1]
    local up = Vector3(0, 0, 1)
    local flat = target - root
    flat = v_norm(Vector3(flat.x, flat.y, 0))
    local root_rot = Unit.world_rotation(unit, 1)
    local back = Quaternion.rotate(root_rot, Vector3(0, -1, 0))
    local side = v_norm(Vector3.cross(up, back))
    local out = Vector3.dot(flat, side) >= 0 and side or side * -1
    curl = cc and (curl or 0) or 0
    local function mix(a, b)
        return a + (b - a) * curl
    end
    -- walking values
    local apex = root + flat * (total * SPIDER.arch_out) + up * (total * (SPIDER.arch_up + SPIDER.swing_knee * (leg.swing or 0) * (leg.lift_share or 0)))
    local d1 = v_norm(out * 0.25 + back * 0.35 + up * 1.0)
    local bulge4 = up * (total * 0.10) + flat * (total * 0.08)
    local bulge5 = up * (total * 0.06) + flat * (total * 0.10)
    if curl > 0 and not cc.view then
        apex = mix(apex, cc.apex)
        d1 = v_norm(mix(d1, cc.d1))
        bulge4 = mix(bulge4, cc.bulge * total)
        bulge5 = mix(bulge5, cc.bulge * (total * 0.6))
    end
    P[2] = root + d1 * L[1]
    P[3] = P[2] + v_norm(apex - P[2]) * L[2]
    apex = P[3]
    P[4] = apex + (target - apex) * 0.4 + bulge4
    P[5] = apex + (target - apex) * 0.75 + bulge5
    P[6] = target
    fabrik(P, L, 3, 5, P[3], target, 10)
    if curl > 0 and cc.view then
        -- view cocoon: blend the joints toward the cocoon chain, then lay the segments out again at the blended
        -- lengths (the per-bone scales set in spider_update)
        for i = 2, 6 do
            P[i] = P[i] + (cc.C[i] - P[i]) * curl
        end
        for i = 1, 5 do
            P[i + 1] = P[i] + v_norm(P[i + 1] - P[i]) * cc.L[i]
        end
    end
    -- bones: rest world rotation (parent world x rest local), turned onto the solved direction
    local parent_rot = Unit.world_rotation(unit, leg.hip_node)
    for i = 1, 5 do
        local b = leg.bones[i]
        local rest_world = Quaternion.multiply(parent_rot, b.rest:unbox())
        local d_rest = Quaternion.rotate(rest_world, b.dir:unbox())
        local d_new = v_norm(P[i + 1] - P[i])
        local world = Quaternion.multiply(q_from_to(d_rest, d_new), rest_world)
        Unit.set_local_rotation(unit, b.node, Quaternion.multiply(Quaternion.inverse(parent_rot), world))
        parent_rot = world
    end
end

local function spider_opt(key, default)
    -- another player's Oraxia is shown with their synced options; one they do not publish reads as false
    -- (SYNC_FALSE), which broke math on numbers (887 errors per mission, 2026-10-05): wrong kind -> default
    local v = opt(key)
    if v == nil or (default ~= nil and type(v) ~= type(default)) then
        return default
    end
    return v
end

local function spider_ability_active(player_unit)
    -- as Dio's Mercy Skins (DiosMercySkins.lua:263-265)
    local ude = player_unit and unit_ok(player_unit) and ScriptUnit.has_extension(player_unit, "unit_data_system")
    if not ude then
        return false
    end
    local ok1, action = pcall(ude.read_component, ude, "combat_ability_action")
    local ok2, ability = pcall(ude.read_component, ude, "combat_ability")
    return (ok1 and action and action.current_action_name and action.current_action_name ~= "none")
        or (ok2 and ability and ability.active) or false
end

local function spider_view(player_unit)
    local ude = player_unit and unit_ok(player_unit) and ScriptUnit.has_extension(player_unit, "unit_data_system")
    if not ude then
        return nil
    end
    local ok, fp = pcall(ude.read_component, ude, "first_person")
    if ok and fp and fp.position and fp.rotation then
        return fp.position, fp.rotation
    end
    return nil
end

local function spider_wall(physics_world, from, to)
    local d = to - from
    d = Vector3(d.x, d.y, 0)
    local len = Vector3.length(d)
    if len < 0.05 then
        return nil
    end
    local hit, pos = PhysicsWorld.raycast(physics_world, from, d * (1 / len), len, "closest",
        "types", "statics", "collision_filter", "filter_player_mover")
    return hit and pos or nil
end

-- 0..1: how far the stepping pair is through its step (sin of the step phase); 0 when both pairs are planted
local function spider_bob(unit)
    local state = unit and SPIDER_STATE[unit]
    return state and state.bob or 0
end

local function spider_update(world, unit, dt, player_unit)
    if not world or not unit_ok(unit) then
        return
    end
    local state = SPIDER_STATE[unit]
    if not state then
        state = { legs = spider_init(unit), curl = 0 }
        SPIDER_STATE[unit] = state
    end
    if #state.legs == 0 then
        return
    end
    local sc = spider_opt("spider_scale", 1)
    local span = spider_opt("spider_distance", SPIDER.span)
    local step_time = math.max(spider_opt("spider_step_time", SPIDER.step_time), 0.05)
    local snap = spider_opt("spider_snappiness", 0.3)
    local min_ground = spider_opt("spider_min_ground", 0.1)
    local walls = spider_opt("spider_walls", true)
    -- feet sink this far into the ground / wall (m), so the tips do not hover over uneven meshes (user, 2026-10-04)
    local depth = spider_opt("spider_foot_depth", 0.1)
    -- no cocoon in the floating form (user, 2026-10-04)
    local curl_on = spider_opt("spider_curl", true) and not spider_opt("float_form", false)
    local cocoon_time = spider_opt("spider_cocoon_time", 3)

    local physics_world = World.physics_world(world)
    local root_pos = Unit.world_position(unit, 1)
    local root_rot = Unit.world_rotation(unit, 1)
    dt = math.min(dt or 0.016, 0.05)
    -- curl around her body while the combat ability is active (blend in / out over ~0.25 s)
    -- cocoon: starts when the ability starts and holds for spider_cocoon_time seconds (0 = only while it is active)
    local active = curl_on and spider_ability_active(player_unit)
    if active and not state.ability_was then
        state.cocoon_t = cocoon_time
    end
    state.ability_was = active
    state.cocoon_t = math.max((state.cocoon_t or 0) - dt, 0)
    local want = (state.cocoon_t > 0 or (active and cocoon_time <= 0)) and 1 or 0
    state.curl = state.curl + (want - state.curl) * math.min(1, dt * 8)
    -- legs shrink while the cocoon closes (8 m legs cannot wrap tightly); the view cocoon sets its own per-bone scales
    local sc_walk = sc
    if not spider_view(player_unit) then
        sc = sc * (1 - state.curl * (1 - COCOON.scale))
    end
    for _, leg in ipairs(state.legs) do
        Unit.set_local_scale(unit, leg.bones[1].node, Vector3(sc, sc, sc))
        for i = 2, 5 do
            Unit.set_local_scale(unit, leg.bones[i].node, Vector3(1, 1, 1))
        end
    end
    local view_pos, view_rot = spider_view(player_unit)

    local view_right, view_up, view_fwd
    if view_pos then
        view_right, view_up, view_fwd = Quaternion.right(view_rot), Quaternion.up(view_rot), Quaternion.forward(view_rot)
    end
    local busy = false
    for _, leg in ipairs(state.legs) do
        busy = busy or leg.t ~= nil
        if not leg.t then
            leg.planted = (leg.planted or 0) + dt
        end
    end
    local last = state.last_root and state.last_root:unbox()
    local vel = last and (root_pos - last) * (1 / math.max(dt, 1e-3)) or Vector3(0, 0, 0)
    vel = Vector3(vel.x, vel.y, 0)
    local drift, rested = {}, { 99, 99 }
    for _, leg in ipairs(state.legs) do
        local total = leg.total * sc
        local k = span / SPIDER.span
        -- footholds (user sliders 2026-10-05, shares of the leg length; defaults = her Warframe idle):
        -- spider_front_reach / spider_back_reach move the front / back feet forward (+) or backward (-),
        -- spider_front_spread sets how far apart (out to the sides) the front feet stand
        local front = leg.sy > 0
        local out = (front and spider_opt("spider_front_spread", SPIDER.front_out) or SPIDER.back_out) * total * k
        local ahead = (front and spider_opt("spider_front_reach", SPIDER.front_fwd)
            or spider_opt("spider_back_reach", SPIDER.back_fwd)) * total * k
        -- moving: plant ahead by speed x stance time / 2 (stance = one swing time), as her walk clip does
        local lead = vel * (step_time * 0.5)
        if Vector3.length(lead) > total * 0.5 then
            lead = v_norm(lead) * (total * 0.5)
        end
        local corner = root_pos + Quaternion.rotate(root_rot, Vector3(leg.sx * out, ahead, 0)) + lead
        local home
        if walls then
            local hip = Unit.world_position(unit, leg.bones[1].node)
            home = spider_wall(physics_world, hip, corner) -- foot on the wall where the way to its corner is blocked
            if home and depth > 0 then
                local d = corner - hip
                home = home + v_norm(Vector3(d.x, d.y, 0)) * depth
            end
        end
        home = home or (spider_ground(physics_world, corner) - Vector3(0, 0, depth))
        leg.target = Vector3Box(home)
        if not leg.foot then
            leg.foot = Vector3Box(home)
        end
        local d = Vector3.length(home - leg.foot:unbox())
        if d > total * 1.2 then
            leg.foot:store(home) -- teleported / spawned: plant at once
            d = 0
        end
        drift[leg.pair] = math.max(drift[leg.pair] or 0, d / total)
        rested[leg.pair] = math.min(rested[leg.pair], leg.planted or 0)
    end
    local speed = Vector3.length(vel)
    state.last_root = Vector3Box(root_pos)
    local threshold = speed < 0.2 and SPIDER.settle or SPIDER.step
    if not busy and state.curl < 0.5 then
        -- the pair that drifted most steps (both its legs together), if past the threshold and planted long enough
        local pick = (drift[1] or 0) >= (drift[2] or 0) and 1 or 2
        if (drift[pick] or 0) > threshold and rested[pick] >= min_ground then
            for _, leg in ipairs(state.legs) do
                if leg.pair == pick then
                    leg.from = Vector3Box(leg.foot:unbox())
                    leg.to = Vector3Box(leg.target:unbox())
                    leg.t = 0
                    leg.planted = 0
                end
            end
        end
    end
    state.bob_new = 0
    state.bob = 0
    for _, leg in ipairs(state.legs) do
        local total = leg.total * sc
        if leg.t then
            leg.t = leg.t + dt / step_time
            local to = leg.to:unbox()
            if leg.t >= 1 then
                leg.foot:store(to)
                leg.t = nil
                leg.swing = 0
            else
                local from = leg.from:unbox()
                local t = leg.t
                -- snappiness: 0 = smooth ease in / out, 1 = shoots out at once and settles
                local smooth = t * t * (3 - 2 * t)
                local quick = 1 - (1 - t) ^ 4
                local e = smooth * (1 - snap) + quick * snap
                local h = math.min(SPIDER.lift_per_m * Vector3.length(to - from) + SPIDER.lift * total, SPIDER.lift_max * total)
                -- peak at about 40 % of the swing (her walk clip), starting and ending at zero speed: the earlier
                -- sin(pi t^0.757) started infinitely fast and snapped the feet up
                local w = t + 0.4 * t * (1 - t)
                local sw = math.sin(math.pi * w)
                leg.swing = sw * sw
                -- the knee rises with the step's own height (a short settling step barely lifts the knee)
                leg.lift_share = h / (SPIDER.lift_max * total)
                local p = from + (to - from) * e + Vector3(0, 0, h * leg.swing)
                leg.foot:store(p)
            end
        end
        if leg.t then
            state.bob = math.max(state.bob_new or 0, math.sin(math.pi * math.min(leg.t, 1)))
            state.bob_new = state.bob
        end
        local target = leg.foot:unbox()
        local cc
        if state.curl > 0.01 and view_pos then
            local row = COCOON_VIEW[(leg.sy > 0 and "upper_" or "lower_") .. (leg.sx < 0 and "left" or "right")]
            local f = COCOON_VIEW_DIST
            local function screen(v, depth)
                return view_pos + view_fwd * depth + view_right * (v[1] * COCOON_TAN_X * depth)
                    + view_up * (v[2] * COCOON_TAN_Y * depth)
            end
            local side = row.start[1] < 0 and -1 or 1
            local away = leg.sy > 0 and 1 or -1 -- away from the slit
            local C = { Unit.world_position(unit, leg.bones[1].node) }
            C[2] = screen(row.start, f)
            C[3] = screen(row.fold, f)
            C[4] = screen(row.back, f * 1.06)
            local need = {}
            for i = 1, 3 do
                need[i] = Vector3.length(C[i + 1] - C[i]) / math.max(leg.bones[i].len, 1e-3)
            end
            need[4], need[5] = need[3], need[3]
            -- hook: on out past the edge it came in from, curling back behind her
            local outward = view_right * side
            C[5] = C[4] + v_norm(outward * 1.0 - view_fwd * 0.6 + view_up * (0.3 * away)) * (leg.bones[4].len * need[4])
            C[6] = C[5] + v_norm(outward * 0.3 - view_fwd * 1.0 + view_up * (0.5 * away)) * (leg.bones[5].len * need[5])
            local e, Lc = {}, {}
            for i = 1, 5 do
                e[i] = sc_walk + (need[i] - sc_walk) * state.curl
                Lc[i] = leg.bones[i].len * e[i]
            end
            Unit.set_local_scale(unit, leg.bones[1].node, Vector3(e[1], e[1], e[1]))
            for i = 2, 5 do
                local k = e[i] / e[i - 1]
                Unit.set_local_scale(unit, leg.bones[i].node, Vector3(k, k, k))
            end
            cc = { view = true, C = C, L = Lc }
        elseif state.curl > 0.01 then
            local c = leg.sy > 0 and COCOON.upper or COCOON.lower
            local function body(v, offset)
                local w = Quaternion.rotate(root_rot, Vector3(leg.sx * v[1], v[2], v[3]))
                return offset and (root_pos + w) or w
            end
            cc = { apex = body(c.apex, true), d1 = body(c.d1), bulge = body(c.bulge) }
            target = target + (body(c.foot, true) - target) * state.curl
        end
        spider_solve(unit, leg, target, sc, state.curl, cc)
    end
end

-- @@drive (gen_mods2 puts the part below after the spider legs code, the part above before apply())
local function float_map(unit, player)
    local m = FLOAT_MAP[unit]
    if m and m.player == player then
        return m
    end
    m = { player = player, nodes = {}, by_name = {} }
    for _, name in ipairs(FLOAT_NODES) do
        if Unit.has_node(unit, name) and Unit.has_node(player, name) then
            local node = Unit.node(unit, name)
            if node ~= 1 then
                local e = {
                    node = node,
                    pnode = Unit.node(player, name),
                    hips = name == "j_hips",
                    neck = name == "j_neck",
                    name = name,
                    steady = FLOAT_STEADY[name],
                }
                m.nodes[#m.nodes + 1] = e
                m.by_name[name] = e
            end
        end
    end
    m.chain = {}
    if Unit.has_node(unit, "j_hips") and Unit.has_node(player, "j_hips") then
        for side, names in pairs(FLOAT_CHAIN) do
            local c = { hips = Unit.node(player, "j_hips") }
            -- her unit only needs thigh, shin and foot (the compiled units have no toe bone: feet are skinned to
            -- j_*foot only); the toe is read from the player's unit for the foot's direction
            for i, name in ipairs(names) do
                local mine = Unit.has_node(unit, name)
                if not Unit.has_node(player, name) or (i <= 3 and not mine) then
                    c = nil
                    break
                end
                c[i] = { node = mine and Unit.node(unit, name) or nil, pnode = Unit.node(player, name) }
            end
            m.chain[side] = c
        end
    end
    FLOAT_MAP[unit] = m
    return m
end

-- the pose keys around time t (looped) and the blend between them
local function float_pose_keys(t)
    local keys = FLOAT_POSE.keys
    local n = #keys
    local x = (t / FLOAT_POSE.period) % 1 * n
    local i = math.floor(x)
    return keys[i % n + 1], keys[(i + 1) % n + 1], x - i
end

-- turns her thigh, shin and foot (as copied from the player) onto the pose directions, top down: each bone is
-- rotated about its joint from its current direction to the pose direction, and the rotation carries down the leg
local function float_legs(unit, player, m, k0, k1, f, hips_w, tuck)
    local root_rot = Unit.world_rotation(player, 1)
    local right, fwd, up = Quaternion.right(root_rot), Quaternion.forward(root_rot), Vector3(0, 0, 1)
    -- tuck: the whole pose turned back about her right axis (a negative angle about x moves the feet backward)
    local back = Quaternion.axis_angle(right, -math.rad(tuck or 0))
    for side, c in pairs(m.chain) do
        if c then
            local parent_w = hips_w or Unit.world_rotation(player, c.hips)
            local acc = Quaternion.identity()
            for i = 1, 3 do
                local b, child = c[i], c[i + 1]
                local v0, v1 = k0[side][i], k1[side][i]
                local want = Quaternion.rotate(back, v_norm(right * (v0[1] + (v1[1] - v0[1]) * f)
                    + fwd * (v0[2] + (v1[2] - v0[2]) * f) + up * (v0[3] + (v1[3] - v0[3]) * f)))
                local cur = Quaternion.rotate(acc, Unit.world_position(player, child.pnode) - Unit.world_position(player, b.pnode))
                acc = Quaternion.multiply(q_from_to(v_norm(cur), want), acc)
                local w = Quaternion.multiply(acc, Unit.world_rotation(player, b.pnode))
                Unit.set_local_rotation(unit, b.node, Quaternion.multiply(Quaternion.inverse(parent_w), w))
                parent_w = w
            end
        end
    end
end

-- arms onto the chosen pose (float_arms_pose; FLOAT_ARM_POSES) in her torso frame, top down, blended by w
local function float_arms(unit, player, m, w, t)
    local pick = FLOAT_CFG.arms_opt and opt(FLOAT_CFG.arms_opt)
    local pose = FLOAT_ARM_POSES[type(pick) == "string" and pick or "crossed"]
    local by = m.by_name
    local ph, ps2, pls, prs = by.j_hips, by.j_spine2, by.j_leftshoulder, by.j_rightshoulder
    if not pose or w <= 0.001 or not (m.sp2_w and ph and ps2 and pls and prs) then
        return
    end
    local keys = pose.keys
    local n = #keys
    local x = (t / pose.period) % 1 * n
    local i = math.floor(x)
    local f = x - i
    local k0, k1 = keys[i % n + 1], keys[(i + 1) % n + 1]
    local function P(e)
        return Unit.world_position(player, e.pnode)
    end
    -- her chest = the player's turned by extra (lean, steady torso); torso frame from the player's joints
    local sp2_w = m.sp2_w
    local extra = Quaternion.multiply(sp2_w, Quaternion.inverse(Unit.world_rotation(player, ps2.pnode)))
    local up = v_norm(Quaternion.rotate(extra, P(ps2) - P(ph)))
    local rt = Quaternion.rotate(extra, P(prs) - P(pls))
    rt = v_norm(rt - up * Vector3.dot(rt, up))
    local fw = Vector3.cross(up, rt)
    for side, names in pairs(FLOAT_ARMS) do
        local sh = by[names[1]]
        local c = { by[names[2]], by[names[3]], by[names[4]], by[names[5]] }
        if sh and c[1] and c[2] and c[3] and c[4] then
            local parent_w = Quaternion.multiply(sp2_w, sh.q or Unit.local_rotation(player, sh.pnode))
            local acc = Quaternion.multiply(parent_w, Quaternion.inverse(Unit.world_rotation(player, sh.pnode)))
            for b = 1, 3 do
                local bone, child = c[b], c[b + 1]
                local v0, v1 = k0[side][b], k1[side][b]
                local want = v_norm(rt * (v0[1] + (v1[1] - v0[1]) * f) + fw * (v0[2] + (v1[2] - v0[2]) * f)
                    + up * (v0[3] + (v1[3] - v0[3]) * f))
                local cur = v_norm(Quaternion.rotate(acc, P(child) - P(bone)))
                want = v_norm(cur + (want - cur) * w)
                acc = Quaternion.multiply(q_from_to(cur, want), acc)
                local wq = Quaternion.multiply(acc, Unit.world_rotation(player, bone.pnode))
                Unit.set_local_rotation(unit, bone.node, Quaternion.multiply(Quaternion.inverse(parent_w), wq))
                parent_w = wq
            end
        end
    end
end

local function float_wielded(player)
    local ude = unit_ok(player) and ScriptUnit.has_extension(player, "unit_data_system")
    if not ude then
        return nil
    end
    local ok, inv = pcall(ude.read_component, ude, "inventory")
    return ok and inv and inv.wielded_slot or nil
end

local function float_unarmed(player)
    local ude = unit_ok(player) and ScriptUnit.has_extension(player, "unit_data_system")
    if not ude then
        return false
    end
    local ok, inv = pcall(ude.read_component, ude, "inventory")
    return ok and inv and inv.wielded_slot == "slot_unarmed" or false
end

-- rotation between a and b (t 0..1) through their forward / up axes (Quaternion.forward / up / look, notes 00)
local function q_blend(a, b, t)
    if t <= 0.001 then
        return a
    elseif t >= 0.999 then
        return b
    end
    local fa, ua = Quaternion.forward(a), Quaternion.up(a)
    return Quaternion.look(v_norm(fa + (Quaternion.forward(b) - fa) * t), v_norm(ua + (Quaternion.up(b) - ua) * t))
end

local function float_acting(player)
    local ude = unit_ok(player) and ScriptUnit.has_extension(player, "unit_data_system")
    if not ude then
        return false
    end
    local ok, action = pcall(ude.read_component, ude, "weapon_action")
    return ok and action and action.current_action_name and action.current_action_name ~= "none" or false
end

-- her torso chain (bones.json parents): each one's world rotation is rebuilt from the local rotations used this frame
local TORSO_PARENT = { j_hips = "j_hips_transform", j_spine = "j_hips", j_spine1 = "j_spine", j_spine2 = "j_spine1",
    j_neck = "j_spine2" }

-- st: lift (m above her steady hip height), hip_h (hip height above the root, held while moving), lean (degrees
-- forward from upright), steady (0..1 weight of the standing pose), capture (true = record the standing pose now)
local function float_drive(unit, player, st, still_legs, k0, k1, f)
    if not (unit_ok(unit) and unit_ok(player) and Unit.has_node(player, FLOAT_HIPS_PARENT)) then
        return
    end
    local m = float_map(unit, player)
    local root_pos, root_rot = Unit.world_position(player, 1), Unit.world_rotation(player, 1)
    -- forward lean about her right axis (z up, y forward: a negative angle about x tips the top forward)
    local lean = Quaternion.axis_angle(Quaternion.right(root_rot), -math.rad(st.lean))
    if st.roll and st.roll ~= 0 then
        -- + = top to the right: a positive angle about her forward axis (y) takes up (z) toward right (x)
        lean = Quaternion.multiply(Quaternion.axis_angle(Quaternion.forward(root_rot), math.rad(st.roll)), lean)
    end
    local W = {} -- her world rotations along the torso chain
    local hips_w
    m.sp2_w = nil
    for _, n in ipairs(m.nodes) do
        local q = Unit.local_rotation(player, n.pnode)
        if n.steady then
            if st.capture then
                n.snap = QuaternionBox(q)
            end
            if n.snap then
                q = q_blend(q, n.snap:unbox(), st.steady)
            end
        end
        local name = n.name
        if name == FLOAT_HIPS_PARENT then
            -- parent (the root) is the player's: its world rotation = the player's node world x inverse local
            local pw = Quaternion.multiply(Unit.world_rotation(player, n.pnode),
                Quaternion.inverse(Unit.local_rotation(player, n.pnode)))
            W[name] = Quaternion.multiply(pw, q)
            Unit.set_local_position(unit, n.node, Unit.local_position(player, n.pnode))
        elseif n.hips then
            local pp = Unit.node(player, FLOAT_HIPS_PARENT)
            local prot = W[FLOAT_HIPS_PARENT] or Unit.world_rotation(player, pp)
            hips_w = Quaternion.multiply(lean, Quaternion.multiply(prot, q))
            q = Quaternion.multiply(Quaternion.inverse(prot), hips_w)
            W[name] = hips_w
            -- height: her steady hip height above the root plus the lift (no walk bob), in the parent frame
            local hp = Unit.world_position(player, n.pnode)
            local want = Vector3(hp.x, hp.y, root_pos.z + st.hip_h + st.lift)
                + Quaternion.right(root_rot) * (st.sx or 0)
            Unit.set_local_position(unit, n.node,
                Quaternion.rotate(Quaternion.inverse(prot), want - Unit.world_position(player, pp)))
        elseif n.neck and W.j_spine2 then
            -- head level: the neck takes the lean back off (her torso leans, her gaze does not)
            local want_w = Quaternion.multiply(Quaternion.inverse(lean), Quaternion.multiply(W.j_spine2, q))
            q = Quaternion.multiply(Quaternion.inverse(W.j_spine2), want_w)
            W[name] = want_w
            Unit.set_local_position(unit, n.node, Unit.local_position(player, n.pnode))
        else
            local parent = TORSO_PARENT[name]
            if parent and W[parent] then
                W[name] = Quaternion.multiply(W[parent], q)
            end
            Unit.set_local_position(unit, n.node, Unit.local_position(player, n.pnode))
        end
        Unit.set_local_rotation(unit, n.node, q)
        n.q = q -- the local rotation used this frame (the arm pose builds on the shoulders')
    end
    m.sp2_w = W.j_spine2
    if still_legs then
        float_legs(unit, player, m, k0, k1, f, hips_w, st.tuck)
    end
    float_arms(unit, player, m, st.arms or 0, st.t or 0)
end

local function float_drive_all(ext, body, parts, dt)
    local player = ext._unit
    local driver = ext.__qiangiq_oraxia_float_driver
    if not (unit_ok(driver) and unit_ok(player)) then
        if unit_ok(body) and unit_ok(player) and not unit_ok(driver) then
            -- the driver is gone while her units still exist (destroyed with them attached, 2026-10-05): they would
            -- stand where it was; start over (despawn, then the game's visibility update spawns them again)
            mod:info("floating form: driver lost, respawning her units")
            despawn(ext)
            ext:force_update_item_visibility()
        end
        return
    end
    dt = dt or 0
    local st = ext.__qiangiq_oraxia_float_st or { steady = 0, moving = 0 }
    ext.__qiangiq_oraxia_float_st = st
    -- speed of the player on the ground
    local rp = Unit.world_position(player, 1)
    local speed = 0
    if st.last then
        local d = rp - st.last:unbox()
        speed = math.sqrt(d.x * d.x + d.y * d.y) / math.max(dt, 1e-3)
    end
    st.last = Vector3Box(rp)
    local moving = speed > 0.3
    local acting = float_acting(player)
    local k = math.min(1, dt * 8)
    st.moving = st.moving + ((moving and 1 or 0) - st.moving) * k
    st.steady = st.steady + (((moving and not acting) and 1 or 0) - st.steady) * k
    st.capture = not moving and not acting
    local arms_want = FLOAT_CFG.arms and float_unarmed(player) and 1 or 0
    st.arms = (st.arms or 0) + (arms_want - (st.arms or 0)) * math.min(1, dt * 6)
    st.tuck = float_num(FLOAT_CFG.tuck_opt, FLOAT_CFG.tuck_default)
    -- hip height above the root: followed while standing (crouching), held while moving
    if Unit.has_node(player, "j_hips") and (not moving or not st.hip_h) then
        local hh = Unit.world_position(player, Unit.node(player, "j_hips")).z - rp.z
        st.hip_h = st.hip_h and st.hip_h + (hh - st.hip_h) * math.min(1, dt * 4) or hh
    end
    -- hover bob (her idle clip) only while standing; nothing moves her up and down while she moves
    ext.__qiangiq_oraxia_float_t = (ext.__qiangiq_oraxia_float_t or 0) + dt
    st.t = ext.__qiangiq_oraxia_float_t
    local k0, k1, f = float_pose_keys(ext.__qiangiq_oraxia_float_t)
    local hover = k0.hip + (k1.hip - k0.hip) * f
    local height = float_num(FLOAT_CFG.height_opt, FLOAT_CFG.height_default)
    st.lift = height + hover * (FLOAT_CFG.hover_moving and 1 or (1 - st.moving))
    st.lean = float_num(FLOAT_CFG.lean_opt, FLOAT_CFG.lean_default) + (FLOAT_CFG.lean_moving or 0) * st.moving
    -- sway (FLOAT_CFG.sway): the pose keys' sideways hip drift sx (m) and torso roll (degrees)
    st.sx = FLOAT_CFG.sway and ((k0.sx or 0) + ((k1.sx or 0) - (k0.sx or 0)) * f) or 0
    st.roll = FLOAT_CFG.sway and ((k0.roll or 0) + ((k1.roll or 0) - (k0.roll or 0)) * f) or 0
    -- camera and crosshair: my own character only
    if ext._player ~= nil and ext._player == sync_me() then
        float_world = ext.__qiangiq_world
        local up = float_camera_node()
        if up then
            up.__qiangiq_world = ext.__qiangiq_world
        end
        local cam_want = opt(FLOAT_CFG.camera_opt) == true and height or 0
        st.cam = (st.cam or 0) + (cam_want - (st.cam or 0)) * math.min(1, dt * 4)
        float_camera_set(st.cam)
    end
    local still = FLOAT_CFG.legs_still_default
    if FLOAT_CFG.legs_still_opt and type(opt(FLOAT_CFG.legs_still_opt)) == "boolean" then
        still = opt(FLOAT_CFG.legs_still_opt)
    end
    float_drive(driver, player, st, still, k0, k1, f)
    float_link_items(ext)
    ext.__qiangiq_body_host = driver -- QIangIQsArmoryVis (see float_parent)
end

-- Hooks ----------------------------------------------------------------------

vl_hook_safe("init", function(self, extension_init_context, unit, extension_init_data)
    self.__qiangiq_world = extension_init_context and extension_init_context.world
    -- player_unit_visual_loadout_extension.lua:81 reads extension_init_data.archetype.breed
    local archetype = extension_init_data and extension_init_data.archetype
    self.__qiangiq_breed = archetype and archetype.breed
end)

vl_hook_safe("_update_item_visibility", function(self, first_person_mode)
    if not is_local_human(self) then
        return
    end
    if EXCLUDED_BREEDS[ext_breed(self)] then
        if self.__qiangiq_oraxia_unit or self.__qiangiq_oraxia_arms then
            despawn(self)
        end
        return
    end
    tracked[self] = true
    apply(self, first_person_mode)
end)

-- PlayerUnitVisualLoadoutExtension.update = function (self, unit, dt, t)
-- Reactive glow: every glowing unit of the model (the body and arms' emissive layer and each glowing part) brightens
-- with the Psyker's peril and the Veteran's plasma gun heat, from its own brightness setting at none to
-- "glow_reactive_peak" at full. Peril: the "warp_charge" component's current_percentage, read as
-- QIangIQsCookedMacroManager does; heat: the "slot_secondary" component's overheat_current_percentage, read as
-- QIangIQsPrototype does (plasmagun_overheat_effects.lua:39,79). Class: player:archetype_name(), as ability_timer.
-- 0 for any other class or when a component cannot be read (pcall).
local REACTIVE_FOLLOW = 0.15 -- share of the way to the new level per 60 fps frame (smooths flicker)
local REACTIVE_SOURCE = { psyker = { "warp_charge", "current_percentage" }, veteran = { "slot_secondary", "overheat_current_percentage" } }

local function reactive_level(ext)
    local player = ext._player
    local ok, archetype = pcall(function()
        return player and player:archetype_name()
    end)
    local source = ok and REACTIVE_SOURCE[archetype]
    local unit = ext._unit
    if not (source and unit_ok(unit)) then
        return 0
    end
    local unit_data_extension = ScriptUnit.has_extension(unit, "unit_data_system")
    if not unit_data_extension then
        return 0
    end
    local ok2, component = pcall(unit_data_extension.read_component, unit_data_extension, source[1])
    local v = ok2 and component and component[source[2]]
    return type(v) == "number" and math.clamp01(v) or 0
end

local function each_glowing_part(ext, fn)
    for _, list in ipairs({ ext.__qiangiq_oraxia_parts, ext.__qiangiq_oraxia_part_arms }) do
        if list then
            for id, unit in pairs(list) do
                local part = PART_BY_ID[id]
                if part and part.glow and unit_ok(unit) then
                    fn(part, unit)
                end
            end
        end
    end
end

local function apply_reactive_glow(ext, dt)
    local body, arms = ext.__qiangiq_oraxia_unit, ext.__qiangiq_oraxia_arms
    if not opt("glow_reactive") then
        if ext.__qiangiq_oraxia_rshown then
            -- switched off: back to the plain brightness settings once
            ext.__qiangiq_oraxia_rshown = nil
            apply_glow(body)
            apply_glow(arms)
            each_glowing_part(ext, apply_part_glow)
        end
        return
    end
    local f = math.min(dt or 0.0167, 0.1) * 60
    local shown = ext.__qiangiq_oraxia_rshown or 0
    shown = shown + (reactive_level(ext) - shown) * (1 - (1 - REACTIVE_FOLLOW) ^ f)
    ext.__qiangiq_oraxia_rshown = shown
    local peak = glow_intensity(opt("glow_reactive_peak") or 100)
    local function lifted(own)
        return own + math.max(peak - own, 0) * shown
    end
    if GLOW_SETTING then
        local v = lifted(glow_intensity(opt(GLOW_SETTING) or GLOW_DEFAULT))
        for _, unit in ipairs({ body, arms }) do
            if unit_ok(unit) then
                Unit.set_scalar_for_materials(unit, "intensity", v, true)
            end
        end
    end
    each_glowing_part(ext, function(part, unit)
        Unit.set_scalar_for_materials(unit, "intensity", lifted(glow_intensity(opt(part.glow) or part.glow_default)), true)
    end)
end

vl_hook_safe("update", function(self, unit, dt)
    if tracked[self] and self.__qiangiq_oraxia_float and self.__qiangiq_oraxia_unit then
        float_drive_all(self, self.__qiangiq_oraxia_unit, self.__qiangiq_oraxia_parts, dt)
    end
    -- the third-person units are hidden in first person, so nothing to move then
    if tracked[self] and self.__qiangiq_oraxia_unit and not self.__qiangiq_oraxia_fp then
        jiggle_all(self.__qiangiq_oraxia_unit, self.__qiangiq_oraxia_parts, dt)
        apply_tail(self.__qiangiq_oraxia_unit)
        apply_shape_all(self.__qiangiq_oraxia_unit, self.__qiangiq_oraxia_parts)
    end
    if tracked[self] and self.__qiangiq_oraxia_unit then
        spider_update(self.__qiangiq_world, self.__qiangiq_oraxia_parts and self.__qiangiq_oraxia_parts.legs, dt, self._unit)
    end
    if tracked[self] then
        apply_reactive_glow(self, dt)
    end
end)

vl_hook("destroy", function(func, self, ...)
    despawn(self)
    tracked[self] = nil
    return func(self, ...)
end)

mod:hook_safe(CLASS.UIProfileSpawner, "_update_items_visibility", function(self)
    ui_apply(self)
end)

-- UIProfileSpawner.update = function (self, dt, t, input_service)
mod:hook_safe(CLASS.UIProfileSpawner, "update", function(self, dt)
    local data = self._character_spawn_data
    if data and data.is_ready then
        ui_apply(self)
        if self.__qiangiq_oraxia_unit then
            jiggle_all(self.__qiangiq_oraxia_unit, self.__qiangiq_oraxia_parts, dt)
            apply_tail(self.__qiangiq_oraxia_unit)
            apply_shape_all(self.__qiangiq_oraxia_unit, self.__qiangiq_oraxia_parts)
        end
    end
end)

mod:hook(CLASS.UIProfileSpawner, "_despawn_current_character_profile", function(func, self, ...)
    ui_despawn(self)
    return func(self, ...)
end)

-- Package loading through Custom Assets --------------------------------------

local function refresh_all()
    for ext in pairs(tracked) do
        if unit_ok(ext._unit) then
            if not model_on() then
                despawn(ext)
            end
            ext:force_update_item_visibility()
        end
    end
    for spawner in pairs(tracked_ui) do
        ui_apply(spawner)
    end
end

local function acquire(name)
    local id = asset_id(name)
    local ticket, err = custom_assets.acquire(mod, id, function(_, _, load_error)
        if load_error then
            mod:error("%s failed to load: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", id, tostring(load_error))
            return
        end
        ready[name] = true
        refresh_all()
    end, { resident = true, reference_name = id })
    if not ticket then
        mod:error("%s could not be requested: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", id, tostring(err))
    end
end

-- Two models of the same group saved "on" (e.g. a newly installed mod, which defaults to on):
-- the later one in CHARACTER_MODS keeps it.
local function resolve_at_load()
    local mine = false
    for _, name in ipairs(CHARACTER_MODS) do
        if name == "QIangIQsOraxia" then
            mine = true
        elseif mine then
            local other = get_mod(name)
            if other and other:get("model_enabled") ~= false and model_on() then
                mod:set("model_enabled", false, false)
            end
        end
    end
end

mod.on_all_mods_loaded = function()
    resolve_at_load()
    jiggle_read_settings()
    custom_assets = get_mod("CustomAssets")
    if not custom_assets or not custom_assets.is_api_compatible or not custom_assets.is_api_compatible(1) then
        mod:error("Custom Assets (API 1) is missing. Install it and put it above QIangIQsOraxia in mod_load_order.txt.")
        return
    end
    acquire(BODY)
    acquire(BODY .. "_driver")
    acquire(ARMS)
    for _, part in ipairs(PARTS) do
        acquire(part.body)
        if part.arms then
            acquire(part.arms)
        end
    end
end

local function switch_others_off()
    for _, name in ipairs(CHARACTER_MODS) do
        if name ~= "QIangIQsOraxia" then
            local other = get_mod(name)
            if other and other:get("model_enabled") ~= false then
                other:set("model_enabled", false, true)
            end
        end
    end
end

mod.toggle_model = function()
    local on = not model_on()
    mod:set("model_enabled", on, true)
    mod:echo("Oraxia model %s", on and "on" or "off")
end

mod:command("oraxia", "Toggle the Oraxia model on your character", function()
    mod.toggle_model()
end)

mod.on_setting_changed = function(setting_id)
    if setting_id == "model_enabled" and model_on() then
        switch_others_off()
    end
    jiggle_read_settings()
    refresh_all()
end

mod.on_disabled = function()
    for ext in pairs(tracked) do
        despawn(ext)
        -- hooks are off now, so this restores the normal body/gear visibility
        if unit_ok(ext._unit) then
            ext:force_update_item_visibility()
        end
    end
    for spawner in pairs(tracked_ui) do
        ui_despawn(spawner)
        if spawner._character_spawn_data and spawner._visible then
            spawner:_update_items_visibility()
        end
    end
end

mod.on_enabled = function()
    refresh_all()
end

mod.on_unload = function()
    for ext in pairs(tracked) do
        despawn(ext)
    end
    for spawner in pairs(tracked_ui) do
        ui_despawn(spawner)
    end
    if custom_assets and custom_assets.release_owner then
        custom_assets.release_owner(mod)
    end
end


-- Cross-client sync: what this mod publishes about me, and the refresh when anyone's options change ---------
local function sync_applies(info)
    return model_on() and (info.breed == nil or not EXCLUDED_BREEDS[info.breed])
end

local sync_enabled = true
local function sync_changed()
    local api = sync_api()
    if api then
        api.changed()
    end
end

mod.sync_key = SYNC_KEY
-- info = { breed, companion_breed, templates = { [weapon_template] = true } } of my own character (fields nil
-- while I have no unit). Returns the array to publish, or nil when this mod shows nothing on my character.
mod.sync_export = function(info)
    info = info or {}
    if not sync_enabled or not sync_applies(info) then
        return nil
    end
    local mask, bit = 0, 1
    for i = 1, #SYNC_BOOLS do
        local key = SYNC_BOOLS[i]
        local v = mod:get(key)
        if v == nil then
            v = SYNC_DEFAULTS[key]
        end
        if v then
            mask = mask + bit
        end
        bit = bit * 2
    end
    local out = { SYNC_LAYOUT, mask }
    for i = 1, #SYNC_VALUES do
        local v = mod:get(SYNC_VALUES[i])
        if type(v) == "number" then
            v = math.floor(v * 100 + 0.5) / 100
        elseif type(v) ~= "string" then
            v = false -- not set: the reader falls back to its default
        end
        out[2 + i] = v
    end
    return out
end

mod.sync_refresh = function()
    for ext in pairs(sync_all) do
        if ext._unit and Unit.alive(ext._unit) and ext.force_update_item_visibility then
            pcall(ext.force_update_item_visibility, ext)
        end
    end
end

local sync_prev_setting_changed = mod.on_setting_changed
mod.on_setting_changed = function(...)
    if sync_prev_setting_changed then
        sync_prev_setting_changed(...)
    end
    sync_changed()
end

local sync_prev_disabled = mod.on_disabled
mod.on_disabled = function(...)
    sync_enabled = false
    if sync_prev_disabled then
        sync_prev_disabled(...)
    end
    sync_changed()
end

local sync_prev_enabled = mod.on_enabled
mod.on_enabled = function(...)
    sync_enabled = true
    if sync_prev_enabled then
        sync_prev_enabled(...)
    end
    sync_changed()
end
