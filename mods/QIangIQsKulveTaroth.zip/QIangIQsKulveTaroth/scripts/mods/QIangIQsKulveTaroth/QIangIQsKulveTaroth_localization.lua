return {
    mod_name = {
        en = "QIangIQ's Kulve Taroth",
    },
    mod_description = {
        en = "Replaces your own character with the Kulve Taroth model (Custom Assets): third person, first-person arms and menu previews, clothing parts that can be switched on and off, and physics on its own physics bones. Only one QIangIQ character model is shown at a time. By QIangIQ.",
    },
    model_enabled = {
        en = "Show the Kulve Taroth model",
    },
    model_enabled_description = {
        en = "Turning this on switches the other QIangIQ human character models off. Chat command: /kulve",
    },
    hide_body = {
        en = "Hide original body and cosmetics",
    },
    hide_body_description = {
        en = "Hides your character's body, face, hair and gear slots while the model is shown. Weapons stay visible.",
    },
    first_person_arms = {
        en = "Model arms in first person",
    },
    first_person_arms_description = {
        en = "Replaces the first-person arms and gloves with the model's arms (and the arm pieces of the clothing parts that are on).",
    },
    menu_previews = {
        en = "Show in menus (operative select, inventory)",
    },
    menu_previews_description = {
        en = "Shows the model on your own operatives in menu previews. Other players' characters are left alone. Ogryns are never replaced.",
    },
    parts_group = {
        en = "Clothing parts",
    },
    part_bra = {
        en = "Bra",
    },
    part_bra_description = {
        en = "Show this part. Off = the part is removed from the model (third person, first-person arms and menus).",
    },
    part_panty = {
        en = "Panty",
    },
    part_panty_description = {
        en = "Show this part. Off = the part is removed from the model (third person, first-person arms and menus).",
    },
    part_cap = {
        en = "Shoulder cape",
    },
    part_cap_description = {
        en = "Show this part. Off = the part is removed from the model (third person, first-person arms and menus).",
    },
    part_bracelet = {
        en = "Bracelets",
    },
    part_bracelet_description = {
        en = "Show this part. Off = the part is removed from the model (third person, first-person arms and menus).",
    },
    shape_group = {
        en = "Body proportions",
    },
    shape_breast = {
        en = "Breast size",
    },
    shape_breast_description = {
        en = "Scales the breasts. 1 = as modelled. Clothing on them follows. 0.5 to 2.",
    },
    shape_butt = {
        en = "Butt size",
    },
    shape_butt_description = {
        en = "Scales the butt. 1 = as modelled. Clothing on it follows. 0.5 to 2.",
    },
    tail_group = {
        en = "Tail size",
    },
    tail_custom = {
        en = "Custom tail size",
    },
    tail_custom_description = {
        en = "Applies the two sliders below. Off = the tail as modelled.",
    },
    tail_length = {
        en = "Tail length",
    },
    tail_length_description = {
        en = "1 = as modelled, 0.5 = half as long, up to 3 times as long. A long tail reaches the floor.",
    },
    tail_thickness = {
        en = "Tail thickness",
    },
    tail_thickness_description = {
        en = "1 = as modelled, 0.5 = half as thick, up to 3 times as thick.",
    },
    tail_phys_group = {
        en = "Tail physics",
    },
    tail_phys_segments = {
        en = "Tail: simulated bones",
    },
    tail_phys_segments_description = {
        en = "How many pieces the tail's physics is worked out in (shown as one smooth curve over all its bones). More = bendier and livelier, fewer = calmer. 6 = one per tail bone (as built).",
    },
    tail_phys_stiffness = {
        en = "Tail: stiffness",
    },
    tail_phys_stiffness_description = {
        en = "How hard the tail is pulled back to its shape. 1 = as built. Higher = snaps back faster, lower = softer and slower. Tail only.",
    },
    tail_phys_damping = {
        en = "Tail: damping",
    },
    tail_phys_damping_description = {
        en = "How quickly the tail's swing dies out. 1 = as built. Higher = settles at once, lower = keeps swinging longer. Tail only.",
    },
    tail_phys_limit = {
        en = "Tail: swing limit",
    },
    tail_phys_limit_description = {
        en = "Scales the largest angle the tail may swing away from its shape. 1 = as built. Tail only.",
    },
    tail_phys_gravity = {
        en = "Tail: gravity",
    },
    tail_phys_gravity_description = {
        en = "How strongly the tail droops towards the ground instead of keeping its modelled shape. 0 = no droop, 0.3 = as built.",
    },
    tail_phys_trail = {
        en = "Tail: trail when running",
    },
    tail_phys_trail_description = {
        en = "How far the tail is left behind when you move. 1 = as built, 0 = moves along with you, higher = streams back further.",
    },
    physics_group = {
        en = "Physics",
    },
    jiggle = {
        en = "Physics on",
    },
    jiggle_description = {
        en = "The model's own physics bones swing and settle when you move, jump, dodge or slide (third person and menu previews). Off = everything stays on the rest pose.",
    },
    jiggle_breast = {
        en = "Amount: breasts",
    },
    jiggle_breast_description = {
        en = "1 = as built. Higher = looser and wider swings, lower = tighter. 0 = this area does not move.",
    },
    jiggle_butt = {
        en = "Amount: butt",
    },
    jiggle_butt_description = {
        en = "1 = as built. Higher = looser and wider swings, lower = tighter. 0 = this area does not move.",
    },
    jiggle_tail = {
        en = "Amount: tail",
    },
    jiggle_tail_description = {
        en = "1 = as built. Higher = looser and wider swings, lower = tighter. 0 = this area does not move.",
    },
    jiggle_cloth = {
        en = "Amount: clothing and chains",
    },
    jiggle_cloth_description = {
        en = "1 = as built. Higher = looser and wider swings, lower = tighter. 0 = this area does not move.",
    },
    jiggle_stiffness = {
        en = "Stiffness (all areas except the tail)",
    },
    jiggle_stiffness_description = {
        en = "How hard everything is pulled back to its rest pose. 1 = as built. Higher = snaps back faster, lower = softer and slower.",
    },
    jiggle_damping = {
        en = "Damping (all areas except the tail)",
    },
    jiggle_damping_description = {
        en = "How quickly the wobble dies out. 1 = as built. Higher = settles at once, lower = keeps bouncing longer.",
    },
    jiggle_limit = {
        en = "Swing limit (all areas except the tail)",
    },
    jiggle_limit_description = {
        en = "Scales the largest angle a bone may swing away from its rest pose. 1 = as built.",
    },
    jiggle_hang = {
        en = "Hang (hair and clothing)",
    },
    jiggle_hang_description = {
        en = "How strongly hair and loose clothing are drawn straight down instead of keeping their modelled direction when you lean or look up and down. 0 = keep the modelled shape.",
    },
    toggle_keybind = {
        en = "Toggle Kulve Taroth model",
    },
}
