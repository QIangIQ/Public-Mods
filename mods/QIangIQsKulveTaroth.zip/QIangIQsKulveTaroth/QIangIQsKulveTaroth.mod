return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsKulveTaroth` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsKulveTaroth", {
            mod_script = "QIangIQsKulveTaroth/scripts/mods/QIangIQsKulveTaroth/QIangIQsKulveTaroth",
            mod_data = "QIangIQsKulveTaroth/scripts/mods/QIangIQsKulveTaroth/QIangIQsKulveTaroth_data",
            mod_localization = "QIangIQsKulveTaroth/scripts/mods/QIangIQsKulveTaroth/QIangIQsKulveTaroth_localization",
        })
    end,
    version = "1.3.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
