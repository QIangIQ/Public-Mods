-- Sprays: aim at a surface, keep one spray per owner, draw it.
--
-- Aim (sources):
--   camera: Managers.state.camera:camera_position / camera_rotation(player.viewport_name)
--           (QIangIQsTarkAccount aim_core.lua:97-102)
--   raycast: PhysicsWorld.raycast(pw, from, dir, dist, "closest", "collision_filter", filter) returns
--           hit, position, distance, normal, actor (beast_of_nurgle.lua:198); statics-only filter
--           "filter_player_character_shooting_raycast_statics" (sound_reflection.lua:141)
--   physics world: World.physics_world(Managers.world:world("level_world")) (Dio's Handholder, HavocTracker)
--
-- Drawing, style "wall" (NOT confirmed in game):
--   World.create_world_gui(world, Matrix4x4.identity(), 1, 1, ...) (components/annotation.lua:43),
--   "immediate" flag as World.create_screen_gui(world, "immediate", ...) (ui_renderer.lua:63),
--   Gui.create_material(gui, name) (ui_renderer.lua:150), texture set as ui_passes.lua:44-51 does,
--   Gui.bitmap_3d(gui, material, tm, offset, layer, size, color) (world_interaction_manager.lua:216).
--   Any error switches this session to the "marker" style.
-- Drawing, style "marker": a world marker at the spot (QIangIQsSprays_markers.lua).
local mod = get_mod("QIangIQsSprays")

local Spray = {
    sprays = {},   -- [owner] = { url, user, pos = Vector3Box, normal = Vector3Box, left, marker_id, material, style }
    gui = nil,
    gui_world = nil,
    wall_failed = false,
    told_wall = false,
}

local REACH = 5
local MATERIAL = "content/ui/materials/base/ui_default_base"
local FILTER = "filter_player_character_shooting_raycast_statics"

local function level_world()
    return Managers.world and Managers.world:has_world("level_world") and Managers.world:world("level_world") or nil
end

function Spray.style()
    if Spray.wall_failed then
        return "marker"
    end
    return mod:get("spray_style") or "wall"
end

-- position, normal (Vector3) of the surface aimed at, or nil and a reason
function Spray.aim()
    local player = Managers.player and Managers.player:local_player_safe(1)
    local viewport = player and player.viewport_name
    local camera_manager = Managers.state and Managers.state.camera
    local world = level_world()
    if not viewport or not camera_manager or not world then
        return nil, "no_camera"
    end
    local from = camera_manager:camera_position(viewport)
    local rotation = camera_manager:camera_rotation(viewport)
    local physics_world = World.physics_world(world)
    if not from or not rotation or not physics_world then
        return nil, "no_camera"
    end
    local hit, position, _, normal = PhysicsWorld.raycast(physics_world, from, Quaternion.forward(rotation), REACH, "closest", "collision_filter", FILTER)
    if not hit or not position or not normal then
        return nil, "no_surface"
    end
    return position, normal
end

-- Wall drawing ------------------------------------------------------------------------------

local function destroy_gui()
    if Spray.gui and Spray.gui_world then
        for _, s in pairs(Spray.sprays) do
            s.material = nil
        end
        pcall(World.destroy_gui, Spray.gui_world, Spray.gui)
    end
    Spray.gui, Spray.gui_world = nil, nil
end

local function ensure_gui()
    local world = level_world()
    if not world then
        return nil
    end
    if Spray.gui and Spray.gui_world == world then
        return Spray.gui
    end
    destroy_gui()
    local gui = World.create_world_gui(world, Matrix4x4.identity(), 1, 1, "immediate")
    Spray.gui, Spray.gui_world = gui, world
    return gui
end

local function set_texture(material, texture)
    -- as apply_material_values (ui_passes.lua:44-51)
    if type(texture) == "string" then
        Material.set_texture(material, "texture_map", texture)
    else
        Material.set_resource(material, "texture_map", texture)
    end
    pcall(Material.set_scalar, material, "use_placeholder_texture", 0)
end

local UP = { 0, 0, 1 }

local function wall_pose(position, normal)
    local n = normal
    local d = n.x * UP[1] + n.y * UP[2] + n.z * UP[3]
    local up
    if math.abs(d) > 0.9 then
        -- floor or ceiling: the image's top points the way the camera looks
        local player = Managers.player:local_player_safe(1)
        local rotation = player and Managers.state.camera:camera_rotation(player.viewport_name)
        local f = rotation and Quaternion.forward(rotation) or Vector3(0, 1, 0)
        up = f - n * Vector3.dot(f, n)
    else
        up = Vector3(UP[1], UP[2], UP[3]) - n * d
    end
    if Vector3.length(up) < 0.001 then
        up = Vector3(1, 0, 0)
    end
    up = Vector3.normalize(up)
    -- Quaternion.look(forward, up): local Y = forward, local Z = up. Here Y = image up, Z = out of the wall,
    -- so X = Y x Z is the image's right as seen by someone facing the wall.
    local rotation = Quaternion.look(up, n)
    return Matrix4x4.from_quaternion_position(rotation, position + n * 0.02)
end

local function draw_wall(s, gui)
    local texture = mod.textures.get(s.url, s.user)
    if not texture then
        return
    end
    if not s.material then
        s.material = Gui.create_material(gui, MATERIAL)
        s.texture_set = nil
    end
    if s.texture_set ~= texture then
        set_texture(s.material, texture)
        s.texture_set = texture
    end
    local size = mod:get("spray_size") or 1
    local tm = wall_pose(s.pos:unbox(), s.normal:unbox())
    Gui.bitmap_3d(gui, s.material, tm, Vector3(-size * 0.5, -size * 0.5, 0), 1, Vector2(size, size), Color(255, 255, 255, 255))
end

local function wall_failed(err)
    Spray.wall_failed = true
    destroy_gui()
    mod:echo("[Sprays] Wall sprays failed here (%s). Using the Marker style for this session.", tostring(err))
    mod:warning("[Sprays] wall style error: %s", tostring(err))
    for _, s in pairs(Spray.sprays) do
        s.style = nil -- re-created as markers in update
    end
end

-- Marker drawing -----------------------------------------------------------------------------

local function remove_view(s)
    if s.marker_id then
        mod.markers.remove(s.marker_id)
        s.marker_id = nil
    end
    s.material = nil
    s.marker_pending = nil
    s.style = nil
end

local function ensure_marker(s)
    if s.marker_id or s.marker_pending then
        return
    end
    s.marker_pending = true
    local placed = mod.markers.spray(s.pos:unbox(), s.url, s.user, function(id)
        s.marker_id = id
        s.marker_pending = nil
    end)
    if not placed then
        s.marker_pending = nil -- marker element not there yet: retry next frame
    end
end

-- API -------------------------------------------------------------------------------------------

function Spray.place(owner, url, position, normal)
    Spray.remove(owner)
    Spray.sprays[owner] = {
        url = url,
        user = "spray:" .. tostring(owner),
        pos = Vector3Box(position),
        normal = Vector3Box(normal),
        left = (mod:get("spray_lifetime") or 5) * 60,
    }
    mod.textures.get(url, "spray:" .. tostring(owner))
    if Spray.style() == "wall" and not Spray.told_wall then
        Spray.told_wall = true
        mod:echo("[Sprays] Wall style. If the spray does not show, set Options > Spray style to Marker.")
    end
end

function Spray.remove(owner)
    local s = Spray.sprays[owner]
    if not s then
        return
    end
    remove_view(s)
    Spray.sprays[owner] = nil
    mod.textures.release(s.url, s.user)
end

function Spray.remove_all()
    for owner in pairs(Spray.sprays) do
        Spray.remove(owner)
    end
    destroy_gui()
end

function Spray.has(owner)
    return Spray.sprays[owner] ~= nil
end

-- style changed in the options: rebuild every spray's view
function Spray.restyle()
    for _, s in pairs(Spray.sprays) do
        remove_view(s)
    end
    if Spray.style() ~= "wall" then
        destroy_gui()
    end
end

-- returns owners whose spray expired (the caller withdraws its own)
function Spray.update(dt)
    local expired
    for owner, s in pairs(Spray.sprays) do
        s.left = s.left - dt
        if s.left <= 0 then
            expired = expired or {}
            expired[#expired + 1] = owner
        end
    end
    if expired then
        for i = 1, #expired do
            Spray.remove(expired[i])
        end
    end
    if next(Spray.sprays) == nil then
        return expired
    end
    local style = Spray.style()
    if style == "wall" then
        local ok, err = pcall(function()
            local gui = ensure_gui()
            if not gui then
                return
            end
            for _, s in pairs(Spray.sprays) do
                if s.style ~= "wall" then
                    remove_view(s)
                    s.style = "wall"
                end
                draw_wall(s, gui)
            end
        end)
        if not ok then
            wall_failed(err)
        end
    else
        for _, s in pairs(Spray.sprays) do
            if s.style ~= "marker" then
                remove_view(s)
                s.style = "marker"
            end
            ensure_marker(s)
        end
    end
    return expired
end

-- the level is going away: its world and HUD with it
function Spray.on_level_exit()
    for _, s in pairs(Spray.sprays) do
        s.marker_id, s.marker_pending, s.material = nil, nil, nil
    end
    Spray.remove_all()
end

return Spray
