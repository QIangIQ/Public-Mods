-- Radial wheel for emoticons and sprays. A copy of the game's emote wheel
-- (scripts/ui/hud/elements/emote_wheel/hud_element_emote_wheel.lua) with its definitions reused as they are;
-- the com_wheel input is replaced by this mod's held keybinds (mod.wheel_open = "emoticon" | "spray" | nil),
-- and slot icons are the downloaded images. Added to the HUD with mod:register_hud_element (DMF).
local mod = get_mod("QIangIQsSprays")

local Definitions = require("scripts/ui/hud/elements/emote_wheel/hud_element_emote_wheel_definitions")
local InputDevice = require("scripts/managers/input/input_device")
local UISoundEvents = require("scripts/settings/ui/ui_sound_events")
local UIWidget = require("scripts/managers/ui/ui_widget")

local SLOTS = 8
local ANIM_SPEED = 25 -- hud_element_emote_wheel_settings.lua
local MIN_RADIUS = 185
local MAX_RADIUS = 190
local HOVER_GRACE_PERIOD = 0.4
local EMPTY_ICON = "content/ui/textures/icons/emotes/empty"

local HudElementQIangIQsSprayWheel = class("HudElementQIangIQsSprayWheel", "HudElementBase")

HudElementQIangIQsSprayWheel.init = function(self, parent, draw_layer, start_scale)
    HudElementQIangIQsSprayWheel.super.init(self, parent, draw_layer, start_scale, Definitions)
    self._wheel_active_progress = 0
    self._wheel_active = false
    self._kind = nil
    self._last_widget_hover_data = { index = nil, t = nil }
    local entries = {}
    for i = 1, SLOTS do
        entries[i] = { widget = self:_create_widget("qiangiq_spray_entry_" .. i, Definitions.entry_widget_definition) }
    end
    self._entries = entries
end

-- fill the slots from the library for the open wheel's kind
HudElementQIangIQsSprayWheel._update_slots = function(self)
    local kind = self._kind or "emoticon"
    local slots = mod.slots(kind)
    for i = 1, SLOTS do
        local entry = self._entries[i]
        local widget = entry.widget
        local name = slots[i]
        local item = name and mod.find(name)
        if item and item.kind ~= kind then
            item = nil
        end
        entry.item = item
        widget.content.visible = true
        widget.content.text = ""
        local material_values = widget.style.icon.material_values
        local texture = item and mod.textures.get(item.url, "library")
        if texture then
            material_values.texture_map = texture
            material_values.use_placeholder_texture = 0
        else
            -- hud_element_emote_wheel.lua:143-144
            material_values.texture_map = EMPTY_ICON
            material_values.use_placeholder_texture = 1
        end
    end
end

HudElementQIangIQsSprayWheel.update = function(self, dt, t, ui_renderer, render_settings, input_service)
    HudElementQIangIQsSprayWheel.super.update(self, dt, t, ui_renderer, render_settings, input_service)
    self:_handle_input(t, dt, ui_renderer, render_settings)
    if self._wheel_active then
        self:_update_slots()
    end
    self:_update_active_progress(dt)
    self:_update_widget_locations()
    if self._wheel_active then
        self:_update_wheel_presentation(dt, t, ui_renderer, render_settings, self._input_service)
    end
end

HudElementQIangIQsSprayWheel._handle_input = function(self, t, dt, ui_renderer, render_settings)
    local input_service = Managers.ui:input_service("Ingame")
    self._input_service = input_service
    -- a menu or the chat took the input: close without picking (hud_element_emote_wheel.lua:302-305)
    local blocked = Managers.ui:using_input(true)
    local want = not blocked and mod:is_enabled() and mod.wheel_open or nil

    if want and not self._wheel_active then
        self._kind = want
        self._wheel_active = true
        self:_update_slots()
        if UISoundEvents.emote_wheel_open then
            Managers.ui:play_2d_sound(UISoundEvents.emote_wheel_open)
        end
        if not InputDevice.gamepad_active then
            self:_push_cursor()
        end
    elseif self._wheel_active and want ~= self._kind then
        local picked = not blocked and self:_hovered_item(t)
        local kind = self._kind
        self:_on_wheel_closed()
        if picked then
            if UISoundEvents.emote_wheel_entry_select then
                Managers.ui:play_2d_sound(UISoundEvents.emote_wheel_entry_select)
            end
            mod.use(kind, picked.name)
        elseif UISoundEvents.emote_wheel_close then
            Managers.ui:play_2d_sound(UISoundEvents.emote_wheel_close)
        end
        if want then
            mod.wheel_open = nil -- the other wheel key: let it be pressed again
        end
    end
end

HudElementQIangIQsSprayWheel._hovered_item = function(self, t)
    for i = 1, SLOTS do
        local entry = self._entries[i]
        if entry.widget.content.hotspot.is_hover or entry.widget.content.hotspot.force_hover then
            return entry.item
        end
    end
    local last_hover = self._last_widget_hover_data
    if last_hover.t and t < last_hover.t + HOVER_GRACE_PERIOD and last_hover.index then
        return self._entries[last_hover.index].item
    end
    return nil
end

HudElementQIangIQsSprayWheel.using_input = function(self)
    return self._wheel_active
end

HudElementQIangIQsSprayWheel._on_wheel_closed = function(self)
    self:_pop_cursor()
    self._wheel_active = false
    self._last_widget_hover_data.t = nil
    self._last_widget_hover_data.index = nil
end

-- hover by cursor angle: hud_element_emote_wheel.lua:412-482
HudElementQIangIQsSprayWheel._update_wheel_presentation = function(self, dt, t, ui_renderer, render_settings, input_service)
    local screen_width, screen_height = RESOLUTION_LOOKUP.width, RESOLUTION_LOOKUP.height
    local scale = render_settings.scale
    local cursor = input_service and input_service:get("cursor")
    if input_service and InputDevice.gamepad_active then
        cursor = input_service:get("navigate_controller_right")
        cursor[1] = screen_width * 0.5 + cursor[1] * screen_width * 0.5
        cursor[2] = screen_height * 0.5 - cursor[2] * screen_height * 0.5
    end
    if not cursor then
        return
    end
    local distance = math.distance_2d(screen_width * 0.5, screen_height * 0.5, cursor[1], cursor[2])
    local cursor_angle = math.angle(screen_width * 0.5, screen_height * 0.5, cursor[1], cursor[2]) - math.pi * 0.5
    local cursor_degrees = math.radians_to_degrees(cursor_angle) % 360
    local half = 22 -- entry_hover_degrees 44 / 2
    local hovered_entry
    for i = 1, SLOTS do
        local entry = self._entries[i]
        local widget = entry.widget
        local widget_degrees = -(math.radians_to_degrees(widget.content.angle or 0) - math.pi * 0.5) % 360
        local is_hover = false
        if entry.item and distance > 130 * scale then
            local diff = (widget_degrees - cursor_degrees + 180 + 360) % 360 - 180
            if diff <= half and diff >= -half then
                is_hover = true
                hovered_entry = entry
            end
        end
        if is_hover and not widget.content.hotspot.force_hover then
            Managers.ui:play_2d_sound(UISoundEvents.emote_wheel_entry_hover)
        end
        widget.content.hotspot.force_hover = is_hover
    end
    local background = self._widgets_by_name.wheel_background
    background.content.angle = cursor_angle
    background.content.force_hover = hovered_entry ~= nil
    background.style.mark.color[1] = hovered_entry and 255 or 0
    background.content.text = hovered_entry and hovered_entry.item.name or ""
end

HudElementQIangIQsSprayWheel._update_active_progress = function(self, dt)
    local progress = self._wheel_active_progress
    if self._wheel_active then
        progress = math.min(progress + dt * ANIM_SPEED, 1)
    else
        progress = math.max(progress - dt * ANIM_SPEED, 0)
    end
    self._wheel_active_progress = progress
end

-- hud_element_emote_wheel.lua:519-546
HudElementQIangIQsSprayWheel._update_widget_locations = function(self)
    local start_angle = math.pi / 2
    local radians_per_widget = math.pi * 2 / SLOTS
    local anim_progress = math.smoothstep(self._wheel_active_progress, 0, 1)
    local radius = MIN_RADIUS + anim_progress * (MAX_RADIUS - MIN_RADIUS)
    for i = 1, SLOTS do
        local widget = self._entries[i].widget
        local angle = start_angle + (i - 1) * radians_per_widget
        widget.content.angle = angle
        widget.offset[1] = math.sin(angle) * radius
        widget.offset[2] = math.cos(angle) * radius
    end
end

HudElementQIangIQsSprayWheel._push_cursor = function(self)
    local input_manager = Managers.input
    local name = self.__class_name
    input_manager:push_cursor(name)
    input_manager:set_cursor_position(name, Vector3(0.5, 0.5, 0))
    self._cursor_pushed = true
end

HudElementQIangIQsSprayWheel._pop_cursor = function(self)
    if self._cursor_pushed then
        Managers.input:pop_cursor(self.__class_name)
        self._cursor_pushed = nil
    end
end

HudElementQIangIQsSprayWheel._draw_widgets = function(self, dt, t, input_service, ui_renderer, render_settings)
    local progress = self._wheel_active_progress
    if progress == 0 then
        return
    end
    local previous_alpha = render_settings.alpha_multiplier
    render_settings.alpha_multiplier = progress
    for i = 1, SLOTS do
        local widget = self._entries[i].widget
        UIWidget.draw(widget, ui_renderer)
        if widget.content.hotspot.is_hover then
            self._last_widget_hover_data.t = t
            self._last_widget_hover_data.index = i
        end
    end
    HudElementQIangIQsSprayWheel.super._draw_widgets(self, dt, t, input_service, ui_renderer, render_settings)
    render_settings.alpha_multiplier = previous_alpha
end

HudElementQIangIQsSprayWheel.destroy = function(self, ui_renderer)
    self:_on_wheel_closed()
    HudElementQIangIQsSprayWheel.super.destroy(self, ui_renderer)
end

return HudElementQIangIQsSprayWheel
