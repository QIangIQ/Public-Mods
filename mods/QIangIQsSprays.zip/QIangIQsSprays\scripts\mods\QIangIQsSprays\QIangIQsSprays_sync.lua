-- Sharing through QIangIQsSyncChannel, category "s" (pattern of QIangIQsEmotes.lua:977-1161).
-- What I publish: e = { q = sequence, u = url } for my last emoticon, p = my spray. Peers diff it with Core.diff.
local mod = get_mod("QIangIQsSprays")

local Sync = {
    CATEGORY = "s",
    NAME = "sprays",
    POLL_INTERVAL = 0.5,
    channel = nil,
    unsubscribe = nil,
    poll_now = true,
    poll_timer = 0,
    state = {}, -- Core.diff state per account id
    mine = { seq = 0, emoticon = nil, spray = nil },
}

-- free of side effects: the channel may call it at any time
local function build()
    if not mod:get("share") or not mod:is_enabled() then
        return nil
    end
    local mine = Sync.mine
    local out = {}
    if mine.emoticon then
        out.e = mine.emoticon
    end
    if mine.spray then
        out.p = mine.spray
    end
    return next(out) and out or nil
end

function Sync.publish()
    if Sync.channel then
        Sync.channel.mark_dirty()
    end
end

function Sync.my_emoticon(url)
    local mine = Sync.mine
    mine.seq = (mine.seq % 99999) + 1
    mine.emoticon = mod.core.emoticon_entry(mine.seq, url)
    Sync.publish()
end

-- the map's mission name (Managers.state.mission:mission_name(), coherency_system.lua:23), so a spray from the
-- previous map is never placed on the next one
function Sync.mission()
    local mission = Managers.state and Managers.state.mission
    if not mission then
        return nil
    end
    local ok, name = pcall(mission.mission_name, mission)
    return ok and type(name) == "string" and name or nil
end

function Sync.my_spray(url, position, normal)
    Sync.mine.spray = url and mod.core.spray_entry(url, { position.x, position.y, position.z }, { normal.x, normal.y, normal.z }, Sync.mission()) or nil
    Sync.publish()
end

-- Emotes.lua:999-1012
local function player_by_account(account_id)
    local players = Managers.player and Managers.player:players()
    if players then
        for _, player in pairs(players) do
            if player.remote and player.account_id then
                local ok, id = pcall(player.account_id, player)
                if ok and id == account_id then
                    return player
                end
            end
        end
    end
    return nil
end

local function peer_owner(account_id)
    return "peer:" .. tostring(account_id)
end

local function run(account_id, action)
    local kind = action[1]
    if kind == "emoticon" then
        local player = player_by_account(account_id)
        local unit = player and player.player_unit
        if unit then
            mod.markers.emoticon(unit, action[2])
        end
    elseif kind == "spray" then
        local pos, n = action[3], action[4]
        mod.spray.place(peer_owner(account_id), action[2], Vector3(pos[1], pos[2], pos[3]), Vector3(n[1], n[2], n[3]))
    elseif kind == "remove_spray" then
        mod.spray.remove(peer_owner(account_id))
    end
end

local function forget(account_id)
    mod.spray.remove(peer_owner(account_id))
end

function Sync.process()
    local channel = Sync.channel
    if not channel then
        return
    end
    local core = mod.core
    local hosts = mod.hosts()
    local show = mod:get("show_others") and mod:is_enabled()
    local present = {}
    local mission = Sync.mission()
    for account_id, entry in pairs(channel.roster()) do
        if show and entry.running then
            present[account_id] = true
            local bucket = type(entry.data) == "table" and entry.data[Sync.CATEGORY] or nil
            local actions = core.diff(Sync.state, account_id, core.read_peer(bucket, hosts), mission or false)
            for i = 1, #actions do
                local ok, err = pcall(run, account_id, actions[i])
                if not ok then
                    mod:warning("[Sprays] peer action failed: %s", tostring(err))
                end
            end
        end
    end
    local gone = core.gone(Sync.state, present)
    for i = 1, #gone do
        forget(gone[i])
    end
end

function Sync.update(dt)
    if not Sync.channel then
        return
    end
    Sync.poll_timer = Sync.poll_timer + dt
    if Sync.poll_now or Sync.poll_timer >= Sync.POLL_INTERVAL then
        Sync.poll_now = false
        Sync.poll_timer = 0
        Sync.process()
    end
end

function Sync.start()
    if Sync.channel then
        return true
    end
    local host = get_mod("QIangIQsSyncChannel")
    local channel = host and host.api
    if not channel then
        mod:info("[Sprays] QIangIQsSyncChannel not found; emoticons and sprays are shown on your own screen only.")
        return false
    end
    channel.provide(Sync.NAME, Sync.CATEGORY, build)
    Sync.channel = channel
    Sync.unsubscribe = channel.on_change(function()
        Sync.poll_now = true
    end)
    Sync.poll_now = true
    return true
end

function Sync.stop()
    if Sync.channel then
        Sync.channel.withdraw(Sync.NAME)
    end
    if Sync.unsubscribe then
        Sync.unsubscribe()
    end
    Sync.channel, Sync.unsubscribe = nil, nil
    for account_id in pairs(Sync.state) do
        forget(account_id)
    end
    Sync.state = {}
end

-- the level ended: peers' sprays went with it; their next read re-places sprays still published
function Sync.on_level_exit()
    Sync.state = {}
    Sync.mine.emoticon = nil
    Sync.mine.spray = nil
    Sync.publish()
end

return Sync
