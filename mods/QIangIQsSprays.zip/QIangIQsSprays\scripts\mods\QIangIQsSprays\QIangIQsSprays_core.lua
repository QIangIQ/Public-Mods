-- QIangIQ's Sprays: engine-free logic (library, URL checks, sync entries, peer diffing).
-- Kept free of engine globals so it can be tested outside the game (tools/test_sprays.py).
-- Author: QIangIQ
local Core = {}

Core.DEFAULT_HOSTS = { "i.imgur.com", "cdn.discordapp.com", "media.discordapp.net" }
Core.MAX_URL = 200 -- a Sync Channel entry must stay under ~200 bytes (note 40)
Core.SLOTS = 8     -- HudElementEmoteWheelSettings.wheel_slots
Core.COOLDOWN = 2  -- Vox Manifold publishes at most every 2 s (QIangIQsSyncChannel.lua api comment)
Core.KINDS = { emoticon = true, spray = true }
Core.MAX_COORD = 100000

local function host_of(url)
    local host = url:match("^https://([^/:%?#]+)")
    return host and host:lower() or nil
end

local function host_allowed(host, hosts)
    for i = 1, #hosts do
        if hosts[i] == host then
            return true
        end
    end
    return false
end

function Core.validate_url(url, hosts)
    if type(url) ~= "string" or url == "" then
        return false, "empty"
    end
    if #url > Core.MAX_URL then
        return false, "too_long"
    end
    if url:find("[%s\"'\\<>]") then
        return false, "chars"
    end
    local host = host_of(url)
    if not host then
        return false, "not_https"
    end
    if not host_allowed(host, hosts or Core.DEFAULT_HOSTS) then
        return false, "host"
    end
    return true
end

function Core.valid_name(name)
    return type(name) == "string" and #name >= 1 and #name <= 24 and name:match("^[%w_%-]+$") ~= nil
end

function Core.library_find(lib, name)
    for i = 1, #lib do
        if lib[i].name == name then
            return lib[i], i
        end
    end
    return nil
end

function Core.library_add(lib, kind, name, url, hosts)
    if not Core.KINDS[kind] then
        return false, "kind"
    end
    if not Core.valid_name(name) then
        return false, "name"
    end
    if Core.library_find(lib, name) then
        return false, "duplicate"
    end
    local ok, reason = Core.validate_url(url, hosts)
    if not ok then
        return false, reason
    end
    lib[#lib + 1] = { name = name, url = url, kind = kind }
    return true
end

function Core.library_remove(lib, name)
    local _, index = Core.library_find(lib, name)
    if index then
        table.remove(lib, index)
        return true
    end
    return false
end

function Core.set_slot(slots, index, name)
    index = tonumber(index)
    if not index or index < 1 or index > Core.SLOTS or index % 1 ~= 0 then
        return false
    end
    slots[index] = name or false
    return true
end

function Core.can_send(last_t, t)
    return last_t == nil or t - last_t >= Core.COOLDOWN
end

local function round2(v)
    return math.floor(v * 100 + 0.5) / 100
end

function Core.emoticon_entry(seq, url)
    return { q = seq, u = url }
end

function Core.spray_entry(url, pos, normal, mission)
    return {
        u = url,
        m = mission,
        x = round2(pos[1]), y = round2(pos[2]), z = round2(pos[3]),
        nx = round2(normal[1]), ny = round2(normal[2]), nz = round2(normal[3]),
    }
end

local function finite(v)
    return type(v) == "number" and v == v and v > -Core.MAX_COORD and v < Core.MAX_COORD
end

-- A peer's category "s" bucket, checked. Anything malformed is dropped, never raised.
function Core.read_peer(bucket, hosts)
    local out = {}
    if type(bucket) ~= "table" then
        return out
    end
    local e = bucket.e
    if type(e) == "table" and type(e.q) == "number" and Core.validate_url(e.u, hosts) then
        out.e = { q = e.q, u = e.u }
    end
    local p = bucket.p
    if type(p) == "table" and Core.validate_url(p.u, hosts)
        and finite(p.x) and finite(p.y) and finite(p.z)
        and finite(p.nx) and finite(p.ny) and finite(p.nz) then
        local len = math.sqrt(p.nx * p.nx + p.ny * p.ny + p.nz * p.nz)
        if len > 0.01 then
            local m = type(p.m) == "string" and #p.m <= 64 and p.m or nil
            out.p = { u = p.u, m = m, pos = { p.x, p.y, p.z }, normal = { p.nx / len, p.ny / len, p.nz / len } }
        end
    end
    return out
end

local function spray_key(p)
    return p and string.format("%s|%s|%s|%s|%s|%s|%s|%s", p.u, tostring(p.m), p.pos[1], p.pos[2], p.pos[3], p.normal[1], p.normal[2], p.normal[3]) or nil
end

-- What to do for one peer. state[account_id] = { started, q, spray_key }.
-- The first read of a peer only records its emoticon sequence: an emoticon sent before I saw them is old.
-- A spray is shown on first read: it is still on the wall.
-- `mission`: a spray made on another map (m differs) is treated as no spray.
function Core.diff(state, account_id, peer, mission)
    local actions = {}
    if peer.p and mission ~= nil and peer.p.m ~= mission then
        peer.p = nil
    end
    local st = state[account_id]
    if not st then
        st = {}
        state[account_id] = st
    end
    local e = peer.e
    if st.started and e and e.q ~= st.q then
        actions[#actions + 1] = { "emoticon", e.u }
    end
    st.q = e and e.q or nil
    st.started = true

    local key = spray_key(peer.p)
    if key ~= st.spray_key then
        if peer.p then
            actions[#actions + 1] = { "spray", peer.p.u, peer.p.pos, peer.p.normal }
        else
            actions[#actions + 1] = { "remove_spray" }
        end
        st.spray_key = key
    end
    return actions
end

-- Peers that were known and are no longer present; their state is cleared.
function Core.gone(state, present)
    local out = {}
    for account_id in pairs(state) do
        if not present[account_id] then
            out[#out + 1] = account_id
        end
    end
    for i = 1, #out do
        state[out[i]] = nil
    end
    return out
end

return Core
