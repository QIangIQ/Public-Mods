-- QIangIQ's Sprays: emoticons above your head and sprays on surfaces, from image links.
-- Pick from a radial wheel (hold a key) or bind slots directly. Shared through QIangIQsSyncChannel.
--   _core      engine-free logic (library, URL checks, sync entries, peer diffing); tested by
--              _QIangIQ_notes/utility/tools/test_sprays.py
--   _textures  image downloads (Managers.url_loader, never with backend auth)
--   _markers   world-marker templates: emoticon, marker-style spray
--   _spray     aim, one spray per owner, wall / marker drawing
--   _wheel     the radial wheel HUD element
--   _sync      Sync Channel category "s"
-- Author: QIangIQ
local mod = get_mod("QIangIQsSprays")

mod.version = "1.0.0"
mod.AUTHOR = "QIangIQ"

local ROOT = "QIangIQsSprays/scripts/mods/QIangIQsSprays/"
local Core = mod:io_dofile(ROOT .. "QIangIQsSprays_core")
mod.core = Core
mod.textures = mod:io_dofile(ROOT .. "QIangIQsSprays_textures")
mod.markers = mod:io_dofile(ROOT .. "QIangIQsSprays_markers")
mod.spray = mod:io_dofile(ROOT .. "QIangIQsSprays_spray")
mod.sync = mod:io_dofile(ROOT .. "QIangIQsSprays_sync")

mod:register_hud_element({
    class_name = "HudElementQIangIQsSprayWheel",
    filename = ROOT .. "QIangIQsSprays_wheel",
    use_hud_scale = true,
    visibility_groups = { "alive" },
})

-- Library ------------------------------------------------------------------------------------
-- Sample image: the link the Sprays mod ships with (Sprays/scripts/mods/Sprays/Sprays.lua:27).
local SAMPLE = { name = "sample", url = "https://i.imgur.com/0L4pcoX.jpg" }

local function copy_list(list)
    local out = {}
    for i = 1, #list do
        out[i] = list[i]
    end
    return out
end

function mod.hosts()
    local hosts = mod:get("hosts")
    if type(hosts) ~= "table" then
        hosts = copy_list(Core.DEFAULT_HOSTS)
        mod:set("hosts", hosts)
    end
    return hosts
end

function mod.library()
    local lib = mod:get("library")
    if type(lib) ~= "table" then
        lib = {
            { name = SAMPLE.name .. "_emoticon", url = SAMPLE.url, kind = "emoticon" },
            { name = SAMPLE.name .. "_spray", url = SAMPLE.url, kind = "spray" },
        }
        mod:set("library", lib)
        mod:set("slots_emoticon", { SAMPLE.name .. "_emoticon" })
        mod:set("slots_spray", { SAMPLE.name .. "_spray" })
    end
    return lib
end

function mod.slots(kind)
    mod.library() -- seeds the slots on first run
    local key = "slots_" .. kind
    local slots = mod:get(key)
    local changed = type(slots) ~= "table"
    slots = changed and {} or slots
    -- always 8 entries (false = empty): a saved table with holes would not keep its indices
    for i = 1, Core.SLOTS do
        if slots[i] == nil then
            slots[i] = false
            changed = true
        end
    end
    if changed then
        mod:set(key, slots)
    end
    return slots
end

function mod.find(name)
    return Core.library_find(mod.library(), name)
end

local function save()
    mod:set("library", mod.library())
end

-- Using an image -------------------------------------------------------------------------------
local last_emoticon_t

local function now()
    return Managers.time and Managers.time:has_timer("main") and Managers.time:time("main") or os.clock()
end

local function my_unit()
    local player = Managers.player and Managers.player:local_player_safe(1)
    return player and player.player_unit
end

function mod.use(kind, name)
    local item = name and mod.find(name)
    if not item then
        mod:echo("[Sprays] no image named '%s'. /spray list shows them.", tostring(name))
        return false
    end
    if kind == "emoticon" then
        local t = now()
        if not Core.can_send(last_emoticon_t, t) then
            return false
        end
        local unit = my_unit()
        if not unit then
            return false
        end
        last_emoticon_t = t
        mod.markers.emoticon(unit, item.url, true)
        mod.sync.my_emoticon(item.url)
        return true
    elseif kind == "spray" then
        local position, normal = mod.spray.aim()
        if not position then
            mod:echo(normal == "no_surface" and "[Sprays] Aim at a wall or the floor within 5 m." or "[Sprays] Can't spray here.")
            return false
        end
        mod.spray.place("me", item.url, position, normal)
        mod.sync.my_spray(item.url, position, normal)
        return true
    end
    return false
end

local function use_slot(kind, index)
    local name = mod.slots(kind)[index]
    if name then
        mod.use(kind, name)
    else
        mod:echo("[Sprays] %s slot %d is empty. /spray slot %s %d <name>", kind, index, kind, index)
    end
end

-- Keybinds ---------------------------------------------------------------------------------------
mod.wheel_open = nil

mod.kb_wheel_emoticon = function(held)
    if held then
        mod.wheel_open = "emoticon"
    elseif mod.wheel_open == "emoticon" then
        mod.wheel_open = nil
    end
end

mod.kb_wheel_spray = function(held)
    if held then
        mod.wheel_open = "spray"
    elseif mod.wheel_open == "spray" then
        mod.wheel_open = nil
    end
end

for i = 1, Core.SLOTS do
    mod["kb_emoticon_" .. i] = function()
        use_slot("emoticon", i)
    end
    mod["kb_spray_" .. i] = function()
        use_slot("spray", i)
    end
end

-- Commands --------------------------------------------------------------------------------------
local REASONS = {
    kind = "the type must be emoticon or spray",
    name = "names use letters, digits, _ and -, up to 24 characters",
    duplicate = "that name is taken",
    empty = "the link is missing",
    too_long = "the link is longer than 200 characters",
    chars = "the link has spaces or quotes",
    not_https = "the link must start with https://",
    host = "that site is not allowed (see /spray host)",
}

local HELP = {
    "/spray add <emoticon|spray> <name> <link>  add an image (and put it in the first free slot)",
    "/spray remove <name>  /spray list  /spray slot <emoticon|spray> <1-8> <name|none>",
    "/spray use <name>  show or spray it now   /spray clear  remove your spray",
    "/spray host [add|remove <site>]  sites images may come from",
}

local function cmd_add(kind, name, url)
    local lib = mod.library()
    local ok, reason = Core.library_add(lib, kind, name, url, mod.hosts())
    if not ok then
        mod:echo("[Sprays] not added: %s.", REASONS[reason] or reason)
        return
    end
    save()
    local slots = mod.slots(kind)
    for i = 1, Core.SLOTS do
        if not slots[i] then
            slots[i] = name
            mod:set("slots_" .. kind, slots)
            mod:echo("[Sprays] added %s '%s' in slot %d.", kind, name, i)
            mod.textures.get(url, "library")
            return
        end
    end
    mod:echo("[Sprays] added %s '%s' (wheel full: /spray slot %s <1-8> %s).", kind, name, kind, name)
end

local function cmd_remove(name)
    local item = mod.find(name)
    if not item or not Core.library_remove(mod.library(), name) then
        mod:echo("[Sprays] no image named '%s'.", tostring(name))
        return
    end
    save()
    for _, kind in ipairs({ "emoticon", "spray" }) do
        local slots = mod.slots(kind)
        for i = 1, Core.SLOTS do
            if slots[i] == name then
                slots[i] = false
            end
        end
        mod:set("slots_" .. kind, slots)
    end
    mod.textures.release(item.url, "library")
    mod:echo("[Sprays] removed '%s'.", name)
end

local function cmd_list()
    for _, kind in ipairs({ "emoticon", "spray" }) do
        local slots = mod.slots(kind)
        local parts = {}
        for i = 1, Core.SLOTS do
            parts[i] = i .. "=" .. (slots[i] or "-")
        end
        mod:echo("[Sprays] %s wheel: %s", kind, table.concat(parts, "  "))
    end
    for _, item in ipairs(mod.library()) do
        local state = mod.textures.failed(item.url) and " (failed to load)" or ""
        mod:echo("  %s [%s] %s%s", item.name, item.kind, item.url, state)
    end
end

local function cmd_slot(kind, index, name)
    if not Core.KINDS[kind] then
        mod:echo("[Sprays] %s.", REASONS.kind)
        return
    end
    if name ~= "none" then
        local item = mod.find(name)
        if not item then
            mod:echo("[Sprays] no image named '%s'.", tostring(name))
            return
        elseif item.kind ~= kind then
            mod:echo("[Sprays] '%s' belongs on the %s wheel.", name, item.kind)
            return
        end
    end
    local slots = mod.slots(kind)
    if not Core.set_slot(slots, index, name ~= "none" and name or nil) then
        mod:echo("[Sprays] slot must be 1-8.")
        return
    end
    mod:set("slots_" .. kind, slots)
    mod:echo("[Sprays] %s slot %s = %s.", kind, tostring(index), name)
end

local function cmd_host(action, host)
    local hosts = mod.hosts()
    if action == "add" and host then
        host = host:lower()
        for i = 1, #hosts do
            if hosts[i] == host then
                return
            end
        end
        hosts[#hosts + 1] = host
        mod:set("hosts", hosts)
    elseif action == "remove" and host then
        host = host:lower()
        for i = #hosts, 1, -1 do
            if hosts[i] == host then
                table.remove(hosts, i)
            end
        end
        mod:set("hosts", hosts)
    end
    mod:echo("[Sprays] allowed sites: %s", table.concat(hosts, ", "))
end

mod:command("spray", "Emoticons and sprays: /spray help", function(sub, a, b, c)
    if sub == "add" then
        cmd_add(a, b, c)
    elseif sub == "remove" then
        cmd_remove(a)
    elseif sub == "list" then
        cmd_list()
    elseif sub == "slot" then
        cmd_slot(a, b, c)
    elseif sub == "use" then
        local item = mod.find(a)
        if item then
            mod.use(item.kind, a)
        else
            mod:echo("[Sprays] no image named '%s'.", tostring(a))
        end
    elseif sub == "clear" then
        mod.spray.remove("me")
        mod.sync.my_spray(nil)
    elseif sub == "host" then
        cmd_host(a, b)
    else
        for i = 1, #HELP do
            mod:echo(HELP[i])
        end
    end
end)

-- Lifecycle --------------------------------------------------------------------------------------
local loaded = false

mod.on_all_mods_loaded = function()
    loaded = true
    mod.library()
    mod.hosts()
    mod.sync.start()
end

mod.update = function(dt)
    dt = dt or 0
    local expired = mod.spray.update(dt)
    if expired then
        for i = 1, #expired do
            if expired[i] == "me" then
                mod.sync.my_spray(nil)
            end
        end
    end
    mod.sync.update(dt)
end

mod.on_setting_changed = function(setting_id)
    if setting_id == "share" then
        mod.sync.publish()
    elseif setting_id == "show_others" then
        mod.sync.poll_now = true
    elseif setting_id == "spray_style" then
        mod.spray.restyle()
    end
end

mod.on_game_state_changed = function(status, state_name)
    if state_name == "StateGameplay" and status == "exit" then
        mod.wheel_open = nil
        mod.spray.on_level_exit()
        mod.sync.on_level_exit()
    end
end

mod.on_disabled = function()
    mod.wheel_open = nil
    mod.spray.remove_all()
    mod.sync.stop()
end

mod.on_enabled = function()
    -- DMF also calls this while mods are still loading, before the channel exists
    if loaded then
        mod.sync.start()
    end
end

mod.on_unload = function()
    mod.spray.remove_all()
    mod.sync.stop()
    mod.textures.release_all()
end
