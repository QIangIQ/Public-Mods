-- Image download cache over Managers.url_loader (scripts/managers/url_loader/url_loader_manager.lua).
-- load_texture(url, require_auth): require_auth defaults to true (line 79), which sends the game's backend
-- authentication with the request. These are third-party image hosts, so it is always false here
-- (as SimpleAssets texture/loading.lua:45). Every load_texture is matched by one unload_texture (lines 54-55, 98-110).
local mod = get_mod("QIangIQsSprays")

local Textures = {
    entries = {}, -- [url] = { texture = userdata|string|nil, failed = bool, loading = bool, users = { [key] = true } }
}

local function entry_for(url)
    local entry = Textures.entries[url]
    if entry then
        return entry
    end
    entry = { users = {} }
    Textures.entries[url] = entry
    local loader = Managers.url_loader
    if not loader then
        entry.failed = true
        return entry
    end
    entry.loading = true
    entry.requested = true
    local ok, promise = pcall(loader.load_texture, loader, url, false, "QIangIQsSprays")
    if not ok or not promise then
        entry.loading, entry.failed = false, true
        mod:warning("[Sprays] could not request %s: %s", url, tostring(promise))
        return entry
    end
    promise:next(function(data)
        entry.loading = false
        if Textures.entries[url] ~= entry then
            return -- released while loading; its unload already ran
        end
        entry.texture = data and data.texture
        entry.failed = entry.texture == nil
    end):catch(function()
        entry.loading = false
        if Textures.entries[url] == entry then
            entry.failed = true -- url_loader caches the failure too; it is not retried this session
            mod:echo("[Sprays] could not load image: %s", url)
        end
    end)
    return entry
end

-- texture or nil (still loading or failed). `user` is any key that keeps the image in memory.
function Textures.get(url, user)
    if type(url) ~= "string" then
        return nil
    end
    local entry = entry_for(url)
    entry.users[user or "default"] = true
    return entry.texture
end

function Textures.failed(url)
    local entry = Textures.entries[url]
    return entry ~= nil and entry.failed == true
end

local function unload(url, entry)
    Textures.entries[url] = nil
    if entry.requested and Managers.url_loader then
        pcall(Managers.url_loader.unload_texture, Managers.url_loader, url)
    end
end

-- drop one user; the image is unloaded when nobody uses it
function Textures.release(url, user)
    local entry = url and Textures.entries[url]
    if not entry then
        return
    end
    entry.users[user or "default"] = nil
    if next(entry.users) == nil then
        unload(url, entry)
    end
end

function Textures.release_all()
    for url, entry in pairs(Textures.entries) do
        unload(url, entry)
    end
end

return Textures
