-- World-marker templates: the emoticon above a head and the "marker" spray style.
-- Template shape and animation from Sprays/scripts/mods/Sprays/SprayMarkerTemplate.lua; marker fields used by
-- HudElementWorldMarkers (hud_element_world_markers.lua): life_time / duration (:310-319), unit_node (:301),
-- position_offset (:327), world_position for position markers (:137-166), update_function(self, ui_renderer,
-- widget, marker, template, dt, t) (:467), create_widget_defintion (sic, :231).
-- The texture pass uses the material of the emote wheel icons ("content/ui/materials/base/ui_default_base" with
-- material_values.texture_map, hud_element_emote_wheel_definitions.lua:75-84).
local mod = get_mod("QIangIQsSprays")
local UIWidget = require("scripts/managers/ui/ui_widget")

local Markers = {}

local MATERIAL = "content/ui/materials/base/ui_default_base"

local function texture_widget(scenegraph_id)
    return UIWidget.create_definition({
        {
            pass_type = "texture",
            style_id = "texture",
            value = MATERIAL,
            style = {
                vertical_alignment = "center",
                horizontal_alignment = "center",
                offset = { 0, 0, 1 },
                size = { 10, 10 },
                material_values = {},
                color = { 255, 255, 255, 255 },
            },
            visibility_function = function(_content, style)
                return style.material_values.texture_map ~= nil
            end,
        },
    }, scenegraph_id)
end

local function apply_texture(widget, url, user)
    local texture = mod.textures.get(url, user)
    widget.style.texture.material_values.texture_map = texture
end

-- Emoticon -----------------------------------------------------------------------------------
local emoticon = {
    name = "qiangiq_emoticon",
    unit_node = "j_head",
    life_time = 2.5,
    position_offset = { 0, 0, 0.35 },
    check_line_of_sight = true,
    max_distance = 30,
    screen_clamp = false,
    fade_settings = {
        default_fade = 1,
        fade_from = 0,
        fade_to = 1,
        distance_max = 30,
        distance_min = 15,
        easing_function = math.ease_exp,
    },
}
emoticon.create_widget_defintion = function(_template, scenegraph_id)
    return texture_widget(scenegraph_id)
end
emoticon.on_enter = function(widget, marker)
    marker.data = marker.data or {}
    marker.data.direction = math.clamp(math.random() - 0.5, -0.5, 0.5)
    apply_texture(widget, marker.data.url, "emoticon")
end
emoticon.on_exit = function() end
emoticon.update_function = function(_parent, _ui_renderer, widget, marker, _template, dt, _t)
    local data = marker.data
    apply_texture(widget, data.url, "emoticon")
    local style = widget.style.texture
    local duration = marker.duration or 0
    local full = mod:get("emoticon_size") or 250
    -- pop in over 0.3 s (easeOutCubic as Sprays), float up, drift, fade out over the last 0.5 s
    local p = math.clamp(math.easeOutCubic(math.min(duration / 0.3, 1)), 0, 1)
    -- shrink with distance, never below 35 %
    local distance = marker.distance or 5
    local distance_scale = math.clamp(6 / math.max(distance, 0.1), 0.35, 1)
    local size = math.lerp(10, full, p) * distance_scale
    style.size[1], style.size[2] = size, size
    style.offset[1] = style.offset[1] + data.direction * 40 * dt
    style.offset[2] = style.offset[2] - 60 * dt
    local fade = math.clamp((emoticon.life_time - duration) / 0.5, 0, 1)
    style.color[1] = 255 * fade
end

-- My own emoticon: a position marker moved every frame. In third person it sits above my head like everyone
-- else's; in first person the head is at the camera, so it is put 1.2 m in front of the camera instead.
-- Unit.has_node / node / world_position as hud_element_world_markers.lua:301-303; camera as Spray.aim.
local function self_anchor(unit)
    local player = Managers.player:local_player_safe(1)
    local camera_manager = Managers.state and Managers.state.camera
    local viewport = player and player.viewport_name
    local camera_position = viewport and camera_manager and camera_manager:camera_position(viewport)
    local head
    if unit and ALIVE[unit] then
        local node = Unit.has_node(unit, "j_head") and Unit.node(unit, "j_head") or 1
        head = Unit.world_position(unit, node) + Vector3(0, 0, 0.35)
    end
    if camera_position and (not head or Vector3.length(head - camera_position) < 0.8) then
        local rotation = camera_manager:camera_rotation(viewport)
        return camera_position + Quaternion.forward(rotation) * 1.2 + Quaternion.up(rotation) * 0.25
    end
    return head
end

local emoticon_self = table.clone(emoticon)
emoticon_self.name = "qiangiq_emoticon_self"
emoticon_self.unit_node = nil
emoticon_self.position_offset = nil
emoticon_self.check_line_of_sight = false
emoticon_self.update_function = function(parent, ui_renderer, widget, marker, template, dt, t)
    local position = self_anchor(marker.data.unit)
    if position and marker.world_position then
        Vector3Box.store(marker.world_position, position) -- as hud_element_world_markers.lua:330
    end
    marker.distance = math.max(marker.distance or 2, 2.5) -- keep it full size this close
    emoticon.update_function(parent, ui_renderer, widget, marker, template, dt, t)
end

-- Spray (marker style) -----------------------------------------------------------------------
local spray = {
    name = "qiangiq_spray",
    check_line_of_sight = true,
    max_distance = 40,
    screen_clamp = false,
}
spray.create_widget_defintion = function(_template, scenegraph_id)
    return texture_widget(scenegraph_id)
end
spray.on_enter = function(widget, marker)
    apply_texture(widget, marker.data.url, marker.data.user)
end
spray.on_exit = function() end
spray.update_function = function(_parent, ui_renderer, widget, marker)
    local data = marker.data
    apply_texture(widget, data.url, data.user)
    -- keep a world size: pixels = metres * screen height / (2 * distance * tan(fov/2)); fov taken as 60 degrees
    local distance = math.max(marker.distance or 5, 0.5)
    local height = RESOLUTION_LOOKUP.height * (ui_renderer.inverse_scale or 1)
    local px = (mod:get("spray_size") or 1) * height / (2 * distance * 0.577)
    local style = widget.style.texture
    style.size[1], style.size[2] = px, px
end

Markers.templates = { emoticon, emoticon_self, spray }
Markers.EMOTICON_SELF = emoticon_self.name
Markers.EMOTICON = emoticon.name
Markers.SPRAY = spray.name

-- HudElementWorldMarkers registers templates in init (Sprays.lua:9-11)
mod:hook_safe("HudElementWorldMarkers", "init", function(self)
    for i = 1, #Markers.templates do
        local template = Markers.templates[i]
        self._marker_templates[template.name] = template
    end
    Markers.hud = self
end)
mod:hook_safe("HudElementWorldMarkers", "destroy", function(self)
    if Markers.hud == self then
        Markers.hud = nil
    end
end)

-- the event would hit a nil template if the marker element was created before this mod hooked it
function Markers.ready()
    local hud = Markers.hud
    return hud ~= nil and hud._marker_templates ~= nil and hud._marker_templates[Markers.EMOTICON] ~= nil
end

function Markers.emoticon(unit, url, is_self)
    if not unit or not Markers.ready() then
        return
    end
    if is_self then
        local position = self_anchor(unit)
        if position then
            -- hud_element_world_markers.lua:50
            Managers.event:trigger("add_world_marker_position", Markers.EMOTICON_SELF, position, nil, { url = url, unit = unit })
        end
        return
    end
    -- event from Sprays.lua:31 / hud_element_world_markers.lua:49
    Managers.event:trigger("add_world_marker_unit", Markers.EMOTICON, unit, nil, { url = url })
end

-- returns the marker id through cb(id)
function Markers.spray(position, url, user, cb)
    if not Markers.ready() then
        return false
    end
    -- event from hud_element_world_markers.lua:50
    Managers.event:trigger("add_world_marker_position", Markers.SPRAY, position, cb, { url = url, user = user })
    return true
end

function Markers.remove(id)
    if id then
        Managers.event:trigger("remove_world_marker", id) -- hud_element_world_markers.lua:51
    end
end

return Markers
