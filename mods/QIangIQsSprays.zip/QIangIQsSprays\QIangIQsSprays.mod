return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsSprays` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsSprays", {
            mod_script = "QIangIQsSprays/scripts/mods/QIangIQsSprays/QIangIQsSprays",
            mod_data = "QIangIQsSprays/scripts/mods/QIangIQsSprays/QIangIQsSprays_data",
            mod_localization = "QIangIQsSprays/scripts/mods/QIangIQsSprays/QIangIQsSprays_localization",
        })
    end,
    version = "1.0.0",
    author = "QIangIQ",
    load_after = { "QIangIQsSyncChannel" },
    packages = {},
}
