local loc = {
    mod_name = { en = "QIangIQ's Sprays" },
    mod_description = {
        en = "Emoticons above your head and sprays on walls, from image links. Hold a wheel key to pick, or bind slots directly. "
            .. "Manage images with /spray (type /spray help). Other players see them when they run this mod and QIangIQ's Sync Channel. By QIangIQ.",
    },
    wheel_emoticon = { en = "Emoticon wheel (hold)" },
    wheel_emoticon_description = { en = "Hold to open the emoticon wheel, point at a slot and release to show it above your head." },
    wheel_spray = { en = "Spray wheel (hold)" },
    wheel_spray_description = { en = "Hold to open the spray wheel, point at a slot and release to spray the surface you aim at (within 5 m)." },
    group_emoticon_keys = { en = "Emoticon slot keys (optional)" },
    group_spray_keys = { en = "Spray slot keys (optional)" },
    group_options = { en = "Options" },
    share = { en = "Share with other players" },
    share_description = { en = "Send your emoticons and spray to other players through QIangIQ's Sync Channel." },
    show_others = { en = "Show other players' images" },
    show_others_description = {
        en = "Show other players' emoticons and sprays. Your PC downloads the image links they picked (only from allowed hosts, see /spray host).",
    },
    emoticon_size = { en = "Emoticon size (pixels)" },
    spray_style = { en = "Spray style" },
    spray_style_description = {
        en = "Wall: the image lies flat on the surface. Marker: the image floats at the spot and always faces you. Wall switches to Marker by itself if it fails.",
    },
    spray_style_wall = { en = "Wall" },
    spray_style_marker = { en = "Marker" },
    spray_size = { en = "Spray size (metres)" },
    spray_lifetime = { en = "Spray lifetime (minutes)" },
}

for kind, label in pairs({ emoticon = "Emoticon", spray = "Spray" }) do
    for i = 1, 8 do
        loc[kind .. "_slot_" .. i] = { en = label .. " slot " .. i }
    end
end

return loc
