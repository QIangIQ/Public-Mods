local mod = get_mod("QIangIQsSprays")

local function slot_keybinds(kind)
    local widgets = {}
    for i = 1, 8 do
        widgets[i] = {
            setting_id = kind .. "_slot_" .. i,
            type = "keybind",
            default_value = {},
            keybind_trigger = "pressed",
            keybind_type = "function_call",
            function_name = "kb_" .. kind .. "_" .. i,
        }
    end
    return widgets
end

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = true,
    options = {
        widgets = {
            {
                setting_id = "wheel_emoticon",
                type = "keybind",
                default_value = {},
                keybind_global = false,
                keybind_trigger = "held", -- as LookAround_data.lua freelook_held
                keybind_type = "function_call",
                function_name = "kb_wheel_emoticon",
            },
            {
                setting_id = "wheel_spray",
                type = "keybind",
                default_value = {},
                keybind_global = false,
                keybind_trigger = "held",
                keybind_type = "function_call",
                function_name = "kb_wheel_spray",
            },
            {
                setting_id = "group_emoticon_keys",
                type = "group",
                sub_widgets = slot_keybinds("emoticon"),
            },
            {
                setting_id = "group_spray_keys",
                type = "group",
                sub_widgets = slot_keybinds("spray"),
            },
            {
                setting_id = "group_options",
                type = "group",
                sub_widgets = {
                    {
                        setting_id = "share",
                        type = "checkbox",
                        default_value = true,
                    },
                    {
                        setting_id = "show_others",
                        type = "checkbox",
                        default_value = true,
                    },
                    {
                        setting_id = "emoticon_size",
                        type = "numeric",
                        default_value = 250,
                        range = { 100, 400 },
                    },
                    {
                        setting_id = "spray_style",
                        type = "dropdown",
                        default_value = "wall",
                        options = {
                            { text = "spray_style_wall", value = "wall" },
                            { text = "spray_style_marker", value = "marker" },
                        },
                    },
                    {
                        setting_id = "spray_size",
                        type = "numeric",
                        default_value = 1,
                        range = { 0.3, 3 },
                        decimals_number = 1,
                    },
                    {
                        setting_id = "spray_lifetime",
                        type = "numeric",
                        default_value = 5,
                        range = { 1, 30 },
                    },
                },
            },
        },
    },
}
