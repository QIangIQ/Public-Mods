-- QIangIQ's Heavy: swaps the local player's body for a Custom Assets unit
-- (third person, first-person arms, and menu / operative-select previews).
-- Author: QIangIQ
local mod = get_mod("QIangIQsHeavy")

-- Cross-client sync ---------------------------------------------------------------
-- QIangIQsModelSync publishes which QIangIQ replacer mods a player has on, with their options, through
-- Vox Manifold (the transport Dio's Wardrobe shares outfits with). No asset data is sent: every client shows
-- the model from its own installed files. While another player's unit is worked on, sync_ctx holds that
-- player's options and opt() answers from them; for my own unit opt() is mod:get().
local SYNC_KEY = "heavy"
local SYNC_BOOLS = { "model_enabled", "hide_body" }
local SYNC_DEFAULTS = { model_enabled = true, hide_body = true }
local SYNC_VALUES = {  }
local SYNC_LAYOUT = #SYNC_BOOLS * 100 + #SYNC_VALUES -- a peer on another version of this mod is not decoded
local sync_ctx = nil
local sync_known = setmetatable({}, { __mode = "k" })   -- other players' extensions this mod has shown something on
local sync_all = setmetatable({}, { __mode = "k" })     -- every visual loadout extension seen
local sync_decoded = setmetatable({}, { __mode = "k" }) -- published array -> options table
local SYNC_FALSE = { __index = function() return false end }
local SYNC_OFF = setmetatable({}, SYNC_FALSE)           -- "everything off": removes what was shown
local sync_extra_import = nil

local function opt(key)
    if sync_ctx then
        return sync_ctx[key]
    end
    return mod:get(key)
end

local function sync_api()
    local hub = get_mod("QIangIQsModelSync")
    return hub and hub.api
end

local function sync_me()
    local players = Managers.player
    if not players then
        return nil
    end
    local ok, player = pcall(players.local_player_safe, players, 1)
    return ok and player or nil
end

-- published array { layout, checkbox bits, value, value, ... [, extra] } -> options by setting id
local function sync_decode(raw)
    local t = sync_decoded[raw]
    if t ~= nil then
        return t
    end
    t = false
    if type(raw) == "table" and raw[1] == SYNC_LAYOUT then
        t = setmetatable({}, SYNC_FALSE)
        local mask = tonumber(raw[2]) or 0
        for i = 1, #SYNC_BOOLS do
            t[SYNC_BOOLS[i]] = mask % 2 >= 1
            mask = math.floor(mask / 2)
        end
        for i = 1, #SYNC_VALUES do
            local v = raw[2 + i]
            if v ~= nil then
                t[SYNC_VALUES[i]] = v
            end
        end
        if sync_extra_import then
            sync_extra_import(t, raw[3 + #SYNC_VALUES])
        end
    end
    sync_decoded[raw] = t
    return t
end

-- whose options apply to this extension: nil = mine, a table = that player's (SYNC_OFF when they publish
-- nothing for this mod)
local function sync_owner(ext)
    sync_all[ext] = true
    local player = ext._player
    if player == nil or player == sync_me() then
        return nil
    end
    local api = sync_api()
    local raw = api and api.peer(SYNC_KEY, player)
    local state = raw and sync_decode(raw)
    if state then
        sync_known[ext] = true
        return state
    end
    return SYNC_OFF
end

-- my own unit, or another player's unit this mod is (or was) showing something on
local function sync_shown(ext)
    local player = ext._player
    return player ~= nil and (player == sync_me() or sync_known[ext] == true)
end

local function sync_pack(...)
    return { n = select("#", ...), ... }
end

-- runs a hook body with the options of the extension's owner
local function sync_wrap(fn, ext_index)
    return function(...)
        local ext = select(ext_index, ...)
        local previous = sync_ctx
        sync_ctx = sync_owner(ext)
        local results = sync_pack(pcall(fn, ...))
        sync_ctx = previous
        if not results[1] then
            error(results[2], 0)
        end
        return unpack(results, 2, results.n)
    end
end

-- The same hook on my own unit's extension and on other players' (husk) extensions. While the mods load, the
-- classes do not exist yet: CLASS.<name> is then only the name and DMF delays the hook ("needs to be delayed"
-- in the log), so the husk class cannot be inspected here. Its methods are taken from
-- player_husk_visual_loadout_extension.lua instead.
local SYNC_HUSK_METHODS = { init = true, update = true, _update_item_visibility = true, destroy = true }

local function vl_hook_safe(method, fn)
    mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, method, sync_wrap(fn, 1))
    if SYNC_HUSK_METHODS[method] then
        mod:hook_safe(CLASS.PlayerHuskVisualLoadoutExtension, method, sync_wrap(fn, 1))
    end
end

local function vl_hook(method, fn)
    mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, method, sync_wrap(fn, 2))
    if SYNC_HUSK_METHODS[method] then
        mod:hook(CLASS.PlayerHuskVisualLoadoutExtension, method, sync_wrap(fn, 2))
    elseif method == "_unequip_item_from_slot" then
        -- a husk has no _unequip_item_from_slot: its unequip arrives as rpc_player_unequip_item_from_slot
        -- (self, channel_id, go_id, slot_id), slot name = NetworkLookup.player_inventory_slot_names[slot_id]
        -- (player_husk_visual_loadout_extension.lua)
        mod:hook(CLASS.PlayerHuskVisualLoadoutExtension, "rpc_player_unequip_item_from_slot", sync_wrap(function(func, self, channel_id, go_id, slot_id, ...)
            local NetworkLookup = require("scripts/network_lookup/network_lookup")
            local slot_name = NetworkLookup.player_inventory_slot_names[slot_id]
            return fn(function()
                return func(self, channel_id, go_id, slot_id)
            end, self, slot_name)
        end, 2))
    end
end
-- ----------------------------------------------------------------------------------

mod.AUTHOR = "QIangIQ"

local BODY_ID = "QIangIQsHeavy:heavy"                     -- <Mod>:<Custom folder>
local BODY_UNIT = "content/mods/qiangiq_heavy/heavy"              -- --asset-path used at compile time
local ARMS_ID = "QIangIQsHeavy:heavy_arms"
local ARMS_UNIT = "content/mods/qiangiq_heavy/heavy_arms"

-- QIangIQ character swap mods: only one model is shown at a time. Turning one on (option,
-- keybind or chat command) switches the others off through their saved "model_enabled" setting
-- (DMFMod:set / DMFMod:get, dmf/modules/core/settings.lua).
local CHARACTER_MODS = { "QIangIQsHeavy", "QIangIQsDvaMech", "QIangIQsRoadhog", "QIangIQsGrendelPrime", "QIangIQsOgbOgy" }

-- The model is fitted to the Ogryn skeleton and is shown on Ogryns only: every other breed, and a
-- character whose breed cannot be read, is left alone (it used to exclude only "human", so anything
-- else, or an unread breed, got the model). Breed name as in player_character_constants.lua.
local ALLOWED_BREED = "ogryn"

-- player_unit_visual_loadout_extension.lua:205-206 keeps the breed on the extension itself
-- (self._static_profile_properties.breed), so it is known even when this mod is loaded mid-game.
local function ext_breed(ext)
    local props = ext._static_profile_properties
    return (props and props.breed) or ext.__qiangiq_breed
end

local custom_assets = nil
local ready = { body = false, arms = false }
local function model_on()
    return opt("model_enabled") ~= false
end

-- extensions / UI spawners we have touched (weak keys)
local tracked = setmetatable({}, { __mode = "k" })
local tracked_ui = setmetatable({}, { __mode = "k" })

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function local_player()
    local players = Managers.player
    if not players then
        return nil
    end
    local ok, player = pcall(players.local_player_safe, players, 1)
    return ok and player or nil
end

-- slot_body_* / slot_gear_* hold the body parts and cosmetics; weapons live in other slots
local function hide_body_slots(slots, key)
    if not slots then
        return
    end
    local attachments_key = key == "unit_1p" and "attachments_by_unit_1p" or "attachments_by_unit_3p"
    for slot_name, slot in pairs(slots) do
        if string.find(slot_name, "^slot_body_") or string.find(slot_name, "^slot_gear_") then
            local unit = slot[key]
            if unit_ok(unit) then
                Unit.set_unit_visibility(unit, false, true)
                local attachments = slot[attachments_key] and slot[attachments_key][unit]
                if attachments then
                    for i = 1, #attachments do
                        if unit_ok(attachments[i]) then
                            Unit.set_unit_visibility(attachments[i], false, true)
                        end
                    end
                end
            end
        end
    end
end

-- In-game player unit -----------------------------------------------------------

local function is_local_human(ext)
    return sync_shown(ext)
end

local function delete_unit(unit)
    if unit_ok(unit) then
        local unit_spawner = Managers.state and Managers.state.unit_spawner
        if unit_spawner then
            unit_spawner:mark_for_deletion(unit)
        end
    end
end

local function despawn(ext)
    delete_unit(ext.__qiangiq_heavy_unit)
    delete_unit(ext.__qiangiq_heavy_arms)
    ext.__qiangiq_heavy_unit = nil
    ext.__qiangiq_heavy_arms = nil
end

-- same spawn + link pattern the game uses for gear (visual_loadout_customization.lua)
local function spawn_linked(world, parent, unit_name, is_first_person)
    local unit_spawner = Managers.state and Managers.state.unit_spawner
    if not (world and unit_spawner and unit_ok(parent)) then
        return nil
    end
    local unit = unit_spawner:spawn_unit(unit_name, Unit.world_pose(parent, 1))
    if not unit then
        return nil
    end
    if is_first_person then
        Unit.set_unit_culling(unit, false)
    end
    World.link_unit(world, unit, 1, parent, 1, World.LINK_MODE_NODE_NAME)
    return unit
end

-- Glow slider (models built with the PBR emissive material only). The compiled material has a
-- scalar variable "intensity" (compiler: pbr_emissive_profile.cpp, id32 0x32f447e5 = "intensity");
-- set the same way the game applies scalar material overrides
-- (visual_loadout_customization.lua:516, Unit.set_scalar_for_materials(unit, name, value, true)).
local HAS_GLOW = false

local function apply_glow(unit)
    if HAS_GLOW and unit_ok(unit) then
        Unit.set_scalar_for_materials(unit, "intensity", opt("glow_brightness") or 1, true)
    end
end

local function apply(ext, first_person_mode)
    if not model_on() then
        despawn(ext)
        return
    end
    local world = ext.__qiangiq_world

    if ready.body and not unit_ok(ext.__qiangiq_heavy_unit) then
        ext.__qiangiq_heavy_unit = spawn_linked(world, ext._unit, BODY_UNIT, false)
    end
    if ready.arms and opt("first_person_arms") and not unit_ok(ext.__qiangiq_heavy_arms) then
        ext.__qiangiq_heavy_arms = spawn_linked(world, ext._first_person_unit, ARMS_UNIT, true)
    elseif not opt("first_person_arms") and ext.__qiangiq_heavy_arms then
        delete_unit(ext.__qiangiq_heavy_arms)
        ext.__qiangiq_heavy_arms = nil
    end

    local body = ext.__qiangiq_heavy_unit
    local arms = ext.__qiangiq_heavy_arms
    apply_glow(body)
    apply_glow(arms)
    if unit_ok(body) then
        Unit.set_unit_visibility(body, not first_person_mode, true)
    end
    if unit_ok(arms) then
        Unit.set_unit_visibility(arms, first_person_mode and true or false, true)
    end

    if opt("hide_body") then
        if not first_person_mode and unit_ok(body) then
            hide_body_slots(ext._equipment, "unit_3p")
        elseif first_person_mode and unit_ok(arms) then
            hide_body_slots(ext._equipment, "unit_1p")
        end
    end
end

-- Menu previews (operative select, inventory, lobby) --------------------------

local function ui_profile_is_mine(profile)
    -- __qiangiq_npc: the companion NPC spawned by QIangIQsCompanionSwap is nobody's character
    if not profile or profile.__qiangiq_npc then
        return false
    end
    -- skip previews of characters that belong to someone else (other players, bots)
    local players = Managers.player and Managers.player:players()
    local me = local_player()
    if players and profile.character_id then
        for _, player in pairs(players) do
            if player ~= me and player.character_id and player:character_id() == profile.character_id then
                return false
            end
        end
    end
    return true
end

local function ui_despawn(spawner)
    local unit = spawner.__qiangiq_heavy_unit
    spawner.__qiangiq_heavy_unit = nil
    spawner.__qiangiq_heavy_parent = nil
    if unit_ok(unit) and spawner._world then
        -- same call ui_profile_spawner.lua uses for its own character unit
        World.destroy_unit(spawner._world, unit)
    end
end

local function ui_apply(spawner)
    local data = spawner._character_spawn_data
    if not data or not unit_ok(data.unit_3p) then
        return
    end
    -- ui_profile_spawner.lua:179-180 reads profile.archetype.breed
    local archetype = data.profile and data.profile.archetype
    local excluded = not (archetype and archetype.breed == ALLOWED_BREED)
    if excluded or not (model_on() and opt("menu_previews") and ready.body and ui_profile_is_mine(data.profile)) then
        if spawner.__qiangiq_heavy_unit then
            ui_despawn(spawner)
            if spawner._visible then
                spawner:_update_items_visibility()
            end
        end
        return
    end
    if spawner.__qiangiq_heavy_parent ~= data.unit_3p then
        ui_despawn(spawner)
    end
    local unit = spawner.__qiangiq_heavy_unit
    if not unit_ok(unit) then
        local world = spawner._world
        unit = World.spawn_unit_ex(world, BODY_UNIT, nil, Unit.world_pose(data.unit_3p, 1))
        World.link_unit(world, unit, 1, data.unit_3p, 1, World.LINK_MODE_NODE_NAME)
        spawner.__qiangiq_heavy_unit = unit
        spawner.__qiangiq_heavy_parent = data.unit_3p
        tracked_ui[spawner] = true
    end
    apply_glow(unit)
    Unit.set_unit_visibility(unit, spawner._visible and true or false, true)
    if spawner._visible and opt("hide_body") then
        hide_body_slots(data.slots, "unit_3p")
    end
end

-- Hooks ----------------------------------------------------------------------

vl_hook_safe("init", function(self, extension_init_context, unit, extension_init_data)
    self.__qiangiq_world = extension_init_context and extension_init_context.world
    -- player_unit_visual_loadout_extension.lua:81 reads extension_init_data.archetype.breed
    local archetype = extension_init_data and extension_init_data.archetype
    self.__qiangiq_breed = archetype and archetype.breed
end)

vl_hook_safe("_update_item_visibility", function(self, first_person_mode)
    if not is_local_human(self) then
        return
    end
    if ext_breed(self) ~= ALLOWED_BREED then
        if self.__qiangiq_heavy_unit or self.__qiangiq_heavy_arms then
            despawn(self)
        end
        return
    end
    tracked[self] = true
    apply(self, first_person_mode)
end)

vl_hook("destroy", function(func, self, ...)
    despawn(self)
    tracked[self] = nil
    return func(self, ...)
end)

mod:hook_safe(CLASS.UIProfileSpawner, "_update_items_visibility", function(self)
    ui_apply(self)
end)

mod:hook_safe(CLASS.UIProfileSpawner, "update", function(self)
    local data = self._character_spawn_data
    if data and data.is_ready then
        ui_apply(self)
    end
end)

mod:hook(CLASS.UIProfileSpawner, "_despawn_current_character_profile", function(func, self, ...)
    ui_despawn(self)
    return func(self, ...)
end)

-- Package loading through Custom Assets --------------------------------------

local function refresh_all()
    for ext in pairs(tracked) do
        if unit_ok(ext._unit) then
            if not model_on() then
                despawn(ext)
            end
            ext:force_update_item_visibility()
        end
    end
    for spawner in pairs(tracked_ui) do
        ui_apply(spawner)
    end
end

local function acquire(key, asset_id)
    local ticket, err = custom_assets.acquire(mod, asset_id, function(_, _, load_error)
        if load_error then
            mod:error("%s failed to load: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", asset_id, tostring(load_error))
            return
        end
        ready[key] = true
        refresh_all()
    end, { resident = true, reference_name = asset_id })
    if not ticket then
        mod:error("%s could not be requested: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", asset_id, tostring(err))
    end
end

-- Two models of the same group saved "on" (e.g. a newly installed mod, which defaults to on):
-- the later one in CHARACTER_MODS keeps it.
local function resolve_at_load()
    local mine = false
    for _, name in ipairs(CHARACTER_MODS) do
        if name == "QIangIQsHeavy" then
            mine = true
        elseif mine then
            local other = get_mod(name)
            if other and other:get("model_enabled") ~= false and model_on() then
                mod:set("model_enabled", false, false)
            end
        end
    end
end

mod.on_all_mods_loaded = function()
    resolve_at_load()
    custom_assets = get_mod("CustomAssets")
    if not custom_assets or not custom_assets.is_api_compatible or not custom_assets.is_api_compatible(1) then
        mod:error("Custom Assets (API 1) is missing. Install it and put it above QIangIQsHeavy in mod_load_order.txt.")
        return
    end
    acquire("body", BODY_ID)
    acquire("arms", ARMS_ID)
end

local function switch_others_off()
    for _, name in ipairs(CHARACTER_MODS) do
        if name ~= "QIangIQsHeavy" then
            local other = get_mod(name)
            if other and other:get("model_enabled") ~= false then
                other:set("model_enabled", false, true)
            end
        end
    end
end

mod.toggle_model = function()
    local on = not model_on()
    mod:set("model_enabled", on, true)
    mod:echo("Heavy model %s", on and "on" or "off")
end

mod:command("heavy", "Toggle the Heavy model on your character", function()
    mod.toggle_model()
end)

mod.on_setting_changed = function(setting_id)
    if setting_id == "model_enabled" and model_on() then
        switch_others_off()
    end
    refresh_all()
end

mod.on_disabled = function()
    for ext in pairs(tracked) do
        despawn(ext)
        -- hooks are off now, so this restores the normal body/gear visibility
        if unit_ok(ext._unit) then
            ext:force_update_item_visibility()
        end
    end
    for spawner in pairs(tracked_ui) do
        ui_despawn(spawner)
        if spawner._character_spawn_data and spawner._visible then
            spawner:_update_items_visibility()
        end
    end
end

mod.on_enabled = function()
    refresh_all()
end

mod.on_unload = function()
    for ext in pairs(tracked) do
        despawn(ext)
    end
    for spawner in pairs(tracked_ui) do
        ui_despawn(spawner)
    end
    if custom_assets and custom_assets.release_owner then
        custom_assets.release_owner(mod)
    end
end


-- Cross-client sync: what this mod publishes about me, and the refresh when anyone's options change ---------
local function sync_applies(info)
    return model_on() and (info.breed == nil or info.breed == ALLOWED_BREED)
end

local sync_enabled = true
local function sync_changed()
    local api = sync_api()
    if api then
        api.changed()
    end
end

mod.sync_key = SYNC_KEY
-- info = { breed, companion_breed, templates = { [weapon_template] = true } } of my own character (fields nil
-- while I have no unit). Returns the array to publish, or nil when this mod shows nothing on my character.
mod.sync_export = function(info)
    info = info or {}
    if not sync_enabled or not sync_applies(info) then
        return nil
    end
    local mask, bit = 0, 1
    for i = 1, #SYNC_BOOLS do
        local key = SYNC_BOOLS[i]
        local v = mod:get(key)
        if v == nil then
            v = SYNC_DEFAULTS[key]
        end
        if v then
            mask = mask + bit
        end
        bit = bit * 2
    end
    local out = { SYNC_LAYOUT, mask }
    for i = 1, #SYNC_VALUES do
        local v = mod:get(SYNC_VALUES[i])
        if type(v) == "number" then
            v = math.floor(v * 100 + 0.5) / 100
        elseif type(v) ~= "string" then
            v = false -- not set: the reader falls back to its default
        end
        out[2 + i] = v
    end
    return out
end

mod.sync_refresh = function()
    for ext in pairs(sync_all) do
        if ext._unit and Unit.alive(ext._unit) and ext.force_update_item_visibility then
            pcall(ext.force_update_item_visibility, ext)
        end
    end
end

local sync_prev_setting_changed = mod.on_setting_changed
mod.on_setting_changed = function(...)
    if sync_prev_setting_changed then
        sync_prev_setting_changed(...)
    end
    sync_changed()
end

local sync_prev_disabled = mod.on_disabled
mod.on_disabled = function(...)
    sync_enabled = false
    if sync_prev_disabled then
        sync_prev_disabled(...)
    end
    sync_changed()
end

local sync_prev_enabled = mod.on_enabled
mod.on_enabled = function(...)
    sync_enabled = true
    if sync_prev_enabled then
        sync_prev_enabled(...)
    end
    sync_changed()
end
