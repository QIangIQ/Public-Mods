return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsHeavy` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsHeavy", {
            mod_script = "QIangIQsHeavy/scripts/mods/QIangIQsHeavy/QIangIQsHeavy",
            mod_data = "QIangIQsHeavy/scripts/mods/QIangIQsHeavy/QIangIQsHeavy_data",
            mod_localization = "QIangIQsHeavy/scripts/mods/QIangIQsHeavy/QIangIQsHeavy_localization",
        })
    end,
    version = "1.3.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
