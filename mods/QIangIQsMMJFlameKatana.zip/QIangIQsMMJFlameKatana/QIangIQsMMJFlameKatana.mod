return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsMMJFlameKatana` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsMMJFlameKatana", {
            mod_script = "QIangIQsMMJFlameKatana/scripts/mods/QIangIQsMMJFlameKatana/QIangIQsMMJFlameKatana",
            mod_data = "QIangIQsMMJFlameKatana/scripts/mods/QIangIQsMMJFlameKatana/QIangIQsMMJFlameKatana_data",
            mod_localization = "QIangIQsMMJFlameKatana/scripts/mods/QIangIQsMMJFlameKatana/QIangIQsMMJFlameKatana_localization",
        })
    end,
    version = "0.1.0",
    author = "QIangIQ",
    packages = {},
}
