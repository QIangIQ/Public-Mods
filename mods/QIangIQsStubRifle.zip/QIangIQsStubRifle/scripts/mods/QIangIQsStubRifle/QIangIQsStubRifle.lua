-- QIangIQ's Stub Rifle 0.2.2: the unreleased stub rifle (stubrifle_p1_m1) as a weapon.
--
-- What is datamined (A:\Dowloads\Darktide_NonMod\unreleased_sweep_oct25 index.tsv / assets\weapon__stubgun_rifle_*.txt,
-- build 139617; node names by id32 match, work folder export_probe.txt):
--   * content/weapons/player/ranged/stubgun_rifle/wpn_stubgun_rifle_chained_rig: root rp_stubgun_rifle_chained_rig,
--     ap_trigger_01, ap_sight_01, ap_bullet_01, ap_recharge_01, ap_safety_01. Its only strings are "item" and
--     content/items/weapons/player/ranged/stubrifle_p1_m1, so that is the item / template name.
--   * attachments receiver_01 (ap_barrel_01, ap_sight_01, ap_stock_01, ap_grip_01, ap_bullet_01, emblems; skinned, own
--     state machine + idle clip), barrel_01 (ap_muzzle_01 at y 0.47, fx_muzzle_01, ap_flashlight_01, ap_trinket; skinned,
--     own state machine), muzzle_01, sight_01, stock_01. No magazine: it is loaded round by round.
--   * HUD icon content/ui/materials/icons/weapons/hud/stubrifle_p1_m1 (material + package).
--   * First-person state machine content/characters/player/human/first_person/animations/stubgun_rifle (de998d93fa158854)
--     with 73 clips: shoot (+vars), ironsight_*, reload_start / reload_loop_one / reload_loop_two / reload_end, equip,
--     equip_fast, idle, sprint, slide, dodge, hit stun. The game already lists it in state_machine_ranged_first_person.lua:60.
--     Its anim events (sm_events.txt) are a subset of the released lasgun_rifle_elysian set; it has reload_start /
--     reload_middle / reload_end, attack_shoot, equip, equip_reload, to_ironsight / to_unaim_ironsight, inspect_start.
--   * Firing sound: player_character_sound_event_aliases.lua:4221 ranged_single_shot.stubrifle_p1_m1 =
--     wwise/events/weapon/play_stubrifle_p1_m1, and that event (+ _husk) is in the game files (index.tsv 9b47f1a237a75c8e).
--   * NOT in the files: weapon template, master item, third-person animations, damage numbers.
--
-- How it is built (user choice 2026-10-30: "Shotgun reload, one bullet"; QIangIQsChainsword2h / QIangIQsMeltagun pattern):
--   * Template stubrifle_p1_m1 = clone of shotgun_p1_m1 (Combat Shotgun): its one-round-at-a-time reload
--     (action_start_reload / action_reload_loop, events reload_start / reload_middle / reload_end) fits the stub rifle's
--     reload clips. Its three shoot actions fire one Headhunter bullet instead of pellets: kind and fire_configuration
--     come from autogun_p2_m1's action_shoot_hip / action_shoot_zoomed (hit_scan_template autogun_p2_m1_bullet, damage
--     type auto_bullet), so the numbers are the Headhunter's, read from the game at runtime, not made up here.
--     Spread, recoil and ammo stay the Combat Shotgun's.
--   * Anim events the stub rifle set lacks: attack_shoot_semi (-> attack_shoot in 1p, the shotgun's own in 3p),
--     equip_fast (-> equip in 1p), load_special (the special shell load is removed: no clip for it). Any other missing
--     1p event is skipped instead of reaching Unit.animation_event (QIangIQsFlamerPistol guard).
--   * Third person keeps the Combat Shotgun's shotgun_rifle state machine: the game has no stub rifle 3p set, so there is
--     nothing of its own to use there.
--   * The template name is the game's, so ranged_single_shot already resolves to play_stubrifle_p1_m1: the real stub
--     rifle shot sound with no swap.
--   * fx sources: _muzzle fx_muzzle_01 (barrel), _eject ap_bullet_01 (chamber; the stub rifle has no fx_eject node).
--   * Item = clone of the shotgun_p1_m1 master item (http_cache.db build 139617) with base_unit = the stub rifle rig and
--     the tree receiver (rig root) -> barrel -> muzzle, receiver -> sight, receiver -> stock. The rig is the one its own
--     animation set is made for, so no grip offset.
--   * Standalone: needs no other mod.
--
-- 0.2.0 tuning (user 2026-10-31: "limited firerate, 5 round mag, 100% armorpen efficency (bascially ignore carapace),
-- enough dmg to 1 shot reaper at havoc 40 at 40m"). Every number is from the game source (Aussiemon master):
--   * Magazine: 5 rounds. The ammo template keeps the Combat Shotgun's name (weapon_tweak_templates.ammo_template_name is a
--     networked lookup, a new name would move ids; lesson-weapon-action-lookup-shift); only this weapon's built copy of it
--     gets ammunition_clips = { 5 } (WeaponTweakTemplates.create hook). Reserve stays the shotgun's (70-95).
--   * Fire rate: one shot per "shot_interval" seconds (default 1.0; the shoot clip pushes the bolt home at 0.8 s). Every shoot
--     action gets an action_condition_func that refuses a new shot until then; the last shot time is taken from
--     ActionHandler.start_action on the fixed-frame time, so host and client agree. Zoom/unzoom cannot skip it.
--   * Armour: armor_damage_modifier_ranged near and far, attack and impact, = 1 for every armour type (Carapace, Flak,
--     Unyielding, Maniac, Infested, void shield): damage_calculation.lua then gives full damage ("full" efficiency).
--   * Damage: power_distribution.attack = "shot_damage" (default 16500). At the player power level 500
--     (action_shoot.lua DEFAULT_POWER_LEVEL, power_level_settings.lua) the base damage equals this number. No range drop-off:
--     the same number near and far, so 40 m is the same as 1 m. Reaper (chaos_ogryn_gunner) at Havoc 40:
--       health 2000 x 2 (_elite_health_steps, Havoc is challenge 5) x 1.5 (Havoc buff_elites modify_elite_health 0.5) = 6000;
--       Tougher Skin (havoc_toughened_skin) ranged_damage_taken_multiplier = 0.1 + 0.01 x rank = 0.5 at rank 40;
--       Bolstering (havoc_bolstering, elites -0.05 a stack, 5 stacks) armour damage x 0.75.
--       Worst case 6000 / (0.5 x 0.75) = 16000; 16500 leaves 3 %. Reapers have no hit zone multipliers, so any hit kills.
--     The damage profile keeps the Headhunter's name autogun_p2_m1 (damage profile names are networked too).
--   * Ability equip guard (QIangIQsStubRifle_guard.lua) against the 2026-10-31 "Unit not found" grenade crash.
-- Author: QIangIQ
local mod = get_mod("QIangIQsStubRifle")

local WeaponTemplates = require("scripts/settings/equipment/weapon_templates/weapon_templates")
local MasterItems = require("scripts/backend/master_items")
local NetworkLookup = require("scripts/network_lookup/network_lookup")
local ArmorSettings = require("scripts/settings/damage/armor_settings")
local WeaponTweakTemplates = require("scripts/extension_systems/weapon/utilities/weapon_tweak_templates")
local WeaponTweakTemplateSettings = require("scripts/settings/equipment/weapon_templates/weapon_tweak_template_settings")
local Guard = mod:io_dofile("QIangIQsStubRifle/scripts/mods/QIangIQsStubRifle/QIangIQsStubRifle_guard")

local STUB = "content/weapons/player/ranged/stubgun_rifle/"
local RIG = STUB .. "wpn_stubgun_rifle_chained_rig"
local RIG_NODE = "rp_stubgun_rifle_chained_rig"
local PARTS = {
    receiver = { unit = STUB .. "attachments/receiver_01/receiver_01", node = RIG_NODE },
    barrel = { unit = STUB .. "attachments/barrel_01/barrel_01", node = "ap_barrel_01" },
    muzzle = { unit = STUB .. "attachments/muzzle_01/muzzle_01", node = "ap_muzzle_01" },
    sight = { unit = STUB .. "attachments/sight_01/sight_01", node = "ap_sight_01" },
    stock = { unit = STUB .. "attachments/stock_01/stock_01", node = "ap_stock_01" },
}
local ITEM_ROOT = "content/items/weapons/player/ranged/"
local PART_ROOT = ITEM_ROOT .. "qiangiq_stubrifle/"
local HUD_ICON = "content/ui/materials/icons/weapons/hud/stubrifle_p1_m1"
local SM_1P = "content/characters/player/human/first_person/animations/stubgun_rifle"
local DONOR = "shotgun_p1_m1"
local BULLET_DONOR = "autogun_p2_m1"
local ARCHETYPES = { "zealot", "veteran", "psyker", "adamant" }

local MARK = {
    template = "stubrifle_p1_m1",
    item = ITEM_ROOT .. "stubrifle_p1_m1",
    display = "loc_qiangiq_stubrifle_p1_m1",
}

-- shoot action -> the Headhunter action whose bullet it fires
local SHOTS = {
    action_shoot_hip = "action_shoot_hip",
    action_shoot_hip_from_reload = "action_shoot_hip",
    action_shoot_zoomed = "action_shoot_zoomed",
}
local MAGAZINE = 5
local SHOT_MARK = "qiangiq_stubrifle_shot"

mod:add_global_localize_strings({
    loc_qiangiq_stubrifle_family = { en = "Stub Rifle (datamined)" },
    loc_qiangiq_stubrifle_p1_m1 = { en = "Stub Rifle (datamined)" },
    loc_qiangiq_stubrifle_desc = {
        en = "The unreleased stub rifle found in the game files. Reloads one round at a time; 5 rounds, one heavy armour-piercing bullet a second.",
    },
})

local function say(fmt, ...)
    local text = string.format(fmt, ...)

    mod:echo(text)
    mod:info(text)
end

local function debug(fmt, ...)
    if mod:get("debug") then
        mod:info(fmt, ...)
    end
end

-- Network lookups (QIangIQsShardStaff append_lookup): new names go at the end so no existing id moves -------------
local function append_lookup(lookup_name, key)
    local lookup = NetworkLookup[lookup_name]

    if not lookup then
        return false, "no lookup"
    end

    local existing = rawget(lookup, key)

    if existing then
        return true, existing
    end

    local index = #lookup + 1

    rawset(lookup, index, key)
    rawset(lookup, key, index)

    return true, index
end

-- Particle / sound aliases keyed by wielded_weapon_template (QIangIQsShardStaff alias_template_keys). Keys the game
-- already has for stubrifle_p1_m1 (ranged_single_shot) are kept.
local ALIAS_MODULES = {
    "scripts/settings/particles/player_character_particle_aliases",
    "scripts/settings/sound/player_character_sound_event_aliases",
}

local function alias_keys(root, source, target, seen, counter)
    if type(root) ~= "table" or seen[root] then
        return
    end

    seen[root] = true

    local value = rawget(root, source)

    if value ~= nil and rawget(root, target) == nil then
        root[target] = value
        counter.n = counter.n + 1
    end

    for _, child in pairs(root) do
        if type(child) == "table" then
            alias_keys(child, source, target, seen, counter)
        end
    end
end

local function copy_aliases(source, target)
    local counter = { n = 0 }

    for _, path in ipairs(ALIAS_MODULES) do
        local ok, module = pcall(require, path)

        if ok then
            alias_keys(module, source, target, {}, counter)
        else
            mod:error("alias module %s: %s", path, tostring(module))
        end
    end

    return counter.n
end

local function package_found(path)
    local ok, exists = pcall(Application.can_get_resource, "package", path)

    return ok and exists and true or false
end

-- Template ------------------------------------------------------------------------------------------------------------
local function drop_special(clone)
    clone.actions.action_weapon_special = nil

    for _, action in pairs(clone.actions) do
        local chains = type(action) == "table" and action.allowed_chain_actions

        if chains then
            chains.special_action = nil
        end
    end

    clone.weapon_special_tweak_data = nil
end

-- every armour type at full damage, near and far, attack and impact
local function full_armor()
    local values = {}

    for _, armor_type in pairs(ArmorSettings.types) do
        values[armor_type] = 1
    end

    return values
end

local function stub_damage_profile(profile)
    profile.armor_damage_modifier_ranged = {
        near = { attack = full_armor(), impact = full_armor() },
        far = { attack = full_armor(), impact = full_armor() },
    }
    profile.armor_damage_modifier = { attack = full_armor(), impact = full_armor() }
    profile.power_distribution_ranged = nil
    profile.power_distribution = profile.power_distribution or {}
    profile.power_distribution.attack = mod:get("shot_damage") or 16500

    -- per-target settings would win over the profile's own (damage_profile.lua armor_damage_modifier)
    for _, target in pairs(profile.targets or {}) do
        if type(target) == "table" then
            target.armor_damage_modifier = nil
            target.armor_damage_modifier_ranged = nil
            target.power_distribution = nil
            target.power_distribution_ranged = nil
        end
    end
end

-- one shot per shot_interval: refused by the action condition until the time has passed
local last_shot = setmetatable({}, { __mode = "k" })

local function gate_shot(action)
    local inner = action.action_condition_func

    action[SHOT_MARK] = true
    action.action_condition_func = function(action_settings, condition_func_params, used_input, t, time_in_action)
        local last = condition_func_params and last_shot[condition_func_params]

        if last and t and t - last < (mod:get("shot_interval") or 1) then
            return false
        end

        return inner == nil or inner(action_settings, condition_func_params, used_input, t, time_in_action)
    end
end

-- 0.2.2 (user 2026-11-01: "after 5th round reload stub is stuck like this until swapping of and on again"): the Combat
-- Shotgun sends reload_end only when a reload is interrupted (anim_end_event_condition_func refuses "action_complete"),
-- because its own 1p reload state leaves by itself. The stub rifle's reload_loop states wait for reload_end, so a reload
-- that finishes the magazine left the rifle lowered. Its reload actions now also send reload_end when they complete with
-- the magazine full or the reserve empty, the two cases where no further reload follows.
local function reload_done(condition_func_params)
    local slot = condition_func_params and condition_func_params.inventory_slot_component

    if not slot then
        return false
    end

    local Ammo = require("scripts/utilities/ammo") -- at run time only: it reads NetworkConstants (lesson-require-action-handler-at-mod-load)

    return Ammo.current_ammo_in_clips(slot) >= Ammo.max_ammo_in_clips(slot) or (slot.current_ammunition_reserve or 0) <= 0
end

local function reload_end_when_done(clone)
    for _, action_name in ipairs({ "action_start_reload", "action_reload_loop" }) do
        local action = clone.actions[action_name]

        if action and action.anim_end_event then
            local end_event = action.anim_end_event

            action.anim_end_event_condition_func = nil
            action.anim_end_event_func = function(time_in_action, action_settings, end_reason, condition_func_params)
                if end_reason == "new_interrupting_action" then
                    return nil
                end

                if end_reason == "action_complete" and not reload_done(condition_func_params) then
                    return nil
                end

                return end_event
            end
        end
    end
end

local function bullet_actions(clone, notes)
    local donor = WeaponTemplates[BULLET_DONOR]

    if not donor then
        notes[#notes + 1] = "no " .. BULLET_DONOR
        return false
    end

    for action_name, donor_action_name in pairs(SHOTS) do
        local action = clone.actions[action_name]
        local donor_action = donor.actions[donor_action_name] or donor.actions.action_shoot_hip

        if action and donor_action and donor_action.fire_configuration then
            local fire = table.clone(donor_action.fire_configuration)

            local profile = fire.hit_scan_template and fire.hit_scan_template.damage and fire.hit_scan_template.damage.impact
                and fire.hit_scan_template.damage.impact.damage_profile

            if profile then
                stub_damage_profile(profile)
            else
                notes[#notes + 1] = "no damage profile for " .. action_name
            end

            fire.anim_event = "attack_shoot"
            fire.anim_event_3p = action.fire_configuration and action.fire_configuration.anim_event or "attack_shoot_semi"
            action.kind = donor_action.kind
            action.fire_configuration = fire
            gate_shot(action)

            local fx = table.clone(action.fx or {})
            local donor_fx = donor_action.fx or {}

            fx.line_effect = donor_fx.line_effect
            fx.muzzle_flash_effect = donor_fx.muzzle_flash_effect
            fx.muzzle_flash_crit_effect = donor_fx.muzzle_flash_crit_effect
            fx.shell_casing_effect = donor_fx.shell_casing_effect
            action.fx = fx
        else
            notes[#notes + 1] = "no bullet for " .. action_name
        end
    end

    -- dot / assault crosshair of the Headhunter instead of the pellet circle
    clone.crosshair = donor.crosshair and table.clone(donor.crosshair) or clone.crosshair

    return true
end

local function ensure_template()
    if rawget(WeaponTemplates, MARK.template) then
        MARK.template_ok = true
        MARK.official_template = not MARK.template_ours

        return true
    end

    local donor = WeaponTemplates[DONOR]

    if not donor or not WeaponTemplates[BULLET_DONOR] then
        return false
    end

    local clone = table.clone(donor)
    local notes = {}

    clone.name = MARK.template

    for action_name, action_settings in pairs(clone.actions) do
        action_settings.name = action_name
    end

    drop_special(clone)
    reload_end_when_done(clone)
    bullet_actions(clone, notes)

    local wield = clone.actions.action_wield

    if wield then
        wield.wield_anim_event_3p = wield.wield_anim_event
        wield.wield_anim_event = "equip"
    end

    clone.fx_sources = { _muzzle = "fx_muzzle_01", _eject = "ap_bullet_01" }
    clone.keywords = { "ranged", "stubgun_rifle", "p1" }

    if mod:get("own_animations") ~= false and package_found(SM_1P) then
        -- player_unit_animation_state.lua:112 needs a settings entry (QIangIQsMeltagun 0.2.2); the game has one already
        local SMSettings = require("scripts/settings/animation/player_unit_animation_state_machine_settings")

        if not SMSettings[SM_1P] then
            SMSettings[SM_1P] = table.clone(SMSettings[clone.anim_state_machine_1p] or { blend_time = 0 })
        end

        clone.anim_state_machine_1p = SM_1P
        MARK.own_sm = true
    else
        notes[#notes + 1] = "stub rifle 1p set not used"
    end

    WeaponTemplates[MARK.template] = clone
    MARK.template_ours = true
    MARK.notes = notes

    local ok, index = append_lookup("weapon_templates", MARK.template)

    MARK.template_id = ok and index or nil
    MARK.aliases = copy_aliases(DONOR, MARK.template)
    MARK.template_ok = ok

    return ok
end

-- Items ---------------------------------------------------------------------------------------------------------------
local function find_item(cache, preferred, template)
    local direct = rawget(cache, preferred)

    if direct and direct.weapon_template == template then
        return preferred, direct
    end

    for name, item in pairs(cache) do
        if type(item) == "table" and item.weapon_template == template then
            return name, item
        end
    end
end

-- Only base_unit is kept: Items.base_unit can also read per-breed / first-person variants of the source part
local function only_base_unit(item, unit)
    for key in pairs(item) do
        if type(key) == "string" and key ~= "base_unit" and key:find("^base_unit") then
            item[key] = nil
        end
    end

    item.base_unit = unit
end

local function make_part(cache, name, template_item, unit, attach_node)
    local item = table.clone(template_item)

    only_base_unit(item, unit)
    item.name = name
    item.resource_dependencies = { [unit] = true }
    item.attachments = nil
    item.material_overrides = nil
    item.material_override_items = nil
    item.attach_node = attach_node
    cache[name] = item

    return name
end

-- a tree node with the donor node's flags (leaf_attach_node_override, link_map_mode_override, material fields)
local function fresh_node(node, item_name)
    local out = {}

    for key, value in pairs(node) do
        if key ~= "children" and key ~= "item" then
            out[key] = type(value) == "table" and table.clone(value) or value
        end
    end

    out.item = item_name
    out.children = {}

    return out
end

local function dump_tree(tree, prefix, out)
    for slot_name, node in pairs(tree) do
        if type(node) == "table" then
            local path = prefix .. slot_name

            out[#out + 1] = string.format("%s=%s", path, tostring(node.item))

            if type(node.children) == "table" then
                dump_tree(node.children, path .. "/", out)
            end
        end
    end

    return out
end

local function archetypes_of(source_item)
    local archetypes, seen = {}, {}

    for _, archetype in ipairs(source_item.archetypes or {}) do
        archetypes[#archetypes + 1] = archetype
        seen[archetype] = true
    end

    for _, archetype in ipairs(ARCHETYPES) do
        if mod:get("unlock_" .. archetype) and not seen[archetype] then
            archetypes[#archetypes + 1] = archetype
            seen[archetype] = true
        end
    end

    return archetypes
end

local function build_item(cache)
    local source_name, source_item = find_item(cache, ITEM_ROOT .. DONOR, DONOR)

    if not source_item then
        return false
    end

    if type(source_item.attachments) ~= "table" then
        return false, "source item has no attachments"
    end

    for _, part in pairs(PARTS) do
        if not package_found(part.unit) then
            return false, part.unit .. " package not found"
        end
    end

    local item = table.clone(source_item)

    item.name = MARK.item
    item.weapon_template = MARK.template
    item.display_name = MARK.display
    item.description = "loc_qiangiq_stubrifle_desc"
    item.dev_description = nil
    item.archetypes = archetypes_of(source_item)

    for _, field in ipairs({ "weapon_family_display_name", "weapon_pattern_display_name", "weapon_mark_display_name" }) do
        if type(item[field]) == "table" then
            item[field].loc_id = field == "weapon_family_display_name" and "loc_qiangiq_stubrifle_family" or MARK.display
        end
    end

    if not MARK.tree_logged then
        MARK.tree_logged = true
        mod:info("source tree of %s: %s", tostring(source_name), table.concat(dump_tree(item.attachments, "", {}), "; "))
    end

    -- master item data of shotgun_p1_m1 (http_cache.db, build 139617): receiver -> ammo, ammo_used, barrel (emblems,
    -- flashlight, trinkets), sight, stock, underbarrel; zzz_shared_material_overrides
    local receiver = item.attachments.receiver
    local rc = receiver and type(receiver.children) == "table" and receiver.children
    local barrel, sight, stock = rc and rc.barrel, rc and rc.sight, rc and rc.stock

    local function source_of(node)
        return node and type(node.item) == "string" and rawget(cache, node.item)
    end

    local sources = {
        receiver = source_of(receiver),
        barrel = source_of(barrel),
        muzzle = source_of(barrel),
        sight = source_of(sight),
        stock = source_of(stock),
    }

    for key, source in pairs(sources) do
        if not source then
            return false, "no " .. key .. " slot in " .. tostring(source_name)
        end
    end

    local names = {}

    for key, part in pairs(PARTS) do
        names[key] = PART_ROOT .. key .. "_01"

        if not rawget(cache, names[key]) then
            make_part(cache, names[key], sources[key], part.unit, part.node)
        end
    end

    local barrel_node = fresh_node(barrel, names.barrel)

    barrel_node.children = { muzzle = fresh_node(barrel, names.muzzle) }
    receiver.item = names.receiver
    receiver.children = {
        barrel = barrel_node,
        sight = fresh_node(sight, names.sight),
        stock = fresh_node(stock, names.stock),
    }

    only_base_unit(item, RIG)

    local deps = item.resource_dependencies or {}

    if source_item.base_unit then
        deps[source_item.base_unit] = nil
    end

    deps[RIG] = true

    for _, part in pairs(PARTS) do
        deps[part.unit] = true
    end

    -- bottom-right weapon HUD: item.hud_icon (hud_element_player_weapon.lua:77, QIangIQsMeltagun), the game's own icon
    if package_found(HUD_ICON) then
        if type(item.hud_icon) == "string" then
            deps[item.hud_icon] = nil
        end

        item.hud_icon = HUD_ICON
        deps[HUD_ICON] = true
    end

    -- what the offline item compile adds for the weapon template (item_package.lua:239-249): state machines, sounds, effects
    local WeaponTemplateResourceDependencies = require("scripts/utilities/weapon_template_resource_dependencies")

    for _, resource in ipairs(WeaponTemplateResourceDependencies.generate(MARK.template)) do
        deps[resource] = true
    end

    item.resource_dependencies = deps

    local ok, index = append_lookup("player_item_names", MARK.item)

    if not ok then
        return false
    end

    cache[MARK.item] = item
    MARK.item_id = index
    MARK.source_item_name = source_name
    MARK.slot = item.slots and item.slots[1]

    return true
end

local function ensure_item()
    local ok, has_data = pcall(MasterItems.has_data)

    if not ok or not has_data then
        return false
    end

    local cache = MasterItems.get_cached()

    if rawget(cache, MARK.item) and not MARK.dirty then
        MARK.item_ok = true

        return true
    end

    local built, err = build_item(cache)

    if err and err ~= MARK.last_error then
        MARK.last_error = err
        mod:error("%s: %s", MARK.template, err)
    end

    MARK.item_ok = built and rawget(cache, MARK.item) ~= nil

    if MARK.item_ok then
        MARK.dirty = false
    end

    return MARK.item_ok
end

-- Unlock lists (weapon_unlock_settings.lua WeaponUnlockSettings[archetype][level] = { item names }); realms_loadout
-- builds its human weapon list from it
local function add_to_unlock_lists()
    if not mod:get("add_to_unlock_list") then
        return
    end

    local ok, unlocks = pcall(require, "scripts/settings/weapon_unlock/weapon_unlock_settings")

    if not ok or not unlocks then
        mod:error("WeaponUnlockSettings not found")

        return
    end

    local level = math.floor(mod:get("unlock_level") or 1)

    for _, archetype in ipairs(ARCHETYPES) do
        local list = unlocks[archetype]

        if mod:get("unlock_" .. archetype) and list then
            list[level] = list[level] or {}

            if not table.find(list[level], MARK.item) then
                table.insert(list[level], MARK.item)
            end
        end
    end
end

local next_poll = 0

local function poll()
    if next_poll > os.clock() then
        return
    end

    next_poll = os.clock() + 1

    local before_t, before_i = MARK.template_ok, MARK.item_ok
    local ok_t, err_t = pcall(ensure_template)
    local ok_i, err_i = true, nil

    if MARK.template_ok then
        ok_i, err_i = pcall(ensure_item)
    end

    if not ok_t then
        mod:error("template: %s", tostring(err_t))
    end

    if not ok_i then
        mod:error("item: %s", tostring(err_i))
    end

    if MARK.template_ok and not before_t then
        if MARK.official_template then
            mod:info("the game now has its own %s template; using it", MARK.template)
        else
            mod:info("template %s registered (clone of %s, %s bullets), %s alias entries, own 1p set %s, notes: %s", MARK.template,
                DONOR, BULLET_DONOR, tostring(MARK.aliases), tostring(MARK.own_sm), table.concat(MARK.notes or {}, "; "))
        end
    end

    if MARK.item_ok and not before_i then
        mod:info("item %s injected (clone of %s, slot %s)", MARK.item, tostring(MARK.source_item_name), tostring(MARK.slot))
    end
end

local ITEM_SETTINGS = { unlock_zealot = true, unlock_veteran = true, unlock_psyker = true, unlock_adamant = true }

mod.on_setting_changed = function(setting_id)
    if ITEM_SETTINGS[setting_id] then
        MARK.dirty = true
    end
end

-- Anim event guard (QIangIQsFlamerPistol 0.5.0): player_unit_animation_extension.lua anim_event* call Unit.animation_event
-- unguarded; an event the current state machine lacks is skipped instead. The wielded template name is stored from
-- inventory_slot_wielded because the authoritative (hosting) class has no _local_wielded_weapon_template.
local ANIM_CLASSES = { "PlayerUnitAnimationExtension", "AuthoritativePlayerUnitAnimationExtension" }
local skipped_events = {}

local function guard(unit_field)
    return function(func, self, event_name, ...)
        if (self.__qiangiq_stubrifle_wielded or self._local_wielded_weapon_template) == MARK.template then
            local unit = self[unit_field]

            if unit and not Unit.alive(unit) then
                return
            end

            if unit and not Unit.has_animation_event(unit, event_name) then
                if not skipped_events[event_name] then
                    skipped_events[event_name] = true
                    mod:info("skipped anim event %s (%s): not in the state machine", tostring(event_name),
                        unit_field == "_first_person_unit" and "1p" or "3p")
                end

                return
            end
        end

        return func(self, event_name, ...)
    end
end

-- Reload / rechamber foley (0.1.1): the stub rifle state machine has no sound markers, so its bolt and shell sounds are
-- played here on the 1p anim event. Times are the clip seconds where the bolt / shell moves (work folder
-- stub_cue_times.py on shoot 1.4 s, reload_start 0.8 s, reload_loop_one/two, reload_end 1.0 s). The events are the
-- Combat Shotgun's own (stand-ins; no stub rifle reload sounds exist in the files). Played like audible_ability_recharge:
-- WwiseWorld.trigger_resource_event on the level world, local player only.
local FOLEY = {
    pull = "wwise/events/weapon/play_shotgun_reload_pull",
    push = "wwise/events/weapon/play_shotgun_reload_push",
    insert = "wwise/events/weapon/play_weapon_shotgun_human_reload_insert_ammo",
}
local CUES = {
    attack_shoot = { { 0.467, "pull" }, { 0.8, "push" } },
    reload_start = { { 0.2, "pull" } },
    reload_middle = { { 0.367, "insert" } },
    reload_end = { { 0.2, "push" } },
}
local pending_cues = {}

local function clock()
    local time = Managers.time

    return time and time:has_timer("gameplay") and time:time("gameplay") or os.clock()
end

local function queue_cues(self, event_name)
    local cues = CUES[event_name]

    if not cues or not mod:get("foley") or (self.__qiangiq_stubrifle_wielded or self._local_wielded_weapon_template) ~= MARK.template then
        return
    end

    if event_name == "attack_shoot" then
        -- a new shot or reload cancels the bolt sounds of the one before
        table.clear(pending_cues)
    end

    local now = clock()

    for _, cue in ipairs(cues) do
        pending_cues[#pending_cues + 1] = { t = now + cue[1], sound = FOLEY[cue[2]] }
    end
end

local function play_cues()
    if #pending_cues == 0 then
        return
    end

    local now = clock()
    local world_manager = Managers.world
    local world = world_manager and world_manager:has_world("level_world") and world_manager:world("level_world")
    local wwise_world = world and world_manager:wwise_world(world)

    for i = #pending_cues, 1, -1 do
        local cue = pending_cues[i]

        if cue.t <= now then
            table.remove(pending_cues, i)

            if wwise_world then
                WwiseWorld.trigger_resource_event(wwise_world, cue.sound)
            end
        end
    end
end

for _, class_name in ipairs(ANIM_CLASSES) do
    local class = CLASS[class_name]

    if class then
        mod:hook_safe(class, "inventory_slot_wielded", function(self, weapon_template)
            self.__qiangiq_stubrifle_wielded = weapon_template and weapon_template.name or false
        end)

        for _, method in ipairs({ "anim_event", "anim_event_with_variable_float", "anim_event_with_variable_floats",
            "anim_event_with_variable_int" }) do
            if class[method] then
                mod:hook(class, method, guard("_unit"))
            end
        end

        for _, method in ipairs({ "anim_event_1p", "anim_event_with_variable_float_1p", "anim_event_with_variable_floats_1p" }) do
            if class[method] then
                mod:hook(class, method, guard("_first_person_unit"))
            end
        end

        if class.anim_event_1p then
            mod:hook_safe(class, "anim_event_1p", queue_cues)
        end
    end
end

-- 0.2.1: hook by class name, never require action_handler at mod load. Its main chunk reads the global
-- NetworkConstants, which does not exist yet while mods load; the failed require poisons package.loaded and
-- the game's own require of it then CTDs on the next hub load ("loop or previous error loading module").
mod:hook_safe("ActionHandler", "start_action", function(self, id, action_objects, action_name, action_params, action_settings,
    used_input, t, transition_type, condition_func_params)
    if action_settings and action_settings[SHOT_MARK] and condition_func_params then
        last_shot[condition_func_params] = t
    end
end)

-- 5-round magazine on this weapon's own built copy of the ammo template
mod:hook(WeaponTweakTemplates, "create", function(func, lerp_values, weapon_template, ...)
    local templates = func(lerp_values, weapon_template, ...)

    if weapon_template and weapon_template.name == MARK.template and weapon_template.ammo_template then
        local ammo = templates[WeaponTweakTemplateSettings.template_types.ammo]
        local own = ammo and ammo[weapon_template.ammo_template]

        if own then
            own = table.clone(own)
            own.ammunition_clips = { MAGAZINE }
            own.force_even_numbers = nil
            ammo[weapon_template.ammo_template] = own
        end
    end

    return templates
end)

Guard.setup(mod)

mod.update = function()
    poll()
    play_cues()
    Guard.tick()
end

mod.on_all_mods_loaded = function()
    add_to_unlock_lists()
end

mod.on_unload = function()
    Guard.unload()

    local ok, cache = pcall(MasterItems.get_cached)

    if ok and cache then
        cache[MARK.item] = nil

        for key in pairs(PARTS) do
            cache[PART_ROOT .. key .. "_01"] = nil
        end
    end

    if MARK.template_ours then
        WeaponTemplates[MARK.template] = nil
    end
end

-- Equip without the backend (QIangIQsShardStaff override): only where this client hosts ----------------------------
local function local_player()
    local players = Managers.player

    return players and players:local_player_safe(1)
end

local function equipped_item_name(player, slot)
    local unit = player and player.player_unit

    if not unit or not Unit.alive(unit) then
        return nil
    end

    local extension = ScriptUnit.has_extension(unit, "visual_loadout_system")
    local item = extension and extension:item_from_slot(slot)

    return item and item.name
end

local previous = {}

local function override(slot, item_name)
    local player = local_player()
    local sync = Managers.profile_synchronization
    local host = sync and sync:synchronizer_host()

    if not player then
        say("no local player")

        return false
    end

    if not host then
        say("not the host here. Use the Psykhanium, a SoloPlay game or a game you host")

        return false
    end

    host:override_slot(player:peer_id(), player:local_player_id(), slot, item_name)
    say("override_slot(%s, %s) sent", slot, tostring(item_name))

    return true
end

local function status()
    say("%s: template %s (id %s, from %s), item %s (id %s, slot %s), own 1p set %s", MARK.template, tostring(MARK.template_ok),
        tostring(MARK.template_id), DONOR, tostring(MARK.item_ok), tostring(MARK.item_id), tostring(MARK.slot), tostring(MARK.own_sm))
    say("  rig package found: %s, 1p set package found: %s, hud icon found: %s", tostring(package_found(RIG)),
        tostring(package_found(SM_1P)), tostring(package_found(HUD_ICON)))

    if MARK.notes and #MARK.notes > 0 then
        say("  notes: %s", table.concat(MARK.notes, "; "))
    end

    if MARK.last_error then
        say("  last error: %s", MARK.last_error)
    end

    debug("skipped events: %s", table.concat(table.keys(skipped_events), ", "))
end

mod:command("stubrifle", mod:localize("command_stubrifle"), function(action)
    action = action or "status"

    if action == "status" then
        status()
    elseif action == "equip" then
        if not (MARK.template_ok and MARK.item_ok and MARK.slot) then
            say("%s not ready yet (template %s, item %s)", MARK.template, tostring(MARK.template_ok), tostring(MARK.item_ok))

            return
        end

        local player = local_player()

        previous[MARK.slot] = previous[MARK.slot] or (player and equipped_item_name(player, MARK.slot))
        override(MARK.slot, MARK.item)
    elseif action == "restore" then
        local any = false

        for slot, item_name in pairs(previous) do
            if item_name and override(slot, item_name) then
                previous[slot] = nil
                any = true
            end
        end

        if not any then
            say("nothing to restore (equip first)")
        end
    else
        say("usage: /stubrifle [status|equip|restore]")
    end
end)
