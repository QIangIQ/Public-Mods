-- Ability equip guard (crash 2026-10-31, Datavault Lessons/lesson-ability-unit-not-loaded):
--   "unit_spawner_manager.lua:586: Unit not found #ID[da66a53af4287607]" while the hub loaded after a Psykhanium visit with
--   a backend-less weapon equipped (host:override_slot). The unit was the zealot_shock_grenade's grenade_stumm: the grenade
--   item was equipped from the talents (realms_loadout _apply_talents hook, SoloPlay) before its package was loaded, and
--   the engine stops the game when it spawns a unit that is not loaded.
-- What it does: when an ability slot item (slot_grenade_ability, slot_combat_ability) is equipped and its base unit is not
-- loaded, the equip is held back, the item's packages are loaded (the same list the package synchroniser uses,
-- ItemPackage.compile_item_instance_dependencies), and the equip is done as soon as they are in. Every other equip is
-- untouched. A copy of this file is in QIangIQsChainaxe2h; both are standalone and either one alone is enough.
local ItemPackage = require("scripts/foundation/managers/package/utilities/item_package")
local MasterItems = require("scripts/backend/master_items")

local Guard = {}
local held = {} -- visual loadout extension -> slot name -> { item, t, unit_3p, correction, ids, packages }
local mod, reference

local function unit_loaded(path)
    local ok, exists = pcall(Application.can_get_resource, "unit", path)

    return not ok or exists
end

local function missing_base_unit(item)
    local path = item and item.base_unit

    if type(path) == "string" and path ~= "" and not unit_loaded(path) then
        return path
    end
end

local function load_packages(extension, item)
    local ok, dependencies = pcall(ItemPackage.compile_item_instance_dependencies, item, MasterItems.get_cached(), nil,
        extension._mission)
    local ids, packages = {}, {}

    if not ok or type(dependencies) ~= "table" then
        mod:warning("ability guard: no package list for %s (%s)", tostring(item.name), tostring(dependencies))

        return ids, packages
    end

    for package_name in pairs(dependencies) do
        packages[#packages + 1] = package_name
        ids[#ids + 1] = Managers.package:load(package_name, reference, nil, true)
    end

    return ids, packages
end

local function release(entry)
    for _, id in ipairs(entry.ids or {}) do
        pcall(Managers.package.release, Managers.package, id)
    end

    entry.ids = {}
end

local function equip_hook(func, self, item, slot_name, t, optional_existing_unit_3p, from_server_correction_occurred, ...)
    local missing = type(slot_name) == "string" and slot_name:find("ability") and missing_base_unit(item)

    if not missing then
        return func(self, item, slot_name, t, optional_existing_unit_3p, from_server_correction_occurred, ...)
    end

    local slots = held[self] or {}
    local previous = slots[slot_name]

    if previous then
        release(previous)
    end

    local ids, packages = load_packages(self, item)

    slots[slot_name] = {
        item = item,
        t = t,
        unit_3p = optional_existing_unit_3p,
        correction = from_server_correction_occurred,
        ids = ids,
        packages = packages,
    }
    held[self] = slots

    mod:warning("ability guard: %s for %s is not loaded (%s); equip held until its %d packages are in", tostring(item.name),
        slot_name, missing, #packages)
end

local function ready(entry)
    for _, package_name in ipairs(entry.packages) do
        if not Managers.package:has_loaded(package_name) then
            return false
        end
    end

    return not missing_base_unit(entry.item)
end

function Guard.update()
    if next(held) == nil then
        return
    end

    for extension, slots in pairs(held) do
        local unit = extension._unit

        if not (unit and Unit.alive(unit) and ScriptUnit.has_extension(unit, "visual_loadout_system") == extension) then
            for _, entry in pairs(slots) do
                release(entry)
            end

            held[extension] = nil
        else
            for slot_name, entry in pairs(slots) do
                if ready(entry) then
                    slots[slot_name] = nil

                    local slot = extension._equipment and extension._equipment[slot_name]

                    if slot and slot.item == nil then
                        local ok, err = pcall(extension._equip_item_to_slot, extension, entry.item, slot_name, entry.t,
                            entry.unit_3p, entry.correction)

                        mod:info("ability guard: %s equipped to %s after its packages loaded%s", tostring(entry.item.name),
                            slot_name, ok and "" or (": " .. tostring(err)))
                    end

                    -- the slot item now holds its own references; ours can go after a second so nothing unloads in between
                    entry.release_at = os.clock() + 1
                    Guard.later = Guard.later or {}
                    Guard.later[#Guard.later + 1] = entry
                end
            end

            if next(slots) == nil then
                held[extension] = nil
            end
        end
    end
end

function Guard.release_later()
    local later = Guard.later

    if not later then
        return
    end

    local now = os.clock()

    for i = #later, 1, -1 do
        if later[i].release_at <= now then
            release(later[i])
            table.remove(later, i)
        end
    end
end

function Guard.setup(owner)
    mod = owner
    reference = owner:get_name() .. "_ability_guard"

    -- hook_require: the class file may not be loaded yet when the mod loads (main menu)
    mod:hook_require("scripts/extension_systems/visual_loadout/player_unit_visual_loadout_extension", function(class)
        if class and class._equip_item_to_slot then
            mod:hook(class, "_equip_item_to_slot", equip_hook)
        else
            mod:warning("ability guard: PlayerUnitVisualLoadoutExtension._equip_item_to_slot not found")
        end
    end)
end

function Guard.tick()
    Guard.update()
    Guard.release_later()
end

function Guard.unload()
    for _, slots in pairs(held) do
        for _, entry in pairs(slots) do
            release(entry)
        end
    end

    for _, entry in ipairs(Guard.later or {}) do
        release(entry)
    end

    held = {}
    Guard.later = nil
end

return Guard
