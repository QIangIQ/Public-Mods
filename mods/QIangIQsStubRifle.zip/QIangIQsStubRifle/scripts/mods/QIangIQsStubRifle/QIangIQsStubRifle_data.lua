local mod = get_mod("QIangIQsStubRifle")

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = false,
    options = {
        widgets = {
            { setting_id = "own_animations", type = "checkbox", default_value = true },
            { setting_id = "foley", type = "checkbox", default_value = true },
            { setting_id = "shot_interval", type = "numeric", default_value = 1, range = { 0.3, 3 }, decimals_number = 1 },
            { setting_id = "shot_damage", type = "numeric", default_value = 16500, range = { 500, 30000 }, decimals_number = 0 },
            { setting_id = "add_to_unlock_list", type = "checkbox", default_value = true },
            { setting_id = "unlock_level", type = "numeric", default_value = 1, range = { 1, 30 }, decimals_number = 0 },
            { setting_id = "unlock_zealot", type = "checkbox", default_value = true },
            { setting_id = "unlock_veteran", type = "checkbox", default_value = true },
            { setting_id = "unlock_psyker", type = "checkbox", default_value = false },
            { setting_id = "unlock_adamant", type = "checkbox", default_value = false },
            { setting_id = "debug", type = "checkbox", default_value = false },
        },
    },
}
