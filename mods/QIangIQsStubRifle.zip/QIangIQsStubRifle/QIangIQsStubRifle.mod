return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsStubRifle` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsStubRifle", {
            mod_script = "QIangIQsStubRifle/scripts/mods/QIangIQsStubRifle/QIangIQsStubRifle",
            mod_data = "QIangIQsStubRifle/scripts/mods/QIangIQsStubRifle/QIangIQsStubRifle_data",
            mod_localization = "QIangIQsStubRifle/scripts/mods/QIangIQsStubRifle/QIangIQsStubRifle_localization",
        })
    end,
    version = "0.2.2",
    author = "QIangIQ",
    packages = {},
}
