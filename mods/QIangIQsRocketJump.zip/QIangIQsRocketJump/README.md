# QIangIQs Rocket Jump

Hive Scum's missile launcher (the "Boom Bringer" blitz) throws you when its blast is near you, like TF2's Soldier. It never hurts you.

## What it does

- **Launch:** your own missile's blast pushes you away from it and up. A rocket at your feet sends you straight up; one against a wall sends you sideways and up.
- **Strength:** at 100% the push is the game's close Poxburster blast (`catapulting_templates.poxwalker_bomber_close`: 13 m/s away from the blast, 8 m/s up), about 2.7 m up. The default 150% is 19.5 m/s and 12 m/s: about 6 m up and 2 seconds in the air. Full strength inside the blast's inner radius (4 m), fading to nothing at its edge (7.5 m).
- **Air control:** you stay in the normal jump and fall, so you can strafe and shoot. The speed you already have is kept, a fall is cancelled first, and a second rocket while rising stacks on top.
- **No damage:** the game already never lets your own missile hurt you. Falls from a rocket jump don't hurt you either, until you land (setting).
- Only your own missile moves you, and only the missile launcher's blast.
- **Keep in hand (default):** the launcher is no longer put away after each shot. It stays up like a 10 round RPG: aim, fire, and fire again after the game's shot recovery (1.45 s, sped up). It is put away when it runs out of missiles or when you switch weapons.
- **Fast draw:** drawing the launcher, its shot, and the weapon drawn after it run 10 times faster. The game caps action speed (about 2.65x seen in a crash log), so the draw ends up around 0.2 s.
- **From the hand (optional, off by default):** instead of drawing the launcher, the blitz key fires a missile with Hive Scum's left-hand quick throw while your weapon stays in your right hand. The launcher model is not shown.
- **Launcher:** 10 missiles instead of 2 (grenade talents still add on top), one comes back every 15 seconds until it is full, and missiles deal half damage to enemies (stagger unchanged).

## Settings

- Launch strength (%): 50 to 300, default 150.
- No fall damage after a rocket jump: on by default.
- Missile launcher charges: 1 to 20, default 10.
- Missile recharge (seconds per missile): 0 (off) to 60, default 15.
- Missile damage to enemies (%): 10 to 100, default 50.
- Keep the launcher in hand: on by default.
- Fire missiles from the left hand: off by default.
- Missile speed-up (x): 1 to 20, default 10 (the game may cap it lower).

## Where it works

The push runs where the game runs the explosion and your movement: the server. That is solo play and a Realms game you host. On Fatshark's mission servers the explosion is not run on your machine, so nothing changes there. Other players in a game you host get the push too if they fire the launcher; they will likely see some snapping, since their own machines don't predict it.

## How it is built

| Part | From the game |
|---|---|
| Which blast | `Explosion.create_explosion` (`scripts/utilities/attack/explosion.lua`), template `broker_missile_launcher` (`player_grenade_explosion_templates.lua`). The owner is found with `AttackingUnitResolver.resolve`, as `_resolve_params` does, before the blast runs |
| No self damage | already in the game: the blast only damages `hit_unit ~= attacking_unit_owner_unit` unless the template has `override_friendly_fire` (it doesn't), and it has no `player_disorientation_type` |
| Reach | `Explosion.radii` (radius 7, close radius 4 at full charge) plus half the player's `broadphase_radius`, the same check the blast uses on players |
| Push | `hit_reaction.lua` `_catapult`: direction from the blast to `j_spine` (as `barrel_explosion`, `use_hit_position`), times force, with z set to z_force. Numbers from `poxwalker_bomber_close` |
| Movement | instead of the catapulted state (no weapons, no control), the push is added after `PlayerCharacterStateJumping` / `PlayerCharacterStateFalling` `fixed_update` has run the game's air movement. On the ground (walking, sprinting, dodging, sliding) the state returns `jumping`, and the push replaces the jump's speed in `on_enter` |
| Charges | `PlayerUnitAbilityExtension.max_ability_charges` for `grenade_ability` when it is `broker_missile_launcher` (2 in `talent_settings_broker.lua`) gets the difference added, on the server; the game hands out the extra charges and syncs the maximum itself |
| Recharge | the timer of `adamant_grenade_replenishment` (`adamant_buff_templates.lua`): while charges are missing, `restore_ability_charge("grenade_ability", 1)` every 15 s and the `charge_ready_indicator` sound, run from the ability extension's `fixed_update` on the server |
| Damage | the damage `DamageCalculation.calculate` returns for `broker_missile_launcher_explosion_close`, `_explosion` and `_impact` is scaled when a player fired it and the target is not a player |
| From the hand | the game's `grenade_ability_quick_flash_grenade` action (`base_template_settings.lua`, on every weapon, already in the network lookups) also accepts the missile launcher's slot; `projectile_template_func` gives `ProjectileTemplates.broker_missile` and the projectile item is the launcher's `bullets/broker_missile`; the blitz key's `action_unwield` is turned off so the launcher isn't drawn. Only for a player on the machine running the game, so the server and the player's prediction agree |
| Keep in hand | `missile_launcher.lua`'s `action_unwield_to_previous` (the `auto_chain` after a shot) is refused while missiles are left; the shot's `total_time` (`math.huge`) becomes 1.5 s and it chains to `action_charge_direct`/`action_charge_brace` and a weapon swap from 1.45 s, the shot's own put-away time. Only for a player on the machine running the game |
| Speed | `ActionHandler._calculate_time_scale` (what wield speed and attack speed buffs change) is multiplied for the hand throw, the launcher's draw and shot (it puts itself away 1.45 s after the shot), and the draw of the weapon after it, capped at the network's maximum |
| Fall damage | `Fall.check_damage` and `Fall.trigger_impact_sound` (`character_states/utilities/fall.lua`) are skipped from the launch until the player leaves the jump/fall states |

## Testing

Harness with the current game Lua, 83 checks pass: template has no friendly fire or disorient; radii 7/4; the game's explosion still runs; only the shooter is pushed; a rocket at the feet gives 12 m/s straight up with the jump speed replaced; mid-air strafe speed kept, fall cancelled, pushed away from the blast; a second rocket stacks; weaker past 4 m, nothing past 7.5 m; frag grenades and clients do nothing; a stale launch is dropped; every grounded state pops into a jump; fall damage skipped during the flight, back after landing and when the setting is off; the launch survives the falling state's own fall speed; 10 charges with talents on top, only for the missile launcher and only on the server; a missile back every 15 s, none when full or set to 0; half damage only for the missile's three profiles fired by a player at a non-player, and only on the server; the blitz key throws a broker_missile from the hand on every weapon (flash grenades unchanged), the launcher is not drawn, setting off and remote players keep the game's behaviour; the throw, launcher draw and shot, and the weapon drawn after it run 10 times faster, normal swaps don't; with keep in hand the launcher is not put away while missiles are left, is put away when empty, and can fire again and swap weapons after 1.45 s.

Not tested in game.
