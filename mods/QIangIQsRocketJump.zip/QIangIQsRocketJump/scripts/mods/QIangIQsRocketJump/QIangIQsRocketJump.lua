local mod = get_mod("QIangIQsRocketJump")

-- Rocket jumping for Hive Scum's missile launcher (blitz "broker_missile_launcher",
-- item content/items/weapons/player/ranged/missile_launcher).
--
-- Self damage: the game already skips it. Explosion.create_explosion only
-- damages a unit when `hit_unit ~= attacking_unit_owner_unit or
-- friendly_fire_override`, and the broker_missile_launcher explosion template
-- has no override_friendly_fire and no player_disorientation_type.
--
-- Knockback: the shooter is pushed the way hit_reaction.lua _catapult pushes a
-- player (direction from the blast to a body node, times force; z set to
-- z_force), with the numbers of catapulting_templates.poxwalker_bomber_close,
-- the strongest explosion catapult in the game. Unlike the catapulted state it
-- keeps the player in the normal jumping / falling states, so weapons and air
-- strafing (PlayerCharacterStateBase._air_movement) keep working.
--
-- Everything runs where the game runs the explosion and the player's movement:
-- the server (solo, or a Realms game you host). On Fatshark's servers the
-- explosion hook never runs on your machine, so nothing changes there.

local AttackingUnitResolver = require("scripts/utilities/attack/attacking_unit_resolver")
local Breed = require("scripts/utilities/breed")

local ROCKET_TEMPLATES = {
	broker_missile_launcher = true,
}

-- catapulting_templates.lua: barrel_explosion (an explosion) aims from
-- j_spine with use_hit_position; poxwalker_bomber_close gives the push.
local LAUNCH = {
	direction_from_node = "j_spine",
	force = 13,
	z_force = 8,
}

-- How long a launch waits for the player's movement to pick it up.
local PENDING_TIME = 0.3

local IN_AIR_STATES = {
	falling = true,
	jumping = true,
}

local pending_launches = mod:persistent_table("rocket_jump_pending", {})
local launched_units = mod:persistent_table("rocket_jump_launched", {})

mod.on_disabled = function ()
	table.clear(pending_launches)
	table.clear(launched_units)
end

local function _is_server()
	local game_session = Managers.state and Managers.state.game_session

	return game_session and game_session:is_server() or false
end

local function _gameplay_time()
	local ok, t = pcall(function ()
		return Managers.time:time("gameplay")
	end)

	return ok and type(t) == "number" and t or nil
end

local function _strength()
	return (mod:get("launch_strength") or 150) / 100
end

-- Explosion.radii, as _resolve_params in explosion.lua calls it. Falls back to
-- the template's own numbers.
local function _radii(Explosion, explosion_template, attacking_unit, owner_unit, charge_level, attack_type)
	local ok, radius, close_radius = pcall(function ()
		local buff_extension = ScriptUnit.has_extension(owner_unit, "buff_system")
		local stat_buffs = buff_extension and buff_extension:stat_buffs()
		local unit_data_extension = ScriptUnit.has_extension(attacking_unit, "unit_data_system")
		local breed = unit_data_extension and unit_data_extension:breed()
		local lerp_values = Explosion.lerp_values(attacking_unit, explosion_template.name)

		return Explosion.radii(explosion_template, charge_level, lerp_values, attack_type, stat_buffs, breed)
	end)

	if ok and type(radius) == "number" and type(close_radius) == "number" then
		return radius, close_radius
	end

	local template_radius = explosion_template.radius
	local template_close_radius = explosion_template.close_radius

	return type(template_radius) == "number" and template_radius or 7, type(template_close_radius) == "number" and template_close_radius or 4
end

-- The push for the owner of a blast at source_position, or nil when out of
-- reach. Full strength inside the close radius, fading to nothing at the
-- radius players are checked against (explosion.lua: half the breed's
-- broadphase_radius plus the radius).
local function _launch_velocity(owner_unit, source_position, radius, close_radius)
	local unit_data_extension = ScriptUnit.has_extension(owner_unit, "unit_data_system")
	local breed = unit_data_extension and unit_data_extension:breed()

	if not breed or not Breed.is_player(breed) then
		return nil
	end

	local node = Unit.has_node(owner_unit, LAUNCH.direction_from_node) and Unit.node(owner_unit, LAUNCH.direction_from_node) or 1
	local body_position = Unit.world_position(owner_unit, node)
	local offset = body_position - source_position
	local distance = Vector3.length(offset)
	local reach = (breed.broadphase_radius or 1) * 0.5 + radius

	if reach < distance then
		return nil
	end

	local scale = 1

	if close_radius < distance and close_radius < reach then
		scale = 1 - (distance - close_radius) / (reach - close_radius)
	end

	scale = scale * _strength()

	local direction = distance > 0.001 and offset / distance or Vector3.up()
	local velocity = direction * LAUNCH.force * scale

	velocity.z = LAUNCH.z_force * scale

	return velocity
end

-- Applies a launch to a velocity: the push is added to the speed the player
-- already has, and a fall is cancelled first (the catapult sets z), so a
-- second rocket stacks on the first.
local function _launched(velocity, launch)
	local result = Vector3(velocity.x + launch.x, velocity.y + launch.y, math.max(velocity.z, 0) + launch.z)

	return result
end

-- The launch waiting for this unit, if it is still fresh.
local function _take_launch(unit, t)
	local entry = pending_launches[unit]

	if not entry then
		return nil
	end

	if entry.t and t and math.abs(t - entry.t) > PENDING_TIME then
		pending_launches[unit] = nil

		return nil
	end

	return entry
end

local function _consume_launch(unit, entry)
	pending_launches[unit] = nil
	launched_units[unit] = true

	return entry.velocity:unbox()
end

-- ####################################################################
-- The blast (server)
-- ####################################################################

mod:hook_require("scripts/utilities/attack/explosion", function (Explosion)
	mod:hook(Explosion, "create_explosion", function (func, world, physics_world, source_position, rotation, attacking_unit, explosion_template, power_level, charge_level, attack_type, ...)
		local owner_unit

		-- Resolved before the blast runs, while the missile is still alive.
		if explosion_template and ROCKET_TEMPLATES[explosion_template.name] and _is_server() then
			local ok, resolved = pcall(AttackingUnitResolver.resolve, attacking_unit)

			owner_unit = ok and resolved or nil
		end

		local result_1, result_2 = func(world, physics_world, source_position, rotation, attacking_unit, explosion_template, power_level, charge_level, attack_type, ...)

		if owner_unit and HEALTH_ALIVE[owner_unit] then
			local ok, err = pcall(function ()
				local radius, close_radius = _radii(Explosion, explosion_template, attacking_unit, owner_unit, charge_level, attack_type)
				local velocity = _launch_velocity(owner_unit, source_position, radius, close_radius)

				if velocity then
					pending_launches[owner_unit] = {
						velocity = Vector3Box(velocity),
						t = _gameplay_time(),
					}
				end
			end)

			if not ok then
				mod:warning("Rocket jump skipped: %s", tostring(err))
			end
		end

		return result_1, result_2
	end)
end)

-- ####################################################################
-- The player's movement (server)
-- ####################################################################

local STATE_PATH = "scripts/extension_systems/character_state_machine/character_states/player_character_state_"

-- On the ground: the game's own jump gets the player airborne, and the
-- launch replaces the jump's speed as it starts.
for _, state_name in ipairs({ "walking", "sprinting", "dodging", "sliding" }) do
	mod:hook_require(STATE_PATH .. state_name, function (State)
		mod:hook(State, "fixed_update", function (func, self, unit, dt, t, next_state_params, fixed_frame)
			local next_state = func(self, unit, dt, t, next_state_params, fixed_frame)

			if next_state == nil and self._is_server and _take_launch(unit, t) then
				return "jumping"
			end

			return next_state
		end)
	end)
end

mod:hook_require(STATE_PATH .. "jumping", function (State)
	mod:hook_safe(State, "on_enter", function (self, unit, dt, t, previous_state, params)
		if not self._is_server then
			return
		end

		local entry = _take_launch(unit, t)

		if entry then
			local steering = self._locomotion_steering_component

			steering.velocity_wanted = _launched(self._locomotion_component.velocity_current, _consume_launch(unit, entry))
		end
	end)
end)

-- In the air: after the state's own air movement has set velocity_wanted.
-- Falling leaves gravity to the locomotion, which with calculate_fall_velocity
-- replaces velocity_wanted.z with the current fall speed
-- (player_unit_locomotion_extension.lua _update_script_driven_movement), so
-- for the launch step falling does what jumping does: calculate_fall_velocity
-- off and gravity taken off here (as QIangIQsSourceMovement does on surf
-- ramps). It is turned back on at the start of the next step.
for _, state_name in ipairs({ "jumping", "falling" }) do
	mod:hook_require(STATE_PATH .. state_name, function (State)
		mod:hook(State, "fixed_update", function (func, self, unit, dt, t, next_state_params, fixed_frame)
			local steering = self._locomotion_steering_component

			if self._qiangiq_rocket_gravity then
				self._qiangiq_rocket_gravity = nil
				steering.calculate_fall_velocity = true
			end

			local next_state = func(self, unit, dt, t, next_state_params, fixed_frame)

			if self._is_server then
				local entry = _take_launch(unit, t)

				if entry then
					local velocity = _launched(steering.velocity_wanted, _consume_launch(unit, entry))

					if steering.calculate_fall_velocity then
						velocity = Vector3(velocity.x, velocity.y, velocity.z - self._constants.gravity * dt)
						steering.calculate_fall_velocity = false
						self._qiangiq_rocket_gravity = true
					end

					steering.velocity_wanted = velocity
				end
			end

			return next_state
		end)

		-- Landed (or grabbed a ledge, got knocked down...): the flight is over.
		mod:hook_safe(State, "on_exit", function (self, unit, t, next_state)
			if next_state and not IN_AIR_STATES[next_state] then
				launched_units[unit] = nil
			end
		end)
	end)
end

-- ####################################################################
-- Fall damage (server: Fall.check_damage runs in falling's fixed_update)
-- ####################################################################

mod:hook_require("scripts/extension_systems/character_state_machine/character_states/utilities/fall", function (Fall)
	mod:hook(Fall, "check_damage", function (func, unit, ...)
		if launched_units[unit] and mod:get("no_fall_damage") ~= false then
			return
		end

		return func(unit, ...)
	end)

	mod:hook(Fall, "trigger_impact_sound", function (func, unit, ...)
		if launched_units[unit] and mod:get("no_fall_damage") ~= false then
			return
		end

		return func(unit, ...)
	end)
end)

-- ####################################################################
-- Missile launcher charges and damage (server)
-- ####################################################################

-- broker_abilities.lua: broker_missile_launcher, max_charges from
-- talent_settings_broker.lua blitz.missile_launcher.max_charges (2), plus the
-- extra_max_amount_of_grenades stat buff.
local MISSILE_ABILITY = "broker_missile_launcher"
local GRENADE_ABILITY_TYPE = "grenade_ability"
local GAME_MAX_CHARGES = 2
local MISSILE_DAMAGE_PROFILES = {
	broker_missile_launcher_explosion = true,
	broker_missile_launcher_explosion_close = true,
	broker_missile_launcher_impact = true,
}
local charge_ready_properties = {
	indicator_type = "human_grenade",
}

local function _setting_number(setting_id, default)
	local value = mod:get(setting_id)

	return type(value) == "number" and value or default
end

local function _has_missile_launcher(ability_extension)
	local ability = ability_extension._equipped_abilities and ability_extension._equipped_abilities[GRENADE_ABILITY_TYPE]

	return ability and ability.name == MISSILE_ABILITY
end

mod:hook_require("scripts/extension_systems/ability/player_unit_ability_extension", function (PlayerUnitAbilityExtension)
	-- More charges: the game's count (with its stat buff) plus the difference.
	-- The game itself hands out the new charges when the maximum goes up
	-- (_update_ability_resources) and syncs the maximum to everyone.
	mod:hook(PlayerUnitAbilityExtension, "max_ability_charges", function (func, self, ability_type)
		local max_charges = func(self, ability_type)

		if self._is_server and ability_type == GRENADE_ABILITY_TYPE and max_charges > 0 and _has_missile_launcher(self) then
			max_charges = max_charges + math.floor(_setting_number("missile_charges", 10)) - GAME_MAX_CHARGES
		end

		return max_charges
	end)

	-- One charge back every missile_regen_time seconds while any are missing:
	-- the timer of adamant_buff_templates.lua adamant_grenade_replenishment,
	-- with its restore_ability_charge and charge_ready_indicator sound.
	mod:hook_safe(PlayerUnitAbilityExtension, "fixed_update", function (self, unit, dt, t, fixed_frame)
		if not self._is_server then
			return
		end

		local ok, err = pcall(function ()
			local regen_time = _setting_number("missile_regen_time", 15)

			if regen_time <= 0 or not _has_missile_launcher(self) or self:missing_ability_charges(GRENADE_ABILITY_TYPE) <= 0 then
				self._qiangiq_next_missile_t = nil

				return
			end

			local next_missile_t = self._qiangiq_next_missile_t

			if not next_missile_t then
				self._qiangiq_next_missile_t = t + regen_time

				return
			end

			if next_missile_t < t then
				self._qiangiq_next_missile_t = nil

				self:restore_ability_charge(GRENADE_ABILITY_TYPE, 1)

				local first_person_extension = ScriptUnit.has_extension(unit, "first_person_system")
				local fx_extension = ScriptUnit.has_extension(unit, "fx_system")

				if fx_extension and first_person_extension and first_person_extension:is_in_first_person_mode() then
					fx_extension:trigger_gear_wwise_event("charge_ready_indicator", charge_ready_properties)
				end
			end
		end)

		if not ok then
			self._qiangiq_next_missile_t = nil

			mod:warning("Missile charge regen skipped: %s", tostring(err))
		end
	end)
end)

-- Less damage to enemies: the damage DamageCalculation.calculate works out for
-- the missile's three damage profiles (broker_damage_profile_templates.lua) is
-- scaled, when a player fired it and the target is not a player. Stagger is
-- untouched.
mod:hook_require("scripts/utilities/attack/damage_calculation", function (DamageCalculation)
	mod:hook(DamageCalculation, "calculate", function (func, damage_profile, damage_type, target_settings, lerp_values, hit_zone_name, power_level, charge_level, breed_or_nil, attacker_owner_breed_or_nil, ...)
		local damage, damage_efficiency, base_damage, base_buff_damage, rending_damage, finesse_boost_damage, backstab_damage, flanking_damage, armor_damage_modifier, hit_zone_damage_multiplier = func(damage_profile, damage_type, target_settings, lerp_values, hit_zone_name, power_level, charge_level, breed_or_nil, attacker_owner_breed_or_nil, ...)

		if damage_profile and MISSILE_DAMAGE_PROFILES[damage_profile.name] and attacker_owner_breed_or_nil and attacker_owner_breed_or_nil.breed_type == "player" and not (breed_or_nil and breed_or_nil.breed_type == "player") and type(damage) == "number" and _is_server() then
			damage = damage * _setting_number("missile_enemy_damage", 50) / 100
		end

		return damage, damage_efficiency, base_damage, base_buff_damage, rending_damage, finesse_boost_damage, backstab_damage, flanking_damage, armor_damage_modifier, hit_zone_damage_multiplier
	end)
end)

-- ####################################################################
-- Firing from the hand, and fast draw / put away
-- ####################################################################

-- Hive Scum's quick flash grenade (base_template_settings.lua
-- grenade_ability_quick_flash_grenade) is an action on every weapon: the
-- grenade key throws it with the left hand ("ability_knife_throw") while the
-- weapon stays in the right hand. Its action name is already in the game's
-- network lookups, and a player has only one blitz, so with the missile
-- launcher equipped the same action fires a missile instead:
--   * ability_type_func / override_origin_slot_func / action_condition_func
--     also accept the missile launcher's grenade slot;
--   * projectile_template_func gives ProjectileTemplates.broker_missile, and
--     the projectile item is the launcher's own missile item
--     (missile_launcher.lua fire_configuration.inventory_item_name);
--   * the grenade key's unwield (generate_unwield_action) is turned off, so
--     the launcher is not drawn.
-- Speed: ActionHandler._calculate_time_scale (the time scale every action
-- runs at, what wield_speed and attack_speed buffs change) is multiplied for
-- this throw, the launcher's draw and shot, and the draw of the weapon you
-- go back to, up to the network's maximum.
--
-- Only for a player on the machine running the game (solo or your own Realms
-- game): the action runs on the server and is predicted on the player's own
-- machine, and both must agree.

local ProjectileTemplates = require("scripts/settings/projectile/projectile_templates")

local QUICK_ACTION = "grenade_ability_quick_flash_grenade"
local MISSILE_ITEM = "content/items/weapons/player/ranged/bullets/broker_missile"
local MISSILE_VO_TAG = "broker_missile_launcher"
local GRENADE_SLOT = "slot_grenade_ability"
local MISSILE_WEAPON_TEMPLATE = "missile_launcher"
local GRENADE_PRESSED_INPUT = "grenade_ability_pressed"
local WIELD_KINDS = {
	ranged_wield = true,
	wield = true,
}

local quick_actions = setmetatable({}, { __mode = "k" })
local _missile_spawn_template

local function _local_hosted_player(player)
	return player and not player.remote and player.is_human_controlled and player:is_human_controlled() and _is_server()
end

-- The missile launcher is this player's blitz and it is fired from the hand.
local function _quick_missile(ability_extension)
	if not ability_extension or mod:get("missile_from_hand") == false then
		return false
	end

	return _has_missile_launcher(ability_extension) and _local_hosted_player(ability_extension._player) or false
end

local function _ability_extension_of(params)
	return params and params.ability_extension
end

-- ActionSpawnProjectile._fire_projectile reads the locomotion template's
-- spawn_projectile_parameters (and trajectory_parameters.spawn), which
-- broker_missile does not have: it is fired by action_shoot_hip, which reads
-- trajectory_parameters.shoot. The hand throw uses a copy of broker_missile
-- (same name, so clients and the network see the game's template) whose
-- locomotion template adds them, taken from its shoot parameters
-- (weapon_projectile_locomotion_templates.lua: speed_initial 76, above
-- speed_maximal so aim_projectile.lua uses 76; offset_forward 0.5; manual
-- physics), aimed straight with no spread like a shot.
local missile_spawn_template

_missile_spawn_template = function ()
	if missile_spawn_template then
		return missile_spawn_template
	end

	local source = ProjectileTemplates.broker_missile
	local source_locomotion = source.locomotion_template
	local shoot = source_locomotion.trajectory_parameters.shoot
	local locomotion = {}

	for key, value in pairs(source_locomotion) do
		locomotion[key] = value
	end

	local trajectory_parameters = {}

	for key, value in pairs(source_locomotion.trajectory_parameters) do
		trajectory_parameters[key] = value
	end

	trajectory_parameters.spawn = trajectory_parameters.spawn or {
		locomotion_state = shoot.locomotion_state,
	}
	locomotion.trajectory_parameters = trajectory_parameters
	locomotion.spawn_projectile_parameters = locomotion.spawn_projectile_parameters or {
		initial_speed = math.max(shoot.speed_initial, shoot.speed_maximal),
		skip_spread = true,
		spawn_offset = Vector3Box(shoot.offset_right or 0, shoot.offset_forward or 0, shoot.offset_up or 0),
		pitch_offset = {
			max = 0,
			min = 0,
		},
		has_target_pitch_offset = {
			max = 0,
			min = 0,
		},
		has_target_yaw_offset = {
			max = 0,
			min = 0,
		},
	}

	local template = {}

	for key, value in pairs(source) do
		template[key] = value
	end

	template.locomotion_template = locomotion
	missile_spawn_template = template

	return template
end

local function _patch_quick_action(action)
	if quick_actions[action] then
		return
	end

	quick_actions[action] = true

	local ability_type_func = action.ability_type_func
	local override_origin_slot_func = action.override_origin_slot_func
	local action_condition_func = action.action_condition_func

	action.ability_type_func = function (action_start_params, condition_func_params)
		if _quick_missile(_ability_extension_of(action_start_params or condition_func_params)) then
			return GRENADE_ABILITY_TYPE
		end

		return ability_type_func(action_start_params, condition_func_params)
	end

	action.override_origin_slot_func = function (action_start_params, condition_func_params)
		if _quick_missile(_ability_extension_of(action_start_params or condition_func_params)) then
			return GRENADE_SLOT
		end

		return override_origin_slot_func(action_start_params, condition_func_params)
	end

	action.action_condition_func = function (action_settings, condition_func_params, used_input, ...)
		if _quick_missile(_ability_extension_of(condition_func_params)) then
			return used_input == GRENADE_PRESSED_INPUT
		end

		return action_condition_func(action_settings, condition_func_params, used_input, ...)
	end

	action.projectile_template_func = function (unit, action_settings)
		if _quick_missile(ScriptUnit.has_extension(unit, "ability_system")) then
			return _missile_spawn_template()
		end

		return nil
	end
end

local function _patch_unwield_action(action)
	if quick_actions[action] then
		return
	end

	quick_actions[action] = true

	local action_condition_func = action.action_condition_func

	action.action_condition_func = function (action_settings, condition_func_params, used_input, ...)
		if used_input == GRENADE_PRESSED_INPUT and _quick_missile(_ability_extension_of(condition_func_params)) then
			return false
		end

		return action_condition_func(action_settings, condition_func_params, used_input, ...)
	end
end

-- Keeping the launcher in hand (setting missile_keep_in_hand), like a
-- 10-round RPG. missile_launcher.lua action_shoot_hip runs forever and puts
-- the launcher away 1.45 s in (conditional auto_chain to
-- action_unwield_to_previous, whose only input is automatic). Here:
--   * action_unwield_to_previous refuses while this player keeps the
--     launcher and has missiles left (out of missiles: put away as before);
--   * action_shoot_hip ends at 1.5 s instead of never, so with the put-away
--     refused the launcher just stays up (for everyone else the put-away at
--     1.45 s still comes first);
--   * from action_shoot_hip the next shot can start: the launcher's own fire
--     and brace inputs (shoot_charge, brace_charge) chain at 1.45 s, and
--     weapon swaps at 0.4 s, the launcher's other actions' wield chain time.
local KEEP_SHOT_END = 1.5
local KEEP_REFIRE_TIME = 1.45
local KEEP_SWAP_TIME = 0.4

local function _keep_launcher(ability_extension)
	if not ability_extension or mod:get("missile_keep_in_hand") == false then
		return false
	end

	return _has_missile_launcher(ability_extension) and _local_hosted_player(ability_extension._player) or false
end

local function _patch_missile_launcher(weapon_template)
	local actions = weapon_template.actions
	local shoot = actions and actions.action_shoot_hip
	local unwield = actions and actions.action_unwield_to_previous

	if not (shoot and unwield and actions.action_charge_direct and actions.action_charge_brace) or quick_actions[unwield] then
		return
	end

	quick_actions[unwield] = true

	local action_condition_func = unwield.action_condition_func

	unwield.action_condition_func = function (action_settings, condition_func_params, used_input, ...)
		local ability_extension = _ability_extension_of(condition_func_params)

		if _keep_launcher(ability_extension) and ability_extension:remaining_ability_charges(GRENADE_ABILITY_TYPE) > 0 then
			return false
		end

		if action_condition_func then
			return action_condition_func(action_settings, condition_func_params, used_input, ...)
		end

		return true
	end

	if shoot.total_time == math.huge then
		shoot.total_time = KEEP_SHOT_END
	end

	local chains = shoot.allowed_chain_actions

	chains.shoot_charge = chains.shoot_charge or {
		action_name = "action_charge_direct",
		chain_time = KEEP_REFIRE_TIME,
	}
	chains.brace_charge = chains.brace_charge or {
		action_name = "action_charge_brace",
		chain_time = KEEP_REFIRE_TIME,
	}

	if not chains.wield then
		local ok, BaseTemplateSettings = pcall(require, "scripts/settings/equipment/weapon_templates/base_template_settings")

		if ok and BaseTemplateSettings.generate_wield_chain_actions then
			chains.wield = BaseTemplateSettings.generate_wield_chain_actions({
				chain_time = KEEP_SWAP_TIME,
			})
		end
	end
end

mod:hook_require("scripts/settings/equipment/weapon_templates/weapon_templates", function (WeaponTemplates)
	if type(WeaponTemplates[MISSILE_WEAPON_TEMPLATE]) == "table" then
		_patch_missile_launcher(WeaponTemplates[MISSILE_WEAPON_TEMPLATE])
	end

	for _, weapon_template in pairs(WeaponTemplates) do
		local actions = type(weapon_template) == "table" and weapon_template.actions

		if type(actions) == "table" then
			local quick_action = actions[QUICK_ACTION]

			if type(quick_action) == "table" and quick_action.ability_type_func and quick_action.override_origin_slot_func and quick_action.action_condition_func then
				_patch_quick_action(quick_action)
			end

			for _, action in pairs(actions) do
				if type(action) == "table" and action.kind == "unwield" and action.start_input == "wield" and action.action_condition_func then
					_patch_unwield_action(action)
				end
			end
		end
	end
end)

-- The missile item and the launcher's voice line for the hand throw: set on
-- the shared action for the length of the start call only.
mod:hook_require("scripts/extension_systems/weapon/actions/action_spawn_projectile", function (ActionSpawnProjectile)
	mod:hook(ActionSpawnProjectile, "start", function (func, self, action_settings, ...)
		if not (quick_actions[action_settings] and _quick_missile(self._ability_extension)) then
			return func(self, action_settings, ...)
		end

		local projectile_item, vo_tag = action_settings.projectile_item, action_settings.vo_tag

		action_settings.projectile_item = MISSILE_ITEM
		action_settings.vo_tag = MISSILE_VO_TAG

		local ok, err = pcall(func, self, action_settings, ...)

		action_settings.projectile_item = projectile_item
		action_settings.vo_tag = vo_tag

		if not ok then
			error(err, 0)
		end
	end)
end)

local function _max_time_scale()
	local ok, max = pcall(function ()
		return NetworkConstants.action_time_scale.max
	end)

	return ok and type(max) == "number" and max or nil
end

mod:hook_require("scripts/utilities/action/action_handler", function (ActionHandler)
	mod:hook(ActionHandler, "_calculate_time_scale", function (func, self, action_settings)
		local time_scale = func(self, action_settings)
		local ability_extension = self._ability_extension

		if not (ability_extension and _has_missile_launcher(ability_extension) and _local_hosted_player(ability_extension._player)) then
			return time_scale
		end

		local inventory = self._inventory_component
		local speed = _setting_number("missile_draw_speed", 10)
		local fast = false

		if quick_actions[action_settings] then
			fast = action_settings.kind == "spawn_projectile" and _quick_missile(ability_extension)
		elseif inventory and inventory.wielded_slot == GRENADE_SLOT then
			-- The launcher itself: its draw and its shot (which puts it away
			-- 1.45 s in, missile_launcher.lua action_shoot_hip).
			fast = WIELD_KINDS[action_settings.kind] or action_settings.kind == "shoot_projectile"
		elseif inventory and inventory.previously_wielded_slot == GRENADE_SLOT and WIELD_KINDS[action_settings.kind] then
			-- The weapon you go back to after the launcher.
			fast = true
		end

		if fast and speed > 1 then
			time_scale = time_scale * speed

			local max = _max_time_scale()

			if max then
				time_scale = math.min(time_scale, max)
			end
		end

		return time_scale
	end)
end)
