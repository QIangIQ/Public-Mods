return {
	missile_keep_in_hand = {
		en = "Keep the launcher in hand",
	},
	missile_keep_in_hand_description = {
		en = "The launcher stays up after a shot, so you can fire all your missiles in a row like an RPG. It is put away when it runs out, or when you switch weapons.",
	},
	missile_from_hand = {
		en = "Fire missiles from the left hand",
	},
	missile_from_hand_description = {
		en = "Instead of drawing the launcher, the blitz key fires a missile with Hive Scum's left-hand quick throw while your weapon stays in your right hand, the way the quick flash grenade works. Off: the launcher is drawn as usual.",
	},
	missile_draw_speed = {
		en = "Missile speed-up (x)",
	},
	missile_draw_speed_description = {
		en = "How many times faster the left-hand throw, the launcher's draw and put away, and the draw of the weapon you go back to run. 10: the throw is over in about 55 ms (the game's is 0.55 s). The game may cap it lower.",
	},
	missile_charges = {
		en = "Missile launcher charges",
	},
	missile_charges_description = {
		en = "How many missiles the launcher holds. The game's is 2. Talents that add grenades still add on top.",
	},
	missile_regen_time = {
		en = "Missile recharge (seconds per missile)",
	},
	missile_regen_time_description = {
		en = "One missile comes back every this many seconds until the launcher is full. 0: off.",
	},
	missile_enemy_damage = {
		en = "Missile damage to enemies (percent)",
	},
	missile_enemy_damage_description = {
		en = "Damage the missile's blast and hit deal to enemies, in percent of the game's. Stagger stays the same.",
	},
	mod_name = {
		en = "QIangIQ's Rocket Jump",
	},
	mod_description = {
		en = "Hive Scum's missile launcher blast throws you, TF2 Soldier style, and never hurts you. Shoot the floor at your feet to go up, a wall to go sideways. You keep full air control, and the speed you already have is kept, so the second rocket stacks on the first. The launcher holds 10 missiles, gets one back every 15 seconds, and deals half damage to enemies (all in the options). Works where the game runs on your machine (solo, your own Realms game); on Fatshark's servers nothing changes.",
	},
	launch_strength = {
		en = "Launch strength (percent)",
	},
	launch_strength_description = {
		en = "100 percent is the game's own close Poxburster blast (13 m/s away from the blast, 8 m/s up): about 2.7 m up. 150 percent is about 6 m up and 2 seconds in the air. The push gets weaker past the blast's inner radius and stops at its edge.",
	},
	no_fall_damage = {
		en = "No fall damage after a rocket jump",
	},
	no_fall_damage_description = {
		en = "From a rocket jump until you land, falls do not hurt you.",
	},
}
