local mod = get_mod("QIangIQsRocketJump")

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			{
				setting_id = "launch_strength",
				type = "numeric",
				default_value = 150,
				range = { 50, 300 },
				decimals_number = 0,
				tooltip = "launch_strength_description",
			},
			{
				setting_id = "no_fall_damage",
				type = "checkbox",
				default_value = true,
				tooltip = "no_fall_damage_description",
			},
			{
				setting_id = "missile_charges",
				type = "numeric",
				default_value = 10,
				range = { 1, 20 },
				decimals_number = 0,
				tooltip = "missile_charges_description",
			},
			{
				setting_id = "missile_regen_time",
				type = "numeric",
				default_value = 15,
				range = { 0, 60 },
				decimals_number = 0,
				tooltip = "missile_regen_time_description",
			},
			{
				setting_id = "missile_enemy_damage",
				type = "numeric",
				default_value = 50,
				range = { 10, 100 },
				decimals_number = 0,
				tooltip = "missile_enemy_damage_description",
			},
			{
				setting_id = "missile_keep_in_hand",
				type = "checkbox",
				default_value = true,
				tooltip = "missile_keep_in_hand_description",
			},
			{
				setting_id = "missile_from_hand",
				type = "checkbox",
				default_value = false,
				tooltip = "missile_from_hand_description",
			},
			{
				setting_id = "missile_draw_speed",
				type = "numeric",
				default_value = 10,
				range = { 1, 20 },
				decimals_number = 0,
				tooltip = "missile_draw_speed_description",
			},
		},
	},
}
