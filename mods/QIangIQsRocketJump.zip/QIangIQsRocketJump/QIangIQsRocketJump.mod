return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsRocketJump` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsRocketJump", {
			mod_script       = "QIangIQsRocketJump/scripts/mods/QIangIQsRocketJump/QIangIQsRocketJump",
			mod_data         = "QIangIQsRocketJump/scripts/mods/QIangIQsRocketJump/QIangIQsRocketJump_data",
			mod_localization = "QIangIQsRocketJump/scripts/mods/QIangIQsRocketJump/QIangIQsRocketJump_localization",
		})
	end,
	packages = {},
}
