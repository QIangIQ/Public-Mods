return {
	mod_name = {
		en = "QIangIQ's Outro Weapon Fix",
	},
	mod_description = {
		en = "Stops the end-of-mission elevator cutscene crash when a player carries a weapon from another class (for example with realms_loadout's Remove Weapon Career Restrictions). Every player in the lobby needs it, since each game plays the cutscene itself.",
	},
}
