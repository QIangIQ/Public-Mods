local mod = get_mod("QIangIQsOutroWeaponFix")

-- Crash this fixes (outro_win_elevator, 6 players, one zealot):
--   cutscene_character_extension.lua:387: animation_event failed, state machine
--   (inventory_zealot) does not have an event with name ...
--
-- _start_inventory_specific_walk_animation (cutscene_character_extension.lua:376-393)
-- switches the character to its class's inventory state machine and plays the
-- equipped weapon's inventory_animation_event without checking it exists. A weapon
-- from another class has no event in that class's state machine, so the engine
-- errors. The weapon version of the same function already guards its call with
-- Unit.has_animation_event (line 349); this applies that same guard here. The
-- body is otherwise the game's own code, unchanged.

local CutsceneCharacterExtension = require("scripts/extension_systems/cutscene_character/cutscene_character_extension")

-- STATE_MACHINE_TYPES is local to the game file (cutscene_character_extension.lua:13-17):
-- none = 0, inventory = 1, weapon = 2.
local INVENTORY = 1

local function play_if_present(unit, event)
	if event and Unit.has_animation_event(unit, event) then
		Unit.animation_event(unit, event)
	end
end

mod:hook(CutsceneCharacterExtension, "_start_inventory_specific_walk_animation", function (func, self)
	local unit = self._unit

	if self._current_state_machine_type ~= INVENTORY then
		local archetype = self._profile.archetype
		local inventory_state_machine = archetype.inventory_state_machine

		Unit.set_animation_state_machine(unit, inventory_state_machine)
		Unit.enable_animation_state_machine(unit)
		play_if_present(unit, self._equipped_weapon and self._equipped_weapon.inventory_animation_event)

		self._current_state_machine_type = INVENTORY
	end

	if self._inventory_animation_event ~= "unready_idle" then
		play_if_present(unit, self._inventory_animation_event)
	end
end)
