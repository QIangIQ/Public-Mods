local mod = get_mod("QIangIQsOutroWeaponFix")

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
}
