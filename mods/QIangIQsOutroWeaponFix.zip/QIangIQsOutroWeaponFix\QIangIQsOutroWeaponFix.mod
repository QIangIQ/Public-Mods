return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsOutroWeaponFix` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsOutroWeaponFix", {
			mod_script       = "QIangIQsOutroWeaponFix/scripts/mods/QIangIQsOutroWeaponFix/QIangIQsOutroWeaponFix",
			mod_data         = "QIangIQsOutroWeaponFix/scripts/mods/QIangIQsOutroWeaponFix/QIangIQsOutroWeaponFix_data",
			mod_localization = "QIangIQsOutroWeaponFix/scripts/mods/QIangIQsOutroWeaponFix/QIangIQsOutroWeaponFix_localization",
		})
	end,
	packages = {},
}
