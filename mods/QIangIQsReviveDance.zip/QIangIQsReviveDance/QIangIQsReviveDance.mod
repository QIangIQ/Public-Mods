return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsReviveDance` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsReviveDance", {
            mod_script = "QIangIQsReviveDance/scripts/mods/QIangIQsReviveDance/QIangIQsReviveDance",
            mod_data = "QIangIQsReviveDance/scripts/mods/QIangIQsReviveDance/QIangIQsReviveDance_data",
            mod_localization = "QIangIQsReviveDance/scripts/mods/QIangIQsReviveDance/QIangIQsReviveDance_localization",
        })
    end,
    version = "0.1.0",
    author = "QIangIQ",
    load_after = { "CustomAssets" },
    packages = {},
}
