-- QIangIQ's Revive Dance: while you revive a teammate, your character dances California Gurls.
--
-- How (taken from QIangIQ's Emotes 1.13.3, revive dance and custom dances; game source line references):
--   * The revive is the "interacting" character state with interaction template "revive" (interaction_templates.lua,
--     player_character_state_interacting.lua). "rescue" frees a hogtied player (rescue_interaction.lua). Both
--     templates use the third-person camera, so the dance is visible.
--   * The dance is a skeleton-only "driver" unit (Custom Assets unit, folder Custom/revive_calgurls) that plays the
--     clip as its simple animation (Unit.play_simple_animation). The driver is linked to the player unit, and the body
--     units are linked to the driver by node name while the dance plays. The game's own body is not touched: it still
--     plays the revive animation underneath, without the parts that were moved to the driver.
--   * Body units: the QIangIQ character models keep theirs on the visual loadout extension as __qiangiq_<key>_unit and
--     __qiangiq_<key>_parts. A standard character uses the game's own slot_body_* / slot_gear_* units
--     (equipment_component.lua, linked by visual_loadout_customization.lua _spawn_attachment). Each gear unit is moved
--     with its item's own attach node and link_map_mode, so a backpack follows the dance too.
--   * Only you see the dance. Nothing is sent over the network.
--
-- Optional, never required: SimpleAudio (music from your own file), QIangIQsArmoryVis (0.2.0: its stowed weapon copies
-- hang on the dancing driver, so they move with the dance). If QIangIQ's Emotes is loaded with its own revive dance on, this mod does nothing.
-- No physics queries are made anywhere in this mod.
-- Author: QIangIQ
local mod = get_mod("QIangIQsReviveDance")

mod.AUTHOR = "QIangIQ"
mod.version = "0.2.0"

local ASSET_ID = "QIangIQsReviveDance:revive_calgurls"
local DRIVER_UNIT = "content/mods/qiangiq_revive_dance/revive_calgurls"
local MUSIC_DIR = "mods/QIangIQsReviveDance/audio/"
local MUSIC_NAME = "calgurls"
local MUSIC_EXTENSIONS = { "ogg", "mp3", "wav", "flac" }
local MUSIC_MIN_DISTANCE = 5
local MUSIC_MAX_DISTANCE = 40
-- Backpacks and the like whose attach node is not on the driver follow the nearest spine bone of the driver
local FALLBACK_ATTACH_NODES = { "j_spine2", "j_spine1", "j_spine", "j_hips" }

local custom_assets = nil
local driver_ready = false
local driver_requested = false
local dancing = {} -- [player unit] = { driver, bodies, body_nodes, driver_nodes, body_modes, ext, standard, music }
local logged_gear = false
local said_no_assets = false

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function in_gameplay()
    return Managers.state ~= nil and Managers.state.unit_spawner ~= nil
end

local function level_world()
    return Managers.world and Managers.world:world("level_world")
end

local function local_player()
    local players = Managers.player
    if not players then
        return nil
    end
    local ok, player = pcall(players.local_player_safe, players, 1)
    return ok and player or nil
end

local function my_unit(unit)
    local player = local_player()
    return player ~= nil and unit ~= nil and player.player_unit == unit
end

-- QIangIQ's Emotes has the same revive dance: do not dance twice
local function emotes_has_revive_dance()
    local emotes = get_mod("QIangIQsEmotes")
    if not emotes or type(emotes.get) ~= "function" then
        return false
    end
    if type(emotes.is_enabled) == "function" and not emotes:is_enabled() then
        return false
    end
    return emotes:get("revive_dance") ~= false
end

-- Driver unit -------------------------------------------------------------------------------

local function request_driver()
    if driver_ready or driver_requested then
        return
    end
    custom_assets = custom_assets or get_mod("CustomAssets")
    if not custom_assets or not custom_assets.is_api_compatible or not custom_assets.is_api_compatible(1) then
        if not said_no_assets then
            said_no_assets = true
            mod:info("Custom Assets (API 1) not found: the revive dance is off.")
        end
        return
    end
    driver_requested = true
    local ticket, err = custom_assets.acquire(mod, ASSET_ID, function(_, _, load_error)
        if load_error then
            driver_requested = false
            mod:error("%s failed to load: %s (run the Custom Assets patcher with the game closed)", ASSET_ID, tostring(load_error))
            return
        end
        driver_ready = true
    end, { resident = true, reference_name = ASSET_ID })
    if not ticket then
        driver_requested = false
        mod:error("%s could not be requested: %s (run the Custom Assets patcher with the game closed)", ASSET_ID, tostring(err))
    end
end

-- Body units --------------------------------------------------------------------------------

local function model_units(unit)
    local ext = ScriptUnit.has_extension(unit, "visual_loadout_system")
    local found = {}
    if ext then
        for key, value in pairs(ext) do
            if type(key) == "string" then
                if string.find(key, "^__qiangiq_.+_unit$") then
                    if unit_ok(value) then
                        found[#found + 1] = value
                    end
                elseif string.find(key, "^__qiangiq_.+_parts$") and type(value) == "table" then
                    for _, part in pairs(value) do
                        if unit_ok(part) then
                            found[#found + 1] = part
                        end
                    end
                end
            end
        end
    end
    return found, ext
end

local function is_body_slot(name)
    return type(name) == "string" and (string.find(name, "^slot_body_") ~= nil or string.find(name, "^slot_gear_") ~= nil)
end

-- the game's own body and gear units, their items and link map modes (World[item.link_map_mode], else node name)
local function standard_body_units(unit)
    local ext = ScriptUnit.has_extension(unit, "visual_loadout_system")
    local equipment = ext and ext._equipment
    local found, items, modes = {}, {}, {}
    if equipment then
        for name, slot in pairs(equipment) do
            if is_body_slot(name) and unit_ok(slot.unit_3p) then
                local item = slot.item
                local map_mode = item and item.link_map_mode and World[item.link_map_mode]
                found[#found + 1] = slot.unit_3p
                items[#items + 1] = item
                modes[#modes + 1] = map_mode or World.LINK_MODE_NODE_NAME
            end
        end
    end
    return found, items, ext, modes
end

-- node of `parent` the item links to (visual_loadout_customization.lua _spawn_attachment); nil = not on this unit
local function attach_index(parent, item, breed_name)
    local node = item and ((item.breed_attach_node and item.breed_attach_node[breed_name]) or item.attach_node)
    if node == nil or node == "" then
        return 1
    end
    if tonumber(node) ~= nil then
        return tonumber(node)
    end
    if Unit.has_node(parent, node) then
        return Unit.node(parent, node)
    end
    return nil
end

local function fallback_attach_index(parent)
    for i = 1, #FALLBACK_ATTACH_NODES do
        if Unit.has_node(parent, FALLBACK_ATTACH_NODES[i]) then
            return Unit.node(parent, FALLBACK_ATTACH_NODES[i])
        end
    end
    return nil
end

-- weapons and other equipment stay on the body that does not dance: hidden for the dance.
-- keep_body: a standard character dances with the game's body and gear units, so those stay visible.
local function hide_equipment(ext, keep_body)
    local equipment = ext and ext._equipment
    if not equipment then
        return
    end
    for name, slot in pairs(equipment) do
        local unit = slot.unit_3p
        if unit_ok(unit) and not (keep_body and is_body_slot(name)) then
            Unit.set_unit_visibility(unit, false, true)
            local attachments = slot.attachments_by_unit_3p and slot.attachments_by_unit_3p[unit]
            if attachments then
                for i = 1, #attachments do
                    if unit_ok(attachments[i]) then
                        Unit.set_unit_visibility(attachments[i], false, true)
                    end
                end
            end
        end
    end
end

-- Music (optional, SimpleAudio) ---------------------------------------------------------------

local function simple_audio()
    local sa = get_mod("SimpleAudio")
    if sa and type(sa.play_file) == "function" and type(sa.stop_file) == "function" and type(sa.file_info) == "function" then
        return sa
    end
    return nil
end

local music_path = nil
local music_checked = false

local function find_music(sa)
    if music_checked then
        return music_path
    end
    music_checked = true
    for i = 1, #MUSIC_EXTENSIONS do
        local path = MUSIC_DIR .. MUSIC_NAME .. "." .. MUSIC_EXTENSIONS[i]
        local ok, info = pcall(sa.file_info, path)
        if ok and type(info) == "table" then
            music_path = path
            return path
        end
    end
    return nil
end

local function start_music(unit, data)
    if mod:get("music") == false then
        return
    end
    local sa = simple_audio()
    local path = sa and find_music(sa)
    if not path then
        return
    end
    local settings = {
        audio_type = "music",
        volume = tonumber(mod:get("music_volume")) or 100,
        loop = true,
    }
    local ok, play_id = pcall(sa.play_file, path, settings, unit, 0, MUSIC_MIN_DISTANCE, MUSIC_MAX_DISTANCE)
    if ok and play_id then
        data.music = play_id
    end
end

local function stop_music(data)
    local play_id = data.music
    data.music = nil
    if play_id then -- never stop_file(nil): that stops the files of every mod
        local sa = simple_audio()
        if sa then
            pcall(sa.stop_file, play_id)
        end
    end
end

-- Dance -------------------------------------------------------------------------------------

-- QIangIQsArmoryVis (optional): its stowed weapon copies hang on ext.__qiangiq_body_host when that unit is alive
-- (QIangIQsArmoryVis_holster.lua Holster.host), on the same node names. The driver has the full skeleton, so the copies
-- dance with the body. Before the driver is deleted the old host is put back and release_host(ext) moves the copies
-- off it (QIangIQsArmoryVis.lua mod.release_host), as QIangIQsOraxia does for its floating form.
local function set_body_host(ext, driver)
    if not ext then
        return nil
    end
    local previous = ext.__qiangiq_body_host
    ext.__qiangiq_body_host = driver
    return previous
end

local function release_body_host(ext, driver, previous)
    if not ext or ext.__qiangiq_body_host ~= driver then
        return
    end
    ext.__qiangiq_body_host = (previous ~= nil and Unit.alive(previous)) and previous or nil
    local armory_vis = get_mod("QIangIQsArmoryVis")
    if armory_vis and type(armory_vis.release_host) == "function" then
        pcall(armory_vis.release_host, ext)
    end
end

local function end_dance(unit, data)
    stop_music(data)
    local world = level_world()
    if world then
        for i = 1, #data.bodies do
            local body = data.bodies[i]
            if unit_ok(body) then
                -- always off the driver first: it is deleted below
                World.unlink_unit(world, body)
                if unit_ok(unit) then
                    World.link_unit(world, body, 1, unit, data.body_nodes and data.body_nodes[i] or 1,
                        data.body_modes and data.body_modes[i] or World.LINK_MODE_NODE_NAME)
                end
            end
        end
    end
    release_body_host(data.ext, data.driver, data.previous_host)
    if unit_ok(data.driver) then
        local unit_spawner = Managers.state and Managers.state.unit_spawner
        if unit_spawner then
            unit_spawner:mark_for_deletion(data.driver)
        end
    end
    if unit_ok(unit) and data.ext and data.ext.force_update_item_visibility then
        data.ext:force_update_item_visibility()
    end
end

local function stop_dance(unit)
    local data = dancing[unit]
    if not data then
        return
    end
    dancing[unit] = nil
    end_dance(unit, data)
end

local function start_dance(unit)
    if not driver_ready then
        request_driver()
        return false
    end
    local world = level_world()
    local unit_spawner = Managers.state and Managers.state.unit_spawner
    if not (unit_ok(unit) and in_gameplay() and world and unit_spawner) then
        return false
    end
    local unit_data_extension = ScriptUnit.has_extension(unit, "unit_data_system")
    if not unit_data_extension or unit_data_extension:breed_name() == "ogryn" then
        return false -- the dance is made for the human skeleton
    end
    if dancing[unit] then
        stop_dance(unit)
    end
    local bodies, ext = model_units(unit)
    local standard_items, standard_modes = nil, nil
    if #bodies == 0 then
        bodies, standard_items, ext, standard_modes = standard_body_units(unit)
        if #bodies == 0 then
            return false
        end
    end
    local driver = unit_spawner:spawn_unit(DRIVER_UNIT, Unit.world_pose(unit, 1))
    if not driver then
        return false
    end
    local body_nodes, driver_nodes, body_modes = nil, nil, nil
    if standard_items then
        local breed_name = unit_data_extension:breed_name()
        local kept, kept_nodes, kept_driver_nodes, kept_modes = {}, {}, {}, {}
        for i = 1, #bodies do
            -- own == nil: the attach node is on another unit (the game searches the child units); the gear follows
            -- that unit, so it is not moved
            local own = attach_index(unit, standard_items[i], breed_name)
            local on_driver = own and (attach_index(driver, standard_items[i], breed_name) or fallback_attach_index(driver))
            if own and on_driver then
                kept[#kept + 1] = bodies[i]
                kept_nodes[#kept_nodes + 1] = own
                kept_driver_nodes[#kept_driver_nodes + 1] = on_driver
                kept_modes[#kept_modes + 1] = standard_modes[i]
            end
            if not logged_gear then
                local item = standard_items[i]
                mod:info("dance gear: %s attach_node=%s link_map_mode=%s on_player=%s on_driver=%s", tostring(item and item.name),
                    tostring(item and ((item.breed_attach_node and item.breed_attach_node[breed_name]) or item.attach_node)),
                    tostring(item and item.link_map_mode), tostring(own), tostring(on_driver))
            end
        end
        logged_gear = true
        bodies, body_nodes, driver_nodes, body_modes = kept, kept_nodes, kept_driver_nodes, kept_modes
        if #bodies == 0 then
            unit_spawner:mark_for_deletion(driver)
            return false
        end
    end
    World.link_unit(world, driver, 1, unit, 1)
    for i = 1, #bodies do
        World.unlink_unit(world, bodies[i])
        World.link_unit(world, bodies[i], 1, driver, driver_nodes and driver_nodes[i] or 1,
            body_modes and body_modes[i] or World.LINK_MODE_NODE_NAME)
    end
    Unit.play_simple_animation(driver, 0, nil, true, 1)
    local data = {
        driver = driver,
        bodies = bodies,
        body_nodes = body_nodes,
        body_modes = body_modes,
        ext = ext,
        standard = standard_items ~= nil,
    }
    data.previous_host = set_body_host(ext, driver)
    dancing[unit] = data
    if mod:get("hide_weapons") ~= false then
        hide_equipment(ext, data.standard)
    end
    start_music(unit, data)
    return true
end

local function stop_all()
    for unit in pairs(dancing) do
        stop_dance(unit)
    end
end

-- Hooks -------------------------------------------------------------------------------------

local REVIVE_TEMPLATES = { revive = true, rescue = true }

mod:hook_safe(CLASS.PlayerCharacterStateInteracting, "on_enter", function(self, unit, dt, t, previous_state, params)
    if not mod:is_enabled() or not my_unit(unit) or emotes_has_revive_dance() then
        return
    end
    local interaction_component = self._interaction_component
    local template = interaction_component and interaction_component.type
    if not (template and REVIVE_TEMPLATES[template]) then
        return
    end
    if template == "rescue" and mod:get("dance_on_rescue") == false then
        return
    end
    if dancing[unit] then
        return
    end
    local ok, err = pcall(start_dance, unit)
    if not ok then
        mod:error("Revive dance could not start: %s", tostring(err))
    end
end)

mod:hook_safe(CLASS.PlayerCharacterStateInteracting, "on_exit", function(self, unit, t, next_state)
    if dancing[unit] then
        stop_dance(unit)
    end
end)

-- the game shows the equipment again whenever it updates item visibility: keep it hidden during the dance
for _, class_name in ipairs({ "PlayerUnitVisualLoadoutExtension", "PlayerHuskVisualLoadoutExtension" }) do
    mod:hook_safe(CLASS[class_name], "_update_item_visibility", function(self)
        local data = self._unit and dancing[self._unit]
        if data and mod:get("hide_weapons") ~= false then
            hide_equipment(self, data.standard)
        end
    end)
end

-- Update and lifecycle ----------------------------------------------------------------------

mod.update = function(dt)
    if next(dancing) == nil then
        return
    end
    for unit in pairs(dancing) do
        local data = dancing[unit]
        if not unit_ok(unit) then
            dancing[unit] = nil
            end_dance(unit, data)
        else
            -- the revive state ended without on_exit (safety): stop
            local unit_data_extension = ScriptUnit.has_extension(unit, "unit_data_system")
            local character_state = unit_data_extension and unit_data_extension:read_component("character_state")
            if not character_state or character_state.state_name ~= "interacting" then
                stop_dance(unit)
            end
        end
    end
end

-- true while the revive dance plays on this unit and weapons are hidden
mod.is_dancing = function(unit)
    return unit ~= nil and dancing[unit] ~= nil and mod:get("hide_weapons") ~= false
end

mod.on_all_mods_loaded = function()
    request_driver()
end

mod.on_setting_changed = function(setting_id)
    if setting_id == "music" or setting_id == "music_volume" then
        music_checked = false
        music_path = nil
    end
end

-- the bodies are gone with the level: forget them (the driver package stays loaded for the next mission)
mod.on_game_state_changed = function(status, state_name)
    if state_name == "StateGameplay" and status == "exit" then
        for _, data in pairs(dancing) do
            stop_music(data)
            if data.ext and data.ext.__qiangiq_body_host == data.driver then
                data.ext.__qiangiq_body_host = nil
            end
        end
        dancing = {}
    end
end

mod.on_disabled = function()
    if in_gameplay() then
        stop_all()
    end
end

mod.on_unload = function()
    stop_all()
    if custom_assets and custom_assets.release_owner then
        custom_assets.release_owner(mod)
    end
end
