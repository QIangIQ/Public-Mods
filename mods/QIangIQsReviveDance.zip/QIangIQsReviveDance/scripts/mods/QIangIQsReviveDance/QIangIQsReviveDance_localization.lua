return {
    mod_name = {
        en = "QIangIQ's Revive Dance",
    },
    mod_description = {
        en = "While you revive a teammate, your character dances California Gurls instead of the revive animation. Only you see it. Needs Custom Assets (run its patcher once with the game closed). By QIangIQ.",
    },
    dance_on_rescue = {
        en = "Also dance when you free a hogtied teammate",
    },
    dance_on_rescue_description = {
        en = "On: the dance also plays while you free a hogtied teammate. Off: only while you revive.",
    },
    hide_weapons = {
        en = "Hide weapons during the dance",
    },
    hide_weapons_description = {
        en = "Your weapons stay on the body that does not dance. On: they are hidden until the dance ends.",
    },
    music = {
        en = "Play music",
    },
    music_description = {
        en = "Needs the SimpleAudio mod and your own music file: mods/QIangIQsReviveDance/audio/calgurls.ogg (or .mp3, .wav, .flac). The mod ships no music.",
    },
    music_volume = {
        en = "Music volume (%)",
    },
    music_volume_description = {
        en = "100 = the loudness of the file. The game's master and music volume also apply.",
    },
}
