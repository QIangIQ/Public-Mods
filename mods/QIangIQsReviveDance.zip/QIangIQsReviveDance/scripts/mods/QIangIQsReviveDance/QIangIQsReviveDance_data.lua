local mod = get_mod("QIangIQsReviveDance")

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = true,
    options = {
        widgets = {
            {
                setting_id = "dance_on_rescue",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "hide_weapons",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "music",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "music_volume",
                type = "numeric",
                default_value = 100,
                range = { 0, 200 },
            },
        },
    },
}
