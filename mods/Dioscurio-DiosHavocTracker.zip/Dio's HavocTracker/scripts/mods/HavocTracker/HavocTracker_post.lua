local mod = get_mod("HavocTracker")

--[[
    CHAT OUTPUT
    ===========

    Posts the tracker readout to chat in a single readable line.

    The delivery half is PORTED VERBATIM from HavocPost (HavocPost.lua:72-113,
    try_send / send_team_chat). That code is not obvious and not guessable: the
    chat manager's API varies across builds, so it tries
    send_channel_message with two different arities, then three alternative
    method names, then walks the session table looking for a party/strike-team
    channel by four possible tag fields, then falls back to brute-forcing
    handles 1-4. Every one of those branches exists because a build needed it.
    Writing my own would mean rediscovering all of that from failures in
    someone's live match.

    The message FORMAT follows HavocPost's shape too - parts joined with " | " -
    because it reads well in the chat line width and the user already knows how
    to scan it.

    SENDING IS THE POINT. The toggle posts to STRIKE TEAM chat so the whole
    team can read it - that is what the feature is for.

    I originally defaulted this to console-preview on the reasoning that
    writing into a shared channel should be opt-in. That was me substituting my
    caution for the stated intent: a tracker readout nobody else can see is not
    a team tool. The master toggle now sends.

    chat_post_preview remains as an opt-in TESTING mode for checking the format
    without posting, which is the case that actually wanted a switch.
--]]

local Post = {}

local STR = {
    no_chat     = "[HavocTracker] no chat manager - cannot post",
    send_failed = "[HavocTracker] could not find a chat channel to post to",
    posted_ok   = "[HavocTracker] posted to team chat",
}

-- ---------------------------------------------------------------------------
-- BEGIN PORTED CODE - dmgtochat (dmgtochat.lua:13-34, 112)
-- ---------------------------------------------------------------------------

--[[
    CHANNEL HANDLE CAPTURE. This replaces HavocPost's delivery, and it is a
    better mechanism rather than merely a different one.

    HavocPost GUESSES: it tries send_channel_message at two arities, three
    alternative method names, walks the session table matching four possible
    tag fields, then brute-forces handles 1 through 4. Every branch exists
    because a build needed it - but the whole cascade is working around not
    knowing the handle.

    dmgtochat does not guess. It hooks the chat element's own connect events
    and keeps whatever handle the GAME is using for the currently connected
    channel:

        ConstantElementChat._on_connect_to_channel
        ConstantElementChat._on_disconnect_from_channel
        ConstantElementChat._next_connected_channel_handle

    then simply Managers.chat:send_channel_message(handle, msg).

    That is the strike team channel you are looking at, by construction. It
    also follows you if you switch channels, which the session-walking approach
    cannot.

    mod:persistent_table survives a mod reload, so the handle is not lost when
    you reload mods mid-session.
--]]
local memory = mod:persistent_table("HavocTracker_post")
memory.channel_handle = memory.channel_handle or nil

local function get_channel_handle(self, channel_handle)
    memory.channel_handle = channel_handle or self._selected_channel_handle
end

mod:hook_safe("ConstantElementChat", "_on_connect_to_channel",         get_channel_handle)
mod:hook_safe("ConstantElementChat", "_on_disconnect_from_channel",    get_channel_handle)
mod:hook_safe("ConstantElementChat", "_next_connected_channel_handle", get_channel_handle)

-- ---------------------------------------------------------------------------
-- END PORTED CODE
-- ---------------------------------------------------------------------------

--[[
    Send, with HavocPost's cascade kept only as a fallback.

    The captured handle is the right answer. The fallback covers the window
    before any connect event has fired - joining a mission in progress, or
    posting before the chat element has initialised - where the handle is still
    nil and guessing beats doing nothing.
--]]
local function try_send(chat_mgr, handle, message)
    if type(chat_mgr.send_channel_message) == "function" then
        if pcall(chat_mgr.send_channel_message, chat_mgr, handle, message) then return true end
        if pcall(chat_mgr.send_channel_message, chat_mgr, handle, message, false) then return true end
    end
    for _, method in ipairs({"send_message", "send_chat_message", "broadcast_message"}) do
        if type(chat_mgr[method]) == "function" then
            if pcall(chat_mgr[method], chat_mgr, handle, message) then return true end
        end
    end
    return false
end

local function send_team_chat(message)
    local chat_mgr = Managers.chat

    if not chat_mgr then
        mod:echo(STR.no_chat)
        return false
    end

    -- The captured handle first. This is the normal path.
    local handle = memory.channel_handle

    if handle and try_send(chat_mgr, handle, message) then
        return true
    end

    -- Fallback: no handle captured yet.
    local sessions = rawget(chat_mgr, "_sessions") or rawget(chat_mgr, "sessions")

    if type(sessions) == "table" then
        for h in pairs(sessions) do
            if try_send(chat_mgr, h, message) then return true end
        end
    end

    for h = 1, 4 do
        if try_send(chat_mgr, h, message) then return true end
    end

    mod:echo(STR.send_failed)
    return false
end

-- ---------------------------------------------------------------------------

--[[
    Build the line, for a reader who is NOT running the mod.

    The previous format was "CAP 31.0/50 standard | E12 O3 S8 H50 | ...". That
    is fine for someone who wrote it and opaque to everyone else - and everyone
    else is the audience, because the whole point of posting to strike team
    chat is that the other three can act on it.

    So: whole words, no single-letter codes, no internal vocabulary. "Pressure"
    rather than "CAP", because a teammate reading it does not need to know
    there is an entity budget - they need to know whether the room is full.

    ELITES ARE FILTERED TO THE RANGED ONES. Gunners, shotgunners, reapers and
    plasma gunners are the threats worth a callout: they apply pressure from
    off-screen and decide where you can stand. Maulers, ragers, bulwarks and
    crushers are melee - already visible, already being fought, and naming them
    spends line length on something nobody acts on.

    Only non-zero groups appear, so the line stays short when little is up
    rather than padding with zeroes.
--]]
function Post.build()
    local cap = mod.Cap and mod.Cap.read()

    if not cap then
        return nil
    end

    local parts = {}

    --[[
        Plain-language pressure. The band word does the work; the number is
        there for anyone who wants it.
    --]]
    local band

    if cap.points >= 65 then
        band = "OVER CAP"
    elseif cap.points >= 50 then
        band = "AT CAP"
    elseif cap.points >= 40 then
        band = "heavy"
    elseif cap.points >= 20 then
        band = "moderate"
    else
        band = "light"
    end

    parts[#parts + 1] = string.format("Pressure %s (%.0f/%d)", band, cap.points, cap.budget)

    --[[
        ELITES, SPLIT BY HOW THEY KILL YOU.

        This used to print only the ranged half, which reads as "that is the
        elite pressure" when it is half of it. Four crushers and four reapers
        are different problems with opposite answers - break line of sight
        versus back off and make room - so a post that cannot tell them apart
        is giving the team half a picture.

        Labelled rather than merely listed, because "6 gunners, 3 crushers" in
        one run-on list makes the reader do the categorising. The prefixes cost
        nine characters and remove that work.

        Non-zero groups only, and the whole clause is dropped when both halves
        are empty - a post that says "0 ranged, 0 melee" is noise.
    --]]
    local function elite_bits(counts, order)
        if not counts or not order then
            return nil
        end

        local bits = {}

        for i = 1, #order do
            local key = order[i]
            local n = counts[key] or 0

            if n > 0 then
                bits[#bits + 1] = string.format("%d %s", n, key)
            end
        end

        return #bits > 0 and table.concat(bits, ", ") or nil
    end

    local ranged_text = elite_bits(mod.Cap.ranged and mod.Cap.ranged(), mod.Cap.RANGED_ORDER)
    local melee_text = elite_bits(mod.Cap.melee_counts and mod.Cap.melee_counts(), mod.Cap.MELEE_ORDER)

    if ranged_text then
        parts[#parts + 1] = "ranged: " .. ranged_text
    end

    if melee_text then
        parts[#parts + 1] = "melee: " .. melee_text
    end

    if (cap.special or 0) > 0 then
        parts[#parts + 1] = string.format("%d specials", cap.special)
    end

    local casc = mod.Cascade and mod.Cascade.read()

    if casc then
        if casc.armed then
            if casc.in_progress then
                parts[#parts + 1] = string.format("wave %d landing now", casc.wave)
            elseif casc.timer and casc.timer > 0 then
                parts[#parts + 1] = string.format("wave %d in %.0fs", casc.wave + 1, casc.timer)
            end
        end

        --[[
            The weakened chance is the one number a teammate can act on
            directly - it tells them whether to expect a beatable monstrosity
            or a full-health one. Worth its words.
        --]]
        if casc.weak_boss then
            parts[#parts + 1] = string.format("weakened boss chance %.0f%%", casc.weak_boss * 100)
        end
    end

    return "[Havoc] " .. table.concat(parts, " | ")
end

--[[
    Post once.

    `live` overrides the setting for a manual command, so /htpost can be told
    to actually send without flipping a setting first.
--]]
function Post.post(force_live)
    local message = Post.build()

    if not message then
        mod:echo("[HavocTracker] nothing to post - not in a mission")
        return false
    end

    --[[
        force_live is for /htpostlive, which sends regardless of the preview
        switch. Otherwise: preview only if explicitly asked for, else send.
    --]]
    local preview = false

    if not force_live then
        preview = mod:get("chat_post_preview") == true
    end

    if preview then
        -- Testing mode: your console only, nothing leaves your client.
        mod:echo("[preview] " .. message)
        return true
    end

    local ok = send_team_chat(message)

    if ok and mod:get("chat_post_status") ~= false then
        mod:echo(STR.posted_ok)
    end

    return ok
end

--[[
    EVENT POSTING - the half that actually matters.

    A timed post tells the team what is true every N seconds. An event post
    tells them the moment something changed, which is when a callout is worth
    reading. Both run; they answer different questions.

    PER-EVENT COOLDOWN, not a global one. A weakened boss and a cap block are
    independent facts, and suppressing one because the other just fired would
    lose information. Each kind has its own clock.

    The DEDUPE on identical text matters more than the cooldown: the cap band
    can flicker across a threshold as bodies die, and posting "CAPPED" four
    times in ten seconds is how a useful feed becomes noise the team mutes.
--]]
local EVENT_COOLDOWN = 8.0

local last_event_t = {}
local last_event_text = {}

function Post.event(kind, text)
    if not kind or not text then
        return false
    end

    if mod:get("chat_post_events") ~= true then
        return false
    end

    local t = now_seconds()
    local last = last_event_t[kind]

    if last and t - last < EVENT_COOLDOWN then
        return false
    end

    -- Same message as last time for this kind: nothing changed, say nothing.
    if last_event_text[kind] == text then
        return false
    end

    last_event_t[kind] = t
    last_event_text[kind] = text

    local message = "[Havoc] " .. text

    if mod:get("chat_post_preview") == true then
        mod:echo("[preview] " .. message)
        return true
    end

    return send_team_chat(message)
end

--[[
    Watch for the events worth calling out.

    Driven from the same board tick as everything else. Each check is a
    comparison against the previous tick's value, so this costs a handful of
    table reads at 4Hz.
--]]
local prev = {}

function Post.check_events()
    if mod:get("chat_post_events") ~= true then
        return
    end

    local cap = mod.Cap and mod.Cap.read()
    local casc = mod.Cascade and mod.Cascade.read()

    if cap then
        --[[
            Band CHANGES, not band state. "standard" every ten seconds is
            noise; crossing into capped is the callout.
        --]]
        local band

        if cap.points >= 65 then band = "OVER CAP"
        elseif cap.points >= 50 then band = "AT CAP"
        end

        --[[
            Only the two states a teammate can act on. "heavy" is information;
            "at cap" is a decision - it means killing things is what unblocks
            the next spawn, and pushing forward will not.
        --]]
        if band and band ~= prev.band then
            Post.event("band", band == "OVER CAP"
                and "Entity cap EXCEEDED - spawns are being blocked"
                or "Entity cap reached - nothing new spawns until things die")
        end

        prev.band = band
    end

    if casc then
        -- A weakened monstrosity actually arriving.
        if (casc.weak_spawns or 0) > (prev.weak_spawns or 0) then
            Post.event("weak", string.format("Weakened monstrosity spawned - %d so far", casc.weak_spawns))
        end
        prev.weak_spawns = casc.weak_spawns or 0

        -- A new wave landing.
        if (casc.wave or 0) > (prev.wave or 0) then
            Post.event("wave", string.format("Specialist wave %d incoming", casc.wave))
        end
        prev.wave = casc.wave or 0

        -- The forced horde being refused: a hard cap confirmation.
        if casc.cap_blocked and not prev.cap_blocked then
            Post.event("capblock", "At entity cap - boss arrived with no horde behind it")
        end
        prev.cap_blocked = casc.cap_blocked and true or false

        -- Surge starting.
        if casc.surge and not prev.surge then
            Post.event("surge", string.format("Special surge - %d specials in 5 seconds", casc.recent or 0))
        end
        prev.surge = casc.surge and true or false
    end

    --[[
        THE ONLY THING HAVOC ACTUALLY PUNISHES.

        Posted on CHANGE, like the bands above, because coherency flickers as
        people move and a line every ten seconds saying "you are split up"
        would be ignored inside a minute.

        Worth posting to the team specifically because this is the one callout
        where the fix is something the OTHER three people do. An entity-cap
        warning tells you to keep killing; this one tells someone to walk back.

        See HavocTracker_punish.lua for the source lines each number comes from.
    --]]
    local punish = mod.__ht_punish

    if punish then
        local warning = punish.warning()

        if warning ~= prev.punish then
            if warning then
                Post.event("punish", warning)
            end
            prev.punish = warning
        end
    end
end

function Post.reset_events()
    for k in pairs(last_event_t) do last_event_t[k] = nil end
    for k in pairs(last_event_text) do last_event_text[k] = nil end
    for k in pairs(prev) do prev[k] = nil end
end

--[[
    Periodic posting.

    Driven from the 4Hz board tick with its own accumulator rather than a
    timer, so it cannot drift relative to the tick that feeds it. Zero or a
    disabled toggle means no automatic posting at all.
--]]
local acc = 0

function Post.update(dt)
    if not dt or dt <= 0 then
        return
    end

    if mod:get("chat_post") ~= true then
        return
    end

    local every = mod:get("chat_post_interval") or 0

    --[[
        Floor of 5s, matching the slider minimum rather than overriding it.

        This used to clamp at 10 regardless of the setting, on my own judgement
        that faster was spam. That was me overruling the slider - if the range
        allows 5 then 5 has to work, otherwise the control lies. The dedupe on
        event posts is what actually prevents noise, and it does so by
        suppressing REPEATS rather than by suppressing rate.
    --]]
    if every < 5 then
        every = 5
    end

    acc = acc + dt

    if acc < every then
        return
    end

    acc = 0
    pcall(Post.post)
end

function Post.reset()
    acc = 0
    Post.reset_events()
end

mod:command("htpost", "Post the tracker readout to strike team chat", function()
    pcall(Post.post)
end)

mod:command("htpostlive", "Post to strike team chat, ignoring preview mode", function()
    pcall(Post.post, true)
end)

mod.Post = Post
return Post
