local mod = get_mod("HavocTracker")

--[[
    Mission and difficulty identification.
    ======================================

    This replaces the guesswork that made the panel say "unknown" for the whole
    session. Every accessor below is one TzeentchRichPresence uses, which is
    proven working on this install - it puts the mission, character and
    modifiers in Discord.

    THREE THINGS I HAD WRONG:

    1. HAVOC RANK. I said this needed an async backend call and could not be
       read in-mission. It can:

           Managers.state.difficulty:get_parsed_havoc_data()
               -> { havoc_rank = 40, circumstances = {...}, modifiers = {...} }

       Outside gameplay the mechanism still carries it as a raw string,
       "...;40;...", which is where the rank comes from on a loading screen.

    2. DIFFICULTY. Since the difficulty overhaul, get_initial_resistance
       returns a plain 1-5 INDEX (1 = Uprising, 5 = Auric), NOT the legacy
       resistance stat. Routing it through Danger.calculate_danger or
       get_danger_settings matches against the OLD values (2,3,4,4,5), where
       Heresy and Damnation both had resistance 4 - so that path silently
       confuses the two. Index straight into DangerSettings instead.

    3. MISSION NAME. Managers.state.mission does not resolve during loading or
       immediately after a state change, which is why going Psykhanium -> solo
       took two or three attempts to bind. Managers.mechanism still knows where
       you are headed, so it works as a fallback and the bind lands first try.

    Managers.state is rebuilt wholesale on every state transition, so nothing
    here caches across frames - every call re-resolves.
--]]

local Identity = {}

--[[
    MechanismManager.mechanism_data() is `return self._mechanism:mechanism_data()`
    with no guard, so it throws outright between states. Always reached through
    this.
--]]
local function mechanism_data()
    local manager = Managers and Managers.mechanism
    if not manager or not manager._mechanism then
        return {}
    end
    local ok, data = pcall(manager.mechanism_data, manager)
    return (ok and type(data) == "table") and data or {}
end

local function state_manager(name)
    local state = Managers and Managers.state
    return state and state[name] or nil
end

local function safe(fn, ...)
    if type(fn) ~= "function" then
        return nil
    end
    local ok, result = pcall(fn, ...)
    return ok and result or nil
end

--[[
    Game modes that are NOT missions.

    The hub, Psykhanium and prologue are all real mission templates, so
    Managers.state.mission resolves in them - which is how a tracker can end up
    reporting a difficulty on the Mourningstar. Gate on game mode instead;
    anything unlisted counts as combat, so new mission types default to shown.
--]]
local NON_COMBAT = {
    hub = true,
    prologue = true,
    prologue_hub = true,
    shooting_range = true,
    training_grounds = true,
}

--- mission key ("cm_archives"), plus zone and game mode.
function Identity.mission()
    local mm = state_manager("mission")

    if mm then
        local key = safe(mm.mission_name, mm)
        local template = safe(mm.mission, mm)
        if key and template then
            return key, template.zone_id, template.game_mode_name
        end
    end

    --[[
        Loading screen / state transition: the mechanism still knows the
        destination. THIS is the fix for "took two or three attempts" - the
        mission manager simply is not up yet at first bind.
    --]]
    local data = mechanism_data()
    if data.mission_name then
        local Missions = safe(require, "scripts/settings/mission/mission_templates")
        local template = Missions and Missions[data.mission_name]
        return data.mission_name,
               template and template.zone_id,
               template and template.game_mode_name
    end

    return nil, nil, nil
end

--- True when we are in something worth tracking.
function Identity.is_combat_mission()
    local _, _, game_mode = Identity.mission()
    if not game_mode then
        return false
    end
    return not NON_COMBAT[game_mode]
end

--[[
    Difficulty as a 1-5 index and its display name.

    DangerSettings is indexed directly - see the note above about why
    calculate_danger cannot be used here.
--]]
function Identity.difficulty()
    local dm = state_manager("difficulty")
    local index

    if dm then
        index = safe(dm.get_initial_resistance, dm)
    end
    if not index then
        index = mechanism_data().resistance
    end

    index = tonumber(index)
    local DangerSettings = safe(require, "scripts/settings/difficulty/danger_settings")

    if not index or not DangerSettings or index < 1 or index > #DangerSettings then
        return nil, nil
    end

    local danger = DangerSettings[index]
    return index, danger and danger.display_name
end

--[[
    Havoc rank plus circumstances and modifiers, or nil outside Havoc.
--]]
function Identity.havoc()
    local dm = state_manager("difficulty")

    if dm then
        local parsed = safe(dm.get_parsed_havoc_data, dm)
        if parsed and parsed.havoc_rank then
            return {
                rank = parsed.havoc_rank,
                circumstances = parsed.circumstances or {},
                modifiers = parsed.modifiers or {},
            }
        end
    end

    --[[
        Outside gameplay only the raw string exists. Take the rank only - the
        modifier field needs NetworkLookup, which is unreliable pre-mission.
        Format is semicolon separated with the rank in field 2.
    --]]
    local raw = mechanism_data().havoc_data
    if type(raw) == "string" and raw ~= "" then
        local parts = string.split(raw, ";")
        local rank = tonumber(parts and parts[2])
        if rank then
            local circumstances = {}
            if parts[5] and parts[5] ~= "" then
                for _, name in ipairs(string.split(parts[5], ":")) do
                    circumstances[#circumstances + 1] = name
                end
            end
            return { rank = rank, circumstances = circumstances, modifiers = {} }
        end
    end

    return nil
end

--[[
    One line describing where we are, for the panel header and diagnostics.
    "Havoc 40" / "Auric Maelstrom" / "Damnation" / "unknown".
--]]
function Identity.label()
    local havoc = Identity.havoc()
    if havoc and havoc.rank then
        return string.format("Havoc %d", havoc.rank), havoc.rank
    end

    local _, display = Identity.difficulty()
    if display then
        local ok, localized = pcall(Localize, display)
        return (ok and localized) or display, nil
    end

    return "unknown", nil
end

mod.Identity = Identity
return Identity
