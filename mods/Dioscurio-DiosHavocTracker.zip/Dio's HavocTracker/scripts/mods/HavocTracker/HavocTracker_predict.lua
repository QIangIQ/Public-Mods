--[[
    HavocTracker prediction engine.

    The rest of the mod measures. This file forecasts: given what we can see,
    what is the game ALLOWED to do next, and how much should you trust that.

    THE CONFIDENCE SCALE
    Every readout carries one of three levels, surfaced as a coloured dot:

      GREEN  measured directly from the client. No inference. Path distances,
             coherency, wound segments, player count.
      YELLOW derived through a known, bounded approximation. Challenge rating
             (aggro proxy), horde clock (burst detection), strike eligibility
             (depends on CR and an inferred pacing state), budgets (can
             undercount off-screen events).
      RED    modelled, and drifts. Tension and the ramp meter. These are
             estimates feeding estimates.

    SELF-VERIFICATION
    Predictions that can be checked against reality are checked. The horde clock
    predicts a window; when a horde actually lands we record whether it fell
    inside it. A rolling hit-rate then promotes or demotes the clock's own
    confidence, so a model that stops matching the game says so instead of
    quietly lying.
--]]

local mod = get_mod("HavocTracker")

local Predict = {}

Predict.CONFIDENCE = { exact = 3, derived = 2, modelled = 1 }

--[[
    Short display names.

    The engine's strike identifiers are long - the worst is
    "ranged_trickle_forward_horde_push_from_behind" at 45 characters. Rendered
    raw they wrap onto a second line and overlap the row beneath, because the
    UI text pass wraps at the style width and there is no no-wrap flag.
    Keep every one of these under about 16 characters.
--]]
Predict.SHORT_NAME = {
    spread_ambush                                 = "spread ambush",
    elite_spread_ambush                           = "elite ambush",
    blockade_push_sandwich                        = "blockade",
    sandwich                                      = "sandwich",
    elite_sandwich_waves                          = "elite sandwich",
    coordinated_special_attack                    = "coord specials",
    elite_coordinated_special_attack              = "elite specials",
    long_horde                                    = "long horde",
    push_from_behind                              = "push behind",
    ranged_push_from_behind                       = "ranged behind",
    elite_roamer_mix_vector                       = "elite mix",
    ranged_trickle_forward_horde_push_from_behind = "ranged sandwich",
}

function Predict.short(name)
    return Predict.SHORT_NAME[name] or name
end

-- ---------------------------------------------------------------------------
-- Strike condition predicates
--
-- These mirror the local functions in mutator_horde_pacing_template.lua:103-211
-- exactly. Each takes the live state table and returns a boolean, or nil when
-- we cannot evaluate it client-side (treated as "unknown", not "false").
-- ---------------------------------------------------------------------------

local MEDIUM_CR, HIGH_CR = 8, 35

local PREDICATES = {}

PREDICATES.has_build_up_tension_or_low = function(s)
    local st = s.pacing_state
    if not st then return nil end
    return st == "build_up_tension_low" or st == "build_up_tension"
end

PREDICATES.has_build_up_tension_or_high = function(s)
    local st = s.pacing_state
    if not st then return nil end
    return st == "build_up_tension" or st == "build_up_tension_high"
end

PREDICATES.has_medium_challenge_rating = function(s)
    local cr = s.challenge_rating or 0
    return cr >= MEDIUM_CR and cr < HIGH_CR
end

PREDICATES.has_high_challenge_rating = function(s)
    return (s.challenge_rating or 0) >= HIGH_CR
end

PREDICATES.has_below_high_challenge_rating = function(s)
    return (s.challenge_rating or 0) < HIGH_CR
end

PREDICATES.long_low_period = function(s)
    local st = s.pacing_state
    if not st then return nil end
    if st ~= "build_up_tension_low" and st ~= "build_up_tension" then
        return false
    end
    return (s.low_state_seconds or 0) > 50
end

-- Combat-vector minions are a server-side concept. Approximated by aggroed
-- minions near the team, which is why anything depending on it is capped at
-- YELLOW confidence.
PREDICATES.has_high_combat_vector_minions = function(s)
    return (s.minion_count or 0) > 8
end

PREDICATES.more_than_one_num_alive_players = function(s)
    return (s.alive_players or 0) > 1
end

PREDICATES.low_coherency = function(s)
    return (s.min_coherency or 4) <= 2
end

PREDICATES.players_backtracking = function(s)
    return (s.backtrack or 0) > 50
end

--- Evaluate a condition list. Returns true / false / nil(unknown).
local function all_pass(list, s)
    local unknown = false
    for i = 1, #list do
        local fn = PREDICATES[list[i]]
        if not fn then
            unknown = true
        else
            local ok = fn(s)
            if ok == nil then
                unknown = true
            elseif ok == false then
                return false
            end
        end
    end
    if unknown then return nil end
    return true
end

-- ---------------------------------------------------------------------------
-- Strike eligibility board
--
-- Rebuilt on demand (5Hz), into a reused table. Each entry is
-- { name, odds, confidence, reason } sorted by odds descending.
-- ---------------------------------------------------------------------------

local board = {}
local board_version = 0

Predict.board = function() return board end
Predict.board_version = function() return board_version end

--- @param defs table strike definitions for the active horde template
--- @param s table live state
--- @param spent table name -> number of times observed this mission
function Predict.update_board(defs, s, spent)
    local previous_top = board[1] and board[1].name
    local previous_n = #board

    for i = #board, 1, -1 do board[i] = nil end

    if not defs then return end

    for i = 1, #defs do
        local def = defs[i]
        local budget_max = def.allowed and def.allowed[2] or 0
        local used = spent[def.name] or 0

        -- A strike whose whole allowance is provably spent cannot fire again.
        if used < budget_max then
            local eligible = all_pass(def.cond, s)

            if eligible ~= false then
                local odds = def.chance
                local reason

                if def.high and #def.high_cond > 0 then
                    local boosted = all_pass(def.high_cond, s)
                    if boosted == true then
                        odds = def.high
                        reason = def.high_cond[1]
                    end
                end

                -- Unknown conditions mean we cannot be sure it is eligible.
                local confidence = (eligible == nil)
                    and Predict.CONFIDENCE.modelled
                    or Predict.CONFIDENCE.derived

                board[#board + 1] = {
                    name = def.name,
                    odds = odds,
                    confidence = confidence,
                    reason = reason,
                    used = used,
                    max = budget_max,
                }
            end
        end
    end

    table.sort(board, function(a, b)
        if a.odds == b.odds then return a.name < b.name end
        return a.odds > b.odds
    end)

    if board[1] and board[1].name ~= previous_top or #board ~= previous_n then
        board_version = board_version + 1
    end
end

-- ---------------------------------------------------------------------------
-- Horde clock self-verification
--
-- We predict a window in which the next horde may land. When one actually
-- lands, record whether the prediction held. The rolling hit rate becomes the
-- clock's confidence, so a drifting model demotes itself.
-- ---------------------------------------------------------------------------

local HISTORY = 8
local hits, samples = 0, 0
local pending_prediction = nil

--- Called when a horde window is computed. Stores what we expect.
function Predict.expect_horde(floor_s, ceil_s)
    pending_prediction = { floor = floor_s, ceil = ceil_s }
end

--- Called when a horde wave is actually detected, with seconds since the last.
function Predict.observe_horde(elapsed)
    local p = pending_prediction
    pending_prediction = nil
    if not p or not elapsed then return end

    -- Generous: anywhere inside the window, or slightly past the ceiling
    -- (the quota may legitimately have delayed it), counts as a hit.
    local hit = elapsed >= p.floor * 0.75

    samples = math.min(samples + 1, HISTORY)
    if hit then
        hits = math.min(hits + 1, samples)
    else
        hits = math.max(hits - 1, 0)
    end
end

function Predict.horde_accuracy()
    if samples < 2 then return nil end
    return hits / samples
end

--- Confidence for the horde clock, demoted if our window keeps missing.
function Predict.horde_confidence()
    local acc = Predict.horde_accuracy()
    if not acc then return Predict.CONFIDENCE.derived end
    if acc >= 0.7 then return Predict.CONFIDENCE.derived end
    return Predict.CONFIDENCE.modelled
end

function Predict.reset()
    for i = #board, 1, -1 do board[i] = nil end
    board_version = board_version + 1
    hits, samples, pending_prediction = 0, 0, nil
end

-- ---------------------------------------------------------------------------
-- Tension model
--
-- Tension drives the pacing state machine, which in turn gates most strike
-- conditions and resets the ramp. The client sees every event that ADDS
-- tension, so it can be modelled - but never the server's true value, and
-- error compounds. This is the least trustworthy thing the mod produces and is
-- always reported as RED.
--
-- Sources (minion_difficulty_settings.lua:880-937), all scaled per rank and
-- halved when a Havoc circumstance applies mutator_auric_tension_modifier.
-- ---------------------------------------------------------------------------

local tension = 0
local decay_delay_until = 0

function Predict.tension() return tension end

function Predict.add_tension(amount, cfg, now)
    tension = math.min(tension + amount * (cfg.tension_mult or 1), cfg.max_tension or 175)
    -- Any gain re-arms the decay delay; decay resumes a second or so later.
    decay_delay_until = now + 1
end

--- Decay and derive the pacing state. Returns state name, low-state seconds.
function Predict.update_tension(dt, now, cfg, state)
    if now >= decay_delay_until then
        -- Decay rate varies by state; the mid-state rate is a fair middle.
        tension = math.max(tension - dt * 2.6, 0)
    end

    local st
    if tension >= (cfg.t_high or 122.5) then
        st = "build_up_tension_high"
    elseif tension >= (cfg.t_low or 26.25) then
        st = "build_up_tension"
    else
        st = "build_up_tension_low"
    end

    if st == "build_up_tension_low" or st == "build_up_tension" then
        state.low_state_seconds = (state.low_state_seconds or 0) + dt
    else
        state.low_state_seconds = 0
    end

    return st
end

function Predict.reset_tension()
    tension = 0
    decay_delay_until = 0
end

return Predict
