local mod = get_mod("HavocTracker")

local UIWidget = require("scripts/managers/ui/ui_widget")
local UIWorkspaceSettings = require("scripts/settings/ui/ui_workspace_settings")
local HudElementBase = require("scripts/ui/hud/elements/hud_element_base")

--[[
    Spawn proximity panel - right side of the screen.
    ================================================

    Separate element from the main tracker on purpose: this one answers a
    different question. The left box tells you what the pacing system is doing
    right now; this one tells you what geography is coming.

    Rows are sorted nearest-first and recoloured by metres-to-trigger, so the
    thing about to happen climbs to the top and turns red on its own.

    THE WALL MARKERS are drawn here too, in SCREEN SPACE, by projecting the
    trigger's world position through the active camera. That is deliberate:
    RitualZones renders its world geometry with LineObject and a World Gui,
    both of which are engine objects with a create/destroy lifecycle, and that
    subsystem plus its per-frame find_ritual_units scan is where its crash
    lives. A projected rect has no lifecycle at all. Nothing to leak.
--]]

local HudElementSpawnPanel = class("HudElementSpawnPanel", "HudElementBase")

-- ---------------------------------------------------------------------------
-- Geometry (1080p reference; everything rescales from BASE)
-- ---------------------------------------------------------------------------

--[[
    Base geometry is deliberately larger than the first version.

    Darktide lays its UI out against a 1080p reference and downscales, so at
    360p everything renders at roughly a third size - a 13px font becomes about
    4px, which is not readable. Bigger base numbers plus a dedicated scale
    multiplier below.
--]]
--[[
    One DEDICATED row below the spawn list.

    The ritual/daemonhost readout used to borrow a spawn row, drawn only when
    a row happened to be free. With several triggers in range every row was
    taken, so the one readout you want visible at all times was the first
    thing to disappear exactly when the panel was busiest. That was a bad
    design decision, not a bug.

    It now owns its own space and is always drawn.
--]]
local PAD        = 8
local ROW_H      = 22
local HEADER_H   = 21
--[[
    Distance cap for the LIST (the world markers use MARKER_RANGE = 150m).
    Wider than the markers because a list you glance at can afford more reach
    than an overlay drawn across the fight.
--]]
local PANEL_RANGE = 300

--[[
    Reused every refresh instead of being rebuilt.

    This runs on the panel's update path, so allocating a fresh table each time
    would hand the GC a steady drip of garbage for no reason - the same class of
    waste that was costing frame time elsewhere in this mod.
--]]
local visible_rows = {}

local MAX_ROWS   = 4
local BAR_H      = 4
local FONT_HEAD  = 17
local FONT_ROW   = 17
local EXTRA_ROWS = 1                      -- info

local W = 240
local H = PAD + HEADER_H + (MAX_ROWS + EXTRA_ROWS) * ROW_H + PAD

local CONTAINER_SIZE = { W, H }

--[[
    Band colours.

    Green while there is nothing within 60m, amber closing, red inside 15m.
    Thresholds are absolute metres (see HavocTracker_spawns.lua) because what
    you are reacting to is time-to-contact, not a fraction of the map.
--]]
local BAND_COLOR = {
    safe     = { 255, 120, 230, 130 },
    near     = { 255, 235, 225, 110 },
    close    = { 255, 250, 165,  60 },
    imminent = { 255, 255,  70,  60 },
}

local COLOR = {
    panel_bg   = { 110,  8,  8, 10 },
    panel_edge = { 160, 70, 70, 70 },
    header     = { 255, 200, 200, 205 },
    dim        = { 180, 150, 150, 150 },
    bar_bg     = {  90,  40,  40,  40 },
}

--[[
    Two nodes, on purpose.

    `container` is the panel: centre-anchored, moved by the offset settings.

    `markers` is a full-screen node pinned to the TOP-LEFT. World markers are
    positioned from Camera.world_to_screen, which returns coordinates in
    screen space with the origin at top-left - so pinning the node the same way
    means a projected (x, y) can be used as a pass offset directly.

    The previous version drew markers as passes on `container` and tried to
    convert screen coordinates into container-local ones by subtracting the
    container origin. That origin is centre-anchored, so every marker was
    displaced by half the panel size. Separate nodes remove the conversion, and
    with it the bug.
--]]
local SCREEN_W, SCREEN_H = 1920, 1080

local scenegraph_definition = {
    screen = UIWorkspaceSettings.screen,
    container = {
        parent = "screen",
        scale = "fit",
        vertical_alignment = "center",
        horizontal_alignment = "center",
        size = CONTAINER_SIZE,
        position = { 0, 0, 100 },
    },
    --[[
        A ROOT, NOT A CHILD OF "screen".

        custom_hud offers every child of a scenegraph root as a draggable
        box. This node is the full-screen canvas the beacon markers are
        projected onto, so dragging it would knock every marker off the spot
        it points at. As its own root (same values as UIWorkspaceSettings
        .screen) it renders identically and is simply not offered.
    --]]
    markers = {
        scale = "fit",
        vertical_alignment = "top",
        horizontal_alignment = "left",
        size = { SCREEN_W, SCREEN_H },
        position = { 0, 0, 90 },
    },
}

-- ---------------------------------------------------------------------------
-- Passes
-- ---------------------------------------------------------------------------

local passes = {}
local BASE = {}

local function rect(id, x, y, w, h, color)
    passes[#passes + 1] = {
        style_id = id,
        pass_type = "rect",
        style = {
            color = color,
            size = { w, h },
            offset = { x, y, 1 },
            horizontal_alignment = "left",
            vertical_alignment = "top",
        },
    }
    BASE[id] = { size = { w, h }, offset = { x, y } }
end

local function text(id, x, y, w, size, color)
    passes[#passes + 1] = {
        style_id = id,
        pass_type = "text",
        value_id = id,
        style = {
            font_size = size,
            font_type = "machine_medium",
            text_color = color,
            size = { w, size + 4 },
            offset = { x, y, 3 },
            horizontal_alignment = "left",
            vertical_alignment = "top",
            text_horizontal_alignment = "left",
            text_vertical_alignment = "top",
        },
    }
    BASE[id] = { size = { w, size + 4 }, offset = { x, y }, font_size = size }
end

rect("panel", 0, 0, W, H, COLOR.panel_bg)
rect("edge_t", 0, 0, W, 1, COLOR.panel_edge)
rect("edge_b", 0, H - 1, W, 1, COLOR.panel_edge)
rect("edge_l", 0, 0, 1, H, COLOR.panel_edge)
rect("edge_r", W - 1, 0, 1, H, COLOR.panel_edge)

text("header", PAD, PAD - 2, W - PAD * 2, FONT_HEAD, COLOR.header)

-- Row ids precomputed for the same reason as the wall ids: no string building
-- inside the per-frame draw path.
local ROW_IDS = {}

--[[
    One mutable colour table per row.

    The BAND_COLOR entries are SHARED - four tables for the whole element.
    Writing an alpha into one to fade a low-probability row would silently
    change every other row currently in that band. Each row gets its own
    scratch table instead, refilled each frame.
--]]
local ROW_COLOR = {}
for i = 1, MAX_ROWS do
    ROW_COLOR[i] = { 255, 255, 255, 255 }
end

for i = 1, MAX_ROWS do
    local y = PAD + HEADER_H + (i - 1) * ROW_H
    local ids = { text = "row" .. i, bar = "bar" .. i, bg = "barbg" .. i }
    ROW_IDS[i] = ids
    text(ids.text, PAD, y, W - PAD * 2, FONT_ROW, COLOR.dim)
    rect(ids.bg,   PAD, y + FONT_ROW, W - PAD * 2, BAR_H, COLOR.bar_bg)
    rect(ids.bar,  PAD, y + FONT_ROW, 1,           BAR_H, COLOR.dim)
end

--[[
    The standing readout, on its own row so a busy spawn list can never push
    it off the panel.

    info = ritual proximity, else daemonhost skip distance (drawn when relevant)

    THE TRICKLE COACH IS GONE. It used to sit above this row reading
    "TRICKLE OFF - hold +35", and it was the last thing on either panel still
    presenting the challenge-rating estimate as advice. The main panel reports
    the entity cap now, which is measured rather than reconstructed, and two
    readouts that disagree about how much pressure is on the field are worse
    than one - especially when the one being sidelined is the one built on a
    number the client cannot actually see.

    mod.suppression_state is left alone. Nothing else drew it, but it is still
    correct, still cited, and the chat diagnostics use it.
--]]
local INFO_Y = PAD + HEADER_H + MAX_ROWS * ROW_H

text("info",  PAD, INFO_Y,  W - PAD * 2, FONT_ROW, COLOR.dim)

local INFO_COLOR  = { 255, 255, 255, 255 }

--[[
    Wall markers.

    Pre-allocated pool, drawn in screen space. A fixed pool means the widget
    definition never changes at runtime - creating widgets per frame is what
    turns a HUD element into a GC problem.
--]]
-- ---------------------------------------------------------------------------
-- World marker passes (separate widget, screen-space node)
--
-- A "wall" only reads correctly when you happen to be facing straight down the
-- path; from any other angle it is a rectangle floating in space that tells you
-- nothing. A vertical beacon reads from every angle, which is what these
-- markers need to do.
--
-- Each marker is: a dotted vertical column, a solid core, a halo behind it, and
-- a text label. All ids precomputed - no string building in the draw loop.
-- ---------------------------------------------------------------------------

local MAX_MARKERS = 3
local BEACON_DOTS = 7
local MARKER_IDS  = {}

local mpasses = {}

local function mrect(id, w, h, color)
    mpasses[#mpasses + 1] = {
        style_id = id,
        pass_type = "rect",
        style = {
            color = { 0, color[2], color[3], color[4] },
            size = { w, h },
            offset = { 0, 0, 2 },
            horizontal_alignment = "left",
            vertical_alignment = "top",
        },
    }
end

local function mtext(id, size, color)
    mpasses[#mpasses + 1] = {
        style_id = id,
        pass_type = "text",
        value_id = id,
        style = {
            font_size = size,
            font_type = "machine_medium",
            text_color = { 0, color[2], color[3], color[4] },
            size = { 260, size + 6 },
            offset = { 0, 0, 4 },
            horizontal_alignment = "left",
            vertical_alignment = "top",
            text_horizontal_alignment = "center",
            text_vertical_alignment = "top",
        },
    }
end

for i = 1, MAX_MARKERS do
    local ids = {
        halo  = "mhalo" .. i,
        core  = "mcore" .. i,
        label = "mlabel" .. i,
        dots  = {},
    }
    MARKER_IDS[i] = ids

    mrect(ids.halo, 1, 1, COLOR.dim)
    for d = 1, BEACON_DOTS do
        local did = "mdot" .. i .. "_" .. d
        ids.dots[d] = did
        mrect(did, 1, 1, COLOR.dim)
    end
    mrect(ids.core, 1, 1, COLOR.dim)
    mtext(ids.label, 18, COLOR.header)
end

local widget_definitions = {
    panel   = UIWidget.create_definition(passes,  "container", nil, CONTAINER_SIZE),
    markers = UIWidget.create_definition(mpasses, "markers",   nil, { SCREEN_W, SCREEN_H }),
}

-- ---------------------------------------------------------------------------

HudElementSpawnPanel.init = function(self, parent, draw_layer, start_scale)
    HudElementSpawnPanel.super.init(self, parent, draw_layer, start_scale, {
        scenegraph_definition = scenegraph_definition,
        widget_definitions = widget_definitions,
    })
    self._applied_scale = nil
end

--[[
    Rescale from BASE, never from current values.

    Compounding a scale factor onto already-scaled geometry was the bug that
    made hud_scale behave erratically in the main element. Always start from
    the captured base numbers.
--]]
HudElementSpawnPanel._apply_scale = function(self, scale)
    if self._applied_scale == scale then
        return
    end
    self._applied_scale = scale

    local styles = self._widgets_by_name.panel.style
    for id, base in pairs(BASE) do
        local st = styles[id]
        if st then
            if base.size then
                st.size[1] = base.size[1] * scale
                st.size[2] = base.size[2] * scale
            end
            if base.offset then
                st.offset[1] = base.offset[1] * scale
                st.offset[2] = base.offset[2] * scale
            end
            if base.font_size then
                st.font_size = base.font_size * scale
            end
        end
    end

    self:_set_scenegraph_size("container", W * scale, H * scale)
end

-- ---------------------------------------------------------------------------
-- World -> screen, for the wall markers
-- ---------------------------------------------------------------------------

--[[
    Returns screen x, y and whether the point is in front of the camera.

    Guarded end to end: the camera manager is absent in some states (loading,
    spectator handoff) and a nil camera here would take the frame down.
--]]
--[[
    Project a world position to screen space.

    Uses CameraManager:world_to_screen_position (camera_manager.lua:411), which
    returns x, y, distance - the same call HudElementWorldMarkers relies on. My
    first version reimplemented this with Camera.world_to_screen plus
    Vector3.x(); Fatshark reads world_to_screen.x as a field, and reusing their
    wrapper avoids betting on which form the engine returns.

    Returns: sx, sy, distance, is_behind
--]]
local VIEWPORT = "player1"

--[[
    Named rather than an inline closure: project() is called for each of the
    three nearest triggers every frame, so an anonymous function here allocated
    ~180 closures a second to answer one boolean.
--]]
local function compute_behind(cam_man, world_pos)
    local camera = cam_man:camera(VIEWPORT)
    if not camera then
        return false
    end
    local cam_pos = Camera.world_position(camera)
    local cam_dir = Quaternion.forward(Camera.world_rotation(camera))
    return Vector3.dot(world_pos - cam_pos, cam_dir) < 0
end

local function project(world_pos)
    local cam_man = Managers.state and Managers.state.camera
    if not cam_man or not cam_man.world_to_screen_position then
        return nil
    end

    local ok, sx, sy, dist =
        pcall(cam_man.world_to_screen_position, cam_man, VIEWPORT, world_pos)
    if not ok or type(sx) ~= "number" or type(sy) ~= "number" then
        return nil
    end

    --[[
        Behind-camera test.

        world_to_screen happily returns coordinates for points behind you, and
        they are mirrored - a marker behind your back would otherwise appear on
        screen pointing the wrong way. HudElementWorldMarkers uses the same
        forward dot product (hud_element_world_markers.lua:352-357).
    --]]
    local ok2, behind = pcall(compute_behind, cam_man, world_pos)
    local is_behind = (ok2 and behind) and true or false

    return sx, sy, dist, is_behind
end

-- ---------------------------------------------------------------------------
-- Update
-- ---------------------------------------------------------------------------

local EMPTY = {}

HudElementSpawnPanel.update = function(self, dt, t, ui_renderer, render_settings, input_service)
    HudElementSpawnPanel.super.update(self, dt, t, ui_renderer, render_settings, input_service)

    -- Every failure in here is contained. A HUD element that throws is drawn
    -- by the game every frame, so an unguarded error is an unrecoverable spam
    -- loop, not a one-off.
    local ok, err = pcall(self._refresh, self, ui_renderer)
    if not ok then
        mod:error("[HavocTracker] spawn panel: %s", tostring(err))
    end
end

HudElementSpawnPanel._refresh = function(self, ui_renderer)
    local widget = self._widgets_by_name.panel
    local styles = widget.style
    local content = widget.content
    local Spawns = mod.Spawns

    local visible = mod.overlay_visible ~= false
        and mod.state
        and mod.state.in_mission
        and mod:get("show_spawn_panel") ~= false
        and Spawns ~= nil

    --[[
        Note that Spawns.count() > 0 is NOT part of the visibility test.

        It used to be, and that made a missing mission indistinguishable from a
        broken mod: the panel simply vanished, with no way to tell whether the
        map was uncached, the cache had failed to load, or something had thrown.
        An empty panel that names the problem is far more useful than no panel.
    --]]
    local no_data = visible and Spawns.count() == 0

    widget.visible = visible and true or false
    if not visible then
        --[[
            Hide the marker widget too.

            It is a SEPARATE widget, so returning early here would leave it
            rendering whatever it drew on the last visible frame - beacons
            frozen in space after the panel is toggled off or the mission ends.
        --]]
        local mw = self._widgets_by_name.markers
        if mw then
            mw.visible = false
        end
        return
    end

    --[[
        Dedicated scale, independent of the main tracker.

        The two panels carry different amounts of text and sit at different
        distances from where your eyes actually are during a fight, so tying
        this to hud_scale meant one of them was always wrong.
    --]]
    local scale = tonumber(mod:get("spawn_scale")) or 2
    self:_apply_scale(scale)

    -- Right side of the screen. Positive X from centre.
    local x = tonumber(mod:get("spawn_offset_x")) or 640
    local y = tonumber(mod:get("spawn_offset_y")) or -260

    -- Yields to custom_hud the same way the main panel does.
    if not (mod.custom_hud_owns and mod.custom_hud_owns(self, "container")) then
        local sg = self._ui_scenegraph
        local node = sg and rawget(sg, "container")
        local p = node and node.position
        if not p or p[1] ~= x or p[2] ~= y
            or node.horizontal_alignment ~= "center" or node.vertical_alignment ~= "center" then
            self:set_scenegraph_position("container", x, y, nil, "center", "center")
        end
    end

    local opacity = tonumber(mod:get("panel_opacity")) or 45
    styles.panel.color[1] = math.floor(110 * (opacity / 45))

    local lead = mod.state.lead

    --[[
        Rows are capped by DISTANCE as well as by count.

        The panel was listing triggers 900m out - several minutes of walking -
        which is not a warning, it is noise with a number attached. PANEL_RANGE
        keeps it to what is plausibly this stretch of the level.

        Deliberately wider than MARKER_RANGE (150m): the panel is a list you
        read when you choose to, the world markers are drawn over the fight.
        The list can afford more reach than the overlay.

        Nothing is silently dropped - hidden_rows below feeds the "+N" count so
        you can still see how many are left.
    --]]
    --[[
        VALUES ARE COPIED, NOT REFERENCED.

        Spawns.upcoming hands back entries from a module-level row_pool that it
        mutates in place on every call, and there are four callers - this panel,
        the world-marker updater (upcoming(lead, 6)), and two more in
        HavocTracker.lua. Storing those references in visible_rows, which
        persists across frames, means any later call repoints our rows at
        somebody else's data.

        Today the build and the draw both happen inside _refresh so nothing can
        intervene, which is why this has not misbehaved yet. That is a property
        of the current call order, not a guarantee - and relying on it is how a
        future caller turns this into rows that silently show the wrong
        trigger. Six scalars per row is cheaper than that risk.

        The destination tables are allocated once, on first use, and mutated
        thereafter - no per-frame garbage.
    --]]
    local all_rows = lead and Spawns.upcoming(lead, MAX_ROWS) or EMPTY
    local rows, hidden_rows = EMPTY, 0

    if all_rows ~= EMPTY then
        rows = visible_rows
        for i = #rows, 1, -1 do rows[i] = nil end

        local n = 0
        for i = 1, #all_rows do
            local r = all_rows[i]
            if r.gap <= PANEL_RANGE and n < MAX_ROWS then
                n = n + 1

                local dst = visible_rows[n]
                if not dst then
                    dst = {}
                    visible_rows[n] = dst
                end

                dst.label = r.label
                dst.kind  = r.kind
                dst.dist  = r.dist
                dst.gap   = r.gap
                dst.band  = r.band
                dst.odds  = r.odds

                rows[n] = dst
            end
        end

        --[[
            TRUE hidden count, from Spawns.remaining rather than from what the
            pool happened to return.

            upcoming is now asked for exactly MAX_ROWS, because that is all the
            panel can display - asking for more existed only to feed this
            count, and it fed it a saturated one. remaining() counts the real
            set, so "+N" is accurate however many are pending.

            Clamped at zero: remaining() is sampled a moment after upcoming and
            a trigger consumed in between would otherwise show "+-1".
        --]]
        local total = Spawns.remaining and Spawns.remaining(lead) or n
        hidden_rows = total - n
        if hidden_rows < 0 then
            hidden_rows = 0
        end
    end

    -- Header: guaranteed-clear distance is the headline number.
    --[[
        Forced horde takes the header for 8 seconds.

        It outranks the clear-distance readout because it is the only line in
        this panel that is a CERTAINTY rather than a probability: at Havoc
        tiers, a monster spawning calls force_horde_pacing_spawn() directly
        (monster_pacing.lua:914-919). Nothing else here is that sure.
    --]]
    local now = mod._now or 0
    local forced_t = mod.state.forced_horde_t
    local forced = forced_t and (now - forced_t) < 8

    local clear = mod.state.clear_for
    if no_data then
        --[[
            Names the mission so it can be checked against the cache, rather
            than leaving you guessing why nothing is showing.
        --]]
        --[[
            Report WHICH failure this is, on screen.

            Two very different problems produced the same blank panel:
              * cache never loaded          -> 0 maps, a file/path fault
              * loaded but map not present  -> N maps, a coverage gap
            Showing the map count and the live mission name side by side makes
            them distinguishable at a glance, and the mission id is the exact
            string that would need to appear as a cache key.
        --]]
        local n = Spawns.cache_map_count and Spawns.cache_map_count() or -1
        content.header = string.format("NO DATA: %s",
            tostring(Spawns.mission() or "no mission name"))
        styles.header.text_color = COLOR.dim

        local why
        if n == 0 then
            why = "CACHE FAILED TO LOAD"
        elseif not Spawns.mission() then
            why = "mission name unavailable yet"
        else
            why = string.format("map not among %d cached", n)
        end

        for i = 1, MAX_ROWS do
            local rids = ROW_IDS[i]
            local txt = ""
            if i == 1 then
                txt = why
            elseif i == 2 then
                -- Live pacing needs Managers.state.pacing, which exists only
                -- when you ARE the server. Regular missions run on Fatshark's
                -- dedicated servers, so that is solo play only - saying "host"
                -- here was misleading.
                txt = "live data: solo play only"
            end
            content[rids.text] = txt
            styles[rids.bar].size[1] = 0
            styles[rids.bg].color[1] = 0
        end

        --[[
            Clear the dedicated rows too.

            This branch returns before they are written, so without this they
            would keep displaying whatever they said on the last frame that had
            data - stale advice presented as current, which is worse than a
            blank row.
        --]]
        content.info = ""

        self:_refresh_markers(EMPTY)
        return
    end

    --[[
        Rush gate sits high in this chain because it is a CERTAINTY with exact
        engine constants (horde_pacing.lua:84), and the only line here you can
        act on inside two seconds: stop moving and a horde cannot start.

        Only surfaced within two seconds of the window. The timer resets on
        every step forward, so shown unconditionally it would sit on screen
        saying nothing for the entire mission.
    --]]
    local gate_t = mod.state.rush_gate_t

    --[[
        EVENT ZONE outranks everything except a confirmed forced horde.

        Inside a scripted event, pause_pacing_on_event suppresses normal spawn
        types (auto_event.lua), so the horde clock, trickle state and spawn
        forecast are all describing a system that is switched off. Saying so is
        more useful than continuing to present them confidently - and this is
        the one case where the honest answer is "do not trust the rest of this
        panel".
    --]]
    if forced then
        content.header = "MONSTER - HORDE FORCED"
        styles.header.text_color = BAND_COLOR.imminent
    elseif mod.state.in_event_zone then
        content.header = "EVENT ZONE - pacing paused"
        styles.header.text_color = BAND_COLOR.close
    elseif mod.state.horde_blocked then
        content.header = string.format("HORDES BLOCKED %.1fs", gate_t or 0)
        styles.header.text_color = BAND_COLOR.safe
    elseif gate_t and gate_t <= 2 then
        content.header = string.format("BLOCK WINDOW IN %.1fs", gate_t)
        styles.header.text_color = BAND_COLOR.near
    elseif mod.state.ritual_armed then
        --[[
            Ritual proximity outranks the clear-distance readout.

            It is a 55m proximity trigger that forces a horde
            (havoc_mutator_local_settings.lua:509-510), so unlike a monster
            candidate it is not something you can walk past at an angle.
        --]]
        content.header = string.format("RITUAL %dm - HORDE",
            math.floor(mod.state.ritual_near_m or 0))
        styles.header.text_color = BAND_COLOR.imminent
    elseif Spawns.is_stale() then
        --[[
            Path divergence, not "old data".

            Crossroads are stitched per run from level_seed and unused branches
            deleted, so a cache recorded on another seed describes a route this
            mission does not contain. Distances then refer to geometry that is
            not there. Naming it plainly matters: the fix is to host (which
            switches to live pacing), not to re-record.
        --]]
        content.header = "PATH DIFFERS - LOW TRUST"
        styles.header.text_color = BAND_COLOR.close
    elseif not lead then
        content.header = "SPAWNS - no path"
        styles.header.text_color = COLOR.dim
    elseif clear then
        content.header = string.format("CLEAR %dm", math.floor(clear))
        styles.header.text_color = clear > 60 and BAND_COLOR.safe
            or clear > 30 and BAND_COLOR.near
            or clear > 15 and BAND_COLOR.close
            or BAND_COLOR.imminent
    else
        content.header = "CLEAR TO END"
        styles.header.text_color = BAND_COLOR.safe
    end

    --[[
        "+N" - how many upcoming triggers are NOT shown.

        Appended after the whole header chain so it applies to every branch
        rather than being duplicated into ten format strings.

        This exists because trimming the list by distance must not be the same
        thing as hiding information: without it, a quiet panel is ambiguous
        between "nothing is coming" and "everything coming is beyond the cap".
        Two characters resolve that.
    --]]
    if hidden_rows > 0 and content.header then
        content.header = content.header .. string.format("  +%d", hidden_rows)
    end

    for i = 1, MAX_ROWS do
        local row = rows[i]
        local rids = ROW_IDS[i]
        local rid, bid, bgid = rids.text, rids.bar, rids.bg

        if row then
            --[[
                Probability is the difference between "there is a marker here"
                and "something is going to be here". A daemonhost candidate at
                7% and a boss patrol at 100% are not the same warning, and
                showing them identically is what made the panel feel noisy.
            --]]
            -- Shared with the world markers so the two cannot word a row
            -- differently. Prints the percentage only when it is below 100.
            content[rid] = mod.format_row(row.label, row.gap, row.odds)

            --[[
                Uniform brightness. Probability is shown as a NUMBER, not as
                opacity.

                Fading low-odds rows was a mistake: a 9% marker that fires is
                exactly as dangerous as a 100% one, and dimming it trains you to
                ignore the very cases that get you killed. The percentage
                already tells you how much to weight it - the row should not
                also be whispering.
            --]]
            local c = BAND_COLOR[row.band]
            local tc = ROW_COLOR[i]
            tc[1], tc[2], tc[3], tc[4] = 255, c[2], c[3], c[4]
            styles[rid].text_color = tc
            styles[bid].color = tc

            --[[
                Bar fills as you close. Full at contact, empty at 100m out, so
                the movement itself reads as "this is arriving" without you
                having to read the number.
            --]]
            local frac = 1 - math.min(row.gap, 100) / 100
            local full = (W - PAD * 2) * scale
            styles[bid].size[1] = math.max(1, full * frac)
            styles[bgid].color[1] = 90
        else
            content[rid] = ""
            styles[bid].size[1] = 0
            styles[bgid].color[1] = 0
        end
    end

    --[[
        Last row is given over to ritual / daemonhost state when there is
        something to say, since that information has no other home and is a
        certainty rather than a probability.
    --]]
    local st = mod.state

    --[[
        Rush gate on the header when it is actionable.

        This outranks the clear-distance readout while active because it is a
        CERTAINTY with exact engine constants (horde_pacing.lua:84), and it is
        the only line in this mod you can act on within the next two seconds:
        stop moving and a horde cannot start.

        Only shown once you are within two seconds of the window - otherwise it
        would be permanently on screen saying nothing, since the timer resets
        every time you take a step.
    --]]
    --[[
        Info row - ritual proximity takes precedence over the daemonhost skip
        readout, since a ritual forces a horde and a pacing daemonhost can
        simply be walked away from.
    --]]
    --[[
        Ritual TICK STATE, not proximity.

        Rituals advance on main-path travel distance measured against the LEAD
        player (bt_chaos_mutator_daemonhost_passive_action.lua:_get_closest_player),
        so how close YOU are is irrelevant. What matters is how much further the
        lead can push before it starts ticking, and at what rate.

            full     ticking at full speed
            half     ticking at 1/9 rate (half_time_multiplier = 9)
            dormant  not ticking at all
    --]]
    if st.ritual_speed then
        local n = st.ritual_count or 1
        local suffix = n > 1 and string.format(" (%d)", n) or ""
        local c

        if st.ritual_speed == "full" then
            content.info = "RITUAL TICKING" .. suffix
            c = BAND_COLOR.imminent
        elseif st.ritual_speed == "half" then
            content.info = string.format("RITUAL slow - full in %dm%s",
                math.max(0, math.floor(st.ritual_to_full or 0)), suffix)
            c = BAND_COLOR.close
        else
            content.info = string.format("RITUAL dormant - %dm%s",
                math.max(0, math.floor((st.ritual_to_full or 0) - 15)), suffix)
            c = BAND_COLOR.safe
        end

        INFO_COLOR[1], INFO_COLOR[2], INFO_COLOR[3], INFO_COLOR[4] = 255, c[2], c[3], c[4]
        styles.info.text_color = INFO_COLOR

    elseif st.ritual_near_m then
        local total = st.ritual_total
        content.info = total
            and string.format("RITUAL %dm (%d on map)", math.floor(st.ritual_near_m), total)
            or  string.format("RITUAL %dm", math.floor(st.ritual_near_m))
        local c = st.ritual_armed and BAND_COLOR.imminent
            or (st.ritual_near_m < 90 and BAND_COLOR.close or BAND_COLOR.near)
        INFO_COLOR[1], INFO_COLOR[2], INFO_COLOR[3], INFO_COLOR[4] = 255, c[2], c[3], c[4]
        styles.info.text_color = INFO_COLOR
    elseif st.daemonhost_m then
        content.info = st.daemonhost_skip
            and string.format("DH %dm SKIPPED", math.floor(st.daemonhost_m))
            or  string.format("DH %dm (65m skips)", math.floor(st.daemonhost_m))
        local c = st.daemonhost_skip and BAND_COLOR.safe or BAND_COLOR.close
        INFO_COLOR[1], INFO_COLOR[2], INFO_COLOR[3], INFO_COLOR[4] = 255, c[2], c[3], c[4]
        styles.info.text_color = INFO_COLOR
    else
        content.info = ""
    end

    self:_refresh_markers(rows)
end

-- ---------------------------------------------------------------------------
-- World markers
--
-- A vertical dotted beacon with a solid core and a label, drawn at the trigger
-- position in screen space. Reads from any angle, unlike the wall it replaces.
--
-- Off-screen and behind-you markers are CLAMPED to the screen edge rather than
-- hidden, so the beacon also tells you which way to turn. Fatshark does the
-- same thing for its own world markers.
-- ---------------------------------------------------------------------------

local function hide_style(st)
    if st then
        st.size[1], st.size[2] = 0, 0
        st.color[1] = 0
    end
end

local function hide_marker(styles, content, ids)
    hide_style(styles[ids.halo])
    hide_style(styles[ids.core])
    for d = 1, BEACON_DOTS do
        hide_style(styles[ids.dots[d]])
    end
    local ls = styles[ids.label]
    if ls then
        ls.text_color[1] = 0
    end
    content[ids.label] = ""
end

local function put(st, x, y, w, h, c, alpha)
    if not st then return end
    st.size[1], st.size[2] = w, h
    st.offset[1], st.offset[2] = x - w * 0.5, y
    st.color[1] = alpha
    st.color[2], st.color[3], st.color[4] = c[2], c[3], c[4]
end

local MARGIN = 48

HudElementSpawnPanel._refresh_markers = function(self, rows)
    local widget = self._widgets_by_name.markers
    if not widget then
        return
    end

    local styles, content = widget.style, widget.content
    local show = mod:get("show_spawn_walls") ~= false
    widget.visible = show

    for i = 1, MAX_MARKERS do
        local ids = MARKER_IDS[i]
        local row = show and rows[i] or nil

        if not row then
            hide_marker(styles, content, ids)
        else
            local pos = mod.Spawns.position_at(row.dist)
            local sx, sy, _, is_behind
            if pos then
                sx, sy, _, is_behind = project(pos)
            end

            if not sx or not sy then
                hide_marker(styles, content, ids)
            else
                --[[
                    Behind the camera, world_to_screen returns mirrored
                    coordinates. Flip them back before clamping so an edge
                    marker points the correct way.
                --]]
                if is_behind then
                    sx = SCREEN_W - sx
                    sy = SCREEN_H - MARGIN
                end

                local clamped = false
                if sx < MARGIN then sx, clamped = MARGIN, true end
                if sx > SCREEN_W - MARGIN then sx, clamped = SCREEN_W - MARGIN, true end
                if sy < MARGIN then sy, clamped = MARGIN, true end
                if sy > SCREEN_H - MARGIN then sy, clamped = SCREEN_H - MARGIN, true end

                local c = BAND_COLOR[row.band]

                --[[
                    Visibility rises as you close AND with how likely the
                    trigger is to be real. A 7% daemonhost at 100m is a faint
                    ghost; a boss patrol at 20m is solid.
                --]]
                local near  = 1 - math.min(row.gap, 150) / 150
                local prob  = row.odds and math.min(1, row.odds * 2.5) or 1
                local vis   = 0.35 + 0.65 * near
                local alpha = math.floor(255 * vis * (0.35 + 0.65 * prob))
                if clamped then
                    alpha = math.floor(alpha * 0.7)
                end

                local core_w = 14 + 26 * near
                local dot_w  = math.max(3, 5 + 7 * near)
                local gap    = dot_w * 2.2

                -- Halo behind the core.
                put(styles[ids.halo], sx, sy - core_w * 0.5,
                    core_w * 2.2, core_w * 2.2, c, math.floor(alpha * 0.28))

                -- Dotted beacon rising from the marker.
                for d = 1, BEACON_DOTS do
                    local dy = sy - core_w - d * gap
                    local fade = 1 - (d - 1) / BEACON_DOTS
                    put(styles[ids.dots[d]], sx, dy, dot_w, dot_w, c,
                        math.floor(alpha * fade * 0.85))
                end

                -- Solid core.
                put(styles[ids.core], sx, sy - core_w * 0.5, core_w, core_w, c, alpha)

                -- Label under the core.
                local ls = styles[ids.label]
                if ls then
                    ls.offset[1] = sx - 130      -- label box is 260 wide, centred
                    ls.offset[2] = sy + core_w * 0.6
                    ls.text_color[1] = alpha
                    ls.text_color[2], ls.text_color[3], ls.text_color[4] = c[2], c[3], c[4]
                    ls.font_size = 15 + 7 * near
                end

                -- Third place a row gets written; routed through the same
                -- helper as the panel and the world markers so all three
                -- suppress a redundant "100%" identically.
                content[ids.label] = mod.format_row(row.label, row.gap, row.odds)
            end
        end
    end
end

return HudElementSpawnPanel
