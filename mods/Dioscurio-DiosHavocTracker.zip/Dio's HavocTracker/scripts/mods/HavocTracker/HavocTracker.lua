--[[
    HavocTracker - step 1: skeleton + live challenge rating

    WHAT THIS DOES
    Reconstructs the pacing system's "total challenge rating" client-side by
    keeping a census of living minions and summing breed.challenge_rating.

    WHY IT HAS TO BE RECONSTRUCTED
    Managers.state.pacing is created inside an `if is_server` block
    (gameplay_init_step_managers.lua:107-113). Havoc runs on Fatshark dedicated
    servers, so on your client that manager is nil. Every pacing value -
    including the authoritative challenge rating - is unreachable. What we can
    see is every networked minion spawn and death, and breed.challenge_rating is
    a plain field on the breed table the client already has loaded.

    WHY THE NUMBER IS PREFIXED WITH "~"
    The server sums challenge rating over *aggroed* minions. Aggro state is not
    reliably replicated to clients, so we sum over *living* minions instead
    (optionally filtered by distance to the nearest player). That reads high.
    The tilde is there to remind you this is a reconstruction, not a readout.

    THRESHOLDS IT MARKS (Havoc 40, challenge 5)
      CR >  40  trickle hordes stop, and distance walked while suppressed is
                permanently deleted rather than banked
      CR > 160  specials stop
      CR > 180  main hordes and roamers stop
--]]

local mod = get_mod("HavocTracker")

-- ---------------------------------------------------------------------------
-- Memoised localisation
--
-- mod:localize is not free: DMF runs every string through pcall(string.format)
-- (localization.lua:23-35), so each call allocates a fresh string. The HUD used
-- to call it several times per frame for labels that never change, which is
-- pure garbage generation at 60fps.
--
-- Use L() for anything static. Strings with runtime arguments still go through
-- mod:localize directly, because those genuinely differ each time.
-- ---------------------------------------------------------------------------

local loc_cache = {}

local function L(key)
    local value = loc_cache[key]
    if value == nil then
        value = mod:localize(key)
        loc_cache[key] = value
    end
    return value
end

mod.clear_loc_cache = function()
    table.clear(loc_cache)
end

-- Exported so the HUD element can use the same cache.
mod.L = L

-- ---------------------------------------------------------------------------
-- Rank data and prediction engine
-- ---------------------------------------------------------------------------

--[[
    Identity module: mission name, difficulty and Havoc rank.

    Loaded FIRST, because detect_rank below and the spawn forecast's mission
    binding both depend on it. Uses the same accessors TzeentchRichPresence
    uses for its Discord presence, which is proven working here.
--]]
local Identity = mod:io_dofile("Dio's HavocTracker/scripts/mods/HavocTracker/HavocTracker_identity")

local RankData = mod:io_dofile("Dio's HavocTracker/scripts/mods/HavocTracker/HavocTracker_ranks")
local Predict  = mod:io_dofile("Dio's HavocTracker/scripts/mods/HavocTracker/HavocTracker_predict")

mod.Predict = Predict

-- ---------------------------------------------------------------------------
-- Rank detection
--
-- DifficultyManager is created at gameplay_init_step_managers.lua:98, OUTSIDE
-- the `if is_server` block at line 107. So unlike the pacing manager it does
-- exist on clients, carrying the parsed havoc data: rank, challenge,
-- resistance, circumstances and the full modifier list.
--
-- That is what makes this work at any rank rather than only at 40. The
-- accessor is written defensively in the style Havoc Auspex uses for the
-- backend service (havoc_net.lua:10-22): guard the manager, type-check the
-- method, guard the call.
-- ---------------------------------------------------------------------------

-- Overlay visibility. Separate from mod:is_enabled() so toggling it off stops
-- the DRAWING without tearing down tracking - the horde clock and budgets keep
-- accumulating, so the numbers are still right when you bring it back.
mod.visible = true

--[[
    THE MASTER SWITCH.

    Three separate things used to decide whether anything drew, and they did
    not agree with each other:

        mod:is_enabled()      DMF's own on/off for the whole mod
        mod.visible           flipped by toggle_overlay
        mod.overlay_visible   read by the spawn panel, the ritual markers and
                              the path line - and never assigned anywhere

    Because nothing ever wrote overlay_visible it was permanently nil, so the
    "~= false" tests around it were always true. Toggling the overlay hid the
    tracker and left the spawn panel, the beacons and the path line on screen,
    and there was no single thing to switch off to get rid of all of it.

    So there is now one function every draw path asks, and overlay_visible is
    kept in step with it for the three call sites that still read the field
    directly. show_overlay is a plain checkbox at the top of the options, for
    people who want it off without hunting for a key to bind.
--]]
mod.overlay_visible = true

mod.overlay_on = function()
    if not mod:is_enabled() then
        return false
    end
    if mod:get("show_overlay") == false then
        return false
    end
    return mod.visible ~= false
end

local function sync_overlay()
    mod.overlay_visible = mod.overlay_on()
end

mod.toggle_overlay = function()
    mod.visible = not mod.visible
    sync_overlay()
    mod:echo(mod.visible and mod:localize("overlay_on") or mod:localize("overlay_off"))
end

mod.refresh_overlay_gate = sync_overlay

mod.cfg = RankData.ranks[40]    -- sane default until a mission resolves
mod.rank_known = false

local function detect_rank()
    local difficulty
    pcall(function() difficulty = Managers.state and Managers.state.difficulty end)

    if not difficulty then
        return false
    end

    -- Primary source: parsed havoc data.
    if type(difficulty.get_parsed_havoc_data) == "function" then
        local ok, data = pcall(difficulty.get_parsed_havoc_data, difficulty)
        if ok and type(data) == "table" and tonumber(data.havoc_rank) then
            local rank = math.clamp(math.floor(tonumber(data.havoc_rank)), 1, 40)
            mod.cfg = RankData.ranks[rank] or RankData.ranks[40]
            mod.rank_known = true
            mod.mission_name = data.mission
            mod.faction = data.faction
            return true
        end
    end

    -- Fallback: not a Havoc mission, or the data is unavailable. Derive the
    -- closest matching row from raw challenge/resistance so the readouts still
    -- mean something in Auric or a normal mission, and mark it as inferred.
    local challenge, resistance
    if type(difficulty.get_challenge) == "function" then
        local ok, c = pcall(difficulty.get_challenge, difficulty)
        if ok then challenge = c end
    end
    if type(difficulty.get_resistance) == "function" then
        local ok, r = pcall(difficulty.get_resistance, difficulty)
        if ok then resistance = r end
    end

    if challenge then
        local best
        for rank = 1, 40 do
            local row = RankData.ranks[rank]
            if row.challenge == challenge and (not resistance or row.resistance == resistance) then
                best = row
                break
            end
        end
        mod.cfg = best or RankData.ranks[40]
        mod.rank_known = false

        --[[
            Name the difficulty using the GAME'S OWN mapping.

            scripts/utilities/danger.lua + danger_settings.lua map
            (challenge, resistance) to the names you see on the mission board:

                ch2/res2 uprising   ch3/res3 malice    ch4/res4 heresy
                ch5/res4 damnation  ch5/res5 auric

            Deriving it myself produced "UNKNOWN" whenever my hand-rolled
            bands missed, and could never have named Auric at all. Using the
            game's table means anything it can name, we can name.

            Resistance 6 deliberately has NO entry there - it only exists via
            mutator_add_resistance, which is exclusive to Havoc 30+. So a nil
            lookup at res6 is itself proof of a high-rank Havoc.
        --]]
        local label

        if resistance == 6 then
            label = "HAVOC 31-40"
        else
            local ok, Danger = pcall(require, "scripts/utilities/danger")
            if ok and Danger and type(Danger.danger_by_difficulty) == "function" then
                local ok2, danger = pcall(Danger.danger_by_difficulty, challenge, resistance)
                if ok2 and type(danger) == "table" then
                    if danger.display_name then
                        local ok3, localized = pcall(Localize, danger.display_name)
                        if ok3 and type(localized) == "string" and localized ~= "" then
                            label = string.upper(localized)
                        end
                    end
                    label = label or (danger.name and string.upper(danger.name))
                end
            end
            label = label or string.format("ch%d/res%s", challenge, tostring(resistance or "?"))
        end

        -- Append the circumstance (Ventilation Purge, Toxic Gas, ...) - the
        -- same thing the tab screen shows next to the difficulty.
        local circ = mod.circumstance_label()
        if circ then
            label = label .. " " .. circ
        end

        mod.rank_band = label
        return true
    end

    return false
end

--- Short display name for the active circumstance, or nil if there isn't one.
function mod.circumstance_label()
    local cm = Managers.state and Managers.state.circumstance
    if not cm or type(cm.circumstance_name) ~= "function" then
        return nil
    end

    local ok, name = pcall(cm.circumstance_name, cm)
    if not ok or type(name) ~= "string" or name == "" or name == "default" then
        return nil
    end

    -- Try the template's localised display name; fall back to the raw key with
    -- the noisy prefixes stripped.
    local ok2, template = pcall(cm.template, cm)
    if ok2 and type(template) == "table" and template.ui and template.ui.display_name then
        local ok3, localized = pcall(Localize, template.ui.display_name)
        if ok3 and type(localized) == "string" and localized ~= "" then
            return localized
        end
    end

    return (name:gsub("^mutator_", ""):gsub("^circumstance_", ""):gsub("_%d+$", ""):gsub("_", " "))
end

mod.detect_rank = detect_rank

--- Strike definitions for the currently active horde template.
local function strike_defs()
    return RankData.strikes[mod.cfg and mod.cfg.strikes or "havoc_02"]
end

-- ---------------------------------------------------------------------------
-- Thresholds (see HAVOC_PACING_REFERENCE.html section 2.3)
-- ---------------------------------------------------------------------------

--[[
    These used to be hardcoded to Havoc 40. They are now views onto the
    detected rank's row in HavocTracker_ranks.lua, so every threshold, timer and
    tripwire scales to whatever assignment you are actually in.

    Kept as a table with the same field names so nothing downstream had to
    change; the values are refreshed whenever a mission resolves its rank.
--]]
mod.THRESHOLDS = {
    trickle  = 40,
    specials = 160,
    hordes   = 180,
}

local function apply_cfg()
    local c = mod.cfg
    if not c then return end

    mod.THRESHOLDS.trickle  = c.cr_trickle
    mod.THRESHOLDS.specials = c.cr_specials
    mod.THRESHOLDS.hordes   = c.cr_hordes

    mod.TRIPWIRE.spread_m       = c.rushing
    mod.TRIPWIRE.alone_seconds  = c.loner_time and c.loner_time[1] or 5
    mod.TRIPWIRE.speedrun_m     = c.sr_dist
    mod.TRIPWIRE.speedrun_period = c.sr_freq
    mod.TRIPWIRE.speedrun_checks = c.sr_checks
    mod.TRIPWIRE.speedrun_min_cr = c.sr_cr

    mod.HORDE.timer_min    = c.horde_timer[1]
    mod.HORDE.timer_max    = c.horde_timer[2]
    mod.HORDE.rate_modifier = c.horde_rate
    mod.HORDE.ticket_min_m = c.horde_ticket[1]
    mod.HORDE.ticket_max_m = c.horde_ticket[2]

    mod.RAMP.duration     = c.ramp_duration
    mod.RAMP.max_hold     = c.ramp_hold
    mod.RAMP.travel_pause = c.ramp_pause
end

mod.apply_cfg = apply_cfg

--[[
    Suppression coach.
    ==================

    THE MECHANIC, verified in source rather than inferred:

        pacing_manager.lua:456-461
            local challenge_rating_threshold = challenge_rating_thresholds[spawn_type]
            local total_challenge_rating = self._total_challenge_rating
            if challenge_rating_threshold and challenge_rating_threshold < total_challenge_rating then
                return false, "disabled_by_challenge_rating"

    A spawn type is DISABLED while challenge rating sits ABOVE its threshold.
    Challenge rating is the summed rating of currently AGGROED minions, so the
    rule inverts ordinary intuition:

        leaving enemies alive starves the director
        clearing the room instantly re-opens the tap

    havoc_pacing_template.lua:27-33 with _challenge_rating_multiplier_steps
    (default_pacing_template.lua:20-30) gives, at Havoc (challenge 5, x2):

        trickle hordes   off above  40
        specials         off above 160
        hordes / roamers off above 180
        terror events    off above 200

    Trickle is the one you can actually hold. 40 is roughly a handful of live
    ragers or a dozen poxwalkers - reachable and maintainable. The others sit
    high enough that being above them means you are already losing.

    This is the mechanism behind "we played perfectly and the room was empty":
    not speed, not stealth - a team that held CR over 40 across a stretch simply
    was not sent trickle waves.

    HONESTY: our CR is an ESTIMATE. Aggro is not replicated to clients, so it is
    approximated from breed detection radius. The THRESHOLD is exact; our
    position relative to it is not, which is why the coach reports a margin
    rather than a promise.
--]]

--[[
    Returns: state, margin, advice_key

    state  - "starving" (trickle suppressed) or "feeding" (trickle enabled)
    margin - CR distance from the trickle threshold, always positive
--]]
function mod.suppression_state()
    local s = mod.state
    local cr = s.challenge_rating or 0
    local threshold = (mod.THRESHOLDS and mod.THRESHOLDS.trickle) or 40

    if cr > threshold then
        return "starving", cr - threshold, threshold
    end
    return "feeding", threshold - cr, threshold
end

-- Behaviour tripwires. All values are Havoc 40 (challenge 5 / resistance 6).
-- See HAVOC_PACING_REFERENCE.html sections 6 and 7.4.
mod.TRIPWIRE = {
    spread_m        = 35,   -- rush prevention: gap between 1st and 2nd player
    backtrack_m     = 50,   -- blockade sandwich goes 5% -> 80%
    alone_seconds   = 5,    -- loner prevention grace is 5-9s; warn at the floor
    coherency_warn  = 2,    -- spread ambush goes 50% -> 80% at <= 2 in a bubble
    speedrun_m      = 10,   -- per 5s check
    speedrun_period = 5,
    speedrun_checks = 2,    -- 4 at ranks 1-10, where a lone lead needs 2
    speedrun_min_cr = 8,    -- check does not run below this
}

-- Main horde pacing, havoc_02 template.
mod.HORDE = {
    timer_min       = 100,  -- raw seconds before modifiers
    timer_max       = 200,
    rate_modifier   = 2.4,  -- horde_spawn_rate_increase tier 7 at rank 40
    ticket_min_m    = 45,   -- travel_distance_required_for_horde
    ticket_max_m    = 70,
    wave_gap        = 7,    -- time_between_waves
    waves_far_vector = 3,
}

-- Ramp-up frequency, challenge 5.
mod.RAMP = {
    duration        = 200,  -- units, where 1 unit = 1 second or 1 metre
    max_hold        = 100,  -- further units at full ramp before it locks
    travel_pause    = 20,   -- meter freezes if no forward progress for this long
}

-- ---------------------------------------------------------------------------
-- Census
-- ---------------------------------------------------------------------------

-- unit -> { cr = challenge_rating, dr = detection_radius }
local tracked = {}

-- Fallback when a breed has no sensible detection_radius. Most melee breeds sit
-- at 15, hounds and monsters at 20.
local DEFAULT_DETECTION_RADIUS = 18

mod.state = {
    -- census
    challenge_rating = 0,
    minion_count     = 0,
    in_mission       = false,

    -- path (exact)
    lead             = nil,   -- furthest-ahead player's travel distance
    tail             = nil,   -- furthest-behind player's travel distance
    furthest         = 0,     -- furthest the team has EVER reached
    spread           = 0,     -- lead - tail
    backtrack        = 0,     -- furthest - lead
    ticket_m         = nil,   -- metres until the next horde quota unlock

    -- horde clock (exact once a wave is detected)
    last_wave_t      = nil,
    horde_active     = false,
    hordes_seen      = 0,
    since_horde      = 0,

    -- tripwires
    alone_seconds    = 0,
    min_coherency    = 4,
    speedrun_checks  = 0,
    lead_is_alone    = false,

    -- ramp (estimate)
    ramp_units       = 0,
    ramp_pct         = 0,
    ramp_locked      = false,

    -- bumped only when the two displayed warnings change, so the HUD can skip
    -- rebuilding without comparing strings
    warnings_version = 0,

    -- pacing does not begin at mission load; see track_unit
    pacing_started   = false,
    start_distance   = 0,

    -- pace, for converting distance gates into seconds
    pace             = nil,
    pace_sampled_t   = 0,
    pace_sampled_dist = 0,

    -- audio cues (exact: the game plays these to you)
    horn_at          = nil,
    horn_counted_t   = nil,
    horn_lead        = 3,
    cue_kind         = nil,
    cue_until        = nil,
    monsters_alive   = 0,
    disablers_alive  = 0,

    -- trickle (distance-driven, the second-biggest spawn source)
    last_trickle_t    = nil,
    last_trickle_dist = 0,

    -- prediction
    pacing_state     = nil,   -- inferred from the tension model
    low_state_seconds = 0,
    tension          = 0,
    budget_line      = nil,   -- "ambush 2/4  surge 1/5"
    ramp_key_holder  = nil,   -- player who can clear a locked ramp
    ramp_key_ready   = false,

    --[[
        ENTITY CAP. The only absolute gate, and it was not modelled at all.

        PacingManager.spawn_type_enabled tests this FIRST, ahead of challenge
        rating, with no escape hatch anywhere in the file:

            local HARD_ALLOCATED_LIMIT = 145
            if total_allocated_num_enemies > HARD_ALLOCATED_LIMIT then
                return false, "Hard_allocated_limit_reached"
            end

        Every other suppression can be cancelled by something - challenge
        rating by a lone lead, heat by a stage change. This one cannot, which
        makes it the single most valuable number on the board and it was the
        one number missing.

        allocated stays nil until it is successfully read, so nil means "could
        not read" rather than "zero" and the row can say so instead of
        claiming a cap that may not exist.
    --]]
    allocated        = nil,
    alloc_capped     = false,
    peak_allocated   = nil,   -- high-water mark, for the end-of-run log
}

--[[
    Read the allocated-enemy count.

    total_allocated_num_enemies counts enemies the spawner has RESERVED, which
    is higher than the number currently walking around - reservations are made
    ahead of the actual spawn. That is the number the cap is tested against, so
    it is the number to show.

    pcall'd and nil-tolerant: MinionSpawnManager only exists on the server, so
    on a client this returns nil every time and the row reports unknown rather
    than a wrong figure. Arguments go straight to pcall rather than through a
    closure - this is called from the board tick, and a closure per call on a
    repeating path is how three framerate regressions started.
--]]
--[[
    HUD MODE, cached.

    mod:get is NOT called from the HUD rebuild path. It is read here on load
    and refreshed from on_setting_changed. The rebuild runs 10x a second and a
    mod:get per rebuild is the shape of bug that has cost this project frames
    three separate times - worst of all via table-valued settings, which DMF
    clones on EVERY read (settings.lua:82-87).
--]]
local cap_only = true

local cap_opacity = 150
local show_cascade = false

--[[
    Two display toggles that the cap rows and the notification line read on
    every rebuild, so they are cached here with the others rather than read
    through mod:get at draw time.
--]]
local show_headcount = false
local show_notifications = true

mod.refresh_hud_mode = function()
    cap_only = (mod:get("hud_mode") or "cap_only") == "cap_only"
    cap_opacity = mod:get("cap_opacity") or 150
    show_cascade = mod:get("show_cascade") == true
    show_headcount = mod:get("show_headcount") == true
    show_notifications = mod:get("show_notifications") ~= false

    if mod.Cap and mod.Cap.refresh then
        pcall(mod.Cap.refresh)
    end
end

mod.cap_opacity = function() return cap_opacity end
mod.show_cascade = function() return show_cascade end
mod.show_headcount = function() return show_headcount end
mod.show_notifications = function() return show_notifications end

mod.cap_only_mode = function()
    return cap_only
end

mod.HARD_ALLOCATED_LIMIT = 145

mod.read_allocated = function()
    local manager = Managers.state and Managers.state.minion_spawn
    if not manager or not manager.total_allocated_num_enemies then
        return nil
    end

    local ok, count = pcall(manager.total_allocated_num_enemies, manager)

    if ok and type(count) == "number" then
        return count
    end

    return nil
end

-- Per-mission observed counts, used for budget tracking and to prune spent
-- strikes from the eligibility board.
local spent = {}
mod.spent = spent

-- ---------------------------------------------------------------------------
-- Horde burst detection
--
-- We cannot read HordePacing's timer. What we can do is notice when a horde
-- WAVE lands, and count up from it - which is the only clock a human can run
-- anyway. A far-vector horde is 3 waves 7s apart; an ambush is 1; a coordinated
-- strike is 3-8 waves 2-12s apart. Trickles arrive in small groups and must not
-- trip the detector.
-- ---------------------------------------------------------------------------

local BURST_WINDOW      = 2.0   -- seconds
local BURST_MIN_SPAWNS  = 10    -- simultaneous spawns that count as a wave
local HORDE_LINGER      = 14    -- a new wave within this = same horde continuing

local spawn_stamps = {}         -- recent spawn timestamps, oldest first
local waves_this_horde = 0      -- wave count within the current horde

--- Called from track_unit for every new minion.
mod._record_spawn = function()
    local t = mod._now or 0
    spawn_stamps[#spawn_stamps + 1] = t
end

local function update_horde_clock(t)
    local state = mod.state

    -- Compact in place rather than allocating a fresh table every frame.
    local cutoff = t - BURST_WINDOW
    local n = #spawn_stamps
    if n > 0 then
        local write = 0
        for i = 1, n do
            local stamp = spawn_stamps[i]
            if stamp >= cutoff then
                write = write + 1
                spawn_stamps[write] = stamp
            end
        end
        for i = n, write + 1, -1 do
            spawn_stamps[i] = nil
        end
    end

    if #spawn_stamps >= BURST_MIN_SPAWNS then
        local is_new_horde = not state.last_wave_t or (t - state.last_wave_t) > HORDE_LINGER
        if is_new_horde then
            --[[
                The horn already counted this one.

                hordes_seen drives the travel-distance ticket, so miscounting
                it makes the ticket row meaningless. The horn is the reliable
                signal - the game plays it - whereas burst detection can miss a
                small wave. If a horn fired in the last few seconds, that horde
                is already on the books.
            --]]
            if not (state.horn_counted_t and (t - state.horn_counted_t) < 8) then
                state.hordes_seen = state.hordes_seen + 1
            end
            -- Score the prediction we made for this gap, so the clock's own
            -- confidence reflects whether the model is actually matching.
            Predict.observe_horde(state.last_wave_t and (t - state.last_wave_t) or nil)
            waves_this_horde = 1
        else
            waves_this_horde = (waves_this_horde or 0) + 1
            --[[
                Wave-count fingerprinting.

                A normal far-vector horde is 3 waves. Anything running longer is
                a coordinated strike, so once we pass 4 waves we charge the
                most likely candidate against its budget. This is why budgets
                are YELLOW and not GREEN: we infer WHICH strike from shape, and
                a strike that fires out of earshot is missed entirely.
            --]]
            if waves_this_horde == 5 then
                local guess = (state.min_coherency or 4) <= 2 and "spread_ambush"
                    or ((state.backtrack or 0) > 50 and "blockade_push_sandwich" or "sandwich")
                spent[guess] = (spent[guess] or 0) + 1
            end
        end
        state.last_wave_t = t
        -- Consume the burst so the same wave is not counted repeatedly.
        spawn_stamps = {}
    end

    --[[
        Trickle detection.

        A group too small to be a horde wave, arriving after a quiet moment, is
        a trickle. Recording the travel distance at which it landed lets us
        predict the next one, since trickles are distance-driven.
    --]]
    local n_now = #spawn_stamps
    if n_now >= 3 and n_now < BURST_MIN_SPAWNS then
        if not state.last_trickle_t or (t - state.last_trickle_t) > 6 then
            state.last_trickle_t = t
            state.last_trickle_dist = state.furthest or 0
        end
    end

    if state.last_wave_t then
        state.since_horde = t - state.last_wave_t
        state.horde_active = state.since_horde <= HORDE_LINGER
    else
        state.since_horde = 0
        state.horde_active = false
    end
end

--[[
    Time and distance to the next horde.

    A horde needs BOTH a timer and a travel-distance ticket. Whichever is not
    yet satisfied is the real constraint, and saying which one is the useful
    part: "ready, needs 22m" is actionable in a way that "42s" is not.

    Returns: kind, seconds_remaining, metres_remaining
      "unknown"  no horde observed yet
      "active"   a horde is landing right now
      "waiting"  timer not up yet
      "gated"    timer is up, but you have not walked far enough
      "due"      inside the window, can fire at any moment
      "overdue"  past the ceiling; fires the instant the gate opens
--]]
mod.horde_eta = function()
    local s = mod.state

    if not s.last_wave_t then return "unknown", nil, nil end
    if s.horde_active then return "active", 0, nil end

    local ramp_mult = 1 + (s.ramp_pct or 0)
    local rate = mod.HORDE.rate_modifier * ramp_mult
    local floor_s = mod.HORDE.timer_min / rate
    local ceil_s  = mod.HORDE.timer_max / rate
    local since = s.since_horde or 0
    local ticket = s.ticket_m or 0

    if since < floor_s then
        return "waiting", floor_s - since, ticket > 0 and ticket or nil
    end

    -- Timer satisfied. If the distance quota is not, that is the binding one.
    if ticket > 0 then
        return "gated", 0, ticket
    end

    if since < ceil_s then
        return "due", 0, nil
    end

    return "overdue", 0, nil
end

-- ---------------------------------------------------------------------------
-- Priority queue: what is coming next, soonest first
--
-- The panel used to be grouped by category, which buries the thing you
-- actually want - what is about to happen. This ranks every foreseeable event
-- by time to impact.
--
-- Coordinated strikes are deliberately folded into the horde row rather than
-- listed separately: they do not have their own timer. A strike fires ON a
-- horde tick, so the horde ETA *is* the strike ETA, and showing them apart
-- implies two independent events when there is only one.
-- ---------------------------------------------------------------------------

local queue_buffer = {}

--- Priority bands. Lower sorts first.
local P_NOW, P_IMMINENT, P_SOON, P_GATED, P_LATER = 0, 1, 2, 3, 4

mod.next_events = function()
    local out = queue_buffer
    for i = #out, 1, -1 do out[i] = nil end

    local s = mod.state

    --[[
        0. Audio cues outrank everything.

        These are the only EXACT advance warnings in the game: the engine has
        already told you, we just heard it too. A horn means a wave lands in
        three seconds regardless of what any timer model thinks.
    --]]
    local horn, horn_left = mod.horn_pending()
    if horn then
        out[#out + 1] = {
            pri = P_NOW,
            text = mod:localize("q_horn", math.max(math.ceil(horn_left), 1)),
            conf = mod.Predict.CONFIDENCE.exact,
        }
    end

    -- Literal keys, not a computed one: the format-safety check verifies that
    -- every string carrying a specifier is reached with arguments, and it can
    -- only do that if it can see the key.
    local cue, cue_left = mod.audio_cue()
    if cue then
        local secs = math.max(math.ceil(cue_left), 1)
        local text
        if cue == "hound" then
            text = mod:localize("q_hound", secs)
        else
            text = mod:localize("q_trapper", secs)
        end
        out[#out + 1] = { pri = P_NOW, text = text, conf = mod.Predict.CONFIDENCE.exact }
    end

    -- Monsters and disablers currently on the field.
    local threat = mod.threat_line()
    if threat then
        out[#out + 1] = { pri = P_NOW, text = threat, conf = mod.Predict.CONFIDENCE.derived }
    end

    -- Anything already tripped is happening now, not later.
    local warnings = mod.warnings()
    for i = 1, math.min(#warnings, 2) do
        out[#out + 1] = {
            pri = P_NOW,
            text = warnings[i],
            conf = mod.Predict.CONFIDENCE.exact,
        }
    end

    -- 1. The horde, with whichever strike is most likely to ride it.
    local kind, secs, metres = mod.horde_eta()
    if kind ~= "unknown" then
        local pri, text
        if kind == "active" then
            pri, text = P_NOW, L("q_horde_now")
        elseif kind == "overdue" then
            pri, text = P_IMMINENT, L("q_horde_overdue")
        elseif kind == "due" then
            pri, text = P_IMMINENT, L("q_horde_due")
        elseif kind == "gated" then
            local secs_to_line = mod.eta_seconds(metres)
            if secs_to_line then
                pri = secs_to_line < 15 and P_SOON or P_GATED
                text = mod:localize("q_horde_gated_eta", metres or 0, math.floor(secs_to_line))
            else
                pri, text = P_GATED, string.format("%s %dm", L("q_horde_gated"), metres or 0)
            end
        else
            pri = (secs and secs < 15) and P_SOON or P_LATER
            text = string.format("%s %ds", L("q_horde_in"), math.floor(secs or 0))
            if metres and metres > 0 then
                text = text .. string.format(" / %dm", metres)
            end
        end

        out[#out + 1] = {
            pri = pri,
            text = text,
            conf = mod.Predict.horde_confidence(),
        }

        --[[
            The likely strike gets its own row rather than being appended.

            Appending produced lines like "HORDE ready in 68m  ranged sandwich
            80%" - about 40 characters, which wraps at this panel width and
            overlaps the row beneath. Same priority band, so it still sorts
            directly under its horde.
        --]]
        local top = mod.Predict.board()[1]
        if top and kind ~= "waiting" then
            out[#out + 1] = {
                pri = pri,
                text = string.format("> %s %d%%",
                    mod.Predict.short(top.name), math.floor(top.odds * 100 + 0.5)),
                conf = top.confidence,
            }
        end
    end

    -- 2. Ramp lock is a background threat, but worth surfacing once it is close
    --    because it doubles everything above.
    if s.ramp_locked then
        out[#out + 1] = {
            pri = P_IMMINENT,
            text = s.ramp_key_ready and L("q_ramp_locked_key") or L("q_ramp_locked"),
            conf = mod.Predict.CONFIDENCE.modelled,
        }
    elseif (s.ramp_pct or 0) >= 0.85 then
        out[#out + 1] = {
            pri = P_LATER,
            text = L("q_ramp_near"),
            conf = mod.Predict.CONFIDENCE.modelled,
        }
    end

    table.sort(out, function(a, b) return a.pri < b.pri end)
    return out
end

--- Seconds to cover `metres` at the current smoothed pace, or nil if unknown.
mod.eta_seconds = function(metres)
    local pace = mod.state.pace
    if not pace or pace <= 0.2 or not metres or metres <= 0 then
        return nil
    end
    return metres / pace
end

--[[
    MOVE / HOLD verdict.

    The one line that answers the actual question. Everything below it is
    evidence; this is the call.

    Grounded only in mechanics verified from source, in priority order:

    1. A tripwire is already tripped. Fix that before anything else - a
       disabler is being aimed at someone right now.

    2. The horde's timer is up and only DISTANCE is holding it back. Crossing
       that line fires it immediately, so cross it when you are set, not
       mid-corridor. This is the single most useful state the mod can report
       and it is invisible in game.

    3. A horde is due or overdue with the gate open. It is coming; be
       positioned rather than strung out.

    4. Challenge rating is above the trickle gate. Every metre walked while
       suppressed DELETES trickle progress rather than banking it
       (horde_pacing.lua:756-757), so this is free distance. Move.

    5. Nothing pending. Move, but remember distance banks horde tickets that
       never expire - short hops beat long sprints.
--]]
local VERDICT = {
    fix   = "fix",
    hold  = "hold",
    brace = "brace",
    move  = "move",
    go    = "go",
}
mod.VERDICT = VERDICT

--[[
    Is every punishment mechanism currently switched off?

    Returns: free, reason  - where free is a boolean and reason is "cap",
    "challenge_rating" or nil.

    THIS IS THE STATE THE OLD VERDICT COULD NOT SEE, and getting it wrong was
    inverting the mod's advice. Both punishments - rush prevention and
    speed-running prevention - are called from inside a single guard in
    specials_pacing.lua:511:

        if specials_allowed then
            self:_update_rush_prevention(target_side_id, template, t)
            self:_update_loner_prevention(target_side_id, template, t)

    so when specials are disabled, NEITHER can fire. There is no punishment to
    avoid, and running is genuinely free.

    Two ways to get there, and they are not equally reliable:

    1. THE ALLOCATED CAP. spawn_type_enabled tests it before anything else and
       there is no override anywhere in the file. Absolute.

    2. CHALLENGE RATING above the specials threshold - 160 at Havoc 40, NOT the
       trickle threshold of 40 that this function used to test. That was the
       bug: between CR 41 and 159 the mod reported "walking is free" while
       specials were fully live and rush prevention could fire at a 35 m lead
       gap. Green light in exactly the band where you can be punished.

       And this one HAS an override (specials_pacing.lua:277):

           if reason == "disabled_by_challenge_rating"
              and not heat_active()
              and self._ahead_unit_has_no_units_in_coherency then
               specials_allowed = true

       so it only holds while the team is together. min_coherency > 1 means
       nobody is alone, therefore the lead is not alone either, therefore the
       override cannot fire. Testing the minimum is conservative in the right
       direction: it never claims safety that is not there.
--]]
mod.punishment_free = function()
    local s = mod.state

    if s.alloc_capped then
        return true, "cap"
    end

    local cr = s.challenge_rating or 0
    local gate = mod.THRESHOLDS.specials or 160

    -- Coherency intact, so the challenge-rating override cannot fire.
    if cr > gate and (s.min_coherency or 4) > 1 then
        return true, "challenge_rating"
    end

    return false, nil
end

mod.verdict = function()
    local s = mod.state
    local C = mod.Predict.CONFIDENCE

    -- 0. The horn has sounded. Nothing else matters for the next few seconds.
    local horn = mod.horn_pending()
    if horn then
        return VERDICT.brace, L("v_horn"), C.exact
    end

    --[[
        1. NOTHING CAN PUNISH YOU. Deliberately ABOVE the tripwire check.

        This is the fix for the medicae-drop case. The tripwires below fire on
        backtracking and speed-running, and speed-running is exactly what you
        are doing when you correctly spend one of these windows - so the old
        order flagged you for the right play and said "fix position" while the
        game had no means to respond. The window is short and time-limited;
        a warning about a punishment that cannot fire is not worth outranking
        it.

        Confidence is exact for the cap (a hard limit read directly) and
        derived for challenge rating (our census approximates the server's).
    --]]
    local free, why = mod.punishment_free()
    if free then
        if why == "cap" then
            return VERDICT.go, L("v_free_cap"), C.exact
        end
        return VERDICT.go, L("v_free_cr"), C.derived
    end

    -- 2. something already tripped
    local warnings = mod.warnings()
    if warnings[1] then
        return VERDICT.fix, L("v_fix"), C.exact
    end

    local kind, _, metres = mod.horde_eta()

    -- 3. horde loaded, held back only by distance
    if kind == "gated" then
        local secs = mod.eta_seconds(metres)
        if secs then
            return VERDICT.hold, mod:localize("v_hold_eta", metres or 0, math.floor(secs)), C.derived
        end
        return VERDICT.hold, mod:localize("v_hold", metres or 0), C.derived
    end

    -- 4. horde imminent with nothing holding it
    if kind == "due" or kind == "overdue" or kind == "active" then
        return VERDICT.brace, L("v_brace"), mod.Predict.horde_confidence()
    end

    --[[
        5. Trickle-only suppression: CR is over the trickle gate but under the
        specials gate.

        Walking still banks nothing for trickle (horde_pacing deletes the
        progress rather than storing it), so distance IS cheaper here - but
        specials are live, so it is not free. Separated from the state above
        because conflating the two is what produced the wrong advice.

        If somebody is off on their own the advice changes: regroup first,
        because a lone lead is what invites rush prevention.
    --]]
    local cr = s.challenge_rating or 0
    if cr > (mod.THRESHOLDS.trickle or 40) then
        if (s.min_coherency or 4) <= 1 then
            return VERDICT.move, L("v_go_together"), C.derived
        end
        return VERDICT.go, L("v_go"), C.derived
    end

    -- 6. nothing pending
    return VERDICT.move, L("v_move"), C.derived
end

-- ---------------------------------------------------------------------------
-- Trickle horde tracking
--
-- The second-biggest spawn source and previously unreported. Trickles are
-- purely distance-driven (every 20-100m at high rank) and stop entirely while
-- challenge rating is above the gate - which is exactly why "move while
-- suppressed" is free progress.
--
-- Small spawn groups that never reach the horde burst threshold are treated as
-- trickles. That is an inference, so this row is YELLOW.
-- ---------------------------------------------------------------------------

mod.trickle_state = function()
    local s = mod.state
    local cfg = mod.cfg
    if not cfg then return nil end

    if (s.challenge_rating or 0) > (mod.THRESHOLDS.trickle or 40) then
        return "suppressed", L("t_suppressed")
    end

    local travelled = (s.furthest or 0) - (s.last_trickle_dist or 0)
    local remaining = (cfg.trickle and cfg.trickle[1] or 20) - travelled
    if remaining <= 0 then
        return "due", L("t_due")
    end
    return "waiting", mod:localize("t_in", math.floor(remaining))
end

--[[
    Audio cues - hearing what the player hears.

    Until now hordes were detected by spawn burst, which happens roughly THREE
    SECONDS after the game has already told you. A player who tracks this well
    is not reading server state - they are reacting to the horn. So we listen
    for the same sound.

    The server plays these through FxSystem and they reach clients as an RPC:
    FxSystem.rpc_trigger_wwise_event resolves the name via
    NetworkLookup.sound_events[event_id] (fx_system.lua:542-543), which is
    exactly the hook we need.

    Timings come from the pacing templates:
      pre-stinger      3s before wave one (PRE_STINGER_DELAYS)
      hound howl       5s before it exists (default_foreshadow_stinger_timers)
      trapper cue      4s before it exists

    This turns the horde clock from "detected after the fact" into three
    seconds of genuine warning, and makes wave timing exact rather than
    inferred from spawn counts.
--]]

local CUE = {
    ["wwise/events/minions/play_signal_horde_poxwalkers_2d"]      = { kind = "horn",    lead = 3 },
    ["wwise/events/minions/play_minion_horde_poxwalker_ambush_2d"] = { kind = "horn",    lead = 3 },
    ["wwise/events/minions/play_enemy_chaos_hound_spawn"]          = { kind = "hound",   lead = 5 },
    ["wwise/events/minions/play_minion_special_netgunner_spawn"]   = { kind = "trapper", lead = 4 },
}

--- Fired when a tracked cue is heard. t is the mod clock.
local function on_cue(kind, lead, t)
    local s = mod.state

    if kind == "horn" then
        -- The horn IS the horde. Anchor the clock here rather than waiting for
        -- bodies to appear, and score the prediction we made for this gap.
        if s.last_wave_t then
            Predict.observe_horde(t - s.last_wave_t)
        end
        s.horn_at = t
        s.horn_lead = lead
        -- Authoritative horde count: the game told us one is starting.
        s.hordes_seen = (s.hordes_seen or 0) + 1
        s.horn_counted_t = t

        --[[
            The notification rides the HORN rather than the bodies. The horn
            fires three seconds before the horde arrives, which is the only
            warning in the mod you can still act on when you read it.
        --]]
        if mod.Cascade and mod.Cascade.notify then
            pcall(mod.Cascade.notify, "HORDE")
        end
    else
        s.cue_kind = kind
        s.cue_until = t + lead
    end
end

--- Incoming special warning, or nil. Exact: the game told us.
mod.audio_cue = function()
    local s = mod.state
    local t = mod._now or 0

    if s.cue_until and t < s.cue_until then
        local remaining = s.cue_until - t
        return s.cue_kind, remaining
    end
    return nil
end

--- True while the horn has sounded but the wave has not landed.
mod.horn_pending = function()
    local s = mod.state
    local t = mod._now or 0
    if not s.horn_at then return false, 0 end

    local elapsed = t - s.horn_at
    local lead = s.horn_lead or 3
    if elapsed <= lead then
        return true, lead - elapsed
    end
    return false, 0
end

mod:hook_safe("FxSystem", "rpc_trigger_wwise_event", function(self, channel_id, event_id)
    local lookup = rawget(_G, "NetworkLookup")
    local name = lookup and lookup.sound_events and lookup.sound_events[event_id]
    local cue = name and CUE[name]
    if cue then
        on_cue(cue.kind, cue.lead, mod._now or 0)
    end
end)

-- ---------------------------------------------------------------------------
-- VANILLA BUG GUARD: daemonhost crash on leaving a mission
--
-- The crash:
--   bt_chaos_mutator_daemonhost_passive_action.lua
--   "bad argument #2 to 'distance_squared' (Vector3 expected, got nil)"
--
-- The vanilla code, in _closets_aggro_target (Fatshark's typo, not mine):
--
--   for i = 1, num_enemies do
--       local target_unit     = valid_enemy_player_units[i]
--       local target_position = POSITION_LOOKUP[target_unit]
--       local distance_sq     = Vector3.distance_squared(position, target_position)
--
-- On teardown a player unit is destroyed, so POSITION_LOOKUP[target_unit] is
-- nil and distance_squared is handed nil as argument #2. It is called from
-- BtChaosMutatorDaemonhostPassiveAction.leave - literally the leave-mission
-- path, which is exactly when this fires.
--
-- Why hook `leave` and not the function that actually breaks: line 22 of that
-- file forward-declares
--     local _setup_progress_bar, _update_progress_bar, _closets_aggro_target
-- so _closets_aggro_target is a FILE-LOCAL upvalue. There is no table to reach
-- it through, so it cannot be hooked. `leave` is a method on a class() table,
-- which can be - and it is the only caller.
--
-- On swallowing the error: the alternative is not "leave() completes
-- correctly", it is "the game crashes to desktop". Nothing downstream of the
-- throw ran before this guard either. In practice this only trips during
-- teardown, when the daemonhost and everything it touches is being destroyed
-- anyway; picking no aggro target at that point costs nothing.
--
-- Hooked by STRING so DMF delays until the behaviour-tree class exists.
-- ---------------------------------------------------------------------------
local daemonhost_leave_saves = 0

mod:hook("BtChaosMutatorDaemonhostPassiveAction", "leave",
    function(func, self, unit, breed, blackboard, scratchpad, action_data, t, reason, destroy)
        local ok, err = pcall(func, self, unit, breed, blackboard, scratchpad, action_data, t, reason, destroy)
        if not ok then
            daemonhost_leave_saves = daemonhost_leave_saves + 1
            -- Log only the first few: if this ever starts firing mid-mission
            -- rather than on teardown, that is worth seeing, but it must never
            -- become per-frame spam.
            if daemonhost_leave_saves <= 3 then
                mod:info("[HavocTracker] suppressed vanilla daemonhost leave() crash (#%d): %s",
                    daemonhost_leave_saves, tostring(err))
            end
        end
    end)

mod.daemonhost_leave_saves = function() return daemonhost_leave_saves end

-- ---------------------------------------------------------------------------
-- Monster and disabler census
--
-- Both exact, both previously invisible. breed.tags carries `monster` and
-- `disabler` flags, so a boss landing or the disabler count climbing can be
-- reported precisely rather than inferred from a challenge rating jump.
-- ---------------------------------------------------------------------------

mod.threat_line = function()
    local s = mod.state
    local parts

    if (s.monsters_alive or 0) > 0 then
        parts = string.format("%dx MONSTER", s.monsters_alive)
    end
    if (s.disablers_alive or 0) > 0 then
        local d = string.format("%d disabler", s.disablers_alive)
        parts = parts and (parts .. "  " .. d) or d
    end
    return parts
end

--- Returns key, label for how overdue the next horde is.
mod.horde_band = function()
    local state = mod.state

    if not state.last_wave_t then
        return "unknown", L("horde_unknown")
    end
    if state.horde_active then
        return "active", L("horde_active")
    end

    -- Effective interval = raw timer / (rate modifier * ramp modifier).
    -- Ramp runs 1.0 to 2.0 for hordes, so the floor moves from ~42s to ~21s.
    local ramp_mult = 1 + mod.state.ramp_pct          -- 1.0 .. 2.0
    local floor_s = mod.HORDE.timer_min / (mod.HORDE.rate_modifier * ramp_mult)
    local ceil_s  = mod.HORDE.timer_max / (mod.HORDE.rate_modifier * ramp_mult)
    local s = state.since_horde

    -- Record what we are predicting so the next observed horde can score it.
    Predict.expect_horde(floor_s, ceil_s)

    if s < floor_s then
        return "safe", L("horde_safe")
    elseif s < ceil_s then
        return "possible", L("horde_possible")
    end
    return "overdue", L("horde_overdue")
end

-- ---------------------------------------------------------------------------
-- Path
--
-- All exact. MainPathManager is created outside the is_server block and
-- registers the path spline with the engine on clients too, so we can query
-- travel distance ourselves even though the manager's own per-unit progress
-- tracking is server-gated.
-- ---------------------------------------------------------------------------

--[[
    File-based diagnostics.

    Borrowed from coherency_zone, which logs to disk rather than to chat. This
    removes the need for anyone to transcribe output: the log lands next to the
    mod and can be read directly.

    Written to the mods folder rather than %APPDATA% specifically so it sits
    somewhere inspectable alongside the mod itself.
--]]
local LOG_PATH do
    local ok = pcall(function()
        local os_ = Mods and Mods.lua and Mods.lua.os
        local base = os_ and os_.getenv("APPDATA")
        LOG_PATH = base and (base .. "/Fatshark/Darktide/HavocTracker_diag.log") or nil
    end)
    if not ok then LOG_PATH = nil end
end

--[[
    SANDBOXED io / os - use these, never the globals.
    =================================================

    The game's Lua environment does not expose a usable global `os` or `io` to
    mods; DMF surfaces them as Mods.lua.os and Mods.lua.io instead.

    Every file feature written after diag() used the plain globals, so ALL of
    them silently did nothing:

        HavocTracker_accuracy.log    never written
        HavocTracker_failures.log    never written
        HavocTracker_user_cache.lua  never written  (so hosted recordings were
                                                     lost every single time)

    Nothing errored, because every one of those writes sits inside a pcall -
    the same habit that hid the POSITION_LOOKUP bug for ten rounds. diag.log
    kept working purely because it was written earlier, against Mods.lua.

    Everything that touches the filesystem now goes through these.
--]]
local function sandbox_io()
    return Mods and Mods.lua and Mods.lua.io or nil
end

local function sandbox_os()
    return Mods and Mods.lua and Mods.lua.os or nil
end

--[[
    Compile a string of Lua. Returns chunk, or nil + reason. NEVER throws.

    THIS IS WHAT BROKE THE SPILLWAY READ.

    The user cache reader used to do

        local chunk = loadstring and loadstring(text) or load(text)

    loadstring is NOT a global in the mod sandbox - DMF's own io.lua keeps a
    copy precisely because of that (modules/core/io.lua:12,
    "local _loadstring = Mods.lua.loadstring"). So the left side short-circuits
    on nil and evaluation falls through to "or load(text)" - and load is not a
    global either. Calling it is a call on a nil value, which THREW inside the
    pcall. That is why the log said "read error" and not "no usable data", and
    why the file loaded perfectly outside the game but never inside it.

    Probe each candidate and never call one that isn't there.
--]]
local function sandbox_load(text, chunk_name)
    if type(text) ~= "string" then
        return nil, "not a string"
    end

    local lua = Mods and Mods.lua or nil
    local candidates = {
        { fn = lua and lua.loadstring, named = true,  label = "Mods.lua.loadstring" },
        { fn = lua and lua.load,       named = true,  label = "Mods.lua.load" },
        { fn = rawget(_G, "loadstring"), named = true,  label = "_G.loadstring" },
        { fn = rawget(_G, "load"),       named = true,  label = "_G.load" },
    }

    local last = "no loader available"
    for _, c in ipairs(candidates) do
        if type(c.fn) == "function" then
            local ok, chunk, err = pcall(c.fn, text, chunk_name)
            if ok and chunk then
                return chunk
            end
            last = string.format("%s: %s", c.label,
                tostring((not ok and chunk) or err or "returned nil"))
        end
    end

    return nil, last
end

--- Absolute path inside the Darktide AppData folder, or nil.
local function appdata_path(filename)
    local os_ = sandbox_os()
    if not os_ or not os_.getenv then
        return nil
    end
    local ok, base = pcall(os_.getenv, "APPDATA")
    if not ok or not base then
        return nil
    end
    return base .. "/Fatshark/Darktide/" .. filename
end

mod.sandbox_io   = sandbox_io
mod.sandbox_os   = sandbox_os
mod.sandbox_load = sandbox_load
mod.appdata_path = appdata_path

local logged_once = {}

local function diag(key, fmt, ...)
    -- One line per distinct key per session: this is for establishing which
    -- APIs work, not for streaming telemetry.
    if logged_once[key] then return end
    logged_once[key] = true

    -- Format BEFORE the closure: '...' does not propagate into a nested
    -- function, which is a load-time syntax error rather than a runtime one.
    local ok, line = pcall(string.format, fmt, ...)
    if not ok then line = tostring(fmt) end

    pcall(function()
        local io_ = Mods and Mods.lua and Mods.lua.io
        if not io_ or not LOG_PATH then return end
        local f = io_.open(LOG_PATH, "a")
        if not f then return end
        f:write(string.format("[%s] %s\n", tostring(key), tostring(line)))
        f:close()
    end)
end

mod.diag = diag

--[[
    Travel distance, via the ENGINE rather than the manager.

    This was silently broken on clients for the entire life of the mod, which
    is why spread, backtrack, ticket and pace all sat at zero.

    The obvious call - Managers.state.main_path:travel_distance_from_position -
    delegates to PathTypeLinear._information_from_position
    (path_type_linear.lua:105-118), whose first act is:

        SpawnPointQueries.group_from_position(nav_world,
            main_path_manager:nav_spawn_points(), position)

    `_nav_spawn_points` is only ever populated by generate_spawn_points(),
    which begins `if not self._is_server then return end`
    (main_path_manager.lua:276-279). On a client it is nil, the group lookup
    fails, and the whole call throws. My pcall then swallowed it and returned
    nil forever.

    MainPathQueries.closest_position goes straight to
    EngineOptimized.closest_pos_at_main_path (main_path_queries.lua:31), and
    the engine's copy of the path IS registered on clients -
    EngineOptimized.register_main_path sits in MainPathManager.init at line 53,
    outside any is_server guard. This is also exactly what the level-side
    MonsterSpawner component uses, and that runs on clients.
--]]
--[[
    Travel distance, the RitualZones recipe.

    Every previous attempt here failed for the same reason, and it was not the
    choice of API: it was feeding a RAW WORLD POSITION to
    travel_distance_from_position. A player's origin is a point in the air above
    the floor; the main path is defined on the navmesh. Query it with an
    off-mesh position and it throws or returns nil, every time, on every getter
    - which is exactly the "all three failed" pattern the diag log kept showing.

    RitualZones (RitualZones.lua, get_strict_linear_travel_distance) does two
    things this code was not doing:

      1. SNAP TO THE NAVMESH FIRST, via a four-step fallback.
      2. Pass return_on_no_index = true (arg 2), so an unresolved index
         degrades to a best-effort number instead of nil.

    It also gates on the path being LINEAR. A non-linear (crossroads-branching)
    main path has no single scalar travel distance, so the query is meaningless
    there and must not be trusted.

    Mechanic being modelled - monster_pacing.lua:672,691:
        local ahead_target_unit, ahead_travel_distance =
            Managers.state.main_path:ahead_unit(target_side_id)
        if spawn_travel_distance <= ahead_travel_distance then ... spawn

    So the trigger fires on the FURTHEST-AHEAD player, not on you and not on
    the group centroid. state.lead below is that value.
--]]

local function get_main_path_manager()
    local sm = Managers.state
    return sm and sm.main_path or nil
end

-- A non-linear path cannot be reduced to one scalar. Bail rather than lie.
local path_is_linear = nil   -- nil = not yet probed, true/false = cached

local function is_linear_path_mode(main_path)
    if path_is_linear ~= nil then
        return path_is_linear
    end
    -- Different game versions expose this differently; treat "no opinion" as
    -- linear, because every live mission except a handful of branchers is.
    local ok, result = pcall(function()
        if main_path.is_linear_path then
            return main_path:is_linear_path()
        end
        if main_path._path_mode then
            return main_path._path_mode == "linear"
        end
        return true
    end)
    path_is_linear = (ok and result ~= false) and true or false
    diag("path_linear", "linear path mode: %s", tostring(path_is_linear))
    return path_is_linear
end

--[[
    Snap a world position onto the navmesh.

    NOTE THE TWO SIGNATURES - they are NOT the same shape, and getting this
    wrong is silent: you get a nil back and fall through to the raw position,
    which is the bug this whole section exists to fix.

        position_on_mesh_with_outside_position(
            nav_world, traverse_logic, position, above, below, horiz, dist)
        position_on_mesh(
            nav_world, position, above, below, traverse_logic)

    traverse_logic is argument 2 in the first and argument 5 in the second.
    (RitualZones.lua:2088-2111.)
--]]
local NAV_ABOVE, NAV_BELOW = 2.0, 2.0

--[[
    Resolved lazily, not at file scope.

    Requiring a game utility while the mod file is still being loaded runs
    before the engine has finished registering it, and a require that throws at
    load time kills the whole mod with no overlay and no settings tab. Deferring
    to first use costs one table lookup per frame and cannot break loading.
--]]
--[[
    MainPathQueries is the CLIENT-SAFE path API. This matters more than
    anything else in this file.

    Regular Darktide missions run on Fatshark's dedicated servers, so every
    player - including the party leader - is a CLIENT. Only SoloPlay makes you
    the server, which is why this mod worked solo and did nothing in real games.

    The manager route is server-only, by two separate gates:

        MainPathManager.update (line 442-448)
            if self._nav_spawn_points then self._path:update_progress_on_path(t)
        PathTypeLinear._information_from_position
            SpawnPointQueries.group_from_position(..., main_path_manager:nav_spawn_points(), ...)

    nav_spawn_points is generated server-side only, so on a client
    furthest_travel_distance stays 0 forever and travel_distance_from_position
    cannot resolve. No amount of navmesh snapping fixes that - I was tuning a
    query that was never going to answer.

    MainPathQueries goes through EngineOptimized instead, which is registered in
    setup_for_level (line 53) for EVERYONE, clients included:

        closest_position(pos)      -> position, TRAVEL DISTANCE, ...
        position_from_distance(d)  -> world position at a travel distance
        total_path_distance()      -> full stitched length
        is_main_path_registered()  -> readiness

    position_from_distance is also the inverse I previously said did not exist,
    and because EngineOptimized holds THIS run's stitched crossroads, it returns
    correct positions on branching maps - which is what put markers in the sky.
--]]
--[[
    Unit position, the RELIABLE way.

    THIS IS THE BUG THAT HAS BEEN BREAKING EVERYTHING.

        raw closest_pos ok=false  err=bad argument #1 to '?' (Vector3 expected, got userdata)
        players positioned: 0

    POSITION_LOOKUP[unit] does not reliably yield something the engine's Vector3
    functions accept from mod code. Fatshark reads it inside systems that
    localise it per frame; from a mod it can come back as userdata that
    Vector3.x, Vector3.distance_squared and closest_pos_at_main_path all reject.

    That single fact explains almost every failure in this mod's history:
        * "Vector3 expected, got userdata" crashes I contained with pcall
        * spread and back permanently 0 (every player read failed)
        * travel distance nil on clients (the position was rejected, not the API)
        * players positioned: 0 with a full team on screen

    Unit.world_position(unit, 1) is the canonical accessor - it is what
    Fatshark's own components use (components/annotation.lua:27,
    auto_event.lua:58) - and it returns a genuine Vector3 every time.

    POSITION_LOOKUP stays as a fallback only.
--]]
--[[
    Counted pcall.
    ==============

    THIS EXISTS BECAUSE OF HOW LONG THE LAST BUG TOOK.

    The mod was full of bare pcall(...) whose error value was discarded. Each
    one converted a precise engine message - "Vector3 expected, got userdata" -
    into a silent nil. The code then carried on with a missing value, and the
    symptom surfaced somewhere unrelated: a dead meter, a blank panel, zero
    spread. Every one of those was diagnosable from an error string that had
    already been thrown and thrown away.

    try() keeps the protection but RECORDS the failure: a count and the last
    message per site, surfaced in /htcopy. A fault now names itself instead of
    having to be inferred from its downstream damage.
--]]
local try_stats = {}

local function try(name, fn, a, b, c)
    local ok, res = pcall(fn, a, b, c)
    if ok then
        return res
    end

    local s = try_stats[name]
    if not s then
        s = { count = 0, last = nil }
        try_stats[name] = s
    end
    s.count = s.count + 1
    s.last = tostring(res)
    return nil
end

mod.try = try

--- Lines describing every site that has failed, for diagnostics.
function mod.try_report()
    local out = {}
    for name, s in pairs(try_stats) do
        out[#out + 1] = string.format("  %s: %d failures | last: %s",
            name, s.count, tostring(s.last))
    end
    table.sort(out)
    return out
end

function mod.try_reset()
    try_stats = {}
end

--[[
    Persist guarded failures to disk.

    A crash means /htcopy can never be run, so anything held only in memory dies
    with the process. Appending at mission end - and at any point we choose -
    leaves a trail that survives, which is the difference between diagnosing the
    next crash in one round and guessing at it for five.
--]]
function mod.write_try_report(tag)
    local lines = mod.try_report()
    if #lines == 0 then
        return
    end
    pcall(function()
        local io_ = sandbox_io()
        local path = appdata_path("HavocTracker_failures.log")
        if not io_ or not path then return end
        local f = io_.open(path, "a")
        if not f then return end
        f:write(string.format("\n=== %s  %s ===\n",
            (function() local o = sandbox_os(); return (o and o.date) and o.date("%Y-%m-%d %H:%M:%S") or "" end)(), tostring(tag)))
        for i = 1, #lines do
            f:write(lines[i], "\n")
        end
        f:close()
    end)
end

--[[
    The single unit-liveness check for the whole mod.

    ALIVE is the game's own table (pacing_manager.lua and ~90 other vanilla
    sites use it). A table lookup on a freed handle is safe and returns nil;
    an ENGINE call on a freed handle is an access violation. So this never
    touches the handle itself.
--]]
local function unit_alive(unit)
    if not unit then
        return false
    end
    local alive = rawget(_G, "ALIVE")
    if alive then
        return alive[unit] and true or false
    end
    -- ALIVE not published yet (very early boot): refuse rather than guess.
    return false
end

mod.unit_alive = unit_alive

--[[
    THE SECOND CRASH GUARD. This is the one that was actually killing you.

    Every EngineOptimized main-path function (closest_pos_at_main_path,
    point_on_mainpath, main_path_total_length) operates on a path registered
    into the ENGINE by MainPathManager:

        main_path_manager.lua:53   EngineOptimized.register_main_path(...)
        main_path_manager.lua:57   self._main_path_version = main_path_version
        main_path_manager.lua:162  EngineOptimized.unregister_main_path()

    Outside the window between those, there is NO registered path, and the
    engine dereferences a null path object -> access violation at null+8, which
    is exactly the address in the crash logs (0x0000000000000008).

    The mod previously guarded these calls with `if EO.closest_pos_at_main_path
    then`. That only proves the FUNCTION EXISTS, which is true for the entire
    lifetime of the process - before the mission loads, and after it tears down.
    It says nothing about whether a path is registered. So on entering a
    mission our update tick fired ~300ms before registration completed and took
    the process down, deterministically.

    And no, the surrounding pcall does not help: a null dereference in engine
    C++ is not a Lua error, so pcall never sees it. That is why these crashes
    always arrived as <<Crash type>>engine with no traceback.

    is_main_path_available() is the manager's own accessor for precisely this
    (_main_path_version ~= nil), so it flips true on the line after
    register_main_path and false on the line before unregister_main_path.
--]]
local function main_path_ready()
    local mgr = Managers and Managers.state and Managers.state.main_path
    if not mgr or not mgr.is_main_path_available then
        return false
    end
    local ok, available = pcall(mgr.is_main_path_available, mgr)
    return ok and available and true or false
end

mod.main_path_ready = main_path_ready

--[[
    THE CRASH GUARD. Do not remove this.

    Unit.world_position() on a DESTROYED unit handle dereferences freed memory.
    That is a native access violation - the engine reads a field off a null
    object (the crash logs show address 0x0 and 0x8, i.e. null and null+8) and
    the process dies instantly.

    pcall CANNOT catch this. try() wraps the call, but pcall only unwinds Lua
    errors; a segfault in engine C++ is not a Lua error. That is precisely why
    these crashes produced <<Crash type>>engine with no Lua traceback, which is
    what made them so hard to place - the mod looked innocent because it never
    threw.

    ALIVE is the game's own guard table (see pacing_manager.lua, roamer_pacing
    .lua and ~90 other vanilla sites). It is a plain Lua table keyed by unit, so
    looking up a freed handle is safe and returns nil - unlike Unit.is_valid(),
    which is itself an engine call on the handle and can fault the same way.

    This function is the funnel for the census sweep, the path update and the
    daemonhost tracker - every unit dereference in the mod comes through here -
    so guarding it once covers all of them.
--]]
local function unit_position(unit)
    if not unit then
        return nil
    end

    if not unit_alive(unit) then
        return nil
    end

    local p = try("Unit.world_position", Unit.world_position, unit, 1)
    if p then
        return p
    end

    --[[
        Fallback only, and note this closure is only constructed when the
        primary path has already failed - which, since Unit.world_position is
        reliable, is effectively never. Keeping it out of the success path
        matters because this function is called hundreds of times per second.
    --]]
    local p2 = try("POSITION_LOOKUP", function() return POSITION_LOOKUP[unit] end)
    if p2 then
        return p2
    end

    return nil
end

mod.unit_position = unit_position

--[[
    Position components as plain numbers, or nil.

    Everything downstream should prefer this: numbers have no lifetime, cannot
    alias an engine temporary, and cannot be rejected by a Vector3 accessor.
--]]
--[[
    Defined ONCE, at load, and reused - never inline in the call.

    This function used to be an anonymous closure created inside unit_xyz:

        pcall(function() return Vector3.x(p), Vector3.y(p), Vector3.z(p) end)

    which allocates a fresh closure on EVERY call. unit_xyz runs per player per
    minion inside the challenge-rating census, so on Havoc that is roughly
    110 x 4 = 440 closures and 440 pcalls per census tick, four times a second.
    That is thousands of short-lived objects a second feeding the collector, and
    it is what dropped the framerate from 60 to the 20s.

    A shared upvalue costs nothing per call.
--]]
local function vector_elements(p)
    return Vector3.x(p), Vector3.y(p), Vector3.z(p)
end

local function unit_xyz(unit)
    local p = unit_position(unit)
    if not p then
        return nil
    end
    -- pcall on a named function: no allocation.
    local ok, x, y, z = pcall(vector_elements, p)
    if ok and type(x) == "number" then
        return x, y, z
    end
    return nil
end

mod.unit_xyz = unit_xyz

local MainPathQueries = nil
local mpq_tried = false

local function resolve_mpq()
    if mpq_tried then
        return MainPathQueries
    end
    mpq_tried = true
    local ok, m = pcall(require, "scripts/utilities/main_path_queries")
    if ok and type(m) == "table" then
        MainPathQueries = m
    end
    return MainPathQueries
end

--- True once the engine has a main path registered for this level.
local function mpq_ready()
    local m = resolve_mpq()
    if not m or not m.is_main_path_registered then
        return false
    end
    local ok, ready = pcall(m.is_main_path_registered)
    return ok and ready and true or false
end

--[[
    Call EngineOptimized DIRECTLY, not MainPathQueries.closest_position.

    That wrapper ends with:

        main_path_node_index = main_path_node_index + 1

    executed unconditionally. The engine returns nil for the node index whenever
    a position does not resolve to one, so the wrapper throws, my pcall
    swallowed it, and travel distance came back nil - while the diagnostic
    happily reported the path as "registered", because it is. The API was fine;
    my route into it was not.

    closest_pos_at_main_path returns:
        closest_position, travel_distance, travel_percentage,
        node_index, segment_index

    We want only the second value, and reading it costs nothing extra.
--]]
local function mpq_travel_distance(position)
    if not position then
        return nil
    end

    -- No registered path == calling into the engine is a segfault, not an error.
    if not main_path_ready() then
        return nil
    end

    local EO = rawget(_G, "EngineOptimized")
    if EO and EO.closest_pos_at_main_path then
        -- Counted: if this ever refuses again, /htcopy will say WHY rather
        -- than reporting a nil lead and leaving the cause to be guessed at.
        local ok, _, dist = pcall(EO.closest_pos_at_main_path, position)
        if ok and type(dist) == "number" and dist == dist then
            return dist
        end
        if not ok then
            local s = try_stats["EngineOptimized.closest_pos_at_main_path"]
            if not s then
                s = { count = 0 }
                try_stats["EngineOptimized.closest_pos_at_main_path"] = s
            end
            s.count = s.count + 1
            s.last = tostring(dist)
        end
    end

    -- Fallback: the wrapper, in case a build exposes it but not the raw call.
    local m = resolve_mpq()
    if m and m.closest_position then
        local ok, _, dist = pcall(m.closest_position, position)
        if ok and type(dist) == "number" and dist == dist then
            return dist
        end
    end

    return nil
end

mod.mpq_ready = mpq_ready

local NavQueries = nil

local function resolve_nav_queries()
    if NavQueries then
        return NavQueries
    end
    local ok, mod_table = pcall(require, "scripts/utilities/nav_queries")
    if ok and type(mod_table) == "table" then
        NavQueries = mod_table
    end
    return NavQueries
end

local function snap_to_mesh(nav_world, traverse_logic, position)
    if not nav_world or not position then
        return nil
    end

    if NavQueries.position_on_mesh_with_outside_position then
        local ok, p = pcall(NavQueries.position_on_mesh_with_outside_position,
            nav_world, traverse_logic, position, NAV_ABOVE, NAV_BELOW, 1, 1)
        if ok and p then
            return p
        end
    end

    if NavQueries.position_on_mesh then
        local ok, p = pcall(NavQueries.position_on_mesh,
            nav_world, position, NAV_ABOVE, NAV_BELOW, traverse_logic)
        if ok and p then
            return p
        end
    end

    return nil
end

--[[
    Four steps, cheapest first. Step 1 costs nothing at all: the navigation
    extension already caches the last valid mesh position for every unit, so a
    player standing on the floor never touches the navmesh query API.
--]]
local function get_position_on_mesh(unit, position)
    -- 1. The unit's own cached navmesh position.
    if unit and ScriptUnit.has_extension(unit, "navigation_system") then
        local ok, nav_ext = pcall(ScriptUnit.extension, unit, "navigation_system")
        if ok and nav_ext then
            if nav_ext.latest_position_on_nav_mesh then
                local ok2, p = pcall(nav_ext.latest_position_on_nav_mesh, nav_ext)
                if ok2 and p then
                    return p
                end
            end

            -- 2. Snap through the unit's own nav world / traverse logic.
            local ok3, p = pcall(function()
                local nw = nav_ext.nav_world and nav_ext:nav_world()
                local tl = nav_ext.traverse_logic and nav_ext:traverse_logic()
                return snap_to_mesh(nw, tl, position)
            end)
            if ok3 and p then
                return p
            end
        end
    end

    -- 3. Snap through the manager. client_traverse_logic is the client-safe
    --    variant; a client has no server traverse logic and asking throws.
    local nav_mesh = Managers.state and Managers.state.nav_mesh
    if nav_mesh then
        local ok, p = pcall(function()
            local nw = nav_mesh:nav_world()
            local tl = nav_mesh.client_traverse_logic
                and nav_mesh:client_traverse_logic() or nil
            return snap_to_mesh(nw, tl, position)
        end)
        if ok and p then
            return p
        end
    end

    -- 4. Raw position. Usually fails downstream, but costs nothing to try.
    return position
end

--[[
    Argument 2 is return_on_no_index, NOT require_group.

    main_path_manager.lua:244 --
        travel_distance_from_position = function (self, position, return_on_no_index)

    Passing true means "give me a best-effort answer when the position does not
    resolve to a path index" rather than nil. Combined with the navmesh snap
    above, that is what turns this from a nil-generator into a usable number.
--]]
local function query_travel_distance(main_path, position)
    local ok, distance = pcall(
        main_path.travel_distance_from_position, main_path, position, true)
    if ok and type(distance) == "number" and distance == distance
        and distance ~= math.huge and distance ~= -math.huge then
        return distance
    end
    return nil
end

local travel_distance_of

-- Exposed so the spawn observers can record where something appeared.
function travel_distance_of(unit)
    if not unit_alive(unit) then
        return nil
    end

    --[[
        Client-safe route FIRST.

        This works for everyone - dedicated-server clients included - and needs
        no navmesh snapping, because EngineOptimized queries the registered
        unified path directly rather than going through the server-only
        spawn-point group lookup.
    --]]
    do
        local position = unit_position(unit)
        if position then
            local d = mpq_travel_distance(position)
            if d then
                return d
            end
        end
    end
    if not resolve_nav_queries() then
        diag("nav_missing", "scripts/utilities/nav_queries unavailable")
        return nil
    end

    local main_path = get_main_path_manager()
    if not main_path then
        diag("mp_missing", "main path manager unavailable")
        return nil
    end
    if not is_linear_path_mode(main_path) then
        -- Branching path: a scalar travel distance is not meaningful.
        return nil
    end

    local position = unit_position(unit)
    if not position then
        return nil
    end

    local snapped = get_position_on_mesh(unit, position)
    local dist = snapped and query_travel_distance(main_path, snapped)
    if dist then
        diag("path_ok", "travel distance resolved -> %.1f", dist)
        return dist
    end

    -- Last resort: try the raw position too, in case the snap moved us off a
    -- valid path group rather than onto one.
    if snapped ~= position then
        dist = query_travel_distance(main_path, position)
        if dist then
            diag("path_raw", "travel distance via raw position -> %.1f", dist)
            return dist
        end
    end

    diag("path_none", "travel_distance_from_position rejected both snapped and raw")
    return nil
end

--[[
    Euclidean spread, which does NOT depend on the main path at all.

    The game measures rush prevention along the path, but POSITION_LOOKUP is
    proven to work client-side - coherency_zone draws decals from it every
    half second - so straight-line distance between the two furthest-apart
    players is a reliable proxy that cannot fail the way path distance has.

    It under-reads around corners, which is the safe direction: it will warn
    late rather than cry wolf.
--]]
-- Published so the spawn observers can record where a unit appeared.
mod.travel_distance_of = travel_distance_of

--[[
    Euclidean spread, from PLAIN NUMBERS.

    THIS IS WHY SPREAD READ 0m, and why distance_squared kept throwing
    "Vector3 expected, got userdata".

    The old version collected POSITION_LOOKUP values into a table and compared
    them in a second pass. Those values are engine temporaries: they are only
    guaranteed valid at the moment you read them. Holding several at once and
    comparing them afterwards is not safe - entries can alias the same
    underlying buffer, so every pair measures as zero distance, or the value
    goes stale and the accessor rejects it outright. Same root cause as the
    marker positions: Vector3 must be used immediately or boxed.

    Extracting x/y/z into Lua numbers at read time sidesteps all of it. Numbers
    have no lifetime, nothing can alias, and Vector3.distance_squared is never
    called - so the userdata error cannot recur here either.
--]]
local function euclidean_spread()
    local xs, ys, zs, n = {}, {}, {}, 0

    for _, player in pairs(Managers.player:players()) do
        local unit = player.player_unit
        if unit_alive(unit) and HEALTH_ALIVE[unit] then
            -- unit_xyz uses Unit.world_position, which returns a real Vector3;
            -- POSITION_LOOKUP was silently failing for every player here, which
            -- is why spread read 0 with a full team.
            local x, y, z = unit_xyz(unit)
            if x then
                n = n + 1
                xs[n], ys[n], zs[n] = x, y, z
            end
        end
    end

    local furthest_sq = 0
    for i = 1, n do
        for j = i + 1, n do
            local dx = xs[i] - xs[j]
            local dy = ys[i] - ys[j]
            local dz = zs[i] - zs[j]
            local d_sq = dx * dx + dy * dy + dz * dz
            if d_sq > furthest_sq then
                furthest_sq = d_sq
            end
        end
    end

    return math.sqrt(furthest_sq), n
end

--[[
    The heroes side id, which is what the pacing system measures against.

    MonsterPacing.update calls ahead_unit(target_side_id) where the target side
    is the players. Cached because get_side_from_name walks a list.
--]]
--[[
    Rush-gate thresholds, verbatim from horde_pacing.lua:57-58.

        local TRAVEL_DISTANCE_CHANGE_ALLOWANCE_MIN = 5
        local TRAVEL_DISTANCE_CHANGE_ALLOWANCE_MAX = 8

    Not tuned, not estimated - these are the engine's own constants, so the
    window is exact rather than modelled.
--]]
local RUSH_GATE_MIN = 5
local RUSH_GATE_MAX = 8

--[[
    Seconds accumulated since the last path update, declared HERE because
    update_path reads it and update_path is defined above the driver loop.

    It was originally declared next to the driver, far below this point, so the
    read inside update_path resolved to a nil GLOBAL - (path_dt or 0) became 0,
    since_forward never advanced, and the rush gate would have sat dead forever
    while looking perfectly correct in the source.

    Fifth occurrence of this trap in this file. All shared state belongs at the
    top.
--]]
local path_dt = 0

local heroes_side_id = nil

local function get_heroes_side_id()
    if heroes_side_id then
        return heroes_side_id
    end
    local ok, id = pcall(function()
        local side_system = Managers.state.extension:system("side_system")
        local side = side_system:get_side_from_name("heroes")
        return side and side.side_id
    end)
    if ok and type(id) == "number" then
        heroes_side_id = id
    end
    return heroes_side_id
end

local function is_hogtied(unit)
    local ude = ScriptUnit.has_extension(unit, "unit_data_system")
    if not ude or type(ude.read_component) ~= "function" then
        return false
    end
    local ok, comp = pcall(ude.read_component, ude, "character_state")
    return ok and type(comp) == "table" and rawget(comp, "state_name") == "hogtied"
end

local function update_path()
    local state = mod.state
    local lead, tail

    --[[
        Ask the engine for the lead distance directly.

        furthest_travel_distance(side_id) (main_path_manager.lua:216) is the
        same number MonsterPacing compares spawn triggers against, maintained by
        the engine every frame. Computing it ourselves from player positions is
        both slower and subtly wrong - the engine's value accounts for units we
        may fail to snap to the navmesh.

        We still run the per-player loop for `tail`, which has no engine getter.
    --]]
    --[[
        furthest_travel_distance returns 0 on a client, not nil.

        update_progress_on_path only runs when nav_spawn_points exists, which is
        server-only, so the value is initialised to 0 and never advances. A
        plain "is it a number" check therefore accepted 0 as a real reading and
        pinned lead to zero for the whole mission - which is what killed the
        meter in real games. Anything at or below zero is treated as
        unavailable so the per-player loop below can answer instead.
    --]]
    local side_id = get_heroes_side_id()
    if side_id then
        local main_path = get_main_path_manager()
        if main_path and main_path.furthest_travel_distance then
            local ok, d = pcall(main_path.furthest_travel_distance, main_path, side_id)
            if ok and type(d) == "number" and d == d and d > 0 then
                lead = d
            end
        end
    end

    --[[
        HOGTIED PLAYERS ARE NOT ON THE SIDE THE PACING MEASURES.

        side_system.lua:404 builds valid_player_units with
        `valid = not PlayerUnitStatus.is_hogtied(...)`, and the linear path's
        update_progress_on_path takes the ahead player from that list. A
        teammate lying hogtied at a respawn beacon is usually AHEAD of
        everyone who can move, so counting them pinned the lead to the
        beacon - every monster trigger, horde gate and the spawn feed then
        read from the wrong place until they were freed. Respawn Rewind
        1.4.2 found the same thing for respawn prediction.
    --]]
    for _, player in pairs(Managers.player:players()) do
        local unit = player.player_unit
        if unit and HEALTH_ALIVE[unit] and not is_hogtied(unit) then
            local d = travel_distance_of(unit)
            if d then
                if not lead or d > lead then lead = d end
                if not tail or d < tail then tail = d end
            end
        end
    end

    state.lead, state.tail = lead, tail

    --[[
        Feed the spawn forecast. Cheap: a sorted-array scan, no allocation.

        The rebind retry matters. on_game_state_changed fires the moment
        StateGameplay is entered, which can be before Managers.state.mission is
        populated - and a single failed bind at that instant would leave the
        forecast dead for the whole mission with no way to recover. Retrying
        once a second until it takes costs nothing and makes the timing
        irrelevant.
    --]]
    local Spawns = mod.Spawns
    if Spawns then
        local now = mod._now or 0

        --[[
            Live pacing refresh, once a second, while hosting.

            _monsters shrinks as entries fire (monster_pacing.lua:695), so
            re-reading keeps the list in sync and gives consumption for free -
            no heuristic retirement needed. On a client refresh_live returns
            false and the cached data stays in place untouched.
        --]]
        if now - (state.live_refresh_t or -99) >= 1 then
            state.live_refresh_t = now
            Spawns.refresh_live()

            --[[
                Auto-record uncached missions while hosting.

                Self-gating: returns immediately unless we are hosting AND the
                mission is absent from both caches AND it has not already been
                recorded this session. So this is a table lookup on every run
                except the one that matters.
            --]]
            if Spawns.record_if_needed then
                Spawns.record_if_needed()
            end
        end

        --[[
            Rebind ONLY when we are not already on live data.

            Late in a hosted mission _monsters legitimately empties out - every
            rolled spawn has fired - so refresh_live correctly reports zero
            triggers meaning "nothing left to spawn". Without this guard that
            zero looked like a failed bind, so ensure_mission reloaded the
            CACHED candidates, and the next refresh_live wiped them again: the
            panel would flicker between "clear to end" and a list of candidates
            once a second for the rest of the run.
        --]]
        --[[
            Rebind retry is BOUNDED.

            Some missions genuinely have no pacing data - the Meat Grinder, the
            Psykhanium - so count() stays 0 forever and this retried once a
            second for the whole session, re-running set_mission, re-sorting the
            trigger list and re-checking staleness each time. Ten attempts is
            far more than the two or three a slow state transition needs.
        --]]
        if Spawns.count() == 0 and not Spawns.is_live()
            and (state.spawn_rebind_tries or 0) < 10 then
            if now - (state.spawn_rebind_t or -99) >= 1 then
                state.spawn_rebind_t = now
                state.spawn_rebind_tries = (state.spawn_rebind_tries or 0) + 1
                Spawns.ensure_mission()
            end
        end

        --[[
            RETRY RANK DETECTION until it succeeds.

            detect_rank ran exactly once, from reset_run_state on StateLoading
            enter - before Managers.state.difficulty is populated. So it failed,
            was never retried, and the header read UNKNOWN for the entire
            mission even though get_parsed_havoc_data would have answered a
            second later.

            Same class of bug as the mission bind above: a one-shot read at the
            earliest possible moment, with no second attempt.
        --]]
        if not mod.rank_known and now - (state.rank_retry_t or -99) >= 1 then
            state.rank_retry_t = now
            pcall(detect_rank)
        end

        if lead then
            -- Live data self-retires: entries vanish from _monsters when they
            -- fire. Only the cached path needs the heuristic sweep.
            if not Spawns.is_live() then
                Spawns.retire_passed(lead)
            end
            state.clear_for = Spawns.clear_for(lead)
        end
    end

    if not lead then
        -- Path distance unavailable: spread still works, the rest cannot.
        local eu, n = euclidean_spread()
        state.spread = eu
        state.players_positioned = n
        state.backtrack, state.ticket_m = 0, nil
        diag("no_lead", "path distance unavailable; spread falling back to euclidean")
        return 0
    end

    --[[
        THE RUSH GATE - horde_pacing.lua:84

            local travel_distance_allowed =
                time_since_forward_travel_changed < TRAVEL_DISTANCE_CHANGE_ALLOWANCE_MIN   -- 5
                or time_since_forward_travel_changed > TRAVEL_DISTANCE_CHANGE_ALLOWANCE_MAX -- 8

        A horde cannot START while that value sits between 5 and 8 seconds. So
        there is a three-second window, opening five seconds after you stop
        making forward progress, in which hordes are blocked outright. Keep
        moving and it never opens; stand still past nine seconds and it closes
        again.

        This is the sharpest rule in the whole pacing system: exact thresholds,
        no randomness, and directly actionable.

        The game reads time_since_forward_travel_changed from the main path
        manager, which is server-gated. We measure the same quantity ourselves:
        seconds since our lead distance last increased. Both sides are watching
        the furthest-ahead player's forward progress, so the values track.
    --]]
    local gained = 0
    if lead > state.furthest then
        gained = lead - state.furthest
        state.furthest = lead
        state.since_forward = 0
    else
        state.since_forward = (state.since_forward or 0) + (path_dt or 0)
    end

    local since = state.since_forward or 0
    state.horde_blocked = since >= RUSH_GATE_MIN and since <= RUSH_GATE_MAX

    --[[
        Seconds until the block window opens, or until it closes.

        Negative is meaningless to a reader, so both are reported as a positive
        countdown and the caller distinguishes them via horde_blocked.
    --]]
    if state.horde_blocked then
        state.rush_gate_t = RUSH_GATE_MAX - since       -- time left blocked
    elseif since < RUSH_GATE_MIN then
        state.rush_gate_t = RUSH_GATE_MIN - since       -- time until blocked
    else
        state.rush_gate_t = nil                          -- past the window
    end

    --[[
        Spread comes from euclidean distance, NOT the path.

        Path distance has failed twice on clients; POSITION_LOOKUP has not.
        This keeps the 35m tripwire working regardless of whether travel
        distance ever resolves.
    --]]
    local eu_spread, player_count = euclidean_spread()
    state.spread = eu_spread
    state.players_positioned = player_count

    state.backtrack = state.furthest - lead

    --[[
        Rolling pace, so distance gates can be quoted in seconds.

        This is the piece that turns "HORDE ready in 22m" into "horde in ~8s".
        The horde TIMER is a fresh random roll each time and genuinely
        unknowable - but the distance gate is deterministic, and anyone who
        calls a horde before the horn is converting metres-to-the-line into
        time at their current pace. Smoothed hard, because instantaneous speed
        is far too jumpy to read off a HUD.
    --]]
    local now = mod._now or 0
    local since = now - (state.pace_sampled_t or 0)
    if since >= 0.5 then
        local moved = state.furthest - (state.pace_sampled_dist or 0)
        local instant = moved / since
        -- Exponential smoothing; ignore standing still so the estimate does
        -- not collapse to zero the moment you stop to fight.
        if instant > 0.2 then
            state.pace = (state.pace or instant) * 0.7 + instant * 0.3
        end
        state.pace_sampled_t = now
        state.pace_sampled_dist = state.furthest
    end

    -- Metres until the next horde quota unlock. The threshold is re-rolled
    -- server-side from 45-70m after every horde, so this is a band: we show the
    -- distance to the nearest boundary we could be approaching.
    --[[
        Measured from where pacing actually began, not from mission load.
        Counting the dropship ride and the walk to first contact inflated
        `furthest` and made the ticket read "due" from the opening seconds.
    --]]
    if not state.pacing_started then
        state.ticket_m = nil
    else
        local travelled = state.furthest - (state.start_distance or 0)
        local hordes = state.hordes_seen
        local next_at_min = mod.HORDE.ticket_min_m * (hordes + 1)
        local next_at_max = mod.HORDE.ticket_max_m * (hordes + 1)
        if travelled < next_at_min then
            state.ticket_m = next_at_min - travelled
        else
            state.ticket_m = 0    -- inside or past the band: a ticket is live
        end
    end

    return gained
end

-- ---------------------------------------------------------------------------
-- Tripwires
-- ---------------------------------------------------------------------------

local speedrun_next_check = 0
local speedrun_last_lead  = nil

-- Previous-frame player state, for transition detection in the tension model.
local player_alive_prev    = {}
local player_disabled_prev = {}

local function coherency_of(unit)
    local ext = ScriptUnit.has_extension(unit, "coherency_system")
    if not ext or not ext.num_units_in_coherency then
        return nil
    end

    local ok, n = pcall(ext.num_units_in_coherency, ext)
    if ok and type(n) == "number" then
        return n
    end
    return nil
end

-- Forward declaration. update_tripwires calls this, but the definition sits
-- below it; without this the call resolves to a global that does not exist.
local recompute_warnings

local function update_tripwires(dt, t)
    local state = mod.state
    local local_player = Managers.player:local_player(1)
    local local_unit = local_player and local_player.player_unit

    -- Coherency: minimum across the team drives the spread-ambush odds; the
    -- local player's own count drives the alone timer.
    local min_coherency = 4
    local alive_players = 0
    for _, player in pairs(Managers.player:players()) do
        local unit = player.player_unit
        if unit and HEALTH_ALIVE[unit] then
            alive_players = alive_players + 1
            local n = coherency_of(unit)
            if n and n < min_coherency then
                min_coherency = n
            end
        end
    end
    state.min_coherency = min_coherency
    -- Living players is a proxy for the game's "non-disabled players" count,
    -- which it derives from PlayerUnitStatus.requires_help. Close enough to
    -- gate the warnings, and it avoids reading character state every frame.
    state.alive_players = alive_players

    if local_unit and HEALTH_ALIVE[local_unit] then
        local own = coherency_of(local_unit)
        if own == 1 then
            state.alone_seconds = state.alone_seconds + dt
        else
            state.alone_seconds = 0
        end
    else
        state.alone_seconds = 0
    end

    --[[
        Speed-running prevention. HavocTracker_pace.lua runs the server's rule
        for every possible offset of the server's 5 s clock and reports the
        worst case; its count replaces the single-offset approximation below,
        which is kept only as the fallback for when that module failed to load.
    --]]
    local Pace = mod.Pace
    if Pace and Pace.state then
        state.speedrun_checks = Pace.state.sr_worst or 0
        state.speedrun_status = Pace.state.sr_status
    elseif t >= speedrun_next_check then
        speedrun_next_check = t + mod.TRIPWIRE.speedrun_period

        local lead = state.lead
        if lead and state.challenge_rating >= mod.TRIPWIRE.speedrun_min_cr then
            if speedrun_last_lead then
                if (lead - speedrun_last_lead) >= mod.TRIPWIRE.speedrun_m then
                    state.speedrun_checks = state.speedrun_checks + 1
                else
                    state.speedrun_checks = 0
                end
            end
            speedrun_last_lead = lead
        else
            state.speedrun_checks = 0
            speedrun_last_lead = lead
        end
    end

    --[[
        lead_is_alone used to read min_coherency == 1, which is "ANYONE is
        alone". The speed-running rule asks about the LEAD player only
        (specials_pacing.lua:1543-1547). Pace reads exactly that.

        spread is replaced the same way: rush prevention measures path
        distance from the lead to the NEXT player, and from the last to the
        one in front of them (:1336-1374), not the two furthest-apart
        players in a straight line.
    --]]
    if Pace and Pace.state then
        local ps = Pace.state
        state.lead_is_alone = ps.lead_alone and true or false
        if ps.rush_line_ahead then
            state.spread = math.max(ps.rush_gap_ahead or 0, ps.rush_gap_behind or 0)
        end
    else
        state.lead_is_alone = (min_coherency == 1)
    end

    --[[
        Ramp-unlock key holder.

        pacing_manager.lua:551 clears a LOCKED ramp on a death, or on a
        knockdown by a player with exactly 2 health segments:

            tension_type == "died" or num_wounds == 2 and tension_type == "knocked_down"

        num_wounds() is segments REMAINING, computed from permanent damage
        (health.lua:107-117). Healing removes permanent damage and RAISES the
        segment count - so healing a player off 2 segments removes their
        ability to clear the ramp. That is the healing breakpoint, and it is
        worth seeing before you take the medicae.
    --]]
    --[[
        Feed the tension model from observed events.

        Rather than hooking APIs whose signatures I cannot verify, this watches
        for state TRANSITIONS on players we are already iterating: alive -> not
        alive is a death, and a transition into a disabled character state is a
        knockdown. Values come from the detected rank's row, and are halved
        automatically when the rank carries a Havoc circumstance (which applies
        mutator_auric_tension_modifier).
    --]]
    --[[
        Both loops below touch per-player extensions whose availability differs
        between the local player and husks. Each player is handled inside its
        own pcall so one unreadable teammate degrades that teammate's data
        rather than throwing the whole tripwire subsystem, which is what
        happened in v0.7.
    --]]
    local cfg = mod.cfg

    local function scan_player(player)
        local unit = player.player_unit
        if not unit then return end

        local alive = HEALTH_ALIVE[unit] and true or false
        if player_alive_prev[unit] == true and alive == false and cfg then
            Predict.add_tension(cfg.ten_died or 60, cfg, t)
        end
        player_alive_prev[unit] = alive

        if not alive then
            player_disabled_prev[unit] = nil
            return
        end

        -- Knockdown detection. read_component can fail on husks, and the
        -- component may not carry state_name at all, so treat every step as
        -- optional rather than assuming the shape.
        local disabled = false
        local ude = ScriptUnit.has_extension(unit, "unit_data_system")
        if ude and type(ude.read_component) == "function" then
            local ok, comp = pcall(ude.read_component, ude, "character_state")
            if ok and type(comp) == "table" then
                local n = rawget(comp, "state_name")
                if type(n) == "string" then
                    disabled = (n == "knocked_down" or n == "hogtied"
                             or n == "netted" or n == "pounced" or n == "consumed")
                end
            end
        end

        if disabled and not player_disabled_prev[unit] and cfg then
            Predict.add_tension(cfg.ten_knock or 60, cfg, t)
        end
        player_disabled_prev[unit] = disabled
    end

    local function wound_key(player)
        local unit = player.player_unit
        if not unit or not HEALTH_ALIVE[unit] then return nil end

        local health_ext = ScriptUnit.has_extension(unit, "health_system")
        if not health_ext or type(health_ext.num_wounds) ~= "function" then
            return nil
        end

        local ok, wounds = pcall(health_ext.num_wounds, health_ext)
        if not ok or wounds ~= 2 then return nil end

        local nm = "someone"
        if type(player.name) == "function" then
            local okn, n = pcall(player.name, player)
            if okn and type(n) == "string" then nm = n end
        end
        return nm
    end

    local holder, ready = nil, false
    for _, player in pairs(Managers.player:players()) do
        pcall(scan_player, player)

        if not ready then
            local ok, nm = pcall(wound_key, player)
            if ok and nm then
                ready, holder = true, nm
            end
        end
    end
    state.ramp_key_ready = ready
    state.ramp_key_holder = holder

    recompute_warnings()
end

-- Reused, so the HUD can ask for warnings every frame without allocating.
local warnings_buffer = {}

--- Active tripwire warnings, most urgent first. The returned table is reused -
--- read it before calling again, do not hold on to it.
--[[
    Warnings are gated on living player count, mirroring the game's own rules.
    Without this, solo and bot runs show COHERENCY permanently - you are always
    at coherency 1 alone, but the strike it warns about cannot fire:

      spread ambush     requires more_than_one_num_alive_players (> 1)
      rush prevention   needs a second-place player to measure a gap against
      loner prevention  switches off entirely at <= 2 non-disabled players

    Backtrack and speed-running have no such gate and apply at any team size.
--]]
--[[
    Recomputed only when the tripwires update (10Hz), never per frame.

    The HUD used to call this every frame, and every active warning meant
    another mod:localize - which is a pcall plus a string allocation each time.
    Now the strings come from the memoised L() and the HUD only rebuilds when
    warnings_version changes.
--]]
-- Assigns to the local forward-declared above update_tripwires.
function recompute_warnings()
    local state = mod.state
    local out = warnings_buffer
    local players = state.alive_players or 0
    local previous_1, previous_2 = out[1], out[2]

    for i = #out, 1, -1 do
        out[i] = nil
    end

    --[[
        BOTH PUNISHMENT TRIPWIRES ARE MUTED WHILE NOTHING CAN PUNISH YOU.

        Backtracking and speed-running are only meaningful because they invoke
        rush prevention and speed-running prevention respectively - and both of
        those are called from inside one guard (specials_pacing.lua:511):

            if specials_allowed then
                self:_update_rush_prevention(...)

        With specials disabled by the allocated cap or by challenge rating,
        neither runs. Warning about them then is not a cautious call, it is a
        false positive - and a costly one, because it used to promote the whole
        verdict to "fix position" during the exact window where the correct
        play is to cover ground.

        The coherency and spread warnings are NOT muted: they describe the team
        being strung out, which stays dangerous for revives and for holding the
        challenge rating up in the first place.
    --]]
    local punish_free = mod.punishment_free and mod.punishment_free() or false

    if not punish_free and state.backtrack > mod.TRIPWIRE.backtrack_m then
        out[#out + 1] = L("warn_backtrack")
    end

    if players > 1 and state.spread >= mod.TRIPWIRE.spread_m then
        out[#out + 1] = L("warn_spread")
    end

    --[[
        Speed-running is NOT muted by punish_free. It is called outside the
        specials_allowed gate (specials_pacing.lua:535) and injects with
        ignore_allowance (:1557), so a challenge-rating or allocation stop on
        specials does not stop it. Only a full set of special slots does.
    --]]
    local Pace = mod.Pace
    local ps = Pace and Pace.state

    if ps then
        if players > 2 and ps.alone_since then
            out[#out + 1] = L("warn_alone")
        end
        if ps.sr_status == "armed" or ps.sr_status == "doomed" or ps.sr_status == "fired" then
            out[#out + 1] = L("warn_speedrun")
        end
    else
        if players > 2 and state.alone_seconds >= mod.TRIPWIRE.alone_seconds then
            out[#out + 1] = L("warn_alone")
        end

        local needed = (state.lead_is_alone and mod.TRIPWIRE.speedrun_checks > 2) and 2
            or mod.TRIPWIRE.speedrun_checks
        if state.speedrun_checks >= needed - 1 and state.speedrun_checks > 0 then
            out[#out + 1] = L("warn_speedrun")
        end
    end

    if players > 1 and state.min_coherency <= mod.TRIPWIRE.coherency_warn then
        out[#out + 1] = L("warn_coherency")
    end

    -- Only the first two are ever displayed, so only those need to bump the
    -- version. Comparing cached strings is a pointer compare, not a strcmp.
    if out[1] ~= previous_1 or out[2] ~= previous_2 then
        state.warnings_version = (state.warnings_version or 0) + 1
    end
end

--- The live warning list. Reused table - read it, do not hold it.
mod.warnings = function()
    return warnings_buffer
end

-- ---------------------------------------------------------------------------
-- Ramp estimator
--
-- ESTIMATE, not a readout. The fill rule is modelable: the meter gains
-- (dt + metres travelled) per frame while the team has moved forward within the
-- last 20s, against a threshold of 200, then holds for 100 more before locking.
--
-- The RESET is the problem. It fires when server-side tension crosses 122.5,
-- and tension is not replicated. So this drifts upward over a run and will
-- report MAX when the truth may be a fresh reset. Hence the "?" and the manual
-- /havoctracker_ramp_reset command.
-- ---------------------------------------------------------------------------

local last_forward_t = 0

local function update_ramp(dt, t, distance_gained)
    local state = mod.state

    if distance_gained > 0 then
        last_forward_t = t
    end

    -- Meter freezes (does not decay) when nobody has advanced recently.
    if (t - last_forward_t) < mod.RAMP.travel_pause then
        state.ramp_units = state.ramp_units + dt + distance_gained
    end

    local total = mod.RAMP.duration + mod.RAMP.max_hold
    state.ramp_pct = math.min(state.ramp_units / mod.RAMP.duration, 1)
    state.ramp_locked = state.ramp_units >= total
end

mod.ramp_band = function()
    local state = mod.state
    if state.ramp_locked then
        return "locked", L("ramp_locked")
    elseif state.ramp_pct >= 1 then
        return "max", L("ramp_max")
    elseif state.ramp_pct >= 0.5 then
        return "building", L("ramp_building")
    end
    return "low", L("ramp_low")
end

local function is_valid_mission()
    local game_mode_manager = Managers.state.game_mode
    if not game_mode_manager then
        return false
    end

    local game_mode_name = game_mode_manager:game_mode_name()
    -- Anything that isn't the hub / prologue-style state is fair game.
    return game_mode_name ~= "hub" and game_mode_name ~= "prologue_hub"
end

--- Add a unit to the census if it carries a challenge rating.
local function track_unit(unit)
    if not unit then
        return
    end

    --[[
        CAP CENSUS FIRST, ABOVE THE challenge_rating GATE.

        Position matters. Everything below bails on cr <= 0, and EVERY horde
        breed is cr = 0 (poxwalker, newly_infected, mutated_poxwalker,
        lesser_mutated_poxwalker, armored_infected, cultist_melee,
        cultist_assault). Registering the cap census after that check would
        make the horde row read zero forever - silently, which is the exact
        failure this was built to avoid.

        Both spawn hooks funnel through here, including the client-side
        spawn_husk_unit path, so this works when not hosting. That is the whole
        point: mod.read_allocated() returns nil on a client because
        MinionSpawnManager is server-only, so the 145 row goes unknown off-host
        while this one keeps working.

        pcall'd because this runs inside the engine's spawn path - an error
        escaping here does not just break a readout, it propagates into unit
        registration.
    --]]
    if mod.Cap then
        pcall(mod.Cap.add, unit)
    end

    if tracked[unit] then
        return
    end

    local unit_data_ext = ScriptUnit.has_extension(unit, "unit_data_system")
    if not unit_data_ext then
        return
    end

    local ok, breed = pcall(unit_data_ext.breed, unit_data_ext)
    if not ok or not breed then
        return
    end

    local cr = breed.challenge_rating
    if not cr or cr <= 0 then
        return
    end

    -- breed.detection_radius is the range at which this breed notices players
    -- (a top-level field, right beside challenge_rating). A few breeds use
    -- math.huge for scripted always-aware behaviour; clamp those.
    local dr = breed.detection_radius
    if type(dr) ~= "number" or dr <= 0 or dr > 1000 then
        dr = DEFAULT_DETECTION_RADIUS
    end

    -- breed.tags carries `monster` and `disabler`; both are worth reporting
    -- exactly rather than inferring from a challenge-rating jump.
    local tags = breed.tags
    local is_monster  = tags and tags.monster and true or false
    local is_disabler = tags and tags.disabler and true or false

    tracked[unit] = { cr = cr, dr = dr, monster = is_monster, disabler = is_disabler,
                      breed_name = breed.name }

    --[[
        Monster spawn edge.

        Fired here rather than off a change in monsters_alive, because this is
        the exact frame the unit appears - the census only runs at 4Hz, so
        edge-detecting from its output would report the forced horde up to a
        quarter second late, and the horde arrives fast.
    --]]
    --[[
        Spawn callbacks are pcall'd.

        This runs inside unit registration, which the game drives - an error
        escaping here does not just break our readout, it propagates into the
        engine's spawn path. A unit mid-initialisation may have no navmesh
        position yet, and travel_distance_of touches its navigation extension,
        so this is a real possibility rather than a theoretical one. On a
        mission restart a burst of units register at once, which is exactly when
        you saw the crash.
    --]]
    if is_monster and mod.on_monster_spawned then
        pcall(mod.on_monster_spawned, breed.name)
    end

    --[[
        Daemonhosts are not tagged `monster`, so they need their own hook - and
        there are TWO breeds, which is why ritual warnings never fired.

        Pacing daemonhosts are `chaos_daemonhost`. RITUAL daemonhosts are
        `chaos_mutator_daemonhost` (havoc_mutator_local_settings.lua:11-66,
        and the same name RitualZones keys off). Checking only the first meant
        ritual units were never registered, so ritual_near_m stayed nil and
        nothing ever appeared on screen.
    --]]
    if mod.on_daemonhost_spawned
        and (breed.name == "chaos_daemonhost"
             or breed.name == "chaos_mutator_daemonhost") then
        pcall(mod.on_daemonhost_spawned, unit,
              breed.name == "chaos_mutator_daemonhost")
    end

    --[[
        Pacing does not start when the mission loads.

        The clock used to run from mission start, so it counted the dropship
        ride and the walk to the first contact. The game itself does the same
        thing: PacingManager keeps a `_first_aggro` flag and only stamps its
        state timers when the first minion aggros (pacing_manager.lua:884-891).

        First minion spawn is the closest client-visible equivalent, so treat
        that as the real start and rebase distance from there.
    --]]
    if not mod.state.pacing_started then
        mod.state.pacing_started = true
        mod.state.start_distance = mod.state.furthest or 0
        mod.state.furthest = mod.state.furthest or 0
    end

    -- Feed the horde detector. A horde wave is a burst of many simultaneous
    -- spawns; trickles arrive in small groups.
    mod._record_spawn()
end

--[[
    Hook targets are given as STRINGS, not as CLASS.Foo table references.

    DMF resolves a string target lazily and will queue the hook until the class
    actually exists (dmf/modules/core/hooks.lua:322-331). A CLASS.Foo reference
    must already be loaded at the moment this file runs; if it isn't, the value
    is nil and DMF indexes it, which is a hard error rather than a retry.
    Mods load early, so string form is the safe choice.
--]]

-- Public-game path. This is the one that matters: it fires on the client for
-- every networked minion the dedicated server spawns.
-- hook_safe runs after the original, by which point spawn_husk_unit has already
-- called _add_network_unit and created the unit's extensions.
mod:hook_safe("UnitSpawnerManager", "spawn_husk_unit", function(self, game_object_id, owner_id)
    local unit_spawner_manager = Managers.state.unit_spawner
    if not unit_spawner_manager then
        return
    end

    local unit = unit_spawner_manager._network_units[game_object_id]
    track_unit(unit)
end)

-- Local/private-game path (you are the server). Kept so the mod also works in
-- solo and Psykhanium testing, which is where you will calibrate it.
-- Note spawn_husk_unit calls _add_network_unit internally, so in public games
-- both hooks fire for the same unit. The is_server guard below stops the second
-- one, and track_unit is idempotent anyway.
mod:hook_safe("UnitSpawnerManager", "_add_network_unit", function(self, unit, game_object_id, is_husk)
    local game_session_manager = Managers.state.game_session
    if not game_session_manager or not game_session_manager:is_server() then
        return
    end

    track_unit(unit)
end)

-- Fast removal. Not load-bearing - the prune pass below is the real safety net,
-- because it also catches despawns and out-of-bounds cleanup, which never fire
-- set_dead.
mod:hook_safe("MinionDeathManager", "set_dead", function(self, unit)
    tracked[unit] = nil

    --[[
        The cap census keeps its OWN table, because this one bails on
        challenge_rating <= 0 and every horde breed is cr=0. Same death edge,
        two tables.
    --]]
    if mod.Cap then
        mod.Cap.remove(unit)
    end
end)

-- ---------------------------------------------------------------------------
-- Recalculation
-- ---------------------------------------------------------------------------

local PRUNE_INTERVAL = 0.25
local prune_accumulator = 0

--[[
    Reused every prune. Holds player UNITS, never positions.

    A Stingray Vector3 is a temporary drawn from a per-frame buffer. Storing one
    in a table that outlives the frame leaves you pointing at recycled memory,
    which Lua reports as:

        bad argument #2 to 'distance_squared' (Vector3 expected, got userdata)

    Every use of POSITION_LOOKUP in Fatshark's own code reads the value and
    consumes it in the same breath - see horde_pacing.lua:757 and
    specials_pacing.lua:1338. Units, by contrast, are stable objects and are
    safe to hold, so we cache those and re-read positions inside the loop.
--]]
local player_units = {}

local function refresh_player_units()
    table.clear(player_units)

    for _, player in pairs(Managers.player:players()) do
        local player_unit = player.player_unit
        if player_unit and HEALTH_ALIVE[player_unit] then
            player_units[#player_units + 1] = player_unit
        end
    end
end

--[[
    Squared distance from a position to the closest living player, or nil.

    Vector3.distance_squared is called through pcall.

    That is not defensive programming for its own sake - it is an admission.
    Something in POSITION_LOOKUP occasionally yields userdata the engine will
    not accept as a Vector3, and I have not been able to identify which unit or
    why from the source alone. Fatshark's own code calls this exact pair without
    guarding (player_manager_testify.lua:115), and travel_distance_from_position
    consumes the same values without complaint, so the fault is narrower than
    "POSITION_LOOKUP is unsafe".

    Until it is pinned down, one bad pair should cost that pair's contribution
    to the estimate, not the whole subsystem. Failures are counted so the cause
    can be found: run /havoctracker to see how many pairs are being skipped.
--]]
mod._bad_position_pairs = 0

--[[
    Units whose position the engine refuses.

    v0.9 blacklisted a unit after ONE failure, which was wrong in a way that
    quietly destroyed the reading: if the fault is systemic, each guarded sweep
    condemns another unit, and after a couple of hundred sweeps the census is
    almost entirely blacklisted and challenge rating reads ~0. That is exactly
    the "sits near zero, briefly hit 28" symptom.

    Now a unit needs to fail repeatedly before it is dropped, and the whole
    list expires periodically so a transient fault - a unit mid-spawn whose
    position is not valid yet - heals itself instead of being permanent.
--]]
local BAD_UNIT_STRIKES = 3
local BAD_UNIT_EXPIRY  = 30      -- seconds
local bad_units = {}
local bad_units_cleared_t = 0

--[[
    Rebuild the challenge rating sum, dropping anything no longer alive.

    The server counts only AGGROED minions. Aggro is not replicated, so we
    approximate it: a minion counts if it is within its own breed's
    detection_radius (times a tunable multiplier) of any living player.

    The multiplier exists because a minion that has already aggroed will chase
    you well beyond the range at which it first noticed you, so the raw
    detection radius alone under-counts an active fight.

    Turning the estimate off counts every living minion on the level, which
    reads dramatically high - pre-placed roamers stream in roughly 75 m ahead of
    the lead player, so there is always a large population you have not met.
--]]
--[[
    One sweep over the census.

    `guard` selects between two modes:

      false - the fast path. No pcall anywhere in the inner loop. Engine
              functions are hoisted into locals first, which is the same thing
              Fatshark do in their own hot loops (bot_group.lua:1206-1210).

      true  - the slow path, used only after the fast path has thrown. Every
              distance call is wrapped so the offending unit can be identified
              and blacklisted, after which we go back to the fast path.

    This is the whole optimisation. The previous version wrapped EVERY
    minion-player pair in a pcall: at 110 active minions and four players that
    is ~1,760 guarded C calls a second, and in LuaJIT a pcall boundary also
    stops the surrounding loop from staying compiled. Now the normal case costs
    exactly one pcall per sweep.
--]]
local function sweep(use_aggro, multiplier, guard)
    local distance_squared = Vector3.distance_squared
    local POSITIONS = POSITION_LOOKUP
    local ALIVE = HEALTH_ALIVE
    local units = player_units
    local num_players = #units

    local total, count = 0, 0
    local monsters, disablers = 0, 0

    --[[
        PLAYER POSITIONS ARE HOISTED - computed once, not per minion.

        The previous version called mod.unit_xyz(units[i]) inside the inner
        loop, so on Havoc it re-resolved all four player positions for every one
        of ~110 minions: roughly 440 lookups per census tick instead of 4. That
        is a 100x multiplier on the hottest loop in the mod, and together with
        the closure allocation it is what collapsed the framerate.

        Fatshark hoist their engine calls the same way in bot_group.lua:1206-1210.
    --]]
    local pxs, pys, pzs, pn = {}, {}, {}, 0
    for i = 1, num_players do
        local x, y, z = mod.unit_xyz(units[i])
        if x then
            pn = pn + 1
            pxs[pn], pys[pn], pzs[pn] = x, y, z
        end
    end

    for unit, info in pairs(tracked) do
        if not ALIVE[unit] then
            tracked[unit] = nil
        else
            --[[
                FAIL OPEN.

                A unit whose position we cannot measure is COUNTED, not
                dropped. We cannot prove it is far away, and the estimate
                already errs high by design - so including it is the honest
                direction to be wrong in.

                Excluding them was the bug behind "challenge rating sits at
                zero": every condemned unit silently vanished from the census
                until nothing was left. Simulated at a 20% failure rate, the
                old behaviour fell 60 -> 0 within thirty seconds and never
                recovered; failing open holds at 60.
            --]]
            local include = true
            local measurable = (bad_units[unit] or 0) < BAD_UNIT_STRIKES

            if use_aggro and num_players > 0 and measurable then
                --[[
                    Positions as plain NUMBERS, via Unit.world_position.

                    This loop used POSITION_LOOKUP and Vector3.distance_squared,
                    which is precisely the pair that fails from mod code -
                    "Vector3 expected, got userdata". Every comparison threw,
                    every unit was marked unmeasurable, and the challenge rating
                    stopped tracking. Numbers cannot be rejected or aliased.
                --]]
                local ux, uy, uz = mod.unit_xyz(unit)
                if ux then
                    local range = info.dr * multiplier
                    local range_sq = range * range
                    local closest

                    --[[
                        Pure arithmetic over the hoisted positions. No calls, no
                        pcall, no allocation - this is the innermost loop of the
                        whole mod and it now does nothing but subtract and
                        multiply.
                    --]]
                    for i = 1, pn do
                        local dx, dy, dz = ux - pxs[i], uy - pys[i], uz - pzs[i]
                        local d = dx * dx + dy * dy + dz * dz
                        if not closest or d < closest then
                            closest = d
                        end
                    end

                    if closest and closest > range_sq then
                        include = false
                    end
                end
            end

            if include then
                total = total + info.cr
                count = count + 1
                if info.monster  then monsters  = monsters  + 1 end
                if info.disabler then disablers = disablers + 1 end
            end
        end
    end

    return total, count, monsters, disablers
end

local function recalculate()
    local use_aggro_estimate = mod:get("use_aggro_estimate")
    local multiplier = mod:get("aggro_multiplier") or 2

    if use_aggro_estimate then
        refresh_player_units()
    end

    -- Let condemned units back in periodically, so a transient fault does not
    -- permanently erode the census.
    local now = mod._now or 0
    if now - bad_units_cleared_t > BAD_UNIT_EXPIRY then
        bad_units_cleared_t = now
        table.clear(bad_units)
    end

    -- Optimistic: run unguarded, and only pay for guards if it actually throws.
    local ok, total, count, monsters, disablers = pcall(sweep, use_aggro_estimate, multiplier, false)

    if not ok then
        -- Re-sweep with per-pair guards to find and blacklist the offender.
        -- Pruning is idempotent, so redoing the partial sweep is harmless.
        total, count, monsters, disablers = sweep(use_aggro_estimate, multiplier, true)
    end

    mod.state.challenge_rating = total or 0
    mod.state.minion_count = count or 0
    mod.state.monsters_alive = monsters or 0
    mod.state.disablers_alive = disablers or 0
end

-- ---------------------------------------------------------------------------
-- Prediction driver
--
-- Runs the tension model every frame (cheap: arithmetic only) but rebuilds the
-- strike board at 5Hz, since its inputs cannot change meaningfully faster than
-- that and sorting a 12-entry list per frame would be waste.
-- ---------------------------------------------------------------------------

--[[
    Previous min_coherency, for break edge detection.

    Declared here with the other board-tick state rather than beside its use.
    A local declared below the function that writes it turns the write into a
    GLOBAL while readers see an always-nil local - the scoping trap that has
    bitten this project repeatedly.
--]]
local last_min_coherency = nil

--[[
    HIGHEST number of triggers passed this mission - a high-water mark of
    positional progress, so a trigger fires once and only once however much you
    walk back and forth over it.

    Declared with the other board-tick state: a local declared below its writer
    turns the write into a GLOBAL while readers see an always-nil local.
--]]
local highest_triggers_passed = nil

local BOARD_INTERVAL = 0.2
local board_accumulator = 0

--[[
    There was a `budget_dirty` flag here. It has been removed.

    Nothing ever READ it - the board recomputes unconditionally at 5Hz, as the
    comment further down already says. Worse, one of the two writes sat at line
    530, far above this declaration, so it was assigning to a GLOBAL named
    budget_dirty rather than to this local. That is a namespace collision
    waiting to happen with any of the other ~110 loaded mods, in exchange for
    state nobody consumed.
--]]

--[[
    Spawn budget line.

    REPLACES the old ambush/blockade counters, which are gone.

    Those counters keyed off hordes running five or more waves, which is the
    only client-visible signature of a coordinated strike. In practice that
    detection almost never fired: the cached data shows ambush triggers exist on
    just 6 of 27 maps, and most missions have none at all. The row therefore sat
    at "amb?/4 blk?/3" for entire runs, which is not a readout - it is
    decoration that implies knowledge we do not have.

    What replaces it is measured against real cached geometry: how many monster
    and daemonhost candidate points the lead player has already walked past, out
    of how many the map holds. Passed candidates can never fire again
    (MonsterPacing.update removes an entry on spawn and its <= test cannot be
    re-satisfied by moving forward), so this is a genuine progress bar through
    the map's danger, not a guess.
--]]
local function update_budget_line()
    local Spawns = mod.Spawns
    if not Spawns or Spawns.count() == 0 then
        mod.state.budget_line = nil
        return
    end

    local parts = {}
    local kinds = {
        { "pacing_monsters", "mon" },
        { "pacing_witches",  "dh"  },
    }

    for i = 1, #kinds do
        local kind, short = kinds[i][1], kinds[i][2]
        local seen, total = Spawns.budget_of(kind)
        if total > 0 then
            parts[#parts + 1] = string.format("%s%d/%d", short, seen, total)
        end
    end

    mod.state.budget_line = #parts > 0 and table.concat(parts, " ") or nil
end

local function update_prediction(dt, t)
    local state = mod.state
    local cfg = mod.cfg
    if not cfg then return end

    state.pacing_state = Predict.update_tension(dt, t, cfg, state)
    state.tension = Predict.tension()

    board_accumulator = board_accumulator + dt
    if board_accumulator >= BOARD_INTERVAL then
        --[[
            Capture the REAL elapsed time before the reset.

            board_accumulator is zeroed, not decremented, so the overshoot past
            BOARD_INTERVAL is thrown away. Anything time-based driven off this
            tick must use the accumulated value, not the constant, or it runs
            slow by exactly that discarded remainder - which for a wave timer
            compounds over a mission.
        --]]
        local board_dt = board_accumulator
        board_accumulator = 0
        Predict.update_board(strike_defs(), state, spent)

        --[[
            Recomputed every board tick (5Hz), NOT gated on budget_dirty.

            The dirty flag was only ever raised by the five-wave horde detector
            that fed the old ambush/blockade counters. Once those were removed
            nothing set it again, so the spawn budget line rendered its
            mission-start value - 0 of N - and stayed there for the whole run
            no matter how many spawn points you walked past.

            The recompute scans the trigger array twice, ~70 iterations for a
            typical map, five times a second. That is far cheaper than the
            bookkeeping needed to keep a dirty flag honest.
        --]]
        update_budget_line()

        --[[
            Allocated count, on the board tick rather than per frame.

            5 Hz is far finer than needed: the cap matters as a state you are
            in or out of, not as a number to watch tick. Reading it here rather
            than in the frame path also keeps the engine call off the hot path,
            which is where this mod's per-frame budget has repeatedly gone
            wrong before.
        --]]
        --[[
            Reconcile the cap census here, on the 4Hz board tick - never per
            frame. Death hooks get missed (despawns, level transitions, a hook
            that did not fire) and an increment-only counter drifts upward
            forever without this.
        --]]
        if mod.Cap then
            pcall(mod.Cap.reconcile)
            pcall(mod.Cap.warn_once)
        end

        --[[
            Cascade timer, on the same 4Hz tick. The shortest interval in the
            pattern is five seconds, so quarter-second resolution is already
            far finer than the thing being modelled.
        --]]
        --[[
            Chat posting shares the board tick. It has its own accumulator and
            a hard 10s floor, so it cannot post faster than the setting says
            no matter how often this runs.
        --]]
        if mod.Post then
            pcall(mod.Post.update, board_dt)

            --[[
                Event watching shares the tick. It compares against the
                previous tick's values, so it must run every tick rather than
                on the post interval - otherwise a band change that happened
                and reverted between posts is never seen.
            --]]
            pcall(mod.Post.check_events)
        end

        if mod.Cascade then
            pcall(mod.Cascade.update, board_dt)

            --[[
                Sample the horde population for the "time since last horde"
                clock. Read off the cap census, which already counts these, so
                this costs one table read rather than a second sweep.
            --]]
            if mod.Cap then
                local c = mod.Cap.read()
                if c then
                    pcall(mod.Cascade.sample_horde, (c.horde or 0) + (c.roamer or 0))
                end
            end

            --[[
                TRIGGER CROSSING, from the RitualZones-derived spawn cache.

                Spawns.remaining(lead) counts triggers ahead of the lead
                player that have not been consumed. When that count DROPS, a
                trigger has just been crossed - which is a new section of the
                map and therefore a fresh wave cycle, whether or not anything
                actually spawned there.

                This is the room signal the cascade needed all along, and it
                needs no hand-placed markers: the cache already carries trigger
                distances for every map in the pool.

                Edge-detected on the count rather than on distance, because
                retire_passed already does the bookkeeping and duplicating that
                logic here would be a second place for it to drift.
            --]]
            --[[
                Fetched HERE, not borrowed from an enclosing scope.

                `local Spawns = mod.Spawns` exists inside
                update_budget_line(), which is a DIFFERENT function - reading
                it from here would have resolved to nil (or worse, a global),
                and the crossing detector would have silently never fired.
                That scoping trap has cost this project real debugging time
                more than once.
            --]]
            local Spawns = mod.Spawns
            local lead = state.lead

            if lead and Spawns and Spawns.passed then
                local ok_r, passed = pcall(Spawns.passed, lead)

                if ok_r and type(passed) == "number" then
                    --[[
                        WATERMARK, NOT A DELTA. This is the back-and-forth fix.

                        Spawns.remaining counts triggers AHEAD of the lead, so
                        it falls as you advance and RISES when you walk back.
                        Comparing against the previous tick therefore fired
                        every time you re-crossed the same trigger: forward
                        (fall, fire), back (rise), forward again (fall, fire
                        again). Pacing back and forth over one trigger could
                        run the wave counter up indefinitely.

                        Comparing against the LOWEST value ever seen fixes it
                        structurally rather than with a cooldown: a trigger can
                        only ever be crossed for the first time once, because
                        the watermark never rises. Re-crossing old ground
                        cannot beat a low that already stands.

                        A cooldown was the other option and it would have been
                        wrong - it only limits how FAST you can inflate the
                        count, not whether you can.
                    --]]
                    --[[
                        HIGH-WATER MARK ON TRIGGERS PASSED, not on triggers
                        remaining.

                        remaining() also drops when a spawn CONSUMES a trigger,
                        so watching it reset the wave cycle every time a
                        monstrosity spawned - which is what made a weakened
                        boss appear to knock the counter back to 0/10.

                        passed() is positional only. It rises as you advance,
                        falls if you walk back, and a spawn cannot move it. The
                        mark keeps back-and-forth from re-firing the same
                        trigger, exactly as before.
                    --]]
                    local high = highest_triggers_passed

                    if high and passed > high then
                        pcall(mod.Cascade.reset_cycle, "trigger")
                    end

                    if not high or passed > high then
                        highest_triggers_passed = passed
                    end
                end
            end

            --[[
                COHERENCY BREAK EDGE.

                Without this the cascade's acceleration could never fire -
                coherency_break() existed but nothing called it, so the wave
                row's "x3 BROKEN" marker was unreachable. Caught on review, not
                in play, which is the cheap place to catch it.

                Edge-detected, not level-detected: min_coherency <= 1 means
                somebody is alone, and that is true for as long as they stay
                alone. Counting it every tick would multiply one break into
                twenty and drive the accelerated timer permanently. Only the
                TRANSITION into that state is a break.

                min_coherency is already maintained by the census, so this
                costs one comparison per board tick.
            --]]
            --[[
                ONLY MEANINGFUL WITH A TEAM.

                state.min_coherency is initialised to 4 and only lowered by
                living teammates (line 2404-2416). In SOLO PLAY there are no
                teammates, so it never moves and this edge can never fire -
                which is why acceleration never appeared during solo testing.
                Guarding on the player count makes that explicit rather than
                leaving it as a silent no-op.
            --]]
            local players = #player_units

            if players > 1 then
                local mc = state.min_coherency or 4
                local was = last_min_coherency or 4

                if mc <= 1 and was > 1 then
                    pcall(mod.Cascade.coherency_break, "distance")
                end

                last_min_coherency = mc
            end
        end

        state.allocated = mod.read_allocated()
        state.alloc_capped = (state.allocated ~= nil)
            and (state.allocated > mod.HARD_ALLOCATED_LIMIT)
            or false

        if state.allocated and (not state.peak_allocated or state.allocated > state.peak_allocated) then
            state.peak_allocated = state.allocated
        end
    end
end

--- Return every derived value to its start-of-mission state.
local function reset_run_state()
    local s = mod.state

    table.clear(tracked)
    spawn_stamps = {}

    s.challenge_rating = 0
    s.minion_count     = 0
    s.lead, s.tail     = nil, nil
    s.furthest         = 0
    s.spread           = 0
    s.backtrack        = 0
    s.ticket_m         = nil
    s.last_wave_t      = nil
    s.horde_active     = false
    s.hordes_seen      = 0
    s.since_horde      = 0
    s.alone_seconds    = 0
    s.min_coherency    = 4
    s.alive_players    = 0
    s.speedrun_checks  = 0
    s.last_trickle_t, s.last_trickle_dist = nil, 0
    s.horn_at, s.cue_kind, s.cue_until = nil, nil, nil
    s.horn_counted_t = nil
    s.pace, s.pace_sampled_t, s.pace_sampled_dist = nil, 0, 0
    s.pacing_started, s.start_distance = false, 0
    s.monsters_alive, s.disablers_alive = 0, 0
    mod._bad_position_pairs = 0
    s.lead_is_alone    = false
    s.ramp_units       = 0
    s.ramp_pct         = 0
    s.ramp_locked      = false
    s.warnings_version = (s.warnings_version or 0) + 1

    table.clear(bad_units)
    for i = #warnings_buffer, 1, -1 do
        warnings_buffer[i] = nil
    end

    speedrun_next_check = 0
    speedrun_last_lead  = nil
    last_forward_t      = 0
    mod._now            = 0

    table.clear(spent)
    s.pacing_state, s.low_state_seconds, s.tension = nil, 0, 0
    s.budget_line, s.ramp_key_holder, s.ramp_key_ready = nil, nil, false

    -- Allocated tracking is per mission. peak_allocated in particular must not
    -- carry over, or the clean-run line would report the previous run's high
    -- water mark and quietly misattribute it.
    s.allocated, s.alloc_capped, s.peak_allocated = nil, false, nil

    Predict.reset()
    Predict.reset_tension()
    board_accumulator = 0

    if mod.Pace and mod.Pace.reset then
        pcall(mod.Pace.reset)
    end

    -- Re-detect on every mission: rank changes between assignments.
    detect_rank()
    apply_cfg()
end

mod.reset_run_state = reset_run_state

local path_accumulator = 0


--[[
    Per-subsystem circuit breakers.

    Anything that throws inside a per-frame loop throws sixty times a second,
    and the symptom is an unreadable wall of red plus a framerate drop rather
    than a usable error. So each subsystem is caught, reported a few times, then
    stopped.

    Critically these are PER SUBSYSTEM. The first version used one breaker for
    everything, so when the census threw, the path, horde clock and tripwires -
    all of which were working fine - stopped updating too, and the overlay
    froze with every value at zero. A fault in the least reliable estimate
    should not take down the three exact readouts.
--]]
local MAX_ERRORS = 5
local breakers = {}

-- Exposed so /htspawns can report whether a subsystem has been shut off.
mod.breaker_count = function(name)
    local b = breakers[name]
    return b and b.count or 0
end

--[[
    SUBSYSTEM PROFILER
    ==================

    Every previous framerate investigation on this mod was a guess, and the
    console logs say why guessing kept failing: the engine profiler attributes
    stalls to `Lua->update` and stops there. It cannot see inside, so it can
    tell you Lua cost 126 of 185 seconds of stall time and not which Lua.

    guarded() is already the single chokepoint every per-frame subsystem passes
    through, so it is the one place that can answer this for free. When the
    profiler is off - which is always, unless you type /htperf - the cost is
    one boolean test per call, and nothing else changes.

    Run /htperf, play for a minute, run /htperf again. It prints ms/frame per
    subsystem, sorted, so the answer is a number rather than an argument.
--]]
--[[
    ALWAYS ON IN A MISSION, AND IT REPORTS ITSELF.

    The manual version shipped and was never run, which is a design failure
    rather than a user one: the moment you most want the numbers is mid-fight
    at 18 fps, which is exactly when nobody stops to type a command.

    So it collects unconditionally and writes a line to the log every
    AUTO_REPORT_INTERVAL seconds. The cost is one os.clock pair around eight
    calls per frame - roughly 480 os.clock calls a second, which is noise
    against a 50ms frame, and it buys an answer that three rounds of static
    analysis did not.

    THE ENTITY COUNT IS ON THE SAME LINE, deliberately.

    Dio's observation is that the collapse tracks how much is on screen rather
    than how long the mission has run, and the fps curve agrees - 55 fps at
    the start, 18 at full density, recovering as the mission winds down. That
    makes this a per-entity cost, and a per-entity cost is only diagnosable if
    the cost and the entity count are measured together.

    Pairing them also settles the "it could be any mod" question by
    subtraction. FpsDoctor already logs total ms/frame on its own line. If this
    line says HavocTracker is 0.4ms while the frame is 50ms, HavocTracker is
    not the problem and the remaining 49.6ms belongs to something else - which
    is a conclusion, not a guess.
--]]
local AUTO_REPORT_INTERVAL = 30.0

local perf_on = true
local perf = {}
local perf_frames = 0
local perf_started = 0
local perf_last_report = 0

--[[
    Written to the log rather than echoed to chat. A line every thirty seconds
    in the console is a diagnostic; the same line in the chat feed is spam that
    would get the whole mod turned off.
--]]
local function perf_auto_report()
    local wall = os.clock() - perf_started
    local frames = math.max(perf_frames, 1)

    local grand, worst, worst_name = 0, 0, nil

    for name, total in pairs(perf) do
        grand = grand + total

        if total > worst then
            worst, worst_name = total, name
        end
    end

    -- Live minion count, the quantity the cost is suspected to scale with.
    local entities = (mod.state and mod.state.minion_count) or 0
    local allocated = mod.read_allocated and mod.read_allocated() or nil

    mod:info(string.format(
        "PERF %.1fs | %d frames (%.1f fps) | minions %d alloc %s | HavocTracker %.3f ms/frame | worst %s %.3f ms/frame",
        wall, perf_frames, perf_frames / math.max(wall, 0.001),
        entities, tostring(allocated or "?"),
        (grand * 1000) / frames,
        tostring(worst_name or "-"), (worst * 1000) / frames))

    -- Window reset, so each line describes the last thirty seconds rather
    -- than a mission-long average that hides the ramp.
    for k in pairs(perf) do
        perf[k] = nil
    end

    perf_frames = 0
    perf_started = os.clock()
end

mod.perf_frame = function()
    if not perf_on then
        return
    end

    perf_frames = perf_frames + 1

    local t = os.clock()

    if perf_started == 0 then
        perf_started = t
        perf_last_report = t
        return
    end

    if (t - perf_last_report) >= AUTO_REPORT_INTERVAL then
        perf_last_report = t
        pcall(perf_auto_report)
    end
end

--[[
    /htperf now PRINTS the current window rather than toggling collection,
    because collection no longer needs turning on. Kept as a command so the
    numbers can be read on demand instead of waiting for the next auto line.
--]]
mod.perf_toggle = function()
    local wall = os.clock() - perf_started
    local frames = math.max(perf_frames, 1)

    local entities = (mod.state and mod.state.minion_count) or 0

    mod:echo(string.format("[HavocTracker] last %.1fs: %d frames (%.1f fps), %d live minions",
        wall, perf_frames, perf_frames / math.max(wall, 0.001), entities))

    -- Sorted by total cost, because the question is always "what is worst".
    local rows = {}
    local grand = 0

    for name, total in pairs(perf) do
        rows[#rows + 1] = { name = name, total = total }
        grand = grand + total
    end

    table.sort(rows, function(x, y) return x.total > y.total end)

    for i = 1, #rows do
        local r = rows[i]
        mod:echo(string.format("  %-12s %7.3f ms/frame   %5.1f pct of mod cost   (%6.2fs total)",
            r.name, (r.total * 1000) / frames, (r.total / math.max(grand, 1e-9)) * 100, r.total))
    end

    local ms_frame = (grand * 1000) / frames

    mod:echo(string.format("  %-12s %7.3f ms/frame   of a %.1f ms frame budget at 60fps",
        "TOTAL", ms_frame, 16.7))

    --[[
        THE ATTRIBUTION LINE.

        The whole point of measuring this mod precisely is to be able to rule
        it out. Comparing its cost against the ACTUAL frame time - derived
        from the frames and wall clock this window just measured - says
        directly whether the answer is in here or somewhere among the other
        ninety-odd mods.
    --]]
    local actual_ms = (wall * 1000) / frames

    mod:echo(string.format("  actual frame %.1f ms - HavocTracker is %.1f pct of it, %.1f ms is elsewhere",
        actual_ms, (ms_frame / math.max(actual_ms, 0.001)) * 100,
        math.max(actual_ms - ms_frame, 0)))

    if entities > 0 then
        mod:echo(string.format("  per live minion: %.4f ms of HavocTracker, %.4f ms total",
            ms_frame / entities, actual_ms / entities))
    end
end

mod:command("htperf", "toggle the subsystem profiler, then print ms/frame", mod.perf_toggle)

local function guarded(name, fn, a, b, c)
    local breaker = breakers[name]
    if not breaker then
        breaker = { count = 0 }
        breakers[name] = breaker
    end

    if perf_on then
        local t0 = os.clock()
        local ok, result = pcall(fn, a, b, c)
        perf[name] = (perf[name] or 0) + (os.clock() - t0)

        if ok then
            return result
        end

        breaker.count = breaker.count + 1
        mod:error("%s failed (%d/%d): %s", name, breaker.count, MAX_ERRORS, tostring(result))
        return nil
    end

    if breaker.count >= MAX_ERRORS then
        return nil
    end

    local ok, result = pcall(fn, a, b, c)
    if ok then
        return result
    end

    breaker.count = breaker.count + 1
    mod:error("%s failed (%d/%d): %s", name, breaker.count, MAX_ERRORS, tostring(result))

    if breaker.count >= MAX_ERRORS then
        mod:echo(mod:localize("breaker_subsystem", name))
    end

    return nil
end

mod.reset_breaker = function()
    for _, breaker in pairs(breakers) do
        breaker.count = 0
    end
end

mod.breaker_status = function()
    local out = {}
    for name, breaker in pairs(breakers) do
        if breaker.count > 0 then
            out[#out + 1] = string.format("%s=%d", name, breaker.count)
        end
    end
    return #out > 0 and table.concat(out, " ") or "all ok"
end

-- DMF calls this automatically once per frame. It is not called from the HUD
-- element; doing both would run the prune timer at double rate.
mod.update = function(dt)
    if not mod:is_enabled() then
        return
    end

    mod.state.in_mission = is_valid_mission()

    if not mod.state.in_mission then
        if next(tracked) or mod.state.furthest > 0 then
            reset_run_state()
        end
        --[[
            FORGET, do not remove.

            in_mission has just gone false, which means the mission is being
            torn down and the world-marker element may already be destroyed.
            Politely removing each marker at that point reaches into an object
            that no longer exists. The element disposes of its own markers, so
            dropping our bookkeeping is both sufficient and safe.
        --]]
        if mod.forget_spawn_markers then
            pcall(mod.forget_spawn_markers)
        end
        -- Unit references die with the level; keeping them across a restart is
        -- a use-after-free waiting for the allocator to reuse the memory.
        if mod.reset_daemonhosts then
            pcall(mod.reset_daemonhosts)
        end
        -- Ritual sites are level geometry; a new level means a new scan.
        if mod.reset_ritual_sites then
            pcall(mod.reset_ritual_sites)
        end
        if mod.reset_event_sites then
            pcall(mod.reset_event_sites)
        end
        mod.state.spawn_rebind_tries = 0
        return
    end

    -- Frame counter for /htperf. One boolean test when the profiler is off.
    mod.perf_frame()

    -- Single monotonic clock shared by every module, so the spawn detector and
    -- the tripwire timers cannot disagree.
    mod._now = (mod._now or 0) + dt
    local t = mod._now

    -- Both rates are settings. The census is the expensive one: its cost scales
    -- with the number of live minions, which on Havoc peaks at 110.
    prune_accumulator = prune_accumulator + dt
    if prune_accumulator >= (mod:get("census_interval") or PRUNE_INTERVAL) then
        prune_accumulator = 0
        guarded("census", recalculate)
    end

    guarded("horde", update_horde_clock, t)

    -- Escape hatch: the predictive layer is the newest and least proven part.
    -- Turning it off leaves the measured readouts fully intact.
    if mod:get("enable_prediction") ~= false then
        guarded("predict", update_prediction, dt, t)
    end

    path_accumulator = path_accumulator + dt
    path_dt = path_dt + dt
    if path_accumulator >= (mod:get("path_interval") or 0.1) then
        path_accumulator = 0
        local gained = guarded("path", update_path) or 0
        guarded("ramp", update_ramp, path_dt, t, gained)
        --[[
            Pace runs BEFORE the tripwires: the tripwire warnings now read its
            speed-running, rush and loner state, which mirror the server's
            rules (HavocTracker_pace.lua) instead of approximating them.
        --]]
        if mod.Pace then
            guarded("pace", mod.Pace.update)
        end
        guarded("tripwires", update_tripwires, path_dt, t)
        path_dt = 0
    end

    -- World markers. Self-throttled to 2Hz internally; guarded because it talks
    -- to the event system, which is outside our control.
    if mod.update_spawn_markers then
        guarded("markers", mod.update_spawn_markers, dt)
    end

    if mod.update_daemonhosts then
        guarded("daemonhost", mod.update_daemonhosts)
    end

    -- Event-zone check: cheap (a handful of 2D distances) and it decides
    -- whether the rest of the panel is telling the truth.
    if mod.update_event_zone then
        guarded("eventzone", mod.update_event_zone)
    end

    --[[
        Punishment state: coherency, the disabler cap and the last-standing
        grace timer. Folded into the path throttle rather than run per frame -
        it walks four players and reads two components each, and none of those
        answers changes meaningfully inside 100ms.
    --]]
    if mod.__ht_punish then
        guarded("punish", mod.__ht_punish.update)
    end

    --[[
        Audio cue on the nearest trigger entering the red band.

        Edge-triggered on the transition, not the state, or it would fire every
        frame you spend inside 15m - which is most of a fight.
    --]]
    local Spawns = mod.Spawns
    if Spawns and mod.state.lead and mod:get("spawn_audio_cue") ~= false then
        local nearest = Spawns.upcoming(mod.state.lead, 1)[1]
        local band = nearest and nearest.band or nil
        if band == "imminent" and mod.state.last_alert_band ~= "imminent" then
            mod.play_alert("imminent")
        end
        mod.state.last_alert_band = band
    end
end

--[[
    ONE handler only.

    DMF assigns these as plain fields, so a second `mod.on_game_state_changed =`
    anywhere in the file silently replaces the first - no warning, no error, the
    earlier one simply stops running. Both the run-state reset and the spawn
    forecast binding live here for that reason. Do not add another.
--]]
mod.on_game_state_changed = function(status, state_name)
    -- Wipe everything between missions so nothing leaks across a run, and give
    -- the breaker a fresh start in case the fault was mission-specific.
    if status == "enter" and state_name == "StateLoading" then
        reset_run_state()
        mod.reset_breaker()
    end

    local Spawns = mod.Spawns
    if not Spawns then
        return
    end

    if state_name == "StateGameplay" and status == "enter" then
        --[[
            Clear the cap census per mission. Units from the previous run are
            long dead but their entries would survive a mission change, and a
            stale entry is a permanent +1 on the budget.
        --]]
        if mod.Cap then
            pcall(mod.Cap.reset)
            pcall(mod.Cap.clear_warning)
        end

        if mod.Cascade then
            pcall(mod.Cascade.reset)
        end

        if mod.Post then
            pcall(mod.Post.reset)
        end

        -- Or the first tick of a new mission reads last run's value as the
        -- "previous" state and can fire a phantom break / phantom crossing.
        last_min_coherency = nil
        highest_triggers_passed = nil

        local bound = Spawns.ensure_mission()
        if bound then
            mod:info("[HavocTracker] spawn forecast bound to %s (%d triggers)",
                tostring(bound), Spawns.count())
        else
            mod:info("[HavocTracker] no cached spawn data for this mission")
        end
    elseif status == "exit" and state_name == "StateGameplay" then
        --[[
            Flush BEFORE reset, or the log and cache lose the mission name and
            tier they are supposed to be recorded against.

            This is also the ONLY place the user cache is written. Everything
            learned during the mission mutates memory and sets a dirty flag;
            the disk write happens here, on the loading screen, where a stall
            costs nothing.
        --]]
        if mod.flush_log then
            pcall(mod.flush_log)
        end
        if Spawns.flush_cache then
            pcall(Spawns.flush_cache)
        end
        -- Written before teardown, so a crash during mission end still leaves
        -- the record of what had already failed.
        if mod.write_try_report then
            pcall(mod.write_try_report, "mission end")
        end
        --[[
            Forget markers, do not remove them. The HUD element is being torn
            down with the mission and takes its own markers with it; reaching
            into it on the way out is what crashed on /restart.
        --]]
        if mod.forget_spawn_markers then
            pcall(mod.forget_spawn_markers)
        end
        -- Unit references die with the level; keeping them across a restart is
        -- a use-after-free waiting for the allocator to reuse the memory.
        if mod.reset_daemonhosts then
            pcall(mod.reset_daemonhosts)
        end
        -- Ritual sites are level geometry; a new level means a new scan.
        if mod.reset_ritual_sites then
            pcall(mod.reset_ritual_sites)
        end
        -- Do not carry a hidden HUD into the next mission.
        if mod.reset_hud_hidden then
            pcall(mod.reset_hud_hidden)
        end
        Spawns.reset()
    end
end

-- ---------------------------------------------------------------------------
-- Band helper, shared with the HUD element
-- ---------------------------------------------------------------------------

--- Returns band_key, label for the current challenge rating.
mod.band = function(cr)
    local t = mod.THRESHOLDS

    if cr >= t.hordes then
        return "hordes", L("band_hordes")
    elseif cr >= t.specials then
        return "specials", L("band_specials")
    elseif cr >= t.trickle then
        return "trickle", L("band_trickle")
    end

    return "none", L("band_none")
end

-- ---------------------------------------------------------------------------
-- HUD element registration
-- ---------------------------------------------------------------------------

--[[
    VISIBILITY GROUPS: FIVE, NOT TWO.

    The game defines fourteen groups (hud_visibility_groups.lua) and shows an
    element only while the ACTIVE group lists it. UIHud builds that list from
    the visibility_groups below, so a group left out here is a state in which
    the overlay is not drawn at all.

    These used to be { "dead", "alive" }, which meant the panel silently
    vanished whenever the HUD switched to any other group:

        communication_wheel     every time the ping wheel is held
        tactical_overlay        every time Tab is held
        player_in_danger_zone   the entire time you stand in a hazard

    The last one is why this looked random rather than tied to a button. In
    Havoc you are in a danger zone constantly, so the overlay would drop out
    and come back with nothing the player did to explain it.

    The set below is what every persistent vanilla element asks for -
    TeamPanelHandler, CombatFeed, BossHealth and PlayerBuffs all use exactly
    these five. Matching them means the tracker is on screen in the same
    states the team panel is, which is the right benchmark: both are things
    you read mid-fight.

    DELIBERATELY NOT INCLUDED:

        in_view, in_hub_view    a menu is open; the HUD should be gone
        popup, cutscene         not gameplay
        emote_wheel             emoting is not a moment for a spawn readout
        disabled, testify,
        onboarding, prologue_*  not states this mod runs in
--]]
local VISIBILITY_GROUPS = {
    "dead",
    "alive",
    "communication_wheel",
    "tactical_overlay",
    "player_in_danger_zone",
}

--[[
    CUSTOM HUD OWNS A NODE ONCE YOU HAVE DRAGGED IT.

    custom_hud lists every element in the HUD's visibility groups (which is
    why both panels appear in its editor) and lists each child of the
    scenegraph root as a movable box. When a box is saved it keeps
    mod._position_overrides[element].nodes[scenegraph_id] and re-pins that
    node after every UIHud.update (custom_hud.lua:540-553).

    The panels used to re-assert their own slider position every frame, so a
    drag in custom_hud never stuck and the two fought over the node, each
    write forcing a full scenegraph rebuild. Now they step aside:

      - while custom_hud's editor is open (is_customizing), so a drag is live
      - while custom_hud is enabled and has a saved position for that node

    Resetting the box in custom_hud hands the panel back to the sliders.
--]]
function mod.custom_hud_owns(element, scenegraph_id)
    local ch = get_mod and get_mod("custom_hud")
    if not ch then
        return false
    end
    if ch.is_enabled and not ch:is_enabled() then
        return false
    end
    if rawget(ch, "is_customizing") then
        return true
    end
    local overrides = rawget(ch, "_position_overrides")
    local entry = overrides and overrides[element]
    local nodes = entry and entry.nodes
    return type(nodes) == "table" and nodes[scenegraph_id] ~= nil
end

local hud_elements = {
    {
        class_name = "HudElementHavocTracker",
        filename   = "Dio's HavocTracker/scripts/mods/HavocTracker/HavocTracker_HUDElement",
        use_hud_scale = true,
        visibility_groups = VISIBILITY_GROUPS,
    },
    {
        class_name = "HudElementSpawnPanel",
        filename   = "Dio's HavocTracker/scripts/mods/HavocTracker/HavocTracker_SpawnPanel",
        use_hud_scale = true,
        visibility_groups = VISIBILITY_GROUPS,
    },
}

for i = 1, #hud_elements do
    mod:add_require_path(hud_elements[i].filename)
end

local function add_hud_element(elements)
    for n = 1, #hud_elements do
        local el = hud_elements[n]
        local i, existing = table.find_by_key(elements, "class_name", el.class_name)
        if not i or not existing then
            table.insert(elements, el)
        else
            elements[i] = el
        end
    end
end

mod:hook_require("scripts/ui/hud/hud_elements_player", add_hud_element)
mod:hook_require("scripts/ui/hud/hud_elements_player_onboarding", add_hud_element)
mod:hook_require("scripts/ui/hud/hud_elements_spectator", add_hud_element)

-- ---------------------------------------------------------------------------
-- World markers
--
-- Uses the game's own world-marker system rather than projecting positions to
-- screen space by hand. Registration pattern lifted from RitualZones
-- (RitualZones.lua:8101-8152), which is known to work on this build: the
-- template must be re-inserted into _marker_templates on BOTH init and update,
-- because the HUD element rebuilds that table when the element is recreated
-- (mission load, spectator handoff) and a template registered only at init
-- silently disappears.
-- ---------------------------------------------------------------------------

-- ---------------------------------------------------------------------------
-- Spawn consequences, daemonhost skip range, audio cue, accuracy log
-- ---------------------------------------------------------------------------

--[[
    Forced horde / pacing pause.

    See Spawns.spawn_effects for the source citations. The short version: at
    Havoc challenge tiers a monster spawn FORCES a horde and suppresses nothing,
    while at low tiers it suppresses hordes for a minute. Both are certainties,
    not estimates, which makes this the highest-confidence warning in the mod.
--]]
mod.on_monster_spawned = function(breed_name)
    local Spawns = mod.Spawns
    if not Spawns or not Spawns.spawn_effects then
        return
    end

    local ok, fx = pcall(Spawns.spawn_effects)
    if not ok or not fx then
        return
    end

    local s = mod.state
    local now = mod._now or 0

    if fx.force_horde then
        --[[
            force_horde_pacing_spawn queues a horde immediately. There is no
            published delay, so this window is a display hint, not a countdown
            to a known event - it is flagged as such in the panel.
        --]]
        s.forced_horde_t = now
        mod.play_alert("forced_horde")
    end

    -- Longest pause wins for display purposes; they run concurrently.
    local longest, which = 0, nil
    for spawn_type, duration in pairs(fx.pause or {}) do
        if duration > longest then
            longest, which = duration, spawn_type
        end
    end

    if longest > 0 then
        s.pacing_pause_until = now + longest
        s.pacing_pause_type  = which
    else
        s.pacing_pause_until = nil
        s.pacing_pause_type  = nil
    end

    if mod.log_event then
        mod.log_event("monster_spawn", breed_name, fx.force_horde and "forced_horde" or "pause")
    end
end

--[[
    Daemonhost skip tracking.

    havoc_monster_pacing_template.lua sets
        despawn_distance_when_passive = { chaos_daemonhost = 65 }
    so a daemonhost you have not woken despawns once every player is 65m away.
    That is the difference between "we skipped it" and "it is still behind us".
--]]
local DH_DESPAWN_M = 65

--[[
    Unit references, and therefore MUST be dropped at mission end.

    This table was never cleared. Units belong to a level; when the level is
    destroyed those references point at freed engine memory. Reading one is
    undefined - on the first restart the memory is often still mapped and
    everything appears fine, by the second it has been reused and touching it
    takes the game down. That is exactly the "first restart OK, second crashes"
    pattern.

    Unit.is_valid does NOT save you here: it is a validity check for a live
    unit, not a use-after-free guard.
--]]
local daemonhosts = {}

local function reset_daemonhosts()
    daemonhosts = {}
    local s = mod.state
    if s then
        s.daemonhost_m, s.daemonhost_skip = nil, false
        s.ritual_near_m, s.ritual_armed, s.ritual_warned = nil, false, false
    end
end
mod.reset_daemonhosts = reset_daemonhosts

--[[
    Chaos ritual settings, read from the game's own tables.

    havoc_mutator_local_settings.lua:507-511 --
        mutator_havoc_chaos_rituals = {
            force_horde_on_spawn = true,
            trigger_distance = 55,
            num_to_spawn_per_mission = { cm_habs = 3, hm_complex = 5, ... },
        }

    Three things worth surfacing, all of them certainties rather than estimates:

      * 55m is a PROXIMITY trigger. Unlike monster spawns, this one does not
        care about travel distance along the path - walk within 55m of a ritual
        and it fires, whatever direction you came from.

      * force_horde_on_spawn is true, so a ritual trigger brings a horde with
        it. Same guarantee as the monster forced horde at Havoc tiers.

      * The per-mission count is fixed and known, so "3 rituals left" is exact.

    This is the useful half of what RitualZones does. What it is NOT doing is
    the per-frame find_ritual_units scan that falls back to iterating every
    enemy on the level - that is the part that causes the crash, and we get the
    same information from registration-time detection at zero cost.
--]]
local ritual_settings = nil
local ritual_settings_tried = false

local function get_ritual_settings()
    if ritual_settings_tried then
        return ritual_settings
    end
    ritual_settings_tried = true

    local ok, s = pcall(function()
        local H = rawget(_G, "HavocMutatorLocalSettings")
        if not H then
            H = require("scripts/settings/havoc/havoc_mutator_local_settings")
        end
        return H and H.mutator_havoc_chaos_rituals or nil
    end)

    if ok and type(s) == "table" then
        ritual_settings = s
    end
    return ritual_settings
end

--- Total rituals this mission, or nil when the modifier is not active/known.
local function ritual_total()
    local s = get_ritual_settings()
    local per = s and s.num_to_spawn_per_mission
    if not per then
        return nil
    end
    local Spawns = mod.Spawns
    local mission = Spawns and Spawns.mission()
    return mission and per[mission] or nil
end

local function ritual_trigger_distance()
    local s = get_ritual_settings()
    return (s and tonumber(s.trigger_distance)) or 55
end

--[[
    is_ritual distinguishes the two breeds. Ritual hosts drive the 55m proximity
    warning; pacing hosts drive the 65m skip readout. Conflating them would have
    the skip advice fire on a ritual, which is wrong - a ritual is not something
    you skip by backing off.
--]]
mod.on_daemonhost_spawned = function(unit, is_ritual)
    daemonhosts[unit] = is_ritual and "ritual" or "pacing"
    if mod.log_event then
        mod.log_event("daemonhost_spawn",
            is_ritual and "chaos_mutator_daemonhost" or "chaos_daemonhost", "")
    end

    --[[
        Record where it appeared, but ONLY while hosting.

        As a client our travel distance is trustworthy but the run's geometry
        may not match what we later replay against, and writing client-derived
        points would slowly poison the cache with positions from a route we
        cannot verify. Hosting is ground truth, so only host observations are
        kept.
    --]]
    local Spawns = mod.Spawns
    if is_ritual and Spawns and Spawns.is_live() and Spawns.note_observed then
        local d = mod.travel_distance_of and mod.travel_distance_of(unit)
        if d then
            Spawns.note_observed("ritual_spawn", d)
        end
    end
end

--[[
    Read a unit's position as three plain numbers.

    Same discipline as euclidean_spread: POSITION_LOOKUP hands back an engine
    temporary, so extract the components immediately rather than holding the
    Vector3 across a loop. Holding two at once and calling distance_squared is
    exactly what produced "Vector3 expected, got userdata" and silent zeroes.
--]]
local function xyz_of(unit)
    -- The lookup itself is guarded: indexing POSITION_LOOKUP with a unit from
    -- a destroyed level is not a safe read either.
    -- Routed through the shared helper so daemonhosts benefit from the same
    -- Unit.world_position fix as everything else.
    return mod.unit_xyz(unit)
end

--[[
    Ritual tick speed - EXACT, from the daemonhost's own behaviour tree.

    bt_chaos_mutator_daemonhost_passive_action.lua:_get_closest_player

        local ahead_unit, ahead_travel_distance = Managers.state.main_path:ahead_unit(1)
        if not main_path_ready() then
            return nil
        end
        local _, monster_travel_distance = MainPathQueries.closest_position(nav_mesh_position)
        local closest_position = MainPathQueries.position_from_distance(monster_travel_distance - close_distance_offset)
        local _, closest_position_distance = MainPathQueries.closest_position(closest_position)
        local far_position = MainPathQueries.position_from_distance(monster_travel_distance - far_distance_offset)
        local _, far_position_distance = MainPathQueries.closest_position(far_position)

        if closest_position_distance < ahead_travel_distance or damage_override then
            scratchpad.speed = "full"; return true
        end
        if far_position_distance < ahead_travel_distance then
            scratchpad.speed = "half"
        end

    chaos_mutator_daemonhost_actions.lua:98-102
        close_distance_offset = 15
        far_distance_offset   = 30
        half_time_multiplier  = 9

    So a ritual is driven by TRAVEL DISTANCE ALONG THE MAIN PATH, compared
    against the LEAD player - not by how close you personally are, and not by
    euclidean range:

        lead is past (ritual - 15m)  ->  FULL speed
        lead is past (ritual - 30m)  ->  HALF speed, which is 1/9 rate
        otherwise                    ->  dormant

    "Half" is a misnomer: half_time_multiplier is 9, so it ticks at one ninth.
    Damaging the host also forces full speed regardless of position.

    Both queries are the client-safe EngineOptimized ones, so this is computed
    exactly rather than estimated - unlike almost everything else in this mod.
--]]
--[[
    RITUAL SPAWNER LOCATIONS - every one on the map, from mission start.
    ====================================================================

    The previous version only knew about rituals whose DAEMONHOST had already
    spawned and registered as a minion, which meant you learned about one at
    roughly the moment you could see it. Useless for planning - as you put it,
    if you are that close you already know.

    mutator_spawner.lua:175 shows how the game finds them:

        local component_system = Managers.state.extension:system("component_system")
        local mutator_spawners = component_system:get_units_from_component_name("MutatorSpawner")

    Those are LEVEL UNITS. They exist on clients, they exist from level load,
    and they exist whether or not anything has spawned at them. So every
    potential ritual site is knowable up front.

    get_position_data() on the component is server-gated, but we do not need
    it: Unit.world_position and MainPathQueries both work client-side, so we
    derive position and travel distance ourselves.

    This is what makes the Archivum Sycorax case work - a ritual 50m off the
    optimal route, behind a wall, that you cross a travel-distance line to
    trigger. It is on the list before you enter the room.
--]]
local ritual_sites = nil          -- array of { x, y, z, travel }
local ritual_sites_scanned = false

local function scan_ritual_sites()
    if ritual_sites_scanned then
        return ritual_sites
    end

    local ext = Managers.state and Managers.state.extension
    if not ext then
        return nil
    end

    local ok, units = pcall(function()
        local cs = ext:system("component_system")
        if not cs or not cs.get_units_from_component_name then
            return nil
        end
        return cs:get_units_from_component_name("MutatorSpawner")
    end)

    if not ok or type(units) ~= "table" then
        return nil
    end

    --[[
        Scanned ONCE per mission. Level units do not move, so re-scanning would
        be pure waste - and this walks every component in the level.
    --]]
    ritual_sites_scanned = true
    ritual_sites = {}

    for i = 1, #units do
        local unit = units[i]
        local x, y, z = mod.unit_xyz(unit)
        if x then
            local travel = mod.travel_distance_of and mod.travel_distance_of(unit)
            ritual_sites[#ritual_sites + 1] = {
                x = x, y = y, z = z,
                travel = travel,
                unit = unit,
            }
        end
    end

    mod:info("[HavocTracker] found %d ritual spawner sites", #ritual_sites)
    return ritual_sites
end

mod.scan_ritual_sites = scan_ritual_sites

mod.reset_ritual_sites = function()
    ritual_sites = nil
    ritual_sites_scanned = false
end

--[[
    AUTO-EVENT ZONES - where the forecast stops being valid.
    ========================================================

    This is a CORRECTNESS fix, not a feature.

    Scripted events (auto events) suppress normal pacing while they run:

        auto_event.lua, on event start
            local should_pause_pacing = self._template.pause_pacing_on_event
            for spawn_type, pause_duration_table in pairs(should_pause_pacing) do
                Managers.state.pacing:pause_spawn_type(spawn_type, true, ...)

    So during an event the horde clock, the trickle readout and the spawn
    forecast are all describing a system that has been switched off - and until
    now the panel presented them exactly as confidently as usual. A forecast
    that is silently invalid is worse than one that admits it does not know.

    WHAT WE CAN AND CANNOT KNOW

    Auto events are FLOW-triggered: mission scripting arms them, so their
    timing is genuinely unpredictable and Managers.state.pacing:auto_event_active()
    is server-only. We cannot know that one is running.

    What we CAN know is location. AutoEvent is a level component
    (scripts/components/auto_event.lua: component("AutoEvent")), so the units
    exist on clients from level load, exactly like MutatorSpawner. And the game
    gates its waves on player proximity:

        auto_event.lua:_check_players_in_radius
            distance < radius + margin        -- 2D, height flattened

        RADIUS_BY_LEVEL_TAG  8 / 16 / 24 / 32   MARGIN 10

    So we report "you are standing in an event zone, treat the forecast as
    unreliable" rather than claiming an event is or is not active. That is the
    honest version of what is knowable.
--]]
local EVENT_DEFAULT_RADIUS = 16      -- level_size_32, the common case
local EVENT_MARGIN         = 10

local event_sites = nil
local event_sites_scanned = false

local function scan_event_sites()
    if event_sites_scanned then
        return event_sites
    end

    local ext = Managers.state and Managers.state.extension
    if not ext then
        return nil
    end

    local ok, units = pcall(function()
        local cs = ext:system("component_system")
        if not cs or not cs.get_units_from_component_name then
            return nil
        end
        return cs:get_units_from_component_name("AutoEvent")
    end)

    if not ok or type(units) ~= "table" then
        return nil
    end

    event_sites_scanned = true
    event_sites = {}

    for i = 1, #units do
        local x, y, z = mod.unit_xyz(units[i])
        if x then
            event_sites[#event_sites + 1] = { x = x, y = y, z = z }
        end
    end

    mod:info("[HavocTracker] found %d auto-event sites", #event_sites)
    return event_sites
end

mod.scan_event_sites = scan_event_sites

mod.reset_event_sites = function()
    event_sites = nil
    event_sites_scanned = false
end

--[[
    Are we inside an event zone?

    Distance is measured in 2D with height discarded, matching the game's own
    check - it flattens both positions to (x, y, 0) before comparing, so a
    gantry directly above an event counts as inside it.
--]]
local function update_event_zone()
    local s = mod.state
    local sites = scan_event_sites()
    if not sites or #sites == 0 then
        s.in_event_zone = false
        s.event_zone_m = nil
        return
    end

    local lp = Managers.player:local_player(1)
    local unit = lp and lp.player_unit
    if not unit then
        return
    end

    local px, py = mod.unit_xyz(unit)
    if not px then
        return
    end

    local threshold = EVENT_DEFAULT_RADIUS + EVENT_MARGIN
    local nearest = nil

    for i = 1, #sites do
        local site = sites[i]
        local dx, dy = site.x - px, site.y - py
        local d = math.sqrt(dx * dx + dy * dy)
        if not nearest or d < nearest then
            nearest = d
        end
    end

    s.event_zone_m = nearest
    s.in_event_zone = nearest ~= nil and nearest <= threshold
end

mod.update_event_zone = update_event_zone

local RITUAL_CLOSE_OFFSET = 15
local RITUAL_FAR_OFFSET   = 30
local RITUAL_HALF_RATE    = 9

--[[
    Returns "full", "half" or "dormant" for a ritual at a given travel distance.

    The game compares POSITIONS derived from the offsets rather than raw
    numbers, because the main path is not a straight line - stepping back 15m
    of travel distance and re-resolving can land at a different value. We
    reproduce that round trip rather than doing the arithmetic directly, so our
    answer matches the game's on folded geometry.
--]]
local function ritual_speed(ritual_travel, lead_travel)
    if not ritual_travel or not lead_travel then
        return nil
    end

    local EO = rawget(_G, "EngineOptimized")
    if not main_path_ready() then
        return
    end
    if not EO or not EO.point_on_mainpath or not EO.closest_pos_at_main_path then
        -- Fall back to plain arithmetic; slightly wrong on folded paths but
        -- better than reporting nothing.
        if ritual_travel - RITUAL_CLOSE_OFFSET < lead_travel then return "full" end
        if ritual_travel - RITUAL_FAR_OFFSET   < lead_travel then return "half" end
        return "dormant"
    end

    local function resolved(offset)
        local ok, pos = pcall(EO.point_on_mainpath, ritual_travel - offset)
        if not ok or not pos then
            return ritual_travel - offset
        end
        local ok2, _, d = pcall(EO.closest_pos_at_main_path, pos)
        return (ok2 and type(d) == "number") and d or (ritual_travel - offset)
    end

    if resolved(RITUAL_CLOSE_OFFSET) < lead_travel then
        return "full"
    end
    if resolved(RITUAL_FAR_OFFSET) < lead_travel then
        return "half"
    end
    return "dormant"
end

mod.ritual_speed = ritual_speed
mod.RITUAL_HALF_RATE = RITUAL_HALF_RATE

local function update_daemonhosts()
    local s = mod.state

    -- Player positions once per call, as numbers.
    local pxs, pys, pzs, pn = {}, {}, {}, 0
    for _, player in pairs(Managers.player:players()) do
        local pu = player.player_unit
        if pu and HEALTH_ALIVE[pu] then
            local x, y, z = xyz_of(pu)
            if x then
                pn = pn + 1
                pxs[pn], pys[pn], pzs[pn] = x, y, z
            end
        end
    end

    local nearest_any, nearest_ritual = nil, nil

    for unit, kind in pairs(daemonhosts) do
        --[[
            The validity check itself is pcall'd.

            Unit.is_valid on a reference whose level has been destroyed is not
            a safe query - it can fault rather than return false. Treating a
            throw as "drop this entry" is the only correct response, and it
            keeps one stale reference from taking down the whole readout.
        --]]
        -- No pcall needed now: unit_alive is a table lookup, it cannot throw
        -- and it cannot fault on a freed handle.
        local alive = unit_alive(unit) and HEALTH_ALIVE[unit] and true or false

        if not alive then
            daemonhosts[unit] = nil
        else
            local x, y, z = xyz_of(unit)
            if x then
                --[[
                    Distance to the CLOSEST player: the despawn rule is "every
                    player is beyond the range", so the nearest one is what
                    holds it alive, and the nearest one is also what will trip
                    a ritual's proximity trigger.
                --]]
                for i = 1, pn do
                    local dx, dy, dz = x - pxs[i], y - pys[i], z - pzs[i]
                    local d = math.sqrt(dx * dx + dy * dy + dz * dz)
                    if not nearest_any or d < nearest_any then
                        nearest_any = d
                    end
                    if kind == "ritual" and (not nearest_ritual or d < nearest_ritual) then
                        nearest_ritual = d
                    end
                end
            end
        end
    end

    local nearest = nearest_any
    s.daemonhost_m = nearest
    s.daemonhost_skip = nearest and (nearest >= DH_DESPAWN_M) or false

    --[[
        Per-ritual tick state and direction.

        Rebuilt into a reused table so the marker layer and the panel read the
        same list, and so nothing allocates per frame. Sorted nearest-first by
        travel distance so "which one is closest" is answerable.
    --]]
    local rituals = s.rituals or {}
    for i = #rituals, 1, -1 do rituals[i] = nil end

    local lead = s.lead

    --[[
        SITES FIRST, then live units.

        Every spawner location goes on the list regardless of whether a
        daemonhost has appeared there, so a ritual behind a wall 50m off route
        is visible from mission start. A live daemonhost at the same place
        supersedes its site entry below.
    --]]
    local sites = scan_ritual_sites()
    if sites then
        for i = 1, #sites do
            local site = sites[i]
            local speed = site.travel and lead and ritual_speed(site.travel, lead) or nil
            rituals[#rituals + 1] = {
                unit    = nil,
                site    = true,
                travel  = site.travel,
                speed   = speed,
                to_half = (site.travel and lead) and ((site.travel - RITUAL_FAR_OFFSET) - lead) or nil,
                to_full = (site.travel and lead) and ((site.travel - RITUAL_CLOSE_OFFSET) - lead) or nil,
                x = site.x, y = site.y, z = site.z,
            }
        end
    end

    for unit, kind in pairs(daemonhosts) do
        if kind == "ritual" and unit_alive(unit) then
            local d = mod.travel_distance_of and mod.travel_distance_of(unit)
            local x, y, z = mod.unit_xyz(unit)
            if x then
                local speed = d and lead and ritual_speed(d, lead) or nil

                --[[
                    Drop the site entry this host is standing on, so one ritual
                    does not draw two markers. 12m covers spawn scatter without
                    swallowing a genuinely separate nearby site.
                --]]
                for j = #rituals, 1, -1 do
                    local r = rituals[j]
                    if r.site then
                        local dx, dy = r.x - x, r.y - y
                        if dx * dx + dy * dy < 144 then
                            table.remove(rituals, j)
                        end
                    end
                end

                rituals[#rituals + 1] = {
                    unit   = unit,
                    live   = true,
                    travel = d,
                    speed  = speed,
                    -- Metres of lead travel until this ritual starts ticking at
                    -- all, and until it goes full. Negative means already past.
                    to_half = (d and lead) and ((d - RITUAL_FAR_OFFSET) - lead) or nil,
                    to_full = (d and lead) and ((d - RITUAL_CLOSE_OFFSET) - lead) or nil,
                    x = x, y = y, z = z,
                }
            end
        end
    end

    table.sort(rituals, function(a, b)
        local ta = a.to_full or math.huge
        local tb = b.to_full or math.huge
        return ta < tb
    end)

    s.rituals = rituals

    --[[
        Headline ritual = the one furthest along, i.e. the first to tick.
        That is the one worth naming, not merely the physically nearest.
    --]]
    local head = rituals[1]
    s.ritual_speed   = head and head.speed or nil
    s.ritual_to_full = head and head.to_full or nil
    s.ritual_count   = #rituals

    --[[
        Ritual proximity.

        Reuses the daemonhost positions we already have, so this costs nothing
        beyond two comparisons. The ritual trigger is a 55m PROXIMITY check, not
        a travel-distance gate - approaching from any angle sets it off - and it
        forces a horde, so crossing it unprepared is materially worse than
        walking past a monster candidate.
    --]]
    --[[
        Ritual proximity uses the RITUAL breed only.

        Measuring against any daemonhost would fire the horde warning next to an
        ordinary pacing host, which does not force a horde and can simply be
        skipped by backing off 65m. Different breeds, different rules.
    --]]
    local trig = ritual_trigger_distance()
    s.ritual_trigger_m = trig
    s.ritual_total     = ritual_total()
    s.ritual_near_m    = nearest_ritual
    s.ritual_armed     = (nearest_ritual ~= nil) and (nearest_ritual <= trig) or false

    if s.ritual_armed and not s.ritual_warned then
        s.ritual_warned = true
        if mod.play_alert then
            mod.play_alert("forced_horde")
        end
        if mod.log_event then
            mod.log_event("ritual_zone", "entered",
                string.format("%.0fm", nearest_ritual or 0))
        end
    elseif not s.ritual_armed then
        s.ritual_warned = false
    end
end

mod.update_daemonhosts = update_daemonhosts

-- ---------------------------------------------------------------------------
-- Audio cue
--
-- Uses an existing Wwise event: custom audio cannot be added, because sounds
-- are baked into soundbanks and referenced by name (the same wall that killed
-- the MP3 idea in AnnoyingBursters).
-- ---------------------------------------------------------------------------

local ALERT_EVENTS = {
    imminent     = "wwise/events/ui/play_ui_click",
    forced_horde = "wwise/events/ui/play_ui_hud_mission_vote_popup_enter",
}

local last_alert_t = 0
local ALERT_COOLDOWN = 2

mod.play_alert = function(kind)
    if mod:get("spawn_audio_cue") == false then
        return
    end

    local now = mod._now or 0
    if now - last_alert_t < ALERT_COOLDOWN then
        return
    end
    last_alert_t = now

    local event = ALERT_EVENTS[kind]
    if not event then
        return
    end

    pcall(function()
        local world = Managers.world:world("level_world")
        local wwise_world = Managers.world:wwise_world(world)
        WwiseWorld.trigger_resource_event(wwise_world, event)
    end)
end

-- ---------------------------------------------------------------------------
-- Accuracy log
--
-- Writes predicted candidates against what actually spawned. Two reasons: it
-- calibrates the probability model against reality, and it lets you decide
-- whether to trust the panel from your own data rather than taking my word for
-- it - which, given how much of this session was me being corrected by your
-- testing, is worth having.
-- ---------------------------------------------------------------------------

local log_lines = {}

mod.log_event = function(kind, name, detail)
    if mod:get("spawn_accuracy_log") == false then
        return
    end
    if #log_lines > 400 then
        return
    end

    local Spawns = mod.Spawns
    local lead = mod.state.lead
    local ok, line = pcall(string.format,
        "%.1f\t%s\t%s\t%s\tlead=%s\tclear=%s",
        mod._now or 0, tostring(kind), tostring(name), tostring(detail or ""),
        lead and string.format("%.1f", lead) or "?",
        (Spawns and lead and Spawns.clear_for(lead))
            and string.format("%.1f", Spawns.clear_for(lead)) or "?")

    if ok then
        log_lines[#log_lines + 1] = line
    end
end

--[[
    A ZERO-SPAWN RUN IS STILL A RESULT, AND IT USED TO BE THROWN AWAY.

    This returned early on `#log_lines == 0`, so a mission where nothing ever
    spawned wrote nothing at all. That is precisely backwards: those runs are
    the rare ones and the ones worth studying. The Archivum Sycorax run on
    2026-09-10 held the team above the specials gate for the whole mission and
    produced zero spawn events - and left no trace in this file, so the only
    record of the best-executed run available was its absence.

    A header is now written either way, with an explicit marker when the body
    is empty. The setting check stays first: if logging is off, log nothing.
--]]
mod.flush_log = function()
    if mod:get("spawn_accuracy_log") == false then
        log_lines = {}
        return
    end

    local Spawns = mod.Spawns

    --[[
        THE HUB IS A GAMEPLAY STATE TOO.

        flush_log runs on `exit StateGameplay`, and leaving the Mourningstar
        exits StateGameplay exactly like finishing a mission does. With the
        old early-return on an empty body that was harmless - nothing was
        written either way. Now that a header is always written, an unguarded
        version would stamp a "CLEAN RUN" entry into the log every single time
        you left the hub, which would bury the real runs it exists to record.

        Gated on the mission name rather than game_mode_name: by the time this
        runs the game mode manager may already be torn down, whereas the name
        Spawns bound at mission start is still there.
    --]]
    local mission = Spawns and Spawns.mission()
    local real_mission = type(mission) == "string"
        and mission ~= ""
        and not string.find(mission, "hub", 1, true)

    if #log_lines == 0 and not real_mission then
        log_lines = {}
        return
    end

    pcall(function()
        local io_ = sandbox_io()
        local path = appdata_path("HavocTracker_accuracy.log")
        if not io_ or not path then return end
        local f = io_.open(path, "a")
        if not f then return end

        f:write(string.format("\n=== %s  mission=%s  tier=%s  triggers=%d ===\n",
            (function() local o = sandbox_os(); return (o and o.date) and o.date("%Y-%m-%d %H:%M:%S") or "" end)(),
            tostring(Spawns and Spawns.mission()),
            tostring(Spawns and Spawns.challenge_tier()),
            Spawns and Spawns.count() or 0))

        if #log_lines == 0 then
            --[[
                Recorded as a positive result, not a blank. The peak allocated
                count is the one number that explains a clean run: if it sat
                near 145 the team was holding the hard cap, which is the only
                suppression the game cannot override.
            --]]
            f:write(string.format("CLEAN RUN - no spawn events. peak_allocated=%s cap=%d\n",
                tostring(mod.state.peak_allocated or "?"), mod.HARD_ALLOCATED_LIMIT))
        end

        for i = 1, #log_lines do
            f:write(log_lines[i], "\n")
        end
        f:close()
    end)

    log_lines = {}
end

local MARKER_PATH = "Dio's HavocTracker/scripts/mods/HavocTracker/HavocTracker_marker"
mod:add_require_path(MARKER_PATH)

local SpawnMarker = nil
mod.marker_template_ok = false
do
    local ok, tmpl = pcall(require, MARKER_PATH)
    if ok and type(tmpl) == "table" then
        SpawnMarker = tmpl
        mod.marker_template_ok = true
    else
        mod:error("[HavocTracker] marker template failed to load: %s", tostring(tmpl))
    end
end

local function ensure_marker_templates(world_markers)
    if not world_markers or not world_markers._marker_templates then
        return
    end
    if SpawnMarker then
        world_markers._marker_templates[SpawnMarker.name] = SpawnMarker
    end
    -- The pace lines (speed gate, rush, blockade). See HavocTracker_pace.lua.
    local pace = mod.Pace and mod.Pace.marker_template
    if pace then
        world_markers._marker_templates[pace.name] = pace
    end
end

--[[
    A fresh HudElementWorldMarkers means every id we hold is stale.

    This fires on mission load, restart and spectator handoff. Forgetting our
    ids here - rather than trying to remove them - is what makes /restart safe:
    the previous element destroyed its own markers as it died, so there is
    nothing left to clean up, only stale bookkeeping to drop.
--]]
mod:hook_safe(CLASS.HudElementWorldMarkers, "init", function(self)
    ensure_marker_templates(self)
    mod.markers_dirty = true
    if mod.forget_spawn_markers then
        mod.forget_spawn_markers()
    end
    if mod.Pace and mod.Pace.forget_markers then
        mod.Pace.forget_markers()
    end
    --[[
        A new world-marker element means a new level, which means every unit
        reference we hold is from the previous one. This is the earliest
        reliable signal of that, so drop them here as well as at mission exit -
        an auto-restart can skip straight past the exit path.
    --]]
    if mod.reset_daemonhosts then
        mod.reset_daemonhosts()
    end
end)

mod:hook_safe(CLASS.HudElementWorldMarkers, "update", function(self)
    ensure_marker_templates(self)
end)

--[[
    Marker lifecycle.

    Keyed by trigger distance, which is stable for a mission. Markers are added
    when a trigger comes within MARKER_RANGE ahead of the lead player and
    removed once consumed or out of range - NOT rebuilt per frame. Add/remove
    goes through the event system and allocates, so churning it every frame is
    exactly the mistake that makes marker mods expensive.
--]]
--[[
    World markers are for things you are about to reach, not the whole run.

    At 260m the scene carried markers for triggers 900m away - five minutes of
    walking - which is the mirror of the old complaint that a 15m warning came
    too late to matter. Something you cannot act on for five minutes is not a
    warning, it is decoration competing with the fight.

    150m is roughly the next stretch of corridor: far enough to plan a position,
    near enough that the plan survives contact. The PANEL still lists further
    ones (see PANEL_RANGE), so nothing is lost - it just stops being drawn over
    the world.
--]]
local MARKER_RANGE    = 150
local MARKER_INTERVAL = 0.5

--[[
    Ring markers.

    A single icon marks a point but does not read as a LINE you are about to
    cross. Placing a circle of small markers around the trigger position makes
    the boundary itself visible - and doing it as N separate world markers means
    the engine projects each one correctly, rather than me trying to draw a
    3D ring in screen space (which is what went wrong with the wall).

    Only the nearest few triggers get rings; every trigger getting one would be
    24+ markers on screen.
--]]

local active_markers   = {}   -- key -> { id, dead, data }
local path_markers     = {}   -- travel distance -> { id, dead }
local marker_accum     = 0

--[[
    Declared HERE, not next to update_path_line where it is used.

    clear_all_markers below resets it, and a Lua local only exists from its
    declaration onward - declaring it later would have made that reset write a
    global while update_path_line kept reading an untouched local, so the line
    would never rebuild after a mission ended. Same trap as `odds` and
    `record_if_needed` earlier in this file.
--]]
local path_last_lead = nil

-- Muted blue-grey: the path line is orientation, not a threat, and must not
-- compete with the band colours used for spawn triggers.
local PATH_RGB = { 120, 170, 210 }

--[[
    Every remove goes through here, and every one is guarded.

    Marker ids belong to a specific HudElementWorldMarkers instance. That
    element is DESTROYED and rebuilt on mission teardown, so on a restart every
    id we are holding refers to an object that no longer exists - and firing
    remove_world_marker with a stale id reaches into the new element's tables
    with a key it does not own. Managers.event can also be part-torn-down at
    that moment.

    So: check the manager still exists, and pcall the trigger. A failed removal
    is harmless (the element took its markers with it when it died); an
    unguarded one takes the game down mid-restart.
--]]
local function safe_remove_world_marker(id)
    if not id then
        return
    end
    local events = Managers and Managers.event
    if not events then
        return
    end
    pcall(function()
        events:trigger("remove_world_marker", id)
    end)
end

local function remove_path_marker(key)
    local entry = path_markers[key]
    if not entry then
        return
    end
    path_markers[key] = nil
    entry.dead = true
    safe_remove_world_marker(entry.id)
end

-- Diagnostics, surfaced by /htspawns.
mod.marker_stats = { active = 0, added = 0, removed = 0, no_position = 0, errors = 0 }

local KIND_ICON = {
    boss_trigger         = "content/ui/materials/icons/difficulty/difficulty_skull_uprising",
    twins_spawn_trigger  = "content/ui/materials/icons/difficulty/difficulty_skull_uprising",
    twins_ambush_trigger = "content/ui/materials/icons/difficulty/difficulty_skull_uprising",
    boss_patrol_trigger  = "content/ui/materials/icons/difficulty/difficulty_skull_uprising",
}

local BAND_RGB = {
    safe     = { 120, 230, 130 },
    near     = { 235, 225, 110 },
    close    = { 250, 165,  60 },
    imminent = { 255,  70,  60 },
}

local function remove_marker(key)
    local entry = active_markers[key]
    if not entry then
        return
    end
    active_markers[key] = nil
    entry.dead = true
    mod.marker_stats.removed = mod.marker_stats.removed + 1
    safe_remove_world_marker(entry.id)
end

--[[
    Drop every marker WITHOUT talking to the event system.

    Used when the world-marker element itself is going away - mission end,
    restart, spectator handoff. The element destroys its own markers as it dies,
    so there is nothing for us to remove; all we have to do is stop believing we
    own ids that no longer exist. Trying to remove them politely is what crashes
    on /restart.
--]]
local function forget_markers()
    -- Ritual markers are a separate table keyed by unit; they die with the
    -- level exactly like the rest and must be forgotten, not removed.
    if mod.forget_ritual_markers then
        mod.forget_ritual_markers()
    end
    for key, entry in pairs(active_markers) do
        entry.dead = true
        active_markers[key] = nil
    end
    for key, entry in pairs(path_markers) do
        entry.dead = true
        path_markers[key] = nil
    end
    path_last_lead = nil
    mod.marker_stats.active = 0
end
mod.forget_spawn_markers = forget_markers

local function clear_all_markers()
    for key in pairs(active_markers) do
        remove_marker(key)
    end
    -- Path dots are a separate table and would otherwise survive a mission end.
    for key in pairs(path_markers) do
        remove_path_marker(key)
    end
    path_last_lead = nil
    mod.marker_stats.active = 0
end
mod.clear_spawn_markers = clear_all_markers

--[[
    Create one world marker.

    The add callback can fire after we have already given up on this marker
    (mission ended, moved out of range, ring rebuilt). Re-checking liveness and
    removing on mismatch is what stops orphaned markers accumulating inside the
    HUD element - the leak vector I flagged in RitualZones.
--]]
local function add_marker(key, position, data)
    local entry = { id = nil, dead = false, data = data }
    active_markers[key] = entry
    mod.marker_stats.added = mod.marker_stats.added + 1

    --[[
        Both the add and the callback's rollback removal are guarded.

        The callback can fire after a mission restart has already invalidated
        everything, in which case the id it hands us belongs to a dead element -
        removing it unguarded is the same crash as any other stale removal.
    --]]
    local ok = pcall(function()
        Managers.event:trigger("add_world_marker_position",
            SpawnMarker.name, position, function(marker_id)
                if entry.dead or active_markers[key] ~= entry then
                    safe_remove_world_marker(marker_id)
                    return
                end
                entry.id = marker_id
            end, data)
    end)

    if not ok then
        active_markers[key] = nil
        mod.marker_stats.errors = mod.marker_stats.errors + 1
    end
end

--[[
    The percentage is only printed when it is NOT a certainty.

    Every row on screen was reading "100%", which is five characters per row
    carrying no information - if all candidates are certain, the number cannot
    discriminate between them, and it was the discrimination that justified
    adding it. Showing it only below 100% restores that: a number appearing at
    all now means "this one is a guess", which is the thing worth knowing.

    Shared by the panel and the world markers so the two can never disagree
    about how a row is written.
--]]
local function format_row(label, gap, odds)
    local pct = odds and math.floor(odds * 100 + 0.5)
    if pct and pct < 100 then
        return string.format("%s %dm %d%%", label, math.floor(gap), pct)
    end
    return string.format("%s %dm", label, math.floor(gap))
end

mod.format_row = format_row

--[[
    SIMPLE LABELS: the specific breed collapses into what it is.

    The panel named each trigger exactly - MONSTER/CAPN, BEAST, CHAOS SPAWN,
    HOUNDMASTER, OGRYN - which is precise and is more than the decision needs.
    At the moment you read the row, every one of those means the same thing:
    something big, at that distance, and going near it spawns it. Six labels
    for one decision is six labels to read.

    TWINS STAY. They were called out specifically as the exception and the
    exception is correct: twins are a scripted pair with their own fight, not
    a monstrosity, and treating them as interchangeable with a beast would be
    wrong rather than merely brief.

    Daemonhosts stay too, on the same reasoning - a daemonhost is an AVOID,
    and folding an avoid into a fight is the one substitution that gets
    somebody killed. Rituals and patrols keep their names for the same reason:
    each is a different action.

    Everything else - monsters, captains, the named breeds - is BOSS.
--]]
local SIMPLE_LABEL = {
    ["MONSTER/CAPN"] = "BOSS",
    ["CAPTAIN"]      = "BOSS",
    ["MONSTER"]      = "BOSS",
    ["BEAST"]        = "BOSS",
    ["CHAOS SPAWN"]  = "BOSS",
    ["OGRYN"]        = "BOSS",
    ["HOUNDMASTER"]  = "BOSS",
}

local simple_labels = false

mod.refresh_simple_labels = function()
    simple_labels = mod:get("simple_labels") == true
end

local function label_for(row)
    local label = row.label

    if simple_labels then
        label = SIMPLE_LABEL[label] or label
    end

    return format_row(label, row.gap, row.odds)
end

--[[
    Gate offsets, precomputed.

    NOT a ring. The trigger is a travel distance, and travel distance is your
    position projected onto the nearest main-path point - so the thing you cross
    behaves like a PLANE perpendicular to the path, extending outwards and
    vertically. You can cross it well off to one side, or on a different floor,
    and it still fires.

    A circle on the ground implied a zone you walk into, which is simply the
    wrong mental model and would get someone killed edging around it. This lays
    markers out along the perpendicular instead, plus a short vertical stack, so
    the shape on screen matches the rule in monster_pacing.lua:691.

    Values are multipliers on the perpendicular axis and on world up.
--]]
--[[
    Gate shape - STATIC.

    Markers laid along the perpendicular to the path at the trigger point, plus
    a short vertical stack. This is the version that worked and read well.

    What broke it afterwards was NOT this shape - it was anchoring the gate to
    the player's height. World markers cannot be moved once placed, so that
    version had to delete and rebuild the whole gate every time you changed
    elevation, and the rebuild churned faster than the async add-callback could
    resolve. The markers were being removed before they ever existed.

    So: fixed offsets from the path point, built once, never touched again. On
    folded geometry a gate can sit a storey above you - accepted deliberately as
    a reference marker rather than a precise crossing line. With live pacing
    data while hosting, the positions are the engine's own anyway.
--]]
--[[
    Density kept - the information is wanted. What changes is visual WEIGHT.

    The complaint was never marker count: it was that each one was a large,
    fully opaque skull sitting on top of a fight. So the gate keeps its shape
    and coverage, and the fix is size and alpha (see ICON_BASE / MARKER_ALPHA).
--]]
--[[
    The outermost pair was dropped (was +/-3.0).

    At GATE_SPACING 2.2 the remaining +/-2.0 still puts the gate edge 4.4m to
    each side, which is wider than any corridor you cross it in - so the gate
    reads identically while costing two fewer widgets per gate, four in total.
--]]
local GATE_OFFSETS = {
    { -2.0, 0 }, { -1.0, 0 }, { 0, 0 }, { 1.0, 0 }, { 2.0, 0 },
    { 0, 1.4 }, { 0, 2.8 },
    { 0, -1.4 },
}
local GATE_SPACING  = 2.2
local GATE_POINTS   = #GATE_OFFSETS
local GATE_TRIGGERS = 2

--[[
    Marker sizes are in 1080p reference pixels and get DOWNSCALED.

    This is why the gates never appeared. Darktide lays its UI out against a
    1080p reference and scales to the actual resolution, so at 360p everything
    renders at roughly a third size. The gate dots were 12px - about 4 real
    pixels - which is invisible against a lit background. The 44px icon markers
    survived at ~15px, which is precisely the "I saw some floating markers but
    no gates" split.

    Base sizes raised, and both multiplied by a user setting so this is
    adjustable rather than another number I guessed at.
--]]
--[[
    Base sizes cut roughly in half.

    56/30 at the old default scale of 2 meant a 112px skull - enormous, and the
    complaint was correct. These are sized so the DEFAULT reads clearly at 1080p
    and the setting is what you raise for 360p, rather than the base already
    assuming a low resolution.
--]]
local ICON_BASE = 30
local GATE_BASE = 14

local function marker_scale()
    return tonumber(mod:get("spawn_marker_scale")) or 1.2
end

--[[
    THE PATH LINE HAS ITS OWN SCALE.

    It used to share spawn_marker_scale with the spawn sites, the boss
    triggers and the ritual markers, which meant the two could not be balanced
    against each other: the path is a line of dozens of dots laid end to end
    and the world markers are a handful of single icons you are meant to look
    at. Sizing the boss markers so they read at distance turned the path into
    a solid bar; sizing the path so it stayed a line made the boss markers
    too small to notice.

    Separate setting, and the base stays 14 against the world markers' 30 -
    the path is meant to be the quieter of the two at equal scale.
--]]
local function path_marker_scale()
    return tonumber(mod:get("path_marker_scale")) or 1
end

--[[
    Main path line.

    RitualZones draws its path with LineObject - per-frame engine geometry with
    a create/destroy lifecycle, which together with find_ritual_units is where
    its crash lives. This does the same job with the world-marker system we are
    already using: small dots placed at fixed travel-distance intervals ahead of
    the lead player, rebuilt only when you have moved a full step.

    Positions come from Spawns.position_at, the same path walk the spawn markers
    use, so the line and the triggers agree by construction.
--]]
--[[
    Spacing widened deliberately.

    Every dot here is a world marker, and every world marker is a UIWidget.draw
    every frame inside the game's own HUD element. At 12m over a 155m span this
    line alone was 13 widgets - more than the base game draws in total - to
    render what is visually just "the path goes that way".

    22m gives 7 dots. The line still reads as a line; the per-frame draw cost is
    roughly halved.
--]]
local PATH_STEP     = 22     -- metres between dots
local PATH_AHEAD    = 130    -- metres of path to show
local PATH_BEHIND   = 25     -- a little behind, so the line reads as continuous

local function update_path_line(lead)
    if mod:get("show_path_line") == false then
        if next(path_markers) then
            for key in pairs(path_markers) do
                remove_path_marker(key)
            end
        end
        path_last_lead = nil
        return
    end

    -- Only rebuild once you have moved a whole step; otherwise the dots would
    -- be destroyed and recreated every tick, which is what killed the gates.
    if path_last_lead and math.abs(lead - path_last_lead) < PATH_STEP then
        return
    end
    path_last_lead = lead

    local Spawns = mod.Spawns
    if not Spawns or not Spawns.position_at then
        return
    end

    local first = math.floor((lead - PATH_BEHIND) / PATH_STEP) * PATH_STEP
    local wanted = {}

    for d = first, lead + PATH_AHEAD, PATH_STEP do
        if d > 0 then
            wanted[d] = true
        end
    end

    for key in pairs(path_markers) do
        if not wanted[key] then
            remove_path_marker(key)
        end
    end

    for d in pairs(wanted) do
        if not path_markers[d] then
            local pos = Spawns.position_at(d)
            if pos then
                local entry = { id = nil, dead = false }
                path_markers[d] = entry
                pcall(function()
                Managers.event:trigger("add_world_marker_position",
                    SpawnMarker.name, pos, function(marker_id)
                        if entry.dead or path_markers[d] ~= entry then
                            safe_remove_world_marker(marker_id)
                            return
                        end
                        entry.id = marker_id
                    end, {
                        color = PATH_RGB,
                        icon_size = 14 * path_marker_scale(),
                        label = "",
                    })
                end)
            end
        end
    end
end

--[[
    Ritual direction markers.

    One marker per live ritual daemonhost, drawn through walls (the template
    disables line-of-sight checks) and clamped to the screen edge by the
    engine's own world-marker system when off-screen - so it doubles as a
    compass, which is what was asked for.

    Colour encodes TICK STATE rather than distance, because that is the
    decision: a dormant ritual 20m away matters less than one already ticking
    at full speed across the room.

        red    ticking FULL
        amber  ticking at 1/9 rate
        grey   dormant

    Keyed by unit, and unit references die with the level - so the table is
    rebuilt from the live ritual list every tick and anything missing is
    removed.
--]]
local ritual_markers = {}

local RITUAL_RGB = {
    full    = { 255,  70,  60 },
    half    = { 250, 175,  60 },
    dormant = { 150, 150, 160 },
}

local function remove_ritual_marker(key)
    local entry = ritual_markers[key]
    if not entry then
        return
    end
    ritual_markers[key] = nil
    entry.dead = true
    safe_remove_world_marker(entry.id)
end

local function clear_ritual_markers()
    for key in pairs(ritual_markers) do
        remove_ritual_marker(key)
    end
end

local function update_ritual_markers()
    if not SpawnMarker or not Managers.event then
        return
    end

    if mod:get("show_ritual_markers") == false or mod.overlay_visible == false then
        if next(ritual_markers) then
            clear_ritual_markers()
        end
        return
    end

    local list = mod.state.rituals
    if type(list) ~= "table" then
        return
    end

    --[[
        Keyed by POSITION, not by unit.

        Site entries have no unit at all - they are level spawner locations,
        not spawned daemonhosts - so a unit key would collapse every site onto
        nil and draw one marker for all of them. Rounded world position is
        stable for a site (level geometry does not move) and stable enough for
        a live host, which barely drifts once placed.
    --]]
    local function marker_key(r)
        return string.format("%d:%d:%d",
            math.floor(r.x), math.floor(r.y), math.floor(r.z))
    end

    -- Drop markers whose ritual is gone; refresh the ones that remain.
    local live = {}
    for i = 1, #list do
        live[marker_key(list[i])] = list[i]
    end
    for key, entry in pairs(ritual_markers) do
        local r = live[key]
        if not r then
            remove_ritual_marker(key)
        elseif entry.data then
            local speed = r.speed or "dormant"
            entry.data.color = RITUAL_RGB[speed] or RITUAL_RGB.dormant
            --[[
                Label states the DECISION, not the raw number: how much further
                the lead player can advance before this thing starts ticking.
            --]]
            if speed == "full" then
                entry.data.label = "RITUAL TICKING"
            elseif speed == "half" then
                entry.data.label = string.format("RITUAL slow - full in %dm",
                    math.max(0, math.floor(r.to_full or 0)))
            else
                entry.data.label = string.format("RITUAL dormant - %dm",
                    math.max(0, math.floor(r.to_half or 0)))
            end
        end
    end

    -- Add markers for rituals we are not yet tracking.
    for i = 1, #list do
        local r = list[i]
        local key = marker_key(r)
        if not ritual_markers[key] then
            local okv, pos = pcall(Vector3, r.x, r.y, r.z)
            if okv and pos then
                local entry = { id = nil, dead = false }
                --[[
                    Site markers draw smaller than live ones: a potential
                    location matters less than a daemonhost actually standing
                    there, and at mission start every site is on screen at once.
                --]]
                local scale = r.live and 1 or 0.7
                local data = {
                    color = RITUAL_RGB[r.speed or "dormant"] or RITUAL_RGB.dormant,
                    icon_size = ICON_BASE * marker_scale() * scale,
                    font_size = 20 * marker_scale() * scale,
                    label = r.live and "RITUAL" or "ritual site",
                }
                entry.data = data
                ritual_markers[key] = entry

                pcall(function()
                    Managers.event:trigger("add_world_marker_position",
                        SpawnMarker.name, pos, function(marker_id)
                            if entry.dead or ritual_markers[key] ~= entry then
                                safe_remove_world_marker(marker_id)
                                return
                            end
                            entry.id = marker_id
                        end, data)
                end)
            end
        end
    end
end

mod.clear_ritual_markers = clear_ritual_markers

--[[
    Drop ritual markers WITHOUT touching the event system, for level teardown -
    same reasoning as forget_markers: the HUD element disposes of its own
    markers as it dies, and reaching into it on the way out is what crashed on
    /restart.
--]]
mod.forget_ritual_markers = function()
    for key, entry in pairs(ritual_markers) do
        entry.dead = true
        ritual_markers[key] = nil
    end
end

local function update_markers(dt)
    if not SpawnMarker or not Managers.event then
        return
    end

    marker_accum = marker_accum + dt
    if marker_accum < MARKER_INTERVAL then
        return
    end
    marker_accum = 0

    local Spawns = mod.Spawns
    local lead = mod.state.lead

    if not Spawns or not lead or Spawns.count() == 0
        or mod:get("show_spawn_walls") == false
        or mod.overlay_visible == false
        or not mod.state.in_mission then
        if next(active_markers) then
            clear_all_markers()
        end
        return
    end

    local wanted = Spawns.upcoming(lead, 6)

    --[[
        Keys we want this tick.

        Strings, because a trigger owns several markers: one icon plus a gate of
        GATE_POINTS. This MUST stay in lockstep with the creation loop below -
        any mismatch means markers are created and instantly dropped as
        unwanted, every tick, and nothing ever renders.
    --]]
    local want = {}
    for i = 1, #wanted do
        local row = wanted[i]
        if row.gap <= MARKER_RANGE then
            want[tostring(row.dist)] = row
            if i <= GATE_TRIGGERS then
                for k = 1, GATE_POINTS do
                    want[tostring(row.dist) .. "r" .. k] = row
                end
            end
        end
    end

    -- Drop what we no longer want; refresh the labels of what we keep.
    for key, entry in pairs(active_markers) do
        local row = want[key]
        if not row then
            remove_marker(key)
        elseif entry.data and entry.data.label ~= nil and entry.data.label ~= "" then
            entry.data.color = BAND_RGB[row.band] or BAND_RGB.safe
            entry.data.label = label_for(row)
        elseif entry.data then
            entry.data.color = BAND_RGB[row.band] or BAND_RGB.safe
        end
    end

    -- Add what is missing.
    for i = 1, #wanted do
        local row = wanted[i]
        if row.gap <= MARKER_RANGE then
            local pos = Spawns.position_at(row.dist)

            if not pos then
                mod.marker_stats.no_position = mod.marker_stats.no_position + 1
            else
                local color = BAND_RGB[row.band] or BAND_RGB.safe
                local key = tostring(row.dist)

                if not active_markers[key] then
                    add_marker(key, pos, {
                        color = color,
                        icon  = KIND_ICON[row.kind],
                        label = label_for(row),
                        icon_size = ICON_BASE * marker_scale(),
                        font_size = 20 * marker_scale(),
                    })
                end

                if i <= GATE_TRIGGERS then
                    --[[
                        Components are read ONCE inside a pcall, then everything
                        works on plain numbers.

                        Vector3 accessors throw on a value that is not a live
                        Vector3, and a throw here costs a breaker strike - five
                        of which permanently disable markers for the mission.
                        That is how an earlier build ended up with none at all.
                    --]]
                    local dir = Spawns.direction_at(row.dist)

                    local okc, px, py, pz, dx, dy = pcall(function()
                        local a, b, c = Vector3.x(pos), Vector3.y(pos), Vector3.z(pos)
                        if not dir then
                            return a, b, c, nil, nil
                        end
                        return a, b, c, Vector3.x(dir), Vector3.y(dir)
                    end)

                    if not okc or type(px) ~= "number" then
                        mod.marker_stats.errors = mod.marker_stats.errors + 1
                    else
                        --[[
                            Perpendicular in the horizontal plane: the path
                            tangent rotated 90 degrees. Falls back to the world
                            X axis when no tangent is available - live pacing
                            positions come straight from the engine and have no
                            associated tangent, so that path is normal, not an
                            error.
                        --]]
                        local ux, uy = 1, 0
                        if type(dx) == "number" and type(dy) == "number" then
                            local len = math.sqrt(dx * dx + dy * dy)
                            if len > 0.001 then
                                ux, uy = -dy / len, dx / len
                            end
                        end

                        for k = 1, GATE_POINTS do
                            local rkey = key .. "r" .. k
                            if not active_markers[rkey] then
                                local off  = GATE_OFFSETS[k]
                                local side = off[1] * GATE_SPACING
                                local okv, rp = pcall(Vector3,
                                    px + ux * side,
                                    py + uy * side,
                                    pz + off[2])
                                if okv and rp then
                                    add_marker(rkey, rp, {
                                        color = color,
                                        icon_size = GATE_BASE * marker_scale(),
                                        label = "",
                                    })
                                end
                            end
                        end
                    end
                end
            end
        end
    end

    update_ritual_markers()
    update_path_line(lead)

    local n = 0
    for _ in pairs(active_markers) do n = n + 1 end
    for _ in pairs(path_markers)   do n = n + 1 end
    mod.marker_stats.active = n
end

mod.update_spawn_markers = update_markers

-- ---------------------------------------------------------------------------
-- Diagnostics
--
-- "Is it actually loaded?" is otherwise hard to answer, because a mod that
-- fails to load produces no overlay AND no settings tab, which looks identical
-- to a mod that loaded but is drawing off-screen.
-- ---------------------------------------------------------------------------

--[[
    Load the spawn forecast module.

    io_dofile rather than require: the file lives in the mod folder, not on the
    engine's resource path, and a failed require here would kill the mod. If the
    forecast cannot load, mod.Spawns stays nil and every consumer of it is
    already nil-guarded, so the rest of the tracker carries on.
--]]
do
    local ok, err = pcall(function()
        mod:io_dofile("Dio's HavocTracker/scripts/mods/HavocTracker/HavocTracker_spawns")
    end)
    if not ok then
        mod:error("[HavocTracker] spawn forecast failed to load: %s", tostring(err))
    end
end

--[[
    Chat font scaling. Independent of everything else - if it fails to load, the
    tracker is unaffected.
--]]
do
    local ok, err = pcall(function()
        mod:io_dofile("Dio's HavocTracker/scripts/mods/HavocTracker/HavocTracker_chat")
    end)
    if not ok then
        mod:error("[HavocTracker] chat scaling failed to load: %s", tostring(err))
    end
end

-- HUD declutter toggle. Independent module; failure here leaves everything else
-- working.
do
    local ok, err = pcall(function()
        mod:io_dofile("Dio's HavocTracker/scripts/mods/HavocTracker/HavocTracker_hud")
        --[[
            Breeds BEFORE cap and cascade: both call into it, and loading it
            after them would leave mod.Breeds nil for the first spawns of a
            mission.
        --]]
        mod:io_dofile("Dio's HavocTracker/scripts/mods/HavocTracker/HavocTracker_breeds")
        mod:io_dofile("Dio's HavocTracker/scripts/mods/HavocTracker/HavocTracker_cap")
        mod:io_dofile("Dio's HavocTracker/scripts/mods/HavocTracker/HavocTracker_cascade")
        mod:io_dofile("Dio's HavocTracker/scripts/mods/HavocTracker/HavocTracker_debug")
        -- Pace before punish: punish reads its speed, rush and loner state.
        mod:io_dofile("Dio's HavocTracker/scripts/mods/HavocTracker/HavocTracker_pace")
        -- Loaded BEFORE _post, because the chat line reads its warning.
        mod:io_dofile("Dio's HavocTracker/scripts/mods/HavocTracker/HavocTracker_punish")
        mod:io_dofile("Dio's HavocTracker/scripts/mods/HavocTracker/HavocTracker_post")
    end)
    if not ok then
        mod:error("[HavocTracker] HUD toggle failed to load: %s", tostring(err))
    end
end

--[[
    ONE assignment only.

    DMF assigns these as plain fields, so a second `mod.on_setting_changed =`
    anywhere in this mod silently replaces this one. If another module needs to
    react to a setting, it gets called from here.
--]]
mod.on_setting_changed = function(setting_id)
    if setting_id == "hud_mode" then
        pcall(mod.refresh_hud_mode)
    end

    if setting_id == "simple_labels" then
        pcall(mod.refresh_simple_labels)
    end

    --[[
        PANEL GEOMETRY, LIVE.

        W, ROW_H and SECTION_GAP were file-scope constants in the HUD element
        and LAYOUT was derived from them at load, so these three sliders did
        nothing at all until a reload - and nothing on screen said so. The
        element rebuilds its layout on demand now; this is the call that asks
        it to.
    --]]
    if setting_id == "panel_width"
        or setting_id == "panel_row_height"
        or setting_id == "panel_section_gap" then
        if mod.rebuild_geometry then
            pcall(mod.rebuild_geometry)
        end
    end

    --[[
        Recomputed on every change, not just show_overlay's. The gate reads
        mod:is_enabled() as well, and DMF does not route the mod's own on/off
        through a setting id, so anything cheaper than this would miss it.
        It is three comparisons on a menu interaction, not a per-frame cost -
        that is the whole reason the result is cached on mod.overlay_visible
        for the draw paths to read.
    --]]
    pcall(mod.refresh_overlay_gate)

    if mod.invalidate_color_cache then
        pcall(mod.invalidate_color_cache)
    end
end

mod.on_enabled = function()
    pcall(mod.refresh_overlay_gate)
end

mod.on_disabled = function()
    pcall(mod.refresh_overlay_gate)
end

mod.on_all_mods_loaded = function()
    mod:echo(mod:localize("loaded_message"))

    pcall(mod.refresh_hud_mode)
    pcall(mod.refresh_overlay_gate)
    pcall(mod.refresh_simple_labels)

    --[[
        Undo any other mod's setting this mod switched off and did not get to
        switch back - a quit or crash with the HUD hidden. Deliberately HERE
        and not at file scope: get_mod returns nil for a mod that has not
        loaded yet, and load order is not ours to assume.
    --]]
    local Hud = mod.Hud
    if Hud and Hud.restore_after_load then
        pcall(Hud.restore_after_load)
    end
end

--[[
    Bind the forecast to the mission on entry, and clear it on exit.

    set_mission is the only expensive call in the whole feature - it copies and
    sorts up to ~50 numbers - and it runs exactly once per mission.
--]]
--[[
    Spawn forecast diagnostics.

    Exists because "I saw nothing" has at least five distinct causes - cache not
    found, mission not in the cache, path distance unavailable, panel toggled
    off, or everything working but off-screen - and they are indistinguishable
    from the outside. This names which one.
--]]
-- No underscore in the name: '_' is bound to a graphics reset on this setup, so
-- the command was untypeable.
--[[
    Diagnostics are BUILT AS LINES, not echoed directly.

    Same text can then be printed to chat or pushed to the clipboard, with no
    risk of the two drifting apart. Chat cannot be selected with the mouse in
    Darktide - there is no hit-testing or selection rendering for it - so
    /htcopy is the only practical way to get this text out of the game and into
    a message.
--]]
local function diag_lines()
    local out = {}
    local function add(fmt, ...)
        local ok, line = pcall(string.format, fmt, ...)
        out[#out + 1] = ok and line or tostring(fmt)
    end

    local Spawns = mod.Spawns
    add("--- Dio's HavocTracker diagnostics ---")

    if not Spawns then
        add("module NOT LOADED - HavocTracker_spawns.lua failed to load")
        return out
    end

    add("SOURCE: %s", Spawns.is_live()
        and "LIVE pacing (you are the server) - exact"
        or  "cached (client) - candidates only")
    add("cache source: %s", tostring(Spawns.cache_source()))
    add("cache maps loaded: %s",
        tostring(Spawns.cache_map_count and Spawns.cache_map_count()))
    add("cache keys e.g.: %s",
        tostring(Spawns.sample_cache_keys and Spawns.sample_cache_keys(5)))

    --[[
        RAW mission name straight from the manager, separate from
        Spawns.mission() which is only set once a bind SUCCEEDS. If they differ,
        the name we query is not the name the cache uses - and that string is
        the entire answer.
    --]]
    local raw = "?"
    pcall(function()
        local mm = Managers.state and Managers.state.mission
        if mm and mm.mission_name then
            raw = tostring(mm:mission_name())
        end
    end)
    add("mission name (raw): %s", raw)
    add("mission (bound): %s", tostring(Spawns.mission()))
    add("triggers: %d", Spawns.count())
    add("cached path length: %s", tostring(Spawns.path_total()))
    add("stale: %s", tostring(Spawns.is_stale()))
    add("challenge tier: %s", tostring(Spawns.challenge_tier and Spawns.challenge_tier()))

    add("main path registered (client-safe API): %s",
        tostring(mod.mpq_ready and mod.mpq_ready()))

    --[[
        Probe the raw engine call and report its ACTUAL error. "registered:
        true / lead: nil" said the API existed but not why it refused, which
        cost a full round of testing to work out.
    --]]
    pcall(function()
        local EO = rawget(_G, "EngineOptimized")
        add("EngineOptimized present: %s  closest_pos: %s",
            tostring(EO ~= nil), tostring(EO and EO.closest_pos_at_main_path ~= nil))

        local lp = Managers.player:local_player(1)
        local unit = lp and lp.player_unit
        if not unit then
            add("no local player unit")
            return
        end
        --[[
            Report BOTH sources, because the difference between them was the
            whole bug: POSITION_LOOKUP returning something Vector3 rejects while
            Unit.world_position returns a usable value.
        --]]
        local raw_pl = nil
        pcall(function() raw_pl = POSITION_LOOKUP[unit] end)
        add("POSITION_LOOKUP type: %s | Unit.world_position type: %s",
            type(raw_pl), type(mod.unit_position and mod.unit_position(unit)))

        local pos = mod.unit_position and mod.unit_position(unit)
        if not pos then
            add("no usable position for local player")
            return
        end
        if EO and EO.closest_pos_at_main_path and main_path_ready() then
            local ok, a, b = pcall(EO.closest_pos_at_main_path, pos)
            add("raw closest_pos ok=%s dist=%s%s", tostring(ok), tostring(b),
                ok and "" or ("  err=" .. tostring(a)))
        end
    end)

    add("lead travel distance: %s", tostring(mod.state.lead))
    add("players positioned: %s  spread: %s  back: %s",
        tostring(mod.state.players_positioned),
        tostring(mod.state.spread), tostring(mod.state.backtrack))

    --[[
        Guarded-call failures, by site.

        Empty here means nothing has silently failed. Anything listed is a
        precise engine error that would previously have been discarded.
    --]]
    local tr = mod.try_report and mod.try_report() or {}
    if #tr > 0 then
        add("GUARDED FAILURES:")
        for i = 1, #tr do
            add("%s", tr[i])
        end
    else
        add("guarded failures: none")
    end

    local ms = mod.marker_stats or {}
    add("markers: active %s added %s removed %s no-position %s errors %s",
        tostring(ms.active), tostring(ms.added), tostring(ms.removed),
        tostring(ms.no_position), tostring(ms.errors))
    add("markers breaker: %s  template ok: %s",
        tostring(mod.breaker_count and mod.breaker_count("markers")),
        tostring(mod.marker_template_ok))
    add("panel: %s  walls: %s  pos x=%s y=%s",
        tostring(mod:get("show_spawn_panel")), tostring(mod:get("show_spawn_walls")),
        tostring(mod:get("spawn_offset_x")), tostring(mod:get("spawn_offset_y")))

    local lead = mod.state.lead
    if not lead then
        add("no lead distance - forecast cannot render")
        return out
    end

    add("clear for: %s m", tostring(Spawns.clear_for(lead)))
    local up = Spawns.upcoming(lead, 5)
    for i = 1, #up do
        add("  %s  %.0fm  (%s)%s", up[i].label, up[i].gap, up[i].band,
            up[i].odds and string.format("  %.0f%%", up[i].odds * 100) or "")
    end

    return out
end

--[[
    DOWNS AND DEATHS - the punishments that were never wired.

    coherency_break() was only ever called from the min_coherency edge, which
    means only the DISTANCE break was detected - and in solo play not even
    that. A down and a death are the two biggest punishments in the model
    (each counts twice: a down is a coherency break AND a down break, a death
    is a coherency break AND a death break) and neither reached the cascade.

    Hooked on the character state's on_enter, which is the exact frame the
    state is entered, so there is no polling and no edge detection to get
    wrong. String targets so DMF defers them until the classes exist.

    Only the LOCAL player's transitions count here. A teammate going down is
    already covered by the coherency edge above, and counting both would
    double-punish one event.
--]]
local function local_player_unit_safe()
    local pm = Managers.player
    if not pm or not pm.local_player_safe then
        return nil
    end

    local ok, player = pcall(pm.local_player_safe, pm, 1)
    return ok and player and player.player_unit or nil
end

mod:hook_safe("PlayerCharacterStateKnockedDown", "on_enter", function(self)
    if mod.Cascade and self._unit and self._unit == local_player_unit_safe() then
        pcall(mod.Cascade.coherency_break, "down")
    end
end)

mod:hook_safe("PlayerCharacterStateDead", "on_enter", function(self)
    if mod.Cascade and self._unit and self._unit == local_player_unit_safe() then
        pcall(mod.Cascade.coherency_break, "death")
    end
end)

--[[
    Hogtied and netted are disabler captures, not coherency breaks, so they do
    NOT call coherency_break - but they are worth knowing about and the model
    may want them later. Left unhooked rather than guessed at.
--]]

mod:command("htspawns", "Show spawn forecast diagnostics", function()
    local lines = diag_lines()
    for i = 1, #lines do
        mod:echo(lines[i])
    end
    mod:echo("(type /htcopy to put this on your clipboard)")
end)

--[[
    Clipboard export.

    Clipboard.put is an engine global - not in the script dump, but present at
    runtime and used by IconBrowser, so it is proven on this build. Guarded
    anyway, with a file fallback, because an unavailable clipboard should
    degrade rather than fail.
--]]
mod:command("htcopy", "Copy diagnostics to clipboard", function()
    local lines = diag_lines()
    local text = table.concat(lines, "\n")

    local clipboard = rawget(_G, "Clipboard")
    local put = clipboard and clipboard.put

    if type(put) == "function" then
        local ok = pcall(put, text)
        if ok then
            mod:echo(string.format(
                "Copied %d lines to clipboard. Paste anywhere with Ctrl+V.", #lines))
            return
        end
    end

    -- Fallback: write a file they can open and copy from.
    local wrote = false
    pcall(function()
        local io_ = sandbox_io()
        local path = appdata_path("HavocTracker_diagnostics.txt")
        if not io_ or not path then return end
        local f = io_.open(path, "w")
        if not f then return end
        f:write(text, "\n")
        f:close()
        wrote = true
        mod:echo("Clipboard unavailable - wrote AppData/Fatshark/Darktide/HavocTracker_diagnostics.txt")
    end)

    if not wrote then
        mod:echo("Could not copy or write diagnostics.")
    end
end)

mod:command("havoctracker", mod:localize("cmd_status_desc"), function()
    local count = 0
    for _ in pairs(tracked) do
        count = count + 1
    end

    mod:echo("--- Havoc Tracker ---")
    mod:echo(string.format("enabled: %s", tostring(mod:is_enabled())))
    mod:echo(string.format("in mission: %s", tostring(mod.state.in_mission)))
    mod:echo(string.format("tracked units: %d (counted: %d)", count, mod.state.minion_count))
    mod:echo(string.format("challenge rating: %.1f", mod.state.challenge_rating))
    mod:echo(string.format("overlay at x=%s y=%s scale=%s",
        tostring(mod:get("hud_offset_x")), tostring(mod:get("hud_offset_y")), tostring(mod:get("hud_scale"))))
    mod:echo(string.format("aggro estimate: %s (x%s detection radius)",
        tostring(mod:get("use_aggro_estimate")), tostring(mod:get("aggro_multiplier"))))

    local s = mod.state
    mod:echo(string.format("players alive=%d | main_path=%s",
        s.alive_players or 0,
        tostring(Managers.state and Managers.state.main_path ~= nil)))
    mod:echo(string.format("path: lead=%s tail=%s furthest=%.0f spread=%.0f backtrack=%.0f",
        s.lead and string.format("%.0f", s.lead) or "NIL",
        s.tail and string.format("%.0f", s.tail) or "NIL",
        s.furthest, s.spread, s.backtrack))
    mod:echo(string.format("hordes seen: %d | since last wave: %.0fs | active: %s",
        s.hordes_seen, s.since_horde, tostring(s.horde_active)))
    mod:echo(string.format("ramp: %.0f pct units=%.0f locked=%s (ESTIMATE)",
        s.ramp_pct * 100, s.ramp_units, tostring(s.ramp_locked)))
    mod:echo(string.format("coherency min=%d | alone=%.1fs | speedrun checks=%d | players=%d",
        s.min_coherency, s.alone_seconds, s.speedrun_checks, s.alive_players or 0))
    mod:echo(string.format("breakers: %s | skipped position pairs: %d",
        mod.breaker_status(), mod._bad_position_pairs or 0))
end)

-- The ramp estimator cannot see its own resets: those fire when server-side
-- tension crosses 122.5, which is not replicated. If you have just survived a
-- genuinely heavy fight, the real meter has almost certainly zeroed - use this
-- to tell the estimate.
--[[
    Path probe.

    Two speculative fixes for travel distance have now failed, so this stops
    guessing and reports what actually happens. It tries every plausible route
    to a travel distance and prints the real result of each, including the
    error text when one throws.

    Run it mid-mission and paste the output.
--]]
mod:command("htpath", "Diagnose why travel distance is not resolving", function()
    local player = Managers.player and Managers.player:local_player(1)
    local unit = player and player.player_unit

    mod:echo("--- path probe ---")
    mod:echo(string.format("player unit: %s | alive: %s",
        tostring(unit ~= nil), tostring(unit and HEALTH_ALIVE[unit] or false)))

    if not unit then return end

    -- Compare both accessors: POSITION_LOOKUP is the one that returns userdata
    -- the Vector3 functions reject, Unit.world_position is the one that works.
    local raw_pl
    pcall(function() raw_pl = POSITION_LOOKUP[unit] end)
    local pos = mod.unit_position and mod.unit_position(unit)
    mod:echo(string.format("POSITION_LOOKUP type=%s | Unit.world_position type=%s",
        type(raw_pl), type(pos)))
    if not pos then return end

    --[[
        This diagnostic pokes the raw engine calls deliberately, so it is the
        one place most likely to crash the game if run at the wrong moment.
        Refuse outright rather than segfault someone who typed a debug command
        in the hub.
    --]]
    if not main_path_ready() then
        mod:echo("no main path registered right now - run this inside a mission")
        return
    end

    -- 1. the engine call the level components use
    local ok, a, b = pcall(function()
        local MPQ = require("scripts/utilities/main_path_queries")
        local cpos, dist = MPQ.closest_position(pos)
        return tostring(cpos), dist
    end)
    mod:echo(string.format("1 MainPathQueries.closest_position -> ok=%s dist=%s %s",
        tostring(ok), tostring(b), ok and "" or tostring(a)))

    -- 2. raw engine function, no wrapper
    local ok2, res2 = pcall(function()
        local _, dist = EngineOptimized.closest_pos_at_main_path(pos)
        return dist
    end)
    mod:echo(string.format("2 EngineOptimized.closest_pos_at_main_path -> ok=%s dist=%s",
        tostring(ok2), tostring(res2)))

    -- 3. the manager route (expected to fail on clients)
    local ok3, res3 = pcall(function()
        return Managers.state.main_path:travel_distance_from_position(pos)
    end)
    mod:echo(string.format("3 main_path:travel_distance_from_position -> ok=%s dist=%s",
        tostring(ok3), tostring(res3)))

    -- 4. is the manager even there, and does it think it has a path?
    local mp = Managers.state and Managers.state.main_path
    mod:echo(string.format("4 main_path mgr=%s  nav_spawn_points=%s",
        tostring(mp ~= nil),
        mp and tostring(pcall(mp.nav_spawn_points, mp)) or "n/a"))

    mod:echo(string.format("state: lead=%s furthest=%.0f spread=%.0f",
        tostring(mod.state.lead), mod.state.furthest or 0, mod.state.spread or 0))
end)

mod:command("htramp", mod:localize("cmd_ramp_reset_desc"), function()
    mod.state.ramp_units  = 0
    mod.state.ramp_pct    = 0
    mod.state.ramp_locked = false
    mod:echo("Havoc Tracker: ramp estimate zeroed.")
end)

--[[
    ONE SET OF DEFAULTS, USED BY BOTH THE COMMAND AND THE BUTTON.

    These used to be three literals inside the /htreset handler, which meant
    the command and the options table could disagree about what "default"
    was and nothing would notice. They agree now because there is only one
    copy, and it is this one.

    DELIBERATELY NOT read out of the options table at runtime. DMF flattens
    that table at registration and does not keep the defaults addressable, so
    reading them back would mean re-parsing the file - which is how the two
    copies got out of step in the first place. A test below asserts they
    match instead.
--]]
local DEFAULT_POSITION = {
    hud_offset_x   = -700,
    hud_offset_y   = -260,
    hud_scale      = 1,
    panel_opacity  = 30,
    spawn_offset_x = 640,
    spawn_offset_y = -260,
    spawn_scale    = 2,
}

--[[
    Every setting this mod owns, with the value it ships as.

    The button writes ALL of these; the /htreset command writes only the
    position block, because "my overlay is off screen" and "put everything
    back" are different problems and conflating them would make the
    recovery command destructive.
--]]
local DEFAULT_SETTINGS = {
    show_overlay            = true,
    hud_mode                = "cap_only",
    show_headcount          = false,
    show_notifications      = true,
    show_cascade            = false,
    cap_opacity             = 150,
    panel_width             = 360,
    panel_row_height        = 19,
    panel_section_gap       = 3,
    show_spawn_panel        = false,
    show_spawn_walls        = false,
    spawn_audio_cue         = false,
    show_path_line          = false,
    path_marker_scale       = 1,
    show_ritual_markers     = false,
    simple_labels           = true,
    spawn_marker_scale      = 2,
    spawn_marker_opacity    = 42,
    keep_base_hud           = true,
    clean_limit_outlines    = true,
    clean_outline_radius    = 20,
    clean_hide_dangerzones  = true,
    clean_hide_weakspots    = true,
    clean_hide_mod_markers  = true,
    chat_scale_enabled      = true,
    chat_scale              = 1,
    chat_post               = false,
    chat_post_interval      = 10,
    chat_post_events        = true,
    chat_post_status        = true,
    chat_post_preview       = false,
    use_aggro_estimate      = true,
    aggro_multiplier        = 2,
    enable_prediction       = true,
    spawn_accuracy_log      = true,
    census_interval         = 0.25,
    path_interval           = 0.1,
}

--[[
    The keeps are listed apart because they are all false and listing thirty
    lines of `= false` would bury the table above.
--]]
local KEEP_SETTINGS = {
    "keep_crosshair", "keep_vitals", "keep_interact", "keep_team",
    "keep_boss", "keep_objective", "keep_buffs", "keep_tags",
    "keep_chat", "keep_tracker", "keep_spawn_panel", "keep_markers",
}

--[[
    notify_mod = true on every write.

    DMFMod:set's third argument is what fires on_setting_changed. Without it
    the value lands in the config and nothing that caches a setting hears
    about it, so the menu would show the new number while the HUD kept
    drawing the old one until a reload. That was the bug in the first version
    of the reset command.
--]]
local function put(id, value)
    pcall(mod.set, mod, id, value, true)
end

local function apply_position_defaults()
    for id, value in pairs(DEFAULT_POSITION) do
        put(id, value)
    end
end

mod.reset_to_defaults = function()
    apply_position_defaults()

    for id, value in pairs(DEFAULT_SETTINGS) do
        put(id, value)
    end

    for i = 1, #KEEP_SETTINGS do
        put(KEEP_SETTINGS[i], false)
    end

    --[[
        Keybinds are NOT reset. They are the one kind of setting where the
        shipped default is "nothing", so resetting them is pure loss - it
        unbinds whatever the user chose and hands back a key they have to
        find and set again. Nobody has ever wanted that from a reset button.
    --]]
    mod:echo("Havoc Tracker: settings reset to defaults. Keybinds left alone.")
end

--[[
    PRESETS.

    Each preset is a sparse patch, not a full settings table. A preset that
    listed every setting would silently undo unrelated choices - picking
    "Minimal" should not decide for you whether the aggro estimate is on.
    Only the keys that define the arrangement are written.
--]]
local PRESETS = {
    --[[
        MINIMAL - the entity cap block and nothing else. No second panel, no
        beacons, no path line. For people who want the one number the mod
        exists to provide and none of the research surface.
    --]]
    minimal = {
        show_overlay        = true,
        show_headcount      = false,
        show_notifications  = true,
        hud_mode            = "cap_only",
        show_cascade        = false,
        show_spawn_panel    = false,
        show_path_line      = false,
        show_ritual_markers = false,
        show_spawn_walls    = false,
        spawn_audio_cue     = false,
        panel_opacity       = 30,
    },

    --[[
        STANDARD - the shipped arrangement. Cap block plus the specialist
        cascade, the spawn panel and its markers. This is what a fresh
        install looks like, so the preset doubles as "put the display back"
        without touching accuracy or performance.
    --]]
    standard = {
        show_overlay        = true,
        show_headcount      = false,
        show_notifications  = true,
        hud_mode            = "cap_only",
        show_cascade        = true,
        show_spawn_panel    = true,
        show_path_line      = true,
        show_ritual_markers = true,
        show_spawn_walls    = true,
        spawn_audio_cue     = true,
        panel_opacity       = 45,
    },

    --[[
        EVERYTHING - the full readout: verdicts, priority queue, forecast and
        ramp, on top of all of the above. This is the mode the modelled
        numbers live in, which is why it is opt-in rather than the default -
        the measured half is trustworthy in a way the predicted half is not.
    --]]
    everything = {
        show_overlay        = true,
        show_headcount      = true,
        show_notifications  = true,
        hud_mode            = "full",
        show_cascade        = true,
        show_spawn_panel    = true,
        show_path_line      = true,
        show_ritual_markers = true,
        show_spawn_walls    = true,
        spawn_audio_cue     = true,
        panel_opacity       = 45,
        enable_prediction   = true,
    },
}

--[[
    Applied on selection, then the dropdown drops back to "custom".

    A preset dropdown that stays on its last value is lying the moment the
    user changes any single setting underneath it - and they will, because
    that is what the settings below it are for. Snapping back to custom means
    the control describes an ACTION taken rather than a state claimed.

    The guard matters: setting it back to "custom" re-enters this function
    through on_setting_changed, and without the early return that is an
    infinite loop rather than a settings menu.
--]]
mod.apply_preset = function(choice)
    if choice == nil or choice == "custom" then
        return
    end

    local patch = PRESETS[choice]

    if not patch then
        return
    end

    for id, value in pairs(patch) do
        put(id, value)
    end

    mod:echo(string.format("Havoc Tracker: applied the %s preset.", tostring(choice)))
end

--[[
    A COMMAND, NOT A DROPDOWN.

    This was a dropdown widget until the dropdown type turned out to be part
    of why the mod failed to register on other people's installs. A command
    costs nothing at load, cannot take the options table down with it, and
    does the same job - see the capability note at the top of the data file.
--]]
mod:command("htpreset", "apply a settings preset: minimal, standard or everything",
function(choice)
    choice = choice and string.lower(choice) or nil

    if not choice or not PRESETS[choice] then
        mod:echo("Havoc Tracker: /htpreset minimal | standard | everything")
        mod:echo("  minimal    - the entity cap block only")
        mod:echo("  standard   - cap block, cascade and the spawn panel")
        mod:echo("  everything - the full readout, including modelled numbers")
        return
    end

    mod.apply_preset(choice)
end)

-- Snap the overlay back to a known-visible spot if it has been lost off-screen.
mod:command("htreset", mod:localize("cmd_reset_desc"), function()
    apply_position_defaults()
    mod:echo("Havoc Tracker: overlay position reset.")
end)
