local mod = get_mod("HavocTracker")

--[[
    ========================================================================
    PACE - a client-side mirror of the three specials-pacing punishments
    ========================================================================

    Source: scripts/managers/pacing/specials_pacing/specials_pacing.lua
    (game 1.13.4, Aussiemon/Darktide-Source-Code e46b892):

        _update_rush_prevention            :1301-1399
        _update_loner_prevention           :1401-1485
        _update_speed_running_prevention   :1487-1568
        try_inject_special                 :1570-1602
        disabler cap and override          :1010-1090

    and the six resistance rows of havoc_specials_pacing_template.lua. Each
    rule is ported line for line below, and the comments say where the
    client has to estimate (the server keeps its timers to itself).

    WHAT THE PLAYER GETS

      SPEED gate   a world marker on the route: "stay behind this line for
                   N s". Cross it before the countdown ends and the next
                   speed-running check counts. Two counted checks in a row
                   (four at ranks 1-10) inject a hound, mutant or trapper
                   ahead of the lead player.
      RUSH line    where the lead player starts a rush-prevention spawn
                   (and the matching line behind the team for the last
                   player).
      LONER        how long somebody has been alone, against the window in
                   which loner prevention fires.
      BLOCKADE     (rank 16+) the point 50 m behind the furthest the team has
                   reached, where the blockade horde strike goes from a 5 pct
                   roll to 50 / 80 pct.
      LAST UP      the disabler cap for the players still up.

    ------------------------------------------------------------------------
    SPEED-RUNNING PREVENTION, EXACTLY

    Per server frame (outside the specials_allowed gate, so it runs even
    while specials are switched off):

      1. return while on cooldown, or with no ahead unit
      2. return while total challenge rating < required (8 at rank 30+)
         - NOTHING is reset here. The baseline from the last check stays,
           and the next check is due immediately once CR is back up. So
           moving freely through an empty corridor and walking into a fight
           can count as a check on the first frame of the fight.
      3. return until the next check time; then schedule the next one 5 s on
      4. first check after a reset only records the baseline
      5. lead moved < required (10 m at rank 11+): count = 0, baseline
         dropped, return
      6. count + 1; inject when count >= required checks (2 at rank 11+,
         4 at ranks 1-10). At ranks 1-10 a lead player with nobody in
         coherency only needs 2.
      7. inject a disabler ahead of the lead, ignoring the special
         allowance. It only fails when every special slot is in use.

    The client cannot see when the server's 5 s clock ticks. So the rule is
    run FIFTY times, once for every 0.1 s offset of that clock, and the
    worst case is what is shown. "Stay behind the line until the countdown
    ends" is true for every possible offset at once.

    ------------------------------------------------------------------------
    WHAT IS ESTIMATED

      challenge rating   the mod's own census (aggro is not replicated)
      special slots      alive specials counted on the client; the server
                         also counts slots that are still foreshadowing
      cooldowns          after a predicted spawn, the shortest cooldown is
                         assumed (warn early rather than late)
      travel distance    projected onto the whole route (the server uses
                         the nav group segment). A forward jump of more than
                         MAX_STEP in one sample by the same lead player is a
                         projection jump, not movement, and is not counted.
--]]

local Pace = {}

local MainPathQueries
do
    local ok, m = pcall(require, "scripts/utilities/main_path_queries")
    MainPathQueries = ok and m or nil
end

-- ---------------------------------------------------------------------------
-- Source tables
-- ---------------------------------------------------------------------------

-- havoc_specials_pacing_template.lua, resistance rows 1-6.
local RUSH_CD       = { { 150, 250 }, { 80, 120 }, { 60, 100 }, { 50, 80 }, { 30, 50 }, { 25, 45 } }
local RUSH_FAIL_CD  = { 5, 10 }
local LONER_CD      = { nil, nil, nil, { 40, 60 }, { 20, 40 }, { 15, 35 } }
local LONER_FAIL_CD = { 3, 7 }
local SR_CD         = { nil, { 20, 40 }, { 20, 40 }, { 10, 15 }, { 10, 15 }, { 10, 15 } }
local SR_FAIL_CD    = { nil, { 5, 10 }, { 5, 10 }, { 2, 8 }, { 2, 8 }, { 2, 8 } }

-- special_pacing_template_settings.havoc, by challenge 1-5, indexed by the
-- number of players who are up (1-4). NOT the default table: in Havoc a down
-- does not lower the disabler cap at challenge 4 and 5.
local DISABLER_CAP = {
    { 0, 0, 1, 1 },
    { 0, 1, 1, 2 },
    { 2, 2, 3, 3 },
    { 3, 3, 3, 3 },
    { 4, 4, 4, 4 },
}
local DISABLER_OVERRIDE = { 360, 240, 160, 100, 80 }

-- mutator_horde_pacing_template.lua:198
local BACKTRACK_M = 50

--[[
    horde_pacing.lua:59-66 (the second definition wins): at ranks that spawn
    hordes by distance (1-15), standing still with NOTHING aggroed for this
    long switches the horde timer from metres to seconds. By resistance.
--]]
local CAMP_S = { 60, 60, 60, 15, 10, 10 }

-- player_unit_status.lua:23-33
local REQUIRES_HELP = {
    consumed = true, grabbed = true, hogtied = true, knocked_down = true,
    ledge_hanging = true, mutant_charged = true, netted = true, pounced = true,
    warp_grabbed = true,
}

-- ---------------------------------------------------------------------------
-- Tuning (display only; none of these change what the game does)
-- ---------------------------------------------------------------------------

--[[
    50 offsets, 0.1 s apart: the same resolution as the 10 Hz path tick that
    feeds this. With 10 offsets a player at sprint speed could pass the line of
    a server clock that falls between two simulated ones (a harness run showed
    injections while the gate read safe). GATE_MARGIN covers what is left
    between a 0.1 s sample and the server's own frame.
--]]
local PHASES      = 50
local GATE_MARGIN = 1.0     -- m; the gate is drawn this much early
local MAX_STEP    = 15      -- m per sample; more is a projection jump
local RUSH_WARN_M = 15      -- show the rush line this far before it
local BACK_WARN_M = 15      -- show the blockade line this far before it
local SPEED_NEAR  = 25      -- show the speed gate only this close to the lead

-- ---------------------------------------------------------------------------
-- State
-- ---------------------------------------------------------------------------

local phases = {}
for i = 1, PHASES do
    phases[i] = { offset = (i - 1) * 5 / PHASES }
end

local S = {
    -- inputs, refreshed per update
    n_valid = 0, n_up = 0,
    lead = nil, lead_unit = nil, tail = nil,
    second_ahead = nil, second_behind = nil,
    lead_alone = false,
    odo = 0, odo_lead = nil, odo_unit = nil,
    hist_t = {}, hist_odo = {}, hist_n = 0, hist_head = 0,

    -- speed
    sr_status = "off",       -- off | paused | clear | warm | armed | doomed
    sr_worst = 0, sr_need = 2, sr_armed = 0,
    sr_gate_odo = nil, sr_gate_t = nil, sr_doom_t = nil,
    sr_window_m = 0,

    -- rush
    rush_gap_ahead = 0, rush_gap_behind = 0,
    rush_line_ahead = nil, rush_line_behind = nil,
    rush_cd_until = 0, rush_cd_max = 0,
    rush_fired_t = nil, rush_fired_dir = nil,

    -- loner
    alone_since = nil, alone_name = nil,
    loner_lo = nil, loner_hi = nil,
    loner_fired_t = nil,

    -- team
    disabler_cap = 4, disablers = 0, slots_free = nil,
    one_up_since = nil,
}

Pace.state = S

local function now()
    return mod._now or 0
end

local function cfg()
    return mod.cfg or {}
end

local function resistance()
    local r = cfg().resistance or 6
    if r < 1 then r = 1 elseif r > 6 then r = 6 end
    return r
end

local function challenge()
    local c = cfg().challenge or 5
    if c < 1 then c = 1 elseif c > 5 then c = 5 end
    return c
end

local function finite(n)
    return type(n) == "number" and n == n and n ~= math.huge and n ~= -math.huge
end

local function character_state(unit)
    local ude = ScriptUnit.has_extension(unit, "unit_data_system")
    if not ude or type(ude.read_component) ~= "function" then
        return nil
    end
    local ok, comp = pcall(ude.read_component, ude, "character_state")
    if not ok or type(comp) ~= "table" then
        return nil
    end
    local name = rawget(comp, "state_name") or comp.state_name
    return type(name) == "string" and name or nil
end

local function coherency_of(unit)
    local ext = ScriptUnit.has_extension(unit, "coherency_system")
    if not ext or not ext.num_units_in_coherency then
        return nil
    end
    local ok, n = pcall(ext.num_units_in_coherency, ext)
    return (ok and type(n) == "number") and n or nil
end

local function player_name(player)
    if player and type(player.name) == "function" then
        local ok, n = pcall(player.name, player)
        if ok and type(n) == "string" then
            return n
        end
    end
    return "someone"
end

-- ---------------------------------------------------------------------------
-- Inputs
-- ---------------------------------------------------------------------------

-- Reused per update, never reallocated.
local valid_d, valid_u, valid_p = {}, {}, {}

local function gather()
    local n, up = 0, 0
    local lead, lead_unit, tail, tail_unit
    local alone_name

    for _, player in pairs(Managers.player:players()) do
        local unit = player.player_unit

        if unit and HEALTH_ALIVE[unit] then
            local state_name = character_state(unit)

            --[[
                side_system.lua:404 builds valid_player_units with
                `not PlayerUnitStatus.is_hogtied`: a teammate lying hogtied at
                a respawn beacon is not on the side the pacing measures.
            --]]
            if state_name ~= "hogtied" then
                local d = mod.travel_distance_of and mod.travel_distance_of(unit)

                if not REQUIRES_HELP[state_name or ""] then
                    up = up + 1
                end

                if finite(d) then
                    n = n + 1
                    valid_d[n], valid_u[n], valid_p[n] = d, unit, player

                    if not lead or d > lead then lead, lead_unit = d, unit end
                    if not tail or d < tail then tail, tail_unit = d, unit end
                end

                -- Loner targets include disabled players: no filter at :1427.
                if coherency_of(unit) == 1 and not alone_name then
                    alone_name = player_name(player)
                end
            end
        end
    end

    for i = n + 1, #valid_d do
        valid_d[i], valid_u[i], valid_p[i] = nil, nil, nil
    end

    S.n_valid, S.n_up = n, up
    S.lead, S.lead_unit, S.tail = lead, lead_unit, tail
    S.alone_name = alone_name

    --[[
        _update_rush_prevention :1336-1367. Two players: each is measured
        against the other. Three or more: the lead against the furthest of
        the middle players, the last against the rearmost of them.
    --]]
    local sa, sb = nil, nil

    if n == 2 then
        sa, sb = tail, lead
    elseif n >= 3 then
        for i = 1, n do
            local u = valid_u[i]
            if u ~= lead_unit and u ~= tail_unit then
                local d = valid_d[i]
                if not sa or d > sa then sa = d end
                if not sb or d < sb then sb = d end
            end
        end
    end

    S.second_ahead, S.second_behind = sa, sb
    S.lead_alone = lead_unit ~= nil and coherency_of(lead_unit) == 1
end

--[[
    The lead odometer. Same numbers as S.lead, except that a jump of more
    than MAX_STEP in one sample by the SAME player is dropped: that is the
    whole-route projection snapping across a fold, which the server's
    nav-group projection does not do. A jump caused by the lead CHANGING
    (the lead going hogtied, a rescued teammate ahead) is kept, because the
    server's ahead distance jumps the same way.
--]]
local HIST = 80   -- 8 s at the 10 Hz path tick

local function update_odometer(t)
    local lead, unit = S.lead, S.lead_unit

    if not lead then
        return
    end

    if S.odo_lead then
        local step = lead - S.odo_lead
        if not (math.abs(step) > MAX_STEP and unit == S.odo_unit) then
            S.odo = S.odo + step
        end
    end

    S.odo_lead, S.odo_unit = lead, unit

    -- Ring buffer of (t, odo), for the 5 s window readout.
    local h = S.hist_head % HIST + 1
    S.hist_head = h
    S.hist_t[h], S.hist_odo[h] = t, S.odo
    if S.hist_n < HIST then S.hist_n = S.hist_n + 1 end
end

-- Odometer value at (or just before) time t_back, or nil.
local function odo_at(t_back)
    local best_t, best_o
    for i = 1, S.hist_n do
        local ht = S.hist_t[i]
        if ht and ht <= t_back and (not best_t or ht > best_t) then
            best_t, best_o = ht, S.hist_odo[i]
        end
    end
    return best_o
end

local function slots_free()
    local c = cfg()
    local max = c.max_alive_specials
    local cap = mod.Cap and mod.Cap.read and mod.Cap.read()
    if not max or not cap or type(cap.special) ~= "number" then
        return nil
    end
    return max - cap.special
end

-- ---------------------------------------------------------------------------
-- Speed-running prevention (:1487-1568), once per clock offset
-- ---------------------------------------------------------------------------

local function sr_config()
    local c = cfg()
    if not c.sr_dist or not c.sr_checks then
        return nil
    end
    return c.sr_dist, c.sr_checks, c.sr_cr or 8, c.sr_freq or 5
end

local function reset_phases()
    for i = 1, PHASES do
        local p = phases[i]
        p.next_t = p.offset
        p.prev = nil
        p.count = 0
        p.cd_until = 0
        p.fired_t = nil
    end
end

reset_phases()

local function run_phase(p, t, odo, cr, req_dist, req_checks, req_cr, freq, free)
    if t < p.cd_until then
        return
    end
    if cr < req_cr then
        return
    end
    if t < p.next_t then
        return
    end

    -- Catch up a clock that fell more than one period behind while CR was
    -- low: the server schedules from the check it just made, not from the
    -- missed slots, so only the phase offset survives.
    p.next_t = t + freq

    if not p.prev then
        p.prev = odo
        return
    end

    local diff = odo - p.prev
    p.prev = odo

    if diff < req_dist then
        p.count = 0
        p.prev = nil
        return
    end

    p.count = p.count + 1

    if req_checks > p.count and (not S.lead_alone or p.count == 1) then
        return
    end

    -- Inject. Fails only with every slot in use.
    local r = resistance()
    local success = (free == nil) or free > 0
    local cd = success and SR_CD[r] or SR_FAIL_CD[r]

    if success then
        p.count = 0
        p.prev = nil
    end

    p.cd_until = t + (cd and cd[1] or 5)
    p.fired_t = t
end

local function update_speed(t, cr, free)
    local req_dist, req_checks, req_cr, freq = sr_config()

    if not req_dist or not S.lead then
        S.sr_status = "off"
        S.sr_gate_odo, S.sr_gate_t, S.sr_doom_t = nil, nil, nil
        return
    end

    local odo = S.odo

    for i = 1, PHASES do
        run_phase(phases[i], t, odo, cr, req_dist, req_checks, req_cr, freq, free)
    end

    --[[
        A phase is ARMED when one more passing check injects:
        count + 1 >= required, or (lead alone and count >= 1).
        It is DOOMED when it is armed and the lead is already past its line,
        so its next check will pass whatever the team does now.
    --]]
    local worst, armed = 0, 0
    local gate_odo, gate_t, doom_t
    local fired_recently = false

    for i = 1, PHASES do
        local p = phases[i]

        if p.fired_t and t - p.fired_t < 6 then
            fired_recently = true
        end

        if t >= p.cd_until then
            if p.count > worst then
                worst = p.count
            end

            local is_armed = p.prev ~= nil
                and (p.count + 1 >= req_checks or (S.lead_alone and p.count >= 1))

            if is_armed then
                armed = armed + 1
                local line = p.prev + req_dist - GATE_MARGIN

                if odo >= line then
                    if not doom_t or p.next_t < doom_t then
                        doom_t = p.next_t
                    end
                else
                    if not gate_odo or line < gate_odo then
                        gate_odo = line
                    end
                    if not gate_t or p.next_t > gate_t then
                        gate_t = p.next_t
                    end
                end
            end
        end
    end

    S.sr_worst, S.sr_armed = worst, armed
    S.sr_need = req_checks
    S.sr_gate_odo, S.sr_gate_t, S.sr_doom_t = gate_odo, gate_t, doom_t
    S.sr_fired_recently = fired_recently

    local back = odo_at(t - freq)
    S.sr_window_m = back and math.max(0, odo - back) or 0
    S.sr_req_dist, S.sr_req_cr = req_dist, req_cr

    --[[
        doomed > armed > just fired > warm > clear. While CR is under the
        threshold nothing is checked, but a doomed or armed baseline is kept
        and is checked the moment CR is back, so those still show.
    --]]
    local paused = cr < req_cr
    S.sr_paused = paused

    if doom_t then
        S.sr_status = "doomed"
    elseif armed > 0 then
        S.sr_status = paused and "paused" or "armed"
    elseif fired_recently then
        S.sr_status = "fired"
    elseif worst > 0 then
        S.sr_status = paused and "paused" or "warm"
    else
        S.sr_status = paused and "off" or "clear"
    end
end

-- ---------------------------------------------------------------------------
-- Rush prevention (:1301-1399)
-- ---------------------------------------------------------------------------

local function update_rush(t, free)
    local c = cfg()
    local dist = c.rushing

    S.rush_line_ahead, S.rush_line_behind = nil, nil
    S.rush_gap_ahead, S.rush_gap_behind = 0, 0

    if not dist or S.n_valid < 2 or not S.second_ahead or not S.lead then
        return
    end

    S.rush_gap_ahead = math.abs(S.lead - S.second_ahead)
    S.rush_gap_behind = math.abs(S.tail - S.second_behind)
    S.rush_line_ahead = S.second_ahead + dist
    S.rush_line_behind = S.second_behind - dist
    S.rush_dist = dist

    -- Rush prevention needs a free special slot (:1308) and runs inside the
    -- specials_allowed gate.
    local slot_ok = free == nil or free > 0

    if t < S.rush_cd_until or not slot_ok then
        return
    end

    local dir
    if S.rush_gap_ahead >= dist then
        dir = "ahead"
    elseif S.rush_gap_behind >= dist then
        dir = "behind"
    end

    if dir then
        local cd = RUSH_CD[resistance()] or RUSH_CD[6]
        S.rush_cd_until = t + cd[1]
        S.rush_cd_max = t + cd[2]
        S.rush_fired_t, S.rush_fired_dir = t, dir
    end
end

-- ---------------------------------------------------------------------------
-- Loner prevention (:1401-1485)
-- ---------------------------------------------------------------------------

local function update_loner(t)
    local c = cfg()

    if not c.loner_time then
        S.alone_since, S.loner_lo, S.loner_hi = nil, nil, nil
        return
    end

    -- Below three players up the rule pushes its own cooldown and stops.
    if S.n_up <= 2 or not S.alone_name then
        S.alone_since, S.loner_lo, S.loner_hi = nil, nil, nil
        return
    end

    local lt = c.loner_time

    --[[
        While nobody is alone, every update re-arms the FAILED cooldown
        (3-7 s, :1452-1456). So once somebody IS alone, the server first
        waits that out, then rolls loner_time (:1463-1467), then injects:

            fires between alone + 3 + loner_time[1] and alone + 7 + loner_time[2]

        That is 8-16 s alone at rank 31+, not the 5-9 s of loner_time alone.
    --]]
    if not S.alone_since then
        S.alone_since = t
        S.loner_lo = t + LONER_FAIL_CD[1] + lt[1]
        S.loner_hi = t + LONER_FAIL_CD[2] + lt[2]
    end

    if t >= S.loner_hi then
        --[[
            Past the latest edge it has fired (if a slot was free). After a
            success the cooldown is the full loner cooldown and nothing pushes
            it, so the next window is fire + cooldown + loner_time.
        --]]
        local cd = LONER_CD[resistance()] or LONER_CD[6]
        S.loner_fired_t = t
        S.loner_lo = t + cd[1] + lt[1]
        S.loner_hi = t + cd[2] + lt[2]

        -- :1479-1483 a loner spawn also restarts the rush cooldown.
        local rcd = RUSH_CD[resistance()] or RUSH_CD[6]
        if t + rcd[1] > S.rush_cd_until then
            S.rush_cd_until = t + rcd[1]
        end
    end
end

-- ---------------------------------------------------------------------------
-- Team
-- ---------------------------------------------------------------------------

local function update_team(t)
    local ch = challenge()
    local up = S.n_up
    local idx = math.max(1, math.min(up, 4))
    S.disabler_cap = (DISABLER_CAP[ch] or DISABLER_CAP[5])[idx]
    S.disablers = (mod.state and mod.state.disablers_alive) or 0

    if up == 1 then
        S.one_up_since = S.one_up_since or t
    else
        S.one_up_since = nil
    end
    S.override_s = DISABLER_OVERRIDE[ch] or 80
end

-- ---------------------------------------------------------------------------
-- Update
-- ---------------------------------------------------------------------------

function Pace.update()
    if not mod.state or not mod.state.in_mission then
        return
    end

    local t = now()

    gather()
    update_odometer(t)

    local free = slots_free()
    S.slots_free = free

    local cr = (mod.state and mod.state.challenge_rating) or 0
    S.cr = cr

    --[[
        Pacing has to have started: before the first spawn the server is not
        running specials pacing at all, and the dropship walk would read as
        a speed run.
    --]]
    if mod.state.pacing_started or cr > 0 then
        update_speed(t, cr, free)
        update_rush(t, free)
        update_loner(t)
    else
        S.sr_status = "off"
    end

    update_team(t)

    if Pace.update_markers then
        Pace.update_markers(t)
    end
end

function Pace.reset()
    reset_phases()
    S.odo, S.odo_lead, S.odo_unit = 0, nil, nil
    S.hist_n, S.hist_head = 0, 0
    for i = 1, HIST do S.hist_t[i], S.hist_odo[i] = nil, nil end
    S.sr_status, S.sr_worst, S.sr_armed = "off", 0, 0
    S.sr_gate_odo, S.sr_gate_t, S.sr_doom_t = nil, nil, nil
    S.rush_cd_until, S.rush_cd_max, S.rush_fired_t = 0, 0, nil
    S.alone_since, S.loner_lo, S.loner_hi, S.loner_fired_t = nil, nil, nil, nil
    S.one_up_since = nil
    for i = 1, #valid_d do valid_d[i], valid_u[i], valid_p[i] = nil, nil, nil end
    if Pace.forget_markers then
        Pace.forget_markers()
    end
end

-- ---------------------------------------------------------------------------
-- Read-outs
-- ---------------------------------------------------------------------------

-- Seconds, never negative, one decimal.
local function secs(x)
    if not x then return 0 end
    x = x - now()
    if x < 0 then x = 0 end
    return math.floor(x * 10 + 0.5) / 10
end

-- Raw travel distance for an odometer value.
local function odo_to_raw(o)
    if not o or not S.lead then return nil end
    return S.lead + (o - S.odo)
end

--[[
    One line for the panel. No percent signs anywhere in this file: with
    DMF's "Output Logs to Developer Console" on, a % reaching the engine's
    print formatter closes the game (found by Respawn Rewind 1.5.0).
--]]
local function camping()
    local c = cfg()
    if not c.travel_spawn then
        return false
    end
    local s = mod.state
    if not s then
        return false
    end
    local still = s.since_forward or 0
    return (s.challenge_rating or 0) <= 0 and still >= (CAMP_S[resistance()] or 60), still
end

Pace.camping = camping

function Pace.panel_line()
    local st = S.sr_status
    local parts = {}

    if st == "doomed" then
        parts[#parts + 1] = S.sr_paused and "SPEED: too fast, spawns when the fight starts"
            or string.format("SPEED: disabler due %.0fs", secs(S.sr_doom_t))
    elseif st == "fired" then
        parts[#parts + 1] = "SPEED: disabler sent ahead"
    elseif st == "armed" then
        local m = S.sr_gate_odo and (S.sr_gate_odo - S.odo) or 0
        parts[#parts + 1] = string.format("SPEED: hold %.1fs (%dm left)", secs(S.sr_gate_t), math.floor(m))
    elseif st == "warm" then
        parts[#parts + 1] = string.format("SPEED %d/%d  %d/%dm in 5s", S.sr_worst, S.sr_need,
            math.floor(S.sr_window_m), S.sr_req_dist or 10)
    elseif st == "paused" then
        parts[#parts + 1] = string.format("SPEED held (CR<%d)", S.sr_req_cr or 8)
    elseif st == "clear" then
        parts[#parts + 1] = string.format("pace %d/%dm", math.floor(S.sr_window_m), S.sr_req_dist or 10)
    end

    if S.rush_line_ahead and S.rush_dist then
        local gap = math.max(S.rush_gap_ahead, S.rush_gap_behind)
        if now() < S.rush_cd_until then
            parts[#parts + 1] = string.format("rush cd ~%ds", math.floor(secs(S.rush_cd_until)))
        else
            parts[#parts + 1] = string.format("rush %d/%dm", math.floor(gap), S.rush_dist)
        end
    end

    if camping() then
        parts[#parts + 1] = "camping: horde timer on the clock"
    end

    if S.alone_since and S.loner_lo then
        parts[#parts + 1] = string.format("ALONE %ds, disabler in %d-%ds",
            math.floor(now() - S.alone_since), math.floor(secs(S.loner_lo)), math.floor(secs(S.loner_hi)))
    end

    return table.concat(parts, "  ")
end

--[[
    Worst-first list of { kind, text } for HavocTracker_punish. Reused table.
--]]
local kinds = {}

function Pace.kinds()
    for i = #kinds, 1, -1 do kinds[i] = nil end

    local function add(kind, text)
        kinds[#kinds + 1] = { kind = kind, text = text }
    end

    local st = S.sr_status
    if st == "doomed" then
        add("speedrun", S.sr_paused and "speed-running: too fast, disabler spawns when the next fight starts"
            or string.format("speed-running: disabler spawns ahead in about %.0fs", secs(S.sr_doom_t)))
    elseif st == "fired" then
        add("speedrun", "speed-running: disabler sent ahead of the lead player")
    elseif st == "armed" then
        add("speedrun", string.format("speed-running armed: stay behind the line %.1fs", secs(S.sr_gate_t)))
    elseif st == "warm" then
        add("speedrun", string.format("speed-running check %d/%d - keep under %dm per 5s",
            S.sr_worst, S.sr_need, S.sr_req_dist or 10))
    end

    if S.rush_line_ahead and S.rush_dist and now() >= S.rush_cd_until then
        if S.rush_gap_ahead >= S.rush_dist - RUSH_WARN_M then
            add("rush", string.format("lead %dm ahead of the next player (spawn at %dm)",
                math.floor(S.rush_gap_ahead), S.rush_dist))
        elseif S.rush_gap_behind >= S.rush_dist - RUSH_WARN_M then
            add("rush", string.format("last player %dm behind (spawn at %dm)",
                math.floor(S.rush_gap_behind), S.rush_dist))
        end
    end

    if camping() then
        add("camping", string.format("no progress for %ds with nothing aggroed - hordes now come on time, not distance",
            math.floor((mod.state and mod.state.since_forward) or 0)))
    end

    if S.alone_since and S.loner_lo then
        add("loner", string.format("%s alone %ds - loner disabler in %d-%ds",
            S.alone_name or "someone", math.floor(now() - S.alone_since),
            math.floor(secs(S.loner_lo)), math.floor(secs(S.loner_hi))))
    end

    return kinds
end

-- ---------------------------------------------------------------------------
-- World markers
-- ---------------------------------------------------------------------------

local UIWidget = require("scripts/managers/ui/ui_widget")

local ICON = "content/ui/materials/hud/interactions/icons/attention"

local COLORS = {
    speed  = { 255, 200, 60 },
    doom   = { 255, 70, 60 },
    rush   = { 255, 140, 60 },
    behind = { 120, 190, 255 },
    back   = { 200, 120, 255 },
}

local template = {
    name = "HavocTracker_pace_marker",
    size = { 32, 32 },
    max_distance = 200,
    min_distance = 0,
    position_offset = { 0, 0, 1.0 },
    check_line_of_sight = false,
    screen_clamp = false,
}

template.create_widget_defintion = function(self, scenegraph_id)
    local size = self.size
    return UIWidget.create_definition({
        {
            pass_type = "texture",
            style_id = "icon",
            value = ICON,
            value_id = "icon",
            style = {
                horizontal_alignment = "center",
                vertical_alignment = "center",
                size = { size[1], size[2] },
                offset = { 0, 0, 1 },
                color = { 255, 255, 200, 60 },
            },
            visibility_function = function(content)
                return content.shown == true
            end,
        },
        {
            pass_type = "text",
            style_id = "label",
            value = "",
            value_id = "label",
            style = {
                font_size = 20,
                font_type = "machine_medium",
                horizontal_alignment = "center",
                vertical_alignment = "center",
                text_horizontal_alignment = "center",
                text_vertical_alignment = "top",
                size = { 300, 48 },
                offset = { 0, size[2] * 0.6, 2 },
                text_color = { 255, 255, 200, 60 },
                drop_shadow = true,
            },
            visibility_function = function(content)
                return content.shown == true and content.label ~= nil and content.label ~= ""
            end,
        },
    }, scenegraph_id)
end

--[[
    One marker per line, kept alive for the mission and MOVED, never re-added.

    marker.world_position is unboxed by HudElementWorldMarkers every frame
    (hud_element_world_markers.lua:293), so storing a new position into it
    moves the marker. Re-adding on every move would churn ids and flicker,
    and Respawn Rewind 1.4.0 found that a position marker cannot otherwise be
    moved after it is added.

    marker.data is our own table: pos (Vector3Box), label, color, shown,
    version. update_function copies them in when version changes.
--]]
local function apply(widget, marker)
    local data = marker.data
    if not data then return end

    if widget.__ht_v ~= data.version then
        widget.__ht_v = data.version
        local c = data.color or COLORS.speed
        local st = widget.style
        local k = data.scale or 1
        st.icon.size[1], st.icon.size[2] = 32 * k, 32 * k
        st.label.font_size = 20 * k
        st.label.size[1], st.label.size[2] = 300 * k, 48 * k
        st.label.offset[2] = 32 * k * 0.6
        st.icon.color[2], st.icon.color[3], st.icon.color[4] = c[1], c[2], c[3]
        st.label.text_color[2], st.label.text_color[3], st.label.text_color[4] = c[1], c[2], c[3]
        widget.content.label = data.label or ""
        widget.content.shown = data.shown == true
        if data.pos and marker.world_position then
            marker.world_position:store(data.pos:unbox())
        end
        widget.dirty = true
    end

    widget.content.line_of_sight_progress = 1
    widget.alpha_multiplier = 1
end

template.on_enter = function(widget, marker)
    pcall(apply, widget, marker)
end

template.update_function = function(parent, ui_renderer, widget, marker)
    pcall(apply, widget, marker)
    return false
end

Pace.marker_template = template

-- key -> { id = marker id or nil, data = {...}, pending = bool }
local markers = {}

local function setting_on(id)
    return mod:get(id) ~= false
end

local function world_pos(raw)
    if not raw or not MainPathQueries then
        return nil
    end
    if mod.main_path_ready and not mod.main_path_ready() then
        return nil
    end
    local ok, pos = pcall(MainPathQueries.position_from_distance, raw)
    if ok and pos then
        return pos
    end
    return nil
end

local function ensure(key)
    local m = markers[key]
    if m then
        return m
    end
    m = { id = nil, pending = false, data = { pos = Vector3Box(0, 0, 0), version = 0, shown = false } }
    markers[key] = m
    return m
end

local marker_scale = 1.5

local function push(key, raw, label, color)
    local m = ensure(key)
    local d = m.data

    local pos = raw and world_pos(raw)
    local shown = pos ~= nil and label ~= nil

    -- Only bump the version on a visible change: the widget rewrites itself
    -- once per bump.
    local moved = false
    if pos then
        local old = d.pos:unbox()
        moved = Vector3.distance(old, pos) > 0.3
        if moved then d.pos:store(pos) end
    end

    if moved or d.label ~= label or d.color ~= color or d.shown ~= shown
        or d.scale ~= marker_scale then
        d.label, d.color, d.shown, d.scale = label, color, shown, marker_scale
        d.version = d.version + 1
    end

    if shown and not m.id and not m.pending then
        m.pending = true
        local ok = pcall(function()
            Managers.event:trigger("add_world_marker_position", template.name, pos, function(id)
                if markers[key] ~= m then
                    pcall(function() Managers.event:trigger("remove_world_marker", id) end)
                    return
                end
                m.id = id
                m.pending = false
            end, d)
        end)
        if not ok then
            m.pending = false
        end
    end
end

function Pace.forget_markers()
    for k in pairs(markers) do
        markers[k] = nil
    end
end

function Pace.clear_markers()
    for k, m in pairs(markers) do
        if m.id then
            local id = m.id
            pcall(function() Managers.event:trigger("remove_world_marker", id) end)
        end
        markers[k] = nil
    end
end

local function hide_all()
    for k in pairs(markers) do
        push(k, nil, nil, nil)
    end
end

function Pace.update_markers(t)
    if not setting_on("pace_markers") or not mod.state.in_mission then
        hide_all()
        return
    end

    marker_scale = tonumber(mod:get("pace_marker_scale")) or 1.5

    -- SPEED gate
    if setting_on("pace_marker_speed") then
        local st = S.sr_status
        if st == "armed" and S.sr_gate_odo and (S.sr_gate_odo - S.odo) <= SPEED_NEAR then
            local left = math.max(0, S.sr_gate_odo - S.odo)
            push("speed", odo_to_raw(S.sr_gate_odo),
                string.format("HOLD %.1fs\n%dm", secs(S.sr_gate_t), math.floor(left)), COLORS.speed)
        elseif st == "paused" and S.sr_gate_odo and (S.sr_gate_odo - S.odo) <= SPEED_NEAR then
            --[[
                CR is under the check threshold, so the server is not
                checking - but the baseline is kept, and the check is due the
                moment CR is back. Crossing now still counts later.
            --]]
            push("speed", odo_to_raw(S.sr_gate_odo), "HOLD\nuntil the fight", COLORS.speed)
        elseif st == "doomed" and S.lead then
            push("speed", S.lead + 6,
                S.sr_paused and "TOO FAST\nspawns at the next fight"
                    or string.format("TOO FAST\ndisabler ~%.0fs", secs(S.sr_doom_t)), COLORS.doom)
        elseif st == "fired" and S.lead then
            push("speed", S.lead + 6, "DISABLER\nSENT AHEAD", COLORS.doom)
        else
            push("speed", nil, nil, nil)
        end
    else
        push("speed", nil, nil, nil)
    end

    -- RUSH lines
    if setting_on("pace_marker_rush") and S.rush_line_ahead and S.rush_dist then
        local cooling = t < S.rush_cd_until
        local ahead_left = S.rush_line_ahead - S.lead
        if not cooling and ahead_left <= RUSH_WARN_M then
            push("rush_ahead", S.rush_line_ahead,
                ahead_left > 0 and string.format("RUSH LINE\n%dm", math.floor(ahead_left)) or "RUSHING",
                COLORS.rush)
        else
            push("rush_ahead", nil, nil, nil)
        end

        local behind_left = S.tail - S.rush_line_behind
        if not cooling and S.n_valid >= 2 and behind_left <= RUSH_WARN_M then
            push("rush_behind", S.rush_line_behind,
                behind_left > 0 and string.format("FALLING BEHIND\n%dm", math.floor(behind_left)) or "TOO FAR BEHIND",
                COLORS.behind)
        else
            push("rush_behind", nil, nil, nil)
        end
    else
        push("rush_ahead", nil, nil, nil)
        push("rush_behind", nil, nil, nil)
    end

    -- BLOCKADE line, Fading Light only (ranks 16+).
    local c = cfg()
    local fl = c.horde_template == "havoc_01" or c.horde_template == "havoc_02"
    local s = mod.state
    if setting_on("pace_marker_backtrack") and fl and S.lead and s.furthest and s.furthest > 0 then
        local line = s.furthest - BACKTRACK_M
        local left = S.lead - line
        if left <= BACK_WARN_M then
            push("backtrack", line,
                left > 0 and string.format("BLOCKADE LINE\n%dm", math.floor(left)) or "BLOCKADE ODDS UP",
                COLORS.back)
        else
            push("backtrack", nil, nil, nil)
        end
    else
        push("backtrack", nil, nil, nil)
    end
end

-- ---------------------------------------------------------------------------
-- Command
-- ---------------------------------------------------------------------------

mod:command("htpace", "speed-run, rush and loner prevention state", function()
    pcall(Pace.update)
    local c = cfg()
    mod:echo(string.format("[HavocTracker] pace  rank %s  res %d  ch %d",
        tostring(c.rank), resistance(), challenge()))
    mod:echo(string.format("  players: %d on path, %d up   lead %s   CR ~%d   free special slots %s",
        S.n_valid, S.n_up, S.lead and string.format("%.0fm", S.lead) or "?",
        math.floor(S.cr or 0), S.slots_free and tostring(S.slots_free) or "?"))
    if c.sr_dist then
        mod:echo(string.format("  speed: %s  worst %d/%d  armed offsets %d/%d  moved %dm in last 5s (limit %dm, CR %d+)",
            S.sr_status, S.sr_worst, S.sr_need, S.sr_armed, PHASES,
            math.floor(S.sr_window_m), c.sr_dist, c.sr_cr or 0))
    else
        mod:echo("  speed: no speed-running prevention at this rank")
    end
    if S.rush_dist then
        mod:echo(string.format("  rush: lead gap %.0fm, last gap %.0fm, limit %dm%s",
            S.rush_gap_ahead, S.rush_gap_behind, S.rush_dist,
            now() < S.rush_cd_until and string.format(" (cooldown about %.0fs)", secs(S.rush_cd_until)) or ""))
    end
    if c.loner_time then
        mod:echo(S.alone_since
            and string.format("  loner: %s alone %.0fs, disabler in %.0f-%.0fs",
                S.alone_name or "someone", now() - S.alone_since,
                secs(S.loner_lo), secs(S.loner_hi))
            or "  loner: nobody alone (needs 3+ players up)")
    else
        mod:echo("  loner: no loner prevention at this rank")
    end
    mod:echo(string.format("  disablers: %d alive, cap %d with %d up", S.disablers, S.disabler_cap, S.n_up))
end)

mod.Pace = Pace

return Pace
