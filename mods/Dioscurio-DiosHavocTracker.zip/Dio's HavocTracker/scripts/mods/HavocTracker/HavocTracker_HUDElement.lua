local mod = get_mod("HavocTracker")

local UIWidget = require("scripts/managers/ui/ui_widget")
local UIWorkspaceSettings = require("scripts/settings/ui/ui_workspace_settings")

local HudElementHavocTracker = class("HudElementHavocTracker", "HudElementBase")

local Predict = mod.Predict
local CONF = Predict.CONFIDENCE

-- ---------------------------------------------------------------------------
-- Colours
--
-- Confidence drives BOTH the dot and the text colour of its row, so a glance
-- tells you how much to trust each line without reading the dot:
--   GREEN   measured directly
--   YELLOW  derived through a known approximation
--   RED     modelled, and drifting
-- ---------------------------------------------------------------------------

local COLOR = {
    green  = { 255, 142, 208, 156 },
    yellow = { 255, 232, 194,  92 },
    red    = { 255, 232, 124, 100 },

    label  = { 210, 150, 162, 178 },
    dim    = { 150, 108, 118, 134 },
    title  = { 255, 226, 172,  78 },

    panel_bg   = { 110,  10,  12,  16 },   -- element 1 is alpha, set at runtime
    panel_edge = { 130,  70,  80,  95 },
}

local CONF_COLOR = {
    [CONF.exact]    = COLOR.green,
    [CONF.derived]  = COLOR.yellow,
    [CONF.modelled] = COLOR.red,
}

-- ---------------------------------------------------------------------------
-- Layout
--
-- Deliberately tight. Font sizes are unchanged - readability at a given scale
-- is preserved - and the box shrank by removing dead space instead:
--   * padding 10 -> 6
--   * section headers 15px/font13 -> 11px/font10
--   * challenge rating and its band merged onto one line
--   * ramp and budget merged onto one line
--   * forecast trimmed from three rows to two
--   * width 300 -> 244
-- Net effect is roughly 60% of the previous area at the same text size.
-- ---------------------------------------------------------------------------

--[[
    PANEL GEOMETRY, now adjustable.

    THE CLIPPING: five rows were added for the spawn feed, and at ROW_H = 17
    with the current font the lines sit close enough that descenders on one row
    touch the row below. The default row height is raised to 19 and the
    settings below let it go further.

    A RELOAD IS REQUIRED to change these, and that is not laziness - the
    scenegraph and the widget definition are both built once at file load from
    these numbers, so a mid-session change would need the whole widget rebuilt.
    Reading them here means the sliders work on the next mod reload (F5 in the
    mod menu) rather than not at all, which is the honest version of
    "adjustable" for a load-time layout.

    mod:get at file load is safe: DMF has already read the settings blob by the
    time mod scripts run. This is NOT a per-frame read - it happens once.
--]]
local function opt(id, fallback)
    local ok, v = pcall(mod.get, mod, id)
    return (ok and type(v) == "number" and v > 0) and v or fallback
end

--[[
    Default width raised 244 -> 300.

    TEXT_W is W - 24, so at 244 the text area was 220px. At font 16 that is
    roughly 27 characters, and the cascade rows run past 50 - so lines were
    overflowing the panel and colliding with each other. Raising the row
    height alone could never fix that; it was a WIDTH problem being treated as
    a spacing one.
--]]
--[[
    Default width 300 -> 360.

    Shrink-to-fit guarantees nothing wraps, but a row that has to drop two
    font sizes to fit is still a row that is harder to read than its
    neighbours. Widening the default means the common case never shrinks at
    all, and shrinking is left as the safety net it should be.

    At 360 the text area is 336px: 40 characters at the row font, 29 on the
    verdict line. Every string in the localization table fits both.
--]]
local W           = opt("panel_width", 360)
local PAD         = 6
local ROW_H       = opt("panel_row_height", 19)
--[[
    TITLE GEOMETRY, derived like the rows.

    This was a hardcoded 11 against a font of 10 - ONE pixel of leading, so
    section headings touched the line below them. Rows were fixed to derive
    height from font (ROW_H - 4) but titles kept the old fixed pair, which is
    why the overlap survived on exactly the heading rows.

    Same +4 as rows: enough for descenders at this font.
--]]
local TITLE_FONT  = 10
local TITLE_H     = TITLE_FONT + 4
local SECTION_GAP = opt("panel_section_gap", 3)

--[[
    Board rebuild cadence. 10 Hz.

    Replaces the nine-value change guard that used to sit in _draw - see the
    note there for why a clock beats a value list. Matched loosely to the
    mod's own 5 Hz board tick in HavocTracker.lua, run at double that so a
    state change never waits more than one board tick to reach the screen.
--]]
local REBUILD_INTERVAL = 0.1
local BIG_H       = 26

--[[
    Ordered by what happens soonest, not by category.

    NEXT holds the priority queue: whatever is already happening sits at the
    top, then the horde with its most likely strike attached, then anything
    gated behind distance. STATE is the standing picture you glance at rather
    than react to.
--]]
local LAYOUT = {
    { id = "hdr",     kind = "title" },
    { id = "verdict", kind = "big"   },   -- MOVE / HOLD / BRACE - the call

    --[[
        HORDE TIMING GETS ITS OWN LINE.

        It used to be appended to the verdict row. That row draws at font 21,
        which leaves a budget of 23 characters, and

            47.5 / 50  CAPPED   horde 42s ago

        is 33. Anything over the budget WRAPS, and a wrapped line draws into
        the next row's space - which is the overlapping text. Raising the row
        height can never fix it because the problem is line length, not
        leading.

        On its own row at the normal font it has 41 characters to work with
        and reads as what it is: a clock, not part of the cap total.
    --]]
    { id = "hordet",  kind = "row"   },

    { id = "s_next",  kind = "title" },
    { id = "q1",      kind = "row"   },
    { id = "q2",      kind = "row"   },

    --[[
        SPECIALS SET APART FROM THE ELITE BLOCK.

        ELITE and OGRYN are both trash-tier weight and read as one group.
        SPECIAL is the row that decides whether a wave is coming, and it was
        sitting flush against them, so the eye had to parse four identical
        lines to find the one that mattered. A section gap ahead of it splits
        the block into "what is on the floor" and "what is about to be".
    --]]
    { id = "q3",      kind = "row", gap_before = true },
    { id = "s_state", kind = "title" },
    { id = "cr",      kind = "row"   },   -- "~47 TRICKLE OFF"
    { id = "trickle", kind = "row"   },   -- distance to next trickle
    { id = "spread",  kind = "row"   },   -- hidden when solo
    --[[
        Punishment gets its OWN row.

        "break x3" was asked to read more plainly, and the plain-English
        version runs 32 characters - more than is left on the wave row once the
        index, state and pattern length are there. Appending it would push that
        row past the width budget and straight back into the wrapping that
        caused the overlapping lines.
    --]]
    { id = "punish",  kind = "row"   },

    --[[
        PACE: the three specials-pacing punishments as the server runs them
        (HavocTracker_pace.lua) - speed-running checks, the rush gap and the
        loner window. Its own row so it never competes with the cascade text.
    --]]
    { id = "pace",    kind = "row"   },

    { id = "ramp",    kind = "row"   },   -- ramp state + budget

    --[[
        SPAWN FEED, under the cascade. Four lines plus a heading.

        Added to LAYOUT rather than reusing existing ids because the feed needs
        its own lines - both loops below iterate this table, so the y-layout and
        the widget set pick the new rows up with no other change.
    --]]
    --[[
        Second override row. The first was reaching ~54 characters once
        rituals and CAP BLOCKED were added, and a row wider than TEXT_W WRAPS -
        the wrapped line draws into the next row's space, which is the
        "stacking on top of each other" that raising the row height could
        never fix. It was never vertical spacing; it was line length.
    --]]
    { id = "trickle2", kind = "row" },

    { id = "s_feed",  kind = "title" },
    { id = "f1",      kind = "row"   },
    { id = "f2",      kind = "row"   },
    { id = "f3",      kind = "row"   },
    { id = "f4",      kind = "row"   },
}

--[[
    Walks the row ladder and writes each row's y, height and font.

    A NAMED FUNCTION rather than a bare loop, because the panel geometry
    sliders re-run it - see recompute_geometry below. It mutates the rows in
    place; the passes captured these tables when they were built, so handing
    back new ones would leave the passes drawing the old ladder.
--]]
local H

local function layout_rows()
    local y = PAD

    for i = 1, #LAYOUT do
        local r = LAYOUT[i]

        --[[
            gap_before lets any row buy the same breathing space a section
            heading gets, without needing a heading it does not want. Applied
            before the row's own placement so the gap sits above it, and it
            uses the existing SECTION_GAP setting so the spacing slider still
            governs everything.
        --]]
        if r.gap_before then
            y = y + SECTION_GAP
        end

        if r.kind == "title" then
            y = y + SECTION_GAP
            r.y, r.h, r.base_font = y, TITLE_H, TITLE_FONT
            y = y + TITLE_H
        elseif r.kind == "big" then
            r.y, r.h, r.base_font = y, BIG_H, 21
            y = y + BIG_H
        else
            --[[
                FONT DERIVED FROM ROW HEIGHT, not hardcoded.

                It was a fixed 16 regardless of ROW_H, so the row-height
                slider changed the gap between lines and never the text -
                which is why raising it appeared to do nothing. Minus 4 leaves
                room for descenders; floored at 9 so a small slider value
                cannot produce unreadable text.
            --]]
            local f = ROW_H - 4
            if f < 9 then f = 9 end

            r.y, r.h, r.base_font = y, ROW_H, f
            y = y + ROW_H
        end
    end

    H = y + PAD
end

layout_rows()

local CONTAINER_SIZE = { W, H }
local DOT_X = W - PAD - 7
local TEXT_W = W - PAD * 2 - 12

--[[
    Character budget, so no row can wrap.

    proxima_nova_bold averages a little under half the font size per character
    for mixed-case text. Dividing by 0.55 * font is deliberately CONSERVATIVE -
    it under-estimates how much fits, which errs toward truncation rather than
    toward the wrap that caused the overlap.

    Computed from W and the font rather than hardcoded, so widening the panel
    genuinely buys more text instead of just more empty space.
--]]
local function max_chars(font)
    local n = math.floor(TEXT_W / (0.55 * font))
    return n > 8 and n or 8
end

--[[
    Truncate to fit. An ellipsis rather than a hard cut, so a clipped row is
    visibly clipped instead of looking like the data just ended.
--]]
local function fit(text, font)
    if not text or text == "" then
        return text
    end

    local limit = max_chars(font or 15)

    if #text <= limit then
        return text
    end

    return string.sub(text, 1, limit - 1) .. "~"
end

-- ---------------------------------------------------------------------------
-- Scenegraph
-- ---------------------------------------------------------------------------

local scenegraph_definition = {
    screen = UIWorkspaceSettings.screen,
    container = {
        parent = "screen",
        scale = "fit",
        vertical_alignment = "center",
        horizontal_alignment = "center",
        size = CONTAINER_SIZE,
        position = { 0, 0, 100 },
    },
}

-- ---------------------------------------------------------------------------
-- Passes
-- ---------------------------------------------------------------------------

local passes = {}

passes[#passes + 1] = {
    style_id = "panel",
    pass_type = "rect",
    style = {
        color = COLOR.panel_bg,
        size = { W, H },
        offset = { 0, 0, 0 },
        horizontal_alignment = "left",
        vertical_alignment = "top",
    },
}

--[[
    Border as four thin rects.

    There is no "border" pass type in Darktide - the valid set lives in
    scripts/managers/ui/ui_passes.lua. Using an invented one fails inside
    UIRenderer, outside this element's pcall, and takes the game down.
--]]
local function edge(id, x, yy, w, h)
    return {
        style_id = id,
        pass_type = "rect",
        style = {
            color = COLOR.panel_edge,
            size = { w, h },
            offset = { x, yy, 1 },
            horizontal_alignment = "left",
            vertical_alignment = "top",
        },
    }
end

passes[#passes + 1] = edge("edge_t", 0, 0, W, 1)
passes[#passes + 1] = edge("edge_b", 0, H - 1, W, 1)
passes[#passes + 1] = edge("edge_l", 0, 0, 1, H)
passes[#passes + 1] = edge("edge_r", W - 1, 0, 1, H)

-- Base geometry captured pre-scaling, so re-scaling never compounds.
local BASE = {
    panel  = { size = { W, H }, offset = { 0, 0 } },
    edge_t = { size = { W, 1 }, offset = { 0, 0 } },
    edge_b = { size = { W, 1 }, offset = { 0, H - 1 } },
    edge_l = { size = { 1, H }, offset = { 0, 0 } },
    edge_r = { size = { 1, H }, offset = { W - 1, 0 } },
}

--[[
    ============================================================
    LIVE GEOMETRY
    ============================================================

    panel_width, panel_row_height and panel_section_gap were read once, here,
    at file scope - so dragging any of those three sliders did nothing until
    the mod was reloaded, and the only thing that said so was a sentence at
    the end of a tooltip. Three controls that appear broken.

    Everything derived from those three is recomputed below rather than
    rebuilt: the widget definition, the passes and the scenegraph node are
    created once by the HUD system and are not ours to replace mid-session.
    What we CAN do is rewrite the numbers they read from, because
    _apply_layout already walks every row and every entry in BASE and writes
    sizes and offsets into the live style table on each pass. It was doing the
    work all along; it was just being handed constants.

    So this recomputes the row ladder, the derived widths, BASE and FIT_ROWS
    in place, and then invalidates _apply_layout's change guard so it runs
    again. TEXT_W and DOT_X have to be module-level upvalues that the draw
    path reads at call time for this to work, which they already are.

    The LAYOUT tables are mutated rather than replaced for the same reason:
    text_pass and dot_pass captured `row` when the passes were built, so a new
    table would leave the passes pointing at the old rows.
--]]
local rebuild_fit_rows

local function recompute_geometry()
    W           = opt("panel_width", 360)
    ROW_H       = opt("panel_row_height", 19)
    SECTION_GAP = opt("panel_section_gap", 3)

    layout_rows()
    rebuild_fit_rows()

    CONTAINER_SIZE[1], CONTAINER_SIZE[2] = W, H
    DOT_X  = W - PAD - 7
    TEXT_W = W - PAD * 2 - 12

    BASE.panel.size[1],  BASE.panel.size[2]  = W, H
    BASE.edge_t.size[1], BASE.edge_t.size[2] = W, 1
    BASE.edge_b.size[1], BASE.edge_b.size[2] = W, 1
    BASE.edge_b.offset[2] = H - 1
    BASE.edge_l.size[1],  BASE.edge_l.size[2]  = 1, H
    BASE.edge_r.size[1],  BASE.edge_r.size[2]  = 1, H
    BASE.edge_r.offset[1] = W - 1
end

local function text_pass(row)
    local is_title = row.kind == "title"
    return {
        value_id  = row.id,
        style_id  = row.id,
        pass_type = "text",
        value     = "",
        style = {
            font_size = row.base_font,
            font_type = "proxima_nova_bold",
            drop_shadow = not is_title,
            text_color = is_title and COLOR.title or COLOR.label,
            text_horizontal_alignment = "left",
            text_vertical_alignment = "top",
            horizontal_alignment = "left",
            vertical_alignment = "top",
            size = { TEXT_W, row.h },
            offset = { PAD, row.y, 10 },
        },
    }
end

--[[
    Row dot.

    THE VISIBILITY FUNCTION IS NOT OPTIONAL. Without it every non-title row
    draws its dot whether or not the row has text, so blanked rows render as a
    column of dots against nothing - which is exactly the "5 lines with dots
    but empty" that the spawn feed rows produced.

    It reads the ROW's text, not the dot's own value, because the dot has no
    value of its own - it is decoration for a line that may or may not exist.
--]]
local function dot_pass(row)
    return {
        value_id  = row.id .. "_dot",
        style_id  = row.id .. "_dot",
        pass_type = "rect",
        visibility_function = function (content)
            local text = content[row.id]
            return text ~= nil and text ~= ""
        end,
        style = {
            color = COLOR.dim,
            size = { 5, 5 },
            offset = { DOT_X, row.y + 5, 11 },
            horizontal_alignment = "left",
            vertical_alignment = "top",
        },
    }
end

for i = 1, #LAYOUT do
    local row = LAYOUT[i]
    passes[#passes + 1] = text_pass(row)
    if row.kind ~= "title" then
        passes[#passes + 1] = dot_pass(row)
    end
end

local widget_definitions = {
    tracker = UIWidget.create_definition(passes, "container", nil, CONTAINER_SIZE),
}

-- ---------------------------------------------------------------------------
-- Element
-- ---------------------------------------------------------------------------

HudElementHavocTracker.init = function(self, parent, draw_layer, start_scale)
    HudElementHavocTracker.super.init(self, parent, draw_layer, start_scale, {
        scenegraph_definition = scenegraph_definition,
        widget_definitions = widget_definitions,
    })
    self._hidden = false

    --[[
        The live instance, published so the settings menu can reach it.

        The HUD system owns construction and hands out no reference, and
        mod.rebuild_geometry has to invalidate THIS object's layout cache -
        recomputing the numbers is useless if _apply_layout's change guard
        then decides nothing moved.

        A plain field, not a list: the element is created once per HUD and
        replaced wholesale when the HUD is rebuilt, so the newest instance is
        always the right one.
    --]]
    mod.__ht_element = self
end

--[[
    Re-read the three geometry settings and push the result into the live
    widget. Called from on_setting_changed.

    Nulling the four cached inputs is what makes _apply_layout actually run -
    it early-outs unless position, scale or opacity changed, and panel width
    is none of those three.
--]]
mod.rebuild_geometry = function()
    recompute_geometry()

    local self = mod.__ht_element

    if not self then
        return
    end

    self._lx, self._ly, self._ls, self._lo = nil, nil, nil, nil
    self._row_fonts = {}
end

--[[
    Writes the per-row font chosen by shrink_to_fit into the widget style.

    Separate from _apply_layout because that runs before the row text exists
    and early-outs when position and scale have not changed - it is a geometry
    cache, and font-to-fit is a content decision. Merging them would either
    break the cache or leave the font a frame stale.

    Falls back to base_font for any row fit_all did not touch, so a row that
    was never measured still renders at its designed size.
--]]
HudElementHavocTracker._apply_row_fonts = function(self)
    local fonts = self._row_fonts
    if not fonts then return end

    local widget = self._widgets_by_name and self._widgets_by_name.tracker
    if not widget then return end

    local style = widget.style
    local scale = self._ls or mod:get("hud_scale") or 1

    for i = 1, #LAYOUT do
        local row = LAYOUT[i]
        local st = style[row.id]

        if st and row.kind ~= "title" then
            st.font_size = (fonts[row.id] or row.base_font) * scale
        end
    end
end

--[[
    POSITION: SLIDERS, UNLESS CUSTOM HUD HAS THE PANEL.

    (The history below is why the sliders are re-checked every frame. Since
    2.13.0 the panel yields to custom_hud instead of fighting it: see
    mod.custom_hud_owns in HavocTracker.lua. Drag it in custom_hud and that
    position sticks; reset it there and the sliders take over again.)

    POSITION IS RE-ASSERTED EVERY FRAME. THE REST IS STILL CACHED.

    This used to early-return whenever the four slider values were unchanged,
    which is correct for the style rebuild below - it walks every row and every
    entry in BASE and is not something to do per frame - but it was also
    gating set_scenegraph_position, and that was a bug.

    The guard compares the SLIDERS to what the sliders were last time. It
    cannot see the scenegraph. So when another mod moves the panel, the
    sliders still match their own cached copies, the guard says "nothing has
    changed", and the position is never written back. The panel stays wherever
    it was put, permanently.

    That is what custom_hud does. HavocTracker adds its elements through
        mod:hook_require("scripts/ui/hud/hud_elements_player", add_hud_element)
    rather than DMF's register_hud_element, so by the time the HUD is built
    HudElementHavocTracker is indistinguishable from a base game element -
    custom_hud lists it, lets you drag it, saves an override, and re-applies
    that override on every open. Ours never fought back, so custom_hud won
    every time and the sliders looked broken. They were not broken; they were
    being overwritten by something that got the last word.

    Splitting the two fixes it. set_scenegraph_position is a couple of number
    writes, so running it per frame costs nothing measurable, and it makes
    this mod's own sliders the authority on where its own panel sits.

    THIS DOES MEAN DRAGGING THE PANEL IN custom_hud NO LONGER STICKS. That is
    the intended outcome - there are two position controls for one panel and
    only one of them can win. The sliders are the one that ships with the
    thing being positioned.
--]]
HudElementHavocTracker._apply_layout = function(self)
    local x = mod:get("hud_offset_x") or 0
    local yy = mod:get("hud_offset_y") or 0
    local scale = mod:get("hud_scale") or 1
    local opacity = mod:get("panel_opacity") or 45

    local owned = mod.custom_hud_owns and mod.custom_hud_owns(self, "container")

    if not owned then
        --[[
            Compare first: set_scenegraph_position flags a full scenegraph
            rebuild, which every frame is wasted work. Alignment is written
            back too, because custom_hud pins with left/top and a reset there
            would otherwise leave the panel anchored to the wrong corner.
        --]]
        local sg = self._ui_scenegraph
        local node = sg and rawget(sg, "container")
        local p = node and node.position
        if not p or p[1] ~= x or p[2] ~= yy
            or node.horizontal_alignment ~= "center" or node.vertical_alignment ~= "center" then
            self:set_scenegraph_position("container", x, yy, nil, "center", "center")
        end
    end

    if self._lx == x and self._ly == yy and self._ls == scale and self._lo == opacity then
        return
    end
    self._lx, self._ly, self._ls, self._lo = x, yy, scale, opacity

    local widget = self._widgets_by_name and self._widgets_by_name.tracker
    if not widget then return end
    local style = widget.style

    for i = 1, #LAYOUT do
        local row = LAYOUT[i]
        local st = style[row.id]
        if st then
            st.font_size = row.base_font * scale
            st.offset[1] = PAD * scale
            st.offset[2] = row.y * scale
            if st.size then
                st.size[1] = TEXT_W * scale
                st.size[2] = row.h * scale
            end
        end

        local dot = style[row.id .. "_dot"]
        if dot then
            dot.size[1], dot.size[2] = 5 * scale, 5 * scale
            dot.offset[1] = DOT_X * scale
            dot.offset[2] = (row.y + 5) * scale
        end
    end

    for id, base in pairs(BASE) do
        local st = style[id]
        if st then
            st.size[1]   = base.size[1] * scale
            st.size[2]   = base.size[2] * scale
            st.offset[1] = base.offset[1] * scale
            st.offset[2] = base.offset[2] * scale
        end
    end

    -- Element 1 of a colour table is alpha. 0 = fully transparent panel,
    -- leaving just the text and border.
    local panel = style.panel
    if panel and panel.color then
        panel.color[1] = math.floor(opacity * 2.55)
    end
    --[[
        The border sits slightly above the plate so the panel still has an
        outline once the fill has been faded out. That +40 used to be
        unconditional, which meant opacity 0 left a visible rectangle drawn
        around nothing and no setting in the mod could remove it. At zero the
        lift goes too: zero means gone.
    --]]
    local edge_alpha = opacity <= 0 and 0
        or math.floor(math.min(opacity * 2.55 + 40, 255))
    for _, id in ipairs({ "edge_t", "edge_b", "edge_l", "edge_r" }) do
        local st = style[id]
        if st and st.color then st.color[1] = edge_alpha end
    end

    self:_set_scenegraph_size("container", W * scale, H * scale)
end

--- Set a row's text, its dot colour, and its text colour to match.
local function put(content, style, id, text, confidence)
    content[id] = text or ""

    local colour = confidence and CONF_COLOR[confidence] or COLOR.dim
    local st = style[id]
    if st then
        st.text_color = colour
    end
    local dot = style[id .. "_dot"]
    if dot then
        dot.color = colour
    end
end

local function blank(content)
    for i = 1, #LAYOUT do
        content[LAYOUT[i].id] = ""
    end
end

HudElementHavocTracker.update = function(self, dt, t, ui_renderer, render_settings, input_service)
    HudElementHavocTracker.super.update(self, dt, t, ui_renderer, render_settings, input_service)

    if self._errors and self._errors >= 5 then
        return
    end

    --[[
        THROTTLED, NOT CHANGE-DETECTED. See the long note in _draw.

        dt is forwarded so the rebuild can be paced. It was not before, which
        is why the old version had to use change detection instead.
    --]]
    self._rebuild_acc = (self._rebuild_acc or 0) + (dt or 0)

    if self._rebuild_acc < REBUILD_INTERVAL then
        return
    end
    self._rebuild_acc = 0

    if not self._row_fonts then
        self._row_fonts = {}
    end

    local ok, err = pcall(self._draw, self)

    --[[
        Fonts are pushed into the style AFTER _draw, not inside _apply_layout.

        _apply_layout runs before the row text exists, so it cannot know how
        much a row needs to shrink. fit_all fills self._row_fonts while it
        measures; this writes those into the widget the renderer reads.
    --]]
    if ok then
        pcall(self._apply_row_fonts, self)
    end
    if not ok then
        self._errors = (self._errors or 0) + 1
        mod:error("hud update failed (%d/5): %s", self._errors, tostring(err))
    end
end

--[[
    The entity cap block.

    Five lines: the weighted total against the budget, then the four weighted
    components. Monsters and captains are shown as a suffix rather than a row,
    because the model gives them no weight - inventing one would be a guess
    presented as a number, and they still matter to read (note 6: a major boss
    in H40 always arrives with horde bodyguards, so a boss with no horde means
    you are already at cap).

    Rows are written by LAYOUT id, so no new widgets are created and the
    existing style table applies unchanged.
--]]
--[[
    THE ENTITY CAP PANEL, plus the specialist cascade and the token counter.

    Row budget is the existing LAYOUT ids, so no widgets are created:

        hdr      title    "ENTITY CAP"
        verdict  big      weighted total / budget
        q1..q3   rows     elite / ogryn / special
        cr       row      horde
        trickle  row      unweighted boss+captain, only when present
        s_next   title    "SPECIALIST CASCADE"
        spread   row      wave index and time to next
        ramp     row      weakened monstrosity ramp / surge state

    PREDICTED VS MEASURED.

    The cap counts are measured - a live census of breed tags. The wave timer
    and surge are MODELLED from play.

    The tilde prefix that used to mark the modelled rows is gone at request -
    it read as noise rather than as a qualifier. The distinction now lives in
    the wording instead: measured rows are bare counts, modelled rows name
    their unit ("next 12s", "weak boss 47%") and the cascade sits under its own
    heading. Worth keeping in mind when reading the panel, because the two
    halves have very different reliability.
--]]
--[[
    The weakened-boss line, shared by every branch.

    It was written out twice - once in the live-pacing branch, once at the
    bottom - and blanked in a third, so which text you got depended on which
    branch happened to run. One function, called from all three.
--]]
--[[
    THE WAVE HEADING CARRIES THE STAGE.

    It said "SPECIALIST WAVE" and nothing else - a label, on a row, above a
    countdown, telling you only that specialist waves exist. Reported as "the
    special wave indicator doesn't show anything for what stage it's in",
    which is exactly right: the stage was tracked, read into casc.wave, and
    never drawn.

    Two things go on it now.

    STAGE - where in the pattern the director is. WAVE_PATTERN is a fixed list
    of gaps, so "3/10" says both how far in you are and how much is left
    before it runs out and queues. "queued" is its own state rather than an
    eleventh number, because the pattern being exhausted is qualitatively
    different from being partway through it.

    LANDING - how many specials have arrived inside the detection window,
    against the number that marks a wave. This is the "landing progress" half:
    2/5 means a wave is assembling right now and three more inside five
    seconds confirms it. It only appears while something is actually landing,
    so the heading stays short the rest of the time.
--]]
local function wave_header(casc)
    if not casc then
        return "SPECIALIST WAVE"
    end

    local head

    if casc.queued then
        head = "SPECIALIST WAVE  queued"
    elseif casc.wave and casc.waves_total and casc.waves_total > 0 then
        head = string.format("SPECIALIST WAVE  %d/%d", casc.wave, casc.waves_total)
    else
        head = "SPECIALIST WAVE"
    end

    --[[
        Only while a burst is actually assembling. A permanent "0/5" would be
        one more number that never changes, which is the thing this panel has
        too many of already.
    --]]
    local landed = casc.recent or 0
    local need = casc.detect_at or 5

    if landed > 0 and landed < need then
        head = head .. string.format("  landing %d/%d", landed, need)
    end

    return head
end

local function ramp_text(casc)
    if not casc then
        return ""
    end

    --[[
        LIVE GATE FIRST, MODEL SECOND - the same rule the wave row follows.

        Cascade.weak_gate reads the game's own monster-override state and says
        which gate is shut, or gives the real percentage when none of them is.
        It returns nil on a client, where _specials_pacing does not exist, and
        the modelled ramp below takes over.

        This is the answer to "a percentage with no way to know whether it can
        happen at all". A cooldown, a boss already up or full monster slots
        each make the number moot, and each of those now says so in words
        rather than leaving a 47 on screen that cannot pay out.
    --]]
    if mod.Cascade.weak_gate then
        local ok, gate = pcall(mod.Cascade.weak_gate)

        if ok and gate then
            return gate
        end
    end

    if casc.weak_boss then
        --[[
            THE HIT COUNT WAS BEING TRUNCATED OFF THE END OF THE ROW.

            Reported as "the hit number is always 0", but it was never printed
            at all - the row read "weak boss 5%  0 roll  hi~", where the tilde
            is this file's own truncation marker (see fit()). The count was
            there, past the character budget, and the only part of it that
            survived was the "hi".

            There was a second bug hiding inside the first. The old format was

                "weak boss %.0f%%  %d roll%s"

            where %s was the hit clause. The trailing %s is exactly where a
            pluralising "s" belongs and reads as one, so "9 roll" with no s
            looked like a typo rather than a clue that the argument after the
            roll count was something else entirely. Both are gone: the plural
            is explicit and the hit clause is its own term.

            Rewritten short enough to fit the narrowest sensible panel. At
            panel_width 300 the budget is ~32 characters; this is 24 at three
            digits of rolls, so it has room to grow before it clips again.
        --]]
        local rolls = casc.rolls or 0
        local hits = casc.weak_spawns or 0
        local plural = rolls == 1 and "" or "s"

        --[[
            "5%  0 rolls" IS THE CORRECT READING RIGHT AFTER A WEAKENED SPAWN -
            the ramp restarts and the roll count restarts with it, because both
            describe the CURRENT climb. It is also exactly what a broken
            counter looks like, which is why it got reported as one.

            So when the per-ramp count is zero and the mission has in fact seen
            rolls, the total is shown instead. The row then says "0 of 40"
            rather than a bare 0, and a genuinely dead counter still reads
            "0 rolls" with no total beside it.
        --]]
        local total = casc.rolls_total or 0

        if rolls == 0 and total > 0 then
            if hits > 0 then
                return string.format("weak %.0f%%  0 of %d  %d Already Spawned",
                    casc.weak_boss * 100, total, hits)
            end

            return string.format("weak %.0f%%  0 of %d Chances",
                casc.weak_boss * 100, total)
        end

        if hits > 0 then
            return string.format("weak %.0f%%  %d Chance%s  %d Already Spawned",
                casc.weak_boss * 100, rolls, plural, hits)
        end

        return string.format("weak %.0f%%  %d Chance%s",
            casc.weak_boss * 100, rolls, plural)
    end

    --[[
        Self-explanatory rather than a bare state.

        "weak boss - no wave yet" was asked what it meant, which is a fair
        question: it described a condition without saying what the condition
        governs. The percentage is a ramp that only starts once a wave has been
        detected, so say that.
    --]]
    return "weak boss: ramp starts at wave 1"
end

--[[
    Every row goes through this before it is drawn.

    DERIVED FROM LAYOUT, not hand-listed. The list used to be written out by
    hand, which drifted twice over: a new row had to be remembered here as well
    as in LAYOUT, and every row was measured at the ROW font regardless of what
    it actually draws at.

    That second part was a real fault. `verdict` draws at font 21, where the
    budget is 23 characters, but it was being fitted as though it were font 15,
    which allows 41. So the one row most likely to overflow was the one row
    whose overflow check was wrong by nearly a factor of two, and it wrapped
    into the line below without fit() ever objecting.

    Building the table from LAYOUT with each row's own base_font means a row
    added later is covered automatically and measured against the font it is
    really drawn in. Titles are excluded: they are short constants set in code,
    not formatted from live values.
--]]
local FIT_ROWS = {}

--[[
    Forward-declared above recompute_geometry, which calls it when the row
    height slider moves - each entry caches its row's base font, so the table
    goes stale the moment the ladder is rebuilt.

    Rebuilt in place. fit_all holds this table across calls.
--]]
function rebuild_fit_rows()
    for i = #FIT_ROWS, 1, -1 do
        FIT_ROWS[i] = nil
    end

    for i = 1, #LAYOUT do
        local r = LAYOUT[i]

        if r.kind ~= "title" then
            FIT_ROWS[#FIT_ROWS + 1] = { id = r.id, font = r.base_font }
        end
    end
end

rebuild_fit_rows()

--[[
    SHRINK TO FIT, RATHER THAN TRUNCATE.

    fit() cut the string and marked the cut with a tilde, which is how "0 roll
    hi~" happened. That was always a damage-limitation measure: it stopped the
    wrap, at the cost of eating the end of the line - and the end of the line
    is usually the number.

    Every row now gets the largest font at or below its own base size at which
    the whole string fits on one line. Nothing wraps, nothing is cut, and a
    long line just renders a point or two smaller than its neighbours.

    Floored at MIN_FONT so a pathological string cannot shrink to unreadable.
    Below that floor it falls back to truncation, which by then is the honest
    outcome.

    Returns the font each row wants; the caller writes it into the style,
    because the style is where the renderer reads it from.
--]]
--[[
    12, not 9.

    Nine was chosen to guarantee a fit rather than to stay readable, and it
    did the first thing at the cost of the second - a row that hit the floor
    was two-thirds the height of the ones around it and unreadable at small
    window sizes, which is where this mod is most often used.

    Raising the floor means some rows now truncate where they used to shrink.
    That is the better trade: a legible line ending in "~" tells you there is
    more, where an illegible full line tells you nothing at all. Widening the
    panel is the real fix for those rows, and max_chars is derived from the
    panel width, so the width setting genuinely buys them back.
--]]
local MIN_FONT = 12

local function shrink_to_fit(text, base_font)
    if not text or text == "" then
        return text, base_font
    end

    local font = base_font

    while font > MIN_FONT and #text > max_chars(font) do
        font = font - 1
    end

    if #text > max_chars(font) then
        return fit(text, font), font
    end

    return text, font
end

--[[
    THE SPAWN FEED IS ONE LINE NOW, NOT FIVE.

    It used to be a heading plus four rows listing what had spawned and how
    many seconds ago. Five of the panel's rows spent on history - and history
    is the one thing on this panel you cannot act on. By the time a line reads
    "trapper 12s", the trapper is either dead or on you; the number never
    changes what you do next.

    What IS worth a line is the moment something lands, for the few seconds
    either side of it. So the feed collapses to a single notification that
    names what just arrived and clears itself:

        ELITE PACK        an elite group
        HORDE             a horde event
        SPECIALIST WAVE   five or more specials inside five seconds

    AND THE OLD FEED WAS NEVER POPULATED ANYWAY. Cascade.log_spawn, which
    built the list those five rows rendered, was called from nowhere - its
    only reference in the mod was its own definition. The rows drew a heading
    and four blanks. So this is not a trade of detail for brevity; it is
    replacing something that displayed nothing with something that displays
    an event.

    The source is Cascade.notification(), fed from the spawn edges that do
    fire: Cap.add on the frame a unit appears, the horn cue for hordes, and
    the burst detector for waves. It ages itself out against its own stamp,
    so there is no timer here and nothing to clear.
--]]
local function draw_feed(content)
    --[[
        Four of the five old feed rows stay blank permanently.

        They are left in LAYOUT rather than removed because the row ladder is
        what text_pass and dot_pass captured when the widget definition was
        built, and rebuilding those at runtime is a larger change than this
        one. Blank rows cost nothing to draw - dot_pass carries a
        visibility_function keyed to its row's text, so an empty row draws
        neither text nor dot.
    --]]
    content.f1, content.f2, content.f3, content.f4 = "", "", "", ""

    if mod.show_notifications and not mod.show_notifications() then
        content.s_feed = ""
        return
    end

    content.s_feed = (mod.Cascade.notification
        and mod.Cascade.notification()) or ""
end

--[[
    THE WEIGHTS COME FROM Cap.CATS, NOT FROM HERE.

    cap.points - the total on the verdict line - is summed in Cap.read() using
    CATS[i].w. If these rows carried their own copy of those numbers, changing
    a weight in one place would leave the rows and the total describing
    different models, and the rows would be the lying half because the total
    is the one the bands are compared against.

    So the weight is looked up rather than passed. It costs one table scan per
    row on a 10 Hz rebuild, which is four scans of a nine-entry list - far
    cheaper than the class of bug it removes.
--]]
local function cat_weight(id, fallback)
    local Cap = mod.Cap
    local cats = Cap and Cap.CATS

    if not cats then
        return fallback
    end

    for i = 1, #cats do
        if cats[i].id == id and cats[i].w then
            return cats[i].w
        end
    end

    return fallback
end

--[[
    One cap row: label, token cost, and optionally the headcount behind it.

    MODULE SCOPE, TAKING counts AS AN ARGUMENT. Written inside _draw_cap
    first, which allocates a fresh closure on every rebuild - ten times a
    second, four times per rebuild. Same per-call-closure mistake already
    fixed in the tracers, the rangefinder and the pcall wrappers: a function
    literal is an allocation, so anything on a repeating path gets hoisted and
    handed its state.
--]]
local function cap_row(label, n, weight, counts)
    if counts then
        return string.format("%-8s%5.1f  (%d)", label, n * weight, n)
    end

    return string.format("%-8s%5.1f", label, n * weight)
end

--[[
    THE SAME FOUR NUMBERS ON ONE LINE.

    The five-row block gives each category its own row, aligned, which is the
    right shape when you are reading it between fights. It is four rows of
    screen for four numbers when you are not.

    This is the compact form:

        E 14.0  O 14.0  S 1.0  H 18.6

    Initials rather than words because the order is fixed and never changes,
    so after the first read the letters are position markers rather than
    labels. Two spaces between pairs - one is not enough separation at the
    font sizes this panel shrinks to.

    Headcounts follow the same setting as the rows do, in parentheses, and are
    what pushes this line long enough to be worth the shrink-to-fit pass:

        E 14.0 (14)  O 14.0 (7)  S 1.0 (1)  H 18.6 (93)

    Deliberately NOT included: the verdict. It stays on its own line above,
    because "47.6 / 55 High" is the one thing read at a glance mid-fight and
    folding it in here would bury it in the middle of a string.
--]]
local function cap_compact(cap, trash, counts)
    local parts = {
        { "E", cap.elite,   cat_weight("elite",   1.0) },
        { "O", cap.ogryn,   cat_weight("ogryn",   2.0) },
        { "S", cap.special, cat_weight("special", 1.0) },
        { "H", trash,       cat_weight("horde",   0.2) },
    }

    local out, n = {}, 0

    for i = 1, #parts do
        local label, count, weight = parts[i][1], parts[i][2], parts[i][3]
        n = n + 1

        if counts then
            out[n] = string.format("%s %.1f (%d)", label, count * weight, count)
        else
            out[n] = string.format("%s %.1f", label, count * weight)
        end
    end

    return table.concat(out, "  ")
end

local function fit_all(content, row_fonts)
    for i = 1, #FIT_ROWS do
        local r = FIT_ROWS[i]
        local text, font = shrink_to_fit(content[r.id], r.font)
        content[r.id] = text

        if row_fonts then
            row_fonts[r.id] = font
        end
    end
end

HudElementHavocTracker._draw_cap = function(self, content, style)
    self._hidden = false

    local cap = mod.Cap and mod.Cap.read()

    if not cap then
        content.hdr = "ENTITY CAP"
        content.verdict = "unavailable"
        content.s_next, content.q1, content.q2, content.q3 = "", "", "", ""
        content.s_state, content.cr, content.trickle = "", "", ""
        content.trickle2 = ""
        -- Cleared with the rest: a stale horde clock under an "unavailable"
        -- total reads as though one number is still live when none are.
        content.hordet = ""
        content.spread, content.ramp = "", ""
        content.s_feed = ""
        content.f1, content.f2, content.f3, content.f4 = "", "", "", ""
        fit_all(content, self._row_fonts)
        return
    end

    content.hdr = "ENTITY CAP"

    --[[
        %.1f, not %d. Horde at 0.1x means the total moves in tenths, and
        rounding to an integer would make ten poxwalkers look like no change.
    --]]
    --[[
        PRESSURE BANDS, DERIVED FROM THE BUDGET RATHER THAN HARDCODED.

        They used to be fixed numbers - 10, 20, 40, 50, 65 - chosen when the
        budget was 50, with a note saying that "capped" at 50 was the budget
        itself so the label and the denominator agreed. That was true, and it
        stopped being true the moment the budget became configurable: at a
        budget of 55, a fixed threshold of 50 reads "Capped" while the
        denominator says 50/55, which is the label contradicting the number
        sitting next to it.

        So the thresholds are ratios of the budget now, keeping exactly the
        proportions the fixed set had:

            0.2   Light
            0.4   Standard
            0.8   High
            1.0   Capped     <- the budget itself, by construction
            1.3   Overcap

        At the shipped budget of 55 that is 11 / 22 / 44 / 55 / 71.5, and
        "Capped" lands on the cap at any budget anyone sets.

        Tested high-to-low, so a value matches exactly one band and adding a
        band later cannot silently shadow another.
    --]]
    --[[
        Fallback must track BUDGET in HavocTracker_cap.lua. It is only reached
        if the cap read returns a zero budget, but a stale number here would
        silently band every row against the old ceiling.
    --]]
    local budget = cap.budget > 0 and cap.budget or 70
    local band

    if cap.points >= budget * 1.3 then
        band = "Overcap"
    elseif cap.points >= budget then
        band = "Capped"
    elseif cap.points >= budget * 0.8 then
        band = "High"
    elseif cap.points >= budget * 0.4 then
        band = "Standard"
    elseif cap.points >= budget * 0.2 then
        band = "Light"
    else
        band = "N/A"
    end

    content.verdict = string.format("%.1f / %d  %s", cap.points, cap.budget, band)

    --[[
        TOKENS, NOT HEADCOUNT.

        Every row used to print the count AND the weight - "ELITE  12   12.0",
        "HORDE  93 x0.3  27.9" - which is three numbers to explain one. The
        count is not the thing that decides anything: forty-seven poxwalkers
        cost the cap less than five elites do, so a row that leads with 47 is
        leading with the number that matters least.

        These are the TOKEN cost now, and the token cost only. Headcount is
        still available behind show_headcount for anyone who wants it, in
        brackets after the token so the token stays the number your eye lands
        on.

        The multipliers go too. They were printed to explain how the count
        became the weight, and with the count gone there is nothing to
        explain - the weight is simply the number.
    --]]
    local counts = mod.show_headcount and mod.show_headcount()

    content.q1 = cap_row("ELITE", cap.elite, cat_weight("elite", 1.0), counts)
    content.q2 = cap_row("OGRYN", cap.ogryn, cat_weight("ogryn", 2.0), counts)
    --[[
        Specials row carries this week's cap bonus when there is one.

        more_alive_specials adds 2-6 to the specials cap depending on level,
        and it is readable as a client where the base cap is not. "+4" is the
        difference between a wave feeling wrong and knowing the ceiling moved.
    --]]
    local sbonus = mod.Cascade and mod.Cascade.specials_bonus
        and mod.Cascade.specials_bonus()

    content.q3 = cap_row("SPECIAL", cap.special, cat_weight("special", 1.0), counts)
        .. (sbonus and string.format("  cap +%d", sbonus) or "")

    --[[
        LABELLED "HORDE".

        It was renamed to TRASH once to avoid a collision: HORDE meant the
        poxwalker count in this row and the horde EVENT everywhere else in the
        panel, two meanings on one screen. Renamed back on request, so the
        collision is live again and worth naming rather than quietly
        reintroducing.

        What keeps it readable is position, not wording. This row sits inside
        the entity cap block, in a column of category counts next to ELITE,
        OGRYN and SPECIAL, and it carries a token cost. The horde EVENT is
        never a category count and never carries one - it appears on the
        verdict line and in the notification row. Same word, but never in the
        same shape or the same place.

        The local stays named trash. It is what these are, and the variable
        is not what anyone reads.
    --]]
    local trash = cap.horde + cap.roamer
    content.cr = cap_row("HORDE", trash, cat_weight("horde", 0.2), counts)

    --[[
        COMPACT MODE collapses the four rows just written into one.

        Written AFTER them rather than instead of them, so both paths compute
        from the same cap values and the same cat_weight lookups - there is no
        second place for the numbers to drift. The four row ids are then
        blanked, which is what actually reclaims the space.

        cr carries the single line because it is already the last of the four
        and already in FIT_ROWS, so the compact string gets the shrink-to-fit
        pass for free. Putting it in q1 would have left the longest string in
        the block as the one row that never shrinks.
    --]]
    if mod:get("cap_compact") == true then
        content.cr = cap_compact(cap, trash, counts)
        content.q1, content.q2, content.q3 = "", "", ""
    end

    --[[
        OVERRIDE ROW.

        These spawn OUTSIDE the budget rather than inside it, so they are
        counted and shown but never added to the total - adding them would
        inflate the one number whose job is to say how much room is left.

        Broken down rather than shown as a bare total, because which kind it is
        changes what you do: a daemonhost is an avoid, a captain is a fight, a
        ritualist is a timer. Only non-zero kinds are listed, so the row stays
        short in the common case.

        Note 6 still applies: a major boss in H40 always arrives with horde
        bodyguards, so a boss here with no horde in the row above is itself the
        cap signal.
    --]]
    if cap.unweighted > 0 then
        local parts, n = {}, 0

        if cap.monster > 0 then
            n = n + 1
            parts[n] = string.format("%d boss", cap.monster)
        end
        if cap.captain > 0 then
            n = n + 1
            parts[n] = string.format("%d capt", cap.captain)
        end
        if cap.armored > 0 then
            n = n + 1
            parts[n] = string.format("%d armhound", cap.armored)
        end

        content.trickle = string.format("Enemies Excluded %d  (%s)",
            cap.unweighted, table.concat(parts, " "))
    else
        content.trickle = ""
    end

    -- Rituals, exclusions and the cap confirmation get their own row now.
    content.trickle2 = ""

    --[[
        EXCLUDED, shown separately and never added to either total.

        Ritualists and the mutator daemonhost spawn regardless of play, so they
        are not tokens spent - but a ritualist on the map is still a timer you
        need to see. Appended to the override row rather than given one of its
        own, and prefixed "excl" so it cannot be misread as part of the +N.
    --]]
    local extra = {}

    if (cap.excluded or 0) > 0 then
        extra[#extra + 1] = string.format("excl %d", cap.excluded)
    end

    --[[
        RITUALS, and the forced-horde cap confirmation.

        Ritual count per map comes from the game's own mutator settings
        (mutator_havoc_chaos_rituals.num_to_spawn_per_mission) - five on most
        maps, three on cm_habs, four on core_research.

        CAP BLOCKED is the valuable half. Every ritual and monstrosity spawn
        sets force_horde_on_spawn, which calls force_horde_pacing_spawn(). The
        horde is REQUESTED, not guaranteed - if the entity cap is full it
        cannot be filled. So a forced-horde event with no horde following is a
        HARD cap confirmation, independent of the weighted estimate, and it
        works on a client where read_allocated() returns nil.
    --]]
    local casc_r = mod.Cascade and mod.Cascade.read()

    if casc_r then
        local bits = {}

        --[[
            Mission key via Spawns.mission(), which is the accessor that
            already holds the bound mission. mod.state has no mission field - I
            assumed one twice now, and both times it resolved to nil and the
            feature silently did nothing.
        --]]
        local mission = mod.Spawns and mod.Spawns.mission and mod.Spawns.mission()

        local total = mission and mod.Cascade.ritual_total
            and mod.Cascade.ritual_total(mission)

        if total then
            bits[#bits + 1] = string.format("rit %d/%d", casc_r.rituals or 0, total)
        elseif (casc_r.rituals or 0) > 0 then
            bits[#bits + 1] = string.format("rit %d", casc_r.rituals)
        end

        if casc_r.cap_blocked then
            --[[
                "CAP BLOCKED" said which mechanism fired and not what it means.
                A boss arrived and the horde that normally escorts it could not
                spawn because the cap was full - which is good news, and read
                as a warning.
            --]]
            bits[#bits + 1] = "Horde Disabled - cap full"
        end

        for i = 1, #bits do
            extra[#extra + 1] = bits[i]
        end
    end

    content.trickle2 = #extra > 0 and table.concat(extra, "  ") or ""

    content.s_state = ""

    -- ---- specialist cascade ----

    local casc = mod.Cascade and mod.show_cascade and mod.show_cascade()
        and mod.Cascade.read() or nil

    if not casc then
        content.s_next, content.spread, content.ramp = "", "", ""
        fit_all(content, self._row_fonts)
        return
    end

    content.s_next = wave_header(casc)

    --[[
        THE SPAWN FEED - RENDERED BEFORE ANY BRANCH RETURNS.

        MOVED UP. Both the live-pacing branch and the not-armed branch return
        early, and neither set these rows - so the feed never rendered and its
        five lines sat empty with only their dots showing. The feed does not
        depend on which branch runs, so it belongs before the branching rather
        than duplicated into each one.

        Newest first. Age in seconds rather than a clock time, because "4s ago"
        is what matters mid-fight.
    --]]
    draw_feed(content)

    --[[
        LIVE PACING FIRST, MODEL SECOND.

        The game exposes a real countdown per queued special
        (_specials_slots[i].spawn_timer) and the real cap
        (max_num_specials()). When those are readable they replace the
        modelled wave row outright - a measured "next 37s, 4/8 queued" beats a
        predicted wave index in every respect.

        Server-side only, so on a client this returns nil and the model below
        takes over. That is why the model is still here rather than deleted.
    --]]
    if mod.Cascade.live_specials then
        local cap_n, alive_n, soonest = mod.Cascade.live_specials()

        if cap_n then
            --[[
                "cap full" is now reachable and means it. Every slot holding a
                live special leaves nothing counting down, so there is no next
                time to show - and that is the state worth seeing, because it
                is the one where killing a special is what lets the next one
                come.
            --]]
            local nxt = soonest and string.format("next %.0fs", soonest) or "cap full"

            --[[
                SPEED RUNNING WARNING, appended to the wave row.

                This is a pre-warning, not a report: the check runs every 5s
                and needs two consecutive passes, so "1/2" means one more fast
                window and the punishment lands. There is time to slow down.

                "ALONE" is the CR suppression cancel
                (_ahead_unit_has_no_units_in_coherency, set inside the same
                check). While it is true, running under suppression is no
                longer free - which is the single most expensive thing to not
                know.
            --]]
            local prev = mod.Cascade.live_prevention and mod.Cascade.live_prevention()

            if prev then
                if prev.checks and prev.checks > 0 then
                    nxt = nxt .. string.format("  SPD %d/%d", prev.checks, prev.required)
                end

                if prev.alone_ahead then
                    nxt = nxt .. "  ALONE"
                end
            end

            -- alive specials against the ceiling, not slots against slots.
            content.spread = string.format("%s  %d/%d live", nxt, alive_n, cap_n)

            content.punish = casc.accel > 1.0
                and string.format("coherency break: timer %.0fx faster", casc.accel) or ""

            --[[
                The weakened ramp row still comes from the model - the game
                does not expose that chance - so it is left to the block below
                by returning only after it has run.
            --]]
            content.ramp = ramp_text(casc)

            fit_all(content, self._row_fonts)
            return
        end
    end

    if not casc.armed then
        --[[
            No wave detected yet. Correct at mission start rather than a fault:
            detection is five specials inside five seconds, so before the first
            such burst there is genuinely nothing to report.

            THE RAMP ROW IS NO LONGER BLANKED HERE. It used to be set to "" and
            returned, which is why nothing appeared below "watching 1/5" - the
            weakened line, which HAS something to say before the first wave,
            was being wiped by the branch that had nothing to say about waves.

            A branch that has no wave information should say so about WAVES and
            leave the other rows alone.
        --]]
        content.spread = string.format("watching  %d/%d in 5s",
            casc.recent or 0, casc.detect_at or 5)

        content.punish = ""
        content.ramp = ramp_text(casc)
        fit_all(content, self._row_fonts)
        return
    end

    --[[
        COHERENCY, SHOWN AS STATE RATHER THAN ONLY AS AN EVENT.

        The break marker never appeared because it only renders while the
        acceleration is active, and the break itself only fires on the EDGE of
        somebody reaching zero teammates in coherency. That is a rare, brief
        condition - so in a normal run there was nothing to see either before
        or after it.

        The live coherency count is far more useful and is available on a
        CLIENT, which matters because everything read from Managers.state.pacing
        is not. min_coherency is already maintained by the census every board
        tick.

        Shown only when it is actually low, so a team playing together gets a
        clean row rather than a permanent "coh 4".
    --]]
    --[[
        The wave row keeps only the short coherency STATE. The punishment
        itself is a sentence and lives on its own row below.
    --]]
    local accel = ""
    local mc = mod.state and mod.state.min_coherency

    if mc and mc <= 2 then
        accel = mc <= 1 and "  ALONE" or string.format("  coh %d", mc)
    end

    --[[
        The multiplier is read from the value in force rather than written as a
        literal, so the wording cannot drift if BREAK_ACCEL is retuned.

        "3x faster" rather than "+300%" deliberately: 3.0 is a multiplier, and
        +300% would describe 4.0. Saying the wrong one plainly is worse than
        saying the right one tersely.
    --]]
    content.punish = casc.accel > 1.0
        and string.format("coherency break: timer %.0fx faster", casc.accel) or ""

    if casc.queued then
        --[[
            Pattern exhausted. Says so plainly instead of reporting an
            eleventh wave the model has no basis for - the old clamp produced
            "wave 14/10" with a fresh timer, which was wrong in both halves.
        --]]
        content.spread = string.format("%d/%d  QUEUED%s",
            casc.wave, casc.waves_total, accel)
    else
        local next_len = mod.Cascade.pattern_at(casc.wave + 1)

        if next_len then
            --[[
                THE (Ns) SUFFIX IS GONE, and it was wrong rather than noisy.

                It printed pattern_at(wave + 1) - the NEXT wave's interval -
                straight after the CURRENT wave's number. So wave 2, which is a
                30 second wave, rendered as "2/10 ... (15s)", because 15 is
                wave 3's interval. Two different waves' facts inside one
                bracket.

                Pairing it with "IN PROGRESS" made it worse. If a wave is
                landing there is no countdown, so the number could only read as
                a duration - and it was not this wave's duration.

                What that interval was actually for is signalling whether the
                pattern has reached its rapid tail. That is now said in a word,
                attached to the thing it describes: the wave being counted down
                TO.
            --]]
            local when

            if casc.in_progress then
                when = "landing now"
            else
                when = string.format("next in %.0fs", casc.timer)

                if next_len <= 5 then
                    when = when .. " Peak Specialist Waves"
                end
            end

            content.spread = string.format("%d/%d  %s%s",
                casc.wave, casc.waves_total, when, accel)
        else
            content.spread = string.format("%d/%d  QUEUED%s",
                casc.wave, casc.waves_total, accel)
        end
    end

    --[[
        TIME SINCE LAST HORDE, on its own row.

        It was appended to the verdict line, which draws at font 21 and
        therefore has a 23-character budget. "47.5 / 50  CAPPED" is already 17
        of those, so adding "   horde 42s ago" pushed it to 33 and the row
        wrapped into the line below it.

        Blank until a horde has actually been seen, because "0s" would imply
        one just landed.
    --]]
    if casc.since_horde then
        content.hordet = string.format("last horde %.0fs ago", casc.since_horde)
    else
        -- Cleared explicitly. Rows persist between rebuilds, so leaving this
        -- unset would freeze the last clock on screen after a mission restart
        -- rather than emptying it.
        content.hordet = ""
    end



    --[[
        TOKEN COUNTER - why the cap is where it is.

        Shows the punishment tokens accrued this room, because those are the
        actions that drive the cascade: a down is a coherency break AND a down
        break, a death is a coherency break AND a death break - double-stacking
        punishment. That is the mechanism this whole mod started from.

        Replaced by the surge line while a surge is live, because during a
        surge the weakened-boss chance is the more actionable number and the
        row budget is fixed.
    --]]
    --[[
        WEAKENED MONSTROSITY RAMP.

        Replaces the token counter, which is removed - the wave row already
        carries the punishment signal via its acceleration marker, and this is
        the more actionable number.

        Shows the percentage, how far through the 90s climb it is, and the ROLL
        COUNT. The roll count is not decoration: the chance is rolled per
        specialist spawn, so "60%" with one roll behind it and "60%" with
        twelve are completely different situations, and the percentage alone
        cannot distinguish them. At 60% a five-special wave expects three
        weakened monstrosities, not 0.6.

        weak_spawns is shown once any have arrived, because the ramp having
        reset is otherwise invisible - the percentage just quietly drops back
        to 5% and looks like nothing happened.
    --]]
    --[[
        WEAKENED BOSS CHANCE.

        Shown whenever a ramp is running, which is now from the first wave
        rather than only during a surge - the percentage was invisible for most
        of a mission otherwise.

        The roll count is load-bearing: the chance is rolled PER specialist
        spawn, so 45% across two rolls and 45% across twelve are completely
        different situations and the percentage alone cannot tell them apart.
        At 45% a five-special wave expects two weakened monstrosities.

        "spawned N" appears once any have arrived, because the ramp resetting
        is otherwise invisible - the number just drops back to 5% and looks
        like nothing happened.
    --]]
    content.ramp = ramp_text(casc)

    if casc.surge then
        content.ramp = content.ramp .. string.format("  SURGE %.0fs", casc.surge_left)
    end
    fit_all(content, self._row_fonts)
end

--[[
    Panel opacity.

    Applied to the backing plate only, not the text - greying the text as well
    is what made earlier readouts unreadable at 360p. Reference panels should
    recede behind the fight; the numbers on them still have to be legible.
--]]
HudElementHavocTracker._apply_cap_opacity = function(self, style)
    local alpha = mod.cap_opacity and mod.cap_opacity() or 150

    if style and style.panel and style.panel.color then
        style.panel.color[1] = alpha
    end
end

HudElementHavocTracker._draw = function(self)
    self:_apply_layout()

    local widget = self._widgets_by_name.tracker
    if not widget then return end

    local content, style = widget.content, widget.style
    local s = mod.state

    --[[
        HIDING MEANS widget.visible, NOT blank().

        blank() only empties the text rows. The backing plate and the four
        edge rects are their own passes with no text to clear, so they kept
        drawing and the overlay turned into an empty box hanging on screen
        with nothing in it. The row dots got away with it because dot_pass
        carries a visibility_function keyed to its row's text; the panel and
        the edges have no such thing.

        widget.visible is the flag the renderer itself checks, so one
        assignment covers every pass the widget owns - which is how the spawn
        panel has always done it.

        The text is still blanked underneath. A widget that comes back visible
        should not flash one frame of whatever it was showing when it went
        away, and _apply_layout is invalidated for the same reason: it
        early-outs when none of its four inputs changed, and hiding is not one
        of those four.
    --]]
    if mod.overlay_visible == false or not s.in_mission then
        if not self._hidden then
            self._hidden = true
            widget.visible = false
            blank(content)
            self._lx, self._ly, self._ls, self._lo = nil, nil, nil, nil
        end
        return
    end

    if self._hidden then
        self._hidden = false
        widget.visible = true
    end

    -- Written before either draw path below, so their fit_all covers it.
    do
        local P = mod.Pace
        local ok, line = false, nil
        if P and P.panel_line then
            ok, line = pcall(P.panel_line)
        end
        put(content, style, "pace", (ok and type(line) == "string") and line or "", CONF.derived)
    end

    --[[
        CAP-ONLY MODE.

        Writes the entity cap block into the row ids the layout already owns
        and blanks the rest, then returns before the verdict engine renders.

        NOTHING IS DELETED to do this. mod.verdict(), mod.next_events(),
        mod.trickle_state(), mod.band(), mod.ramp_band() and the challenge
        rating census all still run - they are simply not drawn. Flipping
        hud_mode back to "full" restores the whole readout with no code change,
        which is the reversibility that was asked for.

        Read once into a local: cfg_hud_mode is refreshed on setting change,
        never per rebuild. mod:get on a repeating path is what took the game
        from 59 to 15 fps via the colour-picker clone.
    --]]
    if mod.cap_only_mode() then
        self:_apply_cap_opacity(style)
        self:_draw_cap(content, style)
        return
    end
    self._hidden = false

    --[[
        THE NINE-VALUE CHANGE GUARD IS GONE. It was silently freezing rows.

        It used to early-out unless one of NINE tracked values had changed:
        cr, since_horde, ticket_m, spread, backtrack, ramp_step,
        warnings_version, board_version, ramp_key_ready.

        But this function draws considerably more than those nine things, and
        every row fed by anything else went stale the moment the nine settled:

            verdict      mod.verdict() - reads alloc_capped and min_coherency,
                         neither of which was tracked. The entity-cap and
                         suppression verdicts could simply never appear.
            queue q1-q3  mod.next_events()
            trickle row  mod.trickle_state(), plus the allocated count
            ramp row     s.budget_line

        This is the THIRD time this mod has had this bug. The comment above
        update_budget_line in HavocTracker.lua records the last one - the spawn
        budget line sat at its mission-start value for entire runs because the
        dirty flag that was meant to raise it had been deleted - and reached
        the same conclusion this does:

            "Recomputed every board tick (5Hz), NOT gated on budget_dirty...
             far cheaper than the bookkeeping needed to keep a dirty flag
             honest."

        So: no guard. Rebuild on a timer instead. A dirty flag or a value list
        has to be updated by hand every time a row is added, and three
        successive authors - all of them me - have failed to do that. A clock
        cannot be forgotten.

        COST: roughly fifteen rows of string.format at 10 Hz, about 150 formats
        a second against the ~60 this mod was already doing per second from the
        board tick. Negligible, and bounded regardless of what rows get added
        later. 100 ms of latency on a readout you act on over seconds is not
        perceptible.
    --]]
    -- Kept because the rows below render them. The other six values the old
    -- guard tracked existed ONLY for the comparison and are gone with it.
    local cr        = math.floor((s.challenge_rating or 0) + 0.5)
    local spread    = math.floor(s.spread or 0)
    local backtrack = math.floor(s.backtrack or 0)

    local L = mod.L
    local cfg = mod.cfg

    --[[
        Header, via the Identity module.

        This used to fall back to "UNKNOWN ch5/res6" whenever my own rank
        detection had not resolved - which was most of the time, because it ran
        once before the difficulty manager existed and never retried.

        Identity.label reads the same accessors TzeentchRichPresence uses to put
        the difficulty in Discord, so if that mod can name your mission this one
        can too. It also answers on loading screens via Managers.mechanism.
    --]]
    local label
    if mod.Identity and mod.Identity.label then
        local ok, text = pcall(mod.Identity.label)
        if ok and text and text ~= "unknown" then
            label = text
        end
    end

    if label then
        --[[
            Circumstances appended when present - "Havoc 40 + Hunting Grounds"
            is materially more useful than the rank alone, and it is the same
            data the Discord presence shows.
        --]]
        local suffix = ""
        local okh, havoc = pcall(mod.Identity.havoc)
        if okh and havoc and havoc.circumstances and #havoc.circumstances > 0 then
            suffix = string.format(" +%d", #havoc.circumstances)
        end
        content.hdr = label .. suffix
    elseif mod.rank_known and cfg then
        content.hdr = string.format("HAVOC %d  ch%d/res%d", cfg.rank, cfg.challenge, cfg.resistance)
    elseif cfg then
        content.hdr = string.format("%s  ch%d/res%d",
            mod.rank_band or "UNKNOWN", cfg.challenge, cfg.resistance)
    else
        content.hdr = "HAVOC TRACKER"
    end

    -- --- NEXT: priority queue, soonest first -------------------------------
    -- --- the call ----------------------------------------------------------
    local _, vtext, vconf = mod.verdict()
    put(content, style, "verdict", vtext, vconf)

    -- --- NEXT: priority queue, soonest first -------------------------------
    content.s_next = L("sec_next")
    local queue = mod.next_events()
    for i = 1, 3 do
        local id = "q" .. i
        local e = queue[i]
        if e then
            put(content, style, id, e.text, e.conf)
        elseif i == 1 then
            put(content, style, id, L("q_clear"), CONF.exact)
        else
            put(content, style, id, "", nil)
        end
    end

    -- --- STATE: the standing picture ---------------------------------------
    content.s_state = L("sec_state")

    local _, band_label = mod.band(s.challenge_rating or 0)
    put(content, style, "cr", string.format("~%d %s", cr, band_label), CONF.derived)

    --[[
        ALLOCATED COUNT shares the trickle row rather than taking a new one.

        It belongs here semantically - this row is "what is currently
        suppressed" - and appending avoids adding a LAYOUT entry, which would
        need matching widget definitions and a re-measured panel height. The
        cap already leads the verdict line when it is active, which is the
        prominent placement it deserves; this row is the supporting number.

        Confidence drops to derived when the count is unreadable, which is the
        normal case on a client - MinionSpawnManager is server-side. Showing
        "alloc ?" is honest; showing 0 would not be.
    --]]
    local _, tlabel = mod.trickle_state()
    local trickle_text = tlabel or ""
    local alloc_conf = CONF.derived

    if s.allocated then
        local cap = mod.HARD_ALLOCATED_LIMIT or 145
        trickle_text = string.format("%s  alloc %d/%d%s",
            trickle_text, s.allocated, cap,
            s.alloc_capped and " CAPPED" or "")
        if s.alloc_capped then
            alloc_conf = CONF.exact
        end
    end

    put(content, style, "trickle", trickle_text, alloc_conf)

    --[[
        Spread is meaningless alone: with one player there is no second player
        to measure a gap against, and the rush-prevention rule it describes
        cannot fire. Bots DO count - the game measures side.valid_player_units,
        which includes them - so this only collapses in genuine solo.
    --]]
    --[[
        Gate on players_positioned, not alive_players.

        players_positioned is the count euclidean_spread actually measured from,
        so the two can never disagree. alive_players is derived separately, and
        when it lagged or read low the row silently fell through to the solo
        variant - showing no spread even with a full team on screen.
    --]]
    if (s.players_positioned or 0) > 1 then
        put(content, style, "spread",
            string.format("%s %dm  %s %dm", L("row_spread"), spread, L("row_back"), backtrack),
            CONF.exact)
    else
        -- Genuinely solo: there is no second player to measure a gap against,
        -- so a "SPREAD 0m" reading was not a bug but it looked like one. Say so.
        put(content, style, "spread",
            string.format("%s  %s %dm", L("row_solo"), L("row_back"), backtrack), CONF.exact)
    end

    local _, rl = mod.ramp_band()
    local ramp_text = rl
    if s.budget_line then
        ramp_text = ramp_text .. " " .. s.budget_line
    end
    put(content, style, "ramp", ramp_text, CONF.modelled)
end

return HudElementHavocTracker
