local mod = get_mod("HavocTracker")

--[[
    Chat font scaling.
    =================

    Nothing to do with Havoc pacing - it is here because reading mod output at
    360p is otherwise impossible, and the diagnostics this mod prints are the
    main thing worth reading.

    WHY THIS HOOK:

    ConstantElementChat._update_message_widgets_sizes runs every frame from
    update() (constant_element_chat.lua:153) and recomputes each message
    widget's height from its font style. Setting the font size immediately
    BEFORE it runs means the layout is recalculated with the new size, so the
    message boxes grow to fit rather than clipping.

    WHY WE CACHE OUR OWN BASE:

    _text_size (line 1367-1374) does:

        if not font_style.default_font_size then
            font_style.default_font_size = font_style.font_size
        end
        local scaled_font_size = Text.scaled_size(font_style.default_font_size, scale)

    So default_font_size is the UNSCALED reference the engine sizes from, and it
    latches on first use. If we simply multiplied font_size each frame we would
    compound it into infinity; if we wrote default_font_size without keeping the
    original we could never scale back down. So the untouched original is stored
    once per style, and every scale is computed from that.
--]]

local Chat = {}

--[[
    1.0, so a fresh install leaves the chat box exactly the size the game drew
    it. 1.6 was a value that suited one 360p screen and it resized every new
    player's chat for them without being asked. Anyone who already has a scale
    saved keeps it - DMF only falls back to the default for a setting that was
    never written.
--]]
local DEFAULT_SCALE = 1

local function wanted_scale()
    if mod:get("chat_scale_enabled") == false then
        return 1
    end
    return tonumber(mod:get("chat_scale")) or DEFAULT_SCALE
end

--[[
    Apply the scale to one text style, remembering its original size.

    __ht_base is our own field. Writing it onto the engine's style table is
    slightly rude but survives exactly as long as the widget does, which is what
    we want - a rebuilt widget gets a fresh base from a fresh style.
--]]
local function scale_style(style, scale)
    if not style then
        return
    end

    if not style.__ht_base then
        style.__ht_base = style.default_font_size or style.font_size
    end

    local base = style.__ht_base
    if type(base) ~= "number" then
        return
    end

    local want = base * scale
    if style.font_size ~= want then
        style.font_size = want
        style.default_font_size = want
    end
end

local function scale_widget(widget, scale)
    if not widget or not widget.style then
        return
    end
    local s = widget.style
    -- Message body, and the channel prefix that sits in front of it.
    scale_style(s.message, scale)
    scale_style(s.channel, scale)
    scale_style(s.timestamp, scale)
end

--[[
    Returns true if anything changed, so callers can force a resize.
--]]
function Chat.apply(element)
    if not element then
        return
    end

    local scale = wanted_scale()

    local widgets = element._message_widgets
    if widgets then
        for i = 1, #widgets do
            scale_widget(widgets[i], scale)
        end
    end

    --[[
        The input line too, or you can read the history but not what you are
        typing - which is exactly the case where you are trying to run a
        diagnostic command.
    --]]
    local input = element._widgets_by_name
    if input then
        local field = input.chat_input_field or input.input_field
        if field and field.style then
            scale_style(field.style.display_text, scale)
            scale_style(field.style.to_channel, scale)
            scale_style(field.style.active_placeholder, scale)
            scale_style(field.style.placeholder, scale)
        end
    end
end

--[[
    Hooked BEFORE the original so the recomputed heights use the new size.

    hook (not hook_safe) because we need to run first and then delegate;
    everything inside is guarded so a failure cannot break the chat window.
--]]
mod:hook(CLASS.ConstantElementChat, "_update_message_widgets_sizes",
    function(func, self, ui_renderer)
        pcall(Chat.apply, self)
        return func(self, ui_renderer)
    end)

--[[
    Newly arriving messages get their widget built after the sizing pass, so
    scale them on arrival as well - otherwise a new line renders at default size
    until the next resize happens to touch it.
--]]
mod:hook_safe(CLASS.ConstantElementChat, "cb_chat_manager_message_recieved",
    function(self)
        pcall(Chat.apply, self)
    end)

mod:hook_safe(CLASS.ConstantElementChat, "cb_system_message_recieved",
    function(self)
        pcall(Chat.apply, self)
    end)

mod.Chat = Chat
return Chat
