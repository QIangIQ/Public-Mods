local mod = get_mod("HavocTracker")

--[[
    LEVEL DEBUG COMMANDS
    ====================

    Ported from QIangIQ's level_debug mod (level_debug.lua). Four commands, and
    reading that file was the single most valuable thing to happen to this
    project.

    ------------------------------------------------------------------------
    THE HEADLINE: THE SPAWN CACHE IS RECONSTRUCTING SOMETHING THE GAME HANDS
    OVER DIRECTLY.
    ------------------------------------------------------------------------

        Managers.state.pacing._monster_pacing._spawn_type_point_sections

    is a live table of, per spawn type, per section, per spawn point:

        spawn_data.position                -- Vector3Box, :unbox()
        spawn_data.spawn_travel_distance   -- the trigger distance

    That is the exact, authoritative trigger set for the current mission -
    captains, monstrosities, daemonhosts - with BOTH halves this project has
    spent weeks approximating: the trigger distance AND the spawn position.
    cache/spawn_cache.lua is 6,166 lines of harvested samples reconstructing
    it, and harvested_cache.lua openly says it only ever sees "1-3 monsters out
    of 10-29 candidates".

    Twins come from their own mutator:

        Managers.state.mutator._mutators.mutator_monster_havoc_twins
            ._spawn_point_sections      -- all candidate points
            ._monsters[1]               -- the ACTIVE one, this seed

    And the conversion nobody had:

        MainPathQueries.position_from_distance(d)   -- distance -> world position

    THE CATCH, and it is why the harvesting exists: Managers.state.pacing is a
    SERVER-side manager. On a client it is nil, so none of this is readable
    when not hosting. That is exactly the constraint that produced the cache -
    but it also means when you ARE hosting, harvesting should read this table
    directly instead of waiting for spawns to fire and sampling them.

    ------------------------------------------------------------------------
    DRAWING

    QuickDrawerStay is the engine's persistent debug drawer - :sphere, :line -
    and it draws in the world with no HUD element and no retained-mode
    problems. It requires debug drawing to be enabled, which is what the
    companion mod's /enable does.
--]]

local Debug = {}

local function drawer()
    return rawget(_G, "QuickDrawerStay")
end

local function mpq()
    local ok, m = pcall(require, "scripts/utilities/main_path_queries")
    return (ok and type(m) == "table") and m or nil
end

local function colors()
    return rawget(_G, "Color")
end

--[[
    Every one of these is READ-ONLY and hosting-dependent. They report what is
    missing rather than erroring, because "Managers.state.pacing is nil" is the
    answer when you are a client, not a fault.
--]]
local function require_host(what)
    local pacing = Managers.state and Managers.state.pacing

    if not pacing then
        mod:echo(string.format(
            "[HavocTracker] %s needs the server-side pacing manager - you are a client this run.", what))
        return nil
    end

    return pacing
end

-- ---------------------------------------------------------------------------

mod:command("main_path", "Draw the main path progression line", function()
    local D, C, M = drawer(), colors(), mpq()
    local mp = Managers.state and Managers.state.main_path

    if not D or not C then
        mod:echo("[HavocTracker] debug drawer unavailable (is debug drawing enabled?)")
        return
    end

    if not mp or not mp._main_path_segments then
        mod:echo("[HavocTracker] no main path segments available")
        return
    end

    local segments = mp._main_path_segments
    local h = Vector3(0, 0, 1)
    local nodes = 0

    for i = 1, #segments do
        local path = segments[i].nodes

        for j = 1, #path do
            -- Nodes are plain {x,y,z} arrays, not Vector3s.
            local position = Vector3(path[j][1], path[j][2], path[j][3])
            D:sphere(position + h, 0.25, C.light_green())
            nodes = nodes + 1

            --[[
                Bridge the gap between segments. Without this the line breaks
                at every segment boundary and the path looks discontinuous
                where it is not.
            --]]
            if j == #path and i ~= #segments then
                local nx = segments[i + 1].nodes[1]
                local next_position = Vector3(nx[1], nx[2], nx[3])
                D:line(position + h, next_position + h, C.light_green())
            end
        end
    end

    mod:echo(string.format("[HavocTracker] main path: %d segments, %d nodes",
        #segments, nodes))
end)

-- ---------------------------------------------------------------------------

mod:command("monsters", "Draw captain / monstrosity / daemonhost / twin triggers", function()
    local D, C, M = drawer(), colors(), mpq()

    if not D or not C or not M or not M.position_from_distance then
        mod:echo("[HavocTracker] debug drawer or MainPathQueries unavailable")
        return
    end

    local pacing = require_host("/monsters")
    if not pacing then
        return
    end

    local monster_pacing = pacing._monster_pacing
    local sections = monster_pacing and monster_pacing._spawn_type_point_sections

    if not sections then
        mod:echo("[HavocTracker] no monster spawn sections for this mission")
        return
    end

    local h = Vector3(0, 0, 1)
    local total = 0

    --[[
        TWINS FIRST, and separately, because they are a mutator rather than
        part of monster pacing - and because _monsters[1] is the one that
        actually spawned this seed, which is the single most useful fact on the
        map. Drawn green; the candidates are yellow.
    --]]
    local mutators = Managers.state.mutator and Managers.state.mutator._mutators
    local twins = mutators and mutators.mutator_monster_havoc_twins

    if twins then
        local active = twins._monsters and twins._monsters[1]

        if active and active.travel_distance then
            local trigger = M.position_from_distance(active.travel_distance)
            local pos = active.position and active.position:unbox()

            if trigger and pos then
                D:sphere(trigger + h, 0.25, C.green())
                D:sphere(pos, 5, C.green())
                D:line(trigger + h, pos, C.green())
                mod:echo(string.format("[HavocTracker] ACTIVE twins at %.1fm",
                    active.travel_distance))
            end
        end

        for _, section_data in pairs(twins._spawn_point_sections or {}) do
            for _, sd in pairs(section_data) do
                local pos = sd.position and sd.position:unbox()
                local trigger = sd.spawn_travel_distance
                    and M.position_from_distance(sd.spawn_travel_distance)

                if pos and trigger then
                    D:sphere(trigger + h, 0.25, C.yellow())
                    D:sphere(pos, 5, C.yellow())
                    D:line(trigger + h, pos, C.yellow())
                    total = total + 1
                end
            end
        end
    end

    for spawn_type, spawn_type_data in pairs(sections) do
        local n = 0

        for _, section_data in pairs(spawn_type_data) do
            for _, sd in pairs(section_data) do
                local pos = sd.position and sd.position:unbox()
                local trigger = sd.spawn_travel_distance
                    and M.position_from_distance(sd.spawn_travel_distance)

                if pos and trigger then
                    -- Small sphere on the TRIGGER point, big sphere on where
                    -- the thing appears, line between: the pairing is the
                    -- information, not either sphere alone.
                    D:sphere(trigger + h, 0.25, C.red())
                    D:sphere(pos, 5, C.red())
                    D:line(trigger + h, pos, C.red())
                    n = n + 1
                    total = total + 1
                end
            end
        end

        mod:echo(string.format("[HavocTracker]   %s: %d candidate(s)", tostring(spawn_type), n))
    end

    mod:echo(string.format("[HavocTracker] %d monster trigger candidates drawn", total))
end)

-- ---------------------------------------------------------------------------

--[[
    BEACON_AHEAD_DISTANCE = 25.

    Taken from the source mod. Max allowed progression for a beacon is its own
    main-path distance MINUS this, which is the number that actually matters:
    push past it and the beacon stops being the respawn point.
--]]
local BEACON_AHEAD_DISTANCE = 25

mod:command("respawn_beacons", "Draw respawn beacons, spawn points and max progress", function()
    local D, C, M = drawer(), colors(), mpq()

    if not D or not C or not M or not M.position_from_distance then
        mod:echo("[HavocTracker] debug drawer or MainPathQueries unavailable")
        return
    end

    local ext = Managers.state and Managers.state.extension
    local rbs = ext and ext:system("respawn_beacon_system")

    if not rbs or not rbs._unit_to_extension_map then
        mod:echo("[HavocTracker] respawn beacon system unavailable")
        return
    end

    local ALIVE = rawget(_G, "ALIVE")
    local h = Vector3(0, 0, 2)
    local n = 0

    for beacon_unit, extension in pairs(rbs._unit_to_extension_map) do
        if not ALIVE or ALIVE[beacon_unit] then
            local beacon_position = Unit.world_position(beacon_unit, 1)
            local beacon_distance = rbs._beacon_main_path_distance_lookup
                and rbs._beacon_main_path_distance_lookup[beacon_unit]

            D:sphere(beacon_position, 0.5, C.cyan())

            -- The actual respawn points this beacon would use.
            local spots = extension.best_respawn_positions and extension:best_respawn_positions()

            if spots then
                for i = 1, #spots do
                    local sp = spots[i].position and spots[i].position:unbox()
                    if sp then
                        D:sphere(sp, 0.25, C.blue())
                        D:line(beacon_position, sp, C.blue())
                    end
                end
            end

            if beacon_distance then
                local max_prog = beacon_distance - BEACON_AHEAD_DISTANCE
                local on_path = M.position_from_distance(beacon_distance)
                local max_pos = M.position_from_distance(max_prog)

                if on_path then
                    D:sphere(on_path + h, 0.3, C.magenta())
                    D:line(beacon_position, on_path + h, C.magenta())
                end

                if max_pos then
                    -- Green is the limit: the furthest you may progress and
                    -- still respawn here.
                    D:sphere(max_pos + h, 0.4, C.green())
                    if on_path then
                        D:line(on_path + h, max_pos + h, C.yellow())
                    end
                end

                mod:echo(string.format("[HavocTracker]   beacon at %.1fm, max progress %.1fm",
                    beacon_distance, max_prog))
            else
                mod:echo("[HavocTracker]   beacon with no main path distance")
            end

            n = n + 1
        end
    end

    mod:echo(string.format("[HavocTracker] %d beacon(s) drawn", n))
end)

-- ---------------------------------------------------------------------------

mod:command("beacon_debug", "Current progress, active beacon and the beacon list", function()
    local M = mpq()
    local ext = Managers.state and Managers.state.extension
    local rbs = ext and ext:system("respawn_beacon_system")

    if not rbs then
        mod:echo("[HavocTracker] respawn beacon system unavailable")
        return
    end

    local ALIVE = rawget(_G, "ALIVE")
    local best = nil

    --[[
        _find_nearest_beacon needs the player side id, which comes from the
        side system's DEFAULT player side rather than being assumed to be 1.
    --]]
    local side_system = ext and ext:system("side_system")

    if side_system then
        local ok, side = pcall(function()
            local name = side_system:get_default_player_side_name()
            return side_system:get_side_from_name(name)
        end)

        if ok and side and rbs._find_nearest_beacon then
            local ok2, b = pcall(rbs._find_nearest_beacon, rbs, side.side_id)
            best = ok2 and b or nil
        end
    end

    mod:echo("[HavocTracker] === beacon debug ===")

    local parts, active = {}, nil

    for i, data in ipairs(rbs._beacon_main_path_data or {}) do
        if not ALIVE or ALIVE[data.unit] then
            local max_prog = (data.distance or 0) - BEACON_AHEAD_DISTANCE

            if data.unit == best then
                active = i
                parts[#parts + 1] = string.format("#%d: %.1f [ACTIVE]", i, max_prog)
            else
                parts[#parts + 1] = string.format("#%d: %.1f", i, max_prog)
            end
        end
    end

    mod:echo("[HavocTracker] beacon max progress: " .. table.concat(parts, " | "))

    if active then
        mod:echo(string.format("[HavocTracker] active beacon: #%d", active))
    end

    -- Current progress, via the closest-position query rather than a manager
    -- call that throws on clients.
    local pm = Managers.player
    local unit = nil

    if pm and pm.local_player_safe then
        local ok, p = pcall(pm.local_player_safe, pm, 1)
        unit = ok and p and p.player_unit or nil
    end

    if unit and M and M.closest_position then
        local pos = mod.unit_position and mod.unit_position(unit)
            or Unit.world_position(unit, 1)

        if pos then
            local ok, _, travelled = pcall(M.closest_position, pos)
            if ok and type(travelled) == "number" then
                mod:echo(string.format("[HavocTracker] current progress: %.2fm", travelled))
            end
        end
    end
end)

--[[
    RANGEFINDER.

    Distance from you to whatever you are looking at, and how far along the
    main path that point is.

    Two numbers because they answer different questions: metres tells you
    whether something is in weapon range, main-path distance tells you where it
    sits relative to a trigger. A boss trigger at 640m means nothing until you
    know you are at 612m.

    The raycast uses the level's own physics world and the same collision
    filter the game uses for line-of-sight checks, so it stops on the geometry
    you would actually shoot.
--]]
local RANGE_MAX = 500

function Debug.rangefinder()
    local pm = Managers.player
    local unit = nil

    if pm and pm.local_player_safe then
        local ok, p = pcall(pm.local_player_safe, pm, 1)
        unit = ok and p and p.player_unit or nil
    end

    if not unit then
        return nil, "no player unit"
    end

    --[[
        Aim direction comes from the FIRST PERSON camera, not the unit's
        rotation - the unit faces where you move, the camera faces where you
        look, and a rangefinder that measures your feet's facing is useless.
    --]]
    local cam = Managers.state and Managers.state.camera
    local pos, dir

    if cam and cam.camera then
        local ok = pcall(function()
            local c = cam:camera("player1")
            if c then
                pos = ScriptCamera.position(c)
                dir = ScriptCamera.forward(c)
            end
        end)

        if not ok then
            pos, dir = nil, nil
        end
    end

    if not pos or not dir then
        return nil, "no camera"
    end

    --[[
        PHYSICS WORLD: World.physics_world(world), from the named level world.

        There is no Managers.state.physics_world - I assumed one and it does
        not exist. The engine's own pattern, used 47 times and including by
        HudElementWorldMarkers._physics_world (line 699), is to fetch the
        "level_world" from the world manager and derive the physics world from
        it. has_world is checked first because the world does not exist outside
        a mission.
    --]]
    local wm = Managers.world

    if not wm or not wm.has_world or not wm:has_world("level_world") then
        return nil, "no level world"
    end

    local hit_pos = nil

    local ok = pcall(function()
        local world = wm:world("level_world")
        local physics_world = World.physics_world(world)

        local hit, hp = PhysicsWorld.raycast(physics_world, pos, dir, RANGE_MAX,
            "closest", "collision_filter", "filter_player_character_shooting_raycast")

        if hit then
            hit_pos = hp
        end
    end)

    if not ok or not hit_pos then
        return nil, "no hit"
    end

    local metres = Vector3.distance(pos, hit_pos)

    -- Main-path distance of the aimed-at point, when the path can answer.
    local along = nil
    local M = mpq()

    if M and M.closest_position then
        local ok2, _, d = pcall(M.closest_position, hit_pos)
        along = (ok2 and type(d) == "number") and d or nil
    end

    return metres, along
end

mod:command("range", "Distance to what you are looking at", function()
    local metres, along = Debug.rangefinder()

    if not metres then
        mod:echo(string.format("[HavocTracker] rangefinder: %s", tostring(along)))
        return
    end

    if along then
        mod:echo(string.format("[HavocTracker] %.1fm away, main path %.1fm", metres, along))
    else
        mod:echo(string.format("[HavocTracker] %.1fm away", metres))
    end
end)

--[[
    PACING DIAGNOSTIC.

    The live specials readout came back nil while hosting and I do not want to
    guess at which step failed - that has cost two rounds already on the marker
    tool. This reports every link in the chain rather than the end result.
--]]
mod:command("htaccel", "Real specials timer multipliers (hosting only)", function()
    if not mod.Cascade or not mod.Cascade.live_timer_multipliers then
        mod:echo("[HavocTracker] cascade module not loaded")
        return
    end

    local total, ramp, tmul, floor_t = mod.Cascade.live_timer_multipliers()

    if not total then
        mod:echo("[HavocTracker] no pacing manager - client, so the modelled 3x applies instead")
        return
    end

    mod:echo(string.format(
        "[HavocTracker] specials timer drain x%.2f  (ramp-up %.2f * timer mult %.2f)",
        total, ramp, tmul))

    mod:echo(string.format(
        "[HavocTracker] last %ds of a slot timer ignores both multipliers", floor_t))

    --[[
        Said explicitly because it is the part people do not expect: distance
        is subtracted from the timer in metres, so moving is spending the
        clock rather than merely provoking a check.
    --]]
    mod:echo("[HavocTracker] note: distance travelled is subtracted from spawn timers directly")
end)

mod:command("htpacing", "Why the live specials readout is or is not available", function()
    local st = Managers.state
    local pacing = st and st.pacing
    local sp = pacing and pacing._specials_pacing

    mod:echo(string.format("[HavocTracker] Managers.state=%s  .pacing=%s  ._specials_pacing=%s",
        tostring(st ~= nil), tostring(pacing ~= nil), tostring(sp ~= nil)))

    if not sp then
        mod:echo("[HavocTracker] no specials pacing - you are a client, or pacing has not initialised")
        return
    end

    local ok_cap, cap = pcall(function() return sp:max_num_specials() end)
    local slots = sp._specials_slots

    mod:echo(string.format("[HavocTracker] max_num_specials=%s (ok=%s)  _specials_slots=%s  #=%s",
        tostring(cap), tostring(ok_cap), type(slots),
        type(slots) == "table" and tostring(#slots) or "n/a"))

    if type(slots) == "table" and type(cap) == "number" then
        local filled = 0

        for i = 1, cap do
            local sl = slots[i]

            if type(sl) == "table" and sl.breed_name then
                filled = filled + 1
                mod:echo(string.format("[HavocTracker]   slot %d: %s in %.1fs",
                    i, tostring(sl.breed_name), tonumber(sl.spawn_timer) or -1))
            end
        end

        if filled == 0 then
            mod:echo("[HavocTracker]   no slots have a breed queued yet")
        end
    end

    -- Ritual mutator presence, the other thing that reads as broken when absent.
    local mm = st and st.mutator
    local muts = mm and mm._mutators

    if muts then
        local names = {}
        for n in pairs(muts) do names[#names + 1] = n end
        table.sort(names)
        mod:echo("[HavocTracker] active mutators: " ..
            (#names > 0 and table.concat(names, ", ") or "none"))
    else
        mod:echo("[HavocTracker] no mutator manager")
    end
end)

--[[
    THIS WEEK'S ROTATION.

    Modifiers rotate weekly, so "what does this map do" is the wrong question -
    the right one is "what is active in this run". Both halves are listed
    because they answer different things: the rotation says what was assigned,
    the loaded mutators say what is actually running, and a feature should gate
    on the second.
--]]
mod:command("htmods", "List this run's Havoc modifiers and loaded mutators", function()
    if not mod.Cascade or not mod.Cascade.modifiers then
        mod:echo("[HavocTracker] cascade module not loaded")
        return
    end

    local m = mod.Cascade.modifiers()

    if m.rank then
        mod:echo(string.format("[HavocTracker] Havoc rank %s", tostring(m.rank)))
    end

    if #m.list > 0 then
        mod:echo("[HavocTracker] modifiers this week:")

        for i = 1, #m.list do
            mod:echo(string.format("   %s  (level %s)",
                m.list[i].name, tostring(m.list[i].level)))
        end
    else
        mod:echo("[HavocTracker] no modifiers found - not a Havoc run, or not loaded yet")
    end

    local vals = {}
    for k in pairs(m.values) do vals[#vals + 1] = k end
    table.sort(vals)

    if #vals > 0 then
        mod:echo("[HavocTracker] resolved values:")

        for i = 1, #vals do
            mod:echo(string.format("   %s = %s", vals[i], tostring(m.values[vals[i]])))
        end
    end

    local muts = {}
    for k in pairs(m.mutators) do muts[#muts + 1] = k end
    table.sort(muts)

    mod:echo("[HavocTracker] loaded mutators: " ..
        (#muts > 0 and table.concat(muts, ", ") or "none"))

    --[[
        The ritual answer stated plainly, since that is the one that prompted
        this - a ritual counter on a week with no rituals is worse than no
        counter, because it implies something is being tracked.
    --]]
    mod:echo(string.format("[HavocTracker] chaos rituals this run: %s",
        m.mutators.mutator_havoc_chaos_rituals and "YES" or "no"))
end)

mod.Debug = Debug
return Debug
