local mod = get_mod("HavocTracker")

--[[
    WHAT HAVOC ACTUALLY PUNISHES
    ============================

    Read out of the five Havoc pacing templates and the two managers that
    consume them, not inferred from play:

        scripts/managers/pacing/templates/havoc_pacing_template.lua
        scripts/managers/pacing/horde_pacing/templates/havoc_horde_pacing_template.lua
        scripts/managers/pacing/specials_pacing/templates/havoc_specials_pacing_template.lua
        scripts/managers/pacing/monster_pacing/templates/havoc_monster_pacing_template.lua
        scripts/managers/pacing/roamer_pacing/templates/havoc_roamer_pacing_template.lua
        scripts/managers/pacing/specials_pacing/specials_pacing.lua
        scripts/managers/pacing/pacing_manager.lua

    ------------------------------------------------------------------------
    THE HEADLINE: COHERENCY IS THE ONLY THING THE GAME PUNISHES.

    Across all four sub-templates there are exactly THREE conditions that can
    raise a spawn chance, and only one of them is about the players:

        long_low_period                 16 sites  (pacing has been quiet > 50s)
        has_high_combat_vector_minions   8 sites  (> 8 aggroed combat minions)
        low_coherency                    4 sites  (a player with <= 2 in coherency)

    Nothing else. There is no term anywhere for deaths, downs, medicae use,
    ammo pickups, stims, grenades or abilities - those strings do not appear in
    scripts/managers/pacing at all. The two "stim" hits in that whole tree are
    roamer_pacing spawning STIMMED ROAMERS, which is an enemy buff and has
    nothing to do with a player using one.

    So: taking a medicae charge, burning your ammo, popping a stim or using an
    ability costs you exactly nothing in pacing terms. That is worth stating
    plainly because it is the opposite of what the community generally assumes.

    ------------------------------------------------------------------------
    PUNISHMENT 1 - SPREAD AMBUSH, 4x MORE LIKELY

    havoc_horde_pacing_template, low_coherency at lines 501, 777, 1050, 1408:

        local function low_coherency(target_side_id)
            ... for each player ...
            if num_units_in_coherency <= 2 then return true end

    It is a high_chance_conditions entry on the spread_ambush coordinated horde
    strike. When false the strike rolls at `chance`; when true it rolls at
    `high_chance`:

        three sites   0.2 -> 0.8    (4x)
        one site      0.5 -> 0.8    (1.6x)

    Note `num_units_in_coherency` COUNTS THE PLAYER THEMSELVES. So "<= 2" means
    one player plus at most one other. A pair split off from the other pair
    trips this exactly as hard as a lone wanderer does, which is the part
    people get wrong - you do not have to be alone to cause it.

    And it scans EVERY player: one person trailing is enough to flip it for the
    whole team.

    ------------------------------------------------------------------------
    PUNISHMENT 2 - DISABLERS ARE AIMED AT WHOEVER IS ALONE

    specials_pacing.lua:761-781, in _find_spawn_position:

        if ... disabler_target_alone_player_chance and breed.tags.disabler
           and disabler_target_alone_player_chance >= math.random() then
            ... collect players where num_units_in_coherency == 1 ...
            target_unit = ALONE_TARGETS[math.random(1, #ALONE_TARGETS)]

    This one is stricter - it needs coherency EXACTLY 1, i.e. genuinely nobody
    else in your bubble - and it is per breed, from
    special_pacing_template_settings.lua:140:

        chaos_hound         0.75
        renegade_netgunner  0.50
        cultist_mutant      0.25

    A spawning hound has a 75% chance of being pointed at the player who is on
    their own, rather than spawning against the team's position. This is not a
    chance to be attacked - it is a chance that the SPAWN POSITION is chosen
    for you specifically. Being alone does not make disablers more frequent, it
    makes them yours.

    ------------------------------------------------------------------------
    DOWNS DO NOT LOWER THE DISABLER CAP IN HAVOC

    specials_pacing.lua:1042-1055 caps active disablers by the number of
    players who are up, through num_allowed_disablers_per_alive_targets.
    Havoc does NOT use the default table. special_pacing_template_settings
    .havoc (the table havoc_specials_pacing_template.lua:16 reads) is:

        challenge 3 (ranks 1-10)    { 2, 2, 3, 3 }
        challenge 4 (ranks 11-20)   { 3, 3, 3, 3 }
        challenge 5 (ranks 21-40)   { 4, 4, 4, 4 }

    indexed by players up (1-4). So from rank 11 a down changes nothing about
    how many disablers may be active, and from rank 21 four may be active
    with one player standing. An earlier version of this file used the
    default table ({ 1, 2, 3, 4 } at the top row) and told a last player
    standing that the cap was down to 1. It is 4.

    The horde side still gates on players: more_than_one_num_alive_players
    is a plain condition on the coordinated strikes, so with one player up
    those strikes do not roll.

    A down IS a coherency event, though: a downed player is not in anyone's
    bubble, and the person who stops to res them is often out of everyone
    else's. That is punishment 1 arriving through the back door.

    ------------------------------------------------------------------------
    THE LAST-PLAYER-STANDING OVERRIDE

    :1077-1088. The override timer only starts when a disabler slot is
    actually swapped for a scrambler because the cap is full AND exactly one
    player is up. It is cleared as soon as the cap has room again. Durations
    by challenge: { 360, 240, 160, 100, 80 }. With a Havoc cap of 4, that
    needs four active disablers, so in practice it almost never runs.

    ------------------------------------------------------------------------
    WHAT THE CR THRESHOLDS ACTUALLY ARE

    Also checked, because the mod leans on them: the five-element tables in
    havoc_pacing_template are NOT an escalation ladder. pacing_manager:100-106
    resolves them once through difficulty:get_table_entry_by_challenge, so a
    mission picks ONE row at load and keeps it. They are difficulty tiers, not
    something the team's behaviour moves.

        specials        80  100  120  140  160
        hordes          90  112  135  157  180
        trickle_hordes  20   25   30   35   40
        roamers         90  112  135  157  180
        terror_events  100  125  150  175  200

    Above the row's value for a spawn type, pacing_manager:459 returns
    "disabled_by_challenge_rating" and that type stops spawning entirely.
--]]

--[[
    ========================================================================
    THE REST OF THE TEMPLATES - READ IN FULL, SECOND PASS
    ========================================================================

    The first pass grepped the monster, roamer and specials templates for
    conditions, found none, and moved on. That was a mistake: those three
    files do not express pressure as conditions, they express it as TIERED
    TABLES, so a grep for `conditions` finds nothing while the file is full of
    the stuff. Everything below came out of reading them line by line.

    Note the tier counts differ per template - monsters have 5 challenge rows,
    specials have 6 resistance rows. They are indexed independently.

    ------------------------------------------------------------------------
    1. MONSTERS STOP BUYING YOU TIME  (havoc_monster_pacing_template)

    pause_pacing_on_spawn, seconds of silence bought by a monster spawning:

        tier 1    plague ogryn / spawn   hordes 60  specials 50  trickle 40
                  beast of nurgle        hordes 60  specials 20  trickle 40
        tier 2    all three              hordes 30  specials 20  trickle 20
        tier 3    all three                         specials 15
        tier 4    {}   NOTHING
        tier 5    {}   NOTHING

    At the top two rows a monstrosity arriving pauses nothing at all. The
    common wisdom that a boss means breathing room is true at low challenge and
    false where Havoc actually lives.

    force_horde = true appears ONLY in tiers 4 and 5, which is why the earlier
    CAP BLOCKED work found exactly two sites.

    Monster counts also change shape: tiers 1-3 roll {0,1} or {0,2} monsters,
    tiers 4-5 roll {1,2} - the floor becomes ONE, so the top rows are
    guaranteed a monstrosity rather than merely likely. Daemonhosts go 0, 0,
    {0,1}, {0,2}, {0,2}, houndmaster is only in the monster list at tiers 4-5,
    and allow_witches_spawned_with_monsters is true only there - so a
    daemonhost arriving alongside a boss is a top-row behaviour.

    despawn_distance_when_passive = { chaos_daemonhost = 65 } on every tier. A
    daemonhost you have not woken despawns once you are 65m away, which makes
    backing off a real option rather than a hope.

    ------------------------------------------------------------------------
    2. STANDING AND FIGHTING STOPS PAUSING SPECIALS  (havoc_specials)

    travel_distance_spawning is true on every havoc row, so the specials timer
    normally advances as the team MOVES. move_timer_override flips it to
    advance on the CLOCK instead (specials_pacing.lua:417):

        should_update_by_travel_distance =
            not coordinated_strike_update_override
            and not move_timer_override
            and travel_distance_spawning

    and these flip it on:

        move_timer_when_horde_active         false false TRUE TRUE TRUE TRUE
        move_timer_when_monster_active       false false TRUE TRUE TRUE TRUE
        move_timer_when_terror_event_active      -     -    - TRUE TRUE TRUE
        move_timer_when_challenge_rating_above  30    30   30   30   20   20

    So from resistance row 3 up, holding a doorway through a horde or a boss no
    longer stalls the specials timer - it runs on the clock regardless. Rows 1
    and 2 do stall it. That inverts the "stop and clear, then move" advice at
    the top rows, and it is the single biggest behavioural difference between
    low and high Havoc in this file.

    The challenge-rating route has a latch: once CR crosses the threshold the
    override stays on for move_timer_when_challenge_rating_above_delay, which
    is 20 seconds on every row, even if CR drops back.

    Other things that move by row (1 -> 6):

        max_alive_specials              3   4   5   6   8  10
        chance_for_coordinated_strike  .1 .15  .2 .25  .5  .6
        coordinated_surge_chance        -   -   -  .2  .4 .45
        first_spawn_timer_modifer     .75 .65 .65  .6  .6  .6
        rushing_distance               80  60  50  45  40  35

    ------------------------------------------------------------------------
    3. THREE SEPARATE MECHANICS ALL SPAWN DISABLERS AT YOU

    special_pacing_template_settings.lua:58-71. Every prevention mechanic in
    the game draws from the same short list:

        rush_prevention_breeds          hound, mutant
        loner_prevention_breeds         hound, mutant, netgunner
        speed_running_prevention_breeds hound, mutant, netgunner

    So "the game punished me" almost always arrives as a disabler, which is why
    the Handholder tracer work and this file are really about the same thing.

    Their triggers, by resistance row:

        rushing_distance                80  60  50  45  40  35   (metres ahead)
        loner_prevention_breeds          -   -   - yes yes yes

        speed_running_required_distance  -  12  12  10  10  10   (metres per check)
        speed_running_required_chal_rat  -  50  30  10   8   8
        num_required_speed_running_checks -  4   4   2   2   2
        speed_running_check_frequency    -  5   5   5   5   5    (seconds)

    Read that bottom block together: at the top rows, every 5 seconds the game
    asks "has this team moved 10m with CR at or above 8", and TWO yeses in a
    row spawns a hound, a mutant or a trapper on you. Ten metres in five
    seconds is a walk. That is not a speedrun penalty at the top rows, it is a
    tax on moving at all while anything is alive, and it tightens from 50 CR at
    row 2 to 8 CR at rows 5-6.

    Loner prevention does not exist below row 4 at all.

    ------------------------------------------------------------------------
    4. ROAMERS - MOSTLY A DEAD END, WORTH RECORDING SO NOBODY RE-CHECKS

    havoc_roamer_pacing_template has no conditions and no player-behaviour
    terms. The one pressure-relevant table is

        pause_spawn_type_when_aggroed.poxwalkers.hordes
            = { 50, 45, 30, 25, 15, 5 }

    i.e. aggroing a poxwalker encampment pauses hordes, for 50s at row 1 down
    to 5s at row 6 - and it is moot in Havoc anyway, because the same file sets

        chance_of_encampment = 0

    so encampments do not generate. spawn_distance is 75 and zone_length 10 on
    every row.
--]]

local P = {}

-- Verified constants. Values only; the reasoning is above.
P.SPREAD_AMBUSH_COHERENCY  = 2      -- <= this trips low_coherency
P.SPREAD_AMBUSH_BASE       = 0.2    -- three of four sites
P.SPREAD_AMBUSH_HIGH       = 0.8
P.ALONE_COHERENCY          = 1      -- == this makes you a disabler target

P.DISABLER_MAGNET = {
    chaos_hound        = 0.75,
    renegade_netgunner = 0.50,
    cultist_mutant     = 0.25,
}

-- num_allowed_disablers_per_alive_targets from special_pacing_template_settings
-- .havoc, by challenge, indexed by the number of players who are up.
P.DISABLER_CAP_BY_CHALLENGE = {
    { 0, 0, 1, 1 },
    { 0, 1, 1, 2 },
    { 2, 2, 3, 3 },
    { 3, 3, 3, 3 },
    { 4, 4, 4, 4 },
}

-- disabler_override_duration, by challenge.
P.LAST_STANDING_GRACE_BY_CHALLENGE = { 360, 240, 160, 100, 80 }

local function challenge_row()
    local c = mod.cfg and mod.cfg.challenge or 5
    if c < 1 then c = 1 elseif c > 5 then c = 5 end
    return c
end

--[[
    Everything every prevention mechanic can send at you. Identical lists on
    purpose - see section 3 above. Exposed so Handholder's disabler tracers and
    this file cannot drift apart about what counts as a disabler.
--]]
P.PREVENTION_BREEDS = {
    rush        = { "chaos_hound", "cultist_mutant" },
    loner       = { "chaos_hound", "cultist_mutant", "renegade_netgunner" },
    speedrun    = { "chaos_hound", "cultist_mutant", "renegade_netgunner" },
}

-- Top resistance row. Metres ahead of the team before rush prevention arms.
P.RUSH_DISTANCE = 35

--[[
    Speed-running prevention, top rows. Every CHECK_FREQUENCY seconds the game
    asks whether the team moved REQUIRED_DISTANCE with CR at or above
    REQUIRED_CR; REQUIRED_CHECKS consecutive yeses spawns a disabler.
--]]
P.SPEEDRUN = {
    check_frequency   = 5,
    required_distance = 10,
    required_cr       = 8,
    required_checks   = 2,
}

--[[
    pause_pacing_on_spawn by monster challenge row. The top two rows are
    empty - a monstrosity buys nothing there.
--]]
P.MONSTER_PAUSE = {
    { hordes = 60, specials = 50, trickle_hordes = 40 },
    { hordes = 30, specials = 20, trickle_hordes = 20 },
    {              specials = 15                      },
    {},
    {},
}

-- A daemonhost you have not woken despawns once you are this far from it.
P.DAEMONHOST_PASSIVE_DESPAWN = 65

--[[
    ------------------------------------------------------------------------
    THE TRANSIENT BREAK ON A DOWN OR A DISCONNECT - CONFIRMED IN SOURCE
    ------------------------------------------------------------------------

    Dio reported that going down or disconnecting drops you out of coherency
    for a moment, and that the pacing code showing no "down" term did not match
    what happens in game. He was right, and it is not a bug on Fatshark's end -
    it falls out of how coherency is stored.

    Coherency is not a per-player radius check. It is a DAISY CHAIN, rebuilt by
    the system rather than incrementally edited. coherency_system.lua:44-52:

        CoherencySystem.on_remove_extension = function (self, unit, ...)
            ...
            _release_daisy_chain(unit)

    and releasing a chain fires on_coherency_exit at line 68 for every member
    of it, not just for the unit that left. The chain is then re-formed by the
    normal update at lines 240-246, which fires exit and then enter again.

    So when a player unit is REMOVED - death, or a disconnect, both of which
    despawn the unit - every other player in that chain is dropped out of
    coherency and put back in. In between, num_units_in_coherency is lower for
    everyone, which is exactly the "limbo for a second" Dio described.

    That matters because low_coherency is evaluated by the horde template
    whenever it rolls, not on our schedule. A dip we never observe is still a
    dip the game can roll against.

    WHY POLLING ALONE CANNOT SEE THIS

    P.update() runs on the 100ms path throttle. A chain rebuild resolves in a
    frame or two, so a poll will miss it the overwhelming majority of the time.
    Reporting "coherency was fine" because we happened not to be looking is
    worse than not reporting at all.

    So the exit event is hooked directly and the LOWEST value seen is kept as a
    watermark, with a timestamp. Polling still runs for the steady state; the
    watermark catches what polling structurally cannot.

    A knocked_down player is NOT removed from the side (side.lua:155-170 runs
    on despawn, not on knockdown), so a plain down does not release the chain
    by this route. What it does do is take that player out of everyone's
    effective bubble as they hit the floor and as whoever revives them moves,
    which is the indirect path described at the top of this file. Death and
    disconnect are the two that release the chain outright.
--]]
local BREAK_MEMORY = 6.0   -- seconds a transient break stays worth reporting

local state = {
    alone_count      = 0,     -- players at coherency exactly 1
    split_count      = 0,     -- players at coherency <= 2
    non_disabled     = 4,
    disabler_cap     = 4,
    last_standing_at = nil,   -- gameplay time the grace timer started

    break_low        = nil,   -- lowest coherency seen during a transient break
    break_at         = nil,   -- when it was seen
}

local function now()
    return mod._now or 0
end

local function coherency_of(unit)
    local ext = ScriptUnit.has_extension(unit, "coherency_system")

    if not ext or not ext.num_units_in_coherency then
        return nil
    end

    local ok, n = pcall(ext.num_units_in_coherency, ext)

    return (ok and type(n) == "number") and n or nil
end

--[[
    THE GAME'S OWN REQUIRES_HELP SET, COPIED EXACTLY.

    player_unit_status.lua:23-32. Transcribed as a whitelist rather than
    reimplemented as "not one of the normal states", because the normal-state
    list is long, changes with every patch that adds a traversal move, and
    getting it wrong fails in the dangerous direction: a state I forgot to
    exclude would be counted as disabled, which would silently under-report
    players_up and therefore under-report the disabler cap.

    This is the exact population specials_pacing indexes the disabler cap by,
    so it has to agree with the game rather than merely resemble it. `dead` is
    not in the game's REQUIRES_HELP table - a corpse cannot be helped - but it
    is in DISABLED_STATES and is obviously not a player who is up, so it is
    added here and flagged as the one deliberate difference.
--]]
local REQUIRES_HELP = {
    consumed = true,
    grabbed = true,
    hogtied = true,
    knocked_down = true,
    ledge_hanging = true,
    mutant_charged = true,
    netted = true,
    pounced = true,
    warp_grabbed = true,

    -- Not in the game's REQUIRES_HELP, but num_non_disabled_players is built
    -- from players who are neither disabled nor dead.
    dead = true,
}

local function requires_help(unit)
    local ude = ScriptUnit.has_extension(unit, "unit_data_system")

    if not ude then
        return false
    end

    local ok, comp = pcall(ude.read_component, ude, "character_state")

    if not ok or not comp then
        return false
    end

    return REQUIRES_HELP[comp.state_name] == true
end

function P.update()
    local ext = Managers.state and Managers.state.extension
    local side_system = ext and ext:system("side_system")

    if not side_system then
        return
    end

    local ok, side = pcall(function()
        local name = side_system:get_default_player_side_name()
        return side_system:get_side_from_name(name)
    end)

    if not ok or not side then
        return
    end

    local units = side.valid_player_units
    if type(units) ~= "table" then
        return
    end

    local alone, split, up = 0, 0, 0

    --[[
        THE COHERENCY COUNTS ONLY INCLUDE PLAYERS WHO ARE UP, AND THE GAME'S DO NOT.

        specials_pacing builds ALONE_TARGETS from side.valid_player_units with
        no disabled filter, so a knocked-down player - whose coherency is 1 by
        definition, nobody is in their bubble - is a valid alone-target as far
        as the engine is concerned. Counting them the same way here would be
        faithful to the source and useless as advice: "2 alone" when two people
        are on the floor reads as "go stand together", which is not the thing
        to do about it, and it would fire on every single knockdown.

        So the counts here answer the question the warning is for - is anyone
        WALKING AROUND on their own - and the down itself is already covered by
        the players_up count and the disabler cap below. This is a deliberate
        divergence from the engine, not an oversight.
    --]]
    for i = 1, #units do
        local unit = units[i]
        local disabled = requires_help(unit)

        if not disabled then
            up = up + 1

            local n = coherency_of(unit)

            if n then
                if n <= P.ALONE_COHERENCY then
                    alone = alone + 1
                end
                if n <= P.SPREAD_AMBUSH_COHERENCY then
                    split = split + 1
                end
            end
        end
    end

    state.alone_count = alone
    state.split_count = split
    state.non_disabled = up

    local idx = math.max(1, math.min(up, 4))
    state.disabler_cap = P.DISABLER_CAP_BY_CHALLENGE[challenge_row()][idx] or 4

    --[[
        The grace timer starts when exactly one player is left up and is
        cleared the moment a second one is back on their feet - matching
        specials_pacing, which nils the override rather than pausing it.
    --]]
    if up == 1 then
        if not state.last_standing_at then
            state.last_standing_at = now()
        end
    else
        state.last_standing_at = nil
    end
end

--[[
    Everything a caller needs, as plain values. No table is built per call:
    this is read from the HUD rebuild and the chat post, both repeating paths.
--]]
function P.alone_count()  return state.alone_count end
function P.split_count()  return state.split_count end
function P.players_up()   return state.non_disabled end
function P.disabler_cap() return state.disabler_cap end

--[[
    Seconds of protection left for a last player standing, or nil.

    Only meaningful while the cap is actually full: the server starts this
    clock when it has to swap a disabler for a scrambler, not when the
    second-to-last player goes down. Counted from the moment one player was
    left up with the cap full, which is the earliest it could have started.
--]]
function P.last_standing_left()
    if not state.last_standing_at then
        return nil
    end

    local alive = (mod.state and mod.state.disablers_alive) or 0
    if alive < state.disabler_cap then
        return nil
    end

    local grace = P.LAST_STANDING_GRACE_BY_CHALLENGE[challenge_row()] or 80
    return math.max(0, grace - (now() - state.last_standing_at))
end

-- True while the team is handing the game a 4x spread-ambush roll.
function P.spread_ambush_armed()
    return state.split_count > 0
end

--[[
    EVENT-DRIVEN BREAK DETECTION.

    Both extension classes are hooked because they are different objects: the
    local player's unit carries UnitCoherencyExtension and every teammate
    carries HuskCoherencyExtension. Hooking only one would make this work
    correctly for a break that happened to involve you and silently miss the
    rest.

    hook_safe rather than hook: this fires inside the coherency system's own
    chain rebuild, and a throw there would break coherency for the whole team -
    a far worse outcome than a missed warning. Nothing here can affect the
    engine's own bookkeeping; it only reads and records.

    Recorded as a MINIMUM rather than a latest value, so a chain that collapses
    over several frames reports how bad it actually got rather than whatever
    the last event happened to say.
--]]
local function note_break(self)
    if not self or not self.num_units_in_coherency then
        return
    end

    local ok, n = pcall(self.num_units_in_coherency, self)

    if not ok or type(n) ~= "number" then
        return
    end

    if n > P.SPREAD_AMBUSH_COHERENCY then
        return
    end

    local t = now()

    -- A new break, or a deeper one than the break we are already holding.
    if not state.break_at or (t - state.break_at) > BREAK_MEMORY
        or n < (state.break_low or math.huge) then
        state.break_low = n
        state.break_at = t
    end
end

mod:hook_safe("UnitCoherencyExtension", "on_coherency_exit", note_break)
mod:hook_safe("HuskCoherencyExtension", "on_coherency_exit", note_break)

--[[
    The lowest coherency seen in a transient break, and how long ago, or nil
    once it has aged out. Separate from the polled counts on purpose: this
    answers "did we just get clipped", which the steady-state numbers cannot.
--]]
function P.recent_break()
    if not state.break_at then
        return nil
    end

    local age = now() - state.break_at

    if age > BREAK_MEMORY then
        return nil
    end

    return state.break_low, age
end

function P.reset()
    state.alone_count, state.split_count = 0, 0
    state.non_disabled, state.disabler_cap = 4, 4
    state.last_standing_at = nil
    state.break_low, state.break_at = nil, nil
end

--[[
    EVERY PUNISHMENT KIND, NOT JUST THE COHERENCY ONES.

    The first version of this file reported coherency and nothing else, which
    left three of the five mechanics invisible. All five, with the source each
    threshold came from:

        coherency   low_coherency, horde template          <= 2 in a bubble
        alone       disabler_target_alone_player_chance     == 1 in a bubble
        rush        rushing_distance, specials template     35 m lead
        speedrun    speed_running_* block, specials         10 m / 5 s, CR >= 8
        loner       loner_prevention_breeds, specials       sustained alone

    The thresholds are read from mod.TRIPWIRE rather than duplicated here,
    because that table is already populated from the live havoc config at
    HavocTracker.lua:262-267 - hardcoding a second copy is how the two drift
    apart when Fatshark moves a number.

    Returns a list of { kind, text } ordered worst-first. Callers that want one
    line take the first; the /htpunish readout shows all of them.
--]]
local kinds_buffer = {}

function P.kinds()
    -- Reused rather than rebuilt: this is read from the HUD rebuild path.
    for i = #kinds_buffer, 1, -1 do
        kinds_buffer[i] = nil
    end

    local s = mod.state or {}
    local tw = mod.TRIPWIRE or {}

    local function add(kind, text)
        kinds_buffer[#kinds_buffer + 1] = { kind = kind, text = text }
    end

    local left = P.last_standing_left()

    if left and left <= 0 then
        add("last_standing", "LAST ONE UP - disabler cap lifted, they spawn past it now")
    elseif left then
        add("last_standing", string.format("LAST ONE UP - cap full, lifts in %ds",
            math.floor(left + 0.5)))
    elseif state.non_disabled == 1 then
        add("last_standing", string.format("one player left up - disabler cap %d", state.disabler_cap))
    end

    if state.alone_count > 0 then
        add("alone", string.format("%d alone - spawning hounds pick you 3 in 4, trappers 1 in 2",
            state.alone_count))
    end

    --[[
        LONER, RUSH and SPEED-RUNNING come from HavocTracker_pace.lua, which
        runs the server's three rules as written (including the 3-7 s failed
        cooldown in front of the loner timer, the lead-vs-next-player rush
        gap, and speed-running's kept baseline while CR is low). The local
        approximations below are only the fallback for when it did not load.
    --]]
    local Pace = mod.Pace
    if Pace and Pace.kinds then
        local list = Pace.kinds()
        for i = 1, #list do
            add(list[i].kind, list[i].text)
        end
    else
        local alone_for = s.alone_seconds or 0
        local alone_grace = (tw.alone_seconds or 5) + 3

        if alone_for >= alone_grace then
            add("loner", string.format("alone %ds - loner prevention spawns hound/mutant/trapper",
                math.floor(alone_for)))
        end

        local spread = s.spread or 0
        local rush_m = tw.spread_m or P.RUSH_DISTANCE

        if spread >= rush_m then
            add("rush", string.format("lead %dm ahead (limit %dm) - rush prevention: hound/mutant",
                math.floor(spread), rush_m))
        end

        local checks = s.speedrun_checks or 0
        local need = tw.speedrun_checks or 2

        if checks >= need then
            add("speedrun", string.format("speedrun prevention ARMED (%d/%d checks) - disabler incoming",
                checks, need))
        elseif checks > 0 then
            add("speedrun", string.format("speedrun check %d/%d - %dm per %ds above CR %d",
                checks, need, tw.speedrun_m or 10, tw.speedrun_period or 5, tw.speedrun_min_cr or 8))
        end
    end

    if state.split_count > 0 then
        add("coherency", string.format("split up - spread ambush rolls %d in 10 instead of %d",
            P.SPREAD_AMBUSH_HIGH * 10, P.SPREAD_AMBUSH_BASE * 10))
    end

    local low = P.recent_break()

    if low then
        add("break", string.format(
            "coherency broke on the last down/death (dropped to %d) - ambush window was open", low))
    end

    return kinds_buffer
end

--[[
    One short line for the chat post and the HUD, or nil when the team is
    clean. Ordered by severity, and only the worst is returned - a post that
    lists three problems gets read as noise.
--]]
function P.warning()
    --[[
        Delegates to P.kinds so there is ONE ordering and ONE set of strings.
        The previous version had its own if-chain, which is how the warning and
        the readout would eventually have disagreed about what was wrong.
    --]]
    local list = P.kinds()

    return list[1] and list[1].text or nil
end

-- The kind of the worst active punishment, for callers that want to branch on
-- it rather than print it.
function P.worst_kind()
    local list = P.kinds()

    return list[1] and list[1].kind or nil
end

mod.__ht_punish = P

mod:command("htpunish", "what Havoc is currently punishing you for", function()
    P.update()

    mod:echo("[HavocTracker] === punishment state ===")
    mod:echo(string.format("  players up: %d   disabler cap: %d active at once (Havoc table, challenge %d)",
        P.players_up(), P.disabler_cap(), challenge_row()))
    mod:echo(string.format("  coherency: %d alone (<=1), %d split (<=2)",
        P.alone_count(), P.split_count()))

    local left = P.last_standing_left()
    if left then
        mod:echo(string.format("  LAST STANDING with the cap full: %.0fs before disablers ignore it", left))
    end

    local list = P.kinds()

    if #list == 0 then
        mod:echo("  clean - nothing is being punished")
    else
        mod:echo(string.format("  %d punishment(s) active, worst first:", #list))
        for i = 1, #list do
            mod:echo(string.format("    [%s] %s", list[i].kind, list[i].text))
        end
    end

    mod:echo("  (medicae, ammo, stims, grenades and abilities do not affect pacing at all)")
    mod:echo("  top-row reminders (see /htpace for the live numbers):")
    mod:echo(string.format("    every %ds: moved %dm with CR >= %d is a check, %d in a row spawns a disabler",
        P.SPEEDRUN.check_frequency, P.SPEEDRUN.required_distance,
        P.SPEEDRUN.required_cr, P.SPEEDRUN.required_checks))
    mod:echo("    a CR drop does not reset the check: the baseline waits, and the next fight counts it")
    mod:echo(string.format("    %dm ahead of the next player arms rush prevention (hound/mutant)", P.RUSH_DISTANCE))
    mod:echo("    alone with 3+ players up: loner disabler after 8-16s at rank 31+")
    mod:echo("    monsters pause NOTHING at the top two rows - no breathing room from a boss")
    mod:echo("    hordes and bosses no longer stall the specials timer above row 2")
    mod:echo(string.format("    a passive daemonhost despawns at %dm - backing off works",
        P.DAEMONHOST_PASSIVE_DESPAWN))
end)

return P
