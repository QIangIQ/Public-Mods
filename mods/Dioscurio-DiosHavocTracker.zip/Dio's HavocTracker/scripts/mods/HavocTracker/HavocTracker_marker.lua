local UIWidget = require("scripts/managers/ui/ui_widget")

-- This file is loaded via add_require_path, not io_dofile, so it never had a
-- `mod` upvalue. marker_alpha reads a setting, so it needs one.
local mod = get_mod("HavocTracker")

--[[
    World marker template for spawn triggers.

    Modelled directly on RitualZones_marker.lua, which is known to work in this
    game build. My previous attempt projected world positions to screen space by
    hand and drew rects; it never appeared once. This instead registers a
    template with the game's OWN world-marker system, which already solves
    projection, occlusion, distance fading, screen clamping and lifetime.

    NOTE the misspelling: `create_widget_defintion`. That is the field name
    HudElementWorldMarkers actually looks up. Spelling it correctly means the
    template is silently never built.
--]]

local template = {}

local DEFAULT_ICON  = "content/ui/materials/icons/difficulty/difficulty_skull_uprising"
local DEFAULT_COLOR = { 255, 90, 60 }

template.name            = "HavocTracker_spawn_marker"
template.size            = { 48, 48 }
template.max_distance    = 300
template.min_distance    = 0
template.position_offset = { 0, 0, 1.4 }

--[[
    Line-of-sight checking OFF.

    These markers exist to tell you what is coming BEFORE you can see it. A
    marker that hides behind the wall it is warning you about is useless.
--]]
template.check_line_of_sight = false

--[[
    Distance falloff.

    A marker sized for readability at 10m is a billboard at 200m, which is what
    made the boss triggers dominate the screen while you were still far away.
    The world-marker system already tracks distance for us, so scale the icon
    down with it: full size close in, FAR_MIN of that at MAX_DIST and beyond.

    Deliberately NOT linear to zero - a distant marker still has to be findable,
    it just should not shout.
--]]
local NEAR_DIST = 25      -- full size at or under this
local MAX_DIST  = 220     -- floor reached here
local FAR_MIN   = 0.34    -- fraction of full size when far

local function distance_factor(marker)
    local d = marker and marker.distance
    if type(d) ~= "number" or d <= NEAR_DIST then
        return 1
    end
    if d >= MAX_DIST then
        return FAR_MIN
    end
    local t = (d - NEAR_DIST) / (MAX_DIST - NEAR_DIST)
    return 1 - (1 - FAR_MIN) * t
end

--[[
    OPACITY.

    Every marker was drawn at alpha 255 - a solid, saturated skull sitting on
    top of whatever you were fighting. That is the real complaint: not how many
    markers there are, but that each one competes with the game for attention.

    These are ambient information, not a threat indicator, so they should sit
    behind the fight visually. Alpha is settable and defaults low; gate dots go
    lower still, since there are more of them and they only need to imply a
    line.
--]]
local function marker_alpha(data)
    local mod_alpha = tonumber(mod:get("spawn_marker_opacity"))
    if not mod_alpha then
        mod_alpha = 42
    end
    local a = math.floor(255 * math.max(0, math.min(100, mod_alpha)) / 100)

    -- Gate dots are unlabelled; fade them further so the icon reads as the
    -- anchor and the dots as its extent.
    if data and (data.label == nil or data.label == "") then
        a = math.floor(a * 0.65)
    end
    return a
end

--[[
    Distance is quantised before it drives anything.

    apply() runs per marker per frame. marker.distance changes by millimetres
    every frame as you walk, so an exact comparison never matches and the
    "has anything changed" check below would never fire. Rounding to whole
    metres means the check succeeds for most frames while the visible result
    is identical - nobody can see a size change from 47.31m to 47.29m.
--]]
local function quantised_distance(marker)
    local d = marker and marker.distance
    if type(d) ~= "number" then
        return -1
    end
    return math.floor(d)
end

local function apply(widget, marker)
    local data = marker.data or {}

    --[[
        EARLY OUT - this is the per-frame cost that mattered.

        Everything below is ~25 table writes into style tables. None of it
        changes unless the label, colour, opacity setting or (rounded) distance
        changes. With ~40 markers live that was ~1000 pointless writes per
        frame, 60,000 a second, to produce a pixel-identical result.

        The cached signature lives on the widget, so it dies with the widget
        and cannot leak across missions.
    --]]
    local qd = quantised_distance(marker)
    local cache = widget.__ht_cache

    if cache
        and cache.d == qd
        and cache.label == data.label
        and cache.icon == data.icon
        and cache.size == data.icon_size
        and cache.font == data.font_size
        and cache.c1 == (data.color and data.color[1])
        and cache.c2 == (data.color and data.color[2])
        and cache.c3 == (data.color and data.color[3])
        and cache.opacity == mod:get("spawn_marker_opacity")
    then
        return
    end

    local color = data.color or DEFAULT_COLOR
    local size  = (data.icon_size or template.size[1]) * distance_factor(marker)
    local alpha = marker_alpha(data)

    local istyle = widget.style.icon
    istyle.size[1], istyle.size[2] = size, size
    istyle.default_size[1], istyle.default_size[2] = size, size
    istyle.color[1] = alpha                       -- was hardcoded 255
    istyle.color[2] = color[1] or DEFAULT_COLOR[1]
    istyle.color[3] = color[2] or DEFAULT_COLOR[2]
    istyle.color[4] = color[3] or DEFAULT_COLOR[3]

    --[[
        The LABEL stays more opaque than the icon.

        The text is the part carrying information - "MONSTER 47m 15%" - while
        the skull is only a position. Fading them equally would make the useful
        half unreadable to solve a problem caused by the decorative half.
    --]]
    local tstyle = widget.style.label
    tstyle.text_color[1] = math.min(255, math.floor(alpha * 1.7))
    tstyle.text_color[2] = color[1] or DEFAULT_COLOR[1]
    tstyle.text_color[3] = color[2] or DEFAULT_COLOR[2]
    tstyle.text_color[4] = color[3] or DEFAULT_COLOR[3]

    --[[
        Font size is data-driven for the same reason icon_size is: these are
        1080p reference pixels that get downscaled, so a fixed 20 renders around
        7 real pixels at 360p - unreadable. The caller scales it.
    --]]
    if data.font_size then
        -- Label follows the icon, but with a gentler floor so the distance
        -- readout stays legible when the icon has shrunk.
        tstyle.font_size = data.font_size * math.max(0.6, distance_factor(marker))
    end

    -- Keep the label clear of the icon as the icon grows.
    tstyle.offset[2] = (size * 0.55)

    widget.content.icon  = data.icon or DEFAULT_ICON
    widget.content.label = data.label or ""

    marker.template.check_line_of_sight = false

    -- Record what this frame was built from, so the next frame can skip.
    local cache = widget.__ht_cache
    if not cache then
        cache = {}
        widget.__ht_cache = cache
    end
    cache.d       = qd
    cache.label   = data.label
    cache.icon    = data.icon
    cache.size    = data.icon_size
    cache.font    = data.font_size
    cache.c1      = data.color and data.color[1]
    cache.c2      = data.color and data.color[2]
    cache.c3      = data.color and data.color[3]
    cache.opacity = mod:get("spawn_marker_opacity")
end

template.create_widget_defintion = function(self, scenegraph_id)
    local size = self.size

    return UIWidget.create_definition({
        {
            pass_type = "texture",
            style_id  = "icon",
            value     = DEFAULT_ICON,
            value_id  = "icon",
            style = {
                horizontal_alignment = "center",
                vertical_alignment   = "center",
                size         = { size[1], size[2] },
                default_size = { size[1], size[2] },
                offset       = { 0, 0, 1 },
                color = { 255, DEFAULT_COLOR[1], DEFAULT_COLOR[2], DEFAULT_COLOR[3] },
            },
            visibility_function = function(content)
                return content.icon ~= nil
            end,
        },
        {
            pass_type = "text",
            style_id  = "label",
            value     = "",
            value_id  = "label",
            style = {
                font_size = 20,
                font_type = "machine_medium",
                horizontal_alignment      = "center",
                vertical_alignment        = "center",
                text_horizontal_alignment = "center",
                text_vertical_alignment   = "top",
                size   = { 240, 28 },
                offset = { 0, size[2] * 0.55, 2 },
                text_color = { 255, DEFAULT_COLOR[1], DEFAULT_COLOR[2], DEFAULT_COLOR[3] },
            },
            visibility_function = function(content)
                return content.label ~= nil and content.label ~= ""
            end,
        },
    }, scenegraph_id)
end

--[[
    Both entry points are guarded.

    These run inside the GAME's world-marker element, not ours. At mission end
    that element tears down while markers we registered may still be in its
    list, and a widget or marker can be partially destroyed when apply() reads
    it. An error thrown here propagates into the engine's UI update rather than
    into our code, which is the shape of a crash on mission end.

    Failing to style a marker is invisible; throwing takes the game down.
--]]
template.on_enter = function(widget, marker)
    pcall(apply, widget, marker)
end

--[[
    Held fully opaque on purpose.

    line_of_sight_progress and alpha_multiplier are what the base system uses to
    fade markers behind geometry and at range. Both are pinned to 1 so the
    marker stays equally readable at 200m through a wall as it does at 10m in
    the open - which is the whole point of a spawn warning.
--]]
--[[
    Named, so no closure is allocated per call.

    update_function runs for EVERY marker on EVERY frame. With 30-40 markers
    that inline `pcall(function() ... end)` was allocating 40 closures a frame,
    around 2,400 a second, purely to set two fields. A shared upvalue costs
    nothing.
--]]
local function pin_visibility(widget)
    widget.content.line_of_sight_progress = 1
    widget.alpha_multiplier = 1
end

template.update_function = function(parent, ui_renderer, widget, marker)
    pcall(apply, widget, marker)
    pcall(pin_visibility, widget)
    return false
end

return template
