local mod = get_mod("HavocTracker")

--[[
    ENTITY CAP CENSUS
    =================

    Counts what is alive, weighted, against the Havoc 40 entity budget of 70.

    WEIGHTS (from the user's competitive model, not from source):
        ogryn elite  2.0
        elite        1.0
        special      1.0
        horde        0.3
        roamer       0.3   (assumed - see ROAMERS below)
        monster      unweighted, reported separately
        captain      unweighted, reported separately

    ------------------------------------------------------------------------
    WHY THIS READS breed.tags AND NOT A HARDCODED BREED LIST
    ------------------------------------------------------------------------

    I was asked to work from a hand-written list of elite and special breed
    names, and said at the time that Darktide has no canonical elite tag. That
    was WRONG. Every breed file carries them:

        chaos_ogryn_bulwark_breed.lua:67
            tags = { bulwark = true, elite = true, melee = true,
                     minion = true, ogryn = true }

    The engine's `elite` tag matches the hand list EXACTLY - all eleven breeds,
    nothing extra, nothing missing. Same for `special`, all nine. So the list
    was right, and the tags independently confirm it.

    But reading the tags instead of the list picks up things the list silently
    omits, and on Havoc 40 with mutators several of them matter:

        elite, missed by the list:
            renegade_radio_operator        cr=4
        special, missed by the list:
            chaos_armored_hound            cr=6
            chaos_hound_mutator            cr=1
            cultist_mutant_mutator         cr=2
            renegade_flamer_mutator        cr=1
        roamer, missed by the list:
            cultist_vanguard, renegade_vanguard

    The list also carried `chaos_lightly_mutated_poxwalker`, which is not a
    breed - the real name is `chaos_lesser_mutated_poxwalker`. A hardcoded list
    cannot tell you it contains a name that never matches; a tag read cannot
    contain one.

    Tags are also self-maintaining: a breed Fatshark adds next patch is
    classified correctly with no edit here.

    ------------------------------------------------------------------------
    OGRYNS - tags.ogryn, not a name prefix
    ------------------------------------------------------------------------

    `ogryn = true` is a real tag. Combined with `elite`, it identifies exactly
    the three 2x breeds (bulwark, executor, reaper gunner). Their challenge
    rating is 8 against 3-4 for every other elite, which is independent
    corroboration of the 2x weighting.

    Matching on the "chaos_ogryn_" name prefix would have been wrong anyway:
    chaos_ogryn_houndmaster and chaos_plague_ogryn are monsters, not elites.

    ------------------------------------------------------------------------
    ROAMERS - a flagged assumption
    ------------------------------------------------------------------------

    The model states horde = 0.1x and does not classify roamers (the
    renegade/cultist melee, assault, rifleman and vanguard groundtroops). They
    are treated as 0.1x here on the grounds that they are the same low-value
    mass, and counted in their own field so the assumption is visible and can
    be changed with one number rather than being buried in a total.

    ------------------------------------------------------------------------
    WHY A SEPARATE UNIT TABLE FROM THE EXISTING CENSUS
    ------------------------------------------------------------------------

    track_unit() in the main file bails on `cr <= 0`, and EVERY horde breed has
    challenge_rating = 0:

        chaos_poxwalker                  cr=0
        chaos_newly_infected             cr=0
        chaos_mutated_poxwalker          cr=0
        chaos_lesser_mutated_poxwalker   cr=0
        chaos_armored_infected           cr=0
        cultist_melee / cultist_assault  cr=0

    So the existing `tracked` table contains no horde at all, and deriving a
    horde count from it would read zero forever - silently, which is the
    failure mode this whole exercise is meant to avoid.

    This table therefore tracks units the other one cannot see. It is
    deliberately CHEAPER per unit: a category id and nothing else. No position,
    no distance, no aggro test. That matters because a poxwalker horde is
    50-100+ units and the aggro sweep is the hottest loop in the mod - the one
    that has caused three framerate regressions. Adding 100 units to THAT loop
    would be a mistake; adding them to an integer-counting loop is not.
--]]

local Cap = {}
Cap._warned_negative = false

--[[
    THE BUDGET IS FIXED AT 70 AND IS NOT A SETTING.

    45 -> 50 -> 55 -> 68 -> 70. The last two are the 2026-09-29 patch.

    After that update the panel read Capped from the moment a mission loaded,
    which cannot be right - a field at mission spawn is the emptiest the map
    will ever be. The composition that used to sit near the old ceiling of 55
    now lands around 68, so 55 had stopped describing anything and the top two
    bands were permanently on. A band that is always lit carries no
    information.

    70 is MEASURED, NOT READ, and the post-patch source confirms why it has
    to be. The 2026-09-30 dump was checked against 2026-09-18: all three Havoc
    pacing templates - havoc_pacing_template, havoc_horde_pacing_template and
    havoc_specials_pacing_template - are IDENTICAL whitespace-insensitive, and
    max_active_minions is still 70/70/85/90/95 across the resistance entries.

    So nothing in the Lua changed. Missions nevertheless now start near the
    old ceiling, which means the change was made somewhere the source dump
    does not cover. There is therefore no file and line to cite for this
    number, and it comes from watching the panel against live fields.

    Treat it as the softest figure in the mod, and expect it to move again.

    NOT the same thing as the game's headcount cap. max_active_minions counts
    BODIES; this counts weighted tokens, where one ogryn elite is worth ten
    poxwalkers. The two scale differently and are not interchangeable.

    The bands are ratios of this number, so changing it here moves all five
    together and they stay in proportion. That is why it is not a setting: the
    weights and the budget are one model, and letting someone move the ceiling
    without the weights produced a readout whose bands matched nothing, with
    no way to tell from the panel that it had been detuned.
--]]
local BUDGET = 70

--[[
    Category order is display order. `w` is the point weight; nil means
    unweighted - counted and shown, but deliberately not added to the total,
    because the model gives monsters and captains no weight and inventing one
    would be a guess presented as a number.
--]]
local CATS = {
    { id = "ogryn",   w = 2.0  },
    { id = "elite",   w = 1.0  },
    { id = "special", w = 1.0  },
    --[[
        Horde and roamer weight: 0.1 -> 0.2 -> 0.3 -> 0.2, budget fixed at 70.

        None of these are source values. The whole weight table is a
        competitive model, and trash was always its softest number - but the
        case for raising it is a measurement, not a preference.

        A real Havoc 40 field, off a screenshot: 14 elites, 7 ogryn elites, 1
        special and NINETY-THREE trash. At 0.1 that read

            38.3 / 50  Standard

        while the team was visibly buried in scab shooters. Trash was 93 of
        the 115 bodies on the map and contributed 9.3 of 38.3 points - eight
        per cent of the score for eighty per cent of the enemies. The number
        that decides whether more can spawn was being driven almost entirely
        by the third of the field that was easiest to see.

        0.3 put the same field at 56.9 / 55 - Capped. That was the right
        reading for THAT field and too hot in general: it tipped ordinary
        fields into Capped as well, and a band that is always on says nothing.

        SETTLED AT 0.2, which puts the screenshot field at

            47.6 / 55  High

        Buried, not over the line. One elite costs what five trash do, so the
        ordering is intact and trash is no longer free, but the top band is
        kept for fields that genuinely have no room left.
    --]]
    { id = "horde",   w = 0.2  },
    { id = "roamer",  w = 0.2  },

    --[[
        OVERRIDE CATEGORIES - counted, reported, and deliberately NOT weighted.

        These spawn outside the entity budget rather than inside it: they
        override the cap instead of consuming it, so folding them into the
        total would inflate a number whose whole purpose is to say how much
        room is left.

          monster    bosses, daemonhosts, houndmaster, and every weakened
                     variant of them (weakened is a health state on the same
                     breed, not a separate breed, so it lands here too)
          captain    captains, including both twins
          ritualist  chaos_mutator_ritualist, cultist_ritualist
          armored    chaos_armored_hound

        chaos_armored_hound is the one that needed catching. It carries
        `special = true` and has no is_boss flag, so tag order alone priced it
        as a 1x special. It is excluded by NAME for that reason - see classify.
    --]]
    { id = "monster",   w = nil },
    { id = "captain",   w = nil },
    { id = "armored",   w = nil },

    --[[
        EXCLUDED - counted for visibility, contributing to NOTHING.

        Different from the unweighted overrides above. Those spawn outside the
        budget but are still part of what the director put on the map, so they
        are reported in the override total. These do not belong to the budget
        conversation at all:

          ritualists (chaos_mutator_ritualist, cultist_ritualist)
              The Dark Communion ritualists are map-specific and spawn
              regardless of anything the team does. cultist_ritualist has
              challenge_rating 0 and no category tag beyond `ritualist`, so it
              never influenced pacing in the first place - including it in a
              budget readout implies a relationship that is not there.

          chaos_mutator_daemonhost
              The Havoc mutator daemonhost. Placed by the mutator, not earned
              by play.

        `skip = true` keeps them out of BOTH the weighted points and the
        override total, so the two numbers that matter stay clean. They are
        still counted and shown separately, because a ritualist on the map is
        a timer you need to know about - it just is not a token you spent.
    --]]
    { id = "excluded",  w = nil, skip = true },
}

Cap.CATS = CATS
Cap.BUDGET = BUDGET

--[[
    Kept as a no-op so the call sites in on_setting_changed do not have to
    care whether the budget is a setting this month.
--]]
function Cap.refresh()
    Cap.BUDGET = BUDGET
end

--[[
    RANGED ELITES, counted by breed.

    The category census counts elites as one number, which is the right shape
    for a budget and the wrong shape for a callout. What a team needs to hear
    is which RANGED pressure is up - gunners, shotgunners, reapers and plasma
    gunners. Maulers, ragers, bulwarks and crushers are melee: they are already
    visible, already being fought, and naming them adds nothing to a chat line.

    Kept as its own small table rather than a breed-level census of everything,
    because only these four groups are ever reported and counting the rest
    would be work nobody reads.
--]]
local RANGED = {
    cultist_gunner          = "gunners",
    renegade_gunner         = "gunners",
    cultist_shocktrooper    = "shotgunners",
    renegade_shocktrooper   = "shotgunners",
    chaos_ogryn_gunner      = "reapers",
    renegade_plasma_gunner  = "plasma",
}

local RANGED_ORDER = { "gunners", "shotgunners", "reapers", "plasma" }

--[[
    MELEE ELITES, the other half of the same question.

    The chat post said "6 gunners, 3 shotgunners" and stopped, which reads as
    "that is the elite pressure" when it is only the part that shoots you. A
    doorway held against four crushers is a completely different problem from
    one held against four reapers, and the fix is different too - back off
    versus break line of sight.

    Every breed with elite = true, split by how it kills you:

        ranged  gunner, shocktrooper, ogryn gunner, plasma gunner
        melee   berzerker, executor, ogryn executor, ogryn bulwark

    renegade_radio_operator is elite = true and is NEITHER - it calls
    reinforcements rather than fighting. Left out of both lists deliberately;
    counting it as melee would overstate the wall in front of you.
--]]
local MELEE = {
    cultist_berzerker      = "ragers",
    renegade_berzerker     = "ragers",
    renegade_executor      = "maulers",
    chaos_ogryn_executor   = "crushers",
    chaos_ogryn_bulwark    = "bulwarks",
}

local MELEE_ORDER = { "ragers", "maulers", "crushers", "bulwarks" }

Cap.MELEE_ORDER = MELEE_ORDER

local melee_counts = { ragers = 0, maulers = 0, crushers = 0, bulwarks = 0 }
local melee_units = {}

function Cap.melee_counts()
    return melee_counts
end

Cap.RANGED_ORDER = RANGED_ORDER

local ranged_counts = { gunners = 0, shotgunners = 0, reapers = 0, plasma = 0 }

-- unit -> ranged group, for units that are one
local ranged_units = {}

function Cap.ranged()
    return ranged_counts
end

-- unit -> category id
local units = {}

-- category id -> live count
local counts = {}
for i = 1, #CATS do
    counts[CATS[i].id] = 0
end

--[[
    Classification order matters.

    monster is tested FIRST: chaos_ogryn_houndmaster carries both `monster` and
    `ogryn`, and it is a monster, not a 2x elite. Testing ogryn first would
    price a houndmaster as two elites.

    ogryn-elite before plain elite for the same reason in reverse - the three
    ogryn elites carry both tags and the 2x branch has to win.
--]]
--[[
    Breeds excluded by NAME rather than by tag.

    chaos_armored_hound is tagged `special` with no is_boss flag, so every
    tag-based test prices it as a 1x special. It spawns outside the budget like
    the other overrides, so it has to be pulled out explicitly.

    A name list is normally the wrong tool - see the long note above about why
    tags beat hardcoded lists - but this is the narrow case it is right for:
    one breed whose tags genuinely do not describe how it is budgeted.
--]]
local BY_NAME = {
    chaos_armored_hound = "armored",

    --[[
        chaos_mutator_daemonhost carries EXACTLY the same tags as
        chaos_daemonhost - minion, monster, witch - and the same challenge
        rating of 20. There is no tag that separates them, so the breed name is
        the only available discriminator. The plain daemonhost stays in the
        override total; only the mutator-placed one is excluded.
    --]]
    chaos_mutator_daemonhost = "excluded",

    --[[
        TWINS, excluded at request.

        Both carry `captain`, so tag classification counted them as two
        captains inside the budget. They are a scripted encounter placed by
        the twins mutator rather than director output competing for the cap,
        so they belong with the other overrides that spawn outside it.

        BOTH names are needed. renegade_twin_captain_two is a separate breed,
        not a second instance of the first - clean_breed_name in the enemy
        tracker folds them for DISPLAY, but the census sees the raw names and
        would otherwise catch only one of the pair. That also explains the
        report of twins counting as a single captain.
    --]]
    renegade_twin_captain = "excluded",
    renegade_twin_captain_two = "excluded",
}

local function classify(breed)
    local tags = breed and breed.tags
    if not tags then
        return nil
    end

    --[[
        Name check FIRST, so it wins over the tag it contradicts.
    --]]
    local named = breed.name and BY_NAME[breed.name]
    if named then
        return named
    end

    --[[
        ANY ritualist, by tag rather than by name, so a ritualist added in a
        future patch is excluded automatically instead of silently joining the
        budget. Tested before the category tags below for the same reason the
        name check comes first: this overrides whatever else the breed claims
        to be.
    --]]
    if tags.ritualist then
        return "excluded"
    end

    --[[
        Order matters beyond that.

        monster before ogryn: chaos_ogryn_houndmaster carries both `monster`
        and `ogryn`, and it is a monster - testing ogryn first would price a
        houndmaster as two elites.

        captain before anything else it might also carry: both twins are
        `captain` + `minion` and is_boss.

        ritualist last of the overrides: the ritualists carry only `minion` and
        `ritualist`, no category tag at all, so before this existed they
        classified as nil and were invisible rather than merely unweighted.

        ogryn-elite before plain elite, so the 2x branch wins for breeds
        carrying both.
    --]]
    if tags.monster then
        return "monster"
    end

    if tags.captain then
        return "captain"
    end


    if tags.elite then
        return tags.ogryn and "ogryn" or "elite"
    end

    if tags.special then
        return "special"
    end

    if tags.horde then
        return "horde"
    end

    if tags.roamer then
        return "roamer"
    end

    return nil
end

Cap.classify = classify

local function breed_of(unit)
    local ext = ScriptUnit.has_extension(unit, "unit_data_system")
        and ScriptUnit.extension(unit, "unit_data_system") or nil

    if not ext or not ext.breed then
        return nil
    end

    local ok, breed = pcall(ext.breed, ext)
    return ok and breed or nil
end

function Cap.add(unit)
    if not unit or units[unit] then
        return
    end

    local breed = breed_of(unit)
    local cat = classify(breed)

    if not cat then
        return
    end

    units[unit] = cat
    counts[cat] = counts[cat] + 1

    --[[
        Tracked per unit as well as counted, so removal can decrement the right
        group without re-reading a breed off a unit that may already be gone.
    --]]
    local group = breed.name and RANGED[breed.name]

    if group then
        ranged_units[unit] = group
        ranged_counts[group] = ranged_counts[group] + 1
    end

    local mgroup = breed.name and MELEE[breed.name]

    if mgroup then
        melee_units[unit] = mgroup
        melee_counts[mgroup] = melee_counts[mgroup] + 1
    end

    --[[
        SPECIAL SPAWN EDGE, fired here.

        This is the exact frame the unit appears. Edge-detecting from the 4Hz
        census output instead would report a surge up to a quarter second late,
        and the surge window is only five seconds wide - a 5% error on the one
        measurement the surge test depends on.
    --]]
    --[[
        Feed the spawn banner for the two categories worth calling out. Horde
        and roamers are deliberately excluded - they arrive constantly and
        would flush anything useful off the feed within a second.
    --]]
    if mod.Cascade and mod.Cascade.log_spawn
        and (cat == "special" or cat == "elite" or cat == "ogryn") then
        pcall(mod.Cascade.log_spawn, breed.name, cat)
    end

    --[[
        Ritual daemonhosts. chaos_mutator_daemonhost is the composition breed
        for mutator_havoc_chaos_rituals, and it is excluded from the budget -
        so it is counted here for the ritual tally rather than in the census.
    --]]
    if cat == "excluded" and breed.name == "chaos_mutator_daemonhost"
        and mod.Cascade and mod.Cascade.ritual_spawned then
        pcall(mod.Cascade.ritual_spawned)
    end

    --[[
        NOTIFICATION EDGES.

        Fired here rather than from the census, because this is the frame the
        unit actually appears - the 4Hz census would report an elite pack up
        to a quarter of a second after it landed, and the whole value of a
        notification is that it coincides with the thing it names.

        Elites notify on the pack, not the individual. One mauler is not an
        event; four arriving together is, and the cascade's own wave detector
        is what decides where that line sits.
    --]]
    if mod.Cascade and mod.Cascade.notify then
        if cat == "elite" or cat == "ogryn" then
            pcall(mod.Cascade.elite_spawned)
        elseif cat == "monster" then
            pcall(mod.Cascade.notify, "BOSS")
        end
    end

    if mod.Cascade then
        if cat == "special" then
            pcall(mod.Cascade.special_spawned)
        --[[
            DELIBERATE SIDE EFFECT of excluding chaos_mutator_daemonhost: it no
            longer classifies as "monster", so it does not reach this branch
            and does not reset the weakened-boss ramp.

            That is correct. The ramp models weakened monstrosities arriving as
            an outcome of the specialist cascade. A mutator-placed daemonhost is
            neither earned by play nor produced by the cascade, so treating its
            arrival as a ramp reset would zero the percentage for something the
            team did not cause. The plain chaos_daemonhost still counts.
        --]]
        elseif cat == "monster" then
            --[[
                Monstrosity spawn edge. The cascade decides whether it was
                weakened and resets its ramp if so - checked HERE because this
                is the frame the unit appears, and the health extension it has
                to read is valid now. Deferring to the 4Hz census would risk
                reading a unit mid-initialisation.
            --]]
            -- breed.name passed too: the weakened check needs it to tell a
            -- weakenable monstrosity from a daemonhost that merely has
            -- is_boss set. See HavocTracker_breeds.lua, WEAKENED_BREEDS.
            pcall(mod.Cascade.monster_spawned, unit, breed.name)

            --[[
                Every monstrosity spawn is a forced-horde event
                (force_horde_on_spawn -> force_horde_pacing_spawn). Watching
                whether the horde follows turns "no horde with a boss" from a
                rule of thumb into a cap measurement.
            --]]
            if mod.Cascade.forced_horde_expected then
                pcall(mod.Cascade.forced_horde_expected, "monster")
            end
        end
    end
end

function Cap.remove(unit)
    local group = ranged_units[unit]

    if group then
        ranged_units[unit] = nil
        ranged_counts[group] = ranged_counts[group] > 0 and ranged_counts[group] - 1 or 0
    end

    -- Melee tally decremented on the same edge, from its own per-unit map, so
    -- the two cannot drift apart when one of them misses a removal.
    local mgroup = melee_units[unit]

    if mgroup then
        melee_units[unit] = nil
        melee_counts[mgroup] = melee_counts[mgroup] > 0 and melee_counts[mgroup] - 1 or 0
    end

    local cat = units[unit]
    if not cat then
        return
    end

    units[unit] = nil
    counts[cat] = counts[cat] > 0 and counts[cat] - 1 or 0
end

function Cap.reset()
    units = {}
    ranged_units = {}
    melee_units = {}

    for i = 1, #RANGED_ORDER do
        ranged_counts[RANGED_ORDER[i]] = 0
    end

    for i = 1, #MELEE_ORDER do
        melee_counts[MELEE_ORDER[i]] = 0
    end

    for i = 1, #CATS do
        counts[CATS[i].id] = 0
    end
end

--[[
    Reconcile against the engine's alive table.

    Death hooks get missed - a unit despawned without dying, a level transition,
    a hook that did not fire - and an increment-only counter drifts upward
    forever. HavocTracker's own census learned this the hard way in the opposite
    direction, where dropping unmeasurable units sent challenge rating to zero
    and it never recovered.

    Called from the 4Hz board tick, not per frame.
--]]
function Cap.reconcile()
    local ALIVE = rawget(_G, "HEALTH_ALIVE")
    if not ALIVE then
        return
    end

    for unit, cat in pairs(units) do
        if not ALIVE[unit] then
            units[unit] = nil
            counts[cat] = counts[cat] > 0 and counts[cat] - 1 or 0

            -- Same prune for the ranged tally, or it drifts upward exactly the
            -- way the category counts would without this pass.
            local group = ranged_units[unit]

            if group then
                ranged_units[unit] = nil
                ranged_counts[group] = ranged_counts[group] > 0 and ranged_counts[group] - 1 or 0
            end

            local mgroup = melee_units[unit]

            if mgroup then
                melee_units[unit] = nil
                melee_counts[mgroup] = melee_counts[mgroup] > 0 and melee_counts[mgroup] - 1 or 0
            end
        end
    end
end

--[[
    The weighted total, plus every component count.

    Returns a table that is REUSED between calls. This is read from the HUD
    rebuild path, and allocating a fresh table per read on a repeating path is
    exactly how the colour-picker leak took the game from 59 to 15 fps.
--]]
--[[
    budget starts at 0, NOT at a number that looks plausible.

    It used to be initialised to 50 and read() never assigned it, so the field
    was a permanent 50 no matter what BUDGET said. Every change to the ceiling
    - 45, 50, 55, 68, 70 - was dead code, because the panel and the bands both
    read cap.budget rather than the constant.

    That is also why the readout sat at "capped" after the 2026-09-29 patch:
    the ceiling had never actually moved off 50.

    Zero is the right initial value precisely because it is obviously wrong. A
    plausible-looking default is what hid this for four revisions; a 0 would
    have shown up as "x / 0" the first time anyone looked.
--]]
local out = {
    points = 0, budget = 0, over = false,
    ogryn = 0, elite = 0, special = 0, horde = 0, roamer = 0,
    monster = 0, captain = 0, armored = 0, excluded = 0,
    unweighted = 0,
}

function Cap.read()
    local points = 0
    local unweighted = 0
    local excluded = 0

    for i = 1, #CATS do
        local c = CATS[i]
        local n = counts[c.id] or 0

        out[c.id] = n

        if c.skip then
            -- Contributes to neither total. Reported only.
            excluded = excluded + n
        elseif c.w then
            points = points + n * c.w
        else
            unweighted = unweighted + n
        end
    end

    --[[
        Clamped, and loudly.

        Both decrement sites already guard against going below zero, so a
        negative total should be impossible - which is exactly why it is worth
        catching rather than assuming. A negative count on screen means the
        bookkeeping has drifted, and silently clamping it would hide the drift
        while showing a number that is merely less obviously wrong.
    --]]
    if points < 0 or unweighted < 0 or excluded < 0 then
        if not Cap._warned_negative then
            Cap._warned_negative = true
            mod:echo(string.format(
                "[HavocTracker] census went negative (pts %.1f, out %d, excl %d) - please report",
                points, unweighted, excluded))
        end

        points = points < 0 and 0 or points
        unweighted = unweighted < 0 and 0 or unweighted
        excluded = excluded < 0 and 0 or excluded
    end

    out.points = points

    --[[
        THE LINE THAT WAS MISSING. Everything downstream - the verdict text and
        all five bands - reads cap.budget, so without this the constant above
        never reached the screen.
    --]]
    out.budget = BUDGET
    out.unweighted = unweighted
    out.excluded = excluded
    out.over = points >= BUDGET

    return out
end

-- ---------------------------------------------------------------------------
-- CROSS-CHECK AGAINST QIangIQsGeneralEnemyTracker
-- ---------------------------------------------------------------------------

--[[
    A SECOND OPINION, NOT A SOURCE OF TRUTH. This deliberately does not feed
    the display.

    Its counts are gated (QIangIQsGeneralEnemyTracker.lua:566):

        record_unit_spawn = function(breed_name, unit)
            local tracked_notif   = ...notif_breeds.inv_table[breed_name]
            local tracked_overlay = ...overlay_breeds.inv_table[breed_name]
            if tracked_notif or tracked_overlay then
                table.insert(...)
                refresh_unit_count(breed_name)
            end

    unit_count is maintained ONLY for breeds enabled for notifications or the
    overlay in that mod's own settings. Anything switched off there reads 0
    forever. Driving the cap from it would mean the number silently changes
    meaning when an unrelated mod's settings change.

    It is still worth reading, because a disagreement means one of the two
    implementations is wrong and I would rather find out from a log line than
    from a bad call in a mission.

    NOTE the breed-name mismatch: that mod cleans `renegade_flamer` and
    `cultist_flamer` into a single `flamer` key, so a per-breed comparison has
    to fold ours the same way before comparing.
--]]
local FOLD = {
    renegade_flamer = "flamer",
    cultist_flamer  = "flamer",
}

--[[
    OPTIONAL, AND THE ONLY REMAINING REFERENCE TO ANOTHER MOD.

    This is a diagnostic second opinion. It does NOT feed the display, the cap
    total, or anything else - the census is authoritative on its own. If
    QIangIQsGeneralEnemyTracker is absent it returns nil and nothing else
    changes, which is what makes this mod genuinely standalone rather than
    standalone-if-you-squint.

    Kept because a disagreement between two independent counts is worth
    knowing about, and finding out from a log line beats finding out from a bad
    call mid-mission.
--]]
function Cap.crosscheck()
    local other = get_mod and get_mod("QIangIQsGeneralEnemyTracker")
    if not other or not other.tracked_units then
        return nil
    end

    local uc = other.tracked_units.unit_count
    if type(uc) ~= "table" then
        return nil
    end

    -- Sum their counts into our categories, so the comparison is like for like.
    local Breeds = rawget(_G, "Breeds")
    if not Breeds then
        return nil
    end

    local theirs = {}
    local untracked = nil

    for breed_name, n in pairs(uc) do
        local breed = Breeds[breed_name]
        local cat = classify(breed)

        if cat then
            theirs[cat] = (theirs[cat] or 0) + (n or 0)
        end
    end

    --[[
        Which breeds they are NOT counting.

        This is the actionable half. If an elite is switched off in their
        settings it contributes 0 to their total, and saying WHICH one turns a
        confusing delta into a one-line fix.
    --]]
    local notif = other.tracked_units.notif_breeds
    local overlay = other.tracked_units.overlay_breeds

    if notif and overlay and notif.inv_table and overlay.inv_table then
        for breed_name, breed in pairs(Breeds) do
            local cat = classify(breed)

            if cat == "elite" or cat == "ogryn" or cat == "special" then
                local key = FOLD[breed_name] or breed_name

                if not notif.inv_table[key] and not overlay.inv_table[key] then
                    untracked = untracked or {}
                    untracked[#untracked + 1] = breed_name
                end
            end
        end
    end

    return theirs, untracked
end

--[[
    One-shot report, from the mission-start path.

    Deliberately loud and deliberately once. A silent dependency on another
    mod's settings is the thing that makes a number wrong without anyone
    noticing.
--]]
local warned = false

function Cap.warn_once()
    if warned then
        return
    end
    warned = true

    local ok, _, untracked = pcall(Cap.crosscheck)

    if not ok then
        return
    end

    if untracked and #untracked > 0 then
        table.sort(untracked)
        mod:echo(string.format(
            "[HavocTracker] %d elite/special breeds are not tracked by GeneralEnemyTracker (its counts read 0 for them). Own census is used, so the cap row is still correct.",
            #untracked))
    end
end

function Cap.clear_warning()
    warned = false
end

mod.Cap = Cap
return Cap
