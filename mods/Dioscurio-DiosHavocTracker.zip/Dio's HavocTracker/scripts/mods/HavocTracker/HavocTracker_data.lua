local mod = get_mod("HavocTracker")

--[[
	OPTIONS TREE
	============

	Rebuilt around one rule: a setting is only on screen while the thing it
	configures is switched on.

	DMF does the hiding itself. mod_options.lua:593 reads

	    if parent.type == "checkbox" then
	        is_visible = get_mod(parent.mod_name):get(parent.setting_id) == true

	so nesting a widget under a CHECKBOX is a functional decision, not a
	cosmetic one - the child disappears while the parent is off. Groups do not
	do this; they are headings and their contents are always drawn. The old
	tree used groups exclusively and put all sixty controls on screen at once.

	WHAT MOVED, AND WHY IT MATTERED

	Everything from chat posting to the entity cap budget used to sit inside
	declutter_group, which is the "Hide HUD" section. That was not a naming
	problem. "Entity cap budget" was filed under Hide HUD, three screens down
	from the readout it governs, and there was no way to guess that from the
	menu. The group had thirty-one children and thirteen of them belonged.

	SETTING IDS ARE UNCHANGED.

	Only positions in the tree moved. DMF keys saved values by setting_id, so
	every existing config carries over untouched - nothing is orphaned and
	nobody is reset to these defaults. That constraint is why this is a
	re-parenting rather than a rename, even where a name could be better.
--]]

--[[
	Repeated widget shapes, so the tree below reads as structure instead of
	punctuation. Written as functions rather than copied tables because a
	shared table would be aliased across every widget that used it, and DMF
	writes into these.
--]]
local function check(id, default, subs)
	return {
		setting_id    = id,
		type          = "checkbox",
		default_value = default,
		tooltip       = id .. "_tooltip",
		sub_widgets   = subs,
	}
end

local function num(id, default, lo, hi, decimals, step)
	return {
		setting_id      = id,
		type            = "numeric",
		default_value   = default,
		range           = { lo, hi },
		decimals_number = decimals or 0,
		step            = step,
		tooltip         = id .. "_tooltip",
	}
end

local function group(id, subs)
	return {
		setting_id  = id,
		type        = "group",
		title       = id,
		sub_widgets = subs,
	}
end

--[[
	========================================================================
	CAPABILITY SURFACE: MATCHED TO THE LAST BUILD KNOWN TO WORK
	========================================================================

	This mod now uses exactly the widget types the last public build
	confirmed working in somebody else's game used, and nothing else:

	    checkbox   numeric   group   keybind

	NO button. NO dropdown. NO collapsed_widgets. Those three were added in
	the settings rewrite, and they are the difference between the build that
	worked for people and the ones that did not. An unknown widget type does
	not get skipped by DMF - options.lua:700-707 gets nil from
	initialize_widget_data and throws, and dmf_mod_manager.lua:181 returns on
	that, so the mod never finishes registering and is absent from the
	settings menu AND the enable/disable list.

	AND THERE IS NO PROBE EITHER, which is the more important half.

	The first attempt at fixing this asked DMF whether it supported those
	types by io_dofile-ing its blueprint table. That file, at file scope,
	pulls in eight nested DMF modules and ten engine requires - ui_renderer,
	ui_font_settings, five pass-template modules - and evaluates
	Color.ui_terminal() and UIFontSettings lookups. All from inside new_mod,
	during early boot, long before the options view exists.

	The same probe in Handholder is what started breaking another player's
	SoloPlay. Asking a yes/no question by constructing a third of the
	settings UI is not a probe; it is a side effect that returns a boolean.

	WHAT THE TWO REMOVED CONTROLS COST, and where they went:

	    reset button    -> /htreset, which already existed and does more
	    preset dropdown -> /htpreset minimal|standard|everything

	Chat commands cost nothing at load and cannot take the mod down with
	them. If the widget types are ever confirmed safe on the machines this
	ships to, they can come back - but that confirmation has to come from
	somebody else's game, not from this one.
--]]

local WIDGETS = {
			--[[
				MINIMAL IS WHAT SHIPS.

				The defaults below are the Minimal preset: the entity cap
				block, the verdict and nothing else. The spawn panel, the
				beacons, the path line and the specialist cascade all start
				off, and the preset dropdown above turns any of it back on in
				one click.

				This is a change of DEFAULT only. DMF writes a default solely
				for a setting that has never been written (options.lua:720),
				so anyone with a saved config keeps every value they had -
				nobody's panel goes quiet because of this.

				THE MASTER SWITCH, and the parent of everything it draws.

				Unticking this hides the overlay AND collapses every setting
				that describes it, which is the shortest path from "I do not
				want this on screen" to a menu that is one line long.
			--]]
			check("show_overlay", true, {
				{
					setting_id      = "toggle_overlay_key",
					type            = "keybind",
					default_value   = {},
					keybind_global  = false,
					keybind_trigger = "pressed",
					keybind_type    = "function_call",
					function_name   = "toggle_overlay",
					tooltip         = "toggle_overlay_key_tooltip",
				},

				--[[
					Position and size of the tracker panel itself. These are
					the three people reach for first and they are now the
					three nearest the top.
				--]]
				num("hud_offset_x", -700, -1200, 1200, 0, 10),
				num("hud_offset_y", -260, -700, 700, 0, 10),
				num("hud_scale", 1, 0.5, 6, 2, 0.1),
				num("panel_opacity", 30, 0, 100, 0),

				--[[
					THE READOUT ITSELF - what the panel says, as opposed to
					where it sits. These were scattered across Hide HUD.
				--]]
				{
					setting_id    = "hud_mode",
					type          = "dropdown",
					default_value = "cap_only",
					options = {
						{ text = "hud_mode_cap_only", value = "cap_only" },
						{ text = "hud_mode_full",     value = "full" },
					},
					tooltip = "hud_mode_tooltip",
				},
				check("show_cascade", false),

				--[[
					The three that decide how much the cap block says. All
					read on rebuild through cached accessors, never through
					mod:get on the draw path.

					cap_compact defaults FALSE, so the five-row block stays
					the default. It is the layout people have been reading and
					the one that is easiest to scan between fights; the single
					line is for anyone who wants the panel out of the way.
				--]]
				check("show_headcount", false),
				check("show_notifications", true),
				check("cap_compact", false),

				num("cap_opacity", 150, 40, 255, 0),

				--[[
					Panel geometry, nested one level deeper because it is the
					tuning layer rather than the thing itself. These apply
					live now - see rebuild_geometry in HavocTracker.lua - so
					the "next reload" warning that used to be in their
					tooltips is gone.
				--]]
				group("geometry_group", {
					num("panel_width", 360, 180, 640, 0),
					num("panel_row_height", 19, 14, 34, 0),
					num("panel_section_gap", 3, 0, 20, 0),
				}),

				--[[
					THE SPAWN PANEL owns its own subtree. Seven settings that
					describe a panel nobody who has turned it off wants to
					scroll past.
				--]]
				check("show_spawn_panel", false, {
					num("spawn_scale", 2, 0.5, 8, 2, 0.1),
					num("spawn_offset_x", 640, -1200, 1200, 0, 10),
					num("spawn_offset_y", -260, -700, 700, 0, 10),
					check("show_spawn_walls", false),
					check("spawn_audio_cue", false),
				}),

				--[[
					IN-WORLD MARKERS are separate from the spawn panel: the
					beacons stay useful with the panel off, and several people
					run exactly that way.
				--]]
				check("show_path_line", false, {
					num("path_marker_scale", 1, 0.5, 6, 2, 0.1),
				}),
				check("show_ritual_markers", false),

				--[[
					Collapses the specific breed on each trigger into BOSS.
					Twins, daemonhosts, rituals and patrols keep their own
					names - each of those is a different action, and folding a
					daemonhost in with a fight is the substitution that gets
					someone killed.
				--]]
				check("simple_labels", true),
				num("spawn_marker_scale", 2, 0.5, 6, 2, 0.1),
				num("spawn_marker_opacity", 42, 5, 100, 0),
			}),

			--[[
				HIDE HUD - and now only Hide HUD.

				The keep_* list is nested under keep_base_hud's inverse rather
				than under a checkbox of its own, because there is no setting
				that means "I am using the keeps". They stay in a group.
			--]]
			--[[
				PUNISHMENT LINES IN THE WORLD. Top level on purpose: they are
				not part of the panel, so switching the panel off with
				show_overlay must not take them with it.
			--]]
			check("pace_markers", true, {
				check("pace_marker_speed", true),
				check("pace_marker_rush", true),
				check("pace_marker_backtrack", true),
				num("pace_marker_scale", 1.5, 0.5, 4, 1, 0.1),
			}),

			group("declutter_group", {
				{
					setting_id      = "toggle_hud_key",
					type            = "keybind",
					default_value   = {},
					keybind_global  = false,
					keybind_trigger = "pressed",
					keybind_type    = "function_call",
					function_name   = "toggle_hud",
					tooltip         = "toggle_hud_key_tooltip",
				},

				--[[
					The switch most people actually want, and the one the
					keeps below are conditional on. Moved to the TOP of the
					group from the bottom of a thirty-one item list: the
					keep_* options only mean anything while this is off, so
					reading them first and finding that out afterwards was
					backwards.
				--]]
				check("keep_base_hud", true),

				--[[
					Every keep option defaults OFF: the key clears the screen
					completely, and you add back only what you want.
				--]]
				group("keeps_group", {
					check("keep_crosshair", false),
					check("keep_vitals", false),
					check("keep_interact", false),
					check("keep_team", false),
					check("keep_boss", false),
					check("keep_objective", false),
					check("keep_buffs", false),
					check("keep_tags", false),
					check("keep_chat", false),
					check("keep_tracker", false),
					check("keep_spawn_panel", false),
					check("keep_markers", false),
				}),

				--[[
					OUTLINES AND HAZARD DECALS are not HUD elements, so the
					visibility gate above cannot touch them. They are the
					loudest thing left on screen once the HUD is gone, and
					they needed their own switches.

					The radius nests under the checkbox that enables it, which
					is the one pairing in this whole file where the dependency
					was already obvious and still was not expressed.
				--]]
				check("clean_limit_outlines", true, {
					num("clean_outline_radius", 20, 3, 80, 0),
				}),
				check("clean_hide_dangerzones", true),
				check("clean_hide_weakspots", true),

				--[[
					In-world markers added by mods - this mod's boss, twins and
					patrol skulls, the path line, Handholder's health markers.

					Separate from keep_markers on purpose. Those markers live
					INSIDE the game's own world-marker element, so keep_markers
					can only take the whole element - pings and objective
					markers with it - and keep_base_hud overrides it anyway.
					This drops the mod markers and leaves every vanilla one
					alone.
				--]]
				check("clean_hide_mod_markers", true),
			}),

			--[[
				CHAT - the game's chat box, and this mod's output into it.
				Two different things that both concern chat, which is why they
				were never going to be found in a section called Hide HUD.
			--]]
			group("chat_group", {
				check("chat_scale_enabled", true, {
					num("chat_scale", 1, 0.5, 4, 2, 0.1),
				}),

				--[[
					CHAT OUTPUT.

					chat_post is the button: switch it on and the readout goes
					to STRIKE TEAM chat on the interval below, so the whole
					team can read it. That is the point of the feature, and
					every setting that shapes it is nested under it - there is
					no reason to show a posting interval to someone who is not
					posting.

					chat_post_preview is an opt-in TESTING mode that prints to
					your own console instead of sending, for checking the
					format. Off by default.
				--]]
				check("chat_post", false, {
					num("chat_post_interval", 10, 5, 120, 0),
					check("chat_post_events", true),
					check("chat_post_status", true),
					check("chat_post_preview", false),
				}),
			}),

			--[[
				ADVANCED - estimation and cost. Correct defaults, and nothing
				here is worth touching without a reason, so it sits last.
			--]]
			group("advanced_group", {
				check("use_aggro_estimate", true, {
					num("aggro_multiplier", 2, 1, 4, 1, 0.1),
				}),
				check("enable_prediction", true),
				check("spawn_accuracy_log", true),
				num("census_interval", 0.25, 0.1, 2, 2),
				num("path_interval", 0.1, 0.05, 1, 2),
			}),

			--[[
				RESET, last and on its own.

				A button rather than a checkbox because it is an action, and
				DMF supports the type (blueprints.lua:149). It exists because
				dragging the overlay off screen used to be recoverable only
				via /htreset, which nobody knows about until they need it and
				cannot find it.
			--]]
}

--[[
	Assembled last, so the tree above can be written plainly and the
	compatibility work happens in one place rather than as a condition on
	every widget.
--]]
local options = { widgets = WIDGETS }

return {
	name            = mod:localize("mod_name"),
	description     = mod:localize("mod_description"),
	is_togglable    = true,
	allow_rehooking = true,
	options         = options,
}
