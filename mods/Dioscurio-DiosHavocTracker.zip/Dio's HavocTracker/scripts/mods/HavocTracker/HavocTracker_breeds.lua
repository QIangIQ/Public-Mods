local mod = get_mod("HavocTracker")

--[[
    BREED CLASSIFICATION - PORTED VERBATIM
    ======================================

    Ported from QIangIQsGeneralEnemyTracker (QIangIQsGeneralEnemyTracker_data.lua,
    util.is_monster / util.clean_breed_name / util.is_weakened).

    WHY THIS FILE EXISTS. The cascade called that mod's util.is_weakened
    through get_mod("QIangIQsGeneralEnemyTracker"), which made the weakened
    boss feature silently dependent on another mod being installed AND enabled.
    Anyone downloading this mod on its own got a ramp that never reset.

    The three functions below are the original code, unchanged. Their comments
    are theirs. They are NOT reimplemented or tidied, for one specific reason:
    util.is_weakened encodes a Havoc detail that is easy to get wrong and whose
    failure mode is silent - in Havoc the modify_monster_health modifier scales
    every monstrosity's health, so a naive `max_health < initial_max_health`
    marks EVERY monster weakened. The havoc branch is the whole value of the
    function. Paraphrasing it would mean re-deriving that, and being wrong
    would not announce itself.

    is_monster and clean_breed_name come along because is_weakened's behaviour
    is only meaningful alongside them - clean_breed_name is what produces the
    "_wk" suffix the rest of that mod keys on.

    The one thing this file adds is a GATE around the port, kept separate from
    the ported code, at the bottom. See WEAKENED_BREEDS.
--]]

local Breeds_ref = nil

local function Breeds_table()
    if not Breeds_ref then
        Breeds_ref = rawget(_G, "Breeds")
    end
    return Breeds_ref
end

local util = {}

-- ---------------------------------------------------------------------------
-- BEGIN PORTED CODE - QIangIQsGeneralEnemyTracker, author QIangIQ
-- Unmodified except for `Breeds` being fetched lazily rather than read as a
-- file-scope global, because capturing engine globals at mod load yields nil.
-- ---------------------------------------------------------------------------

util.is_monster = function(clean_brd_name)
    local Breeds = Breeds_table()
    -- NB: We check if Breeds[clean_brd_name] exists in case the *clean* breed name is, for instance "flamer" which isn't a valid breed
    --if Breeds[clean_brd_name] and Breeds[clean_brd_name].tags and Breeds[clean_brd_name].tags.monster then
    if Breeds[clean_brd_name] and Breeds[clean_brd_name].is_boss then
        return true
    else
        return string.match(clean_brd_name, "(.+)_wk")
    end
end

util.clean_breed_name = function(breed_name, is_weakened)
    local breed_name_no_mutator_marker = string.match(breed_name, "(.+)_mutator$") or breed_name
    local is_monster = util.is_monster(breed_name_no_mutator_marker)
    if string.match(breed_name_no_mutator_marker, "(.+)_flamer") then
        return "flamer"
    elseif breed_name_no_mutator_marker == "cultist_captain" then
        return "renegade_captain"
    elseif breed_name_no_mutator_marker == "renegade_twin_captain_two" then
        return "renegade_twin_captain"
    else
        if is_monster and is_weakened then
            return breed_name_no_mutator_marker.."_wk"
        else
            return breed_name_no_mutator_marker
        end
    end
end

util.is_weakened = function(unit)
    local unit_data_ext = ScriptUnit.extension(unit, "unit_data_system")
    local breed = unit_data_ext and unit_data_ext:breed()
    local is_weakened = false

    if not breed then
        --mod:echo("Error: breed = nil")
        return is_weakened
    end

    if not breed.is_boss or breed.ignore_weakened_boss_name then
        return is_weakened
    end

    local health_extension = ScriptUnit.extension(unit, "health_system")
    local max_health = health_extension and health_extension:max_health()
    local initial_max_health = max_health and math.floor(Managers.state.difficulty:get_minion_max_health(breed.name))

    if not initial_max_health then
        return is_weakened
    end

    if max_health < initial_max_health then
        is_weakened = true
    else
        local is_havoc = Managers.state.difficulty:get_parsed_havoc_data()
        if is_havoc then
            local havoc_extension = Managers.state.game_mode:game_mode():extension("havoc")
            local havoc_health_override_value = havoc_extension:get_modifier_value("modify_monster_health")

            if havoc_health_override_value then
                local multiplied_max_health = initial_max_health + initial_max_health * havoc_health_override_value

                if max_health < multiplied_max_health then
                    is_weakened = true
                end
            end
        end
    end

    return is_weakened
end

-- ---------------------------------------------------------------------------
-- END PORTED CODE
-- ---------------------------------------------------------------------------

local Breeds = {}

Breeds.util = util

--[[
    WHICH BREEDS CAN ACTUALLY BE WEAKENED. THE FALSE-POSITIVE FIX.

    Reported symptom: the tracker said a weakened boss had spawned when none
    had, resetting the ramp for nothing.

    Cause: the ported is_weakened gates on

        if not breed.is_boss or breed.ignore_weakened_boss_name then

    and in this game build ALL SIX monster-tagged breeds have is_boss = true
    with ignore_weakened_boss_name unset:

        chaos_beast_of_nurgle      chaos_daemonhost
        chaos_plague_ogryn         chaos_mutator_daemonhost
        chaos_spawn                chaos_ogryn_houndmaster

    So a daemonhost or a houndmaster passes the gate and goes on to the health
    comparison, where any mismatch against get_minion_max_health reports it
    weakened. But only THREE of those have a weakened form at all - the source
    mod's own trackable list names exactly three "_wk" variants:

        chaos_beast_of_nurgle_wk
        chaos_plague_ogryn_wk
        chaos_spawn_wk

    A daemonhost has no weakened variant, so any "weakened daemonhost" is by
    definition a misread.

    THIS GATE IS DELIBERATELY OUTSIDE THE PORTED FUNCTION. Editing their code
    would mean the port is no longer their code, and the next person could not
    diff it against the original to see what changed. The restriction is this
    mod's decision, so it lives in this mod's wrapper.
--]]
local WEAKENED_BREEDS = {
    chaos_beast_of_nurgle = true,
    chaos_plague_ogryn    = true,
    chaos_spawn           = true,
}

Breeds.WEAKENED_BREEDS = WEAKENED_BREEDS

--[[
    True only for a monstrosity that (a) can be weakened at all, and (b) the
    ported check says is.

    pcall'd because is_weakened reaches into three managers -
    Managers.state.difficulty, Managers.state.game_mode and the havoc
    extension - any of which can be absent outside a Havoc mission.
--]]
function Breeds.is_weakened(unit, breed_name)
    if not unit then
        return false
    end

    if breed_name and not WEAKENED_BREEDS[breed_name] then
        return false
    end

    local ok, result = pcall(util.is_weakened, unit)
    return (ok and result) and true or false
end

mod.Breeds = Breeds
return Breeds
