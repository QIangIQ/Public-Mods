local mod = get_mod("HavocTracker")

--[[
    SPECIALIST CASCADE
    ==================

    The cascade is both the long-term process and the short-term punishment
    waves. Model as described:

      * On crossing into a room, a timer starts. On elapse a specialist wave
        spawns and the next timer starts, walking this pattern:

            45, 30, 15, 15, 15, 5, 5, 5, 5, 5

      * Each wave is a MINIMUM of five specials; anything beyond that is
        trickle carried over from previous spawns. So the tail of the pattern
        is five specials every five seconds.

      * Breaking coherency - down, death, disconnect, or distance - pushes
        spawns into the next wave IMMEDIATELY and accelerates the timer.

      * Crossing into a new room resets the timer. The first wave of a room is
        always expected around 45 seconds after entry.

    ------------------------------------------------------------------------
    WHAT IS MODELLED HERE AND WHAT IS NOT
    ------------------------------------------------------------------------

    This is a MODEL of observed behaviour, not a reading of engine state. The
    wave pattern, the acceleration and the surge curve came from play, not from
    source. That distinction is kept visible in the readout: predicted values
    are marked, and the two things actually measured - specials currently alive
    and specials that spawned in the last five seconds - are shown as counts,
    not predictions.

    The reason to be strict about this: HavocTracker already earned trust by
    reporting the entity cap from PacingManager's real HARD_ALLOCATED_LIMIT.
    Mixing a modelled number into the same panel without labelling it would
    spend that trust on a guess.
--]]

local Cascade = {}

local math_log = math.log
local math_min = math.min
local math_max = math.max

--[[
    The pattern. One 45, one 30, three 15s, five 5s.

    Past the end it HOLDS at the final value rather than wrapping - the tail is
    the steady state, and wrapping back to 45 would predict a lull that does
    not come.
--]]
local WAVE_PATTERN = { 45, 30, 15, 15, 15, 5, 5, 5, 5, 5 }

--[[
    WAVE DETECTION: five or more specials inside five seconds.

    CORRECTED. I lowered this to 3 on the reasoning that the early 45s and 30s
    waves deliver their specials spread over more than five seconds. That was
    wrong, and it was wrong in a way that mattered: five-in-five IS the wave
    signal, at every stage of the pattern. Lowering it would have reported
    ordinary trickle and punishment spawns as waves, which is worse than
    reporting nothing - a tracker that cries wave at every third special is
    actively misleading.

    The real reason nothing was detected is not the threshold. See the room
    gate below.
--]]
local MIN_WAVE_SPECIALS = 5

-- The stated wave minimum, used for reporting rather than detection.
local STATED_WAVE_SIZE = 5

--[[
    Coherency-break acceleration.

    "Accelerated by 300%" is ambiguous - it reads as either 3x speed or +300%
    (4x). Implemented as 3.0 because that is the more common usage, and kept as
    a single named constant so it is one edit if a run says otherwise rather
    than a number buried in an expression.
--]]
local BREAK_ACCEL = 3.0

--[[
    Surge: MORE than this many specials inside the window.

    AN OFF-BY-ONE THAT HID THE BOSS PERCENTAGE. A wave is detected at
    in_window >= 5 and a surge at in_window > 5, so a wave of exactly five -
    the stated minimum, and therefore the most common wave - never started a
    surge. The weakened ramp only begins on a surge, so the percentage row had
    nothing to show for most of a mission.

    The threshold itself is right ("exceeding five specials"), so it is left
    alone. What changed is that the ramp no longer depends solely on it - see
    ramp_start below.
--]]
local SURGE_SPECIAL_THRESHOLD = 5
local SURGE_WINDOW = 5.0

-- Havoc 40. Surge duration and the weakened-boss ramp across it.
local SURGE_DURATION = 90.0
local WEAK_BOSS_MIN = 0.05
local WEAK_BOSS_MAX = 0.60

--[[
    Monstrosities awaiting a weakened verdict. Declared up here rather than
    beside the code that uses it so Cascade.reset - which is defined earlier in
    this file - can clear it. A unit handle left in this table across a mission
    boundary is a stale reference to freed memory.
--]]
local pending_monsters = {}   -- unit -> { breed = name, until_t = t }

--[[
    EVERY UNIT THIS MISSION THAT HAS ALREADY BEEN COUNTED AS WEAKENED.

    The count used to be event-driven: whichever path first saw a unit test
    weakened did state.weak_spawns = state.weak_spawns + 1 and relied on the
    paths not overlapping. They were believed not to - the old comment said
    "first positive wins and the unit is dropped; there is no way to double
    count it" - and in a mission where one weakened boss was fought the panel
    reported five.

    Rather than keep arguing about which path fires twice, the count is now
    idempotent PER UNIT. A unit contributes exactly one hit no matter how many
    times, or from how many directions, it is reported:

        monster_spawned's immediate test
        the pending recheck loop, up to WEAK_RECHECK_WINDOW
        Cap.add firing again for a recycled unit handle
        any future caller nobody has thought of yet

    This is the right shape regardless of which of those was the culprit,
    because "how many weakened monstrosities have spawned" is a question about
    UNITS, and a per-unit set is what answers it. The event counter could only
    ever approximate that.

    Cleared by Cascade.reset with the rest of the per-mission state. Unit
    handles die with the level, so carrying them across a mission would be a
    use-after-free as well as wrong.
--]]
local counted_weak = {}

local state = {
    armed         = false,  -- has a wave been detected yet
    wave_index    = 0,      -- waves elapsed this room
    timer         = 0,      -- seconds remaining on the current timer
    accel         = 1.0,    -- current timer multiplier
    breaks        = 0,      -- coherency breaks this room
    downs         = 0,
    deaths        = 0,
    surge_until   = 0,      -- t at which the surge ends, 0 = no surge

    --[[
        WEAKENED BOSS RAMP - its own clock, NOT the surge clock.

        The chance climbs 5% -> 60% over 90 seconds and is rolled PER SPECIALIST
        SPAWN. When a weakened monstrosity actually spawns the chance resets to
        5% and starts climbing again.

        That reset is why this cannot ride on surge_until. The first version
        derived the chance from surge elapsed time, which is wrong in both
        directions: it would keep climbing after a weakened boss had already
        spawned, and it would cap out at the end of the surge rather than
        cycling. Because the roll is per spawn and the clock resets per hit,
        several weakened monstrosities can arrive inside one wave - the model
        has to be able to express that, and a surge-tied ramp cannot.
    --]]
    ramp_start    = nil,    -- t the current 5% -> 60% climb began

    --[[
        ROLLS SINCE THE RAMP STARTED vs ROLLS ALL MISSION.

        state.rolls is deliberately zeroed every time the ramp restarts,
        because "47% across nine rolls" only means anything about the CURRENT
        climb. But that makes it useless for answering "is this counter
        working at all" - right after a weakened boss spawns the honest
        reading is "5%, 0 rolls", which is indistinguishable from a counter
        that never increments. That ambiguity cost a round trip.

        rolls_total never resets inside a mission, so the two together
        separate the two cases: 0 and 0 means nothing is being counted, 0 and
        40 means the ramp just restarted and everything is fine.
    --]]
    rolls_total   = 0,
    rolls         = 0,      -- specialist spawns since the ramp last reset
    queued        = false, -- pattern exhausted; next wave pending, tracking paused

    --[[
        PUNISHMENT IS NOT A WAVE.

        A coherency break, a death, or speedrunning accelerates the NEXT wave
        and also spawns its own punishment specials. Those spawns are not a
        wave start, so counting them as one would advance the pattern on the
        team's mistakes rather than on the director's schedule - and since a
        break also triples the timer, the two errors compound.

        Punishment spawns still count toward the surge, the feed and the
        weakened ramp - they are real specials on the map - but they cannot
        trigger a wave advance.

        SUPPRESSION LASTS UNTIL THE WAVE IT IS QUEUED FOR, not for a fixed
        number of seconds. A fixed 8s grace was arbitrary and wrong at both
        ends: too short if the punishment burst kept arriving, and still
        running after the next wave had already been detected. Tying it to the
        pause means it ends exactly when the next wave becomes due, which is
        the event it was always about.
    --]]
    punished      = false,
    in_progress   = false,  -- clock says a wave is landing, burst not yet seen
    mission_start = nil,    -- gameplay time at mission enter, for the grace window
    cycles        = 0,      -- how many times the pattern has restarted
    cycle_reason  = nil,
    confirmed     = 0,      -- waves whose burst was actually observed

    --[[
        HORDE TIMING.

        last_horde_t is the last time the horde population JUMPED, not the last
        time a poxwalker spawned. A horde is a burst, and single trickle
        spawns between hordes would otherwise keep resetting the clock and the
        counter would never read anything useful.
    --]]
    last_horde_t  = nil,
    horde_peak    = 0,
    horde_prev    = 0,
    rituals       = 0,      -- ritual daemonhosts seen this mission
    forced_at     = nil,    -- when a forced-horde event fired
    forced_kind   = nil,
    forced_base   = nil,    -- horde population at that moment
    forced_result = nil,    -- "filled" | "blocked" | nil
    cap_blocked_at = nil,
    weak_spawns   = 0,      -- weakened monstrosities seen this mission
    spawn_times   = {},     -- rolling special spawn timestamps
    last_wave_t   = nil,
}

Cascade.state = state
Cascade.WAVE_PATTERN = WAVE_PATTERN

--[[
    Gameplay clock, with a fallback.

    "gameplay" is a real registered timer -
    gameplay_init_step_timer.lua:32  Managers.time:register_timer("gameplay", "main", 0)
    - but it is UNREGISTERED on mission cleanup
    (mission_cleanup_utilities.lua:232). Outside a mission the query throws and
    the previous version returned 0.

    Returning 0 is the dangerous answer, not a safe one: every timestamp
    becomes 0, so the five-second window never expires, the spawn list grows
    without bound, and burst_consumed latches on the first burst and never
    clears - which stops wave detection dead for the rest of the session. A
    clock that silently reads zero breaks everything downstream of it.

    "main" is always registered, so it is the fallback. SlotZones does the same
    thing (markers.lua:34, Managers.time:time("main") with an os.clock
    fallback).
--]]
local function now()
    local tm = Managers.time
    if not tm or not tm.time then
        return 0
    end

    local ok, t = pcall(tm.time, tm, "gameplay")
    if ok and type(t) == "number" then
        return t
    end

    ok, t = pcall(tm.time, tm, "main")
    if ok and type(t) == "number" then
        return t
    end

    return 0
end

--[[
    Seconds the timer for a given wave index starts at, or nil past the end.

    THE BUG THIS FIXES: this used to clamp with math_min, so asking for wave 11
    returned WAVE_PATTERN[10]. Combined with the timer restarting on every
    elapse, the cascade rolled straight past the tenth wave and kept cycling -
    and because wave_index kept incrementing while the displayed pattern value
    stayed at 5, the readout showed "wave 14/10" with a fresh timer, which is
    nonsense in both halves.

    Returning nil makes exhaustion explicit, so the caller has to decide what
    happens next instead of silently getting another 5.
--]]
--[[
    A wave has occurred, by whichever path.

    THE BUG THIS FIXES: the weakened ramp started only inside the burst
    DETECTION branch, but waves advance on the CLOCK - and the clock path never
    touched ramp_start. Detection is also gated on `timer > 0`, which is true
    for almost the whole cycle once the opener is armed, so detection rarely
    ran at all. Net effect: wave 1 arrived, the counter moved, and the ramp
    stayed nil forever - the row sat on "ramp starts at wave 1" permanently,
    which is exactly what was reported.

    Both paths call this now. Two call sites setting the same field in slightly
    different circumstances is how the two drifted apart in the first place.
--]]
local function mark_wave_started(t)
    if not state.ramp_start then
        state.ramp_start = t or now()
    end
end

local function pattern_at(index)
    if index < 1 then
        return WAVE_PATTERN[1]
    end

    return WAVE_PATTERN[index]
end

Cascade.pattern_at = pattern_at

--[[
    enter_room() is gone.

    Two attempts gated wave tracking on room entry - first automatically, then
    from recorded trigger markers - and both were the wrong shape. Detection is
    purely reactive now: five specials in five seconds, then pause for the next
    pattern duration. Nothing needs to know where a room begins.

    Removed rather than left dormant, because a function nothing calls is a
    function the next person has to work out the status of.
--]]
--[[
    RESET THE CYCLE - the pattern and the weakened ramp together.

    Two things reset it, and both were missing:

      1. REACHING WAVE 10. The pattern ends, and the cascade previously latched
         into `queued` forever - so the rest of the mission reported nothing.
         The cycle restarts instead: the pattern is a repeating schedule, not a
         one-shot.

      2. CROSSING A NEW TRIGGER, regardless of whether a boss actually spawns.
         A trigger is a new section of the map and the schedule starts over
         there.

    The weakened ramp resets with it. It was climbing to 60% and staying
    pinned while the roll count kept rising, which is wrong in both halves:
    the chance resets on a weakened spawn, and it should also reset when the
    cycle does. A percentage stuck at its ceiling with an ever-growing roll
    count tells you nothing.

    Deliberately NOT reset: the spawn feed, surge state and horde clock. Those
    describe what is on the map right now, which a trigger crossing does not
    change.
--]]
function Cascade.reset_cycle(reason)
    state.wave_index = 0
    state.accel = 1.0
    state.punished = false
    state.in_progress = false
    state.queued = false

    --[[
        A CROSSING STARTS THE OPENER. It does not return to "watching".

        Reported: the cascade began tracking, reached wave 1/10, then dropped
        back to "0/5 watching" with no countdown. That was this function
        setting armed = false and timer = 0, so the panel fell back to the
        pre-wave state and showed nothing ticking.

        Wrong on the model's own terms: entering a new area starts the 45
        second opener - that is the whole point of the first pattern value.
        Disarming instead threw away the one prediction the crossing licenses.

        So the cycle restarts ARMED, on pattern step 1, with the clock running.
    --]]
    state.armed = true
    state.timer = pattern_at(1)

    -- Ramp resets with the cycle, rolls included.
    state.ramp_start = nil
    state.rolls = 0

    for i = #state.spawn_times, 1, -1 do
        state.spawn_times[i] = nil
    end

    state.cycle_reason = reason
    state.cycles = (state.cycles or 0) + 1
end

function Cascade.reset()
    state.armed = false
    state.wave_index = 0
    state.timer = 0
    state.accel = 1.0
    state.breaks = 0
    state.downs = 0
    state.deaths = 0
    state.surge_until = 0
    state.last_wave_t = nil
    state.room_label = nil
    state.ramp_start = nil
    state.rolls = 0
    state.rolls_total = 0
    state.weak_spawns = 0

    -- Unit handles die with the level; carrying them over is a use-after-free.
    for unit in pairs(pending_monsters) do
        pending_monsters[unit] = nil
    end

    -- Same reasoning, and the count it guards is per mission.
    for unit in pairs(counted_weak) do
        counted_weak[unit] = nil
    end

    state.queued = false
    state.punished = false
    state.in_progress = false
    state.confirmed = 0
    state.mission_start = now()
    state.last_horde_t = nil

    -- Force a reload so a mission change re-reads the cache and clears the
    -- per-trigger latches.
    rooms_mission = nil
    rooms = nil
    state.horde_peak = 0
    state.horde_prev = 0
    state.rituals = 0
    state.forced_at = nil
    state.forced_kind = nil
    state.forced_base = nil
    state.forced_result = nil
    state.cap_blocked_at = nil
    ritual_total_mission = nil
    modifier_cache = nil
    clear_feed()

    for i = #state.spawn_times, 1, -1 do
        state.spawn_times[i] = nil
    end
end

--[[
    A coherency break.

    Two effects, per the model: the pending wave fires immediately, and the
    timer runs faster from here on. Both are applied; the immediate wave is
    modelled by zeroing the timer rather than by faking a spawn, so the readout
    still says "due now" rather than claiming something spawned that may not
    have.
--]]
function Cascade.coherency_break(kind)
    if not state.armed then
        return
    end

    state.breaks = state.breaks + 1

    if kind == "down" then
        state.downs = state.downs + 1
    elseif kind == "death" then
        state.deaths = state.deaths + 1
    end

    state.accel = BREAK_ACCEL
    state.punished = true

    --[[
        If detection was live when the punishment landed, queue the next wave
        so the punishment spawns cannot be read as one.

        Without this the break would leave the pause at zero, punishment
        specials would arrive into an open detection window, and five of them
        would register as a wave the director never scheduled - advancing the
        pattern on the team's mistake. If a pause is already running it is left
        alone; the acceleration above is what a break does to it.
    --]]
    if state.timer <= 0 and not state.queued then
        state.timer = pattern_at(state.wave_index + 1) or 0

        if state.timer == 0 then
            state.queued = true
        end
    end
end

--[[
    Record a special spawning, and detect waves.

    THE MODEL, and it is purely reactive - no room signal, no arming heuristic:

      * Five or more specials inside five seconds IS a wave. That is the only
        detection rule.
      * After a wave is detected, tracking PAUSES for the next pattern
        duration (45, 30, 15, 15, 15, 5, 5, 5, 5, 5).
      * When that pause elapses, detection resumes and the next five-in-five is
        the next wave.

    WHY THE PAUSE REPLACES EVERYTHING I ADDED BEFORE. Two previous attempts
    gated this on something external - first the room, then the first special
    seen - and both were wrong. The pause does the same job with no external
    signal at all:

      * A long burst cannot double-count, because detection is off for the
        whole pause. That is what the burst_consumed latch was for, and it is
        now redundant.
      * No arming problem, because nothing needs to arm. The first
        five-in-five is the first wave, whenever it happens.
      * The pause length is the model's own prediction of when the next wave is
        due, so the countdown shown on screen and the detection window are the
        same number rather than two things that can disagree.

    Punishment still suppresses DETECTION but not counting: a coherency break,
    death or speedrun spawns its own specials and accelerates the next wave,
    but is not itself a wave. Those spawns still feed the surge, the feed and
    the weakened ramp - they are real specials on the map.
--]]
function Cascade.special_spawned()
    local t = now()
    local times = state.spawn_times

    --[[
        Pre-placed specials do not count toward wave detection. mission_start
        is stamped on StateGameplay enter, so this is elapsed mission time
        rather than a wall clock.
    --]]
    if state.mission_start and (t - state.mission_start) < START_GRACE then
        return
    end

    times[#times + 1] = t

    -- Drop timestamps outside the window so the list stays window-sized.
    local cutoff = t - SURGE_WINDOW
    local write = 1

    for i = 1, #times do
        if times[i] >= cutoff then
            times[write] = times[i]
            write = write + 1
        end
    end

    for i = #times, write, -1 do
        times[i] = nil
    end

    local in_window = #times

    -- Surge is independent of the wave pause: it describes density, not schedule.
    if in_window > SURGE_SPECIAL_THRESHOLD and state.surge_until < t then
        state.surge_until = t + SURGE_DURATION

        if not state.ramp_start then
            state.ramp_start = t
        end
    end

    --[[
        The TOTAL counts every special regardless of whether a ramp is
        running. A roll that happens with no ramp is still a special that
        spawned, and it is the number that proves the spawn edge is firing.
    --]]
    state.rolls_total = (state.rolls_total or 0) + 1

    if state.ramp_start then
        state.rolls = state.rolls + 1
    end

    --[[
        DETECTION, gated only by the pause and by punishment.
    --]]
    if state.timer > 0 then
        return
    end

    if state.punished then
        return
    end

    if in_window < MIN_WAVE_SPECIALS then
        return
    end

    --[[
        A burst CONFIRMS the wave that is in progress; it does not advance the
        counter a second time.

        Both the clock and the burst used to advance wave_index, so a wave that
        elapsed and then delivered its five specials counted twice and the
        pattern ran away. The clock owns the counter; the burst owns
        confirmation.
    --]]
    --[[
        START THE RAMP ON ANY WAVE, not only on a surge.

        The weakened-boss chance is rolled per specialist spawn, and specials
        flow from the moment waves start - so gating the ramp on the surge
        threshold meant the percentage stayed hidden through most of a mission
        (see the off-by-one note above). A wave is five specials in five
        seconds, which is when rolls are actually happening, so that is when
        the clock should start.
    --]]
    mark_wave_started(t)

    --[[
        A burst has been confirmed either way below, so the notification goes
        here rather than in one branch - both are a wave landing, they differ
        only in whether a clock predicted it.
    --]]
    Cascade.notify("SPECIALIST WAVE")

    if state.in_progress then
        state.in_progress = false
        state.confirmed = (state.confirmed or 0) + 1
    else
        -- A burst with no wave in progress is the FIRST wave of the mission,
        -- which no clock has predicted yet. That one does advance.
        state.armed = true
        state.wave_index = state.wave_index + 1
        state.last_wave_t = t

        local next_len = pattern_at(state.wave_index + 1)

        if next_len then
            state.timer = next_len
        else
            state.queued = true
            state.timer = 0
        end
    end

    --[[
        Clear the window on detection.

        Without this the same five timestamps are still inside the window when
        the pause ends, so the very next special would instantly re-trigger.
        The wave has been counted; those spawns belong to it.
    --]]
    for i = #times, 1, -1 do
        times[i] = nil
    end
end

--[[
    A monstrosity spawned. If it was weakened, the ramp resets.

    NO LONGER CALLS INTO ANOTHER MOD. This previously did

        get_mod("QIangIQsGeneralEnemyTracker").utilities.is_weakened(unit)

    which made the weakened feature silently dependent on that mod being both
    installed AND enabled - anyone running this mod on its own got a ramp that
    never reset. The check is now ported verbatim into
    HavocTracker_breeds.lua, so this mod stands alone.

    THE BREED NAME IS PASSED THROUGH, and that is the false-positive fix.

    The ported check cannot distinguish a weakenable monstrosity from one that
    merely has is_boss set. All six monster breeds have is_boss = true, but
    only beast of nurgle, plague ogryn and chaos spawn have weakened forms - so
    a daemonhost reached the health comparison, any mismatch against
    get_minion_max_health reported it weakened, and the ramp reset for a boss
    that was never weakened. That is the reported "hit once and nothing
    spawned".
--]]
--[[
    THE COUNTER BUG: THE CHECK RAN A FRAME TOO EARLY.

    is_weakened decides by comparing the unit's max_health against the breed's
    nominal max (HavocTracker_breeds.lua:92-100):

        local max_health = health_extension:max_health()
        local initial    = math.floor(difficulty:get_minion_max_health(breed.name))
        if max_health < initial then is_weakened = true end

    max_health is not a constant. PlayerUnitHealthExtension and its minion
    equivalent both derive it from stat_buffs, and the buffs that make a
    monstrosity "weakened" are applied AFTER the unit is spawned, not as part
    of spawning it. So on the frame the unit appears, max_health is still the
    nominal value, the comparison is false, and a genuinely weakened boss is
    recorded as a normal one.

    That is why the hit counter did not move on a weakened kill: the spawn was
    never counted, so the ramp never reset and "hit N" never incremented.

    Checking once, later, would swap this bug for its mirror - a unit that dies
    inside the delay is missed instead. So the unit is queued and RE-TESTED
    every cascade update until it tests weakened, dies, or the window expires.
    First positive wins and the unit is dropped; there is no way to double
    count it.
--]]
local WEAK_RECHECK_WINDOW = 2.5   -- seconds to keep asking

--[[
    DO NOT TEST BEFORE THIS MANY SECONDS HAVE PASSED.

    is_weakened compares the unit's max_health against the breed's nominal max
    scaled by the havoc modify_monster_health modifier:

        multiplied = initial + initial * modifier
        weakened   = max_health < multiplied

    At Havoc 40 that modifier is 0.7. The buffs that produce max_health are
    applied AFTER the unit spawns, so on the spawn frame max_health is still
    the nominal value and the comparison is

        10000 < 10000 + 10000 * 0.7   ->   10000 < 17000   ->   TRUE

    which is a false positive for EVERY monstrosity, not just weakened ones.
    That is what produced "5 already spawned" in a mission with one weakened
    boss and five bosses total.

    The old code tested immediately and only queued on a negative, so the
    false positive was taken as truth and the queue never got a look in. Now
    nothing is trusted until the buffs have had time to land.

    0.25s is about fifteen frames at 60fps - far longer than the one or two
    the buff actually takes, and still well inside the 2.5s window, so a boss
    that dies fast is still caught.
--]]
local WEAK_SETTLE_DELAY = 0.25

local function count_weakened(unit)
    --[[
        Returns true when this call was the one that counted, so callers can
        tell "counted" from "already knew about this unit" - the ramp reset
        below must not re-fire for a repeat report.
    --]]
    if unit then
        if counted_weak[unit] then
            return false
        end

        counted_weak[unit] = true
    end

    state.weak_spawns = state.weak_spawns + 1

    --[[
        Restart the climb AND clear the roll count.

        Both, because they are one measurement: "47% across nine rolls"
        describes the current climb. Resetting the percentage while leaving the
        rolls accumulating is what produced a reading pinned at 60% with an
        ever-rising roll count that meant nothing.
    --]]
    state.ramp_start = now()
    state.rolls = 0

    return true
end

--[[
    Called from the cascade update. Walks the short pending list, which holds
    at most a handful of entries and usually none.
--]]
function Cascade.recheck_monsters()
    local B = mod.Breeds

    if not B or not B.is_weakened then
        return
    end

    local t = now()
    local alive = rawget(_G, "HEALTH_ALIVE") or rawget(_G, "ALIVE")

    for unit, info in pairs(pending_monsters) do
        local drop = false

        if alive and not alive[unit] then
            -- Died or despawned before the answer settled. Nothing to count.
            drop = true
        elseif info.not_before and t < info.not_before then
            --[[
                Too early to believe the answer. Leave it queued and come back
                - this is the whole point of the settle delay.
            --]]
        elseif t > info.until_t then
            drop = true
        else
            local ok, weak = pcall(B.is_weakened, unit, info.breed)

            if ok and weak then
                count_weakened(unit)
                drop = true
            end
        end

        if drop then
            pending_monsters[unit] = nil
        end
    end
end

function Cascade.monster_spawned(unit, breed_name)
    if not unit then
        return
    end

    local B = mod.Breeds

    if not B or not B.is_weakened then
        return
    end

    --[[
        ALWAYS QUEUED. NEVER TESTED HERE.

        Testing on the spawn frame cannot work: the health buff that makes the
        comparison meaningful has not been applied yet, so is_weakened returns
        true for every monstrosity. See WEAK_SETTLE_DELAY above.

        The recheck loop owns the decision. It waits out the settle delay, then
        re-tests until the unit answers weakened, dies, or the window expires.
    --]]
    local t = now()

    pending_monsters[unit] = {
        breed = breed_name,
        not_before = t + WEAK_SETTLE_DELAY,
        until_t = t + WEAK_RECHECK_WINDOW,
    }
end

function Cascade.recent_specials()
    return #state.spawn_times
end

function Cascade.surge_active()
    return state.surge_until > now()
end

function Cascade.surge_remaining()
    local r = state.surge_until - now()
    return r > 0 and r or 0
end

--[[
    Weakened boss chance, per specialist spawn.

    Linear 5% -> 60% over 90 seconds from ramp_start. "Climbs steadily" says
    linear and there is nothing to justify a curve.

    Returns nil when no ramp is running - nil rather than 0.05, because before
    the first surge this model says nothing at all about the chance, and a
    floor value would read as a claim.

    NOTE this is a PER-SPAWN chance, not a per-second one. At 60% with five
    specials in a wave the expected number of weakened monstrosities is three,
    not 0.6 - which is the whole reason the readout shows the roll count
    alongside the percentage.
--]]
function Cascade.weak_boss_chance()
    if not state.ramp_start then
        return nil
    end

    local elapsed = now() - state.ramp_start
    local frac = math_max(0, math_min(1, elapsed / SURGE_DURATION))

    return WEAK_BOSS_MIN + frac * (WEAK_BOSS_MAX - WEAK_BOSS_MIN)
end

--[[
    Ramp elapsed, CAPPED at the window length.

    It was returning raw elapsed time, so the display read "148/90s" while the
    percentage sat pinned at 60%. The percentage was already clamped; the
    readout was not, which made a capped ramp look like a broken timer.
--]]
function Cascade.ramp_elapsed()
    if not state.ramp_start then
        return nil
    end

    local e = now() - state.ramp_start
    return e > SURGE_DURATION and SURGE_DURATION or e
end

--[[
    The supplied surge curve:  y = 41.12 - 17.62 * ln(x)

    THE AXES WERE NOT SPECIFIED, so this is exposed as a named function and
    displayed with its input, rather than being silently wired into a
    prediction. x is taken as the special count in the window, which is the
    only quantity in scope when the surge is declared.

    If y is meant to be seconds until the next wave, this belongs in the timer.
    If it is a percentage, it belongs in the boss chance. Those are very
    different claims and guessing between them would produce a number that
    looks authoritative and means nothing. Left labelled until confirmed.
--]]
function Cascade.surge_curve(x)
    if not x or x <= 0 then
        return nil
    end
    return 41.12 - 17.62 * math_log(x)
end

--[[
    LIVE SPECIALS PACING - THE REAL TIMERS, NOT A MODEL.
    ====================================================

    This supersedes the modelled wave pattern wherever it is readable, and the
    difference matters: the model was an approximation of behaviour the game
    will simply tell you.

    From havoc_specials_pacing_template.lua, six tiers. The top two:

        max_alive_specials              8      10
        timer_range                 80-240  60-220
        first_spawn_timer_modifer      0.6     0.6
        chance_for_coordinated_strike   0.5     0.6
        coordinated_strike_num_breeds  7-10    8-11
        coordinated_surge_chance        0.4    0.45
        coordinated_surge_timer_range  5-13    4-11
        coordinated_surge_duration    40-80   40-80
        num_coordinated_surges_range    5-8     3-6
        move_timer_when_challenge_rating_above  20  20

    WHAT THIS SAYS ABOUT THE 45/30/15/15/15/5/5/5/5/5 PATTERN.

    That pattern is a good OBSERVATION of a real mechanism, not the mechanism.
    What actually happens:

      * A slot timer is rolled from timer_range, so 80-240s - not a fixed 45.
        The first is multiplied by first_spawn_timer_modifer (0.6), giving
        48-144s. The observed "45 second opener" is the bottom of that range.

      * A spawn has a coordinated_surge_chance (40-45%) of becoming a SURGE:
        num_coordinated_surges_range (5-8) spawns, every
        coordinated_surge_timer_range (5-13) seconds. The observed "five 5
        second timers" is precisely that. The surge is the cascade.

      * Separately, chance_for_coordinated_strike (50-60%) fires a STRIKE of
        coordinated_strike_num_breeds - 7 to 11 specials at once.

      * THE TIMER PAUSES. move_timer_when_horde_active,
        move_timer_when_monster_active, move_timer_when_terror_event_active
        are all true, and move_timer_when_challenge_rating_above = 20 pauses it
        above CR 20 with a 20s delay. So a wave clock that appears to stall is
        often correct - the game has stopped it.

    So the pattern is neither wrong nor fixed: it is one likely roll. Which is
    exactly why reading the live timers beats predicting them.

    ------------------------------------------------------------------------
    WHAT IS READ

        Managers.state.pacing._specials_pacing
            :max_num_specials()        -- the cap, bonuses applied
            ._specials_slots[i]
                .spawned               -- slot is holding a LIVE special
                .breed_name            -- what that slot will send
                .spawn_timer           -- countdown, only while not spawned

    Each slot is a scheduled spawn with its own decrementing timer
    (specials_pacing.lua:121, 375, 484-502). That is a direct readout of what
    is coming and when - no modelling at all.

    ------------------------------------------------------------------------
    READ .spawned, NOT .breed_name

    This counted slots with a breed_name and called that "queued", which is
    why solo play showed 16/16 and every other run showed cap/cap. The count
    was never wrong about anything, because it could not be: _setup_specials_slot
    assigns breed_name on every slot it prepares (specials_pacing.lua:169) and
    NOTHING clears it when the special spawns. _on_special_spawned (line 678)
    sets .spawned and .spawned_unit and leaves breed_name exactly where it
    was, so every slot carries one from the moment pacing starts. "n/n" was a
    tautology with a slash in it.

    .spawned is the field that actually moves. It goes true on spawn and back
    to false when the unit dies (line 353-355), so alive-against-cap is a real
    ratio, and cap minus alive is how many are still counting down.

    The soonest timer was wrong for the same reason. A spawned slot's timer is
    not updated - the update loop takes the `if specials_slot.spawned` branch
    and never reaches the countdown - so it sits at whatever value it held
    when it fired, which is at or below zero. Including those in the minimum
    pinned "next" to 0s permanently as soon as one special was alive. Only
    unspawned slots are considered now.

    SERVER-SIDE ONLY, like monster pacing. On a client this returns nil and the
    modelled cascade remains the fallback, which is why the model is kept
    rather than deleted.

    Returns: cap, alive, soonest_pending
--]]
function Cascade.live_specials()
    local pacing = Managers.state and Managers.state.pacing
    local sp = pacing and pacing._specials_pacing

    if not sp or not sp.max_num_specials then
        return nil
    end

    local ok, cap = pcall(sp.max_num_specials, sp)

    if not ok or type(cap) ~= "number" then
        return nil
    end

    local slots = sp._specials_slots

    if type(slots) ~= "table" then
        return nil
    end

    local alive, soonest = 0, nil

    for i = 1, cap do
        local slot = slots[i]

        if type(slot) == "table" then
            if slot.spawned then
                -- Holding a live special. Its timer is frozen and meaningless.
                alive = alive + 1
            elseif slot.breed_name then
                local t = slot.spawn_timer

                --[[
                    CLAMPED AT ZERO, and this one is a real negative.

                    spawn_timer keeps decrementing past zero between the tick
                    that takes it negative and the update that consumes it
                    (specials_pacing.lua:375 tests `<= 0`), so reading it raw
                    can show "next -1s". Due is due; a negative countdown is
                    noise.
                --]]
                if type(t) == "number" then
                    if t < 0 then
                        t = 0
                    end

                    if not soonest or t < soonest then
                        soonest = t
                    end
                end
            end
        end
    end

    return cap, alive, soonest
end

--[[
    SPEED RUNNING AND RUSH PREVENTION - LIVE, AND PRE-WARNING.
    ==========================================================

    This is the "speedrun punishment" half of the model, and the game exposes
    enough live state to warn BEFORE it lands rather than reporting it after.

    THE SPEED RUNNING CHECK (specials_pacing.lua:1464-1545), every
    speed_running_check_frequency seconds (5):

      1. Prevention must be off cooldown.
      2. total_challenge_rating() must be >= speed_running_required_challenge_rating (8).
      3. The AHEAD player's travel distance is compared to the previous check.
      4. Moved LESS than speed_running_required_distance (10 m)?
             _num_speed_running_checks = 0, previous distance cleared.
         Moved 10 m or more?
             _num_speed_running_checks = _num_speed_running_checks + 1
      5. At num_required_speed_running_checks (2), a prevention special is
         injected AHEAD of the lead player.
      6. Cooldown: 10-15s on success, 2-8s on failure.

    TWO DETAILS WORTH KNOWING:

      * The injection uses ignore_allowance = true, so it BYPASSES the
        specials cap. A speed-running punishment arrives even when specials are
        otherwise blocked - which is why it can feel like it came from nowhere.

      * `_ahead_unit_has_no_units_in_coherency` is set right here
        (line 1490 and 1526), from the lead player's coherency count. That is
        the flag that cancels CR suppression - so this check is also where
        "running while suppressed stops being free" is decided. Moving as a
        group is what keeps it false.

    WHAT THIS GIVES US: `speedrun 1/2` with the seconds to the next check is a
    real warning with time to act on it - slow down, or regroup - rather than a
    post-mortem. It is read, not modelled.

    RUSH PREVENTION (line 1278) is separate: gated on its own cooldown (25-45s
    on success, 5-10s on failure) and on _num_spawned_specials being below the
    cap, with rushing_distance (40 m) as the spread that triggers it.

    Server-side, like the rest of pacing. Returns nil on a client.
--]]
--[[
    THE REAL TIMER MULTIPLIERS, and what actually accelerates specials.
    ===================================================================

    BREAK_ACCEL = 3.0 is a MODEL. Having gone looking for the game's own
    coherency-break multiplier, there isn't one - no coherency, down or death
    multiplier appears anywhere in the specials timer path. The 3x is a
    description of observed behaviour, not a constant the game holds.

    What the game actually does (specials_pacing.lua:484-502) is subtract from
    each slot's spawn timer every frame:

        time_reduction = dt                                   -- plain time
                       or (dt + traveled_this_frame)          -- time AND distance
                       or traveled_this_frame                 -- distance only
        time_reduction = time_reduction
                       * ramp_up_timer_modifier
                       * self._timer_multiplier

    Two things fall out of that, and both are more useful than the 3x:

      1. DISTANCE MOVED LITERALLY DRAINS THE SPAWN TIMER. traveled_this_frame
         is subtracted in metres, alongside or instead of seconds. That is the
         speedrunning mechanic at the mechanical level - not a penalty applied
         after a check, but distance being spent directly against the clock.
         Running does not "anger the director"; it fast-forwards it.

      2. NO_MODIFIER_TIME = 10. Inside the last ten seconds of a slot's timer,
         both multipliers stop applying and it drains at plain dt. So the final
         ten seconds cannot be rushed, however fast you move.

    Both multipliers are readable live:

        Managers.state.pacing:get_ramp_up_frequency_modifier("specials")
        specials_pacing._timer_multiplier

    Server-side, like the rest of pacing - so this reports the real numbers
    when hosting and nil as a client, where the model continues.
--]]
local NO_MODIFIER_TIME = 10

function Cascade.live_timer_multipliers()
    local pacing = Managers.state and Managers.state.pacing

    if not pacing then
        return nil
    end

    local ramp = 1

    if pacing.get_ramp_up_frequency_modifier then
        local ok, v = pcall(pacing.get_ramp_up_frequency_modifier, pacing, "specials")
        if ok and type(v) == "number" then
            ramp = v
        end
    end

    local sp = pacing._specials_pacing
    local tmul = sp and sp._timer_multiplier

    if type(tmul) ~= "number" then
        tmul = 1
    end

    --[[
        The product is what actually scales the drain. Reported alongside its
        parts because a 2.0 from ramp-up and a 2.0 from the timer multiplier
        mean different things even though the effect is identical.
    --]]
    return ramp * tmul, ramp, tmul, NO_MODIFIER_TIME
end

function Cascade.live_prevention()
    local pacing = Managers.state and Managers.state.pacing
    local sp = pacing and pacing._specials_pacing

    if not sp then
        return nil
    end

    local tm = Managers.time
    local t = nil

    if tm and tm.time then
        local ok, v = pcall(tm.time, tm, "gameplay")
        t = ok and v or nil
    end

    local out = {}

    out.checks = sp._num_speed_running_checks or 0

    --[[
        The required count comes from the live template rather than the 2 in
        the config dump, because a mutator can override it and hardcoding
        would then understate how close you are.
    --]]
    local tmpl = sp._template
    out.required = (tmpl and tmpl.num_required_speed_running_checks) or 2

    if t and sp._next_speed_running_check_t then
        local dt = sp._next_speed_running_check_t - t
        out.next_check = dt > 0 and dt or 0
    end

    if t and sp._speed_running_prevention_cooldown then
        local cd = sp._speed_running_prevention_cooldown - t
        out.cooldown = cd > 0 and cd or nil
    end

    if t and sp._rush_prevention_cooldown then
        local cd = sp._rush_prevention_cooldown - t
        out.rush_cooldown = cd > 0 and cd or nil
    end

    --[[
        The CR suppression cancel flag, straight from the source rather than
        inferred from coherency numbers of our own.
    --]]
    out.alone_ahead = sp._ahead_unit_has_no_units_in_coherency and true or false

    out.rushing_distance = (tmpl and tmpl.rushing_distance) or nil
    out.required_cr = (tmpl and tmpl.speed_running_required_challenge_rating) or nil
    out.required_distance = (tmpl and tmpl.speed_running_required_distance) or nil

    return out
end

--[[
    THIS WEEK'S MODIFIERS - READ, NOT ASSUMED.
    ==========================================

    Havoc modifiers rotate weekly, so anything keyed off a map name rather than
    the run's actual modifier set will be wrong most weeks. "Dark Communion"
    names the map; it says nothing about whether rituals are in rotation.

    TWO SOURCES, and they answer different questions:

      1. Managers.state.difficulty:get_parsed_havoc_data()
             .modifiers   -- the backend list: { name = ..., level = ... }
             .havoc_rank
         This is the ROTATION - what was assigned this week, with levels.

      2. game_mode:extension("havoc")._modifiers
         The RESOLVED values, flattened from
         HavocSettings.modifier_templates[name][level]. So
         get_modifier_value("add_max_alive_specials") returns the number
         actually in force, not the template.

    BOTH ARE AVAILABLE ON A CLIENT. GameModeExtensionHavoc.on_gameplay_init
    calls _initialize_modifiers unconditionally - only
    _initialize_server_modifiers sits behind `if self._is_server`. That matters
    here more than usual, because everything read from Managers.state.pacing is
    server-only and this is not.

    For "is a mechanic present", Managers.state.mutator._mutators remains the
    ground truth - a mutator is in that table only when it was actually loaded
    for this run, whatever route it took to get there.
--]]
local modifier_cache = nil

function Cascade.modifiers()
    if modifier_cache then
        return modifier_cache
    end

    local out = { list = {}, values = {}, rank = nil, mutators = {} }

    -- 1. The rotation, from the parsed backend data.
    local diff = Managers.state and Managers.state.difficulty

    if diff and diff.get_parsed_havoc_data then
        local ok, data = pcall(diff.get_parsed_havoc_data, diff)

        if ok and type(data) == "table" then
            out.rank = data.havoc_rank

            if type(data.modifiers) == "table" then
                for i = 1, #data.modifiers do
                    local m = data.modifiers[i]

                    if type(m) == "table" and m.name then
                        out.list[#out.list + 1] = { name = m.name, level = m.level }
                    end
                end
            end
        end
    end

    -- 2. The resolved values.
    local gm = Managers.state and Managers.state.game_mode

    if gm and gm.game_mode then
        local ok, ext = pcall(function()
            return gm:game_mode():extension("havoc")
        end)

        if ok and ext and ext._modifiers then
            for k, v in pairs(ext._modifiers) do
                out.values[k] = v
            end
        end
    end

    -- 3. What is actually loaded, which is what gates features.
    local mm = Managers.state and Managers.state.mutator

    if mm and mm._mutators then
        for name in pairs(mm._mutators) do
            out.mutators[name] = true
        end
    end

    --[[
        Cached only once something resolved. Modifiers initialise during
        gameplay init, so an early call can legitimately find nothing, and
        caching that empty answer would keep it empty for the mission.
    --]]
    if #out.list > 0 or next(out.values) or next(out.mutators) then
        modifier_cache = out
    end

    return out
end

function Cascade.clear_modifiers()
    modifier_cache = nil
end

--[[
    The specials cap, adjusted for this week's modifiers.

    more_alive_specials adds add_max_alive_specials (2 to 6 by level) on top of
    the pacing template's base. Hosting, max_num_specials() already includes
    it. As a CLIENT the pacing manager is nil, so the base is unknown - but the
    bonus is readable, and reporting "+4 specials this week" is worth more than
    reporting nothing.
--]]
function Cascade.specials_bonus()
    local mods = Cascade.modifiers()
    local v = mods and mods.values and mods.values.add_max_alive_specials

    return type(v) == "number" and v or nil
end

--[[
    CHAOS RITUALS, and the forced horde they bring.
    ==============================================

    From the game's own settings
    (settings/havoc/havoc_mutator_local_settings.lua,
    mutator_havoc_chaos_rituals):

        force_horde_on_spawn = true
        trigger_distance     = 55
        spawn_locations      = prebaked_mission_locations()
        num_to_spawn_per_mission = { cm_archives = 5, cm_habs = 3,
                                     core_research = 4, ... }
        composition = CHAOS_DAEMONHOST_COMPOISTION   -- chaos_mutator_daemonhost

    Three things worth having from that:

    1. THE RITUAL COUNT IS KNOWN PER MAP, not estimated. Twenty maps, five
       each except cm_habs (3) and core_research (4). Read from the settings
       table rather than copied here, so a patch that rebalances it is picked
       up without an edit.

    2. RITUALS TRIGGER AT 55 METRES. A fixed distance, not a travel-distance
       gate like monster pacing.

    3. EVERY RITUAL SPAWN FORCES A HORDE. monster_pacing.lua:912-920:

           local force_horde_on_spawn = template.force_horde
           if force_horde_on_spawn then
               ...
               Managers.state.pacing:force_horde_pacing_spawn()
           end

       Note the field is `force_horde` at that layer and
       `force_horde_on_spawn` in the mutator config - two names for the same
       switch.

    ------------------------------------------------------------------------
    WHY THE FORCED HORDE IS THE MOST USEFUL PART

    The horde is REQUESTED, not guaranteed. If the entity cap is full the
    request cannot be filled and no horde arrives.

    That turns the long-standing rule of thumb - "if no horde spawns with a
    major boss you are at entity cap" - from an inference into a measurement.
    A monstrosity or ritual spawning is a known forced-horde event; if the
    horde population has not jumped shortly afterwards, the cap blocked it.

    That is a HARD cap confirmation, independent of the weighted estimate, and
    it works on a client where read_allocated() returns nil.
--]]
--[[
    MISSION-START GRACE.

    Reported: "4/5 specials watching" on mission start, before anything
    happened. Those are not wave spawns - they are units the level places and
    registers during load, which reach the census the moment they exist. The
    five-second window then counts them and the detector opens the run already
    most of the way to a false wave.

    Spawns inside this window are still tracked by the census and still appear
    in the feed; they are just not admitted as WAVE evidence, because a wave is
    a burst the director produced and these are furniture.
--]]
local START_GRACE = 12.0

local RITUAL_TRIGGER_DISTANCE = 55
local FORCED_HORDE_WINDOW = 6.0

local ritual_total_cache = nil
local ritual_total_mission = nil

--[[
    Rituals expected on a mission, from the settings table.

    RitualZones requires this same file, so the path is known good.
--]]
function Cascade.ritual_total(mission)
    if ritual_total_mission == mission then
        return ritual_total_cache
    end

    ritual_total_mission = mission
    ritual_total_cache = nil

    if not mission then
        return nil
    end

    --[[
        IS THE RITUAL MUTATOR EVEN LOADED THIS RUN?

        num_to_spawn_per_mission lists a count for all twenty maps, so reading
        it alone reports "0/5 rituals" on every mission whether or not rituals
        are in rotation. That is worse than showing nothing: it implies a
        counter is tracking something when the mechanic is not present.

        MutatorManager._load_mutators populates _mutators from the run's
        circumstance, so a mutator only appears in that table when it is
        actually loaded for this run. Absence is the gate.
    --]]
    local mm = Managers.state and Managers.state.mutator
    local loaded = mm and mm._mutators and mm._mutators.mutator_havoc_chaos_rituals

    if not loaded then
        return nil
    end

    local ok, settings = pcall(require, "scripts/settings/havoc/havoc_mutator_local_settings")

    if not ok or type(settings) ~= "table" then
        return nil
    end

    local m = settings.mutator_havoc_chaos_rituals
    local per = m and m.num_to_spawn_per_mission

    if type(per) == "table" then
        ritual_total_cache = per[mission]
    end

    return ritual_total_cache
end

Cascade.RITUAL_TRIGGER_DISTANCE = RITUAL_TRIGGER_DISTANCE

--[[
    A forced-horde event fired. Watch for the horde that should follow.

    Called when a monstrosity or a ritual daemonhost spawns. Records the horde
    population at that moment; sample_horde() below resolves it.
--]]
--[[
    NOT EVERY MONSTROSITY FORCES A HORDE. Corrected.

    I read force_horde_on_spawn on the ritual mutator and generalised it to all
    monster spawns. Wrong: in havoc_monster_pacing_template.lua, force_horde
    appears exactly TWICE across the whole file - it is a property of two
    specific pacing tiers, not of monster spawns in general.

    So "a monstrosity spawned and no horde followed" was flagging CAP BLOCKED
    for spawns that never requested a horde, which is why weakened bosses
    appeared to arrive without bodyguards and nothing looked consistent.

    WHAT IS STILL SOUND:

      * RITUALS. mutator_havoc_chaos_rituals sets force_horde_on_spawn = true
        unconditionally, at both the mutator and the spawner node level. Every
        ritual spawn requests a horde, so a ritual with no horde behind it IS a
        cap confirmation.

      * MONSTERS, only when hosting, where the live template can be read and
        template.force_horde actually checked.

    On a client, for a monster, this cannot be known - so it is not claimed.
    Reporting nothing beats reporting a confident wrong answer.
--]]
local function monster_forces_horde()
    local pacing = Managers.state and Managers.state.pacing
    local mp = pacing and pacing._monster_pacing

    -- Client: no template, no claim.
    if not mp then
        return nil
    end

    local tmpl = mp._template

    if type(tmpl) ~= "table" then
        return nil
    end

    return tmpl.force_horde and true or false
end

Cascade.monster_forces_horde = monster_forces_horde

function Cascade.forced_horde_expected(kind)
    --[[
        Only arm the watch when a horde was genuinely requested. A ritual
        always requests one; a monster only on the tiers that set force_horde,
        which is unknowable as a client.
    --]]
    if kind ~= "ritual" then
        if monster_forces_horde() ~= true then
            return
        end
    end

    state.forced_at = now()
    state.forced_kind = kind
    state.forced_base = state.horde_prev or 0
    state.forced_result = nil
end

function Cascade.ritual_spawned()
    state.rituals = (state.rituals or 0) + 1
    Cascade.forced_horde_expected("ritual")
end

--[[
    SPAWN FEED - what is spawning, and when.

    PORTED DATA PATH FROM SpecialsTracker / QIangIQsGeneralEnemyTracker
    (SpecialsTracker.lua:690-730). Their notification pipeline is:

        breed -> presentation name -> priority -> colour
        Managers.event:trigger("event_add_notification_message", type, texts, cb)
        + a hook on ConstantElementNotificationFeed._generate_notification_data
          to shape custom types into a banner

    WHY THE BANNER WIDGET ITSELF IS NOT REUSED, and this matters:
    event_add_notification_message hands the message to
    ConstantElementNotificationFeed, which is a CONSTANT element with its own
    fixed right-hand anchor. Moving it left means moving the element, and that
    element also carries every vanilla notification - mission objectives,
    pickups, level-ups. Relocating it to satisfy one mod's feed would drag all
    of those across the screen.

    So the DATA path is ported and the presentation is rendered in this mod's
    own left-hand element, directly under the cascade rows. Same information,
    same naming, no collateral damage to the vanilla feed.

    Names are the colloquial callouts rather than breed ids, because the point
    is reading it mid-fight: "Trapper" not "renegade_netgunner".
--]]
local FEED_MAX = 4
--[[
    How long a spawn stays in the feed.

    The number shown beside each name is the AGE since it spawned, counting
    up, and the entry drops when it passes this. Twelve seconds is roughly the
    window in which "a trapper just landed" is still actionable - long enough
    to read mid-fight, short enough that the feed reflects now rather than the
    last minute.
--]]
local FEED_TTL = 12.0

local NAMES = {
    -- specials
    chaos_hound              = "Hound",
    chaos_poxwalker_bomber   = "Burster",
    cultist_grenadier        = "Tox Bomber",
    cultist_mutant           = "Mutant",
    renegade_sniper          = "Sniper",
    renegade_grenadier       = "Bomber",
    renegade_netgunner       = "Trapper",
    renegade_flamer          = "Flamer",
    cultist_flamer           = "Flamer",
    chaos_hound_mutator      = "Hound",
    cultist_mutant_mutator   = "Mutant",
    renegade_flamer_mutator  = "Flamer",
    -- elites
    cultist_gunner           = "Dreg Gunner",
    renegade_gunner          = "Scab Gunner",
    cultist_shocktrooper     = "Dreg Shotgunner",
    renegade_shocktrooper    = "Scab Shotgunner",
    renegade_executor        = "Mauler",
    cultist_berzerker        = "Dreg Rager",
    renegade_berzerker       = "Scab Rager",
    renegade_plasma_gunner   = "Plasma Gunner",
    renegade_radio_operator  = "Radio Operator",
    chaos_ogryn_executor     = "Crusher",
    chaos_ogryn_bulwark      = "Bulwark",
    chaos_ogryn_gunner       = "Reaper",
}

local feed = {}

--[[
    Coalesced by name, the way their hybrid notifications are.

    Five gunners arriving together should read "Scab Gunner x5" on one line,
    not fill the whole feed with five identical lines and push the trapper you
    actually needed to see off the bottom.
--]]
function Cascade.log_spawn(breed_name, cat)
    if not breed_name then
        return
    end

    local label = NAMES[breed_name] or breed_name
    local t = now()

    for i = 1, #feed do
        if feed[i].label == label then
            feed[i].count = feed[i].count + 1
            feed[i].t = t
            return
        end
    end

    table.insert(feed, 1, { label = label, count = 1, t = t, cat = cat })

    for i = #feed, FEED_MAX + 1, -1 do
        feed[i] = nil
    end
end

--[[
    Returns the live feed, pruning entries older than the TTL.

    Reuses the table rather than building one per read: this is called from the
    HUD rebuild path, and a fresh table per read on a repeating path is the
    colour-picker leak that cost 59 -> 15 fps.
--]]
--[[
    ========================================================================
    NOTIFICATIONS
    ========================================================================

    THE SPAWN FEED WAS DEAD CODE. Cascade.log_spawn built a nicely coalesced
    list of what had spawned and when, and NOTHING EVER CALLED IT - the only
    reference in the whole mod was its own definition. So the panel's five
    feed rows drew a heading and four blank lines with dots next to them, and
    the "SPAWNED (ago)" readout that got reported as useless was not
    low-value information, it was no information at all.

    What replaces it is one line, fed from the spawn edges that actually fire:
    Cap.add calls special_spawned and monster_spawned on the frame a unit
    appears, and the wave detector already knows when five specials have
    landed inside five seconds.

    A notification is a label and a timestamp. The renderer shows it while it
    is younger than its TTL and nothing otherwise, so there is no clearing
    logic and no timer - the stamp IS the state.
--]]
--[[
    Six seconds. Long enough to read after the fight has your attention, short
    enough that the line is not still claiming a horde landed when the horde
    is dead.

    DECLARED ABOVE ITS USES, which in Lua is not a style preference: a local
    declared later in the file is a different variable from the global the
    earlier code would read, so this sitting below Cascade.notify made every
    age comparison a compare against nil.
--]]
local NOTIFY_TTL = 6

local notify_label_text = nil
local notify_t = 0

--[[
    Priority, not recency. A horde landing and an elite pack landing in the
    same second should read HORDE, because that is the one that changes what
    you do. Equal or higher rank replaces; lower is dropped while the current
    one is still inside its window.
--]]
local NOTIFY_RANK = {
    ["ELITE PACK"]      = 1,
    ["SPECIALIST WAVE"] = 2,
    ["HORDE"]           = 3,
    ["BOSS"]            = 4,
}

function Cascade.notify(label)
    if not label then
        return
    end

    local t = now()

    if notify_label_text and (t - notify_t) < NOTIFY_TTL then
        local old = NOTIFY_RANK[notify_label_text] or 0
        local new = NOTIFY_RANK[label] or 0

        if new < old then
            return
        end
    end

    notify_label_text, notify_t = label, t
end

--[[
    Returns the current notification, or nil once it has aged out.

    Aged here rather than cleared on a timer so there is nothing to drive -
    the renderer asks, and the answer is computed from the stamp.
--]]
--[[
    ELITE PACKS, not elites.

    Elites arrive constantly and individually; a notification per elite would
    be a permanent line saying nothing. A PACK is what matters, and the test
    is the same shape the specials wave detector uses: enough of them inside
    a short window.

    Four inside four seconds. Below that it is attrition, above it something
    was sent.
--]]
local ELITE_PACK_COUNT = 4
local ELITE_PACK_WINDOW = 4

local elite_times = {}

function Cascade.elite_spawned()
    local t = now()

    elite_times[#elite_times + 1] = t

    for i = #elite_times, 1, -1 do
        if (t - elite_times[i]) > ELITE_PACK_WINDOW then
            table.remove(elite_times, i)
        end
    end

    if #elite_times >= ELITE_PACK_COUNT then
        Cascade.notify("ELITE PACK")

        --[[
            Cleared on fire so a pack does not re-announce itself on every
            subsequent elite while the window is still full.
        --]]
        for i = #elite_times, 1, -1 do
            elite_times[i] = nil
        end
    end
end

--[[
    ========================================================================
    WHY A WEAKENED BOSS CANNOT SPAWN
    ========================================================================

    The panel showed a percentage and nothing else, so "weak 47%" was equally
    consistent with "a weakened boss may arrive at any moment" and "a weakened
    boss is impossible right now and that 47 is describing a dice roll that
    will not be made". Those are opposite situations.

    A weakened monstrosity is not a breed. BossExtension.extensions_ready
    (boss_extension.lua:59-66) compares the unit's max_health against the
    breed's normal max_health and sets _is_weakened when it is lower - so
    "weakened" is an OUTCOME of a health modifier applied at spawn, and the
    thing that has to happen first is a monster spawning through the SPECIALS
    pacing path rather than the monster pacing path.

    SpecialsPacing._check_monster_override is that path, and it is a sequence
    of gates. Read in order, the ones a client can see:

      1. _max_monster_duration      a cooldown set when the monster cap was
                                    last hit. While it is in the future the
                                    function returns immediately.
      2. _monster_spawn_config      nil on templates that do not do this at
                                    all. No config, no weakened monster,
                                    whatever the percentage says.
      3. chance_to_spawn_monster    the roll itself. This is the percentage.
      4. max_monsters               counted across the specials slots. At the
                                    cap the check returns and sets the
                                    cooldown in 1.
      5. total_num_allowed          when set, ANY aggroed monster blocks it
                                    outright - pacing_manager:num_aggroed_
                                    monsters() > 0 returns.

    So the honest readout names whichever gate is currently shut, and only
    shows the percentage when none of them is.

    WHAT IS READABLE OFF-HOST: nothing here. _specials_pacing is server-side,
    the same as live_specials. On a client this returns nil and the caller
    falls back to the modelled percentage, which is why the model is kept.
--]]
function Cascade.weak_gate()
    local pacing = Managers.state and Managers.state.pacing
    local sp = pacing and pacing._specials_pacing

    if not sp then
        return nil
    end

    local cfg = sp._monster_spawn_config

    if not cfg then
        return "no weak boss: not on this map"
    end

    --[[
        The cooldown. Reported with its remaining time, because unlike the
        other gates this one clears on its own and knowing when is the whole
        value of showing it.
    --]]
    local until_t = sp._max_monster_duration

    if until_t then
        local ok, t = pcall(Managers.time.time, Managers.time, "gameplay")

        if ok and type(t) == "number" and t < until_t then
            return string.format("no weak boss: cooldown %.0fs", until_t - t)
        end
    end

    --[[
        An aggroed monster blocks it outright, but ONLY when the config uses
        total_num_allowed. Checking num_aggroed_monsters unconditionally would
        report a block that is not there on every other template.
    --]]
    if cfg.total_num_allowed and pacing.num_aggroed_monsters then
        local ok, n = pcall(pacing.num_aggroed_monsters, pacing)

        if ok and type(n) == "number" and n > 0 then
            return "no weak boss: a boss is already up"
        end
    end

    -- Monster slots, counted the way _check_monster_override counts them.
    local slots = sp._specials_slots
    local cap = cfg.max_monsters

    if type(slots) == "table" and type(cap) == "number" then
        local n = 0

        for i = 1, #slots do
            local slot = slots[i]
            local bn = slot and slot.breed_name
            local breed = bn and Breeds and Breeds[bn]

            if breed and breed.tags and breed.tags.monster then
                n = n + 1
            end
        end

        if cap <= n then
            return string.format("no weak boss: monster slots full %d/%d", n, cap)
        end
    end

    --[[
        Nothing is shut. Return the LIVE chance rather than nil - this is the
        game's own number, and it beats the model that would otherwise be
        shown in its place.
    --]]
    local chance = cfg.chance_to_spawn_monster

    if type(chance) == "number" then
        return string.format("weak boss possible - %.0f%% per wave", chance * 100)
    end

    return nil
end

function Cascade.notification()
    if not notify_label_text then
        return nil
    end

    local t = now()

    if (t - notify_t) > NOTIFY_TTL then
        notify_label_text = nil
        return nil
    end

    return notify_label_text
end

function Cascade.feed()
    local t = now()

    for i = #feed, 1, -1 do
        local age = t - feed[i].t

        if age > FEED_TTL then
            table.remove(feed, i)
        else
            -- Stamped here so the renderer does no clock work of its own.
            feed[i].age = age
        end
    end

    return feed
end

local function clear_feed()
    for i = #feed, 1, -1 do
        feed[i] = nil
    end
end

--[[
    HORDE POPULATION SAMPLING, and the counting rule that matters.

    Called from the 4Hz census with the live horde+roamer count.

    ONLY POSITIVE CHANGE COUNTS. If 20 are up, 10 die and 3 spawn, the
    population reads 13 - a net decrease of 7 - while 3 actually arrived. A
    naive delta on the alive count would see -7 and conclude nothing spawned.

    The rule is therefore: REBASE on any decrease, accumulate on any increase.
    The baseline drops to the new floor (13), and growth is measured from
    there. Deaths never subtract from the arrival count; they only move the
    line that growth is measured against.

        20 -> 13   decrease: rebase to 13, add nothing
        13 -> 16   increase: +3

    A HORDE is then a jump of at least HORDE_JUMP within one sample, which
    distinguishes an actual wave arriving from trickle refill.

    NOTE on specials: they are counted differently, by SPAWN EVENT, in
    special_spawned(). That is exact rather than inferred - each spawn is seen
    individually as the unit registers - so it already has the property this
    rule exists to reconstruct, and cannot be fooled by simultaneous deaths.
    Delta sampling is used here only because the horde count is read as a
    population rather than as events.
--]]
local HORDE_JUMP = 8

function Cascade.sample_horde(count)
    if type(count) ~= "number" then
        return
    end

    local prev = state.horde_prev
    state.horde_prev = count

    if count < prev then
        -- Rebase only. A decrease is never an arrival.
        return
    end

    local gained = count - prev

    if gained >= HORDE_JUMP then
        state.last_horde_t = now()
        state.horde_peak = count
    end

    --[[
        RESOLVE A FORCED-HORDE EVENT.

        Measured against the population AT THE EVENT, not against the previous
        sample - the horde arrives over a second or two, so a per-sample delta
        would miss it arriving in dribbles.

        A jump means the request was filled. No jump inside the window means
        the cap refused it, which is a hard confirmation rather than an
        estimate.
    --]]
    if state.forced_at and state.forced_result == nil then
        local elapsed = now() - state.forced_at

        if count - (state.forced_base or 0) >= HORDE_JUMP then
            state.forced_result = "filled"
        elseif elapsed > FORCED_HORDE_WINDOW then
            state.forced_result = "blocked"
            state.cap_blocked_at = now()
        end
    end
end

--[[
    Was a forced horde recently refused? Returns nil when nothing is known.

    Deliberately expires: a cap that was full thirty seconds ago says nothing
    about now, and a stale CAP BLOCKED on screen is worse than no reading.
--]]
local CAP_BLOCKED_TTL = 20.0

function Cascade.cap_blocked()
    if not state.cap_blocked_at then
        return nil
    end

    local age = now() - state.cap_blocked_at

    if age > CAP_BLOCKED_TTL then
        return nil
    end

    return age
end

function Cascade.since_horde()
    if not state.last_horde_t then
        return nil
    end
    return now() - state.last_horde_t
end

--[[
    Advance the timer.

    Driven from the 4Hz board tick, not per frame - the pattern's shortest
    interval is five seconds, so quarter-second resolution is far finer than
    the thing being modelled needs.
--]]
function Cascade.update(dt)
    if not dt or dt <= 0 then
        return
    end

    --[[
        Weakened re-checks run BEFORE the queued early-out, because a boss's
        max_health settles on its own schedule and has nothing to do with
        whether a wave is queued. Putting it below the return would make the
        counter depend on wave state, which is the class of coupling that
        produced the original bug.
    --]]
    Cascade.recheck_monsters()

    if state.queued then
        return
    end

    --[[
        Run down the pause. Acceleration applies here and nowhere else: a
        coherency break makes the next wave arrive sooner, which in this model
        means the pause drains faster.

        The timer only ever counts DOWN. It never advances a wave by itself -
        that was the old "over cap" bug, where a zero timer incremented the
        index with no spawn observed, and out of coherency at 3x it walked far
        past ten.
    --]]
    if state.timer > 0 then
        state.timer = state.timer - dt * state.accel

        if state.timer <= 0 then
            --[[
                THE PAUSE ELAPSING IS ITSELF A WAVE. This is the stuck-at-1/10
                fix.

                Previously the timer only ever counted down, and the wave index
                advanced solely on a detected five-in-five burst. So after wave
                1 the counter sat at 1/10 for the rest of the mission unless
                another five specials happened to land inside five seconds -
                which the later 15s and 5s waves often do not, since their
                specials are partly trickle carried over from earlier.

                The model is explicit: "upon elapse of this timer, the next
                specialist wave will spawn". So elapse advances the wave and
                the next pattern duration starts immediately. Detection then
                CONFIRMS the wave rather than being the only thing that can
                advance it.

                The old over-cap bug is still guarded: `queued` stops this at
                the tenth wave instead of inventing an eleventh.
            --]]
            state.punished = false
            state.accel = 1.0

            local next_len = pattern_at(state.wave_index + 1)

            if next_len then
                state.armed = true
                state.wave_index = state.wave_index + 1
                state.last_wave_t = now()
                state.in_progress = true
                state.timer = next_len

                -- The clock advancing a wave starts the ramp too.
                mark_wave_started()
            else
                --[[
                    Tenth wave consumed: restart the cycle rather than latching
                    into `queued` for the rest of the mission. The 5s tail is
                    the steady state, so the new cycle opens on it rather than
                    going back to a 45s lull that will not happen.
                --]]
                Cascade.reset_cycle("wave 10")
                state.armed = true
                state.wave_index = 1
                state.in_progress = true
                state.timer = WAVE_PATTERN[#WAVE_PATTERN]
                mark_wave_started()
            end
        end
    end
end

--[[
    Readout. Returns a REUSED table - this is read from the HUD rebuild path,
    and a fresh table per read on a repeating path is the colour-picker leak
    that cost 59 -> 15 fps.
--]]
local out = {}

function Cascade.read()
    out.armed = state.armed
    out.wave = state.wave_index
    out.waves_total = #WAVE_PATTERN
    out.queued = state.queued
    out.punished = state.punished
    out.in_progress = state.in_progress
    out.confirmed = state.confirmed
    out.cycles = state.cycles or 0
    out.cycle_reason = state.cycle_reason
    out.since_horde = Cascade.since_horde()
    out.horde_peak = state.horde_peak
    out.rituals = state.rituals or 0
    out.cap_blocked = Cascade.cap_blocked()
    out.timer = state.timer > 0 and state.timer or 0
    out.accel = state.accel
    out.breaks = state.breaks
    out.downs = state.downs
    out.deaths = state.deaths
    out.recent = #state.spawn_times
    out.min_wave = STATED_WAVE_SIZE
    out.detect_at = MIN_WAVE_SPECIALS
    out.surge = Cascade.surge_active()
    out.surge_left = Cascade.surge_remaining()
    out.weak_boss = Cascade.weak_boss_chance()
    out.rolls = state.rolls
    out.rolls_total = state.rolls_total or 0
    out.weak_spawns = state.weak_spawns
    out.ramp_elapsed = Cascade.ramp_elapsed()
    out.ramp_total = SURGE_DURATION
    out.curve = out.surge and Cascade.surge_curve(out.recent) or nil
    out.room = state.room_label
    return out
end

--[[
    The weakened counter, straight from state, untruncated.

    Added because "the hit counter is always 0" turned out to be the HUD row
    clipping the number off its end rather than the counter failing - and
    there was no way to tell those two apart from in game. This prints the raw
    values and the pending queue, so the next time they disagree the answer is
    one command away instead of a guess.
--]]
mod:command("htweak", "raw weakened-boss counters and the pending queue", function()
    local pending = 0

    for _ in pairs(pending_monsters) do
        pending = pending + 1
    end

    mod:echo("[HavocTracker] === weakened boss ===")
    mod:echo(string.format("  hits this mission: %d", state.weak_spawns or 0))
    mod:echo(string.format("  rolls since ramp start: %d", state.rolls or 0))
    mod:echo(string.format("  rolls all mission: %d   <- if this is 0, the special spawn edge is not firing",
        state.rolls_total or 0))
    mod:echo(string.format("  chance now: %s",
        Cascade.weak_boss_chance()
            and string.format("%.0f%%", Cascade.weak_boss_chance() * 100)
            or "no ramp running"))
    mod:echo(string.format("  monsters awaiting a verdict: %d", pending))
    mod:echo(string.format("  weakenable breeds: %s",
        "beast of nurgle, plague ogryn, chaos spawn"))
end)

mod.Cascade = Cascade
return Cascade
