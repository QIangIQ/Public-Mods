local mod = get_mod("HavocTracker")

--[[
    Spawn forecast.
    ===============

    WHAT THIS DATA IS, precisely - because the difference matters and getting it
    wrong would make the panel lie to you.

    monster_pacing.lua builds _spawn_type_point_sections at mission init: the
    map is cut into sections, and each section holds a set of candidate spawn
    points, each with a spawn_travel_distance. That table is STATIC per map.

    Then generate_monster_spawns (monster_pacing.lua:155-200) rolls num_to_spawn
    sections at random and picks ONE point from each. Typically 1-3 monsters out
    of 10-29 candidates. Those rolled entries go into _monsters.

    MonsterPacing.update (line 672, 691):
        local ahead_target_unit, ahead_travel_distance =
            Managers.state.main_path:ahead_unit(target_side_id)
        if spawn_travel_distance <= ahead_travel_distance then
            self:_spawn_monster(...); table.remove(monsters, i); break

    Three consequences that drive this whole module:

      1. The trigger is the FURTHEST-AHEAD player. Not you, not the centroid.
         A teammate who rushes 40m ahead pulls the monster while you are still
         walking. So the meter tracks state.lead.

      2. Candidates are not spawns. We can never say "a monster IS here". We can
         say "a monster CAN be here", and - far more usefully - "there is no
         candidate at all for the next 120m", which is a guarantee.

      3. Only ONE monster spawns per tick (the break), and the entry is removed.
         So once a monster appears we can retire the nearest candidate behind
         the lead player and decrement the budget.

    Also note monster_pacing.lua:719-728: _main_path_sound_events fires the
    audio cue at (travel_distance - sound_data.distance). The horn you hear is
    itself distance-triggered on a fixed lead. This panel fires earlier.
--]]

local Spawns = {}

-- ---------------------------------------------------------------------------
-- Cache loading
-- ---------------------------------------------------------------------------

--[[
    Two paths, in order.

    The bundled copy wins so the mod is self-contained and RitualZones can be
    uninstalled. Falling back to RitualZones' own copy means this works the
    moment you install HavocTracker, with nothing to copy by hand.

    Loading is a one-shot dofile of a plain `return { maps = {...} }` table. No
    hooks, no per-frame work, nothing that touches the code paths that make
    RitualZones crash.
--]]
local CACHE_PATHS = {
    "Dio's HavocTracker/scripts/mods/HavocTracker/cache/spawn_cache",
    "RitualZones/scripts/mods/RitualZones/cache/ritualzones_cache",
}

local cache = nil          -- { maps = { [mission] = {...} } }
local cache_source = nil
local load_attempted = false

local function load_cache()
    if load_attempted then
        return cache
    end
    load_attempted = true

    for i = 1, #CACHE_PATHS do
        local path = CACHE_PATHS[i]
        local ok, data = pcall(function()
            return mod:io_dofile(path)
        end)
        if ok and type(data) == "table" and type(data.maps) == "table" then
            cache = data
            cache_source = path
            mod:info("[HavocTracker] spawn cache loaded from %s", path)
            return cache
        end
    end

    mod:warning("[HavocTracker] no spawn cache found; forecast disabled")
    return nil
end

function Spawns.cache_source()
    return cache_source
end

--[[
    How many maps the bundled cache actually holds.

    Reported on screen so "no data" separates into its two very different
    causes: the cache never loaded (0 maps - a path or file problem), versus the
    cache loaded fine but this mission is not in it (27 maps - a coverage
    problem, fixed only by recording). Those need opposite responses and were
    previously indistinguishable.
--]]
function Spawns.cache_map_count()
    local data = load_cache()
    if not data or type(data.maps) ~= "table" then
        return 0
    end
    local n = 0
    for _ in pairs(data.maps) do
        n = n + 1
    end
    return n
end

--- A few cache keys, for comparing against the live mission name.
function Spawns.sample_cache_keys(limit)
    local data = load_cache()
    if not data or type(data.maps) ~= "table" then
        return "<cache not loaded>"
    end
    local keys, n = {}, 0
    for k in pairs(data.maps) do
        n = n + 1
        keys[n] = k
        if n >= (limit or 4) then break end
    end
    return table.concat(keys, ", ")
end

-- ---------------------------------------------------------------------------
-- User cache (auto-recorded while hosting)
--
-- The bundled cache covers the 27 missions that existed when RitualZones
-- recorded it. Anything Fatshark has added since - Magistrati Oubliette
-- TM8-707, for one - is in neither the cache nor the source dump, so a client
-- has nothing to show there.
--
-- While hosting we can read _spawn_type_point_sections directly, which is the
-- SAME table RitualZones recorded from. So the first time you host a new
-- mission we write its spawn points to a user cache, and every later client run
-- on that map works normally.
--
-- Written to AppData rather than the mod folder: the game may be installed
-- under Program Files, which is not reliably writable.
-- ---------------------------------------------------------------------------

local user_cache = nil
local user_cache_loaded = false

--[[
    True when the last load attempt could not read the file. Write-time guard:
    an in-memory cache built after a failed load is INCOMPLETE, and writing it
    out would delete whatever was on disk.
--]]
local user_cache_load_failed = false
local recorded_this_session = {}

--[[
    Writes are DEFERRED to mission end.

    The first version wrote the whole cache file every time it learned
    something - on every recording, and on every ritual daemonhost that
    appeared. That is synchronous disk I/O on the main thread during gameplay,
    and on a mission restart a burst of units register at once, so it fires
    repeatedly at the worst possible moment.

    Now anything learned sets this flag and mutates the in-memory table only.
    The file is written once, from flush_cache, when the mission ends - at which
    point a stall costs nothing because you are on the loading screen anyway.
--]]
local cache_dirty = false

--[[
    Path via the SANDBOXED os, not the global one.

    The global `os` is not exposed to mods, so os.getenv returned nil, this
    returned nil, and every write silently no-oped inside its pcall - which is
    why HavocTracker_user_cache.lua never appeared despite hosted runs
    reporting successful recordings.
--]]
local function user_cache_path()
    return mod.appdata_path and mod.appdata_path("HavocTracker_user_cache.lua") or nil
end

--[[
    io.open + load rather than mod:io_dofile.

    io_dofile resolves relative to the mods directory and cannot reach an
    absolute AppData path, so the file has to be read and compiled by hand.
--]]
local function load_user_cache()
    if user_cache_loaded then
        return user_cache
    end
    user_cache_loaded = true

    local path = user_cache_path()
    if not path then
        return nil
    end

    local ok, result = pcall(function()
        local io_ = mod.sandbox_io and mod.sandbox_io()
        if not io_ then return nil end
        local f = io_.open(path, "r")
        if not f then return nil end
        local text = f:read("*a")
        f:close()
        if not text or text == "" then return nil end

        if not mod.sandbox_load then error("sandbox_load missing", 0) end
        local chunk, load_err = mod.sandbox_load(text, "@HavocTracker_user_cache")
        if not chunk then error("compile failed - " .. tostring(load_err), 0) end
        local data = chunk()
        return (type(data) == "table" and type(data.maps) == "table") and data or nil
    end)

    if ok and result then
        user_cache = result
        user_cache_load_failed = false
        mod:info("[HavocTracker] user cache loaded (%s)", path)
    else
        --[[
            A SILENT FAILURE HERE DELETED A MAP.

            This used to log only on success. When the read failed - for any of
            the five reasons above, each of which returns a bare nil - the
            function set user_cache_loaded = true, left user_cache as nil, and
            said nothing. record_if_needed then did

                user_cache = user_cache or { maps = {} }

            and the next write replaced the file with just the one map recorded
            this session. fm_resurgence was destroyed by a function that could
            not read it.

            The flag is what write_user_cache checks before it is allowed to
            overwrite anything.
        --]]
        user_cache_load_failed = true
        mod:warning("[HavocTracker] could not read the user cache at %s " ..
            "(%s). Existing recordings will be preserved on write.",
            tostring(path), ok and "no usable data" or
                ("read error: " .. tostring(result)))
    end
    return user_cache
end

local function table_size(t)
    local n = 0

    for _ in pairs(t or {}) do
        n = n + 1
    end

    return n
end

local function serialize_list(t)
    local parts = {}
    for i = 1, #t do
        parts[#parts + 1] = string.format("%.4f", t[i])
    end
    return table.concat(parts, ",")
end

--[[
    Written to a temp file, then renamed over the real one.

    A rename is atomic on every filesystem we care about, so the cache is either
    the old complete version or the new complete version - never a half-written
    file. Without this, a crash or a kill during the write would leave a
    truncated Lua chunk that fails to parse, and you would silently lose every
    map you had recorded.
--]]
--[[
    Re-reads the file from disk, ignoring the cached copy and the loaded flag.
    Used by the write path so a failed load at mission start cannot cause a
    delete at mission end.
--]]
local function read_disk_maps(path)
    local ok, result = pcall(function()
        local io_ = mod.sandbox_io and mod.sandbox_io()
        if not io_ then return nil end
        local f = io_.open(path, "r")
        if not f then return nil end
        local text = f:read("*a")
        f:close()
        if not text or text == "" then return nil end
        if not mod.sandbox_load then error("sandbox_load missing", 0) end
        local chunk, load_err = mod.sandbox_load(text, "@HavocTracker_user_cache")
        if not chunk then error("compile failed - " .. tostring(load_err), 0) end
        local data = chunk()
        return (type(data) == "table" and type(data.maps) == "table") and data.maps or nil
    end)

    return (ok and result) or nil
end

local function write_user_cache()
    local path = user_cache_path()
    if not path or not user_cache then
        return false
    end

    --[[
        MERGE OVER DISK, NEVER REPLACE IT.

        What is in memory is only the maps touched this session. Anything else
        in the file has to survive, and it used to not: a failed load produced
        an empty in-memory table and the write below happily serialised it over
        a file holding other maps.

        So the file is re-read HERE, fresh, and this session's entries are
        layered on top. Newest wins per map, which is correct - a re-recording
        of the same map on a newer build should replace the older one.

        If the re-read fails as well and the load failed earlier, there is no
        safe way to know what we would be destroying, so nothing is written at
        all. Losing one session's recording beats losing the file.
    --]]
    local disk = read_disk_maps(path)

    if not disk and user_cache_load_failed then
        mod:warning("[HavocTracker] user cache unreadable on disk AND in " ..
            "memory - refusing to overwrite it. This run was not saved.")
        return false
    end

    local merged = {}

    for name, entry in pairs(disk or {}) do
        merged[name] = entry
    end

    local kept = 0

    for name, entry in pairs(user_cache.maps or {}) do
        if not merged[name] then
            kept = kept + 1
        end
        merged[name] = entry
    end

    if kept > 0 or next(merged) then
        mod:info("[HavocTracker] user cache: %d map(s) on disk, %d new, %d total",
            disk and table_size(disk) or 0, kept, table_size(merged))
    end

    local tmp = path .. ".tmp"

    local ok = pcall(function()
        local io_ = mod.sandbox_io and mod.sandbox_io()
        if not io_ then return end
        local f = io_.open(tmp, "w")
        if not f then return end
        f:write("-- Dio's HavocTracker: auto-recorded while hosting.\n")
        f:write("-- Safe to delete; it will be rebuilt next time you host.\n")
        f:write("return {\n  maps = {\n")
        for mission, entry in pairs(merged) do
            f:write(string.format("    [%q] = {\n", mission))
            f:write(string.format("      path = { total = %.4f },\n", entry.path_total or 0))
            f:write("      pacing = {\n")
            for kind, list in pairs(entry.pacing or {}) do
                f:write(string.format("        %s = { %s },\n", kind, serialize_list(list)))
            end
            f:write("      },\n      boss = {\n")
            for kind, list in pairs(entry.boss or {}) do
                f:write(string.format("        %s = { %s },\n", kind, serialize_list(list)))
            end
            f:write("      },\n    },\n")
        end
        f:write("  },\n}\n")
        f:close()
    end)

    if not ok then
        pcall(function() local o = mod.sandbox_os and mod.sandbox_os(); if o and o.remove then o.remove(tmp) end end)
        return false
    end

    -- os.rename will not overwrite on Windows, so clear the target first.
    pcall(function() local o = mod.sandbox_os and mod.sandbox_os(); if o and o.remove then o.remove(path) end end)
    local moved = pcall(function() local o = mod.sandbox_os and mod.sandbox_os(); if not (o and o.rename) then error('no os.rename') end o.rename(tmp, path) end)
    if not moved then
        pcall(function() local o = mod.sandbox_os and mod.sandbox_os(); if o and o.remove then o.remove(tmp) end end)
        return false
    end

    return true
end


-- ---------------------------------------------------------------------------
-- Mission identification
-- ---------------------------------------------------------------------------

--[[
    The mission key, as used by the cache.

    mission_name() is a METHOD ON THE MISSION MANAGER that returns the string
    key directly - it is NOT mission() returning a table with a .name field.
    Getting this wrong was the whole bug: mission() does not exist, the pcall
    swallowed it, current_mission_name returned nil, set_mission never matched,
    and the panel hid itself with zero triggers while every other part of the
    forecast worked fine.

    RitualZones.lua:460-469 does exactly this and it is why its cache lookups
    work.
--]]
local function current_mission_name()
    --[[
        Identity module first: it falls back to Managers.mechanism when
        Managers.state.mission is not up yet.

        That is the fix for "going Psykhanium -> solo play takes two or three
        attempts". The mission manager does not resolve immediately after a
        state transition, so the first bind found nothing; the mechanism knows
        the destination throughout and lets the bind land on the first try.
    --]]
    if mod.Identity and mod.Identity.mission then
        local ok, name = pcall(mod.Identity.mission)
        if ok and type(name) == "string" and name ~= "" then
            return name
        end
    end

    local mission_manager = Managers.state and Managers.state.mission
    if mission_manager and mission_manager.mission_name then
        local ok, name = pcall(mission_manager.mission_name, mission_manager)
        if ok and type(name) == "string" and name ~= "" then
            return name
        end
    end

    -- Fallback: the level name usually matches the mission key.
    local ok, level = pcall(function()
        return Managers.state.game_mode:level_name()
    end)
    if ok and type(level) == "string" and level ~= "" then
        return level
    end

    return nil
end

-- ---------------------------------------------------------------------------
-- Trigger kinds
--
-- Ordered by how much they should scare you. Boss patrols and twins are
-- scripted set-pieces; monsters/captains are the pacing roll.
-- ---------------------------------------------------------------------------

local KIND_LABEL = {
    -- Monster points are also captain points (monster_pacing.lua:575-577), so
    -- the label names both rather than implying only one can appear.
    pacing_monsters      = "MONSTER/CAPN",
    pacing_captains      = "CAPTAIN",
    pacing_witches       = "DAEMONHOST",
    boss_patrol_trigger  = "PATROL",
    boss_trigger         = "BOSS",
    twins_ambush_trigger = "TWINS AMBUSH",
    twins_spawn_trigger  = "TWINS",
    ritual_start         = "RITUAL",
    ritual_spawn         = "RITUAL DH",
    ambush_horde         = "AMBUSH",
}

-- Lower sorts first when two triggers sit at the same distance.
--[[
    Ritual triggers sort near the top.

    A ritual is a 55m PROXIMITY trigger that forces a horde
    (havoc_mutator_local_settings.lua:509-510), so unlike a monster candidate it
    cannot be dodged by passing at an angle. Only a scripted boss outranks it.
--]]
local KIND_WEIGHT = {
    boss_trigger         = 1,
    ritual_start         = 2,
    twins_spawn_trigger  = 3,
    ritual_spawn         = 4,
    -- Ambush hordes are scripted set-pieces at fixed sites: they fire when
    -- crossed, so they outrank the probabilistic pacing kinds.
    ambush_horde         = 4,
    twins_ambush_trigger = 5,
    pacing_monsters      = 6,
    pacing_captains      = 7,
    boss_patrol_trigger  = 8,
    pacing_witches       = 9,
}

-- ---------------------------------------------------------------------------
-- Per-mission state
-- ---------------------------------------------------------------------------

--[[
    odds and challenge_tier are declared HERE, with the rest of the per-mission
    state, not next to the probability code that populates them.

    They used to be declared further down, below refresh_live. A Lua local only
    exists from its declaration onward, so refresh_live's `odds = {}` was
    creating a GLOBAL while upcoming() kept reading the still-empty local - live
    spawns rendered as 11% candidates instead of 100% certainties. Silent, and
    only visible because the simulation printed the number.
--]]
local odds       = {}     -- kind -> probability 0..1
local challenge_tier = nil

local triggers   = {}     -- sorted array: { dist, kind, label, consumed }
local mission_id = nil
local path_total = nil    -- cached map length, for staleness detection
local stale      = false
local budget     = {}     -- kind -> { seen, candidates }

local function add_kind(list, tbl, kind)
    if type(tbl) ~= "table" then
        return
    end
    for i = 1, #tbl do
        local d = tonumber(tbl[i])
        if d and d == d then
            list[#list + 1] = {
                dist     = d,
                kind     = kind,
                label    = KIND_LABEL[kind] or kind,
                weight   = KIND_WEIGHT[kind] or 9,
                consumed = false,
            }
        end
    end
end

--[[
    Merge co-located triggers.

    Measured across the cached maps: 56% of daemonhost points sit within 15m of
    a monster point, and 76% within 30m. That is not coincidence -
    _generate_spawns shares SECTION indices between monsters and witches when
    allow_witches_spawned_with_monsters is set (true at challenge tiers 4-5), so
    the two types draw from overlapping geometry.

    The practical consequence is the one you hit in game: a marker labelled
    DAEMONHOST is very often the same physical spot as a monster candidate, so
    when something spawns there it may well be an ogryn. Showing them as two
    separate rows metres apart implied a precision the data does not have.

    Merged entries keep the HIGHEST-priority label and carry every kind, so the
    budget counters still attribute correctly.
--]]
local MERGE_RADIUS = 15

local function merge_colocated(list)
    local merged = {}

    for i = 1, #list do
        local tr = list[i]
        local into = nil

        for j = #merged, 1, -1 do
            local m = merged[j]
            if tr.dist - m.dist > MERGE_RADIUS then
                break        -- sorted, so nothing earlier can be in range
            end
            if m.kind ~= tr.kind then
                into = m
                break
            end
        end

        if into then
            into.kinds = into.kinds or { [into.kind] = true }
            into.kinds[tr.kind] = true
            -- Lower weight sorts first and is the scarier type; let it own the
            -- label so a patrol never hides behind a daemonhost.
            if tr.weight < into.weight then
                into.kind   = tr.kind
                into.label  = tr.label
                into.weight = tr.weight
            end
        else
            merged[#merged + 1] = tr
        end
    end

    return merged
end

--[[
    Build the trigger list for a mission.

    pacing_monsters and pacing_captains are always the same array in the cache
    (they share spawn_point_sections), so listing both would double every row
    for no information. Captains are folded in only where they differ.
--]]
function Spawns.set_mission(name)
    triggers, path_total, stale, budget = {}, nil, false, {}
    mission_id = name

    --[[
        User cache first, bundled second.

        A mission you recorded yourself was captured on this game version, so if
        both exist yours is the fresher description. The bundled cache stays as
        the fallback for everything you have not hosted.
    --]]
    local data = load_cache()
    local uc = load_user_cache()
    local m = (uc and name and uc.maps and uc.maps[name])
              or (data and name and data.maps and data.maps[name])
    if not m then
        return false
    end

    if type(m.path) == "table" then
        -- User-recorded entries store path.total too, so this covers both.
        path_total = tonumber(m.path.total)
    end

    local pacing = m.pacing
    if type(pacing) == "table" then
        add_kind(triggers, pacing.pacing_monsters, "pacing_monsters")
        add_kind(triggers, pacing.pacing_witches,  "pacing_witches")

        --[[
            Captains share monster points by construction.

            monster_pacing.lua:575-577 - add_spawn_point, when called for
            "monsters", immediately calls itself again for "captains" with the
            same position. So the two arrays are identical in every cached map,
            and a monster marker IS a captain marker.

            The label says so, because a captain appearing at a point marked
            MONSTER otherwise looks like the forecast was wrong when it was
            exactly right.
        --]]

        -- Captains only if the array genuinely differs from monsters.
        local mo, ca = pacing.pacing_monsters, pacing.pacing_captains
        local differs = false
        if type(ca) == "table" and type(mo) == "table" then
            if #ca ~= #mo then
                differs = true
            else
                for i = 1, #ca do
                    if ca[i] ~= mo[i] then differs = true break end
                end
            end
        elseif type(ca) == "table" then
            differs = true
        end
        if differs then
            add_kind(triggers, ca, "pacing_captains")
        end
    end

    --[[
        Ritual trigger points.

        Cached as travel distances under `ritual`, with three sub-lists:
        `start` (the ritual arms), `spawn` (its daemonhost appears) and
        `speedup`. Only 5 of the 27 cached maps have them - dm_propaganda,
        fm_resurgence, km_enforcer, km_heresy and lm_scavenge - so the absence
        of ritual rows elsewhere is the data, not a fault.

        Surfacing these is what gives warning BEFORE a ritual, rather than only
        once its daemonhost has already spawned nearby.
    --]]
    --[[
        AMBUSH HORDES.

        Present in the cache the whole time and never read - this is the ambush
        counter that has shown "?" since the beginning.

        The recorded values are CLUSTERED, because one ambush site registers
        several spawn points a few metres apart:

            hm_complex     379.5, 380.3, 379.2          -> one site
            lm_scavenge    50 entries spanning 161-166  -> one site
            dm_propaganda  11 entries spanning 783-790  -> one site

        Listing them raw would put fifty near-identical rows on the panel, so
        they are collapsed to one entry per cluster.

        fm_armoury records a single 0.0, which is a spawner that never resolved
        to a path position rather than an ambush at the mission start line.
        Zero is discarded.
    --]]
    local ambush = m.ambush
    if type(ambush) == "table" and type(ambush.ambush_horde) == "table" then
        local raw = {}
        for i = 1, #ambush.ambush_horde do
            local d = tonumber(ambush.ambush_horde[i])
            -- Guard against the 0.0 sentinel and anything negative.
            if d and d > 1 then
                raw[#raw + 1] = d
            end
        end
        table.sort(raw)

        local clustered = {}
        for i = 1, #raw do
            local last = clustered[#clustered]
            if not last or raw[i] - last > 20 then
                clustered[#clustered + 1] = raw[i]
            end
        end

        add_kind(triggers, clustered, "ambush_horde")
    end

    local ritual = m.ritual
    if type(ritual) == "table" then
        add_kind(triggers, ritual.start, "ritual_start")
        add_kind(triggers, ritual.spawn, "ritual_spawn")
    end

    local boss = m.boss
    if type(boss) == "table" then
        --[[
            KEY NAMES ARE THE CACHE'S, NOT MINE.

            These were `twins_ambush_trigger` / `twins_spawn_trigger`, invented
            to match my internal kind names. The cache actually stores
            `twins_ambush` and `twins_spawn`, so both lookups were nil and twins
            were never surfaced on any map - despite being recorded for five of
            them (up to 15 spawn points on km_heresy).

            Verified against the file rather than assumed:
              boss:   boss_patrol_trigger, boss_trigger, twins_ambush, twins_spawn
              ritual: start, spawn, speedup
              pacing: pacing_monsters, pacing_captains, pacing_witches
              ambush: ambush_horde
        --]]
        add_kind(triggers, boss.boss_patrol_trigger, "boss_patrol_trigger")
        add_kind(triggers, boss.boss_trigger,        "boss_trigger")
        add_kind(triggers, boss.twins_ambush,        "twins_ambush_trigger")
        add_kind(triggers, boss.twins_spawn,         "twins_spawn_trigger")

        --[[
            Self-observed entries also live in the boss bucket - note_observed
            files anything not prefixed pacing_ here - so they must be read back
            or the data you collected while hosting would be written and then
            silently ignored on the next run.
        --]]
        add_kind(triggers, boss.ritual_start, "ritual_start")
        add_kind(triggers, boss.ritual_spawn, "ritual_spawn")
    end

    table.sort(triggers, function(a, b)
        if a.dist == b.dist then
            return a.weight < b.weight
        end
        return a.dist < b.dist
    end)

    triggers = merge_colocated(triggers)

    for i = 1, #triggers do
        local k = triggers[i].kind
        budget[k] = budget[k] or { seen = 0, candidates = 0 }
        budget[k].candidates = budget[k].candidates + 1
    end

    return #triggers > 0
end

function Spawns.mission()
    return mission_id
end

function Spawns.count()
    return #triggers
end

-- ---------------------------------------------------------------------------
-- Staleness
--
-- Ported from RitualZones' update_path_signature. If Fatshark moves geometry in
-- a patch, the cached distances silently stop matching the live map. Comparing
-- the live main-path length against the recorded one catches that: it is one
-- number, it is cheap, and a mismatch is decisive.
--
-- We do NOT hide the rows when stale - we drop their confidence, so the panel
-- degrades instead of vanishing.
-- ---------------------------------------------------------------------------

--[[
    Tolerance is PROPORTIONAL, not a fixed 15m.

    Several missions contain crossroads, and the route taken varies per run, so
    the live main-path length legitimately differs from whatever was recorded -
    by tens of metres on a 1100m map. A flat 15m threshold flagged healthy runs
    as stale, which is worse than not checking at all: it trains you to ignore
    the warning. 10% still catches a patch that genuinely moves geometry.
--]]
local STALE_TOLERANCE_FRAC = 0.10

function Spawns.check_staleness(live_total)
    if not path_total or not live_total or live_total <= 0 then
        return false
    end
    local was_stale = stale
    stale = math.abs(live_total - path_total) > path_total * STALE_TOLERANCE_FRAC

    --[[
        Warn ONCE per mission, not once per check.

        ensure_mission is retried every second while the trigger list is empty -
        which is permanent on maps that have no pacing data at all, like the
        Meat Grinder. That turned a one-off warning into a line of console spam
        every second for the entire session.
    --]]
    if stale and was_stale then
        return stale
    end
    if stale then
        mod:warning(
            "[HavocTracker] spawn cache looks stale for %s: cached path %.0fm, live %.0fm",
            tostring(mission_id), path_total, live_total)
    end
    return stale
end

function Spawns.is_stale()
    return stale
end

function Spawns.path_total()
    return path_total
end

-- ---------------------------------------------------------------------------
-- Consumption
--
-- When a monster actually spawns, retire the nearest un-consumed candidate at
-- or behind the lead player. That is where the game just fired, because
-- update() takes the first entry whose distance the lead player has crossed.
--
-- This is a heuristic: we cannot see _monsters, so we cannot know WHICH
-- candidate was armed. But retiring a passed candidate is always safe - it can
-- never fire again either way, since the lead player has already crossed it.
-- ---------------------------------------------------------------------------

function Spawns.observe_spawn(kind, lead)
    if not lead then
        return
    end
    local best, best_d = nil, nil
    for i = 1, #triggers do
        local tr = triggers[i]
        if not tr.consumed and tr.kind == kind and tr.dist <= lead then
            local gap = lead - tr.dist
            if not best_d or gap < best_d then
                best, best_d = tr, gap
            end
        end
    end
    if best then
        best.consumed = true
        local b = budget[kind]
        if b then b.seen = b.seen + 1 end
    end
end

--[[
    Sweep everything the lead player has walked past.

    Called every path update. A candidate behind the lead player is dead: the
    <= test in MonsterPacing.update can never be re-satisfied by moving
    forward, and backtracking does not re-arm it because the entry is removed
    from _monsters on spawn.
--]]
function Spawns.retire_passed(lead)
    if not lead then
        return
    end
    for i = 1, #triggers do
        local tr = triggers[i]
        if not tr.consumed and tr.dist <= lead then
            tr.consumed = true
        end
    end
end

--[[
    Returns (passed, total) for a kind.

    `passed` counts CONSUMED candidates, not observed spawns. Those are
    different numbers and the distinction matters: retire_passed marks a
    candidate consumed the moment the lead player crosses it, whether or not
    anything spawned there, because a crossed candidate is dead either way.
    Counting only confirmed spawns would leave this near zero all mission and
    tell you nothing about how much of the map's danger you have cleared.
--]]
--[[
    Does this trigger include the given kind?

    After merging, one entry can stand for several kinds - a monster point and a
    daemonhost point 8m apart become a single marker. Counting by tr.kind alone
    would silently drop the absorbed kinds from both the budget line and the
    odds denominator, which would in turn inflate the odds for exactly the type
    that got merged away.
--]]
local function has_kind(tr, kind)
    if tr.kind == kind then
        return true
    end
    return tr.kinds ~= nil and tr.kinds[kind] == true
end

function Spawns.budget_of(kind)
    local total, passed = 0, 0
    for i = 1, #triggers do
        local tr = triggers[i]
        if has_kind(tr, kind) then
            total = total + 1
            if tr.consumed then
                passed = passed + 1
            end
        end
    end
    return passed, total
end

-- ---------------------------------------------------------------------------
-- LIVE pacing source (hosting only)
--
-- Everything above works from RitualZones' recorded cache, which has one
-- structural flaw that cannot be fixed by better code: crossroads are stitched
-- per run from level_seed (main_path_manager.lua:41-45) and unused branches are
-- DELETED from the path. A cache recorded on one seed therefore describes a
-- route that does not exist on another - markers land at the right distance
-- along the wrong geometry, which is how they ended up in the sky.
--
-- While HOSTING, none of that guesswork is necessary. Managers.state.pacing
-- exists, and _monster_pacing._monsters holds THIS run's actual rolled spawns:
--
--     { travel_distance, breed_name, position, section,
--       despawn_distance_when_passive, spawn_type }      (monster_pacing.lua:220-227)
--
-- That is exact. Real trigger distances on the real stitched path, real world
-- positions, and the exact breed - so odds become 100% rather than 8%, because
-- these are the armed spawns, not candidates.
--
-- Entries are table.remove'd when they fire (monster_pacing.lua:695), so
-- re-reading also gives us consumption for free.
-- ---------------------------------------------------------------------------

local live_mode = false

local BREED_LABEL = {
    chaos_plague_ogryn     = "OGRYN",
    chaos_beast_of_nurgle  = "BEAST",
    chaos_spawn            = "CHAOS SPAWN",
    chaos_daemonhost       = "DAEMONHOST",
    chaos_ogryn_houndmaster = "HOUNDMASTER",
    renegade_captain       = "CAPTAIN",
    cultist_captain        = "CAPTAIN",
    renegade_twin_captain  = "TWINS",
    renegade_twin_captain_two = "TWINS",
}

local BREED_WEIGHT = {
    chaos_daemonhost = 7,
}

--[[
    Unbox a position that may arrive boxed or raw.

    Spawn point positions are stored by the engine and we do not control which
    form they take across versions, so handle both and box our own copy for
    persistence (Vector3 is frame-temporary - see position_at).
--]]
local function box_position(p)
    if not p then
        return nil
    end
    if type(p) == "table" or (p.unbox ~= nil) then
        local ok, v = pcall(function() return p:unbox() end)
        if ok and v then
            local okb, b = pcall(Vector3Box, v)
            return okb and b or nil
        end
    end
    local okb, b = pcall(Vector3Box, p)
    return okb and b or nil
end

function Spawns.is_live()
    return live_mode
end

--[[
    Rebuild triggers from live pacing data. Returns true if it took.

    Safe to call on clients: Managers.state.pacing is nil there and we simply
    report false, leaving the cached data in place.
--]]
function Spawns.refresh_live()
    local pacing = Managers.state and Managers.state.pacing
    local mp = pacing and pacing._monster_pacing
    if not mp then
        return false
    end

    local monsters = mp._monsters
    local patrols  = mp._boss_patrols
    if type(monsters) ~= "table" then
        return false
    end

    local list = {}

    for i = 1, #monsters do
        local m = monsters[i]
        local d = tonumber(m and m.travel_distance)
        if d then
            local breed = m.breed_name or ""
            list[#list + 1] = {
                dist     = d,
                kind     = "pacing_" .. tostring(m.spawn_type or "monsters"),
                label    = BREED_LABEL[breed] or "MONSTER",
                weight   = BREED_WEIGHT[breed] or 4,
                consumed = false,
                live     = true,
                pos      = box_position(m.position),
                despawn  = m.despawn_distance_when_passive,
            }
        end
    end

    if type(patrols) == "table" then
        for i = 1, #patrols do
            local p = patrols[i]
            local d = tonumber(p and p.travel_distance)
            if d then
                list[#list + 1] = {
                    dist     = d,
                    kind     = "boss_patrol_trigger",
                    label    = "PATROL",
                    weight   = 6,
                    consumed = false,
                    live     = true,
                    pos      = box_position(p.position),
                }
            end
        end
    end

    table.sort(list, function(a, b)
        if a.dist == b.dist then return a.weight < b.weight end
        return a.dist < b.dist
    end)

    triggers  = list
    live_mode = true
    stale     = false          -- live data cannot be stale by definition

    --[[
        Live entries are certainties, so every kind reads 100%. This is the
        single biggest accuracy jump in the mod: an 8% candidate becomes a
        confirmed spawn with a known breed.
    --]]
    odds = {}
    for i = 1, #triggers do
        odds[triggers[i].kind] = 1
    end

    return true
end

-- ---------------------------------------------------------------------------
-- Hit probability
--
-- The number that turns this from a map of geography into a threat readout.
--
-- generate_monster_spawns rolls num_to_spawn sections at random out of the
-- candidate set, so the chance any GIVEN marker is armed is roughly
--     expected_spawns / num_candidates
--
-- Concretely on cm_habs at high challenge: 1-2 monsters over 19 candidates is
-- about 8%, while boss patrols are 1-3 over a single candidate - which is why
-- patrol markers land every time and daemonhost markers almost never do.
--
-- num_spawns comes from havoc_monster_pacing_template.lua, indexed by challenge.
-- We read the live template when we can so a patch cannot silently invalidate
-- this, and fall back to a transcribed copy when we cannot.
-- ---------------------------------------------------------------------------

local HAVOC_TEMPLATE_PATH =
    "scripts/managers/pacing/monster_pacing/templates/havoc_monster_pacing_template"

--[[
    Transcribed from havoc_monster_pacing_template.lua as of this build.
    Index = challenge tier 1-5. Ranges are {min, max}; a bare 0 means none.
--]]
local HAVOC_FALLBACK = {
    { monsters = { 0, 1 }, witches = { 0, 0 }, patrols = { 0, 0 } },
    { monsters = { 0, 1 }, witches = { 0, 0 }, patrols = { 0, 0 } },
    { monsters = { 0, 2 }, witches = { 0, 1 }, patrols = { 1, 2 } },
    { monsters = { 1, 2 }, witches = { 0, 2 }, patrols = { 1, 2 } },
    { monsters = { 1, 2 }, witches = { 0, 2 }, patrols = { 1, 3 } },
}

-- odds / challenge_tier are declared with the per-mission state near the top.

local function mean_of(v)
    if type(v) == "table" then
        return ((tonumber(v[1]) or 0) + (tonumber(v[2]) or 0)) * 0.5
    end
    return tonumber(v) or 0
end

local function current_challenge()
    local dm = Managers.state and Managers.state.difficulty
    if not dm or not dm.get_challenge then
        return nil
    end
    local ok, c = pcall(dm.get_challenge, dm)
    if ok and type(c) == "number" then
        return math.max(1, math.min(5, math.floor(c)))
    end
    return nil
end

--[[
    Expected spawn counts for the active challenge tier.

    Tries the live template first. get_table_entry_by_challenge is the same
    selector MonsterPacing itself uses (monster_pacing.lua:144, 984), so this
    picks the identical entry rather than guessing the indexing rule.
--]]
local function expected_counts()
    local tier = current_challenge()
    challenge_tier = tier

    local ok, live = pcall(function()
        local tmpl = require(HAVOC_TEMPLATE_PATH)
        local entries = tmpl and tmpl.challenge_templates
        if not entries then return nil end

        local dm = Managers.state.difficulty
        local entry
        if dm and dm.get_table_entry_by_challenge then
            entry = dm:get_table_entry_by_challenge(entries)
        end
        entry = entry or (tier and entries[tier])
        if not entry then return nil end

        local ns = entry.num_spawns or {}
        local bp = entry.boss_patrols and entry.boss_patrols.num_boss_patrols_range
        return {
            monsters = mean_of(ns.monsters),
            witches  = mean_of(ns.witches),
            patrols  = bp and mean_of(bp) or 0,
        }
    end)

    if ok and live then
        return live
    end

    local fb = HAVOC_FALLBACK[tier or 5]
    return {
        monsters = mean_of(fb.monsters),
        witches  = mean_of(fb.witches),
        patrols  = mean_of(fb.patrols),
    }
end

--[[
    Recompute odds. Called once per mission bind, and whenever the tier moves.
--]]
function Spawns.recompute_odds()
    --[[
        Never downgrade live data to a probability.

        refresh_live sets every kind to 1 because those entries ARE the armed
        spawns. Running the candidate maths over them would replace a certainty
        with an 8% estimate - strictly worse information.
    --]]
    if live_mode then
        return
    end

    odds = {}
    local exp = expected_counts()

    -- Count every kind an entry stands for, not just its display label.
    local counts = {}
    for i = 1, #triggers do
        local tr = triggers[i]
        if tr.kinds then
            for k in pairs(tr.kinds) do
                counts[k] = (counts[k] or 0) + 1
            end
        else
            counts[tr.kind] = (counts[tr.kind] or 0) + 1
        end
    end

    local map = {
        pacing_monsters     = exp.monsters,
        pacing_captains     = exp.monsters,
        pacing_witches      = exp.witches,
        boss_patrol_trigger = exp.patrols,
    }

    for kind, expected in pairs(map) do
        local n = counts[kind]
        if n and n > 0 then
            -- Cap at 1: more expected spawns than candidates means every
            -- candidate is used.
            odds[kind] = math.min(1, expected / n)
        end
    end

    --[[
        Scripted triggers: 1/N, NOT 100%.

        I previously hardcoded these to certainty on the reasoning that a
        scripted set-piece always fires. That is only true when the map has ONE
        candidate for it. The cached data has many - lm_scavenge alone carries
        dozens of boss and twins points - and marking every one 100% produced
        exactly what you saw: five markers in a row all claiming certainty, none
        of which spawned anything.

        A scripted trigger fires roughly once per mission, so with N recorded
        candidate locations the chance any GIVEN one is the live one is about
        1/N. That is the same reasoning the pacing kinds already use, and it
        degrades correctly: one candidate still reads 100%, twenty read 5%.

        Ritual kinds are handled the same way. num_to_spawn_per_mission gives a
        real count where we have it, so use that in preference.
    --]]
    local scripted = {
        ambush_horde         = 1,
        boss_trigger         = 1,
        twins_spawn_trigger  = 1,
        twins_ambush_trigger = 1,
        ritual_start         = nil,   -- filled from settings below
        ritual_spawn         = nil,
    }

    -- Rituals have a published per-mission count; prefer it over assuming one.
    local ritual_expected = nil
    pcall(function()
        local H = rawget(_G, "HavocMutatorLocalSettings")
            or require("scripts/settings/havoc/havoc_mutator_local_settings")
        local s = H and H.mutator_havoc_chaos_rituals
        local per = s and s.num_to_spawn_per_mission
        ritual_expected = per and mission_id and per[mission_id] or nil
    end)
    scripted.ritual_start = ritual_expected or 1
    scripted.ritual_spawn = ritual_expected or 1

    for kind, expected in pairs(scripted) do
        local n = counts[kind]
        if n and n > 0 then
            odds[kind] = math.min(1, expected / n)
        end
    end
end

--[[
    What a monster spawn DOES to pacing, at the current challenge tier.

    This is the most decision-relevant asymmetry in the whole pacing system and
    it inverts exactly where you play.

    monster_pacing.lua:912-920 - if template.force_horde is set, spawning a
    monster calls Managers.state.pacing:force_horde_pacing_spawn(). Not a roll,
    not a chance: a direct call.

    monster_pacing.lua:945-952 - pause_pacing_on_spawn[breed] suspends each
    listed spawn type for its duration.

    In havoc_monster_pacing_template.lua:
        tiers 1-2  pause hordes 60s, specials 50s, trickle 40s. No forced horde.
        tier  3    pause specials 15s. Forced horde.
        tiers 4-5  pause NOTHING. Forced horde.

    So at low challenge a monster buys you a breather; at Havoc it hands you a
    monster AND a guaranteed horde with nothing suppressed. Anyone calling
    "brace, horde with this ogryn" at rank 40 is reading this rule.
--]]
local HAVOC_EFFECTS = {
    { force_horde = false, pause = { hordes = 60, specials = 50, trickle_hordes = 40 } },
    { force_horde = false, pause = { hordes = 60, specials = 20, trickle_hordes = 40 } },
    { force_horde = true,  pause = { specials = 15 } },
    { force_horde = true,  pause = {} },
    { force_horde = true,  pause = {} },
}

function Spawns.spawn_effects()
    local tier = challenge_tier or current_challenge() or 5

    -- Prefer the live template so a patch cannot silently invalidate this.
    local ok, live = pcall(function()
        local tmpl = require(HAVOC_TEMPLATE_PATH)
        local entries = tmpl and tmpl.challenge_templates
        if not entries then return nil end

        local dm = Managers.state.difficulty
        local entry
        if dm and dm.get_table_entry_by_challenge then
            entry = dm:get_table_entry_by_challenge(entries)
        end
        entry = entry or entries[tier]
        if not entry then return nil end

        -- pause_pacing_on_spawn is keyed by BREED; every monster breed in a
        -- given tier carries the same durations, so read the first one.
        local pause = {}
        for _, per_type in pairs(entry.pause_pacing_on_spawn or {}) do
            for spawn_type, duration in pairs(per_type) do
                pause[spawn_type] = duration
            end
            break
        end

        return { force_horde = entry.force_horde and true or false, pause = pause }
    end)

    if ok and live then
        return live
    end

    local fb = HAVOC_EFFECTS[tier] or HAVOC_EFFECTS[5]
    return { force_horde = fb.force_horde, pause = fb.pause }
end

function Spawns.odds_of(kind)
    return odds[kind]
end

--[[
    Combined odds for a trigger entry.

    A merged marker fires if ANY of the kinds it stands for fires, so the
    probabilities compose as 1 - product(1 - p). Reporting only the labelled
    kind's odds would understate a merged point - which is the case you noticed,
    where a "9%" daemonhost marker produced a monster.
--]]
local function combined_odds(tr)
    if not tr.kinds then
        return odds[tr.kind]
    end

    local miss, seen = 1, false
    for k in pairs(tr.kinds) do
        local p = odds[k]
        if p then
            miss = miss * (1 - p)
            seen = true
        end
    end

    if not seen then
        return nil
    end
    return 1 - miss
end

function Spawns.challenge_tier()
    return challenge_tier
end

-- ---------------------------------------------------------------------------
-- Query
-- ---------------------------------------------------------------------------

--[[
    Upcoming triggers, nearest first.

    Returns an array of { label, kind, dist, gap, band } where gap is metres
    from the LEAD player to the trigger line, and band is one of
    "safe" / "near" / "close" / "imminent".

    Bands are metres-to-trigger, not a fraction of anything: 15m is 15m whether
    the map is 900m or 1400m long, and the thing you are reacting to is how
    long you have before the lead player crosses the line.
--]]
local BAND_IMMINENT = 15
local BAND_CLOSE    = 30
local BAND_NEAR     = 60

--[[
    Result buffer AND its row tables are both reused.

    The first version reused `out` but allocated a fresh table per row inside
    the loop. Since the HUD calls this every frame, that was four throwaway
    tables per frame - about 240 a second - which is exactly the kind of steady
    churn that shows up as a climbing Lua heap. The rows are now preallocated
    once and mutated in place, so a steady-state frame allocates nothing here.

    Consequence for callers: the returned tables are VOLATILE. Read them during
    the frame; do not hold a reference across frames.
--]]
--[[
    Raised from 8 to 16.

    The panel now asks for more rows than it displays, so it can count how many
    upcoming triggers fall outside its distance cap and show that as "+N". With
    the old ceiling of 8 that count silently saturated - the panel would show
    "+4" whether four or forty were pending, which is worse than showing
    nothing because it looks like a real number.

    These are preallocated once and mutated in place, so the only cost of the
    larger pool is 8 more small tables for the lifetime of the process.
--]]
local MAX_OUT = 16
local out = {}
local row_pool = {}

for i = 1, MAX_OUT do
    row_pool[i] = { label = "", kind = "", dist = 0, gap = 0, band = "safe", odds = nil }
end

local function band_for(gap)
    if gap <= BAND_IMMINENT then return "imminent" end
    if gap <= BAND_CLOSE    then return "close"    end
    if gap <= BAND_NEAR     then return "near"     end
    return "safe"
end

--[[
    EXACT count of un-consumed triggers ahead of the lead.

    Spawns.upcoming can only ever report on the rows it actually built, capped
    at MAX_OUT. The spawn panel was deriving its "+N" hidden count from that
    capped list, so the number saturated - the comment above MAX_OUT describes
    the same problem at the old ceiling of 8 and raised the POOL to 16, but the
    panel still only requests MAX_ROWS + 8 = 12, so in practice "+N" still
    could not exceed 8. Enlarging the pool fixed half of it.

    This counts without building anything, so the panel can show the true
    figure no matter how far it exceeds what the pool could hold. No
    allocation: one integer and a loop over an already-sorted array.
--]]
--[[
    Triggers you have physically moved PAST, ignoring whether they fired.

    Spawns.remaining() conflates two different things: triggers ahead of you
    (positional) and triggers not yet consumed (event-driven). observe_spawn
    marks a trigger consumed when a monster spawns, so remaining() drops on a
    SPAWN as well as on movement.

    Anything watching remaining() for "did we cross into a new area" therefore
    fires when a boss spawns, which is how a weakened monstrosity ended up
    resetting the specialist wave counter to 0/10.

    This is purely positional: it counts triggers behind the lead player and
    nothing else can change it. It rises with progress and falls if you walk
    back, so a high-water mark over it detects a genuine first crossing.
--]]
function Spawns.passed(lead)
    if not lead then
        return 0
    end

    local n = 0

    for i = 1, #triggers do
        if triggers[i].dist <= lead then
            n = n + 1
        end
    end

    return n
end

function Spawns.remaining(lead)
    if not lead then
        return 0
    end

    local n = 0

    for i = 1, #triggers do
        local tr = triggers[i]
        if not tr.consumed and tr.dist > lead then
            n = n + 1
        end
    end

    return n
end

function Spawns.upcoming(lead, limit)
    for i = #out, 1, -1 do
        out[i] = nil
    end
    if not lead or #triggers == 0 then
        return out
    end

    limit = math.min(limit or 4, MAX_OUT)
    local n = 0

    for i = 1, #triggers do
        local tr = triggers[i]
        if not tr.consumed and tr.dist > lead then
            local gap = tr.dist - lead

            n = n + 1
            local r = row_pool[n]
            r.label = tr.label
            r.kind  = tr.kind
            r.dist  = tr.dist
            r.gap   = gap
            r.band  = band_for(gap)
            r.odds  = combined_odds(tr)  -- nil when unknown, 0..1 otherwise
            out[n]  = r

            if n >= limit then
                break
            end
        end
    end

    return out
end

--[[
    Guaranteed-clear distance.

    The single most useful number here, and the one nothing else in the mod can
    give you: metres from the lead player to the nearest candidate of ANY kind.
    Inside this distance no monster, captain, patrol or daemonhost can be
    triggered by the pacing system. This is what "safe to push" actually means.

    Returns nil when there are no candidates left, which means clear to the end.
--]]
function Spawns.clear_for(lead)
    if not lead then
        return nil
    end
    for i = 1, #triggers do
        local tr = triggers[i]
        if not tr.consumed and tr.dist > lead then
            return tr.dist - lead
        end
    end
    return nil
end

--[[
    World position at a travel distance.

    The cache stores travel distances only, so the wall marker has to convert
    one back into a world point. There is NO engine call for this - I checked:
    main_path_manager.lua exposes travel_distance_from_position (world -> scalar)
    but nothing for the inverse. So we walk the path ourselves.

    _calculate_travel_distances (main_path_manager.lua:93-122) gives us exactly
    what we need: every segment carries `nodes` (BOXED Vector3 - they must be
    :unbox()'d) and a parallel `travel_distances` array. Find the node pair that
    brackets the target distance and lerp between them.

    Results are memoised per mission. A trigger's world position never moves, so
    this runs once per marker for the whole mission, not per frame.
--]]
--[[
    Positions are cached as Vector3Box, NOT as Vector3.

    THIS IS THE BUG THAT HAS BITTEN THIS MOD TWICE.

    Vector3 in Stingray is a temporary, frame-allocated value. Storing one in a
    Lua table and reading it on a later frame yields userdata that the engine no
    longer recognises - which surfaces as:

        bad argument #1 to 'x' (Vector3 expected, got userdata)

    and previously as the unexplained
        distance_squared: Vector3 expected, got userdata
    that I papered over with a pcall instead of fixing.

    Vector3Box is the persistent form. Fatshark boxes every stored position for
    exactly this reason (main_path_manager.lua stores boxed nodes and calls
    :unbox(); hud_element_world_markers.lua uses Vector3Box.store). We box on
    write and unbox on every read, so callers always get a live value.
--]]
local position_cache = {}
local direction_cache = {}

--[[
    Path tangent at a travel distance, as a live Vector3.

    Populated as a side effect of position_at, so call that first. Boxed for the
    same lifetime reason as positions.
--]]
function Spawns.direction_at(distance)
    local boxed = direction_cache[distance]
    if not boxed then
        return nil
    end
    local ok, v = pcall(boxed.unbox, boxed)
    return (ok and v) or nil
end

function Spawns.position_at(distance)
    if not distance then
        return nil
    end

    --[[
        Live triggers carry the engine's OWN spawn position.

        Prefer it absolutely. The path-walk fallback below reconstructs a
        position by lerping between main-path nodes, which is correct only if
        the cached distance refers to this run's stitched route - the exact
        assumption that breaks on crossroad maps. When hosting we do not have
        to assume anything.
    --]]
    if live_mode then
        for i = 1, #triggers do
            local tr = triggers[i]
            if tr.dist == distance and tr.pos then
                local ok, v = pcall(tr.pos.unbox, tr.pos)
                if ok and v then
                    return v
                end
                break
            end
        end
    end

    --[[
        Ask the ENGINE for the position at a travel distance.

        MainPathQueries.position_from_distance -> EngineOptimized.point_on_mainpath
        is the exact inverse of the distance query, it is client-safe (it reads
        the unified path registered in setup_for_level rather than the
        server-only spawn-point groups), and it operates on THIS run's stitched
        crossroads - so it does not suffer the seed mismatch that put markers in
        the sky.

        This supersedes the manual segment walk below, which stays only as a
        fallback for builds where the engine call is unavailable.
    --]]
    do
        -- Raw engine call first, same reasoning as mpq_travel_distance: the
        -- Lua wrappers add post-processing that can throw on a nil return.
        -- Gated on a REGISTERED path, not merely on the function existing:
        -- calling this with no path registered is a native null dereference
        -- that pcall cannot catch. See main_path_ready() in HavocTracker.lua.
        local EO = rawget(_G, "EngineOptimized")
        if EO and EO.point_on_mainpath and mod.main_path_ready and mod.main_path_ready() then
            local ok, p = pcall(EO.point_on_mainpath, distance)
            if ok and p then
                return p
            end
        end

        local ok, m = pcall(require, "scripts/utilities/main_path_queries")
        if ok and m and m.position_from_distance then
            local ok2, p = pcall(m.position_from_distance, distance)
            if ok2 and p then
                return p
            end
        end
    end

    local hit = position_cache[distance]
    if hit ~= nil then
        if hit == false then
            return nil          -- already tried and failed
        end
        -- Unbox fresh every call: the previous unbox is dead by now.
        local ok, v = pcall(hit.unbox, hit)
        return (ok and v) or nil
    end

    local main_path = Managers.state and Managers.state.main_path
    if not main_path or not main_path.main_path_segments then
        return nil
    end

    local ok, result = pcall(function()
        local segments = main_path:main_path_segments()
        if type(segments) ~= "table" then
            return nil
        end

        for i = 1, #segments do
            local seg = segments[i]
            local dists, nodes = seg.travel_distances, seg.nodes
            if dists and nodes then
                for j = 2, #dists do
                    if dists[j] >= distance then
                        local d0, d1 = dists[j - 1], dists[j]
                        local span = d1 - d0
                        local frac = span > 0 and (distance - d0) / span or 0
                        local p0 = nodes[j - 1]:unbox()
                        local p1 = nodes[j]:unbox()

                        --[[
                            Also capture the path TANGENT here.

                            The trigger is a distance along the path, so the
                            thing you actually cross is a plane perpendicular to
                            the path at that point. Drawing that correctly needs
                            the direction, and this is the only place we have
                            both bracketing nodes in hand.
                        --]]
                        direction_cache[distance] =
                            Vector3Box(Vector3.normalize(p1 - p0))

                        return Vector3.lerp(p0, p1, frac)
                    end
                end
            end
        end
        return nil
    end)

    if not ok or not result then
        position_cache[distance] = false
        return nil
    end

    -- Box for storage, then hand back the live value we already have.
    local boxed_ok, boxed = pcall(Vector3Box, result)
    position_cache[distance] = (boxed_ok and boxed) or false
    return result
end

function Spawns.reset()
    triggers, mission_id, path_total, stale, budget = {}, nil, nil, false, {}
    position_cache = {}
    direction_cache = {}
    live_mode = false
end

--[[
    Live main-path length, for the staleness check.

    Summing segment path_lengths is the only client-safe way to get this:
    _calculate_travel_distances stores a per-segment path_length, and the last
    segment's final travel_distance is the running total for the whole path.
--]]
local function live_path_total()
    --[[
        Client-safe first: EngineOptimized.main_path_total_length reports the
        stitched length for this run without touching server-only state.
    --]]
    do
        -- total_path_distance bottoms out in EngineOptimized.main_path_total_length,
        -- so it needs the same registered-path gate as every other engine query.
        local ok, m = pcall(require, "scripts/utilities/main_path_queries")
        if ok and m and m.total_path_distance
            and mod.main_path_ready and mod.main_path_ready() then
            local ok2, total = pcall(m.total_path_distance)
            if ok2 and type(total) == "number" and total > 0 then
                return total
            end
        end
    end

    local main_path = Managers.state and Managers.state.main_path
    if not main_path or not main_path.main_path_segments then
        return nil
    end
    local ok, total = pcall(function()
        local segments = main_path:main_path_segments()
        if type(segments) ~= "table" or #segments == 0 then
            return nil
        end
        local last = segments[#segments]
        local dists = last and last.travel_distances
        return dists and dists[#dists] or nil
    end)
    return (ok and type(total) == "number") and total or nil
end

--[[
    Record the current mission's candidate spawn points.

    Reads _spawn_type_point_sections - the full static candidate set for this
    run's stitched path, not the rolled subset - so the resulting cache behaves
    exactly like the bundled one, including its probability maths.

    Only runs while hosting, only for missions we have no data for, and only
    once per session per mission.
--]]
function Spawns.record_if_needed()
    local name = current_mission_name()
    if not name or recorded_this_session[name] then
        return false
    end

    --[[
        Record EVERY hosted mission, not only uncached ones.

        Your own recording is strictly better than the bundled cache: it was
        captured on your game version and on geometry the game actually built,
        whereas the bundled data came from someone else's client on an older
        build. Since set_mission already prefers the user cache, re-recording a
        map you already have simply refreshes it.

        Still once per session per mission - _spawn_type_point_sections is
        static for the run, so reading it twice would produce identical output.
    --]]
    local existing = user_cache and user_cache.maps and user_cache.maps[name]
    if existing and recorded_this_session[name] then
        return false
    end

    local pacing = Managers.state and Managers.state.pacing
    local mp = pacing and pacing._monster_pacing
    local sections = mp and mp._spawn_type_point_sections
    if not sections then
        return false            -- not hosting
    end

    local entry = { pacing = {}, boss = {}, path_total = live_path_total() or 0 }
    local total = 0

    local ok = pcall(function()
        for spawn_type, section_list in pairs(sections) do
            local seen, list = {}, {}
            for _, section in pairs(section_list) do
                for _, sp in pairs(section) do
                    local d = sp and (sp.spawn_travel_distance or sp.spawn_point_travel_distance)
                    d = tonumber(d)
                    if d then
                        local key = math.floor(d * 10)
                        if not seen[key] then
                            seen[key] = true
                            list[#list + 1] = d
                        end
                    end
                end
            end
            if #list > 0 then
                table.sort(list)
                entry.pacing["pacing_" .. tostring(spawn_type)] = list
                total = total + #list
            end
        end

        local patrols = mp._boss_patrols
        if type(patrols) == "table" and #patrols > 0 then
            local list = {}
            for i = 1, #patrols do
                local d = tonumber(patrols[i] and patrols[i].travel_distance)
                if d then list[#list + 1] = d end
            end
            if #list > 0 then
                table.sort(list)
                entry.boss.boss_patrol_trigger = list
                total = total + #list
            end
        end
    end)

    if not ok or total == 0 then
        return false
    end

    load_user_cache()
    user_cache = user_cache or { maps = {} }
    user_cache.maps = user_cache.maps or {}
    user_cache.maps[name] = entry
    recorded_this_session[name] = true

    cache_dirty = true      -- flushed at mission end
    mod:info("[HavocTracker] recorded %s: %d spawn points (pending write)",
        name, total)
    return true
end

--[[
    Record a spawn we actually WITNESSED, at the travel distance it happened.

    _spawn_type_point_sections gives monsters, captains and witches, but NOT
    ritual locations - those come from the mutator's prebaked mission locations,
    which are shaped differently and are not safe to guess at. Observing them
    instead builds the dataset from ground truth: a ritual daemonhost appeared
    HERE, so there is a ritual trigger at this distance.

    Merged with a 5m tolerance so repeat sightings of the same location across
    runs do not accumulate duplicates. Grows over time as you play, which is
    exactly what a client run cannot do for itself.
--]]
local OBSERVE_TOLERANCE = 5

function Spawns.note_observed(kind, distance)
    local name = mission_id
    distance = tonumber(distance)
    if not name or not distance or not kind then
        return false
    end

    load_user_cache()
    user_cache = user_cache or { maps = {} }
    user_cache.maps = user_cache.maps or {}

    local entry = user_cache.maps[name]
    if not entry then
        entry = { pacing = {}, boss = {}, path_total = live_path_total() or 0 }
        user_cache.maps[name] = entry
    end

    -- Ritual and twins entries live under `boss`; pacing types under `pacing`.
    local bucket = (kind:find("^pacing_")) and entry.pacing or entry.boss
    bucket[kind] = bucket[kind] or {}
    local list = bucket[kind]

    for i = 1, #list do
        if math.abs(list[i] - distance) <= OBSERVE_TOLERANCE then
            return false            -- already known
        end
    end

    list[#list + 1] = distance
    table.sort(list)
    cache_dirty = true      -- written at mission end, not now

    mod:info("[HavocTracker] observed %s at %.1fm on %s (%d known)",
        tostring(kind), distance, tostring(name), #list)
    return true
end

--[[
    Write the user cache if anything was learned. Called on mission exit.

    Guarded end to end: a failure here must never take down mission teardown,
    and the worst case is losing one run's observations.
--]]
function Spawns.flush_cache()
    if not cache_dirty then
        return false
    end
    cache_dirty = false

    local ok, written = pcall(write_user_cache)
    if ok and written then
        mod:info("[HavocTracker] user cache written")
        return true
    end
    mod:warning("[HavocTracker] user cache write failed")
    return false
end

--[[
    Auto-bind at mission start. Kept here rather than in the main file so the
    whole forecast feature is one file you can delete.

    Returns the mission name ONLY when usable trigger data was actually found,
    so the caller cannot log "bound to X" for a mission we have nothing for.
--]]
function Spawns.ensure_mission()
    local name = current_mission_name()
    if not name then
        return nil
    end

    if name ~= mission_id then
        local found = Spawns.set_mission(name)
        if not found then
            return nil
        end
    end

    Spawns.check_staleness(live_path_total())
    Spawns.recompute_odds()
    return mission_id
end

mod.Spawns = Spawns
return Spawns
