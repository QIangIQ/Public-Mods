local mod = get_mod("HavocTracker")

--[[
    HUD declutter toggle.
    =====================

    WHY THE FIRST VERSION ONLY HID NAMEPLATES

    It called element:set_visible(false) and nothing else. That looked like the
    right API - the game itself calls it in UIHud._update_element_visibility -
    but:

        HudElementBase.set_visible = function (self, visible, ...)
            return
        end                                  (hud_element_base.lua)

    It is a NO-OP for most elements. Only the handful that override it
    responded, and nameplates is one of them.

    THE CORRECTION, AND IT MATTERS: the conclusion drawn from that was
    "set_visible is useless, flip the gate instead". Wrong. It is NECESSARY BUT
    NOT SUFFICIENT. The three elements that override it are exactly the
    retained-mode ones - team panel, ability handler, weapon handler - and for
    those, set_visible is the only thing that tears down retained draw
    commands. Flipping the gate alone froze them on screen showing the last
    uploaded frame. See the long note above Hud.apply; both halves are required
    and vanilla always does both together.

    THE ACTUAL GATES

    There are two separate systems drawing your screen, each with its own
    switch, and neither is set_visible:

      1. HUD elements - ui_hud.lua:433
             if currently_visible_elements[element_name] and element.draw then
         So _currently_visible_elements is the real gate. This covers the base
         game HUD AND any mod that registers a HUD element - ZDD, specials
         trackers, coherency displays, and this mod's own panels.

      2. CONSTANT elements - ui_constant_elements.lua, draw loop
             if element:should_draw() then
         A separate list holding the chat window among others. Nothing in the
         UIHud path touches it, which is why chat stayed up.

    Hiding therefore means flipping gate 1 per element and suppressing gate 2's
    draw pass wholesale.
--]]

local Hud = {}

local hidden = false
local saved_visibility = nil    -- element name -> value before we hid it

--[[
    Exactly which elements we changed, so restore can undo exactly those.

    Needed because hide is now SELECTIVE: with keep_base_hud on, vanilla
    elements are skipped entirely rather than reasserted. Restore used to walk
    the whole element array and force anything without a saved entry to true,
    which for a skipped vanilla element meant switching on something we had
    never switched off. Recording the set makes the two halves symmetrical by
    construction instead of by two lists agreeing with each other.
--]]
local touched = nil

--[[
    Declared HERE, with the other state, not next to the hook that uses it.

    Hud.toggle seeds this, and toggle is defined above the hook - a local
    declared later would make that seed write a GLOBAL while the hook read an
    always-nil local, so every frame would look like a group change. That is the
    same scoping trap that has bitten this project repeatedly; keeping all
    module state together at the top is the structural fix.
--]]
local last_group = nil

--[[
    Read once on toggle rather than per frame. _calculate_markers runs every
    frame, and the project rule is that no per-frame path calls mod:get.
--]]
local hide_mod_markers = false

--[[
    NOTHING is kept unconditionally.

    The previous version force-kept crosshair, health, ammo and this mod's own
    panels on my judgement of what you would need. You asked for every single
    thing on screen, so the entire keep list is now yours, and every option
    defaults to OFF - press the key and the screen is clear.
--]]
local KEEP_SETTINGS = {
    keep_crosshair = { "HudElementCrosshair" },
    keep_vitals    = { "HudElementPlayerAbilityHandler", "HudElementPlayerWeaponHandler",
                       "HudElementStamina", "HudElementOvercharge",
                       "HudElementWeaponCounter" },
    keep_interact  = { "HudElementInteraction" },
    keep_team      = { "HudElementTeamPanelHandler" },
    keep_boss      = { "HudElementBossHealth", "HudElementMinionShieldHealth" },
    keep_objective = { "HudElementMissionObjectiveFeed",
                       "HudElementObjectiveProgressBar",
                       "HudElementMissionObjectivePopup" },
    keep_buffs     = { "HudElementPlayerBuffs" },
    keep_tags      = { "HudElementSmartTagging", "HudElementNameplates" },
    keep_tracker   = { "HudElementHavocTracker" },
    keep_spawn_panel = { "HudElementSpawnPanel" },
    keep_markers   = { "HudElementWorldMarkers" },
}

local function keep_set()
    local keep = {}
    for setting, names in pairs(KEEP_SETTINGS) do
        if mod:get(setting) then
            for i = 1, #names do
                keep[names[i]] = true
            end
        end
    end
    return keep
end

--[[
    THERE ARE TWO HUDS, AND SPECTATING SWITCHES TO THE OTHER ONE.

    UIManager keeps the player HUD on _hud (ui_manager.lua:437) and builds a
    SECOND, separate UIHud on _spectator_hud when you die and start watching a
    teammate (:454). They are different objects with different element arrays;
    destroy_spectator_hud (:459) throws the second one away on respawn.

    This used to return _hud only. So everything this module does - hiding
    vanilla elements, restoring them, the outline gate - reached the player HUD
    and nothing else, and the moment you died the spectator HUD came up
    completely untouched with every element it shipped with. That is the "HUD
    stays on when you are in spectate" report, and it is also why the state had
    to be re-toggled after dying: the toggle had been applied to a HUD that was
    no longer the one on screen.

    The spectator HUD wins when it exists, because when it exists it is the one
    being drawn.
--]]
local function get_hud()
    local ui = Managers.ui

    if not ui then
        return nil
    end

    return ui._spectator_hud or ui._hud or nil
end


--[[
    WHICH ELEMENTS ARE VANILLA - AN ALLOW-LIST, NOT A MOD REGISTRY.

    The first version asked DMF which elements mods had registered and treated
    everything else as vanilla. That was wrong, and SpecialsTracker is the
    counter-example: it never calls register_hud_element. It appends its
    definition to the GAME's own definition tables -

        mod:hook_require("scripts/ui/hud/hud_elements_player", add_hud_element)
        mod:hook_require("scripts/ui/hud/hud_elements_player_onboarding", ...)
        mod:hook_require("scripts/ui/hud/hud_elements_spectator", ...)

    - so by the time UIHud builds its element array, HudElementSpecialsTracker
    is indistinguishable from a base game element and DMF's registry has never
    heard of it. Asking the registry therefore kept it on screen in base-HUD
    mode. That hook_require pattern is the older and more common way to add a
    HUD element, so other mods are invisible to the registry too.

    The only reliable direction is the other one: enumerate what IS vanilla and
    treat everything else as a mod element. Extracted from the game's own
    definition files -

        scripts/ui/hud/hud_elements_player.lua
        scripts/ui/hud/hud_elements_player_hub.lua
        scripts/ui/hud/hud_elements_player_onboarding.lua
        scripts/ui/hud/hud_elements_spectator.lua

    - every distinct class_name across all four, 36 entries.

    THE TRADEOFF, stated plainly: a game update adding a NEW vanilla element
    would see it hidden, because it is not in this list. That is the wrong
    direction for "keep the base game HUD", but the opposite failure - a mod
    silently staying on screen - is the one actually being complained about,
    and a new mod is far likelier than Fatshark adding a HUD element. If a
    vanilla element ever goes missing, turning this setting off restores the
    old behaviour and the fix is one line here.

    DMF's registry is still consulted as a POSITIVE signal: anything it knows
    about is definitely a mod element, whatever this list says.
--]]
local VANILLA_ELEMENTS = {
    HudElementAreaNotificationPopup = true,
    HudElementBossHealth = true,
    HudElementCharacterNewsFeed = true,
    HudElementCombatFeed = true,
    HudElementCrosshair = true,
    HudElementCutsceneFading = true,
    HudElementCutsceneOverlay = true,
    HudElementDamageIndicator = true,
    HudElementDangerZoneOverlay = true,
    HudElementDodgeCounter = true,
    HudElementEmoteWheel = true,
    HudElementInteraction = true,
    HudElementMinionShieldHealth = true,
    HudElementMissionObjectiveFeed = true,
    HudElementMissionObjectivePopup = true,
    HudElementMissionSpeakerPopup = true,
    HudElementNameplates = true,
    HudElementObjectiveProgressBar = true,
    HudElementOnboardingPopup = true,
    HudElementOvercharge = true,
    HudElementPlayerAbilityHandler = true,
    HudElementPlayerBuffs = true,
    HudElementPlayerCompass = true,
    HudElementPlayerWeaponHandler = true,
    HudElementPrologueStepTracker = true,
    HudElementPrologueTutorialInfoBox = true,
    HudElementPrologueTutorialSequenceTransitionEnd = true,
    HudElementSmartTagging = true,
    HudElementSpectateFading = true,
    HudElementSpectatorText = true,
    HudElementStamina = true,
    HudElementTacticalOverlay = true,
    HudElementTeamPanelHandler = true,
    HudElementWeaponCounter = true,
    HudElementWieldInfo = true,
    HudElementWorldMarkers = true,
}

local function dmf_registered_elements()
    local dbg = rawget(_G, "debug")
    local cls = rawget(_G, "DMFMod")

    if not dbg or type(dbg.getupvalue) ~= "function" or type(cls) ~= "table" then
        return nil
    end

    local fn = cls.register_hud_element
    if type(fn) ~= "function" then
        return nil
    end

    for i = 1, 60 do
        local name, value = dbg.getupvalue(fn, i)
        if name == nil then
            break
        end
        if name == "_elements_data" and type(value) == "table" then
            return value
        end
    end

    return nil
end

--[[
    True when the element did not ship with the game. Registry first because it
    is definitive, then the allow-list.
--]]
local function is_mod_element(name, registered)
    if registered and registered[name] then
        return true
    end

    return not VANILLA_ELEMENTS[name]
end

--[[
    Flip the real gate for every HUD element.

    Originals are saved on the way down so restoring returns the engine's own
    decision rather than forcing everything visible - an element the game had
    hidden for its own reasons stays hidden.
--]]
--[[
    set_visible IS NOT USELESS - IT IS NECESSARY BUT NOT SUFFICIENT.

    The note at the top of this file concluded that because
    HudElementBase.set_visible is a no-op, calling it was pointless and
    flipping _currently_visible_elements was the whole answer. Half right, and
    the wrong half caused the freeze this fixes.

    THREE elements override set_visible, and they are declared with
    use_retained_mode = true in hud_elements*.lua:

        HudElementTeamPanelHandler      health and toughness
        HudElementPlayerAbilityHandler  ability timers
        HudElementPlayerWeaponHandler   ammo

    Retained mode means the draw commands are uploaded to the gui ONCE and
    reused - that is the entire point of it (ui_passes.lua:16, driven by
    render_settings.force_retained_mode, set per element in ui_hud.lua:443).

    RETAINED COMMANDS KEEP RENDERING WITHOUT A DRAW CALL. So flipping the gate
    alone stops update() and draw() while the last uploaded frame stays on
    screen indefinitely. The result is precisely a screenshot of the instant
    the key was pressed: ability timers, health and toughness frozen, because
    nothing updates them and nothing re-uploads them.

    Vanilla never hits this because _update_element_visibility does BOTH
    things together (ui_hud.lua:302-306):

        if element.set_visible then
            element:set_visible(status, ui_renderer, use_retained_mode)
        end
        currently_visible_elements[element_name] = status

    set_visible is what tears the retained commands down and rebuilds them.
    So this now does both halves, in the same order, for the same reason.

    UIHud._refresh_retained looks like it should help and does not: it is set
    at init and on resolution change and read NOWHERE in the source tree.
    Write-only. Do not build on it.
--]]
--[[
    ONE HUD AT A TIME, AND THE HANDOVER IS THE PART THAT WAS MISSING.

    saved_visibility, touched and last_group are a single set of module-level
    variables describing one HUD's element table. Dying replaces the HUD -
    UIManager builds a separate _spectator_hud (ui_manager.lua:454) and
    destroys it again on respawn (:459) - and those three variables kept
    describing the HUD that had gone away.

    Keying all of it per HUD was the other option and it is a worse one: the
    state is read and written at twenty sites inside this function, and only
    ever one HUD is actually on screen. So the fix is to notice the swap and
    drop the state, exactly as the group-change path already does, rather than
    to carry two copies of it.

    Without this the saved "original" values from the player HUD are replayed
    onto the spectator HUD's element table, which shares some names and not
    others - so restore both missed elements it should have brought back and
    wrote values for elements that were never hidden.
--]]
local current_hud = nil

function Hud.apply()
    local hud = get_hud()

    if not hud then
        return
    end

    if hud ~= current_hud then
        current_hud = hud
        saved_visibility = nil
        touched = nil
        last_group = nil
    end

    local visible = hud._currently_visible_elements
    if not visible then
        return
    end

    --[[
        Iterating _elements_array rather than the gate table, because only the
        array carries the element OBJECTS that set_visible has to be called on.
        It is also the same list vanilla walks, so an element that exists but
        has no gate entry yet gets handled rather than skipped.
    --]]
    local elements_array = hud._elements_array
    local ui_renderer = hud._ui_renderer
    local retained = hud._elements_hud_retained_mode_lookup

    local function set_element(name, element, status)
        if touched then
            touched[name] = true
        end

        --[[
            ONLY CALL THROUGH WHEN THE STATE ACTUALLY CHANGES.

            Hud.apply runs from the _update_element_visibility hook, and
            UIHud.update calls _update_element_visibility every frame
            (ui_hud.lua:351). So while the HUD is hidden this ran for every
            element, 60 times a second.

            set_visible on a use_retained_mode element calls set_dirty(), which
            re-uploads that element's whole widget set. Doing it for the entire
            element list every frame measured ~100-113ms per frame, re-flashed
            the HUD, and churned memory.

            Correctness is unchanged: `visible` IS
            hud._currently_visible_elements, so a value the game rewrites no
            longer matches and the next tick re-applies it - which is the only
            reason this needed to repeat at all.
        --]]
        if visible[name] ~= status then
            -- pcall'd: this runs from a hook and from the toggle key, and a
            -- throw inside one element's set_visible would abandon the rest of
            -- the list half-applied - visible gate flipped, retained commands
            -- not.
            if element and element.set_visible then
                pcall(element.set_visible, element, status, ui_renderer,
                    retained and retained[name])
            end

            visible[name] = status
        end
    end

    if hidden then
        local keep = keep_set()

        --[[
            Capture ONCE per genuine game rewrite.

            If this ever re-captures from a table we have already zeroed, the
            original state is lost and restore becomes a no-op. The hook below
            is responsible for clearing saved_visibility only when the game has
            actually written fresh values.
        --]]
        if not saved_visibility then
            saved_visibility = {}
            for name, state in pairs(visible) do
                saved_visibility[name] = state
            end
        end

        touched = touched or {}

        --[[
            BASE-HUD MODE. Hide only what mods injected.

            Boss health bars, vitals, objectives, the interaction prompt and
            everything else vanilla stays exactly as the game had it, so a
            viewer sees a normal Darktide HUD and none of the 90-odd mod
            overlays. The keep_* list still applies on top, so a mod panel can
            be kept individually.

            Vanilla is decided by the allow-list above, not by asking DMF
            which elements mods registered - see the note there for why that
            was wrong and which mod proved it.
        --]]
        local base_hud = mod:get("keep_base_hud") ~= false
        local registered = base_hud and dmf_registered_elements() or nil

        if elements_array then
            for i = 1, #elements_array do
                local element = elements_array[i]
                local name = element.__class_name

                if base_hud and not is_mod_element(name, registered) then
                    --[[
                        LEAVE IT ALONE MEANS TOUCH NOTHING.

                        This used to say

                            status = saved_visibility[name]
                            set_element(name, element, status)

                        which claimed to leave vanilla alone and then called
                        set_visible on it and overwrote its gate entry anyway.
                        That broke the psyker peril gauge, and the mechanism is
                        worth writing down because it is not obvious.

                        saved_visibility is captured from
                        _currently_visible_elements, and an element that has not
                        been through a visibility pass yet simply is not in that
                        table. So status came back NIL, not true, and nil did
                        two separate bits of damage:

                          1. set_visible(nil, ...) takes the FALSE branch.
                             HudElementOvercharge is use_retained_mode = true,
                             and its override reads:

                                 if use_retained_mode then
                                     if visible then self:set_dirty()
                                     else self:_destroy_widgets(ui_renderer) end
                                 end

                             so its widget passes were destroyed. Nothing in
                             set_visible ever recreates them - there is no
                             _create_widgets on the way back - so the gauge was
                             gone for the rest of the mission.

                          2. visible[name] = nil is falsy, and BOTH loops in
                             ui_hud.lua gate on that same table:

                                 update: if currently_visible_elements[n] and element.update
                                 draw:   if currently_visible_elements[n] and element.draw

                             so update stopped too, and the element could not
                             even recompute its values.

                        With keep_base_hud on, vanilla's own
                        _update_element_visibility is the authority for vanilla
                        elements and it runs at the top of every UIHud.update
                        (ui_hud.lua:351). The correct action is therefore NO
                        action: no set_visible, no gate write. Skipping leaves
                        the peril gauge, boss health and everything else
                        shipped with the game behaving exactly as they do with
                        the HUD up, which is the whole point of the setting.

                        This is also why the keep_* list is documented as only
                        mattering when keep_base_hud is OFF - when it is on,
                        those elements are not ours to decide about.
                    --]]
                else
                    set_element(name, element, keep[name] and saved_visibility[name] or false)
                end
            end
        else
            --[[
                No element array (very early, before the HUD has built one).
                Only the gate table is reachable, so set_visible cannot be
                called - but base_hud must still be honoured, or this branch
                would hide the vanilla HUD that the array branch above
                carefully leaves alone.
            --]]
            for name in pairs(visible) do
                if not (base_hud and not is_mod_element(name, registered)) then
                    visible[name] = keep[name] and saved_visibility[name] or false
                    touched[name] = true
                end
            end
        end

    elseif saved_visibility and touched then
        --[[
            Restore, and make it total.

            Iterating saved_visibility alone would miss any element that
            appeared while we were hidden - it would be stuck false with no
            saved entry to restore from. Anything unknown is turned back ON and
            handed to the game, which will correct it on its next pass.
        --]]
        local by_name = {}

        if elements_array then
            for i = 1, #elements_array do
                local element = elements_array[i]
                by_name[element.__class_name] = element
            end
        end

        --[[
            Walk the touched set, not the element array. An element we skipped
            stays skipped, and one we hid gets its own value back. state == nil
            still falls back to true for something that appeared while hidden
            and was hidden by the hook before the game had recorded a value for
            it - handing it back on lets the game correct it on its next pass,
            which is the safe direction for an unknown.
        --]]
        --[[
            Detach the set BEFORE iterating it. set_element writes to
            `touched`, and mutating a table while traversing it with pairs is
            only safe in Lua when no new key is created - true here by
            accident, since every key already exists. Detaching removes the
            dependency on that accident entirely.
        --]]
        local to_restore = touched
        touched = nil

        for name in pairs(to_restore) do
            local state = saved_visibility[name]
            if state == nil then
                state = true
            end

            local element = by_name[name]
            if element then
                set_element(name, element, state)
            else
                visible[name] = state
            end
        end

        saved_visibility = nil
    end
end

--[[
    OUTLINES AND HAZARD DECALS - the two things the visibility gate cannot
    reach, because neither is a HUD element.

    OUTLINES go through the outline SYSTEM, and the per-unit decision lives in
    outline_system.lua:331, inside the system's own update:

        local should_show = not top_outline.visibility_check
            or top_outline.visibility_check(unit)

    and when that is false the material layers are switched off for that unit.
    So wrapping visibility_check gives exact per-unit control, evaluated by the
    engine at the right moment, with no outlines added or removed and nothing
    to keep in sync. Every template in outline_settings.lua has one - I checked
    all of them, including default_outlines_always, which is what this mod's
    ally outlines use - so a single wrapper covers enemies, allies,
    knocked-down teammates and smart tags alike.

    Radius rather than line of sight, deliberately. A true LOS test means a
    raycast per outlined unit per frame, and with an enemy outliner running
    that is dozens of casts a frame. A radius is one squared-distance compare
    and it achieves what was actually asked for: distant things stop drawing,
    including anything that would otherwise show through a wall.

    QLang's outliner REBUILDS its entries whenever any of its settings change
    (update_outline_settings), which silently drops our wrapper. So the wrap is
    re-verified on a timer rather than done once - see gate_tick.
--]]
local OutlineSettings = nil
do
    local ok, mod_settings = pcall(require, "scripts/settings/outline/outline_settings")
    OutlineSettings = ok and mod_settings or nil
end

-- original visibility_check -> true, so a wrapper is never wrapped twice.
local wrapped_checks = setmetatable({}, { __mode = "k" })

--[[
    Local player position, cached per outline-system pass.

    The wrapper runs once per outlined unit and they all resolve against the
    same player position, so looking it up per unit would repeat the same work
    dozens of times a frame. Vector3 is frame-temporary in this engine, so the
    three components are stored as numbers rather than the vector itself - that
    exact mistake cost this project a session of framerate debugging.
--]]
local cache_stamp = -1
local cx, cy, cz = 0, 0, 0

local function player_pos()
    local stamp = Managers.time and Managers.time:time("main") or 0

    if stamp ~= cache_stamp then
        cache_stamp = stamp
        cx, cy, cz = nil, nil, nil

        local pm = Managers.player
        local player = pm and pm.local_player_safe and pm:local_player_safe(1)
        local unit = player and player.player_unit

        if unit and ALIVE[unit] then
            local ok, p = pcall(Unit.local_position, unit, 1)
            if ok and p then
                cx, cy, cz = p.x, p.y, p.z
            end
        end
    end

    return cx, cy, cz
end

local function within_radius(unit)
    local px, py, pz = player_pos()
    if not px then
        -- Cannot locate the player: show the outline rather than blanking the
        -- screen on a bad frame.
        return true
    end

    local ok, p = pcall(Unit.local_position, unit, 1)
    if not ok or not p then
        return true
    end

    local r = tonumber(mod:get("clean_outline_radius")) or 20
    local dx, dy, dz = p.x - px, p.y - py, p.z - pz

    return (dx * dx + dy * dy + dz * dz) <= (r * r)
end

local function wrap_check(original)
    return function(unit)
        --[[
            Only interferes while the HUD is hidden AND the option is on.
            Outside that the original answer is returned untouched, so normal
            play is byte-for-byte unaffected.
        --]]
        if hidden and mod:get("clean_limit_outlines") ~= false then
            if not within_radius(unit) then
                return false
            end
        end

        if original then
            return original(unit)
        end

        return true
    end
end

local function install_outline_gate()
    if not OutlineSettings then
        return
    end

    for _, section in pairs(OutlineSettings) do
        if type(section) == "table" then
            for _, setting in pairs(section) do
                if type(setting) == "table" then
                    local check = setting.visibility_check
                    if type(check) == "function" and not wrapped_checks[check] then
                        local wrapper = wrap_check(check)
                        wrapped_checks[wrapper] = true
                        setting.visibility_check = wrapper
                    elseif check == nil then
                        -- A template with no check shows unconditionally, so it
                        -- needs one adding rather than wrapping.
                        local wrapper = wrap_check(nil)
                        wrapped_checks[wrapper] = true
                        setting.visibility_check = wrapper
                    end
                end
            end
        end
    end
end

--[[
    Re-verify the wrap about once a second.

    Called from the visibility hook, which the game runs every frame, counted
    rather than timed because that hook is handed no dt. Walking ~40 templates
    once a second is nothing, and it is the only thing that survives another
    mod rebuilding its outline settings underneath us.
--]]
local gate_calls = 0

local function gate_tick()
    gate_calls = gate_calls + 1

    if gate_calls >= 60 then
        gate_calls = 0
        pcall(install_outline_gate)
    end
end

--[[
    HAZARD DECALS are units spawned by danger_zone, not outlines, so the gate
    above cannot see them. danger_zone reads its own "<group>_outline_enabled"
    settings through DMF and reacts in on_setting_changed by adding or removing
    the decal, so flipping those settings is the supported way in and it cleans
    up the existing decals for us.

    The previous values are saved and restored rather than assumed, because
    several of these are things you may already have switched off by hand.

    Keys are discovered from the live settings blob via Application.user_setting
    rather than hardcoded, so a danger_zone update that adds a hazard is picked
    up without editing this list.
--]]
--[[
    OTHER MODS' OVERLAYS.

    Some of the loudest things on screen are drawn by other mods and are
    neither HUD elements nor outlines, so neither gate above can reach them.
    What they DO have is a DMF setting they read live, which means flipping it
    is the supported way in - DMF fires on_setting_changed, and both mods below
    use that to tear down what they had already drawn.

    Values are SAVED AND RESTORED rather than assumed, because several of these
    are things you may have switched off by hand already. Restoring blindly to
    "on" would quietly turn your own choices back on every time you toggled.

    Table-driven so adding another mod later is one line. `keys` may be an
    explicit list, or the string "suffix:<text>" to match every setting whose
    id ends that way - danger_zone needs the latter because it has fifteen
    hazard switches and gains more as it is updated.
--]]
local EXTERNAL = {
    {
        setting = "clean_hide_dangerzones",
        mod_name = "danger_zone",
        keys = "suffix:_outline_enabled",
    },
    {
        setting = "clean_hide_weakspots",
        mod_name = "BackstabHitboxDisplay",
        keys = { "enabled" },
    },
}

-- mod name -> { key = previous value }
local saved_external = {}

--[[
    WHY THIS IS WRITTEN TO DISK, AND THE BUG THAT PROVED IT NECESSARY.

    apply_external switches another mod's setting off through DMFMod:set. That
    is not an in-memory change: set marks

        _there_are_unsaved_changes = true                (settings.lua:69)

    so DMF writes the `false` into user_settings.config. The restore, however,
    lived only in `saved_external` above - a plain module local.

    So quitting the game with the HUD hidden persisted the OFF and threw the
    restore away. The result, found in the live config:

        BackstabHitboxDisplay = { enabled = false }
        danger_zone = { all fifteen *_outline_enabled = false }

    Weakspots and every hazard decal permanently off, with no record of what
    they had been. The user_settings_backup.config was written after the fact
    too, so the real prior values were not recoverable from either file.

    The asymmetry is the whole bug: the change was durable and the undo was
    not. Anything written to another mod's persisted settings needs an undo
    that is equally persisted, so the save now goes in OUR settings and is
    replayed by recover_external() on the next load.
--]]
local SAVE_KEY = "clean_external_saved"

local function persist_saved()
    local out = {}

    for mod_name, keys in pairs(saved_external) do
        local copy = {}
        for key, value in pairs(keys) do
            copy[key] = value
        end
        out[mod_name] = copy
    end

    -- notify_mod false: this is our own bookkeeping, nothing reacts to it.
    pcall(mod.set, mod, SAVE_KEY, out, false)
end

--[[
    Replay a save that outlived the session that made it.

    Called from on_all_mods_loaded, which matters: get_mod returns nil for a
    mod that has not loaded yet, and load order is not ours to assume. By
    on_all_mods_loaded every target exists.

    A fresh load is never "hidden", so anything still recorded here is by
    definition a restore that did not happen, and replaying it unconditionally
    is correct. The record is cleared afterwards so this runs once.
--]]
--[[
    ONE-SHOT REPAIR of the damage done before the save above existed.

    The values lost had never been recorded anywhere, so they cannot be
    recovered - only reset to what each mod ships as its default. Taken from
    the mods' own data files:

        BackstabHitboxDisplay_data.lua:13   enabled           default true

        danger_zone_data.lua:33  add_setting(..., default_enabled)
                                 "if default_enabled == nil then true end"
          explicitly false:  explosive_barrel_spawn, fire_barrel_spawn,
                             scab_flamer_spawn, tox_flamer_spawn
          defaulted true:    the remaining eleven

    The four *_spawn groups default to false, so they are already correct and
    are deliberately NOT listed here - writing them would be indistinguishable
    from the bug.

    THE TRADEOFF, stated plainly: if any of these eleven had been turned off by
    hand, this turns it back on once and it has to be turned off again. That is
    unavoidable, because the bug destroyed the only record of which was which.
    It runs exactly once, guarded by a flag, and then never touches these
    settings again.
--]]
local REPAIR_FLAG = "clean_external_repaired"

local REPAIR_DEFAULTS = {
    BackstabHitboxDisplay = { enabled = true },
    danger_zone = {
        fire_barrel_explosion_outline_enabled = true,
        scab_bomber_grenade_outline_enabled   = true,
        scab_flamer_explosion_outline_enabled = true,
        tox_flamer_explosion_outline_enabled  = true,
        explosive_barrel_fuse_outline_enabled = true,
        fire_barrel_fuse_outline_enabled      = true,
        daemonhost_spawn_outline_enabled      = true,
        daemonhost_aura_outline_enabled       = true,
        poxburster_spawn_outline_enabled      = true,
        scab_flamer_fuse_outline_enabled      = true,
        tox_flamer_fuse_outline_enabled        = true,
    },
}

local function repair_external()
    if mod:get(REPAIR_FLAG) then
        return
    end

    -- Set the flag FIRST. If a target mod errors, the repair must not be
    -- retried on every launch forever.
    pcall(mod.set, mod, REPAIR_FLAG, true, false)

    local fixed = 0

    for mod_name, keys in pairs(REPAIR_DEFAULTS) do
        local target = get_mod(mod_name)

        if target then
            for key, want in pairs(keys) do
                local ok, current = pcall(target.get, target, key)

                -- Only touch what is actually off. Anything already on is
                -- either untouched or already fixed.
                if ok and current == false then
                    if pcall(target.set, target, key, want, true) then
                        fixed = fixed + 1
                    end
                end
            end
        end
    end

    if fixed > 0 then
        mod:echo(string.format(
            "Repaired %d overlay setting(s) that an earlier HUD-toggle bug left switched off.",
            fixed))
    end
end

function Hud.recover_external()
    local stored = mod:get(SAVE_KEY)

    if type(stored) ~= "table" or not next(stored) then
        return
    end

    local restored = 0

    for mod_name, keys in pairs(stored) do
        local target = get_mod(mod_name)

        if target and type(keys) == "table" then
            for key, value in pairs(keys) do
                -- notify_mod true, or the mod never rebuilds what it tore down.
                if pcall(target.set, target, key, value, true) then
                    restored = restored + 1
                end
            end
        end
    end

    saved_external = {}
    pcall(mod.set, mod, SAVE_KEY, {}, false)

    if restored > 0 then
        mod:echo(string.format(
            "Restored %d overlay setting(s) left off by a quit while the HUD was hidden.",
            restored))
    end
end

--[[
    Replay first, then repair. Order matters: a genuine save is better evidence
    than a default, so if both apply the recorded value wins and the repair
    then finds nothing left switched off.
--]]
function Hud.restore_after_load()
    pcall(Hud.recover_external)
    pcall(repair_external)
end

local function external_keys(entry, target)
    if type(entry.keys) == "table" then
        return entry.keys
    end

    local suffix = string.match(tostring(entry.keys), "^suffix:(.+)$")
    if not suffix then
        return nil
    end

    --[[
        Discovered from the live settings blob rather than hardcoded, so a mod
        update that adds a hazard is picked up without editing this file.
        Application.user_setting is a public engine call - no upvalue tricks
        needed for this one.
    --]]
    local ok, blob = pcall(Application.user_setting, "mods_settings")
    local settings = ok and blob and blob[entry.mod_name]

    if type(settings) ~= "table" then
        return nil
    end

    local out = {}
    for key in pairs(settings) do
        if type(key) == "string" and string.find(key, suffix, 1, true) then
            out[#out + 1] = key
        end
    end

    return out
end

local function apply_external()
    for i = 1, #EXTERNAL do
        local entry = EXTERNAL[i]
        local target = get_mod(entry.mod_name)

        if target then
            local want_off = hidden and mod:get(entry.setting) ~= false

            if want_off then
                if not saved_external[entry.mod_name] then
                    local keys = external_keys(entry, target)

                    if keys then
                        local saved = {}

                        for k = 1, #keys do
                            local key = keys[k]
                            local ok, value = pcall(target.get, target, key)

                            -- Only touch settings that are currently ON, so a
                            -- restore cannot switch on something you had off.
                            if ok and value ~= false and value ~= nil then
                                saved[key] = value

                                --[[
                                    THE THIRD ARGUMENT IS NOT OPTIONAL.

                                        function DMFMod:set(id, value, notify_mod)
                                            ...
                                            if notify_mod then
                                                dmf.mod_setting_changed_event(self, id)
                                            end

                                    Without it the value changes and the owning
                                    mod is never told, so its
                                    on_setting_changed never runs. That callback
                                    is where these mods tear down what they have
                                    already drawn, so omitting it left work on
                                    screen with nothing left to clear it:

                                      BackstabHitboxDisplay resets its two
                                      LineObjects there. Its update_impl
                                      early-returns once `enabled` is false, so
                                      it never re-dispatches either - the last
                                      dispatch just stayed painted. The cone is
                                      depth-tested and got occluded, so it
                                      looked like it worked; the head markers
                                      are drawn with NO depth test, on top of
                                      everything, so they stayed plainly
                                      visible.

                                      danger_zone removes its decal units there
                                      too, so its hazard markers had the same
                                      fault.
                                --]]
                                pcall(target.set, target, key, false, true)
                            end
                        end

                        saved_external[entry.mod_name] = saved
                        persist_saved()
                    end
                end

            elseif saved_external[entry.mod_name] then
                for key, value in pairs(saved_external[entry.mod_name]) do
                    -- notify_mod on the way back too, or the mod keeps
                    -- believing it is switched off and never rebuilds.
                    pcall(target.set, target, key, value, true)
                end

                saved_external[entry.mod_name] = nil
                persist_saved()
            end
        end
    end
end

Hud.install_outline_gate = install_outline_gate
Hud.gate_tick = gate_tick

function Hud.toggle()
    hidden = not hidden

    --[[
        Force the game to rebuild visibility on restore.

        _update_element_visibility early-outs unless the group changed, so after
        we hand the table back the game would not necessarily recompute it -
        leaving any element we guessed wrong about stuck. Clearing
        _current_group_name makes its next pass treat the group as new and
        reassert its own truth, which is a clean handover rather than us
        pretending to know the correct state.
    --]]
    local hud = get_hud()

    if hidden then
        --[[
            Seed last_group BEFORE the first hook pass.

            Left nil, the very next frame sees group ~= last_group, treats it as
            a fresh rewrite by the game, and discards the capture we just took -
            recreating exactly the bug this is meant to fix, one frame later.
        --]]
        last_group = hud and hud._current_group_name or nil
        pcall(Hud.apply)
    else
        pcall(Hud.apply)
        --[[
            Force the game to rebuild visibility.

            _update_element_visibility early-outs unless the group changed, so
            after handing the table back it would not necessarily recompute.
            Clearing _current_group_name makes its next pass treat the group as
            new and reassert its own truth - a clean handover rather than us
            pretending to know the right answer.
        --]]
        if hud then
            hud._current_group_name = nil
        end
        last_group = nil
    end

    --[[
        Outlines need no action here - the wrapper reads `hidden` directly, so
        it changes behaviour the moment the flag flips. Hazard decals DO need a
        call, because danger_zone only reacts when its settings change.
    --]]
    hide_mod_markers = mod:get("clean_hide_mod_markers") ~= false

    pcall(install_outline_gate)
    pcall(apply_external)

    mod:echo(hidden and "HUD hidden - press again to restore" or "HUD restored")
end

function Hud.is_hidden()
    return hidden
end

--[[
    Re-assert after the game recomputes visibility.

    _update_element_visibility rebuilds _currently_visible_elements on every
    visibility GROUP change - going down, revive, cutscene, spectate. Without
    this the toggle would silently undo itself and the key would look broken.

    hook_safe runs after the original, which is what we want: let the game
    decide, then override.
--]]
--[[
    Re-assert after the game recomputes visibility - WITHOUT destroying the
    saved state.

    THIS HOOK RUNS EVERY FRAME. UIHud.update calls _update_element_visibility
    unconditionally (ui_hud.lua:351); the function itself then early-outs unless
    the visibility GROUP changed.

    The first version discarded saved_visibility here and let apply() re-capture
    it. Since apply had already set every entry false on the previous frame, the
    "original" state became all-false within one frame of hiding, and restoring
    wrote that back - the HUD never came back. It appeared to recover eventually
    only because a real group change (going down, reviving) made the game
    rewrite the table with true values.

    So: only re-capture when the group ACTUALLY changed, which is the only time
    the game writes that table.
--]]

mod:hook_safe(CLASS.UIHud, "_update_element_visibility", function(self)
    --[[
        Re-verify the outline wrap BEFORE the early-out.

        Placed above the `not hidden` return on purpose: the wrap has to be in
        place before the toggle is pressed, not after, and another mod can
        rebuild its outline settings at any time - including while the HUD is
        visible. Putting this below the return would mean the first press after
        any such rebuild did nothing to outlines.
    --]]
    gate_tick()

    if not hidden then
        last_group = self._current_group_name
        return
    end

    local group = self._current_group_name
    if group ~= last_group then
        --[[
            Genuine rewrite by the game: its values are authoritative again.

            BOTH are dropped. They are two halves of one record - what the
            values were, and which elements we changed - so keeping one without
            the other would leave restore trying to undo names it had no saved
            value for, or to skip names it had one for.
        --]]
        last_group = group
        saved_visibility = nil
        touched = nil
    end

    pcall(Hud.apply)
end)

--[[
    Constant elements: suppress the whole draw pass.

    This is the chat window and its siblings. They live in a different manager
    with a different gate (should_draw), so nothing above affects them.
    Skipping the draw call is total and cheap - and total is what was asked
    for, chat included.

    Note this is DRAW only: input and state still update, so chat still
    receives messages while hidden and they are all there when you restore.
--]]
--[[
    CHAT ONLY. This used to suppress the WHOLE constant-elements draw pass:

        if hidden and not mod:get("keep_chat") then
            return    -- skipped func() entirely
        end

    and that list is not just chat (constant_elements.lua):

        ConstantElementPopupHandler      the "Quit game?" confirmation
        ConstantElementSoftwareCursor    the mouse cursor
        ConstantElementNotificationFeed
        ConstantElementSubtitles
        ConstantElementLoading
        ConstantElementVoiceChat         ... and more

    So with the HUD hidden, pressing Escape and choosing quit drew no
    confirmation popup and no cursor - the menu was live and invisible until
    you toggled the HUD back on. That is the reported bug, and suppressing a
    whole draw pass to hide one element was always going to do something like
    it.

    ConstantElementBase.should_draw is the per-element gate the draw loop
    already consults (`if element:should_draw() then`), so hooking chat's own
    override hides exactly chat and touches nothing else.
--]]
mod:hook(CLASS.ConstantElementChat, "should_draw", function(func, self, ...)
    if hidden and not mod:get("keep_chat") then
        return false
    end
    return func(self, ...)
end)


--[[
    MOD-ADDED WORLD MARKERS.
    ========================

    THE BUG THIS FIXES, stated exactly: with keep_base_hud on, the in-world
    boss/twins/patrol skulls and the path line stayed on screen with the HUD
    hidden, and keep_markers did nothing to stop them.

    Why. Mod markers are not their own HUD element. They are handed to the
    GAME's element by event:

        Managers.event:trigger("add_world_marker_unit", ...)     (Handholder)
        Managers.event:trigger("add_world_marker_position", ...) (this mod, x3)

    and HudElementWorldMarkers stores them in _markers_by_type alongside pings,
    objectives and nameplates. So the element is vanilla, the contents are not.
    The allow-list above is therefore structurally unable to separate them: at
    line 347 keep_base_hud sees a vanilla class name and hands the element back
    its own visibility, which is correct for the element and wrong for what is
    riding inside it. keep_markers could only ever hide the whole element -
    pings and objectives included - which is why its own tooltip has to warn
    about that.

    THE GATE. _draw_markers consults a per-marker flag:

        local draw = marker.draw
        if draw then ... UIWidget.draw(widget, ui_renderer) end

    so clearing marker.draw drops one marker and leaves the element, and every
    vanilla marker in it, completely untouched. Same shape as the outline
    visibility_check wrapper: use the engine's own per-item gate instead of
    suppressing a whole pass. That mistake has already been made twice in this
    file (set_visible, and the Escape menu) and is not being made a third time.

    WHICH MARKERS ARE MOD-ADDED. Not a hardcoded list. DMF has no marker
    template registry, and mods inject straight into the live element -

        world_markers._marker_templates[RitualZonesMarker.name] = RitualZonesMarker

    - so the vanilla set is read from the game's own manifest at runtime:

        HudElementWorldMarkersSettings.marker_templates   (a list of paths)
        init: for i = 1, #marker_templates do
                  local template = require(marker_templates[i])
                  self._marker_templates[template.name] = template

    Requiring the same paths and collecting template.name gives exactly the
    names the game shipped, so a patch that adds a vanilla marker is picked up
    with no edit here. This is the one place where the allow-list direction is
    genuinely safe, because the list is the game's, not mine.
--]]
local vanilla_marker_names = nil

local function vanilla_markers()
    if vanilla_marker_names then
        return vanilla_marker_names
    end

    local names = {}
    local ok, settings = pcall(require,
        "scripts/ui/hud/elements/world_markers/hud_element_world_markers_settings")
    local paths = ok and settings and settings.marker_templates

    if type(paths) == "table" then
        for i = 1, #paths do
            local ok_t, template = pcall(require, paths[i])

            if ok_t and type(template) == "table" and template.name then
                names[template.name] = true
            end
        end
    end

    --[[
        Cache ONLY once it actually worked. An empty set would mean "nothing is
        vanilla", and this gate would then hide every marker in the game -
        pings and objectives included - permanently, because the empty result
        would be cached. Retrying next frame is the safe failure.
    --]]
    if next(names) then
        vanilla_marker_names = names
    end

    return names
end

mod:hook_safe(CLASS.HudElementWorldMarkers, "_calculate_markers", function(self)
    if not hidden or not hide_mod_markers then
        return
    end

    local by_type = self._markers_by_type

    if type(by_type) ~= "table" then
        return
    end

    local vanilla = vanilla_markers()

    if not next(vanilla) then
        -- Manifest unreadable: hide nothing rather than hide everything.
        return
    end

    --[[
        A post-hook, so the element has already decided marker.draw from
        distance, line of sight and its own rules. Clearing the flag can only
        ever take a marker away, never force one on, so the element stays the
        authority on its own markers and this only subtracts.
    --]]
    for marker_type, markers in pairs(by_type) do
        if not vanilla[marker_type] then
            for i = 1, #markers do
                markers[i].draw = false
            end
        end
    end
end)

-- Restore on mission end so the state cannot leak into the next run.
mod.reset_hud_hidden = function()
    if hidden then
        hidden = false
        pcall(Hud.apply)
    end
end

mod.toggle_hud = Hud.toggle
mod.Hud = Hud
return Hud
