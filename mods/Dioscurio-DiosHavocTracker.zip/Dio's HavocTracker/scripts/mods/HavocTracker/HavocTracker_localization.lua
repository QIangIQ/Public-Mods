return {
	--[[
		Display name only.

		The INTERNAL id stays "HavocTracker". Renaming the folder or the
		new_mod() id would orphan every saved setting, break the .mod file's
		three script paths, and invalidate the cache path the spawn forecast
		looks up. This changes what you see in the mod list and nothing else.
	--]]
	mod_name = {
		en = "Dio's HavocTracker",
	},
	mod_description = {
		en = "v2.13.1  |  Author: Dioscurio\nReconstructs the pacing system's challenge rating client-side and shows it against the thresholds that suppress trickle hordes, specials and main hordes. Values are estimates - the pacing manager itself is server-only.",
	},

	-- Diagnostics -----------------------------------------------------------
	loaded_message = {
		en = "Havoc Tracker loaded. Commands: /havoctracker (status), /htspawns (spawn forecast), /htpath (travel distance), /htreset (recentre overlay), /htramp (zero ramp).",
	},
	cmd_status_desc = {
		en = "Show Havoc Tracker status and current readings",
	},
	cmd_reset_desc = {
		en = "Reset the Havoc Tracker overlay to its default position",
	},
	cmd_ramp_reset_desc = {
		en = "Zero the ramp estimate (use after surviving a heavy fight)",
	},
	-- %s is supplied by the call site, so a specifier is correct here.
	breaker_subsystem = {
		en = "Havoc Tracker: '%s' paused after repeated errors. Other readouts keep working. Please report the messages above.",
	},

	-- Horde clock ------------------------------------------------------------
	horde_unknown = {
		en = "UNCONFIRMED",
	},
	horde_active = {
		en = "HORDE INCOMING",
	},
	horde_safe = {
		en = "NO HORDE",
	},
	horde_possible = {
		en = "HORDE POSSIBLE",
	},
	horde_overdue = {
		en = "HORDE DUE",
	},

	-- Ramp -------------------------------------------------------------------
	ramp_low = {
		en = "low",
	},
	ramp_building = {
		en = "building",
	},
	ramp_max = {
		en = "MAX?",
	},
	ramp_locked = {
		en = "LOCKED?",
	},

	--[[
	    Tripwire warnings

	    EVERY string in this file is passed through string.format by DMF's
	    localize (dmf/modules/core/localization.lua:23-35), whether or not you
	    supply arguments. A bare '%' is therefore read as the start of a format
	    specifier and throws "bad argument #2 to 'format'" - once per frame, if
	    the string is used in the HUD loop.

	    Write '%%' for a literal percent sign. A string MAY carry real
	    specifiers, but only if every call site reaches it via
	    mod:localize(key, args...) - never via the memoised L(), which passes
	    no varargs and would throw.
	--]]
	warn_backtrack = {
		en = "Backtracking in Progress - Punishment Incoming",
	},
	warn_spread = {
		en = "SPLIT UP - Disablers Incoming",
	},
	warn_alone = {
		en = "Out of Coherency - Disabler Targeting OoC Individual",
	},
	warn_speedrun = {
		en = "Too Fast - Speed-Run Disabler Armed",
	},
	warn_coherency = {
		en = "MULTIPLE SPLIT UP - Increased Punishment",
	},

	-- Verdict ----------------------------------------------------------------
	-- v_hold takes a distance argument, so its specifier is intentional.
	v_fix = {
		en = "Member Out of Coherency",
	},
	v_hold = {
		en = "HORDE IN PROGRESS - %dm fires horde",
	},
	v_hold_eta = {
		en = "HORDE IN PROGRESS - horde %dm/%ds",
	},
	v_horn = {
		en = "HORDE INCOMING - HORN, 3s",
	},
	v_brace = {
		en = "Horde Incoming",
	},
	v_go = {
		en = "Safe to Rush - spawns off",
	},
	--[[
		The two states where nothing can punish you. Worded to be
		distinguishable at a glance, because they are not equally durable: the
		cap is absolute, while challenge rating is cancelled the instant the
		lead player has nobody in coherency.
	--]]
	v_free_cap = {
		en = "RUSH RECOMMENDED",
	},
	v_free_cr = {
		en = "RUN - specials off",
	},
	v_go_together = {
		en = "Regroup Recommended",
	},
	v_move = {
		en = "Safe to Advance - Speedrun Punishment Possible",
	},

	-- Trickle ----------------------------------------------------------------
	t_suppressed = {
		en = "Light Horde OFF",
	},
	t_due = {
		en = "Light Horde due",
	},
	t_in = {
		en = "Light Horde %dm",
	},

	-- Priority queue ---------------------------------------------------------
	q_horde_now = {
		en = "HORDE LANDING",
	},
	q_horde_overdue = {
		en = "HORDE OVERDUE",
	},
	q_horde_due = {
		en = "HORDE DUE",
	},
	q_horde_gated = {
		en = "HORDE QUEUED",
	},
	q_horde_gated_eta = {
		en = "HORDE in %dm / %ds",
	},
	q_horn = {
		en = "HORDE SPAWNED - wave in %ds",
	},
	q_hound = {
		en = "HOUND - %ds",
	},
	q_trapper = {
		en = "TRAPPER - %ds",
	},
	q_horde_in = {
		en = "HORDE",
	},
	q_ramp_locked = {
		en = "DIFFICULT 2x",
	},
	q_ramp_locked_key = {
		en = "DIFFICULTY INCREASED",
	},
	q_ramp_near = {
		en = "near max difficulty",
	},
	sec_next = {
		en = "NEXT",
	},
	sec_state = {
		en = "STATE",
	},
	q_clear = {
		en = "clear",
	},

	-- Section headers --------------------------------------------------------
	sec_clock = {
		en = "CLOCK",
	},
	sec_pos = {
		en = "POSITION",
	},
	sec_forecast = {
		en = "FORECAST",
	},
	sec_ramp = {
		en = "RAMP",
	},
	sec_warn = {
		en = "WARNINGS",
	},
	fc_none = {
		en = "nothing due",
	},
	ramp_key = {
		en = "clearable",
	},
	ramp_nokey = {
		en = "no key",
	},

	-- Row labels -------------------------------------------------------------
	row_horde = {
		en = "HORDE",
	},
	row_ticket = {
		en = "TRIGGER",
	},
	row_spread = {
		en = "Most Progressed Player",
	},
	row_solo = {
		en = "solo",
	},
	row_back = {
		en = "BACK",
	},
	row_ramp = {
		en = "RAMP",
	},

	-- HUD -------------------------------------------------------------------
	hud_label = {
		en = "CHALLENGE RATING (est.)",
	},

	band_none = {
		en = "Light Horde ON",
	},
	band_trickle = {
		en = "LIGHT HORDE OFF",
	},
	band_specials = {
		en = "SPECIALS OFF",
	},
	band_hordes = {
		en = "HORDES OFF",
	},

	overlay_on = {
		en = "Havoc Tracker: overlay shown",
	},
	overlay_off = {
		en = "Havoc Tracker: overlay hidden (still tracking)",
	},

	-- Settings --------------------------------------------------------------
	simple_labels = {
		en = "Simple trigger names",
	},
	simple_labels_tooltip = {
		en = "Collapses MONSTER/CAPN, BEAST, CHAOS SPAWN, OGRYN, HOUNDMASTER and CAPTAIN into a single BOSS label.\n\nAt the moment you read the row they all mean the same thing - something big, at that distance, and going near it spawns it.\n\nTwins, daemonhosts, rituals and patrols keep their own names, because each of those is a different decision.",
	},
	show_headcount = {
		en = "Show enemy counts",
	},
	show_headcount_tooltip = {
		en = "Adds the headcount in brackets after each token cost, as \"ELITE  20.0  (20)\".\n\nOff by default because the count is not what decides anything - one elite costs the cap what three poxwalkers do, so a row that leads with 47 is leading with the number that matters least.",
	},
	show_notifications = {
		en = "Show spawn notifications",
	},
	show_notifications_tooltip = {
		en = "One line naming what just landed - ELITE PACK, SPECIALIST WAVE, HORDE, BOSS - which clears itself after a few seconds.\n\nThis replaced the old five-row spawn feed. The horde notification rides the horn cue, so it arrives about three seconds before the horde does.",
	},
	cap_compact = {
		en = "Compact cap rows",
	},
	cap_compact_tooltip = {
		en = "Puts the four category rows on one line instead of four.\n\n"
			.. "Off (default):\n"
			.. "  ELITE     14.0\n"
			.. "  OGRYN     14.0\n"
			.. "  SPECIAL    1.0\n"
			.. "  HORDE     18.6\n\n"
			.. "On:\n"
			.. "  E 14.0  O 14.0  S 1.0  H 18.6\n\n"
			.. "Same numbers, same order, three fewer rows. The total above stays on its own line either way.\n\n"
			.. "Headcounts follow the setting above and appear in brackets in both layouts.",
	},
	settings_preset = {
		en = "Preset",
	},
	settings_preset_tooltip = {
		en = "Three starting points. Picking one applies it and drops back to Custom, so the box describes what you did rather than claiming to describe your current settings - everything below stays editable afterwards.\n\nMinimal: the entity cap block only.\nStandard: the shipped arrangement.\nEverything: the full readout, including the modelled numbers.",
	},
	preset_custom = {
		en = "Custom",
	},
	preset_minimal = {
		en = "Minimal - cap block only",
	},
	preset_standard = {
		en = "Standard - cap block and spawns",
	},
	preset_everything = {
		en = "Everything - full readout",
	},

	geometry_group = {
		en = "Panel size and spacing",
	},
	keeps_group = {
		en = "Keep on screen when hidden",
	},
	advanced_group = {
		en = "Advanced",
	},

	reset_to_defaults = {
		en = "Reset settings",
	},
	reset_to_defaults_button = {
		en = "Hold to reset",
	},
	reset_to_defaults_tooltip = {
		en = "Puts every setting in this mod back to its shipped default, including the overlay position if you have lost it off screen.\n\nKeybinds are left alone - the default for those is nothing at all, so resetting them would only take away whatever you chose.\n\nHold the button rather than click it. This overwrites settings and a stray click should not be enough.",
	},

	path_marker_scale = {
		en = "Main path marker size",
	},
	path_marker_scale_tooltip = {
		en = "Size of the dots that trace the main path. Separate from the spawn and boss marker size, because the path is a long line of small markers and the others are a handful of large ones - a single number could not suit both.",
	},
	show_overlay = {
		en = "Show overlay",
	},
	show_overlay_tooltip = {
		en = "Master switch. Off hides everything this mod draws - the tracker panel, the spawn panel, the beacons and the path line - in one tick, without disabling the mod or unticking anything else. Tracking keeps running underneath, so the counters are still right when you turn it back on.",
	},
	toggle_overlay_key = {
		en = "Toggle overlay",
	},
	toggle_overlay_key_tooltip = {
		en = "Show or hide the panel without disabling the mod. Tracking keeps running while hidden, so the horde clock and counters are still correct when you bring it back - useful for Auric or anything non-Havoc.",
	},
	hud_offset_x = {
		en = "Horizontal position",
	},
	hud_offset_x_tooltip = {
		en = "Horizontal offset from the centre of the screen. Negative moves left. If you drag the panel in Custom HUD, Custom HUD's position wins; reset it there to hand the panel back to this slider.",
	},
	hud_offset_y = {
		en = "Vertical position",
	},
	hud_offset_y_tooltip = {
		en = "Vertical offset from the centre of the screen. Negative moves up. If you drag the panel in Custom HUD, Custom HUD's position wins; reset it there to hand the panel back to this slider.",
	},
	hud_scale = {
		en = "Scale",
	},
	hud_scale_tooltip = {
		en = "Scales the whole panel - text, box, borders and dots. Goes up to 6x for low resolutions: Darktide's UI is laid out against a 1080p reference and downscaled, so at 360p everything renders at roughly a third size. Try 3 to 4 there.",
	},
	panel_opacity = {
		en = "Panel opacity",
	},
	panel_opacity_tooltip = {
		en = "Background transparency, 0-100. At 0 the box vanishes and only the text and a faint border remain. The border stays slightly more opaque than the fill so the panel keeps its shape.",
	},

	-- Spawn forecast ---------------------------------------------------------
	show_spawn_panel = {
		en = "Show spawn panel",
	},
	show_spawn_panel_tooltip = {
		en = "Right-hand box listing upcoming monster, captain, patrol and daemonhost spawn points, nearest first. Distances are measured from the FURTHEST-AHEAD player, because that is what the game itself tests against - a teammate who rushes ahead pulls the spawn while you are still walking. Green over 60m, amber closing, red inside 15m.",
	},
	show_spawn_walls = {
		en = "Show world walls",
	},
	show_spawn_walls_tooltip = {
		en = "Draws a translucent wall at each upcoming spawn line, in the world. Widens and brightens as you close on it. These are drawn as flat screen overlays rather than engine geometry, so they cost nothing to create or destroy.",
	},
	show_ritual_markers = {
		en = "Show ritual markers",
	},
	show_ritual_markers_tooltip = {
		en = "Marks every live chaos ritual in the world, visible through walls and clamped to the screen edge when off-screen, so it doubles as a compass. Colour shows TICK STATE rather than distance: red is ticking at full speed, amber is ticking at one ninth rate, grey is dormant. Rituals advance on main-path travel distance measured against the LEAD player, so how close you personally are does not matter.",
	},
	show_path_line = {
		en = "Show main path line",
	},
	show_path_line_tooltip = {
		en = "Lays small dots along the main path ahead of the lead player, so you can see the optimal route. Drawn as world markers rather than engine line geometry - the same system the spawn markers use - so it costs nothing to create or destroy and shares its positions with the trigger markers.",
	},
	pace_markers = {
		en = "Punishment lines in the world",
	},
	pace_markers_tooltip = {
		en = "Draws the lines the game punishes you for crossing, on the route itself, independent of the panel. Speed gate: where the lead player has to stay until its countdown ends, or the next speed-running check counts and two in a row spawn a hound, mutant or trapper ahead of them. Rush lines: where the lead player gets too far ahead of the next player, or the last player too far behind. Blockade line, rank 16 and up: 50 m behind the furthest point the team reached, where the push-from-behind horde strike gets much more likely. Use /htpace for the numbers behind them.",
	},
	pace_marker_speed = {
		en = "Speed-running gate",
	},
	pace_marker_speed_tooltip = {
		en = "Shown only when one more fast check would spawn a disabler. HOLD 3.2s / 6m means: stay behind this marker for 3.2 seconds and every possible server check resets. The server checks every 5 s whether the lead player moved 10 m or more (12 m at ranks 1-10) while enemies are aggroed; it does not say when its clock ticks, so the countdown covers every possible timing. TOO FAST means a check is already lost and a disabler is coming ahead of the lead player.",
	},
	pace_marker_rush = {
		en = "Rush lines",
	},
	pace_marker_rush_tooltip = {
		en = "RUSH LINE: the point where the lead player is the rush distance (35 m at rank 31+, 40 m at 30, 45 m at 11-29, 50 m at 1-10) ahead of the next player along the route, which spawns a hound or mutant ahead of them. FALLING BEHIND: the same distance behind the player in front, for the last player, which spawns one behind them. Hidden while the rush cooldown is probably running.",
	},
	pace_marker_backtrack = {
		en = "Blockade line (rank 16+)",
	},
	pace_marker_backtrack_tooltip = {
		en = "Fading Light only. 50 m behind the furthest point the team has reached. Behind it, the blockade push-sandwich horde strike rolls at 50 (rank 16-29) or 80 (rank 30+) in 100 instead of 5 in 100 each time a horde starts.",
	},
	pace_marker_scale = {
		en = "Punishment line size",
	},
	pace_marker_scale_tooltip = {
		en = "Scales the punishment line markers and their labels. Sizes are 1080p reference pixels, so raise this at low resolutions.",
	},
	spawn_marker_opacity = {
		en = "World marker opacity",
	},
	spawn_marker_opacity_tooltip = {
		en = "How solid the in-world skulls are, 5-100. These are ambient information rather than a threat indicator, so they default low and sit behind the fight. Gate dots render fainter still, and the distance label stays more readable than the icon since the text is the part carrying information.",
	},
	spawn_marker_scale = {
		en = "World marker size",
	},
	spawn_marker_scale_tooltip = {
		en = "Scales the in-world spawn icons, gate dots and their labels. Marker sizes are 1080p reference pixels that get downscaled to your resolution, so at 360p a default-size gate dot renders about 4 real pixels and is invisible. Try 2.5 to 4 at low resolutions.",
	},
	spawn_audio_cue = {
		en = "Audio cue",
	},
	spawn_audio_cue_tooltip = {
		en = "Plays a short UI sound when the nearest trigger enters the red band, and when a monster spawn forces a horde. Uses existing game sounds - custom audio cannot be added, because sounds are baked into Wwise soundbanks and referenced by name.",
	},
	spawn_accuracy_log = {
		en = "Accuracy log",
	},
	spawn_accuracy_log_tooltip = {
		en = "Writes what was predicted against what actually spawned to HavocTracker_accuracy.log in your Darktide AppData folder, one block per mission. Lets you check the probability model against your own runs instead of trusting it blind.",
	},
	forced_horde = {
		en = "MONSTER - HORDE FORCED",
	},
	pacing_paused = {
		en = "pacing paused %ds",
	},
	dh_skip = {
		en = "DH %dm - SKIPPED",
	},
	dh_hold = {
		en = "DH %dm (need 65m)",
	},

	spawn_scale = {
		en = "Panel scale",
	},
	spawn_scale_tooltip = {
		en = "Scales the spawn panel independently of the main tracker - text, box, borders and bars. Goes to 8x for low resolutions: Darktide lays its UI out against a 1080p reference and downscales, so at 360p everything renders at roughly a third size. Try 3 to 4 there. Does not affect the world walls, which are sized by distance.",
	},
	spawn_offset_x = {
		en = "Panel horizontal position",
	},
	spawn_offset_x_tooltip = {
		en = "Horizontal offset from screen centre. Positive moves right. If you drag the panel in Custom HUD, Custom HUD's position wins; reset it there to hand the panel back to this slider.",
	},
	spawn_offset_y = {
		en = "Panel vertical position",
	},
	spawn_offset_y_tooltip = {
		en = "Vertical offset from screen centre. Negative moves up. If you drag the panel in Custom HUD, Custom HUD's position wins; reset it there to hand the panel back to this slider.",
	},

	-- HUD declutter ----------------------------------------------------------
	declutter_group = {
		en = "Hide HUD",
	},
	toggle_hud_key = {
		en = "Toggle HUD off",
	},
	toggle_hud_key_tooltip = {
		en = "Hides most of the base game HUD so you can see what you are fighting. Crosshair, health, ability, ammo, stamina and interaction prompts are always kept, as are this mod's panels and world markers. Press again to restore. Restores automatically at mission end.",
	},
	keep_crosshair = {
		en = "Keep crosshair",
	},
	keep_crosshair_tooltip = {
		en = "Keep the crosshair visible while the HUD is hidden.",
	},
	keep_vitals = {
		en = "Keep health, ability and ammo",
	},
	keep_vitals_tooltip = {
		en = "Keep your health bar, ability charge, stamina, peril and ammo counter visible while the HUD is hidden.",
	},
	keep_interact = {
		en = "Keep interaction prompts",
	},
	keep_interact_tooltip = {
		en = "Keep 'press F' style prompts visible while the HUD is hidden. Turning this off means you cannot see what you are about to interact with.",
	},
	keep_chat = {
		en = "Keep chat window",
	},
	keep_chat_tooltip = {
		en = "Keep the chat window visible while the HUD is hidden. Chat is drawn by a separate system from the rest of the HUD, so it has its own switch. Messages still arrive while hidden and are all there when you restore.",
	},
	keep_team = {
		en = "Keep team panel",
	},
	keep_team_tooltip = {
		en = "Keep teammate health and status visible while the HUD is hidden.",
	},
	keep_boss = {
		en = "Keep boss health",
	},
	keep_boss_tooltip = {
		en = "Keep monster and boss health bars visible while the HUD is hidden.",
	},
	keep_objective = {
		en = "Keep objectives",
	},
	keep_objective_tooltip = {
		en = "Keep mission objective text and progress bars visible while the HUD is hidden.",
	},
	keep_buffs = {
		en = "Keep buffs",
	},
	keep_buffs_tooltip = {
		en = "Keep your buff and debuff icons visible while the HUD is hidden.",
	},
	keep_tags = {
		en = "Keep tags and nameplates",
	},
	keep_tags_tooltip = {
		en = "Keep smart tags and player nameplates visible while the HUD is hidden. These are a common source of clutter, so this is off by default.",
	},
	keep_tracker = {
		en = "Keep tracker panel",
	},
	keep_tracker_tooltip = {
		en = "Keep the left challenge-rating panel visible while the HUD is hidden. Off by default: if you are pressing the key to see the fight, this mod's own output is part of what is in the way.",
	},
	keep_spawn_panel = {
		en = "Keep spawn panel",
	},
	keep_spawn_panel_tooltip = {
		en = "Keep the right-hand spawn forecast panel visible while the HUD is hidden.",
	},
	keep_markers = {
		en = "Keep world markers",
	},
	keep_markers_tooltip = {
		en = "Keep in-world spawn skulls, gates and the path line visible while the HUD is hidden. This is the game's world-marker element, so turning it off also hides pings and objective markers.",
	},
	clean_limit_outlines = {
		en = "Limit outlines to a radius",
	},
	hud_mode = {
		en = "HUD mode",
	},
	panel_width = {
		en = "Panel width",
	},
	chat_post = {
		en = "Post readout to chat",
	},
	chat_post_tooltip = {
		en = "Post the tracker readout to STRIKE TEAM chat automatically, so the whole team can read it.\n\nPosts on the interval below. /htpost posts once on demand.\n\nTurn on 'Preview only' if you want to check the format in your own console first without sending anything.",
	},
	chat_post_preview = {
		en = "Preview only (do not send)",
	},
	chat_post_preview_tooltip = {
		en = "Testing mode. Prints the line to your own console instead of sending it to strike team chat.\n\nOff by default, because the point of the feature is that your team can see the readout. Use this only while checking the format. /htpostlive sends regardless of this setting.",
	},
	chat_post_interval = {
		en = "Post every (seconds)",
	},
	chat_post_events = {
		en = "Post on important events",
	},
	chat_post_events_tooltip = {
		en = "Post the moment something changes, not just on the timer.\n\nCalls out: entering high pressure, capped or overcap; a specialist wave landing; a weakened monstrosity spawning; a special surge starting; and CAP BLOCKED, which means a boss spawned with no horde behind it because the entity cap refused it.\n\nEach kind has its own cooldown, and an identical message is never repeated - so a value flickering across a threshold posts once, not four times.",
	},
	chat_post_interval_tooltip = {
		en = "How often to post the full readout, 5-120 seconds. Default 10.\n\nThis is the heartbeat. Event posts are separate and fire the moment something changes, which is usually the more useful of the two.",
	},
	chat_post_status = {
		en = "Confirm each post",
	},
	chat_post_status_tooltip = {
		en = "Print a short confirmation to your own console each time a post is sent to team chat.",
	},
	panel_width_tooltip = {
		en = "Width of the tracker panel in pixels, 180-640. Default 360.\n\nWider is the real fix for a row that has shrunk to fit - the character budget each row gets is derived from this number, so widening the panel buys text rather than empty space.",
	},
	panel_row_height = {
		en = "Row height",
	},
	panel_row_height_tooltip = {
		en = "Vertical space per line, 14-34. Default 19.\n\nThe row font is derived from this, not just the spacing, so raising it makes the text bigger as well as the gaps. Raise it if descenders on one line touch the line below.",
	},
	panel_section_gap = {
		en = "Section gap",
	},
	panel_section_gap_tooltip = {
		en = "Extra space above each section heading, 0-20. Default 3.",
	},
	cap_opacity = {
		en = "Cap panel opacity",
	},
	cap_opacity_tooltip = {
		en = "How solid the entity cap panel is, 40-255. Default 150 - greyed back so it reads as reference rather than competing with the fight.",
	},
	show_cascade = {
		en = "Show specialist cascade",
	},
	show_cascade_tooltip = {
		en = "Show the specialist wave timer, surge state and the token counter explaining the current cap.\n\nWave timings follow the 45/30/15/15/15/5/5/5/5/5 pattern from room entry. These are MODELLED from play, not read from the game, and predicted values are marked with ~ in the readout so they are never mistaken for measurements.",
	},
	hud_mode_tooltip = {
		en = "What the tracker panel shows.\n\nEntity cap only: five lines - the weighted total against the 45 budget, then elites, ogryn elites, specials and horde.\n\nFull readout: the original panel with the verdict, priority queue, challenge rating, trickle, spread and ramp rows.\n\nNothing is deleted by choosing cap-only. Everything still runs and is simply not drawn, so switching back is instant.",
	},
	hud_mode_cap_only = {
		en = "Entity cap only",
	},
	hud_mode_full = {
		en = "Full readout",
	},
	clean_limit_outlines_tooltip = {
		en = "While the HUD is hidden, only outline things within the radius below. Everything further away stops drawing, including anything that would otherwise show through a wall. Outlines are not HUD elements, so the keep list above cannot touch them - this is their switch. Works on every outline the game has: enemies, allies, knocked-down teammates, smart tags.",
	},
	clean_outline_radius = {
		en = "Outline radius (m)",
	},
	clean_outline_radius_tooltip = {
		en = "Metres. Anything beyond this stops being outlined while the HUD is hidden. 20 is about a room; drop to 8 or so for a nearly bare screen, raise toward 60 if you still want to read the fight.",
	},
	clean_hide_dangerzones = {
		en = "Hide hazard decals",
	},
	clean_hide_dangerzones_tooltip = {
		en = "Turns off danger_zone's ground markers - barrel fuses, poxburster and flamer warnings, daemonhost auras - while the HUD is hidden, and puts them back exactly as they were when you restore it. Does nothing if danger_zone is not installed.",
	},
	clean_hide_weakspots = {
		en = "Hide weakspot markers",
	},
	clean_hide_weakspots_tooltip = {
		en = "Turns off BackstabHitboxDisplay's weakspot and backstab overlay while the HUD is hidden, and puts it back exactly as it was when you restore. Only settings that were ON get touched, so anything you had already disabled stays disabled. Does nothing if that mod is not installed. Separate from the game's own Interface > Hit Indicator option, which is always on or always off.",
	},
	clean_hide_mod_markers = {
		en = "Hide mod world markers",
	},
	clean_hide_mod_markers_tooltip = {
		en = "Hide in-world markers added by mods while the HUD is hidden: this mod's boss, twins and patrol skulls, the gate dots and the path line, plus health markers from Dio's Handholder.\n\nThis is not the same as 'Keep world markers'. Mod markers are handed to the game's own world-marker element and stored next to pings, objective markers and nameplates, so that setting can only take the whole element away - useful markers included - and 'Keep base game HUD' overrides it in any case. This setting drops only the mod-added markers and leaves every vanilla one exactly as it was.",
	},

	keep_base_hud = {
		en = "Keep the base game HUD",
	},
	keep_base_hud_tooltip = {
		en = "Hide only HUD elements that MODS added, and leave every vanilla one exactly as the game had it - boss health bars, vitals, objectives, the interaction prompt. This is the setting for recording: a viewer sees a normal Darktide HUD with none of the mod overlays. The keep list above still works on top, so an individual mod panel can be kept. Turn this OFF for the old behaviour, where everything is hidden and the keep list adds things back one at a time.",
	},



	-- Chat scaling -----------------------------------------------------------
	chat_group = {
		en = "Game chat size",
	},
	chat_scale_enabled = {
		en = "Scale game chat",
	},
	chat_scale_enabled_tooltip = {
		en = "Enlarges the base game chat window text, including mod output and the line you are typing. Does not move the chat window - only the font size changes. Turn off to leave chat exactly as the game draws it.",
	},
	chat_scale = {
		en = "Chat text size",
	},
	chat_scale_tooltip = {
		en = "Multiplier on the game's chat font. Chat is laid out against a 1080p reference and downscaled, so at 360p the default is roughly a third size and mod diagnostics are unreadable. Try 2 to 3 there. Message boxes grow to fit, so nothing clips.",
	},

	use_aggro_estimate = {
		en = "Estimate aggro (recommended)",
	},
	use_aggro_estimate_tooltip = {
		en = "The server sums challenge rating over AGGROED minions only. Aggro is not replicated to clients, so this approximates it: a minion counts if it is within its own breed's detection radius (times the multiplier below) of any player. Turning this off counts every living minion on the level, which reads several times too high because pre-placed roamers stream in ahead of you.",
	},
	aggro_multiplier = {
		en = "Aggro range multiplier",
	},
	enable_prediction = {
		en = "Enable prediction layer",
	},
	enable_prediction_tooltip = {
		en = "Turns off the forecast board, tension model, budget tracking and ramp-key readout. The measured readouts - challenge rating, horde clock, spread, backtrack and the tripwire warnings - keep working. Use this if the predictive rows misbehave.",
	},
	census_interval = {
		en = "Census interval (s)",
	},
	census_interval_tooltip = {
		en = "How often the minion census is rebuilt. This is the most expensive thing the mod does, because its cost scales with the number of live minions (up to 110 on Havoc). Raise it to 0.5 if you are framerate-limited; the challenge rating simply updates half as often.",
	},
	path_interval = {
		en = "Path interval (s)",
	},
	path_interval_tooltip = {
		en = "How often player positions are queried for spread, backtrack and the ramp. Each query is an engine spline lookup per player. 0.1 is ten times a second, which is far finer than you can react to anyway.",
	},
	aggro_multiplier_tooltip = {
		en = "Multiplies each breed's detection radius (typically 15-20m). A minion that has already aggroed chases you well beyond the range at which it noticed you, so 1.0 under-counts an active fight. Raise it if the reading stays suspiciously low during a real horde; lower it if the number never drops when a fight ends.",
	},
}
