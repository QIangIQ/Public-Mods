-- HavocTracker harvested cache.
--
-- Recovered from HavocTracker_accuracy.log, which recorded every monster and
-- daemonhost spawn across 34 logged runs. The value used is the `lead=` field:
-- the furthest-ahead player's travel distance at the moment the spawn fired.
--
-- WHAT THESE NUMBERS ARE, precisely. MonsterPacing.update spawns when
--     spawn_travel_distance <= ahead_travel_distance
-- so `lead` at fire time is an UPPER BOUND on the real trigger distance, tight
-- to one tick of player movement. They are also OBSERVED points, not the full
-- candidate set - a run rolls 1-3 monsters out of 10-29 candidates, so this is
-- a sample that grows every time a map is replayed.
--
-- Merged per category, richer wins, so this never overwrites better data that
-- was harvested with a mutator active. Generated; safe to delete.
return {
  maps = {
    cm_archives = {
      boss = {
        28.200000,
        61.200000,
        289.900000,
        749.200000,
        833.500000,
        989.700000,
        1001.000000,
      },
    },
    cm_habs = {
      boss = {
        382.200000,
      },
    },
    cm_raid = {
      boss = {
        11.100000,
        63.900000,
        117.300000,
        163.800000,
        360.550000,
        900.766700,
      },
    },
    core_research = {
      boss = {
        43.500000,
      },
    },
    dm_forge = {
      boss = {
        52.600000,
        86.700000,
        132.900000,
        355.900000,
        430.100000,
        493.700000,
        537.800000,
        614.700000,
        723.800000,
        764.000000,
        1001.100000,
      },
    },
    dm_rise = {
      boss = {
        56.900000,
        67.600000,
        78.533300,
        120.900000,
        338.500000,
        476.200000,
        533.700000,
        608.300000,
        731.400000,
        935.800000,
      },
    },
    fm_cargo = {
      boss = {
        21.950000,
        86.100000,
        114.800000,
        185.400000,
        202.900000,
        265.900000,
        301.850000,
        330.300000,
        409.766700,
        421.800000,
        473.700000,
        554.700000,
        708.700000,
        768.400000,
        805.400000,
        829.000000,
        866.700000,
        1076.300000,
        1134.100000,
      },
    },
    fm_resurgence = {
      boss = {
        140.600000,
        816.400000,
      },
    },
    hm_cartel = {
      boss = {
        232.100000,
      },
    },
    hm_strain = {
      boss = {
        720.400000,
        786.300000,
        814.500000,
        1061.300000,
      },
    },
    km_enforcer = {
      boss = {
        49.400000,
        203.650000,
        280.500000,
        551.500000,
        604.700000,
        625.100000,
        703.300000,
        822.000000,
      },
    },
    km_heresy = {
      boss = {
        38.900000,
        62.066700,
        178.200000,
        208.400000,
        276.400000,
        322.200000,
        352.400000,
        423.500000,
        445.333300,
        576.400000,
        601.200000,
        618.800000,
        661.300000,
        695.700000,
        778.800000,
        946.800000,
        997.500000,
        1013.900000,
      },
    },
    km_station = {
      boss = {
        32.400000,
        114.400000,
        141.400000,
        150.200000,
        162.900000,
        204.100000,
        220.300000,
        279.200000,
        418.600000,
        431.000000,
        441.100000,
        529.800000,
        544.300000,
        616.000000,
        739.600000,
        849.800000,
        961.900000,
      },
    },
    lm_cooling = {
      boss = {
        42.200000,
        59.500000,
        75.400000,
        90.900000,
        106.066700,
        174.600000,
        194.100000,
        334.900000,
        439.700000,
        508.100000,
        549.900000,
        614.400000,
        699.300000,
        709.700000,
        790.900000,
        799.800000,
        828.300000,
        845.800000,
        987.100000,
      },
    },
  },
}
