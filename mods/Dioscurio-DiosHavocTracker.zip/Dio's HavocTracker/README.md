# Havoc Tracker

Step 1 of the tracker project: a working mod skeleton plus a live **challenge rating** readout.

Challenge rating is the pacing system's measure of how much aggroed enemy is on the field. It gates three
spawn systems at Havoc 40:

| Above | What stops |
|-------|------------|
| **40** | Trickle hordes — and distance walked while suppressed is *permanently deleted*, not banked |
| **160** | Specials |
| **180** | Main hordes and roamers |

Holding above 40 is the only mechanic in the game that destroys future spawns rather than delaying them.

---

## Install

1. Copy the `HavocTracker` folder into:
   `...\steamapps\common\Warhammer 40,000 DARKTIDE\mods\`
2. Open `mods\mod_load_order.txt` and make sure the line reads:
   ```
   HavocTracker
   ```
   **not** `-- HavocTracker`. A leading `--` comments it out and the game silently skips it.
   Mod managers such as Servo-Modquisitor sometimes add newly-detected folders in the disabled state.
3. Launch. Settings live under **Options → Mod Options → Havoc Tracker**.

Default overlay position is upper-left. Move it in the settings.

### Is it actually running?

On load it prints a confirmation to chat. Two commands are also available:

| Command | Does |
|---|---|
| `/havoctracker` | Prints enabled state, mission state, tracked unit count, current CR, and overlay position |
| `/havoctracker_reset` | Snaps the overlay back to its default position if you've lost it off-screen |

If you see no overlay **and** no settings tab, the mod did not load — check step 2 first. A mod that loads but
is drawing off-screen looks identical, which is what `/havoctracker` is there to disambiguate.

---

## Read the number correctly

The value renders as `~ 47`. **The tilde is not decoration.**

`Managers.state.pacing` is created inside an `if is_server` block, and Havoc runs on Fatshark dedicated
servers, so on your client that manager is `nil`. The authoritative challenge rating cannot be read. This mod
reconstructs it by watching every networked minion spawn and death and summing `breed.challenge_rating`.

The reconstruction differs from the server's value in one known way:

> The server sums over **aggroed** minions. Aggro state is not replicated to clients, so this sums over
> **living** minions. **It reads high**, especially when un-aggroed roamers are nearby.

### How the aggro estimate works

Each breed carries its own `detection_radius` — the range at which it notices players. It sits right next to
`challenge_rating` on the breed table. Typical values:

| Breed type | Detection radius |
|---|---|
| Melee grunts, ragers, maulers | 15 m |
| Hounds, mutants, monsters | 20 m |
| Flamers (mutator variant) | 12 m |

A minion counts toward the reading if it is within `detection_radius × multiplier` of any living player. The
multiplier defaults to **2.0** because a minion that has already aggroed will chase you far beyond the range at
which it first noticed you, so the raw radius alone under-counts an active fight.

### Calibrating

1. Leave the estimate **on** at multiplier 2.0.
2. Watch the reading during a lull versus during a real horde. It should sit low when nothing is happening and
   climb sharply in a fight.
3. Tune:
   - Reading stays suspiciously low during a genuine horde → **raise** the multiplier.
   - Reading never drops after a fight ends → **lower** it.
4. The sanity check: **trickle hordes should visibly stop arriving at around 40.** That is the one threshold you
   can actually observe, so calibrate against it.

> If you turn the estimate off you will see readings of 150–250. That is every living minion on the level,
> including pre-placed roamers streaming in ~75 m ahead of you that have never seen you. It is not the number the
> server is using.

---

## Settings

| Setting | Default | Notes |
|---|---|---|
| Horizontal / vertical position | -700 / -260 | Offset from screen centre |
| Scale | 1.0 | Text size |
| Show detail line | on | Live minion count + the three thresholds. Turn off once calibrated. |
| Estimate aggro | **on** | Restricts counting to minions plausibly aware of you. See above. |
| Aggro range multiplier | 2.0 | Multiplies each breed's own detection radius |

---

## Colour coding

Estimated values never render in plain white — that is reserved for exact readouts in later steps.

| Colour | Meaning |
|---|---|
| Amber | Below 40 — trickles flowing |
| Green | 40+ — trickles suppressed |
| Blue | 160+ — specials suppressed |
| Pale blue | 180+ — hordes suppressed |

---

## What this does not do

Not because it wasn't built yet, but because a client physically cannot see it:

- Special slot timers and their pre-rolled breeds
- Monster / boss patrol positions
- The ramp meter's true value
- Coordinated strike budgets remaining
- Tension and pacing state

Planned next (all achievable, all exact):

1. **Path module** — front-to-back spread (35 m tripwire), backtrack margin (50 m tripwire), furthest reached
2. **Horde clock** — seconds since the last horde via spawn-burst detection, plus an overdue flag
3. **Tripwire warnings** — alone timer, speedrun check
4. **Ramp estimator** — last, and it will be a coarse `LOW / BUILDING / MAX?` band rather than a percentage

---

## Compatibility

Hooks used:

- `UnitSpawnerManager.spawn_husk_unit` — public games (the one that matters)
- `UnitSpawnerManager._add_network_unit` — private/local games
- `MinionDeathManager.set_dead` — fast removal
- `hud_elements_player` / `_onboarding` / `_spectator` — overlay injection

All are `hook_safe` and read-only. Nothing is modified. The census is additionally pruned every 0.25 s against
`HEALTH_ALIVE`, so despawns and out-of-bounds cleanup are handled even though they never fire `set_dead`.

Shares the `spawn_husk_unit` hook with QIangIQ's Enemy Tracker. `hook_safe` hooks stack, so both work.

Re-derive the threshold values after any Darktide patch.

---

## The readout, line by line

```
CHALLENGE RATING (est.)
~ 47                      <- estimate, colour = which gate you're past
TRICKLES SUPPRESSED
HORDE  38s  possible      <- clock since last horde wave
TICKET  22 m              <- EXACT. metres to next horde quota unlock
SPREAD 18 m   BACK 0 m    <- EXACT. 35m and 50m tripwires
RAMP  building            <- estimate, drifts high
ALONE - disabler incoming <- tripwire warnings, up to 2 shown
12 minions | 40 trickle 160 specials 180 hordes
```

**Colour tells you what to trust.** White = exact, computed from the main path spline. Amber/green/blue =
reconstruction. Red = warning.

### Horde clock

Counts up from the last detected horde wave. A wave is 10+ spawns inside 2 seconds; trickles arrive in small
groups and don't trip it. Waves within 14s of each other are treated as the same horde continuing.

| State | Meaning |
|---|---|
| `HORDE INCOMING` | A wave landed in the last 14s; more may follow |
| `clear` | Below the earliest the next horde can fire |
| `possible` | Inside the window where it can arrive |
| `OVERDUE` | Past the ceiling — it's waiting on distance. It will fire the moment you cross the ticket line |

The window shrinks as the ramp estimate climbs (~42–83s at low ramp, ~21–42s at max).

### Tripwires

All three specials-pacing punishments are run on the client the way the server runs them
(`HavocTracker_pace.lua`, from `specials_pacing.lua` in game 1.13.4). `/htpace` prints the live state.

| Warning | Trigger (rank 31+) | What it costs you |
|---|---|---|
| `BACKTRACKING` | Lead more than 50 m behind the team's furthest point (rank 16+) | Blockade sandwich strike rolls 0.8 instead of 0.05 |
| `SPREAD` | Lead 35 m ahead of the NEXT player along the route, or last player 35 m behind the one in front (40 m at rank 30, 45 m at 11-29, 50 m at 1-10). Needs a free special slot; 25-45 s cooldown | Hound or mutant ahead of the lead / behind the last |
| `ALONE` | Somebody at coherency 1 with 3+ players up. Fires 8-16 s after they went alone (3-7 s failed cooldown, then loner_time 5-9 s) | Hound, mutant or trapper at the loner |
| `SPEEDRUNNING` | Every 5 s: did the lead move 10 m or more with CR 8 or more? Two yes in a row (four at ranks 1-10, two there if the lead is alone) | Hound, mutant or trapper ahead of the lead. Ignores the special allowance; only full slots stop it |
| `COHERENCY` | Any player at 2 or less in their bubble | Spread ambush 0.5 -> 0.8 |

Things that are easy to get wrong about speed-running:

- A CR drop does **not** reset it. The check simply stops running and keeps its last baseline, so a fast walk
  through an empty corridor counts as one check the moment the next fight starts.
- The server's 5 s clock is not visible to clients, so the mod runs the rule for all 50 possible 0.1 s offsets and
  shows the worst case. The **speed gate** world marker reads `HOLD 3.2s / 6m`: stay behind it until the countdown
  ends and every possible check resets. `TOO FAST` means a check is already lost.
- Safe pace is under 2 m/s averaged over 5 s, or a full stop for 5 s after moving.

Disabler cap: Havoc uses its own table, not the default one. Challenge 5 (rank 21+) allows 4 active disablers
with 1, 2, 3 or 4 players up, so a down does not lower it. Challenge 4 is 3/3/3/3, challenge 3 is 2/2/3/3.

### Ramp — read the caveat

The fill is modelable. The **resets are not**: they fire when server-side tension crosses 122.5, which clients
never see. So the estimate only drifts upward and will eventually claim `MAX?`/`LOCKED?` when the truth may be a
fresh reset. The `?` is deliberate.

After surviving a genuinely heavy fight — the kind that would push the team into high tension — run
`/havoctracker_ramp_reset` to zero it. That is the honest workflow; treat the ramp row as a prompt to think,
not as a readout.

---

## Known issue: skipped position pairs

`Vector3.distance_squared` occasionally rejects a value from `POSITION_LOOKUP` with
*"Vector3 expected, got userdata"*. **Root cause not yet identified.** Fatshark's own code calls the same pair
unguarded, and `travel_distance_from_position` consumes the same values without complaint, so it is narrower than
"POSITION_LOOKUP is unsafe" — but I could not pin it down from the source alone.

It is now contained rather than fixed: the call is wrapped, a failed pair is skipped, and the count is reported by
`/havoctracker` as **skipped position pairs**. A handful is harmless. Hundreds means the aggro estimate is
degraded.

**Workaround if it becomes a problem:** turn **Estimate aggro** off. That removes all distance maths, so the crash
cannot occur. The reading becomes an inflated whole-level count (150–250), but everything else — horde clock,
path rows, tripwires — is unaffected and exact.

---

## Works at every Havoc rank

The mod reads your actual assignment and scales to it. `DifficultyManager` is created at
`gameplay_init_step_managers.lua:98` — **outside** the `is_server` block — so unlike the pacing manager it *does*
exist on clients, carrying rank, challenge, resistance and the modifier list.

`HavocTracker_ranks.lua` holds every value resolved from source for ranks 1–40. The header shows what was
detected. Some of what changes:

| Rank | ch/res | Horde template | Ticket | Trickle gate | Specials |
|---|---|---|---|---|---|
| 1–10 | 3/3 | havoc_horde[3] | 80–130 m | 30 | 5 |
| 11–15 | 4/4 | havoc_horde[4] | 50–80 m | 35 | 9 |
| 16–29 | 4–5/4 | **havoc_01** | 50–70 m | 35–40 | 9–11 |
| 30 | 5/5 | **havoc_02** | 45–70 m | 40 | 13 |
| 31–40 | 5/**6** | havoc_02 | 45–70 m | 40 | 14–16 |

Rank 30→31 is the single biggest jump in Havoc: a full resistance step. Non-Havoc missions fall back to matching
on raw challenge/resistance and the header says `NON-HAVOC`.

---

## Reading the box

The top line is **the call**. Everything under it is the evidence.

```
┌────────────────────────────┐
│ HAVOC 31-40  ch5/res6      │
│ HOLD - 22m fires horde   ● │  <- the decision
│ NEXT                       │
│ HORDE ready in 22m       ● │
│ > spread ambush 80%      ● │
│ COHERENCY - ambush       ● │
│ STATE                      │
│ ~47 TRICKLE OFF          ● │
│ trickle OFF              ● │
│ SPREAD 18m  BACK 0m      ● │
│ building? blk0/3 amb2/4  ● │
└────────────────────────────┘
```

### The verdict line

| Says | Means |
|---|---|
| **FIX POSITION** | A tripwire is already tripped — a disabler is being aimed at someone. Deal with that first. |
| **HOLD - 22m fires horde** | The horde timer is up and *only distance* is holding it. Crossing that line fires it. Cross when you're set, not mid-corridor. |
| **BRACE - horde due** | Nothing is holding it back. It's coming; be positioned. |
| **MOVE - trickle suppressed** | Challenge rating is above the gate, so every metre walked **deletes** trickle progress instead of banking it. Free distance — go. |
| **MOVE - short hops** | Nothing pending. Move, but distance banks horde tickets that never expire, so short hops beat long sprints. |

That last distinction is the whole "when to move, when to hold" question. The mechanically important one is
`HOLD - Xm fires horde`: it is invisible in game, and it is the difference between eating a horde in a corridor
and eating it where you chose to.

### Solo

Spread collapses to backtrack-only when you are genuinely alone — with one player there is no second player to
measure a gap against, and the rush-prevention rule it describes cannot fire. **Bots still count**: the game
measures `side.valid_player_units`, which includes them, so coherency and spread stay live in solo-with-bots.


The panel is ordered by **what happens soonest**, not by category.

```
┌────────────────────────────┐
│ HAVOC 35   ch5/res6        │
│ NEXT                       │
│ COHERENCY - 80%% ambush   ● │  <- already tripped
│ HORDE DUE  spread amb 80%%● │  <- imminent, with its likely strike
│ RAMP LOCKED - clearable  ● │
│ STATE                      │
│ ~47  TRICKLES SUPPRESSED ● │
│ SPREAD 18m  BACK 0m      ● │
│ RAMP building  ambush 2/4● │
└────────────────────────────┘
```

**NEXT** is a priority queue. Everything foreseeable is ranked by time to impact:

| Priority | What lands there |
|---|---|
| **p0 — now** | A tripwire you have already crossed, or a horde landing this second |
| **p1 — imminent** | Horde due or overdue; ramp locked |
| **p2 — soon** | Horde inside 15s |
| **p3 — gated** | Timer is up but you have not walked far enough — `HORDE ready in 22m` |
| **p4 — later** | Horde still on the clock; ramp approaching max |

**Coordinated strikes are folded into the horde row rather than listed separately.** They have no timer of their
own — a strike fires *on* a horde tick, so the horde ETA is the strike ETA. Listing them apart would imply two
independent events when there is only one.

The distinction between `HORDE DUE` and `HORDE ready in 22m` is the useful part: a horde needs **both** a timer
and a travel-distance ticket, and the row tells you which one is actually holding it back. If it says
`ready in 22m`, the horde is loaded and fires the moment you walk that far.

**STATE** is the standing picture you glance at rather than react to.


```
┌──────────────────────────────┐
│ HAVOC 35   ch5/res6          │
│ ~ 47                      ●  │  <- confidence dot per row
│ TRICKLES SUPPRESSED       ●  │
│ CLOCK                        │
│ 38s  possible             ●  │
│ TICKET  22m               ●  │
│ POSITION                     │
│ SPREAD 18m   BACK 0m      ●  │
│ FORECAST                     │
│ spread ambush  80%        ●  │
│ sandwich       30%        ●  │
│ RAMP                         │
│ building? - nobody at 2 segs ●│
│ ambush 2/4  blockade 0/3  ●  │
│ WARNINGS                     │
│ COHERENCY - 80%% spread ambush│
└──────────────────────────────┘
```

**The dot is the whole point.** Green = measured, bet on it. Yellow = derived through a known approximation.
Red = modelled and drifting.

| Row | Dot | Why |
|---|---|---|
| Spread / backtrack / ticket | 🟢 | Computed from the main path spline |
| Warnings | 🟢 | Coherency, distances, player counts — all directly readable |
| Challenge rating | 🟡 | Aggro proxy, reads high |
| Horde clock | 🟡→🔴 | **Self-verifying**: predicts a window, scores itself when a horde lands, demotes to red if its hit rate drops below 70% |
| Forecast odds | 🟡→🔴 | Yellow when every condition is measurable, red when it depends on the inferred pacing state |
| Ramp / tension | 🔴 | Estimate feeding an estimate |

### The forecast

Shows which coordinated strikes are currently *allowed to fire* and at what odds, sorted by likelihood. Strikes
whose per-mission budget is provably spent are dropped from the list entirely.

### The ramp row and the healing breakpoint

When the ramp is locked it shows whether anyone can clear it. Per `pacing_manager.lua:551`, a locked ramp clears
on a death **or a knockdown by a player with exactly 2 health segments**.

`num_wounds()` counts segments *remaining* from permanent damage (`health.lua:107-117`), and healing removes
permanent damage — so **healing a player off 2 segments removes their ability to clear the ramp.** That is why
the row tells you who currently holds the key.

---

## Performance

The expensive part was never "counting everything" — the census loop itself is cheap. It was **guarding and
formatting**.

| Was | Now |
|---|---|
| `pcall` around every minion-player distance pair — 1,760 guarded C calls/sec at 110 minions | One `pcall` per sweep: **4/sec** |
| HUD built a `string.format` key every frame just to detect change | Numeric field comparison, zero allocation |
| `mod:localize` called per frame for labels that never change | Memoised — 3,000 lookups now cost 3 calls |
| Warnings recomputed and re-localized every frame | Recomputed at 10Hz, HUD reads a version counter |
| Path queried at 20Hz | 10Hz, and configurable |

Two details worth knowing:

- **`pcall` isn't free in LuaJIT.** Beyond its own cost, a pcall boundary stops the surrounding loop staying
  compiled. Measured on the real loop shape, moving from per-pair to per-sweep guarding was a **2.1x** speedup —
  and that's with a Lua stand-in for the C call, so the real gain is larger.
- **`mod:localize` allocates.** DMF runs every string through `pcall(string.format)`, so calling it per frame for
  a static label generates garbage at 60fps. That was the likely source of the Lua heap growth FpsDoctor
  reported.

### If you still need more

| Setting | Default | Effect |
|---|---|---|
| **Census interval** | 0.25 s | The main dial. 0.5 halves census cost; CR just updates half as often |
| **Path interval** | 0.1 s | Engine spline lookup per player. 0.2 is still far finer than you can react to |
| **Estimate aggro** | on | Turning it **off** removes all distance maths entirely — the cheapest possible mode, at the cost of an inflated CR reading |

---

## Boss spawn points: why there is no map overlay

Asked and answered twice, so worth writing down permanently. **A client cannot know where bosses are**, and this
is not a matter of effort.

Two independent walls:

1. **Not in the source dump.** Monster spawner positions live in compiled `.level` files. `content/` in this
   repo is 1,474 files and every one is `.lua` — there is no geometry to read.
2. **Not reachable at runtime either.** `MonsterPacing` is constructed inside `PacingManager`
   (`pacing_manager.lua:55`), which is created inside the `if is_server` block
   (`gameplay_init_step_managers.lua:112`). On a client the whole object is `nil`, so
   `_monsters` and `_spawn_type_point_sections` do not exist to read.

And even with both, placement is **re-rolled every run** — a random unused section, then a random spawner inside
it. There is no fixed answer to memorise.

### What is actually possible

**Observed-spawn logging.** The mod now detects monsters at the moment they spawn (`breed.tags.monster`) and
knows your exact main-path travel distance. Recording `mission + travel_distance + breed` on every monster spawn,
across many runs, would accumulate a real per-map picture of where spawns *land*.

That is a genuine dataset — but it is **collected by playing, not read from code**, and it gives you a
distribution, not a prediction. Say the word if you want the logger; it is small.

---

## Changelog

**v2.13 - punishments run the server's way, with lines in the world**

- New `HavocTracker_pace.lua`: speed-running, rush and loner prevention ported line for line from
  `specials_pacing.lua`. Speed-running is simulated for all 50 offsets of the server's 5 s clock.
- New world markers (Mod Options -> Punishment lines in the world, independent of the panel): speed gate with a
  countdown, rush line ahead of the lead and behind the last player, blockade line at rank 16+.
- New panel row with the same numbers. `/htpace` command.
- Fixed: spread was the straight-line distance between the two furthest players; the game measures path distance
  to the next player.
- Fixed: "one check is enough if the lead is alone" was wrong. Alone lowers 4 checks to 2 at ranks 1-10 only.
- Fixed: speed-running was muted while specials were off; it runs outside that gate and ignores the allowance.
- Fixed: loner warning fired at loner_time (5 s); the real window starts after a 3-7 s failed cooldown.
- Fixed: the disabler cap used the default table (cap 1 with one player up). Havoc's is 4 at rank 21+.
- Fixed: hogtied teammates counted toward the lead distance; the game leaves them out.
- No percent signs in chat or log output (a `%` can crash the game with DMF's developer console logging on).

**v1.6 — borrowed what works from coherency_zone**

- **Spread now works regardless of the main path.** It is computed from euclidean distance between player
  positions via `POSITION_LOOKUP` — the same source coherency_zone uses to draw decals every half second, which
  is proven to work on clients. Verified in the worst case where *every* travel-distance API throws: spread
  still reads correctly and the 35m tripwire still fires.
  It under-reads around corners, which is the safe direction — late warning rather than false alarm.
- **Added `Unit.is_valid` guards** before touching any unit, which coherency_zone does and I was not.
- **Multi-getter pattern for travel distance**, lifted from coherency_zone's radius lookup: try each candidate
  API, keep the first that returns a plausible number, cache it, and log which one won. Guessing a single API
  twice cost more than this pattern would have.
- **File-based diagnostics.** The mod writes to
  `%APPDATA%/Fatshark/Darktide/HavocTracker_diag.log`, one line per distinct finding per session. No more asking
  anyone to transcribe chat output.


**v1.5 — the path module was dead the whole time**

- **Fixed: spread, backtrack, ticket, pace and the ramp's distance term never worked on a client.**
  `Managers.state.main_path:travel_distance_from_position` delegates to
  `PathTypeLinear._information_from_position`, whose first act is a spawn-point group lookup against
  `main_path_manager:nav_spawn_points()`. That table is only populated by `generate_spawn_points()`, which
  begins `if not self._is_server then return end` — so on a client it is nil and the call throws. My `pcall`
  swallowed the error and returned `nil` forever, which is why every path reading sat at zero.

  Now uses `MainPathQueries.closest_position`, which goes straight to
  `EngineOptimized.closest_pos_at_main_path`. The engine's copy of the path *is* registered on clients
  (`main_path_manager.lua:53`, outside any server guard), and this is the same call the level-side
  `MonsterSpawner` component uses.

  **Blast radius:** the ramp estimate had been running on time alone with no distance term, so it was filling
  far slower than the real meter. Ticket distance never advanced. Pace was never computed.

- **Fixed: horde counting now anchors on the horn** rather than spawn bursts, with an 8s de-duplication guard so
  the burst that follows does not double count. `hordes_seen` drives the ticket threshold, so miscounting it
  made that row meaningless.

**v1.4 — toggle key, real difficulty names, honest counters**

- **Added: toggle-overlay keybind.** Hides the panel without disabling the mod — tracking keeps running, so the
  horde clock and counters are still correct when you bring it back. Bind it under Mod Options.
- **Fixed: difficulty always reading UNKNOWN.** Now uses the game's own mapping
  (`scripts/utilities/danger.lua` + `danger_settings.lua`) instead of bands I invented, so it names
  **Malice / Heresy / Damnation / Auric** correctly and appends the circumstance the way the tab screen does.
  Resistance 6 has no entry in that table *because* it is Havoc-exclusive, which makes a nil lookup positive
  proof of Havoc 31–40.
- **Fixed: strike counters showing a confident `0`.** Detection keys off hordes running five or more waves,
  which only coordinated strikes do — so a zero was indistinguishable from "nothing detected yet". Now shows
  `?` until something is actually observed.
- **Clarified: spread reading 0 in solo was correct, not broken.** With one player there is no second player to
  measure a gap against. The row now says `solo` instead of showing a misleading `0m`.
- `/havoctracker` now reports `lead`, `tail`, player count and whether the main path manager exists.


**v1.3 — hearing the game, and ETAs in seconds**

- **Audio cues.** The mod now listens to the same sounds you do. The server plays stingers through `FxSystem`
  and they arrive on clients as an RPC that resolves the event name via
  `NetworkLookup.sound_events[event_id]` (`fx_system.lua:542`). Hooking it gives:
  **horn → 3s before wave one**, **hound howl → 5s**, **trapper cue → 4s**. All EXACT — the game told us.
  The horn also re-anchors the horde clock, so wave timing no longer depends on counting bodies.
- **Distance gates now quoted in seconds.** `HORDE ready in 22m` becomes `HORDE in 22m / 8s`, converted at your
  smoothed pace. The horde *timer* is a fresh random roll and genuinely unknowable; the *distance gate* is not,
  and that is what a good player is converting in their head when they call an ETA before the horn.
- **Monsters and disablers on the field**, counted exactly from `breed.tags`.

**v1.2 — priority ordering**

- **Panel reordered by imminence.** A `NEXT` queue ranks every foreseeable event by time to impact — already
  tripped, imminent, soon, distance-gated, later — with `STATE` beneath it as the standing picture.
- **Horde ETA now distinguishes its two gates.** `HORDE DUE` means the timer is up and nothing is holding it;
  `HORDE ready in 22m` means the timer is up and only distance is. Verified across six scenarios.
- **Strikes folded into the horde row.** They fire *on* a horde tick and have no independent timer, so showing
  them as a separate section implied two events where there is one.
- Rows 13 → 10.

**v1.1 — smaller box, transparency, confidence-coloured text**

- **Box is 52% of its previous area at the same text size.** Font sizes are unchanged, so readability at your
  scale is preserved; the space came from dead layout rather than shrinking text:
  padding 10→6, section headers 15px→11px, width 300→244, and four merges —
  challenge rating now shares a line with its band, ramp shares a line with the budget, and the forecast shows
  the top two rather than three. 18 rows → 13.
- **Added: Panel opacity** (0–100, default 45). At 0 the fill vanishes entirely and only text plus a faint
  border remain. The border is kept slightly more opaque than the fill so the panel keeps its shape.
- **Confidence now colours the text, not just the dot.** Green rows are measured, yellow derived, red modelled —
  readable at a glance without hunting for the dot.

**v1.0 — readable at low resolution, and the challenge rating collapse**

- **Fixed: the scale slider did nothing.** The v0.7 rewrite read `hud_scale` and never applied it. Scaling now
  rebuilds font sizes, row offsets, the panel rect, all four border edges, the confidence dots *and* the
  scenegraph box, always recomputed from stored base geometry so repeated changes cannot compound.
- **Scale range raised to 6x** and base fonts enlarged. Darktide lays its UI out against a 1080p reference and
  downscales, so at 360p everything renders at roughly a third size. **Try 3–4.**
- **Fixed: challenge rating collapsing to ~0.** Units whose position the engine refused were *excluded* from the
  census. With a persistent fault every sweep condemned more of them until nothing was counted. Simulated at a
  20% failure rate the old behaviour fell 60 → 0 within thirty seconds and never recovered.
  The census now **fails open**: a unit we cannot measure is counted rather than dropped. We cannot prove it is
  far away, and the estimate already errs high by design, so that is the honest direction to be wrong in.
  Condemnation also now needs three strikes and expires every 30s.

**v0.9 — scoping fix**

- **Fixed:** `attempt to call global 'recompute_warnings' (a nil value)`. It was declared as a `local function`
  *below* the function that calls it, so at the call site the local was not yet in scope and Lua fell through to
  a global that never existed. Now forward-declared.
- **Fixed the reason this kept happening.** The test harness stubbed `mod:error` as a no-op, and `guarded()`
  pcalls every subsystem — so runtime errors were caught and silently discarded, and the harness reported PASS.
  It now treats any `mod:error` as a failure, populates four fake players with health/coherency/unit-data
  extensions, runs 30 simulated seconds of movement and spawn bursts, and separately exercises the HUD draw path
  300 times. That combination reproduces this bug class.

**v0.8 — crash fix**

- **Fixed the game crash.** The panel border used `pass_type = "border"`, which **does not exist**. Darktide's
  valid pass types are defined in `scripts/managers/ui/ui_passes.lua` — `rect`, `text`, `texture`, `circle`,
  `triangle`, `rotated_rect` and so on. An invented pass type fails inside `UIRenderer`, which sits outside the
  HUD element's pcall, so it took the game down instead of logging. The border is now four thin `rect` passes,
  which is how the game draws edges itself.
- **Fixed the tripwire errors.** The new tension feed and wound check read per-player extensions whose shape
  differs between the local player and husks. Each player is now scanned inside its own pcall, and
  `state_name` is read with `rawget` and type-checked rather than assumed. One unreadable teammate now degrades
  that teammate's data instead of throwing the whole subsystem.
- **Added:** *Enable prediction layer* toggle. Turning it off keeps every measured readout working.
- **Added to validation:** every `pass_type` in the HUD is now checked against the engine's real list.

**v0.7 — prediction, any rank, boxed UI**

- **Any Havoc rank.** Reads `DifficultyManager` client-side for rank/challenge/resistance; all thresholds,
  timers, tripwires and strike sets scale from generated per-rank tables. Falls back gracefully outside Havoc.
- **Forecast board.** Live list of eligible coordinated strikes and their odds, budget-aware.
- **Budget tracking.** Counts observed strikes against the per-mission allowance.
- **Wound / ramp-unlock readout**, including the healing breakpoint.
- **Tension model** feeding the pacing-state inference (flagged red throughout).
- **Self-verification.** The horde clock scores its own predictions and demotes its confidence below a 70% hit
  rate rather than continuing to assert a window it is missing.
- **Boxed UI** with panel background, border, section headers and per-row confidence dots.
- **Measured:** 1.2 µs per frame, ~2 KB/sec allocation over a simulated 60 seconds of play.

**v0.6 — performance**

- **Census:** one `pcall` per sweep instead of one per minion-player pair (1,760/sec → 4/sec). Engine functions
  hoisted into locals, matching Fatshark's own hot-loop style. Optimistic fast path with a guarded re-sweep only
  if it throws, which then blacklists the offending unit.
- **HUD:** removed per-frame `string.format` change key and per-frame `localize` calls.
- **Warnings:** computed at 10Hz in the model rather than 60Hz in the HUD; version counter for change detection.
- **Added:** Performance settings group — census and path intervals.

**v0.5**

- **Fixed:** the overlay froze with everything at zero after the census threw. One circuit breaker covered all
  four subsystems, so a fault in the *least* reliable estimate took down the three exact readouts with it.
  Breakers are now **per subsystem** — census, horde, path, ramp and tripwires fail independently.
- **Contained:** the `distance_squared` crash is now caught per pair rather than killing the census. See
  *Known issue* above. Root cause still open.
- **Fixed:** tripwire warnings now gate on living player count, mirroring the game's own rules. Solo and bot runs
  previously showed `COHERENCY` permanently — true that you're at coherency 1, but the strike it warns about
  requires more than one living player and cannot fire.
- **Added:** `/havoctracker` reports breaker state and skipped-pair count.

**v0.4**

- **Fixed:** `distance_squared` crash — `bad argument #2 (Vector3 expected, got userdata)`. Player positions were
  cached in a persistent table, but a Stingray `Vector3` is a temporary from a per-frame buffer; holding one past
  the frame means reading recycled memory. Now caches player *units* (stable objects) and re-reads
  `POSITION_LOOKUP` inside the loop, matching how Fatshark's own code uses it.
  This bug shipped in v0.2 but lay dormant because the filter defaulted off; v0.3 turned it on and woke it.
- **Added:** circuit breaker on both update loops. After 5 errors the mod reports once and stops updating instead
  of throwing every frame. Resets on mission load.

**v0.3**

- **Added:** path module — exact spread, backtrack margin, furthest-reached, metres to next horde ticket.
- **Added:** horde clock via spawn-burst detection, with safe/possible/overdue banding.
- **Added:** all five tripwire warnings.
- **Added:** ramp estimator (`LOW/BUILDING/MAX?/LOCKED?`) plus `/havoctracker_ramp_reset`.
- **Fixed:** `warn_backtrack` and `warn_coherency` contained a bare `%`. DMF passes *every* localized string
  through `string.format`, so `80% sandwich` would have thrown the same per-frame error as the v0.2 bug the
  moment either warning fired. Escaped to `%%`.
- **Perf:** burst detector compacts its buffer in place instead of reallocating each frame; `mod.warnings()`
  reuses one table; HUD rebuilds only when a displayed value changes.

**v0.2**

- **Fixed:** `hud_detail` was passed through `string.format` twice — once by me and once inside DMF's
  `localize`, which formats using the varargs you give it. With no varargs supplied it threw
  `bad argument #2 to 'format'` **every frame**, spamming the error feed and tanking framerate.
  Format arguments now go to `localize` directly, which is the correct DMF idiom.
- **Fixed:** the overlay rebuilt and re-localized its strings every frame. It now only does so when a displayed
  value actually changes.
- **Changed:** the flat distance filter is replaced by a per-breed aggro estimate using each breed's own
  `detection_radius`, and it is **on by default**. The old 60 m flat default produced readings of 150–250, which
  is roughly 3–5× the real value.
- **Added:** nil guards on both values handed to `string.format`.
- **Changed:** hooks now use string targets so DMF can delay them until the class exists.

**v0.1** — initial skeleton and challenge rating readout.
