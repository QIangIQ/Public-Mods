return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`HavocTracker` encountered an error loading the Darktide Mod Framework.")

		new_mod("HavocTracker", {
			mod_script       = "Dio's HavocTracker/scripts/mods/HavocTracker/HavocTracker",
			mod_data         = "Dio's HavocTracker/scripts/mods/HavocTracker/HavocTracker_data",
			mod_localization = "Dio's HavocTracker/scripts/mods/HavocTracker/HavocTracker_localization",
		})
	end,
	version = "2.13.1",
	packages = {},
}
