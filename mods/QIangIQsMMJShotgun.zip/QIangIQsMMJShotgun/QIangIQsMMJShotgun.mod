return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsMMJShotgun` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsMMJShotgun", {
            mod_script = "QIangIQsMMJShotgun/scripts/mods/QIangIQsMMJShotgun/QIangIQsMMJShotgun",
            mod_data = "QIangIQsMMJShotgun/scripts/mods/QIangIQsMMJShotgun/QIangIQsMMJShotgun_data",
            mod_localization = "QIangIQsMMJShotgun/scripts/mods/QIangIQsMMJShotgun/QIangIQsMMJShotgun_localization",
        })
    end,
    version = "0.1.0",
    author = "QIangIQ",
    packages = {},
}
