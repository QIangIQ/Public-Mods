-- QIangIQsMMJShotgun per-weapon data (gen.py spec shotgun). Clips are MMJ clip names from shotgun\OBJ-Weapond-Shotgun__17980.
-- Action map sources: Darktide weapon templates (Aussiemon master) via tools\dump_actions.py.
return {
    ranged = true,
    idle = "Shotgun-idle",
    templates = { shotgun_p1_m1 = true, shotgun_p1_m2 = true, shotgun_p1_m3 = true },
    shot = { clips = { "Shotgun-shot", "Shotgun-shotout" }, sounds = { "sfx_wp_shotgun_shot_01.ogg", "sfx_wp_shotgun_shot_02.ogg", "sfx_wp_shotgun_shot_03.ogg", "sfx_wp_shotgun_shot_04.ogg", "sfx_wp_shotgun_shot_05.ogg" } },
    actions = {
        action_wield = { clips = { "Shotgun-fastIntro" }, over_shot = true, sounds = { "sfx_wp_shotgun_intro.ogg" } },
        action_start_reload = { clips = { "Shotgun-reload" }, stretch = true, over_shot = true },
        action_reload_loop = { clips = { "Shotgun-reload" }, stretch = true, sounds = { "shotgun_bullet_reload_01-glued.ogg", "shotgun_bullet_reload_02-glued.ogg", "shotgun_bullet_reload_03-glued.ogg", "shotgun_bullet_reload_04-glued.ogg" } },
        action_weapon_special = { clips = { "Shotgun-reload" }, stretch = true, sounds = { "sfx_wp_shotgun_reload.ogg" } },
    },
}
