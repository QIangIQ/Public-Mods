QIangIQsSpillway
================
Version 1.1 (2026-10-25): fixed a startup crash on some machines caused by percent signs in option names.
Version 1.2 (2026-10-30): level roll watcher for random set-pieces in any mission.
Prophet of Decay (Spillway boss) helper.

Features
- Ring attack: paints the safe ring and counts down to the burn.
- Pillar phase: beams over raised pillars, outline of each pillar's defensive
  hitbox, arrow to the nearest pillar, push countdown.
- Phase 3: hitboxes of the rotating walls drawn with lines (visible even when the
  wall model is not), rise and turn timers, ghost of the next turn.
- Boss projectiles: Nurgle (green) and Warp (red) balls get an oversized marker,
  drop line, ground ring, fading trail, look-ahead, labels and off-screen arrows.
- Boss bar: ticks at the phase health thresholds, numbers on the Prophet bar.
- Spillway mission: SAFE ROUTE / WRONG WAY markers at the branching paths.

Commands: /ringpreview [1-4|stop], /pillarpreview [stop], /saferoute

Credits
- Prophet Safe Zone by AnomalyTea (ring and pillar features)
- NumericUI by raindish and LucLeto (boss bar numbers)
- SafeRoute 1.2.1 (route markers and recorded routes)
- Drawing approach modeled on Blitz Augur (LineObject geometry rebuilt every frame)

Do not run the original Prophet Safe Zone or SafeRoute alongside this mod.
If NumericUI is also enabled its boss numbers draw in the same spot as this mod's.
