-- QIangIQsSpillway: pillar phase (from Prophet Safe Zone by AnomalyTea)
--
-- During the Prophet of Decay's push phase, pillars ("teeth" in the game code)
-- rise out of the floor and players hide behind them from shockwave pushes.
-- This module:
--   * draws a tall light beam over every raised pillar,
--   * makes the beams pulse during the last push of each cycle (after it, all
--     pillars drop and the boss is exhausted),
--   * shows an arrow around the crosshair pointing to the nearest raised pillar,
--     hidden when you're already in cover or close to a pillar,
--   * shows a "PUSH IN x.x" countdown,
--   * outlines each raised pillar's defensive hitbox (the cover wedge behind it).
--
-- Where the information comes from (all client-side, Darktide 1.13.1):
--   * Pillar units: SpillwayBossTooth component (init/destroy). is_raised() is
--     true as soon as the server picks the pillar, ~1.5 s before it rises.
--   * Reshuffles: after each push the server re-sends the raised state of every
--     pillar (SpillwayBossTooth._apply_raised_state). All-false = end of cycle.
--   * Charge-up: effect template "renegade_wizard_hazard_indicator_warp" starts
--     exactly force_push.damage_timing (3.33 s) before the push fires.
--   * Push fired: effect template "renegade_wizard_shockwave" starts.
--   * Arena center: the shockwave plane unit (WizardBossShockwave component).
--   * Cover wedge: WizardShockwaveStageHazard._is_protected_by_tooth. A player is
--     safe if, measured from the pillar along the line arena-center -> pillar,
--     they are 0..length behind it and within a half width that widens from
--     half_width_near to half_width_far (tooth_cover_settings).

local mod = get_mod("QIangIQsSpillway")
local S = mod.psz

local TOOTH_PATH = "scripts/components/spillway_boss_tooth"
local PLANE_PATH = "scripts/components/wizard_boss_shockwave"
local CHARGE_TEMPLATE_PATH = "scripts/settings/fx/effect_templates/renegade_wizard_hazard_indicator_warp"
local PUSH_TEMPLATE_PATH = "scripts/settings/fx/effect_templates/renegade_wizard_shockwave"
local ACTIONS_PATH = "scripts/settings/breed/breed_actions/renegade/renegade_wizard_actions"
local HAZARD_PATH = "scripts/utilities/stage_hazards/wizard_shockwave_stage_hazard"

local TWO_PI = math.pi * 2

-- ---------------------------------------------------------------------------
-- Attack data. Read from the game at load; the values below are fallbacks.
-- ---------------------------------------------------------------------------

local PUSH_DAMAGE_TIMING = 3.3333333333333335 -- charge-up start -> push fires
local PUSHES_PER_CYCLE = 6
local RESHUFFLE_AFTER_PUSH = 1.5 -- server reshuffles this long after a push fires
local NEXT_WINDUP_AFTER_PUSH = 1.3 -- next push's windup starts this long after a push fires
local WINDUPS = { -- per push in the cycle, per difficulty
	{ 3, 3, 3, 2, 2 },
	{ 3, 3, 3, 2, 2 },
	{ 5, 5, 4.5, 2.5, 2.5 },
	{ 5, 5, 4.5, 2.5, 2.5 },
	{ 4, 4, 4, 2.5, 2.5 },
	{ 4, 4, 4, 2.5, 2.5 },
}
local COVER = {
	half_width_near = 0.625,
	half_width_far = 6.25,
	length = 25,
}

do
	local ok, actions = pcall(require, ACTIONS_PATH)
	local force_push = ok and actions and actions.force_push

	if force_push then
		PUSH_DAMAGE_TIMING = force_push.damage_timing or PUSH_DAMAGE_TIMING

		local params = force_push.wave_parameters

		if params and #params > 0 then
			PUSHES_PER_CYCLE = #params
			WINDUPS = {}

			for i = 1, #params do
				WINDUPS[i] = params[i].windup_time or { 3 }
			end

			local travel = params[1].travel_time or 0.5

			RESHUFFLE_AFTER_PUSH = travel + 1
			NEXT_WINDUP_AFTER_PUSH = travel + 0.8
		end
	end
end

-- The cover settings live in a server module; read them lazily so we don't
-- force that module to load early.
local cover_loaded = false

local function _cover_settings()
	if not cover_loaded then
		cover_loaded = true

		local ok, hazard = pcall(require, HAZARD_PATH)
		local settings = ok and hazard and hazard.tooth_cover_settings

		if settings and settings.length then
			COVER = settings
		end
	end

	return COVER
end

local function _difficulty_entry(tbl)
	if type(tbl) ~= "table" then
		return tbl
	end

	local difficulty = Managers.state and Managers.state.difficulty

	if difficulty then
		local ok, value = pcall(difficulty.get_table_entry_by_challenge, difficulty, tbl)

		if ok and value then
			return value
		end
	end

	return tbl[#tbl]
end

-- ---------------------------------------------------------------------------
-- State
-- ---------------------------------------------------------------------------

-- [unit] = { unit, component, position (Vector3Box, pillar base) }
local teeth = {}

-- Arena center (Vector3Box), from the shockwave plane unit.
local center_box = nil

-- Push cycle tracking. "known" means we saw the cycle start, so the push count
-- can be trusted (false after joining or reloading mid-fight, until the next
-- cycle starts).
local cycle = {
	known = false,
	fired = 0,
	last_fire_t = nil,
	last_reshuffle_t = nil,
}

-- Countdown to the next push: estimated at the reshuffle, then locked to the
-- boss's charge-up.
local countdown = {
	push_t = nil,
}

-- Raised-state messages arriving close together form one reshuffle.
local batch = nil -- { t, count, any_raised }
local BATCH_WINDOW = 0.25

-- /pillarpreview state (nil when not previewing).
local preview = nil
local pending_preview = false

-- ---------------------------------------------------------------------------
-- Pillar list (real or preview)
-- ---------------------------------------------------------------------------

local function _tooth_raised(entry)
	local component = entry.component

	if not component or not component.is_raised then
		return false
	end

	if entry.unit and not Unit.alive(entry.unit) then
		return false
	end

	local ok, raised = pcall(component.is_raised, component)

	return ok and raised or false
end

-- Calls fn(x, y, base_z) for every raised pillar.
local function _for_each_raised(fn)
	if preview then
		for i = 1, #preview.slots do
			if preview.raised[i] then
				local p = preview.slots[i]:unbox()

				fn(p.x, p.y, p.z)
			end
		end

		return
	end

	for _, entry in pairs(teeth) do
		if _tooth_raised(entry) then
			local p = entry.position:unbox()

			fn(p.x, p.y, p.z)
		end
	end
end

local function _arena_center()
	if preview then
		return preview.center:unbox()
	end

	return center_box and center_box:unbox() or nil
end

-- ---------------------------------------------------------------------------
-- Cycle / countdown events
-- ---------------------------------------------------------------------------

local function _start_new_cycle(reason)
	cycle.known = true
	cycle.fired = 0
	cycle.last_fire_t = nil
	cycle.last_reshuffle_t = nil

	S.debug("pillars: new cycle (%s)", reason)
end

local function _windup_for_next_push()
	local index = cycle.known and math.clamp(cycle.fired + 1, 1, PUSHES_PER_CYCLE) or 1

	return _difficulty_entry(WINDUPS[index]) or 2
end

local function _on_reshuffle(t)
	cycle.last_reshuffle_t = t

	-- Estimate when the next push fires. Mid-cycle, the next windup started a
	-- little before the reshuffle; at a cycle start they begin together.
	local offset = 0

	if cycle.last_fire_t and t - cycle.last_fire_t < RESHUFFLE_AFTER_PUSH + 1 then
		offset = NEXT_WINDUP_AFTER_PUSH - RESHUFFLE_AFTER_PUSH
	end

	countdown.push_t = t + offset + _windup_for_next_push() + PUSH_DAMAGE_TIMING

	S.debug("pillars: reshuffle (push %d of cycle next%s), push in ~%.1f s", cycle.fired + 1, cycle.known and "" or ", count unknown", countdown.push_t - t)
end

local function _on_all_lowered(t)
	countdown.push_t = nil

	_start_new_cycle("all pillars lowered")
end

local function _on_charge(t)
	countdown.push_t = t + PUSH_DAMAGE_TIMING

	S.debug("pillars: boss charging, push in %.2f s", PUSH_DAMAGE_TIMING)
end

local function _on_push_fired(t)
	cycle.fired = cycle.fired + 1
	cycle.last_fire_t = t
	countdown.push_t = nil

	S.debug("pillars: push %d fired%s", cycle.fired, cycle.known and "" or " (count unknown)")
end

local function _is_final_push()
	if not cycle.known then
		return false
	end

	if cycle.fired >= PUSHES_PER_CYCLE then
		return true
	end

	-- After push N-1 fires, the reshuffle that follows sets up the final push.
	return cycle.fired == PUSHES_PER_CYCLE - 1 and cycle.last_reshuffle_t ~= nil and cycle.last_fire_t ~= nil and cycle.last_reshuffle_t > cycle.last_fire_t
end

local function _process_batch(t)
	if not batch or t < batch.t + BATCH_WINDOW then
		return
	end

	local b = batch

	batch = nil

	if b.any_raised then
		_on_reshuffle(b.t)
	elseif b.count >= 2 then
		_on_all_lowered(b.t)
	end
end

-- ---------------------------------------------------------------------------
-- Hooks
-- ---------------------------------------------------------------------------

-- Fresh pillars spawn one at a time, 0.5 s apart. If several register almost
-- at once, we joined a match in progress, so the push count for this cycle
-- can't be trusted.
local BULK_SPAWN_WINDOW = 0.2
local first_register_t = nil

local function _register_tooth(component, unit, allow_new_cycle)
	if teeth[unit] or not component._init_position then
		return
	end

	local t = S.gameplay_time() or 0

	if next(teeth) == nil then
		first_register_t = t

		if allow_new_cycle then
			_start_new_cycle("pillars spawned")

			countdown.push_t = nil
		end
	elseif cycle.known and first_register_t and t - first_register_t < BULK_SPAWN_WINDOW then
		cycle.known = false

		S.debug("pillars: joined mid-fight, push count unknown until the next cycle")
	end

	teeth[unit] = {
		unit = unit,
		component = component,
		position = Vector3Box(component._init_position:unbox()),
	}
end

local function _on_tooth_init(self, unit)
	if preview or not unit then
		return
	end

	_register_tooth(self, unit, true)
end

local function _on_tooth_destroy(self, unit)
	local tooth_unit = unit or self._unit

	if tooth_unit then
		teeth[tooth_unit] = nil
	end
end

local function _on_tooth_raised_state(self, raised)
	if preview then
		return
	end

	-- Pick up pillars we never saw spawn (mod reloaded mid-fight).
	if self._unit and not teeth[self._unit] then
		_register_tooth(self, self._unit, false)
	end

	local t = S.gameplay_time()

	if not t then
		return
	end

	if not batch then
		batch = {
			t = t,
			count = 0,
			any_raised = false,
		}
	end

	batch.count = batch.count + 1

	if raised then
		batch.any_raised = true
	end
end

local function _on_plane_init(self, unit)
	if not unit then
		return
	end

	local position = POSITION_LOOKUP and POSITION_LOOKUP[unit] or Unit.world_position(unit, 1)

	center_box = Vector3Box(position)
end

local function _hook_once(target, flag, fn)
	if target and not target[flag] then
		target[flag] = true

		fn(target)
	end
end

local function _hook_tooth_class(class)
	_hook_once(class, "__qiangiqs_spillway_hooked", function (c)
		mod:hook_safe(c, "init", _on_tooth_init)
		mod:hook_safe(c, "destroy", _on_tooth_destroy)
		mod:hook_safe(c, "_apply_raised_state", _on_tooth_raised_state)
	end)
end

local function _hook_plane_class(class)
	_hook_once(class, "__qiangiqs_spillway_hooked", function (c)
		mod:hook_safe(c, "init", _on_plane_init)
	end)
end

mod:hook_require(TOOTH_PATH, _hook_tooth_class)
mod:hook_require(PLANE_PATH, _hook_plane_class)

mod:hook_require(CHARGE_TEMPLATE_PATH, function (template)
	_hook_once(template, "__qiangiqs_spillway_hooked", function (tp)
		mod:hook_safe(tp, "start", function ()
			if preview or next(teeth) == nil then
				return
			end

			local t = S.gameplay_time()

			if t then
				_on_charge(t)
			end
		end)
	end)
end)

mod:hook_require(PUSH_TEMPLATE_PATH, function (template)
	_hook_once(template, "__qiangiqs_spillway_hooked", function (tp)
		mod:hook_safe(tp, "start", function ()
			if preview then
				return
			end

			local t = S.gameplay_time()

			if t then
				_on_push_fired(t)
			end
		end)
	end)
end)

-- ---------------------------------------------------------------------------
-- Drawing: light beams
-- ---------------------------------------------------------------------------

local BEAM_SIDES = 6
local BEAM_SEGMENTS = 10
local BEAM_OUTER_ALPHA = 110
local BEAM_CORE_ALPHA = 220
local BEAM_CORE_RATIO = 0.35 -- core radius relative to the beam radius
local BEAM_SINK = 0.3 -- start this far below the pillar's spawn point (its base)

local SIDE_COS, SIDE_SIN = {}, {}

for i = 1, BEAM_SIDES + 1 do
	local angle = TWO_PI * (i - 1) / BEAM_SIDES

	SIDE_COS[i], SIDE_SIN[i] = math.cos(angle), math.sin(angle)
end

local function _beam_rgb()
	return mod:get("beam_color_r") or 40, mod:get("beam_color_g") or 120, mod:get("beam_color_b") or 255
end

local function _draw_prism(gui, x, y, z0, radius, height, alpha, r, g, b)
	for seg = 1, BEAM_SEGMENTS do
		local h0 = z0 + height * (seg - 1) / BEAM_SEGMENTS
		local h1 = z0 + height * seg / BEAM_SEGMENTS
		-- Fade out toward the top.
		local fade = (1 - (seg - 0.5) / BEAM_SEGMENTS) ^ 1.3
		local color = Color(alpha * fade, r, g, b)

		for i = 1, BEAM_SIDES do
			local ax, ay = x + radius * SIDE_COS[i], y + radius * SIDE_SIN[i]
			local bx, by = x + radius * SIDE_COS[i + 1], y + radius * SIDE_SIN[i + 1]
			local a0, b0 = Vector3(ax, ay, h0), Vector3(bx, by, h0)
			local a1, b1 = Vector3(ax, ay, h1), Vector3(bx, by, h1)

			Gui.triangle(gui, a0, b0, b1, 1, color)
			Gui.triangle(gui, a0, b1, a1, 1, color)
		end
	end
end

local function _draw_beams(render, t, final_push)
	local gui = render.world_gui
	local r, g, b = _beam_rgb()
	local radius = (mod:get("beam_width_cm") or 100) / 200
	local height = mod:get("beam_height_m") or 35
	local alpha_mul = 1

	if final_push and mod:get("beam_pulse_final") then
		local wave = 0.5 + 0.5 * math.cos((t * TWO_PI) * 1.6)

		alpha_mul = 0.3 + 0.7 * wave
		radius = radius * (1 + 0.2 * wave)
	end

	-- Brighter, slightly whitened core.
	local cr, cg, cb = r + (255 - r) * 0.6, g + (255 - g) * 0.6, b + (255 - b) * 0.6

	_for_each_raised(function (x, y, z)
		local z0 = z - BEAM_SINK

		_draw_prism(gui, x, y, z0, radius, height, BEAM_OUTER_ALPHA * alpha_mul, r, g, b)
		_draw_prism(gui, x, y, z0, radius * BEAM_CORE_RATIO, height, BEAM_CORE_ALPHA * alpha_mul, cr, cg, cb)
	end)
end

-- ---------------------------------------------------------------------------
-- Nearest-pillar arrow
-- ---------------------------------------------------------------------------

local function _local_player_unit()
	local player = Managers.player and Managers.player:local_player(1)
	local unit = player and player.player_unit

	if unit and Unit.alive(unit) then
		return unit, player
	end

	return nil
end

-- Flat camera forward/right as (fx, fy, rx, ry), or nil.
local function _camera_axes(player, player_unit)
	local rotation
	local camera_manager = Managers.state and Managers.state.camera

	if camera_manager and player and player.viewport_name then
		local ok, rot = pcall(camera_manager.camera_rotation, camera_manager, player.viewport_name)

		if ok then
			rotation = rot
		end
	end

	if not rotation then
		rotation = Unit.world_rotation(player_unit, 1)
	end

	local forward = Quaternion.forward(rotation)
	local fx, fy = forward.x, forward.y
	local length = math.sqrt(fx * fx + fy * fy)

	if length < 0.001 then
		return nil
	end

	fx, fy = fx / length, fy / length

	-- Right is forward rotated 90 degrees clockwise (seen from above).
	return fx, fy, fy, -fx
end

-- Same test the server uses to decide whether a push hits you.
local function _is_in_cover(px, py, cx, cy)
	local cover = _cover_settings()
	local covered = false

	_for_each_raised(function (tx, ty)
		if covered then
			return
		end

		local dx, dy = tx - cx, ty - cy
		local length = math.sqrt(dx * dx + dy * dy)

		if length < 0.001 then
			return
		end

		local ux, uy = dx / length, dy / length
		local rx, ry = px - tx, py - ty
		local along = rx * ux + ry * uy

		if along >= 0 and along <= cover.length then
			local lateral = math.abs(rx * -uy + ry * ux)
			local half_width = cover.half_width_near + (cover.half_width_far - cover.half_width_near) * along / cover.length

			if lateral <= half_width then
				covered = true
			end
		end
	end)

	return covered
end

local function _draw_thick_line(gui, x1, y1, x2, y2, thickness, color, layer)
	local dx, dy = x2 - x1, y2 - y1
	local length = math.sqrt(dx * dx + dy * dy)
	local steps = math.max(1, math.ceil(length / math.max(thickness * 0.4, 1)))
	local half = thickness / 2
	local size = Vector2(thickness, thickness)

	for i = 0, steps do
		local f = i / steps

		Gui.rect(gui, Vector3(x1 + dx * f - half, y1 + dy * f - half, layer), size, color)
	end
end

-- Returns arrow info { dir_x, dir_y, distance } (screen direction, y down), or
-- nil when the arrow should be hidden.
local function _arrow_target(player, player_unit)
	local position = Unit.world_position(player_unit, 1)
	local px, py = position.x, position.y
	local best_d2, best_x, best_y = math.huge, nil, nil

	_for_each_raised(function (x, y)
		local dx, dy = x - px, y - py
		local d2 = dx * dx + dy * dy

		if d2 < best_d2 then
			best_d2, best_x, best_y = d2, x, y
		end
	end)

	if not best_x then
		return nil
	end

	local distance = math.sqrt(best_d2)

	if distance <= (mod:get("arrow_hide_distance") or 4) then
		return nil
	end

	local center = _arena_center()

	if center and _is_in_cover(px, py, center.x, center.y) then
		return nil
	end

	local fx, fy, rx, ry = _camera_axes(player, player_unit)

	if not fx then
		return nil
	end

	local tx, ty = (best_x - px) / distance, (best_y - py) / distance
	local sx = tx * rx + ty * ry -- + is right of screen
	local sy = tx * fx + ty * fy -- + is ahead
	local length = math.sqrt(sx * sx + sy * sy)

	if length < 0.001 then
		return nil
	end

	return sx / length, -sy / length, distance
end

local function _draw_arrow(render, player, player_unit)
	local dir_x, dir_y, distance = _arrow_target(player, player_unit)

	if not dir_x then
		return
	end

	local gui = render.screen_gui
	local width, height = Gui.resolution()
	local scale = height / 1080
	local cx, cy = width / 2, height / 2
	local radius = (mod:get("arrow_radius") or 120) * scale
	local size = 22 * scale
	local thickness = math.max(3, 5 * scale)
	local layer = S.text_layer
	local r, g, b = _beam_rgb()
	local color = Color(235, r + (255 - r) * 0.3, g + (255 - g) * 0.3, b + (255 - b) * 0.3)
	local shadow = Color(150, 0, 0, 0)

	-- Chevron: tip on the circle, two legs swept back.
	local tip_x, tip_y = cx + dir_x * (radius + size * 0.5), cy + dir_y * (radius + size * 0.5)
	local back_x, back_y = tip_x - dir_x * size, tip_y - dir_y * size
	local perp_x, perp_y = -dir_y, dir_x
	local l1x, l1y = back_x + perp_x * size * 0.75, back_y + perp_y * size * 0.75
	local l2x, l2y = back_x - perp_x * size * 0.75, back_y - perp_y * size * 0.75

	_draw_thick_line(gui, tip_x, tip_y, l1x, l1y, thickness + 3 * scale, shadow, layer)
	_draw_thick_line(gui, tip_x, tip_y, l2x, l2y, thickness + 3 * scale, shadow, layer)
	_draw_thick_line(gui, tip_x, tip_y, l1x, l1y, thickness, color, layer + 1)
	_draw_thick_line(gui, tip_x, tip_y, l2x, l2y, thickness, color, layer + 1)

	-- Distance label just inside the chevron.
	local text = string.format("%d m", math.floor(distance + 0.5))
	local font_size = 18 * scale
	local min, max = Gui.slug_text_extents(gui, text, S.font, font_size)
	local label_x = cx + dir_x * (radius - 22 * scale) - (max.x - min.x) / 2
	local label_y = cy + dir_y * (radius - 22 * scale)

	Gui.slug_text(gui, text, S.font, font_size, Vector3(label_x, label_y, layer + 1), nil, color, "shadow", Color(200, 0, 0, 0))
end

-- ---------------------------------------------------------------------------
-- Defensive hitbox (cover wedge behind each raised pillar)
-- Drawn with floor-following lines. The floor under the wedge is sampled once
-- per pillar/center pair, because the arena floor is a shallow funnel.
-- ---------------------------------------------------------------------------

local COVER_ALONG_STEPS = 10
local COVER_ACROSS_STEPS = 4 -- per side of the center line
local cover_cache = {} -- [pillar key] = { cx, cy, heights, ... }

local function _cover_geometry(x, y, z, cx, cy)
	local cover = _cover_settings()
	local dx, dy = x - cx, y - cy
	local length = math.sqrt(dx * dx + dy * dy)

	if length < 0.001 then
		return nil
	end

	local ux, uy = dx / length, dy / length

	return cover, ux, uy, -uy, ux
end

-- Floor height at every vertex of the wedge grid, as heights[(i)*(2*A+1)+j+1].
local function _sample_cover(x, y, z, cx, cy)
	local cover, ux, uy, nx, ny = _cover_geometry(x, y, z, cx, cy)

	if not cover then
		return nil
	end

	local key = string.format("%.2f:%.2f:%.2f:%.2f", x, y, cx, cy)
	local cached = cover_cache[key]

	if cached then
		return cached, cover, ux, uy, nx, ny
	end

	local heights = {}
	local across = COVER_ACROSS_STEPS

	for i = 0, COVER_ALONG_STEPS do
		local along = cover.length * i / COVER_ALONG_STEPS
		local half = cover.half_width_near + (cover.half_width_far - cover.half_width_near) * along / cover.length

		for j = -across, across do
			local lateral = half * j / across
			local px, py = x + ux * along + nx * lateral, y + uy * along + ny * lateral
			local h = S.raycast_floor_z(S.physics_world(), px, py, z + 3, 8)

			heights[i * (2 * across + 1) + (j + across) + 1] = h or z
		end
	end

	cover_cache[key] = heights

	return heights, cover, ux, uy, nx, ny
end

local function _draw_cover_hitboxes(lines, cx, cy)
	local lift = Vector3(0, 0, (mod:get("cover_lift_cm") or 12) / 100)
	local r, g, b = _beam_rgb()
	local edge_color = Color(255, r, g, b)
	local grid_color = Color(110, r, g, b)
	local across = COVER_ACROSS_STEPS
	local per_row = 2 * across + 1

	_for_each_raised(function (x, y, z)
		local heights, cover, ux, uy, nx, ny = _sample_cover(x, y, z, cx, cy)

		if not heights then
			return
		end

		local function vertex(i, j)
			local along = cover.length * i / COVER_ALONG_STEPS
			local half = cover.half_width_near + (cover.half_width_far - cover.half_width_near) * along / cover.length
			local lateral = half * j / across

			return Vector3(x + ux * along + nx * lateral, y + uy * along + ny * lateral, heights[i * per_row + (j + across) + 1]) + lift
		end

		-- Outline: both long sides plus the near and far ends.
		for i = 0, COVER_ALONG_STEPS - 1 do
			LineObject.add_line(lines, edge_color, vertex(i, -across), vertex(i + 1, -across))
			LineObject.add_line(lines, edge_color, vertex(i, across), vertex(i + 1, across))
		end

		LineObject.add_line(lines, edge_color, vertex(0, -across), vertex(0, across))
		LineObject.add_line(lines, edge_color, vertex(COVER_ALONG_STEPS, -across), vertex(COVER_ALONG_STEPS, across))

		-- Faint cross lines every few steps so the size reads from a distance.
		for i = 2, COVER_ALONG_STEPS - 1, 2 do
			LineObject.add_line(lines, grid_color, vertex(i, -across), vertex(i, across))
		end

		LineObject.add_line(lines, grid_color, vertex(0, 0), vertex(COVER_ALONG_STEPS, 0))
	end)
end

-- ---------------------------------------------------------------------------
-- Push countdown
-- ---------------------------------------------------------------------------

local PUSH_TEXT_COLOR = { 255, 160, 205, 255 }
local COUNTDOWN_TIMEOUT = 1.5 -- give up if the push never shows up

local function _draw_push_countdown(t)
	local remaining = countdown.push_t - t
	local c = PUSH_TEXT_COLOR

	if remaining > 0 then
		S.draw_countdown_text(string.format("PUSH IN %.1f", remaining), Color(c[1], c[2], c[3], c[4]))
	else
		S.draw_countdown_text("PUSH", Color(c[1], c[2], c[3], c[4]))
	end
end

-- ---------------------------------------------------------------------------
-- /pillarpreview: fake pillars around you, running three pushes of a cycle
-- (the last one is the final push, so the beams pulse).
-- ---------------------------------------------------------------------------

local PREVIEW_SLOTS = 8
local PREVIEW_RADIUS = 12
local PREVIEW_RAISED = 3
local PREVIEW_PUSHES = 3

local function _preview_reshuffle(t)
	local order = {}

	for i = 1, PREVIEW_SLOTS do
		order[i] = i
	end

	for i = PREVIEW_SLOTS, 2, -1 do
		local j = math.random(1, i)

		order[i], order[j] = order[j], order[i]
	end

	table.clear(preview.raised)

	for i = 1, PREVIEW_RAISED do
		preview.raised[order[i]] = true
	end

	_on_reshuffle(t)
end

local function _start_preview(t)
	pending_preview = false

	if next(teeth) ~= nil then
		mod:echo("Boss pillars are active; preview disabled.")

		return
	end

	local player_unit, player = _local_player_unit()

	if not player_unit then
		mod:echo("Preview only works in a mission or the Psykhanium.")

		return
	end

	local position = Unit.world_position(player_unit, 1)
	local fx, fy = _camera_axes(player, player_unit)

	fx, fy = fx or 1, fy or 0

	-- Put the arena center ahead of you, so you stand on the pillar ring.
	local cx, cy, z = position.x + fx * PREVIEW_RADIUS, position.y + fy * PREVIEW_RADIUS, position.z
	local slots = {}

	for i = 1, PREVIEW_SLOTS do
		local angle = TWO_PI * (i - 0.5) / PREVIEW_SLOTS

		slots[i] = Vector3Box(Vector3(cx + PREVIEW_RADIUS * math.cos(angle), cy + PREVIEW_RADIUS * math.sin(angle), z))
	end

	preview = {
		center = Vector3Box(Vector3(cx, cy, z)),
		slots = slots,
		raised = {},
		state = "wait_push",
		charged = false,
		pushes = 0,
	}

	-- Pretend we're near the end of a cycle so the last preview push is final.
	cycle.known = true
	cycle.fired = PUSHES_PER_CYCLE - PREVIEW_PUSHES
	cycle.last_fire_t = nil
	cycle.last_reshuffle_t = nil

	_preview_reshuffle(t)
	mod:echo(string.format("Pillar preview: %d pushes, the last one is the final push. Arena center is %d m ahead of you.", PREVIEW_PUSHES, PREVIEW_RADIUS))
end

local function _stop_preview(silent)
	if not preview then
		return
	end

	preview = nil
	countdown.push_t = nil
	cycle.known = false
	cycle.fired = 0
	cycle.last_fire_t = nil
	cycle.last_reshuffle_t = nil

	if not silent then
		mod:echo("Pillar preview finished.")
	end
end

local function _update_preview(t)
	local p = preview

	if p.state == "wait_push" then
		if not p.charged and countdown.push_t and t >= countdown.push_t - PUSH_DAMAGE_TIMING then
			p.charged = true

			_on_charge(countdown.push_t - PUSH_DAMAGE_TIMING)
		end

		if countdown.push_t and t >= countdown.push_t then
			_on_push_fired(t)

			p.pushes = p.pushes + 1
			p.state = "wait_reshuffle"
			p.next_t = t + RESHUFFLE_AFTER_PUSH
		end
	elseif p.state == "wait_reshuffle" then
		if t >= p.next_t then
			if p.pushes < PREVIEW_PUSHES then
				p.charged = false
				p.state = "wait_push"

				_preview_reshuffle(t)
			else
				table.clear(p.raised)
				_on_all_lowered(t)

				p.state = "ending"
				p.next_t = t + 1
			end
		end
	elseif p.state == "ending" and t >= p.next_t then
		_stop_preview()
	end
end

-- ---------------------------------------------------------------------------
-- Frame update
-- ---------------------------------------------------------------------------

local function _any_raised()
	local any = false

	_for_each_raised(function ()
		any = true
	end)

	return any
end

local function update(t, ring_countdown_shown)
	if pending_preview then
		_start_preview(t)
	end

	if preview then
		_update_preview(t)
	end

	_process_batch(t)

	-- Drop a countdown whose push never arrived (e.g. the phase ended).
	if countdown.push_t and t > countdown.push_t + COUNTDOWN_TIMEOUT then
		countdown.push_t = nil
	end

	local has_pillars = _any_raised()
	local wants_countdown = countdown.push_t ~= nil and mod:get("show_push_countdown") and not ring_countdown_shown

	if not has_pillars and not wants_countdown then
		return
	end

	local render = S.ensure_render()

	if not render then
		return
	end

	if has_pillars and mod:get("show_beams") then
		_draw_beams(render, t, _is_final_push())
	end

	if has_pillars and mod:get("show_cover_hitbox") then
		local lines = S.lines()
		local center = _arena_center()

		if lines and center then
			_draw_cover_hitboxes(lines, center.x, center.y)
		end
	end

	if has_pillars and mod:get("show_pillar_arrow") then
		local player_unit, player = _local_player_unit()

		if player_unit then
			_draw_arrow(render, player, player_unit)
		end
	end

	if wants_countdown then
		_draw_push_countdown(t)
	end
end

local function reset()
	table.clear(teeth)
	table.clear(cover_cache)

	first_register_t = nil
	center_box = nil
	batch = nil
	preview = nil
	pending_preview = false
	countdown.push_t = nil
	cycle.known = false
	cycle.fired = 0
	cycle.last_fire_t = nil
	cycle.last_reshuffle_t = nil
end

S.pillar_state = function ()
	return cycle, countdown, PUSHES_PER_CYCLE
end

S.modules[#S.modules + 1] = {
	name = "Pillars",
	update = function (t, dt, ring_countdown_shown)
		update(t, ring_countdown_shown)
	end,
	reset = reset,
	on_disabled = function ()
		_stop_preview(true)
	end,
}

mod:command("pillarpreview", mod:localize("pillarpreview_desc"), function (arg)
	if arg == "stop" then
		pending_preview = false
		_stop_preview(true)
		mod:echo("Pillar preview stopped.")

		return
	end

	-- Started on the next frame update (engine vectors aren't valid here).
	pending_preview = true
end)
