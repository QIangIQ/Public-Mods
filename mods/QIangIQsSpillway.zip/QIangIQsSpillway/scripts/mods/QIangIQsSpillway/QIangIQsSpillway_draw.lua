-- QIangIQsSpillway: shared drawing helpers.
-- Geometry goes into a LineObject that the main file resets and dispatches
-- every frame (the approach Blitz Augur uses); text goes through the screen gui.

local mod = get_mod("QIangIQsSpillway")
local S = mod.psz

local TWO_PI = math.pi * 2

local D = {}

S.draw = D

-- Box outline (12 edges) plus optional grid lines on the two big faces.
-- `center`, `forward`, `right`, `up` are Vector3; half = { x = along right,
-- y = along forward, z = along up } in meters.
function D.box(lines, center, right, forward, up, half, edge_color, grid_color, grid_step)
	local function corner(sx, sy, sz)
		return center + right * (half.x * sx) + forward * (half.y * sy) + up * (half.z * sz)
	end

	local c = {}

	for xi = 1, 2 do
		for yi = 1, 2 do
			for zi = 1, 2 do
				c[xi * 4 + yi * 2 + zi] = corner(xi == 1 and -1 or 1, yi == 1 and -1 or 1, zi == 1 and -1 or 1)
			end
		end
	end

	local function k(xi, yi, zi)
		return c[xi * 4 + yi * 2 + zi]
	end

	for a = 1, 2 do
		for b = 1, 2 do
			LineObject.add_line(lines, edge_color, k(a, b, 1), k(a, b, 2)) -- vertical
			LineObject.add_line(lines, edge_color, k(1, a, b), k(2, a, b)) -- across
			LineObject.add_line(lines, edge_color, k(a, 1, b), k(a, 2, b)) -- along
		end
	end

	if grid_color and grid_step and grid_step > 0 then
		local steps = math.max(1, math.floor(half.y * 2 / grid_step))

		for side = -1, 1, 2 do
			for i = 1, steps - 1 do
				local f = -1 + 2 * i / steps
				local bottom = center + right * (half.x * side) + forward * (half.y * f) - up * half.z
				local top = bottom + up * (half.z * 2)

				LineObject.add_line(lines, grid_color, bottom, top)
			end

			-- horizontal mid line and a diagonal pair per face
			local a = center + right * (half.x * side) - forward * half.y
			local b = center + right * (half.x * side) + forward * half.y

			LineObject.add_line(lines, grid_color, a, b)
		end

		-- floor and ceiling center lines
		LineObject.add_line(lines, grid_color, center - forward * half.y - up * half.z, center + forward * half.y - up * half.z)
		LineObject.add_line(lines, grid_color, center - forward * half.y + up * half.z, center + forward * half.y + up * half.z)
	end
end

-- Horizontal circle at z.
function D.ring(lines, color, cx, cy, z, radius, segments, dashed)
	segments = segments or 48

	for i = 1, segments do
		if not dashed or i % 2 == 1 then
			local a1, a2 = TWO_PI * (i - 1) / segments, TWO_PI * i / segments

			LineObject.add_line(lines, color, Vector3(cx + math.cos(a1) * radius, cy + math.sin(a1) * radius, z), Vector3(cx + math.cos(a2) * radius, cy + math.sin(a2) * radius, z))
		end
	end
end

-- Horizontal arc from angle a1 to a2 (radians, math convention).
function D.arc(lines, color, cx, cy, z, radius, a1, a2, segments)
	segments = segments or 16

	for i = 1, segments do
		local t1 = a1 + (a2 - a1) * (i - 1) / segments
		local t2 = a1 + (a2 - a1) * i / segments

		LineObject.add_line(lines, color, Vector3(cx + math.cos(t1) * radius, cy + math.sin(t1) * radius, z), Vector3(cx + math.cos(t2) * radius, cy + math.sin(t2) * radius, z))
	end
end

-- Projects a world position to the screen. Returns x, y (pixels, top-left
-- origin) and whether the point is in front of the camera.
function D.project(camera, position)
	if not camera then
		return nil
	end

	local camera_position = Camera.world_position(camera)
	local camera_forward = Quaternion.forward(Camera.world_rotation(camera))
	local in_front = Vector3.dot(position - camera_position, camera_forward) > 0.5
	local screen = Camera.world_to_screen(camera, position)

	return screen.x, screen.y, in_front
end

-- Text centered on a screen point.
function D.text_at(render, text, x, y, size, color)
	local gui = render.screen_gui
	local min, max = Gui.slug_text_extents(gui, text, S.font, size)

	Gui.slug_text(gui, text, S.font, size, Vector3(x - (max.x - min.x) / 2, y, S.text_layer), nil, color, "shadow", Color(200, 0, 0, 0))
end

-- Label floating above a world position; skipped when behind the camera.
function D.world_label(render, camera, position, text, size, color)
	local x, y, in_front = D.project(camera, position)

	if x and in_front then
		local _, height = Gui.resolution()

		D.text_at(render, text, x, y, size * height / 1080, color)

		return true
	end

	return false
end

local function _thick_line(gui, x1, y1, x2, y2, thickness, color, layer)
	local dx, dy = x2 - x1, y2 - y1
	local length = math.sqrt(dx * dx + dy * dy)
	local steps = math.max(1, math.ceil(length / math.max(thickness * 0.4, 1)))
	local half = thickness / 2
	local size = Vector2(thickness, thickness)

	for i = 0, steps do
		local f = i / steps

		Gui.rect(gui, Vector3(x1 + dx * f - half, y1 + dy * f - half, layer), size, color)
	end
end

-- Chevron on a screen-edge ellipse pointing to an off-screen world position,
-- with a text line next to it. Returns true when drawn.
function D.edge_indicator(render, camera, position, color, text)
	if not camera then
		return false
	end

	local camera_position = Camera.world_position(camera)
	local rotation = Camera.world_rotation(camera)
	local delta = position - camera_position
	local dx = Vector3.dot(delta, Quaternion.right(rotation))
	local dy = Vector3.dot(delta, Quaternion.up(rotation))
	local length = math.sqrt(dx * dx + dy * dy)

	if length < 0.001 then
		return false
	end

	local gui = render.screen_gui
	local width, height = Gui.resolution()
	local scale = height / 1080
	local ux, uy = dx / length, -dy / length -- screen y grows downward
	local rx, ry = width * 0.36, height * 0.36
	local cx, cy = width / 2 + ux * rx, height / 2 + uy * ry
	local size = 20 * scale
	local thickness = math.max(3, 5 * scale)
	local back_x, back_y = cx - ux * size, cy - uy * size
	local px, py = -uy, ux
	local layer = S.text_layer
	local shadow = Color(150, 0, 0, 0)

	_thick_line(gui, cx, cy, back_x + px * size * 0.75, back_y + py * size * 0.75, thickness + 3 * scale, shadow, layer)
	_thick_line(gui, cx, cy, back_x - px * size * 0.75, back_y - py * size * 0.75, thickness + 3 * scale, shadow, layer)
	_thick_line(gui, cx, cy, back_x + px * size * 0.75, back_y + py * size * 0.75, thickness, color, layer + 1)
	_thick_line(gui, cx, cy, back_x - px * size * 0.75, back_y - py * size * 0.75, thickness, color, layer + 1)

	if text then
		D.text_at(render, text, cx - ux * size * 2.2, cy - uy * size * 2.2 - 8 * scale, 16 * scale, color)
	end

	return true
end

-- True when a world position is inside the visible screen rectangle.
function D.on_screen(camera, position)
	local x, y, in_front = D.project(camera, position)

	if not x or not in_front then
		return false
	end

	local width, height = Gui.resolution()

	return x > 0 and x < width and y > 0 and y < height
end
