-- QIangIQsSpillway: Prophet boss-bar additions
--
--  * Ticks at the health values where the fight changes phase.
--  * Health and toughness numbers on the bar (from NumericUI's BossHealth.lua
--    by raindish & LucLeto), shown for the Prophet only unless "all bosses" is on.
--
-- Phase thresholds come from scripts/managers/pacing/bosses/spillway_wizard.lua
-- (PHASE_ORDER, phases.*.phase_settings, BossPhaseUtilities.check_for_next_phase_conditions_met:
-- a health-gated phase ends once current_health_percent < next_phase_health_percentage):
--   dance_01      use_health, next = exhausted_01   0.57
--   exhausted_01  time only (7 s), then intermission_01 (0.56 listed, not health-gated)
--   intermission_01 use_health, next = spawn_teeth  0.55 (forced after 45 s)
--   spawn_teeth   pillars are raised, then force_push
--   force_push    use_health, next = exhausted_02   0.34
--   exhausted_02  time only (7 s), then intermission_02
--   intermission_02 use_health, next = dance_02     0.33 (forced after 45 s)
--   dance_02      walls; enrage_threshold 0.125 (health < 12.5 %), ends at 0
-- Boss damage is also soft-capped at each gate (update_overdamage_protection),
-- so the bar visibly stalls on these lines.

local mod = get_mod("QIangIQsSpillway")
local S = mod.psz

local UIWidget = require("scripts/managers/ui/ui_widget")
local UIHudSettings = require("scripts/settings/ui/ui_hud_settings")
local HudElementBossHealthSettings = require("scripts/ui/hud/elements/boss_health/hud_element_boss_health_settings")

local DEFINITIONS_PATH = "scripts/ui/hud/elements/boss_health/hud_element_boss_health_definitions"
local BOSS_BREED = "renegade_wizard"
local SMALL_BAR_SPACING = 30 -- hud_element_boss_health_definitions.lua small_bar_spacing

local PHASES = {
	{
		pct = 0.57,
		label = "57",
		color = { 255, 90, 220, 255 },
	},
	{
		pct = 0.55,
		label = "55",
		color = { 255, 90, 160, 255 },
	},
	{
		pct = 0.34,
		label = "34",
		color = { 255, 150, 120, 255 },
	},
	{
		pct = 0.33,
		label = "33",
		color = { 255, 255, 90, 90 },
	},
	{
		pct = 0.125,
		label = "12",
		color = { 255, 255, 160, 40 },
	},
}

local NUM_TICKS = #PHASES
local TICK_WIDTH = 3
local TICK_HEIGHT = 20

local TEXT_SIZE = 20
local TEXT_WIDTH = 100
local PADDING = 10

local function _text_style(extra)
	local style = {
		horizontal_alignment = "right",
		vertical_alignment = "center",
		text_horizontal_alignment = "left",
		text_vertical_alignment = "center",
		size = { TEXT_WIDTH, TEXT_SIZE },
		font_size = TEXT_SIZE,
		font_type = "machine_medium",
		offset = { TEXT_WIDTH + PADDING, 0, 100 },
	}

	for key, value in pairs(extra or {}) do
		style[key] = value
	end

	return style
end

local function _number_widgets(left)
	local side = left and {
		horizontal_alignment = "left",
		text_horizontal_alignment = "right",
	} or {}
	local health_offset = { left and -(TEXT_WIDTH + PADDING) or TEXT_WIDTH + PADDING, -13, 100 }
	local toughness_offset = { left and -(TEXT_WIDTH + PADDING) or TEXT_WIDTH + PADDING, -2, 100 }
	local health_style = _text_style(side)
	local toughness_style = _text_style(side)

	health_style.text_color = { 255, 255, 0, 0 }
	health_style.offset = health_offset
	toughness_style.text_color = UIHudSettings.color_tint_secondary_1
	toughness_style.offset = toughness_offset

	return UIWidget.create_definition({
		{
			value_id = "text",
			style_id = "text",
			pass_type = "text",
			value = "",
			style = health_style,
		},
	}, "health_bar"), UIWidget.create_definition({
		{
			value_id = "text",
			style_id = "text",
			pass_type = "text",
			value = "",
			style = toughness_style,
		},
	}, "toughness_bar")
end

local function _tick_widget()
	local passes = {}

	for i = 1, NUM_TICKS do
		passes[#passes + 1] = {
			pass_type = "rect",
			style_id = "tick_" .. i,
			style = {
				horizontal_alignment = "left",
				vertical_alignment = "center",
				size = { TICK_WIDTH, TICK_HEIGHT },
				offset = { 0, -13, 30 },
				color = { 0, 255, 255, 255 },
			},
		}
		passes[#passes + 1] = {
			pass_type = "text",
			style_id = "label_" .. i,
			value_id = "label_" .. i,
			value = "",
			style = {
				horizontal_alignment = "left",
				vertical_alignment = "center",
				text_horizontal_alignment = "center",
				text_vertical_alignment = "top",
				font_type = "machine_medium",
				font_size = 14,
				size = { 40, 16 },
				-- every other label sits a little lower so neighbours do not collide
				offset = { 0, -13 + 14 + (i % 2 == 0 and 12 or 0), 31 },
				text_color = { 0, 255, 255, 255 },
			},
		}
	end

	return UIWidget.create_definition(passes, "health_bar")
end

mod:hook_require(DEFINITIONS_PATH, function (instance)
	if instance.__qiangiqs_spillway_added then
		return
	end

	instance.__qiangiqs_spillway_added = true

	for _, key in ipairs({
		"single_target_widget_definitions",
		"left_double_target_widget_definitions",
		"right_double_target_widget_definitions",
	}) do
		local group = instance[key]
		local health_text, toughness_text = _number_widgets(key == "left_double_target_widget_definitions")

		group.qiq_phase_ticks = _tick_widget()
		group.qiq_health_text = health_text
		group.qiq_toughness_text = toughness_text
	end
end)

local function _set_text(widget, value)
	local content = widget.content

	if content._qiq_value ~= value then
		content._qiq_value = value
		content.text = value and tostring(value) or ""
		widget.dirty = true
	end
end

local function _current_toughness(toughness_extension)
	if toughness_extension.max_toughness then
		return toughness_extension:max_toughness() - toughness_extension:toughness_damage()
	end

	local game_session, game_object_id = toughness_extension._game_session, toughness_extension._game_object_id
	local damage = GameSession.game_object_field(game_session, game_object_id, "toughness_damage")
	local max = GameSession.game_object_field(game_session, game_object_id, "toughness")

	return max - damage
end

local function _update_ticks(widget, show, bar_width, base_x, health_fraction)
	local style = widget.style
	local content = widget.content

	for i = 1, NUM_TICKS do
		local phase = PHASES[i]
		local tick = style["tick_" .. i]
		local label = style["label_" .. i]
		local c = phase.color
		-- Ticks already passed are dimmed.
		local alpha = show and (health_fraction < phase.pct and 90 or 255) or 0
		local x = base_x + math.floor(bar_width * phase.pct)

		tick.color[1], tick.color[2], tick.color[3], tick.color[4] = alpha, c[2], c[3], c[4]
		tick.offset[1] = x - math.floor(TICK_WIDTH / 2)
		label.text_color[1], label.text_color[2], label.text_color[3], label.text_color[4] = show and mod:get("show_tick_labels") and alpha or 0, c[2], c[3], c[4]
		label.offset[1] = x - 20
		content["label_" .. i] = phase.label
	end

	widget.dirty = true
end

mod:hook_safe("HudElementBossHealth", "update", function (self)
	local widget_groups = self._widget_groups
	local active_targets_array = self._active_targets_array
	local num_active_targets = math.min(#widget_groups - 1, #active_targets_array)
	local numbers_on = mod:get("show_boss_numbers")
	local all_bosses = mod:get("boss_numbers_all")
	local ticks_on = mod:get("show_phase_ticks")

	for i = 1, num_active_targets do
		local widget_group_index = num_active_targets > 1 and i + 1 or i
		local widget_group = widget_groups[widget_group_index]
		local target = active_targets_array[i]
		local unit = target.unit
		local is_prophet = target.breed and target.breed.name == BOSS_BREED
		local health_widget = widget_group.qiq_health_text
		local toughness_widget = widget_group.qiq_toughness_text
		local ticks_widget = widget_group.qiq_phase_ticks

		if ticks_widget then
			local bar_size = widget_group_index == 1 and HudElementBossHealthSettings.size or HudElementBossHealthSettings.size_small
			local base_x = widget_group_index == 3 and (HudElementBossHealthSettings.size_small[1] + SMALL_BAR_SPACING) or 0
			local fraction = 1

			if ALIVE[unit] and target.health_extension then
				fraction = target.health_extension:current_health_percent()
			end

			_update_ticks(ticks_widget, ticks_on and is_prophet and ALIVE[unit], bar_size[1], base_x, fraction)

			if is_prophet and ALIVE[unit] and target.health_extension then
				local ok, max_health = pcall(target.health_extension.max_health, target.health_extension)

				S.boss_state = {
					fraction = fraction,
					max_health = ok and max_health or nil,
					t = S.gameplay_time(),
				}
			end
		end

		if health_widget and toughness_widget then
			if numbers_on and (is_prophet or all_bosses) and ALIVE[unit] then
				_set_text(health_widget, math.round(target.health_extension:current_health()))

				local toughness_extension = target.toughness_extension

				if toughness_extension then
					_set_text(toughness_widget, math.round(_current_toughness(toughness_extension)))
				else
					_set_text(toughness_widget, nil)
				end
			else
				_set_text(health_widget, nil)
				_set_text(toughness_widget, nil)
			end
		end
	end
end)
