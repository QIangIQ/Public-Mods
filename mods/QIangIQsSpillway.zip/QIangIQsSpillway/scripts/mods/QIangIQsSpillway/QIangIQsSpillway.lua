-- QIangIQsSpillway
-- Visual aids for the Prophet of Decay boss fight and the Spillway mission.
-- Built on Prophet Safe Zone by AnomalyTea (ring + pillar features), with the
-- boss-bar numbers of NumericUI (raindish & LucLeto) and the route markers of
-- SafeRoute folded in. Unit/template names come from the game source
-- (Aussiemon/Darktide-Source-Code master).
--
-- This file: the ring ("dance") attack, plus the rendering and countdown
-- helpers shared with the pillar feature (QIangIQsSpillway_pillars.lua,
-- _walls, _balls, _bossbar, _saferoute, loaded at the bottom).
--
-- Ring attack: the game's client-side effect for this attack
-- (renegade_psyker_boss_circle_dance) reads networked fields on the boss
-- every frame: "safe_zone" (which ring, 1-4) and "center_position". We hook
-- that effect and read the same fields, so the safe ring is painted the
-- instant the client knows it. "should_play_damage_vfx" tells us when the
-- burning ends.

local mod = get_mod("QIangIQsSpillway")

local EFFECT_TEMPLATE_PATH = "scripts/settings/fx/effect_templates/renegade_psyker_boss_circle_dance"
local ACTIONS_PATH = "scripts/settings/breed/breed_actions/renegade/renegade_wizard_actions"

-- ---------------------------------------------------------------------------
-- Attack data. Read from the game at load so balance patches are picked up
-- automatically; the values below are fallbacks.
-- ---------------------------------------------------------------------------

local RINGS = {
	{ inner = 2.5, outer = 8 },
	{ inner = 8, outer = 13.5 },
	{ inner = 13.5, outer = 19 },
	{ inner = 19, outer = 24.5 },
}
local DAMAGE_START_T = 0.5 + 4.333333333333333 -- seconds after safe ring is picked
local WAVE_END_T = 0.5 + 7.5 -- seconds after safe ring is picked
local WAVE_END_GRACE = 1.0 -- safety margin if the "damage over" flag never arrives

local function _load_attack_data()
	local ok, actions = pcall(require, ACTIONS_PATH)
	local dance = ok and actions and actions.dance

	if not dance then
		mod:warning("Could not read ring attack settings; using built-in defaults.")

		return
	end

	local circle_settings = dance.circle_settings

	if circle_settings and #circle_settings > 0 then
		RINGS = {}

		for i = 1, #circle_settings do
			RINGS[i] = {
				inner = circle_settings[i].inner_radius,
				outer = circle_settings[i].outer_radius,
			}
		end
	end

	local event = dance.anim_event and dance.anim_event[1]
	local delay = dance.delay or 0.5
	local damage_timing = event and dance.anim_damage_timings and dance.anim_damage_timings[event]
	local anim_duration = event and dance.anim_duration and dance.anim_duration[event]

	if damage_timing then
		DAMAGE_START_T = delay + damage_timing
	end

	if anim_duration then
		WAVE_END_T = delay + anim_duration
	end
end

_load_attack_data()

-- ---------------------------------------------------------------------------
-- State
-- ---------------------------------------------------------------------------

-- The wave being displayed (nil when nothing to show):
-- { zone, center (Vector3Box), radii, heights, start_t,
--   phase ("telegraph" | "damaging"), damage_seen, simulated (preview) }
local wave = nil

-- Ring number requested by /ringpreview, started on the next frame update.
local pending_preview_zone = nil

-- Tracking of the boss effect (one boss at a time).
local tracker = nil -- { template_data, game_object_id, last_zone }

-- Last safe_zone value seen per boss, kept across effect restarts so a stale
-- value left over from the previous phase is not mistaken for a new wave.
local last_seen_zone_by_go_id = {}

-- Rendering resources (created lazily in the level world).
local render = {
	world = nil,
	world_gui = nil,
	screen_gui = nil,
	line_object = nil,
	fx_lines = nil,
	triangles_failed = false,
}

local function _debug(fmt, ...)
	if mod:get("debug_log") then
		mod:echo("[Spillway] " .. string.format(fmt, ...))
	end
end

local function _gameplay_time()
	local time_manager = Managers.time

	if time_manager and time_manager:has_timer("gameplay") then
		return time_manager:time("gameplay")
	end

	return nil
end

local function _level_world()
	local world_manager = Managers.world

	if world_manager and world_manager:has_world("level_world") then
		return world_manager:world("level_world")
	end

	return nil
end

local function _destroy_render_resources()
	local world = render.world

	if world then
		pcall(function ()
			if render.world_gui then
				World.destroy_gui(world, render.world_gui)
			end

			if render.screen_gui then
				World.destroy_gui(world, render.screen_gui)
			end

		end)
	end

	-- Line objects are owned by their World and may already be invalid when
	-- the world changes (Blitz Augur drops the references for the same
	-- reason), so they are abandoned rather than destroyed.
	render.world = nil
	render.world_gui = nil
	render.screen_gui = nil
	render.line_object = nil
	render.fx_lines = nil
end

local function _ensure_render_resources()
	local world = _level_world()

	if not world then
		return false
	end

	if render.world ~= world then
		_destroy_render_resources()

		render.world = world
	end

	if not render.world_gui then
		render.world_gui = World.create_world_gui(world, Matrix4x4.identity(), 1, 1, "immediate")
	end

	if not render.screen_gui then
		render.screen_gui = World.create_screen_gui(world, "immediate")
	end

	if not render.fx_lines then
		local ok, line_object = pcall(World.create_line_object, world)

		render.fx_lines = ok and line_object or nil
	end

	return true
end

-- ---------------------------------------------------------------------------
-- Floor sampling
-- The arena floor is a shallow funnel, so a flat ring would sink into it.
-- When a wave starts we probe the floor height across the whole safe ring and
-- bend the paint to match. Probes hit the collision mesh, which can differ
-- slightly from the visible floor (small details may poke through).
-- ---------------------------------------------------------------------------

local RING_SEGMENTS = 96 -- around the circle
local EDGE_WIDTH = 0.18 -- meters, bright rim inside each edge of the safe ring
local RADIAL_STEP = 0.75 -- meters between floor samples across the band
local RAY_ABOVE = 3 -- start probes this far above the center floor
local RAY_LENGTH = 7 -- and probe this far down
local TWO_PI = math.pi * 2

-- Returns the floor height below (x, y), or nil if nothing was hit.
local function _raycast_floor_z(physics_world, x, y, from_z, length)
	local ok, hit, hit_position = pcall(PhysicsWorld.raycast, physics_world, Vector3(x, y, from_z), Vector3.down(), length, "closest", "collision_filter", "filter_player_mover")

	if ok and hit and hit_position then
		return hit_position.z
	end

	return nil
end

local function _physics_world()
	local world = _level_world()

	return world and World.physics_world(world)
end

-- Floor height directly under the ring center.
local function _find_center_floor_z(center)
	local physics_world = _physics_world()
	local z = physics_world and _raycast_floor_z(physics_world, center.x, center.y, center.z + 1.5, 6)

	return z or center.z
end

-- Radii at which we sample across the band: both rim edges, then evenly spaced.
local function _band_radii(ring)
	local radii = { ring.inner, ring.inner + EDGE_WIDTH }
	local fill_start, fill_end = ring.inner + EDGE_WIDTH, ring.outer - EDGE_WIDTH
	local steps = math.max(1, math.ceil((fill_end - fill_start) / RADIAL_STEP))

	for i = 1, steps do
		radii[#radii + 1] = fill_start + (fill_end - fill_start) * i / steps
	end

	radii[#radii + 1] = ring.outer

	return radii
end

-- Samples the floor at every vertex of the ring mesh. Heights are stored as
-- plain numbers: heights[(segment - 1) * #radii + radius_index].
local function _sample_ring_heights(ring, cx, cy, base_z)
	local radii = _band_radii(ring)
	local num_radii = #radii
	local heights = {}
	local misses = 0
	local min_z, max_z = math.huge, -math.huge
	local physics_world = _physics_world()

	for s = 1, RING_SEGMENTS do
		local angle = TWO_PI * (s - 1) / RING_SEGMENTS
		local c, sn = math.cos(angle), math.sin(angle)

		for j = 1, num_radii do
			local r = radii[j]
			local z = physics_world and _raycast_floor_z(physics_world, cx + r * c, cy + r * sn, base_z + RAY_ABOVE, RAY_LENGTH)

			if z then
				min_z = math.min(min_z, z)
				max_z = math.max(max_z, z)
			else
				misses = misses + 1
				-- Fall back to the neighbor we just sampled, or the center floor.
				z = j > 1 and heights[(s - 1) * num_radii + j - 1] or base_z
			end

			heights[(s - 1) * num_radii + j] = z
		end
	end

	return radii, heights, misses, min_z, max_z
end

-- ---------------------------------------------------------------------------
-- Wave logic
-- ---------------------------------------------------------------------------

local function _begin_wave(zone, center, t, simulated, optional_floor_z)
	local ring = RINGS[zone]

	if not ring then
		return
	end

	local floor_z = optional_floor_z or _find_center_floor_z(center)
	local radii, heights, misses, min_z, max_z = _sample_ring_heights(ring, center.x, center.y, floor_z)

	if not simulated and mod.psz then
		mod.psz.ring_last_zone = zone
		mod.psz.ring_last_t = t
	end

	wave = {
		zone = zone,
		center = Vector3Box(center),
		radii = radii,
		heights = heights,
		start_t = t,
		phase = "telegraph",
		damage_seen = false,
		simulated = simulated or false,
	}

	_debug("wave start: safe ring %d (%.1f-%.1f m)%s", zone, ring.inner, ring.outer, simulated and " [preview]" or "")

	local total = RING_SEGMENTS * #radii

	if misses < total then
		_debug("floor: center z=%.2f, ring z %.2f to %.2f, %d/%d probes missed", floor_z, min_z, max_z, misses, total)
	else
		_debug("floor: center z=%.2f, all %d probes missed (drawing flat)", floor_z, total)
	end
end

local function _end_wave(reason)
	if wave then
		_debug("wave end (%s)", reason)
	end

	wave = nil
end

-- damage_flag: the server's "should_play_damage_vfx" (nil for previews).
local function _update_wave_phase(t, damage_flag)
	if not wave then
		return
	end

	local elapsed = t - wave.start_t

	if damage_flag then
		wave.damage_seen = true
	end

	if wave.phase == "telegraph" and (damage_flag or elapsed >= DAMAGE_START_T) then
		wave.phase = "damaging"

		_debug("burning started at %.2f s", t - wave.start_t)
	end

	if wave.phase == "damaging" then
		local server_says_done = wave.damage_seen and damage_flag == false
		local timed_out = elapsed >= WAVE_END_T + (wave.simulated and 0 or WAVE_END_GRACE)

		if server_says_done then
			_end_wave(string.format("server, %.2f s", elapsed))
		elseif timed_out then
			_end_wave(string.format("timeout, %.2f s", elapsed))
		end
	end
end

-- ---------------------------------------------------------------------------
-- Hooks on the boss's ring effect
-- ---------------------------------------------------------------------------

local function _read_field(game_session, game_object_id, field)
	local ok, value = pcall(GameSession.game_object_field, game_session, game_object_id, field)

	if ok then
		return value
	end

	return nil
end

local function _on_effect_start(template_data, template_context)
	local game_object_id = template_data.game_object_id

	if not game_object_id then
		return
	end

	-- A real attack replaces any running preview.
	if wave and wave.simulated then
		_end_wave("real attack started")
	end

	tracker = {
		template_data = template_data,
		game_object_id = game_object_id,
		last_zone = last_seen_zone_by_go_id[game_object_id],
	}

	_debug("ring effect started (last seen ring: %s)", tostring(tracker.last_zone))
end

local function _on_effect_update(template_data, template_context, dt, t)
	if not tracker or tracker.template_data ~= template_data then
		return
	end

	local game_session = template_context.game_session
	local game_object_id = tracker.game_object_id

	if not game_session then
		return
	end

	local zone = _read_field(game_session, game_object_id, "safe_zone")
	local damage_flag = _read_field(game_session, game_object_id, "should_play_damage_vfx")

	-- Finish the current wave first, so a new safe ring arriving in the same
	-- frame starts cleanly.
	if wave and not wave.simulated then
		_update_wave_phase(t, damage_flag)
	end

	if zone and zone ~= tracker.last_zone then
		tracker.last_zone = zone
		last_seen_zone_by_go_id[game_object_id] = zone

		if zone > 0 and RINGS[zone] then
			local center = _read_field(game_session, game_object_id, "center_position")

			if center then
				_begin_wave(zone, center, t, false)
			end
		end
	end
end

local function _on_effect_stop(template_data, template_context)
	if tracker and tracker.template_data == template_data then
		_debug("ring effect stopped")

		tracker = nil

		if wave and not wave.simulated then
			_end_wave("effect stopped")
		end
	end
end

mod:hook_require(EFFECT_TEMPLATE_PATH, function (template)
	if not template or template.__qiangiqs_spillway_hooked then
		return
	end

	template.__qiangiqs_spillway_hooked = true

	mod:hook_safe(template, "start", _on_effect_start)
	mod:hook_safe(template, "update", _on_effect_update)
	mod:hook_safe(template, "stop", _on_effect_stop)
end)

-- ---------------------------------------------------------------------------
-- Drawing: safe ring paint
-- ---------------------------------------------------------------------------

local function _user_rgb()
	return mod:get("color_r") or 0, mod:get("color_g") or 255, mod:get("color_b") or 255
end

-- Unit-circle lookup for each ring segment (index 1 = angle 0).
local SEG_COS, SEG_SIN = {}, {}

for s = 1, RING_SEGMENTS do
	local angle = TWO_PI * (s - 1) / RING_SEGMENTS

	SEG_COS[s], SEG_SIN[s] = math.cos(angle), math.sin(angle)
end

-- Draws the ring as a mesh whose vertices sit on the sampled floor heights.
-- The first and last radial bands are the bright rims; the rest is fill.
local function _draw_ring_triangles(cx, cy, radii, heights, lift, fill_color, edge_color)
	local gui = render.world_gui
	local num_radii = #radii
	local last_band = num_radii - 1

	for s = 1, RING_SEGMENTS do
		local s2 = s % RING_SEGMENTS + 1
		local c1, sn1 = SEG_COS[s], SEG_SIN[s]
		local c2, sn2 = SEG_COS[s2], SEG_SIN[s2]
		local base1 = (s - 1) * num_radii
		local base2 = (s2 - 1) * num_radii

		for j = 1, last_band do
			local r1, r2 = radii[j], radii[j + 1]
			local color = (j == 1 or j == last_band) and edge_color or fill_color
			local a = Vector3(cx + r1 * c1, cy + r1 * sn1, heights[base1 + j] + lift)
			local b = Vector3(cx + r2 * c1, cy + r2 * sn1, heights[base1 + j + 1] + lift)
			local d = Vector3(cx + r2 * c2, cy + r2 * sn2, heights[base2 + j + 1] + lift)
			local e = Vector3(cx + r1 * c2, cy + r1 * sn2, heights[base2 + j] + lift)

			Gui.triangle(gui, a, b, d, 1, color)
			Gui.triangle(gui, a, d, e, 1, color)
		end
	end
end

-- Fallback if the engine refuses world-space triangles: one circle per sampled
-- radius, also following the floor.
local function _draw_ring_lines(cx, cy, radii, heights, lift, color)
	local world = render.world

	if not render.line_object then
		render.line_object = World.create_line_object(world)
	end

	local line_object = render.line_object
	local num_radii = #radii

	LineObject.reset(line_object)

	for j = 1, num_radii do
		local r = radii[j]

		for s = 1, RING_SEGMENTS do
			local s2 = s % RING_SEGMENTS + 1
			local from = Vector3(cx + r * SEG_COS[s], cy + r * SEG_SIN[s], heights[(s - 1) * num_radii + j] + lift)
			local to = Vector3(cx + r * SEG_COS[s2], cy + r * SEG_SIN[s2], heights[(s2 - 1) * num_radii + j] + lift)

			LineObject.add_segmented_line(line_object, color, from, to, 0, 1)
		end
	end

	LineObject.dispatch(world, line_object)
end

local function _clear_lines()
	if render.line_object and render.world then
		pcall(function ()
			LineObject.reset(render.line_object)
			LineObject.dispatch(render.world, render.line_object)
		end)
	end
end

local function _draw_ring(t)
	local center = wave.center:unbox()
	local cx, cy = center.x, center.y
	local lift = (mod:get("height_offset_cm") or 8) / 100
	local r, g, b = _user_rgb()
	local base = math.clamp((mod:get("fill_opacity") or 35) / 100, 0.05, 1) * 255
	local fill_alpha, edge_alpha

	if wave.phase == "telegraph" then
		-- Gentle pulse while it's only a warning. Starts at full brightness so
		-- the ring is obvious the instant it appears.
		local pulse = 0.75 + 0.25 * math.cos((t - wave.start_t) * TWO_PI * 1.5)

		fill_alpha = base * pulse
		edge_alpha = math.min(255, base * 2.2) * pulse
	else
		-- Solid and brighter while the danger rings are burning.
		fill_alpha = math.min(255, base * 1.6)
		edge_alpha = 255
	end

	if not render.triangles_failed then
		local ok, err = pcall(_draw_ring_triangles, cx, cy, wave.radii, wave.heights, lift, Color(fill_alpha, r, g, b), Color(edge_alpha, r, g, b))

		if ok then
			return
		end

		render.triangles_failed = true

		mod:warning("Filled ring drawing failed, switching to line fallback: %s", tostring(err))
	end

	local ok, err = pcall(_draw_ring_lines, cx, cy, wave.radii, wave.heights, lift, Color(math.max(edge_alpha, 160), r, g, b))

	if not ok then
		mod:error("Ring drawing failed: %s", tostring(err))

		_end_wave("draw error")
	end
end

-- ---------------------------------------------------------------------------
-- Drawing: countdown
-- ---------------------------------------------------------------------------

local FONT = "content/ui/fonts/proxima_nova_bold"
local TEXT_LAYER = 900

-- Draws one line of countdown text (and an optional shrinking bar under it)
-- in the shared countdown position. Used by both the ring and pillar features.
local function _draw_countdown_text(text, text_color, bar_fraction)
	local gui = render.screen_gui
	local width, height = Gui.resolution()
	local scale = height / 1080
	local font_size = (mod:get("countdown_size") or 30) * scale
	local from_top = (mod:get("countdown_position") or 30) / 100
	local min, max = Gui.slug_text_extents(gui, text, FONT, font_size)
	local text_width = max.x - min.x
	local x = (width - text_width) / 2
	-- Screen GUI origin is top-left.
	local y = height * from_top

	Gui.slug_text(gui, text, FONT, font_size, Vector3(x, y, TEXT_LAYER), nil, text_color, "shadow", Color(200, 0, 0, 0))

	if bar_fraction then
		local bar_width = 220 * scale
		local bar_height = 6 * scale
		local bar_x = (width - bar_width) / 2
		-- Placed so it can't overlap the text whether the engine anchors text
		-- at its top edge or its baseline.
		local bar_y = y + font_size * 1.05

		Gui.rect(gui, Vector3(bar_x, bar_y, TEXT_LAYER), Vector2(bar_width, bar_height), Color(140, 0, 0, 0))
		Gui.rect(gui, Vector3(bar_x, bar_y, TEXT_LAYER + 1), Vector2(bar_width * bar_fraction, bar_height), text_color)
	end
end

local function _draw_countdown(t)
	if wave.phase == "telegraph" then
		local remaining = math.max(wave.start_t + DAMAGE_START_T - t, 0)

		_draw_countdown_text(string.format("BURN IN %.1f", remaining), Color(255, 255, 220, 120))
	else
		local total = math.max(WAVE_END_T - DAMAGE_START_T, 0.1)
		local remaining = math.max(wave.start_t + WAVE_END_T - t, 0)

		_draw_countdown_text("BURNING", Color(255, 255, 90, 60), math.clamp(remaining / total, 0, 1))
	end
end

-- ---------------------------------------------------------------------------
-- Frame update
-- ---------------------------------------------------------------------------

local countdown_failed = false

-- Starts a /ringpreview request. Runs inside mod.update because engine
-- vectors aren't valid inside chat command callbacks.
local function _start_pending_preview(t)
	local zone = pending_preview_zone

	pending_preview_zone = nil

	if tracker then
		return
	end

	local player = Managers.player and Managers.player:local_player(1)
	local player_unit = player and player.player_unit

	if not player_unit or not Unit.alive(player_unit) then
		mod:echo("Preview only works in a mission or the Psykhanium.")

		return
	end

	-- Center the rings so you stand in the middle of the chosen safe band.
	local position = Unit.world_position(player_unit, 1)
	local px, py, pz = position.x, position.y, position.z
	local ring = RINGS[zone]
	local mid_radius = (ring.inner + ring.outer) / 2

	_begin_wave(zone, Vector3(px + mid_radius, py, pz), t, true, pz)
	mod:echo(string.format("Previewing safe ring %d (%.1f-%.1f m from center). Burning starts in %.1f s.", zone, ring.inner, ring.outer, DAMAGE_START_T))
end

-- Ring feature for one frame. Returns true if it drew the countdown.
local function _update_ring(t)
	if not wave then
		if render.triangles_failed then
			_clear_lines()
		end

		return false
	end

	if wave.simulated then
		_update_wave_phase(t, nil)

		if not wave then
			_clear_lines()

			return false
		end
	end

	if not _ensure_render_resources() then
		return false
	end

	if mod:get("show_ring") then
		_draw_ring(t)
	end

	if wave and mod:get("show_countdown") and not countdown_failed then
		local ok, err = pcall(_draw_countdown, t)

		if not ok then
			countdown_failed = true

			mod:error("Countdown drawing failed: %s", tostring(err))
		end

		return ok
	end

	return false
end

-- Feature modules (pillars, walls, balls, boss bar, route markers) register
-- themselves in mod.psz.modules. Each may define:
--   update(t, dt, ring_countdown_shown)  every frame during gameplay
--   update_always(dt)                    every frame, even without a gameplay timer
--   reset(), on_setting_changed(), on_disabled()
local modules = {}
local module_failed = {}

local function _call_modules(fn_name, ...)
	for i = 1, #modules do
		local m = modules[i]
		local fn = m[fn_name]

		if fn and not module_failed[m] then
			local ok, err = pcall(fn, ...)

			if not ok then
				module_failed[m] = true

				mod:error("%s stopped after an error in %s: %s", m.name or "A feature", fn_name, tostring(err))
			end
		end
	end
end

local function _clear_fx_lines()
	if render.fx_lines and render.world then
		pcall(function ()
			LineObject.reset(render.fx_lines)
			LineObject.dispatch(render.world, render.fx_lines)
		end)
	end
end

mod.update = function (dt)
	_call_modules("update_always", dt)

	local t = _gameplay_time()

	if pending_preview_zone then
		if t then
			_start_pending_preview(t)
		else
			pending_preview_zone = nil
		end
	end

	if not t then
		return
	end

	local ring_countdown_shown = _update_ring(t)
	local has_world = _ensure_render_resources()

	-- LineObject geometry persists after dispatch, so it is rebuilt from
	-- scratch every frame (same approach as Blitz Augur).
	if has_world and render.fx_lines then
		LineObject.reset(render.fx_lines)
	end

	_call_modules("update", t, dt, ring_countdown_shown)

	if has_world and render.fx_lines then
		LineObject.dispatch(render.world, render.fx_lines)
	end
end

mod.on_setting_changed = function ()
	_call_modules("on_setting_changed")
end

-- ---------------------------------------------------------------------------
-- Lifecycle
-- ---------------------------------------------------------------------------

local function _reset_all()
	wave = nil
	tracker = nil
	pending_preview_zone = nil
	table.clear(last_seen_zone_by_go_id)
	_call_modules("reset")
	_destroy_render_resources()
end

mod.on_game_state_changed = function (status, state_name)
	if state_name == "StateGameplay" then
		_reset_all()
	end
end

mod.on_disabled = function ()
	wave = nil
	_clear_lines()
	_clear_fx_lines()
	_call_modules("on_disabled")
end

mod.on_unload = function ()
	_clear_fx_lines()
	_reset_all()
end

-- ---------------------------------------------------------------------------
-- /ringpreview [1-4 | stop]
-- Paints a safe ring around you and runs one full wave timeline, so the look
-- can be checked without reaching the boss.
-- ---------------------------------------------------------------------------

mod:command("ringpreview", mod:localize("ringpreview_desc"), function (arg)
	if arg == "stop" then
		pending_preview_zone = nil

		if wave and wave.simulated then
			_end_wave("preview stopped")
		end

		mod:echo("Preview stopped.")

		return
	end

	if tracker then
		mod:echo("The boss ring attack is active; preview disabled.")

		return
	end

	local zone = tonumber(arg) or 2

	if not RINGS[zone] then
		mod:echo(string.format("Pick a ring from 1 to %d.", #RINGS))

		return
	end

	-- Started on the next frame update (see _start_pending_preview).
	pending_preview_zone = zone
end)

-- ---------------------------------------------------------------------------
-- Helpers shared with the pillar feature, then load it.
-- ---------------------------------------------------------------------------

local function _camera()
	local camera_manager = Managers.state and Managers.state.camera
	local player = Managers.player and Managers.player:local_player(1)

	if not camera_manager or not player or not player.viewport_name then
		return nil
	end

	local ok, camera = pcall(camera_manager.camera, camera_manager, player.viewport_name)

	return ok and camera or nil
end

mod.psz = {
	debug = _debug,
	gameplay_time = _gameplay_time,
	ensure_render = function ()
		if _ensure_render_resources() then
			return render
		end

		return nil
	end,
	-- Shared line object for per-frame debug-style geometry.
	lines = function ()
		return _ensure_render_resources() and render.fx_lines or nil
	end,
	camera = _camera,
	physics_world = _physics_world,
	raycast_floor_z = _raycast_floor_z,
	draw_countdown_text = _draw_countdown_text,
	font = FONT,
	text_layer = TEXT_LAYER,
	modules = modules,
	-- Read-only views for the forecast panel.
	ring_info = function ()
		return RINGS, wave
	end,
}

local BASE = "QIangIQsSpillway/scripts/mods/QIangIQsSpillway/QIangIQsSpillway_"

mod:io_dofile(BASE .. "draw")
mod:io_dofile(BASE .. "pillars")
mod:io_dofile(BASE .. "walls")
mod:io_dofile(BASE .. "balls")
mod:io_dofile(BASE .. "bossbar")
mod:io_dofile(BASE .. "forecast")
mod:io_dofile(BASE .. "saferoute")
