-- QIangIQsSpillway: the boss's green and red projectiles
--
-- The Prophet's "shoot" attack throws force balls (renegade_wizard_actions.lua,
-- shoot.singular / shoot.fan / ground variants) using two projectile templates
-- from scripts/settings/projectile/minion_projectile_templates.lua:
--   renegade_wizard_force_ball_nurgle  explodes on impact (explosion template
--                                      renegade_wizard_projectile_nurgle: close_radius 5,
--                                      radius 10). Shootable: health_component_data.max_health 10.
--   renegade_wizard_force_ball_warp    applies the buff "spillway_wizard_warp_lightning"
--                                      on player impact. Shootable as well.
-- Both fly with locomotion template renegade_wizard_ball (true flight, radius 0.25).
--
-- Every client builds a ProjectileFxExtension for each projectile, with the
-- template name in extension_init_data.projectile_template_name, so that is
-- where the balls are picked up.

local mod = get_mod("QIangIQsSpillway")
local S = mod.psz
local D = S.draw

local FX_PATH = "scripts/extension_systems/fx/projectile_fx_extension"
local EXPLOSION_TEMPLATES_PATH = "scripts/settings/damage/explosion_templates"
local TEMPLATE_PREFIX = "renegade_wizard_force_ball_"

local TRAIL_INTERVAL = 0.05
local TRAIL_POINTS = 24
local LOOKAHEAD_SECONDS = 1.5
local POLE_UP = 8
local MAX_SHOWN_DISTANCE = 120

-- [unit] = { kind, trail = { x, y, z, ... }, last_trail_t, px, py, pz, vx, vy, vz }
local balls = {}

local EXPLOSION_CLOSE_RADIUS, EXPLOSION_RADIUS = 5, 10

do
	local ok, templates = pcall(require, EXPLOSION_TEMPLATES_PATH)
	local nurgle = ok and templates and templates.renegade_wizard_projectile_nurgle

	if nurgle then
		EXPLOSION_CLOSE_RADIUS = nurgle.close_radius or EXPLOSION_CLOSE_RADIUS
		EXPLOSION_RADIUS = nurgle.radius or EXPLOSION_RADIUS
	end
end

local KINDS = {
	nurgle = {
		label = "NURGLE",
		setting = "ball_nurgle",
		default = { 60, 255, 70 },
	},
	warp = {
		label = "WARP",
		setting = "ball_warp",
		default = { 255, 50, 50 },
	},
}

local function _kind_color(kind, alpha)
	local info = KINDS[kind]
	local r = mod:get(info.setting .. "_r") or info.default[1]
	local g = mod:get(info.setting .. "_g") or info.default[2]
	local b = mod:get(info.setting .. "_b") or info.default[3]

	return Color(alpha, r, g, b), r, g, b
end

local function _on_fx_init(self, extension_init_context, unit, extension_init_data)
	local name = extension_init_data and extension_init_data.projectile_template_name

	if type(name) ~= "string" or string.sub(name, 1, #TEMPLATE_PREFIX) ~= TEMPLATE_PREFIX then
		return
	end

	local kind = string.sub(name, #TEMPLATE_PREFIX + 1)

	if KINDS[kind] then
		balls[unit] = {
			kind = kind,
			trail = {},
		}
	end
end

mod:hook_require(FX_PATH, function (class)
	if not class or class.__qiangiqs_spillway_hooked then
		return
	end

	class.__qiangiqs_spillway_hooked = true

	mod:hook_safe(class, "init", _on_fx_init)
end)

local function _update_ball(ball, unit, t)
	local position = Unit.world_position(unit, 1)
	local x, y, z = Vector3.to_elements(position)

	-- Husk projectiles can sit at the origin before their first interpolation.
	if math.abs(x) < 0.001 and math.abs(y) < 0.001 and math.abs(z) < 0.001 then
		return false
	end

	local last_t = ball.last_t

	if last_t and t > last_t then
		local dt = t - last_t

		if dt > 0.001 then
			local k = math.min(1, dt * 12)
			local vx, vy, vz = (x - ball.px) / dt, (y - ball.py) / dt, (z - ball.pz) / dt

			ball.vx = (ball.vx or vx) + (vx - (ball.vx or vx)) * k
			ball.vy = (ball.vy or vy) + (vy - (ball.vy or vy)) * k
			ball.vz = (ball.vz or vz) + (vz - (ball.vz or vz)) * k
		end
	end

	ball.last_t = t
	ball.px, ball.py, ball.pz = x, y, z

	if not ball.trail_t or t - ball.trail_t >= TRAIL_INTERVAL then
		ball.trail_t = t

		local trail = ball.trail

		trail[#trail + 1] = x
		trail[#trail + 1] = y
		trail[#trail + 1] = z

		while #trail > TRAIL_POINTS * 3 do
			table.remove(trail, 1)
			table.remove(trail, 1)
			table.remove(trail, 1)
		end
	end

	return true
end

local function _draw_ball(lines, render, camera, ball, player_position)
	local color, r, g, b = _kind_color(ball.kind, 255)
	local soft = Color(120, r, g, b)
	local position = Vector3(ball.px, ball.py, ball.pz)
	local distance = Vector3.distance(position, player_position)

	if distance > MAX_SHOWN_DISTANCE then
		return
	end

	local size = (mod:get("ball_marker_size_cm") or 80) / 100

	-- Marker sphere: oversized on purpose, the real ball is only 0.25 m across.
	LineObject.add_sphere(lines, color, position, size, 14, 3)
	LineObject.add_sphere(lines, color, position, size * 0.45, 10, 2)

	-- Pole above the ball and a drop line to the floor.
	if mod:get("show_ball_pole") then
		LineObject.add_line(lines, color, position, position + Vector3(0, 0, POLE_UP))
	end

	local floor_z = S.raycast_floor_z(S.physics_world(), ball.px, ball.py, ball.pz + 0.5, 60)

	if floor_z then
		local ground = Vector3(ball.px, ball.py, floor_z + 0.08)

		LineObject.add_line(lines, soft, position, ground)
		D.ring(lines, color, ball.px, ball.py, floor_z + 0.08, 1.2, 20)

		if ball.kind == "nurgle" and mod:get("show_ball_blast") then
			-- Where it would explode if it hit right now (close band and outer edge).
			D.ring(lines, color, ball.px, ball.py, floor_z + 0.08, EXPLOSION_CLOSE_RADIUS, 40)
			D.ring(lines, soft, ball.px, ball.py, floor_z + 0.08, EXPLOSION_RADIUS, 48, true)
		end
	end

	-- Trail, fading toward the oldest point.
	local trail = ball.trail
	local count = #trail / 3

	for i = 2, count do
		local alpha = 40 + 200 * (i / count)
		local a = Vector3(trail[(i - 2) * 3 + 1], trail[(i - 2) * 3 + 2], trail[(i - 2) * 3 + 3])
		local c = Vector3(trail[(i - 1) * 3 + 1], trail[(i - 1) * 3 + 2], trail[(i - 1) * 3 + 3])

		LineObject.add_line(lines, Color(alpha, r, g, b), a, c)
	end

	-- Straight-line look-ahead along the current velocity.
	if mod:get("show_ball_lookahead") and ball.vx then
		local ahead = position + Vector3(ball.vx, ball.vy, ball.vz) * LOOKAHEAD_SECONDS

		LineObject.add_line(lines, soft, position, ahead)
		LineObject.add_sphere(lines, soft, ahead, size * 0.3, 8, 2)
	end

	local text = string.format("%s %d m", KINDS[ball.kind].label, math.floor(distance + 0.5))

	if mod:get("show_ball_labels") then
		if D.on_screen(camera, position) then
			D.world_label(render, camera, position + Vector3(0, 0, size + 0.4), text, 20, color)
		elseif mod:get("show_ball_edge_arrows") then
			D.edge_indicator(render, camera, position, color, text)
		end
	elseif mod:get("show_ball_edge_arrows") and not D.on_screen(camera, position) then
		D.edge_indicator(render, camera, position, color, text)
	end
end

local function update(t, dt)
	if not mod:get("show_balls") or next(balls) == nil then
		return
	end

	local lines = S.lines()
	local render = S.ensure_render()

	if not lines or not render then
		return
	end

	local player = Managers.player and Managers.player:local_player(1)
	local player_unit = player and player.player_unit

	if not player_unit or not Unit.alive(player_unit) then
		return
	end

	local player_position = Unit.world_position(player_unit, 1)
	local camera = S.camera()

	for unit, ball in pairs(balls) do
		if not Unit.alive(unit) then
			balls[unit] = nil
		else
			local ok, valid = pcall(_update_ball, ball, unit, t)

			if ok and valid then
				pcall(_draw_ball, lines, render, camera, ball, player_position)
			end
		end
	end
end

S.modules[#S.modules + 1] = {
	name = "Boss projectiles",
	update = update,
	reset = function ()
		table.clear(balls)
	end,
}
