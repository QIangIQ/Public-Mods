return {
	mod_name = {
		en = "QIangIQs Spillway",
	},
	mod_description = {
		en = "Prophet of Decay and Spillway helper. Ring attack: safe ring paint and burn countdown. Pillar phase: beams, defensive hitbox outlines, nearest-pillar arrow and push countdown. Phase 3: rotating wall hitboxes. Green and red projectile tracking. Boss bar phase ticks and numbers. Route markers for the branching paths. Built on Prophet Safe Zone, NumericUI and SafeRoute.",
	},
	group_ring = {
		en = "Safe ring paint (ring attack)",
	},
	show_ring = {
		en = "Paint the safe ring",
	},
	color_r = {
		en = "Color: red",
	},
	color_g = {
		en = "Color: green",
	},
	color_b = {
		en = "Color: blue",
	},
	fill_opacity = {
		en = "Fill opacity (percent)",
	},
	height_offset_cm = {
		en = "Height above floor (cm)",
	},
	height_offset_cm_description = {
		en = "Raise this if the paint flickers or disappears into the floor.",
	},
	group_pillars = {
		en = "Pillars (push phase)",
	},
	show_beams = {
		en = "Light beams over raised pillars",
	},
	beam_pulse_final = {
		en = "Pulse beams on the final push",
	},
	beam_pulse_final_description = {
		en = "After the final push of each cycle, all pillars drop and the boss is exhausted.",
	},
	beam_color_r = {
		en = "Beam color: red",
	},
	beam_color_g = {
		en = "Beam color: green",
	},
	beam_color_b = {
		en = "Beam color: blue",
	},
	beam_width_cm = {
		en = "Beam width (cm)",
	},
	beam_height_m = {
		en = "Beam height (m)",
	},
	show_cover_hitbox = {
		en = "Outline each pillar's defensive hitbox",
	},
	show_cover_hitbox_description = {
		en = "The cover wedge behind a raised pillar, measured away from the arena center. Standing inside it protects you from the push. Same shape the server tests (tooth_cover_settings: 25 m long, 0.625 m wide at the pillar, 6.25 m wide at the far end). Uses the beam color.",
	},
	cover_lift_cm = {
		en = "Hitbox outline height above floor (cm)",
	},
	show_pillar_arrow = {
		en = "Arrow to nearest pillar",
	},
	show_pillar_arrow_description = {
		en = "Hidden while you're in cover or close to a pillar.",
	},
	arrow_radius = {
		en = "Arrow distance from crosshair (px at 1080p)",
	},
	arrow_hide_distance = {
		en = "Hide arrow within this many meters of a pillar",
	},
	show_push_countdown = {
		en = "Push countdown",
	},
	show_push_countdown_description = {
		en = "Uses the position and size from the Countdown section.",
	},
	group_walls = {
		en = "Phase 3 rotating walls",
	},
	show_walls = {
		en = "Draw the wall hitboxes",
	},
	show_walls_description = {
		en = "Draws each wall's real damage box (1 m wide, 25 m long, 6 m tall) with lines, so the walls are visible even when their model is not. Yellow while the walls are still rising (harmless), solid once they can hurt you. While a wall turns, a dim ghost shows where it will be after the quarter-eighth turn and arcs show the sweep.",
	},
	wall_color_r = {
		en = "Wall color: red",
	},
	wall_color_g = {
		en = "Wall color: green",
	},
	wall_color_b = {
		en = "Wall color: blue",
	},
	show_wall_labels = {
		en = "Wall rise / turn timers",
	},
	group_balls = {
		en = "Boss projectiles (green and red balls)",
	},
	show_balls = {
		en = "Track the boss's projectiles",
	},
	show_balls_description = {
		en = "Marks the Nurgle (green) and Warp (red) balls with an oversized sphere, a drop line, a ground ring, a fading trail and a straight-line look-ahead.",
	},
	ball_marker_size_cm = {
		en = "Marker size (cm)",
	},
	ball_marker_size_cm_description = {
		en = "The real ball is only about 25 cm across.",
	},
	show_ball_pole = {
		en = "Vertical pole above each ball",
	},
	show_ball_blast = {
		en = "Nurgle blast radius on the floor",
	},
	show_ball_blast_description = {
		en = "Shows where a Nurgle ball would explode if it hit right now: solid ring is the close-damage radius, dashed ring the outer radius.",
	},
	show_ball_lookahead = {
		en = "Straight-line look-ahead",
	},
	show_ball_lookahead_description = {
		en = "Extends the ball's current velocity 1.5 seconds. The balls home in, so this is a hint, not a prediction.",
	},
	show_ball_labels = {
		en = "Name and distance labels",
	},
	show_ball_edge_arrows = {
		en = "Arrows for off-screen balls",
	},
	ball_nurgle_r = {
		en = "Nurgle ball: red",
	},
	ball_nurgle_g = {
		en = "Nurgle ball: green",
	},
	ball_nurgle_b = {
		en = "Nurgle ball: blue",
	},
	ball_warp_r = {
		en = "Warp ball: red",
	},
	ball_warp_g = {
		en = "Warp ball: green",
	},
	ball_warp_b = {
		en = "Warp ball: blue",
	},
	group_rolls = {
		en = "Level random rolls (all missions)",
	},
	show_level_rolls = {
		en = "Show level rolls in the world",
	},
	show_level_rolls_description = {
		en = "When a level picks a random set-piece (for example which bridge stays up), shows the number the server drew at that spot and which numbers are still unused. Nothing is known before the first draw.",
	},
	roll_chat = {
		en = "Print level rolls in chat",
	},
	group_forecast = {
		en = "Forecast panel",
	},
	show_forecast = {
		en = "Show forecast panel",
	},
	show_forecast_description = {
		en = "Next phase (by health or time), wave countdown, which ring bands are possible next, and push progress. Countdowns that follow server timers are estimates started when the health threshold is crossed.",
	},
	forecast_x = {
		en = "Panel horizontal position (percent)",
	},
	forecast_y = {
		en = "Panel vertical position (percent)",
	},
	forecast_size = {
		en = "Panel text size",
	},
	group_bossbar = {
		en = "Prophet boss bar",
	},
	show_phase_ticks = {
		en = "Phase threshold ticks",
	},
	show_phase_ticks_description = {
		en = "Ticks on the boss health bar at the health values where the fight changes phase (57, 55, 34, 33 and the 12.5 percent enrage line), from the game's phase table. Passed ticks dim.",
	},
	show_tick_labels = {
		en = "Tick percentage labels",
	},
	show_boss_numbers = {
		en = "Health and toughness numbers on the Prophet bar",
	},
	show_boss_numbers_description = {
		en = "From NumericUI. If NumericUI's own boss numbers are on, they draw in the same spot.",
	},
	boss_numbers_all = {
		en = "Numbers on every boss bar",
	},
	boss_numbers_all_description = {
		en = "Off: only the Prophet gets numbers from this mod.",
	},
	group_countdown = {
		en = "Countdown",
	},
	group_countdown_description = {
		en = "Shared by the ring countdown and the push countdown.",
	},
	show_countdown = {
		en = "Show ring countdown",
	},
	countdown_position = {
		en = "Vertical position (percent from top of screen)",
	},
	countdown_position_description = {
		en = "50 is the crosshair, 0 is the top edge.",
	},
	countdown_size = {
		en = "Text size",
	},
	group_routes = {
		en = "Spillway route markers",
	},
	sr_enabled = {
		en = "Mark the safe route at branching paths",
	},
	sr_enabled_description = {
		en = "Marks the safe road at every branching path of the Spillway mission: SAFE ROUTE and WRONG WAY markers and guide dots (from SafeRoute).",
	},
	sr_show_wrong_roads = {
		en = "Mark wrong roads",
	},
	sr_show_wrong_roads_description = {
		en = "Shows a red marker a few metres into every road the mission did not choose.",
	},
	sr_show_guide_dots = {
		en = "Guide dots from the fork",
	},
	sr_show_guide_dots_description = {
		en = "Dots along routes walked in game, from each fork to the SAFE ROUTE marker (and to each WRONG WAY marker with Mark wrong roads). Roads without a recorded route get no dots.",
	},
	sr_max_distance = {
		en = "Marker range (m)",
	},
	sr_max_distance_description = {
		en = "Markers and dots are shown when you are closer than this.",
	},
	sr_announce = {
		en = "Announce in chat",
	},
	sr_announce_description = {
		en = "Writes a chat line when a mission with branching paths loads.",
	},
	debug_log = {
		en = "Debug logging",
	},
	debug_log_description = {
		en = "Prints ring and pillar events to chat (new safe ring, reshuffles, pushes). Useful when reporting problems.",
	},
	pillarpreview_desc = {
		en = "Preview pillar beams, hitboxes, arrow and push countdown around you. Usage: /pillarpreview [stop]",
	},
	ringpreview_desc = {
		en = "Preview the safe ring around you. Usage: /ringpreview [1-4 | stop]",
	},
	sr_label_safe = {
		en = "SAFE ROUTE",
	},
	sr_label_wrong = {
		en = "WRONG WAY",
	},
	sr_announce_text = {
		en = "Spillway route: %d branching paths found, safe roads marked.",
	},
	sr_crossroad_line = {
		en = "Branching %d: safe road %s of %d",
	},
	sr_no_crossroads = {
		en = "This mission has no branching paths.",
	},
	sr_command_description = {
		en = "List the branching paths of this mission and their safe road.",
	},
	sr_route_recorded = {
		en = "  Fork %s road %s: guide route recorded",
	},
	sr_route_missing = {
		en = "  Fork %s road %s: no guide route",
	},
}
