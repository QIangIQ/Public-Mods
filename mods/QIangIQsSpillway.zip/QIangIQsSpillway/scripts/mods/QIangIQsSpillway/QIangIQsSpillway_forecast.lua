-- QIangIQsSpillway: forecast panel
--
-- Shows what the fight will do next, using only values that are fixed in
-- scripts/managers/pacing/bosses/spillway_wizard.lua:
--   health gates 0.57 / 0.55 / 0.34 / 0.33 / 0.125
--   exhausted_01 / exhausted_02 last 7 s, then the intermission starts; the
--   intermission wave event has a 5 s delay; an intermission ends at its health
--   gate or 45 s after it starts
-- The ring band and the pillar set are random rolls made when they happen
-- (wizard_dance_stage_hazard._set_new_zone: any band except the last one),
-- so only exclusions are shown. Timers are estimates anchored on the moment
-- the boss bar crosses a gate, since clients do not see the server phase.

local mod = get_mod("QIangIQsSpillway")
local S = mod.psz

local GATES = {
	{ pct = 0.57, text = "Exhausted, then wave 1" },
	{ pct = 0.55, text = "Pillars + force push" },
	{ pct = 0.34, text = "Exhausted, then wave 2" },
	{ pct = 0.33, text = "Rotating walls" },
	{ pct = 0.125, text = "ENRAGE (ring stops, teleports)" },
	{ pct = 0.0, text = "Defeat" },
}
local EXHAUST_T = 7
local WAVE_DELAY_T = 5
local INTERMISSION_MAX_T = 45

local crossed = {} -- gate pct -> gameplay time the bar dropped below it
local last_fraction = nil

local function _reset()
	crossed = {}
	last_fraction = nil
	S.boss_state = nil
end

local function _track(state, t)
	local f = state.fraction

	if f > 0.995 then
		crossed = {}
	end

	if last_fraction then
		for i = 1, #GATES do
			local g = GATES[i].pct

			if g > 0 and last_fraction >= g and f < g and not crossed[g] then
				crossed[g] = t
			end
		end
	end

	-- Joined mid-fight: assume the gates already below us were crossed now.
	if not last_fraction then
		for i = 1, #GATES do
			local g = GATES[i].pct

			if g > 0 and f < g then
				crossed[g] = crossed[g] or t
			end
		end
	end

	last_fraction = f
end

local function _intermission_lines(lines, anchor_pct, gate_pct, label, t, f)
	local c = crossed[anchor_pct]

	if not c or f < gate_pct then
		return
	end

	local since = t - c
	local wave_t = EXHAUST_T + WAVE_DELAY_T
	local end_t = EXHAUST_T + INTERMISSION_MAX_T

	if since < EXHAUST_T then
		lines[#lines + 1] = { string.format("%s: boss exhausted ~%.0f s (free damage)", label, EXHAUST_T - since), 255, 150, 120 }
		lines[#lines + 1] = { string.format("%s: wave from EAST + WEST in ~%.0f s", label, wave_t - since), 255, 220, 90 }
	elseif since < wave_t then
		lines[#lines + 1] = { string.format("%s: wave from EAST + WEST in ~%.0f s", label, wave_t - since), 255, 220, 90 }
	elseif since < end_t then
		lines[#lines + 1] = { string.format("%s: clear the wave. Ends at %d%% or in ~%.0f s", label, math.floor(gate_pct * 100 + 0.5), end_t - since), 255, 160, 60 }
	end
end

local function _ring_lines(lines, f)
	-- Ring dance runs in phase 1 (above 57%) and phase 3 (33% down to 12.5%).
	if not ((f >= 0.57) or (f < 0.33 and f >= 0.125)) then
		return
	end

	local rings, wave = S.ring_info()
	local last = S.ring_last_zone
	local function band(z)
		return rings[z] and string.format("%g-%g m", rings[z].inner, rings[z].outer) or "?"
	end

	if wave then
		lines[#lines + 1] = { string.format("RING: safe band %d (%s) now", wave.zone, band(wave.zone)), 90, 255, 160 }
	end

	if last and rings[last] then
		local possible = {}

		for z = 1, #rings do
			if z ~= last then
				possible[#possible + 1] = tostring(z)
			end
		end

		lines[#lines + 1] = { string.format("Next safe band: NOT %d (%s). Could be %s", last, band(last), table.concat(possible, "/")), 120, 220, 255 }
	else
		lines[#lines + 1] = { "Next safe band: random (no ring seen yet)", 120, 220, 255 }
	end
end

local function _push_lines(lines, t, f)
	if not (f < 0.55 and f >= 0.34) then
		return
	end

	local cycle, countdown, total = S.pillar_state()

	if cycle and cycle.known then
		local text = string.format("PUSH %d of %d done", cycle.fired, total)

		if countdown and countdown.push_t and countdown.push_t > t then
			text = text .. string.format(", next in ~%.1f s", countdown.push_t - t)
		end

		lines[#lines + 1] = { text, 255, 190, 90 }
	end
end

local function update(t, dt)
	if not mod:get("show_forecast") then
		return
	end

	local state = S.boss_state

	if not state or t - state.t > 2 then
		if state then
			_reset()
		end

		return
	end

	_track(state, t)

	local render = S.ensure_render()

	if not render then
		return
	end

	local f = state.fraction
	local lines = {}

	for i = 1, #GATES do
		if f > GATES[i].pct then
			local away = state.max_health and string.format(" (%d HP away)", math.floor((f - GATES[i].pct) * state.max_health + 0.5)) or ""

			lines[#lines + 1] = { string.format("NEXT at %g%%: %s%s", GATES[i].pct * 100, GATES[i].text, away), 255, 255, 255 }

			break
		end
	end

	_intermission_lines(lines, 0.57, 0.55, "Intermission 1", t, f)
	_intermission_lines(lines, 0.34, 0.33, "Intermission 2", t, f)
	_push_lines(lines, t, f)
	_ring_lines(lines, f)

	local width, height = Gui.resolution()
	local size = (mod:get("forecast_size") or 22) * height / 1080
	local x = width * (mod:get("forecast_x") or 82) / 100
	local y = height * (mod:get("forecast_y") or 28) / 100

	for i = 1, #lines do
		local l = lines[i]

		S.draw.text_at(render, l[1], x, y + (i - 1) * size * 1.25, size, Color(255, l[2], l[3], l[4]))
	end
end

S.modules[#S.modules + 1] = {
	name = "Forecast",
	update = update,
	reset = _reset,
}
