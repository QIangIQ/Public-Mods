-- QIangIQsSpillway: phase 3 rotating walls
--
-- In the last phase (dance_02) the boss raises rotating walls. The game's
-- WizardBossDanceWalls component keeps one oriented hitbox per wall and, once
-- the walls have fully risen, applies the "spillway_wizard_warp_lightning" buff
-- to everything inside (server side, collision filter "filter_minion_melee").
-- Walls rotate one eighth turn at a time (ROTATION_DELTA, ROTATION_DURATION).
--
-- Source: scripts/components/wizard_boss_dance_walls.lua. Per wall i the
-- component computes, every update:
--   wall_rotation = unit_rotation offset by (2*pi / num_walls * (i - 1)) around up
--   hit_box_position = unit_position + forward * (length / 2 + 2.5) + up * (height / 2)
--   hit_box_rotation = Quaternion.look(forward, up)
--   extents = (width / 2, length / 2, height / 2) = (0.5, 12.5, 3)
-- This module draws exactly that box with lines, so the wall stays visible even
-- when its model is not rendered.

local mod = get_mod("QIangIQsSpillway")
local S = mod.psz
local D = S.draw

local WALLS_PATH = "scripts/components/wizard_boss_dance_walls"
local FixedFrame = require("scripts/utilities/fixed_frame")

local TWO_PI = math.pi * 2
local ROTATION_DELTA = TWO_PI / 8 -- wizard_boss_dance_walls.lua ROTATION_DELTA
local ROTATION_DURATION = 3.8 -- wizard_boss_dance_walls.lua ROTATION_DURATION
local SPAWN_RISE_DURATION = 5 -- wizard_boss_dance_walls.lua SPAWN_RISE_DURATION
local WALL_FORWARD_OFFSET = 2.5 -- wizard_boss_dance_walls.lua WALL_FORWARD_OFFSET

-- [unit] = { component, data = plain-number snapshot of the last update }
local walls = {}

local function _snapshot(self, unit)
	local fixed_t = FixedFrame.get_latest_fixed_time()
	local num_walls = self._num_walls or 0
	local extents = self._hitbox_extents and self._hitbox_extents:unbox()

	if num_walls < 1 or not extents then
		return nil
	end

	local ex, ey, ez = Vector3.to_elements(extents)
	local origin = Unit.world_position(unit, 1)
	local ox, oy, oz = Vector3.to_elements(origin)
	local snap = {
		extents = { ex, ey, ez },
		origin = { ox, oy, oz },
		num_walls = num_walls,
		risen = self:_has_fully_risen(fixed_t),
		rise_progress = math.clamp(self:_get_spawn_rise_progress(fixed_t), 0, 1),
		rotating = self._rotation_target_quat ~= nil,
		rotation_progress = self._progress or 0,
		queued = self._should_rotate == true,
		walls = {},
		targets = nil,
	}

	for i = 1, num_walls do
		local transform = self._wall_transforms[i]
		local position = transform and transform.hit_box_position
		local rotation = transform and transform.hit_box_rotation

		if not position or not rotation then
			return nil
		end

		local px, py, pz = Vector3.to_elements(position)
		local fx, fy, fz = Vector3.to_elements(Quaternion.forward(rotation))

		snap.walls[i] = { px, py, pz, fx, fy, fz }
	end

	if snap.rotating then
		local target = self._rotation_target_quat:unbox()

		snap.targets = {}

		for i = 1, num_walls do
			local wall_rotation = Quaternion.multiply(target, Quaternion.axis_angle(Vector3.up(), TWO_PI / num_walls * (i - 1)))
			local fx, fy, fz = Vector3.to_elements(Quaternion.forward(wall_rotation))

			snap.targets[i] = { fx, fy, fz }
		end
	end

	return snap
end

local function _on_init(self, unit)
	if unit and self._wall_transforms then
		walls[unit] = {
			component = self,
		}
	end
end

local function _on_update(self, unit, dt, t)
	local entry = walls[unit]

	if not entry then
		if self._wall_transforms then
			entry = {
				component = self,
			}
			walls[unit] = entry
		else
			return
		end
	end

	local ok, snap = pcall(_snapshot, self, unit)

	entry.data = ok and snap or nil
end

local function _on_destroy(self, unit)
	walls[unit] = nil
end

mod:hook_require(WALLS_PATH, function (class)
	if not class or class.__qiangiqs_spillway_hooked then
		return
	end

	class.__qiangiqs_spillway_hooked = true

	mod:hook_safe(class, "init", _on_init)
	mod:hook_safe(class, "update", _on_update)
	mod:hook_safe(class, "destroy", _on_destroy)
end)

local function _wall_colors(snap)
	local r, g, b = mod:get("wall_color_r") or 255, mod:get("wall_color_g") or 40, mod:get("wall_color_b") or 40

	if not snap.risen then
		-- Still rising: harmless, so shown in a calmer color.
		return Color(200, 255, 200, 40), Color(80, 255, 200, 40)
	end

	return Color(255, r, g, b), Color(110, r, g, b)
end

local function _draw_snapshot(lines, render, camera, snap)
	local edge, grid = _wall_colors(snap)
	local up = Vector3.up()
	local ox, oy, oz = snap.origin[1], snap.origin[2], snap.origin[3]
	local half = {
		x = snap.extents[1],
		y = snap.extents[2],
		z = snap.extents[3],
	}
	local tip_distance = half.y * 2 + WALL_FORWARD_OFFSET

	for i = 1, snap.num_walls do
		local w = snap.walls[i]
		local center = Vector3(w[1], w[2], w[3])
		local forward = Vector3(w[4], w[5], w[6])
		local right = Vector3.normalize(Vector3.cross(forward, up))

		D.box(lines, center, right, forward, up, half, edge, grid, 2)

		-- Floor stripe along the wall (the lane that will hurt).
		local floor_a = Vector3(ox, oy, oz + 0.05) + forward * WALL_FORWARD_OFFSET
		local floor_b = Vector3(ox, oy, oz + 0.05) + forward * tip_distance

		LineObject.add_line(lines, edge, floor_a + right * half.x, floor_b + right * half.x)
		LineObject.add_line(lines, edge, floor_a - right * half.x, floor_b - right * half.x)

		if snap.rotating and snap.targets then
			-- Where this wall will be when the turn finishes, and the sweep.
			local t = snap.targets[i]
			local target_forward = Vector3(t[1], t[2], t[3])
			local target_right = Vector3.normalize(Vector3.cross(target_forward, up))
			local target_center = Vector3(ox, oy, w[3]) + target_forward * (half.y + WALL_FORWARD_OFFSET)
			local ghost = Color(150, 255, 160, 40)

			D.box(lines, target_center, target_right, target_forward, up, half, ghost, nil, nil)

			local a1 = math.atan2(w[5], w[4])
			local a2 = math.atan2(t[2], t[1])

			-- shortest signed difference, then draw the sweep at the tip and mid
			local diff = (a2 - a1 + math.pi) % TWO_PI - math.pi

			D.arc(lines, ghost, ox, oy, oz + 0.1, tip_distance, a1, a1 + diff, 20)
			D.arc(lines, ghost, ox, oy, oz + 0.1, half.y + WALL_FORWARD_OFFSET, a1, a1 + diff, 16)
		end
	end

	if mod:get("show_wall_labels") then
		local label
		local color

		if not snap.risen then
			label = string.format("WALLS RISING %.1f", math.max((1 - snap.rise_progress) * SPAWN_RISE_DURATION, 0))
			color = Color(255, 255, 220, 60)
		elseif snap.rotating then
			label = string.format("WALLS TURNING %.1f", math.max((1 - snap.rotation_progress) * ROTATION_DURATION, 0))
			color = Color(255, 255, 160, 40)
		end

		if label then
			local w = snap.walls[1]
			local tip = Vector3(w[1] + w[4] * half.y, w[2] + w[5] * half.y, w[3] + half.z + 1)

			D.world_label(render, camera, tip, label, 26, color)
		end
	end
end

local function update(t, dt)
	if not mod:get("show_walls") or next(walls) == nil then
		return
	end

	local lines = S.lines()
	local render = S.ensure_render()

	if not lines or not render then
		return
	end

	local camera = S.camera()

	for unit, entry in pairs(walls) do
		if not Unit.alive(unit) then
			walls[unit] = nil
		elseif entry.data then
			_draw_snapshot(lines, render, camera, entry.data)
		end
	end
end

S.modules[#S.modules + 1] = {
	name = "Dance walls",
	update = update,
	reset = function ()
		table.clear(walls)
	end,
}
