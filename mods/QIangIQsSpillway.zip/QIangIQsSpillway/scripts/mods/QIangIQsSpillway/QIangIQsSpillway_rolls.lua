-- QIangIQsSpillway: level roll watcher (all missions)
--
-- Level scripts pick random set-pieces (which bridge survives, which door
-- opens, ...) through the NetworkedUniqueRandomize component
-- (scripts/components/networked_unique_randomize.lua). The server shuffles
-- the numbers min_rand..max_rand once (table.generate_random_table, no seed,
-- so math.random) and hands them out one by one with get_next. Clients only
-- receive each number when it is drawn (rpc_networked_unique_randomize_roll),
-- so nothing can be known before the first draw. What a client CAN know:
--   * each draw the moment the server makes it, which may be before the level
--     shows the result;
--   * which numbers are still unused in the current shuffle, because a value
--     never repeats until all of min..max have been drawn.

local mod = get_mod("QIangIQsSpillway")
local S = mod.psz

local COMPONENT_PATH = "scripts/components/networked_unique_randomize"
local LABEL_TIME = 30

local tracked = {} -- unit -> { min, max, drawn = {value = true}, count, last, last_t, position (Vector3Box) }

local function _label(entry)
	local unused = {}

	if entry.min and entry.max then
		for v = entry.min, entry.max do
			if not entry.drawn[v] then
				unused[#unused + 1] = tostring(v)
			end
		end
	end

	local range = entry.min and string.format(" of %d-%d", entry.min, entry.max) or ""
	local rest = #unused > 0 and (" | unused: " .. table.concat(unused, ",")) or ""

	return string.format("ROLL %d%s%s", entry.last, range, rest)
end

local function _on_roll(component, result)
	local unit = component.unit or component._unit

	if not unit then
		return
	end

	local entry = tracked[unit]

	if not entry then
		local ok_min, min = pcall(component.get_data, component, unit, "min_rand")
		local ok_max, max = pcall(component.get_data, component, unit, "max_rand")

		entry = {
			min = ok_min and tonumber(min) or nil,
			max = ok_max and tonumber(max) or nil,
			drawn = {},
			count = 0,
		}
		tracked[unit] = entry
	end

	-- A repeated value means the server started a new shuffle (queue_loop).
	if entry.drawn[result] then
		entry.drawn = {}
		entry.count = 0
	end

	if result ~= 0 then
		entry.drawn[result] = true
		entry.count = entry.count + 1
	end

	entry.last = result
	entry.last_t = S.gameplay_time()

	local ok, position = pcall(Unit.world_position, unit, 1)

	entry.position = ok and position and Vector3Box(position) or nil

	local text = _label(entry)

	S.debug("level roll: %s at %s", text, entry.position and tostring(entry.position:unbox()) or "?")

	if mod:get("roll_chat") then
		mod:echo(text)
	end
end

mod:hook_require(COMPONENT_PATH, function (class)
	if class.__qiq_rolls_hooked or not class.events then
		return
	end

	class.__qiq_rolls_hooked = true

	mod:hook_safe(class.events, "rpc_networked_unique_randomize_roll", function (self, result)
		local ok, err = pcall(_on_roll, self, result)

		if not ok then
			S.debug("level roll watcher error: %s", tostring(err))
		end
	end)
end)

local function update(t)
	if not mod:get("show_level_rolls") or not next(tracked) then
		return
	end

	local render = S.ensure_render()
	local camera = render and S.camera()

	if not camera then
		return
	end

	for unit, entry in pairs(tracked) do
		entry.last_t = entry.last_t or t

		if entry.position and entry.last_t and t - entry.last_t < LABEL_TIME then
			local position = entry.position:unbox()
			local text = _label(entry)
			local color = Color(255, 255, 230, 90)

			if S.draw.on_screen(camera, position) then
				S.draw.world_label(render, camera, position, text, 22, color)
			else
				S.draw.edge_indicator(render, camera, position, color, text)
			end
		end
	end
end

S.modules[#S.modules + 1] = {
	name = "Level rolls",
	update = update,
	reset = function ()
		tracked = {}
	end,
}
