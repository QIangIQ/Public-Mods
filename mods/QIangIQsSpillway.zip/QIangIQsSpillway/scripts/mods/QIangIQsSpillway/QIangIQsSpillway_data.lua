local mod = get_mod("QIangIQsSpillway")

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			{
				setting_id = "group_ring",
				type = "group",
				sub_widgets = {
					{
						setting_id = "show_ring",
						type = "checkbox",
						default_value = true,
					},
					{
						setting_id = "color_r",
						type = "numeric",
						default_value = 0,
						range = { 0, 255 },
					},
					{
						setting_id = "color_g",
						type = "numeric",
						default_value = 255,
						range = { 0, 255 },
					},
					{
						setting_id = "color_b",
						type = "numeric",
						default_value = 255,
						range = { 0, 255 },
					},
					{
						setting_id = "fill_opacity",
						type = "numeric",
						default_value = 35,
						range = { 5, 100 },
					},
					{
						setting_id = "height_offset_cm",
						type = "numeric",
						default_value = 8,
						range = { 1, 50 },
					},
				},
			},
			{
				setting_id = "group_pillars",
				type = "group",
				sub_widgets = {
					{
						setting_id = "show_beams",
						type = "checkbox",
						default_value = true,
					},
					{
						setting_id = "beam_pulse_final",
						type = "checkbox",
						default_value = true,
					},
					{
						setting_id = "beam_color_r",
						type = "numeric",
						default_value = 40,
						range = { 0, 255 },
					},
					{
						setting_id = "beam_color_g",
						type = "numeric",
						default_value = 120,
						range = { 0, 255 },
					},
					{
						setting_id = "beam_color_b",
						type = "numeric",
						default_value = 255,
						range = { 0, 255 },
					},
					{
						setting_id = "beam_width_cm",
						type = "numeric",
						default_value = 100,
						range = { 30, 300 },
					},
					{
						setting_id = "beam_height_m",
						type = "numeric",
						default_value = 35,
						range = { 10, 80 },
					},
					{
						setting_id = "show_cover_hitbox",
						type = "checkbox",
						default_value = true,
					},
					{
						setting_id = "cover_lift_cm",
						type = "numeric",
						default_value = 12,
						range = { 2, 60 },
					},
					{
						setting_id = "show_pillar_arrow",
						type = "checkbox",
						default_value = true,
					},
					{
						setting_id = "arrow_radius",
						type = "numeric",
						default_value = 120,
						range = { 60, 400 },
					},
					{
						setting_id = "arrow_hide_distance",
						type = "numeric",
						default_value = 4,
						range = { 0, 10 },
					},
					{
						setting_id = "show_push_countdown",
						type = "checkbox",
						default_value = true,
					},
				},
			},
			{
				setting_id = "group_walls",
				type = "group",
				sub_widgets = {
					{
						setting_id = "show_walls",
						type = "checkbox",
						default_value = true,
					},
					{
						setting_id = "wall_color_r",
						type = "numeric",
						default_value = 255,
						range = { 0, 255 },
					},
					{
						setting_id = "wall_color_g",
						type = "numeric",
						default_value = 40,
						range = { 0, 255 },
					},
					{
						setting_id = "wall_color_b",
						type = "numeric",
						default_value = 40,
						range = { 0, 255 },
					},
					{
						setting_id = "show_wall_labels",
						type = "checkbox",
						default_value = true,
					},
				},
			},
			{
				setting_id = "group_balls",
				type = "group",
				sub_widgets = {
					{
						setting_id = "show_balls",
						type = "checkbox",
						default_value = true,
					},
					{
						setting_id = "ball_marker_size_cm",
						type = "numeric",
						default_value = 80,
						range = { 25, 250 },
					},
					{
						setting_id = "show_ball_pole",
						type = "checkbox",
						default_value = true,
					},
					{
						setting_id = "show_ball_blast",
						type = "checkbox",
						default_value = true,
					},
					{
						setting_id = "show_ball_lookahead",
						type = "checkbox",
						default_value = true,
					},
					{
						setting_id = "show_ball_labels",
						type = "checkbox",
						default_value = true,
					},
					{
						setting_id = "show_ball_edge_arrows",
						type = "checkbox",
						default_value = true,
					},
					{
						setting_id = "ball_nurgle_r",
						type = "numeric",
						default_value = 60,
						range = { 0, 255 },
					},
					{
						setting_id = "ball_nurgle_g",
						type = "numeric",
						default_value = 255,
						range = { 0, 255 },
					},
					{
						setting_id = "ball_nurgle_b",
						type = "numeric",
						default_value = 70,
						range = { 0, 255 },
					},
					{
						setting_id = "ball_warp_r",
						type = "numeric",
						default_value = 255,
						range = { 0, 255 },
					},
					{
						setting_id = "ball_warp_g",
						type = "numeric",
						default_value = 50,
						range = { 0, 255 },
					},
					{
						setting_id = "ball_warp_b",
						type = "numeric",
						default_value = 50,
						range = { 0, 255 },
					},
				},
			},
			{
				setting_id = "group_rolls",
				type = "group",
				sub_widgets = {
					{
						setting_id = "show_level_rolls",
						type = "checkbox",
						default_value = true,
					},
					{
						setting_id = "roll_chat",
						type = "checkbox",
						default_value = true,
					},
				},
			},
			{
				setting_id = "group_forecast",
				type = "group",
				sub_widgets = {
					{
						setting_id = "show_forecast",
						type = "checkbox",
						default_value = true,
					},
					{
						setting_id = "forecast_x",
						type = "numeric",
						default_value = 82,
						range = { 5, 95 },
					},
					{
						setting_id = "forecast_y",
						type = "numeric",
						default_value = 28,
						range = { 5, 90 },
					},
					{
						setting_id = "forecast_size",
						type = "numeric",
						default_value = 22,
						range = { 12, 40 },
					},
				},
			},
			{
				setting_id = "group_bossbar",
				type = "group",
				sub_widgets = {
					{
						setting_id = "show_phase_ticks",
						type = "checkbox",
						default_value = true,
					},
					{
						setting_id = "show_tick_labels",
						type = "checkbox",
						default_value = true,
					},
					{
						setting_id = "show_boss_numbers",
						type = "checkbox",
						default_value = true,
					},
					{
						setting_id = "boss_numbers_all",
						type = "checkbox",
						default_value = false,
					},
				},
			},
			{
				setting_id = "group_countdown",
				type = "group",
				sub_widgets = {
					{
						setting_id = "show_countdown",
						type = "checkbox",
						default_value = true,
					},
					{
						setting_id = "countdown_position",
						type = "numeric",
						default_value = 30,
						range = { 5, 50 },
					},
					{
						setting_id = "countdown_size",
						type = "numeric",
						default_value = 30,
						range = { 16, 60 },
					},
				},
			},
			{
				setting_id = "group_routes",
				type = "group",
				sub_widgets = {
					{
						setting_id = "sr_enabled",
						type = "checkbox",
						default_value = true,
					},
					{
						setting_id = "sr_show_wrong_roads",
						type = "checkbox",
						default_value = true,
					},
					{
						setting_id = "sr_show_guide_dots",
						type = "checkbox",
						default_value = true,
					},
					{
						setting_id = "sr_max_distance",
						type = "numeric",
						default_value = 60,
						range = { 20, 200 },
					},
					{
						setting_id = "sr_announce",
						type = "checkbox",
						default_value = true,
					},
				},
			},
			{
				setting_id = "debug_log",
				type = "checkbox",
				default_value = false,
			},
		},
	},
}
