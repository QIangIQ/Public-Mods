return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsSpillway` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsSpillway", {
			mod_script       = "QIangIQsSpillway/scripts/mods/QIangIQsSpillway/QIangIQsSpillway",
			mod_data         = "QIangIQsSpillway/scripts/mods/QIangIQsSpillway/QIangIQsSpillway_data",
			mod_localization = "QIangIQsSpillway/scripts/mods/QIangIQsSpillway/QIangIQsSpillway_localization",
		})
	end,
	packages = {},
}
