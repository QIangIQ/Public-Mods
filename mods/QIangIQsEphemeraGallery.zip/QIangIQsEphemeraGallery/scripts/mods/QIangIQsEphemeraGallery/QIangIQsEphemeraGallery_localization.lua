return {
    mod_name = {
        en = "QIangIQ's Ephemera Gallery",
    },
    mod_description = {
        en = "Shows Warframe ephemera models (taken from your own Warframe install) around your character, one at a time, picked from a list, each with its own saved position, turn and size. Works on the game's own characters and on the QIangIQ character models. Personal use only. By QIangIQ.",
    },
    enabled = {
        en = "Show the ephemera",
    },
    enabled_description = {
        en = "Chat command: /ephemera (on / off for this session), /ephemera next, /ephemera prev, /ephemera <number>, /ephemera <part of a name>.",
    },
    item = {
        en = "Ephemera",
    },
    item_description = {
        en = "Which ephemera is shown. The sliders below belong to the ephemera picked here and are saved for it.",
    },
    item_x = {
        en = "Move right / left (cm)",
    },
    item_x_description = {
        en = "Moves this ephemera to your right (+) or left (-).",
    },
    item_y = {
        en = "Move forward / back (cm)",
    },
    item_y_description = {
        en = "Moves this ephemera forward (+) or back (-).",
    },
    item_z = {
        en = "Move up / down (cm)",
    },
    item_z_description = {
        en = "Moves this ephemera up (+) or down (-).",
    },
    item_yaw = {
        en = "Turn (degrees)",
    },
    item_yaw_description = {
        en = "Turns this ephemera about the vertical.",
    },
    item_pitch = {
        en = "Tilt (degrees)",
    },
    item_pitch_description = {
        en = "Tilts this ephemera forward / back.",
    },
    item_roll = {
        en = "Roll (degrees)",
    },
    item_roll_description = {
        en = "Rolls this ephemera to the side.",
    },
    item_scale = {
        en = "Size",
    },
    item_scale_description = {
        en = "1 = its Warframe size.",
    },
    reset_item = {
        en = "Reset this ephemera",
    },
    reset_item_description = {
        en = "Puts this ephemera's position, turn and size back to the default.",
    },
    menu_previews = {
        en = "Show in menus (operative previews)",
    },
    menu_previews_description = {
        en = "Also shows it on your own operatives in menu previews.",
    },
    physics_group = {
        en = "Physics",
    },
    jiggle = {
        en = "Physics on",
    },
    jiggle_description = {
        en = "Cloth physics on the ephemera's own Warframe cloth bones (items that have them; up to 32 bones each).",
    },
    jiggle_cloth = {
        en = "Amount",
    },
    jiggle_cloth_description = {
        en = "1 = as built. Higher = looser and wider swings, lower = tighter. 0 = does not move.",
    },
    jiggle_stiffness = {
        en = "Stiffness",
    },
    jiggle_stiffness_description = {
        en = "How hard the cloth is pulled back to its rest pose. 1 = as built. Higher = snaps back faster, lower = softer and slower.",
    },
    jiggle_damping = {
        en = "Damping",
    },
    jiggle_damping_description = {
        en = "How quickly the wobble dies out. 1 = as built. Higher = settles at once, lower = keeps bouncing longer.",
    },
    jiggle_limit = {
        en = "Swing limit",
    },
    jiggle_limit_description = {
        en = "Scales the largest angle a bone may swing away from its rest pose. 1 = as built.",
    },
    jiggle_hang = {
        en = "Hang",
    },
    jiggle_hang_description = {
        en = "How strongly the cloth is drawn straight down instead of keeping its modelled direction when you lean or look up and down. 0 = keep the modelled shape.",
    },
    next_keybind = {
        en = "Next ephemera",
    },
    prev_keybind = {
        en = "Previous ephemera",
    },
    toggle_keybind = {
        en = "On / off for this session",
    },
    eph_batwingsephemeraskel = {
        en = "Bat Wings Ephemera",
    },
    eph_dexephemera = {
        en = "Dex Ephemera",
    },
    eph_duelistephemera = {
        en = "Duelist Ephemera",
    },
    eph_duelistspiritephemera = {
        en = "Duelist Spirit Ephemera",
    },
    eph_infestedheadphonesephemera = {
        en = "Infested Headphones Ephemera",
    },
    eph_infestedheartephemera = {
        en = "Infested Heart Ephemera",
    },
    eph_infestedtailephemera = {
        en = "Infested Tail Ephemera",
    },
    eph_proteacaladriusephemera = {
        en = "Protea Caladrius Ephemera",
    },
    eph_qorvexdeluxeephemera = {
        en = "Qorvex Deluxe Ephemera",
    },
    eph_tc2026hunhullusephemera = {
        en = "TC2026 Hunhullus Ephemera",
    },
}
