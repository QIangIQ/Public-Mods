return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsEphemeraGallery` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsEphemeraGallery", {
            mod_script = "QIangIQsEphemeraGallery/scripts/mods/QIangIQsEphemeraGallery/QIangIQsEphemeraGallery",
            mod_data = "QIangIQsEphemeraGallery/scripts/mods/QIangIQsEphemeraGallery/QIangIQsEphemeraGallery_data",
            mod_localization = "QIangIQsEphemeraGallery/scripts/mods/QIangIQsEphemeraGallery/QIangIQsEphemeraGallery_localization",
        })
    end,
    version = "1.1.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
