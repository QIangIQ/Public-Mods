return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsAnubis` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsAnubis", {
            mod_script = "QIangIQsAnubis/scripts/mods/QIangIQsAnubis/QIangIQsAnubis",
            mod_data = "QIangIQsAnubis/scripts/mods/QIangIQsAnubis/QIangIQsAnubis_data",
            mod_localization = "QIangIQsAnubis/scripts/mods/QIangIQsAnubis/QIangIQsAnubis_localization",
        })
    end,
    version = "1.13.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
