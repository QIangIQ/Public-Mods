return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsMMJPistol` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsMMJPistol", {
            mod_script = "QIangIQsMMJPistol/scripts/mods/QIangIQsMMJPistol/QIangIQsMMJPistol",
            mod_data = "QIangIQsMMJPistol/scripts/mods/QIangIQsMMJPistol/QIangIQsMMJPistol_data",
            mod_localization = "QIangIQsMMJPistol/scripts/mods/QIangIQsMMJPistol/QIangIQsMMJPistol_localization",
        })
    end,
    version = "0.1.0",
    author = "QIangIQ",
    packages = {},
}
