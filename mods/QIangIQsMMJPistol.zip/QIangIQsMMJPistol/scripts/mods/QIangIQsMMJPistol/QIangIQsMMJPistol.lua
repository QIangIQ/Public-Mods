local mod = get_mod("QIangIQsMMJPistol")

-- QIangIQsMMJPistol: Mullet Mad Jack's Pistol in place of stubrevolver_p1_m1 (Quickdraw Stub Revolver), stubrevolver_p1_m2 (Quickdraw Stub Revolver).

-- technique-unity-sprite-clips-hud-overlay); per-weapon data in QIangIQsMMJPistol_config.lua and QIangIQsMMJPistol_sprites.lua.
--
-- Every MMJ weapon is a 2D sprite rig (SpriteRenderers under its weapon camera, animated by Mecanim clips; BLACKSTAR
-- rip 2026-10-29), so first person shows it the way MMJ does: its sprites on screen, played from its own clips, with its
-- own sounds. The first-person arms and the Darktide weapon are hidden while it is held; a ranged weapon's hidden unit is
-- moved so its fx_muzzle_01 node sits under MMJ's muzzle point on screen, so shots leave from the MMJ gun.
--
-- Visual only. The retail weapon templates, actions and items are not changed or copied (no new template or action name,
-- so the weapon_action network lists stay retail: Datavault lesson-weapon-action-lookup-shift). The clip is chosen
-- locally from the weapon_action component. Third person (settings): own character hides the weapon by default, other
-- players keep theirs by default.
-- Contains ripped MMJ art and audio: local use only, never share (Datavault decision-ripped-assets-stay-local).

local Ammo = require("scripts/utilities/ammo")

local SCRIPTS = "QIangIQsMMJPistol/scripts/mods/QIangIQsMMJPistol/"
local CONFIG = mod:io_dofile(SCRIPTS .. "QIangIQsMMJPistol_config")
local Overlay = mod:io_dofile(SCRIPTS .. "QIangIQsMMJPistol_overlay")
local Assets = mod:io_dofile(SCRIPTS .. "QIangIQsMMJPistol_assets")
local Audio = mod:io_dofile(SCRIPTS .. "QIangIQsMMJPistol_audio")

Overlay.setup(mod:io_dofile(SCRIPTS .. "QIangIQsMMJPistol_sprites"))

local persist = mod:persistent_table("runtime")

Assets.setup(persist, function(line)
    mod:info("%s", line)
end)
Audio.setup(persist, function(line)
    mod:info("%s", line)
end)

local function opt(key, default)
    local v = mod:get(key)

    if v == nil then
        return default
    end

    return v
end

-- other mods keep tables under keys this mod scans (__qiangiq_*_arms), so check the type before Unit.alive (an error
-- "bad argument #1 to 'alive' (userdata expected, got table)" every frame, QIangIQsMMJUzi log 2026-11-01)
local function unit_ok(unit)
    return type(unit) == "userdata" and Unit.alive(unit)
end

local errors = {}

local function report(key, err)
    if not errors[key] then
        errors[key] = true
        mod:error("%s: %s", key, tostring(err))
    end
end

-- the slot holding one of the target weapons (wielded or not), if replacing it is switched on
local function our_slot(ext)
    for slot_name, slot in pairs(ext._equipment or {}) do
        local item = slot.item
        local template = item and item.weapon_template

        if template and CONFIG.templates[template] and opt("replace_" .. template, true) then
            return slot, slot_name
        end
    end

    return nil
end

local function component(unit, name)
    local ude = ScriptUnit.has_extension(unit, "unit_data_system")

    if not ude then
        return nil
    end

    local ok, c = pcall(ude.read_component, ude, name)

    return ok and c or nil
end

-- Hiding ------------------------------------------------------------------------------------------------------------------
-- Javelin set_visible pattern: the sets remember the units this mod hid, so showing them again only touches those
-- (weapon units and first-person arm units are kept apart: the arms come back as soon as the weapon is put away)
local hidden = setmetatable({}, { __mode = "k" })
local hidden_arms = setmetatable({}, { __mode = "k" })

local function hide(ext, unit, set)
    set = set or hidden

    if unit_ok(unit) then
        local mine = set[ext] or setmetatable({}, { __mode = "k" })

        set[ext] = mine
        mine[unit] = true
        Unit.set_unit_visibility(unit, false, true)
    end
end

local function hide_weapon(ext, slot)
    hide(ext, slot.unit_1p)

    for unit in pairs(slot.item_name_by_unit_1p or {}) do
        hide(ext, unit)
    end

    if opt("third_person", "hide") == "hide" then
        hide(ext, slot.unit_3p)

        for unit in pairs(slot.item_name_by_unit_3p or {}) do
            hide(ext, unit)
        end
    end
end

-- first-person arm units (QIangIQsButterflyKnife_fingers.lua Fingers.arm_units: QIangIQs model arms + slot_body*/
-- slot_gear* unit_1p)
local function hide_arms(ext)
    for key, value in pairs(ext) do
        if type(key) == "string" then
            if key:find("^__qiangiq_.+_arms$") and not key:find("_part_arms$") then
                hide(ext, value, hidden_arms)
            elseif key:find("^__qiangiq_.+_part_arms$") and type(value) == "table" then
                for _, part in pairs(value) do
                    hide(ext, part, hidden_arms)
                end
            end
        end
    end

    for slot_name, slot in pairs(ext._equipment or {}) do
        if type(slot_name) == "string" and (slot_name:find("^slot_body") or slot_name:find("^slot_gear")) then
            hide(ext, slot.unit_1p, hidden_arms)
        end
    end
end

local function show_hidden(ext, arms_only)
    if not (hidden_arms[ext] or (hidden[ext] and not arms_only)) then
        return
    end

    hidden_arms[ext] = nil

    if not arms_only then
        hidden[ext] = nil
    end

    -- the game sets the right visibility again (QIangIQsEmotes end_dance pattern)
    if ext.force_update_item_visibility then
        pcall(ext.force_update_item_visibility, ext)
    end
end

-- Camera ------------------------------------------------------------------------------------------------------------------
-- the local player's camera (world), QIangIQsSwordShield camera_pose (Datavault lesson-camera-node-not-view);
-- vertical fov from CameraManager.fov (camera_manager.lua:477)
local function camera_pose()
    local ok, rotation, position, fov = pcall(function()
        local camera = Managers.state and Managers.state.camera
        local player = Managers.player and Managers.player:local_player_safe(1)
        local viewport = player and player.viewport_name

        if not camera or not viewport then
            return nil
        end

        return camera:camera_rotation(viewport), camera:camera_position(viewport), camera:fov(viewport)
    end)

    if ok and rotation and position then
        return rotation, position, fov
    end
end

-- Player state (local player) ---------------------------------------------------------------------------------------------
local S = { active = false, clip = CONFIG.idle, clip_t = 0, loop = true, action_key = nil, pick = {} }

-- fov: MMJ CAM_Weapon is perspective, fieldOfView 60 (BLACKSTAR rip camera.json); the weapon roots sit under identity
-- parents (CameraAnimation / Graphics / RangedWeapons)
local function view()
    return {
        w = 1920, h = 1080, fov = math.rad(opt("mmj_fov", 60)), size = opt("size", 100) / 100,
        dx = opt("offset_x", 0) / 100, dy = opt("offset_y", 0) / 100,
        -- rotated_texture angle sign: + = counter-clockwise (inferred from AuspexHelper's arrow_01 directions, not seen
        -- in game yet); /<command> flip turns it round
        angle_sign = mod:get("flip_rotation") and -1 or 1,
        cap = opt("smear_cap", 100) / 100,
    }
end

local function play_sound(list)
    if list and #list > 0 and opt("sounds", true) then
        pcall(Audio.play, list[math.random(1, #list)], opt("volume", 100))
    end
end

local function base_clip(state)
    if state.aiming and CONFIG.aim and Overlay.has(CONFIG.aim) then
        return CONFIG.aim, state.clock, true
    end

    return CONFIG.idle, state.clock, true
end

-- An action entry (config): clips = { name, ... } played one after another (a random one of them when random = true),
-- stretch = fit the clips to the action's total time, loop = loop the (first) clip, loop_last = loop the last clip,
-- hold = keep the last frame, sounds = Ogg files (a random one when the action starts). Without stretch the clips play in real time and the idle follows once they end.
-- Shots (config.shot): the clip ammo count dropping (Ammo.current_ammo_in_clips, scripts/utilities/ammo.lua) starts the
-- shot clips and a random shot sound, once per round, so full-auto weapons play MMJ's shot for every bullet
local function shot_clip(t)
    local shot = CONFIG.shot

    if not (shot and S.shot_t) then
        return nil
    end

    local tt = t - S.shot_t

    for _, clip in ipairs(shot.clips) do
        local length = Overlay.length(clip)

        if tt < length then
            return clip, tt, false
        end

        tt = tt - length
    end

    return nil
end

local function watch_ammo(unit, slot_name, t)
    local shot = CONFIG.shot

    if not shot then
        return
    end

    local slot_component = component(unit, slot_name)
    local ok, ammo = pcall(Ammo.current_ammo_in_clips, slot_component)

    if not ok or type(ammo) ~= "number" then
        return
    end

    if S.ammo and ammo < S.ammo then
        S.shot_t = t
        play_sound(shot.sounds)
    end

    S.ammo = ammo
end

local function pick_clip(unit, t, slot_name)
    local wa = component(unit, "weapon_action")
    local name = wa and wa.current_action_name or "none"
    local start_t = wa and wa.start_t or t
    local key = name .. "@" .. tostring(start_t)
    local fresh = key ~= S.action_key
    local alternate = component(unit, "alternate_fire")
    local state = { clock = t, aiming = alternate and alternate.is_active or false }

    S.action_key = key

    local entry = CONFIG.actions[name]

    if not (entry and entry.over_shot) then
        local clip, tt, loop = shot_clip(t)

        if clip then
            return clip, tt, loop
        end
    end

    if not entry then
        return base_clip(state)
    end

    if fresh then
        play_sound(entry.sounds)

        if entry.random then
            S.pick[name] = entry.clips[math.random(1, #entry.clips)]
        end
    end

    local clips = entry.random and { S.pick[name] or entry.clips[1] } or entry.clips
    local elapsed = t - start_t
    local scale = math.max(wa and wa.time_scale or 1, 0.1)
    local template = wa and WeaponTemplates and WeaponTemplates[wa.template_name]
    local settings = template and template.actions and template.actions[name]
    local total = entry.time or (settings and settings.total_time)

    total = total and total < 10 and total / scale or nil

    -- reload_state actions run for the time of the reload state they start in (ReloadStates.get_total_time,
    -- reload_states.lua:34-37: reload_template[slot.reload_state].time, scaled by time_scale), e.g. the Bolt Pistol's
    -- eject_mag lasts 3.1 s although its ammo goes in at 2.6 s and action_reload.total_time says 2.6. The clip is stretched
    -- over that whole time, so it does not finish early and hold its last frame (user, 2026-11-01). The state is read
    -- once, when the action starts (it moves on to the next state while the action runs).
    if entry.reload_template and template and type(template.reload_template) == "table" then
        if fresh or not S.reload_total then
            local rt = template.reload_template
            local slot_component = slot_name and component(unit, slot_name)
            local state = slot_component and slot_component.reload_state
            -- "none": the weapon does not reload through states (shell-by-shell kinds); keep the action's own time
            local cfg = state and state ~= "none" and rt[state] or nil

            S.reload_total = cfg and cfg.time or nil
        end

        if S.reload_total then
            total = S.reload_total / scale
        end
    end

    if entry.segment then
        -- loop one stretch of the clip (seconds a..b): the magic glove's raised, firing frames while the stream lasts
        local a, b = entry.segment[1], entry.segment[2]

        return clips[1], a + elapsed % math.max(b - a, 0.02), false
    end

    if entry.loop then
        local clip = clips[1]
        local length = Overlay.length(clip)
        local tt = entry.stretch and total and elapsed / total * length or elapsed

        return clip, tt, true
    end

    local sum = 0

    for _, clip in ipairs(clips) do
        sum = sum + Overlay.length(clip)
    end

    local tt = elapsed

    if entry.stretch and total and sum > 0 then
        tt = elapsed / total * sum
    end

    for i, clip in ipairs(clips) do
        local length = Overlay.length(clip)
        local last = i == #clips

        if last and entry.loop_last and not entry.stretch then
            -- wind-up: the last clip loops for as long as the action lasts
            return clip, tt, true
        end

        if tt < length or (last and (entry.stretch or entry.hold)) then
            -- hold: the last frame stays while the action lasts (a block pose)
            return clip, math.min(tt, length), false
        end

        tt = tt - length
    end

    return base_clip(state)
end

-- Muzzle under MMJ's muzzle point: a ranged weapon's hidden first-person unit keeps firing its own effects from
-- fx_muzzle_01, so the weapon unit is moved, inside its own link, until that node sits on the camera ray through MMJ's
-- muzzle point (forward = rig +y, laspistol measurement in QIangIQsChainLaspistol 1.1.0; same convention assumed).
local weapon_saved = setmetatable({}, { __mode = "k" })
local muzzle_check = {}

local function find_muzzle(weapon_unit, parts)
    local rig_r, rig_p = Unit.world_rotation(weapon_unit, 1), Unit.world_position(weapon_unit, 1)
    local inv = Quaternion.inverse(rig_r)

    for unit in pairs(parts or {}) do
        if unit_ok(unit) and Unit.has_node(unit, "fx_muzzle_01") then
            local local_p = Quaternion.rotate(inv, Unit.world_position(unit, Unit.node(unit, "fx_muzzle_01")) - rig_p)

            if Vector3.length(local_p) < 1.2 then
                return local_p
            end
        end
    end

    return nil
end

local function restore_weapon()
    for unit, saved in pairs(weapon_saved) do
        if unit_ok(unit) then
            Unit.set_local_position(unit, 1, saved[1]:unbox())
            Unit.set_local_rotation(unit, 1, saved[2]:unbox())
        end

        weapon_saved[unit] = nil
    end

    muzzle_check.target = nil
end

-- the node the game linked the first-person weapon to (visual_loadout_customization.lua:270-281: wielded_attach_node or
-- attach_node on the first-person unit), or nil
local function attach_parent(slot, fp_unit)
    local item = slot.item
    local name = item and (item.wielded_attach_node or item.attach_node)

    if unit_ok(fp_unit) and type(name) == "string" and Unit.has_node(fp_unit, name) then
        return Unit.world_rotation(fp_unit, Unit.node(fp_unit, name)), Unit.world_position(fp_unit, Unit.node(fp_unit, name))
    end
end

-- world point under MMJ's muzzle (or hand) point on screen, at MMJ's depth; also returns the camera axes
local function muzzle_target(cam_r, cam_p, fov)
    local v = view()
    local sx, sy, depth = Overlay.muzzle(v)
    local nx, ny = (sx - v.w * 0.5) / (v.w * 0.5), (v.h * 0.5 - sy) / (v.h * 0.5)
    local aspect = RESOLUTION_LOOKUP and RESOLUTION_LOOKUP.width and RESOLUTION_LOOKUP.height
        and RESOLUTION_LOOKUP.width / RESOLUTION_LOOKUP.height or 16 / 9
    local tan_v = math.tan(fov * 0.5)
    local forward, right, up = Quaternion.forward(cam_r), Quaternion.right(cam_r), Quaternion.up(cam_r)
    local dir = Vector3.normalize(forward + right * (nx * tan_v * aspect) + up * (ny * tan_v))

    return cam_p + dir * (depth / math.max(Vector3.dot(dir, forward), 0.1)), forward, up
end

local function place_muzzle(slot, cam_r, cam_p, fov, fp_unit)
    local weapon_unit = slot.unit_1p

    if not unit_ok(weapon_unit) or not fov then
        return
    end

    local saved = weapon_saved[weapon_unit]

    if not saved then
        local muzzle = find_muzzle(weapon_unit, slot.item_name_by_unit_1p)

        if not muzzle then
            return
        end

        saved = { Vector3Box(Unit.local_position(weapon_unit, 1)), QuaternionBox(Unit.local_rotation(weapon_unit, 1)), Vector3Box(muzzle) }
        weapon_saved[weapon_unit] = saved
    end

    local v = view()
    local sx, sy, depth = Overlay.muzzle(v)
    local nx, ny = (sx - v.w * 0.5) / (v.w * 0.5), (v.h * 0.5 - sy) / (v.h * 0.5)
    local aspect = RESOLUTION_LOOKUP and RESOLUTION_LOOKUP.width and RESOLUTION_LOOKUP.height
        and RESOLUTION_LOOKUP.width / RESOLUTION_LOOKUP.height or 16 / 9
    local tan_v = math.tan(fov * 0.5)
    local forward, right, up = Quaternion.forward(cam_r), Quaternion.right(cam_r), Quaternion.up(cam_r)
    local dir = Vector3.normalize(forward + right * (nx * tan_v * aspect) + up * (ny * tan_v))
    local tip = cam_p + dir * (depth / math.max(Vector3.dot(dir, forward), 0.1))
    local barrel = Vector3.normalize(cam_p + forward * 50 - tip)
    local want_r = Quaternion.look(barrel, up)
    local want_p = tip - Quaternion.rotate(want_r, saved[3]:unbox())

    -- how far the real muzzle node was from last frame's target (checked once the engine has updated the pose)
    if muzzle_check.target then
        for unit in pairs(slot.item_name_by_unit_1p or {}) do
            if unit_ok(unit) and Unit.has_node(unit, "fx_muzzle_01") then
                muzzle_check.error_cm = Vector3.length(Unit.world_position(unit, Unit.node(unit, "fx_muzzle_01")) - muzzle_check.target:unbox()) * 100

                break
            end
        end
    end

    muzzle_check.target = Vector3Box(tip)

    -- parent pose: the attach node, else current world pose x inverse current local pose
    local parent_r, parent_p = attach_parent(slot, fp_unit)

    if not parent_r then
        local cur_lr, cur_lp = Unit.local_rotation(weapon_unit, 1), Unit.local_position(weapon_unit, 1)

        parent_r = Quaternion.multiply(Unit.world_rotation(weapon_unit, 1), Quaternion.inverse(cur_lr))
        parent_p = Unit.world_position(weapon_unit, 1) - Quaternion.rotate(parent_r, cur_lp)
        muzzle_check.parent = "derived"
    else
        muzzle_check.parent = "attach node"
    end

    local inv_parent = Quaternion.inverse(parent_r)

    Unit.set_local_rotation(weapon_unit, 1, Quaternion.multiply(inv_parent, want_r))
    Unit.set_local_position(weapon_unit, 1, Quaternion.rotate(inv_parent, want_p - parent_p))
end

local function update_local(ext, per_frame)
    local slot, slot_name = our_slot(ext)
    local unit = ext._unit

    if not slot then
        S.active = false
        restore_weapon()
        show_hidden(ext)

        return
    end

    local inventory = unit_ok(unit) and component(unit, "inventory")
    local wielded = inventory and inventory.wielded_slot == slot_name
    local fpe = unit_ok(unit) and ScriptUnit.has_extension(unit, "first_person_system")
    local first_person = fpe and fpe.is_in_first_person_mode and fpe:is_in_first_person_mode()

    -- the Darktide weapon never shows; the arms are hidden only while the MMJ weapon is drawn instead
    if wielded and first_person then
        hide_arms(ext)
    elseif hidden_arms[ext] then
        show_hidden(ext, true)
    end

    hide_weapon(ext, slot)

    S.active = wielded and first_person or false

    if not S.active then
        restore_weapon()
        S.ammo, S.shot_t = nil, nil

        return
    end

    if not per_frame then
        return
    end

    local t = Managers.time:time("gameplay")

    watch_ammo(unit, slot_name, t)

    local clip, clip_t, loop = pick_clip(unit, t, slot_name)

    S.clip, S.clip_t, S.loop = clip, clip_t, loop

    if CONFIG.ranged and not CONFIG.fx_node then
        local cam_r, cam_p, fov = camera_pose()

        if cam_r then
            local ok, err = pcall(place_muzzle, slot, cam_r, cam_p, fov, fpe.first_person_unit and fpe:first_person_unit())

            if not ok then
                report("muzzle", err)
            end
        end
    end
end

-- other players: their weapon stays retail unless the user asks to hide it too (setting third_person_others)
-- Effects that leave from a node of the first-person rig (force staffs: fx_sources._muzzle = "j_leftweaponattach",
-- forcestaff_p2_m1.lua:1066) cannot be moved with the weapon unit. ViewModelTweaker's method moves the whole first-person
-- unit after PlayerUnitFirstPersonExtension.update_unit_position (ViewModelTweaker.lua:193-228: local position + offset,
-- FirstPersonAnimationVariables.update, World.update_unit_and_children). Here the offset is whatever puts that node on
-- MMJ's muzzle point; the rig's arms are hidden while the MMJ weapon is drawn, so only its effects move.
local FirstPersonAnimationVariables = require("scripts/utilities/first_person_animation_variables")

if CONFIG.fx_node then
    mod:hook(CLASS.PlayerUnitFirstPersonExtension, "update_unit_position", function(func, self, unit, dt, t)
        func(self, unit, dt, t)

        if not (S.active and self._is_local_unit and mod:is_enabled()) then
            return
        end

        local ok, err = pcall(function()
            local fp_unit = self._first_person_unit
            local cam_r, cam_p, fov = camera_pose()

            if not (unit_ok(fp_unit) and cam_r and fov and Unit.has_node(fp_unit, CONFIG.fx_node)) then
                return
            end

            local target = muzzle_target(cam_r, cam_p, fov)
            local node_p = Unit.world_position(fp_unit, Unit.node(fp_unit, CONFIG.fx_node))
            local offset = target - node_p

            if Vector3.length(offset) > 1.5 then
                return
            end

            muzzle_check.error_cm = Vector3.length(offset) * 100
            muzzle_check.parent = "first-person rig offset"
            Unit.set_local_position(fp_unit, 1, Unit.local_position(fp_unit, 1) + offset)
            FirstPersonAnimationVariables.update(dt, t, fp_unit, self._unit_data_extension, self._weapon_extension,
                self._state_machine_lerp_values)
            World.update_unit_and_children(self._world, fp_unit)
        end)

        if not ok then
            report("fx node", err)
        end
    end)
end

local function update_other(ext)
    local slot = our_slot(ext)

    if slot then
        if opt("third_person_others", "retail") == "hide" then
            hide(ext, slot.unit_3p)

            for unit in pairs(slot.item_name_by_unit_3p or {}) do
                hide(ext, unit)
            end
        end
    elseif hidden[ext] then
        show_hidden(ext)
    end
end

-- API for the HUD element -------------------------------------------------------------------------------------------------
mod.mmj_weapon = {
    state = function()
        return S
    end,
    rects = function()
        if not S.active or not mod:is_enabled() then
            return nil
        end

        local draws = Overlay.sample(S.clip, S.clip_t or 0, S.loop)

        return draws and Overlay.layout(draws, view()) or nil
    end,
    texture = function(sprite_id)
        local sp = Overlay.data().sprites[sprite_id]

        return sp and Assets.texture(sp.file) or nil
    end,
}

mod:register_hud_element({
    class_name = "HudElementQIangIQsMMJPistol",
    filename = SCRIPTS .. "QIangIQsMMJPistol_hud",
    use_hud_scale = false,
    visibility_groups = { "alive" },
})

-- Hooks --------------------------------------------------------------------------------------------------------------------
local tracked = setmetatable({}, { __mode = "k" })
local busy = false

-- force_update_item_visibility (show_hidden) calls _update_item_visibility, which calls back into this mod
local function run(self, per_frame)
    if busy then
        return
    end

    busy = true

    local ok, err = pcall(self._is_local_unit and update_local or update_other, self, per_frame)

    busy = false

    if not ok then
        report("update", err)
    end
end

for _, class_name in ipairs({ "PlayerUnitVisualLoadoutExtension", "PlayerHuskVisualLoadoutExtension" }) do
    mod:hook_safe(CLASS[class_name], "init", function(self)
        tracked[self] = true
    end)

    mod:hook_safe(CLASS[class_name], "update", function(self)
        if tracked[self] then
            run(self, true)
        end
    end)

    -- the game sets item visibility again here: hide again at once (no one-frame flash)
    mod:hook_safe(CLASS[class_name], "_update_item_visibility", function(self)
        if tracked[self] then
            run(self)
        end
    end)

    mod:hook(CLASS[class_name], "destroy", function(func, self, ...)
        if self._is_local_unit then
            S.active = false
            pcall(restore_weapon)
        end

        tracked[self] = nil
        hidden[self] = nil
        hidden_arms[self] = nil

        return func(self, ...)
    end)
end

local function reset_all()
    S.active = false
    pcall(restore_weapon)

    for ext in pairs(tracked) do
        pcall(show_hidden, ext)
    end
end

-- Other QIangIQ mods that also replace these weapons (the QIangIQsMeleeArsenal claim_template / release_template
-- pattern): switching a weapon on here tells them to let go of it, and they call mod.release_template when they take it.
-- Optional: a mod that is not installed is skipped.
local OTHER_MODS = { "QIangIQsHorizonMaulShields", "QIangIQsDeagle" }

local function claim_template(template)
    for _, name in ipairs(OTHER_MODS) do
        local other = get_mod(name)

        if other and other.release_template then
            other.release_template(template)
        end
    end
end

mod.release_template = function(template)
    if CONFIG.templates[template] and opt("replace_" .. template, true) then
        mod:set("replace_" .. template, false, false)
        reset_all()
        mod:echo("%s is now shown by another QIangIQ mod: switched off in %s.", template, mod:get_name())
    end
end

mod.on_setting_changed = function(setting_id)
    local template = type(setting_id) == "string" and setting_id:match("^replace_(.+)$")

    if template and CONFIG.templates[template] and mod:get(setting_id) then
        claim_template(template)
    end

    reset_all()
end
mod.on_disabled = reset_all

mod:command("mmjpistol", mod:localize("command_desc"), function(arg)
    if arg == "flip" then
        mod:set("flip_rotation", not mod:get("flip_rotation"), false)
        mod:echo("Pistol: sprite rotation sign %s", mod:get("flip_rotation") and "flipped" or "normal")

        return
    end

    local loaded, total = 0, 0

    for _, sp in ipairs(Overlay.data().sprites) do
        total = total + 1

        local tex = Assets.texture(sp.file)

        if tex and tex.texture then
            loaded = loaded + 1
        end
    end

    if CONFIG.ranged then
        mod:echo("Pistol: muzzle off target %s cm (parent from %s)", muzzle_check.error_cm and string.format("%.1f", muzzle_check.error_cm) or "n/a",
            tostring(muzzle_check.parent))
    end

    mod:echo("Pistol: %s, clip %s at %.2f s, sprites loaded %d/%d, assets runtime %s, audio runtime %s",
        S.active and "on screen" or "not held", tostring(S.clip), S.clip_t or 0, loaded, total,
        persist.assets_rt and "ok" or tostring(persist.assets_failed), persist.audio_rt and "ok" or tostring(persist.audio_failed))
end)
