-- QIangIQsMMJPistol per-weapon data (gen.py spec pistol). Clips are MMJ clip names from pistol\OBJ-Weapond-Pistol__20828.
-- Action map sources: Darktide weapon templates (Aussiemon master) via tools\dump_actions.py.
return {
    ranged = true,
    idle = "pistol-idle",
    templates = { stubrevolver_p1_m1 = true, stubrevolver_p1_m2 = true },
    shot = { clips = { "pistol-shot" }, sounds = { "sfx_wp_pistol_shot_01.ogg", "sfx_wp_pistol_shot_03.ogg", "sfx_wp_pistol_shot_04.ogg", "sfx_wp_pistol_shot_05.ogg" } },
    actions = {
        action_wield = { clips = { "pistol- introfast" }, over_shot = true, sounds = { "sfx_wp_pistol_intro.ogg" } },
        action_start_reload = { clips = { "Reload_1Hand" }, stretch = true, reload_template = true, over_shot = true, sounds = { "sfx_wp_pistol_reload_b.ogg" } },
        action_reload_loop = { clips = { "Reload_1Hand" }, stretch = true, over_shot = true, sounds = { "sfx_wp_pistol_reload_b_03.ogg" } },
    },
}
