return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsActionLookupFix` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsActionLookupFix", {
			mod_script       = "QIangIQsActionLookupFix/scripts/mods/QIangIQsActionLookupFix/QIangIQsActionLookupFix",
			mod_data         = "QIangIQsActionLookupFix/scripts/mods/QIangIQsActionLookupFix/QIangIQsActionLookupFix_data",
			mod_localization = "QIangIQsActionLookupFix/scripts/mods/QIangIQsActionLookupFix/QIangIQsActionLookupFix_localization",
		})
	end,
	version = "1.0.0",
	author = "QIangIQ",
	packages = {},
}
