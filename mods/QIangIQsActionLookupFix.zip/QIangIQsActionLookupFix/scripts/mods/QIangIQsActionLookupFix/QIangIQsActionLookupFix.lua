-- Action Lookup Fix
--
-- Several fields of the player state are sent over the network as an index into a list instead of a name:
-- weapon_action.template_name, current_action_name and previous_action_name, the weapon tweak template names,
-- equipped_abilities and the predicted buff names (scripts/extension_systems/unit_data/player_unit_data_component_config.lua).
-- Each list is built from the sorted keys of a settings table (WeaponTemplates, PlayerAbilities, BuffTemplates.PREDICTED)
-- the first time that file is required, at gameplay init. By then other mods have added their own weapons, abilities or
-- buffs, so any new name that sorts before a retail one shifts every later index. The client and an official server
-- then disagree about what an index means. Typical results after a server correction:
--   action_handler.lua:416: attempt to index local 'action_settings' (a nil value)
--   hub_aim_constraints.lua: State machine has no constraint target named ... (hub template decoded as "unarmed")
--   a wrong ability icon / "Error loading material" in the HUD
-- Solo play and the Psykhanium hide it, because there the PC is also the server.
--
-- Fix: when the config file is required, rebuild each list in place: retail entries first, in retail order, then the
-- mod-only entries at the end (so modded content still works where the PC is the server).
-- "Retail" is the state of those tables when this mod loads, so it must load before every mod that adds weapons,
-- abilities or buffs: put it at the top of mod_load_order.txt.
-- Author: QIangIQ
local mod = get_mod("QIangIQsActionLookupFix")

local WeaponTemplates = require("scripts/settings/equipment/weapon_templates/weapon_templates")
local PlayerAbilities = require("scripts/settings/ability/player_abilities/player_abilities")

-- Retail ability list, built the way the config file builds it, from PlayerAbilities as it is when this mod loads.
local RETAIL_ABILITIES = table.keys(PlayerAbilities)

table.sort(RETAIL_ABILITIES)
table.insert(RETAIL_ABILITIES, 1, "none")

-- buff.buff_<i>_template_name are indexes into the sorted names of BuffTemplates.PREDICTED.
local BuffTemplates = require("scripts/settings/buff/buff_templates")
local RETAIL_PREDICTED_BUFFS = {}

for name in pairs(BuffTemplates.PREDICTED) do
	if name ~= "none" then
		RETAIL_PREDICTED_BUFFS[#RETAIL_PREDICTED_BUFFS + 1] = name
	end
end

table.sort(RETAIL_PREDICTED_BUFFS)
table.insert(RETAIL_PREDICTED_BUFFS, 1, "none")

local CONFIG_PATH = "scripts/extension_systems/unit_data/player_unit_data_component_config"
local EXTENSION_PATH = "scripts/extension_systems/unit_data/player_unit_data_extension"

-- Retail snapshot: template name -> sorted action names (same calls as the config file).
local RETAIL = {}
local RETAIL_NAMES = {}
-- template name -> tweak type -> new_identifiers in sorted key order (as _extract_weapon_tweak_template_names reads
-- them). These lists use the same first-appearance order, so they shift too.
local RETAIL_TWEAKS = {}
local TWEAK_TYPES = {}

for name, template in pairs(WeaponTemplates) do
	local action_names = table.keys(template.actions or {})

	table.sort(action_names)

	RETAIL[name] = action_names
	RETAIL_NAMES[#RETAIL_NAMES + 1] = name

	local tweaks = {}
	local base_template_lookup = template.__base_template_lookup or {}

	for tweak_type, tweak_templates in pairs(base_template_lookup) do
		if type(tweak_templates) == "table" then
			local keys = table.keys(tweak_templates)

			table.sort(keys)

			local identifiers = {}

			for i = 1, #keys do
				local entry = tweak_templates[keys[i]]

				identifiers[#identifiers + 1] = type(entry) == "table" and entry.new_identifier or nil
			end

			tweaks[tweak_type] = identifiers
			TWEAK_TYPES[tweak_type] = true
		end
	end

	RETAIL_TWEAKS[name] = tweaks
end

table.sort(RETAIL_NAMES)

-- Same loop as player_unit_data_component_config.lua, on the snapshot.
local function retail_lists()
	local templates = { "none" }
	local actions = { "none" }
	local seen = { none = true }

	for i = 1, #RETAIL_NAMES do
		local name = RETAIL_NAMES[i]

		templates[#templates + 1] = name

		local action_names = RETAIL[name]

		for j = 1, #action_names do
			local action_name = action_names[j]

			if not seen[action_name] then
				seen[action_name] = true
				actions[#actions + 1] = action_name
			end
		end
	end

	return templates, actions
end

local function retail_tweak_list(tweak_type)
	local list = { "none" }
	local seen = { none = true }

	for i = 1, #RETAIL_NAMES do
		local identifiers = RETAIL_TWEAKS[RETAIL_NAMES[i]][tweak_type] or {}

		for j = 1, #identifiers do
			local identifier = identifiers[j]

			if not seen[identifier] then
				seen[identifier] = true
				list[#list + 1] = identifier
			end
		end
	end

	return list
end

-- Bit width rule of unit_data_component_config_formatter.lua.
local function num_bits(size)
	return math.floor(math.log(size) / math.log(2)) + 1
end

-- Rewrites `list` in place: `retail` first, then the entries of `list` that are not in `retail`, in their old order.
local function reorder(list, retail, label)
	local in_retail = {}

	for i = 1, #retail do
		in_retail[retail[i]] = true
	end

	local result = {}

	for i = 1, #retail do
		result[i] = retail[i]
	end

	local extras = {}

	for i = 1, #list do
		local value = list[i]

		if not in_retail[value] then
			result[#result + 1] = value
			extras[#extras + 1] = value
		end
	end

	local old_size = #list
	local changed = old_size ~= #result

	for i = 1, math.max(old_size, #result) do
		if list[i] ~= result[i] then
			changed = true
		end

		list[i] = result[i]
	end

	mod:info("%s: %d entries (retail %d, mod-only %d: %s), %s", label, #list, #retail, #extras, table.concat(extras, ", "), changed and "reordered" or "already in retail order")

	if num_bits(#list) ~= num_bits(#retail) then
		mod:warning("%s: %d entries need %d bits but retail uses %d; the network field type differs from the server's (formatter lookup_Nbit)", label, #list, num_bits(#list), num_bits(#retail))
	end

	return changed
end

-- DMF calls the callback again on later requires of the same file (player_husk_data_extension.lua requires it too,
-- after the first pass), so remember the config table that was already reordered.
local done = setmetatable({}, { __mode = "k" })

mod:hook_require(CONFIG_PATH, function(config)
	if done[config] then
		return
	end

	done[config] = true

	-- The config is first required from inside player_unit_data_extension.lua, and LuaJIT's require puts a
	-- non-table placeholder into package.loaded for a module that is still loading, so only a table means "too late".
	if type(package.loaded[EXTENSION_PATH]) == "table" then
		mod:warning("player_unit_data_extension was formatted before this fix ran; the lists cannot be corrected this session")

		return
	end

	-- equipped_abilities: the three fields share the PLAYER_ABILITIES table
	local equipped_abilities = config.equipped_abilities
	local abilities = equipped_abilities and equipped_abilities.combat_ability

	if type(abilities) == "table" then
		reorder(abilities, RETAIL_ABILITIES, "player abilities")
	else
		mod:warning("equipped_abilities list not found in %s; abilities unchanged", CONFIG_PATH)
	end

	-- every buff_<i>_template_name field shares the PREDICTED_BUFF_TEMPLATES table
	local buff_component = config.buff
	local predicted_buffs = type(buff_component) == "table" and buff_component.buff_1_template_name

	if type(predicted_buffs) == "table" then
		reorder(predicted_buffs, RETAIL_PREDICTED_BUFFS, "predicted buffs")
	else
		mod:warning("buff template list not found in %s; predicted buffs unchanged", CONFIG_PATH)
	end

	local weapon_action = config.weapon_action
	local templates = weapon_action and weapon_action.template_name
	local actions = weapon_action and weapon_action.current_action_name

	if type(templates) ~= "table" or type(actions) ~= "table" then
		mod:warning("weapon_action lists not found in %s; nothing changed", CONFIG_PATH)

		return
	end

	local retail_templates, retail_actions = retail_lists()

	reorder(templates, retail_templates, "weapon templates")
	reorder(actions, retail_actions, "weapon actions")

	-- weapon_tweak_templates.<type>_template_name
	local tweak_component = config.weapon_tweak_templates

	if type(tweak_component) ~= "table" then
		mod:warning("weapon_tweak_templates component not found; tweak lists unchanged")

		return
	end

	for tweak_type in pairs(TWEAK_TYPES) do
		local list = tweak_component[tweak_type .. "_template_name"]

		if type(list) == "table" then
			reorder(list, retail_tweak_list(tweak_type), "tweak " .. tweak_type)
		end
	end
end)

mod:info("retail snapshot: %d weapon templates, %d player abilities, %d predicted buffs", #RETAIL_NAMES, #RETAIL_ABILITIES - 1, #RETAIL_PREDICTED_BUFFS - 1)
