return {
	mod_name = {
		en = "Action Lookup Fix",
	},
	mod_description = {
		en = "Keeps the game's networked weapon, action, ability and buff lists in retail order when mods add new weapons, abilities or buffs. Prevents crashes on official servers such as action_handler.lua:416 'action_settings' (a nil value) and hub_aim_constraints.lua 'State machine has no constraint target'. Put it at the top of mod_load_order.txt.",
	},
}
