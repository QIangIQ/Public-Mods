return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsModelSync` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsModelSync", {
            mod_script = "QIangIQsModelSync/scripts/mods/QIangIQsModelSync/QIangIQsModelSync",
            mod_data = "QIangIQsModelSync/scripts/mods/QIangIQsModelSync/QIangIQsModelSync_data",
            mod_localization = "QIangIQsModelSync/scripts/mods/QIangIQsModelSync/QIangIQsModelSync_localization",
        })
    end,
    version = "2.0.0",
    author = "QIangIQ",
    load_after = { "Vox Manifold", "QIangIQsSyncChannel" },
    require = { "Vox Manifold", "QIangIQsSyncChannel" },
    packages = {},
}
