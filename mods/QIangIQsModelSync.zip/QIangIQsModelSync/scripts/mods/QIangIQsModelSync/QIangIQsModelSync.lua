-- QIangIQ's Model Sync: party members see each other's QIangIQ replacer mods.
--
-- What travels is only "which replacer mod is on, with which options" - never asset data. Each client
-- shows the model from its own files, so my Ember mod draws Ember over a team-mate who runs Ember.
--
-- Transport (2.0): QIangIQsSyncChannel, which spreads the data over 4 Vox Manifold keys (about 1 KB in all instead
-- of one 250-byte key). Three categories: "c" character models, "w" weapons, "i" held items and companion.
-- 1.0 published one key, qiangiq.models; a 1.0 peer and a 2.0 peer do not see each other.
--
-- Only what my current character uses is published: character models of my breed, weapon mods for the weapon
-- templates in my loadout, Paimon with the servo-skull companion (each mod's sync_applies). With no unit
-- (main menu, character select) nothing is published.
--
-- Each replacer mod provides:
--   mod.sync_key              its short key in the payload
--   mod.sync_export(info)     the array to publish for me, or nil when it shows nothing on my character
--   mod.sync_refresh()        re-applies to every unit after someone's options changed
-- and asks this mod for another player's array through api.peer(key, player).
-- Author: QIangIQ
local mod = get_mod("QIangIQsModelSync")

mod.AUTHOR = "QIangIQ"
mod.version = mod.version or "2.0.0"

local POLL_INTERVAL = 1.0

local CATEGORIES = {
    {
        id = "c",
        mods = {
            "QIangIQsAnubis", "QIangIQsDominanceAnubis", "QIangIQsEmber", "QIangIQsCitlali", "QIangIQsYvonne", "QIangIQsKulveTaroth",
            "QIangIQsNavia", "QIangIQsZhuangFangyi", "QIangIQsArknightsEmber", "QIangIQsHornet", "QIangIQsAlienQueen", "QIangIQsAnkha", "QIangIQsValkyrHeirloom", "QIangIQsMesaHeirloom", "QIangIQsCitrinePrime", "QIangIQsOctaviaPrime", "QIangIQsOraxia", "QIangIQsSevagothPrime", "QIangIQsVorunaPrime", "QIangIQsWispPrime", "QIangIQsYareliPrime", "QIangIQsMarieGemini", "QIangIQsEleanorGemini", "QIangIQsJade",
            "QIangIQsHeavy", "QIangIQsDvaMech", "QIangIQsRoadhog", "QIangIQsGrendelPrime", "QIangIQsOgbOgy",
        },
    },
    {
        id = "w",
        mods = {
            "QIangIQsDiamondSword", "QIangIQsGoldenBloodSword", "QIangIQsBismuthRelicBlade", "QIangIQsSkullRuneblade", "QIangIQsBismuthSword",
            "QIangIQsSpearArsenal", "QIangIQsMeleeArsenal", "QIangIQsWarframeArsenal", "QIangIQsHorizonStaffs", "QIangIQsPrototype", "QIangIQsVerdictAxe", "QIangIQsSteelKanabo", "QIangIQsButterflyKnife", "QIangIQsKarambit", "QIangIQsAWP",
        },
    },
    {
        id = "i",
        mods = { "QIangIQsMakimaBean", "QIangIQsPaimon" },
    },
}

local MODS = {}
for c = 1, #CATEGORIES do
    for i = 1, #CATEGORIES[c].mods do
        MODS[#MODS + 1] = CATEGORIES[c].mods[i]
    end
end

local Sync = {
    channel = nil,
    unsubscribe = nil,
    loaded = false,
    peers = {},   -- [account_id] = { [mod key] = published array }
    poll_now = true,
    poll_timer = 0,
    my_signature = nil,
}

local function local_player()
    local players = Managers.player
    if not players then
        return nil
    end
    local ok, player = pcall(players.local_player_safe, players, 1)
    return ok and player or nil
end

-- My own character as the replacer mods need it: breed, companion breed and the weapon templates in my
-- equipment (player_unit_visual_loadout_extension.lua keeps _static_profile_properties and _equipment;
-- equipment_component.lua reads item.weapon_template). nil while I have no unit.
local function local_info()
    local player = local_player()
    local unit = player and player.player_unit
    if not unit or not Unit.alive(unit) then
        return nil
    end
    local ext = ScriptUnit.has_extension(unit, "visual_loadout_system")
    if not ext then
        return nil
    end
    local props = ext._static_profile_properties
    local templates = {}
    if ext._equipment then
        for _, slot in pairs(ext._equipment) do
            local item = slot.item
            if item and item.weapon_template then
                templates[item.weapon_template] = true
            end
        end
    end
    return {
        breed = props and props.breed,
        companion_breed = props and props.companion_breed,
        templates = templates,
    }
end

local function info_signature(info)
    if not info then
        return "none"
    end
    local names = {}
    for name in pairs(info.templates) do
        names[#names + 1] = name
    end
    table.sort(names)
    return tostring(info.breed) .. "|" .. tostring(info.companion_breed) .. "|" .. table.concat(names, ",")
end

-- Builder for one category. Must stay free of side effects: Vox Manifold may call it at any time.
local function builder_for(category)
    return function()
        if not mod:get("share_my_models") then
            return nil
        end
        local info = local_info()
        if not info then
            return nil
        end
        local out, any = {}, false
        for i = 1, #category.mods do
            local other = get_mod(category.mods[i])
            if other and other.sync_key and other.sync_export then
                local ok, value = pcall(other.sync_export, info)
                if ok and value ~= nil then
                    out[other.sync_key] = value
                    any = true
                end
            end
        end
        return any and out or nil
    end
end

local function same(a, b)
    if type(a) ~= type(b) then
        return false
    end
    if type(a) ~= "table" then
        return a == b
    end
    for k, v in pairs(a) do
        if not same(v, b[k]) then
            return false
        end
    end
    for k in pairs(b) do
        if a[k] == nil then
            return false
        end
    end
    return true
end

local function refresh_all()
    for i = 1, #MODS do
        local other = get_mod(MODS[i])
        if other and other.sync_refresh then
            pcall(other.sync_refresh)
        end
    end
end

local function process_members()
    local channel = Sync.channel
    if not channel then
        return
    end
    local seen, changed = {}, false
    for account_id, entry in pairs(channel.roster()) do
        if entry.data then
            seen[account_id] = true
            local merged = {}
            for c = 1, #CATEGORIES do
                local bucket = entry.data[CATEGORIES[c].id]
                if type(bucket) == "table" then
                    for key, value in pairs(bucket) do
                        merged[key] = value
                    end
                end
            end
            -- keep the stored table while nothing changed: the replacer mods cache what they decode from it
            if not same(Sync.peers[account_id], merged) then
                Sync.peers[account_id] = merged
                changed = true
            end
        end
    end
    for account_id in pairs(Sync.peers) do
        if not seen[account_id] then
            Sync.peers[account_id] = nil
            changed = true
        end
    end
    if changed then
        refresh_all()
    end
end

-- API for the replacer mods ----------------------------------------------------------
mod.api = {}

-- The array another player published for one replacer mod, or nil (not sharing it, not running this mod, not
-- in my party, or showing is switched off).
mod.api.peer = function(key, player)
    if not Sync.channel or not mod:get("show_others_models") then
        return nil
    end
    if not player or not player.remote or not player.account_id then
        return nil
    end
    local ok, account_id = pcall(player.account_id, player)
    local entries = ok and account_id and Sync.peers[account_id]
    return entries and entries[key] or nil
end

-- one of my replacer mods changed an option
mod.api.changed = function()
    if Sync.channel then
        Sync.channel.mark_dirty()
    end
end

-- Lifecycle --------------------------------------------------------------------------
local function start()
    local host = get_mod("QIangIQsSyncChannel")
    local channel = host and host.api
    if not channel then
        mod:info("[Model Sync] QIangIQsSyncChannel not found; model sharing is off.")
        return
    end
    for c = 1, #CATEGORIES do
        channel.provide("modelsync", CATEGORIES[c].id, builder_for(CATEGORIES[c]))
    end
    Sync.channel = channel
    Sync.unsubscribe = channel.on_change(function()
        Sync.poll_now = true
    end)
    Sync.poll_now = true
end

local function stop()
    if Sync.channel then
        Sync.channel.withdraw("modelsync")
    end
    if Sync.unsubscribe then
        Sync.unsubscribe()
    end
    Sync.channel, Sync.unsubscribe = nil, nil
    Sync.peers = {}
    refresh_all()
end

-- DMF calls on_all_mods_loaded in reverse load order (dmf_mod_manager.lua:43), so the channel may not have
-- registered with Vox Manifold yet; it keeps the builders and publishes them once it starts
mod.on_all_mods_loaded = function()
    Sync.loaded = true
    start()
end

mod.update = function(dt)
    if not Sync.channel then
        return
    end
    Sync.poll_timer = Sync.poll_timer + (dt or 0)
    if Sync.poll_now or Sync.poll_timer >= POLL_INTERVAL then
        Sync.poll_now = false
        Sync.poll_timer = 0
        process_members()
        -- my character or the weapons I carry changed: publish again
        local signature = info_signature(local_info())
        if signature ~= Sync.my_signature then
            Sync.my_signature = signature
            Sync.channel.mark_dirty()
        end
    end
end

mod.on_setting_changed = function(setting_id)
    if setting_id == "share_my_models" then
        mod.api.changed()
    elseif setting_id == "show_others_models" then
        refresh_all()
    end
end

mod.on_unload = function()
    stop()
end

mod.on_disabled = function()
    stop()
end

mod.on_enabled = function()
    if Sync.loaded and not Sync.channel then
        start()
    end
end

local function installed(key)
    for i = 1, #MODS do
        local other = get_mod(MODS[i])
        if other and other.sync_key == key then
            return true
        end
    end
    return false
end

mod:command("modelsync", "Show which QIangIQ model swaps are shared and received", function()
    if not Sync.channel or not Sync.channel.active() then
        mod:echo("Model Sync: off (QIangIQsSyncChannel or Vox Manifold missing?)")
        return
    end
    mod:echo("Model Sync: sharing %s, showing others %s", mod:get("share_my_models") and "on" or "off", mod:get("show_others_models") and "on" or "off")
    local mine = {}
    for c = 1, #CATEGORIES do
        local values = builder_for(CATEGORIES[c])()
        if values then
            for key in pairs(values) do
                mine[#mine + 1] = key
            end
        end
    end
    table.sort(mine)
    local report = Sync.channel.report()
    local shed = {}
    for i = 1, #report.shed do
        shed[#shed + 1] = report.shed[i]
    end
    mod:echo("  me: %s%s", #mine > 0 and table.concat(mine, ", ") or "nothing",
        #shed > 0 and ("; left out, no room: " .. table.concat(shed, ", ")) or "")
    local any = false
    for account_id, entry in pairs(Sync.channel.roster()) do
        any = true
        local keys = {}
        local entries = Sync.peers[account_id]
        if entries then
            for key in pairs(entries) do
                keys[#keys + 1] = installed(key) and key or (key .. " (not installed here)")
            end
            table.sort(keys)
        end
        mod:echo("  %s: %s", entry.name, entry.running and (#keys > 0 and table.concat(keys, ", ") or "shares no model swaps") or "does not run Sync Channel")
    end
    if not any then
        mod:echo("  no other party members")
    end
end)
