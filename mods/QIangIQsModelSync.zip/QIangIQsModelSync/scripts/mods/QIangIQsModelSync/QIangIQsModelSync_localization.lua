return {
    mod_name = {
        en = "QIangIQ's Model Sync",
    },
    mod_description = {
        en = "Party members who run this mod see each other's QIangIQ model swaps (characters, weapons, held items, servo-skull). Only the choice of mod and its options is sent, through QIangIQ's Sync Channel (Vox Manifold); every client shows the model from its own installed files, so a model only appears on machines that have that mod installed and patched. By QIangIQ.",
    },
    share_my_models = {
        en = "Share my model swaps with my party",
    },
    share_my_models_description = {
        en = "Publishes which QIangIQ replacer mods are on for the character and weapons you are carrying, with their options. Off = party members see your normal character.",
    },
    show_others_models = {
        en = "Show party members' model swaps",
    },
    show_others_models_description = {
        en = "Shows the models party members have shared on their characters, from your own installed copies of those mods. Off = everyone else looks normal. Chat command: /modelsync shows what is shared and received.",
    },
}
