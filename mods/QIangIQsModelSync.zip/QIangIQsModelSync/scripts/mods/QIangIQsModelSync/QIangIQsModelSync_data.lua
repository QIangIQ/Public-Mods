local mod = get_mod("QIangIQsModelSync")

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = true,
    options = {
        widgets = {
            {
                setting_id = "share_my_models",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "show_others_models",
                type = "checkbox",
                default_value = true,
            },
        },
    },
}
