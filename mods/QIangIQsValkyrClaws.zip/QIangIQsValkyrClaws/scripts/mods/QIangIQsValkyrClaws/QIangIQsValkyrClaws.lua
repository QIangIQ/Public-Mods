-- QIangIQ's Valkyr Claws: Valkyr Prime's Hysteria energy claws (Warframe, taken from your own install, personal use;
-- Custom Assets) on your hands while the Chordclaw (Cryptic's combat ability: cryptic_chordclaw.lua wields the item
-- content/items/weapons/player/melee/transonic_claw_p1_m1, weapon template "transonic_claw_p1_m1") is in hand.
-- Units built by D:\WarframeRip\claws\build_claws.py in the Darktide hand joint's own frame: linked to j_lefthand /
-- j_righthand with an identity local pose, in third person (player unit) and first person (first-person unit; hand
-- bones have the same local axes in 1P and 3P). The game's own claw units are hidden while ours show.
-- Engine calls as the QIangIQ character mods use them (spawn_unit + World.link_unit, set_unit_culling,
-- set_shader_pass_flag_for_meshes_in_unit_and_childs "custom_fov", set_vector3 / set_scalar_for_materials).
-- Author: QIangIQ
local mod = get_mod("QIangIQsValkyrClaws")

local TEMPLATE = "transonic_claw_p1_m1"
local UNITS = { left = "valkyrclaw_prime_left", right = "valkyrclaw_prime_right" }
local ASSET_DIR = "content/mods/qiangiq_valkyrclaws/"
-- emissive_color presets (the claws' emission picture is grey; this is its colour)
local COLORS = {
    valkyr = { 1, 0.42, 0.04 },
    red = { 1, 0.04, 0.04 },
    cyan = { 0, 0.85, 1 },
    pink = { 1, 0.08, 0.55 },
    green = { 0.15, 1, 0.2 },
    gold = { 1, 0.69, 0.06 },
    purple = { 0.55, 0.15, 1 },
    white = { 1, 1, 1 },
}

local custom_assets = nil
local ready = {}
local tracked = setmetatable({}, { __mode = "k" })
local find_claw_slot -- defined below

local function unit_ok(u)
    return u ~= nil and Unit.alive(u)
end

local function local_player()
    local players = Managers.player
    if not players then
        return nil
    end
    local ok, p = pcall(players.local_player_safe, players, 1)
    return ok and p or nil
end

local function component(unit, name)
    local ude = unit_ok(unit) and ScriptUnit.has_extension(unit, "unit_data_system")
    if not ude then
        return nil
    end
    local ok, c = pcall(ude.read_component, ude, name)
    return ok and c or nil
end

local function hands()
    local h = mod:get("hands") or "both"
    return { left = h ~= "right", right = h ~= "left" }
end

local function delete_unit(u)
    if unit_ok(u) then
        local spawner = Managers.state and Managers.state.unit_spawner
        if spawner then
            spawner:mark_for_deletion(u)
        end
    end
end

local function despawn(ext)
    local rec = ext.__qiangiq_vclaw
    if rec then
        for _, u in pairs(rec.units) do
            delete_unit(u)
        end
        ext.__qiangiq_vclaw = nil
        if rec.hidden and ext.force_update_item_visibility then
            pcall(ext.force_update_item_visibility, ext)
        end
    end
end

local function spawn_on(ext, parent, node_name, unit_key, first_person)
    local world = ext.__qiangiq_vclaw_world
    local spawner = Managers.state and Managers.state.unit_spawner
    if not (world and spawner and unit_ok(parent) and Unit.has_node(parent, node_name)) then
        return nil
    end
    local node = Unit.node(parent, node_name)
    local u = spawner:spawn_unit(ASSET_DIR .. UNITS[unit_key], Unit.world_pose(parent, node))
    if not u then
        return nil
    end
    if first_person then
        Unit.set_unit_culling(u, false)
        -- 1P items are drawn with the first-person FOV (equipment_component.lua:359)
        Unit.set_shader_pass_flag_for_meshes_in_unit_and_childs(u, "custom_fov", true)
    end
    World.link_unit(world, u, 1, parent, node)
    return u
end

local function style(u)
    local c = COLORS[mod:get("color") or "valkyr"] or COLORS.valkyr
    Unit.set_vector3_for_materials(u, "emissive_color", Vector3(c[1], c[2], c[3]), true)
    Unit.set_scalar_for_materials(u, "intensity", mod:get("brightness") or 1, true)
    local s = math.max(mod:get("size") or 1, 0.1)
    Unit.set_local_scale(u, 1, Vector3(s, s, s))
end

local function set_visibility(u, visible)
    if unit_ok(u) then
        Unit.set_unit_visibility(u, visible, true)
    end
end

-- the game's own claw (and its attachments) hidden while ours show
local function hide_original(slot)
    for _, key in ipairs({ "unit_3p", "unit_1p" }) do
        local u = slot[key]
        if unit_ok(u) then
            Unit.set_unit_visibility(u, false, true)
            local by = slot[key == "unit_3p" and "attachments_by_unit_3p" or "attachments_by_unit_1p"]
            for _, a in ipairs(by and by[u] or {}) do
                set_visibility(a, false)
            end
        end
    end
end

-- the Chordclaw: the ability equips its item (content/items/weapons/player/melee/transonic_claw_p1_m1) into the
-- combat-ability slot and wields "slot_combat_ability" (player_unit_ability_extension.lua _equip_ability,
-- action_cryptic_chordclaw.lua). In game 2026-10-07 matching weapon_template alone found nothing: the item name and
-- the slot are matched too
local function item_matches(item)
    if not item then
        return false
    end
    for _, key in ipairs({ "weapon_template", "name", "__master_item_name" }) do
        local v = item[key]
        if type(v) == "string" and string.find(v, "transonic_claw", 1, true) then
            return true
        end
    end
    return false
end

find_claw_slot = function(ext, inv)
    local eq = ext._equipment or {}
    for name, s in pairs(eq) do
        if item_matches(s.item) then
            return name, s
        end
    end
    -- whatever the combat-ability slot holds while it is wielded and has its own units (the Chordclaw is the only
    -- combat ability that is a wielded item with units in the source's ability list: inventory_item_name)
    local s = eq.slot_combat_ability
    if s and inv and inv.wielded_slot == "slot_combat_ability" and (unit_ok(s.unit_1p) or unit_ok(s.unit_3p)) then
        return "slot_combat_ability", s
    end
    return nil
end

local function update(ext)
    local player_unit = ext._unit
    if not (mod:get("enabled") ~= false and ext._player ~= nil and ext._player == local_player()) then
        despawn(ext)
        return
    end
    local inv = component(player_unit, "inventory")
    local slot_name, slot = find_claw_slot(ext, inv)
    local wielded = slot and inv and inv.wielded_slot == slot_name
    if not wielded or not (ready[UNITS.left] and ready[UNITS.right]) then
        despawn(ext)
        return
    end
    local rec = ext.__qiangiq_vclaw
    local h = hands()
    local gen = (mod:get("hands") or "both") .. "|" .. tostring(mod.__vclaw_gen)
    if rec and rec.gen ~= gen then
        despawn(ext)
        rec = nil
    end
    if not rec then
        rec = { units = {}, gen = gen }
        ext.__qiangiq_vclaw = rec
        for _, side in ipairs({ "left", "right" }) do
            if h[side] then
                rec.units[side .. "_3p"] = spawn_on(ext, player_unit, "j_" .. side .. "hand", side, false)
                rec.units[side .. "_1p"] = spawn_on(ext, ext._first_person_unit, "j_" .. side .. "hand", side, true)
            end
        end
        for _, u in pairs(rec.units) do
            if unit_ok(u) then
                style(u)
            end
        end
    end
    rec.slot = slot
    if mod:get("hide_original") ~= false then
        hide_original(slot)
        rec.hidden = true
    end
    local fp = ext.__qiangiq_vclaw_fp and true or false
    for key, u in pairs(rec.units) do
        set_visibility(u, (key:sub(-2) == "1p") == fp)
    end
end

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "init", function(self, extension_init_context)
    self.__qiangiq_vclaw_world = extension_init_context and extension_init_context.world
end)

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "_update_item_visibility", function(self, first_person_mode)
    self.__qiangiq_vclaw_fp = first_person_mode and true or false
    tracked[self] = true
    -- the game sets its own item visibility here: hide its claw again right after
    local rec = self.__qiangiq_vclaw
    if rec and rec.hidden and rec.slot then
        pcall(hide_original, rec.slot)
    end
end)

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "update", function(self)
    local ok, err = pcall(update, self)
    if not ok then
        mod:error("update failed: %s", tostring(err))
        despawn(self)
    end
end)

mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, "destroy", function(func, self, ...)
    despawn(self)
    tracked[self] = nil
    return func(self, ...)
end)

local function refresh_all()
    mod.__vclaw_gen = (mod.__vclaw_gen or 0) + 1
end

mod.on_setting_changed = function()
    refresh_all()
end

mod.on_all_mods_loaded = function()
    custom_assets = get_mod("CustomAssets")
    if not custom_assets or not custom_assets.is_api_compatible or not custom_assets.is_api_compatible(1) then
        mod:error("Custom Assets (API 1) is missing. Install it and put it above QIangIQsValkyrClaws in mod_load_order.txt.")
        return
    end
    for _, name in pairs(UNITS) do
        local id = "QIangIQsValkyrClaws:" .. name
        local ticket, err = custom_assets.acquire(mod, id, function(_, _, load_error)
            if load_error then
                mod:error("%s failed to load: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", id, tostring(load_error))
                return
            end
            ready[name] = true
        end, { resident = true, reference_name = id })
        if not ticket then
            mod:error("%s could not be requested: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", id, tostring(err))
        end
    end
end

mod.on_disabled = function()
    for ext in pairs(tracked) do
        despawn(ext)
    end
end

mod.on_unload = function()
    for ext in pairs(tracked) do
        despawn(ext)
    end
    if custom_assets and custom_assets.release_owner then
        custom_assets.release_owner(mod)
    end
end

local function debug_dump()
    local p = local_player()
    local unit = p and p.player_unit
    local ext = unit and ScriptUnit.has_extension(unit, "visual_loadout_system")
    local inv = component(unit, "inventory")
    mod:echo("wielded slot: %s, assets ready: %s / %s", tostring(inv and inv.wielded_slot), tostring(ready[UNITS.left]),
        tostring(ready[UNITS.right]))
    for name, s in pairs(ext and ext._equipment or {}) do
        local it = s.item
        mod:info("slot %s: name %s, weapon_template %s, unit_1p %s, unit_3p %s", name, tostring(it and it.name),
            tostring(it and it.weapon_template), tostring(unit_ok(s.unit_1p)), tostring(unit_ok(s.unit_3p)))
    end
    local sn = ext and find_claw_slot(ext, inv)
    mod:echo("claw slot found: %s, claws shown: %s (slot list in the console log)", tostring(sn), tostring(ext and ext.__qiangiq_vclaw ~= nil))
end

mod:command("valkyrclaws", "Valkyr Claws: /valkyrclaws (on / off), /valkyrclaws debug", function(arg)
    if arg == "debug" then
        debug_dump()
        return
    end
    mod:set("enabled", mod:get("enabled") == false, true)
    mod:echo("Valkyr Claws %s", mod:get("enabled") == false and "off" or "on")
end)
