return {
    mod_name = {
        en = "QIangIQ's Valkyr Claws",
    },
    mod_description = {
        en = "Valkyr Prime's Hysteria energy claws (Warframe, from your own install; Custom Assets) on your hands while the Cryptic's Chordclaw is in hand, in first and third person. Colour, brightness and size options. Command: /valkyrclaws. Personal use only. By QIangIQ.",
    },
    enabled = {
        en = "Show Valkyr claws",
    },
    enabled_description = {
        en = "While the Chordclaw is in hand, the game's claw is hidden and Valkyr's energy claws show on your hands.",
    },
    hands = {
        en = "Hands",
    },
    hands_description = {
        en = "Which hands get a claw.",
    },
    hands_both = {
        en = "Both hands",
    },
    hands_right = {
        en = "Right hand only",
    },
    hands_left = {
        en = "Left hand only",
    },
    color = {
        en = "Claw colour",
    },
    color_description = {
        en = "Colour of the energy. Valkyr = her Prime's own orange.",
    },
    color_valkyr = {
        en = "Valkyr (orange)",
    },
    color_red = {
        en = "Red",
    },
    color_cyan = {
        en = "Cyan",
    },
    color_pink = {
        en = "Pink",
    },
    color_green = {
        en = "Green",
    },
    color_gold = {
        en = "Gold",
    },
    color_purple = {
        en = "Purple",
    },
    color_white = {
        en = "White",
    },
    brightness = {
        en = "Glow brightness",
    },
    brightness_description = {
        en = "1 = as built. 0 = no glow.",
    },
    size = {
        en = "Size",
    },
    size_description = {
        en = "1 = Valkyr's claws at Darktide hand size.",
    },
    hide_original = {
        en = "Hide the game's claw",
    },
    hide_original_description = {
        en = "Off = the game's own claw stays visible too.",
    },
}
