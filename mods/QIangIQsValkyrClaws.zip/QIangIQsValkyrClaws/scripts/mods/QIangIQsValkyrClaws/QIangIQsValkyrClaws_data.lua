local mod = get_mod("QIangIQsValkyrClaws")

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = true,
    options = {
        widgets = {
            {
                setting_id = "enabled",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "hands",
                type = "dropdown",
                default_value = "both",
                options = {
                    { text = "hands_both", value = "both" },
                    { text = "hands_right", value = "right" },
                    { text = "hands_left", value = "left" },
                },
            },
            {
                setting_id = "color",
                type = "dropdown",
                default_value = "valkyr",
                options = {
                    { text = "color_valkyr", value = "valkyr" },
                    { text = "color_red", value = "red" },
                    { text = "color_cyan", value = "cyan" },
                    { text = "color_pink", value = "pink" },
                    { text = "color_green", value = "green" },
                    { text = "color_gold", value = "gold" },
                    { text = "color_purple", value = "purple" },
                    { text = "color_white", value = "white" },
                },
            },
            {
                setting_id = "brightness",
                type = "numeric",
                default_value = 1,
                range = { 0, 4 },
                decimals_number = 2,
            },
            {
                setting_id = "size",
                type = "numeric",
                default_value = 1,
                range = { 0.3, 2.5 },
                decimals_number = 2,
            },
            {
                setting_id = "hide_original",
                type = "checkbox",
                default_value = true,
            },
        },
    },
}
