return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsValkyrClaws` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsValkyrClaws", {
            mod_script = "QIangIQsValkyrClaws/scripts/mods/QIangIQsValkyrClaws/QIangIQsValkyrClaws",
            mod_data = "QIangIQsValkyrClaws/scripts/mods/QIangIQsValkyrClaws/QIangIQsValkyrClaws_data",
            mod_localization = "QIangIQsValkyrClaws/scripts/mods/QIangIQsValkyrClaws/QIangIQsValkyrClaws_localization",
        })
    end,
    version = "1.0.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
