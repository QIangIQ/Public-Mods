return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsYvonne` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsYvonne", {
            mod_script = "QIangIQsYvonne/scripts/mods/QIangIQsYvonne/QIangIQsYvonne",
            mod_data = "QIangIQsYvonne/scripts/mods/QIangIQsYvonne/QIangIQsYvonne_data",
            mod_localization = "QIangIQsYvonne/scripts/mods/QIangIQsYvonne/QIangIQsYvonne_localization",
        })
    end,
    version = "1.3.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
