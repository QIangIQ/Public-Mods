local mod = get_mod("QIangIQsYvonne")

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = true,
    options = {
        widgets = {
            {
                setting_id = "model_enabled",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "hide_body",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "first_person_arms",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "menu_previews",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "parts_group",
                type = "group",
                sub_widgets = {
                    {
                        setting_id = "part_jacket",
                        type = "checkbox",
                        default_value = true,
                    },
                    {
                        setting_id = "part_gear",
                        type = "checkbox",
                        default_value = true,
                    },
                    {
                        setting_id = "part_horns",
                        type = "checkbox",
                        default_value = true,
                    },
                    {
                        setting_id = "part_neon",
                        type = "checkbox",
                        default_value = true,
                    },
                    {
                        setting_id = "neon_glow",
                        type = "numeric",
                        default_value = 3,
                        range = { 0, 30 },
                        decimals_number = 1,
                    },
                    {
                        setting_id = "neon_color",
                        type = "dropdown",
                        default_value = "cyan",
                        options = {
                            { text = "color_cyan", value = "cyan" },
                            { text = "color_pink", value = "pink" },
                            { text = "color_green", value = "green" },
                            { text = "color_gold", value = "gold" },
                            { text = "color_purple", value = "purple" },
                            { text = "color_red", value = "red" },
                            { text = "color_white", value = "white" },
                        },
                    },
                },
            },
            {
                setting_id = "physics_group",
                type = "group",
                sub_widgets = {
                    {
                        setting_id = "jiggle",
                        type = "checkbox",
                        default_value = true,
                    },
                    {
                        setting_id = "jiggle_breast",
                        type = "numeric",
                        default_value = 1,
                        range = { 0, 3 },
                        decimals_number = 2,
                    },
                    {
                        setting_id = "jiggle_butt",
                        type = "numeric",
                        default_value = 1,
                        range = { 0, 3 },
                        decimals_number = 2,
                    },
                    {
                        setting_id = "jiggle_tail",
                        type = "numeric",
                        default_value = 1,
                        range = { 0, 3 },
                        decimals_number = 2,
                    },
                    {
                        setting_id = "jiggle_hair",
                        type = "numeric",
                        default_value = 1,
                        range = { 0, 3 },
                        decimals_number = 2,
                    },
                    {
                        setting_id = "jiggle_cloth",
                        type = "numeric",
                        default_value = 1,
                        range = { 0, 3 },
                        decimals_number = 2,
                    },
                    {
                        setting_id = "jiggle_stiffness",
                        type = "numeric",
                        default_value = 1,
                        range = { 0.25, 3 },
                        decimals_number = 2,
                    },
                    {
                        setting_id = "jiggle_damping",
                        type = "numeric",
                        default_value = 1,
                        range = { 0.25, 3 },
                        decimals_number = 2,
                    },
                    {
                        setting_id = "jiggle_limit",
                        type = "numeric",
                        default_value = 1,
                        range = { 0.25, 3 },
                        decimals_number = 2,
                    },
                    {
                        setting_id = "jiggle_hang",
                        type = "numeric",
                        default_value = 0.15,
                        range = { 0, 1 },
                        decimals_number = 2,
                    },
                },
            },
            {
                setting_id = "tail_group",
                type = "group",
                sub_widgets = {
                    {
                        setting_id = "tail_custom",
                        type = "checkbox",
                        default_value = false,
                    },
                    {
                        setting_id = "tail_length",
                        type = "numeric",
                        default_value = 1,
                        range = { 1, 3 },
                        decimals_number = 2,
                    },
                    {
                        setting_id = "tail_thickness",
                        type = "numeric",
                        default_value = 1,
                        range = { 1, 3 },
                        decimals_number = 2,
                    },
                },
            },
            {
                setting_id = "toggle_keybind",
                type = "keybind",
                default_value = {},
                keybind_trigger = "pressed",
                keybind_type = "function_call",
                function_name = "toggle_model",
            },
        },
    },
}
