return {
    mod_name = {
        en = "QIangIQ's Yvonne",
    },
    mod_description = {
        en = "Replaces your own human character with the Yvonne model (Custom Assets): third person, first-person arms and menu previews, clothing parts that can be switched on and off, neon highlights, and physics on her tail, twin tails, side locks, thigh strap, chest and hips. Only one QIangIQ human character model is shown at a time. By QIangIQ.",
    },
    model_enabled = {
        en = "Show the Yvonne model",
    },
    model_enabled_description = {
        en = "Turning this on switches the other QIangIQ human character models off. Chat command: /yvonne",
    },
    hide_body = {
        en = "Hide original body and cosmetics",
    },
    hide_body_description = {
        en = "Hides your character's body, face, hair and gear slots while the model is shown. Weapons stay visible.",
    },
    first_person_arms = {
        en = "Model arms in first person",
    },
    first_person_arms_description = {
        en = "Replaces the first-person arms and gloves with the model's arms (and the arm pieces of the clothing parts that are on).",
    },
    menu_previews = {
        en = "Show in menus (operative select, inventory)",
    },
    menu_previews_description = {
        en = "Shows the model on your own operatives in menu previews. Other players' characters are left alone. Ogryns are never replaced.",
    },
    parts_group = {
        en = "Clothing parts",
    },
    part_jacket = {
        en = "Jacket (sleeves and shoulder flaps)",
    },
    part_jacket_description = {
        en = "Show this part. Off = the part is removed from the model (third person, first-person arms and menus).",
    },
    part_gear = {
        en = "Belts, pouches and thigh strap",
    },
    part_gear_description = {
        en = "Show this part. Off = the part is removed from the model (third person, first-person arms and menus).",
    },
    part_horns = {
        en = "Horns and hair ornaments",
    },
    part_horns_description = {
        en = "Show this part. Off = the part is removed from the model (third person, first-person arms and menus).",
    },
    part_neon = {
        en = "Neon highlights",
    },
    part_neon_description = {
        en = "Show this part. Off = the part is removed from the model (third person, first-person arms and menus).",
    },
    neon_glow = {
        en = "Neon brightness",
    },
    neon_glow_description = {
        en = "Brightness of the glowing layer over the teal piping and the yellow and orange markers of the clothing (boots, sleeves, belt). 3 = as built, 0 = no glow.",
    },
    neon_color = {
        en = "Neon colour",
    },
    neon_color_description = {
        en = "Colour of the glow.",
    },
    color_cyan = {
        en = "Cyan",
    },
    color_pink = {
        en = "Pink",
    },
    color_green = {
        en = "Green",
    },
    color_gold = {
        en = "Gold",
    },
    color_purple = {
        en = "Purple",
    },
    color_red = {
        en = "Red",
    },
    color_white = {
        en = "White",
    },
    tail_group = {
        en = "Tail size",
    },
    tail_custom = {
        en = "Custom tail size",
    },
    tail_custom_description = {
        en = "Applies the two sliders below. Off = the tail as modelled.",
    },
    tail_length = {
        en = "Tail length",
    },
    tail_length_description = {
        en = "1 = as modelled, up to 3 times as long. A long tail reaches the floor.",
    },
    tail_thickness = {
        en = "Tail thickness",
    },
    tail_thickness_description = {
        en = "1 = as modelled, up to 3 times as thick.",
    },
    physics_group = {
        en = "Physics",
    },
    jiggle = {
        en = "Physics on",
    },
    jiggle_description = {
        en = "The model's own physics bones swing and settle when you move, jump, dodge or slide (third person and menu previews). Off = everything stays on the rest pose.",
    },
    jiggle_breast = {
        en = "Amount: breasts",
    },
    jiggle_breast_description = {
        en = "1 = as built. Higher = looser and wider swings, lower = tighter. 0 = this area does not move.",
    },
    jiggle_butt = {
        en = "Amount: butt",
    },
    jiggle_butt_description = {
        en = "1 = as built. Higher = looser and wider swings, lower = tighter. 0 = this area does not move.",
    },
    jiggle_tail = {
        en = "Amount: tail",
    },
    jiggle_tail_description = {
        en = "1 = as built. Higher = looser and wider swings, lower = tighter. 0 = this area does not move.",
    },
    jiggle_hair = {
        en = "Amount: hair",
    },
    jiggle_hair_description = {
        en = "1 = as built. Higher = looser and wider swings, lower = tighter. 0 = this area does not move.",
    },
    jiggle_cloth = {
        en = "Amount: clothing and chains",
    },
    jiggle_cloth_description = {
        en = "1 = as built. Higher = looser and wider swings, lower = tighter. 0 = this area does not move.",
    },
    jiggle_stiffness = {
        en = "Stiffness (all areas)",
    },
    jiggle_stiffness_description = {
        en = "How hard everything is pulled back to its rest pose. 1 = as built. Higher = snaps back faster, lower = softer and slower.",
    },
    jiggle_damping = {
        en = "Damping (all areas)",
    },
    jiggle_damping_description = {
        en = "How quickly the wobble dies out. 1 = as built. Higher = settles at once, lower = keeps bouncing longer.",
    },
    jiggle_limit = {
        en = "Swing limit (all areas)",
    },
    jiggle_limit_description = {
        en = "Scales the largest angle a bone may swing away from its rest pose. 1 = as built.",
    },
    jiggle_hang = {
        en = "Hang (hair and clothing)",
    },
    jiggle_hang_description = {
        en = "How strongly hair and loose clothing are drawn straight down instead of keeping their modelled direction when you lean or look up and down. 0 = keep the modelled shape.",
    },
    toggle_keybind = {
        en = "Toggle Yvonne model",
    },
}
