return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsBoltgunPowerSword` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsBoltgunPowerSword", {
            mod_script = "QIangIQsBoltgunPowerSword/scripts/mods/QIangIQsBoltgunPowerSword/QIangIQsBoltgunPowerSword",
            mod_data = "QIangIQsBoltgunPowerSword/scripts/mods/QIangIQsBoltgunPowerSword/QIangIQsBoltgunPowerSword_data",
            mod_localization = "QIangIQsBoltgunPowerSword/scripts/mods/QIangIQsBoltgunPowerSword/QIangIQsBoltgunPowerSword_localization",
        })
    end,
    version = "0.1.0",
    author = "QIangIQ",
    packages = {},
}
