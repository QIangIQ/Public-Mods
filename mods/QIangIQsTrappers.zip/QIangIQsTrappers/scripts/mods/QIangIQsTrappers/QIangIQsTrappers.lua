-- QIangIQsTrappers 0.1.0
-- Overlay for the Trapper (breed renegade_netgunner): target, net loaded, current action, ranges, net flight.
-- Standalone: needs only DMF.
--
-- Every number below is copied from the game source (Aussiemon/Darktide-Source-Code master, matches the live game):
--   scripts/settings/breed/breed_actions/renegade/renegade_netgunner_actions.lua      (approach_target, shoot_net, reload, run_away)
--   scripts/extension_systems/behavior/trees/renegade/renegade_netgunner_behavior_tree.lua
--   scripts/extension_systems/behavior/nodes/actions/bt_shoot_net_action.lua          (aim -> shoot -> drag, cooldown on leave)
--   scripts/extension_systems/behavior/nodes/actions/bt_renegade_netgunner_approach_action.lua
--   scripts/extension_systems/behavior/utilities/conditions/bt_minion_conditions.lua  (can_shoot_net, netgunner_is_on_cooldown)
--   scripts/extension_systems/behavior/utilities/bt_leave_hooks.lua                   (netgunner_reset_cooldown)
--   scripts/settings/difficulty/minion_difficulty_settings.lua                        (cooldowns.shoot_net_cooldown = 12 on every difficulty)
--   scripts/settings/fx/effect_templates/renegade_netgunner_approach.lua               (20 m warning sound, 25 m re-arm, 10 s)
--   scripts/settings/fx/effect_templates/renegade_netgunner_net.lua                    (net position from game object field net_sweep_position)
--   scripts/settings/breed/breeds/renegade/renegade_netgunner_breed.lua
--
-- How the state is known:
--   Host (solo / local server): the Trapper's blackboard and brain are read directly (exact).
--   Client (Fatshark servers): the AI runs on the server, so the state is rebuilt from what the server sends every client:
--     * target:              game object field target_unit_id (MinionPerception.target_unit)
--     * approaching:         effect template renegade_netgunner_approach runs only inside BtRenegadeNetgunnerApproachAction
--     * wind-up / interrupt / shot / pull: inventory wwise events of BtShootNetAction, networked by MinionFxExtension
--     * net in flight:       effect template renegade_netgunner_net (start at shot, stop at hit or miss)
--     * netted player:       the player's disabled_character_state (disabling_type "netted", disabling_unit)
--     * weapon malfunction:  buff keyword weapon_malfunction on the Trapper

local mod = get_mod("QIangIQsTrappers")

local MinionPerception = require("scripts/utilities/minion_perception")
local MinionVisualLoadout = require("scripts/utilities/minion_visual_loadout")

-- auto dodge (QIangIQsTrappers_dodge.lua); the overlay keeps working if it fails to load
local dodge_ok, Dodge = pcall(mod.io_dofile, mod, "QIangIQsTrappers/scripts/mods/QIangIQsTrappers/QIangIQsTrappers_dodge")

if not dodge_ok or type(Dodge) ~= "table" then
	mod:error("auto dodge did not load: %s", tostring(Dodge))

	Dodge = nil
end

local BREED_NAME = "renegade_netgunner"

-- error lines at most once per 10 s per place, so a repeating error cannot flood the log
local _last_info = {}

local function _info_limited(where, err)
	local tm = Managers.time
	local now = tm and tm:has_timer("main") and tm:time("main") or 0

	if not _last_info[where] or now - _last_info[where] > 10 or now < _last_info[where] then
		_last_info[where] = now
		mod:info("%s: %s", where, tostring(err))
	end
end

-- renegade_netgunner_actions.lua
local APPROACH_LEAVE_DISTANCE = 10 -- approach_target.leave_distance (ends when target_distance <= 10 and the "gun" line of sight is clear)
local AIM_DURATION = 0.8333333333333334 -- shoot_net.aim_duration
local MAX_NET_DISTANCE = 14 -- shoot_net.max_net_distance
local NET_SPEED = 20 -- shoot_net.net_speed (m/s)
local NET_SWEEP_RADIUS = 0.5 -- shoot_net.net_sweep_radius
local NET_DODGE_SWEEP_RADIUS = 0.35 -- shoot_net.net_dodge_sweep_radius
local DRAG_ANIM_EXIT_DELAY = 3 -- shoot_net.drag_anim_exit_delay (after the pull starts)
local RELOAD_DURATION = 3.2 -- reload.anim_durations.reload
local MALFUNCTION_TIME = 12 -- weapon_malfunction_loop.weapon_malfunction_time
-- minion_difficulty_settings.lua cooldowns.shoot_net_cooldown = { 12, 12, 12, 12, 12 }
local SHOOT_NET_COOLDOWN = 12
-- renegade_netgunner_approach.lua
local WARNING_DISTANCE = 20
-- breed: aim_config.target_node, fx source and slot of the net gun
local AIM_TARGET_NODE = "enemy_aim_target_01"
local MUZZLE_NAME = "muzzle"
local NET_SLOT = "slot_netgun"

-- wwise events of BtShootNetAction (renegade_netgunner_actions.lua, renegade_netgunner_shoot_templates.lua)
local EVENT_WINDUP = "wwise/events/minions/play_weapon_netgunner_wind_up"
local EVENT_INTERRUPTED = "wwise/events/minions/play_weapon_netgunner_interupted"
local EVENT_SHOOT = "wwise/events/minions/play_weapon_netgunner"
local EVENT_PULL = "wwise/events/weapon/play_enemy_netgunner_net_pull"

local TEMPLATE_APPROACH = "renegade_netgunner_approach"
local TEMPLATE_NET = "renegade_netgunner_net"

-- After the net effect stops, the client waits this long for a netted player or the pull sound before calling it a miss.
-- (The pull sound plays drag_anim_delay = netted_fp_anim_duration = 0.667 s after the hit.)
local HIT_CONFIRM_WINDOW = 1.0

local FONT = "content/ui/fonts/proxima_nova_bold"
local TEXT_LAYER = 900
local RING_SEGMENTS = 56

-- ---------------------------------------------------------------------------
-- Settings
-- ---------------------------------------------------------------------------

local settings = {}
local SETTING_IDS = {
	"show_labels",
	"show_target_line",
	"rings_mode",
	"show_warning_ring",
	"show_net_path",
	"show_self_alert",
	"alert_position",
	"max_distance",
	"label_size",
	"echo_events",
}

local function _refresh_settings()
	for i = 1, #SETTING_IDS do
		local id = SETTING_IDS[i]

		settings[id] = mod:get(id)
	end

	if settings.show_labels == nil then
		settings.show_labels = true
	end

	if settings.show_target_line == nil then
		settings.show_target_line = true
	end

	settings.rings_mode = settings.rings_mode or "loaded"

	if settings.show_net_path == nil then
		settings.show_net_path = true
	end

	if settings.show_self_alert == nil then
		settings.show_self_alert = true
	end

	settings.alert_position = settings.alert_position or 70
	settings.max_distance = settings.max_distance or 60
	settings.label_size = settings.label_size or 16
end

_refresh_settings()

mod.on_setting_changed = function ()
	_refresh_settings()

	if Dodge then
		Dodge.refresh()
	end
end

local view_on = true

mod.toggle_view = function ()
	view_on = not view_on

	mod:echo("Trapper overlay " .. (view_on and "on" or "off"))
end

-- ---------------------------------------------------------------------------
-- Helpers
-- ---------------------------------------------------------------------------

local function _unit_ok(unit)
	return type(unit) == "userdata" and Unit.alive(unit)
end

local function _gameplay_time()
	local time_manager = Managers.time

	if time_manager and time_manager:has_timer("gameplay") then
		return time_manager:time("gameplay")
	end

	return nil
end

local function _game_session()
	local gsm = Managers.state and Managers.state.game_session

	if not gsm then
		return nil
	end

	local ok, session = pcall(gsm.game_session, gsm)

	return ok and session or nil
end

local function _game_object_id(unit)
	local spawner = Managers.state and Managers.state.unit_spawner

	if not spawner then
		return nil
	end

	local ok, id = pcall(spawner.game_object_id, spawner, unit)

	return ok and id or nil
end

local function _breed_name(unit)
	local ext = ScriptUnit.has_extension(unit, "unit_data_system")

	if not ext then
		return nil
	end

	local ok, breed = pcall(ext.breed, ext)

	return ok and breed and breed.name or nil
end

local function _is_trapper(unit)
	return _unit_ok(unit) and _breed_name(unit) == BREED_NAME
end

local function _local_player_unit()
	local player = Managers.player and Managers.player:local_player(1)

	return player and player.player_unit or nil
end

local function _player_name(unit)
	local pm = Managers.player

	if not pm or not unit then
		return "?"
	end

	local ok, player = pcall(pm.player_by_unit, pm, unit)

	if ok and player then
		local ok2, name = pcall(player.name, player)

		if ok2 and name then
			return tostring(name)
		end
	end

	local breed = _breed_name(unit)

	return breed or "?"
end

-- Unit.world_position, not POSITION_LOOKUP: in game its entries were stale handles ("Vector3 expected, got userdata",
-- 21,000+ errors in one run, 2026-11-07). See lesson-position-lookup-stale-handle.
local function _position(unit)
	return Unit.world_position(unit, 1)
end

local function _node_position(unit, node_name, fallback_up)
	if Unit.has_node(unit, node_name) then
		return Unit.world_position(unit, Unit.node(unit, node_name))
	end

	local p = _position(unit)

	return Vector3(p.x, p.y, p.z + (fallback_up or 1.4))
end

local function _alive(unit)
	local health_alive = rawget(_G, "HEALTH_ALIVE")

	if health_alive then
		return health_alive[unit] ~= nil
	end

	return _unit_ok(unit)
end

-- ---------------------------------------------------------------------------
-- Tracked Trappers
-- ---------------------------------------------------------------------------

-- rec fields (client inference; times are this machine's gameplay time):
--   state       "unknown" | "approach" | "aiming" | "flight" | "net_ended" | "dragging" | "reload" | "flee_loaded"
--               | "flee_cooldown" | "ready" | "malfunction"
--   loaded      true / false / nil (unknown)
--   t_state     time the state started
--   aim_end_t, net_end_t, pull_t, leave_t, hit
local tracked = {}

local function _rec(unit)
	local rec = tracked[unit]

	if not rec then
		rec = {
			unit = unit,
			state = "unknown",
			loaded = nil,
			t_state = 0,
		}
		tracked[unit] = rec
	end

	return rec
end

local function _set_state(rec, state, t)
	rec.state = state
	rec.t_state = t
end

local function _echo(rec, what)
	if settings.echo_events then
		mod:echo(string.format("[Trapper %s] %s", tostring(rec.unit):sub(-6), what))
	end
end

-- BtShootNetAction.leave: cooldown = t + 12, net_is_ready = false; hit_target = was dragging.
local function _on_leave(rec, t0, hit)
	rec.loaded = false
	rec.leave_t = t0
	rec.hit = hit

	if hit then
		-- tree: reload_then_run_sequence -> reload (3.2 s) then run_away; the leave hook of that run_away re-arms the net.
		_set_state(rec, "reload", t0)
	else
		-- tree: run_then_reload -> run_away while t < cooldown, then reload (3.2 s) whose leave hook re-arms the net.
		_set_state(rec, "flee_cooldown", t0)
	end
end

local function _netted_by(trapper_unit)
	local pm = Managers.player

	if not pm then
		return nil
	end

	local ok, players = pcall(pm.players, pm)

	if not ok or not players then
		return nil
	end

	for _, player in pairs(players) do
		local unit = player.player_unit

		if _unit_ok(unit) then
			local ext = ScriptUnit.has_extension(unit, "unit_data_system")

			if ext then
				local ok2, comp = pcall(ext.read_component, ext, "disabled_character_state")

				if ok2 and comp and comp.is_disabled and comp.disabling_type == "netted" and comp.disabling_unit == trapper_unit then
					return unit
				end
			end
		end
	end

	return nil
end

local function _has_malfunction(unit)
	local buff_extension = ScriptUnit.has_extension(unit, "buff_system")

	if not buff_extension then
		return false
	end

	local ok, result = pcall(buff_extension.has_keyword, buff_extension, "weapon_malfunction")

	return ok and result or false
end

-- ---------------------------------------------------------------------------
-- Event hooks (run on host and client alike)
-- ---------------------------------------------------------------------------

local function _on_wwise(unit, event_name)
	if not event_name or not _is_trapper(unit) then
		return
	end

	local t = _gameplay_time() or 0
	local rec = _rec(unit)

	if event_name == EVENT_WINDUP then
		rec.loaded = true
		rec.aim_end_t = t + AIM_DURATION
		_set_state(rec, "aiming", t)
		_echo(rec, "wind-up")
	elseif event_name == EVENT_INTERRUPTED then
		-- aim_stop_wwise_event plays in leave() only while still aiming: the action ended before the shot,
		-- and leave() still starts the 12 s cooldown and empties the net.
		_on_leave(rec, t, false)
		_echo(rec, "interrupted during wind-up")
	elseif event_name == EVENT_SHOOT then
		rec.loaded = false
		rec.shot_t = t
		_set_state(rec, "flight", t)
		_echo(rec, "net fired")
	elseif event_name == EVENT_PULL then
		rec.loaded = false
		rec.pull_t = t
		_set_state(rec, "dragging", t)
		_echo(rec, "pull")
	end
end

local function _on_template_start(template, unit)
	if not template or not unit or not _is_trapper(unit) then
		return
	end

	local t = _gameplay_time() or 0
	local rec = _rec(unit)
	local name = template.name

	if name == TEMPLATE_APPROACH then
		-- approach only runs when can_shoot_net: cooldown over and net_is_ready
		rec.loaded = true
		_set_state(rec, "approach", t)
		_echo(rec, "approach")
	elseif name == TEMPLATE_NET then
		rec.loaded = false
		rec.net_active = true

		if rec.state ~= "flight" then
			rec.shot_t = t
			_set_state(rec, "flight", t)
		end

		_echo(rec, "net effect start")
	end
end

local function _on_template_stop(template_name, unit)
	if not unit or not tracked[unit] then
		return
	end

	local t = _gameplay_time() or 0
	local rec = tracked[unit]

	if template_name == TEMPLATE_NET then
		rec.net_active = false

		if rec.state == "flight" then
			rec.net_end_t = t
			_set_state(rec, "net_ended", t)
		end

		_echo(rec, "net effect stop")
	elseif template_name == TEMPLATE_APPROACH then
		if rec.state == "approach" then
			rec.approach_end_t = t
		end

		_echo(rec, "approach stop")
	end
end

mod:hook_require("scripts/extension_systems/fx/minion_fx_extension", function (MinionFxExtension)
	mod:hook_safe(MinionFxExtension, "_trigger_inventory_wwise_event", function (self, event_name, inventory_slot_name, fx_source_name, optional_target_unit)
		local ok, err = pcall(_on_wwise, self._unit, event_name)

		if not ok then
			_info_limited("wwise hook", err)
		end

		if Dodge then
			Dodge.on_wwise(self, event_name, optional_target_unit)
		end
	end)
end)

mod:hook_require("scripts/extension_systems/fx/utilities/effect_templates_handler", function (EffectTemplatesHandler)
	mod:hook_safe(EffectTemplatesHandler, "start_template_effect", function (self, unit_to_particle_group_lookup, template_context, template_effect, template, optional_unit)
		local ok, err = pcall(_on_template_start, template, optional_unit)

		if not ok then
			_info_limited("template start hook", err)
		end
	end)

	mod:hook(EffectTemplatesHandler, "stop_template_effect", function (func, self, template_context, template_effect, template, ...)
		-- read before the original clears the effect
		local name = template and template.name
		local unit = template_effect and template_effect.optional_unit

		func(self, template_context, template_effect, template, ...)

		if name == TEMPLATE_NET or name == TEMPLATE_APPROACH then
			local ok, err = pcall(_on_template_stop, name, unit)

			if not ok then
				_info_limited("template stop hook", err)
			end
		end
	end)
end)

-- ---------------------------------------------------------------------------
-- Per-frame state
-- ---------------------------------------------------------------------------

local function _host_blackboard(unit)
	local blackboards = rawget(_G, "BLACKBOARDS")

	return blackboards and blackboards[unit] or nil
end

-- Exact state from the server-side AI (only exists on the host).
local function _read_host(rec, unit, t)
	local blackboard = _host_blackboard(unit)

	if not blackboard then
		return false
	end

	local behavior = blackboard.behavior
	local perception = blackboard.perception

	if not behavior or not perception then
		return false
	end

	rec.exact = true
	rec.loaded = behavior.net_is_ready
	rec.cooldown_left = math.max(0, (behavior.shoot_net_cooldown or 0) - t)
	rec.hit_target = behavior.hit_target
	rec.is_dragging = behavior.is_dragging
	rec.target = perception.target_unit
	rec.target_distance = perception.target_distance
	rec.has_los = perception.has_line_of_sight

	local behavior_extension = ScriptUnit.has_extension(unit, "behavior_system")
	local action_name

	if behavior_extension then
		local ok, name = pcall(behavior_extension.running_action, behavior_extension)

		action_name = ok and name or nil
	end

	rec.action = action_name

	-- the brain scratchpad holds the running action's timers (BtShootNetAction / BtReloadAction)
	local brain = behavior_extension and rawget(behavior_extension, "_brain")
	local scratchpad = brain and rawget(brain, "_scratchpad")

	rec.internal_state = scratchpad and scratchpad.internal_state or nil
	rec.shoot_t_left = scratchpad and scratchpad.shoot_t and math.max(0, scratchpad.shoot_t - t) or nil
	rec.reload_left = scratchpad and scratchpad.reload_exit_t and math.max(0, scratchpad.reload_exit_t - t) or nil

	if rec.target and _unit_ok(rec.target) then
		local perception_extension = ScriptUnit.has_extension(unit, "perception_system")

		if perception_extension then
			local ok, clear = pcall(perception_extension.has_line_of_sight_by_id, perception_extension, rec.target, "gun")

			rec.clear_shot = ok and clear or nil
		end
	end

	local malfunction = blackboard.weapon_malfunction

	rec.malfunction_left = malfunction and malfunction.is_malfunctioning and math.max(0, (malfunction.malfunctioning_time or 0) - t) or nil

	return true
end

local function _read_client(rec, unit, t)
	rec.exact = false

	local session = _game_session()
	local go_id = _game_object_id(unit)

	if session and go_id then
		local ok, target = pcall(MinionPerception.target_unit, session, go_id)

		rec.target = ok and target or nil
	else
		rec.target = nil
	end

	if rec.target and _unit_ok(rec.target) then
		rec.target_distance = Vector3.distance(_position(unit), _position(rec.target))
	else
		rec.target_distance = nil
	end

	-- weapon malfunction (Hive Scum ability): BtWeaponMalfunctionAction; its leave hook re-arms the net (reset_net_cooldown = true)
	local malfunctioning = _has_malfunction(unit)

	if malfunctioning then
		if rec.state ~= "malfunction" then
			_set_state(rec, "malfunction", t)
		end
	elseif rec.state == "malfunction" then
		rec.loaded = true
		_set_state(rec, "ready", t)
	end

	local state = rec.state

	if state == "aiming" and rec.aim_end_t and t > rec.aim_end_t + 1.5 then
		-- wind-up ended without a shot sound or interrupt (packet loss or hot join): unknown
		_set_state(rec, "unknown", t)
	elseif state == "net_ended" then
		local netted = _netted_by(unit)

		if netted then
			rec.netted_unit = netted
			_set_state(rec, "dragging", rec.net_end_t)
		elseif t - rec.net_end_t > HIT_CONFIRM_WINDOW then
			_on_leave(rec, rec.net_end_t, false)
			_echo(rec, "miss")
		end
	elseif state == "dragging" then
		local netted = _netted_by(unit)

		if netted then
			rec.netted_unit = netted
			rec.was_netted = true
		end

		-- BtShootNetAction._update_dragging ends the shot at pull + drag_anim_exit_delay, or when the player is no longer netted by it
		if rec.pull_t and t > rec.pull_t + DRAG_ANIM_EXIT_DELAY then
			_on_leave(rec, rec.pull_t + DRAG_ANIM_EXIT_DELAY, true)
			rec.was_netted = nil
		elseif rec.was_netted and not netted then
			_on_leave(rec, t, true)
			rec.was_netted = nil
		end
	elseif state == "reload" and rec.leave_t then
		local reload_start = rec.hit and rec.leave_t or rec.leave_t + SHOOT_NET_COOLDOWN

		if t > reload_start + RELOAD_DURATION then
			if rec.hit then
				-- net is physically reloaded but net_is_ready is only set when the following run_away ends
				_set_state(rec, "flee_loaded", t)
			else
				rec.loaded = true
				_set_state(rec, "ready", t)
			end
		end
	elseif state == "flee_cooldown" and rec.leave_t then
		if t > rec.leave_t + SHOOT_NET_COOLDOWN then
			_set_state(rec, "reload", t)
		end
	end

	rec.cooldown_left = rec.leave_t and math.max(0, rec.leave_t + SHOOT_NET_COOLDOWN - t) or nil
end

-- ---------------------------------------------------------------------------
-- Text for one Trapper
-- ---------------------------------------------------------------------------

local COLOURS = {
	ready = { 255, 255, 140, 0 },
	danger = { 255, 255, 50, 40 },
	safe = { 255, 90, 220, 120 },
	info = { 255, 230, 230, 230 },
	unknown = { 255, 160, 160, 160 },
	me = { 255, 255, 40, 40 },
}

local function _c(name, alpha)
	local c = COLOURS[name]

	return Color(alpha or c[1], c[2], c[3], c[4])
end

local HOST_ACTION_TEXT = {
	approach_target = "Approaching",
	reload = "Reloading",
	run_away = "Fleeing",
	run_away_weapon_malfunction = "Fleeing (malfunction)",
	weapon_malfunction_loop = "Weapon malfunction",
	stagger = "Staggered",
	idle = "Idle",
	climb = "Climbing",
	jump_across = "Jumping",
	open_door = "Opening door",
	teleport = "Teleporting",
	disable = "Pinned (disabled)",
	vortex_grabbed = "In a vortex",
	exit_spawner = "Leaving spawner",
	death = "Dying",
}

local function _state_line(rec, t)
	if rec.exact then
		local action = rec.action

		if action == "shoot_net" then
			local s = rec.internal_state

			if s == "aiming" then
				return string.format("WINDING UP  fires in %.2f s", rec.shoot_t_left or 0), "danger"
			elseif s == "shooting" then
				return "NET IN FLIGHT", "danger"
			elseif s == "dragging" then
				return "DRAGGING " .. _player_name(_netted_by(rec.unit)), "danger"
			end

			return "Shooting", "danger"
		elseif action == "reload" then
			return string.format("Reloading  %.1f s", rec.reload_left or 0), "safe"
		elseif action == "run_away" then
			if rec.cooldown_left and rec.cooldown_left > 0 then
				return string.format("Fleeing  cooldown %.1f s, then 3.2 s reload", rec.cooldown_left), "safe"
			end

			return "Fleeing  re-arms when it stops", "safe"
		elseif action == "approach_target" then
			local shot = rec.clear_shot and "clear shot" or "no clear shot"

			return string.format("Approaching  %s  (fires at 10 m or less with a clear shot)", shot), "ready"
		elseif action == "weapon_malfunction_loop" then
			return string.format("Weapon malfunction  %.1f s", rec.malfunction_left or 0), "safe"
		end

		return HOST_ACTION_TEXT[action] or (action or "Idle"), "info"
	end

	local state = rec.state

	if state == "approach" then
		return "Approaching  (fires at 10 m or less with a clear shot)", "ready"
	elseif state == "aiming" then
		return string.format("WINDING UP  fires in %.2f s", math.max(0, (rec.aim_end_t or t) - t)), "danger"
	elseif state == "flight" then
		return "NET IN FLIGHT", "danger"
	elseif state == "net_ended" then
		return "Net landed...", "danger"
	elseif state == "dragging" then
		return "DRAGGING " .. _player_name(rec.netted_unit), "danger"
	elseif state == "reload" then
		local start = rec.hit and rec.leave_t or (rec.leave_t or t) + SHOOT_NET_COOLDOWN

		return string.format("Reloading  %.1f s", math.max(0, start + RELOAD_DURATION - t)), "safe"
	elseif state == "flee_cooldown" then
		return string.format("Fleeing  cooldown %.1f s, then 3.2 s reload", rec.cooldown_left or 0), "safe"
	elseif state == "flee_loaded" then
		return "Fleeing  reloaded, re-arms when it stops", "safe"
	elseif state == "ready" then
		return "Net re-armed", "ready"
	elseif state == "malfunction" then
		return string.format("Weapon malfunction  up to %d s", MALFUNCTION_TIME), "safe"
	end

	return "State unknown (seen before any event)", "unknown"
end

local function _net_line(rec)
	if not rec.exact and rec.state == "flee_loaded" then
		return "NET RELOADED (arms when it stops fleeing)", "ready"
	elseif rec.loaded == true then
		return "NET LOADED", "ready"
	elseif rec.loaded == false then
		return "NET EMPTY", "safe"
	end

	return "NET ?", "unknown"
end

-- ---------------------------------------------------------------------------
-- Render resources (same lifecycle as QIangIQsCoherencyZone / QIangIQsHitboxView)
-- ---------------------------------------------------------------------------

local render = {
	world = nil,
	screen_gui = nil,
	lines = nil,
	lines_top = nil,
}

local function _level_world()
	local world_manager = Managers.world

	if world_manager and world_manager:has_world("level_world") then
		return world_manager:world("level_world")
	end

	return nil
end

local function _ensure_render()
	local world = _level_world()

	if not world then
		return false
	end

	if render.world ~= world then
		-- old resources belong to a destroyed world; abandon them
		render.world, render.screen_gui, render.lines, render.lines_top = world, nil, nil, nil
	end

	if not render.screen_gui then
		local ok, gui = pcall(World.create_screen_gui, world, "immediate")

		render.screen_gui = ok and gui or nil
	end

	if not render.lines then
		local ok, lines = pcall(World.create_line_object, world)

		render.lines = ok and lines or nil
	end

	if not render.lines_top then
		-- second argument turns the depth test off (as QIangIQsHitboxView); fall back to the normal object
		local ok, lines = pcall(World.create_line_object, world, true)

		render.lines_top = ok and lines or render.lines
	end

	return render.screen_gui ~= nil and render.lines ~= nil
end

local function _clear_lines()
	if render.world and render.lines then
		pcall(function ()
			LineObject.reset(render.lines)
			LineObject.dispatch(render.world, render.lines)

			if render.lines_top and render.lines_top ~= render.lines then
				LineObject.reset(render.lines_top)
				LineObject.dispatch(render.world, render.lines_top)
			end
		end)
	end
end

local function _camera()
	local camera_manager = Managers.state and Managers.state.camera
	local player = Managers.player and Managers.player:local_player(1)

	if not camera_manager or not player or not player.viewport_name then
		return nil
	end

	local ok, camera = pcall(camera_manager.camera, camera_manager, player.viewport_name)

	return ok and camera or nil
end

local function _project(camera, position)
	local camera_position = Camera.world_position(camera)
	local camera_forward = Quaternion.forward(Camera.world_rotation(camera))
	local in_front = Vector3.dot(position - camera_position, camera_forward) > 0.5
	local screen = Camera.world_to_screen(camera, position)

	return screen.x, screen.y, in_front
end

local function _text_centered(text, x, y, size, colour)
	local gui = render.screen_gui
	local min, max = Gui.slug_text_extents(gui, text, FONT, size)

	Gui.slug_text(gui, text, FONT, size, Vector3(x - (max.x - min.x) / 2, y, TEXT_LAYER), nil, colour, "shadow", Color(200, 0, 0, 0))
end

local function _ring(lines, colour, cx, cy, z, radius)
	local step = 2 * math.pi / RING_SEGMENTS

	for i = 0, RING_SEGMENTS - 1 do
		local a1, a2 = i * step, (i + 1) * step

		LineObject.add_line(lines, colour, Vector3(cx + math.cos(a1) * radius, cy + math.sin(a1) * radius, z), Vector3(cx + math.cos(a2) * radius, cy + math.sin(a2) * radius, z))
	end
end

local function _muzzle_position(unit)
	local visual_loadout_extension = ScriptUnit.has_extension(unit, "visual_loadout_system")

	if visual_loadout_extension then
		local ok, pos = pcall(function ()
			local item = visual_loadout_extension:slot_item(NET_SLOT)
			local attachment_unit, node = MinionVisualLoadout.attachment_unit_and_node_from_node_name(item, MUZZLE_NAME)

			return Unit.world_position(attachment_unit, node)
		end)

		if ok and pos then
			return pos
		end
	end

	return _node_position(unit, "j_rightarm_roll", 1.4)
end

-- ---------------------------------------------------------------------------
-- Drawing
-- ---------------------------------------------------------------------------

local function _draw_trapper(rec, camera, me, t, alert)
	local unit = rec.unit
	local pos = _position(unit)
	local px, py, pz = pos.x, pos.y, pos.z
	local lines, top = render.lines, render.lines_top
	local target = rec.target
	local target_ok = target and _unit_ok(target)
	local targets_me = target_ok and target == me
	local danger = rec.exact and rec.action == "shoot_net" or (not rec.exact and (rec.state == "aiming" or rec.state == "flight" or rec.state == "net_ended" or rec.state == "dragging"))

	-- rings
	local mode = settings.rings_mode
	local show_rings = mode == "always" or mode == "loaded" and rec.loaded ~= false or mode == "me" and targets_me

	if show_rings then
		local z = pz + 0.1

		_ring(lines, _c("ready", 200), px, py, z, MAX_NET_DISTANCE)
		_ring(lines, _c("danger", 220), px, py, z, APPROACH_LEAVE_DISTANCE)

		if settings.show_warning_ring then
			_ring(lines, _c("info", 120), px, py, z, WARNING_DISTANCE)
		end
	end

	-- line to target
	if settings.show_target_line and target_ok then
		local from = _node_position(unit, "j_spine", 1.2)
		local to = _node_position(target, AIM_TARGET_NODE, 1.2)

		LineObject.add_line(top, targets_me and _c("me") or danger and _c("danger") or _c("ready", 180), from, to)
	end

	-- net path while winding up; net sphere while in flight
	if settings.show_net_path then
		local aiming = rec.exact and rec.action == "shoot_net" and rec.internal_state == "aiming" or not rec.exact and rec.state == "aiming"
		local flying = rec.exact and rec.action == "shoot_net" and rec.internal_state == "shooting" or not rec.exact and rec.state == "flight"

		if aiming and target_ok then
			local from = _muzzle_position(unit)
			local aim = _node_position(target, AIM_TARGET_NODE, 1.2)
			local dir = Vector3.normalize(aim - from)
			local to = from + dir * MAX_NET_DISTANCE

			LineObject.add_line(top, _c("danger"), from, to)
			LineObject.add_sphere(lines, _c("danger", 160), to, NET_SWEEP_RADIUS, 12, 2)
		end

		if flying then
			local session = _game_session()
			local go_id = _game_object_id(unit)

			if session and go_id then
				local ok, net_pos = pcall(GameSession.game_object_field, session, go_id, "net_sweep_position")

				if ok and net_pos then
					LineObject.add_sphere(top, _c("danger"), net_pos, NET_SWEEP_RADIUS, 16, 3)
					LineObject.add_sphere(top, _c("ready"), net_pos, NET_DODGE_SWEEP_RADIUS, 12, 2)
				end
			end
		end
	end

	-- label
	if settings.show_labels and camera then
		local head = _node_position(unit, "j_head", 1.9)
		local x, y, in_front = _project(camera, Vector3(head.x, head.y, head.z + 0.45))

		if in_front then
			local _, height = Gui.resolution()
			local size = settings.label_size * height / 1080
			local step = size * 1.15
			local health = ""
			local health_extension = ScriptUnit.has_extension(unit, "health_system")

			if health_extension then
				local ok, frac = pcall(health_extension.current_health_percent, health_extension)

				if ok and frac then
					health = string.format("  HP %d", math.floor(frac * 100 + 0.5))
				end
			end

			_text_centered("TRAPPER" .. health .. (rec.exact and "" or "  (inferred)"), x, y, size, _c("info"))

			local net_text, net_colour = _net_line(rec)

			_text_centered(net_text, x, y - step, size, _c(net_colour))

			local state_text, state_colour = _state_line(rec, t)

			_text_centered(state_text, x, y - 2 * step, size, _c(state_colour))

			if target_ok then
				local name = targets_me and "YOU" or _player_name(target)

				_text_centered(string.format("target: %s  %.1f m", name, rec.target_distance or 0), x, y - 3 * step, size, targets_me and _c("me") or _c("info"))
			else
				_text_centered("target: none", x, y - 3 * step, size, _c("unknown"))
			end
		end
	end

	-- most urgent warning for the local player
	if targets_me then
		local d = rec.target_distance or 0
		local priority, text

		if rec.exact and rec.action == "shoot_net" and rec.internal_state == "aiming" or not rec.exact and rec.state == "aiming" then
			local left = rec.exact and rec.shoot_t_left or math.max(0, (rec.aim_end_t or t) - t)

			priority = 3
			text = string.format("TRAPPER WINDING UP ON YOU: net in %.2f s, reaches you %.2f s later (%.1f m)", left, math.min(d, MAX_NET_DISTANCE) / NET_SPEED, d)
		elseif rec.exact and rec.action == "shoot_net" and rec.internal_state == "shooting" or not rec.exact and rec.state == "flight" then
			priority = 4
			text = string.format("NET INCOMING: DODGE or step off its line (%.1f m)", d)
		elseif rec.loaded ~= false then
			priority = 2
			text = string.format("Trapper targeting you: %.1f m (fires at 10 m or less with a clear shot, net reaches 14 m)", d)
		else
			priority = 1
			text = string.format("Trapper targeting you: %.1f m, net empty", d)
		end

		if not alert.priority or priority > alert.priority or priority == alert.priority and d < alert.distance then
			alert.priority, alert.text, alert.distance = priority, text, d
		end
	end
end

-- ---------------------------------------------------------------------------
-- Update
-- ---------------------------------------------------------------------------

local next_scan_t = 0
local SCAN_INTERVAL = 0.5
local LOCOMOTION_EXTENSIONS = { "MinionHuskLocomotionExtension", "MinionLocomotionExtension" }

local function _scan()
	local extension_manager = Managers.state and Managers.state.extension

	if not extension_manager then
		return
	end

	for i = 1, #LOCOMOTION_EXTENSIONS do
		local ok, entities = pcall(extension_manager.get_entities, extension_manager, LOCOMOTION_EXTENSIONS[i])

		if ok and entities then
			for unit in pairs(entities) do
				if not tracked[unit] and _alive(unit) and _is_trapper(unit) then
					_rec(unit)
				end
			end
		end
	end
end

local alert = {}
local was_drawing = false

mod.update = function (dt)
	-- the dodge runs even while the overlay is hidden
	if Dodge then
		Dodge.update(dt)
	end

	if not view_on or not mod:is_enabled() then
		if was_drawing then
			_clear_lines()

			was_drawing = false
		end

		return
	end

	local t = _gameplay_time()

	if not t or not _ensure_render() then
		return
	end

	if t >= next_scan_t then
		next_scan_t = t + SCAN_INTERVAL

		_scan()
	end

	local camera = _camera()
	local me = _local_player_unit()
	local cam_pos = camera and Camera.world_position(camera)
	local max_d2 = settings.max_distance * settings.max_distance
	local lines, top = render.lines, render.lines_top

	LineObject.reset(lines)

	if top ~= lines then
		LineObject.reset(top)
	end

	alert.priority, alert.text, alert.distance = nil, nil, nil

	for unit, rec in pairs(tracked) do
		if not _unit_ok(unit) or not _alive(unit) then
			tracked[unit] = nil
		else
			local ok, err = pcall(function ()
				if not _read_host(rec, unit, t) then
					_read_client(rec, unit, t)
				end

				local pos = _position(unit)
				local near = true

				if cam_pos then
					local dx, dy, dz = pos.x - cam_pos.x, pos.y - cam_pos.y, pos.z - cam_pos.z

					near = dx * dx + dy * dy + dz * dz <= max_d2
				end

				if near or rec.target == me then
					_draw_trapper(rec, camera, me, t, alert)
				end
			end)

			if not ok then
				_info_limited("draw", err)
			end
		end
	end

	LineObject.dispatch(render.world, lines)

	if top ~= lines then
		LineObject.dispatch(render.world, top)
	end

	was_drawing = true

	if settings.show_self_alert and alert.text then
		pcall(function ()
			local width, height = Gui.resolution()
			local size = 22 * height / 1080
			local colour = alert.priority >= 3 and _c("me") or alert.priority == 2 and _c("ready") or _c("safe")

			_text_centered(alert.text, width / 2, height * settings.alert_position / 100, size, colour)
		end)
	end
end

-- ---------------------------------------------------------------------------
-- Lifecycle and commands
-- ---------------------------------------------------------------------------

mod.on_game_state_changed = function (status, state_name)
	if Dodge then
		Dodge.reset()
	end

	if state_name == "StateGameplay" then
		table.clear(tracked)
		render.world, render.screen_gui, render.lines, render.lines_top = nil, nil, nil, nil
	end
end

mod.on_disabled = function ()
	_clear_lines()

	if Dodge then
		Dodge.reset()
	end
end

mod.on_unload = function ()
	if Dodge then
		Dodge.reset()
	end
end

mod:command("trappers_info", "List tracked Trappers and what the mod knows about each.", function ()
	local t = _gameplay_time() or 0
	local n = 0

	for unit, rec in pairs(tracked) do
		n = n + 1

		local state_text = _state_line(rec, t)
		local net_text = _net_line(rec)
		local target = rec.target and _unit_ok(rec.target) and _player_name(rec.target) or "none"

		mod:echo(string.format("%d. %s | %s | %s | target %s %.1f m | %s", n, tostring(unit):sub(-6), net_text, state_text, target, rec.target_distance or 0, rec.exact and "host (exact)" or "client (inferred)"))
	end

	if n == 0 then
		mod:echo("No Trappers tracked.")
	end
end)
