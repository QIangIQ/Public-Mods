-- QIangIQsTrappers dodge module (was the separate QIangIQsTrapperDodge): dodge a Trapper (renegade_netgunner) net on host and on Fatshark servers.
--
-- Everything below is taken from the game source (Aussiemon/Darktide-Source-Code e46b8926):
--   bt_shoot_net_action.lua       aim 0.8333 s, then the net flies straight from the muzzle to the aim point taken at release,
--                                 20 m/s, at most 14 m, sweep radius 0.5; a dodging player is only netted inside 0.35 m (flat)
--   renegade_netgunner_actions.lua shoot_net: aim_duration 0.8333333333333334, net_speed 20, max_net_distance 14;
--                                 approach_target leave_distance 10
--   minion_fx_extension.lua       trigger_inventory_wwise_event sends rpc_trigger_minion_inventory_wwise_event to every client;
--                                 host and clients both end in _trigger_inventory_wwise_event(self, event, slot, source, target, ranged)
--   dodge.lua                     Dodge.check: no dodge while sprinting; move with y <= 0 dodges in exactly that local direction;
--                                 y > 0 needs |x| > 0.707 and then dodges straight sideways; dodge linger is 0 against the net
--   player_character_state_walking.lua  the only normal state that calls Dodge.check
--   human_unit_input.lua          move = (move_right - move_left, move_forward - move_backward)
--   archetype_dodge_templates.lua dodge 2.5 m in 0.4 s (zealot 2.75 m), fastest at the start
--   combatsword_p1_m1.lua         action_push push_radius 2.5 (block, then attack)
--   ping_reporter.lua             Network.ping(Managers.connection:host()) is the round trip in seconds
--
-- No private AI fields are read, so the same code runs on the host and on a client.

local mod = get_mod("QIangIQsTrappers")

local MinionPerception = require("scripts/utilities/minion_perception")

local BREED_NAME = "renegade_netgunner"
local EVENT_WINDUP = "wwise/events/minions/play_weapon_netgunner_wind_up"
local EVENT_INTERRUPTED = "wwise/events/minions/play_weapon_netgunner_interupted"
local EVENT_SHOOT = "wwise/events/minions/play_weapon_netgunner"
local AIM_DURATION = 0.8333333333333334
local NET_SPEED = 20
local MAX_NET_DISTANCE = 14

-- timing (seconds)
-- Fixed step: 1 / tick rate (state_gameplay.lua 32-34; default tick_rate 52, default_game_parameters.lua 17)
local function _fixed_step()
	local cm = Managers.connection
	local ok, rate = pcall(function ()
		return cm and cm.tick_rate and cm:tick_rate()
	end)

	rate = ok and type(rate) == "number" and rate > 0 and rate or 52

	return 1 / rate
end

-- Sprinting ends in the same fixed frame that reads move y <= 0 (player_character_state_sprinting.lua 383, 286-297),
-- so the move goes in one step before the press; dodge is pressed for up to the dodge cooldown 0.2 s
-- (archetype_dodge_templates.lua) plus 2 steps of input buffer (BUFFER_MIN, adaptive_clock_handler_server.lua 4);
-- the move is held one step after the dodge starts.
local function PRE_MOVE() return _fixed_step() end
local function PRESS_WINDOW() return 0.2 + 2 * _fixed_step() end
local function HOLD_AFTER_START() return _fixed_step() end
local MAX_INJECT = 1.2 -- safety limit, not a game value: no made-up input outlives this
-- block then push, timings from AntiBursterPush by josef0464 (BLOCK_TIME 0.10, PUSH_TIME 0.15)
local PUSH_BLOCK_TIME = 0.10
local PUSH_PRESS_TIME = 0.15

-- path checks (metres)
-- player body radius 0.7 (player_unit_locomotion_extension.lua 252); a wall closer than that plus the net's dodge
-- core 0.35 m (shoot_net net_dodge_sweep_radius) stops the dodge too early
local PLAYER_RADIUS = 0.7
local WALL_CLEAR = PLAYER_RADIUS + 0.35
-- the game's sideways limit: Dodge.check dodges straight sideways only when |x| > 0.707 (dodge.lua 70-90)
local MIN_LATERAL = 0.707

local S = {}

local _dodge_distance, _body_radius

-- the wielded weapon's push radius (action_push.push_radius), read as weapon_template.lua 6-8 does;
-- 2.5 (combatsword_p1_m1.lua 1126) when it cannot be read
local _WeaponTemplate = nil

local function _push_radius(me)
	if _WeaponTemplate == nil then
		local ok, wt = pcall(require, "scripts/utilities/weapon/weapon_template")

		_WeaponTemplate = ok and wt or false
	end

	if _WeaponTemplate then
		local ext = ScriptUnit.has_extension(me, "unit_data_system")
		local ok, template = pcall(function ()
			return _WeaponTemplate.current_weapon_template(ext:read_component("weapon_action"))
		end)
		local push = ok and template and template.actions and template.actions.action_push

		if push and push.push_radius then
			return push.push_radius
		end
	end

	return 2.5
end

local function _refresh_settings()
	S.auto_dodge = mod:get("auto_dodge") ~= false
	S.offset = (mod:get("timing_offset_ms") or 0) / 1000
	S.ping = mod:get("ping_compensation") ~= false
	S.max_range = mod:get("dodge_max_range") or 15
	S.camera_mode = mod:get("camera_mode") or "when_needed"
	S.restore_camera = mod:get("restore_camera") ~= false
	S.ledge = mod:get("ledge_protection") ~= false
	S.max_drop = mod:get("max_drop") or 4 -- warning_height 4 (player_character_constants.lua 878)
	S.body_block = mod:get("body_block_check") ~= false
	S.push = mod:get("auto_push") ~= false
	S.debug = mod:get("dodge_debug_log") == true
end

_refresh_settings()


-- ---------------------------------------------------------------------------
-- Small helpers (every engine call that can fail is guarded)
-- ---------------------------------------------------------------------------

local _last_error_t = -100

local function _real_time()
	local tm = Managers.time

	if tm and tm:has_timer("main") then
		return tm:time("main")
	end

	if Application.time_since_launch then
		return Application.time_since_launch()
	end

	return 0
end

local function _report(where, err)
	local now = _real_time()

	if now - _last_error_t > 10 then
		_last_error_t = now
		mod:error("%s: %s", where, tostring(err))
	end
end

local function _log(fmt, ...)
	if S.debug then
		mod:echo("[TrapperDodge] " .. string.format(fmt, ...))
	end
end

local function _timer(name)
	local tm = Managers.time

	if tm and tm:has_timer(name) then
		return tm:time(name)
	end

	return nil
end

local function _unit_ok(unit)
	return type(unit) == "userdata" and Unit.alive(unit)
end

-- Unit.world_position, not POSITION_LOOKUP: in game its entries were stale handles ("Vector3 expected, got userdata",
-- 21,000+ errors in one run, 2026-11-07). See lesson-position-lookup-stale-handle.
local function _position(unit)
	return Unit.world_position(unit, 1)
end

local function _flat(v)
	return Vector3(v.x, v.y, 0)
end

local function _local_player()
	local pm = Managers.player

	return pm and pm:local_player(1) or nil
end

local function _breed_name(unit)
	local ext = ScriptUnit.has_extension(unit, "unit_data_system")

	if not ext then
		return nil
	end

	local ok, breed = pcall(ext.breed, ext)

	return ok and breed and breed.name or nil
end

local function _component(unit, name)
	local ext = ScriptUnit.has_extension(unit, "unit_data_system")

	return ext and ext:read_component(name) or nil
end

local function _ping()
	if not S.ping then
		return 0
	end

	local cm = Managers.connection
	local host = cm and cm.host and cm:host()

	if not host or not Network or not Network.ping then
		return 0
	end

	local ok, rtt = pcall(Network.ping, host)

	if not ok or type(rtt) ~= "number" then
		return 0
	end

	return math.max(rtt, 0)
end

local function _target_of(trapper_unit)
	local gsm = Managers.state and Managers.state.game_session
	local spawner = Managers.state and Managers.state.unit_spawner

	if not gsm or not spawner then
		return nil
	end

	local ok, session = pcall(gsm.game_session, gsm)
	local ok2, go_id = pcall(spawner.game_object_id, spawner, trapper_unit)

	if not ok or not session or not ok2 or not go_id then
		return nil
	end

	local ok3, target = pcall(MinionPerception.target_unit, session, go_id)

	return ok3 and target or nil
end

local function _physics_world()
	local world = Application.main_world()

	if not world then
		return nil
	end

	local ok, pw = pcall(World.physics_world, world)

	return ok and pw or nil
end

-- ---------------------------------------------------------------------------
-- Made-up input (only for the "Ingame" service, expires on its own)
-- ---------------------------------------------------------------------------

local _inject = {}
local _inject_until = 0
local _wield_pressed = false

local function _clear_inject()
	for k in pairs(_inject) do
		_inject[k] = nil
	end

	_inject_until = 0
end

local function _main_time()
	return _real_time()
end

local function _inject_active()
	if _inject_until == 0 then
		return false
	end

	if _main_time() > _inject_until then
		_clear_inject()

		return false
	end

	return true
end

local WIELD_ACTIONS = {
	quick_wield = true, wield_1 = true, wield_2 = true, wield_3 = true, wield_4 = true, wield_5 = true,
	wield_scroll_down = true, wield_scroll_up = true,
}

local function _input_hook(func, self, action_name)
	if self.type == "Ingame" and _inject_until ~= 0 then
		local ok, value = pcall(function ()
			if WIELD_ACTIONS[action_name] or not _inject_active() then
				return nil
			end

			return _inject[action_name] -- may be false (sprint off), which must be returned too
		end)

		if ok and value ~= nil then
			return value
		end

		if WIELD_ACTIONS[action_name] then
			local raw = func(self, action_name)

			if raw then
				_wield_pressed = true
			end

			return raw
		end
	end

	return func(self, action_name)
end

local hooked, hook_err = pcall(mod.hook, mod, CLASS.InputService, "_get", _input_hook)

if not hooked then
	mod:error("could not hook InputService._get: %s", tostring(hook_err))
end

-- ---------------------------------------------------------------------------
-- Shots aimed at the local player
-- ---------------------------------------------------------------------------

-- plan = { unit, seen_t, press_t, rtt, phase, ... }   phase: "wait" | "move" | "press" | "started" | "done"
local plans = {}
local _active = nil
local _push = nil
local _camera_restore = nil

local function _player_unit()
	local player = _local_player()
	local unit = player and player.player_unit

	return _unit_ok(unit) and unit or nil, player
end

local function _schedule(trapper, target_hint, seen_t, reactive)
	local me = _player_unit()

	if not me then
		return
	end

	local target = target_hint

	if not _unit_ok(target) then
		target = _target_of(trapper)
	end

	if target ~= me then
		return
	end

	local distance = Vector3.length(_flat(_position(me) - _position(trapper)))

	if distance > math.min(S.max_range, MAX_NET_DISTANCE + PLAYER_RADIUS) then
		_log("wind-up at %.1f m: out of net range, ignored", distance)

		return
	end

	local rtt = _ping()
	-- The server should see the dodge start at release (the aim follows the target until then). What I see is half a
	-- round trip old (adaptive_clock_handler_client.lua 88) and my input runs half a round trip plus 2 fixed steps later
	-- (adaptive_clock_handler_server.lua 4, 58).
	local delay = rtt + 2 * _fixed_step()
	local press_t

	if reactive then
		press_t = seen_t
	else
		press_t = seen_t + AIM_DURATION - delay + S.offset
	end

	local existing = plans[trapper]

	if existing and existing.phase ~= "done" then
		if reactive and existing.phase == "wait" then
			existing.press_t = math.min(existing.press_t, press_t)
		end

		return
	end

	plans[trapper] = {
		unit = trapper,
		seen_t = seen_t,
		press_t = press_t,
		rtt = rtt,
		distance = distance,
		phase = "wait",
	}

	_log("wind-up at %.1f m, ping %d ms, press in %d ms%s", distance, rtt * 1000, (press_t - seen_t) * 1000, reactive and " (net already fired)" or "")

	if S.push and not reactive and distance <= _push_radius(me) then
		local inventory = _component(me, "inventory")

		if inventory and inventory.wielded_slot == "slot_primary" and press_t - seen_t > PUSH_BLOCK_TIME + PUSH_PRESS_TIME then
			_push = { trapper = trapper, start_t = seen_t }
			_log("pushing first")
		end
	end
end

local function _on_wwise(fx_extension, event_name, optional_target_unit)
	if not S.auto_dodge or not event_name then
		return
	end

	if event_name ~= EVENT_WINDUP and event_name ~= EVENT_INTERRUPTED and event_name ~= EVENT_SHOOT then
		return
	end

	local unit = fx_extension and fx_extension._unit

	if not _unit_ok(unit) or _breed_name(unit) ~= BREED_NAME then
		return
	end

	local t = _timer("gameplay")

	if not t then
		return
	end

	if event_name == EVENT_WINDUP then
		plans[unit] = nil
		_schedule(unit, optional_target_unit, t, false)
	elseif event_name == EVENT_INTERRUPTED then
		local plan = plans[unit]

		if plan and plan.phase == "wait" then
			plan.phase = "done"
			_log("wind-up interrupted, dodge cancelled")
		end
	elseif event_name == EVENT_SHOOT then
		local plan = plans[unit]

		if plan then
			plan.shot_t = t

			if plan.started_t then
				_log("net fired %d ms after the dodge started here", (t - plan.started_t) * 1000)
			end
		end

		-- the wind-up was missed (joined late, packet loss): dodge now
		if not plan or plan.phase == "done" and not plan.started_t then
			_schedule(unit, optional_target_unit, t, true)
		end
	end
end

-- the wwise hook lives in QIangIQsTrappers.lua, which calls Dodge.on_wwise

-- ---------------------------------------------------------------------------
-- Choosing the dodge
-- ---------------------------------------------------------------------------

local function _yaw_basis(yaw)
	local rot = Quaternion.from_yaw_pitch_roll(yaw, 0, 0)

	return Quaternion.right(rot), Quaternion.forward(rot)
end

-- What Dodge.check does with a wanted world direction at this yaw: returns move x, y and the real world direction.
local function _resolve(dir, yaw)
	local right, forward = _yaw_basis(yaw)
	local x, y = Vector3.dot(dir, right), Vector3.dot(dir, forward)

	if y <= 0 then
		return x, y, dir, true
	end

	if math.abs(x) > 0.707 then
		local sx = x > 0 and 1 or -1

		return sx, 0, right * sx, false
	end

	return nil
end

-- ray from max_drop above the feet to max_drop below them; no ground in that range = a larger drop
-- dodge length: archetype base_distance x the largest weapon distance scale 1.1
-- (archetype_dodge_templates.lua, player_character_state_dodging.lua 208, weapon_dodge_templates.lua lerp_perfect)
_dodge_distance = function (me)
	local ext = ScriptUnit.has_extension(me, "unit_data_system")
	local ok, arch = pcall(function ()
		return ext and ext:archetype()
	end)
	local base = ok and arch and arch.dodge and arch.dodge.base_distance or 2.5

	return base * 1.1
end

-- a minion's contact radius: breed.player_locomotion_constrain_radius (player_unit_locomotion_extension.lua 266)
_body_radius = function (unit)
	local ext = ScriptUnit.has_extension(unit, "unit_data_system")
	local ok, breed = pcall(function ()
		return ext and ext:breed()
	end)

	return ok and breed and breed.player_locomotion_constrain_radius or PLAYER_RADIUS
end

local function _ground_z(pw, point, base_z)
	local from = Vector3(point.x, point.y, base_z + S.max_drop)
	local hit, position = PhysicsWorld.raycast(pw, from, Vector3.down(), 2 * S.max_drop, "closest", "types", "statics", "collision_filter", "filter_player_mover")

	return hit and position and position.z or nil
end

local function _path_safe(pw, me_pos, dir, me_unit)
	if not pw then
		return not S.ledge and not S.body_block, "no physics world"
	end

	local base_z = me_pos.z
	local length = _dodge_distance(me_unit)

	if S.ledge then
		-- every body radius out to the class's dodge length
		local step = PLAYER_RADIUS

		while step <= length + 1e-6 do
			local p = me_pos + dir * step
			local z = _ground_z(pw, p, base_z)

			if not z or z < base_z - S.max_drop then
				return false, string.format("ledge at %.1f m", step)
			end

			step = step + PLAYER_RADIUS
		end
	end

	if S.body_block then
		-- one ray at body-radius height (a single height is a choice, not a game value)
		local hit, _, distance = PhysicsWorld.raycast(pw, me_pos + Vector3(0, 0, PLAYER_RADIUS), dir, length, "closest", "types", "statics", "collision_filter", "filter_player_mover")

		if hit and distance and distance < WALL_CLEAR then
			return false, string.format("wall at %.1f m", distance)
		end

		local blockers = {}
		local manager = Managers.state and Managers.state.extension
		local side_system = manager and manager:system("side_system")
		local broadphase_system = manager and manager:system("broadphase_system")
		local side = side_system and side_system.side_by_unit[me_unit]

		if side and broadphase_system and broadphase_system.broadphase then
			local results = {}
			local ok, count = pcall(broadphase_system.broadphase.query, broadphase_system.broadphase, me_pos, length + PLAYER_RADIUS, results, side:relation_side_names("enemy"))

			if ok and count then
				for i = 1, count do
					blockers[#blockers + 1] = results[i]
				end
			end
		end

		local pm = Managers.player
		local ok_p, players = pcall(pm.players, pm)

		if ok_p and players then
			for _, player in pairs(players) do
				if player.player_unit ~= me_unit then
					blockers[#blockers + 1] = player.player_unit
				end
			end
		end

		for _, unit in ipairs(blockers) do
			if _unit_ok(unit) then
				local rel = _flat(_position(unit) - me_pos)
				local along = Vector3.dot(rel, dir)

				if along > 0 and along < length then
					local side_off = Vector3.length(rel - dir * along)

					if side_off < PLAYER_RADIUS + _body_radius(unit) then
						return false, string.format("body in the way at %.1f m", along)
					end
				end
			end
		end
	end

	return true
end

-- Returns move x, y, world direction, new yaw or nil.
local function _choose(plan, me_unit, player)
	local me_pos = _position(me_unit)
	local away = _flat(me_pos - _position(plan.unit))

	if Vector3.length(away) < 0.01 then
		return nil, "on top of the Trapper"
	end

	away = Vector3.normalize(away)

	local p1 = Vector3(-away.y, away.x, 0)
	local p2 = -p1
	local c45 = MIN_LATERAL
	local candidates = { p1, p2, p1 * c45 + away * c45, p2 * c45 + away * c45 }
	local orientation = player:get_orientation()
	local yaw = orientation and orientation.yaw or 0
	local pw = _physics_world()
	local reasons = {}

	-- straight sideways first: the one the game can do without turning the camera comes first
	local x1, _, _, exact1 = _resolve(p1, yaw)

	if not exact1 then
		candidates[1], candidates[2] = p2, p1
	end

	for index, wanted in ipairs(candidates) do
		local x, y, real, exact = _resolve(wanted, yaw)
		local new_yaw = nil

		-- not reachable from this view, or only straight sideways and too far off the wanted angle
		-- turn the camera whenever the wanted direction cannot be dodged exactly from this view
		if not exact and S.camera_mode == "when_needed" then
			-- turn so the wanted side is straight right or left, whichever turn is smaller
			local _, fwd = _yaw_basis(yaw)
			local f_right = Vector3.cross(Vector3.up(), wanted)
			local f_left = -f_right
			local use_right = Vector3.dot(f_right, fwd) >= Vector3.dot(f_left, fwd)
			local new_fwd = use_right and f_right or f_left

			new_yaw = Quaternion.yaw(Quaternion.look(new_fwd, Vector3.up()))
			x, y, real = use_right and 1 or -1, 0, wanted
		end

		if x then
			local lateral = math.abs(Vector3.dot(real, p1))

			if lateral >= MIN_LATERAL - 1e-3 then
				local safe, why = _path_safe(pw, me_pos, real, me_unit)

				if safe then
					return x, y, real, new_yaw, index
				end

				reasons[#reasons + 1] = why
			end
		end
	end

	return nil, table.concat(reasons, ", ")
end

-- ---------------------------------------------------------------------------
-- Per frame (cheap when nothing is planned)
-- ---------------------------------------------------------------------------

-- "dodging" is allowed so a dodge that has just started is seen as started, not as a failure
local DODGE_STATES = { walking = true, sprinting = true, dodging = true }

local function _set_move(x, y, until_main)
	_inject.move_right = math.max(x, 0)
	_inject.move_left = math.max(-x, 0)
	_inject.move_forward = math.max(y, 0)
	_inject.move_backward = math.max(-y, 0)
	_inject.sprinting = false
	_inject.sprint = false
	_inject_until = math.min(until_main, _main_time() + MAX_INJECT)
end

local function _end_active(plan)
	_clear_inject()

	if plan then
		plan.phase = "done"
	end

	_active = nil
end

local function _update_push(t, me)
	local push = _push

	if not push then
		return
	end

	local dt = t - push.start_t
	local inventory = _component(me, "inventory")

	if dt > PUSH_BLOCK_TIME + PUSH_PRESS_TIME or not inventory or inventory.wielded_slot ~= "slot_primary" then
		_push = nil
		_inject.action_two_hold = nil
		_inject.action_one_pressed = nil
		_inject.action_one_hold = nil

		return
	end

	_inject.action_two_hold = true

	if dt >= PUSH_BLOCK_TIME then
		_inject.action_one_pressed = true
		_inject.action_one_hold = true
	end

	_inject_until = math.max(_inject_until, _main_time() + 0.05)
end

local function _restore_camera_now()
	local r = _camera_restore

	_camera_restore = nil

	if r and r.player then
		local o = r.player:get_orientation()

		r.player:set_orientation(r.yaw, o and o.pitch or 0, o and o.roll or 0)
	end
end

local function _update(dt)
	-- The dodge direction is local and is turned by the current view every frame
	-- (player_character_state_dodging.lua 394-396), so the view goes back only once the dodge is over.
	if _camera_restore then
		local t = _timer("gameplay")
		local me = _player_unit()
		local movement = me and _component(me, "movement_state")
		local cs = me and _component(me, "character_state")
		local still_dodging = movement and movement.is_dodging or cs and cs.state_name == "dodging"

		if not me or t and (not still_dodging and t >= _camera_restore.t or t >= _camera_restore.t + 0.8) then -- cap: two 0.4 s dodges (archetype_dodge_templates.lua 5)
			_restore_camera_now()
		end
	end

	if not next(plans) and not _push then
		if _inject_until ~= 0 then
			_inject_active()
		end

		return
	end

	local t = _timer("gameplay")
	local me, player = _player_unit()

	if not t or not me or not mod:is_enabled() or not S.auto_dodge then
		plans = {}
		_push = nil
		_end_active(nil)

		return
	end

	if _wield_pressed then
		_wield_pressed = false

		if _active or _push then
			_log("you switched weapons: cancelled")
			plans = {}
			_push = nil
			_end_active(nil)

			return
		end
	end

	local cs = _component(me, "character_state")
	local state_name = cs and cs.state_name

	if not DODGE_STATES[state_name] then
		for unit, plan in pairs(plans) do
			if plan.phase == "wait" and t > plan.press_t then
				plan.phase = "done"
				_log("could not dodge while %s", tostring(state_name))
			end
		end

		_push = nil
		_end_active(_active)

		return
	end

	_update_push(t, me)

	-- start the earliest due plan
	if not _active then
		local best

		for _, plan in pairs(plans) do
			if plan.phase == "wait" and t >= plan.press_t - PRE_MOVE() and (not best or plan.press_t < best.press_t) then
				best = plan
			end
		end

		if best then
			if not _unit_ok(best.unit) then
				best.phase = "done"
			else
				local x, y, real, new_yaw = _choose(best, me, player)

				if not x then
					best.phase = "done"
					_log("no safe dodge: %s", tostring(y))
				else
					if new_yaw then
						local o = player:get_orientation()

						if S.restore_camera and o then
							best.restore_yaw = o.yaw
						end

						player:set_orientation(new_yaw, o and o.pitch or 0, o and o.roll or 0)
					end

					best.move_x, best.move_y = x, y
					best.phase = "move"
					_active = best
					_log("dodge side chosen%s", new_yaw and " (camera turned)" or "")
				end
			end
		end
	end

	local plan = _active

	if plan then
		local movement = _component(me, "movement_state")
		local dodging = movement and movement.is_dodging or state_name == "dodging"

		_set_move(plan.move_x, plan.move_y, _main_time() + 0.1)

		if plan.phase == "move" and t >= plan.press_t then
			plan.phase = "press"
		end

		if plan.phase == "press" then
			if dodging then
				plan.phase = "started"
				plan.started_t = t
				_inject.dodge = nil
				_log("dodge started %d ms after the planned press", (t - plan.press_t) * 1000)

				if S.debug and _unit_ok(plan.unit) then
					-- numbers only: a Vector3 kept across frames goes stale
					local p, q = _position(me), _position(plan.unit)

					plan.m_x, plan.m_y, plan.m_tx, plan.m_ty = p.x, p.y, q.x, q.y
				end

				if plan.restore_yaw then
					_camera_restore = { player = player, yaw = plan.restore_yaw, t = t }
				end
			elseif t > plan.press_t + PRESS_WINDOW() then
				_log("the game refused the dodge (cooldown or action)")
				_end_active(plan)
			else
				_inject.dodge = true
			end
		elseif plan.phase == "started" and t > plan.started_t + HOLD_AFTER_START() then
			_end_active(plan)
		end
	end

	-- forget finished plans and check whether a fired net caught us
	for unit, p in pairs(plans) do
		if p.m_x and p.started_t and t >= p.started_t + 0.2 then
			-- debug: real angle between the first 0.2 s of movement and the net path
			local pos = _position(me)
			local mx, my = pos.x - p.m_x, pos.y - p.m_y
			local nx, ny = p.m_x - p.m_tx, p.m_y - p.m_ty
			local ml, nl = math.sqrt(mx * mx + my * my), math.sqrt(nx * nx + ny * ny)

			if ml > 0.05 and nl > 0.01 then
				_log("moved %.2f m at %d degrees to the net path", ml, math.deg(math.acos(math.clamp(math.abs(mx * nx + my * ny) / (ml * nl), 0, 1))))
			end

			p.m_x = nil
		end

		if p.phase == "done" and t > (p.shot_t or p.press_t) + 1.5 then
			if S.debug and p.shot_t then
				local disabled = _component(me, "disabled_character_state")

				_log("result: %s", disabled and disabled.disabling_type == "netted" and "netted" or "not netted")
			end

			plans[unit] = nil
		end
	end
end

local function _safe_update(dt)
	local ok, err = pcall(_update, dt)

	if not ok then
		plans = {}
		_push = nil
		_end_active(nil)
		_report("update", err)
	end
end

local function _reset()
	plans = {}
	_push = nil
	pcall(_restore_camera_now)
	_end_active(nil)
	_wield_pressed = false
end

mod.toggle_dodge = function ()
	S.auto_dodge = not S.auto_dodge

	if not S.auto_dodge then
		_reset()
	end

	mod:echo("Trapper auto dodge " .. (S.auto_dodge and "on" or "off"))
end

mod:command("trappers_dodge_status", "Show what the Trapper auto dodge is doing.", function ()
	local n = 0

	for _ in pairs(plans) do
		n = n + 1
	end

	mod:echo(string.format("auto dodge %s, plans %d, active %s, ping %d ms, input hook %s", S.auto_dodge and "on" or "off", n, tostring(_active ~= nil), _ping() * 1000, hooked and "ok" or "failed"))
end)

return {
	on_wwise = function (fx_extension, event_name, optional_target_unit)
		local ok, err = pcall(_on_wwise, fx_extension, event_name, optional_target_unit)

		if not ok then
			_report("wwise", err)
		end
	end,
	update = _safe_update,
	reset = _reset,
	refresh = _refresh_settings,
}
