local mod = get_mod("QIangIQsTrappers")

local function checkbox(id, default)
	return { setting_id = id, type = "checkbox", default_value = default, tooltip = id .. "_tooltip" }
end

local function numeric(id, default, low, high)
	return { setting_id = id, type = "numeric", default_value = default, range = { low, high }, tooltip = id .. "_tooltip" }
end

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			{
				setting_id = "toggle_key",
				type = "keybind",
				default_value = {},
				keybind_trigger = "pressed",
				keybind_type = "function_call",
				function_name = "toggle_view",
				tooltip = "toggle_key_tooltip",
			},
			checkbox("show_labels", true),
			checkbox("show_target_line", true),
			{
				setting_id = "rings_mode",
				type = "dropdown",
				default_value = "loaded",
				tooltip = "rings_mode_tooltip",
				options = {
					{ text = "rings_loaded", value = "loaded" },
					{ text = "rings_always", value = "always" },
					{ text = "rings_me", value = "me" },
					{ text = "rings_off", value = "off" },
				},
			},
			checkbox("show_warning_ring", false),
			checkbox("show_net_path", true),
			checkbox("show_self_alert", true),
			numeric("alert_position", 70, 5, 95),
			numeric("max_distance", 60, 10, 150),
			numeric("label_size", 16, 10, 32),
			checkbox("echo_events", false),
		},
	},
}
