-- No percent signs in any string here: DMF passes localize text through string.format.
return {
	mod_name = { en = "QIangIQs Trappers" },
	mod_description = { en = "Overlay for every Trapper (Scab netgunner): who it is targeting, whether its net is loaded, what it is doing (approaching, winding up, net in flight, dragging, reloading, fleeing on cooldown), its 14 m net range and 10 m firing distance, the net's flight path, and a warning when it is after you. All numbers come from the game's own Trapper code. Exact values when you host (solo); inferred from the game's networked sounds and effects when you are a client on a Fatshark server. Client-side drawing only. /trappers_info lists tracked Trappers." },

	toggle_key = { en = "Toggle key" },
	toggle_key_tooltip = { en = "Turn the Trapper overlay on and off without opening the mod menu." },

	show_labels = { en = "Labels above Trappers" },
	show_labels_tooltip = { en = "Text over each Trapper: health, net loaded or empty, current action with its timer, and its target with the distance to it." },
	show_target_line = { en = "Line to target" },
	show_target_line_tooltip = { en = "Draw a line from each Trapper to the player it is targeting. Red when the target is you." },

	rings_mode = { en = "Range rings" },
	rings_mode_tooltip = { en = "Two rings on the ground around each Trapper. Outer (orange) 14 m: the farthest the net can fly. Inner (red) 10 m: once its target is this close and its gun arm has a clear line to the target, it stops approaching and starts the 0.83 s wind-up. The rings are flat at the Trapper's feet." },
	rings_loaded = { en = "Only while its net is loaded (or unknown)" },
	rings_always = { en = "Always" },
	rings_me = { en = "Only when it targets me" },
	rings_off = { en = "Off" },

	show_warning_ring = { en = "20 m proximity warning ring" },
	show_warning_ring_tooltip = { en = "Also draw the 20 m ring at which the game plays the Trapper proximity warning sound to its target (re-arms once the target is 25 m away, at most every 10 s)." },

	show_net_path = { en = "Net path and net" },
	show_net_path_tooltip = { en = "While a Trapper winds up, draw the straight line its net will fly (14 m long, toward the target's aim point). While the net is in the air, draw its 0.5 m hit sphere and the 0.35 m dodge core." },

	show_self_alert = { en = "Warning when it targets me" },
	show_self_alert_tooltip = { en = "Text on screen when a Trapper is after you: distance, wind-up countdown, and the moment the net is in the air." },
	alert_position = { en = "Warning height (screen)" },
	alert_position_tooltip = { en = "Height of the on-screen warning, as a share of the screen height (0 to 100)." },

	max_distance = { en = "Max distance (m)" },
	max_distance_tooltip = { en = "Trappers farther than this from the camera are not drawn." },
	label_size = { en = "Label size" },
	label_size_tooltip = { en = "Font size of the labels (scaled to 1080p)." },

	echo_events = { en = "Print Trapper events in chat" },
	echo_events_tooltip = { en = "Debug: print each Trapper event the mod sees (approach, wind-up, shot, net end, pull, interrupt) in the chat." },
}
