return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsTrappers` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsTrappers", {
			mod_script       = "QIangIQsTrappers/scripts/mods/QIangIQsTrappers/QIangIQsTrappers",
			mod_data         = "QIangIQsTrappers/scripts/mods/QIangIQsTrappers/QIangIQsTrappers_data",
			mod_localization = "QIangIQsTrappers/scripts/mods/QIangIQsTrappers/QIangIQsTrappers_localization",
		})
	end,
	packages = {},
}
