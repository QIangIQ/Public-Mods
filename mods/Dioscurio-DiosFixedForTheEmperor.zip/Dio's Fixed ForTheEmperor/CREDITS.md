# Dio's Fixed ForTheEmperor

Original mod: For the Emperor by Seventeen.
Fix: Dioscurio.

The original mod did not come with a license file. Seventeen gave Dioscurio permission to redistribute this fixed version (2026-11-20).

This replaces Seventeen's For the Emperor: it registers under the same mod id ("ForTheEmperor"). Remove the original ForTheEmperor folder before installing this one; the line in mod_load_order.txt stays as it is, because the id has not changed.

## What was fixed

Reported by Hoatzin: tagging with the scroll-up keybind crashed him in the Mourningstar while it worked in missions. He runs SoloMourningstar with `solo_hub_on_enter`, so his own game hosts the hub.

Social hub player units carry no SmartTagExtension. The mod's `comms_allowed()` could never return false - its `not (...) and (...)` condition has no true case - so the keybinds ran in the hub as well, and it kept the first `HudElementSmartTagging` it ever saw, so a destroyed mission element was still there to call. As host, the tag was stored and then failed to register an owner; sixty seconds later the tag expired and removing it crashed on the missing extension.

Public hub players never saw it: their request goes to the host, which rejects it.

- `comms_allowed()` rewritten: false with no game mode, in the hub or prologue hub, with no live HUD element, while a view or chat holds input, or when the player unit is missing or dead.
- New `can_tag(unit)`: tag only when the smart tag system exists and that unit has the extension.
- The HUD element is refreshed every frame and cleared when it is destroyed; keybind setup runs once.
- `dibs_option` skips its rewrite when the tag is gone or the replier has no extension.

Side effect: the voice and chat keybinds no longer fire in the hub or while a menu or chat is open. Vanilla has no comms wheel in the hub either.
