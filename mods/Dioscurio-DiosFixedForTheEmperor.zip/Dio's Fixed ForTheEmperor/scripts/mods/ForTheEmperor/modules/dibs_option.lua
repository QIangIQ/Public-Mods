local mod = get_mod("ForTheEmperor")

mod:hook("SmartTagSystem", "reply_tag", function(fun, self, tag_id, replier_unit, reply_name)
	local tag = self._all_tags[tag_id]

	-- Dio fix 2026-11-20: skip when the tag is gone or the replier cannot own tags
	-- (hub units have no smart tag extension; set_tag would store a broken tag)
	if mod:get("disable_dibs") and reply_name == "dibs" and tag and self._unit_extension_data[replier_unit] then
		self:cancel_tag(tag_id, tag._tagger_unit)

		self:set_tag(tag._template.name, replier_unit, tag._target_unit)
	else
		fun(self, tag_id, replier_unit, reply_name)
	end
end)
