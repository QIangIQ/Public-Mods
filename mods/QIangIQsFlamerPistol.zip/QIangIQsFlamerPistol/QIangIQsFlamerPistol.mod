return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsFlamerPistol` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsFlamerPistol", {
            mod_script = "QIangIQsFlamerPistol/scripts/mods/QIangIQsFlamerPistol/QIangIQsFlamerPistol",
            mod_data = "QIangIQsFlamerPistol/scripts/mods/QIangIQsFlamerPistol/QIangIQsFlamerPistol_data",
            mod_localization = "QIangIQsFlamerPistol/scripts/mods/QIangIQsFlamerPistol/QIangIQsFlamerPistol_localization",
        })
    end,
    version = "0.5.0",
    author = "QIangIQ",
    packages = {},
}
