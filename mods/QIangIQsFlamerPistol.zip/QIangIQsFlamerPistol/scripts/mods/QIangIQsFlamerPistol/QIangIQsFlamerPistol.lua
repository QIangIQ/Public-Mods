-- QIangIQ's Flamer Pistol 0.5.0: the datamined Flamer Pistol as a Zealot weapon (split off QIangIQsDauntlessArmory 0.4.2).
--
-- What is datamined (A:\Dowloads\Darktide_NonMod\dauntless_datamine, INDEX.md, Oct 11 2026 build):
--   * Retail units with their own packages: content/weapons/player/ranged/flamer_pistol/attachments receiver/barrel/magazine/
--     grip_01. Node names (recovered by id32 match, _scratch_xbow\nodes.txt): the receiver has ap_barrel_01, ap_magazine_01,
--     ap_grip_01; the barrel has fx_muzzle_02 + fx_pilot, exactly flamer_p1_m1's fx_sources (flamer_p1_m1.lua:643).
--   * NOT datamined: weapon template, stats, actions, animations, item master data, and no flamer pistol rig.
--
-- So behaviour is borrowed: flamer_p1_m1 (the Purgation Flamer) for firing, laspistol_p1_m1 for the rig, state machines and
-- reload. New weapon pattern = QIangIQsShardStaff: template clone into WeaponTemplates + NetworkLookup append + particle/sound
-- alias copy; item clone into MasterItems.get_cached(); equip by override_slot (training_grounds_steps.lua:341-347).
-- Attachments: _spawn_attachment links every attachment with World.LINK_MODE_NODE_NAME unless the slot sets
-- link_map_mode_override, so the receiver slot uses "LINK_MODE_NONE" and every part sits under it (0.2.0).
-- Items only load resource_dependencies, so the template's resources are merged in with
-- WeaponTemplateResourceDependencies.generate (item_package.lua:239-249; a missing lasgun_pistol state machine crashed 0.2.0).
-- Flamer anim events with a laspistol counterpart are swapped to it; any event the lasgun_pistol state machine still lacks is
-- skipped with Unit.has_animation_event (as player_character_state_ledge_vaulting.lua:109).
-- Grip: the hand holds the rig root where the donor's trigger sits (laspistol ap_trigger_01 0,-0.0073,0.0168; flamer pistol
-- receiver ap_trigger_01 0,0.063,0.0636), so the static receiver root is shifted by the difference (grip_offset).
--
-- 0.5.0 (split from QIangIQsDauntlessArmory, user: separate mods, HUD icon, ADS crosshair):
--   * Bottom-right weapon icon shows the Flamer Pistol, not the Flamer (see "Bottom-right weapon icon" below).
--   * ADS: the laspistol's reflex animation lines up the laspistol's own sights, but the flamer pistol receiver stands taller
--     (top z 0.1699 over the laspistol receiver's 0.1302, barrel top 0.1414; _scratch_xbow las.py), so it covered the crosshair.
--     While aiming the first-person model is lowered by mod setting ads_drop_cm (default 5 cm, eased in and out), the way
--     QIangIQsCrossbow lowers its viewmodel (ViewModelTweaker's PlayerUnitFirstPersonExtension update_unit_position hook).
--   * Hosting (Psykhanium, SoloPlay) runs animation through AuthoritativePlayerUnitAnimationExtension, which has no
--     _local_wielded_weapon_template: the wielded template name is stored from inventory_slot_wielded on both classes.
-- Author: QIangIQ
local mod = get_mod("QIangIQsFlamerPistol")

local WeaponTemplates = require("scripts/settings/equipment/weapon_templates/weapon_templates")
local MasterItems = require("scripts/backend/master_items")
local NetworkLookup = require("scripts/network_lookup/network_lookup")

local W = "content/weapons/player/ranged/"
local ITEM_ROOT = "content/items/weapons/player/ranged/"

local WEAPONS = {
    {
        key = "flamerpistol",
        template = "flamer_pistol_p1_m1",
        source_template = "flamer_p1_m1",
        item = ITEM_ROOT .. "flamer_pistol_p1_m1",             -- same naming pattern as crossbow_p1_m1 (not found in the files)
        source_item = ITEM_ROOT .. "flamer_p1_m1",
        base_unit = nil,                                       -- no flamer pistol rig exists: the laspistol's is used
        anim_donor = { template = "laspistol_p1_m1", item = ITEM_ROOT .. "laspistol_p1_m1" },
        grip_offset = { 0, -0.0703, -0.0468 },                 -- laspistol trigger - flamer pistol trigger
        display = "loc_qiangiq_dauntless_flamer_pistol",
        parts = {
            receiver = { unit = W .. "flamer_pistol/attachments/receiver_01/receiver_01" },
            barrel = { unit = W .. "flamer_pistol/attachments/barrel_01/barrel_01", attach_node = "ap_barrel_01" },
            magazine = { unit = W .. "flamer_pistol/attachments/magazine_01/magazine_01", attach_node = "ap_magazine_01" },
            grip = { unit = W .. "flamer_pistol/attachments/grip_01/grip_01", attach_node = "ap_grip_01" },
        },
    },
}

-- Flamer event -> laspistol event for the same role (flamer_p1_m1.lua / laspistol_p1_m1.lua line numbers):
--   action_shoot.anim_event "attack_shoot_start" (247) -> nil: laspistol action_shoot.anim_event = nil (229), its shot anim
--     is fire_configuration.anim_event "attack_shoot" (270), which the flamer burst also has (288).
--   action_shoot_braced.anim_end_event "attack_finished" (319) -> nil: no laspistol shoot action has an end event.
--   push.anim_event "attack_push" (497) -> "weapon_special" (laspistol action_normal_push, 556).
--   alternate_fire_settings "to_braced"/"to_unaim_braced" (653/655) -> "to_reflex"/"to_unaim_reflex" (917/918).
local function overlay_laspistol(clone, donor)
    local actions = clone.actions

    clone.anim_state_machine_3p = donor.anim_state_machine_3p
    clone.anim_state_machine_1p = donor.anim_state_machine_1p
    clone.reload_template = donor.reload_template

    if actions.action_shoot and actions.action_shoot.anim_event == "attack_shoot_start" then
        actions.action_shoot.anim_event = nil
    end

    if actions.action_shoot_braced and actions.action_shoot_braced.anim_end_event == "attack_finished" then
        actions.action_shoot_braced.anim_end_event = nil
    end

    if actions.push and actions.push.anim_event == "attack_push" then
        actions.push.anim_event = "weapon_special"
    end

    local alt = clone.alternate_fire_settings

    if alt then
        alt.start_anim_event = alt.start_anim_event == "to_braced" and "to_reflex" or alt.start_anim_event
        alt.stop_anim_event = alt.stop_anim_event == "to_unaim_braced" and "to_unaim_reflex" or alt.stop_anim_event
    end
end

local PART_ORDER = { "receiver", "barrel", "magazine", "grip", "underbarrel" }

mod:add_global_localize_strings({
    loc_qiangiq_dauntless_flamer_pistol = { en = "Flamer Pistol (datamined)" },
})

local function say(fmt, ...)
    local text = string.format(fmt, ...)

    mod:echo(text)
    mod:info(text)
end

-- Network lookups (QIangIQsShardStaff append_lookup): new names go at the end so no existing id moves -------------
local function append_lookup(lookup_name, key)
    local lookup = NetworkLookup[lookup_name]

    if not lookup then
        return false, "no lookup"
    end

    local existing = rawget(lookup, key)

    if existing then
        return true, existing
    end

    local index = #lookup + 1

    rawset(lookup, index, key)
    rawset(lookup, key, index)

    return true, index
end

-- Particle / sound aliases keyed by wielded_weapon_template (QIangIQsShardStaff alias_template_keys) --------------
local ALIAS_MODULES = {
    "scripts/settings/particles/player_character_particle_aliases",
    "scripts/settings/sound/player_character_sound_event_aliases",
}

local function alias_keys(root, source, target, seen, counter)
    if type(root) ~= "table" or seen[root] then
        return
    end

    seen[root] = true

    local value = rawget(root, source)

    if value ~= nil and rawget(root, target) == nil then
        root[target] = value
        counter.n = counter.n + 1
    end

    for _, child in pairs(root) do
        if type(child) == "table" then
            alias_keys(child, source, target, seen, counter)
        end
    end
end

local function copy_aliases(source, target)
    local counter = { n = 0 }

    for _, path in ipairs(ALIAS_MODULES) do
        local ok, module = pcall(require, path)

        if ok then
            alias_keys(module, source, target, {}, counter)
        else
            mod:error("alias module %s: %s", path, tostring(module))
        end
    end

    return counter.n
end

-- State -------------------------------------------------------------------------------------------------------------
local state = {}

for _, spec in ipairs(WEAPONS) do
    state[spec.key] = { template_ok = false, item_ok = false, notes = {} }
end

local next_poll = 0

-- Template ----------------------------------------------------------------------------------------------------------
local function ensure_template(spec, st)
    local existing = rawget(WeaponTemplates, spec.template)

    if existing then
        st.template_ok = true
        st.official_template = not st.template_ours

        return true
    end

    local source = WeaponTemplates[spec.source_template]
    local donor = spec.anim_donor and WeaponTemplates[spec.anim_donor.template]

    if not source or (spec.anim_donor and not donor) then
        return false
    end

    local clone = table.clone(source)

    clone.name = spec.template

    -- weapon_templates.lua _require_template: action_settings.name = action_name
    for action_name, action_settings in pairs(clone.actions) do
        action_settings.name = action_name
    end

    if donor then
        overlay_laspistol(clone, donor)
        st.guard_anims = true
    end

    WeaponTemplates[spec.template] = clone
    st.template_ours = true

    local ok, index = append_lookup("weapon_templates", spec.template)

    st.template_id = ok and index or nil
    st.aliases = copy_aliases(spec.source_template, spec.template)
    st.template_ok = ok

    return ok
end

-- Items -------------------------------------------------------------------------------------------------------------
local function part_of(item)
    local base_unit = type(item) == "table" and item.base_unit

    if type(base_unit) ~= "string" then
        return nil
    end

    return base_unit:match("/attachments/([%a_]+)_%a*%d+/")
end

local function find_item(cache, preferred, template)
    local direct = rawget(cache, preferred)

    if direct and direct.weapon_template == template then
        return preferred, direct
    end

    for name, item in pairs(cache) do
        if type(item) == "table" and item.weapon_template == template then
            return name, item
        end
    end
end

-- Only base_unit is kept: Items.base_unit can also read per-breed / first-person variants of the source part
local function only_base_unit(item, unit)
    for key in pairs(item) do
        if type(key) == "string" and key ~= "base_unit" and key:find("^base_unit") then
            item[key] = nil
        end
    end

    item.base_unit = unit
end

local function attachment_name(spec, part)
    return ITEM_ROOT .. "qiangiq_dauntless/" .. spec.key .. "_" .. part .. "_01"
end

local function make_attachment(cache, spec, part, template_item)
    local name = attachment_name(spec, part)
    local def = spec.parts[part]
    local item = table.clone(template_item)

    only_base_unit(item, def.unit)
    item.name = name
    item.resource_dependencies = { [def.unit] = true }
    item.attachments = nil
    item.material_overrides = nil
    item.material_override_items = nil

    if def.attach_node then
        item.attach_node = def.attach_node
    end

    cache[name] = item

    return name
end

-- Walk the source weapon's attachment tree. Each slot whose item is a weapon part we have is pointed at our part;
-- every other item becomes "" (spawns nothing). Parts we have but the source lacks go under the receiver.
local function rebuild_tree(cache, spec, tree, placed, reachable, notes)
    for slot_name, node in pairs(tree) do
        if type(node) == "table" then
            local item_name = node.item
            local keep_children_reachable = reachable

            if type(item_name) == "string" and item_name ~= "" then
                local source_part_item = rawget(cache, item_name)
                local part = part_of(source_part_item)

                if part and spec.parts[part] and reachable and not placed[part] then
                    node.item = make_attachment(cache, spec, part, source_part_item)
                    placed[part] = { node = node, template_item = source_part_item, parent = tree, slot = slot_name }
                    notes[#notes + 1] = string.format("%s <- %s", part, item_name)
                else
                    node.item = ""
                    keep_children_reachable = false
                end
            end

            if type(node.children) == "table" then
                rebuild_tree(cache, spec, node.children, placed, keep_children_reachable, notes)
            end
        end
    end
end

-- Source tree as "slot_path=item [leaf override, map mode]" for the log, to check placement against the game's data
local function dump_tree(tree, prefix, out)
    for slot_name, node in pairs(tree) do
        if type(node) == "table" then
            local path = prefix .. slot_name

            out[#out + 1] = string.format("%s=%s%s%s", path, tostring(node.item),
                node.leaf_attach_node_override and (" leaf:" .. tostring(node.leaf_attach_node_override)) or "",
                node.link_map_mode_override and (" map:" .. tostring(node.link_map_mode_override)) or "")

            if type(node.children) == "table" then
                dump_tree(node.children, path .. "/", out)
            end
        end
    end

    return out
end

-- Retail HUD icon (unreleased-asset sweep build 139617: material+package content/ui/materials/icons/weapons/hud/flamer_pistol_p1_m1).
-- Used when the package exists, so the bottom-right icon needs no other mod; the drawn PNG (SimpleAssets) is the opt-in fallback.
local RETAIL_HUD_ICON = "content/ui/materials/icons/weapons/hud/flamer_pistol_p1_m1"
local retail_icon = { used = false }

local function build_item(cache, spec, st)
    local source_name, source_item = find_item(cache, spec.source_item, spec.source_template)

    if not source_item then
        return false
    end

    local rig = spec.base_unit

    if spec.anim_donor then
        local _, donor_item = find_item(cache, spec.anim_donor.item, spec.anim_donor.template)

        rig = donor_item and donor_item.base_unit

        if type(rig) ~= "string" or rig == "" then
            return false, "no " .. spec.anim_donor.template .. " item to take the rig from"
        end

        st.rig = rig
    end

    local item = table.clone(source_item)
    local notes = {}
    local placed = {}

    item.name = spec.item
    item.weapon_template = spec.template
    item.archetypes = { "zealot" }

    if rig then
        local deps = item.resource_dependencies or {}

        if item.base_unit then
            deps[item.base_unit] = nil
        end

        only_base_unit(item, rig)
        deps[rig] = true
        item.resource_dependencies = deps
    end

    item.display_name = spec.display

    local ok_icon, icon_package = pcall(Application.can_get_resource, "package", RETAIL_HUD_ICON)

    if ok_icon and icon_package and mod:get("drawn_hud_icon") ~= true then
        local icon_deps = item.resource_dependencies or {}

        if type(item.hud_icon) == "string" then
            icon_deps[item.hud_icon] = nil
        end

        item.hud_icon = RETAIL_HUD_ICON
        icon_deps[RETAIL_HUD_ICON] = true
        item.resource_dependencies = icon_deps
        retail_icon.used = true
    end

    for _, field in ipairs({ "weapon_family_display_name", "weapon_pattern_display_name", "weapon_mark_display_name" }) do
        if type(item[field]) == "table" then
            item[field].loc_id = spec.display
        end
    end

    if type(item.attachments) ~= "table" then
        return false, "source item has no attachments"
    end

    mod:info("%s: source tree of %s: %s", spec.key, tostring(source_name),
        table.concat(dump_tree(item.attachments, "", {}), "; "))
    rebuild_tree(cache, spec, item.attachments, placed, true, notes)

    local receiver = placed.receiver

    if not receiver then
        return false, "no receiver slot in " .. tostring(source_name)
    end

    -- Static receiver: its nodes no longer follow same-named rig nodes, and every part hangs off those nodes
    receiver.node.link_map_mode_override = "LINK_MODE_NONE"
    receiver.node.children = receiver.node.children or {}

    local receiver_children = receiver.node.children

    for _, part in ipairs(PART_ORDER) do
        local p = placed[part]

        if p and part ~= "receiver" then
            p.node.leaf_attach_node_override = nil
            p.node.link_map_mode_override = nil

            if p.parent ~= receiver_children then
                local slot = rawget(receiver_children, p.slot) == nil and p.slot or ("qiangiq_" .. part)

                p.parent[p.slot] = { item = "", children = {} }
                receiver_children[slot] = p.node
                notes[#notes + 1] = string.format("%s moved under the receiver", part)
            end
        end
    end

    for _, part in ipairs(PART_ORDER) do
        if spec.parts[part] and not placed[part] then
            receiver.node.children = receiver.node.children or {}
            receiver.node.children["qiangiq_" .. part] = {
                item = make_attachment(cache, spec, part, receiver.template_item),
                children = {},
            }
            notes[#notes + 1] = string.format("%s added under the receiver (%s)", part, spec.parts[part].attach_node)
        end
    end

    -- What the offline item compile adds for the weapon template (item_package.lua:239-249): state machines, sounds,
    -- effects. Without it the laspistol state machine was never loaded (crash on equipping the flamer pistol).
    local deps = item.resource_dependencies or {}
    local WeaponTemplateResourceDependencies = require("scripts/utilities/weapon_template_resource_dependencies")

    for _, resource in ipairs(WeaponTemplateResourceDependencies.generate(spec.template)) do
        deps[resource] = true
    end

    item.resource_dependencies = deps

    local ok, index = append_lookup("player_item_names", spec.item)

    if not ok then
        return false
    end

    cache[spec.item] = item
    st.item_id = index
    st.source_item_name = source_name
    st.slot = item.slots and item.slots[1]
    st.notes = notes

    return true
end

local function ensure_item(spec, st)
    local ok, has_data = pcall(MasterItems.has_data)

    if not ok or not has_data then
        return false
    end

    local cache = MasterItems.get_cached()
    local existing = rawget(cache, spec.item)

    if existing then
        st.item_ok = true

        return true
    end

    local built, err = build_item(cache, spec, st)

    if err and err ~= st.last_error then
        st.last_error = err
        mod:error("%s: %s", spec.key, err)
    end

    st.item_ok = built and rawget(cache, spec.item) ~= nil

    return st.item_ok
end

-- Zealot unlock list (weapon_unlock_settings.lua builds WeaponUnlockSettings[archetype][level] = { item names });
-- realms_loadout weapon_catalog.lua human_weapon_levels_by_name builds its human weapon list from it.
local function add_to_unlock_list()
    if not mod:get("add_to_unlock_list") then
        return
    end

    local ok, unlocks = pcall(require, "scripts/settings/weapon_unlock/weapon_unlock_settings")
    local zealot = ok and unlocks and unlocks.zealot

    if not zealot then
        mod:error("WeaponUnlockSettings.zealot not found")

        return
    end

    local level = math.floor(mod:get("unlock_level") or 1)

    zealot[level] = zealot[level] or {}

    for _, spec in ipairs(WEAPONS) do
        if not table.find(zealot[level], spec.item) then
            table.insert(zealot[level], spec.item)
        end
    end
end

local function poll()
    if next_poll > os.clock() then
        return
    end

    next_poll = os.clock() + 1

    for _, spec in ipairs(WEAPONS) do
        local st = state[spec.key]
        local before_t, before_i = st.template_ok, st.item_ok
        local ok_t, err_t = pcall(ensure_template, spec, st)
        local ok_i, err_i = true, nil

        if st.template_ok then
            ok_i, err_i = pcall(ensure_item, spec, st)
        end

        if not ok_t then
            mod:error("%s template: %s", spec.key, tostring(err_t))
        end

        if not ok_i then
            mod:error("%s item: %s", spec.key, tostring(err_i))
        end

        if st.template_ok and not before_t then
            if st.official_template then
                mod:info("%s: the game now has its own %s template; using it", spec.key, spec.template)
            else
                mod:info("%s: template %s registered (clone of %s), %s alias entries", spec.key, spec.template,
                    spec.source_template, tostring(st.aliases))
            end
        end

        if st.item_ok and not before_i then
            mod:info("%s: item %s injected (clone of %s, slot %s): %s", spec.key, spec.item,
                tostring(st.source_item_name), tostring(st.slot), table.concat(st.notes or {}, "; "))
        end
    end
end

-- Anim event guard for the overlaid template (player_unit_animation_extension.lua: anim_event* call Unit.animation_event on
-- self._unit or self._first_person_unit). The wielded template name is stored from inventory_slot_wielded because the
-- authoritative (hosting) class has no _local_wielded_weapon_template. Only events the current state machine lacks are skipped.
local ANIM_CLASSES = { "PlayerUnitAnimationExtension", "AuthoritativePlayerUnitAnimationExtension" }
local skipped_events = {}

local function guard(unit_field)
    return function(func, self, event_name, ...)
        if (self.__qiangiq_flamer_wielded or self._local_wielded_weapon_template) == WEAPONS[1].template then
            local unit = self[unit_field]

            if unit and not Unit.has_animation_event(unit, event_name) then
                if not skipped_events[event_name] then
                    skipped_events[event_name] = true
                    mod:info("skipped anim event %s (%s): not in the laspistol state machine", tostring(event_name),
                        unit_field == "_first_person_unit" and "1p" or "3p")
                end

                return
            end
        end

        return func(self, event_name, ...)
    end
end

for _, class_name in ipairs(ANIM_CLASSES) do
    local class = CLASS[class_name]

    if class then
        mod:hook_safe(class, "inventory_slot_wielded", function(self, weapon_template)
            self.__qiangiq_flamer_wielded = weapon_template and weapon_template.name or false
        end)

        for _, method in ipairs({ "anim_event", "anim_event_with_variable_float", "anim_event_with_variable_floats",
            "anim_event_with_variable_int" }) do
            if class[method] then
                mod:hook(class, method, guard("_unit"))
            end
        end

        for _, method in ipairs({ "anim_event_1p", "anim_event_with_variable_float_1p", "anim_event_with_variable_floats_1p" }) do
            if class[method] then
                mod:hook(class, method, guard("_first_person_unit"))
            end
        end
    end
end

-- Grip offset on the static receiver ------------------------------------------------------------------------------------
-- The hand holds the rig root where the donor's trigger sits; the receiver root is shifted by spec.grip_offset
-- (Unit.set_local_position(unit, 1, ...) on a linked unit, as QIangIQsAWP.lua:282 does).
local FLAMER_ITEM = WEAPONS[1].item
local tracked = {}
local roots = setmetatable({}, { __mode = "k" })

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function receiver_unit(names, spec)
    local want = attachment_name(spec, "receiver")

    if names then
        for unit, item_name in pairs(names) do
            if item_name == want and unit_ok(unit) then
                return unit
            end
        end
    end
end

local function pose_receiver(names, spec)
    local unit = receiver_unit(names, spec)

    if not unit then
        return
    end

    local root = roots[unit]

    if not root then
        local p = Unit.local_position(unit, 1)

        root = { p[1], p[2], p[3] }
        roots[unit] = root
    end

    local o = spec.grip_offset

    Unit.set_local_position(unit, 1, Vector3(root[1] + o[1], root[2] + o[2], root[3] + o[3]))
end

local function apply_pose(ext)
    if not ext._is_local_unit or not ext._equipment then
        return
    end

    for _, slot in pairs(ext._equipment) do
        local item = slot.item

        if item and item.name == FLAMER_ITEM then
            pose_receiver(slot.item_name_by_unit_3p, WEAPONS[1])
            pose_receiver(slot.item_name_by_unit_1p, WEAPONS[1])
        end
    end
end

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "_update_item_visibility", function(self)
    if self._is_local_unit then
        tracked[self] = true
        apply_pose(self)
    end
end)

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "update", function(self)
    if tracked[self] then
        apply_pose(self)
    end
end)

mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, "destroy", function(func, self, ...)
    tracked[self] = nil

    return func(self, ...)
end)

-- ADS: lower the first-person model so the receiver stops covering the crosshair ---------------------------------------
local function flamer_wielded(c_self)
    local weapon_extension = rawget(c_self, "_weapon_extension")
    local ok, template = pcall(function()
        return weapon_extension and weapon_extension:weapon_template()
    end)

    return ok and template and template.name == WEAPONS[1].template
end

local function aiming(unit)
    local ok, active = pcall(function()
        local unit_data = ScriptUnit.has_extension(unit, "unit_data_system")
        local alternate_fire = unit_data and unit_data:read_component("alternate_fire")

        return alternate_fire and alternate_fire.is_active
    end)

    return ok and active == true
end

mod:hook("PlayerUnitFirstPersonExtension", "update_unit_position", function(func, self, unit, dt, t)
    func(self, unit, dt, t)

    local player = self._player

    if not (player and self._is_local_unit and player:is_human_controlled() and flamer_wielded(self)) then
        self.__qiangiq_ads = 0

        return
    end

    local blend = self.__qiangiq_ads or 0

    blend = blend + ((aiming(unit) and 1 or 0) - blend) * math.min(1, (dt or 0) * 14)
    self.__qiangiq_ads = blend

    local drop = (mod:get("ads_drop_cm") or 5) / 100 * blend

    if drop < 0.0005 then
        return
    end

    local first_person_unit = self._first_person_unit
    local input_extension = ScriptUnit.extension(unit, "input_system")
    local yaw, pitch, roll = input_extension:get_orientation()
    local look_rotation = Quaternion.from_yaw_pitch_roll(yaw, pitch, roll)
    local position = Unit.local_position(first_person_unit, 1)

    Unit.set_local_position(first_person_unit, 1, position + Quaternion.rotate(look_rotation, Vector3(0, 0, -drop)))
    World.update_unit_and_children(self._world, first_person_unit)
end)

-- Bottom-right weapon icon -------------------------------------------------------------------------------------------
-- hud_element_player_weapon.lua:76-80 reads item.hud_icon into widget.content.icon, and the game's own icon for this weapon
-- is a blank placeholder. The drawn icon (assets/*.png, make_icons.py) is compiled into this mod's own Custom Assets build
-- as a texture (build_icon_units.py wraps it in a one-quad unit, Custom/hud_icon) and shown through ui_default_base, the
-- way QIangIQsSwordShield does. No SimpleAssets (user rule 2026-10-25: mods stand alone).
local ICON_ITEM = WEAPONS[1].item
local HUD_ICON_ASSET = "QIangIQsFlamerPistol:hud_icon"
local HUD_ICON_MATERIAL = "content/ui/materials/base/ui_default_base"
local HUD_ICON_TEXTURE = "content/mods/qiangiq_flamerpistol/hud_icon_material_1_bca"
local icon_ready = false

-- The handler destroys and recreates the element when the slot's weapon changes (hud_element_player_weapon_handler.lua:82)
mod:hook_safe(CLASS.HudElementPlayerWeapon, "init", function(self, parent, draw_layer, start_scale, data)
    self.__qiangiq_hud_icon = data and data.weapon_name == ICON_ITEM and not retail_icon.used
end)

-- The icon widget is a texture pass whose value is a material; ui_default_base takes the PNG as texture_map, the emote
-- wheel's way (hud_element_emote_wheel_definitions.lua:76-83). Without Custom Assets the donor's icon stays.
mod:hook_safe(CLASS.HudElementPlayerWeapon, "update", function(self)
    local widget = self.__qiangiq_hud_icon and icon_ready and self._widgets_by_name and self._widgets_by_name.icon

    if not widget then
        return
    end

    local style = widget.style.icon

    style.material_values = style.material_values or {}

    if widget.content.icon ~= HUD_ICON_MATERIAL or style.material_values.texture_map ~= HUD_ICON_TEXTURE then
        widget.content.icon = HUD_ICON_MATERIAL
        style.material_values.texture_map = HUD_ICON_TEXTURE
        widget.dirty = true
    end
end)

-- Custom Assets API 1 (QIangIQsSwordShield acquire call). Optional: without it the donor weapon's icon stays.
local function acquire_assets()
    local custom_assets = get_mod("CustomAssets")

    if not custom_assets or not custom_assets.is_api_compatible or not custom_assets.is_api_compatible(1) then
        mod:info("Custom Assets (API 1) is not installed: the drawn HUD icon is not shown")

        return
    end

    local ticket, err = custom_assets.acquire(mod, HUD_ICON_ASSET, function(_, _, load_error)
        if load_error then
            mod:info("%s did not load: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", HUD_ICON_ASSET, tostring(load_error))

            return
        end

        icon_ready = true
        mod:info("%s loaded", HUD_ICON_ASSET)
    end, { resident = true, reference_name = HUD_ICON_ASSET })

    if not ticket then
        mod:info("%s could not be requested: %s", HUD_ICON_ASSET, tostring(err))
    end
end

mod.on_all_mods_loaded = function()
    add_to_unlock_list()
    acquire_assets()
end

mod.on_unload = function()
    local ok, cache = pcall(MasterItems.get_cached)

    for _, spec in ipairs(WEAPONS) do
        if ok and cache then
            cache[spec.item] = nil

            for part in pairs(spec.parts) do
                cache[attachment_name(spec, part)] = nil
            end
        end

        if state[spec.key].template_ours then
            WeaponTemplates[spec.template] = nil
        end
    end
end

mod.update = function()
    poll()

end

-- Equip without the backend (QIangIQsShardStaff override): only where this client hosts ----------------------------
local function local_player()
    local players = Managers.player

    return players and players:local_player_safe(1)
end

local function equipped_item_name(player, slot)
    local unit = player and player.player_unit

    if not unit or not Unit.alive(unit) then
        return nil
    end

    local extension = ScriptUnit.has_extension(unit, "visual_loadout_system")
    local item = extension and extension:item_from_slot(slot)

    return item and item.name
end

local previous = {}

local function override(slot, item_name)
    local player = local_player()
    local sync = Managers.profile_synchronization
    local host = sync and sync:synchronizer_host()

    if not player then
        say("no local player")

        return false
    end

    if not host then
        say("not the host here. Use the Psykhanium, a SoloPlay game or a game you host")

        return false
    end

    host:override_slot(player:peer_id(), player:local_player_id(), slot, item_name)
    say("override_slot(%s, %s) sent", slot, tostring(item_name))

    return true
end

local function package_state(path)
    local ok, exists = pcall(Application.can_get_resource, "package", path)

    return ok and tostring(exists) or "?"
end

local function status()
    for _, spec in ipairs(WEAPONS) do
        local st = state[spec.key]

        say("%s: template %s (id %s, from %s), item %s (id %s, slot %s)", spec.key, tostring(st.template_ok),
            tostring(st.template_id), spec.source_template, tostring(st.item_ok), tostring(st.item_id), tostring(st.slot))

        for _, part in ipairs(PART_ORDER) do
            local def = spec.parts[part]

            if def then
                say("  %s package found: %s", part, package_state(def.unit))
            end
        end

        local rig = spec.base_unit or st.rig

        if rig then
            say("  rig %s package found: %s", rig, package_state(rig))
        end

        if st.notes and #st.notes > 0 then
            say("  %s", table.concat(st.notes, "; "))
        end
    end
end

mod:command("flamerpistol", mod:localize("command_flamerpistol"), function(action)
    action = action or "status"

    if action == "status" then
        status()
    elseif action == "equip" then
        local spec = WEAPONS[1]
        local st = state[spec.key]

        if not (st.template_ok and st.item_ok and st.slot) then
            say("%s not ready yet (template %s, item %s)", spec.key, tostring(st.template_ok), tostring(st.item_ok))

            return
        end

        local player = local_player()

        previous[st.slot] = previous[st.slot] or (player and equipped_item_name(player, st.slot))
        override(st.slot, spec.item)
    elseif action == "restore" then
        local any = false

        for slot, item_name in pairs(previous) do
            if item_name and override(slot, item_name) then
                previous[slot] = nil
                any = true
            end
        end

        if not any then
            say("nothing to restore (equip first)")
        end
    else
        say("usage: /flamerpistol [status|equip|restore]")
    end
end)
