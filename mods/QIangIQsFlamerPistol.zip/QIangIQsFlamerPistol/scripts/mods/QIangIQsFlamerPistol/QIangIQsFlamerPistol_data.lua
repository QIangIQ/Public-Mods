local mod = get_mod("QIangIQsFlamerPistol")

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = false,
    options = {
        widgets = {
            { setting_id = "drawn_hud_icon", type = "checkbox", default_value = true },
            { setting_id = "add_to_unlock_list", type = "checkbox", default_value = true },
            { setting_id = "unlock_level", type = "numeric", default_value = 1, range = { 1, 30 }, decimals_number = 0 },
            { setting_id = "ads_drop_cm", type = "numeric", default_value = 5, range = { 0, 12 }, decimals_number = 1 },
        },
    },
}
