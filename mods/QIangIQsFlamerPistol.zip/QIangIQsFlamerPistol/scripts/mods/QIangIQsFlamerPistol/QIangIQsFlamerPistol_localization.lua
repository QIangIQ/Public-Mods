return {
    mod_name = {
        en = "QIangIQ's Flamer Pistol",
    },
    mod_description = {
        en = "Adds the datamined Flamer Pistol as a Zealot weapon, built from the unreleased retail models in the game files. The game has no weapon template for it yet, so it fires like the Purgation Flamer (flamer_p1_m1) with the Laspistol's animations and rig. The bottom-right weapon icon shows the Flamer Pistol (needs Custom Assets and CUSTOM_ASSETS_PATCH.bat) and, while aiming, the first-person model is lowered so it no longer covers the crosshair. Pick it in Realms Loadout (/rl) or equip with /flamerpistol equip in the Psykhanium or a game you host. Everyone in the game needs this mod.",
    },
    command_flamerpistol = {
        en = "/flamerpistol [status|equip|restore]",
    },
    drawn_hud_icon = { en = "Use the drawn bottom-right icon (needs Custom Assets and a restart). Off = the game's own icon for this weapon, which is a blank placeholder" },
    add_to_unlock_list = { en = "List the Flamer Pistol in the Zealot weapon unlock list (Realms Loadout reads it)" },
    unlock_level = { en = "Unlock level in that list (needs a restart)" },
    ads_drop_cm = { en = "Aiming: lower the model by this many cm (0 = off)" },
}
