return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsSourceMovement` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsSourceMovement", {
            mod_script = "QIangIQsSourceMovement/scripts/mods/QIangIQsSourceMovement/QIangIQsSourceMovement",
            mod_data = "QIangIQsSourceMovement/scripts/mods/QIangIQsSourceMovement/QIangIQsSourceMovement_data",
            mod_localization = "QIangIQsSourceMovement/scripts/mods/QIangIQsSourceMovement/QIangIQsSourceMovement_localization",
        })
    end,
    version = "1.4.0",
    author = "QIangIQ",
    packages = {},
}
