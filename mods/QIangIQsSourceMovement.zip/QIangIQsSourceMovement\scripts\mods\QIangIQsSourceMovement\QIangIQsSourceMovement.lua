local mod = get_mod("QIangIQsSourceMovement")

local Action = require("scripts/utilities/action/action")
local WeaponTemplate = require("scripts/utilities/weapon/weapon_template")
local Fall = require("scripts/extension_systems/character_state_machine/character_states/utilities/fall")

local session_on = true
local cache = {}

-- Realms (Realms/docs/README.md, same pattern as QIangIQsOgrynRide): the host runs the character states of client
-- units too (player_character_unit_template.lua:64, is_local_unit = not player.remote) and each client predicts its
-- own unit. Both sides must move the same way, so a client uses the host's settings, and only when the host runs
-- this mod too (otherwise the host corrects every jump back to normal movement).
local RPC_HELLO = "sm_hello"
local RPC_CFG = "sm_cfg"
local SYNCED = { "no_fall_damage", "air_strafe", "air_accelerate", "air_cap", "surf", "no_air_drag", "keep_jump_speed",
    "bhop", "auto_jump", "auto_hop", "no_vault", "max_speed" }
local realms = nil
local network_ready = false
local peers_on = {}
local host_cfg = nil
local host_cfg_peer = nil

local function normalize_peer(peer_id)
    return string.lower(tostring(peer_id))
end

local function is_server()
    local game_session = Managers.state and Managers.state.game_session
    return game_session and game_session:is_server() or false
end

local function own(id)
    local v = cache[id]
    if v == nil then
        v = mod:get(id)
        cache[id] = v
    end
    return v
end

local function opt(id)
    if host_cfg and id ~= "enabled" and not is_server() then
        return host_cfg[id]
    end
    return own(id)
end

local function remote_on(unit)
    if not next(peers_on) then
        return false
    end
    local player = Managers.player and Managers.player:player_by_unit(unit)
    if not (player and player.remote and player:is_human_controlled()) then
        return false
    end
    return peers_on[normalize_peer(player:peer_id())] == true
end

local function active(self)
    if self._is_local_unit then
        return session_on and own("enabled") ~= false and (self._is_server or host_cfg ~= nil)
    end
    return self._is_server and remote_on(self._unit)
end

local function copy(v)
    return Vector3(v.x, v.y, v.z)
end

local function source_air(self, velocity_current, x, y, rotation, move_speed, player_speed_scale, dt)
    local len = math.sqrt(x * x + y * y)
    if len < 0.0001 then
        return copy(velocity_current)
    end
    local flat_rotation = Quaternion.look(Vector3.flat(Quaternion.forward(rotation)), Vector3.up())
    local wishdir = Quaternion.rotate(flat_rotation, Vector3(x / len, y / len, 0))
    local wishspeed = move_speed * player_speed_scale * math.min(len, 1)
    local capped = math.min(wishspeed, opt("air_cap") or 0.57)
    local add = capped - Vector3.dot(velocity_current, wishdir)
    if add <= 0 then
        return copy(velocity_current)
    end
    local accel = math.min((opt("air_accelerate") or 12) * wishspeed * dt, add)
    return velocity_current + wishdir * accel
end

local RAMP_MAX_NZ = 0.7
local RAMP_MIN_NZ = 0.05
local RAY_UP = 0.6
local on_ramp = {}

local function ramp_normal(self, unit)
    local physics_world = self._physics_world
    local position = self._locomotion_component.position
    local mover = Unit.mover(unit)
    local radius = mover and Mover.radius(mover) or 0.35
    local ok, hit, _, distance, normal = pcall(PhysicsWorld.raycast, physics_world, position + Vector3(0, 0, RAY_UP),
        Vector3.down(), RAY_UP + 1.5, "closest", "collision_filter", "filter_player_mover")
    if not (ok and hit and normal) then
        return nil
    end
    local nz = normal.z
    if nz < RAMP_MIN_NZ or nz >= RAMP_MAX_NZ then
        return nil
    end
    if distance - RAY_UP > radius / nz - radius + 0.1 then
        return nil
    end
    return normal
end

local function set_drag(self, on)
    local locomotion_extension = self._locomotion_extension
    if locomotion_extension and locomotion_extension._use_drag ~= on then
        locomotion_extension._use_drag = on
    end
end

local function air_hook(func, self, velocity_current, x, y, rotation, move_speed, player_speed_scale, dt)
    if not active(self) then
        set_drag(self, true)
        return func(self, velocity_current, x, y, rotation, move_speed, player_speed_scale, dt)
    end
    set_drag(self, opt("no_air_drag") == false)
    local velocity
    if opt("air_strafe") ~= false then
        velocity = source_air(self, velocity_current, x, y, rotation, move_speed, player_speed_scale, dt)
    else
        velocity = func(self, velocity_current, x, y, rotation, move_speed, player_speed_scale, dt)
    end
    local unit = self._unit
    local steering = self._locomotion_steering_component
    local normal = opt("surf") ~= false and ramp_normal(self, unit)
    on_ramp[unit] = normal and true or nil
    if not normal then
        if self.name == "falling" then
            steering.calculate_fall_velocity = true
        end
        return velocity
    end
    local g = self._constants.gravity * dt
    velocity = Vector3(velocity.x, velocity.y, velocity.z - g)
    local into = Vector3.dot(velocity, normal)
    if into < 0 then
        velocity = velocity - normal * into
    end
    if self.name == "falling" then
        steering.calculate_fall_velocity = false
        return velocity
    end
    return Vector3(velocity.x, velocity.y, velocity.z + g)
end

mod:hook("PlayerCharacterStateFalling", "_air_movement", air_hook)
mod:hook("PlayerCharacterStateJumping", "_air_movement", air_hook)

local hop_chain = {}

mod:hook_safe("PlayerCharacterStateFalling", "on_exit", function(self, unit, t, next_state)
    on_ramp[unit] = nil
    self._locomotion_steering_component.calculate_fall_velocity = true
end)

mod:hook_safe("PlayerCharacterStateFalling", "on_enter", function(self, unit, dt, t, previous_state, params)
    if previous_state ~= "jumping" then
        hop_chain[unit] = nil
    end
end)

mod:hook_safe("PlayerCharacterStateJumping", "on_enter", function(self, unit, dt, t, previous_state, params)
    hop_chain[unit] = active(self) and opt("bhop") ~= false or nil
    if not (active(self) and opt("keep_jump_speed") ~= false) or previous_state == "ladder_climbing" or previous_state == "dodging" then
        return
    end
    local v = self._locomotion_component.velocity_current
    local vx, vy = v.x, v.y
    local cap = opt("max_speed") or 0
    local speed = math.sqrt(vx * vx + vy * vy)
    if cap > 0 and speed > cap then
        vx, vy = vx * cap / speed, vy * cap / speed
    end
    self._locomotion_steering_component.velocity_wanted = Vector3(vx, vy, self._constants.jump_speed)
end)

local function no_jump_held(input_source)
    return setmetatable({
        get = function(_, action)
            if action == "jump_held" then
                return false
            end
            return input_source:get(action)
        end,
    }, {
        __index = function(_, k)
            local v = input_source[k]
            if type(v) == "function" then
                return function(_, ...)
                    return v(input_source, ...)
                end
            end
            return v
        end,
    })
end

local function hop_hook(func, self, unit, t, next_state_params, input_source, ...)
    local on = active(self) and opt("bhop") ~= false
    local chained = on and hop_chain[unit]
    local source = chained and opt("no_vault") ~= false and no_jump_held(input_source) or input_source
    local next_state = func(self, unit, t, next_state_params, source, ...)
    if on and on_ramp[unit] and (next_state == "walking" or next_state == "sprinting" or next_state == "sliding") then
        return nil
    end
    if (next_state ~= "walking" and next_state ~= "sprinting") or not on then
        if next_state and next_state ~= "jumping" and next_state ~= "falling" then
            hop_chain[unit] = nil
        end
        return next_state
    end
    hop_chain[unit] = nil
    local movement_state_component = self._movement_state_component
    if not movement_state_component.can_jump or movement_state_component.is_crouching then
        return next_state
    end
    local move = input_source:get("move")
    local moving = move and Vector3.length_squared(move) > 0
    local wants = input_source:get("jump") or (opt("auto_hop") ~= false and input_source:get("jump_held"))
        or (chained and opt("auto_jump") ~= false and moving)
    if not wants then
        return next_state
    end
    local weapon_action_component = self._weapon_action_component
    local weapon_template = WeaponTemplate.current_weapon_template(weapon_action_component)
    local _, weapon_action_setting = Action.current_action(weapon_action_component, weapon_template)
    if weapon_action_setting and weapon_action_setting.action_prevents_jump then
        return next_state
    end
    next_state_params.disable_sprint_start_slowdown = nil
    return "jumping"
end

mod:hook("PlayerCharacterStateFalling", "_check_transition", hop_hook)
mod:hook("PlayerCharacterStateJumping", "_check_transition", hop_hook)

mod:hook(Fall, "check_damage", function(func, unit, ...)
    if own("no_fall_damage") ~= false and is_server() then
        local player = Managers.player and Managers.player:local_player_safe(1)
        if session_on and own("enabled") ~= false and player and player.player_unit == unit then
            return
        end
        if remote_on(unit) then
            return
        end
    end
    return func(unit, ...)
end)

local function local_speed()
    local player = Managers.player and Managers.player:local_player_safe(1)
    local unit = player and player.player_unit
    local ude = unit and ScriptUnit.has_extension(unit, "unit_data_system")
    if not ude then
        return nil
    end
    local v = ude:read_component("locomotion").velocity_current
    return math.sqrt(v.x * v.x + v.y * v.y)
end

mod:command("srcmove", "Source movement: /srcmove (toggle for this session), /srcmove speed", function(which)
    if which == "speed" then
        local s = local_speed()
        mod:echo(s and string.format("Horizontal speed %.2f m/s", s) or "No player unit")
        return
    end
    session_on = not session_on
    mod:echo("Source movement %s for this session", session_on and "on" or "off")
    mod.say_hello()
end)

mod.toggle_source_movement = function()
    session_on = not session_on
    mod:echo("Source movement %s for this session", session_on and "on" or "off")
    mod.say_hello()
end

-- ##########################################################
-- Realms: client says hello, host replies with its settings

local function send(rpc_name, recipient, ...)
    if not network_ready then
        return false
    end
    local ok, sent = pcall(realms.network_send, mod, rpc_name, recipient, ...)
    return ok and sent == true
end

local function is_host()
    local connection = Managers.connection
    return connection and connection:is_host() or false
end

local function cfg_table()
    local t = {}
    for _, id in ipairs(SYNCED) do
        t[id] = own(id)
    end
    return t
end

mod.say_hello = function()
    if network_ready and not is_host() and realms.network_is_available() then
        send(RPC_HELLO, "host", session_on and own("enabled") ~= false)
    end
end

local function on_hello(sender, on)
    if not is_host() then
        return
    end
    peers_on[sender] = on == true or nil
    send(RPC_CFG, sender, cfg_table())
    mod:info("Realms peer %s: Source movement %s", sender, on == true and "on" or "off")
end

local function on_cfg(sender, cfg)
    if is_host() or type(cfg) ~= "table" then
        return
    end
    local first = host_cfg == nil
    host_cfg, host_cfg_peer = cfg, sender
    if first then
        mod:echo("Source movement: synced with the host's settings")
    end
end

mod.on_setting_changed = function()
    cache = {}
    if network_ready and realms.network_is_available() then
        if is_host() then
            send(RPC_CFG, "others", cfg_table())
        else
            mod.say_hello()
        end
    end
end

mod.on_all_mods_loaded = function()
    realms = get_mod("Realms")
    if not realms or type(realms.network_register) ~= "function" or type(realms.network_send) ~= "function" then
        realms = nil
        return
    end
    network_ready = true
    for rpc_name, handler in pairs({ [RPC_HELLO] = on_hello, [RPC_CFG] = on_cfg }) do
        local ok, registered, register_error = pcall(realms.network_register, mod, rpc_name, function(sender_peer_id, ...)
            handler(normalize_peer(sender_peer_id), ...)
        end)
        if not ok or not registered then
            network_ready = false
            mod:info("Realms network registration failed for %s: %s", rpc_name, tostring(ok and register_error or registered))
        end
    end
    if not network_ready then
        return
    end
    if type(realms.network_on_peer_joined) == "function" then
        pcall(realms.network_on_peer_joined, mod, function(peer_id)
            local connection = Managers.connection
            local host = connection and connection:host()
            if host and normalize_peer(host) == normalize_peer(peer_id) then
                mod.say_hello()
            end
        end)
    end
    if type(realms.network_on_peer_left) == "function" then
        pcall(realms.network_on_peer_left, mod, function(peer_id)
            local peer = normalize_peer(peer_id)
            peers_on[peer] = nil
            if peer == host_cfg_peer then
                host_cfg, host_cfg_peer = nil, nil
            end
        end)
    end
end

mod.on_game_state_changed = function(status, state_name)
    if state_name == "StateGameplay" and status == "enter" then
        mod.say_hello()
    end
end
