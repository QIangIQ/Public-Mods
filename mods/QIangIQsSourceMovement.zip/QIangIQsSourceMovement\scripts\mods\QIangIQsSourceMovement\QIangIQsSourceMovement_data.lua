local mod = get_mod("QIangIQsSourceMovement")

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = true,
    options = {
        widgets = {
            { setting_id = "enabled", type = "checkbox", default_value = true },
            { setting_id = "no_fall_damage", type = "checkbox", default_value = true },
            {
                setting_id = "group_air",
                type = "group",
                sub_widgets = {
                    { setting_id = "air_strafe", type = "checkbox", default_value = true },
                    { setting_id = "air_accelerate", type = "numeric", default_value = 12, range = { 1, 300 }, decimals_number = 0 },
                    { setting_id = "air_cap", type = "numeric", default_value = 0.57, range = { 0.1, 5 }, decimals_number = 2 },
                    { setting_id = "surf", type = "checkbox", default_value = true },
                    { setting_id = "no_air_drag", type = "checkbox", default_value = true },
                },
            },
            {
                setting_id = "group_hop",
                type = "group",
                sub_widgets = {
                    { setting_id = "keep_jump_speed", type = "checkbox", default_value = true },
                    { setting_id = "bhop", type = "checkbox", default_value = true },
                    { setting_id = "auto_jump", type = "checkbox", default_value = true },
                    { setting_id = "auto_hop", type = "checkbox", default_value = true },
                    { setting_id = "no_vault", type = "checkbox", default_value = true },
                    { setting_id = "max_speed", type = "numeric", default_value = 0, range = { 0, 40 }, decimals_number = 1 },
                },
            },
            {
                setting_id = "toggle_keybind",
                type = "keybind",
                default_value = {},
                keybind_trigger = "pressed",
                keybind_type = "function_call",
                function_name = "toggle_source_movement",
            },
        },
    },
}
