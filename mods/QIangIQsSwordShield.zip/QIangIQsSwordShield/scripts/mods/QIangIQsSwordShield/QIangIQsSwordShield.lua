-- QIangIQ's Sword and Shield 0.3.0: the datamined sword-and-shield as a Zealot weapon.
--
-- What is datamined (A:\Dowloads\Darktide_NonMod\dauntless_datamine, INDEX.md "Sword + shield", Oct 11 2026 build):
--   * Retail units with their names in the dictionary: content/weapons/player/melee/combat_sword/attachments/blade_08/blade_08
--     and .../grip_08/grip_08. Node names (id32 match, scratch\swordshield\probe3.py): grip_08 has
--     ap_blade_01 at z 0.101 and ap_trinket_hook; blade_08 has fx_sweep (root) and fx_block (z 0.26).
--   * An UNNAMED heater shield unit 26b996dc3fdb55ff (no name, no textures). A retail unit can only be loaded by name,
--     so its datamined geometry is compiled as our own unit (Custom/heater_shield, build_shield_glb.py + DarktideGLBCompiler)
--     with a plain steel material (extrapolated: the unit ships no textures).
--   * NOT datamined: weapon template, item, animations. The colleagues' label combatsword_shield_p1_m1 (INDEX.md) is used
--     for the template and item name.
--
-- Built from released weapons (the QIangIQsDauntlessArmory pattern: template clone + NetworkLookup append + alias copy,
-- item clone into MasterItems.get_cached(), equip by override_slot):
--   * Rig, animations, block and weapon special = powermaul_shield_p1_m1 (power_maul_shields/powermaul_shield_p1_m1.lua):
--     the only human one-hander with a shield on the left arm (state machines assault_shield_maul, lines 1459-1460).
--   * 0.1.1: slots taken by path from the live item trees (the shield is a whole item in "left"; 0.1.0 looked for an
--     /attachments/ unit there and never built the item).
--   * Sword = the shaft slot of the shield maul becomes grip_08 (attach node of the maul shaft, LINK_MODE_NONE so it does not
--     follow same-named rig nodes, DauntlessArmory 0.2.0), with blade_08 on its ap_blade_01. Maul head and connector go.
--   * Shield = the retail assault shield stays in the item (it carries fx_display and fx_shield_special_active, and the hand
--     holds it); our heater is linked to its root and the retail shield is hidden. The heater was authored in the same frame:
--     both handles sit on -x (retail centroid -0.078, 0.200, 0.003; heater -0.090, 0.186, 0.001; probe4.py), the 1.5 cm
--     difference is baked into the compiled unit.
--
-- Custom moveset (0.2.0; animations grafted from both shield maul marks, see GRAFTS; damage profiles from
-- combatsword_damage_profile_templates.lua and power_maul_shield_damage_profile_templates.lua):
--   light chain   1 horizontal sword sweep   light_combatsword_linesman   faster (1.2)
--                 2 right diagonal cut       light_combatsword_linesman   faster (1.3)
--                 3 rising cut               light_combatsword_smiter     faster (1.2)
--                 4 shield poke              powermaul_shield_light_smiter_shield (blunt)
--   heavies       1 diagonal sword cleave    heavy_combatsword
--                 2 overhead sword chop      heavy_combatsword_smiter
--                 3 shield slam (4th swing)  powermaul_shield_heavy_tank_shield (blunt)
--   push follow   sword sweep                light_combatsword_linesman
--   block / special: the shield maul's own (block charges, shield push on release).
--   No power field (0.2.0): no shock buff or keyword, blunt wounds instead of shock wounds, power-field slot scripts
--   removed from the items, sword sounds/particles first in the alias copy.
-- Author: QIangIQ
local mod = get_mod("QIangIQsSwordShield")

local WeaponTemplates = require("scripts/settings/equipment/weapon_templates/weapon_templates")
local MasterItems = require("scripts/backend/master_items")
local NetworkLookup = require("scripts/network_lookup/network_lookup")

local TEMPLATE = "combatsword_shield_p1_m1"
local SOURCE_TEMPLATE = "powermaul_shield_p1_m1"
local SWORD_TEMPLATE = "combatsword_p1_m1"
local ITEM_ROOT = "content/items/weapons/player/melee/"
local ITEM = ITEM_ROOT .. "combatsword_shield_p1_m1"
local SOURCE_ITEM = ITEM_ROOT .. "powermaul_shield_p1_m1"
local SWORD_ITEM = ITEM_ROOT .. "combatsword_p1_m1"
local PART_ROOT = ITEM_ROOT .. "qiangiq_swordshield/"
local GRIP_ITEM = PART_ROOT .. "grip_08"
local BLADE_ITEM = PART_ROOT .. "blade_08"
local SHIELD_ITEM = PART_ROOT .. "shield"
local SWORD_UNITS = "content/weapons/player/melee/combat_sword/attachments/"
local GRIP_UNIT = SWORD_UNITS .. "grip_08/grip_08"
local BLADE_UNIT = SWORD_UNITS .. "blade_08/blade_08"
local BLADE_NODE = "ap_blade_01"
local SHIELD_ASSET, SHIELD_UNIT = "QIangIQsSwordShield:heater_shield", "content/mods/qiangiq_swordshield/heater_shield"
local HUD_ICON_ASSET = "QIangIQsSwordShield:hud_icon"
local RETAIL_HUD_ICON = "content/ui/materials/icons/weapons/hud/combatsword_shield_p1_m1"
local DISPLAY = "loc_qiangiq_swordshield"

mod:add_global_localize_strings({
    loc_qiangiq_swordshield = { en = "Sword and Shield (datamined)" },
})

local function say(fmt, ...)
    local text = string.format(fmt, ...)

    mod:echo(text)
    mod:info(text)
end

-- Network lookups (QIangIQsShardStaff append_lookup): new names go at the end so no existing id moves -------------
local function append_lookup(lookup_name, key)
    local lookup = NetworkLookup[lookup_name]

    if not lookup then
        return false, "no lookup"
    end

    local existing = rawget(lookup, key)

    if existing then
        return true, existing
    end

    local index = #lookup + 1

    rawset(lookup, index, key)
    rawset(lookup, key, index)

    return true, index
end

-- Particle / sound aliases keyed by wielded_weapon_template (QIangIQsShardStaff alias_template_keys) --------------
local ALIAS_MODULES = {
    "scripts/settings/particles/player_character_particle_aliases",
    "scripts/settings/sound/player_character_sound_event_aliases",
}

local function alias_keys(root, source, target, seen, counter)
    if type(root) ~= "table" or seen[root] then
        return
    end

    seen[root] = true

    local value = rawget(root, source)

    if value ~= nil and rawget(root, target) == nil then
        root[target] = value
        counter.n = counter.n + 1
    end

    for _, child in pairs(root) do
        if type(child) == "table" then
            alias_keys(child, source, target, seen, counter)
        end
    end
end

local function copy_aliases(source, target)
    local counter = { n = 0 }

    for _, path in ipairs(ALIAS_MODULES) do
        local ok, module = pcall(require, path)

        if ok then
            alias_keys(module, source, target, {}, counter)
        else
            mod:error("alias module %s: %s", path, tostring(module))
        end
    end

    return counter.n
end

-- Moveset (see the header) ----------------------------------------------------------------------------------------
-- 0.2.0: the attacks themselves are taken from the two shield maul marks, which share one state machine
-- (assault_shield_maul, powermaul_shield_p1_m1.lua:1334-1335 and powermaul_shield_p1_m2.lua:1543-1544), so every
-- animation event below exists for this rig. 0.1.x only changed damage, so it played exactly like the maul.
--   graft = { donor template, donor action }; chain = allowed_chain_actions rewired for this order
local M1, M2 = "powermaul_shield_p1_m1", "powermaul_shield_p1_m2"
local GRAFTS = {
    -- light 1: horizontal sweep (m2 attack_left, :297-394) from the m2 left windup (:213)
    action_melee_start_left = { M2, "action_melee_start_left" },
    action_light_1 = { M2, "action_light_1" },
    -- heavy 1: diagonal cleave (m2 heavy_attack_left_diagonal_down, :395-470)
    action_heavy_1 = { M2, "action_heavy_1" },
    -- light 2 / heavy 2 stay m1: right diagonal cut, overhead (m1 :525-689)
    -- light 3: rising cut (m2 attack_left_up, :757-845) from the m2 second left windup (:696)
    action_melee_start_left_2 = { M2, "action_melee_start_left_2" },
    action_light_3 = { M2, "action_light_3" },
    -- light 4 / heavy 3: shield poke and shield slam from the m1 shield windup (m1 :690-838 and :389-465)
    action_melee_start_right_2 = { M1, "action_melee_start_left_2", chain = { light_attack = "action_light_4", heavy_attack = "action_heavy_3" } },
    action_light_4 = { M1, "action_light_3", chain = { start_attack = "action_melee_start_left" } },
    action_heavy_3 = { M1, "action_heavy_1" },
}

-- Damage per action. Sword hits use the combat sword's profiles with its wound shapes (combatsword_p1_m1.lua:238-832):
-- WoundsTemplates.slash only has the fine shapes and the maul's *_coarse shapes gave wound_settings = nil and the
-- 0.1.1 crash (wound_materials.lua:185). Shield hits keep the shield maul profiles with plain blunt wounds.
local MOVESET = {
    action_light_1 = { profile = "light_combatsword_linesman", damage_type = "metal_slashing_light", wounds = "horizontal_slash", speed = "time_scale_1_2" },
    action_heavy_1 = { profile = "heavy_combatsword", damage_type = "metal_slashing_medium", wounds = "left_45_slash" },
    action_light_2 = { profile = "light_combatsword_linesman", damage_type = "metal_slashing_light", wounds = "right_45_slash", speed = "time_scale_1_3" },
    action_heavy_2 = { profile = "heavy_combatsword_smiter", damage_type = "metal_slashing_medium", wounds = "vertical_slash" },
    action_light_3 = { profile = "light_combatsword_smiter", damage_type = "metal_slashing_light", wounds = "vertical_slash", speed = "time_scale_1_2" },
    action_light_4 = { profile = "powermaul_shield_light_smiter_shield", damage_type = "blunt", blunt = true },
    action_heavy_3 = { profile = "powermaul_shield_heavy_tank_shield", damage_type = "blunt_heavy", blunt = true },
    action_pushfollow = { profile = "light_combatsword_linesman", damage_type = "metal_slashing_light", wounds = "horizontal_slash" },
}

-- powermaul_shield_p1_m1.lua:1383-1391: the power field sources sit on the maul head; the combat sword has only
-- _block/_sweep (combatsword_p1_m1.lua:1197-1200). The sources stay defined (slot scripts look them up) but point at
-- the blade's fx_block; the scripts that drew the power field on them are removed from the items (STRIP_SCRIPTS).
local FX_SOURCES = { _special_active = "fx_block", _wielded_idling = "fx_block" }

local blunt_profiles = {}

-- Same profile with WoundsTemplates.blunt instead of shock_blunt (power_maul_shield_damage_profile_templates.lua:632).
-- The name stays the game's, so the network still sends a known profile name.
local function blunt_profile(profile)
    local WoundsTemplates = require("scripts/settings/damage/wounds_templates")

    -- only shock wounds are swapped: 0.2.0 swapped every profile here, so the sword's slash profiles got blunt wounds,
    -- which list only *_coarse shapes, and the sword shapes crashed again (wound_materials.lua:185, user test 2026-10-25)
    if profile.wounds_template ~= WoundsTemplates.shock_blunt then
        return profile
    end

    local clone = blunt_profiles[profile]

    if not clone then
        clone = table.clone(profile)
        clone.wounds_template = WoundsTemplates.blunt
        blunt_profiles[profile] = clone
    end

    return clone
end

-- Copies a donor action into the clone. weapon_tweak_templates.lua _preparse_templates (:213-287) renamed each
-- <type>_template of an action to "<action>_<base>" and stored { new_identifier, base_identifier } under the action
-- name, and damage/explosion get {} per action (:289-309); a missing entry is the weapon_tweak_templates.lua:579 crash.
-- So the donor's entries are copied under our action name and the action's fields renamed to match.
local function graft(clone, action_name, donor, donor_action_name, notes)
    local WeaponTweakTemplateSettings = require("scripts/settings/equipment/weapon_templates/weapon_tweak_template_settings")
    local donor_action = donor.actions and donor.actions[donor_action_name]
    local donor_lookup = rawget(donor, "__base_template_lookup")
    local lookup = rawget(clone, "__base_template_lookup")

    if not (donor_action and donor_lookup and lookup) then
        notes[#notes + 1] = string.format("graft %s <- %s.%s missing", action_name, tostring(donor.name), donor_action_name)

        return false
    end

    local action = table.clone(donor_action)

    action.name = action_name

    for _, template_type in pairs(WeaponTweakTemplateSettings.template_types) do
        local from, to = donor_lookup[template_type], lookup[template_type]

        if from and to then
            for suffix, field in pairs({ [""] = template_type .. "_template", ["_special"] = "special_" .. template_type .. "_template" }) do
                local entry = from[donor_action_name .. suffix]

                if entry and entry.base_identifier then
                    local new_identifier = string.format("%s%s_%s", action_name, suffix, entry.base_identifier)

                    to[action_name .. suffix] = { new_identifier = new_identifier, base_identifier = entry.base_identifier }
                    action[field] = new_identifier
                elseif entry then
                    to[action_name .. suffix] = {}
                else
                    to[action_name .. suffix] = nil
                end
            end
        end
    end

    clone.actions[action_name] = action

    return true
end

local function apply_moveset(clone, notes)
    local DamageProfileTemplates = require("scripts/settings/damage/damage_profile_templates")
    local DamageSettings = require("scripts/settings/damage/damage_settings")
    local WoundsSettings = require("scripts/settings/wounds/wounds_settings")
    local WeaponHandlingTemplates = require("scripts/settings/equipment/weapon_handling_templates/weapon_handling_templates")
    local WeaponTweakTemplateSettings = require("scripts/settings/equipment/weapon_templates/weapon_tweak_template_settings")
    local damage_types = DamageSettings.damage_types
    local wounds_shapes = WoundsSettings.shapes

    for action_name, def in pairs(GRAFTS) do
        local donor = WeaponTemplates[def[1]]

        if donor and graft(clone, action_name, donor, def[2], notes) and def.chain then
            local chains = clone.actions[action_name].allowed_chain_actions

            for input, target in pairs(def.chain) do
                if chains and chains[input] then
                    chains[input].action_name = target
                end
            end
        end
    end

    -- stat bars and trait lerps per action (powermaul_shield_p1_m1.lua base_stats): heavy 3 reads like heavy 1
    for _, stat in pairs(clone.base_stats or {}) do
        local damage = type(stat) == "table" and stat.damage

        if damage and damage.action_heavy_1 and not damage.action_heavy_3 then
            damage.action_heavy_3 = table.clone(damage.action_heavy_1)
            damage.action_heavy_3.display_data = nil
        end
    end

    local handling = rawget(clone, "__base_template_lookup")
    handling = handling and handling[WeaponTweakTemplateSettings.template_types.weapon_handling]

    for action_name, def in pairs(MOVESET) do
        local action = clone.actions[action_name]
        local profile = rawget(DamageProfileTemplates, def.profile)

        if action and profile then
            action.damage_profile = def.blunt and blunt_profile(profile) or profile
            action.damage_type = rawget(damage_types, def.damage_type) or action.damage_type

            if def.wounds and wounds_shapes[def.wounds] then
                action.wounds_shape = wounds_shapes[def.wounds]
            elseif def.blunt then
                action.wounds_shape = nil
            end

            -- _build_templates resolves base_identifier, so the speed is changed in the lookup
            local entry = def.speed and handling and handling[action_name]

            if entry and entry.base_identifier and rawget(WeaponHandlingTemplates, def.speed) then
                entry.base_identifier = def.speed
            end
        else
            notes[#notes + 1] = string.format("moveset: %s/%s missing", action_name, def.profile)
        end
    end

    -- no power field: any shock damage left (special, push) becomes plain blunt with blunt wounds
    for _, action in pairs(clone.actions) do
        if action.damage_type == damage_types.blunt_shock then
            action.damage_type = damage_types.blunt
        end

        if type(action.damage_profile) == "table" then
            action.damage_profile = blunt_profile(action.damage_profile)
        end
    end

    clone.fx_sources = table.clone(clone.fx_sources or {})

    for source, node in pairs(FX_SOURCES) do
        clone.fx_sources[source] = node
    end

    -- powermaul_shield_p1_m1.lua:1613-1626: the shock-on-hit buff and the "Shock Weapon" keyword
    clone.buffs = {}

    local keywords = {}

    for _, keyword in ipairs(clone.displayed_keywords or {}) do
        if keyword.display_name ~= "loc_weapon_keyword_shock_weapon" then
            keywords[#keywords + 1] = keyword
        end
    end

    clone.displayed_keywords = keywords
end

-- State -------------------------------------------------------------------------------------------------------------
local state = { template_ok = false, item_ok = false, notes = {} }
local next_poll = 0
local assets_ready = false

-- Fatshark's unreleased sword-and-shield first-person animations (0.3.0) ---------------------------------------------
-- content/characters/player/human/first_person/animations/combat_sword_shield ships as a package + state machine
-- (unreleased-asset sweep 2026-10-25, index.tsv f732d4dc7e89349b) with no Lua using it. Its events, id32-matched against
-- every quoted string of the game source (technique-state-machine-event-scan; scratch\swordshield\sm\scan.py),
-- are exactly the assault_shield_maul 1P events plus an alternative inspect, so every action above plays its own sword-
-- and-shield clip. No 3P set exists; 3P stays assault_shield_maul. player_unit_animation_state.lua:112 indexes
-- PlayerUnitAnimationStateMachineSettings by path, so the new path gets a copy of the maul's entry (QIangIQsChainLaspistol
-- 0.3.0, rawset because the table comes from settings()).
local SWORD_SHIELD_SM_1P = "content/characters/player/human/first_person/animations/combat_sword_shield"

local function use_retail_animations(clone)
    state.retail_anims = false

    if mod:get("retail_animations") == false then
        return
    end

    local ok, found = pcall(Application.can_get_resource, "package", SWORD_SHIELD_SM_1P)

    if not (ok and found) then
        mod:info("%s not found: the Shield Maul's first-person animations stay", SWORD_SHIELD_SM_1P)

        return
    end

    local SMSettings = require("scripts/settings/animation/player_unit_animation_state_machine_settings")

    if not rawget(SMSettings, SWORD_SHIELD_SM_1P) then
        rawset(SMSettings, SWORD_SHIELD_SM_1P, table.clone(rawget(SMSettings, clone.anim_state_machine_1p) or { blend_time = 0 }))
    end

    clone.anim_state_machine_1p = SWORD_SHIELD_SM_1P
    state.retail_anims = true
end

local function ensure_template()
    if rawget(WeaponTemplates, TEMPLATE) then
        state.template_ok = true
        state.official_template = not state.template_ours

        return true
    end

    local source = WeaponTemplates[SOURCE_TEMPLATE]

    if not source then
        return false
    end

    local clone = table.clone(source)

    clone.name = TEMPLATE

    -- weapon_templates.lua _require_template: action_settings.name = action_name
    for action_name, action_settings in pairs(clone.actions) do
        action_settings.name = action_name
    end

    apply_moveset(clone, state.notes)
    use_retail_animations(clone)

    WeaponTemplates[TEMPLATE] = clone
    state.template_ours = true

    local ok, index = append_lookup("weapon_templates", TEMPLATE)

    state.template_id = ok and index or nil
    -- sword first (hits, swings), the shield maul fills what the sword lacks (block, shield special)
    state.aliases = copy_aliases(SWORD_TEMPLATE, TEMPLATE) + copy_aliases(SOURCE_TEMPLATE, TEMPLATE)
    state.template_ok = ok

    return ok
end

-- Items -------------------------------------------------------------------------------------------------------------
local function find_item(cache, preferred, template)
    local direct = rawget(cache, preferred)

    if direct and direct.weapon_template == template then
        return preferred, direct
    end

    for name, item in pairs(cache) do
        if type(item) == "table" and item.weapon_template == template then
            return name, item
        end
    end
end

-- Only base_unit is kept: Items.base_unit can also read per-breed / first-person variants of the source part
local function only_base_unit(item, unit)
    for key in pairs(item) do
        if type(key) == "string" and key ~= "base_unit" and key:find("^base_unit") then
            item[key] = nil
        end
    end

    item.base_unit = unit
end

local function make_part(cache, name, template_item, unit, attach_node)
    local item = table.clone(template_item)

    only_base_unit(item, unit)
    item.name = name
    item.resource_dependencies = { [unit] = true }
    item.attachments = nil
    item.material_overrides = nil
    item.material_override_items = nil
    item.attach_node = attach_node
    cache[name] = item

    return name
end

-- Source tree as "slot_path=item" for the log, to check the placement against the game's data
local function dump_tree(tree, prefix, out)
    for slot_name, node in pairs(tree) do
        if type(node) == "table" then
            local path = prefix .. slot_name

            out[#out + 1] = string.format("%s=%s%s", path, tostring(node.item),
                node.link_map_mode_override and (" map:" .. tostring(node.link_map_mode_override)) or "")

            if type(node.children) == "table" then
                dump_tree(node.children, path .. "/", out)
            end
        end
    end

    return out
end

-- Every item in the tree becomes "" (spawns nothing) except the nodes listed in keep
local function clear_tree(tree, keep)
    for _, node in pairs(tree) do
        if type(node) == "table" then
            if not keep[node] and type(node.item) == "string" then
                node.item = ""
            end

            if type(node.children) == "table" then
                clear_tree(node.children, keep)
            end
        end
    end
end

-- Slot scripts are read from the root item and every attachment item (wieldable_slot_scripts.lua:99-150, CLASSES by
-- name). These draw the power field / shock: shock_maul_hit_effects.lua, power_weapon_effects.lua,
-- power_weapon_charges_effects.lua, riot_shield_effects.lua (electrified shield loop on _shield_special_active).
local STRIP_SCRIPTS = {
    ShockMaulHitEffects = true,
    PowerWeaponEffects = true,
    PowerWeaponChargesEffects = true,
    PowerWeaponOverheatEffects = true,
    RiotShieldEffects = true,
}

local function strip_scripts(item, removed)
    if type(item.wieldable_slot_scripts) ~= "table" then
        return
    end

    local kept = {}

    for _, script_name in ipairs(item.wieldable_slot_scripts) do
        if STRIP_SCRIPTS[script_name] then
            removed[#removed + 1] = script_name
        else
            kept[#kept + 1] = script_name
        end
    end

    item.wieldable_slot_scripts = kept
end

local function build_item(cache)
    local source_name, source_item = find_item(cache, SOURCE_ITEM, SOURCE_TEMPLATE)
    local sword_name, sword_item = find_item(cache, SWORD_ITEM, SWORD_TEMPLATE)

    if not source_item or not sword_item then
        return false
    end

    if type(source_item.attachments) ~= "table" or type(sword_item.attachments) ~= "table" then
        return false, "source items have no attachments"
    end

    local item = table.clone(source_item)
    local notes = state.notes

    item.name = ITEM
    item.weapon_template = TEMPLATE
    item.display_name = DISPLAY

    for _, field in ipairs({ "weapon_family_display_name", "weapon_pattern_display_name", "weapon_mark_display_name" }) do
        if type(item[field]) == "table" then
            item[field].loc_id = DISPLAY
        end
    end

    local archetypes = {}

    for _, archetype in ipairs(source_item.archetypes or {}) do
        archetypes[#archetypes + 1] = archetype
    end

    if not table.find(archetypes, "zealot") then
        archetypes[#archetypes + 1] = "zealot"
    end

    item.archetypes = archetypes

    if not state.trees_logged then
        state.trees_logged = true
        mod:info("source tree of %s: %s", tostring(source_name), table.concat(dump_tree(item.attachments, "", {}), "; "))
        mod:info("sword tree of %s: %s", tostring(sword_name), table.concat(dump_tree(sword_item.attachments, "", {}), "; "))
    end

    -- Live trees (console log 2026-10-25 03:35):
    --   powermaul_shield_p1_m1: left = assault_shield_p1_m1 (the shield is a whole item on its own rig), right =
    --     powermaul_p1_empty, right/shaft (/connector/head, trinkets), right/trail = power_maul_trail_01
    --   combatsword_p1_m1: grip = combat_sword_grip_01, grip/body = combat_sword_blade_01, grip/trinket_hook, trail
    local left = item.attachments.left
    local right = item.attachments.right
    local shaft = right and type(right.children) == "table" and right.children.shaft
    local shaft_item = shaft and type(shaft.item) == "string" and rawget(cache, shaft.item)
    local grip = sword_item.attachments.grip
    local blade = grip and type(grip.children) == "table" and grip.children.body
    local grip_source = grip and rawget(cache, grip.item)
    local blade_source = blade and rawget(cache, blade.item)
    local sword_trail = sword_item.attachments.trail

    if not (left and type(left.item) == "string" and rawget(cache, left.item) and shaft_item) then
        return false, "no left (shield) or right/shaft slot in " .. tostring(source_name)
    end

    if not (grip_source and blade_source) then
        return false, "no grip or grip/body slot in " .. tostring(sword_name)
    end

    -- the shield item is copied whole under our name, so its spawned unit can be found by item name
    local shield_item = table.clone(rawget(cache, left.item))

    shield_item.name = SHIELD_ITEM
    cache[SHIELD_ITEM] = shield_item
    left.item = SHIELD_ITEM

    local removed = {}

    strip_scripts(item, removed)
    strip_scripts(shield_item, removed)

    if not state.scripts_logged then
        state.scripts_logged = true
        mod:info("slot scripts: root %s, shield %s, removed %s", table.concat(item.wieldable_slot_scripts or {}, ","),
            table.concat(shield_item.wieldable_slot_scripts or {}, ","), table.concat(removed, ","))
    end

    -- the sword takes the shaft's place under the right-hand rig and stays static relative to that node
    make_part(cache, GRIP_ITEM, grip_source, GRIP_UNIT, shaft_item.attach_node)
    make_part(cache, BLADE_ITEM, blade_source, BLADE_UNIT, BLADE_NODE)
    clear_tree(shaft.children or {}, {})
    shaft.item = GRIP_ITEM
    shaft.link_map_mode_override = "LINK_MODE_NONE"
    shaft.children = shaft.children or {}
    -- 0.3.0: the blade is held rigidly on the grip's ap_blade_01 too (user: blade not attached to the hilt; with the
    -- default LINK_MODE_NODE_NAME its nodes could follow same-named nodes instead, the DauntlessArmory 0.2.0 gotcha)
    shaft.children.qiangiq_blade = { item = BLADE_ITEM, children = {}, link_map_mode_override = "LINK_MODE_NONE" }

    -- sword trail instead of the power maul's
    if right.children.trail and sword_trail and type(sword_trail.item) == "string" and rawget(cache, sword_trail.item) then
        right.children.trail.item = sword_trail.item
    end

    notes[#notes + 1] = string.format("sword on right/shaft (attach node %s), shield %s", tostring(shaft_item.attach_node),
        tostring(shield_item.base_unit))


    -- HUD icon (hud_element_player_weapon.lua:77 reads item.hud_icon): the game's own unreleased sword-and-shield icon
    -- (material+package content/ui/materials/icons/weapons/hud/combatsword_shield_p1_m1, unreleased-asset sweep
    -- 2026-10-25, build 139617), else the combat sword's. The drawn icon can go over it (setting, needs Custom Assets).
    local deps0 = item.resource_dependencies or {}

    for _, icon in ipairs({ RETAIL_HUD_ICON, sword_item.hud_icon }) do
        local ok_icon, icon_found = pcall(Application.can_get_resource, "package", tostring(icon))

        if type(icon) == "string" and ok_icon and icon_found then
            if type(item.hud_icon) == "string" then
                deps0[item.hud_icon] = nil
            end

            item.hud_icon = icon
            deps0[icon] = true
            notes[#notes + 1] = "hud icon " .. icon

            break
        end
    end

    item.resource_dependencies = deps0

    -- What the offline item compile adds for the weapon template (item_package.lua:239-249): state machines, sounds,
    -- effects (DauntlessArmory 0.3.0)
    local deps = item.resource_dependencies or {}
    local WeaponTemplateResourceDependencies = require("scripts/utilities/weapon_template_resource_dependencies")

    for _, resource in ipairs(WeaponTemplateResourceDependencies.generate(TEMPLATE)) do
        deps[resource] = true
    end

    item.resource_dependencies = deps

    local ok, index = append_lookup("player_item_names", ITEM)

    if not ok then
        return false
    end

    cache[ITEM] = item
    state.item_id = index
    state.source_item_name = source_name
    state.slot = item.slots and item.slots[1]
    state.archetypes = archetypes

    return true
end

local function ensure_item()
    local ok, has_data = pcall(MasterItems.has_data)

    if not ok or not has_data then
        return false
    end

    local cache = MasterItems.get_cached()

    if rawget(cache, ITEM) then
        state.item_ok = true

        return true
    end

    local built, err = build_item(cache)

    if err and err ~= state.last_error then
        state.last_error = err
        mod:error("%s", err)
    end

    state.item_ok = built and rawget(cache, ITEM) ~= nil

    return state.item_ok
end

-- Unlock lists (weapon_unlock_settings.lua WeaponUnlockSettings[archetype][level] = { item names }); realms_loadout
-- weapon_catalog.lua builds its human weapon list from it
local function add_to_unlock_list()
    if not mod:get("add_to_unlock_list") then
        return
    end

    local ok, unlocks = pcall(require, "scripts/settings/weapon_unlock/weapon_unlock_settings")
    local zealot = ok and unlocks and unlocks.zealot

    if not zealot then
        mod:error("WeaponUnlockSettings.zealot not found")

        return
    end

    local level = math.floor(mod:get("unlock_level") or 1)

    zealot[level] = zealot[level] or {}

    if not table.find(zealot[level], ITEM) then
        table.insert(zealot[level], ITEM)
    end
end

local function poll()
    if next_poll > os.clock() then
        return
    end

    next_poll = os.clock() + 1

    local before_t, before_i = state.template_ok, state.item_ok
    local ok_t, err_t = pcall(ensure_template)
    local ok_i, err_i = true, nil

    if state.template_ok then
        ok_i, err_i = pcall(ensure_item)
    end

    if not ok_t then
        mod:error("template: %s", tostring(err_t))
    end

    if not ok_i then
        mod:error("item: %s", tostring(err_i))
    end

    if state.template_ok and not before_t then
        if state.official_template then
            mod:info("the game now has its own %s template; using it", TEMPLATE)
        else
            mod:info("template %s registered (clone of %s), %s alias entries, 1P animations %s", TEMPLATE, SOURCE_TEMPLATE,
                tostring(state.aliases), state.retail_anims and SWORD_SHIELD_SM_1P or "assault_shield_maul")
        end
    end

    if state.item_ok and not before_i then
        mod:info("item %s injected (clone of %s, slot %s): %s", ITEM, tostring(state.source_item_name), tostring(state.slot),
            table.concat(state.notes, "; "))
    end
end

-- Visuals: heater over the retail shield, sword grip offset ------------------------------------------------------------
-- Spawning, linking, 1p flags and cleanup follow QIangIQsDauntlessArmory's clip display (QIangIQsShardStaff pattern):
-- PlayerUnitVisualLoadoutExtension init/_update_item_visibility/update/_unequip_item_from_slot/destroy hooks,
-- ext._equipment[slot] item_name_by_unit_1p/3p (equipment_component.lua:299/345).
local tracked = {}

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function delete_unit(unit)
    local unit_spawner = Managers.state and Managers.state.unit_spawner

    if unit_ok(unit) and unit_spawner then
        unit_spawner:mark_for_deletion(unit)
    end
end

local function unit_named(names, want)
    if names then
        for unit, item_name in pairs(names) do
            if item_name == want and unit_ok(unit) then
                return unit
            end
        end
    end
end

local function spawn_linked(ext, unit_name, parent, first_person)
    local world = ext.__qiangiq_swordshield_world
    local unit_spawner = Managers.state and Managers.state.unit_spawner
    local unit = world and unit_spawner and unit_spawner:spawn_unit(unit_name, Unit.world_pose(parent, 1))

    if not unit then
        return nil
    end

    if first_person then
        Unit.set_unit_culling(unit, false)
        Unit.set_shader_pass_flag_for_meshes_in_unit_and_childs(unit, "custom_fov", true)
    end

    World.link_unit(world, unit, 1, parent, 1, World.LINK_MODE_NONE)

    return unit
end

local function drop_record(records, key)
    local rec = records[key]

    if rec then
        delete_unit(rec.unit)
        records[key] = nil
    end
end

local function sync_shield(ext, records, key, names, visible, first_person)
    local rec = records[key]
    local retail = unit_named(names, SHIELD_ITEM)
    local want = retail and assets_ready and mod:get("shield_model") ~= "retail"

    if rec and (rec.parent ~= retail or not want or not unit_ok(rec.unit)) then
        drop_record(records, key)
        rec = nil
    end

    if not want then
        return
    end

    if not rec then
        rec = { parent = retail, unit = spawn_linked(ext, SHIELD_UNIT, retail, first_person) }
        records[key] = rec

        if not rec.unit then
            return
        end
    end

    -- recursive visibility also reaches the linked heater, so the heater is set after the retail shield
    Unit.set_unit_visibility(retail, false, true)
    Unit.set_unit_visibility(rec.unit, visible, true)

    -- +x is the shield's outer face (probe4.py); the compiled mesh is already 6 cm further out than 0.1.x
    local depth = (mod:get("shield_depth") or 0) / 100

    if rec.depth ~= depth then
        rec.depth = depth
        Unit.set_local_position(rec.unit, 1, Vector3(depth, 0, 0))
    end
end

local function place_grip(names)
    local grip = unit_named(names, GRIP_ITEM)

    if grip then
        local offset = (mod:get("grip_offset") or 0) / 100

        Unit.set_local_position(grip, 1, Vector3(0, 0, offset))
    end
end

local function drop_slot(records, slot_name)
    drop_record(records, slot_name .. ":3p")
    drop_record(records, slot_name .. ":1p")
end

local function apply_visuals(ext)
    if not ext._is_local_unit or not ext._equipment then
        return
    end

    local records = ext.__qiangiq_swordshield

    if not records then
        records = {}
        ext.__qiangiq_swordshield = records
    end

    for slot_name, slot in pairs(ext._equipment) do
        local item = slot.item

        if item and item.name == ITEM then
            place_grip(slot.item_name_by_unit_3p)
            place_grip(slot.item_name_by_unit_1p)
            sync_shield(ext, records, slot_name .. ":3p", slot.item_name_by_unit_3p, slot.hidden_3p == false, false)
            sync_shield(ext, records, slot_name .. ":1p", slot.item_name_by_unit_1p, slot.hidden_1p == false, true)
        elseif records[slot_name .. ":3p"] or records[slot_name .. ":1p"] then
            drop_slot(records, slot_name)
        end
    end
end

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "init", function(self, extension_init_context)
    self.__qiangiq_swordshield_world = extension_init_context and extension_init_context.world
end)

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "_update_item_visibility", function(self)
    if self._is_local_unit then
        tracked[self] = true
        apply_visuals(self)
    end
end)

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "update", function(self)
    if tracked[self] then
        apply_visuals(self)
    end
end)

mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, "_unequip_item_from_slot", function(func, self, slot_name, ...)
    local records = self.__qiangiq_swordshield

    if records then
        drop_slot(records, slot_name)
    end

    return func(self, slot_name, ...)
end)

mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, "destroy", function(func, self, ...)
    local records = self.__qiangiq_swordshield

    if records then
        for key in pairs(records) do
            drop_record(records, key)
        end
    end

    tracked[self] = nil

    return func(self, ...)
end)

-- HUD icon ------------------------------------------------------------------------------------------------------------
-- No retail sword-and-shield icon exists. The icon (assets/swordshield_hud.png, _build/build_hud_icon.py) is compiled
-- into this mod's own Custom Assets build as a texture (_build/build_hud_glb.py wraps it in a one-quad unit, Custom/hud_icon)
-- and becomes resident with the heater; no SimpleAssets (user rule 2026-10-25: mods stand alone). The weapon HUD icon
-- widget (hud_element_player_weapon.lua:813 set_icon) is a texture pass whose value is a material; it is switched to
-- content/ui/materials/base/ui_default_base with material_values.texture_map, the emote wheel's way
-- (hud_element_emote_wheel_definitions.lua:76-83, hud_element_emote_wheel.lua:134). Without Custom Assets the HUD keeps
-- the game's own icon (see build_item). Setting hud_icon picks "game" (default) or "drawn".
local HUD_ICON_MATERIAL = "content/ui/materials/base/ui_default_base"
local HUD_ICON_TEXTURE = "content/mods/qiangiq_swordshield/hud_icon_material_1_bca"
local icon_ready = false

mod:hook_require("scripts/ui/hud/elements/player_weapon/hud_element_player_weapon", function(HudElementPlayerWeapon)
    mod:hook_safe(HudElementPlayerWeapon, "init", function(self, _, _, _, data)
        self.__qiangiq_swordshield = data and data.item and data.item.name == ITEM or false
    end)

    mod:hook_safe(HudElementPlayerWeapon, "update", function(self)
        local texture = self.__qiangiq_swordshield and icon_ready and mod:get("hud_icon") == "drawn" and HUD_ICON_TEXTURE
        local widget = texture and self._widgets_by_name and self._widgets_by_name.icon

        if not widget then
            return
        end

        local style = widget.style.icon

        style.material_values = style.material_values or {}

        if widget.content.icon ~= HUD_ICON_MATERIAL or style.material_values.texture_map ~= texture then
            widget.content.icon = HUD_ICON_MATERIAL
            style.material_values.texture_map = texture
            widget.dirty = true
        end
    end)
end)

-- Anim event guard (QIangIQsMeltagun 0.2.1 pattern): every grafted event is in the assault_shield_maul state machine,
-- this only skips one that is not instead of letting it fail. AuthoritativePlayerUnitAnimationExtension (hosting) has no
-- _local_wielded_weapon_template, so the wielded template name is stored from inventory_slot_wielded.
local skipped_events = {}

local function guard(unit_field)
    return function(func, self, event_name, ...)
        if (self.__qiangiq_swordshield_wielded or self._local_wielded_weapon_template) == TEMPLATE then
            local unit = self[unit_field]

            if unit and not Unit.has_animation_event(unit, event_name) then
                if not skipped_events[event_name] then
                    skipped_events[event_name] = true
                    mod:info("skipped anim event %s: not in the state machine", tostring(event_name))
                end

                return
            end
        end

        return func(self, event_name, ...)
    end
end

for _, class_name in ipairs({ "PlayerUnitAnimationExtension", "AuthoritativePlayerUnitAnimationExtension" }) do
    mod:hook_safe(CLASS[class_name], "inventory_slot_wielded", function(self, weapon_template)
        self.__qiangiq_swordshield_wielded = weapon_template and weapon_template.name or false
    end)

    for _, method in ipairs({ "anim_event_1p", "anim_event_with_variable_float_1p", "anim_event_with_variable_floats_1p" }) do
        mod:hook(CLASS[class_name], method, guard("_first_person_unit"))
    end
end

mod.update = function()
    poll()
end

-- Custom Assets API 1, the QIangIQsDauntlessArmory acquire call. Optional: without Custom Assets the weapon works with
-- the retail shield and the combat sword HUD icon (user rule 2026-10-25: no other mod is needed to function).
local function acquire(asset_id, on_ready)
    local custom_assets = get_mod("CustomAssets")

    if not custom_assets or not custom_assets.is_api_compatible or not custom_assets.is_api_compatible(1) then
        mod:info("Custom Assets (API 1) is not installed: %s is not shown, the retail look stays", asset_id)

        return
    end

    local ticket, err = custom_assets.acquire(mod, asset_id, function(_, _, load_error)
        if load_error then
            mod:info("%s did not load: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", asset_id, tostring(load_error))

            return
        end

        on_ready()
        mod:info("%s loaded", asset_id)
    end, { resident = true, reference_name = asset_id })

    if not ticket then
        mod:info("%s could not be requested: %s", asset_id, tostring(err))
    end
end

local function acquire_assets()
    acquire(SHIELD_ASSET, function()
        assets_ready = true
    end)
    acquire(HUD_ICON_ASSET, function()
        icon_ready = true
    end)
end

mod.on_all_mods_loaded = function()
    add_to_unlock_list()
    acquire_assets()
end

mod.on_unload = function()
    local ok, cache = pcall(MasterItems.get_cached)

    if ok and cache then
        for _, name in ipairs({ ITEM, GRIP_ITEM, BLADE_ITEM, SHIELD_ITEM }) do
            cache[name] = nil
        end
    end

    if state.template_ours then
        WeaponTemplates[TEMPLATE] = nil
    end
end

-- Equip without the backend (QIangIQsShardStaff override): only where this client hosts ----------------------------
local function local_player()
    local players = Managers.player

    return players and players:local_player_safe(1)
end

local function equipped_item_name(player, slot)
    local unit = player and player.player_unit

    if not unit or not Unit.alive(unit) then
        return nil
    end

    local extension = ScriptUnit.has_extension(unit, "visual_loadout_system")
    local item = extension and extension:item_from_slot(slot)

    return item and item.name
end

local previous = {}

local function override(slot, item_name)
    local player = local_player()
    local sync = Managers.profile_synchronization
    local host = sync and sync:synchronizer_host()

    if not player then
        say("no local player")

        return false
    end

    if not host then
        say("not the host here. Use the Psykhanium, a SoloPlay game or a game you host")

        return false
    end

    host:override_slot(player:peer_id(), player:local_player_id(), slot, item_name)
    say("override_slot(%s, %s) sent", slot, tostring(item_name))

    return true
end

local function package_state(path)
    local ok, exists = pcall(Application.can_get_resource, "package", path)

    return ok and tostring(exists) or "?"
end

local function status()
    say("template %s (id %s, from %s), item %s (id %s, slot %s, archetypes %s)", tostring(state.template_ok),
        tostring(state.template_id), SOURCE_TEMPLATE, tostring(state.item_ok), tostring(state.item_id), tostring(state.slot),
        table.concat(state.archetypes or {}, ","))
    say("  grip_08 package found: %s, blade_08 package found: %s", package_state(GRIP_UNIT), package_state(BLADE_UNIT))
    say("  heater model loaded: %s (shield model setting: %s), HUD icon loaded: %s", tostring(assets_ready),
        tostring(mod:get("shield_model")), tostring(icon_ready))

    if #state.notes > 0 then
        say("  %s", table.concat(state.notes, "; "))
    end
end

mod:command("swordshield", mod:localize("command_swordshield"), function(action)
    action = action or "status"

    if action == "status" then
        status()
    elseif action == "equip" then
        if not (state.template_ok and state.item_ok and state.slot) then
            say("not ready yet (template %s, item %s)", tostring(state.template_ok), tostring(state.item_ok))

            return
        end

        local player = local_player()

        previous[state.slot] = previous[state.slot] or (player and equipped_item_name(player, state.slot))
        override(state.slot, ITEM)
    elseif action == "restore" then
        local any = false

        for slot, item_name in pairs(previous) do
            if item_name and override(slot, item_name) then
                previous[slot] = nil
                any = true
            end
        end

        if not any then
            say("nothing to restore (equip first)")
        end
    else
        say("usage: /swordshield [status|equip|restore]")
    end
end)
