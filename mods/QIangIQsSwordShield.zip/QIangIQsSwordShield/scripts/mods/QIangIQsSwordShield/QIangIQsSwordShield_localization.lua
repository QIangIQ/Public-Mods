return {
    mod_name = {
        en = "QIangIQ's Sword and Shield",
    },
    mod_description = {
        en = "Adds the datamined sword and heater shield as a Zealot weapon. The sword is the unreleased retail Combat Sword blade_08 on grip_08; the heater shield is the unnamed datamined shield model, rebuilt as a Custom Assets model painted red and gold (optional: with Custom Assets and CUSTOM_ASSETS_PATCH.bat the heater (and an optional drawn HUD icon) show; without it the Shield Maul's shield does, and the weapon works the same). The game has no template for it, so it uses Fatshark's unreleased sword-and-shield first-person animations (third person: the Shield Maul's) with the Shield Maul's block and shield special with its own moveset: a horizontal sweep, a diagonal cut, a rising cut and a shield poke on lights; a diagonal cleave, an overhead chop or a shield slam on heavies; no power field. Pick it in Realms Loadout (/rl) or equip with /swordshield equip in the Psykhanium or a game you host. Everyone in the game needs this mod.",
    },
    command_swordshield = {
        en = "/swordshield [status|equip|restore]",
    },
    retail_animations = { en = "Use Fatshark's unreleased sword-and-shield first-person animations (needs a restart)" },
    add_to_unlock_list = { en = "List the weapon in the Zealot weapon unlock list (Realms Loadout reads it)" },
    unlock_level = { en = "Unlock level in that list (needs a restart)" },
    shield_model = { en = "Shield model" },
    shield_model_heater = { en = "Heater shield (datamined)" },
    shield_model_retail = { en = "Assault shield (retail)" },
    grip_offset = { en = "Sword position along the grip (cm)" },
    hud_icon = { en = "HUD icon" },
    hud_icon_game = { en = "Game's unreleased sword-and-shield icon" },
    hud_icon_drawn = { en = "Drawn icon (needs Custom Assets)" },
    shield_depth = { en = "Shield distance from the arm (cm, + = further out)" },
}
