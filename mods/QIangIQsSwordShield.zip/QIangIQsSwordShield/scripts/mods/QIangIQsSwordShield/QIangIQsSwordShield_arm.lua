-- Shield arm lift (first person, 0.4.0): the shield arm is raised by script (user test of 0.3.0: "shield arm is far to
-- low" with the sword-and-shield animations).
--
-- Method = QIangIQsChainLaspistol_brace.lua (QIangIQsKarambit / QIangIQsButterflyKnife driver method, seen working in
-- game): a skeleton-only "driver" unit with the first-person bone names is linked to the first-person unit, copies the
-- animated pose every frame, the arm meshes are re-linked to it (LINK_MODE_NODE_NAME), and Lua then overrides bones.
-- Here the override is a two-bone IK on j_leftarm / j_leftforearm that moves the left hand by an offset in camera
-- space and keeps its animated rotation, and the shield (a chained rig) is re-linked to the driver by node name like the
-- arm meshes, so hand and shield move together. The driver asset ships in this mod
-- (Custom/ss_fp_driver, a rename of ChainLaspistol's cl_fp_driver, _build/make_driver.py): no other mod is needed.
local Arm = {}
local CFG = nil

function Arm.setup(cfg)
    CFG = cfg
end

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function parent_chain(unit, node)
    local list, current, guard = {}, node, 0

    while current and guard < 64 do
        list[#list + 1] = current

        if current == 1 then
            break
        end

        current = Unit.scene_graph_parent(unit, current)
        guard = guard + 1
    end

    return list
end

local function root_relative(unit, node)
    if node == nil or node == 1 then
        return Quaternion.identity(), Vector3(0, 0, 0)
    end

    local chain = parent_chain(unit, node)
    local rotation, position = Quaternion.identity(), Vector3(0, 0, 0)
    local first = chain[#chain] == 1 and #chain - 1 or #chain

    for i = first, 1, -1 do
        position = position + Quaternion.rotate(rotation, Unit.local_position(unit, chain[i]))
        rotation = Quaternion.multiply(rotation, Unit.local_rotation(unit, chain[i]))
    end

    return rotation, position
end

-- driver <-> first-person node table (QIangIQsChainLaspistol_brace.lua make_fpd)
local function make_fpd(driver, fp_unit)
    local fpd = { driver = driver, fp_unit = fp_unit, nodes = {}, by_node = {}, fp_chains = {} }

    for _, name in ipairs(CFG.fp_nodes) do
        if Unit.has_node(driver, name) then
            local node = Unit.node(driver, name)

            if node ~= 1 and not fpd.by_node[node] then
                local entry = { node = node, parent = Unit.scene_graph_parent(driver, node) }

                if Unit.has_node(fp_unit, name) then
                    entry.fp = Unit.node(fp_unit, name)
                    fpd.fp_chains[entry.fp] = parent_chain(fp_unit, entry.fp)
                end

                fpd.by_node[node] = entry
                fpd.nodes[#fpd.nodes + 1] = entry
            end
        end
    end

    for _, name in ipairs({ "j_leftarm", "j_leftforearm", "j_lefthand", "j_leftweaponattach", "ap_camera_node" }) do
        if not (Unit.has_node(driver, name) and Unit.has_node(fp_unit, name)) then
            return nil
        end
    end

    return fpd
end

-- copy the animated first-person pose onto the driver (QIangIQsChainLaspistol_brace.lua copy_pose)
local function copy_pose(fpd)
    local driver, fp_unit = fpd.driver, fpd.fp_unit
    local poses = {}

    local function pose_of(node)
        if node == nil or node == 1 then
            return Quaternion.identity(), Vector3(0, 0, 0)
        end

        local pose = poses[node]

        if pose then
            return pose[1], pose[2]
        end

        local entry = fpd.by_node[node]
        local rotation, position

        if entry and entry.fp then
            local chain = fpd.fp_chains[entry.fp]
            rotation, position = Quaternion.identity(), Vector3(0, 0, 0)

            local first = chain[#chain] == 1 and #chain - 1 or #chain

            for i = first, 1, -1 do
                position = position + Quaternion.rotate(rotation, Unit.local_position(fp_unit, chain[i]))
                rotation = Quaternion.multiply(rotation, Unit.local_rotation(fp_unit, chain[i]))
            end
        else
            local parent_rotation, parent_position = pose_of(Unit.scene_graph_parent(driver, node))

            rotation = Quaternion.multiply(parent_rotation, Unit.local_rotation(driver, node))
            position = parent_position + Quaternion.rotate(parent_rotation, Unit.local_position(driver, node))
        end

        poses[node] = { rotation, position }

        return rotation, position
    end

    for i = 1, #fpd.nodes do
        local entry = fpd.nodes[i]

        if entry.fp then
            local rotation, position = pose_of(entry.node)
            local parent_rotation, parent_position = pose_of(entry.parent)
            local inverse_parent = Quaternion.inverse(parent_rotation)

            Unit.set_local_rotation(driver, entry.node, Quaternion.multiply(inverse_parent, rotation))
            Unit.set_local_position(driver, entry.node, Quaternion.rotate(inverse_parent, position - parent_position))
        end
    end
end

-- IK helpers (driver root-relative space, QIangIQsChainLaspistol_brace.lua) -----------------------------------------
local function rotation_between(u, v)
    local lu, lv = Vector3.length(u), Vector3.length(v)

    if lu < 1e-6 or lv < 1e-6 then
        return Quaternion.identity()
    end

    u, v = u * (1 / lu), v * (1 / lv)

    local axis = Vector3.cross(u, v)
    local s = Vector3.length(axis)

    if s < 1e-6 then
        return Quaternion.identity()
    end

    return Quaternion.axis_angle(axis * (1 / s), math.atan2(s, Vector3.dot(u, v)))
end

local function turn_node(driver, node, q)
    local pr = root_relative(driver, Unit.scene_graph_parent(driver, node))
    local r = root_relative(driver, node)

    Unit.set_local_rotation(driver, node, Quaternion.multiply(Quaternion.inverse(pr), Quaternion.multiply(q, r)))
end

local function pos(driver, name)
    local _, p = root_relative(driver, Unit.node(driver, name))

    return p
end

local function two_bone(driver, target, pole_point, w)
    local arm, fore = Unit.node(driver, "j_leftarm"), Unit.node(driver, "j_leftforearm")
    local S, E, H = pos(driver, "j_leftarm"), pos(driver, "j_leftforearm"), pos(driver, "j_lefthand")
    local a, b = Vector3.length(E - S), Vector3.length(H - E)
    local to_target = target - S
    local d = math.clamp(Vector3.length(to_target), math.abs(a - b) + 1e-3, a + b - 1e-3)
    local dir = Vector3.normalize(to_target)
    local pv = pole_point - S

    pv = pv - dir * Vector3.dot(pv, dir)

    if Vector3.length(pv) < 1e-5 then
        pv = (E - S) - dir * Vector3.dot(E - S, dir)
    end

    if Vector3.length(pv) < 1e-5 then
        return
    end

    pv = Vector3.normalize(pv)

    local cos_a = math.clamp((a * a + d * d - b * b) / (2 * a * d), -1, 1)
    local sin_a = math.sqrt(math.max(0, 1 - cos_a * cos_a))
    local elbow = S + dir * (cos_a * a) + pv * (sin_a * a)
    local q1 = Quaternion.lerp(Quaternion.identity(), rotation_between(E - S, elbow - S), w)

    turn_node(driver, arm, q1)

    local E1, H1 = pos(driver, "j_leftforearm"), pos(driver, "j_lefthand")
    local goal = H + (S + dir * d - H) * w
    local q2 = rotation_between(H1 - E1, goal - E1)

    turn_node(driver, fore, q2)
end

-- Camera frame in driver root space. 0.5.2 (user: shield only visible looking almost straight down): 0.5.x used the
-- rotation of the rig's ap_camera_node bone, whose axes need not be the view axes. The view comes from the camera
-- manager now (CFG.camera_pose: world rotation/position of the local player's camera, +y forward, +z up), taken into the
-- first-person unit's space; ap_camera_node stays the fallback.
local function camera_frame(data)
    local driver = data.driver
    local rotation, position = CFG.camera_pose and CFG.camera_pose()

    if rotation and position and unit_ok(data.fp_unit) then
        local inv_root = Quaternion.inverse(Unit.world_rotation(data.fp_unit, 1))

        return Quaternion.multiply(inv_root, rotation),
            Quaternion.rotate(inv_root, position - Unit.world_position(data.fp_unit, 1)), true
    end

    local cam_r, cam_p = root_relative(driver, Unit.node(driver, "ap_camera_node"))

    return cam_r, cam_p, false
end

-- the lift: hand position + offset (camera right / forward / up), animated hand rotation kept; the elbow keeps the
-- side it is animated on (pole = animated elbow, a little lower)
-- frame_offset (0.6.2): an extra move in the shield's own frame (attach node axes), so the hand can follow a heater
-- that was moved on the shield frame and stay on its grip
local function apply_lift(data, offset, frame_offset)
    local driver = data.driver
    local hand = Unit.node(driver, "j_lefthand")
    local cam_r = camera_frame(data)
    local hand_r, hand_p = root_relative(driver, hand)
    local target = hand_p + (offset and Quaternion.rotate(cam_r, offset) or Vector3(0, 0, 0))

    if frame_offset and data.shield_node and Unit.has_node(driver, data.shield_node) then
        local attach_r = root_relative(driver, Unit.node(driver, data.shield_node))

        target = target + Quaternion.rotate(attach_r, frame_offset)
    end
    local down = Quaternion.rotate(cam_r, Vector3(0, 0, -1))

    two_bone(driver, target, pos(driver, "j_leftforearm") + down * 0.1, 1)

    local parent_r = root_relative(driver, Unit.scene_graph_parent(driver, hand))

    Unit.set_local_rotation(driver, hand, Quaternion.multiply(Quaternion.inverse(parent_r), hand_r))
end

local FINGERS = {}         -- { left node name, right node name }

for _, finger in ipairs({ "index", "middle", "ring", "pinky" }) do
    FINGERS[#FINGERS + 1] = { "j_leftinhand" .. finger, "j_rightinhand" .. finger }

    for i = 1, 3 do
        FINGERS[#FINGERS + 1] = { "j_lefthand" .. finger .. i, "j_righthand" .. finger .. i }
    end
end

for i = 1, 3 do
    FINGERS[#FINGERS + 1] = { "j_lefthandthumb" .. i, "j_righthandthumb" .. i }
end

-- 0.5.0 hold (Combat Sword animations, user decision 2026-10-25): the shield's attach frame is put at a fixed camera-space
-- pose and the left hand is solved backwards from it (QIangIQsChainLaspistol_brace.lua apply_hold): the attach node keeps
-- its animated offset to j_lefthand, so hand target = shield frame * inverse(that offset), and the hand gets that rotation.
-- 0.5.1 (user: "forearm not through forearm shield loop like arbitrator shield"): the arm is no longer a plain IK to the
-- hand. Both shields carry their handles on the back at y ~0.19 (forearm loop) and y ~0 (hand grip) of the attach frame
-- (probe8.py: retail loop centroid -0.07/0.20/0, heater loop -0.065/0.189/0.002, heater
-- grip -0.046/0.002/0), so +y of the shield frame runs from the palm up the forearm. The elbow is put on that line
-- (wrist + forearm length along it) and the frame slides along the line until the upper arm length fits, so the forearm
-- lies through the loop.
-- boxed: a plain Vector3 made at load time is a frame temporary and is dead by the first update (0.5.2 log: "bad
-- argument #2 to 'rotate' (Vector3 expected, got userdata)", so the hold never ran and the shield followed the hand)
local FOREARM_AXIS = Vector3Box(-0.019, 0.189, 0.002)   -- grip -> loop in the shield frame (probe8.py)

local function apply_hold(data, offset, rotation)
    local driver = data.driver
    local arm, fore, hand = Unit.node(driver, "j_leftarm"), Unit.node(driver, "j_leftforearm"), Unit.node(driver, "j_lefthand")
    local attach = Unit.node(driver, data.shield_node)
    local cam_r, cam_p, from_camera = camera_frame(data)
    local shield_r = Quaternion.multiply(cam_r, rotation)
    local shield_p = cam_p + Quaternion.rotate(cam_r, offset)
    -- 0.5.2: rotation/offset place the SHIELD frame (the handles of probe8.py are in it); the attach node frame is that
    -- times the inverse of the shield root's local pose on the node (read live, the game links it with an offset)
    local local_r, local_p = data.shield_local_r:unbox(), data.shield_local_p:unbox()
    local frame_r = Quaternion.multiply(shield_r, Quaternion.inverse(local_r))
    local frame_p = shield_p - Quaternion.rotate(frame_r, local_p)
    local hand_r, hand_p = root_relative(driver, hand)
    local attach_r, attach_p = root_relative(driver, attach)
    local inv_hand = Quaternion.inverse(hand_r)
    local rel_r = Quaternion.multiply(inv_hand, attach_r)
    local rel_p = Quaternion.rotate(inv_hand, attach_p - hand_p)
    local target_r = Quaternion.multiply(frame_r, Quaternion.inverse(rel_r))
    local S, E0 = pos(driver, "j_leftarm"), pos(driver, "j_leftforearm")
    local a, b = Vector3.length(E0 - S), Vector3.length(hand_p - E0)
    local dir = Vector3.normalize(Quaternion.rotate(shield_r, FOREARM_AXIS:unbox()))
    local H = frame_p - Quaternion.rotate(target_r, rel_p)

    -- slide along the forearm line so |H + b*dir - S| = a
    local Q = H + dir * b - S
    local qd = Vector3.dot(Q, dir)
    local disc = qd * qd - Vector3.dot(Q, Q) + a * a
    local slide

    if disc >= 0 then
        local r = math.sqrt(disc)
        local s1, s2 = -qd + r, -qd - r

        slide = math.abs(s1) < math.abs(s2) and s1 or s2
    else
        slide = -qd
    end

    H = H + dir * slide

    local E = H + dir * b

    if disc < 0 then
        E = S + Vector3.normalize(E - S) * a
    end

    turn_node(driver, arm, rotation_between(pos(driver, "j_leftforearm") - S, E - S))

    local E1 = pos(driver, "j_leftforearm")

    turn_node(driver, fore, rotation_between(pos(driver, "j_lefthand") - E1, H - E1))

    local parent_r = root_relative(driver, Unit.scene_graph_parent(driver, hand))

    Unit.set_local_rotation(driver, hand, Quaternion.multiply(Quaternion.inverse(parent_r), target_r))

    -- fingers closed on the grip: the right hand's finger pose (it holds the sword); assumes mirrored joint axes
    -- (QIangIQsChainLaspistol_brace.lua grip_fingers)
    for i = 1, #FINGERS do
        local l, r = FINGERS[i][1], FINGERS[i][2]

        if Unit.has_node(driver, l) and Unit.has_node(driver, r) then
            Unit.set_local_rotation(driver, Unit.node(driver, l), Unit.local_rotation(driver, Unit.node(driver, r)))
        end
    end

    data.slide, data.from_camera = slide, from_camera
end

-- Pose rigs (0.6.0) ------------------------------------------------------------------------------------------------
-- A hidden copy of the retail first-person rig (human_breed.lua first_person_unit = content/characters/player/human/
-- first_person/base, skeleton only, spawned the same way by player_unit_first_person_extension.lua:90) plays a retail
-- first-person state machine (Unit.set_animation_state_machine, npc_animation.lua:58). Its j_left* (Arbites shield) or
-- j_right* (duelling sword) bones are copied onto the driver in root (= view) space, so the arm, and the shield or sword
-- linked to it, sit where the retail weapon puts them relative to the camera. The rig animates in the engine's world
-- update after Lua, so the copy is one frame behind, as the driver's copy of the first-person rig already is.
local POSE_UNIT = "content/characters/player/human/first_person/base"
-- 0.6.1: the rig's clips fire flow events (footsteps, foley, weapon sounds) whose FlowCallbacks read the "owner_unit"
-- data of the first-person unit (flow_callbacks.lua:725-729) and crashed on nil (user CTD 2026-10-25 23:35,
-- flow_callbacks.lua:704 first_person_extension nil). The main file drops flow callbacks from these rigs (Arm.is_rig), so
-- the hidden rigs stay silent; owner_unit is also set so a callback that gets through cannot crash.
local rigs = {}
-- 0.6.13: the sword-and-shield set's own riposte event (see riposte_event)
local RIPOSTE_EVENT = "attack_stab_to_parry_pose"

function Arm.is_rig(unit)
    return unit ~= nil and rigs[unit] == true
end

local function spawn_pose(world, fp_unit, state_machine)
    local unit_spawner = Managers.state and Managers.state.unit_spawner
    local ok, found = pcall(Application.can_get_resource, "state_machine", state_machine)

    if not unit_spawner or not (ok and found) then
        return nil, "state machine " .. tostring(state_machine) .. " not loaded", true
    end

    local unit = unit_spawner:spawn_unit(POSE_UNIT, Unit.world_pose(fp_unit, 1))

    if not unit then
        return nil, "rig did not spawn"
    end

    rigs[unit] = true

    local owner = Unit.get_data(fp_unit, "owner_unit")

    if owner then
        Unit.set_data(unit, "owner_unit", owner)
    end

    local set_ok, err = pcall(Unit.set_animation_state_machine, unit, state_machine)

    if not set_ok then
        unit_spawner:mark_for_deletion(unit)

        return nil, tostring(err)
    end

    World.link_unit(world, unit, 1, fp_unit, 1)

    if Unit.has_animation_event(unit, "equip") then
        Unit.animation_event(unit, "equip")
    end

    return unit
end

local function delete_pose(unit)
    local unit_spawner = Managers.state and Managers.state.unit_spawner

    if unit ~= nil then
        rigs[unit] = nil
    end

    if unit_ok(unit) and unit_spawner then
        unit_spawner:mark_for_deletion(unit)
    end
end

local function pose_nodes(driver, source, prefix)
    local list = {}

    for _, name in ipairs(CFG.fp_nodes) do
        if name:sub(1, #prefix) == prefix and Unit.has_node(driver, name) and Unit.has_node(source, name) then
            local node = Unit.node(driver, name)

            if node ~= 1 then
                list[#list + 1] = { node = node, src = Unit.node(source, name), depth = #parent_chain(driver, node) }
            end
        end
    end

    table.sort(list, function(a, b)
        return a.depth < b.depth
    end)

    return list
end

-- the driver's bones in list take the source rig's root-relative pose (w = blend from the current pose, 0..1)
local function apply_source(driver, source, list, w)
    local targets = {}

    for i = 1, #list do
        local r, p = root_relative(source, list[i].src)

        targets[i] = { r, p }
    end

    for i = 1, #list do
        local node = list[i].node
        local pr, pp = root_relative(driver, Unit.scene_graph_parent(driver, node))
        local inv = Quaternion.inverse(pr)
        local r = Quaternion.multiply(inv, targets[i][1])
        local p = Quaternion.rotate(inv, targets[i][2] - pp)

        if w < 1 then
            r = Quaternion.lerp(Unit.local_rotation(driver, node), r, w)
            p = Vector3.lerp(Unit.local_position(driver, node), p, w)
        end

        Unit.set_local_rotation(driver, node, r)
        Unit.set_local_position(driver, node, p)
    end
end

-- first-person events for the Arbites rig: block, push, equip, movement and inspect go through; the sword's swings do
-- not (user 0.5.3: "2H attacks bring the shield too"), and the parry special raises the shield like a block
local function shield_event(event_name)
    if event_name == "parry_special" then
        return "parry_pose"
    end

    if event_name == "attack_push" or event_name == "attack_finished" then
        return event_name
    end

    if event_name:find("^attack_") or event_name:find("^heavy_") or event_name:find("^hit_") then
        return nil
    end

    return event_name
end

local current = nil

function Arm.anim_event(fp_unit, event_name)
    local data = current

    if not (data and data.pose_l and data.fp_unit == fp_unit and type(event_name) == "string" and unit_ok(data.pose_l)) then
        return
    end

    local mapped = shield_event(event_name)

    if mapped and Unit.has_animation_event(data.pose_l, mapped) then
        Unit.animation_event(data.pose_l, mapped)
    end
end

local SABRE_EVENTS = { brace = "heavy_charge_stab_left", stab = "heavy_attack_stab_left" }

-- 0.6.13 (Oct 30 name list: 75 combat_sword_shield clips named; align2.py,
-- events2.py): the sword-and-shield set has its own event attack_stab_to_parry_pose (id32 only in that state machine,
-- not in assault_shield_maul) and its clips attack_stab_to_parry_pose / attack_stab_underhand sit after the shield poke.
-- Brace: the rig is already in parry_pose (the parry special is forwarded as parry_pose), its right arm holds the blade
-- beside the shield. Stab: the riposte event. Afterwards the rig returns to the block pose by the forwarded events.
local function riposte_event(data, phase)
    local unit = data.pose_l

    if phase == "stab" and unit_ok(unit) and Unit.has_animation_event(unit, RIPOSTE_EVENT) then
        Unit.animation_event(unit, RIPOSTE_EVENT)
    end
end

local function sabre_event(data, phase)
    local unit = data.pose_r
    local event_name = phase and SABRE_EVENTS[phase] or "attack_finished"

    if unit_ok(unit) and Unit.has_animation_event(unit, event_name) then
        Unit.animation_event(unit, event_name)
    elseif not data.sabre_missing then
        data.sabre_missing = true
        CFG.error("duelling sword rig has no event " .. event_name)
    end
end

-- start / stop / update --------------------------------------------------------------------------------------------
local function arm_units(ext)
    local found = {}

    for slot_name, slot in pairs(ext._equipment or {}) do
        if type(slot_name) == "string" and (slot_name:find("^slot_body") or slot_name:find("^slot_gear")) and unit_ok(slot.unit_1p) then
            found[#found + 1] = slot.unit_1p
        end
    end

    -- 0.6.11: first-person arm models spawned by other mods (QIangIQsNovitiate's Lacrima arms) are not in a slot. Such a
    -- mod lists them in ext.__qiangiq_fp_arms (unit = true) so they move with the Arbites left arm as well; without this
    -- they stayed on the first-person unit and played the Combat Sword's empty left hand beside the shield.
    for unit in pairs(ext.__qiangiq_fp_arms or {}) do
        if unit_ok(unit) then
            found[#found + 1] = unit
        end
    end

    return found
end

local function relink(world, unit, parent, parent_node)
    World.unlink_unit(world, unit)
    World.link_unit(world, unit, 1, parent, parent_node or 1, World.LINK_MODE_NODE_NAME)
end

-- the first-person node the shield's root sits on (the item's attach node; the game does not keep it in Lua): among the
-- rig nodes at the shield root's position (within 1 cm of the closest), the one whose rotation matches it best. 0.4.2
-- took the closest by position only and hit a node at the same spot with another rotation: the shield was upside down
-- (user screenshot 2026-10-25 08:59). 0.4.4: the log showed why: on the first frame the shield root was 1.24 m from every
-- rig node (not placed yet), so the pick was arbitrary (ap_magazine_01_elysian_offhand). The shield rig has a single
-- node (wpn_assault_shield_chained_rig, probe6.py), so its root sits on the attach node.
-- Now the pick waits until the root is within 3 cm of a rig node, prefers j_leftweaponattach (the left-hand attach
-- node), and if no node matches within 60 frames the lift is switched off and the shield stays where the game put it.
local function rotation_angle(a, b)
    local _, _, _, w = Quaternion.to_elements(Quaternion.multiply(Quaternion.inverse(a), b))

    return 2 * math.acos(math.min(1, math.abs(w)))
end

local function shield_attach_node(fp_unit, shield, prefer)
    prefer = prefer or "j_leftweaponattach"

    local root, root_r = Unit.world_position(shield, 1), Unit.world_rotation(shield, 1)
    local found, best_d = {}, nil

    for _, name in ipairs(CFG.fp_nodes) do
        if Unit.has_node(fp_unit, name) then
            local node = Unit.node(fp_unit, name)
            local d = Vector3.length(Unit.world_position(fp_unit, node) - root)

            found[#found + 1] = { name = name, d = d, a = rotation_angle(root_r, Unit.world_rotation(fp_unit, node)) }

            if not best_d or d < best_d then
                best_d = d
            end
        end
    end

    if not best_d or best_d > 0.03 then
        return nil, best_d
    end

    local best

    for _, entry in ipairs(found) do
        if entry.d <= best_d + 0.01 and entry.a < math.rad(5) and entry.name == prefer then
            best = entry

            break
        end

        if entry.d <= best_d + 0.01 and (not best or entry.a < best.a) then
            best = entry
        end
    end

    if best then
        return best.name, best.d, math.deg(best.a)
    end
end

-- The 1P shield is wpn_assault_shield_chained_rig (item log 2026-10-25): a chained rig linked by node name, so its bones
-- follow the parent's same-named bones. 0.4.0 linked it with LINK_MODE_NONE onto j_leftweaponattach and those bones fell
-- back to their bind pose, far left of the screen (user screenshot 2026-10-25 08:44). 0.4.1 re-links it like the arm
-- meshes: by node name onto the driver, and back onto the first-person unit when the lift stops. 0.4.1 used node 1 for
-- the root, so the root (and the heater linked to it) sat at the rig origin and ignored the lift (user 2026-10-25 08:51:
-- only the depth slider moved it). 0.4.2 links the root onto the same-named node it sat on (shield_attach_node).
local function release_shield(world, data)
    local shield = data.shield

    data.shield = nil

    if shield and unit_ok(shield) and unit_ok(data.fp_unit) then
        relink(world, shield, data.fp_unit, Unit.node(data.fp_unit, data.shield_node))
    end
end

function Arm.stop(ext)
    local data = ext.__qiangiq_swordshield_arm

    if not data then
        return
    end

    ext.__qiangiq_swordshield_arm = nil

    local world = ext.__qiangiq_swordshield_world

    if current == data then
        current = nil
    end

    delete_pose(data.pose_l)
    delete_pose(data.pose_r)

    if world then
        pcall(release_shield, world, data)

        if data.sword and unit_ok(data.sword) and unit_ok(data.fp_unit) then
            pcall(relink, world, data.sword, data.fp_unit, Unit.node(data.fp_unit, data.sword_node))
        end

        if unit_ok(data.fp_unit) then
            for unit in pairs(data.arms) do
                if unit_ok(unit) then
                    relink(world, unit, data.fp_unit)
                end
            end
        end
    end

    if unit_ok(data.driver) then
        local unit_spawner = Managers.state and Managers.state.unit_spawner

        if unit_spawner then
            unit_spawner:mark_for_deletion(data.driver)
        end
    end
end

local function start(ext, fp_unit, world)
    local unit_spawner = Managers.state and Managers.state.unit_spawner
    local path = CFG.driver_path()

    if not (unit_spawner and path) then
        return nil
    end

    local driver = unit_spawner:spawn_unit(path, Unit.world_pose(fp_unit, 1))

    if not driver then
        return nil
    end

    local ok, fpd = pcall(make_fpd, driver, fp_unit)

    if not ok or not fpd then
        unit_spawner:mark_for_deletion(driver)
        CFG.error("arm driver lacks the left arm / camera nodes: shield arm lift off")

        return nil
    end

    World.link_unit(world, driver, 1, fp_unit, 1)
    copy_pose(fpd)

    local data = { driver = driver, fpd = fpd, fp_unit = fp_unit, arms = {} }

    ext.__qiangiq_swordshield_arm = data

    return data
end

-- slot = our wielded slot (nil if not ours), shield = its first-person shield unit, mode = { kind = "lift", offset } or
-- { kind = "hold", offset, rotation } in camera space (nil = off). Returns true while it runs.
function Arm.update(ext, slot, shield, mode, sword)
    local fpe = unit_ok(ext._unit) and ScriptUnit.has_extension(ext._unit, "first_person_system")
    local fp_unit = fpe and fpe:first_person_unit()
    local world = ext.__qiangiq_swordshield_world
    local data = ext.__qiangiq_swordshield_arm
    local want = slot ~= nil and slot.hidden_1p == false and mode ~= nil and CFG.driver_path() ~= nil and world ~= nil
        and unit_ok(fp_unit) and unit_ok(shield) and shield ~= ext.__qiangiq_swordshield_arm_skip
        and fpe.is_in_first_person_mode and fpe:is_in_first_person_mode()

    if data and (not want or data.fp_unit ~= fp_unit or not unit_ok(data.driver) or (data.shield and data.shield ~= shield)
        or (data.sword and data.sword ~= sword)) then
        Arm.stop(ext)
        data = nil
    end

    if not want then
        return false
    end

    data = data or start(ext, fp_unit, world)

    if not data then
        return false
    end

    current = data

    -- arm meshes follow the driver (re-check: a body slot can be re-spawned)
    for _, unit in ipairs(arm_units(ext)) do
        if not data.arms[unit] then
            relink(world, unit, data.driver)
            data.arms[unit] = true
        end
    end

    for unit in pairs(data.arms) do
        if not unit_ok(unit) then
            data.arms[unit] = nil
        end
    end

    copy_pose(data.fpd)

    if not data.shield then
        local name, distance, angle = shield_attach_node(data.fp_unit, shield)

        if not (name and Unit.has_node(data.driver, name)) then
            data.wait = (data.wait or 0) + 1

            if data.wait > 60 then
                ext.__qiangiq_swordshield_arm_skip = shield
                CFG.error(string.format("shield attach node not found (closest rig node %.3f m away): shield arm lift off",
                    distance or -1))
                Arm.stop(ext)
            else
                World.update_unit_and_children(world, data.driver)
            end

            return false
        end

        relink(world, shield, data.driver, Unit.node(data.driver, name))
        data.shield, data.shield_node = shield, name
        data.shield_local_r = QuaternionBox(Unit.local_rotation(shield, 1))
        data.shield_local_p = Vector3Box(Unit.local_position(shield, 1))
        CFG.info(string.format("shield root on %s (%.3f m, %.0f deg off; local pose %s, %s), linked to the arm driver", name,
            distance, angle, tostring(Unit.local_position(shield, 1)), tostring(Unit.local_rotation(shield, 1))))
    end

    -- 0.6.0: the sword's right-hand root follows the driver too (same node-name link), for the duelling sword riposte
    if not data.sword and sword and unit_ok(sword) and not data.sword_failed then
        local name = shield_attach_node(data.fp_unit, sword, "j_rightweaponattach")

        if name and Unit.has_node(data.driver, name) then
            relink(world, sword, data.driver, Unit.node(data.driver, name))
            data.sword, data.sword_node = sword, name
            CFG.info("sword root on " .. name .. ", linked to the arm driver")
        else
            data.sword_wait = (data.sword_wait or 0) + 1

            if data.sword_wait > 60 then
                data.sword_failed = true
                CFG.error("sword attach node not found: the duelling sword riposte pose is off")
            end
        end
    end

    -- 0.6.13: the left rig plays Fatshark's own sword-and-shield set first (CFG.shield_sms[1]), the Arbites set is the
    -- fallback when that one cannot start
    if mode.kind == "anim" and not data.pose_l and not data.anim_failed then
        local sms = CFG.shield_sms or { CFG.shield_sm }
        local index = data.sm_index or 1
        local sm = sms[index]
        local unit, why, retry = spawn_pose(world, fp_unit, sm)

        data.l_tries = (data.l_tries or 0) + 1

        if unit then
            data.pose_l = unit
            data.pose_l_sm = sm
            data.left_nodes = pose_nodes(data.driver, unit, "j_left")
            -- the sword-and-shield set also carries the riposte (event attack_stab_to_parry_pose, only in that set)
            data.ss_riposte = Unit.has_animation_event(unit, RIPOSTE_EVENT)

            if data.ss_riposte then
                data.right_nodes = pose_nodes(data.driver, unit, "j_right")
            end

            CFG.info(string.format("shield rig started on %s (%d left arm bones, own riposte %s)", tostring(sm),
                #data.left_nodes, tostring(data.ss_riposte)))
        elseif retry and data.l_tries < 300 then
            mode = mode.fallback
        elseif sms[index + 1] then
            CFG.info("shield rig " .. tostring(sm) .. " did not start (" .. tostring(why) .. "), trying " .. tostring(sms[index + 1]))
            data.sm_index = index + 1
            data.l_tries = 0
            mode = mode.fallback
        else
            data.anim_failed = true
            CFG.error("shield rig did not start (" .. tostring(why) .. "): scripted hold instead")
        end
    end

    if mode.kind == "anim" and not data.pose_r and not data.sabre_failed and data.pose_l and not data.ss_riposte then
        local unit, why, retry = spawn_pose(world, fp_unit, CFG.sabre_sm)

        data.r_tries = (data.r_tries or 0) + 1

        if unit then
            data.pose_r = unit
            data.right_nodes = pose_nodes(data.driver, unit, "j_right")
        elseif retry and data.r_tries < 300 then
            -- try again next frame
        else
            data.sabre_failed = true
            CFG.error("duelling sword rig did not start (" .. tostring(why) .. "): no riposte pose")
        end
    end

    if mode.kind == "anim" and data.anim_failed then
        mode = mode.fallback
    end

    -- 0.6.12 idle sway (user: "give the left arm some idle sway as it being perfectly still is a bit unrealistic, do the
    -- same for the shield arm"): a slow breathing drift of a few millimetres and about a degree, in camera space (right /
    -- forward / up), added to every pose; the same curves as QIangIQsDauntlessFalchion's left arm
    data.sway_t = (data.sway_t or 0) + (ext.__qiangiq_swordshield_dt or 0)

    local sway_offset, sway_rotation
    local sway_mod = rawget(_G, "get_mod") and get_mod("QIangIQsSwordShield")
    local sway = (sway_mod and sway_mod:get("idle_sway") or 100) / 100

    if sway > 0 then
        local t = data.sway_t

        sway_offset = Vector3(0.004 * math.sin(t * 1.1), 0.002 * math.sin(t * 0.7 + 2), 0.006 * math.sin(t * 0.8 + 1)) * sway
        sway_rotation = Quaternion.from_yaw_pitch_roll(math.rad(0.6 * sway * math.sin(t * 0.5)),
            math.rad(1.2 * sway * math.sin(t * 0.9 + 0.5)), math.rad(0.8 * sway * math.sin(t * 0.6 + 1.5)))
    end

    local function swayed(offset)
        if not sway_offset then
            return offset
        end

        return offset and offset + sway_offset or sway_offset
    end

    local ok, err = true, nil

    if mode.kind == "anim" then
        ok, err = pcall(apply_source, data.driver, data.pose_l, data.left_nodes, 1)

        if ok and (mode.offset or mode.frame_offset or sway_offset) then
            ok, err = pcall(apply_lift, data, swayed(mode.offset), mode.frame_offset)
        end

        -- right arm: duelling sword windup through the parry special, its heavy stab on the riposte
        local right_rig = data.ss_riposte and data.pose_l or data.pose_r

        if right_rig and data.sword then
            if mode.phase ~= data.phase then
                data.phase = mode.phase

                if data.ss_riposte then
                    pcall(riposte_event, data, mode.phase)
                else
                    pcall(sabre_event, data, mode.phase)
                end
            end

            local rate = mode.phase and 10 or 6
            local w = math.clamp((data.right_w or 0) + (mode.phase and 1 or -1) * (mode.dt or 0) * rate, 0, 1)

            data.right_w = w

            if ok and w > 0 then
                ok, err = pcall(apply_source, data.driver, right_rig, data.right_nodes, w * w * (3 - 2 * w))
            end
        end
    elseif mode.kind == "hold" then
        local rotation = sway_rotation and Quaternion.multiply(mode.rotation, sway_rotation) or mode.rotation

        ok, err = pcall(apply_hold, data, swayed(mode.offset), rotation)

        if ok and mode.lift then
            ok, err = pcall(apply_lift, data, mode.lift)
        end
    else
        ok, err = pcall(apply_lift, data, swayed(mode.offset))
    end

    if not ok and not data.reported then
        data.reported = true
        CFG.error("arm " .. tostring(mode.kind) .. ": " .. tostring(err))
    end

    World.update_unit_and_children(world, data.driver)

    return true
end

function Arm.debug(ext)
    local data = ext.__qiangiq_swordshield_arm

    if not data then
        return "shield arm lift: not active (driver asset " .. tostring(CFG.driver_path()) .. ")"
    end

    local n = 0

    for _ in pairs(data.arms) do
        n = n + 1
    end

    local cam_r = camera_frame(data)
    local bone_r = root_relative(data.driver, Unit.node(data.driver, "ap_camera_node"))

    return string.format("shield arm: active, %d arm units on the driver, shield on %s, sword on %s, shield rig %s (%s), riposte from %s (phase %s, weight %.2f), view from camera %s, camera bone %.0f deg off the view",
        n, tostring(data.shield_node), tostring(data.sword_node), data.pose_l and "on" or (data.anim_failed and "failed" or "off"),
        tostring(data.pose_l_sm), data.ss_riposte and "the sword-and-shield set" or (data.pose_r and "the duelling sword rig"
        or (data.sabre_failed and "nothing (failed)" or "nothing")), tostring(data.phase), data.right_w or 0,
        tostring(data.from_camera), math.deg(rotation_angle(cam_r, bone_r)))
end

return Arm
