local mod = get_mod("QIangIQsSwordShield")

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = false,
    options = {
        widgets = {
            {
                setting_id = "animation_set",
                type = "dropdown",
                default_value = "sword",
                options = {
                    { text = "animation_set_sword", value = "sword" },
                    { text = "animation_set_shield_maul", value = "shield_maul" },
                },
            },
            {
                setting_id = "left_arm_set",
                type = "dropdown",
                default_value = "sword_shield",
                options = {
                    { text = "left_arm_set_sword_shield", value = "sword_shield" },
                    { text = "left_arm_set_arbites", value = "arbites" },
                },
            },
            {
                setting_id = "shield_hold",
                type = "dropdown",
                default_value = "arbites",
                options = {
                    { text = "shield_hold_arbites", value = "arbites" },
                    { text = "shield_hold_scripted", value = "scripted" },
                },
            },
            {
                setting_id = "third_person_set",
                type = "dropdown",
                default_value = "shield",
                options = {
                    { text = "third_person_set_shield", value = "shield" },
                    { text = "third_person_set_sword", value = "sword" },
                },
            },
            { setting_id = "cleave_multiplier", type = "numeric", default_value = 2, range = { 1, 4 }, decimals_number = 1 },
            { setting_id = "damage_percent", type = "numeric", default_value = 100, range = { 25, 150 }, decimals_number = 0 },
            { setting_id = "carapace_heavy", type = "checkbox", default_value = true },
            { setting_id = "carapace_light", type = "checkbox", default_value = true },
            { setting_id = "shield_defence", type = "checkbox", default_value = true },
            { setting_id = "hold_x", type = "numeric", default_value = 0, range = { -30, 30 }, decimals_number = 1 },
            { setting_id = "hold_y", type = "numeric", default_value = 0, range = { -30, 30 }, decimals_number = 1 },
            { setting_id = "hold_z", type = "numeric", default_value = 0, range = { -30, 30 }, decimals_number = 1 },
            { setting_id = "hold_turn", type = "numeric", default_value = 0, range = { -180, 180 }, decimals_number = 0 },
            { setting_id = "hold_tilt", type = "numeric", default_value = 0, range = { -180, 180 }, decimals_number = 0 },
            { setting_id = "hold_spin", type = "numeric", default_value = 0, range = { -180, 180 }, decimals_number = 0 },
            { setting_id = "block_x", type = "numeric", default_value = 0, range = { -30, 30 }, decimals_number = 1 },
            { setting_id = "block_y", type = "numeric", default_value = 0, range = { -30, 30 }, decimals_number = 1 },
            { setting_id = "block_z", type = "numeric", default_value = 0, range = { -30, 30 }, decimals_number = 1 },
            { setting_id = "retail_animations", type = "checkbox", default_value = true },
            { setting_id = "add_to_unlock_list", type = "checkbox", default_value = true },
            { setting_id = "unlock_level", type = "numeric", default_value = 1, range = { 1, 30 }, decimals_number = 0 },
            {
                setting_id = "shield_model",
                type = "dropdown",
                default_value = "heater",
                options = {
                    { text = "shield_model_heater", value = "heater" },
                    { text = "shield_model_retail", value = "retail" },
                },
            },
            {
                setting_id = "heater_fit",
                type = "dropdown",
                default_value = "arbites",
                options = {
                    { text = "heater_fit_arbites", value = "arbites" },
                    { text = "heater_fit_handles", value = "handles" },
                },
            },
            { setting_id = "grip_offset", type = "numeric", default_value = 0, range = { -15, 15 }, decimals_number = 1 },
            { setting_id = "blade_offset", type = "numeric", default_value = -2.5, range = { -10, 10 }, decimals_number = 1 },
            {
                setting_id = "hud_icon",
                type = "dropdown",
                default_value = "game",
                options = {
                    { text = "hud_icon_game", value = "game" },
                    { text = "hud_icon_drawn", value = "drawn" },
                },
            },
            { setting_id = "shield_depth", type = "numeric", default_value = 0, range = { -10, 10 }, decimals_number = 1 },
            { setting_id = "shield_lift", type = "numeric", default_value = 0, range = { -20, 30 }, decimals_number = 1 },
            { setting_id = "shield_forward", type = "numeric", default_value = 0, range = { -20, 20 }, decimals_number = 1 },
            { setting_id = "shield_side", type = "numeric", default_value = 0, range = { -20, 20 }, decimals_number = 1 },
            { setting_id = "idle_sway", type = "numeric", default_value = 100, range = { 0, 300 }, decimals_number = 0 },
        },
    },
}
