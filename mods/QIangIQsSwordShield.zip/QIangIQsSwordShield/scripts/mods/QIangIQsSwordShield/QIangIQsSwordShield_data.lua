local mod = get_mod("QIangIQsSwordShield")

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = false,
    options = {
        widgets = {
            { setting_id = "retail_animations", type = "checkbox", default_value = true },
            { setting_id = "add_to_unlock_list", type = "checkbox", default_value = true },
            { setting_id = "unlock_level", type = "numeric", default_value = 1, range = { 1, 30 }, decimals_number = 0 },
            {
                setting_id = "shield_model",
                type = "dropdown",
                default_value = "heater",
                options = {
                    { text = "shield_model_heater", value = "heater" },
                    { text = "shield_model_retail", value = "retail" },
                },
            },
            { setting_id = "grip_offset", type = "numeric", default_value = 0, range = { -15, 15 }, decimals_number = 1 },
            {
                setting_id = "hud_icon",
                type = "dropdown",
                default_value = "game",
                options = {
                    { text = "hud_icon_game", value = "game" },
                    { text = "hud_icon_drawn", value = "drawn" },
                },
            },
            { setting_id = "shield_depth", type = "numeric", default_value = 0, range = { -10, 10 }, decimals_number = 1 },
        },
    },
}
