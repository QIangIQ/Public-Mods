# id32 scan of state machines (technique-state-machine-event-scan): candidate = every quoted string in the game source.
import os, re, struct, collections, json
def m64(data, seed=0):
    m = 0xc6a4a7935bd1e995; r = 47; M = (1 << 64) - 1
    h = (seed ^ (len(data) * m)) & M
    n = len(data) // 8
    for i in range(n):
        k = struct.unpack_from("<Q", data, i * 8)[0]
        k = (k * m) & M; k ^= k >> r; k = (k * m) & M
        h ^= k; h = (h * m) & M
    t = data[n * 8:]
    for i in range(len(t) - 1, -1, -1):
        h ^= t[i] << (8 * i)
    if t: h = (h * m) & M
    h ^= h >> r; h = (h * m) & M; h ^= h >> r
    return h

SRC = r'scratch\aussiemon_src\scripts'
words = set()
q = re.compile(r'"([A-Za-z0-9_]{2,80})"')
for root, _, files in os.walk(SRC):
    for f in files:
        if f.endswith('.lua'):
            for w in q.findall(open(os.path.join(root, f), encoding='utf-8', errors='ignore').read()):
                words.add(w)
h32 = collections.defaultdict(set)
for w in words:
    h32[m64(w.encode()) >> 32].add(w)

def scan(path):
    b = open(path, 'rb').read(); found = collections.Counter()
    for off in range(0, len(b) - 3):
        v = struct.unpack_from('<I', b, off)[0]
        if v in h32: found[v] += 1
    return {",".join(sorted(h32[v])): c for v, c in found.items()}

A = r'A:\Dowloads\Darktide_NonMod\chainlas_sm\content\characters\player\human\first_person\animations'
res = {
    'combat_sword_shield': scan(r'scratch\swordshield\sm\content\characters\player\human\first_person\animations\combat_sword_shield.state_machine'),
    'assault_shield_maul': scan(A + r'\assault_shield_maul.state_machine'),
    'combat_sword': scan(A + r'\combat_sword.state_machine'),
}
json.dump(res, open(r'scratch\swordshield\sm\scan.json', 'w'), indent=0)
for k, v in res.items(): print(k, len(v))
