import sys
sys.path.insert(0, r'A:\Dowloads\QIangIQsMapViewer\pipeline')
import dtfmt, unit as UN
id32 = lambda s: dtfmt.murmur64(s) >> 32
cands = ['fx_sweep','fx_block','fx_display','fx_special_active','fx_shield_special_active','fx_trail','ap_blade_01','ap_grip_01','ap_body_01','ap_trinket_01','ap_emblem_01','ap_emblem_left','ap_emblem_right','ap_left_01','ap_shield_01','ap_handle_01','ap_pommel_01','ap_guard_01','ap_shaft_01','ap_head_01','ap_connector_01','rp_blade_08','rp_grip_08','rp_wpn_combat_sword_chained_rig','ap_body','ap_blade','ap_grip','root_point','ap_left','ap_right','fx_trail_01','fx_impact','ap_slot_trinket_1','ap_trinket_hook','ap_trinket_hook_01','fx_handle','rp_assault_shield_01','fx_01','fx_02','ap_anim_01','ap_anim_02','ap_anim_03','ap_anim_04','ap_emblem_left_01','ap_emblem_right_01']
m = {id32(c): c for c in cands}
for n in ['content/weapons/player/melee/combat_sword/wpn_combat_sword_chained_rig','content/weapons/player/melee/combat_sword/attachments/blade_08/blade_08','content/weapons/player/melee/combat_sword/attachments/blade_07/blade_07','content/weapons/player/melee/combat_sword/attachments/grip_08/grip_08','content/weapons/player/shields/assault_shield/attachments/assault_shield_01/assault_shield_01','content/weapons/player/melee/human_power_maul_short/wpn_human_power_maul_short_chained_rig']:
    try: U = UN.load_unit(dtfmt.murmur64(n))
    except Exception as e: print(n,'ERR',e); continue
    print(n.split('/')[-1], [(m.get(h, hex(h)), U['node_world'][i][:3,3].round(3).tolist()) for i,h in enumerate(U['node_names'])])
