# Builds heater_shield.glb v4 (user 2026-10-26: "remove arby shield texture, for now gild the symbols and edges, and have
# velvet and armor for the center part"). Geometry and planar UV layout are v2's (build_shield_glb.py: front faces left
# half, back faces right half, mirrored). No retail texture is used any more: the paint is driven by the heater's own
# relief. Front and back height maps (largest / smallest x over (y, z), same rasteriser as probe12.py) give:
#   gold   = raised symbols (fleurs, studs: height above a blurred copy) + the outer rim band + the grip end caps
#   velvet = the recessed field between the rim and the central plate (crimson, non-metal, rough)
#   armour = a heater-shaped steel plate in the centre (inset PLATE_IN from the silhouette), brushed, with a dark seam
# Back: dark blackened steel, gilded rim, leather grips. Normal map flat; the mesh carries the relief.
import io, json, struct, sys
import numpy as np
from PIL import Image
from scipy.ndimage import distance_transform_edt, gaussian_filter

SRC = r'A:\Dowloads\Darktide_NonMod\dauntless_datamine\05_weapon_sword_and_shield\26b996dc3fdb55ff\26b996dc3fdb55ff.obj'
OUT = sys.argv[1] if len(sys.argv) > 1 else 'heater_shield.glb'
OFFSET = (0.072, 0.014, 0.002)
R = 2048            # texture size
G = 1024            # relief grid
RIM_W = 0.018       # gilded rim band, metres from the silhouette
PLATE_IN = 0.085    # armour plate inset, metres from the silhouette
SYMBOL_H = 0.0012   # symbol height above the blurred surface, metres
GOLD = np.array([226, 176, 74], np.float32)
VELVET = np.array([96, 8, 18], np.float32)
STEEL = np.array([150, 152, 158], np.float32)
BLACK_STEEL = np.array([52, 52, 56], np.float32)
LEATHER = np.array([74, 46, 28], np.float32)

# heater geometry + v2 UVs ---------------------------------------------------------------------------------------------
V, VN, F = [], [], []
for line in open(SRC):
    if line.startswith('v '):
        V.append(tuple(map(float, line.split()[1:4])))
    elif line.startswith('vn '):
        VN.append(tuple(map(float, line.split()[1:4])))
    elif line.startswith('f '):
        F.append([tuple(int(x) - 1 if x else -1 for x in p.split('/')) for p in line.split()[1:]])
Va = np.array(V)
ymin, ymax = Va[:, 1].min(), Va[:, 1].max()
zmin, zmax = Va[:, 2].min(), Va[:, 2].max()
ry, rz = ymax - ymin, zmax - zmin

def uv_of(y, z, side):
    u = 0.02 + 0.46 * (y - ymin) / ry
    if side == 1:
        u = 1.0 - u
    return u, 0.02 + 0.96 * (zmax - z) / rz

key_to_idx = {}; pos = []; nrm = []; uv = []; idx = []
for f in F:
    fn = np.mean([VN[n] for _, _, n in f], 0)
    side = 0 if fn[0] >= 0 else 1
    tri = []
    for v, _, n in f:
        k = (v, n, side)
        x, y, z = V[v]
        if k not in key_to_idx:
            key_to_idx[k] = len(pos)
            pos.append((x + OFFSET[0], z + OFFSET[2], -(y + OFFSET[1])))
            nx, ny, nz = VN[n]; nrm.append((nx, nz, -ny))
            uv.append(uv_of(y, z, side))
        tri.append(key_to_idx[k])
    for i in range(1, len(tri) - 1):
        idx += [tri[0], tri[i], tri[i + 1]]
pos = np.array(pos, np.float32); nrm = np.array(nrm, np.float32); uv = np.array(uv, np.float32); idx = np.array(idx, np.uint32)

# relief height maps over (y, z) ---------------------------------------------------------------------------------------
s = (G - 1) / max(ry, rz)          # grid cells per metre
front = np.full((G, G), np.nan); back = np.full((G, G), np.nan)
for f in F:
    vs = [p[0] for p in f]
    for i in range(1, len(vs) - 1):
        a, b, c = Va[vs[0]], Va[vs[i]], Va[vs[i + 1]]
        gy = (np.array([a[1], b[1], c[1]]) - ymin) * s; gz = (zmax - np.array([a[2], b[2], c[2]])) * s
        xs, ys = np.meshgrid(np.arange(int(gy.min()), int(np.ceil(gy.max())) + 1), np.arange(int(gz.min()), int(np.ceil(gz.max())) + 1))
        den = (gz[1] - gz[2]) * (gy[0] - gy[2]) + (gy[2] - gy[1]) * (gz[0] - gz[2])
        if abs(den) < 1e-12: continue
        w0 = ((gz[1] - gz[2]) * (xs - gy[2]) + (gy[2] - gy[1]) * (ys - gz[2])) / den
        w1 = ((gz[2] - gz[0]) * (xs - gy[2]) + (gy[0] - gy[2]) * (ys - gz[2])) / den
        w2 = 1 - w0 - w1
        m = (w0 >= -1e-3) & (w1 >= -1e-3) & (w2 >= -1e-3) & (xs >= 0) & (ys >= 0) & (xs < G) & (ys < G)
        x = w0 * a[0] + w1 * b[0] + w2 * c[0]
        for grid, better in ((front, np.greater), (back, np.less)):
            cur = grid[ys[m], xs[m]]
            ok = np.isnan(cur) | better(x[m], cur)
            grid[ys[m][ok], xs[m][ok]] = x[m][ok]
inside = ~np.isnan(front)
# metres to the silhouette; padded, the top (z max) and side (y min) bounds sit on the grid border
edge = distance_transform_edt(np.pad(inside, 4))[4:-4, 4:-4] / s

def raised(h, sign):
    # height above a blurred copy of the surface (holes filled from the nearest cell first)
    _, (iy, ix) = distance_transform_edt(np.isnan(h), return_indices=True)
    hf = h[iy, ix]
    return sign * (hf - gaussian_filter(hf, 0.012 * s))

rng = np.random.default_rng(7)
def noise(sigma, amp):
    n = gaussian_filter(rng.standard_normal((G, G)), sigma)
    return n * amp / max(1e-9, n.std())

# front paint -----------------------------------------------------------------------------------------------------------
sym_f = (raised(front, 1) > SYMBOL_H) & inside
rim = inside & (edge < RIM_W)
gold_f = gaussian_filter((sym_f | rim).astype(float), 0.8) > 0.5
plate = inside & (edge > PLATE_IN)
seam = inside & (np.abs(edge - PLATE_IN) < 0.0025)
weave = noise(1.2, 0.10) + noise(10, 0.14)                        # crushed velvet
brush = noise((14, 0.4), 0.06)   # vertical brushing
col_f = np.empty((G, G, 3), np.float32); rough_f = np.empty((G, G)); metal_f = np.empty((G, G))
col_f[:] = VELVET * (1 + weave)[..., None]; rough_f[:] = 0.92; metal_f[:] = 0.0
col_f[plate] = (STEEL * (1 + brush + noise(30, 0.04))[..., None])[plate]; rough_f[plate] = 0.42; metal_f[plate] = 1.0
col_f[seam] = BLACK_STEEL * 0.6; rough_f[seam] = 0.6; metal_f[seam] = 1.0
col_f[gold_f] = (GOLD * (1 + noise(6, 0.05))[..., None])[gold_f]; rough_f[gold_f] = 0.28; metal_f[gold_f] = 1.0

# back paint ------------------------------------------------------------------------------------------------------------
inside_b = ~np.isnan(back)
# the back plate is curved: fit a quadratic surface to it (refit without the grips), depth = how far the grips stand off
yy, zz = np.mgrid[0:G, 0:G][::-1]
A = np.stack([np.ones(G * G), yy.ravel(), zz.ravel(), yy.ravel() ** 2, zz.ravel() ** 2, (yy * zz).ravel()], 1).astype(float)
fit = inside_b.ravel().copy()
for _ in range(3):
    c, *_ = np.linalg.lstsq(A[fit], back.ravel()[fit], rcond=None)
    base = (A @ c).reshape(G, G)
    fit = (inside_b & (np.abs(back - base) < 0.004)).ravel()
depth = np.where(inside_b, base - back, 0)
grip = inside_b & (depth > 0.006)
sym_b = (raised(back, -1) > SYMBOL_H) & inside_b & ~grip
grip_core = grip & (depth > 0.03)                       # the bars; the shallower ends are the gilded caps
gold_b = (inside_b & (edge < RIM_W)) | sym_b | (grip & ~grip_core)
col_b = np.empty((G, G, 3), np.float32); rough_b = np.empty((G, G)); metal_b = np.empty((G, G))
col_b[:] = BLACK_STEEL * (1 + brush + noise(20, 0.05))[..., None]; rough_b[:] = 0.55; metal_b[:] = 1.0
col_b[grip_core] = (LEATHER * (1 + noise(1.5, 0.12))[..., None])[grip_core]; rough_b[grip_core] = 0.75; metal_b[grip_core] = 0.0
col_b[gold_b] = GOLD; rough_b[gold_b] = 0.3; metal_b[gold_b] = 1.0
print('front: symbols %.3f rim %.3f plate %.3f of the face; back: grips %.3f symbols %.3f' % (
    sym_f.sum() / inside.sum(), rim.sum() / inside.sum(), plate.sum() / inside.sum(), grip.sum() / inside_b.sum(), sym_b.sum() / inside_b.sum()))

# bake into the v2 UV layout --------------------------------------------------------------------------------------------
vv, uu = np.mgrid[0:R, 0:R]
u = (uu + 0.5) / R; v = (vv + 0.5) / R
bc = np.zeros((R, R, 3), np.float32); mr = np.zeros((R, R, 3), np.float32); mr[..., 0] = 255
for side, (col, rough, metal) in enumerate(((col_f, rough_f, metal_f), (col_b, rough_b, metal_b))):
    sel = u <= 0.5 if side == 0 else u > 0.5
    uf = u if side == 0 else 1.0 - u
    y = ymin + (uf - 0.02) / 0.46 * ry
    z = zmax - (v - 0.02) / 0.96 * rz
    gx = np.clip(np.round((y - ymin) * s), 0, G - 1).astype(int)
    gy = np.clip(np.round((zmax - z) * s), 0, G - 1).astype(int)
    bc[sel] = col[gy[sel], gx[sel]]
    mr[..., 1][sel] = rough[gy[sel], gx[sel]] * 255
    mr[..., 2][sel] = metal[gy[sel], gx[sel]] * 255
bc = np.clip(bc, 0, 255).astype(np.uint8); mr = np.clip(mr, 0, 255).astype(np.uint8)
Image.fromarray(bc).save(OUT.replace('.glb', '_bc_preview.png'))

def png(a):
    b = io.BytesIO(); Image.fromarray(a).save(b, 'PNG'); return b.getvalue()
# all three at full size: with a 64 px normal map the compiler's atlas step emitted a 512 px colour texture
tex = {'bc': png(bc), 'nm': png(np.full((R, R, 3), (128, 128, 255), np.uint8)), 'mr': png(mr)}

blob = bytearray(); views = []; acc = []
def add(data, target=None):
    while len(blob) % 4: blob.append(0)
    off = len(blob); blob.extend(data)
    vw = {'buffer': 0, 'byteOffset': off, 'byteLength': len(data)}
    if target: vw['target'] = target
    views.append(vw); return len(views) - 1
def accessor(arr, ctype, typ, target, minmax=False):
    a = {'bufferView': add(arr.tobytes(), target), 'componentType': ctype, 'count': len(arr), 'type': typ}
    if minmax:
        a['min'] = arr.min(0).tolist(); a['max'] = arr.max(0).tolist()
    acc.append(a); return len(acc) - 1
a_pos = accessor(pos, 5126, 'VEC3', 34962, True)
a_nrm = accessor(nrm, 5126, 'VEC3', 34962)
a_uv = accessor(uv, 5126, 'VEC2', 34962)
a_idx = accessor(idx, 5125, 'SCALAR', 34963)
images = [{'bufferView': add(tex[r]), 'mimeType': 'image/png', 'name': 'heater_shield_' + r} for r in ('bc', 'nm', 'mr')]
gl = {
    'asset': {'version': '2.0', 'generator': 'QIangIQsSwordShield build_shield_glb_v4.py'},
    'scene': 0, 'scenes': [{'nodes': [0]}],
    'nodes': [{'name': 'heater_shield', 'mesh': 0}],
    'meshes': [{'name': 'heater_shield', 'primitives': [{'attributes': {'POSITION': a_pos, 'NORMAL': a_nrm, 'TEXCOORD_0': a_uv}, 'indices': a_idx, 'material': 0}]}],
    'materials': [{'name': 'heater_shield', 'pbrMetallicRoughness': {'baseColorTexture': {'index': 0}, 'metallicFactor': 1, 'roughnessFactor': 1, 'metallicRoughnessTexture': {'index': 2}}, 'normalTexture': {'index': 1}, 'doubleSided': False}],
    # repeat wrap: with clamp the compiler "canonicalized material texture domains into atlas" at 512 px
    'samplers': [{'magFilter': 9729, 'minFilter': 9987, 'wrapS': 10497, 'wrapT': 10497}],
    'images': images,
    'textures': [{'sampler': 0, 'source': i} for i in range(3)],
    'accessors': acc, 'bufferViews': views, 'buffers': [{'byteLength': 0}],
}
while len(blob) % 4: blob.append(0)
gl['buffers'][0]['byteLength'] = len(blob)
j = json.dumps(gl, separators=(',', ':')).encode()
while len(j) % 4: j += b' '
with open(OUT, 'wb') as fh:
    fh.write(struct.pack('<III', 0x46546C67, 2, 12 + 8 + len(j) + 8 + len(blob)))
    fh.write(struct.pack('<II', len(j), 0x4E4F534A)); fh.write(j)
    fh.write(struct.pack('<II', len(blob), 0x004E4942)); fh.write(blob)
print(OUT, len(pos), 'verts', len(idx) // 3, 'tris')
