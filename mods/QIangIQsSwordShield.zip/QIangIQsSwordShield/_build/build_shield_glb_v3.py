# Builds heater_shield.glb v3 (0.6.3, user 2026-10-26: "texture the shield"). Geometry and planar UV layout are v2's
# (build_shield_glb.py: front faces left half, back faces right half, mirrored). The base colour is no longer painted:
# it is baked from the retail Arbites shield (content/weapons/player/shields/assault_shield/attachments/assault_shield_01)
# by an orthographic projection along x: each heater texel's (y, z) is stretched from the heater's bounds onto the
# retail shield's, the outermost retail triangle facing the same way is found there, and its own albedo is sampled at
# the interpolated UV. Retail data from the QIangIQsMapViewer pipeline (unit.load_unit, material.resolved,
# texture.load_texture; A:\Dowloads\staging\swordshield\probe9.py / probe10.py): mesh 1 batches 0/1/5 (materials
# 0x370439bb.., 0x9f84c2a2.., 0xe72f54d4.. keys), albedo channel 0x6f515750 (2048, grey gunmetal + Arbites emblem).
# Normal map stays flat (tangent conventions differ between the two models).
import io, json, struct, sys
import numpy as np
from PIL import Image

sys.path.insert(0, r'A:\Dowloads\QIangIQsMapViewer\pipeline')
import dtfmt, unit as UN, material as MA, texture as TX

SRC = r'A:\Dowloads\Darktide_NonMod\dauntless_datamine\05_weapon_sword_and_shield\26b996dc3fdb55ff\26b996dc3fdb55ff.obj'
OUT = sys.argv[1] if len(sys.argv) > 1 else 'heater_shield.glb'
OFFSET = (0.072, 0.014, 0.002)
R = 2048            # baked texture size
G = 1024            # projection grid
ALBEDO = 0x6f515750

# heater geometry + v2 UVs ---------------------------------------------------------------------------------------------
V, VN, F = [], [], []
for line in open(SRC):
    if line.startswith('v '):
        V.append(tuple(map(float, line.split()[1:4])))
    elif line.startswith('vn '):
        VN.append(tuple(map(float, line.split()[1:4])))
    elif line.startswith('f '):
        F.append([tuple(int(x) - 1 if x else -1 for x in p.split('/')) for p in line.split()[1:]])
Va = np.array(V)
ymin, ymax = Va[:, 1].min(), Va[:, 1].max()
zmin, zmax = Va[:, 2].min(), Va[:, 2].max()
ry, rz = ymax - ymin, zmax - zmin

def uv_of(y, z, side):
    u = 0.02 + 0.46 * (y - ymin) / ry
    if side == 1:
        u = 1.0 - u
    return u, 0.02 + 0.96 * (zmax - z) / rz

key_to_idx = {}; pos = []; nrm = []; uv = []; idx = []
for f in F:
    fn = np.mean([VN[n] for _, _, n in f], 0)
    side = 0 if fn[0] >= 0 else 1
    tri = []
    for v, _, n in f:
        k = (v, n, side)
        x, y, z = V[v]
        if k not in key_to_idx:
            key_to_idx[k] = len(pos)
            pos.append((x + OFFSET[0], z + OFFSET[2], -(y + OFFSET[1])))
            nx, ny, nz = VN[n]; nrm.append((nx, nz, -ny))
            uv.append(uv_of(y, z, side))
        tri.append(key_to_idx[k])
    for i in range(1, len(tri) - 1):
        idx += [tri[0], tri[i], tri[i + 1]]
pos = np.array(pos, np.float32); nrm = np.array(nrm, np.float32); uv = np.array(uv, np.float32); idx = np.array(idx, np.uint32)

# retail shield: triangles, UVs, albedo per batch ----------------------------------------------------------------------
U = UN.load_unit(dtfmt.murmur64('content/weapons/player/shields/assault_shield/attachments/assault_shield_01/assault_shield_01'))
m = U['meshes'][1]; d = m['data']
W = np.array(m['world'])
P = (np.c_[np.asarray(d['pos'], float), np.ones(len(d['pos']))] @ W.T)[:, :3]
UV = np.asarray(d['uv0'], float)
I = np.asarray(d['indices']).reshape(-1, 3)
albedo = {}
tri_tex = np.full(len(I), -1)
for bi, (mi, start, count, _) in enumerate(d['batches']):
    mat = U['materials'].get(d['mats'][mi]) if isinstance(U['materials'], dict) else None
    res = MA.resolved(mat) if mat else None
    th = res and res['textures'].get(ALBEDO)
    if not th:
        print('batch', bi, 'no albedo, skipped'); continue
    if th not in albedo:
        img, info = TX.load_texture(th, 2048)
        albedo[th] = np.asarray(img)[..., :3].astype(np.float32)
        print('albedo', hex(th), info['w'], info['h'])
    tri_tex[start:start + count] = list(albedo).index(th)
tex_list = list(albedo.values())
rp = P[I.ravel()].reshape(-1, 3, 3)
rmin, rmax = P.min(0), P.max(0)
print('retail bounds', rmin.round(3), rmax.round(3))

# orthographic projection grids along x: front keeps the largest x, back the smallest
def project(side):
    tid = np.full((G, G), -1, np.int64); depth = np.full((G, G), -np.inf if side == 0 else np.inf)
    bary = np.zeros((G, G, 3), np.float32)
    n = np.cross(rp[:, 1] - rp[:, 0], rp[:, 2] - rp[:, 0])
    for t in np.nonzero((tri_tex >= 0) & ((n[:, 0] > 1e-9) if side == 0 else (n[:, 0] < -1e-9)))[0]:
        a, b, c = rp[t]
        gy = (np.array([a[1], b[1], c[1]]) - rmin[1]) / (rmax[1] - rmin[1]) * (G - 1)
        gz = (rmax[2] - np.array([a[2], b[2], c[2]])) / (rmax[2] - rmin[2]) * (G - 1)
        x0, x1 = int(np.floor(gy.min())), int(np.ceil(gy.max())); y0, y1 = int(np.floor(gz.min())), int(np.ceil(gz.max()))
        if x1 < 0 or y1 < 0 or x0 >= G or y0 >= G:
            continue
        xs, ys = np.meshgrid(np.arange(max(x0, 0), min(x1, G - 1) + 1), np.arange(max(y0, 0), min(y1, G - 1) + 1))
        den = (gz[1] - gz[2]) * (gy[0] - gy[2]) + (gy[2] - gy[1]) * (gz[0] - gz[2])
        if abs(den) < 1e-12:
            continue
        w0 = ((gz[1] - gz[2]) * (xs - gy[2]) + (gy[2] - gy[1]) * (ys - gz[2])) / den
        w1 = ((gz[2] - gz[0]) * (xs - gy[2]) + (gy[0] - gy[2]) * (ys - gz[2])) / den
        w2 = 1 - w0 - w1
        inside = (w0 >= -1e-4) & (w1 >= -1e-4) & (w2 >= -1e-4)
        if not inside.any():
            continue
        dx = w0 * a[0] + w1 * b[0] + w2 * c[0]
        xi, yi = xs[inside], ys[inside]; dd = dx[inside]
        better = dd > depth[yi, xi] if side == 0 else dd < depth[yi, xi]
        xi, yi, dd = xi[better], yi[better], dd[better]
        depth[yi, xi] = dd; tid[yi, xi] = t
        bary[yi, xi] = np.stack([w0[inside][better], w1[inside][better], w2[inside][better]], -1)
    print('side', side, 'covered', (tid >= 0).mean().round(3))
    return tid, bary

grids = [project(0), project(1)]

def fill(tid, bary):
    # holes take the nearest covered cell
    from scipy.ndimage import distance_transform_edt
    miss = tid < 0
    _, (iy, ix) = distance_transform_edt(miss, return_indices=True)
    return tid[iy, ix], bary[iy, ix]
grids = [fill(*g) for g in grids]

# bake: heater texel -> heater (y, z) -> stretched to retail -> grid cell -> retail UV -> albedo -----------------------
vv, uu = np.mgrid[0:R, 0:R]
u = (uu + 0.5) / R; v = (vv + 0.5) / R
bc = np.zeros((R, R, 3), np.float32)
for side in (0, 1):
    uf = u if side == 0 else 1.0 - u
    sel = (uf >= 0.0) & (uf <= 0.5)
    if side == 1:
        sel = u > 0.5
    else:
        sel = u <= 0.5
    y = ymin + (uf - 0.02) / 0.46 * ry
    z = zmax - (v - 0.02) / 0.96 * rz
    yr = rmin[1] + (y - ymin) / ry * (rmax[1] - rmin[1])
    zr = rmin[2] + (z - zmin) / rz * (rmax[2] - rmin[2])
    gx = np.clip(np.round((yr - rmin[1]) / (rmax[1] - rmin[1]) * (G - 1)), 0, G - 1).astype(int)
    gy = np.clip(np.round((rmax[2] - zr) / (rmax[2] - rmin[2]) * (G - 1)), 0, G - 1).astype(int)
    tid, bary = grids[side]
    t = tid[gy[sel], gx[sel]]; w = bary[gy[sel], gx[sel]]
    tuv = (UV[I[t, 0]] * w[:, :1] + UV[I[t, 1]] * w[:, 1:2] + UV[I[t, 2]] * w[:, 2:3])
    out = np.zeros((len(t), 3), np.float32)
    for k, img in enumerate(tex_list):
        mk = tri_tex[t] == k
        h, wd = img.shape[:2]
        px = np.clip((tuv[mk, 0] % 1.0) * wd, 0, wd - 1).astype(int)
        py = np.clip((tuv[mk, 1] % 1.0) * h, 0, h - 1).astype(int)
        out[mk] = img[py, px]
    bc[sel] = out
bc = np.clip(bc, 0, 255).astype(np.uint8)
Image.fromarray(bc).save(OUT.replace('.glb', '_bc_preview.png'))
mr = np.stack([np.full((R, R), 255), np.full((R, R), 140), np.full((R, R), 210)], -1).astype(np.uint8)

def png(a):
    b = io.BytesIO(); Image.fromarray(a).save(b, 'PNG'); return b.getvalue()
# all three at full size: with a 64 px normal map the compiler's atlas step emitted a 512 px colour texture
tex = {'bc': png(bc), 'nm': png(np.full((R, R, 3), (128, 128, 255), np.uint8)), 'mr': png(mr)}

blob = bytearray(); views = []; acc = []
def add(data, target=None):
    while len(blob) % 4: blob.append(0)
    off = len(blob); blob.extend(data)
    vw = {'buffer': 0, 'byteOffset': off, 'byteLength': len(data)}
    if target: vw['target'] = target
    views.append(vw); return len(views) - 1
def accessor(arr, ctype, typ, target, minmax=False):
    a = {'bufferView': add(arr.tobytes(), target), 'componentType': ctype, 'count': len(arr), 'type': typ}
    if minmax:
        a['min'] = arr.min(0).tolist(); a['max'] = arr.max(0).tolist()
    acc.append(a); return len(acc) - 1
a_pos = accessor(pos, 5126, 'VEC3', 34962, True)
a_nrm = accessor(nrm, 5126, 'VEC3', 34962)
a_uv = accessor(uv, 5126, 'VEC2', 34962)
a_idx = accessor(idx, 5125, 'SCALAR', 34963)
images = [{'bufferView': add(tex[r]), 'mimeType': 'image/png', 'name': 'heater_shield_' + r} for r in ('bc', 'nm', 'mr')]
gl = {
    'asset': {'version': '2.0', 'generator': 'QIangIQsSwordShield build_shield_glb_v3.py'},
    'scene': 0, 'scenes': [{'nodes': [0]}],
    'nodes': [{'name': 'heater_shield', 'mesh': 0}],
    'meshes': [{'name': 'heater_shield', 'primitives': [{'attributes': {'POSITION': a_pos, 'NORMAL': a_nrm, 'TEXCOORD_0': a_uv}, 'indices': a_idx, 'material': 0}]}],
    'materials': [{'name': 'heater_shield', 'pbrMetallicRoughness': {'baseColorTexture': {'index': 0}, 'metallicFactor': 1, 'roughnessFactor': 1, 'metallicRoughnessTexture': {'index': 2}}, 'normalTexture': {'index': 1}, 'doubleSided': False}],
    # repeat wrap: with clamp the compiler "canonicalized material texture domains into atlas" at 512 px
    'samplers': [{'magFilter': 9729, 'minFilter': 9987, 'wrapS': 10497, 'wrapT': 10497}],
    'images': images,
    'textures': [{'sampler': 0, 'source': i} for i in range(3)],
    'accessors': acc, 'bufferViews': views, 'buffers': [{'byteLength': 0}],
}
while len(blob) % 4: blob.append(0)
gl['buffers'][0]['byteLength'] = len(blob)
j = json.dumps(gl, separators=(',', ':')).encode()
while len(j) % 4: j += b' '
with open(OUT, 'wb') as fh:
    fh.write(struct.pack('<III', 0x46546C67, 2, 12 + 8 + len(j) + 8 + len(blob)))
    fh.write(struct.pack('<II', len(j), 0x4E4F534A)); fh.write(j)
    fh.write(struct.pack('<II', len(blob), 0x004E4942)); fh.write(blob)
print(OUT, len(pos), 'verts', len(idx) // 3, 'tris')
