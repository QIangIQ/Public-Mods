# Draws assets/swordshield_hud.png: white silhouette on transparent (the HUD tints it), 512x192 for the 256x96
# weapon icon box (hud_element_player_weapon_handler_settings.lua weapon_icon_size). Heater shield left, sword pointing
# right; the shield's cross is cut out and a transparent gap separates shield and sword.
import os, sys
from PIL import Image, ImageDraw, ImageChops

S = 4
W, H = 512 * S, 192 * S
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), '..', 'assets', 'swordshield_hud.png')

def p(*pts):
    return [(x * S, y * S) for x, y in pts]

sword = Image.new('L', (W, H), 0); d = ImageDraw.Draw(sword)
d.polygon(p((150, 86), (470, 86), (500, 96), (470, 106), (150, 106)), fill=255)    # blade + point
d.rectangle(p((132, 58), (148, 134)), fill=255)                                     # crossguard
d.rectangle(p((80, 89), (132, 103)), fill=255)                                      # grip
d.ellipse(p((62, 84), (86, 108)), fill=255)                                         # pommel
fuller = Image.new('L', (W, H), 0); ImageDraw.Draw(fuller).rectangle(p((160, 94), (430, 98)), fill=255)
sword = ImageChops.subtract(sword, fuller)

def heater(x0, y0, x1, y1):
    m = Image.new('L', (W, H), 0); dd = ImageDraw.Draw(m)
    mx = (x0 + x1) / 2
    pts = [(x0, y0), (x1, y0), (x1, y0 + (y1 - y0) * 0.45)]
    for i in range(1, 17):                                                          # curved sides to the point
        t = i / 16
        pts.append((x1 - (x1 - mx) * t ** 1.6, y0 + (y1 - y0) * (0.45 + 0.55 * t)))
    for i in range(15, 0, -1):
        t = i / 16
        pts.append((x0 + (mx - x0) * t ** 1.6, y0 + (y1 - y0) * (0.45 + 0.55 * t)))
    pts.append((x0, y0 + (y1 - y0) * 0.45))
    dd.polygon(p(*pts), fill=255)
    return m

shield = heater(150, 8, 290, 186)
gap = heater(142, 2, 298, 192)
cross = Image.new('L', (W, H), 0); dc = ImageDraw.Draw(cross)
dc.rectangle(p((214, 36), (226, 140)), fill=255)
dc.rectangle(p((186, 64), (254, 76)), fill=255)
rim = ImageChops.subtract(shield, heater(160, 18, 280, 172))
inner = ImageChops.subtract(heater(166, 24, 274, 164), cross)
shield = ImageChops.add(rim, inner)

alpha = ImageChops.add(ImageChops.subtract(sword, gap), shield)
alpha = alpha.resize((512, 192), Image.LANCZOS)
img = Image.new('RGBA', (512, 192), (255, 255, 255, 0)); img.putalpha(alpha)
os.makedirs(os.path.dirname(os.path.abspath(OUT)), exist_ok=True)
img.save(OUT)
print(OUT)
