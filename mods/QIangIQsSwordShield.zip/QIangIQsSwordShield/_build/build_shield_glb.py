# Builds heater_shield.glb (v2) from the datamined, unnamed heater shield unit 26b996dc3fdb55ff (dauntless_datamine
# 05_weapon_sword_and_shield). The unit ships no textures and its OBJ has no usable UVs (every vt is 0,1; uvcheck.py),
# so v2 makes planar UVs (front faces left half, back faces right half) and paints a texture here. The paint scheme
# (red enamel field, gold rim, gold cross) is extrapolated, no source texture exists.
# Placement: the heater is authored in the retail assault_shield_01 frame. Handle centroid retail -0.078, 0.200, 0.003,
# heater -0.090, 0.186, 0.001 (probe4.py) -> y/z offset. x is pushed +0.060 further out than the handle match because the
# heater plate stops at x 0.049 where the retail plate reaches 0.145, so the forearm poked through (user test 2026-10-25).
# Writer = QIangIQsDauntlessArmory _build/build_glb.py (Stingray Z-up -> glTF Y-up, OBJ v flipped).
import io, json, struct, sys
import numpy as np
from PIL import Image, ImageDraw

SRC = r'A:\Dowloads\Darktide_NonMod\dauntless_datamine\05_weapon_sword_and_shield\26b996dc3fdb55ff\26b996dc3fdb55ff.obj'
OUT = sys.argv[1] if len(sys.argv) > 1 else 'heater_shield.glb'
OFFSET = (0.072, 0.014, 0.002)
R = 1024

V, VN, F = [], [], []
for line in open(SRC):
    if line.startswith('v '):
        V.append(tuple(map(float, line.split()[1:4])))
    elif line.startswith('vn '):
        VN.append(tuple(map(float, line.split()[1:4])))
    elif line.startswith('f '):
        F.append([tuple(int(x) - 1 if x else -1 for x in p.split('/')) for p in line.split()[1:]])
Va = np.array(V)
ymin, ymax = Va[:, 1].min(), Va[:, 1].max()
zmin, zmax = Va[:, 2].min(), Va[:, 2].max()
ry, rz = ymax - ymin, zmax - zmin

def uv_of(y, z, side):
    u = 0.02 + 0.46 * (y - ymin) / ry
    if side == 1:
        u = 1.0 - u                       # back half, mirrored so it lines up with the front
    return u, 0.02 + 0.96 * (zmax - z) / rz

key_to_idx = {}; pos = []; nrm = []; uv = []; idx = []; tris_uv = {0: [], 1: []}
for f in F:
    fn = np.mean([VN[n] for _, _, n in f], 0)
    side = 0 if fn[0] >= 0 else 1            # +x = outer face
    tri = []; puv = []
    for v, _, n in f:
        k = (v, n, side)
        x, y, z = V[v]
        if k not in key_to_idx:
            key_to_idx[k] = len(pos)
            pos.append((x + OFFSET[0], z + OFFSET[2], -(y + OFFSET[1])))
            nx, ny, nz = VN[n]; nrm.append((nx, nz, -ny))
            uv.append(uv_of(y, z, side))
        tri.append(key_to_idx[k]); puv.append(uv_of(y, z, side))
    tris_uv[side].append(puv)
    for i in range(1, len(tri) - 1):
        idx += [tri[0], tri[i], tri[i + 1]]
pos = np.array(pos, np.float32); nrm = np.array(nrm, np.float32); uv = np.array(uv, np.float32); idx = np.array(idx, np.uint32)

def mask_of(polys):
    m = Image.new('L', (R, R), 0); d = ImageDraw.Draw(m)
    for p in polys:
        d.polygon([(u * R, v * R) for u, v in p], fill=255)
    return np.array(m) > 0
front = mask_of(tris_uv[0]); back = mask_of(tris_uv[1])

def erode(m, n):
    for _ in range(n):
        m = m & np.roll(m, 1, 0) & np.roll(m, -1, 0) & np.roll(m, 1, 1) & np.roll(m, -1, 1)
    return m
rim_px = max(3, int(0.028 / ry * 0.46 * R))
inner = erode(front, rim_px)
rim = front & ~inner

GOLD = np.array((176, 136, 62)); RED = np.array((118, 16, 18)); STEEL = np.array((72, 72, 78))
bc = np.zeros((R, R, 3)); bc[:] = STEEL
bc[front] = GOLD; bc[inner] = RED
# gold cross centred on the field, 62% up the shield
cu = 0.02 + 0.23; cv = 0.02 + 0.96 * 0.38
yy, xx = np.mgrid[0:R, 0:R] / R
arm = 0.016; hl = 0.20; hw = 0.10
cross = (((abs(xx - cu) < arm) & (abs(yy - cv) < hl)) | ((abs(yy - (cv - 0.05)) < arm * 0.96 / 0.46 * 0.5) & (abs(xx - cu) < hw))) & inner
bc[cross] = GOLD
rng = np.random.default_rng(7)
noise = rng.normal(0, 1, (R // 8, R // 8))
noise = np.array(Image.fromarray(((noise - noise.min()) / np.ptp(noise) * 255).astype(np.uint8)).resize((R, R), Image.BICUBIC)) / 255.0
bc *= (0.80 + 0.25 * noise)[..., None]
bc = np.clip(bc, 0, 255).astype(np.uint8)

metal = np.where(rim | cross | ~front, 255, 0)           # gold + steel metallic, enamel not
rough = np.where(rim | cross, 90, np.where(front, 150, 120)) + (noise * 40).astype(int)
mr = np.stack([np.full((R, R), 255), np.clip(rough, 0, 255), metal], -1).astype(np.uint8)

def png(a):
    b = io.BytesIO(); Image.fromarray(a).save(b, 'PNG'); return b.getvalue()
Image.fromarray(bc).save(OUT.replace('.glb', '_bc_preview.png'))
tex = {'bc': png(bc), 'nm': png(np.full((64, 64, 3), (128, 128, 255), np.uint8)), 'mr': png(mr)}

blob = bytearray(); views = []; acc = []
def add(data, target=None):
    while len(blob) % 4: blob.append(0)
    off = len(blob); blob.extend(data)
    v = {'buffer': 0, 'byteOffset': off, 'byteLength': len(data)}
    if target: v['target'] = target
    views.append(v); return len(views) - 1
def accessor(arr, ctype, typ, target, minmax=False):
    a = {'bufferView': add(arr.tobytes(), target), 'componentType': ctype, 'count': len(arr), 'type': typ}
    if minmax:
        a['min'] = arr.min(0).tolist(); a['max'] = arr.max(0).tolist()
    acc.append(a); return len(acc) - 1
a_pos = accessor(pos, 5126, 'VEC3', 34962, True)
a_nrm = accessor(nrm, 5126, 'VEC3', 34962)
a_uv = accessor(uv, 5126, 'VEC2', 34962)
a_idx = accessor(idx, 5125, 'SCALAR', 34963)
images = [{'bufferView': add(tex[r]), 'mimeType': 'image/png', 'name': 'heater_shield_' + r} for r in ('bc', 'nm', 'mr')]
gl = {
    'asset': {'version': '2.0', 'generator': 'QIangIQsSwordShield build_shield_glb.py v2'},
    'scene': 0, 'scenes': [{'nodes': [0]}],
    'nodes': [{'name': 'heater_shield', 'mesh': 0}],
    'meshes': [{'name': 'heater_shield', 'primitives': [{'attributes': {'POSITION': a_pos, 'NORMAL': a_nrm, 'TEXCOORD_0': a_uv}, 'indices': a_idx, 'material': 0}]}],
    'materials': [{'name': 'heater_shield', 'pbrMetallicRoughness': {'baseColorTexture': {'index': 0}, 'metallicFactor': 1, 'roughnessFactor': 1, 'metallicRoughnessTexture': {'index': 2}}, 'normalTexture': {'index': 1}, 'doubleSided': False}],
    'samplers': [{'magFilter': 9729, 'minFilter': 9987, 'wrapS': 33071, 'wrapT': 33071}],
    'images': images,
    'textures': [{'sampler': 0, 'source': i} for i in range(3)],
    'accessors': acc, 'bufferViews': views, 'buffers': [{'byteLength': 0}],
}
while len(blob) % 4: blob.append(0)
gl['buffers'][0]['byteLength'] = len(blob)
j = json.dumps(gl, separators=(',', ':')).encode()
while len(j) % 4: j += b' '
with open(OUT, 'wb') as fh:
    fh.write(struct.pack('<III', 0x46546C67, 2, 12 + 8 + len(j) + 8 + len(blob)))
    fh.write(struct.pack('<II', len(j), 0x4E4F534A)); fh.write(j)
    fh.write(struct.pack('<II', len(blob), 0x004E4942)); fh.write(blob)
print(OUT, len(pos), 'verts', len(idx) // 3, 'tris', 'front px', front.sum(), 'back px', back.sum(), 'rim', rim_px, 'bounds', pos.min(0), pos.max(0))
