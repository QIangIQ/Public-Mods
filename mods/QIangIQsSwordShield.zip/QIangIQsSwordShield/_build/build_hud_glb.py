# Wraps assets/swordshield_hud.png in a one-quad GLB (alphaMode BLEND) so DarktideGLBCompiler emits it as a TEXTURE
# resource inside the mod's own Custom Assets build: content/mods/qiangiq_swordshield/hud_icon_material_1_bc.
# The quad is never spawned; loading the package only makes the texture resource available to the HUD.
import json, os, struct, sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
PNG = os.path.join(HERE, '..', 'assets', 'swordshield_hud.png')
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, 'hud_icon.glb')

pos = np.array([[0, 0, 0], [0.256, 0, 0], [0.256, 0.096, 0], [0, 0.096, 0]], np.float32)
nrm = np.array([[0, 0, 1]] * 4, np.float32)
uv = np.array([[0, 1], [1, 1], [1, 0], [0, 0]], np.float32)
idx = np.array([0, 1, 2, 0, 2, 3], np.uint32)
png = open(PNG, 'rb').read()

blob = bytearray(); views = []; acc = []
def add(data, target=None):
    while len(blob) % 4: blob.append(0)
    off = len(blob); blob.extend(data)
    v = {'buffer': 0, 'byteOffset': off, 'byteLength': len(data)}
    if target: v['target'] = target
    views.append(v); return len(views) - 1
def accessor(arr, ctype, typ, target, minmax=False):
    a = {'bufferView': add(arr.tobytes(), target), 'componentType': ctype, 'count': len(arr), 'type': typ}
    if minmax:
        a['min'] = arr.min(0).tolist(); a['max'] = arr.max(0).tolist()
    acc.append(a); return len(acc) - 1
a_pos = accessor(pos, 5126, 'VEC3', 34962, True)
a_nrm = accessor(nrm, 5126, 'VEC3', 34962)
a_uv = accessor(uv, 5126, 'VEC2', 34962)
a_idx = accessor(idx, 5125, 'SCALAR', 34963)
img = add(png)
gl = {
    'asset': {'version': '2.0', 'generator': 'QIangIQsSwordShield build_hud_glb.py'},
    'scene': 0, 'scenes': [{'nodes': [0]}],
    'nodes': [{'name': 'hud_icon', 'mesh': 0}],
    'meshes': [{'name': 'hud_icon', 'primitives': [{'attributes': {'POSITION': a_pos, 'NORMAL': a_nrm, 'TEXCOORD_0': a_uv}, 'indices': a_idx, 'material': 0}]}],
    'materials': [{'name': 'hud_icon', 'alphaMode': 'BLEND', 'pbrMetallicRoughness': {'baseColorTexture': {'index': 0}, 'metallicFactor': 0, 'roughnessFactor': 1}}],
    'samplers': [{'magFilter': 9729, 'minFilter': 9987, 'wrapS': 33071, 'wrapT': 33071}],
    'images': [{'bufferView': img, 'mimeType': 'image/png', 'name': 'hud_icon_bc'}],
    'textures': [{'sampler': 0, 'source': 0}],
    'accessors': acc, 'bufferViews': views, 'buffers': [{'byteLength': 0}],
}
while len(blob) % 4: blob.append(0)
gl['buffers'][0]['byteLength'] = len(blob)
j = json.dumps(gl, separators=(',', ':')).encode()
while len(j) % 4: j += b' '
with open(OUT, 'wb') as fh:
    fh.write(struct.pack('<III', 0x46546C67, 2, 12 + 8 + len(j) + 8 + len(blob)))
    fh.write(struct.pack('<II', len(j), 0x4E4F534A)); fh.write(j)
    fh.write(struct.pack('<II', len(blob), 0x004E4942)); fh.write(blob)
print(OUT)
