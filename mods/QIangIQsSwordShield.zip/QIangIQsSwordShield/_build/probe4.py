import sys, numpy as np
sys.path.insert(0, r'A:\Dowloads\QIangIQsMapViewer\pipeline')
import dtfmt, unit as UN
U = UN.load_unit(dtfmt.murmur64('content/weapons/player/shields/assault_shield/attachments/assault_shield_01/assault_shield_01'))
def rep(name, p):
    p = np.asarray(p, float)
    print('==', name, len(p), 'min', p.min(0).round(3), 'max', p.max(0).round(3))
    h, e = np.histogram(p[:,0], 12)
    print(' x hist', h.tolist(), e.round(3).tolist())
    for lo, hi in [(e[0], e[2]), (e[-3], e[-1])]:
        q = p[(p[:,0] >= lo) & (p[:,0] <= hi)]
        print('  x in [%.3f,%.3f]: n=%d centroid %s min %s max %s' % (lo, hi, len(q), q.mean(0).round(3), q.min(0).round(3), q.max(0).round(3)))
for i, m in enumerate(U['meshes']):
    w = np.array(m['world']); p = m['data']['pos']
    q = (np.c_[p, np.ones(len(p))] @ w.T)[:, :3]
    rep('retail mesh %d' % i, q)
v = [tuple(map(float, l.split()[1:4])) for l in open(r'A:\Dowloads\Darktide_NonMod\dauntless_datamine\05_weapon_sword_and_shield\26b996dc3fdb55ff\26b996dc3fdb55ff.obj') if l.startswith('v ')]
rep('heater', v)
