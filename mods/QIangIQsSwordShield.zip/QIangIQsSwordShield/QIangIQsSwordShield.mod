return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsSwordShield` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsSwordShield", {
            mod_script = "QIangIQsSwordShield/scripts/mods/QIangIQsSwordShield/QIangIQsSwordShield",
            mod_data = "QIangIQsSwordShield/scripts/mods/QIangIQsSwordShield/QIangIQsSwordShield_data",
            mod_localization = "QIangIQsSwordShield/scripts/mods/QIangIQsSwordShield/QIangIQsSwordShield_localization",
        })
    end,
    version = "0.3.0",
    author = "QIangIQ",
    packages = {},
}
