local mod = get_mod("QIangIQsShardStaff")

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = true,
    options = {
        widgets = {
            { setting_id = "passive_enabled", type = "checkbox", default_value = true },
            { setting_id = "elites_only", type = "checkbox", default_value = true },
            { setting_id = "swarm_enabled", type = "checkbox", default_value = true },
            { setting_id = "float_when_stowed", type = "checkbox", default_value = true },
            { setting_id = "sounds_enabled", type = "checkbox", default_value = true },
            {
                setting_id = "group_balance",
                type = "group",
                sub_widgets = {
                    { setting_id = "heavy_damage", type = "numeric", default_value = 1500, range = { 100, 6000 }, decimals_number = 0 },
                    { setting_id = "heavy_cooldown", type = "numeric", default_value = 2.6, range = { 0.5, 15 }, decimals_number = 1 },
                    { setting_id = "dart_damage", type = "numeric", default_value = 450, range = { 50, 3000 }, decimals_number = 0 },
                    { setting_id = "dart_cooldown", type = "numeric", default_value = 1.4, range = { 0.2, 10 }, decimals_number = 1 },
                    { setting_id = "swarm_damage", type = "numeric", default_value = 90, range = { 10, 800 }, decimals_number = 0 },
                    { setting_id = "swarm_radius", type = "numeric", default_value = 1.3, range = { 0.5, 4 }, decimals_number = 1 },
                    { setting_id = "swarm_duration", type = "numeric", default_value = 3.5, range = { 1, 10 }, decimals_number = 1 },
                    { setting_id = "swarm_cooldown", type = "numeric", default_value = 4, range = { 0, 20 }, decimals_number = 1 },
                },
            },
            {
                setting_id = "group_fit",
                type = "group",
                sub_widgets = {
                    { setting_id = "staff_scale", type = "numeric", default_value = 1, range = { 0.3, 3 }, decimals_number = 2 },
                    { setting_id = "staff_grip", type = "numeric", default_value = 0, range = { -0.5, 0.5 }, decimals_number = 2 },
                    { setting_id = "staff_roll", type = "numeric", default_value = 0, range = { -180, 180 }, decimals_number = 0 },
                    { setting_id = "staff_tilt", type = "numeric", default_value = 0, range = { -90, 90 }, decimals_number = 0 },
                    { setting_id = "staff_flip", type = "checkbox", default_value = true },
                },
            },
        },
    },
}
