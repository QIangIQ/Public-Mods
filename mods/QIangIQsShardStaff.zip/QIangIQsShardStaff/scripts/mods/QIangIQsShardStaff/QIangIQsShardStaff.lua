-- QIangIQ's Shard Staff: SPIKE 0.0.1. Question: can a brand-new weapon (own template + own master item) exist
-- next to the stock ones, instead of overlaying one? This file only probes that; there is no model or new behaviour.
--
-- Every call below is taken from the Darktide source or an installed mod:
--   * WeaponTemplates is the table built in scripts/settings/equipment/weapon_templates/weapon_templates.lua
--     (template_data.name = template_name; weapon_templates[name] = template).
--   * Item definitions are injected into the master item cache the way extended_weapon_customization/.../kitbash.lua:153
--     does it: master_items.get_cached()[name] = item.
--   * Equip without the backend: scripts/extension_systems/training_grounds/training_grounds_steps.lua:341-347
--     (_equip_item) = Managers.profile_synchronization:synchronizer_host():override_slot(peer_id, local_player_id,
--     slot_name, item_name); implementation in scripts/loading/profile_synchronizer_host.lua:270.
--   * Item path style: scripts/settings/training_grounds/training_grounds_item_names.lua.
-- Author: QIangIQ
local mod = get_mod("QIangIQsShardStaff")

local WeaponTemplates = require("scripts/settings/equipment/weapon_templates/weapon_templates")
local MasterItems = require("scripts/backend/master_items")

local SOURCE_TEMPLATE = "forcestaff_p4_m1"      -- Voidstrike (note: weapons/00 and Enhanced_descriptions)
-- Hub crash (Nexus report 2026-10-17, "hub_aim_constraints.lua: State machine has no constraint target named
-- #ID[f8cbbdda]" = aim_constraint_target_torso): player_unit_data_component_config.lua builds the networked
-- weapon_action.template_name list from table.keys(WeaponTemplates), sorted. "shard_staff" sorted before
-- "shotgun_*" ... "unarmed_hub_human", so on a Fatshark hub server a correction decoded unarmed_hub_human as "unarmed"
-- (player_unit_animation_extension.lua server_correction_occurred -> set_anim_state_machine), whose state machine
-- has no torso aim target. The name must sort after every retail template (last retail: "zealot_relic") so it lands
-- at the end of the list and no retail index moves.
local NEW_TEMPLATE = "zz_qiangiq_shard_staff"
local NEW_ITEM = "content/items/weapons/player/ranged/shard_staff"
local SOURCE_ITEM_GUESS = "content/items/weapons/player/ranged/forcestaff_p4_m1"   -- same pattern as forcestaff_p1_m1; verified at run time

local NetworkLookup = require("scripts/network_lookup/network_lookup")

-- Network ids (crash 13:03 in console log 2026-10-11-13.01.36): the equip path does
-- NetworkLookup.player_item_names[item.name] (player_unit_visual_loadout_extension.lua:679-687) and block.lua:229 does
-- NetworkLookup.weapon_templates[weapon_template.name]. Both lists are built before this mod runs
-- (network_lookup.lua:550, master_data.lua:35 create_network_lookup), and a missing key raises an error
-- (network_lookup.lua _init). New names are appended at the end so no existing id moves.
local function append_lookup(lookup_name, key)
    local lookup = NetworkLookup[lookup_name]

    if not lookup then
        return false, "no lookup"
    end

    local existing = rawget(lookup, key)

    if existing then
        return true, existing
    end

    local index = #lookup + 1

    rawset(lookup, index, key)
    rawset(lookup, key, index)

    return true, index
end

local function network_type_max(type_name)
    local ok, info = pcall(Network.type_info, type_name)

    return ok and info and info.max or nil
end

-- Alias tables (crash 23:52 in console log 2026-10-11-23.50.03): particle and sound aliases switch on
-- profile_properties.wielded_weapon_template with no_default (player_character_particle_aliases.lua "ranged_charging"
-- etc., resolved by player_character_particles.lua resolve_particle), so a new template name resolves to nothing and
-- spawn_looping_particles (player_unit_fx_extension.lua:2111) indexes NetworkLookup.player_character_particles[nil].
-- Every table that has an entry for the source template gets the same entry for the new template.
local function alias_template_keys(root, seen, counter)
    if type(root) ~= "table" or seen[root] then
        return
    end

    seen[root] = true

    local source_value = rawget(root, SOURCE_TEMPLATE)

    if source_value ~= nil and rawget(root, NEW_TEMPLATE) == nil then
        root[NEW_TEMPLATE] = source_value
        counter.n = counter.n + 1
    end

    for _, value in pairs(root) do
        if type(value) == "table" then
            alias_template_keys(value, seen, counter)
        end
    end
end

local ALIAS_MODULES = {
    "scripts/settings/particles/player_character_particle_aliases",
    "scripts/settings/sound/player_character_sound_event_aliases",
}

local function alias_new_template()
    local counter = { n = 0 }

    for _, path in ipairs(ALIAS_MODULES) do
        local ok, module = pcall(require, path)

        if ok then
            alias_template_keys(module, {}, counter)
        else
            mod:error("alias module %s: %s", path, tostring(module))
        end
    end

    return counter.n
end

local remap_inputs -- defined in the Inputs section below
local convert_heavy -- defined before the Model section

local state = {
    template_ok = false,
    item_ok = false,
    source_item_name = nil,
    slot = nil,
    previous_item_name = nil,
    next_poll = 0,
}

local function say(fmt, ...)
    local text = string.format(fmt, ...)

    mod:echo(text)
    mod:info(text)
end

-- Template ------------------------------------------------------------------------

local function ensure_template()
    if rawget(WeaponTemplates, NEW_TEMPLATE) then
        state.template_ok = true

        return true
    end

    local source = WeaponTemplates[SOURCE_TEMPLATE]

    if not source then
        return false
    end

    local clone = table.clone(source)

    clone.name = NEW_TEMPLATE

    -- weapon_templates.lua sets action_settings.name = action_name for every action; the keys are unchanged in the clone
    for action_name, action_settings in pairs(clone.actions) do
        action_settings.name = action_name
    end

    WeaponTemplates[NEW_TEMPLATE] = clone

    local ok, index = append_lookup("weapon_templates", NEW_TEMPLATE)

    state.template_lookup_index = ok and index or nil
    state.aliases_copied = alias_new_template()
    state.inputs_remapped = remap_inputs(clone)
    state.heavy_converted = convert_heavy(clone)
    state.template_ok = rawget(WeaponTemplates, NEW_TEMPLATE) ~= nil and ok

    return state.template_ok
end

-- Item ----------------------------------------------------------------------------

local function find_source_item(cache)
    local direct = rawget(cache, SOURCE_ITEM_GUESS)

    if direct and direct.weapon_template == SOURCE_TEMPLATE then
        return SOURCE_ITEM_GUESS, direct
    end

    for name, item in pairs(cache) do
        if type(item) == "table" and item.weapon_template == SOURCE_TEMPLATE then
            return name, item
        end
    end
end

local function ensure_item()
    local ok, has_data = pcall(MasterItems.has_data)

    if not ok or not has_data then
        return false
    end

    local cache = MasterItems.get_cached()

    if rawget(cache, NEW_ITEM) then
        state.item_ok = true

        return true
    end

    local source_name, source_item = find_source_item(cache)

    if not source_item then
        return false
    end

    local item = table.clone(source_item)

    item.name = NEW_ITEM
    item.weapon_template = NEW_TEMPLATE
    local ok, index = append_lookup("player_item_names", NEW_ITEM)

    if not ok then
        -- the lookup is created from the cache after master data loads: try again on the next poll
        return false
    end

    cache[NEW_ITEM] = item

    state.item_lookup_index = index
    state.source_item_name = source_name
    state.slot = item.slots and item.slots[1]
    state.item_ok = rawget(cache, NEW_ITEM) ~= nil

    return state.item_ok
end

-- Poll: the backend data arrives some time after start, and a master item refresh can drop the injected entry
local function poll_registration()
    if state.next_poll > os.clock() then
        return
    end

    state.next_poll = os.clock() + 1

    local template_before, item_before = state.template_ok, state.item_ok
    local ok_t, err_t = pcall(ensure_template)
    local ok_i, err_i = pcall(ensure_item)

    if not ok_t then
        mod:error("template: %s", tostring(err_t))
    end

    if not ok_i then
        mod:error("item: %s", tostring(err_i))
    end

    if state.template_ok and not template_before then
        say("template '%s' registered (clone of %s), %s alias entries copied", NEW_TEMPLATE, SOURCE_TEMPLATE,
            tostring(state.aliases_copied))
    end

    if state.item_ok and not item_before then
        say("item '%s' injected (clone of %s, slot %s)", NEW_ITEM, tostring(state.source_item_name), tostring(state.slot))
    end
end

-- Inputs (stage 1) --------------------------------------------------------------------
-- Voidstrike: left click = quick shot (shoot_pressed), hold right = charge, right held + left = charged shot
-- (forcestaff_p4_m1.lua:27-66, 147-180). Shard Staff: hold left = charge, release left = the charged shot
-- (pattern of lasgun_p2_m1.lua shoot_release_charged: input action_one_hold, value false, time_window = math.huge).
-- Only action NAMES are fixed by the network (player_unit_data_component_config.lua:102-126 builds the list from
-- all templates at load); input names and sequences are per template (action_input_formatter.lua), so they are free.
-- The formatter reads WeaponTemplates when a player unit is created, so this runs when the template is registered.
remap_inputs = function(template)
    local inputs = template.action_inputs

    if not (inputs and inputs.charge and inputs.charge_release and inputs.shoot_charged) then
        return false
    end

    inputs.charge.input_sequence = { { input = "action_one_hold", value = true } }
    inputs.charge_release.input_sequence = { { input = "action_one_hold", value = false, time_window = math.huge } }
    inputs.shoot_charged.input_sequence = { { input = "action_one_hold", value = false, time_window = math.huge } }

    -- left click no longer fires the quick shot
    local hierarchy = template.action_input_hierarchy

    for i = #hierarchy, 1, -1 do
        if hierarchy[i].input == "shoot_pressed" then
            table.remove(hierarchy, i)
        end
    end

    return true
end

-- The charged shot no longer spawns Voidstrike's ball: the action becomes a dummy (Riftlance's release_action does the
-- same to the surge staff's shot: kind = "dummy", the rest of the action kept so inputs and chains still resolve).
-- The heavy shard strike is started by the controller when current_action_name becomes action_shoot_charged.
convert_heavy = function(template)
    local action = template.actions and template.actions.action_shoot_charged

    if not action then
        return false
    end

    action.kind = "dummy"
    action.projectile_template = nil
    action.projectile_item = nil
    action.vfx_effect_name = nil
    action.vfx_effect_source_name = nil
    action.fire_time = nil

    return true
end

-- Model (stage 1): the Kitain Cross Spear, compiled from DMS/work/arsenal/spears/kitain_cross_spear.glb with
-- --asset-path content/mods/qiangiq_shard_staff/kitain_cross_spear (own path: QIangIQsSpearArsenal's assets are not
-- installed on this PC, and two mods must not carry the same resource, note 62). Spawn, link and fit follow
-- QIangIQsSpearArsenal 2.2 (ingame_spawn / fit / sync_record), local player only. Asset id "<Mod>:<folder>";
-- the model is authored butt y = 0, tip y = 1, flat facing local Z.
local SPEAR_ASSET = "QIangIQsShardStaff:kitain_cross_spear"
local SPEAR_UNIT = "content/mods/qiangiq_shard_staff/kitain_cross_spear"
local FIT_FRAMES = 10

local GREAT_ASSET = "QIangIQsShardStaff:crystal_greatsword"
local GREAT_UNIT = "content/mods/qiangiq_shard_staff/crystal_greatsword"
local SHARD_ASSET = "QIangIQsShardStaff:assail_shard"
local SHARD_UNIT = "content/mods/qiangiq_shard_staff/assail_shard"
local fly_loaded = { great = false, shard = false }
local model_loaded = false
local fit_generation = 0
local tracked = setmetatable({}, { __mode = "k" })

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function profile()
    return {
        scale = mod:get("staff_scale") or 1,
        grip = mod:get("staff_grip") or 0,
        roll = mod:get("staff_roll") or 0,
        tilt = mod:get("staff_tilt") or 0,
        flip = mod:get("staff_flip") == true,
    }
end

local function staff_parts(base, attachments)
    local parts = {}
    local function add(unit)
        if unit_ok(unit) then
            local pose, ext = Unit.box(unit)

            if pose and ext then
                local half = math.max(ext.x, ext.y, ext.z)

                if half > 0.005 then
                    parts[#parts + 1] = { center = Matrix4x4.translation(pose), half = half }
                end
            end
        end
    end

    add(base)

    if attachments then
        for i = 1, #attachments do
            add(attachments[i])
        end
    end

    return parts
end

local function fit(staff, base, attachments, parent_scale, p)
    local parts = staff_parts(base, attachments)

    if #parts == 0 then
        return false
    end

    local origin = Unit.world_position(base, 1)
    local far_d, far_c = 0, nil

    for i = 1, #parts do
        local d = Vector3.length_squared(parts[i].center - origin)

        if d > far_d then
            far_d, far_c = d, parts[i].center
        end
    end

    if not far_c or far_d < 0.0001 then
        return false
    end

    local dir = Vector3.normalize(far_c - origin)
    local base_rot = Unit.world_rotation(base, 1)
    local base_axes = { Quaternion.right(base_rot), Quaternion.forward(base_rot), Quaternion.up(base_rot) }
    local best, best_axis = 0, nil

    for i = 1, 3 do
        local d = Vector3.dot(base_axes[i], dir)

        if math.abs(d) > best then
            best = math.abs(d)
            best_axis = d < 0 and -base_axes[i] or base_axes[i]
        end
    end

    if best_axis and best > 0.97 then
        dir = best_axis
    end

    if p.flip then
        dir = -dir
    end

    local t_min, t_max = 0, 0

    for i = 1, #parts do
        local t = Vector3.dot(parts[i].center - origin, dir)

        t_min = math.min(t_min, t - parts[i].half)
        t_max = math.max(t_max, t + parts[i].half)
    end

    local length = t_max - t_min

    if length <= 0 then
        return false
    end

    local ls = p.scale
    local s_world = length * ls
    local ref, ref_dot = nil, nil

    for i = 1, 3 do
        local d = math.abs(Vector3.dot(base_axes[i], dir))

        if ref_dot == nil or d < ref_dot then
            ref, ref_dot = base_axes[i], d
        end
    end

    local up = Vector3.normalize(ref - dir * Vector3.dot(ref, dir))
    local roll = math.rad(p.roll)

    if roll ~= 0 then
        local side = Vector3.cross(dir, up)

        up = up * math.cos(roll) + side * math.sin(roll)
    end

    local tilt = math.rad(p.tilt)

    if tilt ~= 0 then
        local side = Vector3.cross(dir, up)

        dir = Vector3.normalize(dir * math.cos(tilt) + side * math.sin(tilt))
    end

    local butt = origin + dir * (t_min * ls - p.grip * s_world)
    local bx, by, bz = base_axes[1], base_axes[2], base_axes[3]
    local function to_local(v)
        return Vector3(Vector3.dot(v, bx), Vector3.dot(v, by), Vector3.dot(v, bz))
    end

    local k = parent_scale and parent_scale > 0 and parent_scale or 1
    local s = s_world / k

    Unit.set_local_position(staff, 1, to_local(butt - origin) * (1 / k))
    Unit.set_local_rotation(staff, 1, Quaternion.look(to_local(dir), to_local(up)))
    Unit.set_local_scale(staff, 1, Vector3(s, s, s))

    return true
end

local function hide_originals(base, attachments)
    Unit.set_unit_visibility(base, false, true)

    if attachments then
        for i = 1, #attachments do
            if unit_ok(attachments[i]) then
                Unit.set_unit_visibility(attachments[i], false, true)
            end
        end
    end
end

local function spawn_model(ext, parent, first_person)
    local world = ext.__qiangiq_shard_world
    local unit_spawner = Managers.state and Managers.state.unit_spawner

    if not (world and unit_spawner) then
        return nil
    end

    local unit = unit_spawner:spawn_unit(SPEAR_UNIT, Unit.world_pose(parent, 1))

    if not unit then
        return nil
    end

    if first_person then
        Unit.set_unit_culling(unit, false)
        -- same flag the game sets on first-person weapons (equipment_component.lua), as the Spear Arsenal does
        Unit.set_shader_pass_flag_for_meshes_in_unit_and_childs(unit, "custom_fov", true)
    end

    World.link_unit(world, unit, 1, parent, 1, World.LINK_MODE_NODE_NAME)

    return unit
end

local function destroy_model(unit)
    if unit_ok(unit) then
        local unit_spawner = Managers.state and Managers.state.unit_spawner

        if unit_spawner then
            unit_spawner:mark_for_deletion(unit)
        end
    end
end

-- one record per slot and view: { model, base, frames, count, gen, fitted, hid }
local function sync_record(ext, records, key, base, attachments, visible, first_person)
    local rec = records[key]
    local want = model_loaded and mod:is_enabled() and unit_ok(base) and attachments ~= nil

    if rec and (not want or rec.base ~= base or not unit_ok(rec.model)) then
        destroy_model(rec.model)
        records[key] = nil

        if rec.hid and rec.base == base and unit_ok(base) and visible then
            Unit.set_unit_visibility(base, true, true)
        end

        rec = nil
    end

    if not want then
        return
    end

    if not rec then
        local model = spawn_model(ext, base, first_person)

        if not model then
            return
        end

        rec = { model = model, base = base, frames = 0, count = -1, fitted = false }
        records[key] = rec
    end

    if rec.count ~= #attachments or rec.gen ~= fit_generation then
        rec.gen = fit_generation
        rec.count = #attachments
        rec.frames = 0
    end

    if rec.frames < FIT_FRAMES then
        rec.frames = rec.frames + 1

        local base_scale = Unit.local_scale(base, 1)
        local k = base_scale and base_scale.x or 1

        rec.fitted = fit(rec.model, base, attachments, k, profile()) or rec.fitted
    end

    if rec.fitted and visible then
        hide_originals(base, attachments)
        rec.hid = true
        Unit.set_unit_visibility(rec.model, true, true)
    else
        Unit.set_unit_visibility(rec.model, false, true)
    end
end

local function clear_records(records)
    if records then
        for key, rec in pairs(records) do
            destroy_model(rec.model)
            records[key] = nil
        end
    end
end

local function apply_models(ext)
    if not ext._is_local_unit or not ext._equipment then
        return
    end

    local records = ext.__qiangiq_shard_records

    if not records then
        records = {}
        ext.__qiangiq_shard_records = records
    end

    for slot_name, slot in pairs(ext._equipment) do
        local item = slot.item

        if (item and item.weapon_template == NEW_TEMPLATE) or records[slot_name .. ":3p"] or records[slot_name .. ":1p"] then
            local active = item and item.weapon_template == NEW_TEMPLATE
            local base_3p, base_1p = slot.unit_3p, slot.unit_1p
            local att_3p = base_3p and slot.attachments_by_unit_3p and slot.attachments_by_unit_3p[base_3p]
            local att_1p = base_1p and slot.attachments_by_unit_1p and slot.attachments_by_unit_1p[base_1p]

            if active then
                sync_record(ext, records, slot_name .. ":3p", base_3p, att_3p, slot.hidden_3p == false, false)
                sync_record(ext, records, slot_name .. ":1p", base_1p, att_1p, slot.hidden_1p == false, true)
            else
                for _, view in ipairs({ ":3p", ":1p" }) do
                    local rec = records[slot_name .. view]

                    if rec then
                        destroy_model(rec.model)
                        records[slot_name .. view] = nil
                    end
                end
            end
        end
    end
end

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "init", function(self, extension_init_context)
    self.__qiangiq_shard_world = extension_init_context and extension_init_context.world
end)

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "_update_item_visibility", function(self)
    if self._is_local_unit then
        tracked[self] = true
        apply_models(self)
    end
end)

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "update", function(self)
    if tracked[self] then
        apply_models(self)
    end
end)

mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, "_unequip_item_from_slot", function(func, self, slot_name, ...)
    local records = self.__qiangiq_shard_records

    if records then
        for _, view in ipairs({ ":3p", ":1p" }) do
            local rec = records[slot_name .. view]

            if rec then
                destroy_model(rec.model)
                records[slot_name .. view] = nil
            end
        end
    end

    return func(self, slot_name, ...)
end)

mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, "destroy", function(func, self, ...)
    clear_records(self.__qiangiq_shard_records)
    tracked[self] = nil

    return func(self, ...)
end)

mod.on_setting_changed = function()
    fit_generation = fit_generation + 1
end

mod.on_all_mods_loaded = function()
    local custom_assets = get_mod("CustomAssets")

    if not custom_assets or not custom_assets.is_api_compatible or not custom_assets.is_api_compatible(1) then
        mod:error("Custom Assets (API 1) is missing: the staff keeps its own model")

        return
    end

    local function acquire(id, on_loaded)
        local ticket, err = custom_assets.acquire(mod, id, function(_, _, load_error)
            if load_error then
                mod:error("%s failed to load: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", id, tostring(load_error))

                return
            end

            on_loaded()
            say("model %s loaded", id)
        end, { resident = true, reference_name = id })

        if not ticket then
            mod:error("%s could not be requested: %s", id, tostring(err))
        end
    end

    acquire(SPEAR_ASSET, function() model_loaded = true end)
    acquire(GREAT_ASSET, function() fly_loaded.great = true end)
    acquire(SHARD_ASSET, function() fly_loaded.shard = true end)
end

-- Controller (stages 2 and 3) -------------------------------------------------------------------------------
-- Visuals: free units of the compiled assets, posed every frame with Unit.set_local_position / set_local_rotation /
-- set_local_scale. The big shard is the crystal greatsword, everything else is an assail shard.
-- Damage: Explosion.create_explosion on the host only, with the call, the damage profile (name "default_bfg", the
-- network sends profiles by name) and the explosion template (name kept, sounds and effects removed) taken from
-- fviuff's Riftlance 1.0.0 (scripts/mods/Riftlance/Riftlance.lua damage_profile / explosion_template / explode).
-- All three explosions are small (single target): nothing here is an area attack.
-- Targets: weights and tags of companion_dog_target_selection_template.lua:38-57 and 242-330, candidates from
-- Broadphase.query as in true_flight_defaults.lua:154-165, hostile units only.
local POWER_LEVEL = 500                 -- Riftlance: at power 500 the attack value is the damage
local SWARM_COUNT = 6
local TARGET_RADIUS = 28                -- m around the player
local LOOK_MAX = 22                     -- m, how far from the player the big shard roams
local AIM_RANGE = 45

local PASSIVE_SCALE = 1.9               -- x the unit's own length (1 m: butt 0, tip 1)
local SWARM_SCALE = 0.9

local PATROL_SPEED, PATROL_TURN = 15, 7.0       -- m/s, rad/s
local DART_SPEED, DART_TURN = 22, 10.0
local DART_FLIGHT_MAX = 3.2             -- s
local DART_HIT_DISTANCE = 2.2
local DART_RADIUS = 1.1                 -- single target
local BALLISTA_V0, BALLISTA_VMAX, BALLISTA_RANGE = 8, 80, 80   -- m/s at the start, m/s at the end, m: straight, pierces
local HEAVY_HIT_RANGE = 2.2         -- m from the flight line to an enemy's centre
local RECALL_SPEED = 38
local CHARGE_RETURN_SPEED = 75     -- m/s: back beside the player for the next strike, as fast as it can
local HEAVY_RADIUS = 1.6
local HEAVY_STUCK = 1.7                 -- s the sword stays in what it hit
local SWARM_SPEED, SWARM_TURN = 26, 8.0
local SWARM_HIT_DISTANCE = 1.3
local SWARM_RETARGET = 0.45             -- s between a shard's hits
local SWARM_LIFETIME_MAX = 8

local TRAIL_PIECES = 5
local TRAIL_STEP = 0.04                 -- s between trail samples

local damage = nil
local ctrl = {
    time = 0,
    mode = "orbit",           -- orbit | patrol | dart | heavy | stuck
    cooldown_dart = 0,
    cooldown_swarm = 0,
    heavy_ready = 0,
    shards = nil,             -- { main, extras[1..6] } each { unit, pos, dir, trail }
    swarm = "off",            -- off | out | regroup
    swarm_t = 0,
    target = nil,
    target_t = 0,
    last_target_name = nil,
    darts = 0,
    swarm_hits = 0,
    heavies = 0,
    heavy_hits = 0,
    aborted = 0,
    heavy_hit = {},
    errors = 0,
    scan_t = 0,
    look_t = 0,
    hostiles = 0,
    hostile_units = {},
}
local broad_results = {}

-- log 2026-10-12 00:36: "bad argument #1 to '__add' (Vector3 expected, got userdata)" on POSITION_LOOKUP[player] +
-- Vector3: some position sources are boxes. servo_friend (players.lua:41) takes unit positions with
-- Unit.world_position(unit, 1); boxes are unboxed here whatever they are.
local function vec(v)
    if v == nil then
        return nil
    end

    local ok, unboxed = pcall(function()
        return v:unbox()
    end)

    if ok and unboxed ~= nil then
        return unboxed
    end

    return v
end

local function unit_pos(unit)
    local ok, position = pcall(Unit.world_position, unit, 1)

    return ok and position or nil
end

-- Sound cues. Only events that belong to the Voidstrike template this staff is cloned from, so they are the ones the
-- game has loaded for it (names from the source):
--   shot  player_character_sound_event_aliases.lua ranged_single_shot  forcestaff_p4_m1
--   hit   force_staff_explosion_templates.lua force_staff_p4_demolition sfx event_name
--   load  player_character_sound_event_aliases.lua sfx_equip           forcestaff_p4_m1
-- Played with the call Riftlance uses for its own sounds: WwiseWorld.trigger_resource_event(wwise_world, event, position).
local SOUND_SHOT = "wwise/events/weapon/play_psyker_smite_fire"
local SOUND_HIT = "wwise/events/weapon/play_explosion_force_med"
local SOUND_LOAD = "wwise/events/weapon/play_force_staff_equip"
local sound_t = {}

local function cue(ctx, event, position, key, gap)
    if mod:get("sounds_enabled") == false or not position then
        return
    end

    local now = ctrl.time

    if key and gap then
        if sound_t[key] and now - sound_t[key] < gap then
            return
        end

        sound_t[key] = now
    end

    pcall(function()
        WwiseWorld.trigger_resource_event(Wwise.wwise_world(ctx.world), event, position)
    end)
end

local function ensure_damage()
    if damage then
        return damage
    end

    local ArmorSettings = require("scripts/settings/damage/armor_settings")
    local GibbingSettings = require("scripts/settings/gibbing/gibbing_settings")
    local PowerLevelSettings = require("scripts/settings/damage/power_level_settings")
    local ExplosionTemplates = require("scripts/settings/damage/explosion_templates")

    local function profile(attack, impact)
        local full = {}

        for _, armor_type in pairs(ArmorSettings.types) do
            full[armor_type] = 1
        end

        return {
            name = "default_bfg",
            ignore_hitzone_multiplier = true,
            ragdoll_push_force = 600,
            stagger_category = "ranged",
            cleave_distribution = { attack = 0.15, impact = 0.15 },
            armor_damage_modifier = { attack = full, impact = full },
            power_distribution = { attack = attack, impact = impact },
            gibbing_power = GibbingSettings.gibbing_power.heavy,
            gibbing_type = GibbingSettings.gibbing_types.warp,
            targets = { default_target = { boost_curve = PowerLevelSettings.boost_curves.default } },
        }
    end

    local function template(p, radius)
        local t = table.clone(ExplosionTemplates.default_force_staff_demolition)

        t.radius = radius
        t.close_radius = radius * 0.5
        t.scalable_radius = false
        t.static_power_level = POWER_LEVEL
        t.damage_profile = p
        t.close_damage_profile = p
        t.min_radius, t.min_close_radius, t.sfx, t.scalable_vfx = nil, nil, nil, nil

        return t
    end

    local dart_profile, swarm_profile, heavy_profile = profile(450, 10), profile(90, 6), profile(1500, 20)

    damage = {
        dart_profile = dart_profile,
        swarm_profile = swarm_profile,
        heavy_profile = heavy_profile,
        dart = template(dart_profile, DART_RADIUS),
        swarm = template(swarm_profile, 1.3),
        heavy = template(heavy_profile, HEAVY_RADIUS),
    }

    return damage
end

local function explode(ctx, position, which)
    cue(ctx, SOUND_HIT, position, "hit_" .. which, which == "swarm" and 0.12 or 0.06)

    if not ctx.is_server then
        return
    end

    local d = ensure_damage()
    local Explosion = require("scripts/utilities/attack/explosion")
    local AttackSettings = require("scripts/settings/damage/attack_settings")
    local chosen

    if which == "heavy" then
        d.heavy_profile.power_distribution.attack = (mod:get("heavy_damage") or 1500) * (0.4 + 0.6 * (ctrl.heavy_charge or 1))
        chosen = d.heavy
    elseif which == "dart" then
        d.dart_profile.power_distribution.attack = mod:get("dart_damage") or 450
        chosen = d.dart
    else
        d.swarm_profile.power_distribution.attack = mod:get("swarm_damage") or 90
        d.swarm.radius = mod:get("swarm_radius") or 1.3
        d.swarm.close_radius = d.swarm.radius * 0.5
        chosen = d.swarm
    end

    Explosion.create_explosion(ctx.world, ctx.physics_world, position, Quaternion.identity(), ctx.player_unit, chosen,
        POWER_LEVEL, 1, AttackSettings.attack_types.explosion, false, false, nil, nil, nil, nil, nil, nil, nil, true)
end

-- the local player's visual loadout extension with the Shard Staff equipped (in hand or not), or nil.
-- ctx.wielded: the staff is the wielded weapon. Not wielded: the sword only floats beside the player.
local function active_context()
    local float_stowed = mod:get("float_when_stowed") ~= false

    for ext in pairs(tracked) do
        if ext._is_local_unit and unit_ok(ext._unit) and ext._equipment and ext._inventory_component then
            local wielded_slot = ext._inventory_component.wielded_slot

            for slot_name, slot in pairs(ext._equipment) do
                local item = slot.item

                if item and item.weapon_template == NEW_TEMPLATE then
                    local world = ext.__qiangiq_shard_world
                    local wielded = slot_name == wielded_slot

                    if world and (wielded or float_stowed) then
                        return {
                            ext = ext,
                            slot = slot,
                            wielded = wielded,
                            world = world,
                            physics_world = World.physics_world(world),
                            player_unit = ext._unit,
                            is_server = ext._is_server,
                        }
                    end
                end
            end
        end
    end

    return nil
end

local function player_view(ctx)
    local data = ScriptUnit.has_extension(ctx.player_unit, "unit_data_system")
    local first_person = data and data:read_component("first_person")

    if not first_person then
        return nil
    end

    return vec(first_person.position), first_person.rotation
end

local function right_held()
    local input = Managers.input and Managers.input:get_input_service("Ingame")

    return input and input:get("action_two_hold") and true or false
end

-- where the player looks: first hit that is not the player, or the end of the range (Riftlance aim())
local function aim_point(ctx, from, rotation)
    local direction = Quaternion.forward(rotation)
    local hits = PhysicsWorld.raycast(ctx.physics_world, from, direction, AIM_RANGE, "all", "types", "both", "max_hits",
        32, "collision_filter", "filter_player_character_shooting_raycast")

    if hits then
        for i = 1, #hits do
            local found = hits[i]
            local actor = found.actor or found[4]
            local unit = actor and Actor.unit(actor)

            if unit ~= ctx.player_unit then
                return found.position or found[1]
            end
        end
    end

    return from + direction * AIM_RANGE
end

-- nearest world geometry along a segment (same raycast as aim_point), or nil. Not the player, not anything with health.
local function ballista_hit(ctx, from, dir, length)
    -- "statics": level geometry only. Dead enemies and ragdolls are dynamic actors; with "both" a corpse without a
    -- health extension counted as a wall and held the sword in mid-air after a kill.
    local hits = PhysicsWorld.raycast(ctx.physics_world, from, dir, length, "all", "types", "statics", "max_hits", 8,
        "collision_filter", "filter_player_character_shooting_raycast")
    local best, best_d = nil, math.huge

    if hits then
        for i = 1, #hits do
            local found = hits[i]
            local actor = found.actor or found[4]
            local unit = actor and Actor.unit(actor)

            -- units with health (enemies, destructibles) never stop the sword: it flies through them
            local solid = not unit or not ScriptUnit.has_extension(unit, "health_system")

            if unit ~= ctx.player_unit and solid then
                local position = found.position or found[1]
                local d = Vector3.length(position - from)

                if d < best_d then
                    best, best_d = position, d
                end
            end
        end
    end

    return best
end

local function segment_distance(point, a, b)
    local ab = b - a
    local length_sq = Vector3.length_squared(ab)
    local t = 0

    if length_sq > 0.000001 then
        t = math.clamp(Vector3.dot(point - a, ab) / length_sq, 0, 1)
    end

    return Vector3.length(point - (a + ab * t))
end

local near_results, near_units = {}, {}

-- hostile units within `radius` of a point, for the strike (the sword leaves the 28 m the scan covers)
local function hostiles_near(ctx, position, radius)
    table.clear(near_units)

    local ok, count = pcall(function()
        local broadphase = Managers.state.extension:system("broadphase_system").broadphase
        local side = ScriptUnit.extension(ctx.player_unit, "side_system").side

        table.clear(near_results)

        return Broadphase.query(broadphase, position, radius, near_results, side:relation_side_names("enemy"))
    end)

    if ok and count then
        for i = 1, count do
            near_units[i] = near_results[i]
        end
    end

    return near_units
end

-- dog weights (companion_dog_target_selection_template.lua:38-57), tokens and aggro left out
local SPECIAL_WEIGHT, ELITE_WEIGHT, RANGED_WEIGHT = 2, 2, 2
local PLAYER_CLOSENESS, SHARD_CLOSENESS, DANGER, IN_DOT, DOT_CHECK = 1.5, 0.5, 1, 10, 0.5
local FAR_DISTANCE = 16
local MAX_LISTED = 40

local AIM_CONE_COS = math.cos(math.rad(9))   -- the cone around the crosshair that counts as "looking at"
local AIM_FLAT, AIM_BONUS = 8, 22

-- best target: whatever you look at first (any enemy in the cone), else elites by the dog's score; also how many
-- hostiles there are, and ctrl.hostile_units = all of them for the swarm
local function find_target(ctx, shard_pos, player_pos, look_dir, eye)
    local ok, count = pcall(function()
        local broadphase = Managers.state.extension:system("broadphase_system").broadphase
        local side = ScriptUnit.extension(ctx.player_unit, "side_system").side

        table.clear(broad_results)

        return Broadphase.query(broadphase, player_pos, TARGET_RADIUS, broad_results, side:relation_side_names("enemy"))
    end)

    table.clear(ctrl.hostile_units)

    if not ok or not count or count == 0 then
        return nil, nil, 0
    end

    local forward = Vector3.normalize(look_dir)
    local flat_look = Vector3.normalize(Vector3.flat(look_dir))
    local best, best_score, best_name = nil, -math.huge, nil
    local hostile = 0
    local only_elites = mod:get("elites_only") ~= false

    for i = 1, count do
        local unit = broad_results[i]

        if unit and HEALTH_ALIVE[unit] and ScriptUnit.has_extension(unit, "health_system") then
            local data = ScriptUnit.has_extension(unit, "unit_data_system")
            local breed = data and data:breed()
            local position = unit_pos(unit)

            if breed and not breed.is_untargetable and position then
                hostile = hostile + 1

                if hostile <= MAX_LISTED then
                    ctrl.hostile_units[hostile] = unit
                end

                local tags = breed.tags
                local is_special, is_elite = tags and tags.special, tags and tags.elite
                local is_ranged = (tags and tags.far) or breed.ranged
                local to_eye = position - eye
                local eye_distance = Vector3.length(to_eye)
                local aim_cos = eye_distance > 0.5 and Vector3.dot(to_eye * (1 / eye_distance), forward) or -1
                local aimed = aim_cos >= AIM_CONE_COS and eye_distance <= AIM_RANGE

                if is_special or is_elite or aimed or not only_elites then
                    local to_unit = position - player_pos
                    local distance = Vector3.length(to_unit)
                    local player_term = PLAYER_CLOSENESS * (1 - math.min(distance, FAR_DISTANCE * 1.5) / (FAR_DISTANCE * 1.5))
                    local shard_term = SHARD_CLOSENESS * (1 - math.min(Vector3.length(position - shard_pos), FAR_DISTANCE * 1.25) / (FAR_DISTANCE * 1.25))
                    local threat = 1 + (is_special and SPECIAL_WEIGHT or 0) + (is_elite and ELITE_WEIGHT or 0) + (is_ranged and RANGED_WEIGHT or 0)
                    local dot = distance > 0.01 and Vector3.dot(Vector3.normalize(Vector3.flat(to_unit)), flat_look) or 0
                    local angle_term = math.clamp((dot - DOT_CHECK) / (1 - DOT_CHECK), 0, 1)
                    local score = player_term + shard_term + DANGER * threat + IN_DOT * angle_term

                    if aimed then
                        score = score + AIM_FLAT + AIM_BONUS * (aim_cos - AIM_CONE_COS) / (1 - AIM_CONE_COS)
                    end

                    if score > best_score then
                        best, best_score, best_name = unit, score, breed.name
                    end
                end
            end
        end
    end

    return best, best_name, hostile
end

-- shard units ----------------------------------------------------------------------
local destroy_shards

local function spawn_shard(ctx, pos, unit_path)
    local unit_spawner = Managers.state and Managers.state.unit_spawner
    local base = ctx.player_unit

    if not (unit_spawner and unit_ok(base)) then
        return nil
    end

    local unit = unit_spawner:spawn_unit(unit_path, Unit.world_pose(base, 1))

    if not unit then
        return nil
    end

    Unit.set_unit_visibility(unit, false, true)

    return {
        unit = unit,
        pos = Vector3Box(pos),
        dir = Vector3Box(Vector3(0, 1, 0)),
        trail = {},
        history = {},
        trail_t = 0,
    }
end

local function ensure_shards(ctx, pos)
    local s = ctrl.shards

    if s and (s.great ~= fly_loaded.great or s.shard ~= fly_loaded.shard) then
        -- the real models arrived after the placeholders were spawned
        destroy_shards()
        s = nil
    end

    if s and unit_ok(s.main.unit) then
        return s
    end

    local shard_path = fly_loaded.shard and SHARD_UNIT or SPEAR_UNIT
    local main = spawn_shard(ctx, pos, fly_loaded.great and GREAT_UNIT or SPEAR_UNIT)

    if not main then
        return nil
    end

    s = { main = main, extras = {}, great = fly_loaded.great, shard = fly_loaded.shard, path = shard_path }

    for i = 1, SWARM_COUNT do
        s.extras[i] = spawn_shard(ctx, pos, shard_path)
    end

    ctrl.shards = s

    return s
end

local function destroy_one(shard)
    if shard then
        destroy_model(shard.unit)

        for i = 1, #shard.trail do
            destroy_model(shard.trail[i])
        end
    end
end

destroy_shards = function()
    local s = ctrl.shards

    if s then
        destroy_one(s.main)

        for i = 1, #s.extras do
            destroy_one(s.extras[i])
        end
    end

    ctrl.shards = nil
    ctrl.mode = "orbit"
    ctrl.swarm = "off"
end

local function show(shard, visible, scale)
    if shard and unit_ok(shard.unit) then
        Unit.set_unit_visibility(shard.unit, visible, true)

        if visible then
            Unit.set_local_position(shard.unit, 1, shard.pos:unbox())
            Unit.set_local_rotation(shard.unit, 1, Quaternion.look(shard.dir:unbox(), Vector3.up()))
            Unit.set_local_scale(shard.unit, 1, Vector3(scale, scale, scale))
        end
    end
end

-- Trail: the assail shard's particle trail (psyker_throwing_knives effects.spawn.vfx) only loads with the assail
-- ability, so the trail here is a row of small assail shards left at the last positions, shrinking away.
local function update_trail(ctx, shard, visible, moving, scale, dt)
    if not (shard and fly_loaded.shard) then
        return
    end

    if #shard.trail == 0 and visible then
        for i = 1, TRAIL_PIECES do
            local piece = spawn_shard(ctx, shard.pos:unbox(), SHARD_UNIT)

            shard.trail[i] = piece and piece.unit or nil
            -- the spawn helper made a record we do not need: only its unit is kept
        end
    end

    if visible and moving then
        shard.trail_t = shard.trail_t + dt

        if shard.trail_t >= TRAIL_STEP then
            shard.trail_t = 0
            table.insert(shard.history, 1, { pos = Vector3Box(shard.pos:unbox()), dir = Vector3Box(shard.dir:unbox()) })
            shard.history[TRAIL_PIECES + 1] = nil
        end
    elseif not moving then
        -- hover: let the trail drain
        shard.history[#shard.history] = nil
    end

    for i = 1, #shard.trail do
        local unit = shard.trail[i]
        local h = shard.history[i]

        if unit_ok(unit) then
            if visible and h then
                local s = scale * (0.55 - 0.09 * i)

                Unit.set_unit_visibility(unit, true, true)
                Unit.set_local_position(unit, 1, h.pos:unbox())
                Unit.set_local_rotation(unit, 1, Quaternion.look(h.dir:unbox(), Vector3.up()))
                Unit.set_local_scale(unit, 1, Vector3(s, s, s))
            else
                Unit.set_unit_visibility(unit, false, true)
            end
        end
    end
end

-- Movement: a heading that can only turn so fast, so paths curve instead of snapping onto the target.
-- Close to the target the limit loosens so a shard does not circle it forever.
local function steer(shard, target, speed, turn_rate, dt)
    local p = shard.pos:unbox()
    local to = target - p
    local distance = Vector3.length(to)

    if distance < 0.001 then
        return distance
    end

    local desired = to * (1 / distance)
    local heading = shard.dir:unbox()
    local cos = math.clamp(Vector3.dot(heading, desired), -1, 1)
    local angle = math.acos(cos)
    local max_turn = turn_rate * dt * (1 + math.max(0, 1 - distance / 4) * 3)
    local new_heading = desired

    if angle > max_turn and angle > 0.0001 then
        -- rotate the heading by max_turn towards the target, in the plane of the two. A straight blend of opposite
        -- vectors never leaves the line (the sword could not turn round), so a target dead behind gets a sideways turn.
        local perp = desired - heading * cos
        local perp_length = Vector3.length(perp)

        if perp_length < 0.0001 then
            perp = Vector3.cross(heading, Vector3.up())

            if Vector3.length(perp) < 0.01 then
                perp = Vector3.cross(heading, Vector3(1, 0, 0))
            end

            perp = Vector3.normalize(perp)
        else
            perp = perp * (1 / perp_length)
        end

        new_heading = heading * math.cos(max_turn) + perp * math.sin(max_turn)
    end

    shard.dir:store(new_heading)

    local moved = p + new_heading * math.min(distance, speed * dt)
    local floor_z = ctrl.floor_z

    -- a curve must not dip into the ground: floor = lower of the player and the look point, 2.5 m below
    if floor_z and moved.z < floor_z then
        moved = Vector3(moved.x, moved.y, floor_z)
    end

    shard.pos:store(moved)

    return distance
end

-- ease toward a hover point (soft, never overshoots)
local function ease(shard, target, rate, dt)
    local p = shard.pos:unbox()
    local to = target - p
    local distance = Vector3.length(to)

    if distance > 0.001 then
        shard.pos:store(p + to * (1 - math.exp(-rate * dt)))

        if distance > 0.3 then
            shard.dir:store(to * (1 / distance))
        end
    end
end

local function hover_point(player_pos, rotation, t)
    local forward = Vector3.normalize(Vector3.flat(Quaternion.forward(rotation)))
    local right = Quaternion.right(rotation)

    return player_pos + Vector3(0, 0, 2.1 + 0.15 * math.sin(t * 2.1)) + right * 0.9 - forward * 0.3
end

-- nearest hostile to a shard that no other shard is on, else the nearest
local function pick_swarm_target(shards, me, from)
    local best, best_d, fallback, fallback_d = nil, math.huge, nil, math.huge

    for i = 1, #ctrl.hostile_units do
        local unit = ctrl.hostile_units[i]

        if unit and HEALTH_ALIVE[unit] then
            local position = unit_pos(unit)

            if position then
                local d = Vector3.length(position - from)
                local taken = false

                for k = 1, SWARM_COUNT do
                    local other = shards.extras[k]

                    if other and other ~= me and other.target == unit then
                        taken = true
                    end
                end

                if not taken and d < best_d then
                    best, best_d = unit, d
                end

                if d < fallback_d then
                    fallback, fallback_d = unit, d
                end
            end
        end
    end

    return best or fallback
end

local function update_controller(dt)
    local ctx = active_context()

    if not ctx or not mod:is_enabled() or not model_loaded then
        if ctrl.shards then
            destroy_shards()
        end

        return
    end

    local eye, rotation = player_view(ctx)

    if not eye then
        return
    end

    ctrl.time = ctrl.time + dt

    local player_pos = unit_pos(ctx.player_unit) or eye
    local look_dir = Quaternion.forward(rotation)
    local home = hover_point(player_pos, rotation, ctrl.time)
    local shards = ensure_shards(ctx, home)

    if not shards then
        return
    end

    local main = shards.main
    local now = ctrl.time
    local passive = mod:get("passive_enabled") ~= false
    local swarm_on = mod:get("swarm_enabled") ~= false

    -- hostiles about five times a second: the best elite and how many enemies there are at all
    if now >= ctrl.scan_t then
        ctrl.scan_t = now + 0.2

        local unit, name, hostile = find_target(ctx, main.pos:unbox(), player_pos, look_dir, eye)

        ctrl.scan_unit, ctrl.scan_name, ctrl.hostiles = unit, name, hostile or 0

        if ctrl.hostiles > 0 then
            ctrl.hostile_t = now
        end
    end

    local enemies_near = ctrl.hostiles > 0 or now - (ctrl.hostile_t or -10) < 1.5

    -- where you look, ten times a second, at most LOOK_MAX m from you
    if now >= ctrl.look_t or not ctrl.look then
        ctrl.look_t = now + 0.1

        local point = aim_point(ctx, eye, rotation)
        local to_point = point - eye
        local length = Vector3.length(to_point)

        if length > LOOK_MAX then
            point = eye + to_point * (LOOK_MAX / length)
        end

        ctrl.look = Vector3Box(point)
    end

    local look = ctrl.look:unbox()

    ctrl.floor_z = ctrl.mode ~= "heavy" and math.min(player_pos.z, look.z) - 2.5 or nil

    -- charged shot (the clone's action_shoot_charged is a dummy, see convert_heavy). While the left button charges
    -- (current_action_name == action_charge) the sword comes back next to you and points where you look; on release
    -- it flies straight ahead like a ballista bolt until it hits something or reaches BALLISTA_RANGE, then returns.
    local unit_data = ScriptUnit.has_extension(ctx.player_unit, "unit_data_system")
    local weapon_action = unit_data and unit_data:read_component("weapon_action")
    local charge_component = unit_data and unit_data:read_component("action_module_charge")
    local action_name = weapon_action and weapon_action.current_action_name
    local charging = ctx.wielded and action_name == "action_charge"
    local released = ctx.wielded and action_name == "action_shoot_charged" and ctrl.prev_action ~= "action_shoot_charged"

    if charging and charge_component then
        ctrl.last_charge = charge_component.charge_level
    end

    ctrl.prev_action = action_name

    -- a new charge has priority over everything the sword is doing: it leaves what it is stuck in, stops a flight in
    -- progress or a flight home, and comes straight back to be loaded. Starting the charge ends the cooldown.
    if charging and ctrl.mode ~= "charge" then
        if ctrl.mode == "heavy" or ctrl.mode == "stuck" or ctrl.mode == "recall" then
            ctrl.aborted = ctrl.aborted + 1
        end

        ctrl.mode, ctrl.target, ctrl.wander = "charge", nil, nil
        ctrl.parked = false
        ctrl.heavy_ready = now
    elseif ctrl.mode == "charge" and not charging and not released then
        ctrl.mode = "patrol"
    end

    local free = ctrl.mode ~= "heavy" and ctrl.mode ~= "stuck" and ctrl.mode ~= "recall"
    local ready = now >= ctrl.heavy_ready

    if released and ready and (ctrl.mode == "charge" or free) then
        -- aim from the sword at the point under the crosshair
        local from = main.pos:unbox()
        local point = aim_point(ctx, eye, rotation)
        local to_point = point - from
        local length = Vector3.length(to_point)
        local dir = length > 3 and to_point * (1 / length) or Vector3.normalize(look_dir)

        ctrl.mode = "heavy"
        cue(ctx, SOUND_SHOT, from, "launch", 0.2)
        ctrl.heavy_charge = math.max(ctrl.last_charge or 1, 0.25)
        ctrl.heavy_dir = Vector3Box(dir)
        ctrl.heavy_travel = 0
        ctrl.heavy_hit = {}
        ctrl.heavies = ctrl.heavies + 1
        ctrl.target, ctrl.wander = nil, nil
        main.dir:store(dir)
    elseif released and ctrl.mode == "charge" then
        ctrl.mode = "patrol"
    end

    -- not in hand: the sword floats by your shoulder and does nothing else
    if not ctx.wielded and ctrl.mode ~= "orbit" then
        ctrl.mode, ctrl.target = "orbit", nil
    end

    -- big shard ----------------------------------------------------------------------------
    local moving = true

    if ctrl.mode == "charge" then
        local forward = Vector3.normalize(look_dir)
        local right = Quaternion.right(rotation)
        local pull = 0.55 * math.clamp((charge_component and charge_component.charge_level) or ctrl.last_charge or 0, 0, 1)
        local slot = eye + forward * (1.4 - pull) + right * 0.5 - Vector3(0, 0, 0.18)

        if Vector3.length(slot - main.pos:unbox()) > 0.8 then
            steer(main, slot, CHARGE_RETURN_SPEED, 24, dt)
        else
            -- loaded: sits on the line of sight, tip forward, and follows the aim
            local heading = main.dir:unbox()
            local k = 1 - math.exp(-16 * dt)

            main.pos:store(slot)
            main.dir:store(Vector3.normalize(heading * (1 - k) + forward * k))
            moving = false

            if not ctrl.parked then
                ctrl.parked = true
                cue(ctx, SOUND_LOAD, slot, "parked", 0.3)
            end
        end
    elseif ctrl.mode == "heavy" then
        local dir = ctrl.heavy_dir:unbox()
        -- slow at first, exponentially faster: BALLISTA_V0 at the start, BALLISTA_VMAX at BALLISTA_RANGE
        local speed = BALLISTA_V0 * (BALLISTA_VMAX / BALLISTA_V0) ^ math.min(ctrl.heavy_travel / BALLISTA_RANGE, 1)
        local step = speed * dt
        local p = main.pos:unbox()
        local q = p + dir * step
        local wall = ballista_hit(ctx, p, dir, step + 0.4)

        main.dir:store(dir)

        -- the blast is measured from an enemy's own position (Explosion.create_explosion queries the broadphase
        -- around the blast centre), so every hostile near the flight line is hit at its centre, once per strike;
        -- candidates are taken around the sword itself, the flight goes far past the player's 28 m scan
        local candidates = hostiles_near(ctx, q, 7)

        for i = 1, #candidates do
            local unit = candidates[i]

            if unit and HEALTH_ALIVE[unit] and not ctrl.heavy_hit[unit] and ScriptUnit.has_extension(unit, "health_system") then
                local position = unit_pos(unit)

                if position then
                    local centre = position + Vector3(0, 0, 1.0)

                    if segment_distance(centre, p, q) <= HEAVY_HIT_RANGE then
                        ctrl.heavy_hit[unit] = true
                        ctrl.heavy_hits = ctrl.heavy_hits + 1
                        explode(ctx, centre, "heavy")
                    end
                end
            end
        end

        if wall then
            -- a wall or the ground: it sits in it for a moment
            main.pos:store(wall + dir * 0.45)
            ctrl.mode, ctrl.stuck_t = "stuck", now
            ctrl.heavy_ready = now + (mod:get("heavy_cooldown") or 2.6)
            cue(ctx, SOUND_HIT, wall, "wall", 0.2)
            cue(ctx, SOUND_SHOT, wall, "wall_shot", 0.2)
        else
            main.pos:store(q)
            ctrl.heavy_travel = ctrl.heavy_travel + step

            if ctrl.heavy_travel >= BALLISTA_RANGE then
                -- the whole range flown: normal flight from where it is
                ctrl.mode = "patrol"
                ctrl.heavy_ready = now + (mod:get("heavy_cooldown") or 2.6)
                ctrl.cooldown_dart = now + 0.3
                cue(ctx, SOUND_LOAD, q, "range_end", 0.5)
            end
        end
    elseif ctrl.mode == "stuck" then
        moving = false

        if now - ctrl.stuck_t >= HEAVY_STUCK then
            ctrl.mode = "patrol"
            ctrl.cooldown_dart = now + 0.6
        end
    elseif ctrl.mode == "recall" then
        -- nothing was hit, or the sword is free again: back to you, fast, then on with the patrol
        if steer(main, home, RECALL_SPEED, 10, dt) < 1.2 then
            ctrl.mode = "patrol"
        end
    else
        if ctrl.mode == "orbit" and enemies_near and ctx.wielded then
            ctrl.mode, ctrl.wander_t = "patrol", 0
        elseif ctrl.mode == "patrol" and not enemies_near then
            ctrl.mode = "orbit"
        elseif ctrl.mode ~= "orbit" and ctrl.mode ~= "patrol" and ctrl.mode ~= "dart" then
            ctrl.mode = "patrol"
        end

        if ctrl.mode == "orbit" then
            local goal = home + Vector3(math.cos(now * 1.3) * 0.25, math.sin(now * 1.7) * 0.25, 0)

            local away = Vector3.length(goal - main.pos:unbox())

            if away > 0.8 then
                steer(main, goal, away > 20 and RECALL_SPEED or PATROL_SPEED * 1.4, PATROL_TURN * 1.5, dt)
            else
                ease(main, goal, 5, dt)
                moving = false
            end
        elseif ctrl.mode == "patrol" then
            -- darts between points around where you look, on a curve
            local wander = ctrl.wander and ctrl.wander:unbox()

            if not wander or now >= (ctrl.wander_t or 0) or Vector3.length(wander - main.pos:unbox()) < 1.2 then
                ctrl.wander_t = now + 0.5 + math.random() * 0.5

                local angle = math.random() * 2 * math.pi
                local radius = 2.0 + math.random() * 3.5

                wander = look + Vector3(math.cos(angle) * radius, math.sin(angle) * radius, 1.2 + math.random() * 2.4)
                ctrl.wander = Vector3Box(wander)
            end

            steer(main, wander, PATROL_SPEED, PATROL_TURN, dt)

            if passive and ctx.wielded and now >= ctrl.cooldown_dart and ctrl.scan_unit then
                ctrl.target, ctrl.target_t, ctrl.last_target_name = ctrl.scan_unit, now, ctrl.scan_name
                ctrl.mode = "dart"
                cue(ctx, SOUND_SHOT, main.pos:unbox(), "dart", 0.35)
            end
        elseif ctrl.mode == "dart" then
            local unit = ctrl.target

            if not (unit and HEALTH_ALIVE[unit]) or now - ctrl.target_t > DART_FLIGHT_MAX then
                ctrl.mode, ctrl.target = "patrol", nil
            else
                local position = (unit_pos(unit) or main.pos:unbox()) + Vector3(0, 0, 1.0)

                if steer(main, position, DART_SPEED, DART_TURN, dt) <= DART_HIT_DISTANCE then
                    ctrl.darts = ctrl.darts + 1
                    explode(ctx, position, "dart")
                    ctrl.mode, ctrl.target = "patrol", nil
                    ctrl.cooldown_dart = now + (mod:get("dart_cooldown") or 1.0)
                end
            end
        end
    end

    -- swarm: six assail shards appear where you look, hunt on their own, then regroup into the sword -----------
    local held = swarm_on and ctx.wielded and right_held()

    if ctrl.swarm == "off" and held and now >= ctrl.cooldown_swarm then
        ctrl.swarm, ctrl.swarm_t = "out", 0
        cue(ctx, SOUND_SHOT, look, "swarm_out", 0.5)

        for i = 1, SWARM_COUNT do
            local e = shards.extras[i]

            if e then
                local angle = (i - 1) * (2 * math.pi / SWARM_COUNT) + math.random() * 0.4

                e.pos:store(look + Vector3(math.cos(angle) * 1.4, math.sin(angle) * 1.4, 2.2 + math.random() * 1.2))
                e.dir:store(Vector3.normalize(Vector3(math.cos(angle), math.sin(angle), 0.4)))
                e.target, e.next_t = nil, now + 0.15 * i
                e.alive_t = now
            end
        end
    end

    local extras_visible = false

    if ctrl.swarm == "out" then
        ctrl.swarm_t = ctrl.swarm_t + dt
        extras_visible = true

        local duration = math.min(mod:get("swarm_duration") or 3.5, SWARM_LIFETIME_MAX)

        for i = 1, SWARM_COUNT do
            local e = shards.extras[i]

            if e then
                if e.target and not HEALTH_ALIVE[e.target] then
                    e.target = nil
                end

                if not e.target and now >= (e.next_t or 0) then
                    e.target = pick_swarm_target(shards, e, e.pos:unbox())
                end

                if e.target then
                    local position = (unit_pos(e.target) or e.pos:unbox()) + Vector3(0, 0, 1.0)

                    if steer(e, position, SWARM_SPEED, SWARM_TURN, dt) <= SWARM_HIT_DISTANCE then
                        ctrl.swarm_hits = ctrl.swarm_hits + 1
                        explode(ctx, position, "swarm")
                        e.target, e.next_t = nil, now + SWARM_RETARGET
                    end
                else
                    -- no one to hit: circle the look point on a loose curve
                    local angle = ctrl.swarm_t * 1.6 + i * (2 * math.pi / SWARM_COUNT)

                    steer(e, look + Vector3(math.cos(angle) * 3.0, math.sin(angle) * 3.0, 2.5), SWARM_SPEED * 0.6,
                        SWARM_TURN, dt)
                end
            end
        end

        if not held or ctrl.swarm_t >= duration then
            ctrl.swarm = "regroup"
            cue(ctx, SOUND_LOAD, look, "regroup", 0.5)
        end
    elseif ctrl.swarm == "regroup" then
        extras_visible = true

        local all_home = true

        for i = 1, SWARM_COUNT do
            local e = shards.extras[i]

            if e and steer(e, main.pos:unbox(), SWARM_SPEED, SWARM_TURN * 1.4, dt) > 0.9 then
                all_home = false
            end
        end

        if all_home then
            ctrl.swarm = "off"
            cue(ctx, SOUND_LOAD, main.pos:unbox(), "absorbed", 0.5)
            ctrl.cooldown_swarm = now + (mod:get("swarm_cooldown") or 4)
            extras_visible = false
        end
    end

    -- draw -------------------------------------------------------------------------------------
    local main_scale = PASSIVE_SCALE

    if ctrl.mode == "stuck" then
        main_scale = PASSIVE_SCALE * (1 + 0.03 * math.sin((now - ctrl.stuck_t) * 40) * math.max(0, 1 - (now - ctrl.stuck_t) / 0.4))
    end

    local main_visible = passive or not ctx.wielded or ctrl.mode == "heavy" or ctrl.mode == "stuck"
        or ctrl.mode == "charge" or ctrl.mode == "recall"

    show(main, main_visible, main_scale)
    update_trail(ctx, main, main_visible, moving and ctrl.mode ~= "orbit", main_scale * 0.5, dt)

    for i = 1, SWARM_COUNT do
        local e = shards.extras[i]

        show(e, extras_visible, SWARM_SCALE)
        update_trail(ctx, e, extras_visible, extras_visible, SWARM_SCALE * 0.9, dt)
    end
end

mod.update = function(dt, t)
    poll_registration()

    local ok, err = pcall(update_controller, dt)

    if not ok then
        ctrl.errors = ctrl.errors + 1

        if ctrl.errors <= 3 then
            mod:error("controller: %s", tostring(err))
        end
    end
end

mod.on_unload = function()
    local ok, cache = pcall(MasterItems.get_cached)

    if ok and cache then
        cache[NEW_ITEM] = nil
    end

    WeaponTemplates[NEW_TEMPLATE] = nil
    destroy_shards()
end

-- Equip probe -----------------------------------------------------------------------

local function local_player()
    local players = Managers.player

    return players and players:local_player_safe(1)
end

local function equipped_item_name(player, slot)
    local unit = player and player.player_unit

    if not unit or not Unit.alive(unit) then
        return nil
    end

    local extension = ScriptUnit.has_extension(unit, "visual_loadout_system")
    local item = extension and extension:item_from_slot(slot)

    return item and item.name
end

local function status()
    local player = local_player()
    local lines = {
        string.format("template registered: %s", tostring(state.template_ok)),
        string.format("item injected: %s (slot %s)", tostring(state.item_ok), tostring(state.slot)),
        string.format("template resolves by item: %s", tostring(rawget(WeaponTemplates, NEW_TEMPLATE) ~= nil)),
    }

    if player and state.slot then
        lines[#lines + 1] = string.format("equipped in %s: %s", state.slot, tostring(equipped_item_name(player, state.slot)))
    end

    lines[#lines + 1] = string.format("inputs remapped: %s, model loaded: %s", tostring(state.inputs_remapped), tostring(model_loaded))

    lines[#lines + 1] = string.format("network ids: template %s (max %s), item %s (max %s)",
        tostring(state.template_lookup_index), tostring(network_type_max("weapon_template_id")),
        tostring(state.item_lookup_index), tostring(network_type_max("player_item_name")))

    lines[#lines + 1] = string.format("profile synchronizer host: %s",
        tostring(Managers.profile_synchronization and Managers.profile_synchronization:synchronizer_host() ~= nil))

    for _, line in ipairs(lines) do
        say("%s", line)
    end
end

local function override(item_name)
    local player = local_player()
    local sync = Managers.profile_synchronization
    local host = sync and sync:synchronizer_host()

    if not player then
        say("no local player")

        return
    end

    if not host then
        say("no profile synchronizer host here (not the host / hub server). Try the Psykhanium or a host mission")

        return
    end

    if not state.slot then
        say("slot unknown, item not injected yet")

        return
    end

    host:override_slot(player:peer_id(), player:local_player_id(), state.slot, item_name)
    say("override_slot(%s, %s) sent", state.slot, tostring(item_name))
end

mod:command("shardstaff", mod:localize("command_shardstaff"), function(action)
    action = action or "status"

    if action == "status" then
        status()
    elseif action == "equip" then
        if not (state.template_ok and state.item_ok) then
            say("not ready yet (template %s, item %s): wait for the registered messages", tostring(state.template_ok), tostring(state.item_ok))

            return
        end

        local player = local_player()

        state.previous_item_name = state.previous_item_name or (player and state.slot and equipped_item_name(player, state.slot))
        say("previous item in %s: %s", tostring(state.slot), tostring(state.previous_item_name))
        override(NEW_ITEM)
    elseif action == "stats" then
        say("mode %s, swarm %s, darts %d, strike hits %d, swarm hits %d, hostiles %d, target %s, controller errors %d, shards %s",
            ctrl.mode, ctrl.swarm, ctrl.darts, ctrl.heavy_hits, ctrl.swarm_hits, ctrl.hostiles, tostring(ctrl.last_target_name),
            ctrl.errors, tostring(ctrl.shards ~= nil))
    elseif action == "restore" then
        if not state.previous_item_name then
            say("nothing to restore (equip first)")

            return
        end

        override(state.previous_item_name)
    else
        say("usage: /shardstaff [status|stats|equip|restore]")
    end
end)

