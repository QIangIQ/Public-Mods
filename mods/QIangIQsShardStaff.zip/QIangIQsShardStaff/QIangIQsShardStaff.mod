return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsShardStaff` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsShardStaff", {
            mod_script = "QIangIQsShardStaff/scripts/mods/QIangIQsShardStaff/QIangIQsShardStaff",
            mod_data = "QIangIQsShardStaff/scripts/mods/QIangIQsShardStaff/QIangIQsShardStaff_data",
            mod_localization = "QIangIQsShardStaff/scripts/mods/QIangIQsShardStaff/QIangIQsShardStaff_localization",
        })
    end,
    version = "0.1.1",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
