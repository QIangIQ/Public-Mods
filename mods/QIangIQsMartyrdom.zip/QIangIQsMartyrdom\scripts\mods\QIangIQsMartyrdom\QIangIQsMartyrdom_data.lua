local mod = get_mod("QIangIQsMartyrdom")

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = false,
	options = {
		widgets = {
			{
				setting_id = "rework_in_hub",
				type = "checkbox",
				default_value = true,
				tooltip = "rework_in_hub_description",
			},
			{
				setting_id = "convert_base_toughness",
				type = "checkbox",
				default_value = false,
				tooltip = "convert_base_toughness_description",
			},
			{
				setting_id = "until_death_cap",
				type = "numeric",
				default_value = 100,
				range = { 50, 100 },
				decimals_number = 0,
				tooltip = "until_death_cap_description",
			},
		},
	},
}
