return {
	mod_name = {
		en = "QIangIQ's Martyrdom",
	},
	mod_description = {
		en = "Reworks Martyrdom on the current Zealot tree. Blazing Piety, Inexorable Judgement and their modifiers are removed. Zealots on this tree have no Toughness: Toughness Damage Reduction becomes Damage Reduction, and Toughness the tree would restore heals instead (10:1, also for allies). Martyrdom is about Health only: it heals 1%% of melee damage and gives up to double attack speed at low health, with no bonus per missing wound. Its modifiers: attack speed on taking or dodging a hit, cleave and melee damage after your ability, health regeneration (0.5 per second), corruption cleanse on melee kills, healing after monstrosity kills, ammo from lost Health, and a +30 maximum Health node under the cleanse. Below the augments grows a branching tree of 25 more talents and 22 small stat nodes (healing, tempo, monstrosity, coherency, pain and blood frenzy lines), each talent behind a small stat node. The three combat ability cooldown modifiers work as in 1.6.1 and can all be picked together. Damage Reduction from the tree is 15%% weaker. Until Death gives Damage Reduction equal to 85%% of your net Health lost over the last 15 seconds instead of resisting death; its modifiers are removed. Every Zealot also gets +0.25 armour damage on melee attacks (up to 0.8) and 10%% ranged Damage Reduction per elite kill (5 stacks, gone 1 second after a ranged hit). Host side only: works in SoloPlay, the Psykhanium and Realms you host; Fatshark missions use the official tree. Everyone in a Realms game needs this mod.",
	},
	rework_in_hub = {
		en = "Reworked tree in the Mourning Star",
	},
	rework_in_hub_description = {
		en = "Show the reworked tree in the Mourning Star and the main menu. Builds you save there have no Blazing Piety or Inexorable Judgement. Fatshark missions always use the official tree.",
	},
	convert_base_toughness = {
		en = "Also convert base Toughness regen",
	},
	convert_base_toughness_description = {
		en = "Off: only Toughness from talents, blessings and abilities turns into Health. On: coherency regen, melee kill Toughness and full restores turn into Health too.",
	},
	until_death_cap = {
		en = "Until Death max reduction (%%)",
	},
	until_death_cap_description = {
		en = "Highest Damage Reduction Until Death can give. 100 leaves it uncapped.",
	},
	command_description = {
		en = "Shows whether the Martyrdom rework is on.",
	},
}
