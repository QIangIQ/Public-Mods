# QIangIQsMartyrdom

Reworks Martyrdom on the **modern** Zealot talent tree.

## What changes
- **Hidden:** the Piety and Inexorable Judgement keystones with all their augments. They are hidden, not deleted, so saved builds keep their indices.
- **Layout:** the talent groups left and right of Martyrdom move 60 units further out (their hubs stay under their abilities). The three Martyrdom augments (Ability Empowerment, Health Regeneration, Attack Speed on Hit) split into seven second-row augments, and a tree grows downwards from them in lanes. Columns are 120 apart, counted from Health Regeneration; rows are 120 apart:

  Second row, left to right: Martyr's Resolve, Pain Is a Gift (under Ability Empowerment), Monstrosity Kill Healing, Corruption Cleanse, Triage (under Health Regeneration), Ammo on Health Loss, Blood Frenzy (under Attack Speed on Hit). The +30 Health node sits under Corruption Cleanse and the health spine continues below it.
  Every talent hangs behind a small stat node (never two talents in a row), no node has more than two children (Health Regeneration has three), and the lanes only fork where it makes sense: Penance Pulse, Rally and Catch Your Breath. The nodes are listed below.
- **Combat ability cooldown modifiers (the three hexagons) work as in game version 1.6.1, and you can pick all three:**
  - Melee crits: +200% cooldown regen (2 s per second) for 4.25 s, instead of +100% for 3.25 s.
  - Backstab kills restore 20% of the combat ability cooldown (1.6.1's talent), instead of the current weakspot/backstab hit version.
  - Each point of damage taken restores 1% of the cooldown (1.6.1's talent), instead of the current health-based version.
- **No toughness on the whole tree (every Zealot on the modern tree):**
  - Toughness is always 0.
  - Toughness damage reduction (TDR) from buffs becomes damage reduction (DR) with the same formula.
  - Toughness from talents, blessings and abilities heals instead, at 10 toughness to 1 HP: a share of max toughness heals a tenth of that share of max health (20% toughness heals 2% health), and flat toughness heals a tenth as much HP.
  - Tree talents that gave **allies** toughness heal them the same way: Bolstering Prayer (per second, per pulse and its bonus toughness) and melee kills that restore toughness to the targeted ally.
  - Tree buffs that gave allies TDR give DR instead: the improved toughness aura, Bolstering Prayer's defensive stacks and the revive buff.
  - Every tree tooltip is rewritten without the word Toughness. Titles the mod does not rewrite get "Toughness" swapped for "Health" ("Toughness Damage Reduction" for "Damage Reduction").
  - The shared Toughness Damage Reduction stat node text is only rewritten when your current character is a Zealot, because every class uses it.
- **Damage reduction from the tree is 15% weaker:** each reduction keeps 85% of its size (the user first cut it by 30%, then asked for stronger DR; 85% is halfway back). This covers the DR stat node (10% to 8.5%), the improved aura and revive buff (15% to 12.75%), Bolstering Prayer's stacks (8% to 6.8% each), critical hits (40% to 34%), leaving stealth (30% to 25.5%), dodging (25% to 21.25%), weakspot kills (15% to 12.75%), the ally buff when they take damage (60% to 51%) and Until Death. Tooltips show the new numbers.
- **Martyrdom keystone (health only, no wound bonus):**
  - 1% of melee damage dealt heals you.
  - Attack speed scales with missing health: normal at full health, up to +100% (double) at 1 HP, linear in between.
- **Martyrdom subnodes:**
  - Attack Speed on Hit: taking or dodging a hit gives +20% attack speed for 6 s.
  - Ability Empowerment: using your combat ability gives +100% cleave and +50% melee damage for 10 s. It triggers on ability start.
  - Health Regeneration (middle): 0.5 HP per second (was 1, halved so health swings less).
  - Corruption Cleanse (under Health Regeneration): a melee kill heals 1 corruption, a weakspot or crit melee kill heals 3, and a weakspot crit kill heals 5. This goes past wound boundaries.
  - +30 Health (small node under Corruption Cleanse): +30 maximum health, added after health multipliers, not while knocked down. It reuses the hidden Until Death healing augment node.
  - Under the +30 Health node, three small stat nodes: +5% damage reduction, +5% maximum health and +5% movement speed. They use the game's own low stat node buffs.
  - Monstrosity Kill Healing (left of Cleanse): killing a monstrosity heals 40% of max health, spread evenly over 10 s. Another monstrosity kill restarts the 10 s.
  - Ammo on Health Loss (under Attack Speed on Hit): health you lose refills reserve ammo at half the share, so losing 10% of max health gives 5% of max reserve ammo, on every weapon that uses ammo.
- **Extra augments and talents** (nodes are appended to the layout, so every saved index stays valid; each talent is behind a small stat node):
  - Second row (the four old placeholder nodes): **Martyr's Resolve** (ability heals 25% of missing health), **Pain Is a Gift** (ability cooldown regen up to +100% at 1 HP), **Triage** (+25% healing received), **Blood Frenzy** (elite kills heal 1% and give +3% attack speed, 5 stacks of 8 s).
  - Healing lane (left): Combat Medic, **Penance Pulse** (ability heals allies in Coherency 10%), Thick Skin, **Last Rites** (ability under 30% health: 90% less damage for 3 s, once per 60 s), Grit, **Relentless** (stun immunity for 4 s after a hit of 20% max health, 10 s cooldown). Branch off Penance Pulse: Steady Hands, **Field Medic** (assisting an ally heals 20%).
  - Tempo lane: Zeal, **Crimson Rush** (+20% movement for 6 s after the ability), the existing +5% movement node, **Adrenal Rush** (below 25% health: +20% movement, +10% attack speed), Fleet Footed, **Pilgrim's Stride** (dodges heal 1.5%).
  - Monstrosity lane: Monster Hide, **Emperor's Gaze** (melee hits on monsters or captains: 10% less damage for 5 s), Heavy Hand, **Field Dressing** (a hit of 15% max health starts a 10% heal over 5 s, 10 s cooldown), Guard, **Unbowed** (below 30% health: +1 HP per second).
  - Health spine (under the +30 Health node): +5% health node, **Scar Tissue** (each time health falls under 30%: +10 maximum health for the mission, 3 times, re-arms above 50%), +5% DR node, **Second Chance** (cheat death: 3 s unkillable, heals 25%, once per 30 minutes), Quick Hands, **Catch Your Breath** (5 s without damage: +1 HP per second), then a fork: Vigor into **Fortress of Flesh** (+25% max health, -8% movement) and Pilgrim's Pace into **Berserker's Toll** (-10% max health, +15% melee damage).
  - Coherency lane: Rallying Presence, **Hold the Line** (3% less damage per ally in Coherency, up to 3), Medic's Hands, **Litany of Fortitude** (2 or more allies: +10% max health), Endurance, **Sanguine Tithe** (elite kills heal allies 3%).
  - Pain lane (under Ammo on Health Loss): Provisioner, **Bleed for the Emperor** (taking melee damage: +5% melee damage for 8 s, 5 stacks), Zeal's Edge, **Defiance** (below 50% health: +10% melee crit chance), Keen Eye, **Apotheosis** (a hit that leaves 10% health: +15% damage for 10 s, 90 s cooldown).
  - Blood frenzy lane (under Blood Frenzy): Swiftness, **Rally** (a kill within 3 s of taking damage heals half of it), Precision, **Vampire's Kiss** (weakspot kills heal 2%), Field Medicine, **Bloodletting** (critical melee kills heal 3%). Branch off Rally: Wrath, **Adrenaline Surge** (special kills heal 3%).
  - From the idea list, left out: Blood Pact (no toughness exists), Warp Siphon (same as Adrenaline Surge), Iron Constitution (replaced by Unbowed, since regen is not interrupted by damage anyway). Combat Medic, Thick Skin, Stamina Boost and Grit became stat nodes.
- **Until Death (replaced):** DR equal to 85% of your net health loss over the last 15 s: your highest health in that time minus your current health, as a share of max health. Healing lowers it, so a hit, a heal and another hit count as one net loss. It multiplies on top of your other DR. The death-prevention effect is removed.
- **Until Death augments are moved** under Corruption Cleanse as the +30 Health node and its three stat nodes, so Until Death is only its DR.
- **Zealot class passives (any modern-tree Zealot):**
  - Melee attacks get +0.25 armour damage modifier (ADM), up to a cap of 0.8. A value already at 0.8 or higher is unchanged, pushes are unaffected, and 0 ADM stays 0.
  - Elite kills give 10% ranged DR, stacking up to 5 times. All stacks drop 1 s after you take a ranged hit.

## Defaults picked where the design was open
- "0 Toughness in the talent tree" is read as: no Zealot on the modern tree has toughness, picked Martyrdom or not, and allies get healing and DR instead of toughness and TDR from Zealot talents.
- "Martyrdom scales on health remaining" is read as the attack speed bonus above, not as a scale on the other Martyrdom effects.
- Health Regeneration reuses the middle augment node and Cleanse reuses the node the official tree hangs below it. The +30 Health node is the official Until Death healing augment, so a build with it but without Until Death is not a valid official build. The same goes for a build with more than one cooldown hexagon. The same goes for the new nodes, whose official parents are other keystones.
- The 1.6.1 cooldown numbers come from QIangIQsLegacyTalents' 1.6.1 files. They use the current game's cooldown functions (restore instead of reduce).
- The ability buff triggers on ability **start**.
- The ADM bonus and elite ranged DR are class-wide passives, not tied to Martyrdom.
- On a ranged hit, all elite stacks clear after 1 s. The other reading would be that each stack lasts 1 s.
- Holy Revenant is unchanged.
- The DR cut also applies to Until Death; the +5% DR stat node is not cut. Ranged-only DR (the ranged talent and the elite kill stacks) and the half damage when a wound breaks are not global DR, so they are unchanged.
- The amounts the user left open: ammo at half the share of health lost, and the three stat nodes at the game's low stat node values (5%).
- Martyrdom no longer has its damage per missing wound (the setting for it is gone).
- The extra nodes are sent to the backend with their index, like any node. On official servers unknown indices are ignored (untested: whether the backend accepts a build that picks them).
- Heals from the new talents use Health.add like the rest of the mod, so healing modifiers such as Triage apply to them.
- Base toughness sources stay off and do not heal: coherency regen, the base melee-kill toughness and full restores. Setting: *Convert base toughness*. Only talent, blessing and ability toughness converts by default.
- TDR from sprint and slide states and from weapon toughness templates is not converted, only TDR from buffs.
- "Cleave" means +1 max hit mass for attacks and impacts.
- Corruption amounts are flat HP, like Benediction's.
- The Until Death DR has an optional cap. Setting: *Until Death DR cap*, default 100%.

## Where it works
- It works only when you are the host: SoloPlay, the Psykhanium and Realms you host. On Fatshark mission servers you get the official tree. In the Mourning Star it follows the *Rework in hub* setting.
- In Realms, every player needs the mod.
- **QIangIQsLegacyTalents' "legacy Zealot" option must be off.** While the legacy Zealot tree is on, this mod stays inactive.
- Chat command `/martyrdom` shows whether the rework is active.
