local mod = get_mod("QIangIQsMartyrdom")

-- Martyrdom rework for the current (modern) Zealot tree.
--
-- Tree: the Blazing Piety (zealot_fanatic_rage) and Inexorable Judgement
-- (zealot_quickness_passive) keystones and their modifiers are hidden. Nodes
-- are never removed from the layout, because the backend talent string
-- stores nodes by their index (talent_layout_parser.lua pack_backend_data);
-- hidden nodes keep their index, lose their links, are locked and are not
-- drawn. Two of the hidden Piety modifiers are drawn again under Martyrdom as
-- locked placeholders, and the groups left and right of Martyrdom move
-- outwards to make room for its augments.
--
-- Every node keeps its talent name, so builds stay valid on the backend. The
-- Martyrdom augments are laid out as
--   Ability Empowerment   Health Regen   Attack Speed on Hit
--   placeholder         Corruption Cleanse        placeholder
-- and the buffs the talents grant change:
--   zealot_martyrdom                      -> 1% of melee damage heals, attack
--                                            speed up to +100% at low health
--   zealot_martyrdom_grants_attack_speed  -> +20% attack speed for 6 s on
--                                            taking or dodging a hit
--   zealot_martyrdom_grants_toughness     -> combat ability: +100% cleave and
--                                            +50% melee damage for 10 s
--   zealot_corruption_resistance_stacking -> 1 health per second
--   zealot_martyrdom_toughness_modifier   -> melee kills cleanse corruption
--   zealot_resist_death (Until Death)     -> DR equal to the net health lost
--                                            over the last 15 s, no cheat
--                                            death; its augments are hidden
-- The regen node reuses the middle modifier and the cleanse node the one the
-- official tree hangs below it, so every build this tree allows is also a
-- valid build on the official tree.
-- Every modern Zealot also gets class passives: no toughness (toughness
-- damage reduction becomes damage reduction, toughness the tree would restore
-- heals at 10 toughness to 1 health), +0.25 ADM on melee attacks (to at most
-- 0.8) and 10% ranged DR per elite kill (5 stacks). Tree talents that give
-- allies toughness heal them instead, and their TDR buffs become DR.
--
-- Gameplay runs where the game runs talents: on the host. On Fatshark's
-- mission servers nothing here runs and the tree is the official one.

local AttackSettings = require("scripts/settings/damage/attack_settings")
local BuffSettings = require("scripts/settings/buff/buff_settings")
local BuffTemplates = require("scripts/settings/buff/buff_templates")
local CheckProcFunctions = require("scripts/settings/buff/helper_functions/check_proc_functions")
local DamageSettings = require("scripts/settings/damage/damage_settings")
local FixedFrame = require("scripts/utilities/fixed_frame")
local Ammo = require("scripts/utilities/ammo")
local Health = require("scripts/utilities/health")
local TalentSettings = require("scripts/settings/talent/talent_settings")
local ToughnessSettings = require("scripts/settings/toughness/toughness_settings")

local attack_types = AttackSettings.attack_types
local keywords = BuffSettings.keywords
local talent_settings = TalentSettings.zealot
local talent_settings_2 = TalentSettings.zealot_2
local talent_settings_3 = TalentSettings.zealot_3
local heal_types = DamageSettings.heal_types
local proc_events = BuffSettings.proc_events
local stat_buffs = BuffSettings.stat_buffs
local toughness_replenish_types = ToughnessSettings.replenish_types

local LAYOUT_PATH = "scripts/ui/views/talent_builder_view/layouts/zealot_tree"

-- Numbers from the user's design.
local TOUGHNESS_PER_HEALTH = 10
local LOW_HEALTH_ATTACK_SPEED = 1
-- User 2026-10-12: health swung too fast, so regen is halved and DR raised.
local HEALTH_REGEN_PER_SECOND = 0.5
local MELEE_LIFESTEAL = 0.01
local HIT_ATTACK_SPEED = 0.2
local HIT_ATTACK_SPEED_DURATION = 6
local ABILITY_CLEAVE = 1
local ABILITY_MELEE_DAMAGE = 0.5
local ABILITY_DURATION = 10
local CLEANSE_MELEE_KILL = 1
local CLEANSE_WEAKSPOT_OR_CRIT_KILL = 3
local CLEANSE_WEAKSPOT_CRIT_KILL = 5
local ADM_BONUS = 0.25
local ADM_CAP = 0.8
local UNTIL_DEATH_WINDOW = 15
local ELITE_RANGED_DR_PER_STACK = 0.1
local ELITE_RANGED_MAX_STACKS = 5
local ELITE_RANGED_CLEAR_DELAY = 1
-- Damage reduction from the tree keeps this share of its strength: a
-- reduction r becomes r * DR_SCALE. The user first cut it by 30% (0.7), then
-- asked for it stronger again; 0.85 is halfway back.
local DR_SCALE = 0.85
-- The small node under Corruption Cleanse.
local HEALTH_NODE_BONUS = 30
-- Middle augment: a monstrosity kill heals this share of max health over
-- MONSTER_HEAL_DURATION seconds.
local MONSTER_HEAL_SHARE = 0.4
local MONSTER_HEAL_DURATION = 10
-- Right augment: each share of max health lost gives this much of that share
-- as reserve ammo (losing 10% health gives 5% ammo).
local AMMO_PER_HEALTH_LOST = 0.5
-- Cooldown modifiers as in game version 1.6.1 (QIangIQsLegacyTalents
-- legacy/1.6.1 talent_settings_zealot.lua): crits_grants_cd and
-- zealot_backstab_kills_restore_cd. combat_ability_cd_restore_on_damage
-- (0.01) is the same in both versions.
local LEGACY_CRIT_CD_REGEN = 2
local LEGACY_CRIT_CD_DURATION = 4.25
local LEGACY_BACKSTAB_CD = 0.2

-- Buff names. All are server buffs (predicted = false), like the Zealot
-- talent buffs in zealot_buff_templates.lua.
local BUFF_REWORK = "qiangiq_martyrdom_rework"
local BUFF_LIFESTEAL = "qiangiq_martyrdom_melee_lifesteal"
local BUFF_LOW_HEALTH_SPEED = "qiangiq_martyrdom_low_health_attack_speed"
local BUFF_REGEN = "qiangiq_martyrdom_health_regen"
local BUFF_HIT_SPEED = "qiangiq_martyrdom_hit_attack_speed"
local BUFF_HIT_SPEED_ACTIVE = "qiangiq_martyrdom_hit_attack_speed_active"
local BUFF_ABILITY = "qiangiq_martyrdom_ability_empower"
local BUFF_ABILITY_ACTIVE = "qiangiq_martyrdom_ability_empower_active"
local BUFF_CLEANSE = "qiangiq_martyrdom_corruption_cleanse"
local BUFF_UNTIL_DEATH = "qiangiq_zealot_until_death_dr"
local BUFF_ADM = "qiangiq_zealot_melee_adm"
local BUFF_ELITE_RANGED = "qiangiq_zealot_elite_ranged_dr"
local BUFF_HEALTH_NODE = "qiangiq_martyrdom_max_health"
local BUFF_DR_NODE = "qiangiq_zealot_dr_node"
local BUFF_MONSTER_HEAL = "qiangiq_martyrdom_monster_kill_heal"
local BUFF_MONSTER_HEAL_ACTIVE = "qiangiq_martyrdom_monster_kill_heal_active"
local BUFF_AMMO_ON_LOSS = "qiangiq_martyrdom_ammo_on_health_loss"
-- Stat nodes under the health node: the game's own low stat node buffs
-- (player_buff_templates.lua). Their toughness damage reduction becomes
-- damage reduction like every other TDR.
local BUFF_STAT_DR = "player_toughness_damage_reduction_node_buff_low_1"
local BUFF_STAT_HEALTH = "player_health_node_buff_low_1"
local BUFF_STAT_MOVEMENT = "player_movement_speed_node_buff_low_1"
local BUFF_BACKSTAB_CD = "qiangiq_zealot_backstab_kills_restore_cd"
-- 1.6.1's damage taken modifier buff. The current game still has it
-- (zealot_buff_templates.lua), just no talent uses it.
local BUFF_DAMAGE_TAKEN_CD = "zealot_ability_cooldown_on_heavy_melee_damage"

-- Shared stat node buff (player_buff_templates.lua). Other classes use it, so
-- Zealots get a scaled copy (BUFF_DR_NODE) instead of a changed original.
local STAT_NODE_BUFF = "player_toughness_damage_reduction_node_buff_medium_1"

-- Key the class passives are listed under in the talent extension's passives.
local CLASS_PASSIVE_KEY = "qiangiq_zealot_class_passive"

-- zealot_tree.lua (current game, version 29): keystones and modifiers to hide.
local HIDDEN_NODES = {
	-- Blazing Piety
	["node_9e19621f-a49c-46a1-837a-056d1ea935bb"] = "zealot_fanatic_rage",
	-- Inexorable Judgement
	["node_86295aae-d8b7-4c66-9862-29d98ae57798"] = "zealot_quickness_passive",
	-- Their other modifiers are the side placeholders (PLACEHOLDER_NODES).
	-- The four Until Death augments are the health node and its three stat
	-- nodes (MOVED_NODES), so Until Death is only its damage reduction.
}

-- Locked, empty Martyrdom augment slots. None are left: the four old
-- placeholders are real augments now (EXTRA_NODES). The lock code below still
-- handles entries added here.
local PLACEHOLDER_NODES = {}

-- Nodes that can never be picked: hidden ones and placeholders.
local LOCKED_NODES = {}
local LOCKED_TALENTS = {}

for _, list in ipairs({ HIDDEN_NODES, PLACEHOLDER_NODES }) do
	for widget_name, talent_name in pairs(list) do
		LOCKED_NODES[widget_name] = talent_name
		LOCKED_TALENTS[talent_name] = true
	end
end

-- Martyrdom and its augments.
local NODE_MARTYRDOM = "node_00de95af-259d-4c82-ae16-91fa3b533ed9"
local NODE_ABILITY = "node_2d176f63-527c-4758-a1c1-eed8dfd6ac78"
local NODE_ATTACK_SPEED = "node_9d8273b3-4c5d-4317-b480-54a125376f0d"
local NODE_REGEN = "node_ccd0b423-3a44-4f74-8339-7c7b65ba2d63"
local NODE_CLEANSE = "node_4db4d1f1-d5b8-4d3f-a352-b50194ef96e4"

-- The three combat ability cooldown modifiers (exclusive_group "cdr_1" in
-- zealot_tree.lua). The user wants them all pickable together.
local CDR_NODES = {
	"node_5e1591e1-f942-4d8d-9b53-0d11864a59ef", -- zealot_crits_grant_cd
	"node_5a6a015e-77a8-4675-a51b-7fd233eb1b26", -- zealot_restore_stealth_cd_on_damage
	"node_5321e553-acec-4b27-9d43-a5af507fa953", -- zealot_backstab_kills_restore_cd
}
-- Until Death's heal augment, moved under Corruption Cleanse as a stat node.
local NODE_HEALTH = "node_18bc94af-2948-4b9a-84e8-5c9408b37343"
-- The other Until Death augments, as small stat nodes under the health node.
local NODE_STAT_DR = "node_3483d4d7-3f13-48de-8055-ecfc04d70aae"
local NODE_STAT_HEALTH = "node_9ad99512-0439-46e8-8113-5d7de6d174da"
local NODE_STAT_MOVEMENT = "node_2eb4f6f4-6d27-4ecd-a41c-bac7a014a6c0"
-- Placeholders turned into real augments.
local NODE_MONSTER_HEAL = "node_2a3a12a6-983c-4998-8541-83e9266b031d"
local NODE_AMMO = "node_4edf073e-7aa4-4234-9d90-c0551ccdfb32"

-- Nodes that leave their official place: other nodes drop their old links
-- to them, and _apply_tree links them again.
local MOVED_NODES = {
	[NODE_HEALTH] = true,
	[NODE_STAT_DR] = true,
	[NODE_STAT_HEALTH] = true,
	[NODE_STAT_MOVEMENT] = true,
	[NODE_MONSTER_HEAL] = true,
	[NODE_AMMO] = true,
	-- The four old placeholders (Piety and Inexorable Judgement modifiers).
	["node_e079e0d7-8d4b-45de-8e6b-5ed57f82c641"] = true,
	["node_1473ca58-1a77-4543-b2e5-9c4491d240c8"] = true,
	["node_23264a41-d011-4792-a45e-ea68c7d5b27f"] = true,
	["node_8b72c79c-2b0f-4081-b919-f730aaee433d"] = true,
}

-- Node spacing in zealot_tree.lua: columns 120 apart, augment rows 120 apart
-- (ccd0b423 at y 2345, 4db4d1f1 at y 2465).
local NODE_SPACING = 120

-- The groups left and right of Martyrdom (below the Piety and Inexorable
-- Judgement hubs) move outwards by this much. The hubs stay under their
-- abilities.
local SIDE_GROUP_SHIFT = 60
local LEFT_GROUP = {
	"node_0e6bc32b-bdab-4856-94e7-f141355cc9a0",
	"node_5e1591e1-f942-4d8d-9b53-0d11864a59ef",
	"node_0dbb9346-b495-40d9-81d2-3d69b24056f7",
	"node_3f11f576-443e-42b0-b6f9-cedcafb6a224",
	"node_5832cbce-960a-4303-b772-3f8813fde6d0",
}
local RIGHT_GROUP = {
	"node_1fbb7b5c-aac2-4489-9a39-9a9eab68f484",
	"node_5321e553-acec-4b27-9d43-a5af507fa953",
	"node_324c71cf-ae7e-4441-acb6-203a35ae041d",
	"node_09a97b15-e79d-4953-a189-f24beac4a40d",
	"node_72f07a65-a83f-4264-99fe-6d3551d135e1",
}

-- Existing zealot tree icons (zealot_tree.lua) for the moved nodes.
local ICON_REGEN = "content/ui/textures/icons/talents/zealot/zealot_resist_death_healing"
local ICON_CLEANSE = "content/ui/textures/icons/talents/zealot/zealot_reduced_corruption_damage_taken"
-- The icon every stat node in zealot_tree.lua uses.
local ICON_STAT = "content/ui/textures/frames/talents/circular_small_frame"
local ICON_MONSTER_HEAL = "content/ui/textures/icons/talents/zealot/zealot_heal_part_of_damage_taken"
local ICON_AMMO = "content/ui/textures/icons/talents/zealot/zealot_increased_reload_speed_on_melee_kills"

-- Passive buffs that replace the talents' own (zealot_talents.lua passives).
local PASSIVE_REPLACEMENTS = {
	zealot_martyrdom_grants_attack_speed = { BUFF_HIT_SPEED },
	zealot_martyrdom_grants_toughness = { BUFF_ABILITY },
	zealot_corruption_resistance_stacking = { BUFF_REGEN },
	zealot_martyrdom_toughness_modifier = { BUFF_CLEANSE },
	zealot_resist_death = { BUFF_UNTIL_DEATH },
	zealot_resist_death_heal = { BUFF_HEALTH_NODE },
	zealot_resist_death_ability = { BUFF_STAT_DR },
	zealot_resist_death_fire = { BUFF_STAT_HEALTH },
	zealot_resist_death_golden_toughness = { BUFF_STAT_MOVEMENT },
	zealot_shared_fanatic_rage = { BUFF_MONSTER_HEAL },
	zealot_quickness_passive_dodge_stacks = { BUFF_AMMO_ON_LOSS },
	base_toughness_damage_reduction_node_buff_medium_1 = { BUFF_DR_NODE },
	zealot_backstab_kills_restore_cd = { BUFF_BACKSTAB_CD },
	zealot_restore_stealth_cd_on_damage = { BUFF_DAMAGE_TAKEN_CD },
}

-- Zealot buffs that give other players toughness damage reduction. While the
-- rework is on, their TDR stats become the matching DR stats (buff.lua
-- update_stat_buffs reads the template's stat tables every update). The
-- talent text reads these templates through other fields (zealot_talents.lua
-- format_values), so only the stat tables change.
local TDR_TO_DR_TEMPLATES = {
	"zealot_coherency_toughness_damage_resistance_improved",
	"zealot_revive_speed_effect",
	"zealot_channel_toughness_damage_reduction",
}
local TDR_TO_DR_STATS = {
	toughness_damage_taken_multiplier = "damage_taken_multiplier",
	toughness_damage_taken_modifier = "damage_taken_modifier",
}

-- Every buff the tree's damage reduction talents apply (zealot_buff_templates.lua),
-- scaled by DR_SCALE while the rework is on. Not here: ranged-only reduction
-- (zealot_reduced_damage_from_ranged) and the wound segment reduction
-- (zealot_preacher_segment_breaking_half_damage), which are not global.
local DR_SCALED_TEMPLATES = {
	"zealot_coherency_toughness_damage_resistance_improved",
	"zealot_revive_speed_effect",
	"zealot_channel_toughness_damage_reduction",
	"zealot_reduced_toughness_damage_taken_on_critical_strike_hits_effect",
	"zealot_leaving_stealth_restores_toughness",
	"zealot_preacher_ally_defensive_buff",
	"zealot_weakspot_damage_reduction_effect",
	"zealot_damage_reduction_after_dodge",
}
local DR_MULTIPLIER_STATS = {
	damage_taken_multiplier = true,
	toughness_damage_taken_multiplier = true,
}
local DR_MODIFIER_STATS = {
	damage_taken_modifier = true,
	toughness_damage_taken_modifier = true,
}
local STAT_TABLE_FIELDS = {
	"stat_buffs",
	"proc_stat_buffs",
	"conditional_stat_buffs",
}

local state = mod:persistent_table("martyrdom_state", {
	registered = false,
	host_type = nil,
	saved = nil,
	hidden_tables = nil,
	saved_templates = nil,
	original_funcs = {},
})

-- ####################################################################
-- Extra Martyrdom augments (data)
-- ####################################################################

-- A branching tree of talents and small stat nodes under the Martyrdom
-- augments. Positions are columns and rows relative to the Health
-- Regeneration node (columns and rows are NODE_SPACING apart). The four old
-- placeholder nodes, the Monstrosity, Ammo, Cleanse and +30 Health nodes and
-- the three small stat nodes are placed here as well; every other entry is a
-- node added to the layout while the rework is on. Added nodes go at the end
-- of the node list, so every saved node index stays valid (the backend
-- stores nodes by index, talent_layout_parser.lua pack_backend_data).
local Extra = {}

local EXTRA_ICONS = "content/ui/textures/icons/talents/zealot/"

-- { key, column, row, parent key, widget name (existing nodes), icon (existing nodes) }
Extra.NODES = {
	{ "ae", -1, 0, "mart", NODE_ABILITY },
	{ "reg", 0, 0, "mart", NODE_REGEN, ICON_REGEN },
	{ "as", 1, 0, "mart", NODE_ATTACK_SPEED },
	{ "mr", -3, 1, "ae", "node_e079e0d7-8d4b-45de-8e6b-5ed57f82c641" },
	{ "pg", -2, 1, "ae", "node_1473ca58-1a77-4543-b2e5-9c4491d240c8" },
	{ "mon", -1, 1, "reg", NODE_MONSTER_HEAL, ICON_MONSTER_HEAL },
	{ "cln", 0, 1, "reg", NODE_CLEANSE, ICON_CLEANSE },
	{ "tri", 1, 1, "reg", "node_23264a41-d011-4792-a45e-ea68c7d5b27f" },
	{ "amm", 2, 1, "as", NODE_AMMO, ICON_AMMO },
	{ "bf", 3, 1, "as", "node_8b72c79c-2b0f-4081-b919-f730aaee433d" },
	{ "hp30", 0, 2, "cln", NODE_HEALTH, ICON_STAT },
	-- Ability, healing line.
	{ "s_heal", -3, 2, "mr" },
	{ "pp", -3, 3, "s_heal" },
	{ "s_corr", -3, 4, "pp" },
	{ "lr", -3, 5, "s_corr" },
	{ "s_grit", -3.5, 6, "lr" },
	{ "rel", -4, 7, "s_grit" },
	{ "s_assist", -4, 4, "pp" },
	{ "fm", -4, 5, "s_assist" },
	-- Ability, tempo line.
	{ "s_cdr", -2, 2, "pg" },
	{ "cr", -2, 3, "s_cdr" },
	{ "s_move", -2, 4, "cr", NODE_STAT_MOVEMENT, ICON_STAT },
	{ "ar", -2, 5, "s_move" },
	{ "s_dodge", -2, 6, "ar" },
	{ "ps", -2, 7, "s_dodge" },
	-- Monstrosity line.
	{ "s_mon", -1, 2, "mon" },
	{ "eg", -1, 3, "s_mon" },
	{ "s_imp", -1, 4, "eg" },
	{ "fd", -1, 5, "s_imp" },
	{ "s_block", -1, 6, "fd" },
	{ "ub", -1, 7, "s_block" },
	-- Health line (below the +30 Health node).
	{ "s_hp", 0, 3, "hp30", NODE_STAT_HEALTH, ICON_STAT },
	{ "st", 0, 4, "s_hp" },
	{ "s_dr", 0, 5, "st", NODE_STAT_DR, ICON_STAT },
	{ "sc", 0, 6, "s_dr" },
	{ "s_reload", 0, 7, "sc" },
	{ "cyb", 0, 8, "s_reload" },
	{ "s_vig", -0.5, 9, "cyb" },
	{ "fof", -0.5, 10, "s_vig" },
	{ "s_vig2", 0.5, 9, "cyb" },
	{ "bt", 0.5, 10, "s_vig2" },
	-- Coherency line.
	{ "s_coh", 1, 2, "tri" },
	{ "htl", 1, 3, "s_coh" },
	{ "s_revive", 1, 4, "htl" },
	{ "lit", 1, 5, "s_revive" },
	{ "s_stam", 1, 6, "lit" },
	{ "sang", 1, 7, "s_stam" },
	-- Ammo and pain line.
	{ "s_ammo", 2, 2, "amm" },
	{ "bfe", 2, 3, "s_ammo" },
	{ "s_mel", 2, 4, "bfe" },
	{ "def", 2, 5, "s_mel" },
	{ "s_crit", 2, 6, "def" },
	{ "apo", 2, 7, "s_crit" },
	-- Blood frenzy line.
	{ "s_as", 3, 2, "bf" },
	{ "ral", 3, 3, "s_as" },
	{ "s_weak", 3, 4, "ral" },
	{ "vk", 3, 5, "s_weak" },
	{ "s_med", 3, 6, "vk" },
	{ "bl", 3, 7, "s_med" },
	{ "s_dmg", 4, 4, "ral" },
	{ "adr", 4, 5, "s_dmg" },
}

-- Talents. A def with a `talent` is an old placeholder node that keeps its
-- official talent (so builds stay valid on the official tree); every other
-- def is a new talent named qiangiq_mt_<key>.
Extra.DEFS = {
	mr = { name = "Martyr's Resolve", talent = "zealot_fanatic_rage_toughness_on_max", loc_name = "loc_talent_zealot_fanatic_rage_toughness", loc_desc = "loc_talent_zealot_fanatic_rage_toughness_replenish_desc", icon = EXTRA_ICONS .. "zealot_cleansing_flame" },
	pg = { name = "Pain Is a Gift", talent = "zealot_momentum_toughness_replenish", loc_name = "loc_talent_zealot_quickness_toughness_per_stack", loc_desc = "loc_talent_zealot_momentum_toughness_replenish_desc", icon = EXTRA_ICONS .. "zealot_death_comes_frequently" },
	tri = { name = "Triage", talent = "zealot_fanatic_rage_improved", loc_name = "loc_talent_zealot_fanatic_rage_improved", loc_desc = "loc_talent_zealot_fanatic_rage_improved_desc", icon = EXTRA_ICONS .. "zealot_aura_cleansing_prayer" },
	bf = { name = "Blood Frenzy", talent = "zealot_quickness_increased_duration", loc_name = "loc_talent_zealot_quickness_increased_duration", loc_desc = "loc_talent_zealot_quickness_increased_duration_desc", icon = EXTRA_ICONS .. "zealot_elite_kills_empowers" },
	pp = { name = "Penance Pulse", icon = EXTRA_ICONS .. "zealot_aura_the_emperor_will" },
	lr = { name = "Last Rites", icon = EXTRA_ICONS .. "zealot_to_your_aid" },
	fm = { name = "Field Medic", icon = EXTRA_ICONS .. "zealot_revive_speed" },
	rel = { name = "Relentless", icon = EXTRA_ICONS .. "zealot_uninterruptible_no_slow_heavies" },
	cr = { name = "Crimson Rush", icon = EXTRA_ICONS .. "zealot_damage_boosts_movement" },
	ar = { name = "Adrenal Rush", icon = EXTRA_ICONS .. "zealot_improved_sprint" },
	ps = { name = "Pilgrim's Stride", icon = EXTRA_ICONS .. "zealot_zealous_pilgrim" },
	eg = { name = "Emperor's Gaze", icon = EXTRA_ICONS .. "zealot_increased_damage_vs_resilient" },
	fd = { name = "Field Dressing", icon = EXTRA_ICONS .. "zealot_toughness_on_heavy_kills" },
	ub = { name = "Unbowed", icon = EXTRA_ICONS .. "zealot_reduced_damage_on_wound" },
	st = { name = "Scar Tissue", icon = EXTRA_ICONS .. "zealot_additional_wounds" },
	sc = { name = "Second Chance", icon = EXTRA_ICONS .. "zealot_resist_death" },
	cyb = { name = "Catch Your Breath", icon = EXTRA_ICONS .. "zealot_default_general_talent" },
	fof = { name = "Fortress of Flesh", icon = EXTRA_ICONS .. "zealot_defensive_knockback" },
	bt = { name = "Berserker's Toll", icon = EXTRA_ICONS .. "zealot_hits_grant_stacking_damage" },
	htl = { name = "Hold the Line", icon = EXTRA_ICONS .. "zealot_ally_damage_taken_reduced" },
	lit = { name = "Litany of Fortitude", icon = EXTRA_ICONS .. "zealot_aura_the_emperor_demand" },
	sang = { name = "Sanguine Tithe", icon = EXTRA_ICONS .. "zealot_bleed_kills_stacking_damage" },
	bfe = { name = "Bleed for the Emperor", icon = EXTRA_ICONS .. "zealot_stacking_melee_damage_after_dodge" },
	def = { name = "Defiance", icon = EXTRA_ICONS .. "zealot_increased_crit_and_weakspot_damage_after_dodge" },
	apo = { name = "Apotheosis", icon = EXTRA_ICONS .. "zealot_fire_and_fury" },
	ral = { name = "Rally", icon = EXTRA_ICONS .. "zealot_heal_part_of_damage_taken" },
	vk = { name = "Vampire's Kiss", icon = EXTRA_ICONS .. "zealot_crits_apply_bleed" },
	bl = { name = "Bloodletting", icon = EXTRA_ICONS .. "zealot_crits_rend" },
	adr = { name = "Adrenaline Surge", icon = EXTRA_ICONS .. "zealot_multihits_restore_stamina" },
}

-- Small stat nodes: { name, stat, value, multiplicative, text }. A
-- multiplicative stat holds the share kept (0.95 is 5% less).
Extra.STATS = {
	s_heal = { "Combat Medic", "healing_recieved_modifier", 0.1, false, "+%s Healing Received." },
	s_corr = { "Thick Skin", "corruption_taken_multiplier", 0.95, true, "-%s Corruption Taken." },
	s_grit = { "Grit", "knocked_down_health_modifier", 0.25, false, "+%s Health while knocked down." },
	s_assist = { "Steady Hands", "assist_speed_modifier", 0.15, false, "+%s Assist Speed." },
	s_cdr = { "Zeal", "combat_ability_resource_regen_modifier", 0.05, false, "+%s Combat Ability Cooldown Regeneration." },
	s_dodge = { "Fleet Footed", "dodge_distance_modifier", 0.1, false, "+%s Dodge Distance." },
	s_mon = { "Monster Hide", "monster_damage_taken_multiplier", 0.95, true, "-%s Damage Taken from Monstrosities." },
	s_imp = { "Heavy Hand", "impact_modifier", 0.1, false, "+%s Impact." },
	s_block = { "Guard", "block_cost_multiplier", 0.9, true, "-%s Block Cost." },
	s_reload = { "Quick Hands", "reload_speed", 0.05, false, "+%s Reload Speed." },
	s_vig = { "Vigor", "max_health_modifier", 0.03, false, "+%s Maximum Health." },
	s_vig2 = { "Pilgrim's Pace", "sprint_movement_speed", 0.05, false, "+%s Sprint Speed." },
	s_coh = { "Rallying Presence", "coherency_radius_modifier", 0.15, false, "+%s Coherency Radius." },
	s_revive = { "Medic's Hands", "revive_speed_modifier", 0.1, false, "+%s Revive Speed." },
	s_stam = { "Endurance", "stamina_regeneration_modifier", 0.1, false, "+%s Stamina Regeneration." },
	s_ammo = { "Provisioner", "ammo_reserve_capacity", 0.1, false, "+%s Reserve Ammo." },
	s_mel = { "Zeal's Edge", "melee_damage", 0.03, false, "+%s Melee Damage." },
	s_crit = { "Keen Eye", "melee_critical_strike_chance", 0.03, false, "+%s Melee Critical Strike Chance." },
	s_as = { "Swiftness", "attack_speed", 0.03, false, "+%s Attack Speed." },
	s_weak = { "Precision", "melee_weakspot_damage", 0.05, false, "+%s Melee Weakspot Damage." },
	s_med = { "Field Medicine", "healing_recieved_modifier", 0.05, false, "+%s Healing Received." },
	s_dmg = { "Wrath", "damage", 0.03, false, "+%s Damage." },
}

for key, stat in pairs(Extra.STATS) do
	Extra.DEFS[key] = { name = stat[1], stat = stat, icon = ICON_STAT }
end

-- Numbers of the new talents.
Extra.N = {
	MR_MISSING_HEAL = 0.25,
	PG_MAX = 1,
	TRIAGE = 0.25,
	BF_SPEED = 0.03,
	BF_STACKS = 5,
	BF_DURATION = 8,
	BF_HEAL = 0.01,
	PP_HEAL = 0.1,
	LR_HEALTH = 0.3,
	LR_MULT = 0.1,
	LR_DURATION = 3,
	LR_COOLDOWN = 60,
	FM_HEAL = 0.2,
	REL_HIT = 0.2,
	REL_DURATION = 4,
	REL_COOLDOWN = 10,
	CR_SPEED = 0.2,
	CR_DURATION = 6,
	AR_HEALTH = 0.25,
	AR_MOVE = 0.2,
	AR_ATTACK = 0.1,
	PS_HEAL = 0.015,
	EG_MULT = 0.9,
	EG_DURATION = 5,
	FD_HIT = 0.15,
	FD_SHARE = 0.1,
	FD_DURATION = 5,
	FD_COOLDOWN = 10,
	UB_HEALTH = 0.3,
	UB_REGEN = 1,
	ST_THRESHOLD = 0.3,
	ST_RESET = 0.5,
	ST_BONUS = 10,
	ST_STACKS = 3,
	SC_ACTIVE = 3,
	SC_COOLDOWN = 1800,
	SC_HEAL = 0.25,
	CYB_DELAY = 5,
	CYB_REGEN = 1,
	FOF_HEALTH = 0.25,
	FOF_MOVE = -0.08,
	BT_HEALTH = -0.1,
	BT_MELEE = 0.15,
	HTL_PER_ALLY = 0.03,
	HTL_ALLIES = 3,
	LIT_HEALTH = 0.1,
	LIT_ALLIES = 2,
	SANG_HEAL = 0.03,
	BFE_DAMAGE = 0.05,
	BFE_STACKS = 5,
	BFE_DURATION = 8,
	DEF_HEALTH = 0.5,
	DEF_CRIT = 0.1,
	APO_HEALTH = 0.1,
	APO_DAMAGE = 0.15,
	APO_DURATION = 10,
	APO_COOLDOWN = 90,
	RAL_WINDOW = 3,
	RAL_SHARE = 0.5,
	VK_HEAL = 0.02,
	BL_HEAL = 0.03,
	ADR_HEAL = 0.03,
}

Extra.PREFIX = "qiangiq_mt_"

-- Buff, talent and loc names of a key.
Extra.name = function (key)
	return Extra.PREFIX .. key
end

Extra.widget = function (key)
	return "node_qiangiq-mt-" .. key
end

-- The four old placeholders keep their official talents; their buffs are the
-- extra talents of the same key.
PASSIVE_REPLACEMENTS.zealot_fanatic_rage_toughness_on_max = { Extra.name("mr") }
PASSIVE_REPLACEMENTS.zealot_momentum_toughness_replenish = { Extra.name("pg") }
PASSIVE_REPLACEMENTS.zealot_fanatic_rage_improved = { Extra.name("tri") }
PASSIVE_REPLACEMENTS.zealot_quickness_increased_duration = { Extra.name("bf") }

-- ####################################################################
-- Mode: which tree is in use
-- ####################################################################

-- QIangIQsLegacyTalents replaces layout.nodes when its legacy Zealot tree is
-- on, and keeps both tables in its toggle record (mode_toggle.lua). Same
-- lookup as QIangIQsZealotDeflect _legacy_nodes.
local function _legacy_record()
	local legacy_mod = get_mod("QIangIQsLegacyTalents")

	if not legacy_mod then
		return nil
	end

	local legacy_state = legacy_mod:persistent_table("legacy_state")
	local toggle = legacy_state and legacy_state.toggle

	if not toggle or not toggle.tables then
		return nil
	end

	local layout = require(LAYOUT_PATH)

	for i = 1, toggle.count do
		if toggle.tables[i] == layout and toggle.keys[i] == "nodes" then
			return toggle, i
		end
	end

	return nil
end

local function _modern_nodes()
	local toggle, i = _legacy_record()

	if toggle then
		return toggle.vanilla[i]
	end

	return require(LAYOUT_PATH).nodes
end

local function _legacy_zealot_active()
	local toggle = _legacy_record()

	return toggle ~= nil and toggle.active == true
end

-- Same host types as QIangIQsLegacyTalents _wanted_active.
local function _wanted(host_type)
	if host_type == "mission_server" then
		return false
	elseif host_type == "player" or host_type == "singleplay" or host_type == "singleplay_backend_session" then
		return true
	end

	-- hub_server, or no connection yet (main menu).
	return mod:get("rework_in_hub") ~= false
end

local function _is_active()
	return _wanted(state.host_type) and not _legacy_zealot_active()
end

local function _is_modern_zealot(profile)
	local archetype = profile and profile.archetype

	if not archetype or archetype.name ~= "zealot" then
		return false
	end

	return require(LAYOUT_PATH).nodes == _modern_nodes()
end

-- ####################################################################
-- Tree edits (reversible)
-- ####################################################################

local function _without_hidden(list)
	local out = {}
	local changed = false

	for i = 1, #list do
		if LOCKED_NODES[list[i]] or MOVED_NODES[list[i]] then
			changed = true
		else
			out[#out + 1] = list[i]
		end
	end

	return changed and out or nil
end

local function _apply_tree()
	if state.saved then
		return
	end

	local nodes = _modern_nodes()

	if type(nodes) ~= "table" then
		return
	end

	local saved = {}
	local hidden_tables = {}

	local function save(node, key, value)
		saved[#saved + 1] = { node, key, node[key] }
		node[key] = value
	end

	local function lowest_y(hidden)
		local lowest = nil

		for i = 1, #nodes do
			local node = nodes[i]

			if node.y and not (hidden and HIDDEN_NODES[node.widget_name]) and (not lowest or node.y > lowest) then
				lowest = node.y
			end
		end

		return lowest
	end

	local official_lowest_y = lowest_y(false)

	local by_name = {}

	for i = 1, #nodes do
		local node = nodes[i]

		by_name[node.widget_name] = node

		if LOCKED_NODES[node.widget_name] then
			local requirements = table.clone(node.requirements or {})

			requirements.exclusive_group = nil

			if HIDDEN_NODES[node.widget_name] then
				-- node_builder_view_base.lua _node_availability_status: a node
				-- whose min_points_spent is above the points spent is locked.
				-- Hidden nodes are never hovered, so their tooltip is never
				-- built.
				requirements.min_points_spent = 9999
			else
				-- Placeholders are hovered. A locked node with min_points_spent
				-- above 0 builds a requirement tooltip that reads
				-- style.requirement_title_height (talent_builder_view.lua
				-- _setup_tooltip_info), which does not exist, and the game
				-- crashes. Lock them the way the official tree does for
				-- incompatible nodes instead: their parent needs Martyrdom,
				-- so Martyrdom is always picked when they could be.
				requirements.min_points_spent = 0
				requirements.min_points_spent_in_group = nil
				requirements.incompatible_talent = "zealot_martyrdom"
			end

			save(node, "children", {})
			save(node, "parents", {})
			save(node, "requirements", requirements)

			if HIDDEN_NODES[node.widget_name] then
				hidden_tables[node] = true
			end
		else
			for _, key in ipairs({ "children", "parents" }) do
				local list = node[key]
				local filtered = list and _without_hidden(list)

				if filtered then
					save(node, key, filtered)
				end
			end
		end
	end

	-- Side groups outwards.
	for _, group in ipairs({ { LEFT_GROUP, -SIDE_GROUP_SHIFT }, { RIGHT_GROUP, SIDE_GROUP_SHIFT } }) do
		for _, widget_name in ipairs(group[1]) do
			local node = by_name[widget_name]

			if node and node.x then
				save(node, "x", node.x + group[2])
			end
		end
	end

	-- Martyrdom augments and the tree below them (Extra.NODES).
	local regen = by_name[NODE_REGEN]
	local martyrdom = by_name[NODE_MARTYRDOM]

	if regen and martyrdom and regen.x and regen.y then
		Extra.layout(nodes, by_name, regen, save)
	end

	-- Cooldown modifiers: no longer one-of-three.
	for _, widget_name in ipairs(CDR_NODES) do
		local node = by_name[widget_name]

		if node and node.requirements and node.requirements.exclusive_group then
			local requirements = table.clone(node.requirements)

			requirements.exclusive_group = nil

			save(node, "requirements", requirements)
		end
	end

	-- The view scrolls only as far as the layout's background_height
	-- (TalentBuilderView._scroll_to_height), so it grows by as much as the
	-- tree now reaches below its official bottom row.
	local layout = require(LAYOUT_PATH)
	local new_lowest_y = lowest_y(true)

	if type(layout) == "table" and layout.background_height and official_lowest_y and new_lowest_y and new_lowest_y > official_lowest_y then
		save(layout, "background_height", layout.background_height + (new_lowest_y - official_lowest_y))
	end

	state.saved = saved
	state.hidden_tables = hidden_tables
end

local function _revert_tree()
	local saved = state.saved

	if not saved then
		return
	end

	for i = #saved, 1, -1 do
		local entry = saved[i]

		entry[1][entry[2]] = entry[3]
	end

	Extra.unlayout()

	state.saved = nil
	state.hidden_tables = nil
end

local function _reset_localization_cache()
	local localization_manager = Managers.localization

	if localization_manager and localization_manager.reset_cache then
		localization_manager:reset_cache()
	end
end

-- Set once the buff templates are loaded (below).
local _refresh_templates = nil

local function _refresh_mode()
	if _wanted(state.host_type) then
		_apply_tree()
	else
		_revert_tree()
	end

	if _refresh_templates then
		_refresh_templates()
	end

	_reset_localization_cache()
end

local function _set_host_type(host_type)
	state.host_type = host_type

	_refresh_mode()
end

-- Same hooks as QIangIQsLegacyTalents: the host type is known when the
-- connection is set, before profiles are synced.
mod:hook_require("scripts/managers/multiplayer/connection_manager", function (ConnectionManager)
	mod:hook(ConnectionManager, "set_connection_client", function (func, self, connection_client, ...)
		local ok, host_type = pcall(function ()
			return connection_client:host_type()
		end)

		if ok then
			_set_host_type(host_type)
		end

		return func(self, connection_client, ...)
	end)

	mod:hook(ConnectionManager, "set_connection_host", function (func, self, connection_host, ...)
		local ok, host_type = pcall(function ()
			return connection_host:host_type()
		end)

		if ok then
			_set_host_type(host_type)
		end

		return func(self, connection_host, ...)
	end)
end)

-- Hidden nodes are not drawn (ui_widget.lua UIWidget.draw passes
-- widget.visible to every pass).
mod:hook_require("scripts/ui/views/talent_builder_view/talent_builder_view", function (TalentBuilderView)
	mod:hook(TalentBuilderView, "_create_node_widget", function (func, self, node)
		local widget = func(self, node)
		local hidden_tables = state.hidden_tables

		if widget and hidden_tables and hidden_tables[node] then
			widget.visible = false
		end

		return widget
	end)
end)

-- Builds saved with a hidden node load without it, in the tree view and in
-- the profile (profile_utils.lua _fill_talents_and_selected_nodes).
mod:hook_require("scripts/ui/views/talent_builder_view/utilities/talent_layout_parser", function (TalentLayoutParser)
	mod:hook(TalentLayoutParser, "unpack_backend_data", function (func, talent_layout, backend_data, node_tiers, ...)
		local result = func(talent_layout, backend_data, node_tiers, ...)

		if state.saved and node_tiers and talent_layout == require(LAYOUT_PATH) and talent_layout.nodes == _modern_nodes() then
			for widget_name in pairs(LOCKED_NODES) do
				node_tiers[widget_name] = nil
			end
		end

		return result
	end)
end)

-- ####################################################################
-- Shared checks
-- ####################################################################

-- Server and local units use PlayerUnitBuffExtension; husks on a client have
-- no buff list (same check as QIangIQsZealotDeflect _has_stance).
-- A reduction r (multiplier 1 - r, or modifier -r) becomes r * DR_SCALE.
local function _scaled_stat(key, value)
	if type(value) ~= "number" then
		return value
	end

	if DR_MULTIPLIER_STATS[key] then
		return 1 - (1 - value) * DR_SCALE
	elseif DR_MODIFIER_STATS[key] then
		return value * DR_SCALE
	end

	return value
end

-- A copy of a stat table with its reductions scaled, and, when convert is
-- set, toughness damage reduction turned into damage reduction.
local function _scaled_stats(stat_table, convert)
	local out = {}

	for key, value in pairs(stat_table) do
		out[convert and TDR_TO_DR_STATS[key] or key] = _scaled_stat(key, value)
	end

	return out
end

local function _has_buff(unit, buff_name)
	local buff_extension = unit and ScriptUnit.has_extension(unit, "buff_system")

	if not buff_extension or not buff_extension.has_buff_using_buff_template then
		return false
	end

	return buff_extension:has_buff_using_buff_template(buff_name)
end

local function _add_timed_buff(unit, buff_name, t)
	local buff_extension = ScriptUnit.has_extension(unit, "buff_system")

	if buff_extension then
		buff_extension:add_internally_controlled_buff(buff_name, t)
	end
end

-- damage.lua sends on_damage_taken to every player on the side, with the
-- hit player in attacked_unit.
local function _own_hit(params, template_context)
	return params.attacked_unit == template_context.unit and (params.damage_amount or 0) > 0
end

local function _heal(unit, amount, heal_type)
	if amount > 0 then
		Health.add(unit, amount, heal_type)
	end
end

-- ####################################################################
-- Toughness removed (server)
-- ####################################################################

local function _empty_toughness(toughness_extension)
	-- _toughness_regen_delay is nil until the first hit (add_damage), and
	-- _update_toughness compares it with t as soon as toughness damage is
	-- above 0, so it needs a value before the first update.
	if toughness_extension._toughness_regen_delay == nil and toughness_extension.set_toughness_regen_delay then
		toughness_extension:set_toughness_regen_delay()
	end

	local max_toughness = toughness_extension:max_toughness()

	if toughness_extension._toughness_damage == max_toughness then
		return
	end

	toughness_extension._toughness_damage = max_toughness

	local game_session = toughness_extension._game_session
	local game_object_id = toughness_extension._game_object_id

	if game_session and game_object_id then
		GameSession.set_game_object_field(game_session, game_object_id, "toughness_damage", math.min(max_toughness, NetworkConstants.toughness.max))
	end
end

local function _reworked_toughness(toughness_extension)
	return toughness_extension._is_server and _has_buff(toughness_extension._unit, BUFF_REWORK)
end

-- Above 0 while a reworked Zealot's talent or ability restores toughness to
-- someone (allies included): that toughness heals instead.
local convert_scope = 0

local function _with_convert_scope(func, ...)
	convert_scope = convert_scope + 1

	local results = { pcall(func, ...) }

	convert_scope = convert_scope - 1

	if not results[1] then
		error(results[2], 0)
	end

	return unpack(results, 2, table.maxn(results))
end

local function _converts(toughness_extension)
	if _reworked_toughness(toughness_extension) then
		return true
	end

	return convert_scope > 0 and toughness_extension._is_server and _is_active()
end

-- A share of max toughness heals the same share of max health, divided by
-- TOUGHNESS_PER_HEALTH (20% toughness heals 2% health).
local function _heal_health_share(unit, share)
	local health_extension = share > 0 and ScriptUnit.has_extension(unit, "health_system")

	if health_extension then
		_heal(unit, share / TOUGHNESS_PER_HEALTH * health_extension:max_health(), heal_types.buff)
	end
end

-- Toughness that would have been restored heals TOUGHNESS_PER_HEALTH : 1, as
-- a share of max toughness turned into the same share of max health.
local function _toughness_to_health(toughness_extension, toughness_amount)
	_empty_toughness(toughness_extension)

	local max_toughness = toughness_extension:max_toughness()

	if toughness_amount > 0 and max_toughness > 0 then
		_heal_health_share(toughness_extension._unit, toughness_amount / max_toughness)
	end
end

-- Same multipliers recover_percentage_toughness and recover_flat_toughness
-- apply (player_unit_toughness_extension.lua).
local function _replenish_multiplier(toughness_extension, ignore_stat_buffs)
	if ignore_stat_buffs then
		return 1
	end

	local stat_buffs_table = toughness_extension._buff_extension:stat_buffs()

	return (stat_buffs_table.toughness_replenish_modifier or 1) * (stat_buffs_table.toughness_replenish_multiplier or 1)
end

mod:hook_require("scripts/extension_systems/toughness/player_unit_toughness_extension", function (PlayerUnitToughnessExtension)
	-- _update_toughness: coherency regen (a base mechanic) plus the
	-- toughness_regen_percent stat that talents and blessings add.
	mod:hook(PlayerUnitToughnessExtension, "update", function (func, self, context, dt, t)
		if not _reworked_toughness(self) then
			return func(self, context, dt, t)
		end

		_empty_toughness(self)

		local before = self._toughness_damage
		local buffs = self._buff_extension:stat_buffs()
		local talent_regen = (buffs.toughness_regen_percent or 0) * self:max_toughness() * dt
		local result = func(self, context, dt, t)
		local regenerated = math.max(before - self._toughness_damage, 0)
		local from_talents = math.min(regenerated, talent_regen)
		local converted = mod:get("convert_base_toughness") and regenerated or from_talents

		_toughness_to_health(self, converted)

		return result
	end)

	-- Toughness.replenish (melee kills, attack.lua): the base amount is a
	-- base mechanic, the part added by toughness_melee_replenish and
	-- toughness_replenish stat buffs comes from talents. Same multiplier as
	-- recover_toughness.
	mod:hook(PlayerUnitToughnessExtension, "recover_toughness", function (func, self, recovery_type, ...)
		if not _reworked_toughness(self) then
			return func(self, recovery_type, ...)
		end

		_empty_toughness(self)

		local recovered = func(self, recovery_type, ...)
		local stat_buffs_table = self._buff_extension:stat_buffs()
		local is_melee_kill = recovery_type == toughness_replenish_types.melee_kill
		local melee_buff = is_melee_kill and stat_buffs_table.toughness_melee_replenish or 1
		local multiplier = (melee_buff + stat_buffs_table.toughness_replenish_modifier - 1) * (stat_buffs_table.toughness_replenish_multiplier or 1)
		local from_talents = multiplier > 1 and recovered * (1 - 1 / multiplier) or 0
		local converted = mod:get("convert_base_toughness") and recovered or from_talents

		_toughness_to_health(self, converted)

		return recovered
	end)

	-- Toughness.replenish_percentage: talents, blessings and abilities
	-- (zealot_buff_templates.lua, zealot_lunge_templates.lua,
	-- action_zealot_channel.lua). The toughness is not restored; the same
	-- share heals instead, also on full toughness.
	mod:hook(PlayerUnitToughnessExtension, "recover_percentage_toughness", function (func, self, fixed_percentage, ignore_stat_buffs, reason, ...)
		if not _converts(self) then
			return func(self, fixed_percentage, ignore_stat_buffs, reason, ...)
		end

		if _reworked_toughness(self) then
			_empty_toughness(self)
		end

		if self:_toughness_regen_disabled(nil, nil, reason) then
			return 0
		end

		_heal_health_share(self._unit, (fixed_percentage or 0) * _replenish_multiplier(self, ignore_stat_buffs))

		return 0
	end)

	-- Toughness.replenish_flat: flat toughness heals 1 health per TOUGHNESS_PER_HEALTH.
	mod:hook(PlayerUnitToughnessExtension, "recover_flat_toughness", function (func, self, amount, ignore_stat_buffs, reason, ...)
		if not _converts(self) then
			return func(self, amount, ignore_stat_buffs, reason, ...)
		end

		if _reworked_toughness(self) then
			_empty_toughness(self)
		end

		if self:_toughness_regen_disabled(nil, nil, reason) then
			return 0
		end

		local heal = (amount or 0) * _replenish_multiplier(self, ignore_stat_buffs) / TOUGHNESS_PER_HEALTH

		_heal(self._unit, heal, heal_types.buff)

		return 0
	end)

	-- recover_max_toughness: stances and getting up from knocked down.
	mod:hook(PlayerUnitToughnessExtension, "recover_max_toughness", function (func, self, ...)
		if not _reworked_toughness(self) then
			return func(self, ...)
		end

		_empty_toughness(self)

		local recovered = func(self, ...)

		_toughness_to_health(self, mod:get("convert_base_toughness") and recovered or 0)

		return recovered
	end)
end)

-- Bolstering Prayer restores toughness to everyone in coherency each frame
-- and each pulse (action_zealot_channel.lua fixed_update, _on_channel_tick).
mod:hook_require("scripts/extension_systems/weapon/actions/action_zealot_channel", function (ActionZealotChannel)
	mod:hook(ActionZealotChannel, "fixed_update", function (func, self, ...)
		if self._is_server and _has_buff(self._player_unit, BUFF_REWORK) then
			return _with_convert_scope(func, self, ...)
		end

		return func(self, ...)
	end)
end)

-- Buffs the tree adds while the rework is on (player_unit_buff_extension.lua):
-- the Bolstering Prayer bonus toughness heals instead, at TOUGHNESS_PER_HEALTH
-- toughness to 1 health.
mod:hook_require("scripts/extension_systems/buff/player_unit_buff_extension", function (PlayerUnitBuffExtension)
	mod:hook(PlayerUnitBuffExtension, "add_internally_controlled_buff", function (func, self, template_name, t, ...)
		if self._is_server and _is_active() then
			local template = BuffTemplates[template_name]
			local bonus_toughness = convert_scope > 0 and template and template.stat_buffs and template.stat_buffs[stat_buffs.toughness_bonus_flat]

			if bonus_toughness then
				_heal(self._unit, bonus_toughness / TOUGHNESS_PER_HEALTH, heal_types.buff)

				return
			end
		end

		return func(self, template_name, t, ...)
	end)
end)

-- Toughness damage reduction becomes damage reduction: the same toughness
-- stat buffs _calculate_toughness_damage_player reads
-- (damage_taken_calculation.lua) scale the damage before it reaches health.
local function _toughness_damage_reduction(stat_buffs_table, attack_type)
	local multiplier = stat_buffs_table.toughness_damage_taken_multiplier or 1
	local modifier = stat_buffs_table.toughness_damage_taken_modifier or 1

	if attack_type == attack_types.melee then
		multiplier = multiplier * (stat_buffs_table.melee_toughness_damage_taken_multiplier or 1)
		modifier = modifier + (stat_buffs_table.melee_toughness_damage_taken_modifier or 1) - 1
	elseif attack_type == attack_types.ranged then
		multiplier = multiplier * (stat_buffs_table.ranged_toughness_damage_taken_multiplier or 1)
		modifier = modifier + (stat_buffs_table.ranged_toughness_damage_taken_modifier or 1) - 1
	end

	return math.max(multiplier * modifier, 0)
end

mod:hook_require("scripts/utilities/attack/damage_taken_calculation", function (DamageTakenCalculation)
	mod:hook(DamageTakenCalculation, "calculate_attack_result", function (func, damage_amount, damage_profile, attack_type, attack_direction, instakill, ...)
		-- Arguments 18 and 20: attacked_unit_stat_buffs, attacked_unit.
		local attacked_unit_stat_buffs = select(13, ...)
		local attacked_unit = select(15, ...)

		-- Only hits toughness would have taken (_calculate_toughness_damage).
		if damage_amount and damage_amount > 0 and not instakill and attacked_unit_stat_buffs and damage_profile and not damage_profile.ignore_toughness and _has_buff(attacked_unit, BUFF_REWORK) then
			damage_amount = damage_amount * _toughness_damage_reduction(attacked_unit_stat_buffs, attack_type)
		end

		return func(damage_amount, damage_profile, attack_type, attack_direction, instakill, ...)
	end)
end)

-- ####################################################################
-- Zealot passive: melee attacks gain ADM
-- ####################################################################

local adm_override = {
	active = false,
}

mod:hook_require("scripts/utilities/attack/damage_calculation", function (DamageCalculation)
	mod:hook(DamageCalculation, "calculate", function (func, ...)
		-- Arguments 17 and 20: attack_type, attacker_buff_extension.
		local attack_type = select(17, ...)
		local attacker_buff_extension = select(20, ...)

		if attack_type ~= attack_types.melee or not attacker_buff_extension or not attacker_buff_extension.has_buff_using_buff_template or not attacker_buff_extension:has_buff_using_buff_template(BUFF_ADM) then
			return func(...)
		end

		adm_override.active = true

		local results = { pcall(func, ...) }

		adm_override.active = false

		if not results[1] then
			error(results[2], 0)
		end

		return unpack(results, 2, table.maxn(results))
	end)
end)

mod:hook_require("scripts/utilities/attack/damage_profile", function (DamageProfile)
	mod:hook(DamageProfile, "armor_damage_modifier", function (func, power_type, damage_profile, target_settings, damage_profile_lerp_values, armor_type, ...)
		local armor_damage_modifier = func(power_type, damage_profile, target_settings, damage_profile_lerp_values, armor_type, ...)

		if not adm_override.active or power_type ~= "attack" or damage_profile.is_push then
			return armor_damage_modifier
		end

		-- damage_calculation.lua treats a 0 ADM on non super armor as a push;
		-- that stays as it is.
		if armor_damage_modifier == 0 and armor_type ~= "super_armor" then
			return armor_damage_modifier
		end

		if armor_damage_modifier < ADM_CAP then
			return math.min(armor_damage_modifier + ADM_BONUS, ADM_CAP)
		end

		return armor_damage_modifier
	end)
end)

-- ####################################################################
-- Buff templates
-- ####################################################################

local HUD_GRADIENT_KEYSTONE = "content/ui/textures/color_ramps/talent_keystone"
local HUD_GRADIENT_DEFAULT = "content/ui/textures/color_ramps/talent_default"

local function _templates()
	local templates = {}

	-- Class passive: no toughness (the hooks above keep it at 0).
	templates[BUFF_REWORK] = {
		class_name = "buff",
		predicted = false,
		start_func = function (template_data, template_context)
			if not template_context.is_server then
				return
			end

			local toughness_extension = ScriptUnit.has_extension(template_context.unit, "toughness_system")

			if toughness_extension and toughness_extension.max_toughness then
				_empty_toughness(toughness_extension)
			end
		end,
	}

	-- Martyrdom: 1% of melee damage dealt heals, the way
	-- zealot_resist_death_leech_effect reads params.damage from
	-- on_damage_dealt.
	templates[BUFF_LIFESTEAL] = {
		class_name = "proc_buff",
		predicted = false,
		proc_events = {
			[proc_events.on_damage_dealt] = 1,
		},
		check_proc_func = function (params, template_data, template_context)
			return params.attack_type == attack_types.melee and (params.damage or 0) > 0
		end,
		proc_func = function (params, template_data, template_context)
			if template_context.is_server then
				_heal(template_context.unit, params.damage * MELEE_LIFESTEAL, heal_types.leech)
			end
		end,
	}

	-- Martyrdom: attack speed scales with missing health, +0% at full health
	-- to +100% (double) near 0. Lerped like zealot_martyrdom_toughness, with
	-- current_health_percent the way zealot_combat_ability_cd_restore_on_damage
	-- reads it.
	templates[BUFF_LOW_HEALTH_SPEED] = {
		class_name = "buff",
		max_stacks = 1,
		max_stacks_cap = 1,
		predicted = false,
		lerped_stat_buffs = {
			[stat_buffs.attack_speed] = {
				min = 0,
				max = LOW_HEALTH_ATTACK_SPEED,
			},
		},
		start_func = function (template_data, template_context)
			template_data.health_extension = ScriptUnit.has_extension(template_context.unit, "health_system")
		end,
		lerp_t_func = function (t, start_time, duration, template_data, template_context)
			local health_extension = template_data.health_extension

			if not health_extension or not health_extension.current_health_percent then
				return 0
			end

			return math.clamp01(1 - health_extension:current_health_percent())
		end,
	}

	-- Subnode: 1 health per second. interval_buff like
	-- zealot_preacher_coherency_corruption_healing, healing with the heal type
	-- zealot_heal_part_of_damage_taken uses.
	templates[BUFF_REGEN] = {
		class_name = "interval_buff",
		interval = 1,
		max_stacks = 1,
		max_stacks_cap = 1,
		predicted = false,
		interval_func = function (template_data, template_context, template)
			if template_context.is_server then
				_heal(template_context.unit, HEALTH_REGEN_PER_SECOND, heal_types.heal_over_time_tick)
			end
		end,
	}

	-- Subnode: taking or dodging a hit gives attack speed. Same shape as
	-- zealot_flame_grenade_thrown (a proc buff adding a timed buff).
	templates[BUFF_HIT_SPEED] = {
		class_name = "proc_buff",
		predicted = false,
		proc_events = {
			[proc_events.on_damage_taken] = 1,
			[proc_events.on_successful_dodge] = 1,
		},
		specific_check_proc_funcs = {
			[proc_events.on_damage_taken] = function (params, template_data, template_context)
				return _own_hit(params, template_context) and params.attack_type ~= attack_types.buff
			end,
			[proc_events.on_successful_dodge] = function (params, template_data, template_context)
				return params.dodging_unit == template_context.unit
			end,
		},
		proc_func = function (params, template_data, template_context, t)
			if template_context.is_server then
				_add_timed_buff(template_context.unit, BUFF_HIT_SPEED_ACTIVE, t)
			end
		end,
	}
	templates[BUFF_HIT_SPEED_ACTIVE] = {
		class_name = "buff",
		duration = HIT_ATTACK_SPEED_DURATION,
		hud_icon = "content/ui/textures/icons/buffs/hud/zealot/zealot_improved_weapon_handling_after_dodge",
		hud_icon_gradient_map = HUD_GRADIENT_KEYSTONE,
		hud_priority = 3,
		max_stacks = 1,
		predicted = false,
		refresh_duration_on_stack = true,
		stat_buffs = {
			[stat_buffs.attack_speed] = HIT_ATTACK_SPEED,
		},
	}

	-- Subnode: on combat ability start (on_combat_ability, the event
	-- zealot_toughness_on_combat_ability uses) +100% cleave and +50% melee
	-- damage. Cleave = the two hit mass stats the game's cleave buffs raise.
	templates[BUFF_ABILITY] = {
		class_name = "proc_buff",
		predicted = false,
		proc_events = {
			[proc_events.on_combat_ability] = 1,
		},
		proc_func = function (params, template_data, template_context, t)
			if template_context.is_server then
				_add_timed_buff(template_context.unit, BUFF_ABILITY_ACTIVE, t)
			end
		end,
	}
	-- Same fields as zealot_channel_damage.
	templates[BUFF_ABILITY_ACTIVE] = {
		class_name = "buff",
		duration = ABILITY_DURATION,
		hud_icon = "content/ui/textures/icons/buffs/hud/zealot/zealot_channel_grants_damage",
		hud_icon_gradient_map = HUD_GRADIENT_KEYSTONE,
		hud_priority = 1,
		max_stacks = 1,
		predicted = false,
		refresh_duration_on_stack = true,
		stat_buffs = {
			[stat_buffs.max_hit_mass_attack_modifier] = ABILITY_CLEAVE,
			[stat_buffs.max_hit_mass_impact_modifier] = ABILITY_CLEAVE,
			[stat_buffs.melee_damage] = ABILITY_MELEE_DAMAGE,
		},
	}

	-- Subnode: melee kills heal corruption. add_heal with
	-- buff_corruption_healing (action_zealot_channel.lua) is not held at the
	-- wound boundary the way reduce_permanent_damage is
	-- (player_unit_health_extension.lua), so it heals across wounds.
	templates[BUFF_CLEANSE] = {
		class_name = "proc_buff",
		predicted = false,
		proc_events = {
			[proc_events.on_kill] = 1,
		},
		check_proc_func = CheckProcFunctions.on_melee_kill,
		proc_func = function (params, template_data, template_context)
			if not template_context.is_server then
				return
			end

			local health_extension = ScriptUnit.has_extension(template_context.unit, "health_system")

			if not health_extension then
				return
			end

			local amount = CLEANSE_MELEE_KILL

			if params.hit_weakspot and params.is_critical_strike then
				amount = CLEANSE_WEAKSPOT_CRIT_KILL
			elseif params.hit_weakspot or params.is_critical_strike then
				amount = CLEANSE_WEAKSPOT_OR_CRIT_KILL
			end

			health_extension:add_heal(amount, heal_types.buff_corruption_healing)
		end,
	}

	-- Until Death replacement: damage reduction equal to the net share of max
	-- health lost over the last UNTIL_DEATH_WINDOW seconds, which is the
	-- highest health in that window minus current health. Healing lowers it,
	-- so taking a hit, healing it back and taking another counts once.
	-- The window keeps a falling run of health samples (sliding maximum).
	-- damage_taken_multiplier is a multiplicative stat (buff_settings.lua), so
	-- it stacks on top of the rest of the player's damage reduction. Lerped
	-- like zealot_martyrdom_toughness.
	templates[BUFF_UNTIL_DEATH] = {
		class_name = "buff",
		hud_always_show_stacks = true,
		hud_icon = "content/ui/textures/icons/buffs/hud/zealot/zealot_resist_death",
		hud_icon_gradient_map = HUD_GRADIENT_KEYSTONE,
		hud_priority = 2,
		predicted = false,
		lerped_stat_buffs = {
			[stat_buffs.damage_taken_multiplier] = {
				min = 1,
				max = 0,
			},
		},
		start_func = function (template_data, template_context)
			template_data.samples = {}
			template_data.first = 1
			template_data.last = 0
			template_data.reduction = 0
			template_data.health_extension = ScriptUnit.has_extension(template_context.unit, "health_system")
		end,
		update_func = function (template_data, template_context, dt, t)
			local health_extension = template_data.health_extension
			local samples = template_data.samples

			if not health_extension or not samples then
				return
			end

			local max_health = health_extension:max_health()

			if not max_health or max_health <= 0 then
				template_data.reduction = 0

				return
			end

			local health = health_extension:current_health()
			local first, last = template_data.first, template_data.last

			-- Samples at or below the current health can never be the peak again.
			while last >= first and samples[last].health <= health do
				samples[last] = nil
				last = last - 1
			end

			last = last + 1
			samples[last] = {
				health = health,
				t = t,
			}

			while samples[first].t < t - UNTIL_DEATH_WINDOW do
				samples[first] = nil
				first = first + 1
			end

			template_data.first, template_data.last = first, last

			local net_loss = (samples[first].health - health) / max_health
			local cap = (mod:get("until_death_cap") or 100) / 100

			template_data.reduction = math.clamp(net_loss, 0, cap) * DR_SCALE
		end,
		lerp_t_func = function (t, start_time, duration, template_data, template_context)
			return template_data.reduction or 0
		end,
		visual_stack_count = function (template_data, template_context)
			return math.floor((template_data.reduction or 0) * 100 + 0.5)
		end,
	}

	-- Backstab modifier as in 1.6.1: backstab kills restore
	-- LEGACY_BACKSTAB_CD of the combat ability. The 1.6.1 talent used this
	-- template; only the restored share differs from the current game's copy.
	local backstab = BuffTemplates.zealot_ability_cooldown_on_leaving_coherency_on_backstab

	if backstab then
		local legacy_backstab = table.clone(backstab)

		legacy_backstab.proc_func = function (params, template_data, template_context)
			local ability_extension = template_data.ability_extension

			ability_extension:restore_ability_charge_percentage("combat_ability", LEGACY_BACKSTAB_CD)

			local t = FixedFrame.get_latest_fixed_time()

			template_data.next_proc_t = t + 0.2
		end

		templates[BUFF_BACKSTAB_CD] = legacy_backstab
	end

	-- Middle augment: a monstrosity kill (breed tag monster, like
	-- CheckProcFunctions.on_elite_kill checks elite) heals over time.
	templates[BUFF_MONSTER_HEAL] = {
		class_name = "proc_buff",
		predicted = false,
		proc_events = {
			[proc_events.on_kill] = 1,
		},
		check_proc_func = function (params, template_data, template_context)
			return CheckProcFunctions.on_kill(params, template_data, template_context) and params.tags and params.tags.monster and true or false
		end,
		proc_func = function (params, template_data, template_context, t)
			if template_context.is_server then
				_add_timed_buff(template_context.unit, BUFF_MONSTER_HEAL_ACTIVE, t or FixedFrame.get_latest_fixed_time())
			end
		end,
	}

	-- MONSTER_HEAL_SHARE of max health spread evenly over the duration;
	-- another monstrosity kill restarts it.
	templates[BUFF_MONSTER_HEAL_ACTIVE] = {
		class_name = "buff",
		duration = MONSTER_HEAL_DURATION,
		hud_icon = "content/ui/textures/icons/buffs/hud/zealot/zealot_resist_death",
		hud_icon_gradient_map = HUD_GRADIENT_KEYSTONE,
		hud_priority = 3,
		max_stacks = 1,
		predicted = false,
		refresh_duration_on_stack = true,
		start_func = function (template_data, template_context)
			template_data.health_extension = ScriptUnit.has_extension(template_context.unit, "health_system")
		end,
		update_func = function (template_data, template_context, dt, t)
			local health_extension = template_data.health_extension

			if not template_context.is_server or not health_extension or not dt or dt <= 0 then
				return
			end

			_heal(template_context.unit, health_extension:max_health() * MONSTER_HEAL_SHARE / MONSTER_HEAL_DURATION * dt, heal_types.heal_over_time_tick)
		end,
	}

	-- Right augment: health lost gives reserve ammo (Ammo.add_to_all_slots,
	-- as veteran_survivalist_passive uses it).
	templates[BUFF_AMMO_ON_LOSS] = {
		class_name = "proc_buff",
		predicted = false,
		proc_events = {
			[proc_events.on_damage_taken] = 1,
		},
		check_proc_func = function (params, template_data, template_context)
			return _own_hit(params, template_context)
		end,
		proc_func = function (params, template_data, template_context)
			if not template_context.is_server then
				return
			end

			local unit = template_context.unit
			local health_extension = ScriptUnit.has_extension(unit, "health_system")
			local max_health = health_extension and health_extension:max_health()

			if max_health and max_health > 0 then
				Ammo.add_to_all_slots(unit, params.damage_amount / max_health * AMMO_PER_HEALTH_LOST)
			end
		end,
	}

	-- Health node: marker the max_health hook checks for.
	templates[BUFF_HEALTH_NODE] = {
		class_name = "buff",
		predicted = false,
	}

	-- Stat node copy with every tier's reduction scaled.
	local stat_node = BuffTemplates[STAT_NODE_BUFF]

	if stat_node then
		local dr_node = table.clone(stat_node)
		local overrides = {}

		dr_node.stat_buffs = _scaled_stats(stat_node.stat_buffs or {}, false)

		for i, override in ipairs(stat_node.talent_overrides or {}) do
			overrides[i] = {
				stat_buffs = _scaled_stats(override.stat_buffs or {}, false),
			}
		end

		dr_node.talent_overrides = stat_node.talent_overrides and overrides or nil

		templates[BUFF_DR_NODE] = dr_node
	end

	-- Zealot passive: marker the ADM hook checks for.
	templates[BUFF_ADM] = {
		class_name = "buff",
		predicted = false,
	}

	-- Zealot passive: elite kills (CheckProcFunctions.on_elite_kill) give
	-- ranged damage reduction stacks. Taking a ranged hit starts a
	-- ELITE_RANGED_CLEAR_DELAY timer, then all stacks go.
	templates[BUFF_ELITE_RANGED] = {
		class_name = "proc_buff",
		hud_always_show_stacks = true,
		hud_icon = "content/ui/textures/icons/buffs/hud/zealot/zealot_elite_kills_empowers",
		hud_icon_gradient_map = HUD_GRADIENT_DEFAULT,
		hud_priority = 4,
		predicted = false,
		proc_events = {
			[proc_events.on_kill] = 1,
			[proc_events.on_damage_taken] = 1,
		},
		lerped_stat_buffs = {
			[stat_buffs.ranged_damage_taken_multiplier] = {
				min = 1,
				max = 1 - ELITE_RANGED_DR_PER_STACK * ELITE_RANGED_MAX_STACKS,
			},
		},
		start_func = function (template_data, template_context)
			template_data.stacks = 0
			template_data.clear_at = nil
		end,
		specific_check_proc_funcs = {
			[proc_events.on_kill] = CheckProcFunctions.on_elite_kill,
			[proc_events.on_damage_taken] = function (params, template_data, template_context)
				return _own_hit(params, template_context) and params.attack_type == attack_types.ranged
			end,
		},
		specific_proc_func = {
			[proc_events.on_kill] = function (params, template_data, template_context, t)
				template_data.stacks = math.min((template_data.stacks or 0) + 1, ELITE_RANGED_MAX_STACKS)
			end,
			[proc_events.on_damage_taken] = function (params, template_data, template_context, t)
				if (template_data.stacks or 0) > 0 and not template_data.clear_at then
					template_data.clear_at = t + ELITE_RANGED_CLEAR_DELAY
				end
			end,
		},
		update_func = function (template_data, template_context, dt, t)
			local clear_at = template_data.clear_at

			if clear_at and clear_at <= t then
				template_data.stacks = 0
				template_data.clear_at = nil
			end
		end,
		lerp_t_func = function (t, start_time, duration, template_data, template_context)
			return math.clamp01((template_data.stacks or 0) / ELITE_RANGED_MAX_STACKS)
		end,
		visual_stack_count = function (template_data, template_context)
			return template_data.stacks or 0
		end,
	}

	return templates
end

-- Same as QIangIQsZealotDeflect _append_lookup: new names go at the end so
-- every existing id keeps its index.
local function _append_lookup(lookup_name, name)
	local NetworkLookup = rawget(_G, "NetworkLookup") or require("scripts/network_lookup/network_lookup")
	local lookup = NetworkLookup[lookup_name]

	if not lookup then
		mod:error("NetworkLookup.%s is missing", lookup_name)

		return
	end

	if rawget(lookup, name) == nil then
		local index = #lookup + 1

		rawset(lookup, index, name)
		rawset(lookup, name, index)
	end
end

-- ####################################################################
-- Extra Martyrdom augments (buffs, talents, layout)
-- ####################################################################

-- The buffs of the extra talents. Every one is a server buff (predicted =
-- false). Healing uses the same Health.add as the rest of this mod; events
-- and check functions are the ones the game's own Zealot buffs use
-- (zealot_buff_templates.lua, check_proc_functions.lua).
Extra.templates = function ()
	local N = Extra.N
	local templates = {}

	local function health_percent(template_data)
		local health_extension = template_data.health_extension

		if health_extension and health_extension.current_health_percent then
			return health_extension:current_health_percent()
		end

		return 1
	end

	local function start_health(template_data, template_context)
		template_data.health_extension = ScriptUnit.has_extension(template_context.unit, "health_system")
		template_data.coherency_extension = ScriptUnit.has_extension(template_context.unit, "coherency_system")
	end

	local function heal_share(unit, share, heal_type)
		local health_extension = ScriptUnit.has_extension(unit, "health_system")

		if health_extension then
			_heal(unit, health_extension:max_health() * share, heal_type or heal_types.buff)
		end
	end

	-- Allies in Coherency, not counting the player.
	local function allies(template_data, template_context)
		local out = {}
		local coherency_extension = template_data.coherency_extension

		if coherency_extension then
			for unit in pairs(coherency_extension:in_coherence_units()) do
				if unit ~= template_context.unit and ALIVE[unit] then
					out[#out + 1] = unit
				end
			end
		end

		return out
	end

	local function stat_table(stat, value)
		return {
			[stat_buffs[stat]] = value,
		}
	end

	-- A timed, stacking buff added by another buff's proc.
	local function timed(key, duration, max_stacks, stats)
		templates[Extra.name(key)] = {
			class_name = "buff",
			duration = duration,
			max_stacks = max_stacks,
			max_stacks_cap = max_stacks,
			predicted = false,
			refresh_duration_on_stack = true,
			stat_buffs = stats,
		}
	end

	local function add_timed(template_context, key, t)
		if template_context.is_server then
			_add_timed_buff(template_context.unit, Extra.name(key), t or FixedFrame.get_latest_fixed_time())
		end
	end

	-- Ability side ----------------------------------------------------

	-- Martyr's Resolve: the combat ability heals a share of the missing health.
	templates[Extra.name("mr")] = {
		class_name = "proc_buff",
		predicted = false,
		proc_events = {
			[proc_events.on_combat_ability] = 1,
		},
		proc_func = function (params, template_data, template_context)
			local unit = template_context.unit
			local health_extension = ScriptUnit.has_extension(unit, "health_system")

			if template_context.is_server and health_extension then
				_heal(unit, (health_extension:max_health() - health_extension:current_health()) * N.MR_MISSING_HEAL, heal_types.buff)
			end
		end,
	}

	-- Pain Is a Gift: ability cooldown regeneration scales with missing
	-- health, lerped like BUFF_LOW_HEALTH_SPEED.
	templates[Extra.name("pg")] = {
		class_name = "buff",
		max_stacks = 1,
		max_stacks_cap = 1,
		predicted = false,
		lerped_stat_buffs = {
			[stat_buffs.combat_ability_resource_regen_modifier] = {
				min = 0,
				max = N.PG_MAX,
			},
		},
		start_func = start_health,
		lerp_t_func = function (t, start_time, duration, template_data, template_context)
			return math.clamp01(1 - health_percent(template_data))
		end,
	}

	-- Triage
	templates[Extra.name("tri")] = {
		class_name = "buff",
		predicted = false,
		stat_buffs = stat_table("healing_recieved_modifier", N.TRIAGE),
	}

	-- Blood Frenzy: elite kills give stacking attack speed and a small heal.
	templates[Extra.name("bf")] = {
		class_name = "proc_buff",
		predicted = false,
		proc_events = {
			[proc_events.on_kill] = 1,
		},
		check_proc_func = CheckProcFunctions.on_elite_kill,
		proc_func = function (params, template_data, template_context, t)
			if template_context.is_server then
				add_timed(template_context, "bf_stack", t)
				heal_share(template_context.unit, N.BF_HEAL)
			end
		end,
	}
	timed("bf_stack", N.BF_DURATION, N.BF_STACKS, stat_table("attack_speed", N.BF_SPEED))

	-- Penance Pulse: the combat ability heals allies in Coherency.
	templates[Extra.name("pp")] = {
		class_name = "proc_buff",
		predicted = false,
		proc_events = {
			[proc_events.on_combat_ability] = 1,
		},
		start_func = start_health,
		proc_func = function (params, template_data, template_context)
			if template_context.is_server then
				for _, ally in ipairs(allies(template_data, template_context)) do
					heal_share(ally, N.PP_HEAL)
				end
			end
		end,
	}

	-- Last Rites: the ability used at low health makes the next seconds
	-- much safer, at most once per LR_COOLDOWN.
	templates[Extra.name("lr")] = {
		class_name = "proc_buff",
		predicted = false,
		active_duration = N.LR_DURATION,
		cooldown_duration = N.LR_COOLDOWN,
		proc_events = {
			[proc_events.on_combat_ability] = 1,
		},
		proc_stat_buffs = stat_table("damage_taken_multiplier", N.LR_MULT),
		start_func = start_health,
		check_proc_func = function (params, template_data, template_context)
			return health_percent(template_data) < N.LR_HEALTH
		end,
	}

	-- Field Medic: assisting an ally heals the helper (on_player_assist_done
	-- goes to the interactor's buff extension, assist.lua).
	templates[Extra.name("fm")] = {
		class_name = "proc_buff",
		predicted = false,
		proc_events = {
			[proc_events.on_player_assist_done] = 1,
		},
		check_proc_func = function (params, template_data, template_context)
			return params.interactor_unit == template_context.unit
		end,
		proc_func = function (params, template_data, template_context)
			if template_context.is_server then
				heal_share(template_context.unit, N.FM_HEAL)
			end
		end,
	}

	-- Relentless: a big hit grants stun immunity.
	templates[Extra.name("rel")] = {
		class_name = "proc_buff",
		predicted = false,
		active_duration = N.REL_DURATION,
		cooldown_duration = N.REL_COOLDOWN,
		proc_events = {
			[proc_events.on_damage_taken] = 1,
		},
		proc_keywords = {
			keywords.stun_immune,
		},
		start_func = start_health,
		check_proc_func = function (params, template_data, template_context)
			local health_extension = template_data.health_extension

			return _own_hit(params, template_context) and health_extension and params.damage_amount >= health_extension:max_health() * N.REL_HIT
		end,
	}

	-- Crimson Rush
	templates[Extra.name("cr")] = {
		class_name = "proc_buff",
		predicted = false,
		proc_events = {
			[proc_events.on_combat_ability] = 1,
		},
		proc_func = function (params, template_data, template_context, t)
			add_timed(template_context, "cr_active", t)
		end,
	}
	timed("cr_active", N.CR_DURATION, 1, stat_table("movement_speed", N.CR_SPEED))

	-- Adrenal Rush: speed at low health.
	templates[Extra.name("ar")] = {
		class_name = "buff",
		predicted = false,
		conditional_stat_buffs = {
			[stat_buffs.movement_speed] = N.AR_MOVE,
			[stat_buffs.attack_speed] = N.AR_ATTACK,
		},
		start_func = start_health,
		conditional_stat_buffs_func = function (template_data, template_context)
			return health_percent(template_data) < N.AR_HEALTH
		end,
	}

	-- Pilgrim's Stride: dodges heal.
	templates[Extra.name("ps")] = {
		class_name = "proc_buff",
		predicted = false,
		proc_events = {
			[proc_events.on_successful_dodge] = 1,
		},
		check_proc_func = function (params, template_data, template_context)
			return params.dodging_unit == template_context.unit
		end,
		proc_func = function (params, template_data, template_context)
			if template_context.is_server then
				heal_share(template_context.unit, N.PS_HEAL)
			end
		end,
	}

	-- Monstrosity side ------------------------------------------------

	-- Emperor's Gaze: melee hits on monsters and captains reduce damage taken.
	templates[Extra.name("eg")] = {
		class_name = "proc_buff",
		predicted = false,
		active_duration = N.EG_DURATION,
		proc_events = {
			[proc_events.on_hit] = 1,
		},
		proc_stat_buffs = stat_table("damage_taken_multiplier", N.EG_MULT),
		check_proc_func = CheckProcFunctions.combine(CheckProcFunctions.on_melee_hit, CheckProcFunctions.on_monster_or_captain_hit),
	}

	-- Field Dressing: a big hit starts a heal over time.
	templates[Extra.name("fd")] = {
		class_name = "proc_buff",
		predicted = false,
		cooldown_duration = N.FD_COOLDOWN,
		proc_events = {
			[proc_events.on_damage_taken] = 1,
		},
		start_func = start_health,
		check_proc_func = function (params, template_data, template_context)
			local health_extension = template_data.health_extension

			return _own_hit(params, template_context) and health_extension and params.damage_amount >= health_extension:max_health() * N.FD_HIT
		end,
		proc_func = function (params, template_data, template_context, t)
			add_timed(template_context, "fd_heal", t)
		end,
	}
	templates[Extra.name("fd_heal")] = {
		class_name = "buff",
		duration = N.FD_DURATION,
		max_stacks = 1,
		max_stacks_cap = 1,
		predicted = false,
		refresh_duration_on_stack = true,
		start_func = start_health,
		update_func = function (template_data, template_context, dt, t)
			local health_extension = template_data.health_extension

			if template_context.is_server and health_extension and dt and dt > 0 then
				_heal(template_context.unit, health_extension:max_health() * N.FD_SHARE / N.FD_DURATION * dt, heal_types.heal_over_time_tick)
			end
		end,
	}

	-- Unbowed: regeneration at low health.
	templates[Extra.name("ub")] = {
		class_name = "interval_buff",
		interval = 1,
		max_stacks = 1,
		max_stacks_cap = 1,
		predicted = false,
		start_func = start_health,
		interval_func = function (template_data, template_context, template)
			if template_context.is_server and health_percent(template_data) < N.UB_HEALTH then
				_heal(template_context.unit, N.UB_REGEN, heal_types.heal_over_time_tick)
			end
		end,
	}

	-- Health spine ----------------------------------------------------

	-- Scar Tissue: dropping below the threshold adds a permanent stack that
	-- the max_health hook counts. It re-arms above ST_RESET.
	templates[Extra.name("st")] = {
		class_name = "buff",
		predicted = false,
		start_func = function (template_data, template_context)
			start_health(template_data, template_context)
			template_data.armed = true
		end,
		update_func = function (template_data, template_context, dt, t)
			if not template_context.is_server then
				return
			end

			local percent = health_percent(template_data)

			if percent >= N.ST_RESET then
				template_data.armed = true
			elseif template_data.armed and percent < N.ST_THRESHOLD then
				template_data.armed = false

				local buff_extension = ScriptUnit.has_extension(template_context.unit, "buff_system")

				if buff_extension and buff_extension:current_stacks(Extra.name("st_stack")) < N.ST_STACKS then
					_add_timed_buff(template_context.unit, Extra.name("st_stack"), t)
				end
			end
		end,
	}
	templates[Extra.name("st_stack")] = {
		class_name = "buff",
		max_stacks = N.ST_STACKS,
		max_stacks_cap = N.ST_STACKS,
		predicted = false,
	}

	-- Second Chance: Until Death's cheat death (zealot_resist_death) with its
	-- own numbers and a heal.
	local resist_death = BuffTemplates.zealot_resist_death

	if resist_death then
		local second_chance = table.clone(resist_death)

		second_chance.start_func = nil
		second_chance.related_talents = nil
		second_chance.active_duration = N.SC_ACTIVE
		second_chance.cooldown_duration = N.SC_COOLDOWN
		second_chance.proc_events = {
			[proc_events.on_damage_taken] = 1,
		}
		second_chance.proc_func = function (params, template_data, template_context)
			if template_context.is_server then
				heal_share(template_context.unit, N.SC_HEAL)
			end
		end

		templates[Extra.name("sc")] = second_chance
	end

	-- Catch Your Breath: regeneration after a calm spell.
	templates[Extra.name("cyb")] = {
		class_name = "proc_buff",
		predicted = false,
		proc_events = {
			[proc_events.on_damage_taken] = 1,
		},
		start_func = function (template_data, template_context)
			template_data.last_hit = FixedFrame.get_latest_fixed_time()
		end,
		check_proc_func = function (params, template_data, template_context)
			return _own_hit(params, template_context)
		end,
		proc_func = function (params, template_data, template_context, t)
			template_data.last_hit = t
		end,
		update_func = function (template_data, template_context, dt, t)
			if template_context.is_server and dt and dt > 0 and t - (template_data.last_hit or t) >= N.CYB_DELAY then
				_heal(template_context.unit, N.CYB_REGEN * dt, heal_types.heal_over_time_tick)
			end
		end,
	}

	-- Fortress of Flesh and Berserker's Toll
	templates[Extra.name("fof")] = {
		class_name = "buff",
		predicted = false,
		stat_buffs = {
			[stat_buffs.max_health_modifier] = N.FOF_HEALTH,
			[stat_buffs.movement_speed] = N.FOF_MOVE,
		},
	}
	templates[Extra.name("bt")] = {
		class_name = "buff",
		predicted = false,
		stat_buffs = {
			[stat_buffs.max_health_modifier] = N.BT_HEALTH,
			[stat_buffs.melee_damage] = N.BT_MELEE,
		},
	}

	-- Coherency side --------------------------------------------------

	-- Hold the Line: less damage taken per ally in Coherency.
	templates[Extra.name("htl")] = {
		class_name = "buff",
		max_stacks = 1,
		max_stacks_cap = 1,
		predicted = false,
		lerped_stat_buffs = {
			[stat_buffs.damage_taken_multiplier] = {
				min = 1,
				max = 1 - N.HTL_PER_ALLY * N.HTL_ALLIES,
			},
		},
		start_func = function (template_data, template_context)
			start_health(template_data, template_context)
			template_data.allies = 0
		end,
		update_func = function (template_data, template_context, dt, t)
			template_data.allies = #allies(template_data, template_context)
		end,
		lerp_t_func = function (t, start_time, duration, template_data, template_context)
			return math.clamp01((template_data.allies or 0) / N.HTL_ALLIES)
		end,
	}

	-- Litany of Fortitude: more health near allies.
	templates[Extra.name("lit")] = {
		class_name = "buff",
		predicted = false,
		conditional_stat_buffs = stat_table("max_health_modifier", N.LIT_HEALTH),
		start_func = function (template_data, template_context)
			start_health(template_data, template_context)
			template_data.allies = 0
		end,
		update_func = function (template_data, template_context, dt, t)
			template_data.allies = #allies(template_data, template_context)
		end,
		conditional_stat_buffs_func = function (template_data, template_context)
			return (template_data.allies or 0) >= N.LIT_ALLIES
		end,
	}

	-- Sanguine Tithe: elite kills heal allies.
	templates[Extra.name("sang")] = {
		class_name = "proc_buff",
		predicted = false,
		proc_events = {
			[proc_events.on_kill] = 1,
		},
		start_func = start_health,
		check_proc_func = CheckProcFunctions.on_elite_kill,
		proc_func = function (params, template_data, template_context)
			if template_context.is_server then
				for _, ally in ipairs(allies(template_data, template_context)) do
					heal_share(ally, N.SANG_HEAL)
				end
			end
		end,
	}

	-- Pain side -------------------------------------------------------

	-- Bleed for the Emperor: melee damage taken gives melee damage.
	templates[Extra.name("bfe")] = {
		class_name = "proc_buff",
		predicted = false,
		proc_events = {
			[proc_events.on_damage_taken] = 1,
		},
		check_proc_func = function (params, template_data, template_context)
			return _own_hit(params, template_context) and params.attack_type == attack_types.melee
		end,
		proc_func = function (params, template_data, template_context, t)
			add_timed(template_context, "bfe_stack", t)
		end,
	}
	timed("bfe_stack", N.BFE_DURATION, N.BFE_STACKS, stat_table("melee_damage", N.BFE_DAMAGE))

	-- Defiance: melee crit chance at low health.
	templates[Extra.name("def")] = {
		class_name = "buff",
		predicted = false,
		conditional_stat_buffs = stat_table("melee_critical_strike_chance", N.DEF_CRIT),
		start_func = start_health,
		conditional_stat_buffs_func = function (template_data, template_context)
			return health_percent(template_data) < N.DEF_HEALTH
		end,
	}

	-- Apotheosis: a hit that leaves almost no health grants damage.
	templates[Extra.name("apo")] = {
		class_name = "proc_buff",
		predicted = false,
		active_duration = N.APO_DURATION,
		cooldown_duration = N.APO_COOLDOWN,
		proc_events = {
			[proc_events.on_damage_taken] = 1,
		},
		proc_stat_buffs = stat_table("damage", N.APO_DAMAGE),
		start_func = start_health,
		check_proc_func = function (params, template_data, template_context)
			return _own_hit(params, template_context) and health_percent(template_data) <= N.APO_HEALTH
		end,
	}

	-- Blood frenzy side -----------------------------------------------

	-- Rally: a kill soon after a hit heals part of that damage back.
	templates[Extra.name("ral")] = {
		class_name = "proc_buff",
		predicted = false,
		proc_events = {
			[proc_events.on_damage_taken] = 1,
			[proc_events.on_kill] = 1,
		},
		start_func = function (template_data, template_context)
			template_data.pending = 0
			template_data.expires = 0
		end,
		specific_check_proc_funcs = {
			[proc_events.on_damage_taken] = function (params, template_data, template_context)
				return _own_hit(params, template_context)
			end,
			[proc_events.on_kill] = function (params, template_data, template_context)
				return CheckProcFunctions.on_kill(params, template_data, template_context) and (template_data.pending or 0) > 0
			end,
		},
		specific_proc_func = {
			[proc_events.on_damage_taken] = function (params, template_data, template_context, t)
				if t > (template_data.expires or 0) then
					template_data.pending = 0
				end

				template_data.pending = (template_data.pending or 0) + params.damage_amount
				template_data.expires = t + N.RAL_WINDOW
			end,
			[proc_events.on_kill] = function (params, template_data, template_context, t)
				if t <= (template_data.expires or 0) and template_context.is_server then
					_heal(template_context.unit, template_data.pending * N.RAL_SHARE, heal_types.buff)
				end

				template_data.pending = 0
			end,
		},
	}

	-- Vampire's Kiss, Bloodletting and Adrenaline Surge: kills that heal.
	local function kill_heal(key, check, share)
		templates[Extra.name(key)] = {
			class_name = "proc_buff",
			predicted = false,
			proc_events = {
				[proc_events.on_kill] = 1,
			},
			check_proc_func = check,
			proc_func = function (params, template_data, template_context)
				if template_context.is_server then
					heal_share(template_context.unit, share)
				end
			end,
		}
	end

	kill_heal("vk", CheckProcFunctions.on_weakspot_kill, N.VK_HEAL)
	kill_heal("bl", function (params, template_data, template_context)
		return CheckProcFunctions.on_melee_kill(params, template_data, template_context) and params.is_critical_strike and true or false
	end, N.BL_HEAL)
	kill_heal("adr", CheckProcFunctions.on_special_kill, N.ADR_HEAL)

	-- Small stat nodes ------------------------------------------------

	for key, stat in pairs(Extra.STATS) do
		if stat_buffs[stat[2]] then
			templates[Extra.name(key)] = {
				class_name = "buff",
				predicted = false,
				stat_buffs = stat_table(stat[2], stat[3]),
			}
		end
	end

	return templates
end

-- Talents the extra nodes carry, registered the way QIangIQsZealotDeflect
-- registers its augments. The four repurposed nodes keep their official
-- talents.
Extra.register_talents = function ()
	local ArchetypeTalents = require("scripts/settings/ability/archetype_talents/archetype_talents")
	local zealot_talents = ArchetypeTalents and ArchetypeTalents.zealot

	if not zealot_talents then
		return
	end

	for _, spec in ipairs(Extra.NODES) do
		local key = spec[1]
		local def = Extra.DEFS[key]

		if def and not def.talent then
			local name = Extra.name(key)

			zealot_talents[name] = {
				description = "loc_" .. name .. "_desc",
				display_name = "loc_" .. name .. "_name",
				icon = def.icon,
				name = name,
				passive = {
					buff_template_name = name,
					identifier = name,
				},
			}

			_append_lookup("archetype_talent_names", name)
			_append_lookup("talent_node_names", Extra.widget(key))
		end
	end
end

-- The tree: existing nodes move, new ones go at the END of the node list so
-- every saved index stays valid. `save` records the change for the revert.
Extra.layout = function (nodes, by_name, regen, save)
	local spacing = NODE_SPACING
	local widgets = {
		mart = NODE_MARTYRDOM,
	}
	local children = {}

	for _, spec in ipairs(Extra.NODES) do
		widgets[spec[1]] = spec[5] or Extra.widget(spec[1])
	end

	for _, spec in ipairs(Extra.NODES) do
		local parent = spec[4]

		if parent ~= "mart" then
			children[parent] = children[parent] or {}
			children[parent][#children[parent] + 1] = widgets[spec[1]]
		end
	end

	local added = {}

	for _, spec in ipairs(Extra.NODES) do
		local key = spec[1]
		local x = regen.x + spec[2] * spacing
		local y = regen.y + spec[3] * spacing
		local parents = { widgets[spec[4]] }
		local node_children = children[key] or {}
		local node = spec[5] and by_name[spec[5]]

		if node then
			save(node, "x", x)
			save(node, "y", y)
			save(node, "parents", parents)
			save(node, "children", node_children)

			if spec[6] then
				save(node, "icon", spec[6])
			end

			if MOVED_NODES[spec[5]] then
				-- Picked like any other node: no old exclusive group or
				-- point requirement.
				local requirements = table.clone(node.requirements or {})

				requirements.exclusive_group = nil
				requirements.min_points_spent = 0
				requirements.min_points_spent_in_group = nil
				requirements.incompatible_talent = nil

				save(node, "requirements", requirements)
			end

			if key == "hp30" or key == "s_hp" or key == "s_dr" or key == "s_move" then
				save(node, "type", "stat")
			end
		elseif not spec[5] then
			local def = Extra.DEFS[key]
			local new_node = {
				cost = 1,
				icon = def.icon,
				max_points = 1,
				talent = Extra.name(key),
				type = def.stat and "stat" or "keystone_modifier",
				widget_name = Extra.widget(key),
				x = x,
				y = y,
				children = node_children,
				connector_offset = { 0, 0 },
				parents = parents,
				requirements = {
					all_parents_chosen = false,
					children_unlock_points = 1,
					min_points_spent = 0,
				},
			}

			nodes[#nodes + 1] = new_node
			by_name[new_node.widget_name] = new_node
			added[#added + 1] = new_node
		end
	end

	state.added = added
	state.added_to = nodes
end

Extra.unlayout = function ()
	local added = state.added
	local nodes = state.added_to

	if added and nodes then
		local is_added = {}

		for _, node in ipairs(added) do
			is_added[node] = true
		end

		for i = #nodes, 1, -1 do
			if is_added[nodes[i]] then
				table.remove(nodes, i)
			end
		end
	end

	state.added = nil
	state.added_to = nil
end

local function _register_buffs()
	local non_predicted = rawget(BuffTemplates, "NON_PREDICTED")

	-- Sorted: every client must append the lookup names in the same order.
	for _, templates in ipairs({ _templates(), Extra.templates() }) do
		local names = {}

		for name in pairs(templates) do
			names[#names + 1] = name
		end

		table.sort(names)

		for _, name in ipairs(names) do
			local template = templates[name]

			template.name = name
			BuffTemplates[name] = template

			if non_predicted then
				non_predicted[name] = name
			end

			_append_lookup("buff_templates", name)
		end
	end

	Extra.register_talents()

	state.registered = true
end

_register_buffs()

-- zealot_melee_kills_restore_toughness_to_target gives the ally the enemy was
-- after toughness: inside the convert scope it heals them instead. proc_func
-- is looked up on the template at every proc (proc_buff.lua), so wrapping it
-- once covers every instance. The original is kept across mod reloads.
local function _wrap_template_funcs()
	local original_funcs = state.original_funcs or {}

	state.original_funcs = original_funcs

	local template = BuffTemplates.zealot_melee_kills_restore_toughness_to_target

	if template and template.proc_func then
		local key = "zealot_melee_kills_restore_toughness_to_target.proc_func"
		local original = original_funcs[key] or template.proc_func

		original_funcs[key] = original
		template.proc_func = function (params, template_data, template_context, ...)
			if template_context.is_server and _has_buff(template_context.unit, BUFF_REWORK) then
				return _with_convert_scope(original, params, template_data, template_context, ...)
			end

			return original(params, template_data, template_context, ...)
		end
	end
end

_wrap_template_funcs()

local TDR_TO_DR_LOOKUP = {}

for _, template_name in ipairs(TDR_TO_DR_TEMPLATES) do
	TDR_TO_DR_LOOKUP[template_name] = true
end

-- Talent text values for the scaled reductions (zealot_talents.lua
-- format_values), as the share of damage removed before scaling. Each reads
-- the same setting or template field as the talent's own format value.
local DR_FORMAT_VALUES = {
	{ "zealot_crits_reduce_toughness_damage", "toughness_damage_reduction", function ()
		return 1 - talent_settings_2.toughness_2.toughness_damage_taken_multiplier
	end },
	{ "zealot_leaving_stealth_restores_toughness", "dr", function ()
		return 1 - talent_settings.zealot_leave_stealth_toughness_regen.damage_reduction_percentage
	end },
	{ "zealot_revive_speed", "tdr", function ()
		return 1 - talent_settings.zealot_revive_speed.toughness_damage_taken_multiplier
	end },
	{ "zealot_toughness_damage_reduction_coherency_improved", "damage_reduction", function ()
		return 1 - talent_settings_2.coop_2.toughness_damage_taken_multiplier
	end },
	{ "zealot_channel_grants_toughness_damage_reduction", "toughness", function ()
		return BuffTemplates.zealot_channel_toughness_damage_reduction.toughness
	end },
	{ "zealot_ally_damage_taken_reduced", "damage_reduction", function ()
		return 1 - talent_settings_3.coop_3.damage_taken_multiplier
	end },
	{ "zealot_weakspot_damage_reduction", "damage_resistance", function ()
		return 1 - talent_settings.zealot_weakspot_damage_reduction.damage_taken_multiplier
	end },
	{ "zealot_reduced_damage_after_dodge", "damage", function ()
		return 1 - BuffTemplates.zealot_damage_reduction_after_dodge.proc_stat_buffs[stat_buffs.damage_taken_multiplier]
	end },
}

-- Talent text values for the 1.6.1 cooldown modifiers.
local LEGACY_FORMAT_VALUES = {
	{ "zealot_crits_grant_cd", "cooldown_regen", {
		format_type = "percentage",
		prefix = "+",
		value = LEGACY_CRIT_CD_REGEN,
	} },
	{ "zealot_crits_grant_cd", "duration", {
		format_type = "number",
		value = LEGACY_CRIT_CD_DURATION,
	} },
	{ "zealot_backstab_kills_restore_cd", "ability_cooldown", {
		format_type = "percentage",
		value = LEGACY_BACKSTAB_CD,
	} },
}

-- DR_SCALED_TEMPLATES, the 1.6.1 crit modifier and the talent text values:
-- reversible, like the tree edits. Text values are read first, from the
-- unchanged templates.
local function _apply_templates()
	if state.saved_templates then
		return
	end

	local saved = {}

	local function save(owner, key, value)
		saved[#saved + 1] = { owner, key, owner[key] }
		owner[key] = value
	end


	local ok, zealot_talents = pcall(require, "scripts/settings/ability/archetype_talents/talents/zealot_talents")
	local talents = ok and type(zealot_talents) == "table" and zealot_talents.talents

	if talents then
		for _, entry in ipairs(LEGACY_FORMAT_VALUES) do
			local definition = talents[entry[1]]
			local format_values = definition and definition.format_values

			if format_values and format_values[entry[2]] then
				save(format_values, entry[2], entry[3])
			end
		end

		for _, entry in ipairs(DR_FORMAT_VALUES) do
			local definition = talents[entry[1]]
			local format_values = definition and definition.format_values
			local value_ok, reduction = pcall(entry[3])

			if format_values and format_values[entry[2]] and value_ok and type(reduction) == "number" then
				save(format_values, entry[2], {
					format_type = "percentage",
					prefix = "+",
					value = reduction * DR_SCALE,
				})
			end
		end
	end

	-- zealot_crits_cooldown_buff reads cooldown_regen from the settings on
	-- every tick, but copied duration into the template when it loaded. The talents are
	-- required above first, so their text values hold the current numbers.
	if talent_settings.crits_grants_cd then
		save(talent_settings.crits_grants_cd, "cooldown_regen", LEGACY_CRIT_CD_REGEN)
		save(talent_settings.crits_grants_cd, "duration", LEGACY_CRIT_CD_DURATION)
	end

	if BuffTemplates.zealot_crits_cooldown_buff then
		save(BuffTemplates.zealot_crits_cooldown_buff, "duration", LEGACY_CRIT_CD_DURATION)
	end

	for _, template_name in ipairs(DR_SCALED_TEMPLATES) do
		local template = BuffTemplates[template_name]

		if template then
			local convert = TDR_TO_DR_LOOKUP[template_name] or false

			for _, field in ipairs(STAT_TABLE_FIELDS) do
				if template[field] then
					save(template, field, _scaled_stats(template[field], convert))
				end
			end

			if template.stepped_stat_buffs then
				local steps = {}

				for i = 1, #template.stepped_stat_buffs do
					steps[i] = _scaled_stats(template.stepped_stat_buffs[i], convert)
				end

				save(template, "stepped_stat_buffs", steps)
			end
		end
	end

	state.saved_templates = saved
end

local function _revert_templates()
	local saved = state.saved_templates

	if not saved then
		return
	end

	for i = #saved, 1, -1 do
		local entry = saved[i]

		entry[1][entry[2]] = entry[3]
	end

	state.saved_templates = nil
end

_refresh_templates = function ()
	if _is_active() then
		_apply_templates()
	else
		_revert_templates()
	end
end

-- ####################################################################
-- Talents -> buffs
-- ####################################################################

-- Special rules of the repurposed talents (zealot_talents.lua), each only set
-- by that talent.
local REMOVED_SPECIAL_RULES = {
	"zealot_resist_death_staggers",
	"zealot_resist_death_ability",
	"zealot_preacher_spread_fanatic_rage",
	"zealot_quickness_passive_dodge_stacks",
	-- The four placeholder talents, now Martyr's Resolve, Pain Is a Gift,
	-- Triage and Blood Frenzy.
	"zealot_fanatic_rage_toughness",
	"zealot_momentum_toughness_replenish",
	"zealot_preacher_increased_crit_chance",
	"zealot_quickness_increased_duration",
}

mod:hook_require("scripts/utilities/character_sheet", function (CharacterSheet)
	mod:hook(CharacterSheet, "class_loadout", function (func, profile, destination, force_base_talents, optional_selected_talents, ...)
		if not _is_active() or not _is_modern_zealot(profile) then
			return func(profile, destination, force_base_talents, optional_selected_talents, ...)
		end

		-- The hidden keystones never apply, even from an old build.
		local filtered = optional_selected_talents

		if type(optional_selected_talents) == "table" then
			filtered = {}

			for talent_name, tier in pairs(optional_selected_talents) do
				if not LOCKED_TALENTS[talent_name] then
					filtered[talent_name] = tier
				end
			end
		end

		local results = { func(profile, destination, force_base_talents, filtered, ...) }
		local passives = destination and destination.passives

		if passives then
			-- Some repurposed talents only had a special rule, so a picked
			-- talent gets its buffs even without a passive entry.
			for talent_name, buff_names in pairs(PASSIVE_REPLACEMENTS) do
				if passives[talent_name] or (type(filtered) == "table" and filtered[talent_name]) then
					passives[talent_name] = table.clone(buff_names)
				end
			end

			-- Martyrdom is health only: its damage per missing wound
			-- (zealot_martyrdom_base) is gone.
			if passives.zealot_martyrdom then
				passives.zealot_martyrdom = {
					BUFF_LIFESTEAL,
					BUFF_LOW_HEALTH_SPEED,
				}
			end

			-- The stat node copy takes the original's tier
			-- (Buff talent_overrides read it by template name).
			local tiers = destination.buff_template_tiers

			if tiers and tiers[STAT_NODE_BUFF] then
				tiers[BUFF_DR_NODE] = tiers[STAT_NODE_BUFF]
			end

			passives[CLASS_PASSIVE_KEY] = {
				BUFF_REWORK,
				BUFF_ADM,
				BUFF_ELITE_RANGED,
			}
		end

		-- The health node keeps none of the Until Death heal augment: its
		-- special rule goes with its passive.
		local special_rules = destination and destination.special_rules

		if special_rules then
			for _, rule in ipairs(REMOVED_SPECIAL_RULES) do
				special_rules[rule] = nil
			end
		end

		return unpack(results, 1, table.maxn(results))
	end)
end)

-- Health node: flat maximum health on top of the multipliers
-- (PlayerUnitHealthExtension.max_health), not while knocked down.
mod:hook_require("scripts/extension_systems/health/player_unit_health_extension", function (PlayerUnitHealthExtension)
	mod:hook(PlayerUnitHealthExtension, "max_health", function (func, self, force_knocked_down_health, ...)
		local health = func(self, force_knocked_down_health, ...)

		if self._is_knocked_down or force_knocked_down_health or not _is_active() then
			return health
		end

		local buff_extension = self._buff_extension

		if buff_extension and buff_extension.has_buff_using_buff_template then
			if buff_extension:has_buff_using_buff_template(BUFF_HEALTH_NODE) then
				health = health + HEALTH_NODE_BONUS
			end

			-- Scar Tissue: one stack per time health fell low.
			health = health + buff_extension:current_stacks(Extra.name("st_stack")) * Extra.N.ST_BONUS
		end

		return health
	end)
end)

-- ####################################################################
-- Talent text
-- ####################################################################

-- Raw strings for LocalizationManager._lookup (same hook as
-- QIangIQsZealotDeflect). {name:%s} is filled from the talent's own
-- format_values (zealot_talents.lua). Numbers for toughness turned into
-- health come from the same settings the talents use.

local function _percent(value)
	local percent = value * 100
	local text

	if percent >= 10 or math.abs(percent - math.floor(percent + 0.5)) < 0.05 then
		text = string.format("%.0f", percent)
	elseif percent >= 1 then
		text = string.format("%.1f", percent)
	else
		text = string.format("%.2f", percent)
	end

	if string.find(text, ".", 1, true) then
		text = string.gsub(string.gsub(text, "0+$", ""), "%.$", "")
	end

	return text .. "%"
end

-- A share of max toughness as the share of max health it heals.
local function _health_percent(toughness_share)
	return _percent(toughness_share / TOUGHNESS_PER_HEALTH)
end

-- Flat toughness as the health it heals.
local function _health_amount(toughness)
	local health = toughness / TOUGHNESS_PER_HEALTH

	if math.abs(health - math.floor(health + 0.5)) < 0.05 then
		return string.format("%.0f", health)
	end

	return string.format("%.1f", health)
end

-- Fields that only exist on the buff template (zealot_buff_templates.lua);
-- the default is the template's value.
local function _template_value(template_name, field, default)
	local template = BuffTemplates[template_name]

	return template and template[field] or default
end

-- Names and descriptions of the extra talents and small stat nodes. The four
-- repurposed nodes set the text of their official talents; every other node
-- has its own loc keys (Extra.register_talents).
Extra.text = function (loc)
	local N = Extra.N
	local pct = _percent
	local seconds = function (value)
		return tostring(value) .. " seconds"
	end

	local descriptions = {
		mr = "Using your Combat Ability heals " .. pct(N.MR_MISSING_HEAL) .. " of your missing Health.",
		pg = "The lower your Health, the faster your Combat Ability recharges: up to +" .. pct(N.PG_MAX) .. " Combat Ability Cooldown Regeneration at 1 Health.",
		tri = "+" .. pct(N.TRIAGE) .. " Healing Received.",
		bf = "Elite kills heal " .. pct(N.BF_HEAL) .. " of your maximum Health and grant +" .. pct(N.BF_SPEED) .. " Attack Speed for " .. seconds(N.BF_DURATION) .. ", stacking up to " .. N.BF_STACKS .. " times.",
		pp = "Using your Combat Ability heals allies in Coherency for " .. pct(N.PP_HEAL) .. " of their maximum Health.",
		lr = "Using your Combat Ability below " .. pct(N.LR_HEALTH) .. " Health makes you take " .. pct(1 - N.LR_MULT) .. " less damage for " .. seconds(N.LR_DURATION) .. ". Once every " .. seconds(N.LR_COOLDOWN) .. ".",
		fm = "Assisting an ally heals you for " .. pct(N.FM_HEAL) .. " of your maximum Health.",
		rel = "A single hit of " .. pct(N.REL_HIT) .. " of your maximum Health or more makes you immune to stuns for " .. seconds(N.REL_DURATION) .. ". Once every " .. seconds(N.REL_DURATION + N.REL_COOLDOWN) .. ".",
		cr = "Using your Combat Ability grants +" .. pct(N.CR_SPEED) .. " Movement Speed for " .. seconds(N.CR_DURATION) .. ".",
		ar = "Below " .. pct(N.AR_HEALTH) .. " Health, gain +" .. pct(N.AR_MOVE) .. " Movement Speed and +" .. pct(N.AR_ATTACK) .. " Attack Speed.",
		ps = "Successful dodges heal " .. pct(N.PS_HEAL) .. " of your maximum Health.",
		eg = "Melee hits on Monstrosities and Captains make you take " .. pct(1 - N.EG_MULT) .. " less damage for " .. seconds(N.EG_DURATION) .. ".",
		fd = "A single hit of " .. pct(N.FD_HIT) .. " of your maximum Health or more heals " .. pct(N.FD_SHARE) .. " of your maximum Health over " .. seconds(N.FD_DURATION) .. ". Once every " .. seconds(N.FD_COOLDOWN) .. ".",
		ub = "Below " .. pct(N.UB_HEALTH) .. " Health, regenerate " .. N.UB_REGEN .. " Health per second.",
		st = "Each time your Health falls below " .. pct(N.ST_THRESHOLD) .. ", gain +" .. N.ST_BONUS .. " Maximum Health for the rest of the mission, up to " .. N.ST_STACKS .. " times. It can trigger again once you are above " .. pct(N.ST_RESET) .. " Health.",
		sc = "A hit that would kill you leaves you at 1 Health instead: you cannot die for " .. seconds(N.SC_ACTIVE) .. " and heal " .. pct(N.SC_HEAL) .. " of your maximum Health. Once every " .. tostring(math.floor(N.SC_COOLDOWN / 60)) .. " minutes.",
		cyb = "After " .. seconds(N.CYB_DELAY) .. " without taking damage, regenerate " .. N.CYB_REGEN .. " Health per second.",
		fof = "+" .. pct(N.FOF_HEALTH) .. " Maximum Health, " .. pct(N.FOF_MOVE) .. " Movement Speed.",
		bt = pct(N.BT_HEALTH) .. " Maximum Health, +" .. pct(N.BT_MELEE) .. " Melee Damage.",
		htl = "Take " .. pct(N.HTL_PER_ALLY) .. " less damage for each ally in Coherency, up to " .. N.HTL_ALLIES .. " allies.",
		lit = "While " .. N.LIT_ALLIES .. " or more allies are in Coherency, +" .. pct(N.LIT_HEALTH) .. " Maximum Health.",
		sang = "Elite kills heal allies in Coherency for " .. pct(N.SANG_HEAL) .. " of their maximum Health.",
		bfe = "Taking melee damage grants +" .. pct(N.BFE_DAMAGE) .. " Melee Damage for " .. seconds(N.BFE_DURATION) .. ", stacking up to " .. N.BFE_STACKS .. " times.",
		def = "Below " .. pct(N.DEF_HEALTH) .. " Health, +" .. pct(N.DEF_CRIT) .. " Melee Critical Hit Chance.",
		apo = "A hit that leaves you at " .. pct(N.APO_HEALTH) .. " Health or less grants +" .. pct(N.APO_DAMAGE) .. " Damage for " .. seconds(N.APO_DURATION) .. ". Once every " .. seconds(N.APO_COOLDOWN) .. ".",
		ral = "Killing an enemy within " .. seconds(N.RAL_WINDOW) .. " of taking damage heals " .. pct(N.RAL_SHARE) .. " of the damage you took.",
		vk = "Weakspot kills heal " .. pct(N.VK_HEAL) .. " of your maximum Health.",
		bl = "Critical melee kills heal " .. pct(N.BL_HEAL) .. " of your maximum Health.",
		adr = "Special kills heal " .. pct(N.ADR_HEAL) .. " of your maximum Health.",
	}

	for key, def in pairs(Extra.DEFS) do
		local name = Extra.name(key)
		local name_key = def.loc_name or "loc_" .. name .. "_name"
		local desc_key = def.loc_desc or "loc_" .. name .. "_desc"

		if def.stat then
			local stat = def.stat
			local amount = stat[4] and 1 - stat[3] or stat[3]

			loc[name_key] = stat[1]
			loc[desc_key] = string.gsub(stat[5], "%%s", (string.gsub(pct(amount), "%%", "%%%%")))
		else
			loc[name_key] = (def.talent and "Martyrdom: " or "") .. def.name
			loc[desc_key] = descriptions[key]
		end
	end
end

local in_melee = talent_settings.zealot_toughness_in_melee
local prayer = talent_settings_3.bolstering_prayer
local restore_to_target = talent_settings.zealot_melee_kills_restore_toughness_to_target
local until_death_text = "Gain Damage Reduction equal to " .. _percent(DR_SCALE) .. " of the share of your maximum Health you have lost over the last 15 seconds, counting healing: your highest Health in that time minus your current Health. It stacks on top of your other Damage Reduction.\n\nYou no longer resist death."
local stat_node_reduction = math.abs(_template_value(STAT_NODE_BUFF, "stat_buffs", {})[stat_buffs.toughness_damage_taken_modifier] or 0.1)
local defensive_prayer_text = "Each pulse of {talent_name:%s} grants you and allies in Coherency a stack of {toughness:%s} Damage Reduction for {duration:%s} seconds, up to {max_stacks:%s} stacks."
local LOC_TEXT = {
	-- Martyrdom and its augments.
	loc_talent_zealot_martyrdom_desc = "1% of your melee damage heals you.\n\nThe lower your Health, the faster you attack: normal speed at full Health, up to double Attack Speed at 1 Health.",
	loc_talent_zealot_attack_speed_per_martyrdom = "Martyrdom: Attack Speed on Hit",
	loc_talent_zealot_attack_speed_per_martyrdom_upd_desc = "Taking or dodging a hit grants +20% Attack Speed for 6 seconds.",
	loc_talent_zealot_martyrdom_grants_toughness = "Martyrdom: Ability Empowerment",
	loc_talent_zealot_martyrdom_grants_toughness_upd_desc = "Using your Combat Ability grants +100% Cleave and +50% Melee Damage for 10 seconds.",
	loc_talent_zealot_corruption_resistance_stacking = "Martyrdom: Health Regeneration",
	loc_talent_zealot_corruption_resistance_stacking_desc = "Regenerate " .. tostring(HEALTH_REGEN_PER_SECOND) .. " Health per second.",
	loc_talent_zealot_martyrdom_toughness_modifier = "Martyrdom: Corruption Cleanse",
	loc_talent_zealot_martyrdom_toughness_modifier_upd_desc = "Melee kills heal 1 Corruption. Weakspot or Critical melee kills heal 3, and Weakspot Critical melee kills heal 5. This heals across wounds.",
	loc_talent_zealot_shared_fanatic_rage = "Martyrdom: Monstrosity Kill Healing",
	loc_talent_zealot_shared_fanatic_rage_new_desc = "Killing a Monstrosity heals " .. _percent(MONSTER_HEAL_SHARE) .. " of your maximum Health over " .. tostring(MONSTER_HEAL_DURATION) .. " seconds.",
	loc_talent_zealot_heal_during_resist_death = "Martyrdom: Health",
	loc_talent_zealot_quickness_dodge_stacks = "Martyrdom: Ammo on Health Loss",
	loc_talent_zealot_quickness_dodge_stacks_desc = "Losing Health refills your reserve ammo: every 10% of maximum Health lost gives " .. _percent(0.1 * AMMO_PER_HEALTH_LOST) .. " of your maximum reserve ammo.",
	loc_talent_zealot_resist_death_ability = "Damage Reduction",
	loc_talent_zealot_resist_death_ability_offensive_desc = "+" .. _percent(math.abs(_template_value(BUFF_STAT_DR, "stat_buffs", {})[stat_buffs.toughness_damage_taken_modifier] or 0.05)) .. " Damage Reduction.",
	loc_talent_zealot_resist_death_fire = "Health",
	loc_talent_zealot_resist_death_fire_desc = "+" .. _percent(_template_value(BUFF_STAT_HEALTH, "stat_buffs", {})[stat_buffs.max_health_modifier] or 0.05) .. " Maximum Health.",
	loc_talent_zealot_resist_death_recuperate = "Movement Speed",
	loc_talent_resist_death_toughness_desc = "+" .. _percent(_template_value(BUFF_STAT_MOVEMENT, "stat_buffs", {})[stat_buffs.movement_speed] or 0.05) .. " Movement Speed.",

	-- Cooldown modifiers, 1.6.1 behaviour (the crit one keeps its own text).
	loc_talent_zealot_cooldown_on_backstab_weakspot_desc = "Backstab kills restore {ability_cooldown:%s} of your Combat Ability cooldown.",
	loc_talent_zealot_damage_taken_restores_cd_new_description = "Each point of damage you take restores {cooldown_restore:%s} of your Combat Ability cooldown.",
	loc_talent_zealot_resist_death_heal_desc = "+" .. tostring(HEALTH_NODE_BONUS) .. " Maximum Health.",

	-- Until Death.
	loc_talent_zealot_resist_death_base_desc = until_death_text,
	loc_talent_zealot_resist_death_desc = until_death_text,

	-- Talents that restored toughness now heal; TDR is now DR.
	loc_talent_zealot_toughness_melee_effectiveness_desc = "Critical Hits grant {toughness_damage_reduction:%s} Damage Reduction for {time:%s} seconds.",
	loc_talent_zealot_toughness_on_dodge_desc = "Successful dodges heal " .. _health_percent(_template_value("zealot_toughness_on_dodge", "toughness_percentage", 0.15)) .. " of your maximum Health, at most once every " .. tostring(_template_value("zealot_toughness_on_dodge", "cooldown_duration", 0.5)) .. " seconds.",
	loc_talent_zealot_toughness_on_heavy_kills_desc = "Killing an enemy with a heavy melee attack heals " .. _health_percent(_template_value("zealot_toughness_on_heavy_kills", "toughness_percentage", 0.1)) .. " of your maximum Health.",
	loc_talent_zealot_toughness_while_shooting_desc = "While shooting, heal " .. _health_percent(talent_settings.zealot_toughness_while_shooting.toughness) .. " of your maximum Health per second.",
	loc_talent_zealot_toughness_near_enemies_desc = "While enemies are within " .. tostring(in_melee.range) .. " metres, heal " .. _health_percent(in_melee.initial_percentage_toughness) .. " of your maximum Health per second, plus " .. _health_percent(in_melee.percentage_toughness_per_enemy) .. " for each enemy after the first, up to " .. _health_percent(in_melee.max_percentage_toughness) .. ". Monsters and captains count as " .. tostring(in_melee.monster_count + 1) .. " enemies.",
	loc_talent_zealot_stealth_toughness_dr_desc = "Entering {talent_name:%s} heals " .. _health_percent(talent_settings.zealot_leave_stealth_toughness_regen.toughness_to_restore) .. " of your maximum Health. Leaving it grants {dr:%s} Damage Reduction for {duration:%s} seconds.",
	loc_talent_zealot_elite_kills_empowers_desc = "Elite kills grant {damage:%s} Damage for {duration:%s} seconds and heal " .. _health_percent(talent_settings.zealot_elite_kills_empowers.toughness) .. " of your maximum Health over that time.",
	loc_talent_zealot_melee_kills_restore_toughness_to_target_desc = "Killing an enemy in melee heals the ally it was attacking for " .. _health_percent(restore_to_target.toughness) .. " of their maximum Health, and you for " .. _health_percent(restore_to_target.self_toughness) .. " of yours.",
	loc_talent_zealot_revive_speed_desc = "{revive_speed:%s} Revive Speed. Allies you revive, rescue, pull up or free from a net gain {movement_speed:%s} Movement Speed and {tdr:%s} Damage Reduction for {duration:%s} seconds.",
	loc_talent_zealot_toughness_aura_efficiency_desc = "Improves {talent_name:%s}: you and allies in Coherency gain {damage_reduction:%s} Damage Reduction.",
	loc_talent_zealot_bolstering_prayer_expanded_description = "Channel a prayer that heals you and allies in Coherency for " .. _health_percent(prayer.team_toughness) .. " of maximum Health per second. Every {interval:%s} seconds it also heals them for " .. _health_percent(prayer.toughness_percentage) .. " of maximum Health plus " .. _health_amount(prayer.toughness_bonus) .. " Health, and they cannot die or be stunned for 1.5 seconds. Enemies around you are staggered.\n\nCooldown: {cooldown:%s} seconds.",
	["loc_talent_zealot_zealot_channel_defensive_desc "] = defensive_prayer_text,
	loc_talent_zealot_zealot_channel_defensive_desc = defensive_prayer_text,
	loc_talent_zealot_attack_speed_after_dash_new_desc = "Dash to an enemy and heal " .. _health_percent(talent_settings_2.combat_ability.toughness) .. " of your maximum Health. Your first melee hit within " .. tostring(talent_settings_2.combat_ability.duration) .. " seconds of the dash is a Critical Hit with {damage:%s} Damage and {rending:%s} Rending, and you gain {attack_speed:%s} Attack Speed for {time:%s} seconds.\n\nCooldown: {cooldown:%s} seconds.",

	-- Shared stat node (base_talents.lua), only rewritten for Zealots.
	loc_talent_toughness_damage_reduction_medium_desc = "+" .. _percent(stat_node_reduction * DR_SCALE) .. " Damage Reduction.",
}

Extra.text(LOC_TEXT)

-- Keys every class's tree uses.
local SHARED_KEYS = {
	loc_talent_toughness_damage_reduction_medium = true,
	loc_talent_toughness_damage_reduction_medium_desc = true,
}

-- Every name and description key the Zealot tree shows: anything still
-- saying toughness there is caught by _without_toughness_words.
local tree_keys = nil

local function _tree_keys()
	if tree_keys then
		return tree_keys
	end

	local keys = {}
	local ok = pcall(function ()
		local zealot_talents = require("scripts/settings/ability/archetype_talents/talents/zealot_talents")
		local base_talents = require("scripts/settings/ability/archetype_talents/talents/base_talents")
		local talents = zealot_talents.talents or {}
		local nodes = _modern_nodes()

		for i = 1, #nodes do
			local talent_name = nodes[i].talent
			local definition = talent_name and (talents[talent_name] or (base_talents.talents or {})[talent_name])

			if definition then
				for _, field in ipairs({ "display_name", "description" }) do
					if definition[field] then
						keys[definition[field]] = true
					end
				end

				for _, format_value in pairs(definition.format_values or {}) do
					if type(format_value) == "table" and format_value.format_type == "loc_string" and type(format_value.value) == "string" then
						keys[format_value.value] = true
					end
				end
			end
		end
	end)

	if not ok then
		keys = {}
	end

	tree_keys = keys

	return keys
end

-- Toughness words outside {placeholders}: "Toughness Damage Reduction"
-- becomes "Damage Reduction", any other "Toughness" becomes "Health".
local function _without_toughness_words(text)
	if type(text) ~= "string" or not string.find(string.lower(text), "toughness", 1, true) then
		return text
	end

	local protected = {}

	text = string.gsub(text, "%b{}", function (placeholder)
		protected[#protected + 1] = placeholder

		return "\1" .. #protected .. "\2"
	end)

	for _, pair in ipairs({
		{ "Toughness Damage Reduction", "Damage Reduction" },
		{ "toughness damage reduction", "damage reduction" },
		{ "TOUGHNESS DAMAGE REDUCTION", "DAMAGE REDUCTION" },
		{ "Toughness", "Health" },
		{ "toughness", "health" },
		{ "TOUGHNESS", "HEALTH" },
	}) do
		text = string.gsub(text, pair[1], pair[2])
	end

	text = string.gsub(text, "\1(%d+)\2", function (index)
		return protected[tonumber(index)]
	end)

	return text
end

local function _local_player_is_modern_zealot()
	local player_manager = Managers.player
	local player = player_manager and player_manager.local_player and player_manager:local_player(1)
	local profile = player and player.profile and player:profile()

	return _is_modern_zealot(profile)
end

mod:hook(CLASS.LocalizationManager, "_lookup", function (func, self, key)
	if not _is_active() then
		return func(self, key)
	end

	local shared = SHARED_KEYS[key]

	if shared and not _local_player_is_modern_zealot() then
		return func(self, key)
	end

	local text = LOC_TEXT[key]

	if text then
		return text
	end

	local result = func(self, key)

	if result and (shared or _tree_keys()[key]) then
		return _without_toughness_words(result)
	end

	return result
end)

-- ####################################################################
-- Settings, load
-- ####################################################################

mod.on_setting_changed = function (setting_id)
	_refresh_mode()
end

mod.on_all_mods_loaded = function ()
	_refresh_mode()

	if _legacy_zealot_active() then
		mod:warning("The legacy Zealot tree from QIangIQsLegacyTalents is on, so the Martyrdom rework is off. Turn off its Zealot option to use the current tree.")
	end
end

_refresh_mode()

mod:command("martyrdom", mod:localize("command_description"), function ()
	mod:echo("Martyrdom rework: %s (host type %s, tree edits %s, legacy Zealot tree %s)", _is_active() and "on" or "off", tostring(state.host_type), state.saved and "applied" or "not applied", _legacy_zealot_active() and "on" or "off")
end)
