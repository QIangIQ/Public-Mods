return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsMartyrdom` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsMartyrdom", {
			mod_script       = "QIangIQsMartyrdom/scripts/mods/QIangIQsMartyrdom/QIangIQsMartyrdom",
			mod_data         = "QIangIQsMartyrdom/scripts/mods/QIangIQsMartyrdom/QIangIQsMartyrdom_data",
			mod_localization = "QIangIQsMartyrdom/scripts/mods/QIangIQsMartyrdom/QIangIQsMartyrdom_localization",
		})
	end,
	packages = {},
}
