# Dio's Fixed CursedBlade

Original mod: Cursed Blade by Seph (Steam: Concoction of Constitution).
Fixes: Dioscurio.

The original mod did not come with a license file. Seph gave Dioscurio permission to redistribute this fixed version (2026-11-20).

This replaces Seph's Cursed Blade: it registers under the same mod id ("CursedBlade"). Remove Seph's original CursedBlade folder and its line in mod_load_order.txt before installing this one.
