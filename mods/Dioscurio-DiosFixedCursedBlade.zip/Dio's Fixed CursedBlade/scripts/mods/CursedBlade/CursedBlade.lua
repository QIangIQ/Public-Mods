local mod = get_mod("CursedBlade")
-- Author: Seph

local Promise = require("scripts/foundation/utilities/promise")
local MasterItems = require("scripts/backend/master_items")
local ItemPackage = require("scripts/foundation/managers/package/utilities/item_package")
local MinionVisualLoadout = require("scripts/utilities/minion_visual_loadout")
local Component = require("scripts/utilities/component")

local weaponPrimary
-- Weapon unit a spawn already failed on. Stops the per-frame retry loop that flooded the log.
local spawnFailedFor

mod.spawn_melee = function()
	if MasterItems.has_data() and mod:get("MEnable") then
		local item = MasterItems.get_item("content/items/weapons/minions/melee/chaos_traitor_guard_2h_power_sword")
		local world = Managers.world:world("level_world")
		local player = Managers.player:local_player_safe(1)
		if player == nil then return end
		local player_unit = player.player_unit
		mod.player_unit = player_unit
		if Unit.is_valid(player_unit) and Unit.is_valid(weaponPrimary) and spawnFailedFor ~= weaponPrimary then
            local ok, unit = pcall(World.spawn_unit, world, item.base_unit, Vector3.zero(), Quaternion.identity())
            if not ok or not unit then
                spawnFailedFor = weaponPrimary
                mod:error("Could not spawn the power sword model: %s", tostring(unit))
                return
            end
            mod.item_unit = unit
            local powersword = {}
            powersword["unit"] = mod.item_unit
            powersword["visible"] = true
            powersword["item_data"] = item
            powersword["state"] = "wielded"
            powersword["drop_on_death"] = true
            Unit.set_unit_objects_visibility(weaponPrimary, false, true)
            World.link_unit(world, mod.item_unit, 1, weaponPrimary, 1)
            
            Unit.set_local_rotation(mod.item_unit, 1, Quaternion.from_euler_angles_xyz(0,0,-50))

            local attachment_unit, node_index = MinionVisualLoadout.attachment_unit_and_node_from_node_name(powersword, "fx_shaft")
            local position = Unit.world_position(attachment_unit, node_index)
            local t = World.time(world)

            if mod:get("glowVFX") then
                Unit.set_scalar_for_material(attachment_unit, "blade_effect_01", "fade_out", t)
                Unit.set_scalar_for_material(attachment_unit, "blade_effect_01", "power_toggle", 1)
            end
            
            -- local eye = MasterItems.get_item("content/environment/gameplay/corruptor/corruptor_bulb")
            -- mod.eye_unit = World.spawn_unit(world, eye.base_unit, Vector3(0,0,0), Vector3(0,0,0))
            -- World.link_unit(world, mod.eye_unit, 1, weaponPrimary, 1)
		end
	end
end


local destroyParticles = function(id)
    local world = Application.main_world()
    if world and id then World.destroy_particles(world, id) end
end

local specialActive = false
local vfx_particle_id
local vfx_particle_id2
local vfx_particle_id3
local vfx_particle_id4
local vfx_particle_id5
local vfx_particle_id6
local vfx_particle_id7
mod:hook_safe("PlayerUnitWeaponExtension", "set_wielded_weapon_weapon_special_active", function(self, t, want_active, optional_reason)
    specialActive = want_active
end)


local PSParticles
local currentSlot = ""
local currentMark = ""
mod:hook_safe("PlayerUnitWeaponExtension", "_wielded_weapon", function(self, inventory_component, weapons)
    if weapons.slot_primary then 
        -- currentMark = weapons.slot_primary.item.__master_item.weapon_mark_display_name.dev_text
        if weaponPrimary ~= weapons.slot_primary.weapon_unit then
            weaponPrimary = weapons.slot_primary.weapon_unit
            if Unit.is_valid(mod.item_unit) then
                Unit.set_unit_objects_visibility(mod.item_unit, false, true)
            end
            mod.item_unit = nil
        end
    end
    -- if weapons.slot_secondary then weaponSecondary = weapons.slot_secondary.weapon_unit end
    local wielded_slot = inventory_component.wielded_slot
    if wielded_slot ~= currentSlot then
        currentSlot = wielded_slot
        destroyParticles(PSParticles)
        PSParticles = nil
    end
    if wielded_slot == "slot_primary" and not Unit.is_valid(mod.item_unit) then mod.spawn_melee() end
end)



mod:hook(World, "create_particles", function(f, world, particles, pos, ...)
    -- mod:echo(particles)
    if mod:get("MEnable") then
        if (particles == "content/fx/particles/weapons/foce_sword/forcesword_2h_charge" or particles == "content/fx/particles/weapons/swords/powersword_1h_activate_mesh" or particles == "content/fx/particles/weapons/swords/powersword_2h/powersword_2h_activate_mesh") and mod:get("chargedVFX") then
            particles = "content/fx/particles/enemies/twins/twins_aoe_sweep_windup"
            -- particles = "content/fx/particles/environment/fire_blaze_01"
            -- particles = "content/fx/particles/environment/tank_foundry_embers_02"
        -- elseif particles == "content/fx/particles/weapons/foce_sword/forcesword_2h_wisps_fingerstips" and mod:get("chargedVFX") then
        --     particles = "content/fx/particles/interacts/grimoire_throw"
        elseif particles == "content/fx/particles/weapons/swords/powersword_p1_m1_trail" and mod:get("trailVFX") then
            particles = "content/fx/particles/enemies/renegade_captain/renegade_captain_2h_heavy_swing_trail"
        elseif particles == "content/fx/particles/impacts/weapons/power_sword/power_sword_1h_impact" and mod:get("hitVFX") then
            particles = "content/fx/particles/enemies/renegade_captain/renegade_captain_2h_heavy_swing_trail"
            -- return
        end
    end
    local x = f(world, particles, pos, ...)
    if particles == "content/fx/particles/enemies/twins/twins_aoe_sweep_windup" then PSParticles = x end
    return x
end)


mod:hook(World, "link_particles", function(f, world, effect_id, unit, object, pose, orphaned_policy)
    if Unit.is_valid(unit) and mod:get("MEnable") then
        if PSParticles == effect_id then --and currentMark == "M1"
            Matrix4x4.set_rotation(pose, Quaternion.from_euler_angles_xyz(-90,0,-90))
        end
    end
    -- Always pass through, otherwise every particle link in the game is dropped when the mod is toggled off
    return f(world, effect_id, unit, object, pose, orphaned_policy)
end)

local playSound = function(soundfile)
    local world = Managers.world:world("level_world")
    if world then 
        local wwise_world = Managers.world:wwise_world(world)
        if wwise_world then WwiseWorld.trigger_resource_event(wwise_world, soundfile) end
    end
end

mod:hook("WwiseWorld","trigger_resource_event",function(func, s, file_path, ...)
    if mod:get("MEnable") then
        if currentSlot == "slot_primary" then
            if (file_path == "wwise/events/weapon/play_force_sword_on" or file_path == "wwise/events/weapon/play_power_sword_on" or file_path == "wwise/events/weapon/play_power_sword_2h_on") then 
                if mod:get("chargeSFX") then
                    file_path = "wwise/events/weapon/play_minion_captain_powersword_charge"
                    playSound("wwise/events/minions/play_minion_twin_swing")
                end
                if mod:get("activation") then playSound("wwise/events/minions/play_minion_captain__force_field_overload_vce") end
                if mod:get("chargeLoopSFX") then
                    playSound("wwise/events/player/stop_grimoire_unequip")
                    playSound("wwise/events/player/play_grimoire_unequip")
                end
                -- playSound("wwise/events/minions/play_minion_twin_powersword_charge")

            elseif (file_path == "wwise/events/weapon/play_power_sword_swing" or file_path == "wwise/events/weapon/play_power_sword_2h_swing") and mod:get("cSlashSFX") then
                if specialActive then
                    file_path = "wwise/events/minions/play_minion_twin_swing_powered_single"
                else
                    -- file_path = ""
                end
            elseif (file_path == "wwise/events/weapon/play_force_sword_2h_swing_heavy" or file_path == "wwise/events/weapon/play_force_sword_2h_swing") and mod:get("cSlashSFX") then
                if specialActive then
                    file_path = "wwise/events/minions/play_minion_twin_swing_powered_single"
                else
                    -- file_path = ""
                end
            elseif file_path == "wwise/events/weapon/play_power_sword_hit" and mod:get("cHitSFX") then
                file_path = "wwise/events/minions/play_traitor_captain_shield_bullet_hits"
                
            elseif file_path == "wwise/events/weapon/play_weapon_equip_medium_sword" and mod:get("equipSFX") then
                file_path = "wwise/events/minions/play_minion_captain_equip_sword"

            elseif file_path == "wwise/events/player/play_elite_killed" and mod:get("laugh") then
                playSound("wwise/events/minions/play_minion_captain__mocking_laughter_vce")
                playSound("wwise/events/minions/play_minion_captain__mocking_laughter_vce")
                playSound("wwise/events/minions/play_minion_captain__mocking_laughter_vce")
            
            elseif file_path == "wwise/events/weapon/play_power_sword_loop" then
                -- file_path = "wwise/events/world/play_forge_ladie_lava"
                -- file_path = "wwise/events/world/play_em_lava_ladle"
                if mod:get("chargeLoopSFX") then
                    file_path = "wwise/events/player/stop_grimoire_unequip"
                    playSound("wwise/events/player/play_grimoire_unequip")
                end
                if mod:get("skullVFX") then
                    destroyParticles(vfx_particle_id); destroyParticles(vfx_particle_id2); destroyParticles(vfx_particle_id3); destroyParticles(vfx_particle_id4); destroyParticles(vfx_particle_id5); destroyParticles(vfx_particle_id6); destroyParticles(vfx_particle_id7)
                    
                    local M = Matrix4x4.identity()
                    Matrix4x4.set_translation(M, Vector3(-0.025,0,0.2))
                    
                    vfx_particle_id = World.create_particles(Application.main_world(), "content/fx/particles/enemies/red_glowing_eyes", Vector3(0,0,0), _, Vector3(0.5,0.5,0.5))
                    vfx_particle_id2 = World.create_particles(Application.main_world(), "content/fx/particles/interacts/grimoire_throw", Vector3(0,0,0), _, Vector3(0.5,0.5,0.5))
                    vfx_particle_id3 = World.create_particles(Application.main_world(), "content/fx/particles/interacts/grimoire_throw", Vector3(0,0,0), _, Vector3(0.5,0.5,0.5))
                    vfx_particle_id4 = World.create_particles(Application.main_world(), "content/fx/particles/interacts/grimoire_throw", Vector3(0,0,0), _, Vector3(0.5,0.5,0.5))
                    vfx_particle_id5 = World.create_particles(Application.main_world(), "content/fx/particles/interacts/grimoire_idle", Vector3(0,0,0), _, Vector3(0.5,0.5,0.5))
                    vfx_particle_id6 = World.create_particles(Application.main_world(), "content/fx/particles/interacts/grimoire_idle", Vector3(0,0,0), _, Vector3(0.5,0.5,0.5))
                    vfx_particle_id7 = World.create_particles(Application.main_world(), "content/fx/particles/interacts/grimoire_idle", Vector3(0,0,0), _, Vector3(0.5,0.5,0.5))
                    
                    World.link_particles(Application.main_world(), vfx_particle_id2, weaponPrimary, 1, M, "destroy")
                    World.link_particles(Application.main_world(), vfx_particle_id3, weaponPrimary, 1, M, "destroy")
                    World.link_particles(Application.main_world(), vfx_particle_id4, weaponPrimary, 1, M, "destroy")
                    World.link_particles(Application.main_world(), vfx_particle_id5, weaponPrimary, 1, M, "destroy")
                    local M2 = M
                    Matrix4x4.set_translation(M2, Vector3(0.0075,-0.07,0.245))
                    World.link_particles(Application.main_world(), vfx_particle_id, weaponPrimary, 1, M2, "destroy")
                    World.set_particles_material_vector3(Application.main_world(), vfx_particle_id, "eye_flash_init", "material_variable_21872256", Vector3(0, 0.025, 0) ) 
                    World.set_particles_material_vector3(Application.main_world(), vfx_particle_id, "eye_glow", "trail_color", Vector3(0, 1, 0) ) 
                    World.set_particles_material_vector3(Application.main_world(), vfx_particle_id, "eye_socket", "material_variable_21872256", Vector3(0, 1, 0) ) 
                        
                    local M3 = M
                    -- Matrix4x4.set_translation(M3, Vector3(0.02,-0.02,-0.025))
                    -- Matrix4x4.set_translation(M4, Vector3(-0.02,0.02,-0.025))
                    World.link_particles(Application.main_world(), vfx_particle_id6, weaponPrimary, 1, M3, "destroy") 
                    World.link_particles(Application.main_world(), vfx_particle_id7, weaponPrimary, 1, M3, "destroy") 
                end
            elseif file_path == "wwise/events/weapon/stop_power_sword_loop" then
                -- file_path = ""
                if mod:get("chargeLoopSFX") then
                    file_path = "wwise/events/player/stop_grimoire_unequip"
                end
                destroyParticles(vfx_particle_id); destroyParticles(vfx_particle_id2); destroyParticles(vfx_particle_id3); destroyParticles(vfx_particle_id4); destroyParticles(vfx_particle_id5); destroyParticles(vfx_particle_id6); destroyParticles(vfx_particle_id7)
                vfx_particle_id, vfx_particle_id2, vfx_particle_id3, vfx_particle_id4, vfx_particle_id5, vfx_particle_id6, vfx_particle_id7 = nil, nil, nil, nil, nil, nil, nil
                
                -- playSound("wwise/events/player/stop_grimoire_unequip")

            elseif file_path == "wwise/events/player/play_player_foley_arms_drastic" and mod:get("push") then
                playSound("wwise/events/minions/play_minion_captain__melee_attack_charged_vce")

            elseif file_path == "wwise/events/player/play_footsteps_boots_dodge" and mod:get("dodgeSFX") then
                file_path = "wwise/events/minions/play_minion_captain_drastic_short"

            elseif file_path == "wwise/events/player/play_player_slide" and mod:get("slide") then
                file_path = "wwise/events/minions/play_minion_captain__grunt_vce"

            elseif file_path == "wwise/events/player/play_melee_charge_grip_hands" and mod:get("attack") then
                -- file_path = ""
                playSound("wwise/events/minions/play_minion_captain__kick_vce")
            -- elseif file_path == "wwise/events/player/stop_melee_charge_grip_hands" then
                -- file_path = ""
            elseif file_path == "wwise/events/weapon/play_hit_indicator_weakspot_melee_sharp" and mod:get("weakspotSFX") then
                playSound("wwise/events/player/play_grimoire_unequip_finish")
            elseif file_path == "wwise/events/weapon/play_indicator_crit_melee_swing" and mod:get("critSFX") then
                -- file_path = ""
                playSound("wwise/events/minions/play_minion_captain_equip_sword")
            end  
        end
    end
    -- mod:echo(file_path)
    return func(s, file_path, ...)
end)

-- wwise/events/minions/play_minion_twin_swing_powered_single
-- wwise/events/minions/play_minion_twin_swing_powered

mod.on_unload = function()
    destroyParticles(vfx_particle_id); destroyParticles(vfx_particle_id2); destroyParticles(vfx_particle_id3); destroyParticles(vfx_particle_id4); destroyParticles(vfx_particle_id5); destroyParticles(vfx_particle_id6); destroyParticles(vfx_particle_id7)
    destroyParticles(PSParticles)
end


