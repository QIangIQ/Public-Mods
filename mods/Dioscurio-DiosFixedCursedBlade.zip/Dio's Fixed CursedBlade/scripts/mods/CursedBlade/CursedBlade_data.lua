local mod = get_mod("CursedBlade")

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
		{
			setting_id = "ColoredTitle",
			type = "checkbox",
			default_value = true
		},
		{
			setting_id = "ColoredDesc",
			type = "checkbox",
			default_value = true
		},
		{
			setting_id = "MEnable",
			type = "checkbox",
			default_value = true
		},
		{
			setting_id = "BladeVFX",
			type = "group",
			sub_widgets = {
			{
				setting_id = "glowVFX",
				type = "checkbox",
				default_value = true
			},
			{
				setting_id = "skullVFX",
				type = "checkbox",
				default_value = true
			},
			{
				setting_id = "chargedVFX",
				type = "checkbox",
				default_value = true
			},
			{
				setting_id = "trailVFX",
				type = "checkbox",
				default_value = true
			},
			{
				setting_id = "hitVFX",
				type = "checkbox",
				default_value = true
			},
		},
	},
	{
		setting_id = "BladeSFX",
		type = "group",
		sub_widgets = {
		{
			setting_id = "chargeSFX",
			type = "checkbox",
			default_value = true
		},
		{
			setting_id = "chargeLoopSFX",
			type = "checkbox",
			default_value = true
		},
		{
			setting_id = "cSlashSFX",
			type = "checkbox",
			default_value = true
		},
		{
			setting_id = "cHitSFX",
			type = "checkbox",
			default_value = true
		},
		{
			setting_id = "critSFX",
			type = "checkbox",
			default_value = true
		},
		{
			setting_id = "weakspotSFX",
			type = "checkbox",
			default_value = true
		},
		{
			setting_id = "equipSFX",
			type = "checkbox",
			default_value = true
		},
		{
			setting_id = "dodgeSFX",
			type = "checkbox",
			default_value = true
		},
	},
},
		{
			setting_id = "voice",
			type = "group",
			sub_widgets = {
			{
				setting_id = "activation",
				type = "checkbox",
				default_value = true
			},
			{
				setting_id = "attack",
				type = "checkbox",
				default_value = true
			},
			{
				setting_id = "push",
				type = "checkbox",
				default_value = true
			},
			{
				setting_id = "slide",
				type = "checkbox",
				default_value = true
			},
			{
				setting_id = "laugh",
				type = "checkbox",
				default_value = true
			},
		},
	},
		},
	},
}
