-- Dio's Fixed CursedBlade: original mod by Seph (Steam: Concoction of Constitution), fixed by Dioscurio.
return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`CursedBlade` encountered an error loading the Darktide Mod Framework.")

		new_mod("CursedBlade", {
			mod_script       = "Dio's Fixed CursedBlade/scripts/mods/CursedBlade/CursedBlade",
			mod_data         = "Dio's Fixed CursedBlade/scripts/mods/CursedBlade/CursedBlade_data",
			mod_localization = "Dio's Fixed CursedBlade/scripts/mods/CursedBlade/CursedBlade_localization",
		})
	end,
	version = "1.0.0",
	packages = {},
}
