return {
	--[[
		TEST BUILD 0.0.0 - jumpscare branch.

		NO DEPENDENCIES, AND NO LOAD ORDER TO GET RIGHT.

		The jumpscare needs two things this engine will not do on its own -
		decode a loose .png and play a loose .ogg - and both are handled by
		native runtimes that ship inside this mod, under vendor/.

		If SimpleAssets or SimpleAudio happen to be installed, THEIRS ARE
		USED and ours are never loaded. That is not politeness: each runtime
		stands up a local HTTP or audio service, ffi.load on a second path is
		a second module to Windows, and two live copies resolve differently
		on different machines. See DiosHandholder_assets.lua and
		DiosHandholder_audio.lua for the gates.

		So: install alongside them or without them, in any load order.

		Neither runtime is touched during mod load. Both resolve on the first
		frame that asks for a texture or a sound, because loading a native
		DLL in early boot is what broke another player's SoloPlay once
		already.

		If either vendor/*/bin folder is deleted, that half degrades - the
		scare still fires, without its animation or without its sound - and
		says which in the log and in /hhscare.
	--]]
	run = function()
		fassert(rawget(_G, "new_mod"), "`Dio's Handholder` encountered an error loading the Darktide Mod Framework.")

		new_mod("DiosHandholder", {
			mod_script       = "Dio's Handholder/scripts/mods/DiosHandholder/DiosHandholder",
			mod_data         = "Dio's Handholder/scripts/mods/DiosHandholder/DiosHandholder_data",
			mod_localization = "Dio's Handholder/scripts/mods/DiosHandholder/DiosHandholder_localization",
		})
	end,
	version = "0.0.7",
	packages = {},
}
