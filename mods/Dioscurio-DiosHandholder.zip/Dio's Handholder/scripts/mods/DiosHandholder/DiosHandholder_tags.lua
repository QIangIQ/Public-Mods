local mod = get_mod("DiosHandholder")

--[[
    Loadout resolution and ability tagging.

    Split out of the main file so the hook wiring stays readable. Nothing here
    draws; it answers two questions about a player: what colour is their class,
    and what should their ability be CALLED when you shout it at them.
--]]

--[[
    SINGLETON, for the same reason as the bleedout module: io_dofile
    re-executes the file, and this one carries three caches - the per-unit
    ability tag, the loadout cache and the resolved ability configuration.
    Separate copies mean each call site pays the resolution cost again and
    warms its own table, which is the per-frame-lookup shape that cost 39 fps
    the last time it happened.
--]]
if mod.__dio_tags then
    return mod.__dio_tags
end

local T = {}

-- ---------------------------------------------------------------------------
-- Class colours
-- ---------------------------------------------------------------------------

--[[
    The same hues coherence_hud uses, deliberately.

    A teammate should be one colour everywhere. Two systems disagreeing about
    what colour a psyker is would be worse than neither having colour at all -
    the whole value of colour-coding is that it is learned once and then read
    without thinking.
--]]
T.CLASS_RGB = {
    veteran = { 90, 175, 255 },
    zealot  = { 255, 70, 55 },
    psyker  = { 125, 95, 255 },
    ogryn   = { 245, 165, 65 },
    adamant = { 230, 75, 160 },
    broker  = { 70, 235, 115 },
    cryptic = { 75, 210, 255 },
}
T.CLASS_RGB_DEFAULT = { 200, 200, 200 }

--[[
    Archetype resolution, taken from coherence_hud verbatim.

    My previous version read profile.archetype.name and looked it up directly in
    a table. That failed for every class you actually had on the team, for two
    reasons this code already handles:

    1. player:archetype_name() is tried FIRST. It is a direct method on the
       player and it is what actually answers reliably; the profile path is a
       fallback, not the primary source.

    2. The result is NORMALISED by substring rather than matched exactly. The
       raw value is not guaranteed to be "psyker" - it can be a display name or
       a localisation key - and the newer classes go by several names:

           arbites / arbitrator / arbitor  -> adamant
           hive / scum                     -> broker
           skitarii                        -> cryptic

       An exact lookup cannot match any of those. That is why Psyker,
       Arbitrator and Skitarii all resolved to the same wrong thing.
--]]
local function safe_call(obj, method)
    if not obj or type(obj[method]) ~= "function" then
        return nil
    end
    local ok, v = pcall(obj[method], obj)
    return ok and v or nil
end

local function safe_field(tbl, key)
    if type(tbl) ~= "table" then
        return nil
    end
    return tbl[key]
end

local function raw_archetype(player)
    if not player then
        return nil
    end

    local name = safe_call(player, "archetype_name")
    if name then
        return name
    end

    local profile = safe_call(player, "profile")
    local archetype = safe_field(profile, "archetype")
    if type(archetype) == "table" then
        return safe_field(archetype, "name") or safe_field(archetype, "archetype_name")
    end

    return safe_field(profile, "archetype_name")
end

function T.class_key(player)
    local raw = raw_archetype(player)
    if not raw then
        return nil
    end

    local name = tostring(raw):lower()

    if string.find(name, "veteran", 1, true) then return "veteran" end
    if string.find(name, "zealot", 1, true) then return "zealot" end
    if string.find(name, "psyker", 1, true) then return "psyker" end
    if string.find(name, "ogryn", 1, true) then return "ogryn" end

    if string.find(name, "adamant", 1, true)
        or string.find(name, "arbites", 1, true)
        or string.find(name, "arbitrator", 1, true)
        or string.find(name, "arbitor", 1, true) then
        return "adamant"
    end

    if string.find(name, "broker", 1, true)
        or string.find(name, "hive", 1, true)
        or string.find(name, "scum", 1, true) then
        return "broker"
    end

    if string.find(name, "cryptic", 1, true)
        or string.find(name, "skitarii", 1, true) then
        return "cryptic"
    end

    return name
end

--[[
    Icon paths confirmed against coherence_hud, which uses classes/large/.

    NOTE the gap: coherence_hud has no `cryptic` entry and silently falls back
    to the veteran icon, so Skitarii shows the wrong class art there too. The
    asset follows the same naming as every other class, so it is included here
    - if it turns out not to exist the fallback is the same one coherence_hud
    already lands on, so this is strictly no worse.
--]]
local CLASS_ICON = {
    veteran = "content/ui/materials/icons/classes/large/veteran",
    zealot  = "content/ui/materials/icons/classes/large/zealot",
    psyker  = "content/ui/materials/icons/classes/large/psyker",
    ogryn   = "content/ui/materials/icons/classes/large/ogryn",
    adamant = "content/ui/materials/icons/classes/large/adamant",
    broker  = "content/ui/materials/icons/classes/large/broker",
    cryptic = "content/ui/materials/icons/classes/large/cryptic",
}

function T.class_icon(player)
    local key = T.class_key(player)
    return CLASS_ICON[key] or CLASS_ICON.veteran
end

function T.class_color(player)
    local key = T.class_key(player)
    return (key and T.CLASS_RGB[key]) or T.CLASS_RGB_DEFAULT
end

-- ---------------------------------------------------------------------------
-- Ability tags
-- ---------------------------------------------------------------------------

--[[
    SUBSTRING patterns against the localization KEY, checked in order.

    Two things this got wrong before, both confirmed by running /hhtalents on a
    live lobby rather than by reading source:

    1. Match on `talent.display_name`, not `talent.name`. `name` is already
       localized - it returns "Zealot Stealth" or "Gain an additional charge of
       Combat Ability", and for some talents an empty string. `display_name` is
       the stable key, e.g. loc_ability_zealot_stealth.

    2. Substrings, not exact keys. The zealot dash alone appears as zealot_dash,
       zealot_targeted_dash, zealot_targeted_dash_improved and
       zealot_targeted_dash_improved_double; matching exactly would fail on
       three of four while looking correct.

    Order matters - first match wins - so anything that is a substring of
    another entry must come after it.
--]]
T.ABILITY_TAGS = {
    --[[
        Matched against the Player ability ID from equipped_abilities(), which
        is the id column in the BetterBots class docs:

            zealot_relic          Chorus of Spiritual Fortitude
            zealot_targeted_dash  Fury of the Faithful
            psyker_force_field    Telekine Shield
            ogryn_taunt_shout     Loyal Protector

        Substrings, because each ships variants - the dash alone is
        zealot_targeted_dash, _improved and _improved_double.
    --]]
    -- Zealot
    { "zealot_relic",         "BOOK" },     -- Chorus of Spiritual Fortitude
    { "bolstering_prayer",    "BOOK" },
    { "targeted_dash",        "DASH" },     -- Fury of the Faithful
    { "zealot_dash",          "DASH" },
    { "zealot_invisibility",  "STEALTH" },  -- Shroudfield
    { "zealot_stealth",       "STEALTH" },

    -- Psyker
    { "force_field",          "BUBBLE" },   -- Telekine Shield
    { "sphere_shield",        "BUBBLE" },
    { "psyker_shout",         "SHRIEK" },   -- Venting Shriek
    { "overcharge_stance",    "GAZE" },     -- Scrier's Gaze

    -- Ogryn
    { "taunt",                "TAUNT" },    -- Loyal Protector
    { "ogryn_charge",         "RUSH" },     -- Bull Rush
    { "gunlugger_stance",     "BARRAGE" },  -- Point-Blank Barrage

    -- Veteran
    { "squad_leader",         "VOC" },      -- Voice of Command
    { "ranger_stance",        "EXEC" },     -- Executioner's Stance
    { "veteran_invisibility", "STEALTH" },  -- Infiltrate

    -- Broker. Seeded from keys observed live, not from the class docs - the
    -- newer archetypes are not documented there yet.
    { "punk_rage",            "RAGE" },
    { "broker_ability_focus", "FOCUS" },
}

T.BLITZ_TAGS = {
    --[[
        "throwing_kni" - stops before the two spellings diverge.

        Fatshark uses BOTH: the ability id is zealot_throwing_knives, while the
        localization key is loc_ability_zealot_throwing_knifes. "knives" and
        "knifes" split at the fourth letter (v vs f), so any pattern containing
        either one silently fails against the other. Truncating to the common
        prefix matches both.
    --]]
    { "throwing_kni",   "KNIVES" },
    { "shock_grenade",  "STUN" },
    { "tox_grenade",    "TOX" },
    { "flash_grenade",  "FLASH" },
    { "flame_grenade",  "FIRE" },
    { "fire_grenade",   "FIRE" },
    { "chain_lightning", "CHAIN" },
    { "brain_burst",    "BURST" },
    { "smite",          "SMITE" },
    { "assail",         "ASSAIL" },
    { "krak",           "KRAK" },
    { "smoke",          "SMOKE" },
    { "frag",           "FRAG" },
    { "box_of_hurt",    "BOX" },
    { "rock",           "ROCK" },
}

-- ---------------------------------------------------------------------------
-- Player state, reachable from a unit alone
-- ---------------------------------------------------------------------------

--[[
    ALIVE is the game's own liveness table. A lookup on a freed handle is safe
    and returns nil; an ENGINE call on one is an access violation that pcall
    cannot catch. Everything below goes through this first.
--]]
function T.unit_alive(unit)
    local alive = rawget(_G, "ALIVE")
    return (unit and alive and alive[unit]) and true or false
end

--[[
    States that count as "needs help". Read from the networked character_state
    component, which is what the game's own outline extension uses - so this
    agrees with the engine rather than inferring from health.
--]]
T.DOWN_STATES = {
    knocked_down = true,
    hogtied = true,
    netted = true,
    ledge_hanging = true,
    warp_grabbed = true,
    consumed = true,
    grabbed = true,
    pounced = true,
    catapulted = true,
}

local function read_state(unit)
    local ude = ScriptUnit.has_extension(unit, "unit_data_system")
    local comp = ude and ude:read_component("character_state")
    return comp and comp.state_name
end

--[[
    Downed detection, delegated to the copied coherence_hud implementation.

    My own version read only the `character_state` component. coherence_hud
    checks FOUR:

        character_state
        disabled_character_state
        knocked_down_character_state
        ledge_hanging_character_state

    plus health is_alive / is_dead / current_health <= 0. A knocked-down player
    does not necessarily surface in `character_state` alone, which is why
    nothing was ever detected as down and the nameplate never changed.

    Falls back to the old single-component read only if the export is missing,
    so this cannot become a hard dependency on load order.
--]]
function T.is_downed(player)
    local unit = player and player.player_unit
    if not T.unit_alive(unit) then
        return false
    end

    local detector = mod.unit_is_dead_or_disabled
    if type(detector) == "function" then
        local ok, downed = pcall(detector, unit)
        if ok then
            return downed and true or false
        end
    end

    local ok, state = pcall(read_state, unit)
    return (ok and state and T.DOWN_STATES[state]) and true or false
end

--[[
    The raw character state name, or nil.

    Exposed because "needs help" and "is bleeding out" are different questions
    and the code needed to stop answering the second with the first.
--]]
function T.character_state(player)
    local unit = player and player.player_unit
    if not T.unit_alive(unit) then
        return nil
    end

    local ok, state = pcall(read_state, unit)
    return ok and state or nil
end

--[[
    KNOCKED DOWN specifically - the only state with a bleedout pool.

    T.is_downed above is the "needs help" question and is true for nine states.
    Eight of them have no bleedout: a netted or pounced teammate still has
    their ordinary health pool, which does not drain on the knocked-down timer.
    Measuring that pool and calling the result a bleedout countdown is what
    produced the ~1500-second readings.

    PlayerUnitStatus.is_knocked_down compares state_name against a single
    constant, which is exactly this - reimplemented rather than required so a
    bundle that is not loaded yet costs nothing.
--]]
function T.is_knocked_down(player)
    return T.character_state(player) == "knocked_down"
end

--[[
    A short label for a teammate who needs help but is NOT bleeding out.

    These want a rescue, not a countdown, and the thing you need to read off
    the nameplate is what has hold of them - a netted teammate needs someone to
    shoot the net, a pounced one needs the dog killed. A percentage told you
    none of that and was wrong anyway.
--]]
T.DISABLED_LABEL = {
    netted        = "NET",
    hogtied       = "TRAP",
    pounced       = "DOG",
    warp_grabbed  = "GRAB",
    consumed      = "GRAB",
    grabbed       = "GRAB",
    ledge_hanging = "LEDGE",
    catapulted    = "FLUNG",
    mutant_charged = "MUTIE",
    vortex_grabbed = "VORTEX",
    dead          = "DEAD",
}

--[[
    THE DEAD-PLAYER FALLBACK. This is the bug behind "downed suffix empty".

    The live log line was

        downed suffix empty: tags=yes bleed=yes unit=yes alive=yes
                             published=combat_ability ability_ext=yes cfg=yes

    - every dependency resolved, and still nothing was produced. Two separate
    faults, both only visible once a player actually DIED rather than went
    down:

    1. T.character_state gates on T.unit_alive, which reads the engine's ALIVE
       table. A dead player's unit is not in ALIVE, so character_state returned
       nil, so this returned nil - even though `dead` is in DISABLED_LABEL and
       would have matched. The label for the one state the caller most wanted
       was unreachable by construction.

    2. The caller had already decided this player was dead-or-disabled through
       unit_is_dead_or_disabled, which reaches that verdict via HEALTH, not via
       character_state. So the two halves disagreed: one said "dead", the other
       said "I cannot see a state", and the disagreement produced silence.

    Resolved by asking the health extension directly when the state read comes
    back empty. A unit that is out of ALIVE but still has a readable health
    extension is a corpse, and a corpse is exactly what we want to label.
--]]
local function looks_dead(unit)
    local ext = ScriptUnit.has_extension(unit, "health_system")

    if not ext then
        return false
    end

    local ok_alive, alive = pcall(ext.is_alive, ext)

    if ok_alive and alive == false then
        return true
    end

    local ok_hp, hp = pcall(ext.current_health, ext)

    return ok_hp and type(hp) == "number" and hp <= 0
end

function T.disabled_label(player)
    local state = T.character_state(player)
    local label = state and T.DISABLED_LABEL[state]

    if label then
        return label
    end

    --[[
        No readable state. Before giving up, check whether this is a corpse -
        the case the caller is most likely to be asking about, and the one the
        ALIVE gate above makes invisible.
    --]]
    local unit = player and player.player_unit

    if unit then
        local ok, dead = pcall(looks_dead, unit)

        if ok and dead then
            return T.DISABLED_LABEL.dead
        end
    end

    return nil
end

--[[
    Ability extension straight off the unit.

    The HUD path gets this via parent:get_all_player_extensions, but nameplate
    templates have no such parent - they only have the player. ability_system
    is the registered extension name, so this reaches the same object without
    needing a HUD element to ask on our behalf.
--]]
local function read_ability_ext(unit)
    return ScriptUnit.has_extension(unit, "ability_system")
end

function T.ability_extension(player)
    local unit = player and player.player_unit
    if not T.unit_alive(unit) then
        return nil
    end
    local ok, ext = pcall(read_ability_ext, unit)
    return ok and ext or nil
end

function T.talent_key(entry)
    local t = entry and entry.talent
    if not t then
        return nil
    end
    local key = t.display_name
    if type(key) == "string" and key ~= "" then
        return key
    end
    local n = t.name or t.talent_name
    return (type(n) == "string" and n ~= "") and n or nil
end

-- Plain find (the `true`), so underscores and any incidental magic characters
-- in a key cannot be reinterpreted as a pattern.
function T.match_tag(key, list)
    if not key then
        return nil
    end
    for i = 1, #list do
        if string.find(key, list[i][1], 1, true) then
            return list[i][2]
        end
    end
    return nil
end

-- ---------------------------------------------------------------------------
-- Loadout
-- ---------------------------------------------------------------------------

local CharacterSheet = nil
do
    local ok, cs = pcall(require, "scripts/utilities/character_sheet")
    CharacterSheet = ok and cs or nil
end

--[[
    ability_configuration maps an ability id to the slot it occupies:

        zealot_relic        -> slot_combat_ability
        zealot_shock_grenade-> slot_grenade_ability

    Hoisted to file scope. require() is hooked by DMF, so calling it inside a
    per-frame path pays a lookup and a hook check every frame to fetch a table
    that never changes.
--]]
--[[
    RESOLVED LAZILY, NOT ONCE AT LOAD.

    This was a one-shot pcall(require) at file scope. If the game's script
    bundle was not ready at the moment this module loaded, ABILITY_CONFIGURATION
    stayed nil FOREVER - and because the pcall swallowed the failure there was
    nothing in the log to say so. T.equipped then returned nil on its first
    line for the rest of the session, which is a silent, permanent, invisible
    failure of the whole tag feature.

    Resolved on first successful use instead, so a bundle that is not ready yet
    costs one retry rather than the feature.
--]]
local ABILITY_CONFIGURATION = nil

local function ability_configuration()
    if ABILITY_CONFIGURATION then
        return ABILITY_CONFIGURATION
    end

    local ok, consts = pcall(require, "scripts/settings/player_character/player_character_constants")
    ABILITY_CONFIGURATION = ok and consts and consts.ability_configuration or nil

    return ABILITY_CONFIGURATION
end

T.SLOT_COMBAT = "slot_combat_ability"
T.SLOT_BLITZ  = "slot_grenade_ability"

--[[
    THE ACTUAL SOURCE OF TRUTH for what a teammate has equipped.

    Read from that player's OWN ability extension, not from their profile.
    This is what TalentUI does, and it is why TalentUI is right where my earlier
    attempt was not: CharacterSheet.class_loadout resolves a talent tree, which
    is a different question from "what is in this unit's ability slots right
    now".

    The returned `ability_id` is the documented Player ability ID -
    zealot_relic, psyker_force_field, ogryn_taunt_shout - which is precisely
    the string the tag patterns are written against.

    `ability_settings.hud_icon` is the real icon the game uses for that ability,
    so no icon lookup table is needed either.
--]]
function T.equipped(extensions, slot_type)
    local ext = extensions and extensions.ability
    local config = ability_configuration()

    if not ext or not config then
        return nil, nil
    end

    local ok, equipped = pcall(ext.equipped_abilities, ext)
    if not ok or type(equipped) ~= "table" then
        return nil, nil
    end

    for ability_type, settings in pairs(equipped) do
        -- Empty slot entries appear here after a loadout sync; skipping them
        -- rather than indexing them is what stops this throwing mid-mission.
        if settings and config[ability_type] == slot_type then
            --[[
                RETURNS settings.name, NOT THE LOOP KEY.

                The comment above this function claimed the key was "the
                documented Player ability ID - zealot_relic,
                psyker_force_field, ogryn_taunt_shout". It is not. Both this
                table and ability_configuration are keyed by ability TYPE, so
                the key is the literal string "combat_ability" for every
                player of every class, and every tag pattern here is written
                against real ids - so nothing ever matched.

                player_abilities.lua:12 sets entry_data.name = ability_name
                when it builds PlayerAbilities, so the real id is on the
                value. The loop variable is renamed to say what it actually
                holds, because the old name is what made the bug invisible.
            --]]
            return settings.name or ability_type, settings
        end
    end

    return nil, nil
end

local EMPTY_TALENTS = {}

--[[
    Memoised on profile + talents identity, both of which are REPLACED rather
    than mutated when someone changes loadout.

    This matters more than it looks: CharacterSheet.class_loadout resolves the
    entire talent tree and logs a line per priority comparison. Uncached, per
    teammate per frame, it produced 171,000 log lines in a 28 minute session -
    26 MB of synchronous disk writes, which is a stutter source, not just noise.
--]]
local cache = setmetatable({}, { __mode = "k" })

function T.loadout(player)
    if not CharacterSheet or not CharacterSheet.class_loadout or not player then
        return nil
    end

    local ok, profile = pcall(player.profile, player)
    if not ok or not profile then
        return nil
    end

    local talents = profile.talents
    local c = cache[player]
    if c and c.profile == profile and c.talents == talents then
        return c.data
    end

    local data = { ability = {}, blitz = {}, aura = {} }
    if not pcall(CharacterSheet.class_loadout, profile, data, false, talents or EMPTY_TALENTS) then
        return nil
    end

    cache[player] = { profile = profile, talents = talents, data = data }
    return data
end

--[[
    Tags computed once and hung off the loadout table.

    Storing them there means they inherit the loadout's invalidation for free,
    instead of needing a second cache with its own staleness rules. `false`
    rather than nil for "no tag", so an unrecognised ability does not rescan
    every pattern on every frame - that being exactly the case that scans the
    whole list.
--]]
--[[
    The combat-ability tag for a player, from the unit alone.

    Wraps T.equipped so callers that only have a player - nameplate templates,
    world markers - can get the same answer the team strip shows, without a HUD
    parent to resolve extensions for them.

    Cached per unit: equipped_abilities() walks a table and this is called per
    nameplate per frame. The equipped ability cannot change mid-mission, so the
    lookup happens once. Weak keys, so a despawned unit is not pinned.
--]]
local tag_by_unit = setmetatable({}, { __mode = "k" })

function T.ability_tag_of(player)
    local unit = player and player.player_unit
    if not T.unit_alive(unit) then
        return nil
    end

    local cached = tag_by_unit[unit]
    if cached ~= nil then
        return cached or nil
    end

    local ext = T.ability_extension(player)
    if not ext then
        -- Not cached: extensions can be absent for a frame or two on spawn,
        -- and caching that would make the tag permanently missing.
        return nil
    end

    local id = T.equipped({ ability = ext }, T.SLOT_COMBAT)

    --[[
        A miss is NOT cached when the ability id could not be read at all.

        The old code cached `false` for any failure, so a single early frame
        where the config or the equipped list was not ready yet poisoned that
        unit for the whole mission - the tag could never appear afterwards even
        once everything was available. Only a real "resolved, but no tag
        matches" result is worth remembering.
    --]]
    if not id then
        return nil
    end

    local tag = T.match_tag(id, T.ABILITY_TAGS) or false

    tag_by_unit[unit] = tag
    return tag or nil
end

function T.tags(loadout)
    if not loadout then
        return nil, nil
    end
    if loadout.__tag_ability == nil then
        loadout.__tag_ability = T.match_tag(T.talent_key(loadout.ability), T.ABILITY_TAGS) or false
        loadout.__tag_blitz   = T.match_tag(T.talent_key(loadout.blitz), T.BLITZ_TAGS) or false
    end
    return loadout.__tag_ability or nil, loadout.__tag_blitz or nil
end

mod.__dio_tags = T

return T
