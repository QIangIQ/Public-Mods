local mod = get_mod("DiosHandholder")

local CharacterSheet
local success_require = pcall(function()
	CharacterSheet = require("scripts/utilities/character_sheet")
end)

if not success_require or not CharacterSheet then
	mod:error("Failed to load CharacterSheet module")
	CharacterSheet = {}
	CharacterSheet.class_loadout = function() end
end

local UIHudSettings = require("scripts/settings/ui/ui_hud_settings")
local HudElementPlayerAbilitySettings = require("scripts/ui/hud/elements/player_ability/hud_element_player_ability_settings")
local FixedFrame = require("scripts/utilities/fixed_frame")
-- Hoisted from inside get_player_ability_by_type, which runs once per frame
-- per teammate. require() is hooked by DMF, so calling it in a per-frame path
-- pays a lookup and hook-check every frame to fetch a table that never changes.
local PlayerCharacterConstants = require("scripts/settings/player_character/player_character_constants")
local ABILITY_CONFIGURATION = PlayerCharacterConstants.ability_configuration

local TalentUISettings = mod:io_dofile("Dio's Handholder/scripts/mods/DiosHandholder/DHT_settings")

local teammate_abilities_data = {}

mod.teammate_abilities_data = teammate_abilities_data

local player_previous_human_state = {}


--[[
	CACHED. This previously did a full talent-tree resolution on EVERY call.

	It is reached from update_teammate_all_abilities, which runs once per frame
	per teammate, and was called twice per teammate (aura and blitz).
	CharacterSheet.class_loadout resolves the whole talent tree and logs an INFO
	line for every priority comparison it makes. Measured over a 28 minute
	session: 171,191 log lines and 26 MB of synchronous disk writes, at roughly
	360 full resolutions per second.

	Talents cannot change mid-mission, so the result is memoized per player and
	rebuilt only when the profile table or its talents table is REPLACED, which
	is what loadout sync does. One resolution now fills all three keys instead
	of one resolution per key.

	EMPTY_TALENTS is a shared constant on purpose: writing `profile.talents or {}`
	inline would build a fresh table every call, so the identity comparison below
	would never match and the cache would never hit.

	Weak keys so a departing player is not pinned in memory by this cache.
--]]
local EMPTY_TALENTS = {}
local _sheet_cache = setmetatable({}, { __mode = "k" })

local function get_talent_from_character_sheet(player, ability_key)
	local profile = player and player:profile()

	if not profile then
		return nil
	end

	local talents = profile.talents
	local cached = _sheet_cache[player]

	if cached and cached.profile == profile and cached.talents == talents then
		return cached.loadout[ability_key]
	end

	local loadout_data = {
		ability = {},
		blitz = {},
		aura = {},
	}

	-- Arguments handed straight to pcall rather than through a closure, so the
	-- rebuild path allocates nothing beyond loadout_data itself.
	local success = pcall(CharacterSheet.class_loadout, profile, loadout_data, false, talents or EMPTY_TALENTS)

	if not success then
		return nil
	end

	_sheet_cache[player] = {
		profile = profile,
		talents = talents,
		loadout = loadout_data,
	}

	return loadout_data[ability_key]
end

local TALENT_ABILITY_METADATA = mod.TALENT_ABILITY_METADATA

local function get_player_ability_by_type(player, extensions, slot_type)
	if slot_type == "slot_coherency_ability" then
		local aura_entry = get_talent_from_character_sheet(player, "aura")

		if aura_entry and aura_entry.icon then
			return {
				ability_id = "aura",
				ability_type = "coherency_ability",
				icon = aura_entry.icon,
				name = aura_entry.talent and aura_entry.talent.display_name or "Aura",
			}
		end

		return nil
	end
	
	if not extensions or not extensions.ability then
		return nil
	end
	
	local ability_extension = extensions.ability
	local equipped_abilities = ability_extension:equipped_abilities()
	
	if not equipped_abilities then
		return nil
	end
	
	local ability_configuration = ABILITY_CONFIGURATION
	
	for ability_id, ability_settings in pairs(equipped_abilities) do
		if not ability_settings then
			-- empty slot entry from ability extension; skip (avoids errors after loadout sync changes)
		else
		local slot_id = ability_configuration[ability_id]
		if slot_id == slot_type then
			local ability_type
			if slot_type == "slot_combat_ability" then
				ability_type = "combat_ability"
			elseif slot_type == "slot_grenade_ability" then
				ability_type = "grenade_ability"
			else
				ability_type = nil
			end
			
			if ability_type then
				local icon = nil

				if slot_type == "slot_grenade_ability" then
					local blitz_entry = get_talent_from_character_sheet(player, "blitz")
					icon = blitz_entry and blitz_entry.icon

					if not icon and extensions.visual_loadout and extensions.unit_data then
						local inventory_component = extensions.unit_data:read_component("inventory")
						if inventory_component then
							local visual_loadout_extension = extensions.visual_loadout
							local slot_name = "slot_grenade_ability"
							local item_name = inventory_component[slot_name]
							local weapon_template = item_name and visual_loadout_extension:weapon_template_from_slot(slot_name)

							if weapon_template and weapon_template.hud_icon_small then
								icon = weapon_template.hud_icon_small
							end
						end
					end

					if not icon then
						icon = ability_settings.hud_icon
					end
				else
					icon = ability_settings.hud_icon
				end
				
				--[[
					THE LOOP KEY IS THE ABILITY TYPE, NOT THE ABILITY ID.

					This is why downed teammates showed "TRAP" at the res totem
					instead of their ability, and why the diagnostic kept
					printing published=combat_ability.

					player_character_constants.lua:722 is keyed by TYPE:

						ability_configuration = {
							combat_ability     = "slot_combat_ability",
							grenade_ability    = "slot_grenade_ability",
							pocketable_ability = "slot_pocketable_small",
						}

					and PlayerUnitAbilityExtension stores equipped abilities
					the same way - _equipped_abilities[ability_type] = ability.
					So the loop variable named `ability_id` holds the literal
					string "combat_ability" for every player of every class.

					Every tag pattern is written against real ids -
					zealot_relic, psyker_force_field, ogryn_taunt_shout - so
					matching against "combat_ability" could never hit, the tag
					was always nil, and the nameplate fell through to whatever
					disabled label was going.

					The real id is on the VALUE: player_abilities.lua:12 does
					entry_data.name = ability_name when it builds the table, so
					ability_settings.name is "zealot_relic". The loop key is
					kept as a fallback only so a future patch that changes the
					shape degrades to the old behaviour rather than to nil.
				--]]
				return {
					ability_id = ability_settings.name or ability_id,
					ability_type = ability_type,
					icon = icon,
					name = ability_settings.name,
				}
			end
		end
		end
	end
	
	return nil
end

--[[
	THE "STUCK AT 50-55 s" BUG LIVED HERE.

	This used the husk extension's own get_ability_resource_regen_progress,
	which subtracts charges x an UNBUFFED cost from a BUFFED resource. With
	any cooldown reduction (curio perks, the psyker aura, talents) the result
	clamps to a full missing charge, progress reads 0, and the panel showed
	the whole buffed cooldown - 52.8 s or 55.2 s on a 60 s ability - frozen,
	often on an ability that was already up. Full write-up in
	DHT_ability_clock.lua, which now does the reading for both this file and
	the local timer.

	Returns (progress 0..1, seconds_left or nil, clock) - same first two
	values as before, so callers did not have to change shape.
--]]
local Clock = type(mod.AbilityClock) == "table" and mod.AbilityClock or nil

-- One reused result table per ability type. Read immediately, never held.
local _clock_out = {
	combat_ability = {},
	grenade_ability = {},
	pocketable_ability = {},
}

local function read_clock(ability_extension, ability_type)
	if not Clock or not ability_extension or not ability_type then
		return nil
	end

	local out = _clock_out[ability_type]

	if not out then
		out = {}
		_clock_out[ability_type] = out
	end

	local ok, res = pcall(Clock.read, ability_extension, ability_type, out)

	if ok and type(res) == "table" and res.equipped then
		return res
	end

	return nil
end

local function ability_cooldown_info(ability_extension, ability_type)
	--[[
		Pre-1.13 builds kept an absolute cooldown. Kept so an old game build
		still reads, and checked first because it is exact when present.
	--]]
	if ability_extension.remaining_ability_cooldown then
		local remaining = ability_extension:remaining_ability_cooldown(ability_type) or 0
		local max_cd = ability_extension:max_ability_cooldown(ability_type) or 0
		local progress = max_cd > 0 and (1 - math.clamp(remaining / max_cd, 0, 1)) or 1

		return progress, remaining > 0 and remaining or nil, nil
	end

	local clock = read_clock(ability_extension, ability_type)

	if not clock then
		-- No reading: claim nothing rather than print a wrong number.
		return 1, nil, nil
	end

	return clock.progress or 1, clock.seconds, clock
end

--[[
	Archetype test for the Ogryn-only blitz charge display below.

	player:archetype_name() is the cheap path; the profile table is the
	fallback for husks/bots where the method may be absent. pcall'd because
	this runs per teammate per frame and a nil profile mid-join must not throw.
--]]
local function is_ogryn(player)
	if not player then
		return false
	end

	local ok, name = pcall(function()
		if player.archetype_name then
			return player:archetype_name()
		end
		local profile = player.profile and player:profile()
		local archetype = profile and profile.archetype
		return type(archetype) == "table" and archetype.name or nil
	end)

	return ok and name == "ogryn"
end

local function get_ability_state(player, extensions, ability_type)
	if ability_type == "coherency_ability" then
		return 1, false, nil, false, nil
	end
	
	if not extensions or not extensions.ability then
		return 1, false, nil, false, nil
	end
	
	local ability_extension = extensions.ability
	
	if not ability_extension:ability_is_equipped(ability_type) then
		return 1, false, nil, false, nil
	end
	
	local remaining_charges = ability_extension:remaining_ability_charges(ability_type)
	local max_charges = ability_extension:max_ability_charges(ability_type)
	
	local uses_charges = max_charges and max_charges > 1
	local has_charges_left = remaining_charges and remaining_charges > 0 or false
	
	local cooldown_progress, _, clock = ability_cooldown_info(ability_extension, ability_type)

	if clock then
		has_charges_left = clock.ready
		remaining_charges = clock.charges
	end
	
	--[[
		A CHARGE IN HAND IS NOT A COOLDOWN.

		cooldown_progress tracks regeneration of the NEXT charge
		(remaining_ability_cooldown -> cooldown - fixed_frame_t,
		player_unit_ability_extension.lua:732), while remaining_ability_charges
		-> component.num_charges (:800) is what you can actually cast now.

		On a multi-charge ability the regen clock keeps running while a charge
		is still available, so this read "on cooldown" and the panel printed
		the next-charge time - 55s on the Zealot book - for an ability that was
		ready. has_charges_left is computed just above; it just was not used.
	--]]
	local on_cooldown = cooldown_progress < 1 and not has_charges_left
	
	return cooldown_progress, on_cooldown, remaining_charges, has_charges_left, max_charges
end

local function get_ability_state_colors(on_cooldown, uses_charges, has_charges_left)
	local source_colors
	
	if on_cooldown then
		if uses_charges then
			if has_charges_left then
				source_colors = HudElementPlayerAbilitySettings.has_charges_cooldown_colors
			else
				source_colors = HudElementPlayerAbilitySettings.out_of_charges_cooldown_colors
			end
		else
			source_colors = HudElementPlayerAbilitySettings.cooldown_colors
		end
	elseif not uses_charges or uses_charges and has_charges_left then
		source_colors = HudElementPlayerAbilitySettings.active_colors
	else
		source_colors = HudElementPlayerAbilitySettings.inactive
	end
	
	return source_colors
end

local function get_ability_gradient_map(ability_id)
	if ability_id == "ability" then
		return "content/ui/textures/color_ramps/talent_ability"
	elseif ability_id == "blitz" then
		return "content/ui/textures/color_ramps/talent_blitz"
	elseif ability_id == "aura" then
		return "content/ui/textures/color_ramps/talent_aura"
	end
	
	return nil
end

local function get_ability_material_settings(ability_id, on_cooldown, uses_charges, has_charges_left, max_charges)
	if not TalentUISettings or not TalentUISettings.teammate_ability_icon_material_settings then
		return {intensity = 0, saturation = 1}
	end
	
	local icon_settings = TalentUISettings.teammate_ability_icon_material_settings
	if not icon_settings[ability_id] then
		return {intensity = 0, saturation = 1}
	end
	
	local ability_settings = icon_settings[ability_id]
	local state_key
	
	if ability_id == "aura" then
		state_key = "active"
	elseif ability_id == "blitz" then
		if max_charges == 0 then
			if on_cooldown then
				state_key = "on_cooldown"
			else
				state_key = "active"
			end
		else
			if has_charges_left then
				state_key = "active"
			else
				state_key = "inactive"
			end
		end
	elseif ability_id == "ability" then
		if on_cooldown then
			state_key = "on_cooldown"
		else
			state_key = "active"
		end
	else
		if on_cooldown then
			if uses_charges then
				if has_charges_left then
					state_key = "has_charges_cooldown"
				else
					state_key = "out_of_charges_cooldown"
				end
			else
				state_key = "on_cooldown"
			end
		elseif not uses_charges or (uses_charges and has_charges_left) then
			state_key = "active"
		else
			state_key = "inactive"
		end
	end
	
	local state_settings = ability_settings[state_key]
	if state_settings then
		local intensity = state_settings.intensity or 0
		local saturation = state_settings.saturation or 1
		return {
			intensity = intensity,
			saturation = saturation,
		}
	end
	
	return {intensity = 0, saturation = 1}
end

local function set_team_talent_widget_visible(widget, visible)
	if not widget or not widget.content then
		return
	end

	widget.visible = true

	if widget.content.visible ~= visible then
		widget.content.visible = visible
		widget.dirty = true
	end
end

local function hide_all_ability_widgets(self)
	for _, ability_type in ipairs(TALENT_ABILITY_METADATA) do
		local icon_widget = self._widgets_by_name["talent_ui_all_" .. ability_type.id .. "_icon"]
		local text_widget = self._widgets_by_name["talent_ui_all_" .. ability_type.id .. "_text"]

		set_team_talent_widget_visible(icon_widget, false)
		set_team_talent_widget_visible(text_widget, false)
	end
end

local function format_cooldown_text(ability_ext, ability_type_name, format_type, uses_charges, remaining_charges)
	local charges_text = ""
	local cooldown_text = ""
	
	if uses_charges and remaining_charges ~= nil and remaining_charges > 0 then
		charges_text = tostring(remaining_charges)
	end
	
	local progress, remaining_cooldown, clock = ability_cooldown_info(ability_ext, ability_type_name)

	--[[
		A single-charge ability with its charge in hand is READY: no number.
		Multi-charge abilities keep "charges (next charge)" while they refill.
	--]]
	if clock and clock.ready and not uses_charges then
		progress = 1
	end

	if progress < 1 then
		if format_type == "time" then
			if remaining_cooldown and remaining_cooldown > 0 then
				cooldown_text = string.format("%d", math.ceil(remaining_cooldown))
			end
		elseif format_type == "percent" then
			local percent = progress * 100
			if percent < 99 then
				cooldown_text = string.format("%d%%", math.floor(percent))
			end
		end
	end
	
	if charges_text ~= "" and cooldown_text ~= "" then
		return string.format("%s (%s)", charges_text, cooldown_text)
	elseif charges_text ~= "" then
		return charges_text
	elseif cooldown_text ~= "" then
		return cooldown_text
	end
	
	return ""
end

local function update_teammate_all_abilities(self, player, dt)
	local player_name = player:name()

	-- if self._show_as_dead or self._dead or self._hogtied then
	-- 	hide_all_ability_widgets(self)
	-- 	return
	-- end

	if not player_name then
		hide_all_ability_widgets(self)
		return
	end

	local extensions = self:_player_extensions(player)

	if not extensions then
		hide_all_ability_widgets(self)
		return
	end

	local is_human_controlled = player:is_human_controlled()
	local was_human_controlled = player_previous_human_state[player_name]

	if was_human_controlled and not is_human_controlled then
		mod.clear_teammate_all_abilities_data(player_name)
	end

	player_previous_human_state[player_name] = is_human_controlled

	local show_for_bots = TalentUISettings and TalentUISettings.show_abilities_for_bots ~= false
	--[[
		PUBLISH THE COMBAT ABILITY BEFORE THE DEAD/HOGTIED GATE.

		The gate below returns for _show_as_dead, _dead and _hogtied - which is
		correct for the icons, since a downed teammate's ability row is hidden.
		But it is the exact case the downed nameplate needs, so anything placed
		after it can never run when it matters. That is why the tag resolved to
		nil and the nameplate fell back to "[DOWN]": not a broken resolver, a
		resolver that was never reached.

		Resolved here instead, from the same extensions the icons use, so the
		answer is recorded whether the player is up or down. Weak-keyed on the
		player and written only on change, so a stable loadout costs one
		comparison per frame and no allocation.
	--]]
	do
		local combat = get_player_ability_by_type(player, extensions, "slot_combat_ability")
		local ability_id = combat and combat.ability_id

		if ability_id then
			local published = mod.__dio_combat_ability

			if not published then
				published = setmetatable({}, { __mode = "k" })
				mod.__dio_combat_ability = published
			end

			if published[player] ~= ability_id then
				published[player] = ability_id
			end
		end
	end

	if (not show_for_bots and not player:is_human_controlled()) or self._show_as_dead or self._dead or self._hogtied then
		hide_all_ability_widgets(self)
		return
	end
	
	local icon_size = mod:get("teammate_ability_icon_size") or TalentUISettings.teammate_ability_icon_size
	
	for i = 1, #TALENT_ABILITY_METADATA do
		-- if self._show_as_dead or self._dead or self._hogtied then
		-- 	hide_all_ability_widgets(self)
		-- 	return
		-- end
		
		local ability_info = TALENT_ABILITY_METADATA[i]
		local icon_widget = self._widgets_by_name["talent_ui_all_" .. ability_info.id .. "_icon"]
		local text_widget = self._widgets_by_name["talent_ui_all_" .. ability_info.id .. "_text"]
		
		if icon_widget then
			local data_key = player_name .. "_" .. ability_info.id
			
			local ability_data = get_player_ability_by_type(player, extensions, ability_info.slot)

			if ability_data and ability_data.ability_type and ability_data.icon then
				local cached_data = teammate_abilities_data[data_key]
				if not cached_data or cached_data.ability_type ~= ability_data.ability_type or cached_data.icon ~= ability_data.icon then
					teammate_abilities_data[data_key] = {
						ability_id = ability_data.ability_id,
						ability_type = ability_data.ability_type,
						icon = ability_data.icon,
					}
				end
			end

			local has_ability = teammate_abilities_data[data_key] and teammate_abilities_data[data_key].ability_type
			local show_icon = true
			if ability_info.id == "ability" then
				show_icon = mod:get("show_teammate_ability_icon")
			elseif ability_info.id == "blitz" then
				show_icon = mod:get("show_teammate_blitz_icon")
			elseif ability_info.id == "aura" then
				show_icon = mod:get("show_teammate_aura_icon")
			end
			
			-- Проверяем состояние смерти в цикле и скрываем иконки явно
			if self._show_as_dead or self._dead or self._hogtied then
				set_team_talent_widget_visible(icon_widget, false)
				set_team_talent_widget_visible(text_widget, false)
			elseif has_ability and show_icon then
				local ability_type = teammate_abilities_data[data_key].ability_type
				local icon = teammate_abilities_data[data_key].icon
				
				if text_widget and text_widget.style and text_widget.style.text then
					if text_widget.style.text.size then
						if text_widget.style.text.size[1] ~= icon_size or text_widget.style.text.size[2] ~= icon_size then
							text_widget.style.text.size[1] = icon_size
							text_widget.style.text.size[2] = icon_size
							text_widget.dirty = true
						end
					end
				end
				
				local cooldown_progress, on_cooldown, remaining_charges, has_charges_left, max_charges = get_ability_state(player, extensions, ability_type)
				local uses_charges = max_charges and max_charges > 1
				
				local gradient_map = get_ability_gradient_map(ability_info.id)
				if gradient_map and icon_widget.style and icon_widget.style.icon and icon_widget.style.icon.material_values and icon_widget.style.icon.material_values.gradient_map ~= gradient_map then
					icon_widget.style.icon.material_values.gradient_map = gradient_map
					icon_widget.dirty = true
				end
				
				local material_settings = get_ability_material_settings(ability_info.id, on_cooldown, uses_charges, has_charges_left, max_charges)
				
				if icon_widget.style and icon_widget.style.icon and icon_widget.style.icon.material_values then
					local material_values = icon_widget.style.icon.material_values
					local needs_update = false
					
					if material_values.intensity ~= material_settings.intensity then
						material_values.intensity = material_settings.intensity
						needs_update = true
					end
					
					if material_values.saturation ~= material_settings.saturation then
						material_values.saturation = material_settings.saturation
						needs_update = true
					end
					
					if needs_update then
						icon_widget.dirty = true
					end
				end
				
				if icon and icon_widget.style and icon_widget.style.icon and icon_widget.style.icon.material_values then
					local material_values = icon_widget.style.icon.material_values
					if material_values.icon ~= icon then
						material_values.icon = icon
						icon_widget.dirty = true
					end
				end
				
				local needs_icon_update = false

				if icon_widget.content.visible ~= true then
					set_team_talent_widget_visible(icon_widget, true)
					needs_icon_update = true
				end

				if needs_icon_update then
					icon_widget.dirty = true
				end
				
				if text_widget then
					local display_text = ""
					local show_text = true
					
					if ability_info.id == "ability" then
						show_text = mod:get("show_teammate_ability_cooldown")
						
						if show_text and extensions and extensions.ability then
							local ability_ext = extensions.ability
							local format_type = mod:get("cooldown_format")
							display_text = format_cooldown_text(ability_ext, "combat_ability", format_type, uses_charges, remaining_charges)
						end
					elseif ability_info.id == "blitz" then
						show_text = mod:get("show_teammate_blitz_charges")
						
						if show_text and extensions and extensions.ability then
							local ability_ext = extensions.ability
							--[[
								OGRYN'S SINGLE-CHARGE BLITZ GETS A COUNT TOO.

								This gated only on `uses_charges`, which is `max_charges > 1`
								(line 276) - MULTI-charge only. A one-charge blitz, the Ogryn
								frag bomb, fell to the else branch and
								showed a cooldown number with no indication of whether the
								charge was in hand. "Is the nuke up?" is the question this
								panel exists to answer, and 0 or 1 answers it.

	Ogryn only: no other class has a one-charge grenade, so widening
	this for everyone would just put a permanent "1" on blitzes that
	never needed one.

								`uses_charges` is left alone: it still drives the icon colours
								and material settings (588, 299, 333), where "more than one
								charge" is the meaning that is wanted there.
							--]]
							if uses_charges or (is_ogryn(player) and max_charges and max_charges >= 1) then
								local charges = ability_ext:remaining_ability_charges("grenade_ability")
								if charges ~= nil and charges >= 0 then
									display_text = tostring(charges)
								end
							else
								local format_type = mod:get("cooldown_format")
								display_text = format_cooldown_text(ability_ext, "grenade_ability", format_type, uses_charges, remaining_charges)
							end
						end
					end
					
					local needs_text_update = false
					local new_visible = show_text and display_text ~= ""
					
					if text_widget.content.text ~= display_text then
						text_widget.content.text = display_text
						needs_text_update = true
					end
					
					if text_widget.content.visible ~= new_visible then
						set_team_talent_widget_visible(text_widget, new_visible)
						needs_text_update = true
					end
					
					if needs_text_update then
						text_widget.dirty = true
					end
				end
			else
				set_team_talent_widget_visible(icon_widget, false)

				if text_widget then
					set_team_talent_widget_visible(text_widget, false)
				end
			end
		end
	end
end

mod.update_teammate_all_abilities = update_teammate_all_abilities

mod.clear_teammate_all_abilities_data = function(player_name)
	local keys_to_remove = {}
	
	for key, _ in pairs(teammate_abilities_data) do
		if string.find(key, player_name .. "_", 1, true) == 1 then
			table.insert(keys_to_remove, key)
		end
	end
	
	for _, key in ipairs(keys_to_remove) do
		teammate_abilities_data[key] = nil
	end
	
	player_previous_human_state[player_name] = nil
end
