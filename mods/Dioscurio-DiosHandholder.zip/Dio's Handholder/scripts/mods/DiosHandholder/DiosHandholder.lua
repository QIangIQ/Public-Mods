local mod = get_mod("DiosHandholder")
local UISoundEvents = require("scripts/settings/ui/ui_sound_events")
local UIWidget = require("scripts/managers/ui/ui_widget")
local ui_settings_ok, UISettings = pcall(require, "scripts/settings/ui/ui_settings")
local profile_utils_ok, ProfileUtils = pcall(require, "scripts/utilities/profile_utils")

if not ui_settings_ok then
    UISettings = nil
end

if not profile_utils_ok then
    ProfileUtils = nil
end

mod.detected_archetype = nil
mod.debug_last_archetype = nil
mod.hud_players = {}
mod.previous_player_states = {}
mod.last_out_sound_t = 0
mod.debug_last_hud_signature = nil
mod.native_coherence_by_unit = {}
mod.local_player_unit = nil
mod.local_player_unit_from_input = nil
mod.outline_system = nil
mod.human_player_by_unit = {}
mod.tracked_health_markers = {}

local MAX_HUD_PLAYERS = 4
local OUT_SOUND_COOLDOWN = 5
local OUT_SOUND_EVENT = UISoundEvents.default_click
local HEALTH_MARKER_NAME = "dio_handholder_teammate_health_marker"
local ICON_PACKAGE_REF = "dio_handholder_icons"
local WORLD_NAMEPLATE_MAX_DISTANCE = 1000
local WORLD_LOCATOR_BORDER = 3
local WORLD_HEALTH_BAR_WIDTH = 132
local WORLD_HEALTH_BAR_HEIGHT = 7
local COLOR_PRESETS = {
    gold = { 255, 255, 215, 55 },
    blue = { 255, 80, 190, 255 },
    green = { 255, 95, 235, 110 },
    purple = { 255, 185, 120, 255 },
    red = { 255, 255, 80, 65 },
    white = { 255, 255, 255, 255 },
    black = { 255, 0, 0, 0 },
}
local CLASS_COLOR_DEFAULTS = {
    veteran = { 255, 90, 175, 255 },
    zealot = { 255, 255, 70, 55 },
    psyker = { 255, 125, 95, 255 },
    ogryn = { 255, 245, 165, 65 },
    adamant = { 255, 230, 75, 160 },
    broker = { 255, 70, 235, 115 },
    cryptic = { 255, 75, 210, 255 },
}
local PLATFORM_COLOR_DEFAULTS = {
    steam = { 255, 210, 210, 210 },
    xbox = { 255, 80, 220, 80 },
    psn = { 255, 80, 160, 255 },
    ps5 = { 255, 80, 160, 255 },
    unknown = { 255, 190, 190, 190 },
}
local ICON_PACKAGES = {
    -- Telas onde ícones de classe/perfil aparecem
    "packages/ui/views/main_menu_view/main_menu_view",
    "packages/ui/views/main_menu_background_view/main_menu_background_view",
    "packages/ui/views/character_appearance_view/character_appearance_view",
    "packages/ui/views/class_selection_view/class_selection_view",
    "packages/ui/views/options_view/options_view",
    "packages/ui/views/inventory_view/inventory_view",
    "packages/ui/views/inventory_background_view/inventory_background_view",
    "packages/ui/views/inventory_cosmetics_view/inventory_cosmetics_view",
    "packages/ui/views/player_character_options_view/player_character_options_view",
    "packages/ui/views/talent_builder_view/talent_builder_view",
    "packages/ui/views/social_menu_view/social_menu_view",
    "packages/ui/views/social_menu_roster_view/social_menu_roster_view",
    "packages/ui/views/lobby_view/lobby_view",

    -- HUDs de gameplay
    "packages/ui/hud/team_player_panel/team_player_panel",
    "packages/ui/hud/tactical_overlay/tactical_overlay",
    "packages/ui/hud/world_markers/world_markers",
    "packages/ui/hud/player_ability/player_ability",
}
local PLATFORM_ICONS = {
    steam = "\238\129\171",
    xbox = "\238\129\172",
    psn = "\238\129\177",
    ps5 = "\238\129\177",
    unknown = "\238\129\175",
}
local UNKNOWN_CLASS_ICON = "\238\128\133"
local ICON_PACKAGE_RETRY_COOLDOWN = 10
local loaded_icon_packages = {}
local icon_packages_all_loaded = false
local icon_package_next_retry_t = 0

local function package_retry_time()
    if Managers and Managers.time and Managers.time.time then
        local ok, t = pcall(function()
            return Managers.time:time("main")
        end)

        if ok and type(t) == "number" then
            return t
        end
    end

    if os and os.clock then
        return os.clock()
    end

    return 0
end

local function get_setting(setting_id, fallback)
    if not mod.get then
        return fallback
    end

    local ok, value = pcall(mod.get, mod, setting_id)

    if ok and value ~= nil then
        return value
    end

    return fallback
end

local function get_bool_setting(setting_id, fallback)
    return get_setting(setting_id, fallback) ~= false
end

local RUNTIME_TEXT = {
    coherence_left = {
        en = "You left coherence.",
        ["pt-br"] = "Você saiu da coerência.",
        es = "Saliste de coherencia.",
    },
    coherence_entered = {
        en = "You entered coherence.",
        ["pt-br"] = "Você entrou em coerência.",
        es = "Entraste en coherencia.",
    },
    language_changed = {
        en = "Coherence HUD language changed. HUD text updates now; reload mods or restart the game to rebuild DMF menu labels.",
        ["pt-br"] = "Idioma do Coherence HUD alterado. Textos da HUD atualizam agora; recarregue os mods ou reinicie o jogo para reconstruir as labels do DMF.",
        es = "Idioma de Coherence HUD cambiado. El texto de la HUD se actualiza ahora; recarga mods o reinicia el juego para reconstruir las etiquetas de DMF.",
    },
    player_fallback = {
        en = "Player %s",
        ["pt-br"] = "Jogador %s",
        es = "Jugador %s",
    },
    class_veteran = {
        en = "Veteran",
        ["pt-br"] = "Veterano",
        es = "Veterano",
    },
    class_zealot = {
        en = "Zealot",
        ["pt-br"] = "Fanático",
        es = "Fanático",
    },
    class_psyker = {
        en = "Psyker",
        ["pt-br"] = "Psyker",
        es = "Psíquico",
    },
    class_ogryn = {
        en = "Ogryn",
        ["pt-br"] = "Ogryn",
        es = "Ogryn",
    },
    class_adamant = {
        en = "Arbites",
        ["pt-br"] = "Árbitro",
        es = "Árbitro",
    },
    class_broker = {
        en = "Hive Scum",
        ["pt-br"] = "Escória da Colmeia",
        es = "Escoria de la Colmena",
    },
    class_cryptic = {
        en = "Skitarii",
        ["pt-br"] = "Skitarii",
        es = "Skitarii",
    },
}

local function normalize_language(language)
    language = tostring(language or "en"):lower()

    if language == "pt_br" or language == "br-pt" then
        return "pt-br"
    end

    if language ~= "en" and language ~= "pt-br" and language ~= "es" then
        return "en"
    end

    return language
end

local function tr(key, ...)
    local language = normalize_language(get_setting("language", "en"))
    local entry = RUNTIME_TEXT[key]
    local text = entry and (entry[language] or entry.en) or tostring(key)

    if select("#", ...) > 0 then
        local ok, formatted = pcall(string.format, text, ...)

        if ok then
            return formatted
        end
    end

    return text
end

local CLASS_LOCALIZATION_KEYS = {
    veteran = "loc_class_veteran_name",
    zealot = "loc_class_zealot_name",
    psyker = "loc_class_psyker_name",
    ogryn = "loc_class_ogryn_name",
    adamant = "loc_class_adamant_name",
    broker = "loc_class_broker_name",
}

local function localize_game_text(localization_key)
    if type(localization_key) ~= "string" or localization_key == "" or not Localize then
        return nil
    end

    local ok, text = pcall(Localize, localization_key)

    if ok and type(text) == "string" and text ~= "" and text ~= localization_key then
        return text
    end

    return nil
end

local function clamp255(value, fallback)
    value = tonumber(value)

    if not value then
        return fallback
    end

    if value < 0 then
        return 0
    end

    if value > 255 then
        return 255
    end

    return math.floor(value + 0.5)
end

local function safe_color_component(value, fallback)
    value = tonumber(value)

    if not value then
        return fallback
    end

    if value < 0 then
        return 0
    end

    if value > 255 then
        return 255
    end

    return math.floor(value + 0.5)
end

local function normalize_color_array(color)
    if type(color) ~= "table" then
        return { 255, 255, 255, 255 }
    end

    return {
        safe_color_component(color[1], 255),
        safe_color_component(color[2], 255),
        safe_color_component(color[3], 255),
        safe_color_component(color[4], 255),
    }
end

local function safe_color_tag(text, color)
    text = tostring(text or "")
    color = normalize_color_array(color)

    return string.format("{#color(%d,%d,%d)}%s{#reset()}", color[2], color[3], color[4], text)
end

--[[
    NATIVE COLOUR SETTING - CACHED, because mod:get CLONES.

    DMF's colour widget stores {a, r, g, b} as a TABLE, and DMFMod:get ends
    with

        return type(setting_value) == "table"
            and table.clone(setting_value) or setting_value

    so every read of a table-valued setting ALLOCATES A FRESH TABLE. These
    readers are called per player per frame from the squad bar and the world
    markers, so reading the colour straight out of mod:get produced hundreds of
    throwaway tables a second.

    That is not a theoretical cost. It took a session from 59 fps at a 166 MB
    heap down to 15 fps at 390 MB over about forty minutes, with the hitches
    landing on frames FpsDoctor attributed no cleanup time to at all - the heap
    itself was the problem, not the collector.

    So the resolved colour is memoised per prefix and only re-read when a
    setting actually changes. The numeric _red/_green/_blue path never had this
    problem, because numbers are returned by value and cost nothing to read.
--]]
local color_cache = {}

mod.invalidate_color_cache = function()
    for k in pairs(color_cache) do
        color_cache[k] = nil
    end
end

local function native_color(prefix)
    local cached = color_cache[prefix]

    if cached ~= nil then
        -- `false` marks "checked, not a colour table" so a miss is not re-read
        -- every frame either.
        return cached or nil
    end

    local c = get_setting(prefix)

    -- Guarding on the shape rather than just nil: the same setting_id may hold
    -- a legacy scalar on a config written by an older build, and feeding that
    -- to normalize_color_array would silently produce white.
    if type(c) == "table" and c[1] and c[2] and c[3] then
        local resolved = normalize_color_array(c)
        color_cache[prefix] = resolved
        return resolved
    end

    color_cache[prefix] = false
    return nil
end

--[[
    SUFFIXED KEYS ARE BUILT ONCE, NOT PER FRAME.

    `prefix .. "_alpha"` allocates a new string on every evaluation, and the
    two resolvers below did four of them EACH. The squad HUD resolves up to
    sixteen colours per frame - icon, border, label and distance for four
    slots - so this was roughly 64 string allocations per frame, about 3,800
    per second, for keys that are fixed at load.

    Memoising by prefix turns each of those into one hash lookup. The nested
    table is keyed by prefix then suffix so a new prefix costs one small table
    once and nothing afterwards.

    This is the other half of the fix whose first half is the color_cache
    above. That one stopped DMF from cloning the native colour table every
    read; this one stops the FALLBACK path - the numeric _red/_green/_blue
    route, which is what most of these settings actually use - from rebuilding
    its keys and re-reading four settings on every single frame.
--]]
local _suffix_keys = {}

local function key_for(prefix, suffix)
    local t = _suffix_keys[prefix]

    if not t then
        t = {}
        _suffix_keys[prefix] = t
    end

    local k = t[suffix]

    if not k then
        k = prefix .. suffix
        t[suffix] = k
    end

    return k
end

--[[
    THE FOUR SETTINGS READS ARE MEMOISED TOO, NOT JUST THE KEYS.

    Removing the string concatenation above left the real cost behind: four
    DMFMod:get calls per colour, per resolution, per frame. At sixteen colours
    a frame that is 64 trips into DMF's settings machinery every frame for
    values that only change when the user opens the options menu.

    So the resolved RGBA is cached as four NUMBERS keyed by prefix, and
    invalidated by invalidate_color_cache - which already runs on every setting
    change (see mod.on_setting_changed). Numbers rather than a cached table on
    purpose: callers mutate the result (`color[1] = alpha_override`), so handing
    out a shared table would let one caller's alpha override leak into every
    other caller's colour. Rebuilding a four-element table from cached numbers
    keeps the existing mutation semantics exactly, and a small table is far
    cheaper than four settings lookups plus four string allocations.

    _rgba_cache is deliberately stored in color_cache's companion so the single
    existing invalidation path clears both; adding a second cache with its own
    staleness rules is how the two drift apart.
--]]
local WHITE_DEFAULT = { 255, 255, 255, 255 }

local _rgba_cache = {}

local _prev_invalidate = mod.invalidate_color_cache

mod.invalidate_color_cache = function()
    if _prev_invalidate then
        _prev_invalidate()
    end

    for k in pairs(_rgba_cache) do
        _rgba_cache[k] = nil
    end
end

local function rgba_of(prefix, default_color)
    local c = _rgba_cache[prefix]

    if not c then
        c = {
            clamp255(get_setting(key_for(prefix, "_alpha"), default_color[1]), default_color[1]),
            clamp255(get_setting(key_for(prefix, "_red"),   default_color[2]), default_color[2]),
            clamp255(get_setting(key_for(prefix, "_green"), default_color[3]), default_color[3]),
            clamp255(get_setting(key_for(prefix, "_blue"),  default_color[4]), default_color[4]),
        }
        _rgba_cache[prefix] = c
    end

    -- A fresh table, because the caller owns and may mutate it.
    return { c[1], c[2], c[3], c[4] }
end

local function color_from_settings(prefix, default_preset)
    local preset = get_setting(key_for(prefix, "_preset"), default_preset)
    local preset_color = COLOR_PRESETS[preset]

    if preset_color and preset ~= "custom" then
        return normalize_color_array(preset_color)
    end

    return native_color(prefix) or normalize_color_array(rgba_of(prefix, WHITE_DEFAULT))
end

local function color_from_rgb_settings(prefix, default_color)
    default_color = normalize_color_array(default_color)

    return native_color(prefix) or normalize_color_array(rgba_of(prefix, default_color))
end

local _class_color_prefix = {}

mod.get_ally_color = function(alpha_override)
    local color = color_from_settings("ally_color", "gold")

    if alpha_override then
        color[1] = alpha_override
    end

    return color
end

mod.get_class_color = function(class_key, alpha_override)
    if not get_bool_setting("use_class_colors", false) then
        return mod.get_ally_color(alpha_override)
    end

    class_key = tostring(class_key or "veteran")

    -- Memoised for the same reason as everything else on this path: there are
    -- seven classes and this is called per teammate per frame, so the concat
    -- was ~240 identical strings a second.
    local prefix = _class_color_prefix[class_key]

    if not prefix then
        prefix = "class_color_" .. class_key
        _class_color_prefix[class_key] = prefix
    end

    local color = color_from_rgb_settings(prefix, CLASS_COLOR_DEFAULTS[class_key] or COLOR_PRESETS.gold)

    if alpha_override then
        color[1] = alpha_override
    end

    return color
end

--[[
    HOISTED. This table was being rebuilt on EVERY call - four tables (the
    outer one plus three inner) allocated per call, for constants. The squad
    HUD asks for a state colour per slot per frame, so at four slots and 60fps
    that is 960 needless tables per second.

    The prefix string is memoised for the same reason the suffixes above are.
--]]
local STATE_COLOR_DEFAULTS = {
    out = { 255, 255, 80, 65 },
    disabled = { 255, 25, 25, 25 },
    distance = { 255, 210, 245, 255 },
}

local _state_color_prefix = {}

mod.get_state_color = function(state_key)
    local key = tostring(state_key)
    local prefix = _state_color_prefix[key]

    if not prefix then
        prefix = "state_color_" .. key
        _state_color_prefix[key] = prefix
    end

    return color_from_rgb_settings(prefix, STATE_COLOR_DEFAULTS[state_key] or COLOR_PRESETS.white)
end

mod.get_platform_icon_color = function(platform_key)
    platform_key = tostring(platform_key or "unknown"):lower()

    return color_from_rgb_settings("platform_color_" .. platform_key, PLATFORM_COLOR_DEFAULTS[platform_key] or PLATFORM_COLOR_DEFAULTS.unknown)
end

mod.get_health_bar_color = function()
    return color_from_settings("health_color", "green")
end

mod.get_hud_icon_scale = function()
    local value = tonumber(get_setting("hud_icon_scale", 100)) or 100

    return math.max(60, math.min(140, value)) / 100
end

mod.get_world_icon_scale = function()
    local value = tonumber(get_setting("world_icon_scale", 100)) or 100

    return math.max(60, math.min(160, value)) / 100
end

mod.get_world_marker_max_distance = function()
    local value = tonumber(get_setting("world_marker_max_distance", WORLD_NAMEPLATE_MAX_DISTANCE)) or WORLD_NAMEPLATE_MAX_DISTANCE

    if value < 50 then
        return 50
    end

    if value > WORLD_NAMEPLATE_MAX_DISTANCE then
        return WORLD_NAMEPLATE_MAX_DISTANCE
    end

    return value
end

mod.get_bool_setting = get_bool_setting

mod:register_hud_element({
    class_name = "HudElementDiosExpandedUI",
    filename = "Dio's Handholder/scripts/mods/DiosHandholder/HudElementDiosExpandedUI",
    use_hud_scale = true,

    --[[
        The same five every persistent vanilla element asks for
        (TeamPanelHandler, CombatFeed, BossHealth, PlayerBuffs).

        This was { "alive", "dead" }, which meant the squad bar disappeared
        whenever the HUD switched group - while the ping wheel was held, while
        Tab was held, and the entire time the player stood in a danger zone.
        The last one is why it looked random: nothing the player did explained
        it, and in a hazard you are in that group for minutes at a time.

        A bar you read to see who is dying has to be on screen in exactly the
        states the team panel is.
    --]]
    visibility_groups = {
        "alive",
        "dead",
        "communication_wheel",
        "tactical_overlay",
        "player_in_danger_zone",
    },
})

--[[
    RANGEFINDER: "alive" ONLY.

    The squad bar above is registered for both groups because a dead player
    still needs to see where the team is. A crosshair readout has no meaning
    without a crosshair, so registering it for "dead" would put a floating
    distance in the middle of the spectator camera.
--]]
--[[
    JUMPSCARE OVERLAY: "alive" only.

    The whole joke is that it happens to YOU, mid-fight. Firing one over a
    spectator camera is just a confusing black flash on somebody else's
    gameplay.
--]]
--[[
    REGISTERED AS "Crosshair", NOT AS ITSELF.

    class_name is the string HUD-editing mods list and let people drag around.
    Registering this as HudElementDiosJumpscare put a movable entry called
    "Dio's Jumpscare" in those menus - which both spoils the joke by announcing
    it and lets someone park the scare in a corner where it does nothing.

    Crosshair is the name to borrow because the vanilla crosshair is the one
    element that is definitionally centre-screen, so an editor that respects
    the name leaves it there.

    THIS DOES NOT COLLIDE WITH THE REAL CROSSHAIR. The game's is
    HudElementCrosshair; this is Crosshair, a different key in the same table,
    and DMF registers additively rather than replacing. The real one is
    untouched.
--]]
mod:register_hud_element({
    class_name = "Crosshair",
    filename = "Dio's Handholder/scripts/mods/DiosHandholder/HudElementDiosJumpscare",
    use_hud_scale = false,

    --[[
        No "dead": the joke is that it happens to YOU mid-fight, and firing one
        over a spectator camera is a confusing black flash on someone else's
        game.

        player_in_danger_zone is included because a hazard is most of a Havoc
        mission - without it the scare simply could not fire for long stretches
        and the odds would not mean what they say.
    --]]
    visibility_groups = {
        "alive",
        "player_in_danger_zone",
    },
})

mod:register_hud_element({
    class_name = "HudElementDiosRangefinder",
    filename = "Dio's Handholder/scripts/mods/DiosHandholder/HudElementDiosRangefinder",
    use_hud_scale = true,

    --[[
        No "dead": the readout is measured from a live crosshair, so there is
        nothing to show while spectating.

        The other two are added because a rangefinder that blanks the moment
        you hold the ping wheel is useless precisely when you are about to call
        a distance out, and one that blanks in a hazard is useless in the place
        you most want it.
    --]]
    visibility_groups = {
        "alive",
        "communication_wheel",
        "player_in_danger_zone",
    },
})

--[[
    THE CLOSURE IS GONE. This was the single most-allocated thing in the mod.

    It used to read:

        local ok, value = pcall(function()
            return object[field_name]
        end)

    `function() ... end` inside a function body is not free. It captures
    `object` and `field_name` as upvalues, so LuaJIT allocates a NEW closure
    object on EVERY call. safe_field has 35 call sites, several of them per
    marker per frame - the _calculate_markers hook alone calls it once for
    every nameplate on screen, every frame.

    pcall already accepts a function plus its arguments, so the same guard
    costs zero allocations if the function is hoisted to file scope and the
    values are passed as arguments instead of captured. _index is created once,
    at load, and reused forever.

    This is the same class of bug as the colour-picker clone that took the game
    from 59 to 15 fps, and it is why heap climbed ~80-120 MB/min mid-mission.
--]]
local function _index(object, field_name)
    return object[field_name]
end

local function safe_field(object, field_name)
    if not object or field_name == nil then
        return nil
    end

    local ok, value = pcall(_index, object, field_name)

    if ok then
        return value
    end

    return nil
end

local function safe_call(object, method_name, ...)
    local method = safe_field(object, method_name)

    if type(method) ~= "function" then
        return nil
    end

    local ok, result = pcall(method, object, ...)

    if ok then
        return result
    end

    return nil
end

local function safe_get_mod(mod_name)
    if not get_mod then
        return nil
    end

    local ok, other_mod = pcall(get_mod, mod_name)

    if ok then
        return other_mod
    end

    return nil
end

local function package_is_available(package_name)
    if not Application or not Application.can_get_resource then
        return false
    end

    local ok, exists = pcall(function()
        return Application.can_get_resource("package", package_name)
    end)

    return ok and exists
end

local function package_is_loaded(package_name)
    local package_manager = Managers and Managers.package

    if not package_manager or not package_manager.has_loaded then
        return false
    end

    local ok, is_loaded = pcall(package_manager.has_loaded, package_manager, package_name)

    return ok and is_loaded or false
end

local function ensure_icon_packages_loaded()
    if icon_packages_all_loaded then
        return true
    end

    local package_manager = Managers and Managers.package

    if not package_manager or not package_manager.load then
        return false
    end

    local now = package_retry_time()

    if now < icon_package_next_retry_t then
        return false
    end

    icon_package_next_retry_t = now + ICON_PACKAGE_RETRY_COOLDOWN

    local all_loaded = true

    for _, package_name in ipairs(ICON_PACKAGES) do
        if package_is_available(package_name) then
            if package_is_loaded(package_name) then
                loaded_icon_packages[package_name] = true
            elseif not loaded_icon_packages[package_name] then
                local ok = pcall(function()
                    package_manager:load(package_name, ICON_PACKAGE_REF, nil, true)
                end)

                loaded_icon_packages[package_name] = ok or nil
                all_loaded = false
            else
                all_loaded = false
            end
        end
    end

    icon_packages_all_loaded = all_loaded

    return all_loaded
end

local function get_time(t)
    if t then
        return t
    end

    if Managers and Managers.time and Managers.time.time then
        local ok, gameplay_t = pcall(function()
            return Managers.time:time("gameplay")
        end)

        if ok and gameplay_t then
            return gameplay_t
        end
    end

    return 0
end

local function get_game_mode_name()
    local game_mode_manager = Managers and Managers.state and Managers.state.game_mode

    if not game_mode_manager or not game_mode_manager.game_mode_name then
        return nil
    end

    local ok, game_mode_name = pcall(function()
        return game_mode_manager:game_mode_name()
    end)

    if ok then
        return game_mode_name
    end

    return nil
end

mod.is_disabled_in_hub = function()
    return get_bool_setting("disable_in_mourningstar", false) and get_game_mode_name() == "hub"
end

local function should_scan_human_team()
    local game_mode_name = get_game_mode_name()

    return game_mode_name ~= "hub" and not mod.is_disabled_in_hub()
end

local function get_local_player()
    local player_manager = Managers and Managers.player

    -- local_player_safe, not local_player: local_player calls Network.peer_id()
    -- unconditionally, which is a native crash (not catchable by pcall) before
    -- the network is up. Same bug that crashed the foxy jumpscare mod.
    if not player_manager or not player_manager.local_player_safe then
        return nil
    end

    local ok, player = pcall(player_manager.local_player_safe, player_manager, 1)

    if ok then
        return player
    end

    return nil
end

local function get_player_archetype(player)
    if not player then
        return nil
    end

    local archetype_name = safe_call(player, "archetype_name")

    if archetype_name then
        return archetype_name
    end

    local profile = safe_call(player, "profile")
    local archetype = safe_field(profile, "archetype")

    if type(archetype) == "table" then
        return safe_field(archetype, "name") or safe_field(archetype, "archetype_name")
    end

    local profile_archetype = safe_field(profile, "archetype_name")

    if profile_archetype then
        return profile_archetype
    end

    if type(archetype) == "string" then
        return archetype
    end

    return nil
end

local function get_local_player_archetype()
    local local_player = get_local_player()

    if not local_player then
        return nil
    end

    return get_player_archetype(local_player)
end

local function is_human_player(player)
    local is_human = safe_call(player, "is_human_controlled")

    if is_human ~= nil then
        return is_human
    end

    local is_bot = safe_call(player, "is_bot")

    if is_bot ~= nil then
        return not is_bot
    end

    return player ~= nil
end

local function is_local_player(player, local_player)
    if not player or not local_player then
        return false
    end

    if player == local_player then
        return true
    end

    local account_id = safe_call(player, "account_id")
    local local_account_id = safe_call(local_player, "account_id")

    return account_id ~= nil and account_id == local_account_id
end

local function get_player_id(player, fallback_index)
    return safe_call(player, "account_id") or safe_call(player, "unique_id") or safe_call(player, "name") or tostring(fallback_index)
end

local function get_player_display_name(player, fallback_index)
    local profile = safe_call(player, "profile")
    local name = safe_call(player, "name")
        or safe_call(player, "account_name")
        or safe_call(player, "character_name")
        or safe_field(player, "name")
        or safe_field(profile, "name")
        or safe_field(profile, "character_name")
        or tr("player_fallback", tostring(fallback_index or "?"))

    name = tostring(name)

    if #name > 14 then
        name = string.sub(name, 1, 13) .. "."
    end

    return name
end

local function get_player_profile(player)
    return safe_call(player, "profile")
end

local function get_world_display_name(player, fallback_index)
    local profile = get_player_profile(player)
    local name = safe_call(player, "name")
        or safe_call(player, "account_name")
        or safe_call(player, "character_name")
        or safe_field(player, "name")
        or safe_field(profile, "name")
        or safe_field(profile, "character_name")
        or tr("player_fallback", tostring(fallback_index or "?"))

    return tostring(name)
end

local function get_social_player_info(account_id)
    if not account_id or not Managers or not Managers.data_service or not Managers.data_service.social then
        return nil
    end

    local ok, player_info = pcall(function()
        return Managers.data_service.social:get_player_info_by_account_id(account_id)
    end)

    if ok then
        return player_info
    end

    return nil
end

local function get_player_platform_key(player)
    local account_id = safe_call(player, "account_id")
    local player_info = get_social_player_info(account_id)
    local who_are_you = safe_get_mod("who_are_you")
    local platform = safe_call(player, "platform")
        or safe_call(player_info, "platform")
        or safe_call(player_info, "platform_name")

    if type(platform) == "string" and platform ~= "" then
        local normalized = string.lower(platform)

        if normalized == "playstation" or normalized == "ps5" then
            normalized = "psn"
        end

        return PLATFORM_ICONS[normalized] and normalized or "unknown"
    end

    local account_name = safe_call(player_info, "user_display_name")

    if not account_name and who_are_you and who_are_you.account_name then
        local ok, value = pcall(who_are_you.account_name, account_id)

        if ok then
            account_name = value
        end
    end

    if type(account_name) == "string" then
        if string.find(account_name, PLATFORM_ICONS.steam, 1, true) then
            return "steam"
        end

        if string.find(account_name, PLATFORM_ICONS.xbox, 1, true) then
            return "xbox"
        end

        if string.find(account_name, PLATFORM_ICONS.psn, 1, true) then
            return "psn"
        end
    end

    return "unknown"
end

local function get_player_platform_icon(player)
    return PLATFORM_ICONS[get_player_platform_key(player)] or PLATFORM_ICONS.unknown
end

local function get_player_level_parts(player)
    local profile = get_player_profile(player)
    local character_id = safe_field(profile, "character_id")
    local true_level_mod = safe_get_mod("true_level")
    local true_levels

    local true_level_is_enabled = safe_field(true_level_mod, "is_enabled")
    local true_level_get_levels = safe_field(true_level_mod, "get_true_levels")

    if type(true_level_is_enabled) == "function" and type(true_level_get_levels) == "function" then
        local enabled_ok, enabled = pcall(true_level_is_enabled, true_level_mod)

        if enabled_ok and enabled then
            local levels_ok, levels = pcall(true_level_get_levels, character_id)

            if levels_ok then
                true_levels = levels
            end
        end
    end

    local base_level = safe_field(true_levels, "current_level")
        or safe_field(profile, "current_level")
    local extra_level = safe_field(true_levels, "additional_level")
    local true_level = safe_field(true_levels, "true_level")
    local level = base_level

    if not extra_level and true_level and base_level and true_level > base_level then
        extra_level = true_level - base_level
    end

    return level, extra_level
end

local function get_player_level_label(player)
    local level, extra_level = get_player_level_parts(player)
    local mode = get_setting("player_level_format", "vanilla")

    if mode == "hidden" then
        return ""
    end

    if not level then
        return "?"
    end

    if mode == "true_total" and extra_level and extra_level > 0 then
        return tostring(level + extra_level)
    end

    if mode == "true_separate" and extra_level and extra_level > 0 then
        return tostring(level) .. " (+" .. tostring(extra_level) .. ")"
    end

    return tostring(level)
end

local function get_player_title(player)
    local profile = get_player_profile(player)

    if not profile then
        return ""
    end

    local title

    if ProfileUtils and ProfileUtils.character_title then
        local ok, value = pcall(ProfileUtils.character_title, profile)

        if ok then
            title = value
        end
    end

    if not title or title == "" then
        local title_fields = {
            "character_title",
            "title",
            "title_id",
            "equipped_title",
            "selected_title",
            "current_title",
        }

        for _, field_name in ipairs(title_fields) do
            local ok, value = pcall(function()
                return profile[field_name]
            end)

            if ok and value ~= nil and value ~= "" then
                title = value
                break
            end
        end
    end

    if type(title) == "table" then
        title = safe_field(title, "display_name")
            or safe_field(title, "name")
            or safe_field(title, "loc_name")
            or safe_field(title, "localization_key")
            or safe_field(title, "id")
    end

    if not title or title == "" then
        return ""
    end

    if Localize and type(title) == "string" and string.find(title, "^loc_") then
        local localized_ok, localized = pcall(Localize, title)

        if localized_ok and localized then
            return tostring(localized)
        end
    end

    return tostring(title)
end

--[[
    ADDITION: downed teammates show their ABILITY and bleedout, not their name.

    This is edited into the copied builder rather than applied from a separate
    hook. update_world_nameplate_marker writes content.header_text directly, so
    an outside hook that also writes it is simply overwritten - which is exactly
    why the downed display never appeared no matter how the hook was arranged.
    One writer, extended here.

    entry.is_dead is computed by the copied unit_is_dead_or_disabled, which
    checks four character-state components plus health, so it catches
    knocked-down, hogtied, netted and ledge-hanging - not just character_state.
--]]
--[[
    DOWNED ABILITY SUFFIX - appended to the name, not replacing it.

    The first version replaced the whole name with the tag, on the reasoning
    that a downed teammate's name tells you nothing you can act on. That was
    over-thinking it: the name is how you know who you are looking at, and
    losing it to gain the tag is a trade nobody asked for. Appending gives you
    both, and it means a failure here degrades to "the normal nameplate"
    rather than "a nameplate that lost its name".
--]]
--[[
    TAG RESOLUTION IS CACHED AND THROTTLED. This is not an optimisation, it is
    the fix for a regression I introduced.

    The previous version ran all three resolution paths BEFORE consulting the
    cache, every frame, for every downed teammate - and the third path built a
    closure and called require(), which DMF hooks. I had also just removed the
    negative caching from Tags.ability_tag_of, so a teammate whose ability
    genuinely could not be read re-ran the full lookup on every single frame
    for as long as they were down.

    That is what took the last run from 59 fps to a flat 20. The signature was
    different from the colour-clone leak: heap stayed flat at ~230 MB and GC
    cleanup sat near zero, while Lua->update accounted for 53 of 57 stall
    traces. Pure CPU, no allocation growth - which is exactly what a per-frame
    uncached lookup looks like.

    So: resolve at most once every RESOLVE_INTERVAL per player, remember the
    answer, and never touch require() from here at all.
--]]
local RESOLVE_INTERVAL = 1.0

-- player -> { tag, at, text, bucket, pct }
local downed_cache = setmetatable({}, { __mode = "k" })

--[[
    ability_configuration, fetched ONCE for the whole file.

    require() is hooked by DMF, so calling it per frame pays a hook walk to
    fetch a table that never changes. DHT_teammate_ability carries the same
    note above its own hoisted require, and I put one back on a hot path
    anyway.
--]]
local ABILITY_CONFIG = nil

local function ability_config()
    if ABILITY_CONFIG == nil then
        local ok, consts = pcall(require, "scripts/settings/player_character/player_character_constants")
        ABILITY_CONFIG = (ok and consts and consts.ability_configuration) or false
    end

    return ABILITY_CONFIG or nil
end

--[[
    Direct read off the unit. No closure: the arguments go straight to pcall,
    so a failed read costs nothing and a successful one allocates nothing
    beyond what the engine returns.
--]]
local function read_combat_ability_id(unit)
    local ext = ScriptUnit.has_extension(unit, "ability_system")
    if not ext then
        return nil
    end

    local equipped = ext:equipped_abilities()
    if type(equipped) ~= "table" then
        return nil
    end

    local config = ability_config()
    if not config then
        return nil
    end

    --[[
        THIRD COPY OF THE SAME MISTAKE. Both this table and
        ability_configuration are keyed by ability TYPE, so the loop key is
        "combat_ability" rather than "zealot_relic". The real id is
        settings.name - see the long note in DHT_teammate_ability.lua.
    --]]
    for ability_type, settings in pairs(equipped) do
        if settings and config[ability_type] == "slot_combat_ability" then
            return settings.name or ability_type
        end
    end

    return nil
end

local function resolve_downed_tag(Tags, player, now)
    local cached = downed_cache[player]

    -- Answered already, or asked recently enough. Both are cache hits; the
    -- second is what stops an unresolvable teammate re-running the lookup
    -- sixty times a second.
    if cached and (cached.tag or (now - cached.at) < RESOLVE_INTERVAL) then
        return cached.tag, cached
    end

    local tag = nil

    -- 1. What DHT resolved for the ability icons. Free: a table read.
    local published = mod.__dio_combat_ability
    local ability_id = published and published[player] or nil

    if ability_id and Tags.match_tag and Tags.ABILITY_TAGS then
        tag = Tags.match_tag(ability_id, Tags.ABILITY_TAGS) or nil
    end

    -- 2. The tags module.
    if not tag and Tags.ability_tag_of then
        tag = Tags.ability_tag_of(player) or nil
    end

    -- 3. Straight off the unit, if neither module could answer.
    if not tag and Tags.match_tag and Tags.ABILITY_TAGS then
        local unit = player.player_unit

        if unit and ALIVE[unit] then
            local ok, direct = pcall(read_combat_ability_id, unit)
            if ok and direct then
                tag = Tags.match_tag(direct, Tags.ABILITY_TAGS) or nil
            end
        end
    end

    if cached then
        cached.tag = tag
        cached.at = now
    else
        cached = { tag = tag, at = now }
        downed_cache[player] = cached
    end

    return tag, cached
end

--[[
    The percentage-bucket helper that used to live here is gone. Urgency now
    comes from Bleedout.urgency_rgb, which colours by SECONDS where seconds are
    known - see DiosHandholder_bleedout.lua. Two places deciding the same
    thresholds independently is how they drift apart.
--]]

local function dio_downed_suffix(entry)
    if not entry or not entry.is_dead then
        return nil
    end

    if mod:get("dio_downed_ability_names") == false then
        return nil
    end

    local Tags = mod.__dio_tags
    local player = entry.player
    if not Tags or not player then
        return nil
    end

    local now = mod._now or 0
    local tag, cached = resolve_downed_tag(Tags, player, now)

    --[[
        SECONDS when knocked down, the CAUSE when merely disabled.

        entry.is_dead is unit_is_dead_or_disabled, which is true for the whole
        "needs help" family. Only knocked_down has a bleedout pool, and the old
        code asked for a pool percentage regardless - so a netted teammate's
        ordinary health was printed as though it were a bleedout figure. That
        same confusion is what made the seconds version report ~1500s and get
        abandoned. Bleed.label returns nil for anything but knocked down, and
        the disabled label fills the gap with something actionable.
    --]]
    local suffix, secs = nil, nil
    local Bleed = mod.__dio_bleedout

    if Bleed and Bleed.label and mod:get("dio_show_bleedout") ~= false then
        if Bleed.sample then
            pcall(Bleed.sample, player)
        end
        local ok, s, sec = pcall(Bleed.label, player)
        if ok then
            suffix, secs = s, sec
        end
    end

    if not suffix and Tags.disabled_label then
        local ok, s = pcall(Tags.disabled_label, player)
        suffix = ok and s or nil
    end

    --[[
        SELF-DIAGNOSING, ONCE PER PLAYER PER MISSION.

        This feature has now failed four times and every diagnosis was a guess,
        because a nil anywhere in the chain looks identical from the outside.
        Rather than guess a fifth time, the first frame a downed teammate
        produces nothing writes one line naming which link was empty.

        Once per player, guarded by a flag on the cache entry, so it costs one
        boolean test per frame afterwards and never repeats.
    --]]
    if not tag and not suffix then
        --[[
            NOT EVERY EMPTY RESULT IS A FAULT.

            Reported as errors firing with nobody downed, and specifically when
            being grabbed by a mutant and thrown. That is not a bug in the
            label path - it is the two halves of "is this player in trouble"
            disagreeing for a frame, which they legitimately do.

            entry.is_dead comes from unit_is_dead_or_disabled, which reaches
            its verdict through HEALTH: is_alive false, is_dead true, or
            current_health <= 0. Those can all read true transiently while the
            character state is still a perfectly ordinary one - a husk's health
            and state components sync from separate game-object fields and do
            not land on the same frame, and a mutant charge slams you through
            several states in quick succession.

            So when the state IS readable and simply is not a trouble state,
            there is nothing to label and nothing wrong. Return quietly. The
            diagnostic is for the case it was written for: a player we believe
            is down, dead or disabled whose state we cannot read at all.
        --]]
        local state_now = Tags.character_state and Tags.character_state(player) or nil

        if state_now and not Tags.DISABLED_LABEL[state_now] then
            return nil
        end

        if not cached.reported then
            cached.reported = true

            local unit = player.player_unit
            local Bleed2 = mod.__dio_bleedout

            --[[
                THE CHARACTER STATE IS NOW IN THE LINE.

                The previous version printed seven "yes" values and no state,
                so when it fired with everything resolved there was nothing in
                it that pointed anywhere. The missing field was the one that
                mattered: the player was DEAD, character_state was unreadable
                because a corpse is not in ALIVE, and the label path returned
                nil silently. A diagnostic that cannot distinguish "knocked
                down" from "dead" could never have caught that.
            --]]
            local st = Tags.character_state and Tags.character_state(player) or nil

            mod:error(
                "[Dio] downed suffix empty: state=%s tags=%s bleed=%s unit=%s alive=%s published=%s ability_ext=%s cfg=%s",
                tostring(st or "UNREADABLE"),
                mod.__dio_tags and "yes" or "NO",
                Bleed2 and "yes" or "NO",
                unit and "yes" or "NO",
                (unit and ALIVE[unit]) and "yes" or "NO",
                tostring((mod.__dio_combat_ability and mod.__dio_combat_ability[player]) or "nil"),
                (unit and ScriptUnit.has_extension(unit, "ability_system")) and "yes" or "NO",
                ability_config() and "yes" or "NO")
        end

        return nil
    end

    --[[
        Keyed on the SUFFIX STRING rather than a bucket plus a percentage.

        The suffix is now the thing that is drawn, so comparing it directly is
        both simpler and exactly right - there is no longer a way for the
        cached text and the current state to disagree while the key matches.
        It does rebuild once a second while a countdown ticks, which is a
        string.format and nothing else; the expensive part this cache exists to
        avoid is the tag resolution above, and that is untouched.
    --]]
    if cached.text and cached.built_tag == tag and cached.suffix == suffix then
        return cached.text
    end

    local rgb = Tags.class_color and Tags.class_color(player) or { 235, 235, 235 }
    local text = ""

    if tag then
        text = string.format("  {#color(%d,%d,%d)}[%s]{#reset()}",
            rgb[1], rgb[2], rgb[3], tag)
    end

    if suffix then
        local cr, cg, cb = 255, 190, 80

        if Bleed and Bleed.urgency_rgb then
            if secs then
                local ok, r, g, b = pcall(Bleed.urgency_rgb, player, secs)
                if ok then cr, cg, cb = r, g, b end
            elseif string.find(suffix, "%%") then
                local ok, r, g, b = pcall(Bleed.urgency_rgb, player, nil)
                if ok then cr, cg, cb = r, g, b end
            end
        end

        text = text .. string.format("%s{#color(%d,%d,%d)}%s{#reset()}",
            (text == "") and "  " or " ", cr, cg, cb, suffix)
    end

    if text == "" then
        return nil
    end

    cached.text = text
    cached.built_tag = tag
    cached.suffix = suffix

    return text
end

local function build_world_nameplate_text(entry)
    local name = tostring(entry.world_name or entry.player_name or entry.label or "")
    local title = tostring(entry.title_label or "")
    local ally_color = normalize_color_array(mod.get_class_color(entry.class_key))
    local platform_icon = get_bool_setting("show_platform_icon", true) and tostring(entry.platform_icon or "") or ""
    local level_text = get_bool_setting("show_player_level", true) and tostring(entry.level_label or "") or ""
    local level_label = level_text ~= "" and (" - " .. level_text) or ""
    local header

    if platform_icon ~= "" then
        local colored_platform_icon = safe_color_tag(platform_icon, mod.get_platform_icon_color(entry.platform_key))

        header = colored_platform_icon .. " " .. safe_color_tag(name, ally_color) .. level_label
    else
        header = safe_color_tag(name, ally_color) .. level_label
    end

    --[[
        Appended to the NAME line, not the title line: the title is optional
        and often absent, so hanging the tag off it would make the feature
        disappear for anyone without one equipped.
    --]]
    header = header .. (dio_downed_suffix(entry) or "")

    if get_bool_setting("show_player_title", true) and title ~= "" then
        return header .. "\n" .. safe_color_tag(title, { 205, 230, 255 })
    end

    return header
end

local unit_is_alive
local get_unit_extension
local unit_is_dead_or_disabled
local clamp01

local HealthMarkerTemplate = {}

HealthMarkerTemplate.name = HEALTH_MARKER_NAME
HealthMarkerTemplate.unit_node = "j_head"
HealthMarkerTemplate.position_offset = { 0, 0, 2.35 }
HealthMarkerTemplate.check_line_of_sight = false
HealthMarkerTemplate.max_distance = WORLD_NAMEPLATE_MAX_DISTANCE
HealthMarkerTemplate.screen_clamp = false
HealthMarkerTemplate.remove_on_death_duration = 1.0
HealthMarkerTemplate.size = { WORLD_HEALTH_BAR_WIDTH + 12, 18 }
HealthMarkerTemplate.fade_settings = {
    fade_to = 1,
    fade_from = 0.65,
    default_fade = 1,
    distance_max = WORLD_NAMEPLATE_MAX_DISTANCE,
    distance_min = 20,
    easing_function = math.ease_out_quad,
}

HealthMarkerTemplate.create_widget_defintion = function(template, scenegraph_id)
    local bar_width = WORLD_HEALTH_BAR_WIDTH
    local bar_height = WORLD_HEALTH_BAR_HEIGHT
    local half_width = bar_width * 0.5

    return UIWidget.create_definition({
        {
            pass_type = "rect",
            style_id = "health_frame",
            style = {
                color = { 220, 8, 14, 10 },
                offset = { -half_width - 2, 0, 1 },
                size = { bar_width + 4, bar_height + 4 },
            },
        },
        {
            pass_type = "rect",
            style_id = "health_bg",
            style = {
                color = { 190, 18, 34, 20 },
                offset = { -half_width, 2, 2 },
                size = { bar_width, bar_height },
            },
        },
        {
            pass_type = "rect",
            style_id = "health_fill",
            style = {
                color = { 255, 95, 235, 110 },
                offset = { -half_width, 2, 3 },
                size = { bar_width, bar_height },
            },
        },
    }, scenegraph_id)
end

HealthMarkerTemplate.update_function = function(parent, ui_renderer, widget, marker)
    if not get_bool_setting("show_ally_health_bars", false) then
        if widget and widget.content then
            widget.content.visible = false
        end

        return
    end

    local unit = safe_field(marker, "unit")
    local style = widget and widget.style

    if not unit or not unit_is_alive(unit) or unit_is_dead_or_disabled(unit) then
        if widget and widget.content then
            widget.content.visible = false
        end

        return
    end

    if widget and widget.content then
        widget.content.visible = true
    end

    if not style or not style.health_bg or not style.health_fill then
        return
    end

    local health_extension = get_unit_extension(unit, "health_system")
    local health_fraction = safe_call(health_extension, "current_health_percent")

    if type(health_fraction) ~= "number" then
        local current_health = safe_call(health_extension, "current_health")
        local max_health = safe_call(health_extension, "max_health")

        if type(current_health) == "number" and type(max_health) == "number" and max_health > 0 then
            health_fraction = current_health / max_health
        else
            health_fraction = 0
        end
    end

    health_fraction = clamp01(health_fraction)

    local health_color = mod.get_health_bar_color()

    if style.health_bg.size then
        style.health_bg.size[1] = WORLD_HEALTH_BAR_WIDTH
    end

    if style.health_fill.size then
        style.health_fill.size[1] = math.max(1, WORLD_HEALTH_BAR_WIDTH * health_fraction)
    end

    if style.health_fill.color then
        style.health_fill.color[1] = health_fraction > 0 and health_color[1] or 0
        style.health_fill.color[2] = health_color[2]
        style.health_fill.color[3] = health_color[3]
        style.health_fill.color[4] = health_color[4]
    end
end

local function register_health_marker_template()
    if not get_bool_setting("show_ally_health_bars", false) then
        return false
    end

    if not Managers or not Managers.ui or not Managers.ui._hud then
        return false
    end

    local ok, registered = pcall(function()
        local hud = Managers.ui._hud
        local max_distance = mod.get_world_marker_max_distance()

        HealthMarkerTemplate.max_distance = max_distance
        HealthMarkerTemplate.fade_settings.distance_max = max_distance

        if not hud._elements then
            return false
        end

        for _, element in pairs(hud._elements) do
            if element and element.__class_name == "HudElementWorldMarkers" and element._marker_templates then
                element._marker_templates[HEALTH_MARKER_NAME] = HealthMarkerTemplate
                return true
            end
        end

        return false
    end)

    return ok and registered
end

local function add_health_marker(unit)
    if not get_bool_setting("show_ally_health_bars", false) then
        return
    end

    if not unit or mod.tracked_health_markers[unit] or not unit_is_alive(unit) then
        return
    end

    if not Managers or not Managers.event or not get_unit_extension(unit, "health_system") or not register_health_marker_template() then
        return
    end

    --[[
        THE CALLBACK IS THE POINT. It hands back the marker id, and without an
        id there is nothing removal can act on - see remove_health_marker.
    --]]
    local ok = pcall(function()
        local player = Managers.player and Managers.player.player_by_unit and Managers.player:player_by_unit(unit)

        Managers.event:trigger("add_world_marker_unit", HEALTH_MARKER_NAME, unit,
            function(id)
                mod.tracked_health_markers[unit] = id
            end,
            player)
    end)

    if ok and not mod.tracked_health_markers[unit] then
        --[[
            Marked pending if the callback has not fired yet. `true` is not an
            id, so removal will know it cannot remove this one and will simply
            drop the record rather than firing a bad event.
        --]]
        mod.tracked_health_markers[unit] = true
    end
end

--[[
    REMOVAL WAS A SILENT NO-OP.

    This fired "remove_world_marker_unit", an event the engine does not
    register. HudElementWorldMarkers registers exactly four
    (hud_element_world_markers.lua:49-52):

        add_world_marker_unit
        add_world_marker_position
        remove_world_marker          <- takes an ID, not a unit
        request_world_markers_list

    Managers.event:trigger on an unregistered event does nothing and reports
    nothing, so every health marker ever added stayed on screen for the rest of
    the mission and the tracking table only ever grew. Same class as the
    retained-mode and notify_mod bugs: something added with nothing removing
    it.

    The fix is to keep the id the add callback hands back, and remove BY ID.
--]]
local function remove_health_marker(unit)
    local id = unit and mod.tracked_health_markers[unit]

    if not id then
        return
    end

    --[[
        `true` means the add callback had not fired yet, so no id exists. Drop
        the record rather than triggering with a boolean - the previous code's
        failure was firing an event that could not work, and firing a
        differently-wrong one would not be an improvement.
    --]]
    if id ~= true and Managers and Managers.event then
        pcall(function()
            Managers.event:trigger("remove_world_marker", id)
        end)
    end

    mod.tracked_health_markers[unit] = nil
end

local function sync_health_markers(active_units)
    active_units = active_units or {}

    if not get_bool_setting("show_ally_health_bars", false) then
        for unit, _ in pairs(mod.tracked_health_markers) do
            remove_health_marker(unit)
        end

        return
    end

    for unit, _ in pairs(mod.tracked_health_markers) do
        if not active_units[unit] or not unit_is_alive(unit) then
            remove_health_marker(unit)
        end
    end

    for unit, _ in pairs(active_units) do
        add_health_marker(unit)
    end
end

local function remove_all_health_markers()
    for unit, _ in pairs(mod.tracked_health_markers) do
        remove_health_marker(unit)
    end

    mod.tracked_health_markers = {}
end

local function add_world_locator_box_to_definition(name, definition)
    if type(name) ~= "string" or not string.find(name, "nameplate") or string.find(name, "companion") then
        return
    end

    if not definition or definition.dio_handholder_locator_added or not definition.passes or not definition.style or not definition.content then
        return
    end

    definition.dio_handholder_locator_added = true
    definition.content.dio_handholder_locator_box = false

    local function add_rect(style_id, color, size)
        definition.passes[#definition.passes + 1] = {
            pass_type = "rect",
            style_id = style_id,
            visibility_function = function(content)
                return content.dio_handholder_locator_box == true
            end,
        }

        definition.style[style_id] = {
            color = color,
            size = size,
            offset = { 0, 0, 940 },
        }
    end

    local function add_border(style_id)
        add_rect(style_id, { 255, 255, 230, 70 }, { 96, WORLD_LOCATOR_BORDER })
    end

    add_border("dio_handholder_locator_top")
    add_border("dio_handholder_locator_bottom")
    add_border("dio_handholder_locator_left")
    add_border("dio_handholder_locator_right")
end

local function normalize_archetype_name(raw_name)
    if not raw_name then
        return nil
    end

    local name = tostring(raw_name):lower()

    if string.find(name, "veteran") then
        return "veteran"
    end

    if string.find(name, "zealot") then
        return "zealot"
    end

    if string.find(name, "psyker") then
        return "psyker"
    end

    if string.find(name, "ogryn") then
        return "ogryn"
    end

    if string.find(name, "adamant") or string.find(name, "arbites") or string.find(name, "arbitrator") or string.find(name, "arbitor") then
        return "adamant"
    end

    if string.find(name, "broker") or string.find(name, "hive") or string.find(name, "scum") then
        return "broker"
    end

    if string.find(name, "cryptic") or string.find(name, "skitarii") then
        return "cryptic"
    end

    return name
end

mod.get_class_display_name = function(class_key)
    local display_names = {
        veteran = tr("class_veteran"),
        zealot = tr("class_zealot"),
        psyker = tr("class_psyker"),
        ogryn = tr("class_ogryn"),
        adamant = tr("class_adamant"),
        broker = tr("class_broker"),
        cryptic = tr("class_cryptic"),
    }

    if class_key == "cryptic" then
        return display_names.cryptic
    end

    return localize_game_text(CLASS_LOCALIZATION_KEYS[class_key]) or display_names[class_key] or tostring(class_key)
end

mod.get_class_icon = function(class_key)
    local texture_icons = {
        veteran = "content/ui/materials/icons/classes/large/veteran",
        zealot = "content/ui/materials/icons/classes/large/zealot",
        psyker = "content/ui/materials/icons/classes/large/psyker",
        ogryn = "content/ui/materials/icons/classes/large/ogryn",
        adamant = "content/ui/materials/icons/classes/large/adamant",
        broker = "content/ui/materials/icons/classes/large/broker",
    }

    return texture_icons[class_key] or texture_icons.veteran
end

mod.get_class_font_icon = function(class_key)
    local archetype_icons = UISettings and UISettings.archetype_font_icon
    local icon = archetype_icons and archetype_icons[class_key]

    if type(icon) == "string" and icon ~= "" then
        return icon
    end

    return UNKNOWN_CLASS_ICON
end

mod.use_texture_class_icons = function()
    local icon_style = get_setting("class_icon_style", "auto")

    if icon_style == "texture" then
        return true
    end

    if icon_style == "font" then
        return false
    end

    return safe_get_mod("IconBrowser") ~= nil or ensure_icon_packages_loaded()
end

local function get_player_sort_key(player, fallback_index)
    local slot = safe_call(player, "slot")

    if type(slot) == "number" then
        return slot
    end

    if slot then
        local slot_number = tonumber(tostring(slot):match("%d+"))

        if slot_number then
            return slot_number
        end
    end

    return fallback_index or 99
end

function unit_is_alive(unit)
    if not unit then
        return false
    end

    if HEALTH_ALIVE and HEALTH_ALIVE[unit] ~= nil then
        return HEALTH_ALIVE[unit]
    end

    if ALIVE and ALIVE[unit] ~= nil then
        return ALIVE[unit]
    end

    if Unit and Unit.alive then
        local ok, alive = pcall(Unit.alive, unit)

        if ok then
            return alive
        end
    end

    return false
end

function get_unit_extension(unit, extension_name)
    if not unit or not ScriptUnit or not ScriptUnit.has_extension then
        return nil
    end

    local ok, extension = pcall(ScriptUnit.has_extension, unit, extension_name)

    if ok then
        return extension
    end

    return nil
end

--[[
    STATE NAMES COPIED FROM VANILLA, not invented.

    The old version guessed at three possible field names, wrapped each read in
    a closure inside a pcall, and compared against a hand-written list of six
    state names. Two things were wrong with that:

    1. THE LIST WAS INCOMPLETE. scripts/utilities/attack/player_unit_status.lua
       defines DISABLED_STATES with TWELVE entries. Mine had six and was
       missing consumed, grabbed, mutant_charged, netted, pounced,
       vortex_grabbed and warp_grabbed - so a teammate netted by a trapper or
       pounced by a hound simply did not register as needing help.

    2. IT ALLOCATED. A fields table plus a closure per component per call, four
       components per player per frame - roughly a thousand closures a second
       with a full team. That is the same per-frame allocation pattern that has
       cost this project three separate framerate regressions.

    The table below is DISABLED_STATES verbatim, hoisted to file scope, read
    with a direct index and no pcall. Components are plain Lua tables behind a
    read-only metatable (PlayerUnitDataExtension._create_read_component), so
    indexing them needs no protection.
--]]
local DISABLED_STATE_NAMES = {
    catapulted = true,
    consumed = true,
    dead = true,
    grabbed = true,
    hogtied = true,
    knocked_down = true,
    ledge_hanging = true,
    mutant_charged = true,
    netted = true,
    pounced = true,
    vortex_grabbed = true,
    warp_grabbed = true,
}

--[[
    One line per unit, the first time it is asked about, naming the state that
    was actually read. The downed display has now failed four times and every
    diagnosis was a theory about this exact value; this ends that.
--]]
local state_reported = setmetatable({}, { __mode = "k" })

local function component_has_dead_state(component, unit)
    if type(component) ~= "table" then
        return false
    end

    local state_name = component.state_name

    if type(state_name) ~= "string" then
        return false
    end

    if unit and not state_reported[unit] and state_name ~= "walking" then
        state_reported[unit] = true
        mod:info("[Dio] character_state=%q disabled=%s", state_name,
            tostring(DISABLED_STATE_NAMES[state_name] == true))
    end

    return DISABLED_STATE_NAMES[state_name] == true
end
function unit_is_dead_or_disabled(unit)
    if not unit then
        return true
    end

    if not unit_is_alive(unit) then
        return true
    end

    local health_extension = get_unit_extension(unit, "health_system")

    if health_extension then
        local is_alive = safe_call(health_extension, "is_alive")

        if is_alive == false then
            return true
        end

        local is_dead = safe_call(health_extension, "is_dead")

        if is_dead == true then
            return true
        end

        local current_health = safe_call(health_extension, "current_health")

        if type(current_health) == "number" and current_health <= 0 then
            return true
        end
    end

    local unit_data_extension = get_unit_extension(unit, "unit_data_system")

    if unit_data_extension then
        --[[
            character_state is the one that carries the answer -
            PlayerUnitStatus.is_disabled, is_knocked_down and is_hogtied all
            read state_name off THIS component and no other. The three extra
            components the old code walked have no state_name field at all, so
            checking them was three wasted reads per player per frame.
        --]]
        local component = safe_call(unit_data_extension, "read_component", "character_state")

        if component_has_dead_state(component, unit) then
            return true
        end
    end

    return false
end

local function unit_position(unit)
    if not unit then
        return nil
    end

    if POSITION_LOOKUP then
        local position = POSITION_LOOKUP[unit]

        if position then
            return position
        end
    end

    if Unit and Unit.world_position then
        local ok, position = pcall(Unit.world_position, unit, 1)

        if ok then
            return position
        end
    end

    return nil
end

local function get_player_unit(player)
    if not player then
        return nil
    end

    local ok, player_unit = pcall(function()
        return player.player_unit
    end)

    if ok and player_unit then
        return player_unit
    end

    return safe_call(player, "unit")
end

local function get_local_player_unit()
    return get_player_unit(get_local_player()) or mod.local_player_unit_from_input
end

local function reset_native_coherence_if_needed(local_player_unit)
    if mod.local_player_unit ~= local_player_unit then
        remove_all_health_markers()
        mod.local_player_unit = local_player_unit
        mod.native_coherence_by_unit = {}
        mod.human_player_by_unit = {}
        mod.previous_player_states = {}
        mod.debug_last_hud_signature = nil
    end
end

local function set_native_coherence(unit, is_coherent)
    if not unit then
        return
    end

    mod.native_coherence_by_unit[unit] = is_coherent
end

local function keep_outline_visible(unit)
    if not get_bool_setting("show_world_nameplates", true) or mod.is_disabled_in_hub() then
        return
    end

    if not unit or not mod.outline_system then
        return
    end

    if mod.outline_system.set_global_visibility then
        pcall(mod.outline_system.set_global_visibility, mod.outline_system, true)
    end
end

function clamp01(value)
    if not value then
        return 0
    end

    if value < 0 then
        return 0
    end

    if value > 1 then
        return 1
    end

    return value
end

local function round_number(value)
    if type(value) ~= "number" then
        return nil
    end

    return math.floor(value + 0.5)
end

local function update_world_nameplate_marker(marker, entry)
    if not marker or not entry or entry.is_self then
        return
    end

    local widget = safe_field(marker, "widget")
    local content = widget and widget.content
    local marker_player = safe_field(marker, "data")

    if marker_player and safe_field(marker_player, "__deleted") ~= true then
        entry.world_name = get_world_display_name(marker_player, entry.sort_key)
        entry.level_label = get_player_level_label(marker_player)
        entry.title_label = get_player_title(marker_player)
        entry.platform_icon = get_player_platform_icon(marker_player)
    end

    if not get_bool_setting("show_world_nameplates", true) or mod.is_disabled_in_hub() then
        if content then
            content.header_text = ""
            content.icon_text = ""
            content.dio_handholder_locator_box = false
        end

        if widget then
            widget.alpha_multiplier = 0
        end

        return
    end

    local max_distance = mod.get_world_marker_max_distance()

    marker.max_distance = max_distance
    marker.block_screen_clamp = false

    local template = safe_field(marker, "template")

    if template then
        template.max_distance = max_distance
        template.check_line_of_sight = false
        template.screen_clamp = true
    end

    local style = widget and widget.style
    local ally_color = mod.get_class_color(entry.class_key)

    if content then
        local distance_label = get_bool_setting("show_world_distance", true) and tostring(entry.distance_label or "") or ""

        content.header_text = build_world_nameplate_text(entry) .. "\n{#color(210,245,255)}" .. distance_label .. "{#reset()}"
        content.icon_text = content.icon_text or ""
        content.dio_handholder_locator_box = true
    end

    if style then
        local distance = content and tonumber(content.distance) or entry.distance or 0
        local frame_size = math.min(180, math.max(72, 72 + (distance * 1.4)))
        local header_style = style.header_text or style.text

        local function apply_color_to_style(style, color)
            if type(style) ~= "table" or type(color) ~= "table" then
                return
            end

            if type(style.text_color) == "table" then
                style.text_color[1] = color[1]
                style.text_color[2] = color[2]
                style.text_color[3] = color[3]
                style.text_color[4] = color[4]
            end

            if type(style.color) == "table" then
                style.color[1] = color[1]
                style.color[2] = color[2]
                style.color[3] = color[3]
                style.color[4] = color[4]
            end
        end

        if header_style then
            header_style.font_size = math.max(header_style.font_size or 0, 18)
            header_style.default_font_size = math.max(header_style.default_font_size or 0, 18)
            header_style.drop_shadow = true

            apply_color_to_style(header_style, ally_color)
        end

        local background_style = style.background

        if background_style and background_style.color then
            if background_style.size then
                background_style.size[1] = frame_size
                background_style.size[2] = frame_size
            end

            background_style.color[1] = 180
            background_style.color[2] = 0
            background_style.color[3] = 0
            background_style.color[4] = 0
        end

        local ring_style = style.ring

        if ring_style then
            if ring_style.size then
                ring_style.size[1] = frame_size
                ring_style.size[2] = frame_size
            end

            if ring_style.color then
                ring_style.color[1] = ally_color[1]
                ring_style.color[2] = ally_color[2]
                ring_style.color[3] = ally_color[3]
                ring_style.color[4] = ally_color[4]
            end
        end

        local icon_style = style.icon

        if icon_style then
            if icon_style.size then
                local icon_size = math.max(20, frame_size * 0.28 * mod.get_world_icon_scale())

                icon_style.size[1] = icon_size
                icon_style.size[2] = icon_size
            end

            if icon_style.color then
                icon_style.color[1] = math.min(ally_color[1], 180)
                icon_style.color[2] = ally_color[2]
                icon_style.color[3] = ally_color[3]
                icon_style.color[4] = ally_color[4]
            end
        end

        local half_size = frame_size * 0.5
        local box_styles = {
            top = style.dio_handholder_locator_top,
            bottom = style.dio_handholder_locator_bottom,
            left = style.dio_handholder_locator_left,
            right = style.dio_handholder_locator_right,
        }

        if box_styles.top and box_styles.bottom and box_styles.left and box_styles.right then
            box_styles.top.size[1] = frame_size
            box_styles.top.size[2] = WORLD_LOCATOR_BORDER
            box_styles.top.offset[1] = -half_size
            box_styles.top.offset[2] = -frame_size - 24

            box_styles.bottom.size[1] = frame_size
            box_styles.bottom.size[2] = WORLD_LOCATOR_BORDER
            box_styles.bottom.offset[1] = -half_size
            box_styles.bottom.offset[2] = -24

            box_styles.left.size[1] = WORLD_LOCATOR_BORDER
            box_styles.left.size[2] = frame_size
            box_styles.left.offset[1] = -half_size
            box_styles.left.offset[2] = -frame_size - 24

            box_styles.right.size[1] = WORLD_LOCATOR_BORDER
            box_styles.right.size[2] = frame_size
            box_styles.right.offset[1] = half_size - WORLD_LOCATOR_BORDER
            box_styles.right.offset[2] = -frame_size - 24

            for _, box_style in pairs(box_styles) do
                box_style.color[1] = ally_color[1]
                box_style.color[2] = ally_color[2]
                box_style.color[3] = ally_color[3]
                box_style.color[4] = ally_color[4]
            end
        end
    end

    if widget then
        widget.alpha_multiplier = 1
    end
end

local function distance_sq(a, b)
    if not a or not b then
        return nil
    end

    if Vector3 and Vector3.distance_squared then
        local ok, distance = pcall(Vector3.distance_squared, a, b)

        if ok then
            return distance
        end
    end

    local ok, dx, dy, dz = pcall(function()
        return a[1] - b[1], a[2] - b[2], a[3] - b[3]
    end)

    if not ok then
        return nil
    end

    return (dx * dx) + (dy * dy) + (dz * dz)
end

local function distance_m(a, b)
    if not a or not b then
        return nil
    end

    if Vector3 and Vector3.distance then
        local ok, distance = pcall(Vector3.distance, a, b)

        if ok and distance then
            return distance
        end
    end

    local sq = distance_sq(a, b)

    if sq then
        return math.sqrt(sq)
    end

    return nil
end

local function format_distance_label(distance)
    if not get_bool_setting("show_distance", true) or not distance then
        return ""
    end

    local rounded = math.floor(distance + 0.5)

    if rounded > 1000 then
        rounded = 1000
    end

    return tostring(rounded) .. "m"
end

local function native_coherence_state(entry, entries)
    if entry.is_dead then
        return "dead"
    end

    local alive_count = 0
    local has_unknown_teammate = false
    local has_coherent_teammate = false

    for _, other_entry in ipairs(entries) do
        if not other_entry.is_dead then
            alive_count = alive_count + 1

            if not other_entry.is_self then
                local native_value = other_entry.unit and mod.native_coherence_by_unit[other_entry.unit]

                if native_value == true then
                    has_coherent_teammate = true
                elseif native_value == nil then
                    has_unknown_teammate = true
                end
            end
        end
    end

    if alive_count <= 1 then
        return entry.is_self and "self_coherent" or "other_coherent"
    end

    if entry.is_self then
        if has_coherent_teammate or has_unknown_teammate then
            return "self_coherent"
        end

        return "self_out"
    end

    local native_value = entry.unit and mod.native_coherence_by_unit[entry.unit]

    if native_value == false then
        return "other_out"
    end

    return "other_coherent"
end

local function play_out_sound_once(t)
    if not Managers or not Managers.ui or not Managers.ui.play_2d_sound then
        return
    end

    if t - mod.last_out_sound_t < OUT_SOUND_COOLDOWN then
        return
    end

    local ok = pcall(function()
        Managers.ui:play_2d_sound(OUT_SOUND_EVENT)
    end)

    if ok then
        mod.last_out_sound_t = t
    end
end

local function build_hud_player_entry(player, local_player, local_position, index)
    local raw_archetype = get_player_archetype(player)
    local class_key = normalize_archetype_name(raw_archetype)

    if not class_key then
        return nil
    end

    local player_unit = get_player_unit(player)
    local position = unit_position(player_unit)
    local is_dead = false

    if player_unit then
        is_dead = unit_is_dead_or_disabled(player_unit)
    elseif should_scan_human_team() then
        is_dead = true
    end

    local is_self = is_local_player(player, local_player)
    local player_distance = is_self and 0 or distance_m(local_position, position)

    return {
        player = player,
        unit = player_unit,
        id = get_player_id(player, index),
        sort_key = get_player_sort_key(player, index),
        class_key = class_key,
        label = mod.get_class_display_name(class_key),
        player_name = get_player_display_name(player, index),
        world_name = get_world_display_name(player, index),
        platform_key = get_player_platform_key(player),
        platform_icon = get_player_platform_icon(player),
        level_label = get_player_level_label(player),
        title_label = get_player_title(player),
        icon = mod.get_class_icon(class_key),
        icon_text = mod.get_class_font_icon(class_key),
        icon_is_texture = mod.use_texture_class_icons(),
        position = position,
        distance = player_distance,
        distance_label = is_self and "" or format_distance_label(player_distance),
        is_dead = is_dead,
        is_self = is_self,
    }
end

local function update_debug_signature(hud_players)
    local parts = {}

    for i, entry in ipairs(hud_players) do
        parts[i] = tostring(entry.class_key) .. ":" .. tostring(entry.state)
    end

    local signature = table.concat(parts, "|")

    if signature ~= mod.debug_last_hud_signature then
        mod.debug_last_hud_signature = signature
    end
end

mod.update_hud_players = function(t)
    t = get_time(t)

    local player_manager = Managers and Managers.player
    local local_player = get_local_player()
    local local_player_unit = get_player_unit(local_player)
    local local_position = unit_position(local_player_unit)
    local hud_players = {}

    reset_native_coherence_if_needed(local_player_unit)

    if mod.is_disabled_in_hub() then
        sync_health_markers({})
        mod.human_player_by_unit = {}
        mod.hud_players = {}
        return mod.hud_players
    end

    if player_manager and player_manager.players and should_scan_human_team() then
        local ok, players = pcall(function()
            return player_manager:players()
        end)

        if ok and players then
            local index = 0
            local human_player_by_unit = {}
            local active_health_units = {}

            for _, player in pairs(players) do
                if player and is_human_player(player) then
                    index = index + 1

                    local entry = build_hud_player_entry(player, local_player, local_position, index)

                    if entry and (get_bool_setting("show_unavailable_players", true) or not entry.is_dead or entry.is_self) then
                        if entry.unit then
                            human_player_by_unit[entry.unit] = entry
                        end

                        if not entry.is_self then
                            keep_outline_visible(entry.unit)

                            if get_bool_setting("show_ally_health_bars", false) and entry.unit and not entry.is_dead then
                                active_health_units[entry.unit] = true
                            end
                        end

                        hud_players[#hud_players + 1] = entry
                    end
                end
            end

            mod.human_player_by_unit = human_player_by_unit
            sync_health_markers(active_health_units)
        end
    else
        sync_health_markers({})
    end

    for _, entry in ipairs(hud_players) do
        local state

        state = native_coherence_state(entry, hud_players)

        local old_state = mod.previous_player_states[entry.id]

        if get_bool_setting("show_coherence_state", true) and old_state and old_state ~= state and (state == "self_out" or state == "other_out") then
            play_out_sound_once(t)
        end

        if get_bool_setting("show_coherence_state", true) and old_state and old_state ~= state and entry.is_self and get_bool_setting("coherence_messages_enabled", true) then
            if state == "self_out" then
                mod:echo(tr("coherence_left"))
            elseif state == "self_coherent" then
                mod:echo(tr("coherence_entered"))
            end
        end

        mod.previous_player_states[entry.id] = state

        if not get_bool_setting("show_coherence_state", true) and state ~= "dead" then
            state = entry.is_self and "self_coherent" or "other_coherent"
        end

        entry.state = state
    end

    table.sort(hud_players, function(a, b)
        if a.is_self ~= b.is_self then
            return a.is_self
        end

        return a.sort_key < b.sort_key
    end)

    while #hud_players > MAX_HUD_PLAYERS do
        table.remove(hud_players)
    end

    if #hud_players == 0 and local_player then
        local entry = build_hud_player_entry(local_player, local_player, local_position, 1)

        if entry then
            entry.state = entry.is_dead and "dead" or "self_coherent"
            hud_players[1] = entry
        end
    end

    mod.hud_players = hud_players
    update_debug_signature(hud_players)

    return hud_players
end

mod.update_local_archetype = function()
    local raw_archetype = get_local_player_archetype()
    local normalized = normalize_archetype_name(raw_archetype)

    mod.detected_archetype = normalized

    mod.debug_last_archetype = raw_archetype or mod.debug_last_archetype

    return normalized
end

mod.on_enabled = function()
end

mod.on_disabled = function()
    remove_all_health_markers()
end

mod.on_all_mods_loaded = function()
    if get_setting("class_icon_style", "auto") ~= "font" then
        ensure_icon_packages_loaded()
    end
end

mod.on_setting_changed = function(setting_id)
    -- Any setting change may be a colour change; clearing the whole cache is a
    -- handful of table writes on a menu interaction, versus matching prefixes
    -- on every callback.
    if mod.invalidate_color_cache then
        mod.invalidate_color_cache()
    end

    --[[
        The per-frame hooks cache their gating setting rather than reading it
        sixty times a second. This is what keeps those caches honest - DMF
        fires this on every change, so clearing here means a cached value can
        never outlive the setting it came from.
    --]]
    if mod.refresh_outline_setting then
        mod.refresh_outline_setting()
    end

    if mod.refresh_local_ability_setting then
        mod.refresh_local_ability_setting()
    end

    if setting_id == "show_ally_health_bars" and not get_bool_setting("show_ally_health_bars", false) then
        remove_all_health_markers()
    elseif setting_id == "disable_in_mourningstar" and mod.is_disabled_in_hub() then
        remove_all_health_markers()
        mod.human_player_by_unit = {}
        mod.hud_players = {}
    elseif setting_id == "language" then
        local ok, message = pcall(tr, "language_changed")

        if ok and message and mod.echo then
            pcall(mod.echo, mod, message)
        end
    end
end

mod:hook_safe("PlayerUnitInputExtension", "fixed_update", function(self, unit)
    mod.local_player_unit_from_input = unit
end)

mod:hook_safe("OutlineSystem", "init", function(self)
    mod.outline_system = self
end)

mod:hook_safe("OutlineSystem", "destroy", function()
    mod.outline_system = nil
end)

mod:hook("OutlineSystem", "set_global_visibility", function(func, self, visible, ...)
    if get_bool_setting("show_world_nameplates", true) then
        visible = true
    end

    mod.outline_system = self

    return func(self, visible, ...)
end)

mod:hook("HudElementWorldMarkers", "_create_widget", function(func, self, name, definition)
    add_world_locator_box_to_definition(name, definition)

    return func(self, name, definition)
end)

mod:hook_safe("HudElementWorldMarkers", "event_add_world_marker_unit", function(self, marker_type, unit)
    if type(marker_type) ~= "string" or not string.find(marker_type, "nameplate") or string.find(marker_type, "companion") then
        return
    end

    local markers = self._markers_by_type and self._markers_by_type[marker_type]

    if type(markers) ~= "table" then
        return
    end

    for i = 1, #markers do
        local marker = markers[i]

        local marker_unit = safe_field(marker, "unit")

        if marker and marker_unit == unit and not safe_field(marker, "dio_handholder_profile_hooks") then
            marker.dio_handholder_profile_hooks = true
            marker._event_update_player_name = function(marker_self)
                local unit = safe_field(marker_self, "unit")
                local entry = unit and mod.human_player_by_unit and mod.human_player_by_unit[unit]

                if entry then
                    update_world_nameplate_marker(marker_self, entry)
                end
            end

            marker.cb_event_player_profile_updated = function(marker_self, synced_peer_id, synced_local_player_id, new_profile, force_update)
                local player = safe_field(marker_self, "data")
                local peer_id = safe_call(player, "peer_id")
                local valid = force_update or peer_id and peer_id == synced_peer_id

                if not valid then
                    return
                end

                local set_profile = safe_field(player, "set_profile")

                if type(set_profile) == "function" and new_profile then
                    pcall(set_profile, player, new_profile)
                end

                local unit = safe_field(marker_self, "unit")
                local entry = unit and mod.human_player_by_unit and mod.human_player_by_unit[unit]

                if entry then
                    update_world_nameplate_marker(marker_self, entry)
                end
            end

            return
        end
    end
end)

--[[
    PER-FRAME HOOK. Everything avoidable has been hoisted out of it.

    This runs once per frame and walks every world-marker type the game has.
    Three things in the old version were paid on every frame for an answer that
    never changes:

    1. TWO string.find CALLS PER MARKER TYPE, PER FRAME. Whether the string
       "nameplate_party" contains "nameplate" is fixed for the lifetime of the
       process, but it was being re-derived ~15 times a frame, forever. Now
       memoised in WANTED_MARKER_TYPE, so after the first frame it is one hash
       lookup.

    2. safe_field PER MARKER, PER FRAME - which allocated a closure each time
       (see the note on safe_field above). `marker.unit` is a plain table
       index on a table the game owns and cannot throw, so the guard bought
       nothing and cost an allocation per nameplate per frame.

    3. The human_player_by_unit lookup is hoisted into a local rather than
       re-indexed through `mod.` on every marker.
--]]
local WANTED_MARKER_TYPE = {}

local function is_nameplate_type(marker_type)
    local cached = WANTED_MARKER_TYPE[marker_type]

    if cached == nil then
        cached = type(marker_type) == "string"
            and string.find(marker_type, "nameplate", 1, true) ~= nil
            and string.find(marker_type, "companion", 1, true) == nil
        WANTED_MARKER_TYPE[marker_type] = cached
    end

    return cached
end

mod:hook_safe("HudElementWorldMarkers", "_calculate_markers", function(self)
    local markers_by_type = self._markers_by_type
    local by_unit = mod.human_player_by_unit

    if not markers_by_type or not by_unit then
        return
    end

    for marker_type, markers in pairs(markers_by_type) do
        if is_nameplate_type(marker_type) then
            for i = 1, #markers do
                local marker = markers[i]
                local unit = marker and marker.unit
                local entry = unit and by_unit[unit]

                if entry and not entry.is_self then
                    update_world_nameplate_marker(marker, entry)
                end
            end
        end
    end
end)

mod:hook_safe("HuskCoherencyExtension", "on_coherency_exit", function(self, coherency_unit)
    if self._unit ~= get_local_player_unit() then
        return
    end

    set_native_coherence(coherency_unit, false)
end)

mod:hook_safe("HuskCoherencyExtension", "on_coherency_enter", function(self, coherency_unit)
    if self._unit ~= get_local_player_unit() then
        return
    end

    set_native_coherence(coherency_unit, true)
end)

-- ---------------------------------------------------------------------------
-- TalentUI, folded in
-- ---------------------------------------------------------------------------
-- DHT.lua is TalentUI's main script copied verbatim (only its mod handle and
-- file paths renamed). Loading it here installs its hooks under this mod, so
-- the teammate ability icons come from the code that already worked rather
-- than from a reimplementation.
pcall(function()
    mod:io_dofile("Dio's Handholder/scripts/mods/DiosHandholder/DHT")
end)

-- Expose the copied mod's own state detectors to the additions below.
-- unit_is_dead_or_disabled checks FOUR components - character_state,
-- disabled_character_state, knocked_down_character_state and
-- ledge_hanging_character_state - where my own version only read the first,
-- which is why downed teammates were never detected.
mod.unit_is_dead_or_disabled = unit_is_dead_or_disabled

--[[
    Is the local player alive and in a mission?

    Used by the jumpscare to avoid firing in the hub or over a corpse.
    Written defensively because it runs every frame and every manager it
    touches is nil at some point during a mission transition.
--]]
mod.unit_is_alive_local = function()
    local pm = Managers and Managers.player

    if not pm or not pm.local_player_safe then
        return false
    end

    local ok, p = pcall(pm.local_player_safe, pm, 1)
    local unit = ok and p and p.player_unit

    if not unit then
        return false
    end

    local dead = true
    local ok_d, d = pcall(unit_is_dead_or_disabled, unit)

    if ok_d then
        dead = d
    end

    return not dead
end
mod.unit_is_alive_checked = unit_is_alive

-- ---------------------------------------------------------------------------
-- Additions on top of the copied baseline
-- ---------------------------------------------------------------------------
-- Everything above this line is coherence_hud and TalentUI copied verbatim.
-- Everything below is new behaviour that neither mod provides, kept in
-- separate files so the copied code stays a clean copy and can be refreshed
-- from upstream without untangling my changes from theirs.
--
--   outlines  - paints ally world outlines in their class colour
--   nameplate - downed teammates show their ability + bleedout instead of a name
--
-- pcall'd individually: a fault in an addition must not take down the baseline,
-- which is the part that actually works.
pcall(function()
    mod:io_dofile("Dio's Handholder/scripts/mods/DiosHandholder/DiosHandholder_outlines")
end)

--[[
    The separate nameplate hook is NOT loaded any more.

    It wrote content.header_text from outside, and update_world_nameplate_marker
    in this file writes the same field - so whichever ran last won, and it was
    never mine. The downed display is now produced inside
    build_world_nameplate_text above, where the single writer lives.
--]]
--[[
    LOUD on failure.

    This was a bare pcall with no handler, so if either module failed to load
    the downed display simply never appeared and there was nothing in the log
    to say why - which is most of the reason this feature has been "not
    working" repeatedly without a diagnosable cause.
--]]
do
    local ok_t, tags = pcall(mod.io_dofile, mod,
        "Dio's Handholder/scripts/mods/DiosHandholder/DiosHandholder_tags")
    if ok_t and type(tags) == "table" then
        mod.__dio_tags = tags
    else
        mod:error("[Dio] tags module failed to load - downed ability tags disabled: %s", tostring(tags))
    end

    local ok_b, bleed = pcall(mod.io_dofile, mod,
        "Dio's Handholder/scripts/mods/DiosHandholder/DiosHandholder_bleedout")
    if ok_b and type(bleed) == "table" then
        mod.__dio_bleedout = bleed
    else
        mod:error("[Dio] bleedout module failed to load - percentage disabled: %s", tostring(bleed))
    end
end

-- ---------------------------------------------------------------------------
-- Diagnostics
-- ---------------------------------------------------------------------------
-- These were defined in the previous version of this file and were lost when
-- it was replaced by the coherence_hud copy, which is why /hhbleed did not
-- exist when it was needed. Restored here, after the copy, so a replace cannot
-- silently take them again.
local _Tags = nil
local _Bleed = nil
pcall(function()
    --[[
        Sound swaps must load before the breed sound tables are first required,
        so this sits with the other module loads rather than being deferred.
    --]]
    pcall(mod.io_dofile, mod, "Dio's Handholder/scripts/mods/DiosHandholder/DiosHandholder_sounds")

    -- Publishes mod.__dio_rangefinder and registers /range. The HUD element
    -- reads it through that field, so a failure here costs the readout and
    -- nothing else.
    pcall(mod.io_dofile, mod, "Dio's Handholder/scripts/mods/DiosHandholder/DiosHandholder_rangefinder")

    -- Publishes mod.__dio_tracers, which mod.update below drives.
    pcall(mod.io_dofile, mod, "Dio's Handholder/scripts/mods/DiosHandholder/DiosHandholder_tracers")

    --[[
        The two backend gates. Both only DEFINE their resolve logic here -
        neither calls get_mod, loads a DLL or touches SimpleAssets/SimpleAudio
        until something asks them for a texture or a sound, which is always a
        normal frame rather than mod load. That ordering is the rule that came
        out of the SoloPlay breakage.
    --]]
    mod:io_dofile("Dio's Handholder/scripts/mods/DiosHandholder/DiosHandholder_assets")
    mod:io_dofile("Dio's Handholder/scripts/mods/DiosHandholder/DiosHandholder_audio")
    mod:io_dofile("Dio's Handholder/scripts/mods/DiosHandholder/DiosHandholder_jumpscare")
    _Tags = mod:io_dofile("Dio's Handholder/scripts/mods/DiosHandholder/DiosHandholder_tags")
    _Bleed = mod:io_dofile("Dio's Handholder/scripts/mods/DiosHandholder/DiosHandholder_bleedout")
end)

--[[
    /hhdowned - prints every link in the chain for each teammate.

    This feature has been reported broken several times and each diagnosis was
    a guess, because a silent nil anywhere in
    modules -> is_dead -> ability extension -> tag -> text
    looks identical from the outside. One command, whole chain, no guessing.
--]]
mod:command("hhdowned", "Dio: show the downed-tag chain for each teammate", function()
    local Tags = mod.__dio_tags
    local Bleed = mod.__dio_bleedout

    mod:echo(string.format("[Dio] tags module: %s   bleedout module: %s   setting: %s",
        Tags and "loaded" or "MISSING",
        Bleed and "loaded" or "MISSING",
        tostring(mod:get("dio_downed_ability_names"))))

    if not Tags then
        mod:echo("[Dio] tags module missing - check the log for the load error at startup.")
        return
    end

    local pm = Managers and Managers.player
    if not pm then
        mod:echo("[Dio] no player manager (not in a mission?)")
        return
    end

    for _, player in pairs(pm:players()) do
        local unit = player.player_unit
        local name = "?"
        pcall(function() name = player:name() end)

        local downed = "?"
        if mod.unit_is_dead_or_disabled and unit then
            local ok, d = pcall(mod.unit_is_dead_or_disabled, unit)
            downed = ok and tostring(d) or "err"
        end

        local ext = Tags.ability_extension and Tags.ability_extension(player)
        local cfg_ok = false
        pcall(function()
            local c = require("scripts/settings/player_character/player_character_constants")
            cfg_ok = (c and c.ability_configuration) and true or false
        end)
        local tag = Tags.ability_tag_of and Tags.ability_tag_of(player)

        --[[
            STATE is printed alongside the label now. The whole bleedout bug
            was that "downed" and "knocked down" are different things, so a
            diagnostic that only showed the first could never have caught it.
        --]]
        local state = Tags.character_state and Tags.character_state(player) or nil
        local kd    = Tags.is_knocked_down and Tags.is_knocked_down(player) or false
        local label = (Bleed and Bleed.label) and select(1, Bleed.label(player)) or nil

        local published = mod.__dio_combat_ability
        local pub_id = published and published[player] or nil

        mod:echo(string.format("  %-16s unit=%s  downed=%s  state=%s  kd=%s  ability_ext=%s  cfg=%s  published=%s  tag=%s  bleed=%s",
            tostring(name),
            unit and "yes" or "NO",
            downed,
            tostring(state or "nil"),
            tostring(kd),
            ext and "yes" or "NO",
            cfg_ok and "yes" or "NO",
            tostring(pub_id or "nil"),
            tostring(tag or "nil"),
            tostring(label or "nil")))
    end
end)

mod:command("hhbleed", "print downed-state and bleedout numbers for every teammate", function()
    local pm = Managers and Managers.player
    if not pm or not _Tags then
        mod:echo("not ready - run this in a mission")
        return
    end

    local ok, players = pcall(pm.players, pm)
    if not ok or not players then
        mod:echo("could not read players")
        return
    end

    local n = 0
    for _, player in pairs(players) do
        n = n + 1
        local nok, nm = pcall(player.name, player)
        local downed = _Tags.is_downed and _Tags.is_downed(player)
        local line = string.format("%s: downed=%s", tostring((nok and nm) or "?"), tostring(downed))
        if downed and _Bleed and _Bleed.debug then
            line = line .. "  " .. tostring(_Bleed.debug(player))
        end
        mod:echo(line)
    end
    if n == 0 then mod:echo("no players found") end
end)

mod:command("hhtalents", "print teammate ability ids and resolved tags", function()
    local pm = Managers and Managers.player
    if not pm or not _Tags then
        mod:echo("not ready - run this in a mission")
        return
    end
    local ok, players = pcall(pm.players, pm)
    if not ok or not players then return end
    for _, player in pairs(players) do
        local nok, nm = pcall(player.name, player)
        local ext = _Tags.ability_extension and _Tags.ability_extension(player)
        local id = ext and _Tags.equipped({ ability = ext }, _Tags.SLOT_COMBAT) or nil
        local tag = _Tags.ability_tag_of and _Tags.ability_tag_of(player) or nil
        mod:echo(string.format("%s: class=%s ability_id=%s tag=%s",
            tostring((nok and nm) or "?"),
            tostring(_Tags.class_key and _Tags.class_key(player)),
            tostring(id), tostring(tag)))
    end
end)

mod:command("hhoutline", "report ally outline state", function()
    local ok, sys = pcall(function()
        return Managers.state.extension:system("outline_system")
    end)
    if not ok or not sys then
        mod:echo("no outline system")
        return
    end
    mod:echo(string.format("outlines=%s visible=%s",
        tostring(sys._total_num_outlines), tostring(sys._visible)))
    local pm = Managers and Managers.player
    local count = 0
    if sys._unit_extension_data then
        for unit, ext in pairs(sys._unit_extension_data) do
            local p = pm and pm:player_by_unit(unit)
            if p then
                count = count + 1
                local top = ext.outlines and ext.outlines[1]
                local nok, nm = pcall(p.name, p)
                mod:echo(string.format("  %s: top=%s", tostring((nok and nm) or "?"),
                    tostring(top and top.name)))
            end
        end
    end
    if count == 0 then mod:echo("  no PLAYER units carry an outline") end
end)

-- ---------------------------------------------------------------------------
-- Per-frame entry point
-- ---------------------------------------------------------------------------

--[[
    DMF calls mod.update(dt) once per frame when the field exists.

    The tracers need a real per-frame hook rather than a HUD element's update,
    because they draw into the WORLD through a line object rather than into a
    UI workspace. Driving world drawing from a HUD element would tie it to that
    element's visibility group and stop it working in exactly the states - like
    being grabbed - where seeing the thing holding you matters most.

    pcall'd and kept to one call: anything that throws here throws every frame,
    and a stack spam at 60Hz is its own performance problem on top of whatever
    actually broke.
--]]
function mod.update(dt)
    local tracers = mod.__dio_tracers

    if tracers and tracers.update then
        pcall(tracers.update, dt)
    end

    -- Spam-bark timer. Cheap when the mode is off: one settings read and a
    -- compare before it returns.
    if mod.sounds_update then
        pcall(mod.sounds_update, dt)
    end

    --[[
        Jumpscare roll. Returns on its first line when the feature is off,
        which is the default, so the cost of having it installed is one
        settings read per frame.
    --]]
    local jump = mod.__dio_jumpscare

    if jump and jump.update then
        pcall(jump.update, dt)
    end
end

--[[
    Line objects belong to the world they were created in, so the cached one is
    dropped when a mission ends rather than carried into the next world where
    it would be a dead handle.
--]]
mod.on_game_state_changed = function(status, state_name)
    if status == "exit" and mod.__dio_tracers and mod.__dio_tracers.reset then
        pcall(mod.__dio_tracers.reset)
    end

    if status == "exit" and mod.__dio_bleedout and mod.__dio_bleedout.reset then
        pcall(mod.__dio_bleedout.reset)
    end
end

--[[
    ========================================================================
    CONFLICT REPORT
    ========================================================================

    Written because "your mod breaks my other mod" was diagnosed three times
    by reading source and guessing, and guessing did not settle it. This
    prints the state another mod could plausibly be fighting over, so a
    report comes back as facts rather than as a symptom.

    Deliberately reports what this mod has DONE to shared state - the global
    dofile hook, the hologram gate, the outline system - rather than its own
    settings, because a conflict is by definition about shared state.
--]]
mod:command("hhconflict", "report what Handholder has changed that other mods can see", function()
    local function say(fmt, ...)
        mod:echo("[hhconflict] " .. string.format(fmt, ...))
    end

    say("mod enabled: %s", tostring(mod:is_enabled()))

    --[[
        The global dofile. If this is not the engine's own function, some mod
        has wrapped it - this one does, and reports so, but if the chain is
        longer than expected that is worth seeing.
    --]]
    local df = rawget(_G, "dofile")
    say("_G.dofile is %s (this mod wraps it for the ability cooldown widget)",
        type(df))

    --[[
        The hologram gate. Reported with the game mode, because the whole
        defect this replaced was reading the mode by name and getting four
        of them wrong.
    --]]
    local gm = Managers and Managers.state and Managers.state.game_mode

    if gm then
        local ok_name, name = pcall(gm.game_mode_name, gm)
        local ok_holo, holo = pcall(gm.disable_hologram, gm)

        say("game mode: %s   disable_hologram(): %s",
            ok_name and tostring(name) or "?",
            ok_holo and tostring(holo) or "error")
    else
        say("game mode: no game_mode manager (in a menu)")
    end

    --[[
        Which other mods this one looks for. A missing one is not an error -
        every lookup is optional - but knowing which are present turns
        "works for me" into something comparable between two machines.
    --]]
    local watched = {
        "SoloPlay", "TrueSoloQoL", "NumericUI", "TalentUI", "PlayerOutlines",
        "QIangIQsGeneralEnemyOutliner", "coherency_zone", "custom_hud",
        "HavocTracker", "IconBrowser", "who_are_you", "true_level",
    }
    local present = {}

    for i = 1, #watched do
        local m = safe_get_mod(watched[i])

        if m then
            local ok, on = pcall(m.is_enabled, m)
            present[#present + 1] = watched[i] .. (ok and on and "" or "(off)")
        end
    end

    say("other mods present: %s",
        #present > 0 and table.concat(present, ", ") or "none of the watched list")

    --[[
        Hooks this mod installs that replace or wrap engine behaviour other
        mods also reach for. Named explicitly so a conflict report can be
        checked against another mod's hook list without reading this source.
    --]]
    say("shared hooks: _G.dofile (wrap), GameModeManager.disable_hologram (wrap),")
    say("              OutlineSystem init/destroy/update/set_global_visibility,")
    say("              PlayerUnitOutlineExtension.extensions_ready,")
    say("              HudElementWorldMarkers _create_widget/_calculate_markers,")
    say("              HuskCoherencyExtension on_coherency_enter/exit,")
    say("              PlayerUnitSmartTargetingExtension.fixed_update (rangefinder)")
end)
