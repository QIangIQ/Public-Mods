local mod = get_mod("DiosHandholder")

local VERSION = "0.0.7"

local function safe_get(setting_id, fallback)
    if not mod or not mod.get then
        return fallback
    end

    local ok, value = pcall(mod.get, mod, setting_id)

    if ok and value ~= nil then
        return value
    end

    return fallback
end

local function normalize_language(language)
    language = tostring(language or "en"):lower()

    if language == "br-pt" or language == "pt_br" then
        return "pt-br"
    end

    if language ~= "en" and language ~= "pt-br" and language ~= "es" then
        return "en"
    end

    return language
end

local function safe_color_component(value, fallback)
    value = tonumber(value)

    if not value then
        return fallback
    end

    if value < 0 then
        return 0
    end

    if value > 255 then
        return 255
    end

    return math.floor(value + 0.5)
end

local function color(text, r, g, b)
    text = tostring(text or "")
    r = safe_color_component(r, 255)
    g = safe_color_component(g, 255)
    b = safe_color_component(b, 255)

    return string.format("{#color(%d,%d,%d)}%s{#reset()}", r, g, b, text)
end

local TEXT = {
    mod_name = {
        en = color("Dio's", 210, 245, 210) .. " " .. color("Expanded UI", 255, 215, 55),
        ["pt-br"] = color("Dio's", 210, 245, 210) .. " " .. color("Expanded UI", 255, 215, 55),
        es = color("Dio's", 210, 245, 210) .. " " .. color("Expanded UI", 255, 215, 55),
    },
    mod_description = {
        en = color("v" .. VERSION .. "  |  Author: Dioscurio", 255, 215, 95)
            .. "\n"
            .. color("Squad readability at small render scales - class-coloured bar, ally outlines, teammate abilities and downed callouts.", 185, 210, 170)
            .. "\n ",
        ["pt-br"] = color("v" .. VERSION .. "  |  Author: Dioscurio", 255, 215, 95)
            .. "\n"
            .. color("Leitura do esquadrão em escalas baixas - barra colorida por classe, contornos de aliados, habilidades da equipe e avisos de queda.", 185, 210, 170)
            .. "\n ",
        es = color("v" .. VERSION .. "  |  Author: Dioscurio", 255, 215, 95)
            .. "\n"
            .. color("Legibilidad del escuadrón en escalas bajas - barra por clase, contornos de aliados, habilidades del equipo y avisos de caída.", 185, 210, 170)
            .. "\n ",
    },
    interface_group = { en = color("Interface", 255, 215, 95), ["pt-br"] = color("Interface", 255, 215, 95), es = color("Interfaz", 255, 215, 95) },
    compatibility_group = { en = color("Compatibility", 255, 215, 95), ["pt-br"] = color("Compatibilidade", 255, 215, 95), es = color("Compatibilidad", 255, 215, 95) },
    language = { en = "Language", ["pt-br"] = "Idioma", es = "Idioma" },
    language_tooltip = {
        en = "Selects Coherence HUD's own language. HUD text changes immediately; DMF menu labels are rebuilt after reloading mods or restarting the game.",
        ["pt-br"] = "Seleciona o idioma próprio do Coherence HUD. Textos da HUD mudam na hora; labels do menu DMF são reconstruídos ao recarregar os mods ou reiniciar o jogo.",
        es = "Selecciona el idioma propio de Coherence HUD. El texto de la HUD cambia al instante; las etiquetas del menú DMF se reconstruyen al recargar mods o reiniciar el juego.",
    },
    language_en = { en = "English", ["pt-br"] = "Inglês", es = "Inglés" },
    language_pt_br = { en = "Português", ["pt-br"] = "Português", es = "Portugués" },
    language_es = { en = "Español", ["pt-br"] = "Espanhol", es = "Español" },
    disable_in_mourningstar = { en = "Disable in Mourningstar", ["pt-br"] = "Desativar no Mourningstar", es = "Desactivar en Mourningstar" },
    disable_in_mourningstar_tooltip = {
        en = "Hides Coherence HUD in the hub/social space. Missions are unaffected.",
        ["pt-br"] = "Oculta o Coherence HUD no hub/espaço social. Missões não são afetadas.",
        es = "Oculta Coherence HUD en el hub/espacio social. Las misiones no se ven afectadas.",
    },

    coherence_messages_group = { en = color("Coherence Messages", 255, 215, 95), ["pt-br"] = color("Mensagens de coerência", 255, 215, 95), es = color("Mensajes de coherencia", 255, 215, 95) },
    coherence_messages_enabled = { en = "Show enter/exit coherence messages", ["pt-br"] = "Mostrar mensagens ao entrar/sair da coerência", es = "Mostrar mensajes al entrar/salir de coherencia" },
    coherence_messages_enabled_tooltip = { en = "Shows a small chat message when you enter or leave team coherence.", ["pt-br"] = "Mostra uma pequena mensagem no chat quando você entra ou sai da coerência da equipe.", es = "Muestra un pequeño mensaje en el chat cuando entras o sales de la coherencia del equipo." },

    hud_group = { en = color("HUD", 255, 215, 95), ["pt-br"] = color("HUD", 255, 215, 95), es = color("HUD", 255, 215, 95) },
    show_hud = { en = "Show bottom HUD", ["pt-br"] = "Mostrar HUD inferior", es = "Mostrar HUD inferior" },
    show_hud_tooltip = { en = "Shows the compact squad coherence HUD near the bottom center of the screen.", ["pt-br"] = "Mostra a HUD compacta de coerência do esquadrão perto da parte inferior central da tela.", es = "Muestra la HUD compacta de coherencia del escuadrón cerca de la parte inferior central de la pantalla." },
    show_hud_distance = { en = "Show distance on HUD", ["pt-br"] = "Mostrar distância na HUD", es = "Mostrar distancia en la HUD" },
    show_hud_distance_tooltip = { en = "Shows teammate distance above each bottom HUD slot.", ["pt-br"] = "Mostra a distância dos aliados acima de cada espaço da HUD inferior.", es = "Muestra la distancia de los aliados sobre cada espacio de la HUD inferior." },
    show_distance = { en = "Show distance", ["pt-br"] = "Mostrar distância", es = "Mostrar distancia" },
    show_distance_tooltip = { en = "Global distance toggle for Coherence HUD text.", ["pt-br"] = "Controle global de distância dos textos do Coherence HUD.", es = "Control global de distancia para los textos de Coherence HUD." },
    show_ally_name = { en = "Show ally name", ["pt-br"] = "Mostrar nome do aliado", es = "Mostrar nombre del aliado" },
    show_ally_name_tooltip = { en = "When enabled, the bottom HUD label uses the player name.", ["pt-br"] = "Quando ligado, a HUD inferior usa o nome do jogador.", es = "Al activarlo, la etiqueta inferior usa el nombre del jugador." },
    show_class_icon = { en = "Show class icon", ["pt-br"] = "Mostrar ícone de classe", es = "Mostrar icono de clase" },
    show_class_icon_tooltip = { en = "Shows a class icon in each bottom HUD slot.", ["pt-br"] = "Mostra um ícone de classe em cada espaço da HUD inferior.", es = "Muestra un icono de clase en cada espacio de la HUD inferior." },
    class_icon_style = { en = "Class icon style", ["pt-br"] = "Estilo do ícone de classe", es = "Estilo de icono de clase" },
    class_icon_style_tooltip = {
        en = "Auto uses the original texture when IconBrowser is loaded, then falls back to safe font icons if needed.",
        ["pt-br"] = "Auto usa a textura original quando o IconBrowser está carregado e cai para ícones de fonte seguros se necessário.",
        es = "Auto usa la textura original cuando IconBrowser está cargado y usa iconos de fuente seguros si hace falta.",
    },
    class_icon_style_auto = { en = "Auto (IconBrowser)", ["pt-br"] = "Auto (IconBrowser)", es = "Auto (IconBrowser)" },
    class_icon_style_font = { en = "Font icon (safe)", ["pt-br"] = "Ícone de fonte (seguro)", es = "Icono de fuente (seguro)" },
    class_icon_style_texture = { en = "Original texture", ["pt-br"] = "Textura original", es = "Textura original" },
    hud_icon_scale = { en = "Bottom icon size", ["pt-br"] = "Tamanho do ícone inferior", es = "Tamaño del icono inferior" },
    hud_icon_scale_tooltip = { en = "Scales class icons in the bottom HUD.", ["pt-br"] = "Redimensiona os ícones de classe da HUD inferior.", es = "Escala los iconos de clase de la HUD inferior." },
    show_coherence_state = { en = "Show coherence state", ["pt-br"] = "Mostrar estado de coerência", es = "Mostrar estado de coherencia" },
    show_coherence_state_tooltip = { en = "Controls coherence state coloring and enter/exit warnings.", ["pt-br"] = "Controla cores de estado de coerência e avisos de entrada/saída.", es = "Controla los colores de estado de coherencia y avisos de entrada/salida." },
    show_unavailable_players = { en = "Show dead/disconnected players", ["pt-br"] = "Mostrar jogadores mortos/desconectados", es = "Mostrar jugadores muertos/desconectados" },
    show_unavailable_players_tooltip = { en = "Keeps players visible when their unit is dead, missing, or temporarily unavailable.", ["pt-br"] = "Mantém jogadores visíveis quando a unidade está morta, ausente ou temporariamente indisponível.", es = "Mantiene visibles a los jugadores cuando su unidad está muerta, ausente o temporalmente no disponible." },
    hud_label_mode = { en = "HUD label mode", ["pt-br"] = "Modo do texto da HUD", es = "Modo de etiqueta de la HUD" },
    hud_label_mode_tooltip = { en = "Chooses what text appears below each bottom HUD slot.", ["pt-br"] = "Escolhe qual texto aparece abaixo de cada espaço da HUD inferior.", es = "Elige qué texto aparece debajo de cada espacio de la HUD inferior." },
    hud_label_mode_class = { en = "Class", ["pt-br"] = "Classe", es = "Clase" },
    hud_label_mode_name = { en = "Player Name", ["pt-br"] = "Nome do jogador", es = "Nombre del jugador" },
    hud_label_mode_hidden = { en = "Hidden", ["pt-br"] = "Oculto", es = "Oculto" },

    world_markers_group = { en = color("Ally Markers", 255, 215, 95), ["pt-br"] = color("Marcadores dos aliados", 255, 215, 95), es = color("Marcadores de aliados", 255, 215, 95) },
    show_world_nameplates = { en = "Show ally world markers", ["pt-br"] = "Mostrar marcadores dos aliados", es = "Mostrar marcadores de aliados" },
    show_world_nameplates_tooltip = { en = "Enhances teammate nameplates in the world with coherence-focused information.", ["pt-br"] = "Melhora os nameplates dos aliados no mundo com informações focadas em coerência.", es = "Mejora los nameplates de aliados en el mundo con información centrada en coherencia." },
    show_world_distance = { en = "Show distance in world markers", ["pt-br"] = "Mostrar distância nos marcadores", es = "Mostrar distancia en marcadores" },
    show_world_distance_tooltip = { en = "Adds teammate distance to the enhanced world marker text.", ["pt-br"] = "Adiciona a distância dos aliados ao texto melhorado dos marcadores.", es = "Añade la distancia de los aliados al texto mejorado de los marcadores." },
    show_platform_icon = { en = "Show platform icon", ["pt-br"] = "Mostrar ícone da plataforma", es = "Mostrar icono de plataforma" },
    show_platform_icon_tooltip = { en = "Shows Steam, Xbox, PlayStation, or unknown platform icons when available.", ["pt-br"] = "Mostra ícones de Steam, Xbox, PlayStation ou plataforma desconhecida quando disponíveis.", es = "Muestra iconos de Steam, Xbox, PlayStation o plataforma desconocida cuando estén disponibles." },
    show_player_level = { en = "Show player level", ["pt-br"] = "Mostrar nível do jogador", es = "Mostrar nivel del jugador" },
    show_player_level_tooltip = { en = "Includes the character level in the world marker header.", ["pt-br"] = "Inclui o nível do personagem no cabeçalho do marcador.", es = "Incluye el nivel del personaje en el encabezado del marcador." },
    player_level_format = { en = "Level format", ["pt-br"] = "Formato do nível", es = "Formato del nivel" },
    player_level_format_tooltip = {
        en = "Controls Coherence HUD's own level text so it does not force True Level's detailed format.",
        ["pt-br"] = "Controla o texto de nível do Coherence HUD para não forçar o formato detalhado do True Level.",
        es = "Controla el texto de nivel de Coherence HUD para no forzar el formato detallado de True Level.",
    },
    player_level_format_vanilla = { en = "Vanilla", ["pt-br"] = "Padrão do jogo", es = "Predeterminado" },
    player_level_format_true_total = { en = "True Level total", ["pt-br"] = "True Level total", es = "True Level total" },
    player_level_format_true_separate = { en = "True Level 30 (+99)", ["pt-br"] = "True Level 30 (+99)", es = "True Level 30 (+99)" },
    player_level_format_hidden = { en = "Hidden", ["pt-br"] = "Oculto", es = "Oculto" },
    show_player_title = { en = "Show player title", ["pt-br"] = "Mostrar título do jogador", es = "Mostrar título del jugador" },
    show_player_title_tooltip = { en = "Includes the equipped character title below the player name when available.", ["pt-br"] = "Inclui o título equipado abaixo do nome do jogador quando disponível.", es = "Incluye el título equipado debajo del nombre del jugador cuando esté disponible." },
    world_marker_max_distance = { en = "World marker max distance", ["pt-br"] = "Distância máxima dos marcadores", es = "Distancia máxima de marcadores" },
    world_marker_max_distance_tooltip = { en = "Maximum distance in meters for the enhanced ally world markers.", ["pt-br"] = "Distância máxima em metros para os marcadores melhorados dos aliados.", es = "Distancia máxima en metros para los marcadores mejorados de aliados." },
    world_icon_scale = { en = "World icon size", ["pt-br"] = "Tamanho do ícone no mundo", es = "Tamaño del icono mundial" },
    world_icon_scale_tooltip = { en = "Scales icons inside enhanced world markers.", ["pt-br"] = "Redimensiona ícones nos marcadores melhorados do mundo.", es = "Escala los iconos en los marcadores mejorados del mundo." },

    ally_color_group = { en = color("Ally Color", 80, 190, 255), ["pt-br"] = color("Cor dos aliados", 80, 190, 255), es = color("Color de aliados", 80, 190, 255) },
    ally_color_preset = { en = color("Ally color preset", 95, 235, 110), ["pt-br"] = color("Predefinição de cor dos aliados", 95, 235, 110), es = color("Preajuste de color de aliados", 95, 235, 110) },
    ally_color_preset_tooltip = { en = "Changes the color used for coherent allies on the HUD and world markers. RGB values are used only when Custom is selected.", ["pt-br"] = "Altera a cor usada para aliados coerentes na HUD e nos marcadores. Valores RGB só são usados quando Customizado está selecionado.", es = "Cambia el color usado para aliados en coherencia en la HUD y marcadores. Los valores RGB solo se usan con Personalizado." },
    ally_color_red = { en = "R", ["pt-br"] = "R", es = "R" },
    ally_color_green = { en = "G", ["pt-br"] = "G", es = "G" },
    ally_color_blue = { en = "B", ["pt-br"] = "B", es = "B" },
    ally_color_alpha = { en = color("Ally opacity", 230, 235, 225), ["pt-br"] = color("Opacidade dos aliados", 230, 235, 225), es = color("Opacidad de aliados", 230, 235, 225) },
    class_colors_group = { en = color("Class Colors", 80, 190, 255), ["pt-br"] = color("Cores de classe", 80, 190, 255), es = color("Colores de clase", 80, 190, 255) },
    use_class_colors = { en = "Use individual class colors", ["pt-br"] = "Usar cores individuais por classe", es = "Usar colores individuales por clase" },
    use_class_colors_tooltip = {
        en = "Uses class-specific colors for coherent allies in the bottom HUD and world markers.",
        ["pt-br"] = "Usa cores específicas por classe para aliados em coerência na HUD inferior e nos marcadores.",
        es = "Usa colores específicos por clase para aliados en coherencia en la HUD inferior y marcadores.",
    },
    class_color_veteran = { en = "Veteran", ["pt-br"] = "Veterano", es = "Veterano" },
    class_color_zealot = { en = "Zealot", ["pt-br"] = "Fanático", es = "Fanático" },
    class_color_psyker = { en = "Psyker", ["pt-br"] = "Psyker", es = "Psíquico" },
    class_color_ogryn = { en = "Ogryn", ["pt-br"] = "Ogryn", es = "Ogryn" },
    class_color_adamant = { en = "Arbites", ["pt-br"] = "Árbitro", es = "Árbitro" },
    class_color_broker = { en = "Hive Scum", ["pt-br"] = "Escória da Colmeia", es = "Escoria de la Colmena" },
    class_color_cryptic = { en = "Skitarii", ["pt-br"] = "Skitarii", es = "Skitarii" },
    state_colors_group = { en = color("State Colors", 80, 190, 255), ["pt-br"] = color("Cores de estado", 80, 190, 255), es = color("Colores de estado", 80, 190, 255) },
    state_color_out = { en = "Out of coherence", ["pt-br"] = "Fora da coerência", es = "Fuera de coherencia" },
    state_color_disabled = { en = "Dead/disabled", ["pt-br"] = "Morto/desabilitado", es = "Muerto/incapacitado" },
    state_color_distance = { en = "Distance text", ["pt-br"] = "Texto de distância", es = "Texto de distancia" },
    platform_colors_group = { en = color("Platform Icon Colors", 80, 190, 255), ["pt-br"] = color("Cores dos ícones de plataforma", 80, 190, 255), es = color("Colores de iconos de plataforma", 80, 190, 255) },
    platform_color_steam = { en = "Steam", ["pt-br"] = "Steam", es = "Steam" },
    platform_color_xbox = { en = "Xbox", ["pt-br"] = "Xbox", es = "Xbox" },
    platform_color_psn = { en = "PlayStation", ["pt-br"] = "PlayStation", es = "PlayStation" },
    platform_color_unknown = { en = "Unknown platform", ["pt-br"] = "Plataforma desconhecida", es = "Plataforma desconocida" },

    health_color_group = { en = color("Health Bar Color", 80, 190, 255), ["pt-br"] = color("Cor da barra de vida", 80, 190, 255), es = color("Color de barra de vida", 80, 190, 255) },
    show_ally_health_bars = { en = "Show ally health bars", ["pt-br"] = "Mostrar barras de vida dos aliados", es = "Mostrar barras de vida de aliados" },
    show_ally_health_bars_tooltip = { en = "Shows the original extra world-space ally health bars. Can be toggled during a mission without rebuilding the HUD.", ["pt-br"] = "Mostra as barras extras originais de vida dos aliados no mundo. Pode ser alterado durante a missão sem reconstruir a HUD.", es = "Muestra las barras extra originales de vida de aliados en el mundo. Puede cambiarse durante la misión sin reconstruir la HUD." },
    health_color_preset = { en = color("Health color preset", 95, 235, 110), ["pt-br"] = color("Predefinição de cor da vida", 95, 235, 110), es = color("Preajuste de color de vida", 95, 235, 110) },
    health_color_preset_tooltip = { en = "Changes the ally health bar fill color. RGB values are used only when Custom is selected.", ["pt-br"] = "Altera a cor de preenchimento da barra de vida dos aliados. Valores RGB só são usados quando Customizado está selecionado.", es = "Cambia el color de relleno de la barra de vida de aliados. Los valores RGB solo se usan con Personalizado." },
    health_color_red = { en = "R", ["pt-br"] = "R", es = "R" },
    health_color_green = { en = "G", ["pt-br"] = "G", es = "G" },
    health_color_blue = { en = "B", ["pt-br"] = "B", es = "B" },
    health_color_alpha = { en = color("Health opacity", 230, 235, 225), ["pt-br"] = color("Opacidade da vida", 230, 235, 225), es = color("Opacidad de vida", 230, 235, 225) },

    --[[
        THIS MOD'S OWN SECTION HEADINGS.

        Two colours, used consistently: gold for the eight top-level sections,
        pale green for anything nested inside one. The inherited menus used
        gold for coherence_hud's groups and blue for its colour groups while
        TalentUI's had no colour at all, so the menu read as three different
        mods stacked on top of each other. One palette, one hierarchy.
    --]]
    dio_group_squad = { en = color("Squad Bar", 255, 215, 55), ["pt-br"] = color("Barra do esquadrão", 255, 215, 55), es = color("Barra del escuadrón", 255, 215, 55) },
    dio_group_world = { en = color("In World", 255, 215, 55), ["pt-br"] = color("No mundo", 255, 215, 55), es = color("En el mundo", 255, 215, 55) },
    dio_group_downed = { en = color("Downed Allies", 255, 215, 55), ["pt-br"] = color("Aliados caídos", 255, 215, 55), es = color("Aliados caídos", 255, 215, 55) },
    dio_group_audible = { en = color("Audible Disablers", 255, 215, 55), ["pt-br"] = color("Incapacitadores audíveis", 255, 215, 55), es = color("Incapacitadores audibles", 255, 215, 55) },
    dio_group_rangefinder = { en = color("Rangefinder", 255, 215, 55), ["pt-br"] = color("Telêmetro", 255, 215, 55), es = color("Telémetro", 255, 215, 55) },
    dio_group_tracers = { en = color("Disabler Tracers", 255, 215, 55), ["pt-br"] = color("Traçados de incapacitadores", 255, 215, 55), es = color("Trazadores de incapacitadores", 255, 215, 55) },
    dio_group_loadout = { en = color("Teammate Loadout", 255, 215, 55), ["pt-br"] = color("Equipamento dos aliados", 255, 215, 55), es = color("Equipo de aliados", 255, 215, 55) },
    dio_group_you = { en = color("Your Abilities", 255, 215, 55), ["pt-br"] = color("Suas habilidades", 255, 215, 55), es = color("Tus habilidades", 255, 215, 55) },
    dio_group_colors = { en = color("Colours", 255, 215, 55), ["pt-br"] = color("Cores", 255, 215, 55), es = color("Colores", 255, 215, 55) },
    dio_group_general = { en = color("General", 255, 215, 55), ["pt-br"] = color("Geral", 255, 215, 55), es = color("General", 255, 215, 55) },
    dio_group_more = { en = color("More", 255, 215, 55), ["pt-br"] = color("Mais", 255, 215, 55), es = color("Más", 255, 215, 55) },

    dio_sub_abilities = { en = color("Ability, Blitz & Aura", 210, 245, 210), ["pt-br"] = color("Habilidade, Blitz e Aura", 210, 245, 210), es = color("Habilidad, Blitz y Aura", 210, 245, 210) },
    dio_sub_weapons = { en = color("Weapons", 210, 245, 210), ["pt-br"] = color("Armas", 210, 245, 210), es = color("Armas", 210, 245, 210) },
    dio_sub_markers = { en = color("Ally Markers", 210, 245, 210), ["pt-br"] = color("Marcadores dos aliados", 210, 245, 210), es = color("Marcadores de aliados", 210, 245, 210) },
    dio_sub_outlines = { en = color("Ally Outlines", 210, 245, 210), ["pt-br"] = color("Contornos dos aliados", 210, 245, 210), es = color("Contornos de aliados", 210, 245, 210) },
    dio_sub_allies = { en = color("Allies", 210, 245, 210), ["pt-br"] = color("Aliados", 210, 245, 210), es = color("Aliados", 210, 245, 210) },
    dio_sub_classes = { en = color("Classes", 210, 245, 210), ["pt-br"] = color("Classes", 210, 245, 210), es = color("Clases", 210, 245, 210) },
    dio_sub_states = { en = color("States", 210, 245, 210), ["pt-br"] = color("Estados", 210, 245, 210), es = color("Estados", 210, 245, 210) },
    dio_sub_platforms = { en = color("Platform Icons", 210, 245, 210), ["pt-br"] = color("Ícones de plataforma", 210, 245, 210), es = color("Iconos de plataforma", 210, 245, 210) },
    dio_sub_health = { en = color("Health Bars", 210, 245, 210), ["pt-br"] = color("Barras de vida", 210, 245, 210), es = color("Barras de vida", 210, 245, 210) },

    color_gold = { en = color("Gold", 255, 215, 55), ["pt-br"] = color("Dourado", 255, 215, 55), es = color("Dorado", 255, 215, 55) },
    color_blue = { en = color("Blue", 80, 190, 255), ["pt-br"] = color("Azul", 80, 190, 255), es = color("Azul", 80, 190, 255) },
    color_green = { en = color("Green", 95, 235, 110), ["pt-br"] = color("Verde", 95, 235, 110), es = color("Verde", 95, 235, 110) },
    color_purple = { en = color("Purple", 185, 120, 255), ["pt-br"] = color("Roxo", 185, 120, 255), es = color("Morado", 185, 120, 255) },
    color_red = { en = color("Red", 255, 80, 65), ["pt-br"] = color("Vermelho", 255, 80, 65), es = color("Rojo", 255, 80, 65) },
    color_white = { en = color("White", 255, 255, 255), ["pt-br"] = color("Branco", 255, 255, 255), es = color("Blanco", 255, 255, 255) },
    color_custom = { en = "Custom", ["pt-br"] = "Customizado", es = "Personalizado" },
}

local current_language = normalize_language(safe_get("language", "en"))

local function translate(key, language)
    local entry = TEXT[key]
    local normalized_language = normalize_language(language or current_language)

    return entry and (entry[normalized_language] or entry.en) or tostring(key)
end

local function tr(key)
    return translate(key, current_language)
end

if mod then
    mod.dio_handholder_menu_translate = translate
end

local function checkbox(setting_id, default_value, tooltip)
    return {
        setting_id = setting_id,
        type = "checkbox",
        default_value = default_value,
        title = tr(setting_id),
        tooltip = tr(tooltip or setting_id .. "_tooltip"),
        localize = false,
    }
end

local function numeric(setting_id, default_value, range, tooltip, title_key)
    return {
        setting_id = setting_id,
        type = "numeric",
        default_value = default_value,
        range = range,
        decimals_number = 0,
        title = tr(title_key or setting_id),
        tooltip = tooltip and tr(tooltip) or nil,
        localize = false,
    }
end

local function options(items)
    items.localize = false

    return items
end

local function dropdown(setting_id, default_value, items, tooltip)
    return {
        setting_id = setting_id,
        type = "dropdown",
        default_value = default_value,
        title = tr(setting_id),
        tooltip = tr(tooltip or setting_id .. "_tooltip"),
        options = options(items),
        localize = false,
    }
end

local function group(setting_id, sub_widgets)
    return {
        setting_id = setting_id,
        type = "group",
        title = tr(setting_id),
        localize = false,
        sub_widgets = sub_widgets,
    }
end

--[[
    NATIVE COLOUR PICKER, replacing three numeric sliders per colour.

    DMF's August update added a real "color" widget - hue strip, preview
    swatch, optional alpha - so the hand-rolled R/G/B triple every mod was
    carrying is now obsolete. This mod had SIXTEEN of them: 48 sliders plus 16
    wrapper groups to hold them, 64 of the 142 widgets in the tree, for what is
    conceptually sixteen values.

    The reader in DiosHandholder.lua checks this setting_id first and falls
    back to the old prefix_red/_green/_blue trio, so nothing already saved is
    lost - see the note there.

    Stored as {a, r, g, b}: alpha first, matching Darktide's own convention.
--]]
--[[
    NO PROBE. THE COLOUR WIDGET IS ASSUMED ABSENT.

    This used to io_dofile DMF's own blueprint table to ask whether the colour
    widget existed. That probe is why this mod started breaking SoloPlay, and
    the reason is what executing that file COSTS rather than what it returns.

    dmf_options_view_content_blueprints.lua does all of this at file scope:

        io_dofile  dmf_options_view_settings
        io_dofile  color/color_widget      -> color_utils, color_widget_passes
        io_dofile  numeric/numeric_input   -> text_input_utils, ui_renderer
        io_dofile  text_input/text_input_widget
        io_dofile  text/text_widget        -> list_header_templates
        require    button_pass_templates, checkbox_pass_templates,
                   dropdown_pass_templates, keybind_pass_templates,
                   slider_pass_templates, input_utils, ui_font_settings
        Color.ui_terminal(255, true)
        Color.ui_grey_medium(255, true)
        table.clone(UIFontSettings.list_button)

    Eight nested DMF modules and ten engine requires, executed from inside
    new_mod - which runs during early boot, long before the options view is
    ever constructed and long before that part of the UI stack would otherwise
    be touched. Asking a yes/no question by building a third of the settings
    UI is not a probe, it is a side effect with a return value.

    The honest cost of removing it: the colour picker is never offered, and
    the four RGBA sliders are used instead. That was already the fallback
    whenever the probe failed or returned false, so nothing regresses for
    anyone who was getting sliders - and nobody's saved colours change, because
    both paths read and write the same setting ids.
--]]
local COLOR_WIDGET_SUPPORTED = false

mod.color_widget_supported = COLOR_WIDGET_SUPPORTED

--[[
    One colour, as either the native picker or four plain sliders.

    The fallback is not a downgrade in what is stored: the reader in
    DiosHandholder.lua already checks the packed setting first and then falls
    back to prefix_alpha / _red / _green / _blue, so both shapes drive the same
    colour and nothing saved under either is lost.
--]]
local function color_widget(setting_id, red, green, blue, alpha)
    if COLOR_WIDGET_SUPPORTED then
        return {
            setting_id = setting_id,
            type = "color",
            -- has_alpha is validated as a REQUIRED boolean by DMF
            -- (validate_color_data), not merely defaulted, so it is always passed.
            has_alpha = alpha ~= nil,
            default_value = { alpha or 255, red, green, blue },
            title = tr(setting_id),
            localize = false,
        }
    end

    local function slider(suffix, value, label)
        return {
            setting_id = setting_id .. suffix,
            type = "numeric",
            default_value = value,
            range = { 0, 255 },
            decimals_number = 0,
            title = tr(setting_id) .. " - " .. label,
            localize = false,
        }
    end

    local subs = {
        slider("_red", red, "R"),
        slider("_green", green, "G"),
        slider("_blue", blue, "B"),
    }

    if alpha ~= nil then
        subs[#subs + 1] = slider("_alpha", alpha, "A")
    end

    return {
        setting_id = setting_id .. "_group",
        type = "group",
        title = tr(setting_id),
        localize = false,
        sub_widgets = subs,
    }
end


--[[
    TalentUI's widgets, pulled out INDIVIDUALLY and re-parented.

    DHT_data.lua is TalentUI's data file, copied verbatim, and it is left that
    way so it can be re-copied from upstream without redoing a hand merge. But
    its layout is TalentUI's: seven separate top-level groups for what are
    really two things - the teammate ability row and the teammate weapon row.
    Appending those next to coherence_hud's nine groups is what made this menu
    twenty-three entries long.

    So the widgets are looked up BY setting_id and placed into this mod's own
    sections. By id, not by position, because position is what silently breaks
    when upstream reorders something - and anything upstream adds that this
    file does not name still shows up, under "More" at the bottom, rather than
    disappearing without a trace.
--]]
local _ok_dht, _dht = pcall(function()
    return get_mod("DiosHandholder"):io_dofile(
        "Dio's Handholder/scripts/mods/DiosHandholder/DHT_data")
end)

local _dht_index = {}
local _dht_order = {}
local _dht_used = {}

--[[
    Groups are skipped, leaves are kept. TalentUI's group widgets exist only to
    carry its own headings, which are exactly what is being replaced here; the
    settings themselves are the leaves.
--]]
local function _index_widgets(list)
    for i = 1, #list do
        local w = list[i]
        if type(w) == "table" then
            if type(w.setting_id) == "string" and w.type ~= "group" and _dht_index[w.setting_id] == nil then
                _dht_index[w.setting_id] = w
                _dht_order[#_dht_order + 1] = w.setting_id
            end
            if type(w.sub_widgets) == "table" then
                _index_widgets(w.sub_widgets)
            end
        end
    end
end

if _ok_dht and type(_dht) == "table" and _dht.options and type(_dht.options.widgets) == "table" then
    _index_widgets(_dht.options.widgets)
end

--[[
    TalentUI's widgets need localize = true, individually.

    coherence_hud sets options.localize = false and gives every one of its
    widgets an explicit `title`, because it resolves its own translations. But
    TalentUI's widgets carry NO title - they expect DMF to localize their
    setting_id against the localization file.

    Mixed together under localize = false, DMF rejects the TalentUI widgets:

        [widget "group_teammate_ability" (group)]: lacks 'title' field
        (localization is disabled)

    and ONE rejected widget fails the whole options table, which is why the mod
    vanished from the menu entirely rather than showing partial settings.

    DMF flattens the tree before initialising it and applies `localize` per
    widget (initialize_generic_widget_data: "Overwrite global options
    localization setting if widget defined it"), so nesting depth does not
    affect this - a localize = true widget works at any level under a
    localize = false group.
--]]
local function D(setting_id)
    local w = _dht_index[setting_id]

    if not w then
        return nil
    end

    _dht_used[setting_id] = true
    w.localize = true

    return w
end

--[[
    Drops nils, so a missing TalentUI widget leaves a gap rather than an error.
    Relying on table literals here would truncate the list at the first nil.
--]]
local function list(...)
    local out = {}

    for i = 1, select("#", ...) do
        local v = select(i, ...)

        if v ~= nil then
            out[#out + 1] = v
        end
    end

    return out
end

--[[
    Nesting under a CHECKBOX is the actual decluttering mechanism, not just
    visual grouping: DMF hides a checkbox's sub_widgets while it is unchecked
    (mod_options.update_widget_set_visibility - "if parent.type == 'checkbox'
    then is_visible = mod:get(parent.setting_id) == true"). So the icon-style
    and size settings only exist on screen while icons are actually on, which
    is the difference between a long menu and a short one.
--]]
local function with(widget, sub_widgets)
    if widget and type(sub_widgets) == "table" and #sub_widgets > 0 then
        widget.sub_widgets = sub_widgets
    end

    return widget
end

--[[
    Same trick for dropdowns, which support per-option visibility. The RGB
    sliders belong to the "Custom" preset and are meaningless under any other,
    so they are shown only for that value instead of sitting there inert.

    show_widgets indexes into the dropdown's own sub_widgets, so it is built
    from the list rather than hardcoded.
--]]
local function with_preset(widget, sub_widgets, custom_value)
    if not widget then
        return nil
    end

    widget.sub_widgets = sub_widgets

    local indices = {}
    for i = 1, #sub_widgets do
        indices[i] = i
    end

    for i = 1, #widget.options do
        if widget.options[i].value == custom_value then
            widget.options[i].show_widgets = indices
        end
    end

    return widget
end

--[[
    An empty group is a hard error in DMF ("must have at least 1 sub_widget"),
    and one hard error takes the whole options tree with it. Since several
    groups below are assembled from TalentUI widgets that may or may not be
    present, they are built through this rather than declared directly.
--]]
local function group_if(setting_id, sub_widgets)
    if type(sub_widgets) ~= "table" or #sub_widgets == 0 then
        return nil
    end

    return group(setting_id, sub_widgets)
end

-- ---------------------------------------------------------------------------
-- Sections
-- ---------------------------------------------------------------------------
--[[
    Eight sections, organised by WHERE YOU SEE THE THING rather than by which
    mod the code came from:

        Squad Bar        the strip at the bottom of the screen
        In World         nameplates, outlines and health bars on the ally
        Downed Allies    what replaces the name when someone is on the floor
        Teammate Loadout the ability / blitz / aura / weapon icons
        Your Abilities   your own cooldown readout
        Colours          every colour in one place
        General          language, hub, reset
        More             anything upstream added that this file does not name

    Colours in particular were previously four separate top-level groups -
    ally, class, state, platform - plus a fifth for health, which is five
    entries in the list for one concept.
--]]
local _widgets = {}

local function add(widget)
    if widget ~= nil then
        _widgets[#_widgets + 1] = widget
    end
end

-- Squad Bar ------------------------------------------------------------------
add(group("dio_group_squad", {
    --[[
        show_distance sits OUTSIDE show_hud's children on purpose: it is the
        master switch that format_distance_label checks, so it also governs the
        world markers. Nested under show_hud, turning the bar off would silently
        blank the distance on the markers too with no visible cause.
    --]]
    checkbox("show_distance", true),
    with(checkbox("show_hud", true), {
        dropdown("hud_label_mode", "class", {
            { text = tr("hud_label_mode_class"), value = "class" },
            { text = tr("hud_label_mode_name"), value = "name" },
            { text = tr("hud_label_mode_hidden"), value = "hidden" },
        }),
        checkbox("show_ally_name", false),
        checkbox("show_hud_distance", true),
        with(checkbox("show_class_icon", true), {
            dropdown("class_icon_style", "auto", {
                { text = tr("class_icon_style_auto"), value = "auto" },
                { text = tr("class_icon_style_font"), value = "font" },
                { text = tr("class_icon_style_texture"), value = "texture" },
            }),
            numeric("hud_icon_scale", 100, { 60, 140 }, "hud_icon_scale_tooltip"),
        }),
        checkbox("show_coherence_state", true),
        checkbox("show_unavailable_players", true),
    }),
}))

-- In World -------------------------------------------------------------------
add(group("dio_group_world", {
    group("dio_sub_markers", {
        with(checkbox("show_world_nameplates", true), {
            checkbox("show_world_distance", true),
            checkbox("show_platform_icon", true),
            with(checkbox("show_player_level", true), {
                dropdown("player_level_format", "vanilla", {
                    { text = tr("player_level_format_vanilla"), value = "vanilla" },
                    { text = tr("player_level_format_true_total"), value = "true_total" },
                    { text = tr("player_level_format_true_separate"), value = "true_separate" },
                    { text = tr("player_level_format_hidden"), value = "hidden" },
                }),
            }),
            checkbox("show_player_title", true),
            numeric("world_marker_max_distance", 1000, { 50, 1000 }, "world_marker_max_distance_tooltip"),
            numeric("world_icon_scale", 100, { 60, 160 }, "world_icon_scale_tooltip"),
        }),
        checkbox("show_ally_health_bars", false),
    }),
    --[[
        The colouring is nested under the forcing switch because it depends on
        it: with no outline on the unit there is nothing to colour, so exposing
        the colour options while outlines are off invites the exact "I turned it
        on and nothing happened" confusion this ordering avoids.
    --]]
    group("dio_sub_outlines", {
        with({
            setting_id = "dio_force_outlines",
            type = "checkbox",
            default_value = true,
            localize = true,
            tooltip = "dio_force_outlines_tooltip",
        }, {
            {
                setting_id = "dio_class_outlines",
                type = "checkbox",
                default_value = true,
                localize = true,
                tooltip = "dio_class_outlines_tooltip",
            },
            {
                setting_id = "dio_outline_brightness",
                type = "numeric",
                default_value = 70,
                range = { 20, 130 },
                decimals_number = 0,
                localize = true,
                tooltip = "dio_outline_brightness_tooltip",
            },
        }),
    }),
}))

-- Downed Allies --------------------------------------------------------------
add(group("dio_group_downed", {
    with({
        setting_id = "dio_downed_ability_names",
        type = "checkbox",
        default_value = true,
        localize = true,
        tooltip = "dio_downed_ability_names_tooltip",
    }, {
        {
            setting_id = "dio_show_bleedout",
            type = "checkbox",
            default_value = true,
            localize = true,
            tooltip = "dio_show_bleedout_tooltip",
        },
    }),
}))

--[[
    Disabler Tracers -----------------------------------------------------------

    The hound range is exposed as a slider because 16 is the game's number, not
    necessarily yours: it is the distance at which a hound commits to a pounce
    (bt_chaos_hound_approach_action's leave_distance), so it is the last moment
    the line is still useful rather than the first moment it is. Raising it
    trades earlier warning for more lines on screen.
--]]
add(group("dio_group_tracers", {
    with({
        setting_id = "dio_tracers",
        type = "checkbox",
        default_value = false,
        localize = true,
        tooltip = "dio_tracers_tooltip",
    }, {
        {
            setting_id = "dio_tracer_trappers",
            type = "checkbox",
            default_value = true,
            localize = true,
            tooltip = "dio_tracer_trappers_tooltip",
        },
        {
            setting_id = "dio_tracer_hounds",
            type = "checkbox",
            default_value = true,
            localize = true,
            tooltip = "dio_tracer_hounds_tooltip",
        },
        {
            setting_id = "dio_tracer_hound_range",
            type = "numeric",
            default_value = 16,
            range = { 8, 40 },
            decimals_number = 0,
            localize = true,
            tooltip = "dio_tracer_hound_range_tooltip",
        },
        {
            setting_id = "dio_tracer_rave",
            type = "checkbox",
            default_value = false,
            localize = true,
            tooltip = "dio_tracer_rave_tooltip",
        },
    }),
}))

-- Rangefinder ----------------------------------------------------------------
add(group("dio_group_rangefinder", {
    with({
        setting_id = "dio_rangefinder",
        type = "checkbox",
        default_value = false,
        localize = true,
        tooltip = "dio_rangefinder_tooltip",
    }, {
        {
            setting_id = "dio_rangefinder_names",
            type = "checkbox",
            default_value = true,
            localize = true,
            tooltip = "dio_rangefinder_names_tooltip",
        },
    }),
}))

--[[
    Audible Disablers ----------------------------------------------------------

    CREDIT: the idea is Seph's (Steam: Concoction of Constitution), from
    CacklingTrapper - swap a breed's FOOTSTEP event for a vocalisation so it
    announces itself continuously while it moves. This applies the same trick to
    the three hound breeds. Credited in the group tooltip as well as here,
    because a credit only visible in source is not a credit.

    A dropdown rather than a checkbox plus a volume slider: the footstep event
    is fired by the animation system, so there is no Lua call to hang a volume
    on. Choosing between bark, growl and breath is the honest version of a
    loudness control. See DiosHandholder_sounds.lua.
--]]
add(group("dio_group_audible", {
    {
        setting_id = "dio_hound_vocal",
        type = "dropdown",
        default_value = "bark",
        localize = true,
        tooltip = "dio_hound_vocal_tooltip",
        options = {
            localize = true,
            { text = "dio_hound_vocal_off",    value = "off" },
            { text = "dio_hound_vocal_bark",   value = "bark" },
            { text = "dio_hound_vocal_growl",  value = "growl" },
            { text = "dio_hound_vocal_breath", value = "breath" },
            { text = "dio_hound_vocal_spam",   value = "spam" },
        },
    },
}))


-- Teammate Loadout -----------------------------------------------------------
add(group_if("dio_group_loadout", list(
    group_if("dio_sub_abilities", list(
        with(D("show_teammate_ability_icon"), list(D("show_teammate_ability_cooldown"))),
        with(D("show_teammate_blitz_icon"), list(D("show_teammate_blitz_charges"))),
        D("show_teammate_aura_icon"),
        D("teammate_ability_position_preset"),
        D("teammate_ability_vertical_offset"),
        D("teammate_ability_horizontal_offset"),
        D("teammate_ability_orientation"),
        D("teammate_ability_spacing"),
        D("teammate_ability_icon_size"),
        D("teammate_ability_text_alignment"),
        D("teammate_ability_cooldown_font_size")
    )),
    group_if("dio_sub_weapons", list(
        D("show_teammate_weapon_primary_icon"),
        D("show_teammate_weapon_secondary_icon"),
        D("teammate_weapon_position_preset"),
        D("teammate_weapon_vertical_offset"),
        D("teammate_weapon_horizontal_offset"),
        D("teammate_weapon_orientation"),
        D("teammate_weapon_spacing"),
        with(D("teammate_weapon_show_ammo"), list(
            D("teammate_weapon_text_alignment"),
            D("teammate_weapon_ammo_font_size"),
            D("teammate_weapon_ammo_text_offset_x"),
            D("teammate_weapon_ammo_text_offset_y")
        ))
    ))
)))

-- Your Abilities -------------------------------------------------------------
add(group_if("dio_group_you", list(
    D("show_local_ability_active"),
    with(D("show_local_ability_cooldown"), list(
        D("cooldown_format"),
        D("show_local_ability_decimals"),
        D("local_cooldown_font_size")
    )),
    D("show_local_ability_ready_notification")
)))

-- Colours --------------------------------------------------------------------
add(group("dio_group_colors", {
    group("dio_sub_allies", {
        with_preset(dropdown("ally_color_preset", "gold", {
            { text = tr("color_gold"), value = "gold" },
            { text = tr("color_blue"), value = "blue" },
            { text = tr("color_green"), value = "green" },
            { text = tr("color_purple"), value = "purple" },
            { text = tr("color_white"), value = "white" },
            { text = tr("color_custom"), value = "custom" },
        }), {
            -- Alpha lives on the picker now, so it is shown with Custom
            -- rather than sitting outside as a separate slider.
            color_widget("ally_color", 255, 215, 55, 255),
        }, "custom"),
    }),
    --[[
        Seven per-class colour groups behind one switch. They were previously
        always on screen even with class colours disabled, which is seven rows
        of settings that did nothing.
    --]]
    group("dio_sub_classes", {
        with(checkbox("use_class_colors", false), {
            color_widget("class_color_veteran", 90, 175, 255),
            color_widget("class_color_zealot", 255, 70, 55),
            color_widget("class_color_psyker", 125, 95, 255),
            color_widget("class_color_ogryn", 245, 165, 65),
            color_widget("class_color_adamant", 230, 75, 160),
            color_widget("class_color_broker", 70, 235, 115),
            color_widget("class_color_cryptic", 75, 210, 255),
        }),
    }),
    group("dio_sub_states", {
        color_widget("state_color_out", 255, 80, 65),
        color_widget("state_color_disabled", 25, 25, 25),
        color_widget("state_color_distance", 210, 245, 255),
    }),
    group("dio_sub_platforms", {
        color_widget("platform_color_steam", 210, 210, 210),
        color_widget("platform_color_xbox", 80, 220, 80),
        color_widget("platform_color_psn", 80, 160, 255),
        color_widget("platform_color_unknown", 190, 190, 190),
    }),
    group("dio_sub_health", {
        with_preset(dropdown("health_color_preset", "green", {
            { text = tr("color_green"), value = "green" },
            { text = tr("color_blue"), value = "blue" },
            { text = tr("color_gold"), value = "gold" },
            { text = tr("color_red"), value = "red" },
            { text = tr("color_white"), value = "white" },
            { text = tr("color_custom"), value = "custom" },
        }), {
            color_widget("health_color", 95, 235, 110, 255),
        }, "custom"),
    }),
}))

-- General --------------------------------------------------------------------
add(group("dio_group_general", list(
    dropdown("language", "en", {
        { text = tr("language_en"), value = "en" },
        { text = tr("language_pt_br"), value = "pt-br" },
        { text = tr("language_es"), value = "es" },
    }),
    checkbox("disable_in_mourningstar", false),
    checkbox("coherence_messages_enabled", true),
    D("reset_talent_ui_settings")
)))

--[[
    Anything from TalentUI this file did not place, kept rather than dropped.

    Hand-listing setting_ids means a setting added upstream would otherwise
    vanish with no error - it would simply never appear, and the only symptom
    would be the user not finding a control they expect. This catches it in
    upstream's own order.
--]]
do
    local leftovers = {}

    for i = 1, #_dht_order do
        local id = _dht_order[i]

        if not _dht_used[id] then
            leftovers[#leftovers + 1] = D(id)
        end
    end

    add(group_if("dio_group_more", leftovers))
end

--[[
    ONE BAD WIDGET MUST NOT TAKE DOWN THE MOD.

    dmf_mod_manager.lua:181-187 wraps options initialisation in a pcall and
    RETURNS on failure:

        local success, error_message = pcall(dmf.initialize_mod_options, ...)
        if not success then
            mod:error(ERRORS.REGULAR.mod_options_initializing_failed, ...)
            return
        end

    That early return abandons the rest of new_mod, so the mod does not finish
    registering. It does not appear in the settings menu, and it does not
    appear in the mods toggle list either - it is simply absent, with one line
    in the log as the only clue. This mod has now hit that twice: once on a
    TalentUI group that lacked a title, and once on a DMF build with no
    support for the colour widget.

    So the tree is validated HERE against DMF's own rules (options.lua:63-90
    and the per-type validators below it) and anything that would be rejected
    is dropped, with a line naming it. Losing one setting is recoverable.
    Losing the whole mod, silently, is not.

    This is a safety net, not a licence to be sloppy - a dropped widget still
    means something is wrong and the log still says so.
--]]
local VALID_TYPES = {
    checkbox = true, dropdown = true, numeric = true, group = true,
    button = true, keybind = true, color = true, text_input = true,
    header = true, slider = true, function_call = true,
}

local function widget_is_valid(w, localize, seen, path)
    if type(w) ~= "table" then
        return false, "not a table"
    end

    if type(w.setting_id) ~= "string" then
        return false, "missing setting_id"
    end

    if not VALID_TYPES[w.type] then
        return false, "unknown type '" .. tostring(w.type) .. "'"
    end

    -- The exact test DMF makes: a widget inherits localize from the options
    -- table unless it sets its own, and without localization it needs a title.
    local localized = w.localize
    if localized == nil then localized = localize end

    if not localized and type(w.title) ~= "string" then
        return false, "no title and localization is off"
    end

    if w.title ~= nil and type(w.title) ~= "string" then
        return false, "title is not a string"
    end

    if w.tooltip ~= nil and type(w.tooltip) ~= "string" then
        return false, "tooltip is not a string"
    end

    if seen[w.setting_id] then
        return false, "duplicate setting_id"
    end

    if w.type == "group" and (type(w.sub_widgets) ~= "table" or #w.sub_widgets == 0) then
        return false, "group with no sub_widgets"
    end

    if w.type == "checkbox" and type(w.default_value) ~= "boolean" then
        return false, "checkbox default_value is not a boolean"
    end

    if w.type == "dropdown" then
        if type(w.options) ~= "table" or #w.options < 2 then
            return false, "dropdown needs at least 2 options"
        end
    end

    return true
end

local function prune(list, localize, seen, dropped)
    local out = {}

    for i = 1, #list do
        local w = list[i]

        -- Depth first: a group is only judged once its children are settled,
        -- because pruning children can empty it and empty groups are rejected.
        if type(w) == "table" and type(w.sub_widgets) == "table" then
            local child_localize = w.localize
            if child_localize == nil then child_localize = localize end
            w.sub_widgets = prune(w.sub_widgets, child_localize, seen, dropped)
        end

        local ok, why = widget_is_valid(w, localize, seen, nil)

        if ok then
            seen[w.setting_id] = true
            out[#out + 1] = w
        else
            dropped[#dropped + 1] = string.format("%s (%s)",
                (type(w) == "table" and tostring(w.setting_id)) or "?", why)
        end
    end

    return out
end

local _dropped = {}
_widgets = prune(_widgets, false, {}, _dropped)

if #_dropped > 0 and mod and mod.error then
    pcall(mod.error, mod,
        "[Dio] %d settings were dropped so the mod could still load: %s",
        #_dropped, table.concat(_dropped, ", "))
end

local _mod_data = {
    name = tr("mod_name"),
    description = tr("mod_description"),
    is_togglable = true,
    options = {
        localize = false,
        widgets = _widgets,
    },
}

return _mod_data
