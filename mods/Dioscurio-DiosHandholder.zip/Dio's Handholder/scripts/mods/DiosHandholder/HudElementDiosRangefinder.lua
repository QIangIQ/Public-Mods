local mod = get_mod("DiosHandholder")

local UIWorkspaceSettings = require("scripts/settings/ui/ui_workspace_settings")
local UIWidget = require("scripts/managers/ui/ui_widget")

--[[
    RANGEFINDER READOUT.

    A single line under the crosshair: what is under it, and how far away.

    A SEPARATE ELEMENT rather than another row on the squad bar. The squad bar
    lives at the bottom of the screen and is read between fights; this is read
    WHILE aiming and has to sit where the eye already is. Bolting it onto an
    element with a fixed four-slot layout would also have meant reworking that
    layout for a feature that has nothing to do with it.

    Offset BELOW the crosshair, not above: the top half of the reticle area is
    where hit markers and the enemy health bar appear, and overlapping either
    of those would trade one readable thing for another.
--]]

local WIDTH = 220
local HEIGHT = 20
local BELOW_CROSSHAIR = 34

--[[
    font_type is a SHORT NAME, not a content path.

    I first wrote "content/ui/fonts/proxima_nova_bold" here, which is how
    materials and icons are addressed and is not how fonts are. The engine
    resolves font_type through its own font table - every vanilla element and
    both of this mod's existing elements pass a bare name like
    "machine_medium" or "proxima_nova_medium". A path silently fails to
    resolve, so the mistake would have shown up as invisible text rather than
    an error.
--]]
local FONT = "proxima_nova_medium"

local COLOR_HOSTILE = { 255, 255, 190, 80 }
local COLOR_NEUTRAL = { 205, 225, 225, 225 }
local COLOR_ALLY    = { 230, 120, 235, 140 }

local definitions = {
    scenegraph_definition = {
        screen = UIWorkspaceSettings.screen,

        dio_rangefinder_root = {
            parent = "screen",
            vertical_alignment = "center",
            horizontal_alignment = "center",
            size = { WIDTH, HEIGHT },
            position = { 0, BELOW_CROSSHAIR, 4 },
        },
    },

    widget_definitions = {
        rangefinder = UIWidget.create_definition({
            {
                pass_type = "text",
                style_id = "text",
                value_id = "text",
                value = "",
                style = {
                    font_type = FONT,
                    font_size = 14,
                    text_horizontal_alignment = "center",
                    text_vertical_alignment = "center",
                    text_color = COLOR_NEUTRAL,
                    --[[
                        An outline, because this draws over the world rather
                        than over a panel. Pale text on a pale wall is not a
                        readout, and at 640x360 there is no room for a
                        background plate that would not itself be in the way.
                    --]]
                    drop_shadow = true,
                    offset = { 0, 0, 5 },
                    size = { WIDTH, HEIGHT },
                },
            },
        }, "dio_rangefinder_root"),
    },
}

HudElementDiosRangefinder = class("HudElementDiosRangefinder", "HudElementBase")

HudElementDiosRangefinder.init = function(self, parent, draw_layer, start_scale)
    HudElementDiosRangefinder.super.init(self, parent, draw_layer, start_scale, definitions)
end

local function get_bool(id, fallback)
    if not mod.get then
        return fallback
    end
    local ok, v = pcall(mod.get, mod, id)
    if not ok or v == nil then
        return fallback
    end
    return v and true or false
end

HudElementDiosRangefinder.update = function(self, dt, t, ui_renderer, render_settings, input_service)
    HudElementDiosRangefinder.super.update(self, dt, t, ui_renderer, render_settings, input_service)

    local widget = self._widgets_by_name and self._widgets_by_name.rangefinder
    if not widget then
        return
    end

    if not get_bool("dio_rangefinder", false) then
        widget.visible = false
        return
    end

    local R = mod.__dio_rangefinder
    if not R or not R.read then
        widget.visible = false
        return
    end

    local ok, metres, label, hostile = pcall(R.read)

    if not ok or type(metres) ~= "number" then
        widget.visible = false
        return
    end

    --[[
        Name only when the ray hit something with a name. Aiming at a wall
        reports the distance alone rather than inventing a target - the metres
        are still useful for judging a gap or a drop.
    --]]
    local show_names = get_bool("dio_rangefinder_names", true)

    if label and show_names then
        widget.content.text = string.format("%s  %.0fm", label, metres)
    else
        widget.content.text = string.format("%.0fm", metres)
    end

    local color = COLOR_NEUTRAL
    if label and show_names then
        color = hostile and COLOR_HOSTILE or COLOR_ALLY
    end

    local style = widget.style and widget.style.text
    if style and style.text_color then
        style.text_color[1] = color[1]
        style.text_color[2] = color[2]
        style.text_color[3] = color[3]
        style.text_color[4] = color[4]
    end

    widget.visible = true
end

return HudElementDiosRangefinder
