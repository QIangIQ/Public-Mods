local mod = get_mod("DiosHandholder")

local Tags = mod:io_dofile("Dio's Handholder/scripts/mods/DiosHandholder/DiosHandholder_tags")
local Bleedout = mod:io_dofile("Dio's Handholder/scripts/mods/DiosHandholder/DiosHandholder_bleedout")

--[[
    Downed teammates show their ABILITY instead of their name.

    "Res the zealot" is ambiguous with two zealots on the team. "Res BOOK" is
    not. And at the moment someone is on the floor their name carries no
    information you can act on - you already know who they are from the class
    colour - whereas which ability is about to be unavailable changes whether
    you push or fall back.

    So while a player is knocked down, hogtied, netted, ledge-hanging, grabbed
    or pounced, their nameplate reads BOOK / BUBBLE / TAUNT / VOC in their class
    colour, and reverts to the normal name the instant they are back up.

    HOW

    The nameplate is a world-marker template. Its update_function runs per
    nameplate per frame, and the header is a single string on
    widget.content.header_text using the game's inline colour markup:

        {#color(r,g,b)}TEXT{#reset()}

    Wrapping update_function rather than replacing the template means the
    vanilla behaviour - clamping, line of sight fade, distance scaling - is
    untouched; only the header string is overwritten, and only while downed.
--]]

local N = {}

local NAMEPLATE_PATH =
    "scripts/ui/hud/elements/world_markers/templates/world_marker_template_nameplate_combat"

--[[
    Restores are keyed on the MARKER, not the player.

    A marker is created per nameplate and destroyed with it, so anything stored
    here dies with the thing it describes. Storing the original text on the
    player would outlive the widget and could restore a string into a nameplate
    that has since been rebuilt for someone else.
--]]
local function restore(widget, marker)
    local saved = marker.__dio_saved_header
    if saved ~= nil then
        widget.content.header_text = saved
        marker.__dio_saved_header = nil
    end
end

local function apply(widget, marker)
    if mod:get("dio_downed_ability_names") == false then
        restore(widget, marker)
        return
    end

    local player = marker and marker.data
    local content = widget and widget.content
    if not player or not content then
        return
    end

    if not Tags.is_downed(player) then
        restore(widget, marker)
        return
    end

    -- Feed the bleedout sampler from here: it only needs to run while a downed
    -- teammate is actually on screen, which is exactly when this fires.
    Bleedout.sample(player)

    local tag = Tags.ability_tag_of(player)

    --[[
        SECONDS when they are bleeding out, the CAUSE when they are not.

        The old version showed a pool percentage for every "needs help" state,
        which was wrong twice over: a netted or pounced teammate has no
        bleedout pool, so the figure was their ordinary health dressed up as a
        countdown, and a percentage does not tell you what to do about it
        anyway.

        Now: knocked down reads "BOOK 23s", and netted reads "BOOK NET" -
        which says shoot the net. Bleedout.label returns nil for anything that
        is not knocked down, so the disabled label is what fills the gap.
    --]]
    local show_bleed = mod:get("dio_show_bleedout") ~= false
    local suffix, secs

    if show_bleed then
        suffix, secs = Bleedout.label(player)
    end

    if not suffix then
        suffix = Tags.disabled_label(player)
    end

    if not tag and not suffix then
        -- Nothing to add: leave the name alone rather than blanking it. An
        -- unlabelled downed teammate is still better than an unnamed one.
        restore(widget, marker)
        return
    end

    -- Save the real header once, on the first frame of being downed.
    if marker.__dio_saved_header == nil then
        marker.__dio_saved_header = content.header_text or ""
    end

    local rgb = Tags.class_color(player)

    --[[
        Countdown colour is separate from the class colour on purpose.

        The class colour answers "who", and must stay stable or it stops
        identifying anyone. Urgency is a different axis, so it goes on the
        number: white with time to spare, amber when it is getting tight, red
        when you are about to lose them.
    --]]
    local text = string.format("{#color(%d,%d,%d)}%s{#reset()}",
        rgb[1], rgb[2], rgb[3], tag or "DOWN")

    if suffix then
        --[[
            Urgency is driven by SECONDS where seconds are known. "Ten seconds
            left" means the same thing on any pool size; "25% left" does not -
            a quarter of a big pool at a short distance is far more time than a
            quarter of the same pool across the room.

            A disabled label that is not a countdown gets the amber, because it
            is a call to act but not a clock running out.
        --]]
        local cr, cg, cb
        if secs then
            cr, cg, cb = Bleedout.urgency_rgb(player, secs)
        elseif string.find(suffix, "%%") then
            cr, cg, cb = Bleedout.urgency_rgb(player, nil)
        else
            cr, cg, cb = 255, 190, 80
        end

        text = text .. string.format("  {#color(%d,%d,%d)}%s{#reset()}",
            cr, cg, cb, suffix)
    end

    content.header_text = text
end

-- ---------------------------------------------------------------------------
-- The assistance marker
-- ---------------------------------------------------------------------------

--[[
    THE BIG OVERHEAD MARKER, not just the nameplate.

    player_assistance is the pulsing icon that appears over a teammate who
    needs picking up. It is added by hud_element_player_panel_base for
    `disabled and not hogtied and not consumed`, so it covers knocked down,
    netted, pounced, ledge-hanging and warp-grabbed - and crucially it is the
    thing you actually look at in that moment. The nameplate is small, is
    behind it, and fades with line of sight; this does not.

    So the tag and the countdown belong here too. Vanilla writes only the
    distance into content.text; this appends to whatever it wrote rather than
    replacing it, because the distance is why the marker is readable at range
    in the first place.

    marker.data is { player = player } here, NOT the player directly - which
    is the difference from the nameplate template and is worth stating,
    because passing marker.data straight through would silently produce
    nothing and look like the feature simply not working.
--]]
local ASSISTANCE_PATH =
    "scripts/ui/hud/elements/world_markers/templates/world_marker_template_player_assistance"

local function apply_assistance(widget, marker)
    if mod:get("dio_downed_ability_names") == false then
        return
    end

    local data = marker and marker.data
    local player = data and data.player
    local content = widget and widget.content

    if not player or not content then
        return
    end

    local tag = Tags.ability_tag_of(player)

    local suffix, secs
    if mod:get("dio_show_bleedout") ~= false then
        Bleedout.sample(player)
        suffix, secs = Bleedout.label(player)
    end

    if not suffix then
        suffix = Tags.disabled_label(player)
    end

    if not tag and not suffix then
        return
    end

    --[[
        Built onto the CURRENT text, which vanilla has just set to the
        distance. Read fresh each frame rather than saved and restored: this
        template rewrites content.text unconditionally every update, so there
        is nothing of ours to clobber and nothing to put back.
    --]]
    local base = content.text
    if type(base) ~= "string" then
        base = ""
    end

    local rgb = Tags.class_color(player)
    local parts = base ~= "" and { base } or {}

    if tag then
        parts[#parts + 1] = string.format("{#color(%d,%d,%d)}%s{#reset()}",
            rgb[1], rgb[2], rgb[3], tag)
    end

    if suffix then
        local cr, cg, cb
        if secs then
            cr, cg, cb = Bleedout.urgency_rgb(player, secs)
        elseif string.find(suffix, "%%") then
            cr, cg, cb = Bleedout.urgency_rgb(player, nil)
        else
            cr, cg, cb = 255, 190, 80
        end
        parts[#parts + 1] = string.format("{#color(%d,%d,%d)}%s{#reset()}",
            cr, cg, cb, suffix)
    end

    content.text = table.concat(parts, "  ")
end

mod:hook_require(ASSISTANCE_PATH, function(instance)
    if not instance or instance.__dio_wrapped then
        return
    end
    instance.__dio_wrapped = true

    local original = instance.update_function

    instance.update_function = function(parent, ui_renderer, widget, marker, template, dt, t)
        local result
        if original then
            result = original(parent, ui_renderer, widget, marker, template, dt, t)
        end

        pcall(apply_assistance, widget, marker)

        return result
    end
end)

--[[
    hook_require fires when the template file is loaded, before any nameplate
    exists, so the wrapper is in place from the first one built.
--]]
mod:hook_require(NAMEPLATE_PATH, function(instance)
    if not instance or instance.__dio_wrapped then
        return
    end
    instance.__dio_wrapped = true

    local original = instance.update_function

    instance.update_function = function(parent, ui_renderer, widget, marker, template, dt, t)
        local result
        if original then
            result = original(parent, ui_renderer, widget, marker, template, dt, t)
        end

        --[[
            pcall'd and applied AFTER the original.

            After, because the vanilla function may rewrite header_text itself
            and would otherwise clobber the override. pcall'd because this runs
            inside the game's world-marker update - a throw here propagates
            into the HUD, and a mislabelled nameplate is a far smaller problem
            than a dead marker system.
        --]]
        pcall(apply, widget, marker)

        return result
    end
end)

return N
