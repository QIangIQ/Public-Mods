local mod = get_mod("DiosHandholder")

local UIWidget = require("scripts/managers/ui/ui_widget")
local UIWorkspaceSettings = require("scripts/settings/ui/ui_workspace_settings")

--[[
    ========================================================================
    FULL-SCREEN JUMPSCARE OVERLAY
    ========================================================================

    Two passes, both filling the screen:

        flash   a plain rect. Always works, needs nothing loaded, and is the
                whole effect when SimpleAssets is absent or the textures have
                not arrived yet.
        image   the Foxy frame, bound through material_values.

    THE MATERIAL IS ui_default_base AND THAT CHOICE MATTERS.

    content/ui/materials/base/ui_default_base is the engine's stock texture
    material; its settable slot is texture_map, and ui_passes routes a
    userdata material value through Material.set_resource - so a texture
    object with no resource name binds there exactly like the resource-name
    strings the game's own views assign.

    The obvious alternative, the news view's article_image_blank, is a banner
    material with a built-in horizontal edge fade baked into its material
    values. An image drawn through it comes out smeared and with the alpha
    channel gone. That is CustomCrosshairs' finding (crosshair_template.lua
    :16-26) and it saved a long afternoon.

    material_values MUST EXIST AT DEFINITION TIME. ui_passes only builds a
    per-pass gui material - and so only honours material_values at all - when
    the style already carries that table. An empty table is fine; a nil one
    means the texture silently never binds.
--]]

local IMAGE_MATERIAL = "content/ui/materials/base/ui_default_base"
local IMAGE_SLOT = "texture_map"

--[[
    1920x1080 is the workspace reference, not the monitor. The scenegraph
    "fit" scaling maps it to whatever the real resolution is, so sizes here
    are resolution-independent without this file knowing the resolution.

    FULLSCREEN, AND NOT RESIZABLE. This was tried and reverted, so the reason
    is written down.

    In UIScenegraph.update_scenegraph, the scale = "fit" branch forces the
    node to full screen and NEVER CALLS _handle_alignment - only the
    aspect_ratio, fit_width and fit_height branches align. So the
    horizontal_alignment and vertical_alignment set on the node below do
    nothing at all: it sits at the safe-rect origin, which is the top-left.

    This element was therefore never centred by alignment. A 1920x1080 image
    drawn from the top-left simply fills the screen, which is
    indistinguishable from centred. A build that shrank it to 640x360 put it
    in the bottom right - not a centred thing knocked off-centre, but the
    corner anchor finally becoming visible.

    Making it smaller needs scale = "aspect_ratio", which does align. Not
    worth it for something that is supposed to fill the screen.
--]]
local W, H = 1920, 1080

--[[
    THE CLASS NAME MUST MATCH THE REGISTERED class_name, AND IT DID NOT.

    This is what killed the animation. UIHud uses the name twice, from two
    different places:

      _add_element              elements[definition.class_name] = element
      _update_element_visibility local n = element.__class_name
                                 status = visible_elements[n] or false

    visible_elements is built from the REGISTRATION's class_name (ui_hud.lua
    :200), but the visibility lookup asks the ELEMENT for its own name, and
    that comes from the string passed to class() here. Registering as
    "Crosshair" while the class was still "HudElementDiosJumpscare" meant the
    visibility group knew about a Crosshair it could never find, the element
    reported a name nothing had registered, and status came back false on
    every frame.

    The element was constructed, ticked, and permanently invisible - which is
    exactly why the frames still loaded and the sound still played. Both of
    those run from mod.update, not from this file.

    The local is left with its descriptive name; only the class STRING has to
    match. class() also publishes a global under that string, and nothing in
    the game or in the installed mods defines a global "Crosshair", so there
    is nothing to collide with.
--]]
local HudElementDiosJumpscare = class("Crosshair", "HudElementBase")

local scenegraph_definition = {
    screen = UIWorkspaceSettings.screen,
    --[[
        A ROOT, NOT A CHILD OF "screen", so HUD editors do not offer it.

        custom_hud lists every child of a scenegraph root as a draggable box,
        and the borrowed "Crosshair" name does not keep it out of custom_hud's
        list (that only skips HudElementCrosshair). A root with the same
        values as UIWorkspaceSettings.screen renders the same full-screen
        canvas and has no children to offer.
    --]]
    fullscreen = {
        scale = "fit",
        vertical_alignment = "center",
        horizontal_alignment = "center",
        size = { W, H },
        --[[
            z of 900. High enough to sit over the rest of the HUD, which is
            the point of a jumpscare, and below nothing that matters because
            it is only up for a second.
        --]]
        position = { 0, 0, 900 },
    },
}

local widget_definitions = {
    jumpscare = UIWidget.create_definition({
        {
            pass_type = "rect",
            style_id = "flash",
            style = {
                color = { 0, 0, 0, 0 },
                size = { W, H },
                offset = { 0, 0, 0 },
                horizontal_alignment = "center",
                vertical_alignment = "center",
            },
        },
        {
            pass_type = "texture",
            style_id = "image",
            value = IMAGE_MATERIAL,
            style = {
                color = { 0, 255, 255, 255 },
                size = { W, H },
                offset = { 0, 0, 1 },
                horizontal_alignment = "center",
                vertical_alignment = "center",
                material_values = {},
            },
        },
    }, "fullscreen"),
}

HudElementDiosJumpscare.init = function(self, parent, draw_layer, start_scale)
    HudElementDiosJumpscare.super.init(self, parent, draw_layer, start_scale, {
        scenegraph_definition = scenegraph_definition,
        widget_definitions = widget_definitions,
    })

    self._was_active = false
end

HudElementDiosJumpscare.update = function(self, dt, t, ui_renderer, render_settings, input_service)
    HudElementDiosJumpscare.super.update(self, dt, t, ui_renderer, render_settings, input_service)

    --[[
        NO POSITION RE-ASSERTION HERE, and removing it was a fix rather than
        a simplification.

        An earlier build called set_scenegraph_position every frame to stop
        HUD editors moving this element. It could not have worked: "fit" nodes
        never reach the alignment code, so there was nothing for the write to
        influence. What it did do was set _update_scenegraph every frame,
        forcing a full scenegraph rebuild sixty times a second for a nil
        effect.

        A fullscreen node cannot meaningfully be dragged anyway - it is
        already the whole screen.
    --]]
    local widget = self._widgets_by_name and self._widgets_by_name.jumpscare

    if not widget then
        return
    end

    local Jump = mod.__dio_jumpscare
    local on = Jump and Jump.active()

    --[[
        widget.visible rather than zeroing the alphas. It is the flag the
        renderer itself checks, so one assignment covers both passes - and a
        rect left at alpha 0 is still a full-screen draw every frame for
        something nobody can see.
    --]]
    if not on then
        if self._was_active then
            self._was_active = false
            widget.visible = false
        end

        return
    end

    if not self._was_active then
        self._was_active = true
        widget.visible = true
    end

    local style = widget.style

    --[[
        Rebound EVERY FRAME, not once. The textures arrive asynchronously, so
        the widget reliably exists before its image does, and a mod reload
        replaces the frame table underneath a live widget.

        A nil here is the normal state while frames are still loading, and it
        is handled by leaving the image transparent rather than by skipping
        the draw - the flash still fires, so the scare lands even on the very
        first trigger of a session.
    --]]
    local tex = Jump.frame(Jump.current_frame())

    if style.image and style.image.material_values then
        style.image.material_values[IMAGE_SLOT] = tex
        style.image.color[1] = tex and 255 or 0
    end

    --[[
        The flash fades out across the animation, so it reads as an impact
        rather than a black box sitting on screen. Full opacity when there is
        no texture to show, so the feature still does something without
        SimpleAssets.
    --]]
    if style.flash then
        local peak = tex and 120 or 255
        local frac = 1 - ((Jump.current_frame() - 1) / 14)

        style.flash.color[1] = math.floor(peak * frac)
    end
end

return HudElementDiosJumpscare
