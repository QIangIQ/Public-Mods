local mod = get_mod("DiosHandholder")

--[[
    AUDIBLE DISABLERS
    =================

    Makes hounds vocalise continuously while moving, the same way
    CacklingTrapper does for trappers.

    CREDIT: the idea and the mechanism are Seph's (Steam: Concoction of
    Constitution), from the CacklingTrapper mod. It is three lines and it is
    clever:

        mod:hook_require(".../renegade_netgunner_sounds", function(sound_data)
            sound_data.events.footstep = ".../play_traitor_guard_netgunner_laugh_vce"
        end)

    Replacing the FOOTSTEP event rather than adding a new sound is the whole
    trick. Footsteps already fire from the animation on every step, at the
    unit's position, with the game's own falloff and occlusion - so swapping
    the event gives a continuous, correctly-positioned vocalisation for free.
    No update loop, no proximity checks, no sound handles to clean up.

    Every hound sound table sets use_proximity_culling.footstep = false, so the
    swapped event is not distance-culled either. That is the property that
    makes this useful at all: a hound you cannot see is a hound you can hear.

    ------------------------------------------------------------------------
    WHY THE EVENT IS READ FROM THE TABLE INSTEAD OF HARDCODED

    There are three hound breeds and they do NOT share event names:

        chaos_hound            play_enemy_chaos_hound_vce_bark
        chaos_armored_hound    play_chaos_hound_armoured_vce_bark
        chaos_hound_mutator    play_chaos_hound_mutator_vce_bark

    Hardcoding one string would have silently mis-sounded two of the three, so
    the swap reads the breed's OWN sfx_bark / sfx_growl / sfx_breath out of the
    table it was handed. That also survives a patch renaming the events, and
    degrades to "no change" rather than "broken audio" if one is removed.

    ------------------------------------------------------------------------
    WHY THERE IS NO VOLUME SLIDER

    Asked for, and not possible through this mechanism. The footstep event is
    fired by the ANIMATION system, not from Lua - "footstep" appears nowhere in
    the engine's Lua outside the breed sound tables themselves. There is no
    call to intercept, so there is nothing to attach a volume or a frequency
    to.

    Shipping a slider that silently does nothing would be worse than not having
    one, so instead the setting chooses WHICH vocalisation plays. They differ
    in intensity, which is the practical part of what a volume control was for:

        bark    loudest, most obvious
        growl   lower and less piercing
        breath  quietest, closest to a hint

    ------------------------------------------------------------------------
    A RELOAD IS REQUIRED to change this.

    hook_require fires once, when the game first loads that breed's sound
    table. Changing the setting mid-session cannot reach a table that has
    already been read. The setting is applied at load, so it takes effect on
    the next mod reload - stated in the tooltip rather than left to be
    discovered.
--]]

local HOUND_SOUNDS = {
    "scripts/settings/breed/breeds/chaos/chaos_hound_sounds",
    "scripts/settings/breed/breeds/chaos/chaos_armored_hound_sounds",
    "scripts/settings/breed/breeds/chaos/chaos_hound_mutator_sounds",
}

local VOCALISATIONS = {
    bark   = "sfx_bark",
    growl  = "sfx_growl",
    breath = "sfx_breath",
}

--[[
    Read at hook time, because hook_require fires during load and a later read
    would be asking a question whose answer can no longer be used.

    DMFMod:get returns nil for a setting never written, so "bark" is spelled
    out here as the real default rather than left to a coincidence. It must
    match the widget's default_value in the data file.
--]]
local function chosen_setting()
    local ok, choice = pcall(mod.get, mod, "dio_hound_vocal")

    if not ok or type(choice) ~= "string" then
        return "bark"
    end

    return choice
end

--[[
    "spam" is not a vocalisation, it is a delivery mode - so it maps to bark
    for the footstep swap and separately turns the timer below on. Without
    this it would fall through VOCALISATIONS, return nil, and silently disable
    the footstep swap it was meant to add to.
--]]
local function chosen_key()
    local choice = chosen_setting()

    if choice == "off" then
        return nil
    end

    if choice == "spam" then
        return VOCALISATIONS.bark
    end

    return VOCALISATIONS[choice]
end

local function swap_footstep(sound_data)
    local key = chosen_key()

    if not key then
        return
    end

    --[[
        Guarded rather than assigned blind: a future patch that restructures
        this table should leave the hound sounding vanilla, not throw during
        load. A mod that breaks a breed's sound table breaks the breed.
    --]]
    if type(sound_data) ~= "table" or type(sound_data.events) ~= "table" then
        return
    end

    local event = sound_data.events[key]

    if type(event) ~= "string" then
        return
    end

    sound_data.events.footstep = event

    --[[
        The vanilla table already sets this false for every hound event, but it
        is asserted rather than assumed - the whole point of the feature is
        that the sound carries past line of sight.
    --]]
    if type(sound_data.use_proximity_culling) == "table" then
        sound_data.use_proximity_culling.footstep = false
    end
end

for i = 1, #HOUND_SOUNDS do
    mod:hook_require(HOUND_SOUNDS[i], swap_footstep)
end

--[[
    ========================================================================
    SPAM MODE - a bark every 0.2 seconds, regardless of what the hound does
    ========================================================================

    The footstep swap above cannot do this. It rides the animation, so a hound
    that is standing still is silent and one that is sprinting barks at its
    stride rate - which is the behaviour, not a setting. Asking for "every
    0.2s" means driving the sound from a clock instead.

    So this plays the bark directly, on a timer, at each hound's own position:

        Wwise.wwise_world(world)                 the audio world
        WwiseWorld.make_auto_source(ww, pos)     a source at that point
        WwiseWorld.trigger_resource_event(...)   fire the event

    make_auto_source rather than make_manual_source: an auto source is
    positional and fire-and-forget, so there is no handle to track and nothing
    to clean up when the hound dies mid-bark. A manual source bound to a unit
    node would need releasing, and releasing one attached to a freed unit is
    a crash rather than an error.

    RANGE-GATED so this is annoying rather than unusable. A bark every 0.2s
    from every hound on the level, through walls, at any distance, is not a
    feature anyone can play with - the audio engine will also start dropping
    voices and the ones that matter are the ones it drops.
--]]
local SPAM_INTERVAL = 0.2
local SPAM_RANGE = 45

local spam_next_t = 0

local function spam_tick()
    if chosen_setting() ~= "spam" then
        return
    end

    local t = mod._now_sounds or 0

    if t < spam_next_t then
        return
    end
    spam_next_t = t + SPAM_INTERVAL

    local tracers = mod.__dio_tracers

    if not tracers or not tracers.hounds_in_range then
        return
    end

    local Wwise = rawget(_G, "Wwise")
    local WwiseWorld = rawget(_G, "WwiseWorld")
    local wm = Managers.world

    if not Wwise or not WwiseWorld or not wm or not wm.has_world
        or not wm:has_world("level_world") then
        return
    end

    local ok_w, world = pcall(wm.world, wm, "level_world")

    if not ok_w or not world then
        return
    end

    local ok_ww, wwise_world = pcall(Wwise.wwise_world, world)

    if not ok_ww or not wwise_world then
        return
    end

    local hounds = tracers.hounds_in_range(SPAM_RANGE)

    for i = 1, #hounds do
        local pos = hounds[i]

        pcall(function()
            local source = WwiseWorld.make_auto_source(wwise_world, pos)

            WwiseWorld.trigger_resource_event(wwise_world,
                "wwise/events/minions/play_enemy_chaos_hound_vce_bark", source)
        end)
    end
end

--[[
    Driven from the mod's own per-frame hook rather than a hook of its own, so
    there is one place that decides how often anything in this mod runs.
--]]
mod.sounds_update = function(dt)
    mod._now_sounds = (mod._now_sounds or 0) + (dt or 0)
    pcall(spam_tick)
end

return true
