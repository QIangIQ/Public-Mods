local mod = get_mod("DiosHandholder")

local UIWorkspaceSettings = require("scripts/settings/ui/ui_workspace_settings")
local UIWidget = require("scripts/managers/ui/ui_widget")

local SLOT_SIZE = { 54, 54 }
local ICON_SIZE = { 42, 42 }
local SLOT_SPACING = 8
local SELF_GROUP_SPACING = 20
local BORDER_SIZE = 2
local TOTAL_HEIGHT = 90
local MAX_SLOTS = 4

local TOTAL_WIDTH = (SLOT_SIZE[1] * MAX_SLOTS) + (SLOT_SPACING * (MAX_SLOTS - 1)) + SELF_GROUP_SPACING
local DEFAULT_ICON = "content/ui/materials/icons/classes/large/veteran"
local DEFAULT_ICON_TEXT = "\238\128\133"

local COLORS = {
    background = { 95, 0, 0, 0 },
    background_active = { 140, 0, 0, 0 },

    absent_icon = { 42, 255, 255, 255 },
    absent_border = { 145, 0, 0, 0 },
    absent_label = { 55, 255, 255, 255 },
    absent_distance = { 65, 255, 255, 255 },

    self_icon = { 255, 255, 255, 255 },
    self_border = { 170, 255, 255, 255 },
    self_label = { 220, 255, 255, 255 },
    self_distance = { 230, 255, 255, 255 },

    self_out_icon = { 255, 255, 45, 35 },
    self_out_border = { 255, 255, 25, 20 },
    self_out_label = { 255, 255, 80, 65 },
    self_out_distance = { 255, 255, 90, 70 },

    other_coherent_icon = { 255, 255, 215, 55 },
    other_coherent_border = { 255, 255, 215, 55 },
    other_coherent_label = { 255, 255, 230, 120 },
    other_coherent_distance = { 255, 255, 235, 130 },

    other_out_icon = { 255, 255, 45, 35 },
    other_out_border = { 255, 255, 25, 20 },
    other_out_label = { 255, 255, 80, 65 },
    other_out_distance = { 255, 255, 90, 70 },

    dead_icon = { 255, 140, 85, 45 },
    dead_border = { 255, 120, 72, 38 },
    dead_label = { 255, 150, 105, 75 },
    dead_distance = { 255, 150, 105, 75 },
}

local function get_setting(setting_id, fallback)
    if mod.get then
        local ok, value = pcall(mod.get, mod, setting_id)

        if ok and value ~= nil then
            return value
        end
    end

    return fallback
end

local function get_bool_setting(setting_id, fallback)
    if mod.get_bool_setting then
        return mod.get_bool_setting(setting_id, fallback)
    end

    return get_setting(setting_id, fallback) ~= false
end

local function configured_ally_color(alpha_override, class_key)
    if mod.get_class_color then
        return mod.get_class_color(class_key, alpha_override)
    end

    if mod.get_ally_color then
        return mod.get_ally_color(alpha_override)
    end

    return {
        alpha_override or COLORS.other_coherent_icon[1],
        COLORS.other_coherent_icon[2],
        COLORS.other_coherent_icon[3],
        COLORS.other_coherent_icon[4],
    }
end

local function configured_state_color(state_key, fallback)
    if mod.get_state_color then
        local ok, color = pcall(mod.get_state_color, state_key)

        if ok and type(color) == "table" then
            return color
        end
    end

    return fallback
end

local function configured_hud_icon_scale()
    if mod.get_hud_icon_scale then
        local ok, scale = pcall(mod.get_hud_icon_scale)

        if ok and type(scale) == "number" then
            return math.max(0.6, math.min(1.4, scale))
        end
    end

    return 1
end

local definitions = {
    scenegraph_definition = {
        screen = UIWorkspaceSettings.screen,

        dio_handholder_root = {
            parent = "screen",
            vertical_alignment = "bottom",
            horizontal_alignment = "center",
            size = {
                TOTAL_WIDTH,
                TOTAL_HEIGHT,
            },
            position = {
                0,
                -104,
                5,
            },
        },
    },

    widget_definitions = {},
}

for i = 1, MAX_SLOTS do
    local scenegraph_id = "slot_" .. i .. "_area"
    local widget_id = "slot_" .. i

    definitions.scenegraph_definition[scenegraph_id] = {
        parent = "dio_handholder_root",
        vertical_alignment = "center",
        horizontal_alignment = "left",
        size = SLOT_SIZE,
        position = {
            0,
            4,
            12,
        },
    }

    definitions.widget_definitions[widget_id] = UIWidget.create_definition({
        {
            pass_type = "rect",
            style_id = "background",
            style = {
                color = COLORS.background,
                offset = {
                    0,
                    0,
                    1,
                },
            },
        },

        {
            pass_type = "rect",
            style_id = "border_top",
            style = {
                color = COLORS.absent_border,
                size = {
                    SLOT_SIZE[1],
                    BORDER_SIZE,
                },
                offset = {
                    0,
                    0,
                    3,
                },
            },
        },

        {
            pass_type = "rect",
            style_id = "border_bottom",
            style = {
                color = COLORS.absent_border,
                size = {
                    SLOT_SIZE[1],
                    BORDER_SIZE,
                },
                offset = {
                    0,
                    SLOT_SIZE[2] - BORDER_SIZE,
                    3,
                },
            },
        },

        {
            pass_type = "rect",
            style_id = "border_left",
            style = {
                color = COLORS.absent_border,
                size = {
                    BORDER_SIZE,
                    SLOT_SIZE[2],
                },
                offset = {
                    0,
                    0,
                    3,
                },
            },
        },

        {
            pass_type = "rect",
            style_id = "border_right",
            style = {
                color = COLORS.absent_border,
                size = {
                    BORDER_SIZE,
                    SLOT_SIZE[2],
                },
                offset = {
                    SLOT_SIZE[1] - BORDER_SIZE,
                    0,
                    3,
                },
            },
        },

        {
            pass_type = "text",
            value = "",
            value_id = "distance",
            style_id = "distance",
            style = {
                font_type = "proxima_nova_medium",
                font_size = 12,
                text_horizontal_alignment = "center",
                text_vertical_alignment = "center",
                text_color = COLORS.absent_distance,
                size = {
                    SLOT_SIZE[1] + 8,
                    16,
                },
                offset = {
                    -4,
                    -18,
                    8,
                },
            },
        },

        {
            pass_type = "texture",
            value = DEFAULT_ICON,
            value_id = "icon",
            style_id = "icon",
            visibility_function = function(content)
                return get_bool_setting("show_class_icon", true) and content.icon_is_texture == true
            end,
            style = {
                horizontal_alignment = "center",
                vertical_alignment = "center",
                size = ICON_SIZE,
                color = COLORS.absent_icon,
                offset = {
                    0,
                    0,
                    8,
                },
            },
        },

        {
            pass_type = "text",
            value = DEFAULT_ICON_TEXT,
            value_id = "icon_text",
            style_id = "icon_text",
            visibility_function = function(content)
                return get_bool_setting("show_class_icon", true) and content.icon_is_texture ~= true
            end,
            style = {
                font_type = "proxima_nova_medium",
                font_size = 34,
                text_horizontal_alignment = "center",
                text_vertical_alignment = "center",
                text_color = COLORS.absent_icon,
                size = SLOT_SIZE,
                offset = {
                    0,
                    -2,
                    8,
                },
            },
        },

        {
            pass_type = "text",
            value = "",
            value_id = "label",
            style_id = "label",
            style = {
                font_type = "proxima_nova_medium",
                font_size = 11,
                text_horizontal_alignment = "center",
                text_vertical_alignment = "top",
                text_color = COLORS.absent_label,
                size = {
                    SLOT_SIZE[1] + 18,
                    18,
                },
                offset = {
                    -9,
                    SLOT_SIZE[2],
                    8,
                },
            },
        },
    }, scenegraph_id)
end

HudElementDiosExpandedUI = class("HudElementDiosExpandedUI", "HudElementBase")

HudElementDiosExpandedUI.init = function(self, parent, draw_layer, start_scale)
    HudElementDiosExpandedUI.super.init(self, parent, draw_layer, start_scale, definitions)
end

local function apply_visual_state(widget, state, slot_data)
    if not widget or not widget.style then
        return
    end

    widget.visible = true

    local icon_color = COLORS.absent_icon
    local border_color = COLORS.absent_border
    local label_color = COLORS.absent_label
    local distance_color = COLORS.absent_distance
    local background_color = COLORS.background

    if state == "self_coherent" then
        icon_color = COLORS.self_icon
        border_color = COLORS.self_border
        label_color = COLORS.self_label
        distance_color = configured_state_color("distance", COLORS.self_distance)
        background_color = COLORS.background_active

    elseif state == "self_out" then
        icon_color = configured_state_color("out", COLORS.self_out_icon)
        border_color = icon_color
        label_color = icon_color
        distance_color = icon_color
        background_color = COLORS.background_active

    elseif state == "other_coherent" then
        icon_color = configured_ally_color(255, slot_data and slot_data.class_key)
        border_color = configured_ally_color(255, slot_data and slot_data.class_key)
        label_color = configured_ally_color(255, slot_data and slot_data.class_key)
        distance_color = configured_state_color("distance", configured_ally_color(255, slot_data and slot_data.class_key))
        background_color = COLORS.background_active

    elseif state == "other_out" then
        icon_color = configured_state_color("out", COLORS.other_out_icon)
        border_color = icon_color
        label_color = icon_color
        distance_color = icon_color
        background_color = COLORS.background_active

    elseif state == "dead" then
        icon_color = configured_state_color("disabled", COLORS.dead_icon)
        border_color = icon_color
        label_color = icon_color
        distance_color = icon_color
        background_color = COLORS.background_active

    elseif state == "absent" then
        icon_color = COLORS.absent_icon
        border_color = COLORS.absent_border
        label_color = COLORS.absent_label
        distance_color = COLORS.absent_distance
        background_color = COLORS.background
    end

    if widget.style.background then
        widget.style.background.color = background_color
    end

    if widget.style.icon then
        widget.style.icon.color = icon_color
    end

    if widget.style.icon_text then
        widget.style.icon_text.text_color = icon_color
    end

    if widget.style.label then
        widget.style.label.text_color = label_color
    end

    if widget.style.distance then
        widget.style.distance.text_color = distance_color
    end

    if widget.style.border_top then
        widget.style.border_top.color = border_color
    end

    if widget.style.border_bottom then
        widget.style.border_bottom.color = border_color
    end

    if widget.style.border_left then
        widget.style.border_left.color = border_color
    end

    if widget.style.border_right then
        widget.style.border_right.color = border_color
    end
end

local function get_hud_label(slot_data)
    if get_bool_setting("show_ally_name", false) then
        return slot_data.player_name or slot_data.label or ""
    end

    local label_mode = get_setting("hud_label_mode", "class")

    if label_mode == "hidden" then
        return ""
    end

    if label_mode == "name" then
        return slot_data.player_name or slot_data.label or ""
    end

    return slot_data.label or ""
end

local function update_slot_widget(widget, slot_data, visible_index, visible_count)
    if not slot_data then
        if widget then
            widget.visible = false
        end

        return
    end

    if not widget or not widget.content or not widget.offset then
        return
    end

    local content_width = (SLOT_SIZE[1] * visible_count) + (SLOT_SPACING * (visible_count - 1))

    if visible_count > 1 then
        content_width = content_width + SELF_GROUP_SPACING
    end

    local start_x = (TOTAL_WIDTH - content_width) * 0.5
    local group_offset = visible_index > 1 and SELF_GROUP_SPACING or 0

    widget.visible = true
    widget.offset[1] = start_x + ((visible_index - 1) * (SLOT_SIZE[1] + SLOT_SPACING)) + group_offset
    widget.offset[2] = 4
    widget.content.icon = slot_data.icon or DEFAULT_ICON
    widget.content.icon_text = slot_data.icon_text or DEFAULT_ICON_TEXT
    widget.content.icon_is_texture = slot_data.icon_is_texture == true
    widget.content.label = get_hud_label(slot_data)
    widget.content.distance = get_bool_setting("show_distance", true) and get_bool_setting("show_hud_distance", true) and (slot_data.distance_label or "") or ""

    local icon_scale = configured_hud_icon_scale()

    if widget.style.icon and widget.style.icon.size then
        widget.style.icon.size[1] = ICON_SIZE[1] * icon_scale
        widget.style.icon.size[2] = ICON_SIZE[2] * icon_scale
    end

    if widget.style.icon_text then
        widget.style.icon_text.font_size = 34 * icon_scale
    end

    apply_visual_state(widget, slot_data.state or "other_coherent", slot_data)
end

HudElementDiosExpandedUI.update = function(self, dt, t, ui_renderer, render_settings, input_service)
    HudElementDiosExpandedUI.super.update(self, dt, t, ui_renderer, render_settings, input_service)

    if mod.update_local_archetype then
        pcall(mod.update_local_archetype)
    end

    local hud_players = {}

    if mod.update_hud_players then
        local ok, players = pcall(mod.update_hud_players, t)

        if ok and type(players) == "table" then
            hud_players = players
        end
    end

    local visible_count = math.min(#hud_players, MAX_SLOTS)

    if not get_bool_setting("show_hud", true) then
        visible_count = 0
    end

    for i = 1, MAX_SLOTS do
        local widgets_by_name = self._widgets_by_name
        local widget = widgets_by_name and widgets_by_name["slot_" .. i]

        if widget then
            if visible_count > 0 then
                local ok = pcall(update_slot_widget, widget, hud_players[i], i, visible_count)

                if not ok then
                    widget.visible = false
                end
            else
                widget.visible = false
            end
        end
    end
end

return HudElementDiosExpandedUI
