local VERSION = "0.0.7"

local function safe_color_component(value, fallback)
    value = tonumber(value)

    if not value then
        return fallback
    end

    if value < 0 then
        return 0
    end

    if value > 255 then
        return 255
    end

    return math.floor(value + 0.5)
end

local function color(text, r, g, b)
    text = tostring(text or "")
    r = safe_color_component(r, 255)
    g = safe_color_component(g, 255)
    b = safe_color_component(b, 255)

    return string.format("{#color(%d,%d,%d)}%s{#reset()}", r, g, b, text)
end

local function L(en, pt, es)
    return {
        en = en,
        ["pt-br"] = pt or en,
        ["br-pt"] = pt or en,
        es = es or en,
    }
end

local _mod_loc = {
    mod_name = L(color("Dio's", 210, 245, 210) .. " " .. color("Expanded UI", 255, 215, 55)),
    mod_description = L(
        color("v" .. VERSION .. "  |  Author: Dioscurio", 255, 215, 95)
            .. "\n"
            .. color("Compact squad HUD with class, name, distance, health and coherence readability.", 185, 210, 170)
            .. "\n ",
        color("v" .. VERSION .. "  |  Author: Dioscurio", 255, 215, 95)
            .. "\n"
            .. color("HUD compacta do esquadrão com classe, nome, distância, vida e leitura de coerência.", 185, 210, 170)
            .. "\n ",
        color("v" .. VERSION .. "  |  Author: Dioscurio", 255, 215, 95)
            .. "\n"
            .. color("HUD compacta del escuadrón con clase, nombre, distancia, salud y lectura de coherencia.", 185, 210, 170)
            .. "\n "
    ),

    interface_group = L(color("Interface", 255, 215, 95), color("Interface", 255, 215, 95), color("Interfaz", 255, 215, 95)),
    language = L("Language", "Idioma", "Idioma"),
    language_tooltip = L(
        "Selects Coherence HUD's own language. HUD text changes immediately; DMF menu labels are rebuilt after reloading mods or restarting the game.",
        "Seleciona o idioma próprio do Coherence HUD. Textos da HUD mudam na hora; labels do menu DMF são reconstruídos ao recarregar os mods ou reiniciar o jogo.",
        "Selecciona el idioma propio de Coherence HUD. El texto de la HUD cambia al instante; las etiquetas del menú DMF se reconstruyen al recargar mods o reiniciar el juego."
    ),
    language_en = L("English", "Inglês", "Inglés"),
    language_pt_br = L("Português", "Português", "Portugués"),
    language_es = L("Español", "Espanhol", "Español"),

    coherence_messages_group = L(color("Coherence Messages", 255, 215, 95), color("Mensagens de coerência", 255, 215, 95), color("Mensajes de coherencia", 255, 215, 95)),
    coherence_messages_enabled = L("Show enter/exit coherence messages", "Mostrar mensagens ao entrar/sair da coerência", "Mostrar mensajes al entrar/salir de coherencia"),
    coherence_messages_enabled_tooltip = L("Shows a small chat message when you enter or leave team coherence.", "Mostra uma pequena mensagem no chat quando você entra ou sai da coerência da equipe.", "Muestra un pequeño mensaje en el chat cuando entras o sales de la coherencia del equipo."),

    hud_group = L(color("HUD", 255, 215, 95)),
    show_hud = L("Show bottom HUD", "Mostrar HUD inferior", "Mostrar HUD inferior"),
    show_hud_tooltip = L("Shows the compact squad coherence HUD near the bottom center of the screen.", "Mostra a HUD compacta de coerência do esquadrão perto da parte inferior central da tela.", "Muestra la HUD compacta de coherencia del escuadrón cerca de la parte inferior central de la pantalla."),
    show_hud_distance = L("Show distance on HUD", "Mostrar distância na HUD", "Mostrar distancia en la HUD"),
    show_hud_distance_tooltip = L("Shows teammate distance above each bottom HUD slot.", "Mostra a distância dos aliados acima de cada espaço da HUD inferior.", "Muestra la distancia de los aliados sobre cada espacio de la HUD inferior."),
    show_distance = L("Show distance", "Mostrar distância", "Mostrar distancia"),
    show_distance_tooltip = L("Global distance toggle for Coherence HUD text.", "Controle global de distância dos textos do Coherence HUD.", "Control global de distancia para los textos de Coherence HUD."),
    show_ally_name = L("Show ally name", "Mostrar nome do aliado", "Mostrar nombre del aliado"),
    show_ally_name_tooltip = L("When enabled, the bottom HUD label uses the player name.", "Quando ligado, a HUD inferior usa o nome do jogador.", "Al activarlo, la etiqueta inferior usa el nombre del jugador."),
    show_class_icon = L("Show class icon", "Mostrar ícone de classe", "Mostrar icono de clase"),
    show_class_icon_tooltip = L("Shows a class icon in each bottom HUD slot.", "Mostra um ícone de classe em cada espaço da HUD inferior.", "Muestra un icono de clase en cada espacio de la HUD inferior."),
    class_icon_style = L("Class icon style", "Estilo do ícone de classe", "Estilo de icono de clase"),
    class_icon_style_tooltip = L(
        "Auto uses the original texture when IconBrowser is loaded, then falls back to safe font icons if needed.",
        "Auto usa a textura original quando o IconBrowser está carregado e cai para ícones de fonte seguros se necessário.",
        "Auto usa la textura original cuando IconBrowser está cargado y usa iconos de fuente seguros si hace falta."
    ),
    class_icon_style_auto = L("Auto (IconBrowser)", "Auto (IconBrowser)", "Auto (IconBrowser)"),
    class_icon_style_font = L("Font icon (safe)", "Ícone de fonte (seguro)", "Icono de fuente (seguro)"),
    class_icon_style_texture = L("Original texture", "Textura original", "Textura original"),
    show_coherence_state = L("Show coherence state", "Mostrar estado de coerência", "Mostrar estado de coherencia"),
    show_coherence_state_tooltip = L("Controls coherence state coloring and enter/exit warnings.", "Controla cores de estado de coerência e avisos de entrada/saída.", "Controla los colores de estado de coherencia y avisos de entrada/salida."),
    show_unavailable_players = L("Show dead/disconnected players", "Mostrar jogadores mortos/desconectados", "Mostrar jugadores muertos/desconectados"),
    show_unavailable_players_tooltip = L("Keeps players visible when their unit is dead, missing, or temporarily unavailable.", "Mantém jogadores visíveis quando a unidade está morta, ausente ou temporariamente indisponível.", "Mantiene visibles a los jugadores cuando su unidad está muerta, ausente o temporalmente no disponible."),
    hud_label_mode = L("HUD label mode", "Modo do texto da HUD", "Modo de etiqueta de la HUD"),
    hud_label_mode_tooltip = L("Chooses what text appears below each bottom HUD slot.", "Escolhe qual texto aparece abaixo de cada espaço da HUD inferior.", "Elige qué texto aparece debajo de cada espacio de la HUD inferior."),
    hud_label_mode_class = L("Class", "Classe", "Clase"),
    hud_label_mode_name = L("Player Name", "Nome do jogador", "Nombre del jugador"),
    hud_label_mode_hidden = L("Hidden", "Oculto", "Oculto"),

    world_markers_group = L(color("Ally Markers", 255, 215, 95), color("Marcadores dos aliados", 255, 215, 95), color("Marcadores de aliados", 255, 215, 95)),
    show_world_nameplates = L("Show ally world markers", "Mostrar marcadores dos aliados", "Mostrar marcadores de aliados"),
    show_world_nameplates_tooltip = L("Enhances teammate nameplates in the world with coherence-focused information.", "Melhora os nameplates dos aliados no mundo com informações focadas em coerência.", "Mejora los nameplates de aliados en el mundo con información centrada en coherencia."),
    show_world_distance = L("Show distance in world markers", "Mostrar distância nos marcadores", "Mostrar distancia en marcadores"),
    show_world_distance_tooltip = L("Adds teammate distance to the enhanced world marker text.", "Adiciona a distância dos aliados ao texto melhorado dos marcadores.", "Añade la distancia de los aliados al texto mejorado de los marcadores."),
    show_platform_icon = L("Show platform icon", "Mostrar ícone da plataforma", "Mostrar icono de plataforma"),
    show_platform_icon_tooltip = L("Shows Steam, Xbox, PlayStation, or unknown platform icons when available.", "Mostra ícones de Steam, Xbox, PlayStation ou plataforma desconhecida quando disponíveis.", "Muestra iconos de Steam, Xbox, PlayStation o plataforma desconocida cuando estén disponibles."),
    show_player_level = L("Show player level", "Mostrar nível do jogador", "Mostrar nivel del jugador"),
    show_player_level_tooltip = L("Includes the character level in the world marker header.", "Inclui o nível do personagem no cabeçalho do marcador.", "Incluye el nivel del personaje en el encabezado del marcador."),
    show_player_title = L("Show player title", "Mostrar título do jogador", "Mostrar título del jugador"),
    show_player_title_tooltip = L("Includes the equipped character title below the player name when available.", "Inclui o título equipado abaixo do nome do jogador quando disponível.", "Incluye el título equipado debajo del nombre del jugador cuando esté disponible."),
    world_marker_max_distance = L("World marker max distance", "Distância máxima dos marcadores", "Distancia máxima de marcadores"),
    world_marker_max_distance_tooltip = L("Maximum distance in meters for the enhanced ally world markers.", "Distância máxima em metros para os marcadores melhorados dos aliados.", "Distancia máxima en metros para los marcadores mejorados de aliados."),

    ally_color_group = L(color("Ally Color", 255, 215, 55), color("Cor dos aliados", 255, 215, 55), color("Color de aliados", 255, 215, 55)),
    ally_color_preset = L(color("Ally color preset", 255, 215, 55), color("Predefinição de cor dos aliados", 255, 215, 55), color("Preajuste de color de aliados", 255, 215, 55)),
    ally_color_preset_tooltip = L("Changes the color used for coherent allies on the HUD and world markers. RGB values are used only when Custom is selected.", "Altera a cor usada para aliados coerentes na HUD e nos marcadores. Valores RGB só são usados quando Customizado está selecionado.", "Cambia el color usado para aliados en coherencia en la HUD y marcadores. Los valores RGB solo se usan con Personalizado."),
    ally_color_red = L("R"),
    ally_color_green = L("G"),
    ally_color_blue = L("B"),
    ally_color_alpha = L("Ally opacity", "Opacidade dos aliados", "Opacidad de aliados"),

    health_color_group = L(color("Health Bar Color", 95, 235, 110), color("Cor da barra de vida", 95, 235, 110), color("Color de barra de vida", 95, 235, 110)),
    show_ally_health_bars = L("Show ally health bars", "Mostrar barras de vida dos aliados", "Mostrar barras de vida de aliados"),
    show_ally_health_bars_tooltip = L("Shows the original extra world-space ally health bars. Can be toggled during a mission without rebuilding the HUD.", "Mostra as barras extras originais de vida dos aliados no mundo. Pode ser alterado durante a missão sem reconstruir a HUD.", "Muestra las barras extra originales de vida de aliados en el mundo. Puede cambiarse durante la misión sin reconstruir la HUD."),
    health_color_preset = L(color("Health color preset", 95, 235, 110), color("Predefinição de cor da vida", 95, 235, 110), color("Preajuste de color de vida", 95, 235, 110)),
    health_color_preset_tooltip = L("Changes the ally health bar fill color. RGB values are used only when Custom is selected.", "Altera a cor de preenchimento da barra de vida dos aliados. Valores RGB só são usados quando Customizado está selecionado.", "Cambia el color de relleno de la barra de vida de aliados. Los valores RGB solo se usan con Personalizado."),
    health_color_red = L("R"),
    health_color_green = L("G"),
    health_color_blue = L("B"),
    health_color_alpha = L("Health opacity", "Opacidade da vida", "Opacidad de vida"),

    color_gold = L(color("Gold", 255, 215, 55), color("Dourado", 255, 215, 55), color("Dorado", 255, 215, 55)),
    color_blue = L(color("Blue", 80, 190, 255), color("Azul", 80, 190, 255), color("Azul", 80, 190, 255)),
    color_green = L(color("Green", 95, 235, 110), color("Verde", 95, 235, 110), color("Verde", 95, 235, 110)),
    color_purple = L(color("Purple", 185, 120, 255), color("Roxo", 185, 120, 255), color("Morado", 185, 120, 255)),
    color_red = L(color("Red", 255, 80, 65), color("Vermelho", 255, 80, 65), color("Rojo", 255, 80, 65)),
    color_white = L(color("White", 255, 255, 255), color("Branco", 255, 255, 255), color("Blanco", 255, 255, 255)),
    color_custom = L("Custom", "Customizado", "Personalizado"),
}

-- TalentUI's localization keys, folded in. Ours win on any collision, so the
-- mod name and description stay this mod's rather than TalentUI's.
local _ok_l, _dhtl = pcall(function()
    return get_mod("DiosHandholder"):io_dofile(
        "Dio's Handholder/scripts/mods/DiosHandholder/DHT_localization")
end)

if _ok_l and type(_dhtl) == "table" then
    for k, v in pairs(_dhtl) do
        if _mod_loc[k] == nil then
            _mod_loc[k] = v
        end
    end
end

-- Keys for the additions. Plain tables (not L()) because DMF reads these
-- directly when a widget sets localize = true.
_mod_loc.dio_force_outlines = { en = "Force ally outlines on" }
_mod_loc.dio_force_outlines_tooltip = {
    en = "Add an outline to every teammate regardless of the game's own Player Outlines setting. That switch lives in backend account data rather than a config file, and while it is off no ally has an outline at all - so there is nothing for the colouring below to colour. Turn this off if you prefer the game's own behaviour.",
}

_mod_loc.dio_outline_brightness = { en = "Ally outline brightness" }
_mod_loc.dio_outline_brightness_tooltip = {
    en = "Scales how bright the class-coloured ally outline glows, without changing its hue - so a teammate stays the same colour on the HUD and in the world. Applies live.",
}

_mod_loc.dio_class_outlines = { en = "Class-coloured ally outlines" }
_mod_loc.dio_class_outlines_tooltip = {
    en = "Paint each teammate's world outline in their class colour, matching their slot colour here. A smart tag or psyker mark still overrides it, which is intended - those are transient signals and should win.",
}

_mod_loc.dio_downed_ability_names = { en = "Downed allies show their ability" }
_mod_loc.dio_downed_ability_names_tooltip = {
    en = "While a teammate is knocked down, netted, hogtied, ledge-hanging, grabbed or pounced, their nameplate shows their combat ability - BOOK, BUBBLE, TAUNT - instead of their name. With two zealots on the team \"res the zealot\" is ambiguous and \"res BOOK\" is not.",
}

_mod_loc.dio_show_bleedout = { en = "Downed bleedout percentage" }
_mod_loc.dio_show_bleedout_tooltip = {
    en = "Show how much of a downed teammate's bleedout pool is left, next to their ability. A percentage rather than a predicted countdown, because the drain rate is not fixed - it scales with distance to the nearest living teammate and pauses during a revive.",
}

_mod_loc.dio_tracers = { en = "Draw tracers to disablers" }
_mod_loc.dio_tracers_tooltip = {
    en = "Draws a line from in front of you to every disabler that can act on you right now - so a trapper on a balcony behind you is something you see rather than something you find out about.\n\nTrappers and hounds use different rules on purpose, because they are different threats. See the two options below.\n\nOff by default: lines in the world are intrusive, and a mod that draws them without being asked is a mod you turn off entirely.",
}

_mod_loc.dio_tracer_trappers = { en = "Trappers - always" }
_mod_loc.dio_tracer_trappers_tooltip = {
    en = "Red line to every trapper, at any range. Deliberately not distance-gated: the whole problem with a netgunner is that it shoots from somewhere nobody is looking, and being far away does not make it less likely to hit you.",
}

_mod_loc.dio_tracer_hounds = { en = "Hounds - in pounce range" }
_mod_loc.dio_tracer_hounds_tooltip = {
    en = "Amber line to hounds that are close enough to leap, and a dimmed line to ones closing on that range. Covers all three - normal, armoured and mutator.\n\nDistance-gated where trappers are not, because a hound across the level is noise. Drawing every hound would teach you to ignore the lines, which costs you the one that mattered.",
}

_mod_loc.dio_tracer_hound_range = { en = "Hound pounce range (m)" }
_mod_loc.dio_tracer_hound_range_tooltip = {
    en = "How close a hound has to be before its line is drawn at full brightness. The line appears dimmed six metres before this.\n\n16 is the game's own number, not an estimate: it is leave_distance in all three hounds' approach behaviour, the point at which they stop running at you and commit to the leap. Raising it buys earlier warning at the cost of more lines on screen.",
}

_mod_loc.dio_tracer_rave = { en = "Rave mode" }
_mod_loc.dio_tracer_rave_tooltip = {
    en = "Cycles the tracer colours through the spectrum instead of colouring them by threat.\n\nPurely cosmetic, and worth knowing it makes the lines HARDER to read: normally red means trapper and amber means hound, and that distinction is the whole point. Off by default.",
}

_mod_loc.dio_hound_vocal_spam = { en = "Constant barking - every 0.2s" }

_mod_loc.dio_rangefinder = { en = "Rangefinder under crosshair" }
_mod_loc.dio_rangefinder_tooltip = {
    en = "Shows the distance to whatever is under your crosshair, just below it. Useful for judging whether a gunner is inside your weapon's damage falloff, how far a gap is before you commit to the jump, and how far ahead a teammate has run.\n\nRaycast against the same collision filter the game uses for your own shots, so it reports where a bullet would actually land - not where the crosshair points in open air. Recomputed ten times a second rather than every frame.\n\nOff by default: it is another thing on screen, and at low render scales that is a real cost.",
}

_mod_loc.dio_rangefinder_names = { en = "Name the target" }
_mod_loc.dio_rangefinder_names_tooltip = {
    en = "Prints what the crosshair is on as well as how far - GUNNER 34m, TRAPPER 18m, a teammate's name in green. Specials use the short names people actually shout rather than their internal breed names.\n\nTurn this off for the distance alone, which is quieter and is all you need if you are using it to judge gaps and drops rather than targets.",
}

--[[
    Audible Disablers. The credit to Seph is in the tooltip on purpose - it is
    the only place a player who did not read the source will ever see it, and
    the idea is his.
--]]
_mod_loc.dio_hound_vocal = { en = "Hounds vocalise while moving" }
_mod_loc.dio_hound_vocal_tooltip = {
    en = "Replaces a hound's footstep sound with one of its own vocalisations, so it announces itself continuously while it runs at you instead of only on the leap. Applies to all three hounds - normal, armoured and the mutator variant - each using its own audio.\n\nIdea and mechanism by Seph (Concoction of Constitution), from CacklingTrapper.\n\nThere is no volume slider because the footstep event is fired by the animation system and cannot be intercepted from Lua. The three vocalisations differ in loudness instead: bark is the most obvious, growl sits lower, breath is closest to a hint.\n\nCHANGING THIS NEEDS A MOD RELOAD - the breed's sound table is read once, when the game loads it.",
}

_mod_loc.dio_hound_vocal_off    = { en = "Off (vanilla footsteps)" }
_mod_loc.dio_hound_vocal_bark   = { en = "Bark - loudest" }
_mod_loc.dio_hound_vocal_growl  = { en = "Growl - moderate" }
_mod_loc.dio_hound_vocal_breath = { en = "Breath - quietest" }

return _mod_loc
