local mod = get_mod("DiosHandholder")

--[[
    RANGEFINDER
    ===========

    Distance from the camera to whatever is under the crosshair, and what it
    is.

    Ported from HavocTracker's /range command, which was a one-shot chat
    printout. The useful version is continuous and on screen: the question
    "is that gunner in range" is asked while aiming, not by typing a slash
    command and reading the chat log.

    WHAT IT ADDS OVER THE COMMAND

    The command reported metres to the geometry. This also resolves the UNIT
    that was hit, via Actor.unit on the raycast's fifth return, so it can say
    "GUNNER 34m" rather than "34m". Knowing the range to a wall is rarely the
    question.

    ------------------------------------------------------------------------
    EVERYTHING ENGINE-SIDE IS RESOLVED LAZILY.

    Vector3, World, PhysicsWorld, Actor and ScriptCamera are all nil at the
    moment a mod file is loaded. `local Vector3 = Vector3` at file scope
    captures that nil permanently and the feature never works, which has now
    cost this project three separate debugging rounds. rawget(_G, ...) at call
    time is the only safe form.
--]]

local R = {}

local RANGE_MAX = 500

--[[
    THROTTLED. A raycast per frame per player is not free, and the number is
    read by a human - anything faster than a few times a second is wasted
    work that a 640x360 laptop cannot spare.
--]]
local INTERVAL = 0.1

local last_t = 0
local cached = { metres = nil, label = nil, hostile = false }

local function g(name)
    return rawget(_G, name)
end

local function now()
    local t = Managers and Managers.time
    if not t then
        return nil
    end
    local ok, v = pcall(t.time, t, "gameplay")
    return ok and v or nil
end

local function local_unit()
    local pm = Managers and Managers.player
    if not pm or not pm.local_player_safe then
        return nil
    end

    --[[
        local_player_safe, NOT local_player. local_player calls
        Network.peer_id(), which faults uncatchably outside a session - pcall
        does not save you from it.
    --]]
    local ok, p = pcall(pm.local_player_safe, pm, 1)
    return ok and p and p.player_unit or nil
end

--[[
    ========================================================================
    THE RAY COMES FROM THE SMART-TARGETING EXTENSION, NOT THE CAMERA MANAGER
    ========================================================================

    This is Zombine's approach from the range_finder mod (v1.2.0), and it is
    used here because the version that went before it did not work.

    WHAT WAS WRONG

    The old code asked Managers.state.camera for a camera named "player1" and
    raycast from that. Managers.state.camera indexes cameras by VIEWPORT name,
    and the player viewport is not called "player1" - so cam_mgr:camera()
    returned nil on every call, camera_ray() returned nil, nil, and read()
    bailed before it ever cast anything. The rangefinder was not inaccurate;
    it was never running.

    WHAT REPLACES IT

    PlayerUnitSmartTargetingExtension already holds both halves of the
    problem, correct and current, as its own fields:

        self._first_person_component   .position and .rotation of the view
        self._physics_world            the world to cast into

    That extension is what the game itself uses to decide what your crosshair
    is pointing at, so its idea of "where you are looking" is the same one the
    game uses for tagging and interaction. Hooking its fixed_update means the
    values are read at the moment the game considers them valid, with no
    manager lookups, no name guessing, and nothing to be nil.

    Quaternion.forward(rotation) is the aim vector. The unit's own rotation is
    deliberately not used - the unit faces where you move, the view faces
    where you look.

    THE FILTER AND MODE ARE ZOMBINE'S TOO

    "all" with filter_debug_unit_selector rather than "closest" with
    filter_player_character_shooting_raycast. The shooting filter stops on
    geometry a bullet would stop on, which sounds right and is wrong here: it
    passes straight through the enemy you are pointing at if your own body is
    in the way, and it will not return the hit you want when the first
    intersection is yourself. Collecting all hits and taking the first one
    that is not the player's own unit gets the target in every case.

    THE HOOK IS THE WHOLE MEASUREMENT. read() below is now just the cache and
    the naming layer over what the hook last wrote.
--]]
local INDEX_DISTANCE = 2
local INDEX_ACTOR    = 4

local hit_distance = nil
local hit_unit     = nil

--[[
    hook_safe, not hook: this runs inside the game's own targeting update, on
    the fixed timestep, for every frame the player is alive. A throw here
    would take the crosshair's target resolution down with it, and a
    rangefinder is not worth that.
--]]
mod:hook_safe(CLASS.PlayerUnitSmartTargetingExtension, "fixed_update",
function(self, unit, dt, t, fixed_frame)
    if mod:get("dio_rangefinder") ~= true then
        hit_distance, hit_unit = nil, nil
        return
    end

    local fpc = self._first_person_component
    local pw  = self._physics_world

    if not fpc or not pw then
        hit_distance, hit_unit = nil, nil
        return
    end

    local Quaternion = g("Quaternion")
    local PhysicsWorld = g("PhysicsWorld")
    local Actor = g("Actor")

    if not Quaternion or not PhysicsWorld or not Actor then
        return
    end

    local hits, num_hits = PhysicsWorld.raycast(pw, fpc.position,
        Quaternion.forward(fpc.rotation), RANGE_MAX,
        "all", "collision_filter", "filter_debug_unit_selector")

    local distance, target = nil, nil

    if hits then
        for i = 1, num_hits do
            local hit = hits[i]
            local actor_unit = Actor.unit(hit[INDEX_ACTOR])

            --[[
                Skip the player's own unit. In first person the capsule is
                still in the world and the ray starts inside it, so without
                this the reading is your own collision hull at zero metres.
            --]]
            if actor_unit and actor_unit ~= unit then
                distance = hit[INDEX_DISTANCE]
                target = actor_unit
                break
            end
        end
    end

    hit_distance, hit_unit = distance, target
end)

--[[
    Returns what the hook above last measured, with the target named.

    NO RAYCAST HERE ANY MORE. The measurement happens on the game's fixed
    timestep inside the hook; this is the read side, and it exists separately
    because naming the target means touching the breed tables and that is not
    work worth doing on every fixed frame when the HUD redraws at a tenth of
    the rate.

    The throttle is kept for the NAMING only. metres passes through live -
    a distance readout that lags a tenth of a second behind the crosshair is
    the thing people notice first.

    metres is nil when there is nothing to report: rangefinder off, no
    targeting extension yet, or the ray reached RANGE_MAX without hitting
    anything that was not you. Callers draw nothing rather than drawing zero.
--]]
function R.read()
    local metres = hit_distance

    if not metres then
        cached.metres, cached.label, cached.hostile = nil, nil, false
        return nil
    end

    local t = now()

    if t and (t - last_t) >= INTERVAL then
        last_t = t

        local label, hostile = nil, false

        if hit_unit then
            local ok, l, h = pcall(describe, hit_unit)
            if ok then
                label, hostile = l, h
            end
        end

        cached.label, cached.hostile = label, hostile
    end

    cached.metres = metres

    return metres, cached.label, cached.hostile
end

function R.reset()
    last_t = 0
    cached.metres, cached.label, cached.hostile = nil, nil, false
end

--[[
    NAMED hhrange, NOT range.

    DMF commands are registered in one global namespace across every installed
    mod, and HavocTracker already owns /range. Registering a duplicate does not
    shadow it - DMF refuses the second one outright and logs

        (command): command name 'range' is already used by another mod 'HavocTracker'

    so the command simply did not exist. Every command in this suite is
    prefixed by its mod for exactly this reason; this one was the exception and
    it broke on contact.
--]]
mod:command("hhrange", "distance to what you are looking at", function()
    local metres, label, hostile = R.read()

    if not metres then
        mod:echo("[Dio] rangefinder: nothing in range")
        return
    end

    mod:echo(string.format("[Dio] rangefinder: %s%.1fm",
        label and (label .. " at ") or "", metres))
end)

mod.__dio_rangefinder = R

return R
