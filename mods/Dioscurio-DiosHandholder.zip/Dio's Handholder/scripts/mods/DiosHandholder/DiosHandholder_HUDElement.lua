-- Superseded by the literal coherence_hud copy. Not referenced.
return {}
