local mod = get_mod("DiosHandholder")

local PLAYER_ABILITY_DEF_PATH = "scripts/ui/hud/elements/player_ability/hud_element_player_ability_vertical_definitions"

local UIWidget = require("scripts/managers/ui/ui_widget")
local UIFontSettings = require("scripts/managers/ui/ui_font_settings")
local UIHudSettings = require("scripts/settings/ui/ui_hud_settings")
local HudElementPlayerAbilitySettings = require("scripts/ui/hud/elements/player_ability/hud_element_player_ability_settings")
local FixedFrame = require("scripts/utilities/fixed_frame")

local TalentUISettings = mod:io_dofile("Dio's Handholder/scripts/mods/DiosHandholder/DHT_settings")

local ACTIVE_COLOR = UIHudSettings.color_tint_main_1
local COOLDOWN_COLOR = UIHudSettings.color_tint_alert_2
local NOTIFICATION_LINE_DEFAULT = UIHudSettings.color_tint_main_2
local NOTIFICATION_ICON_DEFAULT = UIHudSettings.color_tint_main_2
local NOTIFICATION_TEXT_DEFAULT = UIHudSettings.color_tint_main_1
local NOTIFICATION_BACKGROUND_DEFAULT = Color.terminal_grid_background(180, true)

local function clone_color(color)
	return {
		color[1],
		color[2],
		color[3],
		color[4],
	}
end

--[[
    ========================================================================
    THE GLOBAL dofile HOOK
    ========================================================================

    WHY IT HAS TO BE dofile AT ALL

    hud_element_player_ability.lua:13 loads its definitions with

        local definitions = dofile(definition_path)

    not with require, so hook_require cannot see it. Hooking the global is
    the only way to reach that table, and reaching it is how the cooldown
    timer gets added to the ability widget.

    WHAT WAS WRONG WITH THE FIRST VERSION

    It ran on EVERY dofile in the game. The engine loads main path data
    (main_path_manager.lua:125), options templates
    (options_templates.lua:42), dialogue tag queries and navmesh data the
    same way, and all of them were being routed through a mod closure for no
    reason.

    Three concrete faults, in order of how much they matter:

    1. RETURN VALUES WERE TRUNCATED. `local instance = func(path)` keeps one
       value; dofile returns everything the chunk returns. Any caller doing
       `local a, b = dofile(...)` silently lost b. Nothing in this mod cared;
       everything else in the game that used dofile was exposed to it.

    2. IT COULD THROW INTO ENGINE CODE. mod:hook is not hook_safe, so an
       error raised in here surfaces inside whatever called dofile. If
       TalentUISettings had failed to load - DMF's io_dofile returns `false`
       rather than nil on failure - then indexing it on the font-size line
       would have thrown, and it would have thrown inside the engine's
       main-path loader rather than inside this mod.

    3. IT DID THE WORK BEFORE CHECKING THE PATH. The early return now comes
       first, so a dofile this mod has no interest in costs one string
       comparison.

    The rewrite below touches nothing but the one path it needs, passes
    every return value through untouched, and cannot raise.
--]]
mod:hook(_G, "dofile", function(func, path, ...)
    --[[
        Pass through FIRST and untouched. select("#", ...) preserves the
        real arity, including trailing nils, which table.pack/unpack round
        trips do not - and an engine call that relies on a second return
        value is not something a UI mod should be able to break.
    --]]
    if path ~= PLAYER_ABILITY_DEF_PATH then
        return func(path, ...)
    end

    local instance = func(path, ...)

    --[[
        pcall around the mutation. A failure here costs the cooldown timer on
        the ability icon. A throw here costs whoever called dofile, and that
        is the engine.
    --]]
    local ok, err = pcall(function()
        if type(instance) ~= "table"
            or type(instance.scenegraph_definition) ~= "table"
            or type(instance.widget_definitions) ~= "table" then
            return
        end

        local style = table.clone(UIFontSettings.hud_body)

        style.text_horizontal_alignment = "center"
        style.text_vertical_alignment = "center"
        --[[
            TalentUISettings can be `false`, not nil - that is what DMF's
            io_dofile returns when the file cannot be opened - so it is
            type-checked rather than trusted. A plain `or` chain through a
            boolean is an index error.
        --]]
        style.font_size = mod:get("local_cooldown_font_size")
            or (type(TalentUISettings) == "table"
                and (TalentUISettings.local_cooldown_font_size
                     or TalentUISettings.teammate_ability_cooldown_font_size))
            or 40
        style.font_type = "machine_medium"
        style.drop_shadow = true

        instance.scenegraph_definition.cooldown = {
            parent = "slot",
            vertical_alignment = "center",
            horizontal_alignment = "center",
            size = HudElementPlayerAbilitySettings.icon_size,
            position = { 0, 0, 10 },
        }

        instance.widget_definitions.talentui_cooldown_timer = UIWidget.create_definition({
            {
                value_id = "text",
                style_id = "text",
                pass_type = "text",
                value = "",
                style = style,
            },
        }, "cooldown")
    end)

    if not ok then
        mod:error("[Handholder] ability cooldown widget not added: %s", tostring(err))
    end

    return instance
end)

local function get_buff_remaining_time(buff_extension, buff_template_name)
	if not buff_extension then
		return 0
	end

	local buffs_by_index = buff_extension._buffs_by_index
	if not buffs_by_index then
		return 0
	end

	local timer = 0
	for _, buff in pairs(buffs_by_index) do
		local template = buff:template()
		if template and template.name == buff_template_name then
			local remaining = buff:duration_progress() or 1
			local duration = buff:duration() or 15
			timer = math.max(timer, duration * remaining)
		end
	end

	return timer
end

--[[
	CACHED, for the same reason as the outline hook: this runs every frame and
	DMFMod:get is not a field read. Cleared by on_setting_changed, so it cannot
	go stale; nil means "not resolved yet" rather than a guessed default.
--]]
local _show_cooldown = nil

--[[
	Charges, progress and seconds left all come from the shared ability clock
	(DHT_ability_clock.lua), the same reading the teammate panels use.

	The old version here took the game's regen progress and multiplied it by
	the BASE regen time per charge. That ignored cooldown-speed buffs, so the
	number ran slow, and it kept printing a frozen figure while the regen was
	paused. The clock uses the engine's own rate formula for the local player,
	and it gives no number at all while regen is paused.

	It is also what the HUD shows while spectating a teammate: then this
	element is fed a husk extension, and the clock's husk path is the one
	that fixes the "stuck at 50-55 s while ready" reading.
--]]
local Clock = type(mod.AbilityClock) == "table" and mod.AbilityClock or nil
local _clock_out = {}

local function read_clock(ability_extension, ability_type)
	if not Clock or not ability_extension or not ability_type then
		return nil
	end

	local ok, out = pcall(Clock.read, ability_extension, ability_type, _clock_out)

	if ok and type(out) == "table" and out.equipped then
		return out
	end

	return nil
end

mod.refresh_local_ability_setting = function()
	_show_cooldown = nil
end

mod:hook_safe("HudElementPlayerAbility", "update", function(self)
	if _show_cooldown == nil then
		_show_cooldown = mod:get("show_local_ability_cooldown") and true or false
	end

	if not _show_cooldown then
		return
	end
	
	local widgets_by_name = self._widgets_by_name
	local text_widget = widgets_by_name.talentui_cooldown_timer
	
	if not text_widget then
		return
	end
	
	local player = self._data.player
	local player_unit = player.player_unit
	local parent = self._parent
	-- 1.13 renamed HudElementPlayerAbility._ability_id to _ability_type.
	local ability_id = self._ability_type or self._ability_id
	
	if not rawget(_G, "ALIVE") or not ALIVE[player_unit] then
		text_widget.content.text = ""
		text_widget.visible = false
		text_widget.dirty = true
		return
	end
	
	local ability_extension = parent:get_player_extension(player, "ability_system")
	local buff_extension = parent:get_player_extension(player, "buff_system")
	
	local progress = self._ability_progress
	local on_cooldown = self._on_cooldown
	local format_type = mod:get("cooldown_format")
	local show_active = mod:get("show_local_ability_active") ~= false
	local show_decimals = mod:get("show_local_ability_decimals") ~= false
	local show_ready_notification = mod:get("show_local_ability_ready_notification") ~= false
	
	local display_text = ""
	local display_color = COOLDOWN_COLOR
	local is_active = false
	
	--[[
		ability_pause_cooldown_settings exists only on the local extension.
		While spectating, this element is fed a teammate's husk extension,
		which has no such method, and the unguarded call threw every frame.
	--]]
	if ability_extension and ability_extension.ability_pause_cooldown_settings
		and ability_extension:ability_is_equipped(ability_id) then
		local pause_cooldown_settings = ability_extension:ability_pause_cooldown_settings(ability_id)
		
		if pause_cooldown_settings and buff_extension then
			local duration_tracking_buff = pause_cooldown_settings.duration_tracking_buff
			
			if duration_tracking_buff then
				local has_active_buff = buff_extension:current_stacks(duration_tracking_buff) > 0
				
				if has_active_buff and show_active then
					is_active = true
					local remaining_buff_time = get_buff_remaining_time(buff_extension, duration_tracking_buff)
					
					if remaining_buff_time and remaining_buff_time >= 0.05 then
						display_color = ACTIVE_COLOR
						
						if format_type == "time" then
							if show_decimals then
								display_text = string.format("%.1f", remaining_buff_time)
							else
								display_text = string.format("%.0f", math.ceil(remaining_buff_time))
							end
						elseif format_type == "percent" then
							local duration_progress = buff_extension:buff_duration_progress(duration_tracking_buff)
							local percent = (1 - duration_progress) * 100
							display_text = string.format("%d%%", math.floor(percent))
						end
					else
						display_text = ""
					end
				end
			end
		end
	end
	
	-- Charges in hand decide "ready"; the regen clock only decides how long
	-- until the next one. See DHT_ability_clock.lua.
	local clock = read_clock(ability_extension, ability_id)
	local has_charge = clock and clock.ready or false

	if not is_active then
		if not clock then
			-- No clock (failed to load): no number is better than a wrong one.
			display_text = ""
		elseif clock.ready then
			display_text = ""
		else
			display_color = COOLDOWN_COLOR

			if format_type == "time" then
				local time_remaining = clock.seconds

				if time_remaining and time_remaining > 0 then
					if show_decimals then
						display_text = string.format("%.1f", time_remaining)
					else
						display_text = string.format("%.0f", math.ceil(time_remaining))
					end
				else
					-- Paused regen, or nothing synced yet.
					display_text = ""
				end
			elseif format_type == "percent" then
				local p = clock.progress or 0
				if p >= 1 then
					display_text = ""
				else
					display_text = string.format("%d%%", math.floor(p * 100))
				end
			else
				display_text = ""
			end
		end
	end
	
	text_widget.content.text = display_text
	text_widget.style.text.text_color = display_color
	text_widget.visible = display_text ~= ""
	text_widget.dirty = true
	
	-- The "ability ready" notification follows the same rule: a charge in
	-- hand IS ready, even while the next one is still regenerating.
	local is_ready
	if clock then
		is_ready = has_charge and not is_active
	else
		is_ready = (not on_cooldown and (progress or 0) >= 1) and not is_active
	end
	
	if show_ready_notification then
		if self._ability_ready_prev == nil then
			self._ability_ready_prev = is_ready
			self._ability_prev_on_cooldown = on_cooldown
		else
			local became_ready_after_cooldown = is_ready and not self._ability_ready_prev and (self._ability_prev_on_cooldown or on_cooldown)
			
			if became_ready_after_cooldown then
				local line_color = clone_color(NOTIFICATION_LINE_DEFAULT)
				local icon_color = clone_color(NOTIFICATION_ICON_DEFAULT)
				local background_color = clone_color(NOTIFICATION_BACKGROUND_DEFAULT)
				local text_color = clone_color(NOTIFICATION_TEXT_DEFAULT)
				local line_1_text = mod:localize("local_ability_ready_notification")
				line_1_text = string.format("{#color(%d,%d,%d)}%s{#reset()}", text_color[2], text_color[3], text_color[4], line_1_text)
				
				local notification_data = {
					icon_size = "currency",
					color = background_color,
					line_color = line_color,
					icon_color = icon_color,
					line_1 = line_1_text,
					show_shine = true,
				}
				
				Managers.event:trigger("event_add_notification_message", "custom", notification_data)
			end
			
			self._ability_ready_prev = is_ready
			self._ability_prev_on_cooldown = on_cooldown
		end
	end
end)

