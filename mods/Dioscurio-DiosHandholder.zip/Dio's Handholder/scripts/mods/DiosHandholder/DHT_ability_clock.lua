local mod = get_mod("DiosHandholder")

--[[
	========================================================================
	ABILITY CLOCK - one reading of "is it up, and how long until it is"
	========================================================================

	Used by the local ability timer (DHT_local_ability.lua), the teammate
	panels (DHT_teammate_ability.lua) and anything else that needs it, so the
	two can never disagree about the same ability.

	WHY THE GAME'S OWN HELPERS ARE NOT USED FOR TEAMMATES

	Darktide 1.13 replaced cooldown end times with a regenerating resource.
	For a teammate the client has a PlayerHuskAbilityExtension, and its
	helpers mix values from two different sources:

	  max_ability_resource()          synced from the server, BUFFED
	                                  (charges x cost after cooldown curios,
	                                  the psyker aura, talents)
	  get_ability_resource_cost_per_charge()
	                                  computed on the client, UNBUFFED - the
	                                  husk version skips the
	                                  _resource_flat_cost_per_use and
	                                  _resource_cost_per_use_modifier stat
	                                  buffs that the server version applies
	                                  (player_husk_ability_extension.lua:469
	                                  against player_unit_ability_extension.lua
	                                  :1446)

	missing_ability_resource_until_next_charge() subtracts
	charges x UNBUFFED cost from the BUFFED resource. With any cooldown
	reduction the result goes negative, is clamped to a full charge, and
	get_ability_resource_regen_progress() returns 0. The timer then printed
	1 x max_regen_time_for_ability_charge - the buffed cooldown, for example
	60 s x 0.88 = 52.8 s or 60 s x 0.92 = 55.2 s - and it never moved:

	  - on a READY single-charge ability whenever the synced max resource
	    came out even slightly above the synced resource (the full check
	    `max <= remaining` fails, so the code falls through to the bad
	    subtraction)
	  - on a multi-charge ability for the whole window where the resource
	    is between n x buffed cost and n x base cost

	While the ability did tick, it ticked at the wrong pace: progress was
	resource / UNBUFFED cost, so it ran out at 88 % and snapped to ready.

	THE FIX

	Everything here is derived from the synced numbers only:

	  charges in hand     num_charges (an integer, exact)
	  cost of one charge  max_resource / max_charges (the server's own,
	                      buffed value: max_ability_resource is charges x
	                      buffed cost by definition, :1326)
	  progress to next    (resource - charges x cost) / cost
	  ready               charges > 0, or charges == max (full)

	Seconds left are (cost - progress part) / regen rate. For the local
	player the rate is computed with the engine's own formula
	(_update_ability_resources, :771), so buffs are included. For a teammate
	the stat buffs are not on the client, so the rate is MEASURED from how
	fast the synced resource is actually rising, with the base rate as the
	starting value. A paused regen (resource_regen_paused) gives no number at
	all instead of a frozen one.
--]]

local Clock = {}

local EPS = 1e-6

-- A sample window shorter than this is mostly network quantisation.
local MIN_SAMPLE_DT = 0.25

-- A rise bigger than this share of one charge in one window is a refund
-- (a talent restoring cooldown), not the regen rate.
local REFUND_SHARE = 0.25

local function finite(n)
	return type(n) == "number" and n == n and n ~= math.huge and n ~= -math.huge
end

local function call(ext, name, ...)
	local f = ext[name]

	if type(f) ~= "function" then
		return nil
	end

	local ok, a = pcall(f, ext, ...)

	if ok then
		return a
	end

	return nil
end

local function gameplay_time()
	local tm = Managers and Managers.time

	if tm and tm.time then
		local ok, t = pcall(tm.time, tm, "gameplay")

		if ok and finite(t) then
			return t
		end
	end

	return os.clock()
end

-- The husk keeps its synced regen time in this table; the local extension
-- has no such field. Cheaper and sturdier than comparing class names.
local function is_husk(ext)
	return rawget(ext, "_ability_charge_max_regen_time") ~= nil
end

--[[
	Local player: the exact rate, by the engine's formula.

	_update_ability_resources (:846-869):
	  base  = resource_regen_per_second
	        + max_resource * resource_regen_percent_per_second   (0 if paused)
	  rate  = (base + <type>_resource_flat_regen) * <type>_resource_regen_modifier
	        - resource cost per second
--]]
local function local_rate(ext, ability_type, ability, max_resource, paused)
	local buff_ext = rawget(ext, "_buff_extension")
	local stat_buffs = buff_ext and call(buff_ext, "stat_buffs")

	if type(stat_buffs) ~= "table" then
		return nil
	end

	local base = 0

	if not paused then
		base = (ability.resource_regen_per_second or 0)
			+ max_resource * (ability.resource_regen_percent_per_second or 0)
	end

	local flat = stat_buffs[ability_type .. "_resource_flat_regen"] or 0
	local modifier = stat_buffs[ability_type .. "_resource_regen_modifier"] or 1
	local cost_per_second = call(ext, "get_ability_resource_cost_per_second", ability_type) or 0

	local rate = (base + flat) * modifier - cost_per_second

	if not finite(rate) then
		return nil
	end

	return rate
end

--[[
	Teammate: the measured rate.

	Weak-keyed on the extension, so a teammate who leaves does not keep an
	entry alive. One small table per ability per teammate, reused.
--]]
local samples = setmetatable({}, { __mode = "k" })

local function measured_rate(ext, ability_type, resource, charges, cost, base_rate, paused)
	local per_ext = samples[ext]

	if not per_ext then
		per_ext = {}
		samples[ext] = per_ext
	end

	local s = per_ext[ability_type]
	local t = gameplay_time()

	if not s then
		s = { r = resource, n = charges, t = t, rate = nil }
		per_ext[ability_type] = s

		return base_rate
	end

	local dt = t - s.t

	if dt < 0 then
		-- Clock went backwards (new mission). Start over.
		s.r, s.n, s.t, s.rate = resource, charges, t, nil

		return base_rate
	end

	if dt >= MIN_SAMPLE_DT then
		local dr = resource - s.r

		--[[
			Only a plain rise inside one charge says anything about the rate.
			A cast (dr < 0), a refund (big jump), a charge change or a pause
			moves the baseline and nothing else.
		--]]
		if not paused and charges == s.n and dr >= 0 and dr <= cost * REFUND_SHARE then
			local inst = dr / dt

			if inst > EPS then
				s.rate = s.rate and (s.rate * 0.6 + inst * 0.4) or inst
			end
		end

		s.r, s.n, s.t = resource, charges, t
	end

	return s.rate or base_rate
end

--[[
	Clock.read(ability_extension, ability_type, out) -> out

	Fills and returns `out` (pass a table you keep, so nothing is allocated
	per frame):

	  equipped      false when there is nothing to show
	  ready         a cast is possible now (a charge is in hand)
	  full          every charge is in hand
	  charges       charges in hand
	  max_charges   charge capacity
	  progress      0..1 toward the next charge (1 when full)
	  seconds       seconds to the next charge, or nil (full, paused, unknown)
	  paused        regen is paused by the ability itself
--]]
function Clock.read(ext, ability_type, out)
	out = out or {}
	out.equipped, out.ready, out.full, out.paused = false, false, false, false
	out.charges, out.max_charges, out.progress, out.seconds = 0, 0, 1, nil

	if not ext or not ability_type then
		return out
	end

	-- ability_is_equipped returns the ability table itself, not a boolean.
	if not call(ext, "ability_is_equipped", ability_type) then
		return out
	end

	local equipped = call(ext, "equipped_abilities")
	local ability = type(equipped) == "table" and equipped[ability_type] or nil

	if type(ability) ~= "table" then
		return out
	end

	if call(ext, "ability_enabled", ability_type) == false then
		return out
	end

	out.equipped = true

	local charges = call(ext, "remaining_ability_charges", ability_type) or 0
	local max_charges = call(ext, "max_ability_charges", ability_type) or 0

	if not finite(charges) then charges = 0 end
	if not finite(max_charges) then max_charges = 0 end

	out.charges, out.max_charges = charges, max_charges
	out.ready = charges > 0

	--[[
		Grenades that only use charges (zealot knives, ogryn rock and so on)
		have no regen clock at all: charges come from pickups and talents.
	--]]
	if ability.only_uses_charges then
		out.full = max_charges > 0 and charges >= max_charges
		out.progress = out.full and 1 or 0

		return out
	end

	if max_charges > 0 and charges >= max_charges then
		out.full, out.ready, out.progress = true, true, 1

		return out
	end

	local paused = call(ext, "is_ability_resource_regen_paused", ability_type) == true
	out.paused = paused

	local max_resource = call(ext, "max_ability_resource", ability_type)
	local resource = call(ext, "remaining_ability_resource", ability_type)

	if not finite(max_resource) or not finite(resource) or max_resource <= EPS then
		-- Nothing synced yet. Say "ready" only if a charge is in hand.
		out.progress = out.ready and 1 or 0

		return out
	end

	local cost, part

	if max_charges > 0 then
		cost = max_resource / max_charges
		part = resource - charges * cost
	else
		-- Resource-type ability (none ship in 1.13, kept for safety).
		cost = max_resource
		part = resource
	end

	if cost <= EPS then
		out.progress = out.ready and 1 or 0

		return out
	end

	if part < 0 then part = 0 end
	if part > cost then part = cost end

	out.progress = part / cost

	local missing = cost - part

	if missing <= EPS * cost then
		out.progress = 1

		return out
	end

	if paused then
		return out
	end

	-- Base rate: the synced regen time is cost / base regen on both sides.
	local base_rate
	local max_time = call(ext, "max_regen_time_for_ability_charge", ability_type)

	if finite(max_time) and max_time > EPS then
		base_rate = cost / max_time
	end

	local rate

	if is_husk(ext) then
		rate = measured_rate(ext, ability_type, resource, charges, cost, base_rate, paused)
	else
		rate = local_rate(ext, ability_type, ability, max_resource, paused) or base_rate
	end

	if finite(rate) and rate > EPS then
		out.seconds = missing / rate
	end

	return out
end

--[[
	Reset the measured rates, for a new mission. Not required for
	correctness (samples age out on their own), but it stops the first
	reading of a mission from using a rate measured in the last one.
--]]
function Clock.reset()
	for k in pairs(samples) do
		samples[k] = nil
	end
end

return Clock
