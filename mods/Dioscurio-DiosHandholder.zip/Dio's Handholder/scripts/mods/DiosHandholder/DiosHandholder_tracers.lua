local mod = get_mod("DiosHandholder")

--[[
    DISABLER TRACERS
    ================

    A line drawn from just in front of you to every disabler that can act on
    you, so a trapper lining up a shot from a balcony or a hound coming in from
    behind is something you SEE rather than something you get told about after
    it lands.

    TWO DIFFERENT RULES, BECAUSE THEY ARE DIFFERENT THREATS

        Trapper   global. A netgunner is dangerous at whatever range it has
                  line of sight from, and the whole problem with trappers is
                  that they shoot from somewhere nobody is looking. Range does
                  not reduce the threat, so it does not gate the tracer.

        Hound     inside the pounce radius only, with a warning band outside
                  it. A hound forty metres away across a room you are leaving
                  is noise; one at fourteen metres is about to be in your
                  face. Drawing every hound on the level would train you to
                  ignore the lines, which costs you the one that mattered.

    ------------------------------------------------------------------------
    WHERE 16 METRES COMES FROM

    Not estimated. bt_chaos_hound_approach_action leaves the approach state
    and hands over to the leap when

        leave_distance <= target_distance

    and leave_distance is 16 in all three hound action sets - chaos_hound,
    chaos_armored_hound and chaos_hound_mutator, which is a rare piece of luck
    since almost nothing else about the three matches. So 16m is the distance
    at which a hound actually commits to a pounce, and it is the default.

    The band above it exists because "entering the radius" was asked for
    explicitly, and a line that appears at exactly the moment the hound is
    already leaping is a notification, not a warning. The band is drawn dimmer
    so the two states are distinguishable without reading anything.

    ------------------------------------------------------------------------
    EVERY ENGINE GLOBAL IS RESOLVED AT CALL TIME.

    Vector3, World, LineObject, Color, Unit and DebugDrawer are all nil when a
    mod file is loaded. Capturing them at file scope captures nil forever,
    which has already cost this project three debugging rounds on a different
    feature. rawget(_G, ...) inside the function is the only correct form.
--]]

local T = {}

--[[
    Breeds, by exact name. A tag-based test would be wrong here: "special"
    includes snipers, bombers and flamers, none of which are disablers, and
    the point of this feature is that the lines stay rare enough to mean
    something.
--]]
local TRAPPERS = {
    renegade_netgunner = true,
}

local HOUNDS = {
    chaos_hound = true,
    chaos_armored_hound = true,
    chaos_hound_mutator = true,
}

local DEFAULT_POUNCE_RADIUS = 16      -- bt_chaos_hound_approach_action leave_distance
local WARNING_BAND = 6                -- metres of "closing" shown above the radius
local TRAPPER_MAX = 120               -- sanity cap; beyond this it is not your fight

local SCAN_INTERVAL = 0.25            -- how often the unit list is rebuilt
local CHEST_OFFSET = 1.1              -- up-axis offset so lines land on the body

--[[
    The scan result, rebuilt on the interval and redrawn every frame from the
    units it holds. Positions are re-read per frame - a cached POSITION would
    lag the line behind a sprinting hound, which is the case that matters.
--]]
local scanned = { trappers = {}, hounds = {}, at = 0 }

local line_object = nil
local line_world = nil

local function g(name)
    return rawget(_G, name)
end

local function now()
    local t = Managers and Managers.time
    if not t then
        return nil
    end
    local ok, v = pcall(t.time, t, "gameplay")
    return ok and v or nil
end

local function get_bool(id, fallback)
    if not mod.get then
        return fallback
    end
    local ok, v = pcall(mod.get, mod, id)
    if not ok or v == nil then
        return fallback
    end
    return v and true or false
end

local function get_number(id, fallback)
    if not mod.get then
        return fallback
    end
    local ok, v = pcall(mod.get, mod, id)
    if not ok or type(v) ~= "number" then
        return fallback
    end
    return v
end

local function unit_position(unit)
    local ALIVE = g("ALIVE")
    if not ALIVE or not ALIVE[unit] then
        return nil
    end

    --[[
        POSITION_LOOKUP first: the engine already maintains it for every unit
        with a locomotion extension and reading it is a table index, where
        Unit.world_position is an engine call. Falling back rather than relying
        on it, because a unit can be absent from the lookup for a frame after
        spawning.
    --]]
    local lookup = g("POSITION_LOOKUP")
    local p = lookup and lookup[unit]
    if p then
        return p
    end

    local Unit = g("Unit")
    if not Unit or not Unit.world_position then
        return nil
    end

    local ok, v = pcall(Unit.world_position, unit, 1)
    return ok and v or nil
end

local function local_player_unit()
    local pm = Managers and Managers.player
    if not pm or not pm.local_player_safe then
        return nil
    end
    -- local_player_safe, not local_player: the latter calls Network.peer_id()
    -- and faults uncatchably outside a session.
    local ok, p = pcall(pm.local_player_safe, pm, 1)
    return ok and p and p.player_unit or nil
end

local function breed_name(unit)
    local ScriptUnit = g("ScriptUnit")
    if not ScriptUnit or not ScriptUnit.has_extension then
        return nil
    end

    local ok, ext = pcall(ScriptUnit.has_extension, unit, "unit_data_system")
    if not ok or not ext or not ext.breed then
        return nil
    end

    local ok2, breed = pcall(ext.breed, ext)
    if not ok2 or type(breed) ~= "table" then
        return nil
    end

    return breed.name
end

--[[
    Enemies come from the side system's per-tag list rather than from a sweep
    of every unit in the level. alive_units_by_tag("enemy", "special") is a
    table the game already maintains for its own AI, so the scan is a walk over
    a handful of entries rather than hundreds.
--]]
local function read_player_side(side_system)
    local name = side_system:get_default_player_side_name()

    return side_system:get_side_from_name(name)
end

local function scan()
    local trappers, hounds = {}, {}

    local ext = Managers.state and Managers.state.extension
    local side_system = ext and ext:system("side_system")

    if not side_system then
        return trappers, hounds
    end

    -- Hoisted like the camera read above. scan() only runs on the 250ms
    -- throttle rather than per frame, but the pattern is the problem, not the
    -- frequency - leaving one in place is how the next one gets written.
    local ok, side = pcall(read_player_side, side_system)

    if not ok or not side or not side.alive_units_by_tag then
        return trappers, hounds
    end

    local ok2, list = pcall(side.alive_units_by_tag, side, "enemy", "special")
    if not ok2 or type(list) ~= "table" then
        return trappers, hounds
    end

    local n = list.size or 0
    for i = 1, n do
        local unit = list[i]
        if unit then
            local name = breed_name(unit)
            if name then
                if TRAPPERS[name] then
                    trappers[#trappers + 1] = unit
                elseif HOUNDS[name] then
                    hounds[#hounds + 1] = unit
                end
            end
        end
    end

    return trappers, hounds
end

--[[
    The line ORIGIN is in front of the camera, not at it.

    A line starting at the eye is a single pixel - it is exactly along the view
    axis and there is nothing to see. Pushing the origin forward and down puts
    a visible segment on screen that still reads as coming from you.
--]]
--[[
    HOISTED OUT OF origin(), WHICH RUNS EVERY FRAME.

    It used to be

        local ok = pcall(function()
            local c = cam_mgr:camera("player1")
            ...
        end)

    and a function literal inside a pcall captures its surroundings as
    upvalues, so LuaJIT allocates a fresh closure on every call. That is
    exactly the bug I spent this session removing from safe_field, and I
    reintroduced it in new code two days later - which is why the rule has to
    be "never build a closure inside a pcall on a repeating path" rather than
    "remember to check for it".

    Passing the two values as arguments makes this a plain shared function
    created once at load.
--]]
local function read_camera(cam_mgr, ScriptCamera)
    local c = cam_mgr:camera("player1")

    if not c then
        return nil, nil
    end

    return ScriptCamera.position(c), ScriptCamera.forward(c)
end

local function origin()
    local cam_mgr = Managers.state and Managers.state.camera
    local ScriptCamera = g("ScriptCamera")
    local Vector3 = g("Vector3")

    if not cam_mgr or not cam_mgr.camera or not ScriptCamera or not Vector3 then
        return nil
    end

    local ok, pos, dir = pcall(read_camera, cam_mgr, ScriptCamera)

    if not ok or not pos or not dir then
        return nil
    end

    --[[
        FROM THE CROSSHAIR.

        The first version pushed the origin down by 0.55 so the line would not
        be a single pixel along the view axis. It stopped being degenerate and
        started looking like it came out of the player's feet, which is worse -
        a tracer is meant to read as "look here", and one rising from below
        reads as something else entirely.

        Straight down the view axis from just in front of the camera. A line to
        anything off-centre still has length on screen, and a line to something
        dead ahead is short because the thing IS dead ahead, which is correct
        rather than a bug.
    --]]
    return pos + dir * 0.35
end

--[[
    LINE DRAWING, ON THE PATH THAT ACTUALLY WORKS IN THE SHIPPED GAME.

    The first version used DebugDrawer. That is why no tracer ever appeared:
    DebugDrawer is an EDITOR facility. Every vanilla site that builds one sits
    behind

        if not rawget(_G, "LevelEditor") then return end

    (bot_jump_assist.lua:45, ladder.lua, minion_multi_teleporter.lua), so in a
    retail build the global is nil and the whole draw silently did nothing.

    LineObject is the real path, and this follows SlotZones' line_draw.lua,
    which is proven in a shipping mod:

        World.create_line_object(world)   once, cached per world
        LineObject.reset(obj)             start of frame
        LineObject.add_line(obj, c, a, b) per line
        LineObject.dispatch(world, obj)   end of frame

    Every engine call is pcall'd and the cache is dropped on any failure. A
    line object belongs to the world it was made in, so a stale one after a
    mission ends is a dangling pointer rather than a harmless no-op.

    Colour is Color(ALPHA, r, g, b) - alpha first, which is Darktide's order
    and the opposite of what the constructor name suggests.
--]]
local line_object = nil
local line_world = nil

local function drop_line_object()
    line_object, line_world = nil, nil
end

local function ensure_line_object()
    local wm = Managers.world
    local World = g("World")
    local LineObject = g("LineObject")

    if not wm or not World or not LineObject or not wm.has_world
        or not wm:has_world("level_world") then
        return nil, nil, nil
    end

    local ok_world, world = pcall(wm.world, wm, "level_world")

    if not ok_world or not world then
        return nil, nil, nil
    end

    if line_world ~= world or not line_object then
        drop_line_object()

        local ok, obj = pcall(World.create_line_object, world)

        if not ok or not obj then
            return nil, nil, nil
        end

        line_object, line_world = obj, world
    end

    return line_object, world, LineObject
end

local function make_color(a, r, gg, b)
    local Color = g("Color")

    if type(Color) == "function" then
        return Color(a, r, gg, b)
    end

    local mt = Color and getmetatable(Color)

    if mt and type(mt.__call) == "function" then
        return Color(a, r, gg, b)
    end

    if Color and type(Color.new) == "function" then
        return Color.new(a, r, gg, b)
    end

    return { r, gg, b }
end

--[[
    RAVE MODE.

    Hue cycles over time so the lines strobe. Purely cosmetic and off by
    default - a disabler warning that changes colour constantly is harder to
    read at a glance than one that does not, which is the whole point of the
    feature normally.

    Hue to RGB inline rather than pulling in a colour library, because this is
    six lines and runs per line per frame.
--]]
local RAVE_SPEED = 1.6

local function rave_rgb(t, offset)
    local h = ((t * RAVE_SPEED + (offset or 0)) % 1) * 6
    local i = math.floor(h)
    local f = h - i
    local q = 1 - f

    if i == 0 then return 255, math.floor(f * 255), 0 end
    if i == 1 then return math.floor(q * 255), 255, 0 end
    if i == 2 then return 0, 255, math.floor(f * 255) end
    if i == 3 then return 0, math.floor(q * 255), 255 end
    if i == 4 then return math.floor(f * 255), 0, 255 end
    return 255, 0, math.floor(q * 255)
end

function T.update(dt)
    if not get_bool("dio_tracers", false) then
        return
    end

    local t = now()
    if not t then
        return
    end

    local me = local_player_unit()
    if not me then
        return
    end

    local from = origin()
    if not from then
        return
    end

    if (t - scanned.at) >= SCAN_INTERVAL then
        scanned.at = t
        scanned.trappers, scanned.hounds = scan()
    end

    local show_trappers = get_bool("dio_tracer_trappers", true)
    local show_hounds = get_bool("dio_tracer_hounds", true)

    if not show_trappers and not show_hounds then
        return
    end

    local Vector3 = g("Vector3")
    local Color = g("Color")
    if not Vector3 or not Color then
        return
    end

    local my_pos = unit_position(me)
    if not my_pos then
        return
    end

    local obj, world, LineObject = ensure_line_object()

    if not obj or not LineObject or not LineObject.add_line then
        return
    end

    -- Reset before adding this frame's lines. Skipping this is how the world
    -- fills up with every line ever drawn.
    if not pcall(LineObject.reset, obj) then
        drop_line_object()
        return
    end

    local up = Vector3.up()
    local rave = get_bool("dio_tracer_rave", false)
    local drew = false

    --[[
        In rave mode every line takes its colour from the clock instead of
        from what it is warning about, with a per-line offset so they are not
        all the same hue at once. The threat colouring is the point of the
        feature, so this is opt-in and off by default.
    --]]
    local function colour_for(default_a, default_r, default_g, default_b, offset)
        if not rave then
            return make_color(default_a, default_r, default_g, default_b)
        end

        local rr, gg, bb = rave_rgb(t, offset)

        return make_color(255, rr, gg, bb)
    end

    local function line(to, a, r, gg, b, offset)
        pcall(LineObject.add_line, obj, colour_for(a, r, gg, b, offset),
            from, to + up * CHEST_OFFSET)
        drew = true
    end

    if show_trappers then
        local list = scanned.trappers
        for i = 1, #list do
            local p = unit_position(list[i])
            if p and Vector3.distance(my_pos, p) <= TRAPPER_MAX then
                --[[
                    Red, and drawn for every trapper regardless of range. The
                    colour is not shared with the hound band on purpose: two
                    threats that want two different reactions should not look
                    the same in peripheral vision.
                --]]
                line(p, 255, 255, 60, 50, i * 0.11)
            end
        end
    end

    if show_hounds then
        local radius = get_number("dio_tracer_hound_range", DEFAULT_POUNCE_RADIUS)
        local list = scanned.hounds

        for i = 1, #list do
            local p = unit_position(list[i])
            if p then
                local dist = Vector3.distance(my_pos, p)

                if dist <= radius then
                    -- Inside pounce range: bright amber, it can leap now.
                    line(p, 255, 255, 175, 40, 0.5 + i * 0.11)
                elseif dist <= (radius + WARNING_BAND) then
                    --[[
                        Closing. Dimmed rather than a different hue, so it
                        reads as "the same thing, not yet" at a glance instead
                        of needing to be told apart.
                    --]]
                    line(p, 110, 255, 175, 40, 0.5 + i * 0.11)
                end
            end
        end
    end

    --[[
        Dispatch even when nothing was added: the reset above has already
        cleared last frame's lines, and dispatching an empty object is what
        makes them disappear. Returning early here would freeze the last frame
        of tracers on screen.
    --]]
    if not pcall(LineObject.dispatch, world, obj) then
        drop_line_object()
    end
end

function T.reset()
    scanned.trappers, scanned.hounds, scanned.at = {}, {}, 0
    line_object, line_world = nil, nil
end

--[[
    Positions of every hound within `range` of the local player.

    Lives here rather than in the sounds module because the scan that finds
    hounds already runs here on its own throttle, and duplicating it would mean
    two walks of the side system per frame for the same answer.

    Returns positions, not units: the caller wants somewhere to put a sound,
    and handing out unit handles invites someone to keep one past its lifetime.
--]]
local range_buffer = {}

function T.hounds_in_range(range)
    for i = #range_buffer, 1, -1 do
        range_buffer[i] = nil
    end

    local Vector3 = g("Vector3")
    local me = local_player_unit()

    if not Vector3 or not me then
        return range_buffer
    end

    local my_pos = unit_position(me)

    if not my_pos then
        return range_buffer
    end

    -- The scan is refreshed by T.update on its own interval. If tracers are
    -- switched off it can go stale, so refresh it here when it has aged out.
    local t = now()

    if t and (t - scanned.at) >= SCAN_INTERVAL then
        scanned.at = t
        scanned.trappers, scanned.hounds = scan()
    end

    local list = scanned.hounds

    for i = 1, #list do
        local p = unit_position(list[i])

        if p and Vector3.distance(my_pos, p) <= (range or 45) then
            range_buffer[#range_buffer + 1] = p
        end
    end

    return range_buffer
end

mod.__dio_tracers = T

return T
