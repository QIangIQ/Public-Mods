local mod = get_mod("DiosHandholder")

--[[
    ========================================================================
    JUMPSCARE
    ========================================================================

    A 1-in-N chance per second of a full-screen animated jumpscare.

    Ported in CONCEPT from PredatedElk6's Balatro mod "1/10000 chance for
    Withered Foxy Jumpscare every second". None of that mod's code is here and
    none of it could be: it is written against LOVE 2D, which is the engine
    Balatro runs on. love.graphics, love.audio, love.keyboard, NFS, SMODS and
    Balatro's own G / Game.update / pseudorandom are all LOVE or Balatro
    globals with no counterpart in Fatshark's Stingray fork.

    What carries over is the idea and the 14 frames. Everything below is
    written against Darktide.

    ------------------------------------------------------------------------
    HOW AN ARBITRARY PNG GETS ON SCREEN IN THIS ENGINE

    It does not, directly. Darktide will not decode a loose image file -
    file:// reaches the bytes and the decoder refuses them, and there is no
    local-file texture loader exposed anywhere. The only route is:

        assets/*.png
          -> SimpleAssets, whose native runtime serves the file over
             127.0.0.1 with Content-Type: image/png, because HTTP is the one
             transport the engine's image decoder accepts
          -> Managers.url_loader, which returns a promise resolving to a
             texture object
          -> style.material_values.texture_map on a "texture" pass using
             content/ui/materials/base/ui_default_base

    That chain, and the reasons for each link, are CustomCrosshairs' work
    (CustomCrosshairs.lua:7-18, crosshair_template.lua:16-26). This module
    follows it because it is the route that works, and credit for finding it
    belongs there.

    THIS BUILD SHIPS ITS OWN COPY of that chain under vendor/simpleassets, so
    there is no hard dependency. The installed SimpleAssets is still preferred
    whenever it exists and the bundled copy is never loaded in that case - see
    DiosHandholder_assets.lua for the gate and for why loading two native
    runtimes in one process is the thing to avoid.

    With neither available the jumpscare still fires as a screen flash and a
    sound, and says so once in the log.

    ------------------------------------------------------------------------
    THE SOUND IS THE MOD'S OWN .OGG NOW

    It did not used to be. The first build played an existing Wwise event -
    play_daemonhost_mutator_awakened_stinger - on the reasoning that Wwise
    only plays events compiled into soundbanks and a loose .ogg therefore
    could not be played at all.

    The first half of that was right and the conclusion was wrong. Wwise
    plays events whose BANK IS RESIDENT, and the daemonhost banks stream in
    with the daemonhost - so in a mission without one the event resolves to
    nothing and fails silently. The animation played, the sound did not, and
    the pcall around the call swallowed the complaint. That is what Win hit
    in testing.

    A loose .ogg cannot be played BY WWISE. It can be played by decoding it
    outside Wwise and pushing the samples at XAudio2, which is what
    SimpleAudio's native runtime does. So assets/jumpscare_sfx.ogg - the
    actual sound from the Balatro mod - now plays through
    DiosHandholder_audio.lua, and that file carries the gate that keeps our
    bundled copy from colliding with an installed SimpleAudio.

    The Wwise event is kept as a last-ditch fallback for when there is no
    audio backend at all. It usually will not fire, for the reason above,
    and it costs nothing to try.

    ------------------------------------------------------------------------
    ON BY DEFAULT, 1 IN 1000 PER SECOND.

    No setting. This build exists to test the scare, so a switch that starts
    off would just be a step between Win and the thing being tested, and the
    chance is picked to fire on its own within a session rather than to be
    fair.

    1/1000 per second is a 50% chance in about 11.5 minutes of being alive
    in a mission, and ~95% across an hour. Rolls only happen while alive and
    in a mission, so hub time does not count toward it.

    /hhscare still fires one on demand.
--]]

local Jump = {}

local FRAME_COUNT = 14
local FRAME_DELAY = 0.07

--[[
    The mod's own sound, decoded off disk. Same "mods/" prefixed form as the
    textures and for the same stack-walking reason - see ASSET_PREFIX below.
--]]
local SCARE_FILE = "mods/Dio's Handholder/assets/jumpscare_sfx.ogg"

-- Only reached when there is no audio backend at all. See the header.
local SCARE_SOUND = "wwise/events/minions/play_daemonhost_mutator_awakened_stinger"

--[[
    Hardcoded, not settings. One roll per second, 1 in CHANCE to fire.
--]]
local ROLL_INTERVAL = 1
local CHANCE = 1000

--[[
    Always the "mods/" prefixed form.

    A bare relative path makes SimpleAssets infer the calling mod by walking
    the Lua stack for "/mods/<name>/scripts/", and that walk stops at the
    first frame that does not match - so any C frame in between, a pcall
    being the easiest one to introduce, resolves the path against
    SimpleAssets' own folder instead. The prefixed form is resolved straight
    from the mods directory and never consults the caller.
--]]
local ASSET_PREFIX = "mods/Dio's Handholder/assets/"

local MAX_ATTEMPTS = 3

-- frame index -> { texture = <userdata>, width, height }
local frames = {}
local pending = {}
--[[
    load_state is the coarse phase; load_backend is which texture backend the
    requests actually went to. Kept apart because the frame COUNT must not be
    baked into either - Jump.state() computes that on read.
--]]
local load_state = "not started"
local load_backend = "unknown"

local active = false
local scare_timer = 0
local frame_index = 1
local frame_timer = 0
local roll_timer = 0

local function g(name)
    return rawget(_G, name)
end

--[[
    UrlLoaderManager caches per url, FAILURES INCLUDED and permanently: a
    second load for a url it has already rejected returns the cached rejection
    without touching the network. Dropping the entry is the only way to make a
    retry mean anything, and unload_texture is what drops it once the
    reference our failed attempt added falls back to zero.
--]]
local function forget_failed_url(url)
    if type(url) ~= "string" or url == "" then
        return
    end

    local url_loader = Managers and Managers.url_loader

    if url_loader then
        pcall(function()
            url_loader:unload_texture(url)
        end)
    end
end

local function request_frame(assets, entry)
    local promise = assets.load_texture(ASSET_PREFIX .. entry.file)

    --[[
        nil means there is no texture backend at all on this install, which is
        permanent - requeueing would spin forever. A rejected promise is a
        per-file failure and IS worth retrying; that path is below.

        The state change is the point. This used to be a bare return, so a
        backend that reported itself healthy and then failed every request
        left load_state saying "requested" forever - /hhscare printed "0/14
        still fetching" for a session in which nothing was ever fetching.
        The gate logs the underlying cause; this records that it happened.
    --]]
    if not promise then
        load_state = "texture backend refused the request - see the log"
        return
    end

    promise:next(function(data)
        if data and data.is_ok and data.texture then
            frames[entry.index] = {
                texture = data.texture,
                width   = data.width,
                height  = data.height,
                url     = data.url,
            }
        else
            --[[
                Resolved without a texture means the file was reached and
                could not be decoded. Retrying cannot change that.
            --]]
            mod:error("[jumpscare] could not decode %s", tostring(entry.file))
        end
    end, function(err)
        local url = type(err) == "table" and tostring(err.url) or nil

        forget_failed_url(url)

        entry.attempts = entry.attempts + 1

        if entry.attempts < MAX_ATTEMPTS then
            pending[#pending + 1] = entry
            return
        end

        mod:error("[jumpscare] gave up on %s after %d attempts",
            tostring(entry.file), entry.attempts)
    end)
end

--[[
    Swaps the queue out before requesting, because a failed request pushes its
    entry straight back on and appending to the list being walked would retry
    the same frame forever inside one tick.
--]]
local function pump_queue()
    if #pending == 0 then
        return
    end

    local assets = mod.__dio_assets

    if not assets then
        load_state = "asset loader not loaded"
        return
    end

    if assets.backend() == "none" then
        load_state = "no texture backend"
        pending = {}
        return
    end

    local batch = pending
    pending = {}

    for i = 1, #batch do
        request_frame(assets, batch[i])
    end

    --[[
        NOT a frame count. Counting here was the bug: this line runs the
        instant the requests go out, when by definition zero have come back,
        and pump_queue then returns early forever because the queue is empty -
        so the string froze at "0/14" and /hhscare reported that for the rest
        of the session while the animation played perfectly.

        The count belongs in Jump.state(), computed on read. All this needs to
        record is which backend the requests went to.
    --]]
    load_backend = tostring(assets.backend())
    load_state = "requested"
end

function Jump.loaded()
    local n = 0

    for i = 1, FRAME_COUNT do
        if frames[i] then
            n = n + 1
        end
    end

    return n
end

function Jump.frame(i)
    local f = frames[i]

    return f and f.texture or nil
end

--[[
    Computed on read, never cached. The textures arrive asynchronously long
    after the requests go out, so any status string built at request time is
    wrong by construction - see the note in pump_queue.
--]]
function Jump.state()
    if load_state ~= "requested" then
        return load_state
    end

    local n = Jump.loaded()

    if n == FRAME_COUNT then
        return string.format("all %d frames loaded via %s",
            FRAME_COUNT, tostring(load_backend))
    end

    return string.format("%d/%d frames loaded via %s%s",
        n, FRAME_COUNT, tostring(load_backend),
        n == 0 and " (still fetching, or they failed - check the log)" or " (still fetching)")
end

--[[
    Queued, not loaded, at module load. The textures arrive asynchronously
    over a local HTTP request, so nothing here blocks and nothing here touches
    SimpleAssets during new_mod - the whole point of the last round of fixes
    was that mod-load-time side effects are what break other people's games.
--]]
function Jump.begin_load()
    if load_state ~= "not started" then
        return
    end

    load_state = "queued"

    for i = 1, FRAME_COUNT do
        pending[#pending + 1] = {
            index = i,
            file = "jumpscare_" .. i .. ".png",
            attempts = 0,
        }
    end
end

--[[
    The fallback, and the reason it is only the fallback: the event's bank
    has to already be resident. See the header.
--]]
local function play_wwise_fallback()
    local Wwise = g("Wwise")
    local WwiseWorld = g("WwiseWorld")
    local wm = Managers and Managers.world

    if not Wwise or not WwiseWorld or not wm or not wm.has_world
        or not wm:has_world("level_world") then
        return
    end

    local ok_w, world = pcall(wm.world, wm, "level_world")

    if not ok_w or not world then
        return
    end

    local ok_ww, wwise_world = pcall(Wwise.wwise_world, world)

    if not ok_ww or not wwise_world then
        return
    end

    --[[
        A 2D source at the listener rather than a positional one: this is not
        a thing in the world, it is a thing happening to you.
    --]]
    pcall(WwiseWorld.trigger_resource_event, wwise_world, SCARE_SOUND)
end

local function play_sound()
    local audio = mod.__dio_audio

    --[[
        audio_type "sfx" so the sound rides the player's SFX slider and their
        master volume. A jumpscare that ignores the volume settings of
        someone who turned the game down is not a joke, it is a hazard.
    --]]
    if audio and audio.play_file(SCARE_FILE, { audio_type = "sfx" }) then
        return
    end

    play_wwise_fallback()
end

function Jump.trigger()
    active = true
    scare_timer = FRAME_COUNT * FRAME_DELAY
    frame_index = 1
    frame_timer = 0

    play_sound()
end

function Jump.active()
    return active
end

function Jump.current_frame()
    return frame_index
end

--[[
    Driven from the mod's own per-frame hook, so there is one place that
    decides how often anything in this mod runs.
--]]
function Jump.update(dt)
    Jump.begin_load()
    pump_queue()

    --[[
        Warms the audio backend on the first tick and pumps it on every one
        after. Both are no-ops once there is nothing to do, and the warm-up
        deliberately does not happen at mod load - loading a native DLL
        during new_mod is the thing that broke someone else's SoloPlay.
    --]]
    local audio = mod.__dio_audio

    if audio then
        audio.warm()
        audio.update(dt)
    end

    if active then
        scare_timer = scare_timer - dt

        if scare_timer <= 0 then
            active = false
        else
            frame_timer = frame_timer + dt

            if frame_timer >= FRAME_DELAY then
                frame_timer = frame_timer - FRAME_DELAY
                frame_index = frame_index + 1

                --[[
                    Clamped to the last frame rather than looping. The timer is
                    already sized to the animation, so a second pass cannot
                    start - clamping just makes the final frame hold cleanly
                    instead of snapping back to frame one on the last tick.
                --]]
                if frame_index > FRAME_COUNT then
                    frame_index = FRAME_COUNT
                end
            end
        end

        return
    end

    --[[
        THE ROLL. Only while alive and in a mission - a jumpscare in the
        Mourningstar is just confusing, and one while you are already dead is
        not funny.
    --]]
    if not mod.unit_is_alive_local or not mod.unit_is_alive_local() then
        return
    end

    roll_timer = roll_timer + dt

    if roll_timer < ROLL_INTERVAL then
        return
    end

    --[[
        Subtract rather than zero, so a frame that overshoots the interval
        does not quietly shorten the next second. Over a long session zeroing
        would drift the real rate above 1 roll/sec.
    --]]
    roll_timer = roll_timer - ROLL_INTERVAL

    if math.random() < (1 / CHANCE) then
        Jump.trigger()
    end
end

--[[
    Reports both backends before firing, because the two failure modes look
    identical from the couch: no animation means the texture chain, no sound
    means the audio chain, and each has its own three states.
--]]
mod:command("hhscare", "fire the jumpscare once, for testing", function()
    local assets = mod.__dio_assets
    local audio = mod.__dio_audio

    mod:echo(string.format("[Dio] frames: %s (via %s)",
        Jump.state(),
        assets and tostring(assets.backend()) or "asset loader not loaded"))

    mod:echo(string.format("[Dio] sound: %s",
        audio and audio.describe() or "audio loader not loaded"))

    --[[
        Warm on demand too. Without this, /hhscare run in the first seconds
        of a session reports "still loading FFmpeg" and plays nothing, which
        reads as a failure rather than as "ask again in a moment".
    --]]
    if audio then
        audio.warm()
    end

    Jump.trigger()
end)

mod.__dio_jumpscare = Jump

return Jump
