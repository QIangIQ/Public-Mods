local mod = get_mod("DiosHandholder")

--[[
    SINGLETON. io_dofile RE-EXECUTES THE FILE.

    Three call sites were each doing io_dofile on this module - the main file
    twice and the nameplate once - and every one of them got a SEPARATE table
    with its own tick history. So the nameplate sampled one copy, the squad HUD
    sampled another, and /hhbleed printed the state of a third that nothing
    ever sampled at all.

    That is not just wasted work. It is why this feature was impossible to
    diagnose: the numbers being drawn and the numbers being printed came from
    different objects, so the diagnostic could never disagree with the display
    in a way that pointed at anything.

    Publishing on the mod and returning early makes every caller share one
    history. A mod reload builds a fresh DMFMod, so the flag clears with it.
--]]
if mod.__dio_bleedout then
    return mod.__dio_bleedout
end

local Tags = mod:io_dofile("Dio's Handholder/scripts/mods/DiosHandholder/DiosHandholder_tags")

--[[
    Time until a downed teammate actually dies.

    ===========================================================================
    THE BUG THAT MADE THE OLD COUNTDOWN REPORT ~1500 SECONDS
    ===========================================================================

    It was not the arithmetic. It was the gate.

    The sampler ran on Tags.is_downed(), which is true for the whole "needs
    help" family - knocked down, hogtied, NETTED, POUNCED, ledge-hanging,
    warp-grabbed, dead. Only ONE of those has a bleedout pool.

    A netted or pounced player is not knocked down. Their health extension
    still reports their NORMAL health pool, which is not draining on a timer at
    all - netted_damage_tick fires once every five seconds and is ordinary
    damage against ordinary health. So the sampler measured a near-zero drain
    rate against a full health pool and divided one by the other. 150 / 0.1 is
    1500. The number was an honest answer to the wrong question.

    The percentage had the same fault and hid it better: a bounded 0-1 ratio
    looks plausible whatever pool it came from, so "63%" of a netted player's
    ordinary health read as a bleedout figure and nobody could tell.

    Everything below is gated on is_knocked_down - the single character state
    that actually has a bleedout pool - and the countdown is back.

    ===========================================================================
    WHY THE RATE IS COUNTED IN TICKS, NOT SECONDS
    ===========================================================================

    From player_buff_templates.lua, knocked_down_damage_tick is an
    interval_buff with interval = 2. Bleedout is not a continuous drain; it is
    a discrete hit every two seconds, and its size scales with the distance to
    the NEAREST living teammate:

        lerp_t      = normalize_01(closest_distance_sq, 2500, 22500)
        power_level = lerp(MIN_POWER_LEVEL, MAX_POWER_LEVEL, lerp_t)

    The old code divided damage by elapsed WALL TIME over a sliding window.
    Against a discrete tick that is systematically wrong: a 5-second window
    containing two ticks reports drained/5 when the real rate is drained/4, and
    a window that happens to land between ticks reports zero.

    Since every observed drop IS one tick and ticks are exactly 2s apart,
    dividing by (ticks x 2) instead of by wall time removes the error entirely.
    No window tuning, no minimum span, and a reading is available after the
    second tick rather than after an arbitrary 2.5 seconds.

    The last few ticks are averaged rather than just the latest, because the
    rate moves with the team and a single tick taken as someone sprints past is
    not representative. Three is enough to smooth that without lagging a real
    change in distance.

    ===========================================================================
    WHAT "NO NUMBER" MEANS

    interval_func returns early when the player is being assisted, so the pool
    stops draining during a revive. That produces no ticks, so no rate, so no
    countdown - which is correct: someone being picked up has no meaningful
    time of death. nil, not a large number.
--]]

local B = {}

local TICK_INTERVAL = 2.0   -- knocked_down_damage_tick: interval = 2
local TICKS_AVERAGED = 3    -- how many recent ticks feed the rate
local MIN_TICKS = 1         -- one tick is enough to say something
local SAMPLE_DT = 0.1       -- 10Hz; far finer than a 2s tick needs
local STALE_AFTER = 6.0     -- ticks older than this stop counting

--[[
    Per unit, weak-keyed so a despawning player is not pinned in memory.
--]]
local tracked = setmetatable({}, { __mode = "k" })

local function now()
    local t = Managers and Managers.time
    if not t then
        return nil
    end
    local ok, v = pcall(t.time, t, "gameplay")
    return ok and v or nil
end

--[[
    current_health() is correct on BOTH extension types while knocked down.

    PlayerUnitHealthExtension (you) and PlayerHuskHealthExtension (teammates)
    both branch on _is_knocked_down internally, returning the knocked-down pool
    and knocked_down_damage rather than the normal ones. The husk syncs both
    from the game object every fixed_update.

    Note that the husk's max_health takes NO argument - the old code called
    max_health(true) expecting the local extension's force_knocked_down_health
    parameter, which a teammate's extension silently ignores. It happened not
    to matter, because the husk already branches on _is_knocked_down, but it
    was a call written against the wrong signature and is not repeated here.
--]]
local function health_of(unit)
    local ext = ScriptUnit.has_extension(unit, "health_system")
    if not ext then
        return nil, nil
    end

    local ok_h, hp = pcall(ext.current_health, ext)
    local ok_m, mx = pcall(ext.max_health, ext)

    if not ok_h or not ok_m or type(hp) ~= "number" or type(mx) ~= "number" then
        return nil, nil
    end

    return hp, mx
end

local function forget(unit)
    if unit then
        tracked[unit] = nil
    end
end

--[[
    Sampling is driven from the nameplate/HUD update rather than its own timer,
    so it only runs while something is actually displaying a downed teammate.
--]]
function B.sample(player)
    local unit = player and player.player_unit
    if not Tags.unit_alive(unit) then
        return
    end

    --[[
        THE GATE. is_knocked_down, not is_downed - see the header. A netted or
        pounced teammate is cleared rather than sampled, so a later genuine
        knockdown starts from an empty history instead of inheriting readings
        taken against their normal health pool.
    --]]
    if not Tags.is_knocked_down(player) then
        forget(unit)
        return
    end

    local t = now()
    if not t then
        return
    end

    local hp, mx = health_of(unit)
    if not hp then
        return
    end

    local entry = tracked[unit]
    if not entry then
        entry = { hp = hp, max = mx, last = 0, ticks = {}, n = 0 }
        tracked[unit] = entry
    end

    --[[
        The epsilon is not fussiness. Gameplay time arrives as a float and
        accumulates rounding, so a gap that should be exactly SAMPLE_DT often
        computes as 0.0999999996 and the sample is dropped. When the dropped
        frame is the one a tick landed on, the tick is registered late - the
        total is still right, but the count is briefly wrong and the countdown
        stalls for a frame. Cheaper to widen the gate than to explain that.
    --]]
    if entry.last ~= 0 and (t - entry.last) < (SAMPLE_DT - 0.001) then
        return
    end
    entry.last = t
    entry.max = mx

    --[[
        A DROP IS A TICK.

        Any decrease in the knocked-down pool is recorded as one tick's worth
        of damage. That deliberately includes enemies still hitting the downed
        player: it is damage to the same pool on the same clock, and pretending
        otherwise would under-report exactly when the countdown matters most.

        An INCREASE means the pool was refilled - a revive completed, or the
        knocked-down max changed - so the history is dropped rather than
        recorded as a negative tick.
    --]]
    local delta = entry.hp - hp
    entry.hp = hp

    if delta < 0 then
        entry.ticks, entry.n = {}, 0
        return
    end

    if delta > 0 then
        local n = entry.n + 1
        entry.ticks[n] = { t = t, d = delta }
        entry.n = n

        -- Keep only the most recent few; shifting a table this small is
        -- cheaper and clearer than maintaining a circular index.
        if n > TICKS_AVERAGED then
            for i = 1, TICKS_AVERAGED do
                entry.ticks[i] = entry.ticks[i + (n - TICKS_AVERAGED)]
            end
            for i = TICKS_AVERAGED + 1, n do
                entry.ticks[i] = nil
            end
            entry.n = TICKS_AVERAGED
        end
    end
end

--[[
    Damage per second, or nil when the pool is not draining.

    Ticks older than STALE_AFTER are discarded rather than averaged, so a
    revive that starts and then gets interrupted does not blend a stale
    pre-revive rate into the new one.
--]]
local function rate_of(entry, t)
    if not entry or entry.n < MIN_TICKS then
        return nil
    end

    local total, counted, latest = 0, 0, 0
    for i = 1, entry.n do
        local tick = entry.ticks[i]
        if tick and (t - tick.t) <= STALE_AFTER then
            total = total + tick.d
            counted = counted + 1
            latest = tick.d
        end
    end

    if counted < MIN_TICKS or total <= 0 then
        return nil
    end

    --[[
        THE WORSE OF THE TWO, DELIBERATELY.

        A three-tick mean smooths noise, but it also lags a real change - and
        the change that matters is the team running off and the drain
        tripling. Averaged, the countdown said 8 seconds while the true figure
        was 4.8, which is the one direction this number must never err in. A
        rescue timer that over-promises gets someone killed; one that
        under-promises makes you hurry.

        So the rate is the larger of the latest tick and the recent mean. On
        the way up the latest tick wins immediately; on the way down the mean
        holds the estimate conservative for a tick or two while the team
        closes, which is the safe side of the same trade.

        Each counted drop is one 2-second interval. Dividing by wall time is
        what made the old number wrong; dividing by the interval is exact.
    --]]
    local mean = total / counted

    return math.max(latest, mean) / TICK_INTERVAL
end

--[[
    Seconds until death, or nil when it cannot be said honestly.

    nil rather than a large number: a teammate being revived, or one nobody is
    near between ticks, has no meaningful countdown, and inventing one would be
    worse than showing nothing.
--]]
function B.time_left(player)
    local unit = player and player.player_unit
    if not Tags.unit_alive(unit) or not Tags.is_knocked_down(player) then
        return nil
    end

    local entry = tracked[unit]
    local t = now()
    if not entry or not t then
        return nil
    end

    local rate = rate_of(entry, t)
    if not rate then
        return nil
    end

    local hp = entry.hp
    if hp <= 0 then
        return 0
    end

    --[[
        The elapsed part of the current interval is subtracted, so the number
        counts DOWN between ticks instead of sitting still for two seconds and
        then jumping. Clamped at zero: the next tick may be bigger than the
        last, and a negative countdown is not information.
    --]]
    local last_tick = entry.ticks[entry.n]
    local since = last_tick and (t - last_tick.t) or 0

    return math.max(0, hp / rate - math.min(since, TICK_INTERVAL))
end

--[[
    Fraction of the bleedout pool remaining, 0-1, or nil.

    Kept as the fallback for the first two seconds, before any tick has been
    observed and a countdown can be stated. Now gated on is_knocked_down like
    everything else - previously this happily reported a NETTED teammate's
    ordinary health percentage as though it were a bleedout figure.
--]]
function B.pool_fraction(player)
    local unit = player and player.player_unit
    if not Tags.unit_alive(unit) or not Tags.is_knocked_down(player) then
        return nil
    end

    local hp, mx = health_of(unit)
    if not hp or not mx or mx <= 0 then
        return nil
    end

    return math.max(0, math.min(1, hp / mx))
end

--[[
    What the nameplate should actually print, as a short string, or nil.

    Centralised here rather than formatted at each call site: the main HUD and
    the world nameplate were both deciding this independently and could drift.

    Seconds when a rate is known, percentage until then. The percentage is
    marked with a % and the countdown with an s, so the two cannot be confused
    at a glance.
--]]
function B.label(player)
    local secs = B.time_left(player)
    if secs then
        return string.format("%ds", math.floor(secs + 0.5)), secs
    end

    local frac = B.pool_fraction(player)
    if frac then
        return string.format("%d%%", math.floor(frac * 100 + 0.5)), nil
    end

    return nil, nil
end

--[[
    Urgency colour for the label. Driven by SECONDS when seconds are known,
    because "ten seconds left" means the same thing regardless of how big the
    pool was, whereas a percentage does not.
--]]
function B.urgency_rgb(player, secs)
    if secs then
        if secs <= 10 then
            return 255, 70, 60
        elseif secs <= 25 then
            return 255, 190, 80
        end
        return 235, 235, 235
    end

    local frac = B.pool_fraction(player)
    if frac then
        if frac <= 0.25 then
            return 255, 70, 60
        elseif frac <= 0.55 then
            return 255, 190, 80
        end
    end

    return 235, 235, 235
end

--[[
    Raw numbers, for checking this against reality rather than guessing at it.
--]]
function B.debug(player)
    local unit = player and player.player_unit
    if not Tags.unit_alive(unit) then
        return "unit not alive"
    end

    local ext = ScriptUnit.has_extension(unit, "health_system")
    if not ext then
        return "no health extension"
    end

    local ok_h, hp = pcall(ext.current_health, ext)
    local ok_m, mx = pcall(ext.max_health, ext)
    local state = Tags.character_state(player)
    local kd = Tags.is_knocked_down(player)

    local entry = tracked[unit]
    local t = now()
    local rate = (entry and t) and rate_of(entry, t) or nil

    return string.format(
        "state=%s knocked_down=%s | hp=%s max=%s | ticks=%d rate=%s | left=%s",
        tostring(state), tostring(kd),
        tostring(ok_h and hp), tostring(ok_m and mx),
        entry and entry.n or 0,
        rate and string.format("%.2f/s", rate) or "n/a",
        tostring(B.time_left(player)))
end

function B.reset()
    for k in pairs(tracked) do
        tracked[k] = nil
    end
end

-- Published BEFORE the return so the guard at the top of this file sees it on
-- every subsequent io_dofile, whichever call site gets here first.
mod.__dio_bleedout = B

return B
