local mod = get_mod("DiosHandholder")

--[[
    ========================================================================
    TEXTURE LOADING: REAL SimpleAssets FIRST, VENDORED COPY ONLY AS FALLBACK
    ========================================================================

    This mod ships a trimmed copy of SimpleAssets under vendor/simpleassets so
    the jumpscare works with nothing else installed. That copy is a LAST
    RESORT and is never touched when the real mod is present.

    WHY THE ORDER MATTERS, AND IT IS NOT POLITENESS

    SimpleAssets is not Lua. bin/simple-assets-runtime.dll is a native runtime
    that stands up a local HTTP server, because serving the file over
    127.0.0.1 is the only way this engine will decode an image that is not in
    a game bundle. Loading a SECOND copy of that DLL, from a second path,
    means a second native runtime inside one process:

      * ffi.load on a different file path is a different module to Windows,
        so the loader will not hand back the already-loaded instance
      * two runtimes means two servers, which means either a second port or a
        bind failure on the first
      * whichever way that resolves, it resolves differently on different
        machines, which is the category of bug this project has spent days on

    So: if get_mod("SimpleAssets") answers and can load a texture, that is the
    one used, and vendor/ is never read. Our DLL is never loaded. There is
    nothing to conflict with because nothing of ours is running.

    WHAT WAS CHANGED IN THE VENDORED COPY

    Four mechanical rewrites, no logic:

        get_mod("SimpleAssets")              -> get_mod("DiosHandholder")
        io_dofile "SimpleAssets/scripts/..." -> "Dio's Handholder/vendor/..."
        the DLL path                         -> our vendor bin
        mod._simple_assets_native_runtime    -> mod._dio_vendored_sa_runtime

    That last rename is deliberate. If both copies were ever somehow live, a
    shared cache key would let one hand the other its runtime handle. Separate
    keys means separate state, and a bug there stays visible instead of
    turning into an action at a distance.

    Only the texture chain is vendored - ten files. Fonts, video, slug albums
    and mouse cursors are left behind because every vendored file is a file
    that has to be kept in step with upstream by hand.

    CREDIT: SimpleAssets is not this project's work. It is included here
    because this is a private test build and Win asked for it to be
    self-contained. It should not be redistributed on that basis.
--]]

local Assets = {}

local VENDOR = "Dio's Handholder/vendor/simpleassets/"

local backend = nil       -- "simpleassets" | "vendor" | "none"
local loader = nil        -- function(path) -> promise
local reported_failure = false

--[[
    Resolved once and cached, because the answer cannot change mid-session:
    DMF has finished loading mods long before anything here is called, so a
    SimpleAssets that is not there now will not appear later.

    Called lazily from the first texture request rather than at mod load.
    Nothing in this file runs during new_mod - which is the rule that came out
    of the last round of "your mod broke my other mod", and vendoring a native
    runtime is exactly the kind of thing that must not run early.
--]]
local function resolve()
    if backend then
        return
    end

    local sa = get_mod("SimpleAssets")

    if sa and type(sa.load_texture) == "function" then
        backend = "simpleassets"
        loader = function(path)
            return sa.load_texture(path)
        end

        mod:info("[assets] using the installed SimpleAssets")
        return
    end

    --[[
        No SimpleAssets. Load our own chain, inside pcall - the DLL may be
        missing, blocked by antivirus, or refused on a non-Windows install,
        and none of those should do more than cost the animation.

        THE RUNTIME HAS TO BE STARTED, AND THAT IS NOT PART OF LOADING THESE
        MODULES.

        This is the bug that shipped. SimpleAssets.lua - the mod's entry file,
        which is NOT vendored because it is mostly demo views and loaders we
        do not use - calls native_runtime.initialize() on its fourth line,
        before anything else. initialize() calls SimpleAssetsRuntime_Start(),
        and THAT is what stands up the 127.0.0.1 server every texture request
        goes through.

        Vendoring texture/loading.lua and calling load_texture on it without
        that start looks like it works and does nothing: get_asset_path ->
        canonical_asset_path -> runtime_or_error(), which raises because
        state.runtime was never populated. Zero HTTP requests, zero frames,
        and - because the raise was caught two layers up and discarded - zero
        log lines. A silent, invisible failure, which is the worst kind.

        The audio gate got this right because SimpleAudio's equivalent is
        named start_initialize and is impossible to miss. This one is a
        one-liner at the top of a file I chose not to vendor.
    --]]
    local ok, result = pcall(function()
        local native = mod:io_dofile(VENDOR .. "runtime/native")

        local started, start_error = native.initialize()

        if not started then
            error(tostring(start_error), 0)
        end

        return mod:io_dofile(VENDOR .. "texture/loading")
    end)

    if ok and type(result) == "table"
        and type(result.load_texture) == "function" then
        backend = "vendor"
        loader = result.load_texture

        mod:info("[assets] SimpleAssets not installed - using the bundled copy")
        return
    end

    backend = "none"
    loader = nil

    mod:warning("[assets] no texture backend available: %s",
        ok and "bundled copy did not export load_texture" or tostring(result))
end

--[[
    Returns a promise, or nil when there is no backend at all.

    nil rather than a rejected promise so callers can tell "cannot load
    images on this install" from "this particular image failed", which are
    different problems with different responses - the first is permanent and
    should stop the queue, the second is worth a retry.
--]]
function Assets.load_texture(path)
    resolve()

    if not loader then
        return nil
    end

    local ok, promise = pcall(loader, path)

    --[[
        SAY SO. This pcall silently returning nil is half of why a runtime
        that was never started looked like nothing happening at all - the
        other half being request_frame dropping a nil promise without a word.

        Reported once per session rather than once per request, because the
        failure is per-install and fourteen identical lines is not fourteen
        times the information.
    --]]
    if not ok then
        if not reported_failure then
            reported_failure = true

            mod:error("[assets] texture request raised (backend=%s): %s",
                tostring(backend), tostring(promise))
        end

        return nil
    end

    return promise
end

function Assets.backend()
    resolve()

    return backend
end

mod.__dio_assets = Assets

return Assets
