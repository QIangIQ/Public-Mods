local mod = get_mod("DiosHandholder")

local Tags = mod:io_dofile("Dio's Handholder/scripts/mods/DiosHandholder/DiosHandholder_tags")

--[[
    Class-coloured ally outlines.

    The point is the downed-teammate case: with two zealots on the team, "res
    the zealot" is ambiguous, but a red silhouette versus a blue one is not.

    APPROACH TAKEN FROM CareerColourOutlines, which does this properly. My first
    version was worse in three specific ways and this replaces it wholesale:

    1. It used Unit.set_vector3_for_material (singular) and therefore had to
       hardcode the material layer names - player_outline_general,
       player_outline_knocked_down and so on - which meant it silently stopped
       working the moment a player entered a state that used a different layer
       set. set_vector3_for_materials (PLURAL) writes the variable across every
       material on the unit, so no layer table is needed and no state is missed.

    2. It ran on its own 4Hz timer, wrote once, and assumed nothing would
       overwrite it. The engine rewrites outline colours when the top outline
       changes, so that assumption fails whenever an outline is added or
       removed. Hooking OutlineSystem.update instead means the colour is
       reasserted on the system's own schedule, immediately after any engine
       write.

    3. It iterated every player. The system already keeps _unit_extension_data,
       which is exactly the set of units that currently HAVE an outline, so
       iterating that is both smaller and correct by construction - a unit with
       no outline cannot be coloured anyway.

    The one deliberate difference from CareerColourOutlines: it colours by
    PLAYER SLOT (UISettings.player_slot_colors), which is the game's own
    1/2/3/4 colouring. This colours by CLASS, so the outline matches the class
    colour used in the team strip and the nameplates - the association being
    the entire point.
--]]

local O = {}

--[[
    Note the plural. set_vector3_for_materialS applies to all materials on the
    unit; the singular form takes one named layer. The trailing `true` includes
    child units, which is what carries the colour onto attached gear rather
    than just the body.
--]]
local set_outline_color = Unit.set_vector3_for_materials

--[[
    Vector3 is built FRESH on every call. Do not cache it.

    I previously cached one per player "to avoid allocating every frame". That
    caused thousands of errors per second:

        Vector3 expected, got userdata

    Vector3 in this engine is a FRAME-TEMPORARY value. Holding one past the
    frame it was created in leaves a stale handle that engine functions reject -
    the same trap that produced the userdata errors in HavocTracker earlier.
    Anything kept across frames has to be a Vector3Box, and for three numbers
    that is not worth it.

    CareerColourOutlines constructs its colour vector inline on every call and
    is correct for exactly this reason. The RGB lookup is cached instead, which
    is the part that is actually a table walk; building the Vector3 from three
    numbers is trivial.
--]]
local rgb_cache = setmetatable({}, { __mode = "k" })

local function class_vector(player)
    local rgb = rgb_cache[player]
    if not rgb then
        rgb = Tags.class_color(player)
        rgb_cache[player] = rgb
    end

    --[[
        Brightness multiplier, settable.

        The class colours are chosen to read on a dark HUD panel; applied to a
        glowing world outline the same values come out hotter than intended.
        Scaling here rather than editing the class table keeps the outline and
        the panel the same HUE - only the intensity differs, so a teammate is
        still recognisably the same colour in both places.
    --]]
    local k = (tonumber(mod:get("dio_outline_brightness")) or 70) / 100

    -- Constructed here, used immediately, never stored.
    return Vector3((rgb[1] / 255) * k, (rgb[2] / 255) * k, (rgb[3] / 255) * k)
end

--[[
    NOT IN THE MOURNINGSTAR.

    Found in the profiler, not guessed at. The Aug 24 session logged 195
    main-thread stalls at an exact 2.0-second cadence, each around 170 ms, each
    tracing to "Lua->update" - and 195 of them were in the HUB against 1 in a
    mission. The hub holds twenty to thirty other players in full cosmetics
    streaming in and out on a timer, and the forcing below was treating every
    one of them as a teammate to outline and recolour.

    Nothing about this feature is useful in the social space - it exists so you
    can tell which downed zealot is which - so it is simply switched off there.
--]]
local function game_mode_name()
    local gm = Managers and Managers.state and Managers.state.game_mode

    if not gm or not gm.game_mode_name then
        return nil
    end

    local ok, name = pcall(gm.game_mode_name, gm)

    return ok and name or nil
end

local function outlines_allowed()
    return game_mode_name() ~= "hub"
end

--[[
    Rewrite throttle.

    set_vector3_for_materials with the child-unit flag walks the whole unit
    hierarchy - body plus every piece of attached gear, every material on each -
    and it was running for every outlined unit every frame. The colour is a
    constant per player, so almost all of that was rewriting the same value.

    It still has to be re-asserted rather than written once, because the engine
    rewrites outline colours whenever the top outline changes. So: write when
    the top outline changes, and otherwise refresh at 4 Hz. That keeps the
    correctness the frame-by-frame version had for ~7% of the calls.
--]]
local REFRESH_INTERVAL = 0.25
local last_write = setmetatable({}, { __mode = "k" })

-- Forward declaration: defined below, but captured by the update hook above it.
local ensure_downed_outline

--[[
    hook_safe: this runs inside the engine's own outline update. A throw here
    would propagate into the system rather than into mod code, and failing to
    colour an outline is invisible where taking the outline system down is not.
--]]
--[[
    THE SETTING IS CACHED, NOT READ PER FRAME.

    This hook runs every frame. DMFMod:get is a method call into DMF's settings
    store that resolves the mod name and does two table lookups before it
    returns - and for a table-valued setting it CLONES on every read. It is not
    a field access, and putting one on the first line of a per-frame hook means
    paying for it sixty times a second to learn something that changes only
    when the options menu is open.

    _enabled is refreshed by on_setting_changed below, which DMF fires on every
    change, so the cached value cannot go stale. nil means "not read yet", so
    the first frame still resolves it properly rather than assuming a default.
--]]
local _enabled = nil

local function outlines_enabled()
    if _enabled == nil then
        _enabled = mod:get("dio_class_outlines") ~= false
    end
    return _enabled
end

mod.refresh_outline_setting = function()
    _enabled = nil
end

mod:hook_safe("OutlineSystem", "update", function(self, context, dt, t)
    if not outlines_enabled() or not outlines_allowed() then
        return
    end

    -- Nothing outlined, or outlines globally hidden: nothing to do, and both
    -- checks are cheaper than walking the table.
    if self._total_num_outlines == 0 or not self._visible then
        return
    end

    local pm = Managers and Managers.player
    if not pm then
        return
    end

    --[[
        ITERATE PLAYERS, NOT OUTLINED UNITS.

        CareerColourOutlines walks self._unit_extension_data and calls
        player_by_unit on each entry, and I copied that. Reading
        OutlineSystem.on_add_extension shows why that is the wrong loop here:
        the table holds every unit that has an outline EXTENSION, not every
        unit that is currently outlined - so every minion carrying one for
        smart-tag purposes is in it. With an enemy outliner mod also running,
        that is a hundred-plus player_by_unit calls per frame to find at most
        three teammates.

        Worse, player_by_unit is not a lookup - PlayerManager defines it as a
        linear scan of human players and then bot players, comparing
        player.player_unit each time. So the old loop was units-with-outline-
        extensions MULTIPLIED BY players, every frame, to find three teammates.

        There are never more than four players. Looping those and indexing into
        the table is the same result for a fixed, tiny cost.
    --]]
    local unit_extension_data = self._unit_extension_data
    local players = pm:players()

    --[[
        local_player_safe, NOT local_player, and this hook runs every frame.

        PlayerManager.local_player calls Network.peer_id(), which faults
        UNCATCHABLY outside a session - pcall does not save you from it, as
        this project has already established twice elsewhere. Wrapping it in a
        pcall looked safe and was not; this hook is one of the few places that
        still had the unsafe form.

        local_player_safe answers the same question without the network call,
        so this is both correct and cheaper on a per-frame path.
    --]]
    local ok_lp, local_player = pcall(pm.local_player_safe, pm, 1)
    local local_unit = ok_lp and local_player and local_player.player_unit or nil

    for _, player in pairs(players) do
        -- A FIELD, not a method: PlayerManager.player_by_unit compares
        -- `player.player_unit` directly. Calling it would throw.
        local unit = player.player_unit

        -- Skipped for the same reason extensions_ready skips it: you cannot
        -- see your own silhouette, so there is nothing to colour.
        if unit and unit ~= local_unit and ALIVE[unit] then
            local extension = unit_extension_data[unit]
            local top_outline = extension and extension.outlines and extension.outlines[1]

            --[[
                Only colour while an outline is actually on top. Without this
                the write would fight whatever higher-priority outline is
                showing - a smart tag or a psyker mark - and those are
                transient signals that should win.
            --]]
            if top_outline then
                local stamp = last_write[unit]

                if stamp == nil or stamp.outline ~= top_outline or (t or 0) - stamp.t >= REFRESH_INTERVAL then
                    local color = class_vector(player)

                    if color then
                        set_outline_color(unit, "outline_color", color, true)
                    end

                    if stamp == nil then
                        last_write[unit] = { outline = top_outline, t = t or 0 }
                    else
                        stamp.outline = top_outline
                        stamp.t = t or 0
                    end
                end
            end

            -- Re-evaluated here rather than on the extension, which has no
            -- update method to hook. See the note on ensure_outline below.
            ensure_downed_outline(self, extension, unit)
        end
    end
end)

--[[
    FORCE ally outlines to exist. Approach taken from PlayerOutlines.

    Colouring an outline does nothing if there is no outline, and my previous
    attempt failed for two reasons I found by diffing against PlayerOutlines:

    1. WRONG TEMPLATE NAME. I used "default_both_skeleton", copied from
       player_unit_outline_extension.lua. That name is NOT defined in
       outline_settings.lua - the templates there are default_both_obscured,
       default_both_always, default_outlines_always, default_outlines_obscured,
       default_mesh_always and default_mesh_obscured. add_outline with an
       unknown template cannot produce anything. PlayerOutlines uses
       "default_outlines_always", which exists.

    2. MISSING disable_hologram OVERRIDE. The vanilla gate is

           player_outlines_enabled = interface_settings.player_outlines
               and not Managers.state.game_mode:disable_hologram()

       so even with the account flag on, a game mode that disables holograms
       suppresses ally outlines entirely. PlayerOutlines overrides
       disable_hologram to return false, and without that the outline can be
       stripped again after we add it.

    3. ADD ONCE IS NOT ENOUGH for the knocked-down outline, which has to follow
       a state that changes during the mission. The BASE outline is different:
       nothing removes it, so it is added once and left alone.
--]]
local FORCED_OUTLINE = "default_outlines_always"
local DISABLED_OUTLINE = "knocked_down"

--[[
    ========================================================================
    THE HOLOGRAM GATE - NOW DELEGATED TO VANILLA INSTEAD OF GUESSED BY NAME
    ========================================================================

    WHAT THIS GATE ACTUALLY CONTROLS, which is more than outlines:

        player_character_unit_template.lua:221 and :411
            if not Managers.state.game_mode:disable_hologram() then
                config:add("PlayerUnitHologramExtension", { breed = breed })

    It decides whether every non-local player unit gets a hologram EXTENSION
    at spawn. It is not a display toggle; it changes the extension config of
    player units.

    WHAT WAS WRONG

    This was hook_origin - a total replacement - returning true only when the
    game mode was literally named "hub", and false for everything else.
    Vanilla shuts this gate in FIVE modes, not one:

        hub               disable_hologram = true
        prologue          disable_hologram = true
        prologue_hub      disable_hologram = true
        shooting_range    disable_hologram = true
        training_grounds  disable_hologram = true

    Everything else leaves it unset, which reads as false.

    So in prologue, prologue_hub, shooting_range and training_grounds - the
    last two being the Meat Grinder - this mod was forcing hologram
    extensions onto player units that the game deliberately spawns without
    them. And because hook_origin replaces rather than wraps, no other mod
    could put it back.

    Worth being plain about what the override was ever worth: vanilla already
    returns false in every real mission, so in the case this feature exists
    for, the override agreed with vanilla and changed nothing. All it did
    differently was in the four modes it had no business touching.

    WHAT IT DOES NOW

    Wrapping hook. Vanilla is asked first and its answer is respected
    whenever it says "shut" - that answer is a property of the game mode and
    is not ours to contradict. The override survives only in its one
    defensible form: if something ELSE has hooked this to return true during
    a real mission, force it back open, which is the conflict this was
    written to win in the first place.
--]]
mod:hook("GameModeManager", "disable_hologram", function(func, self, ...)
    local ok, vanilla = pcall(func, self, ...)

    if not ok then
        return true
    end

    --[[
        Vanilla says disable. Hub, prologue, the Meat Grinder. Left alone -
        these are modes where the game does not spawn holograms on purpose,
        and overriding it here is what broke them.
    --]]
    if vanilla then
        return true
    end

    if mod:get("dio_force_outlines") == false then
        return vanilla
    end

    --[[
        Vanilla says enable and so do we. Returning an explicit false rather
        than `vanilla` so a later hook in the chain that flipped it sees this
        one flip it back - which is the whole and only purpose of the
        override.
    --]]
    return false
end)

--[[
    A downed teammate gets the dedicated knocked_down outline on top, which is
    the one that reads through walls - exactly the case this feature exists
    for. Flagged on the outline system's extension entry so it is added and
    removed once per state change rather than every frame.
--]]
function ensure_downed_outline(outline_system, extension, unit)
    if not extension or mod:get("dio_force_outlines") == false then
        return
    end

    local downed = false
    local detector = mod.unit_is_dead_or_disabled

    if type(detector) == "function" then
        local ok, d = pcall(detector, unit)
        downed = ok and d or false
    end

    if downed == (extension.__dio_downed_outline or false) then
        return
    end

    if downed then
        pcall(outline_system.add_outline, outline_system, unit, DISABLED_OUTLINE)
    else
        pcall(outline_system.remove_outline, outline_system, unit, DISABLED_OUTLINE)
    end

    extension.__dio_downed_outline = downed
end

--[[
    THE BASE OUTLINE IS ADDED EXACTLY ONCE, at extensions_ready.

    There was a second hook here, on PlayerUnitOutlineExtension.update, meant to
    re-assert it. It never ran. The log says so plainly:

        [DiosHandholder][ERROR] (hook_safe): trying to hook function or method
        that doesn't exist: [PlayerUnitOutlineExtension.update]

    and reading the extension confirms it - the class defines init,
    game_object_initialized, extensions_ready and destroy, and nothing else.
    There is no update to hook. The outlines have been working this whole time
    on the extensions_ready call alone, because add_outline is refcounted by
    template name and nothing removes ours.

    So the dead hook is gone rather than repaired. The one thing it was
    genuinely needed for - the knocked-down swap, which does change mid-mission
    - now runs from the OutlineSystem update above, where the unit is already
    in hand.
--]]
mod:hook_safe("PlayerUnitOutlineExtension", "extensions_ready", function(self, world, unit)
    if self._is_local_human or mod:get("dio_force_outlines") == false or not outlines_allowed() then
        return
    end

    local os_ = self._outline_system

    if not os_ or not os_.add_outline then
        return
    end

    pcall(os_.add_outline, os_, unit, FORCED_OUTLINE)
end)


--[[
    Cached vectors are keyed on the player object, which survives a mission, so
    a character change between missions would otherwise keep the old colour.
--]]
function O.reset()
    for k in pairs(rgb_cache) do
        rgb_cache[k] = nil
    end
end

return O
