local mod = get_mod("DiosHandholder")

--[[
    ========================================================================
    FILE AUDIO: REAL SimpleAudio FIRST, VENDORED COPY ONLY AS FALLBACK
    ========================================================================

    Same gate as DiosHandholder_assets.lua and for the same reason: the
    backend is a native DLL, ffi.load on a different path is a different
    module to Windows, and two copies in one process is a bug that resolves
    differently on different machines.

    So if get_mod("SimpleAudio") answers, that is what plays the sound and
    vendor/simpleaudio is never read. Our DLLs are never loaded. Nothing of
    ours is running, so there is nothing to conflict with.

    ------------------------------------------------------------------------
    WHY THIS EXISTS AT ALL - THE WWISE ROUTE DID NOT WORK

    The previous build played an existing game event:

        wwise/events/minions/play_daemonhost_mutator_awakened_stinger

    The animation fired and the sound did not, which is the expected result
    and I should have predicted it. Wwise only plays events whose SOUNDBANK
    IS RESIDENT. The daemonhost banks are streamed in with the daemonhost,
    so on a mission with no daemonhost the event resolves to nothing. It
    fails silently, and the pcall around it swallowed even the complaint.

    That is not a fixable bug so much as the wrong approach: there is no
    event this mod can name that is guaranteed loaded in every mission, and
    picking one that happens to be resident today is the kind of thing that
    breaks on a patch.

    SimpleAudio sidesteps it entirely - it decodes an .ogg off disk through
    FFmpeg and plays it through XAudio2, with no bank and no Wwise involved.
    So the sound is now the mod's ACTUAL Foxy sound effect rather than a
    borrowed game sting, which is also just better.

    The Wwise attempt is still there as a last-ditch fallback (see
    DiosHandholder_jumpscare.lua) on the grounds that it costs nothing and
    occasionally the bank will happen to be loaded.

    ------------------------------------------------------------------------
    THE SIZE OF THIS THING

    vendor/simpleaudio/bin is ~134 MB on disk, ~56 MB compressed, and almost
    all of it is FFmpeg. The runtime LoadLibrary's all six by name, in
    dependency order, and initialization fails if any is missing - so they
    cannot be trimmed:

        avutil-60  swresample-6  swscale-9  avcodec-62  avformat-62
        avfilter-11

    If that is not worth it, DELETING vendor/simpleaudio/bin IS SAFE. The
    gate below degrades to "no audio backend" and the scare still fires with
    its animation. Installing the real SimpleAudio then restores the sound
    without the mod carrying the DLLs at all.

    ------------------------------------------------------------------------
    INITIALIZATION IS ASYNC AND SLOW

    Loading 134 MB of FFmpeg takes seconds. SimpleAudio's runtime is built
    around that: start_initialize returns immediately and status only reaches
    READY later, which is why upstream has a "still initializing after 10s"
    notice.

    So this module cannot start on demand at the moment of the scare - the
    sound would arrive after the animation had finished. It warms up on the
    first update tick instead. NOT during new_mod: a native DLL load in early
    boot is exactly the class of thing that broke someone else's SoloPlay,
    and the rule from that round of fixes holds here.
--]]

local Audio = {}

local VENDOR = "Dio's Handholder/vendor/simpleaudio/"

local backend = nil       -- "simpleaudio" | "vendor" | "none"
local native = nil        -- vendor runtime, when backend == "vendor"
local options_module = nil
local warmed = false

--[[
    Resolved once. DMF has long finished loading mods by the time anything
    here runs, so a SimpleAudio that is not present now will not appear.
--]]
local function resolve()
    if backend then
        return
    end

    local sa = get_mod("SimpleAudio")

    if sa and type(sa.play_file) == "function" then
        backend = "simpleaudio"

        mod:info("[audio] using the installed SimpleAudio")
        return
    end

    --[[
        No SimpleAudio. Load our own chain inside pcall - the DLLs may be
        absent (see "deleting bin is safe" above), quarantined by antivirus,
        or refused on a non-Windows install, and none of those should cost
        more than the sound.
    --]]
    local ok, result = pcall(function()
        local n = mod:io_dofile(VENDOR .. "runtime/native")
        local o = mod:io_dofile(VENDOR .. "playback/options")

        return { native = n, options = o }
    end)

    if not (ok and type(result) == "table"
        and type(result.native) == "table"
        and type(result.native.play) == "function") then
        backend = "none"

        mod:warning("[audio] no audio backend available: %s", tostring(result))
        return
    end

    --[[
        AND THE DLL HAS TO ACTUALLY LOAD.

        native.lua loads cleanly as a Lua module whether or not the DLLs are
        beside it - ffi.load happens lazily, deep inside start_initialize.
        So "the module loaded" is not evidence of anything, and an earlier
        version of this gate that stopped at the check above reported
        backend="vendor" on an install with no bin/ folder at all. The sound
        still degraded correctly, but /hhscare said "bundled" when the honest
        answer was "nothing here works", which is worse than useless when the
        whole point of the command is to tell those two apart.

        native.runtime is SimpleAudio's own load_runtime, memoised, so
        calling it here costs the load we were going to do anyway.
    --]]
    local ok_dll, runtime = pcall(result.native.runtime)

    if not ok_dll or not runtime then
        backend = "none"

        mod:warning("[audio] bundled runtime DLL did not load: %s",
            tostring(ok_dll and "not found" or runtime))
        return
    end

    backend = "vendor"
    native = result.native
    options_module = result.options

    mod:info("[audio] SimpleAudio not installed - using the bundled copy")
end

--[[
    Kicks off the FFmpeg load. Safe to call every frame; start_initialize is
    only actually issued once.
--]]
function Audio.warm()
    if warmed then
        return
    end

    warmed = true

    resolve()

    if backend ~= "vendor" then
        return
    end

    local ok, started, err = pcall(native.start_initialize)

    if not ok or not started then
        mod:warning("[audio] bundled runtime did not start: %s",
            tostring(ok and err or started))
    end
end

--[[
    Must run every frame while the vendored backend is live: it drives
    initialization state AND drains the runtime's event queue. Without it a
    finished sound never releases its slot.

    Nothing happens on the installed-SimpleAudio path - that mod pumps its
    own runtime from its own update, and pumping it from here as well would
    double-drain the queue and eat its callbacks.
--]]
function Audio.update(dt)
    if backend ~= "vendor" or not native then
        return
    end

    pcall(native.update, dt)
end

--[[
    path is the "mods/"-prefixed form for the same reason the texture loader
    uses it: a bare relative path makes SimpleAudio infer the calling mod by
    walking the Lua stack for "/mods/<name>/scripts/", and any C frame in
    between - a pcall is the easiest one to introduce - stops that walk and
    resolves against SimpleAudio's own folder instead.

    Returns truthy on success. Callers treat false as "fall back to Wwise".
--]]
function Audio.play_file(path, settings)
    resolve()

    if backend == "simpleaudio" then
        local sa = get_mod("SimpleAudio")
        local ok, id = pcall(sa.play_file, path, settings)

        return ok and id or false
    end

    if backend ~= "vendor" then
        return false
    end

    --[[
        The vendored path calls native.play directly rather than going
        through SimpleAudio's playback/file.lua. That file pulls in paths.lua
        -> context.lua, whose only job is to guess the calling mod from the
        stack - a guess this module does not need, because the "mods/" form
        is already absolute. Two fewer vendored files for no lost behaviour.

        The "../" prefix is what resolve_audio_path would have produced: the
        runtime's working directory is the game binary folder, one level
        below mods/.
    --]]
    local resolved = "../" .. path:gsub("\\", "/"):gsub("^/", "")

    local opts
    local ok_o, built = pcall(options_module.create, settings or {}, 100, nil)

    if ok_o then
        opts = built
    else
        --[[
            options.create reads the game's audio sliders through
            Application.user_setting. If that is unavailable the sound should
            still play, just without honouring the user's volume.
        --]]
        opts = { volume_gain = 1, base_volume_gain = 1 }
    end

    local ok, id, err = pcall(native.play, resolved, opts)

    if not ok or not id then
        mod:warning("[audio] could not play %s: %s",
            tostring(resolved), tostring(ok and err or id))

        return false
    end

    return id
end

--[[
    Stop a sound that play_file started, with an optional fade in seconds.
    Needed by anything that loops: a loop_count of -1 runs until something
    stops it. Returns false when the backend cannot stop (then callers should
    not start a loop in the first place).
--]]
function Audio.stop(play_id, fade_out)
    resolve()

    if not play_id then
        return false
    end

    if backend == "simpleaudio" then
        local sa = get_mod("SimpleAudio")

        if sa and type(sa.stop) == "function" then
            local ok, stopped = pcall(sa.stop, play_id, fade_out)

            return ok and stopped
        end

        return false
    end

    if backend ~= "vendor" or not native or type(native.stop) ~= "function" then
        return false
    end

    local ok, stopped = pcall(native.stop, play_id, fade_out)

    return ok and stopped
end

--[[
    true, false, or NIL when this install has no way to tell.

    The difference matters more than it looks. A caller that is told "false"
    believes the sound has ended and drops the handle; if that was really "no
    idea", the sound plays on with nothing left that can reach it. Returning
    false here for every install that cannot report playback is exactly what
    left copies of a looping track running until the game was closed.
--]]
function Audio.is_playing(play_id)
    resolve()

    if not play_id or not Audio.can_verify() then
        return nil
    end

    local ok, playing = pcall(native.is_playing, play_id)

    if not ok or playing == nil then
        return nil
    end

    return playing and true or false
end

--[[
    How long a file runs, in seconds, or nil if it cannot be worked out.

    A caller that cannot loop natively needs this to know when a one-shot has
    finished and may be started again.
--]]
function Audio.duration(path)
    resolve()

    if backend == "simpleaudio" then
        local sa = get_mod("SimpleAudio")

        if sa and type(sa.file_info) == "function" then
            local ok, info = pcall(sa.file_info, path)

            if ok and type(info) == "table" and tonumber(info.duration) then
                return tonumber(info.duration)
            end
        end

        return nil
    end

    if backend ~= "vendor" or not native or type(native.file_info) ~= "function" then
        return nil
    end

    local resolved = "../" .. path:gsub("\\", "/"):gsub("^/", "")
    local ok, info = pcall(native.file_info, resolved)

    if not ok or type(info) ~= "table" then
        return nil
    end

    return tonumber(info.duration)
end

--[[
    Stop EVERYTHING this runtime is playing, handle or no handle.

    The runtime's own stop takes a nil id as "all of them"
    (SimpleAudioRuntime_StopAll). This is the only way to reach a sound whose
    play id was lost, so it is what a panic button should call. It stops other
    callers' sounds too, so it is not for routine cleanup.
--]]
function Audio.stop_all(fade_out)
    resolve()

    if backend == "simpleaudio" then
        local sa = get_mod("SimpleAudio")

        if sa and type(sa.stop) == "function" then
            local ok, stopped = pcall(sa.stop, nil, fade_out or 0.3)

            return ok and stopped
        end

        return false
    end

    if backend ~= "vendor" or not native or type(native.stop) ~= "function" then
        return false
    end

    local ok, stopped = pcall(native.stop, nil, fade_out or 0.3)

    return ok and stopped
end

--[[
    Whether is_playing can give a real answer. Only the vendored runtime can;
    SimpleAudio exposes no way to ask. Anything that wants to start an endless
    loop should check this as well as can_stop, because a stop that cannot be
    confirmed is a stop that might not have happened.
--]]
function Audio.can_verify()
    resolve()

    return backend == "vendor" and native ~= nil and type(native.is_playing) == "function"
end

--[[
    Whether Audio.stop can actually stop a sound on this install. Callers that
    want a looping track check this before starting one.
--]]
function Audio.can_stop()
    resolve()

    if backend == "vendor" then
        return native ~= nil and type(native.stop) == "function"
    end

    if backend == "simpleaudio" then
        local sa = get_mod("SimpleAudio")

        return sa ~= nil and type(sa.stop) == "function"
    end

    return false
end

function Audio.backend()
    resolve()

    return backend
end

--[[
    Reported by /hhscare so one command says which of the three states this
    install is in, rather than leaving it to be inferred from whether a
    noise happened.
--]]
function Audio.describe()
    resolve()

    if backend == "simpleaudio" then
        return "installed SimpleAudio"
    elseif backend == "vendor" then
        --[[
            resolve() has already proved the DLL loads - it does not set
            backend to "vendor" otherwise - so this only reads status.
        --]]
        local ok, runtime = pcall(native.runtime)

        if not ok or not runtime then
            return "bundled (DLL unloaded since startup)"
        end

        local ok_s, status = pcall(function()
            return tonumber(runtime.SimpleAudioRuntime_InitializationStatus())
        end)

        if not ok_s then
            return "bundled (status unavailable)"
        end

        local STATUS = {
            [0] = "bundled (uninitialized)",
            [1] = "bundled (still loading FFmpeg)",
            [2] = "bundled, ready",
            [3] = "bundled (initialization FAILED)",
            [4] = "bundled (shutting down)",
        }

        return STATUS[status] or ("bundled (status " .. tostring(status) .. ")")
    end

    return "none - no sound (install SimpleAudio, or restore vendor/simpleaudio/bin)"
end

mod.__dio_audio = Audio

return Audio
