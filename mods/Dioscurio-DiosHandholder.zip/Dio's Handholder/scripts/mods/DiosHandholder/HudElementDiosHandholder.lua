-- Renamed to HudElementDiosExpandedUI.lua so custom_hud shows the right
-- label (it lists elements by __class_name). Not referenced.
return {}
