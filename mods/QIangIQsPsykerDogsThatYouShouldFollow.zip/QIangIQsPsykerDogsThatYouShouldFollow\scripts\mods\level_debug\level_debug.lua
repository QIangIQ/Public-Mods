local mod = get_mod("level_debug")
local debug_utils = get_mod("debug_utils")
local MonsterPacing = require("scripts/managers/pacing/monster_pacing/monster_pacing")
local MutatorMonsterSpawnerSettings = require("scripts/settings/mutator/mutator_monster_spawner_settings")
local MainPathQueries = require("scripts/utilities/main_path_queries")
local MonsterInjectionTemplates = require("scripts/managers/pacing/monster_pacing/templates/monster_injection_templates")
local SharedNav = require("scripts/components/utilities/shared_nav")
local MissionTemplates = require("scripts/settings/mission/mission_templates")

mod:command("drawer", "", function() 
  local local_player = Managers.player:local_player(1)
  local local_player_unit = local_player.player_unit
  local current_position = Unit.local_position(local_player_unit, 1)
  local h = Vector3(0, 0, 1)
  QuickDrawerStay:sphere(current_position, 0.25, Color.light_green())
end)

mod:command("main_path", "", function() 
  local h = Vector3(0, 0, 1)
  local main_path_manager = Managers.state.main_path
  main_path_segments = main_path_manager._main_path_segments
  --mod:echo(main_path_segments)
	for i = 1, #main_path_segments, 1 do
		local path = main_path_segments[i].nodes

		for j = 1, #path, 1 do
			local position = Vector3(path[j][1], path[j][2], path[j][3])
      --mod:echo(position)
			QuickDrawerStay:sphere(position + h, 0.25, Color.light_green())

			if j == #path and i ~= #main_path_segments then
				local nextPositon = Vector3(main_path_segments[i + 1].nodes[1][1], main_path_segments[i + 1].nodes[1][2], main_path_segments[i + 1].nodes[1][3])

				QuickDrawerStay:line(position + h, nextPositon + h, Color.yellow())
			elseif j ~= #path then
				local nextPositon = Vector3(path[j + 1][1], path[j + 1][2], path[j + 1][3])

				QuickDrawerStay:line(position + h, nextPositon + h, Color.light_green())
			end
		end
	end
end)

mod:command("monsters", "", function() 
  local debug_text = Managers.state.debug_text

  local h = Vector3(0, 0, 1)
  local main_path_manager = Managers.state.main_path
  main_path_segments = main_path_manager._main_path_segments

  local monster_pacing = Managers.state.pacing._monster_pacing
  local spawn_type_point_sections = monster_pacing._spawn_type_point_sections

  local count = 0

  local mutator_twins = Managers.state.mutator._mutators.mutator_monster_havoc_twins
  if mutator_twins then
    local twins_spawn_point_sections = mutator_twins._spawn_point_sections

    --active havoc twin spawn point
    local active_twin_spawn = mutator_twins._monsters[1]

    local spawn_trigger_position = MainPathQueries.position_from_distance(active_twin_spawn.travel_distance)
    local spawn_position = active_twin_spawn.position:unbox()
    mod:echo(spawn_position)

    QuickDrawerStay:sphere(spawn_trigger_position + h, 0.25, Color.green())
    QuickDrawerStay:sphere(spawn_position, 5, Color.green())
    QuickDrawerStay:line(spawn_trigger_position + h, spawn_position, Color.green())

    debug_utils.debug_text:output_world_text("active twin spawn", 0.1, spawn_trigger_position + h * 1.5 + Vector3(0, 0, .25 * count) , nil, "category: item_spawner_id", Color.yellow())

    --all havoc twin spawn points  
    for section, section_data in pairs(twins_spawn_point_sections) do
      for spawn, spawn_data in pairs(section_data) do
        local spawn_position = spawn_data.position:unbox()
        local spawn_trigger_position = MainPathQueries.position_from_distance(spawn_data.spawn_travel_distance)

        QuickDrawerStay:sphere(spawn_trigger_position + h, 0.25, Color.yellow())
        QuickDrawerStay:sphere(spawn_position, 5, Color.yellow())
        QuickDrawerStay:line(spawn_trigger_position + h, spawn_position, Color.yellow())


        debug_utils.debug_text:output_world_text("twins", 0.1, spawn_trigger_position + h * 1.5 + Vector3(0, 0, .25 * count) , nil, "category: item_spawner_id", Color.yellow())
      end
    end
  end

  for spawn_type, spawn_type_data in pairs(spawn_type_point_sections) do
    -- mod:echo(spawn_type)
    -- mod:dump(spawn_type_data, "", 3)
    
    for section, section_data in pairs(spawn_type_data) do
      -- mod:echo(section)
      -- mod:echo(section_data)
      for spawn, spawn_data in pairs(section_data) do
        -- mod:echo(spawn)
        -- mod:echo(spawn_data.spawn_travel_distance)
        -- mod:echo(spawn_data.position)
        local spawn_position = spawn_data.position:unbox()
        local spawn_trigger_position = MainPathQueries.position_from_distance(spawn_data.spawn_travel_distance)
        -- mod:echo(spawn_trigger_position)
        -- mod:echo(spawn_position)
        QuickDrawerStay:sphere(spawn_trigger_position + h, 0.25, Color.red())
        QuickDrawerStay:sphere(spawn_position, 5, Color.red())
        QuickDrawerStay:line(spawn_trigger_position + h, spawn_position, Color.red())
        -- mod:echo(debug_utils.debug_text)
        local text_size = .1
        debug_utils.debug_text:output_world_text(spawn_type, text_size, spawn_trigger_position + h * 1.5 + Vector3(0, 0, .25 * count) , nil, "category: item_spawner_id", Color.yellow())
      end
    end
    count = count + 1
  end

 -- mod:dump(debug_utils.debug_text, "debug", 4)
end)

mod:hook_safe("MutatorToxicGasTwins", "init", function(self, ...)
  mod:echo("yey")
end)

mod:command("respawn_beacons", "", function() 
  local h = Vector3(0, 0, 2)
  
  local respawn_beacon_system = Managers.state.extension:system("respawn_beacon_system")
  
  local beacon_extensions = respawn_beacon_system._unit_to_extension_map
  
  local text_size = 0.2
  local BEACON_AHEAD_DISTANCE = 25 
  
  for beacon_unit, extension in pairs(beacon_extensions) do
    if ALIVE[beacon_unit] then
      local beacon_position = Unit.world_position(beacon_unit, 1)
      local beacon_travel_distance = respawn_beacon_system._beacon_main_path_distance_lookup[beacon_unit]
      
      local max_progression_for_beacon = beacon_travel_distance - BEACON_AHEAD_DISTANCE
      local max_progression_position = MainPathQueries.position_from_distance(max_progression_for_beacon)
      
      QuickDrawerStay:sphere(beacon_position, 0.5, Color.cyan())
      
      local valid_spawn_positions = extension:best_respawn_positions()
      if valid_spawn_positions then
        for i = 1, #valid_spawn_positions do
          local spawn_position = valid_spawn_positions[i].position:unbox()
          QuickDrawerStay:sphere(spawn_position, 0.25, Color.blue())
          QuickDrawerStay:line(beacon_position, spawn_position, Color.blue())
        end
      end
      
      if beacon_travel_distance and max_progression_position then
        local beacon_main_path_position = MainPathQueries.position_from_distance(beacon_travel_distance)
        QuickDrawerStay:sphere(beacon_main_path_position + h, 0.3, Color.magenta())
        QuickDrawerStay:line(beacon_position, beacon_main_path_position + h, Color.magenta())
        
        QuickDrawerStay:sphere(max_progression_position + h, 0.4, Color.green())
        QuickDrawerStay:line(beacon_main_path_position + h, max_progression_position + h, Color.yellow())
        
        local text_position = beacon_position + h
        local distance_text = string.format("MaxProg: %.1f", beacon_travel_distance, max_progression_for_beacon)
        debug_utils.debug_text:output_world_text(distance_text, text_size * 1.5, text_position, nil, "respawn_beacon", Color.cyan())
      else
        local text_position = beacon_position + h
        debug_utils.debug_text:output_world_text("No MainPath", text_size, text_position, nil, "respawn_beacon", Color.cyan())
      end
    end
  end
end)

mod:command("beacon_debug", "", function()
  local respawn_beacon_system = Managers.state.extension:system("respawn_beacon_system")

  local side_system = Managers.state.extension:system("side_system")
  local default_player_side_name = side_system:get_default_player_side_name()
  local player_side = side_system:get_side_from_name(default_player_side_name)
  local side_id = player_side.side_id
  
  mod:echo("=== BEACON DEBUG INFO ===")
  
  local best_beacon = respawn_beacon_system:_find_nearest_beacon(side_id)
  
  local beacon_main_path_data = respawn_beacon_system._beacon_main_path_data
  local active_beacon_number = nil
  
  local beacon_info = "Beacon Max Progress: "
  local beacon_entries = {}
  
  for i, data in ipairs(beacon_main_path_data) do
    local unit = data.unit
    local distance = data.distance
    local max_progression = distance - 25
    if ALIVE[unit] then
      if unit == best_beacon then
        active_beacon_number = i
        beacon_entries[i] = string.format("#%d: %.1f {#color(255,0,0)}[ACTIVE]{#reset()}", i, max_progression)
      else
        beacon_entries[i] = string.format("#%d: %.1f", i, max_progression)
      end
    end
  end
  
  for i = 1, #beacon_entries do
    if beacon_entries[i] then
      if i > 1 then
        beacon_info = beacon_info .. " | " .. beacon_entries[i]
      else
        beacon_info = beacon_info .. beacon_entries[i]
      end
    end
  end
  
  mod:echo(beacon_info)
  
  local local_player = Managers.player:local_player(1)
  local local_player_unit = local_player.player_unit
  local current_position = Unit.local_position(local_player_unit, 1)
  local path_position, travel_distance = MainPathQueries.closest_position(current_position)
  
  if active_beacon_number then
    mod:echo("Active beacon: #" .. active_beacon_number)
  end
  
  if travel_distance then
    mod:echo("Current progress: " .. string.format("%.2f", travel_distance))
  end
end)

mod:command("path_marker", "", function() 
  local h = Vector3(0, 0, 1)
  local main_path_manager = Managers.state.main_path
  local path_markers = main_path_manager._path_markers
  mod:echo(path_markers)
  for key, value in pairs(path_markers) do
    mod:echo(key)
    mod:echo(value.position)
    mod:echo(value.position:unbox())
    QuickDrawerStay:sphere(value.position:unbox(), 1, Color.red())
  end
end)

mod:command("nav_spawn", "", function() 
  local nav_info = SharedNav.create_nav_info()
end)

mod:command("position", "", function() 
  local local_player = Managers.player:local_player(1)
  local local_player_unit = local_player.player_unit
  mod:echo(local_player_unit)
  local current_position = Unit.local_position(local_player_unit, 1)
  mod:echo(current_position)
  local path_position, travel_distance = MainPathQueries.closest_position(current_position)
  mod:echo(path_position)
end)

mod:command("mission", "", function() 
  mod:echo(MissionTemplates)
  
  local mission_name = Managers.state.mission:mission_name()
  mod:dump(MissionTemplates[mission_name], "mission_name", 2)
end)

mod:command("dump", "", function() 
  mod:dump(Managers.state.main_path._path_markers, "_path_markers", 5)
end)

mod.current_progress = function() 
  local h = Vector3(0, 0, 1)
  local local_player = Managers.player:local_player(1)
  local local_player_unit = local_player.player_unit
  local current_position = Unit.local_position(local_player_unit, 1)
  local path_position, travel_distance = MainPathQueries.closest_position(current_position)
  QuickDrawer:sphere(path_position + h, 0.25, Color.yellow())
  QuickDrawer:line(path_position + h, current_position + h, Color.yellow())
end

-- Your mod code goes here.
-- https://vmf-docs.verminti.de