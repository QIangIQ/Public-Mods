requires debug_utils to show path

/main_path - shows map progression line
/monsters - shows triggers for captains, monstrosities, daemonhosts and twins
/respawn_beacons - display spawn locations at respawn beacons and max progress allowed
/beacon_debug - gives current map progress, current active beacon and beacon list

