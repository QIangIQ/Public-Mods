return {
	mod_description = {
		en = "Twin u freaky looking at ts frfr uncle",
	},
}
