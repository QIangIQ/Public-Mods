local mod = get_mod("level_debug")

return {
	name = "QIangIQ's Psyker Dogs That You Should Follow",
	description = mod:localize("mod_description"),
	is_togglable = true,
}
