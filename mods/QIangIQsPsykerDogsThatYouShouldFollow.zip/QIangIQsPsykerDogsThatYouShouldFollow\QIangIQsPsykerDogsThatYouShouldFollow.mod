return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsPsykerDogsThatYouShouldFollow` encountered an error loading the Darktide Mod Framework.")

		new_mod("level_debug", {
			mod_script       = "QIangIQsPsykerDogsThatYouShouldFollow/scripts/mods/level_debug/level_debug",
			mod_data         = "QIangIQsPsykerDogsThatYouShouldFollow/scripts/mods/level_debug/level_debug_data",
			mod_localization = "QIangIQsPsykerDogsThatYouShouldFollow/scripts/mods/level_debug/level_debug_localization",
		})
	end,
	packages = {},
}
