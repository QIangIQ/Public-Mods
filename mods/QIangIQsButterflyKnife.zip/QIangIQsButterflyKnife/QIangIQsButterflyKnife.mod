return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsButterflyKnife` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsButterflyKnife", {
            mod_script = "QIangIQsButterflyKnife/scripts/mods/QIangIQsButterflyKnife/QIangIQsButterflyKnife",
            mod_data = "QIangIQsButterflyKnife/scripts/mods/QIangIQsButterflyKnife/QIangIQsButterflyKnife_data",
            mod_localization = "QIangIQsButterflyKnife/scripts/mods/QIangIQsButterflyKnife/QIangIQsButterflyKnife_localization",
        })
    end,
    version = "1.8.10",
    author = "QIangIQ",
    load_after = { "CustomAssets" },
    packages = {},
}
