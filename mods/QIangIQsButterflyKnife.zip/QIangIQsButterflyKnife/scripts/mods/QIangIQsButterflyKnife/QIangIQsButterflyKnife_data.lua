local mod = get_mod("QIangIQsButterflyKnife")

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = true,
    options = {
        widgets = {
            { setting_id = "cs2_3p", type = "checkbox", default_value = true },
            {
                setting_id = "replace_combat_knife",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "replace_duelling_sword",
                type = "checkbox",
                default_value = false,
            },
            { setting_id = "duelling_size", type = "numeric", default_value = 1, range = { 0.3, 2.5 }, decimals_number = 2 },
            {
                setting_id = "group_fit",
                type = "group",
                sub_widgets = {
                    { setting_id = "knife_scale", type = "numeric", default_value = 0.86, range = { 0.3, 3 }, decimals_number = 2 },
                    { setting_id = "fp_scale", type = "numeric", default_value = 0.51, range = { 0.2, 1.5 }, decimals_number = 2 },
                    { setting_id = "knife_grip", type = "numeric", default_value = 0.18, range = { -0.5, 0.5 }, decimals_number = 2 },
                    { setting_id = "knife_roll", type = "numeric", default_value = -180, range = { -180, 180 }, decimals_number = 0 },
                    { setting_id = "knife_tilt", type = "numeric", default_value = -20, range = { -90, 90 }, decimals_number = 0 },
                    { setting_id = "knife_pitch", type = "numeric", default_value = 0, range = { -180, 180 }, decimals_number = 0 },
                    { setting_id = "knife_edge", type = "numeric", default_value = 180, range = { -180, 180 }, decimals_number = 0 },
                    { setting_id = "knife_flip", type = "checkbox", default_value = false },
                },
            },
            {
                setting_id = "group_flips",
                type = "group",
                sub_widgets = {
                    { setting_id = "flip_on_inspect", type = "checkbox", default_value = true },
                    { setting_id = "hand_lock", type = "checkbox", default_value = true },
                    { setting_id = "hold_on_fingertips", type = "checkbox", default_value = true },
                    { setting_id = "hold_fingers", type = "numeric", default_value = 0, range = { -10, 10 }, decimals_number = 1 },
                    { setting_id = "hold_palm", type = "numeric", default_value = 0, range = { -10, 10 }, decimals_number = 1 },
                    { setting_id = "hold_thumb", type = "numeric", default_value = 0, range = { -10, 10 }, decimals_number = 1 },
                    { setting_id = "cs2_wrist_turns", type = "checkbox", default_value = false },
                    { setting_id = "fp_fingers", type = "checkbox", default_value = true },
                    { setting_id = "arm_motion", type = "numeric", default_value = 1, range = { 0, 1.5 }, decimals_number = 2 },
                    { setting_id = "flip_speed", type = "numeric", default_value = 1, range = { 0.25, 3 }, decimals_number = 2 },
                    {
                        setting_id = "flip_keybind",
                        type = "keybind",
                        default_value = {},
                        keybind_trigger = "pressed",
                        keybind_type = "function_call",
                        function_name = "flip",
                    },
                },
            },
            {
                setting_id = "group_cs2_arms",
                type = "group",
                sub_widgets = {
                    {
                        setting_id = "cs2_arms",
                        type = "dropdown",
                        default_value = "viewmodel",
                        options = {
                            { text = "cs2_arms_off", value = "off" },
                            { text = "cs2_arms_viewmodel", value = "viewmodel" },
                            { text = "cs2_arms_follow", value = "follow" },
                        },
                    },
                    {
                        setting_id = "cs2_sleeves",
                        type = "dropdown",
                        default_value = "ct",
                        options = {
                            { text = "cs2_sleeves_ct", value = "ct" },
                            { text = "cs2_sleeves_t", value = "t" },
                            { text = "cs2_sleeves_character", value = "character" },
                        },
                    },
                    { setting_id = "cs2_vm_x", type = "numeric", default_value = 1, range = { -2, 2.5 }, decimals_number = 1 },
                    { setting_id = "cs2_vm_y", type = "numeric", default_value = 1, range = { -2, 2 }, decimals_number = 1 },
                    { setting_id = "cs2_vm_z", type = "numeric", default_value = -1, range = { -2, 2 }, decimals_number = 1 },
                    { setting_id = "finger_open", type = "numeric", default_value = 12, range = { 0, 30 }, decimals_number = 0 },
                    { setting_id = "cs2_attack_speed", type = "numeric", default_value = 1, range = { 0.5, 2 }, decimals_number = 2 },
                    { setting_id = "cs2_backstab_anims", type = "checkbox", default_value = true },
                    { setting_id = "cs2_hit_anims", type = "checkbox", default_value = false },
                    { setting_id = "cs2_heavy_light_swings", type = "checkbox", default_value = true },
                },
            },
            {
                setting_id = "group_cs2_sounds",
                type = "group",
                sub_widgets = {
                    { setting_id = "cs2_sounds", type = "checkbox", default_value = true },
                    { setting_id = "cs2_sound_volume", type = "numeric", default_value = 100, range = { 0, 400 }, decimals_number = 0 },
                },
            },
            {
                setting_id = "free_look_inspect",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "menu_previews",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "toggle_knife_keybind",
                type = "keybind",
                default_value = {},
                keybind_trigger = "pressed",
                keybind_type = "function_call",
                function_name = "toggle_knife",
            },
        },
    },
}
