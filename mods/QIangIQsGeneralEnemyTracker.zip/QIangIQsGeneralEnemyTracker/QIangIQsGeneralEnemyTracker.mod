return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsGeneralEnemyTracker` encountered an error loading the Darktide Mod Framework.")

        new_mod("QIangIQsGeneralEnemyTracker", {
            mod_script       = "QIangIQsGeneralEnemyTracker/scripts/mods/QIangIQsGeneralEnemyTracker/QIangIQsGeneralEnemyTracker",
            mod_data         = "QIangIQsGeneralEnemyTracker/scripts/mods/QIangIQsGeneralEnemyTracker/QIangIQsGeneralEnemyTracker_data",
            mod_localization = "QIangIQsGeneralEnemyTracker/scripts/mods/QIangIQsGeneralEnemyTracker/QIangIQsGeneralEnemyTracker_localization",
        })
    end,
    packages = {},
}
