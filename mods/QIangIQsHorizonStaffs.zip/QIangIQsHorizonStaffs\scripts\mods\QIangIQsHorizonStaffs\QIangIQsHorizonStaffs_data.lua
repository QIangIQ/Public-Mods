local mod = get_mod("QIangIQsHorizonStaffs")

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = true,
    options = {
        widgets = {
            {
                setting_id = "replace_inferno_staff",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "staff_choice",
                type = "dropdown",
                default_value = "qps",
                options = {
                    { text = "staff_qps", value = "qps" },
                    { text = "staff_sol", value = "sol" },
                },
            },
            {
                setting_id = "group_fit",
                type = "group",
                sub_widgets = {
                    { setting_id = "staff_scale", type = "numeric", default_value = 1, range = { 0.3, 3 }, decimals_number = 2 },
                    { setting_id = "fp_scale", type = "numeric", default_value = 0.6, range = { 0.2, 1.5 }, decimals_number = 2 },
                    { setting_id = "staff_grip", type = "numeric", default_value = 0, range = { -0.5, 0.5 }, decimals_number = 2 },
                    { setting_id = "staff_roll", type = "numeric", default_value = 0, range = { -180, 180 }, decimals_number = 0 },
                    { setting_id = "staff_tilt", type = "numeric", default_value = 0, range = { -90, 90 }, decimals_number = 0 },
                    { setting_id = "staff_flip", type = "checkbox", default_value = false },
                },
            },
            {
                setting_id = "group_glow",
                type = "group",
                sub_widgets = {
                    { setting_id = "glow_brightness", type = "numeric", default_value = 2, range = { 0, 50 }, decimals_number = 1 },
                    { setting_id = "glow_peril", type = "numeric", default_value = 12, range = { 0, 50 }, decimals_number = 1 },
                    { setting_id = "glow_pulse", type = "numeric", default_value = 0.3, range = { 0, 1 }, decimals_number = 2 },
                    { setting_id = "glow_pulse_speed", type = "numeric", default_value = 0.8, range = { 0.1, 5 }, decimals_number = 1 },
                    { setting_id = "orb_brightness", type = "numeric", default_value = 0.15, range = { 0, 10 }, decimals_number = 2 },
                    { setting_id = "glow_charge", type = "numeric", default_value = 8, range = { 0, 50 }, decimals_number = 1 },
                    { setting_id = "ability_flare", type = "checkbox", default_value = true },
                    {
                        setting_id = "glow_color",
                        type = "dropdown",
                        default_value = "original",
                        options = {
                            { text = "color_original", value = "original" },
                            { text = "color_cyan", value = "cyan" },
                            { text = "color_pink", value = "pink" },
                            { text = "color_green", value = "green" },
                            { text = "color_gold", value = "gold" },
                            { text = "color_purple", value = "purple" },
                            { text = "color_red", value = "red" },
                            { text = "color_white", value = "white" },
                        },
                    },
                },
            },
            {
                setting_id = "group_motion",
                type = "group",
                sub_widgets = {
                    { setting_id = "motion_enabled", type = "checkbox", default_value = true },
                    { setting_id = "spin_speed", type = "numeric", default_value = 1, range = { 0, 4 }, decimals_number = 2 },
                    { setting_id = "float_amount", type = "numeric", default_value = 1, range = { 0, 3 }, decimals_number = 2 },
                    { setting_id = "orb_physics", type = "numeric", default_value = 1, range = { 0, 3 }, decimals_number = 2 },
                    { setting_id = "wing_flap", type = "numeric", default_value = 1, range = { 0, 3 }, decimals_number = 2 },
                    { setting_id = "peril_speed", type = "numeric", default_value = 1.5, range = { 0, 5 }, decimals_number = 2 },
                    { setting_id = "charge_reaction", type = "checkbox", default_value = true },
                    { setting_id = "charge_spread", type = "numeric", default_value = 15, range = { 0, 40 }, decimals_number = 0 },
                },
            },
            {
                setting_id = "menu_previews",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "toggle_staff_keybind",
                type = "keybind",
                default_value = {},
                keybind_trigger = "pressed",
                keybind_type = "function_call",
                function_name = "toggle_staff",
            },
            {
                setting_id = "cycle_staff_keybind",
                type = "keybind",
                default_value = {},
                keybind_trigger = "pressed",
                keybind_type = "function_call",
                function_name = "cycle_staff",
            },
        },
    },
}
