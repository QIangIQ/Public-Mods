-- QIangIQ's Horizon Staffs: Horizon Walker EX weapons (The Queen's Platinum Staff, Sol) over the Inferno Force
-- Staff, as Custom Assets units built in DMS/work/hwstaffs (bake.py, build.py). Glow layers come from the game's
-- own light maps and react to peril; spinning / floating / orbiting parts are unit nodes driven here.
-- Fit, records, menu previews and sync follow QIangIQsSpearArsenal 2.2.
-- Author: QIangIQ
local mod = get_mod("QIangIQsHorizonStaffs")

-- Cross-client sync ---------------------------------------------------------------
-- QIangIQsModelSync publishes which QIangIQ replacer mods a player has on, with their options, through
-- Vox Manifold. No asset data is sent: every client shows the model from its own installed files. While another
-- player's unit is worked on, sync_ctx holds that player's options and opt() answers from them.
-- (Block copied from QIangIQsSpearArsenal 2.2.)
local SYNC_KEY = "hwstaff"
local SYNC_BOOLS = { "replace_inferno_staff", "staff_flip", "motion_enabled", "charge_reaction", "ability_flare" }
local SYNC_DEFAULTS = { replace_inferno_staff = true, staff_flip = false, motion_enabled = true, charge_reaction = true, ability_flare = true }
local SYNC_VALUES = { "staff_choice", "staff_scale", "fp_scale", "staff_grip", "staff_roll", "staff_tilt", "glow_brightness",
    "glow_peril", "glow_pulse", "glow_pulse_speed", "orb_brightness", "glow_color", "spin_speed", "float_amount", "orb_physics", "wing_flap", "glow_charge", "charge_spread",
    "peril_speed" }
local SYNC_LAYOUT = 100 + #SYNC_VALUES
local sync_ctx = nil
local sync_known = setmetatable({}, { __mode = "k" })   -- other players' extensions this mod has shown something on
local sync_all = setmetatable({}, { __mode = "k" })     -- every visual loadout extension seen
local sync_decoded = setmetatable({}, { __mode = "k" }) -- published array -> options table
local SYNC_FALSE = { __index = function() return false end }
local SYNC_OFF = setmetatable({}, SYNC_FALSE)           -- "everything off": removes what was shown
local sync_extra_import = nil

local function opt(key)
    if sync_ctx then
        return sync_ctx[key]
    end
    return mod:get(key)
end

local function sync_api()
    local hub = get_mod("QIangIQsModelSync")
    return hub and hub.api
end

local function sync_me()
    local players = Managers.player
    if not players then
        return nil
    end
    local ok, player = pcall(players.local_player_safe, players, 1)
    return ok and player or nil
end

-- published array { layout, checkbox bits, value, value, ... [, extra] } -> options by setting id
local function sync_decode(raw)
    local t = sync_decoded[raw]
    if t ~= nil then
        return t
    end
    t = false
    if type(raw) == "table" and raw[1] == SYNC_LAYOUT then
        t = setmetatable({}, SYNC_FALSE)
        local mask = tonumber(raw[2]) or 0
        for i = 1, #SYNC_BOOLS do
            t[SYNC_BOOLS[i]] = mask % 2 >= 1
            mask = math.floor(mask / 2)
        end
        for i = 1, #SYNC_VALUES do
            local v = raw[2 + i]
            if v ~= nil then
                t[SYNC_VALUES[i]] = v
            end
        end
        if sync_extra_import then
            sync_extra_import(t, raw[3 + #SYNC_VALUES])
        end
    end
    sync_decoded[raw] = t
    return t
end

-- whose options apply to this extension: nil = mine, a table = that player's (SYNC_OFF when they publish
-- nothing for this mod)
local function sync_owner(ext)
    sync_all[ext] = true
    local player = ext._player
    if player == nil or player == sync_me() then
        return nil
    end
    local api = sync_api()
    local raw = api and api.peer(SYNC_KEY, player)
    local state = raw and sync_decode(raw)
    if state then
        sync_known[ext] = true
        return state
    end
    return SYNC_OFF
end

-- my own unit, or another player's unit this mod is (or was) showing something on
local function sync_shown(ext)
    local player = ext._player
    return player ~= nil and (player == sync_me() or sync_known[ext] == true)
end

local function sync_pack(...)
    return { n = select("#", ...), ... }
end

-- runs a hook body with the options of the extension's owner
local function sync_wrap(fn, ext_index)
    return function(...)
        local ext = select(ext_index, ...)
        local previous = sync_ctx
        sync_ctx = sync_owner(ext)
        local results = sync_pack(pcall(fn, ...))
        sync_ctx = previous
        if not results[1] then
            error(results[2], 0)
        end
        return unpack(results, 2, results.n)
    end
end

-- The same hook on my own unit's extension and on other players' (husk) extensions. While the mods load, the
-- classes do not exist yet: CLASS.<name> is then only the name and DMF delays the hook ("needs to be delayed"
-- in the log), so the husk class cannot be inspected here. Its methods are taken from
-- player_husk_visual_loadout_extension.lua instead.
local SYNC_HUSK_METHODS = { init = true, update = true, _update_item_visibility = true, destroy = true }

local function vl_hook_safe(method, fn)
    mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, method, sync_wrap(fn, 1))
    if SYNC_HUSK_METHODS[method] then
        mod:hook_safe(CLASS.PlayerHuskVisualLoadoutExtension, method, sync_wrap(fn, 1))
    end
end

local function vl_hook(method, fn)
    mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, method, sync_wrap(fn, 2))
    if SYNC_HUSK_METHODS[method] then
        mod:hook(CLASS.PlayerHuskVisualLoadoutExtension, method, sync_wrap(fn, 2))
    elseif method == "_unequip_item_from_slot" then
        -- a husk has no _unequip_item_from_slot: its unequip arrives as rpc_player_unequip_item_from_slot
        -- (self, channel_id, go_id, slot_id), slot name = NetworkLookup.player_inventory_slot_names[slot_id]
        -- (player_husk_visual_loadout_extension.lua)
        mod:hook(CLASS.PlayerHuskVisualLoadoutExtension, "rpc_player_unequip_item_from_slot", sync_wrap(function(func, self, channel_id, go_id, slot_id, ...)
            local NetworkLookup = require("scripts/network_lookup/network_lookup")
            local slot_name = NetworkLookup.player_inventory_slot_names[slot_id]
            return fn(function()
                return func(self, channel_id, go_id, slot_id)
            end, self, slot_name)
        end, 2))
    end
end
-- ----------------------------------------------------------------------------------

-- ----------------------------------------------------------------------------------

mod.AUTHOR = "QIangIQ"

-- Inferno Force Staff (Enhanced_descriptions NAMES_Enemies_Weapons.lua:1313; QIangIQsSpearArsenal STAFFS)
local STAFF_TEMPLATE = "forcestaff_p2_m1"

-- Models: Custom folder (= unit name, asset id "<Mod>:<folder>"), unit path = --asset-path at compile time
-- (DMS/work/hwstaffs/build.py). One SKINNED unit per staff (the layout of Dio's Mercy Skins' caduceus, whose
-- petal bones move in game): bone hw_root at the origin, one bone per moving part at its pivot (weight 1.0),
-- marker bones staff_head (0, 1, 0) and hw_axis_x (0.1, 0, 0) giving the body axes in hw_root space.
-- (1.1.0: nodes of a static unit did not move in game; 1.2.0: one unit per part worked but carried 10 texture sets.)
-- pivot = part origin in body units (butt y = 0, head y = 1), tip = part centroid - pivot (build.py report.json).
-- Motion is rotation only: no game-proven code writes bone positions, and 1.3.0 doing so lost every part in game.
-- Glow slots = glTF material names; colour = baked emissive colour (linear).
local MODELS = {
    qps = {
        name = "The Queen's Platinum Staff",
        glow = {
            -- gold, as the lines in the official render (build.py; the light map's pale blue in 1.0)
            { slot = "glow_a", k = 1 },
            { slot = "glow_b", k = 1, shimmer = true },
            { slot = "glow_b2", k = 0.5, shimmer = true },
            { slot = "glow_orb", orb = true },
        },
        parts = {
            -- the orb hangs on a lever (bone 0.1 below it): float and inertia are small turns of the lever
            { bone = "hw_orb", tip = { 0, 0.1, 0 }, bob = 0.012, bob_hz = 0.35, spread = 0,
              swing = { pull = 60, drag = 9, max = math.rad(22), gain = 1 } },
            { bone = "hw_frame", spin = -18 },
            { bone = "hw_sats", spin = 55, tip = { -0.0449, -0.0507, 0.0392 }, bob = 0.006, bob_hz = 0.5, spread = 0,
              swing = { pull = 35, drag = 6, max = math.rad(15), gain = 1 } },
            { bone = "hw_wings", tip = { 0.0693, -0.0896, 0.1036 }, flap = 4, flap_hz = 0.3, spread = 1,
              swing = { pull = 28, drag = 5, max = math.rad(12), gain = 1.6 } },
            { bone = "hw_ribbons", tip = { -0.0083, -0.1032, 0.0192 }, flap = 2, flap_hz = 0.45, spread = 0.6,
              swing = { pull = 22, drag = 3.5, max = math.rad(14), gain = 2.2 } },
        },
    },
    sol = {
        name = "Sol",
        glow = {
            { slot = "glow_a", k = 1 },
            { slot = "glow_b", k = 1, shimmer = true },
            { slot = "glow_b2", k = 0.5, shimmer = true },
        },
        parts = {
            { bone = "hw_crown", spin = 22 },
            { bone = "hw_cage", spin = -14 },
            { bone = "hw_gems", spin = 60 },
        },
    },
}
local MODEL_KEYS = { "qps", "sol" }
-- every unit to load: the bodies and all their parts
local ALL_UNITS = MODEL_KEYS

-- QIangIQsAnubis GLOW_COLORS
local GLOW_COLORS = {
    cyan = { 0, 0.85, 1 },
    pink = { 1, 0.08, 0.55 },
    green = { 0.15, 1, 0.2 },
    gold = { 1, 0.69, 0.06 },
    purple = { 0.55, 0.15, 1 },
    red = { 1, 0.04, 0.04 },
    white = { 1, 1, 1 },
}

local function model_key()
    local k = opt("staff_choice")
    return MODELS[k] and k or "qps"
end

local function asset_id(key)
    return "QIangIQsHorizonStaffs:" .. key
end

local function unit_path(key)
    return "content/mods/qiangiq_hw_staffs/" .. key
end

local loaded = {}

local FIT_FRAMES = 10
local fit_generation = 0
local glow_generation = 0

local custom_assets = nil
local mod_on = true
local session_off = false

local tracked = setmetatable({}, { __mode = "k" })
local tracked_ui = setmetatable({}, { __mode = "k" })
local tracked_wpn = setmetatable({}, { __mode = "k" })

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function wants_item(item)
    if not (mod_on and item and item.weapon_template == STAFF_TEMPLATE) then
        return false
    end
    if session_off and not sync_ctx then
        return false
    end
    if not opt("replace_inferno_staff") then
        return false
    end
    return loaded[model_key()] == true
end

-- Fitting (QIangIQsSpearArsenal fit, unchanged: Unit.box centres, largest half-extent, base unit axes) ------

local function fmt(v)
    return string.format("(%.3f, %.3f, %.3f)", v.x, v.y, v.z)
end

local last_fit = {}
local fit_world_length = 1 -- world length of the last fitted staff (butt..head = 1 in its own units)

local function staff_parts(base, attachments)
    local parts = {}
    local function add(unit)
        if unit_ok(unit) then
            local pose, ext = Unit.box(unit)
            if pose and ext then
                local half = math.max(ext.x, ext.y, ext.z)
                if half > 0.005 then
                    parts[#parts + 1] = { center = Matrix4x4.translation(pose), half = half }
                end
            end
        end
    end
    add(base)
    if attachments then
        for i = 1, #attachments do
            add(attachments[i])
        end
    end
    return parts
end

local function fit(staff, base, attachments, parent_scale, view, first_person)
    local parts = staff_parts(base, attachments)
    if #parts == 0 then
        return false
    end
    local origin = Unit.world_position(base, 1)
    local far_d, far_c = 0, nil
    for i = 1, #parts do
        local d = Vector3.length_squared(parts[i].center - origin)
        if d > far_d then
            far_d, far_c = d, parts[i].center
        end
    end
    if not far_c or far_d < 0.0001 then
        return false
    end
    local dir = Vector3.normalize(far_c - origin)
    local source = "hand->farthest piece"
    -- the staff's own head: the piece carrying the "fx_overheat" node (weapon_template.fx_sources _muzzle of every
    -- forcestaff_p*_m1; Dio's Mercy Skins staff_fit). The farthest piece can be the butt on some staffs.
    for _, u in ipairs({ base, unpack(attachments or {}) }) do
        if unit_ok(u) and Unit.has_node(u, "fx_overheat") then
            local fx = Unit.world_position(u, Unit.node(u, "fx_overheat"))
            local d = Vector3.length(fx - origin)
            if d > 0.1 then
                dir = (fx - origin) / d
                source = "fx_overheat node"
            end
            break
        end
    end
    local base_rot = Unit.world_rotation(base, 1)
    local base_axes = { Quaternion.right(base_rot), Quaternion.forward(base_rot), Quaternion.up(base_rot) }
    local best, best_axis = 0, nil
    for i = 1, 3 do
        local d = Vector3.dot(base_axes[i], dir)
        if math.abs(d) > best then
            best = math.abs(d)
            best_axis = d < 0 and -base_axes[i] or base_axes[i]
        end
    end
    if best_axis and best > 0.97 then
        dir = best_axis
        source = string.format("base unit axis (%.2f to hand->farthest)", best)
    end
    if opt("staff_flip") then
        dir = -dir
    end
    local t_min, t_max = 0, 0
    for i = 1, #parts do
        local t = Vector3.dot(parts[i].center - origin, dir)
        t_min = math.min(t_min, t - parts[i].half)
        t_max = math.max(t_max, t + parts[i].half)
    end
    local length = t_max - t_min
    if length <= 0 then
        return false
    end
    local ls = (opt("staff_scale") or 1) * (first_person and (opt("fp_scale") or 0.6) or 1)
    local s_world = length * ls
    local shift = opt("staff_grip") or 0
    local ref, ref_dot = nil, nil
    for i = 1, 3 do
        local d = math.abs(Vector3.dot(base_axes[i], dir))
        if ref_dot == nil or d < ref_dot then
            ref, ref_dot = base_axes[i], d
        end
    end
    local up = Vector3.normalize(ref - dir * Vector3.dot(ref, dir))
    local roll = math.rad(opt("staff_roll") or 0)
    if roll ~= 0 then
        local side = Vector3.cross(dir, up)
        up = up * math.cos(roll) + side * math.sin(roll)
    end
    local tilt = math.rad(opt("staff_tilt") or 0)
    if tilt ~= 0 then
        local side = Vector3.cross(dir, up)
        dir = Vector3.normalize(dir * math.cos(tilt) + side * math.sin(tilt))
    end
    local butt = origin + dir * (t_min * ls - shift * s_world)
    local bx, by, bz = base_axes[1], base_axes[2], base_axes[3]
    local function to_local(v)
        return Vector3(Vector3.dot(v, bx), Vector3.dot(v, by), Vector3.dot(v, bz))
    end
    local k = parent_scale and parent_scale > 0 and parent_scale or 1
    local s = s_world / k
    local local_pos = to_local(butt - origin) * (1 / k)
    local local_dir = to_local(dir)
    Unit.set_local_position(staff, 1, local_pos)
    Unit.set_local_rotation(staff, 1, Quaternion.look(local_dir, to_local(up)))
    Unit.set_local_scale(staff, 1, Vector3(s, s, s))
    fit_world_length = s_world
    if view then
        last_fit[view] = string.format("%s: %d pieces, dir by %s, length %.3f (hand at %.2f of it), local start %s, local dir %s",
            view, #parts, source, length, -t_min / length, fmt(local_pos), fmt(local_dir))
    end
    return true
end

local function hide_originals(base, attachments)
    Unit.set_unit_visibility(base, false, true)
    if attachments then
        for i = 1, #attachments do
            if unit_ok(attachments[i]) then
                Unit.set_unit_visibility(attachments[i], false, true)
            end
        end
    end
end

-- Glow and motion ----------------------------------------------------------------

local function now()
    local time = Managers.time
    local ok, t = pcall(time.time, time, "main") -- gameplay_session.lua:22 reads Managers.time:time("main")
    return ok and t or 0
end

-- peril of the staff's holder: unit_data_extension:read_component("warp_charge").current_percentage
-- (force_weapon_effects.lua:32, action_psyker_shout.lua:45). 0 in menus or when unreadable.
local function peril_of(player_unit)
    if not unit_ok(player_unit) then
        return 0
    end
    local ok, p = pcall(function()
        local ude = ScriptUnit.has_extension(player_unit, "unit_data_system")
        local c = ude and ude:read_component("warp_charge")
        return c and c.current_percentage or 0
    end)
    return ok and tonumber(p) or 0
end

local function v3(t)
    return Vector3(t[1], t[2], t[3])
end

-- Whole-unit glow colour (Unit.set_vector3_for_materials, visual_loadout_customization.lua:534; per-slot colour calls
-- did not take in game in Dio's Mercy Skins 1.4.1). "Original" keeps the baked colours: switching back to it
-- respawns the unit (sync_record) because one whole-unit call cannot restore two baked colours.
local function apply_color(rec)
    local c = GLOW_COLORS[opt("glow_color")]
    if c then
        Unit.set_vector3_for_materials(rec.sword, "emissive_color", Vector3(c[1], c[2], c[3]), true)
        rec.custom_color = true
    end
    rec.color_gen = glow_generation
end

-- weapon_action.current_action_name (scripts/utilities/action/action.lua): action_charge, action_charge_flame,
-- action_shoot_flame, action_shoot_charged(_flame), action_trigger_explosion on the forcestaff templates
-- (list from Dio's Mercy Skins psyker_charging)
local CHARGE_ACTIONS = { "charge", "flame", "shoot_charged", "trigger_explosion" }

local function read_comp(ude, name)
    local ok, comp = pcall(ude.read_component, ude, name)
    return ok and comp or nil
end

-- holder state: peril, charging, combat ability active (Dio's Mercy Skins fx_update reads the same components)
local function holder_state(holder_unit)
    local ude = unit_ok(holder_unit) and ScriptUnit.has_extension(holder_unit, "unit_data_system")
    if not ude then
        return 0, false, false
    end
    local warp = read_comp(ude, "warp_charge")
    local peril = warp and tonumber(warp.current_percentage) or 0
    local charging = false
    local wa = read_comp(ude, "weapon_action")
    local name = wa and wa.current_action_name
    if type(name) == "string" and name ~= "none" then
        for i = 1, #CHARGE_ACTIONS do
            if string.find(name, CHARGE_ACTIONS[i], 1, true) then
                charging = true
                break
            end
        end
    end
    local ability = false
    local action = read_comp(ude, "combat_ability_action")
    local ab = read_comp(ude, "combat_ability")
    ability = (action and action.current_action_name and action.current_action_name ~= "none") or (ab and ab.active) or false
    return peril, charging, ability
end

-- bone handles + the body axes in hw_root space (from the marker bones)
local function bones_init(rec, model)
    rec.bones = {}
    local unit = rec.sword
    if not (Unit.has_node(unit, "staff_head") and Unit.has_node(unit, "hw_axis_x")) then
        return
    end
    local ey = Unit.local_position(unit, Unit.node(unit, "staff_head"))
    local ex = Unit.local_position(unit, Unit.node(unit, "hw_axis_x")) * 10
    local len = Vector3.length(ey)
    if len < 1e-6 or Vector3.length(ex) < 1e-6 then
        return
    end
    local ez = Vector3.cross(Vector3.normalize(ex), Vector3.normalize(ey)) * len
    rec.ax = { Vector3Box(ex), Vector3Box(ey), Vector3Box(ez) }
    for i = 1, #model.parts do
        local m = model.parts[i]
        if Unit.has_node(unit, m.bone) then
            local n = Unit.node(unit, m.bone)
            rec.bones[#rec.bones + 1] = { m = m, node = n, pos = Vector3Box(Unit.local_position(unit, n)), rot = QuaternionBox(Unit.local_rotation(unit, n)) }
        end
    end
end

local function animate(rec, model, holder_unit)
    local unit = rec.sword
    local t = now()
    local dt = rec.last_t and math.min(0.1, math.max(0, t - rec.last_t)) or 0
    rec.last_t = t
    local peril, charging, ability = holder_state(holder_unit)
    rec.peril = (rec.peril or 0) + (peril - (rec.peril or 0)) * 0.15
    local want_open = (charging and opt("charge_reaction") ~= false) and 1 or 0
    rec.open = (rec.open or 0) + (want_open - (rec.open or 0)) * math.min(dt * (want_open > (rec.open or 0) and 6 or 3), 1)
    if ability and opt("ability_flare") ~= false then
        rec.flare = math.min(1, (rec.flare or 0) + dt * 5)
        rec.hold = 1.2
    else
        rec.hold = math.max(0, (rec.hold or 0) - dt)
        if rec.hold <= 0 then
            rec.flare = math.max(0, (rec.flare or 0) - dt * 1.2)
        end
    end

    -- glow: per-slot intensity (ammo_display.lua:85, per-slot scalar works in game: Prototype 1.3 / Skull Runeblade),
    -- at 15 Hz and only when a value moved (the material calls walk every mesh; Dio's Mercy Skins does the same)
    if rec.color_gen ~= glow_generation then
        apply_color(rec)
    end
    rec.glow_acc = (rec.glow_acc or 1) + dt
    if rec.glow_acc >= 1 / 15 then
        rec.glow_acc = 0
        local base = opt("glow_brightness") or 2
        local extra = (opt("glow_peril") or 0) * rec.peril + (opt("glow_charge") or 8) * rec.open
        local boost = 1 + 1.5 * (rec.flare or 0)
        local depth = opt("glow_pulse") or 0
        local w = 2 * math.pi * (opt("glow_pulse_speed") or 0.8)
        if peril > 0.8 then
            depth, w = math.max(depth, 0.6), 2 * math.pi * 1.3 -- danger: fast pulse near overload
        end
        rec.last_glow = rec.last_glow or {}
        for i = 1, #model.glow do
            local g = model.glow[i]
            local v
            if g.orb then
                v = (opt("orb_brightness") or 0.15) * (1 + 0.5 * depth * math.sin(w * 0.7 * t) + 0.5 * rec.peril + 2 * rec.open) * boost
            else
                v = (base + extra) * g.k * (1 + depth * math.sin(w * t + (g.shimmer and 1.7 or 0))) * boost
            end
            v = math.max(0, v)
            local last = rec.last_glow[g.slot]
            if last == nil or math.abs(last - v) >= 0.03 * math.max(last, 0.1) then
                rec.last_glow[g.slot] = v
                pcall(Unit.set_scalar_for_material, unit, g.slot, "intensity", v)
            end
        end
    end

    -- moving parts: bones of the skinned unit, turned in hw_root space (Mercy's petals: axis_angle x rest rotation)
    if not rec.bones then
        bones_init(rec, model)
    end
    if not rec.ax then
        return
    end
    local ex, ey, ez = rec.ax[1]:unbox(), rec.ax[2]:unbox(), rec.ax[3]:unbox()
    local function to_root(v) -- body vector (body units) -> hw_root space
        return ex * v.x + ey * v.y + ez * v.z
    end
    local on = opt("motion_enabled")
    local speed = (opt("spin_speed") or 1) * (1 + (opt("peril_speed") or 0) * rec.peril) * (1 + 2.5 * rec.open + 2 * (rec.flare or 0))
    local float = opt("float_amount") or 1
    local flap = opt("wing_flap") or 1
    local phys = opt("orb_physics") or 1
    local spread = math.rad(opt("charge_spread") or 15) * rec.open
    rec.phase = (rec.phase or 0) + dt * speed

    -- inertia: the unit root's world acceleration in body units and body axes drives the springs
    local acc = nil
    if dt > 0 and phys > 0 then
        local wp = Unit.world_position(unit, 1)
        local inv = Quaternion.inverse(Unit.world_rotation(unit, 1))
        local len = rec.world_len or 1
        if rec.prev_wp then
            local vel = (wp - rec.prev_wp:unbox()) * (1 / dt)
            if rec.prev_vel then
                local a = (vel - rec.prev_vel:unbox()) * (1 / dt)
                if Vector3.length(a) < 400 then -- teleports / respawns are not motion
                    acc = Quaternion.rotate(inv, a) * (1 / len)
                end
            end
            rec.prev_vel = Vector3Box(vel)
        end
        rec.prev_wp = Vector3Box(wp)
    end
    local function spring(e, sp, gain)
        local o = e.off and e.off:unbox() or Vector3(0, 0, 0)
        local v = e.vel and e.vel:unbox() or Vector3(0, 0, 0)
        local a = o * (-sp.pull) - v * sp.drag
        if acc then
            a = a - acc * (phys * (gain or 1))
        end
        v = v + a * dt
        o = o + v * dt
        e.off = Vector3Box(o)
        e.vel = Vector3Box(v)
        return o, v
    end

    -- rotations are built from (body axis, angle) pairs converted to hw_root space on creation (to_root is a rotation
    -- times a uniform scale, so converting each factor equals converting the product)
    local function rq(axis_body, ang)
        return Quaternion.axis_angle(Vector3.normalize(to_root(axis_body)), ang)
    end
    for i = 1, #rec.bones do
        local e = rec.bones[i]
        local m = e.m
        local rot = e.rot:unbox()
        if on then
            if m.spin then
                rot = Quaternion.multiply(rq(Vector3(0, 1, 0), math.rad(m.spin * rec.phase)), rot)
            end
            if m.tip then
                local tip = v3(m.tip)
                local tl = math.max(Vector3.length(tip), 0.01)
                local tipn = Vector3.normalize(tip)
                local across = Vector3.cross(Vector3(0, 1, 0), tipn)
                if Vector3.length(across) < 0.05 then
                    across = Vector3(1, 0, 0)
                end
                across = Vector3.normalize(across)
                -- idle sway, float (as an arc of the tip), spread while charging (as the caduceus petals open)
                local ang = math.rad((m.flap or 0) * flap * math.sin(2 * math.pi * (m.flap_hz or 0.3) * t))
                    + spread * (m.spread or 0)
                if m.bob then
                    ang = ang + (m.bob / tl) * float * (1 + rec.open) * math.sin(2 * math.pi * m.bob_hz * t)
                end
                if ang ~= 0 then
                    rot = Quaternion.multiply(rq(across, ang), rot)
                end
                if m.swing and phys > 0 and dt > 0 then
                    -- inertia: the tip lags behind the motion; the lag turns the part about its pivot
                    local o = spring(e, m.swing, m.swing.gain)
                    local o_perp = o - tipn * Vector3.dot(o, tipn)
                    local l = Vector3.length(o_perp)
                    local sw = math.min(l / tl, m.swing.max)
                    if l / tl > m.swing.max then
                        e.off = Vector3Box(o * (m.swing.max * tl / math.max(l, 1e-6)))
                    end
                    if sw > 0.0005 then
                        rot = Quaternion.multiply(rq(Vector3.cross(tipn, o_perp), sw), rot)
                    end
                end
            end
        end
        Unit.set_local_rotation(unit, e.node, rot)
    end
end

-- Records: one per (holder, slot, view) { sword = unit, base, key, frames, count } ----------------------

local function sync_record(records, key, base, attachments, item, visible, spawn_fn, destroy_fn, parent_scale, first_person, holder_unit)
    local rec = records[key]
    local want = unit_ok(base) and wants_item(item) and attachments ~= nil
    local mk = model_key()
    -- back to the "Original" glow colour after a custom one: a fresh unit has the baked colours again
    local recolour = rec and rec.custom_color and not GLOW_COLORS[opt("glow_color")]
    if rec and (recolour or not want or rec.base ~= base or rec.model ~= mk or not unit_ok(rec.sword)) then
        for _, part in ipairs(rec.parts or {}) do
            destroy_fn(part.unit)
        end
        destroy_fn(rec.sword)
        records[key] = nil
        if rec.hid and rec.base == base and unit_ok(base) and visible then
            Unit.set_unit_visibility(base, true, true)
        end
        rec = nil
    end
    if not want then
        return false
    end
    if not rec then
        local staff = spawn_fn(base, unit_path(mk))
        if not staff then
            return false
        end
        if first_person then
            Unit.set_shader_pass_flag_for_meshes_in_unit_and_childs(staff, "custom_fov", true)
        end
        rec = { sword = staff, base = base, model = mk, frames = 0, count = -1, fitted = false }
        records[key] = rec
    end
    if rec.count ~= #attachments or rec.gen ~= fit_generation then
        rec.gen = fit_generation
        rec.count = #attachments
        rec.frames = 0
    end
    if rec.frames < FIT_FRAMES then
        rec.frames = rec.frames + 1
        local base_scale = Unit.local_scale(base, 1)
        local k = (parent_scale or 1) * (base_scale and base_scale.x or 1)
        if fit(rec.sword, base, attachments, k, key, first_person) then
            rec.fitted = true
            rec.world_len = fit_world_length
        end
    end
    if rec.fitted and visible then
        hide_originals(base, attachments)
        rec.hid = true
        Unit.set_unit_visibility(rec.sword, true, true)
        animate(rec, MODELS[mk], holder_unit)
    else
        Unit.set_unit_visibility(rec.sword, false, true)
    end
    return true
end

local function clear_records(records, destroy_fn)
    if not records then
        return
    end
    for key, rec in pairs(records) do
        for _, part in ipairs(rec.parts or {}) do
            destroy_fn(part.unit)
        end
        destroy_fn(rec.sword)
        records[key] = nil
    end
end

-- In game --------------------------------------------------------------------------

local function ingame_spawn(ext, is_first_person)
    return function(parent, path)
        local world = ext.__qiangiq_hwstaff_world
        local unit_spawner = Managers.state and Managers.state.unit_spawner
        if not (world and unit_spawner) then
            return nil
        end
        local unit = unit_spawner:spawn_unit(path, Unit.world_pose(parent, 1))
        if not unit then
            return nil
        end
        if is_first_person then
            Unit.set_unit_culling(unit, false)
        end
        World.link_unit(world, unit, 1, parent, 1, World.LINK_MODE_NODE_NAME)
        return unit
    end
end

local function ingame_destroy(unit)
    if unit_ok(unit) then
        local unit_spawner = Managers.state and Managers.state.unit_spawner
        if unit_spawner then
            unit_spawner:mark_for_deletion(unit)
        end
    end
end

local function ingame_apply(ext)
    local records = ext.__qiangiq_hwstaff_records
    if not records then
        records = {}
        ext.__qiangiq_hwstaff_records = records
    end
    local equipment = ext._equipment
    if not equipment then
        return
    end
    for slot_name, slot in pairs(equipment) do
        local item = slot.item
        if item and item.weapon_template == STAFF_TEMPLATE or records[slot_name .. ":3p"] or records[slot_name .. ":1p"] then
            local base_3p, base_1p = slot.unit_3p, slot.unit_1p
            local att_3p = base_3p and slot.attachments_by_unit_3p and slot.attachments_by_unit_3p[base_3p]
            local att_1p = base_1p and slot.attachments_by_unit_1p and slot.attachments_by_unit_1p[base_1p]
            sync_record(records, slot_name .. ":3p", base_3p, att_3p, item, slot.hidden_3p == false,
                ingame_spawn(ext, false), ingame_destroy, 1, false, ext._unit)
            sync_record(records, slot_name .. ":1p", base_1p, att_1p, item, slot.hidden_1p == false,
                ingame_spawn(ext, true), ingame_destroy, 1, true, ext._unit)
        end
    end
end

vl_hook_safe("init", function(self, extension_init_context)
    self.__qiangiq_hwstaff_world = extension_init_context and extension_init_context.world
end)

vl_hook_safe("_update_item_visibility", function(self)
    if not sync_shown(self) then
        return
    end
    tracked[self] = true
    ingame_apply(self)
end)

vl_hook_safe("update", function(self)
    if tracked[self] then
        ingame_apply(self)
    end
end)

vl_hook("_unequip_item_from_slot", function(func, self, slot_name, ...)
    local records = self.__qiangiq_hwstaff_records
    if records then
        for _, view in ipairs({ ":3p", ":1p" }) do
            local rec = records[slot_name .. view]
            if rec then
                for _, part in ipairs(rec.parts or {}) do
                    ingame_destroy(part.unit)
                end
                ingame_destroy(rec.sword)
                records[slot_name .. view] = nil
            end
        end
    end
    return func(self, slot_name, ...)
end)

vl_hook("destroy", function(func, self, ...)
    clear_records(self.__qiangiq_hwstaff_records, ingame_destroy)
    tracked[self] = nil
    return func(self, ...)
end)

-- Menu previews (QIangIQsSpearArsenal) ------------------------------------------------

local function local_player()
    local players = Managers.player
    if not players then
        return nil
    end
    local ok, player = pcall(players.local_player_safe, players, 1)
    return ok and player or nil
end

local function ui_profile_is_mine(profile)
    if not profile then
        return false
    end
    local players = Managers.player and Managers.player:players()
    local me = local_player()
    if players and profile.character_id then
        for _, player in pairs(players) do
            if player ~= me and player.character_id and player:character_id() == profile.character_id then
                return false
            end
        end
    end
    return true
end

local function ui_spawn(world)
    return function(parent, path)
        local unit = World.spawn_unit_ex(world, path, nil, Unit.world_pose(parent, 1))
        World.link_unit(world, unit, 1, parent, 1, World.LINK_MODE_NODE_NAME)
        return unit
    end
end

local function ui_destroy_fn(world)
    return function(unit)
        if unit_ok(unit) and world then
            World.destroy_unit(world, unit)
        end
    end
end

local function scale_x(unit)
    if unit_ok(unit) then
        local s = Unit.local_scale(unit, 1)
        return s and s.x or 1
    end
    return 1
end

local function profile_apply(spawner)
    local world = spawner._world
    local records = spawner.__qiangiq_hwstaff_records
    if not records then
        records = {}
        spawner.__qiangiq_hwstaff_records = records
    end
    local data = spawner._character_spawn_data
    local allowed = data and data.slots and opt("menu_previews") and ui_profile_is_mine(data.profile)
    if not allowed then
        clear_records(records, ui_destroy_fn(world))
        return
    end
    tracked_ui[spawner] = true
    local k = scale_x(data.unit_3p)
    for slot_name, slot in pairs(data.slots) do
        local item = slot.item
        if item and item.weapon_template == STAFF_TEMPLATE or records[slot_name] then
            local base = slot.unit_3p
            local att = base and slot.attachments_by_unit_3p and slot.attachments_by_unit_3p[base]
            sync_record(records, slot_name, base, att, item, spawner._visible and slot.hidden_3p == false,
                ui_spawn(world), ui_destroy_fn(world), k, false, nil)
        end
    end
end

mod:hook_safe(CLASS.UIProfileSpawner, "_update_items_visibility", function(self)
    profile_apply(self)
end)

mod:hook_safe(CLASS.UIProfileSpawner, "update", function(self)
    local data = self._character_spawn_data
    if data and data.is_ready then
        profile_apply(self)
    elseif self.__qiangiq_hwstaff_records then
        clear_records(self.__qiangiq_hwstaff_records, ui_destroy_fn(self._world))
    end
end)

mod:hook(CLASS.UIProfileSpawner, "_despawn_current_character_profile", function(func, self, ...)
    clear_records(self.__qiangiq_hwstaff_records, ui_destroy_fn(self._world))
    return func(self, ...)
end)

local function weapon_apply(spawner)
    local world = spawner._world
    local records = spawner.__qiangiq_hwstaff_records
    if not records then
        records = {}
        spawner.__qiangiq_hwstaff_records = records
    end
    local data = spawner._weapon_spawn_data
    if not (data and opt("menu_previews")) then
        if next(records) ~= nil then
            clear_records(records, ui_destroy_fn(world))
            if data and data.visible and unit_ok(data.item_unit_3p) then
                Unit.set_unit_visibility(data.item_unit_3p, true, true)
            end
        end
        return
    end
    tracked_wpn[spawner] = true
    local base = data.item_unit_3p
    local att = base and data.attachment_units_3p and data.attachment_units_3p[base]
    local k = scale_x(data.link_unit)
    sync_record(records, "weapon", base, att, data.item, data.visible and true or false,
        ui_spawn(world), ui_destroy_fn(world), k, false, nil)
end

mod:hook_safe(CLASS.UIWeaponSpawner, "update", function(self)
    weapon_apply(self)
end)

mod:hook(CLASS.UIWeaponSpawner, "_despawn_current_weapon", function(func, self, ...)
    clear_records(self.__qiangiq_hwstaff_records, ui_destroy_fn(self._world))
    return func(self, ...)
end)

-- Refresh / toggles -------------------------------------------------------------------

local function refresh_all()
    for ext in pairs(tracked) do
        if unit_ok(ext._unit) then
            ingame_apply(ext)
            ext:force_update_item_visibility()
        end
    end
    for spawner in pairs(tracked_ui) do
        profile_apply(spawner)
        if spawner._character_spawn_data and spawner._visible then
            spawner:_update_items_visibility()
        end
    end
    for spawner in pairs(tracked_wpn) do
        weapon_apply(spawner)
    end
end

local function after_change()
    fit_generation = fit_generation + 1
    glow_generation = glow_generation + 1
    refresh_all()
end

mod.toggle_staff = function()
    session_off = not session_off
    refresh_all()
    mod:echo("Horizon Staffs %s for this session", session_off and "off" or "on")
end

mod.cycle_staff = function()
    local k = model_key() == "qps" and "sol" or "qps"
    mod:set("staff_choice", k, true)
    mod:echo("Horizon Staffs: %s", MODELS[k].name)
end

-- Only one QIangIQ mod shows a force staff at a time (QIangIQsSpearArsenal / QIangIQsWarframeArsenal
-- mod.release_template). This mod loads after both, so it keeps the Inferno staff when it is switched on.
local OTHER_STAFF_MODS = { "QIangIQsSpearArsenal", "QIangIQsWarframeArsenal" }

local function claim_inferno()
    for _, name in ipairs(OTHER_STAFF_MODS) do
        local other = get_mod(name)
        if other and other.release_template then
            pcall(other.release_template, STAFF_TEMPLATE)
        end
    end
end

-- DMF runs on_all_mods_loaded in reverse load order (note model-sync/40), so at load the other staff mods have
-- not read their profiles yet when this mod's runs, and their load-time claims would switch this one off. The
-- claim therefore waits for the first frame (mod.update), and releases asked for before it are ignored: this mod
-- is the later one in the list and keeps the staff ("the later one in the list keeps it", notes 00).
local claim_pending = true

mod.update = function()
    if claim_pending then
        claim_pending = false
        if mod:get("replace_inferno_staff") ~= false then
            claim_inferno()
        end
    end
end

mod.release_template = function(template)
    if claim_pending then
        return
    end
    if template == STAFF_TEMPLATE and mod:get("replace_inferno_staff") then
        mod:set("replace_inferno_staff", false, false)
        after_change()
        mod:echo("The Inferno Force Staff is now shown by another QIangIQ mod: switched off in Horizon Staffs.")
    end
end

mod:command("hwstaff", "Horizon Staffs: /hwstaff (toggle), /hwstaff cycle, /hwstaff debug", function(which)
    if which == "debug" then
        local any = false
        for _, line in pairs(last_fit) do
            mod:echo(line)
            any = true
        end
        for ext in pairs(tracked) do
            for key, rec in pairs(ext.__qiangiq_hwstaff_records or {}) do
                mod:echo("%s: %s, %d moving bones, peril %.2f, charge %.2f, flare %.2f", key, MODELS[rec.model].name, rec.bones and #rec.bones or 0, rec.peril or 0, rec.open or 0, rec.flare or 0)
                any = true
            end
        end
        if not any then
            mod:echo("Nothing fitted yet: wield the Inferno Force Staff with the replacement switched on.")
        end
        return
    end
    if which == "cycle" then
        mod.cycle_staff()
        return
    end
    mod.toggle_staff()
end)

mod.on_setting_changed = function(setting_id)
    if setting_id == "replace_inferno_staff" and mod:get("replace_inferno_staff") then
        claim_inferno()
    end
    after_change()
end

mod.on_all_mods_loaded = function()
    custom_assets = get_mod("CustomAssets")
    if not custom_assets or not custom_assets.is_api_compatible or not custom_assets.is_api_compatible(1) then
        mod:error("Custom Assets (API 1) is missing. Install it and put it above QIangIQsHorizonStaffs in mod_load_order.txt.")
        return
    end
    for _, key in ipairs(ALL_UNITS) do
        local id = asset_id(key)
        local ticket, err = custom_assets.acquire(mod, id, function(_, _, load_error)
            if load_error then
                mod:error("%s failed to load: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", id, tostring(load_error))
                return
            end
            loaded[key] = true
            refresh_all()
        end, { resident = true, reference_name = id })
        if not ticket then
            mod:error("%s could not be requested: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", id, tostring(err))
        end
    end
end

local function remove_all()
    for ext in pairs(tracked) do
        clear_records(ext.__qiangiq_hwstaff_records, ingame_destroy)
    end
    for spawner in pairs(tracked_ui) do
        clear_records(spawner.__qiangiq_hwstaff_records, ui_destroy_fn(spawner._world))
    end
    for spawner in pairs(tracked_wpn) do
        clear_records(spawner.__qiangiq_hwstaff_records, ui_destroy_fn(spawner._world))
    end
end

mod.on_disabled = function()
    remove_all()
    for ext in pairs(tracked) do
        if unit_ok(ext._unit) then
            ext:force_update_item_visibility()
        end
    end
    for spawner in pairs(tracked_ui) do
        if spawner._character_spawn_data and spawner._visible then
            spawner:_update_items_visibility()
        end
    end
    for spawner in pairs(tracked_wpn) do
        local data = spawner._weapon_spawn_data
        if data and data.visible and unit_ok(data.item_unit_3p) then
            Unit.set_unit_visibility(data.item_unit_3p, true, true)
        end
    end
end

mod.on_enabled = function()
    refresh_all()
end

mod.on_unload = function()
    remove_all()
    if custom_assets and custom_assets.release_owner then
        custom_assets.release_owner(mod)
    end
end

-- Cross-client sync (QIangIQsModelSync): published when I carry the Inferno staff with this mod on --------

local sync_enabled = true
local function sync_changed()
    local api = sync_api()
    if api then
        api.changed()
    end
end

mod.sync_key = SYNC_KEY
mod.sync_export = function(info)
    info = info or {}
    if not sync_enabled or session_off or not mod:get("replace_inferno_staff") then
        return nil
    end
    if info.templates ~= nil and not info.templates[STAFF_TEMPLATE] then
        return nil
    end
    local mask, bit = 0, 1
    for i = 1, #SYNC_BOOLS do
        local key = SYNC_BOOLS[i]
        local v = mod:get(key)
        if v == nil then
            v = SYNC_DEFAULTS[key]
        end
        if v then
            mask = mask + bit
        end
        bit = bit * 2
    end
    local out = { SYNC_LAYOUT, mask }
    for i = 1, #SYNC_VALUES do
        local v = mod:get(SYNC_VALUES[i])
        if type(v) == "number" then
            v = math.floor(v * 100 + 0.5) / 100
        elseif type(v) ~= "string" then
            v = false
        end
        out[2 + i] = v
    end
    return out
end

mod.sync_refresh = function()
    for ext in pairs(sync_all) do
        if ext._unit and Unit.alive(ext._unit) and ext.force_update_item_visibility then
            pcall(ext.force_update_item_visibility, ext)
        end
    end
end

local sync_prev_setting_changed = mod.on_setting_changed
mod.on_setting_changed = function(...)
    if sync_prev_setting_changed then
        sync_prev_setting_changed(...)
    end
    sync_changed()
end

local sync_prev_disabled = mod.on_disabled
mod.on_disabled = function(...)
    sync_enabled = false
    if sync_prev_disabled then
        sync_prev_disabled(...)
    end
    sync_changed()
end

local sync_prev_enabled = mod.on_enabled
mod.on_enabled = function(...)
    sync_enabled = true
    if sync_prev_enabled then
        sync_prev_enabled(...)
    end
    sync_changed()
end

-- QIangIQsArmoryVis: stowed-weapon copies (see QIangIQsArmoryVis/README.md). Armory Vis calls apply every frame
-- and clear once per copy with `holder` (one table per character and stowed slot: _unit, _player, _ext,
-- _slot_name) and `equipment` ({ [slot_name] = slot-like table of the copy, hidden_3p false while shown }).
-- The in-game apply above runs on the holder as it runs on a loadout extension.
mod.armory_vis = {
    apply = function(holder, world, equipment)
        holder.__qiangiq_hwstaff_world = world
        holder._equipment = equipment
        ingame_apply(holder)
    end,
    clear = function(holder)
        clear_records(holder.__qiangiq_hwstaff_records, ingame_destroy)
        holder.__qiangiq_hwstaff_records = nil
    end,
}
