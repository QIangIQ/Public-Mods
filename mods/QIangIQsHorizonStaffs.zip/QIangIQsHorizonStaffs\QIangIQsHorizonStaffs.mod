return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsHorizonStaffs` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsHorizonStaffs", {
            mod_script = "QIangIQsHorizonStaffs/scripts/mods/QIangIQsHorizonStaffs/QIangIQsHorizonStaffs",
            mod_data = "QIangIQsHorizonStaffs/scripts/mods/QIangIQsHorizonStaffs/QIangIQsHorizonStaffs_data",
            mod_localization = "QIangIQsHorizonStaffs/scripts/mods/QIangIQsHorizonStaffs/QIangIQsHorizonStaffs_localization",
        })
    end,
    version = "1.3.1",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
