return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsSteelKanabo` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsSteelKanabo", {
            mod_script = "QIangIQsSteelKanabo/scripts/mods/QIangIQsSteelKanabo/QIangIQsSteelKanabo",
            mod_data = "QIangIQsSteelKanabo/scripts/mods/QIangIQsSteelKanabo/QIangIQsSteelKanabo_data",
            mod_localization = "QIangIQsSteelKanabo/scripts/mods/QIangIQsSteelKanabo/QIangIQsSteelKanabo_localization",
        })
    end,
    version = "1.1.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
