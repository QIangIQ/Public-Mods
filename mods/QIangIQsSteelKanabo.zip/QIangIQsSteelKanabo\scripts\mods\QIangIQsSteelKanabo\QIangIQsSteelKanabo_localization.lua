return {
    mod_name = {
        en = "QIangIQ's Steel Kanabo",
    },
    mod_description = {
        en = "Shows the Steel Kanabo model (Custom Assets) in place of the Bully Club (Mk I, Mk II, Mk IIIb). By QIangIQ.",
    },
    replace_mk1 = {
        en = "Replace Bully Club Mk I",
    },
    replace_mk1_description = {
        en = "Weapon template ogryn_club_p2_m1. Chat command: /kanabo 1",
    },
    replace_mk2 = {
        en = "Replace Bully Club Mk II",
    },
    replace_mk2_description = {
        en = "Weapon template ogryn_club_p2_m2. Chat command: /kanabo 2",
    },
    replace_mk3 = {
        en = "Replace Bully Club Mk IIIb",
    },
    replace_mk3_description = {
        en = "Weapon template ogryn_club_p2_m3. Chat command: /kanabo 3 (switches the Verdict Axe off for this mark)",
    },
    model_size = {
        en = "Size",
    },
    model_size_description = {
        en = "1 = the head reaches as far from your hand as the original weapon's.",
    },
    model_roll = {
        en = "Spin around its length (degrees)",
    },
    model_roll_description = {
        en = "Turns the model around its own long axis, e.g. if it is lying on its side or upside down.",
    },
    model_slide = {
        en = "Slide through the hand",
    },
    model_slide_description = {
        en = "Moves the model forwards (+) or backwards (-) along its length, as a fraction of its length.",
    },
    flip_model = {
        en = "Flip end to end",
    },
    flip_model_description = {
        en = "Use this if the head points backwards.",
    },
    menu_previews = {
        en = "Show in menus (inventory, operative previews)",
    },
    menu_previews_description = {
        en = "Also swaps the weapon in menu previews of your own operatives and in the weapon inspect view.",
    },
    toggle_keybind = {
        en = "Toggle Steel Kanabo replacement (all marks)",
    },
}
