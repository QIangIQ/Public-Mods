local mod = get_mod("QIangIQsSteelKanabo")

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = true,
    options = {
        widgets = {
            {
                setting_id = "replace_mk1",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "replace_mk2",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "replace_mk3",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "model_size",
                type = "numeric",
                default_value = 1,
                range = { 0.25, 3 },
                decimals_number = 2,
            },
            {
                setting_id = "model_roll",
                type = "numeric",
                default_value = 0,
                range = { -180, 180 },
                decimals_number = 0,
            },
            {
                setting_id = "model_slide",
                type = "numeric",
                default_value = 0,
                range = { -0.5, 0.5 },
                decimals_number = 2,
            },
            {
                setting_id = "flip_model",
                type = "checkbox",
                default_value = false,
            },
            {
                setting_id = "menu_previews",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "toggle_keybind",
                type = "keybind",
                default_value = {},
                keybind_trigger = "pressed",
                keybind_type = "function_call",
                function_name = "toggle_weapon",
            },
        },
    },
}
