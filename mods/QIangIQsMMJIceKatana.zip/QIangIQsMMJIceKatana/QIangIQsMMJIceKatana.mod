return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsMMJIceKatana` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsMMJIceKatana", {
            mod_script = "QIangIQsMMJIceKatana/scripts/mods/QIangIQsMMJIceKatana/QIangIQsMMJIceKatana",
            mod_data = "QIangIQsMMJIceKatana/scripts/mods/QIangIQsMMJIceKatana/QIangIQsMMJIceKatana_data",
            mod_localization = "QIangIQsMMJIceKatana/scripts/mods/QIangIQsMMJIceKatana/QIangIQsMMJIceKatana_localization",
        })
    end,
    version = "0.1.0",
    author = "QIangIQ",
    packages = {},
}
