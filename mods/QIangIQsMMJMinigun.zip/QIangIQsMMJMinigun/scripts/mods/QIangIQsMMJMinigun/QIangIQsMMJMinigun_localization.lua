return {
    mod_name = {
        en = "QIangIQ's MMJ Minigun",
    },
    mod_description = {
        en = "Replaces the Braced Autogun with Mullet Mad Jack's minigun: MMJ's sprites and clips in first person (spin up, fire, spin down) with its sounds. Visual only: the weapon still works as before. Contains Mullet Mad Jack art and audio: personal use only.",
    },
    command_desc = { en = "MMJ Minigun status (add flip to turn the sprite rotation round)" },
    replace_autogun_p2_m1 = { en = "Replace Braced Autogun (autogun_p2_m1)" },
    replace_autogun_p2_m2 = { en = "Replace Braced Autogun (autogun_p2_m2)" },
    replace_autogun_p2_m3 = { en = "Replace Braced Autogun (autogun_p2_m3)" },
    third_person = { en = "Third person: your character" },
    third_person_others = { en = "Third person: other players" },
    third_person_hide = { en = "Hide the weapon" },
    third_person_retail = { en = "Show the weapon" },
    sounds = { en = "MMJ sounds" },
    volume = { en = "Sound volume (%%)" },
    layout = { en = "Screen layout" },
    mmj_fov = { en = "MMJ weapon camera field of view (degrees)" },
    size = { en = "Size (%%)" },
    offset_x = { en = "Move right (cm)" },
    offset_y = { en = "Move up (cm)" },
    smear_cap = { en = "Fade sprites bigger than this share of the screen (%%, 0 = off)" },
}
