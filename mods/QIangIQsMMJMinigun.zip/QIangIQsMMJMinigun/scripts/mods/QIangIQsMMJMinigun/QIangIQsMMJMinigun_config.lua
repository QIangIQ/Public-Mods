-- QIangIQsMMJMinigun per-weapon data (gen.py spec minigun). Clips are MMJ clip names from minigun\OBJ-Weapond-Minigun__16946.
-- Action map sources: Darktide weapon templates (Aussiemon master) via tools\dump_actions.py.
return {
    ranged = true,
    idle = "minigun - iddle",
    templates = { autogun_p2_m1 = true, autogun_p2_m2 = true, autogun_p2_m3 = true },
    shot = { clips = { "minigun - fire" }, sounds = { "mmc_sfx_weapon_machinegun_click_01.ogg", "mmc_sfx_weapon_machinegun_click_02.ogg", "mmc_sfx_weapon_machinegun_click_03.ogg", "mmc_sfx_weapon_machinegun_click_04.ogg" } },
    actions = {
        action_wield = { clips = { "minigun - pickup" }, over_shot = true, sounds = { "sfx_gp_wp_machinegun_intro.ogg" } },
        action_shoot_hip = { clips = { "minigun - start", "minigun - cycle" }, loop_last = true, sounds = { "mmc_sfx_weapon_machinegun_windup.ogg" } },
        action_shoot_zoomed = { clips = { "minigun - start", "minigun - cycle" }, loop_last = true, sounds = { "mmc_sfx_weapon_machinegun_windup.ogg" } },
        action_reload = { clips = { "minigun - end" }, hold = true, over_shot = true, sounds = { "mmc_sfx_weapon_machinegun_windown.ogg" } },
    },
}
