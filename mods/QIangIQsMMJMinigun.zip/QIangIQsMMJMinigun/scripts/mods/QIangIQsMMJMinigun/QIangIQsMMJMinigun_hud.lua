-- The first-person MMJ weapon sprites, drawn as one HUD element (DMF register_hud_element; pass pool pattern from
-- QIangIQsMMJHud's hud_element_mmj_hud.lua). Each sprite is a rotated_texture pass (ui_passes.lua: angle in radians,
-- pivot in pixels from the top-left, uvs, material_values applied on every draw, so texture_map can change per frame).
-- Being a normal HUD element, it is laid out inside QIangIQsMMJHud's game screen when that mod fits the HUD into it.
local mod = get_mod("QIangIQsMMJMinigun")
local UIWorkspaceSettings = require("scripts/settings/ui/ui_workspace_settings")
local UIWidget = require("scripts/managers/ui/ui_widget")

local MATERIAL = "content/ui/materials/base/ui_default_base"
-- pass pool: the most sprites any baked frame of this weapon draws, plus a margin (gen.py)
local SPRITES = 15

local function sprite_passes()
    local passes = {}

    for i = 1, SPRITES do
        passes[i] = {
            pass_type = "rotated_texture",
            value_id = "s" .. i,
            style_id = "s" .. i,
            value = MATERIAL,
            style = {
                color = { 255, 255, 255, 255 },
                offset = { 0, 0, 1 },
                size = { 0, 0 },
                angle = 0,
                pivot = { 0, 0 },
                uvs = { { 0, 0 }, { 1, 1 } },
                material_values = {},
                visible = false,
            },
        }
    end

    return passes
end

local definitions = {
    scenegraph_definition = {
        screen = UIWorkspaceSettings.screen,
    },
    widget_definitions = {
        sprites = UIWidget.create_definition(sprite_passes(), "screen"),
    },
}

HudElementQIangIQsMMJMinigun = class("HudElementQIangIQsMMJMinigun", "HudElementBase")

function HudElementQIangIQsMMJMinigun:init(parent, draw_layer, start_scale)
    HudElementQIangIQsMMJMinigun.super.init(self, parent, draw_layer, start_scale, definitions)

    self._widget = self._widgets_by_name.sprites
end

function HudElementQIangIQsMMJMinigun:update(dt, t, ui_renderer, render_settings, input_service)
    HudElementQIangIQsMMJMinigun.super.update(self, dt, t, ui_renderer, render_settings, input_service)

    local api = mod.mmj_weapon
    local rects = api and not rawget(_G, "__qiangiq_taunt_hide_weapon") and api.rects(dt, t) -- none while QIangIQsTaunts plays a taunt
    local style = self._widget.style
    local n = 0

    if rects then
        for _, r in ipairs(rects) do
            local tex = api.texture(r.sprite)

            if n < SPRITES and tex and tex.texture then
                n = n + 1

                local st = style["s" .. n]

                st.visible = true
                st.offset[1], st.offset[2], st.offset[3] = r.x, r.y, n
                st.size[1], st.size[2] = r.w, r.h
                st.pivot[1], st.pivot[2] = r.pivot_x, r.pivot_y
                st.angle = r.angle
                st.uvs[1][1], st.uvs[2][1] = r.mirror and 1 or 0, r.mirror and 0 or 1
                st.material_values.texture_map = tex.texture
                -- UI colours are { a, r, g, b } 0-255
                st.color[1], st.color[2], st.color[3], st.color[4] = (r.a or 1) * 255, (r.r or 1) * 255, (r.g or 1) * 255, (r.b or 1) * 255
            end
        end
    end

    for i = n + 1, SPRITES do
        local st = style["s" .. i]

        st.visible = false
        st.material_values.texture_map = nil
    end

    self._widget.dirty = true
end

return HudElementQIangIQsMMJMinigun
