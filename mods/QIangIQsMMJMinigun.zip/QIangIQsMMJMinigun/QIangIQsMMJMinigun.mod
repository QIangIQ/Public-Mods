return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsMMJMinigun` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsMMJMinigun", {
            mod_script = "QIangIQsMMJMinigun/scripts/mods/QIangIQsMMJMinigun/QIangIQsMMJMinigun",
            mod_data = "QIangIQsMMJMinigun/scripts/mods/QIangIQsMMJMinigun/QIangIQsMMJMinigun_data",
            mod_localization = "QIangIQsMMJMinigun/scripts/mods/QIangIQsMMJMinigun/QIangIQsMMJMinigun_localization",
        })
    end,
    version = "0.1.0",
    author = "QIangIQ",
    packages = {},
}
