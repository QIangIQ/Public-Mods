-- QIangIQsChainaxe2h third person: the Mauler attacks on the third-person body (user rule 2026-10-27: borrowed animations
-- are retargeted in third person too). Datavault: Mods/QIangIQsChainaxe2h, technique-darktide-animation-decode.
--
-- How (QIangIQsEmotes custom-dance method, lesson-emotes-standard-body):
--   * Custom/ca_tp_driver is a skeleton-only unit on the player's third-person skeleton (167 nodes) whose simple animation is
--     the five Mauler clips one after the other (stubrifle_chainaxe tp_bake.py, bl_tp_driver.py; the
--     compiled clip was decoded back and matched the bake within 0.15 degrees, verify_tp.py).
--   * On an attack the driver is spawned, its unit root linked to the player's j_hips (the bake puts the driver's j_hips on
--     its root), and the body and gear units except the legs (slot_body_legs, slot_gear_lowerbody) are moved onto it by node
--     name, with the axe (its rig is linked by node name too, so it follows the driver's j_rightweaponattach, where the bake
--     puts the axe). The legs stay on the game's own body, so walking and the waist are unchanged; the Mauler's hip lunge is
--     not used.
--   * Timing: the same piecewise warp as first person (QIangIQsChainaxe2h_arms.lua warp), played as up to three segments of
--     the clip at their own speed (Unit.play_simple_animation(unit, from, to, loop, speed), QIangIQsEmotes 1.13).
--   * Other players: the anim event reaches clients as an index (AnimationSystem.rpc_player_anim_event). The index of each
--     event is learnt when this client's own chain axe plays it (PlayerUnitAnimationExtension.anim_event -> Unit.animation_event
--     returns it), so another player's chain axe attacks are shown once you have swung yours once.
--   * Ends when the attack's time is over or the weapon plays any other event of its template (block, push, special,
--     wield, hit stop), and snaps back to the Eviscerator animation (no blend).
local Tp = {}
local CFG

function Tp.setup(cfg)
    CFG = cfg
end

-- seconds of each Mauler clip in the driver's clip (tp_bake.py output)
local SPANS = {
    attack_01 = { start = 0, length = 4.5 },
    attack_02 = { start = 4.6, length = 4.1667 },
    attack_03 = { start = 8.8667, length = 3.3333 },
    attack_04 = { start = 12.3, length = 2.5833 },
    attack_reach_up = { start = 14.9667, length = 2.25 },
}
local KEEP_ON_BODY = { slot_body_legs = true, slot_gear_lowerbody = true }
local MAX_HOLD = 3.5

local active = {}      -- 3p unit -> state
local wielded = {}     -- 3p unit -> weapon template name
local event_names = {} -- state machine event index -> name (learnt from this client's own swings)
local stop_events = {} -- template name -> set of its other anim events

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function now()
    local time = Managers.time

    return time and time:has_timer("gameplay") and time:time("gameplay") or os.clock()
end

local function template_events(name)
    if stop_events[name] then
        return stop_events[name]
    end

    local set = {}
    local template = WeaponTemplates[name]

    local function scan(t, depth)
        if depth > 4 then
            return
        end

        for k, v in pairs(t) do
            if type(v) == "string" and type(k) == "string" and k:find("anim_event") then
                set[v] = true
            elseif type(v) == "table" then
                scan(v, depth + 1)
            end
        end
    end

    if template and template.actions then
        scan(template.actions, 0)
    end

    stop_events[name] = set

    return set
end

-- damage window and length of the action that plays this event (the template's own numbers; the local player's current
-- action, with its attack speed, when it matches)
local function timing(template_name, event, unit)
    local info = CFG.local_action and CFG.local_action(unit)

    if info and info.event == event and info.total then
        return info.total, info.dws, info.dwe
    end

    local template = WeaponTemplates[template_name]

    for _, action in pairs(template and template.actions or {}) do
        if action.anim_event == event and action.total_time and action.total_time < 10 then
            return action.total_time, action.damage_window_start, action.damage_window_end
        end
    end
end

-- body/gear units of a player unit with the node each is linked to (QIangIQsEmotes standard_body_units / attach_index)
local function attach_index(parent, item, breed_name)
    local node = item and ((item.breed_attach_node and breed_name and item.breed_attach_node[breed_name]) or item.attach_node)

    if node == nil or node == "" then
        return 1
    end

    if tonumber(node) ~= nil then
        return tonumber(node)
    end

    if Unit.has_node(parent, node) then
        return Unit.node(parent, node)
    end
end

local function movable_units(unit)
    local ext = ScriptUnit.has_extension(unit, "visual_loadout_system")
    local found = {}

    for name, slot in pairs(ext and ext._equipment or {}) do
        local item = slot.item
        local body = type(name) == "string" and (name:find("^slot_body_") or name:find("^slot_gear_")) and not KEEP_ON_BODY[name]
        local axe = item and item.name == CFG.item_name()

        if (body or axe) and unit_ok(slot.unit_3p) then
            local map_mode = item and item.link_map_mode and World[item.link_map_mode]

            if map_mode == nil or map_mode == World.LINK_MODE_NODE_NAME then
                found[#found + 1] = { unit = slot.unit_3p, item = item }
            end
        end
    end

    return found
end

local function relink(world, child, parent, node)
    World.unlink_unit(world, child)
    World.link_unit(world, child, 1, parent, node, World.LINK_MODE_NODE_NAME)
end

function Tp.stop(unit)
    local data = active[unit]

    if not data then
        return
    end

    active[unit] = nil

    if unit_ok(unit) then
        for _, moved in ipairs(data.moved) do
            if unit_ok(moved.unit) then
                relink(data.world, moved.unit, unit, moved.node)
            end
        end
    end

    if unit_ok(data.driver) then
        local unit_spawner = Managers.state and Managers.state.unit_spawner

        if unit_spawner then
            unit_spawner:mark_for_deletion(data.driver)
        end
    end
end

local function start(unit)
    local path = CFG.tp_driver_path()
    local unit_spawner = Managers.state and Managers.state.unit_spawner
    local world = unit_ok(unit) and Unit.world(unit)

    if not (path and unit_spawner and world and Unit.has_node(unit, "j_hips")) then
        return nil
    end

    local driver = unit_spawner:spawn_unit(path, Unit.world_pose(unit, 1))

    if not driver then
        return nil
    end

    World.link_unit(world, driver, 1, unit, Unit.node(unit, "j_hips"))

    local unit_data = ScriptUnit.has_extension(unit, "unit_data_system")
    local breed_name = unit_data and unit_data.breed_name and unit_data:breed_name()
    local data = { driver = driver, world = world, moved = {} }

    for _, entry in ipairs(movable_units(unit)) do
        local own = attach_index(unit, entry.item, breed_name)
        local on_driver = own and attach_index(driver, entry.item, breed_name)

        if own and on_driver then
            relink(world, entry.unit, driver, on_driver)
            data.moved[#data.moved + 1] = { unit = entry.unit, node = own }
        end
    end

    active[unit] = data

    return data
end

local function play(data, t)
    local piece = data.pieces[data.i]

    if not piece then
        return
    end

    Unit.play_simple_animation(data.driver, piece.from, piece.to, false, piece.speed)
    data.next_t = t + piece.dur
end

-- the warp of QIangIQsChainaxe2h_arms.lua as clip segments: wind-up up to the hit, the hit over the damage window, the
-- follow-through over the rest of the action
local function pieces_for(clip_name, start_t, total, dws, dwe)
    local span, baked = SPANS[clip_name], CFG.baked()[clip_name]
    local h0, h1 = baked and baked.hit0, baked and baked.hit1
    local L = span.length
    local o = span.start
    local list = {}

    local function add(a, b, dur)
        if b > a and dur > 0.001 then
            list[#list + 1] = { from = o + a, to = o + b, dur = dur, speed = (b - a) / dur }
        end
    end

    start_t = math.min(start_t or 0, h0 or 0)

    if dws and dwe and h0 and h1 and dwe > dws and dwe < total and dws > 0 and h1 < L then
        add(start_t, h0, dws)
        add(h0, h1, dwe - dws)
        add(h1, L, total - dwe)
    else
        add(start_t, L, total)
    end

    return list
end

function Tp.on_event(unit, event)
    local template_name = wielded[unit]

    if not (template_name and template_name == CFG.template_name() and CFG.enabled()) then
        return
    end

    local clip_name, mode = CFG.pick(event)
    local data = active[unit]

    if not clip_name or not SPANS[clip_name] then
        if data and template_events(template_name)[event] then
            Tp.stop(unit)
        end

        return
    end

    local t = now()
    local charged = data and data.charged

    data = data or start(unit)

    if not data then
        return
    end

    data.i = 1
    data.charged = nil

    if mode == "charge" then
        local baked = CFG.baked()[clip_name]
        local hold = ((baked and baked.hit0) or SPANS[clip_name].length * 0.4) * CFG.hold_share
        local dur = math.max(CFG.opt("charge_time", 0.5), 0.05)

        data.pieces = { { from = SPANS[clip_name].start, to = SPANS[clip_name].start + hold, dur = dur, speed = hold / dur } }
        data.charged = { clip = clip_name, t = hold }
        data.end_t = t + MAX_HOLD
    else
        local total, dws, dwe = timing(template_name, event, unit)

        total = total or SPANS[clip_name].length

        local from = charged and charged.clip == clip_name and charged.t or 0

        data.pieces = pieces_for(clip_name, from, total, dws, dwe)
        data.end_t = t + total
    end

    data.clip = clip_name
    play(data, t)
end

function Tp.update()
    if next(active) == nil then
        return
    end

    local t = now()

    for unit, data in pairs(active) do
        if not unit_ok(unit) or not unit_ok(data.driver) or wielded[unit] ~= CFG.template_name() or t >= data.end_t then
            Tp.stop(unit)
        elseif data.next_t and t >= data.next_t and data.pieces[data.i + 1] then
            data.i = data.i + 1
            play(data, t)
        end
    end
end

function Tp.wielded(unit, template_name)
    wielded[unit] = template_name

    if active[unit] and template_name ~= CFG.template_name() then
        Tp.stop(unit)
    end
end

-- learning the state machine index of an event from this client's own swing
function Tp.learn(func, unit, event_name, ...)
    if wielded[unit] ~= CFG.template_name() or not CFG.pick(event_name) and not template_events(wielded[unit])[event_name] then
        return func(...)
    end

    local original = Unit.animation_event

    Unit.animation_event = function(u, name, ...)
        local index = original(u, name, ...)

        if u == unit and name == event_name and index then
            event_names[index] = name
        end

        return index
    end

    local ok, a, b = pcall(func, ...)

    Unit.animation_event = original

    if not ok then
        error(a, 0)
    end

    return a, b
end

function Tp.on_husk_event(unit, event_index)
    local name = event_names[event_index]

    if name then
        Tp.on_event(unit, name)
    end
end

function Tp.forget(unit)
    Tp.stop(unit)
    wielded[unit] = nil
end

function Tp.stop_all()
    for unit in pairs(active) do
        Tp.stop(unit)
    end
end

function Tp.debug()
    local n, learnt = 0, 0

    for _ in pairs(active) do
        n = n + 1
    end

    for _ in pairs(event_names) do
        learnt = learnt + 1
    end

    return string.format("third person: %d attacking, %d events learnt for other players, driver %s", n, learnt,
        tostring(CFG.tp_driver_path()))
end

return Tp
