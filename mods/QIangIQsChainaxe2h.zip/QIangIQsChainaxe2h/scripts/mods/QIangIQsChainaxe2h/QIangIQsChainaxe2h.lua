-- QIangIQ's 2H Chain Axe 0.3.1: the unreleased two-handed chain axe (chainaxe_2h_p1_m1) as a weapon, swung with the
-- enemy Mauler's attacks.
--
-- What is datamined (A:\Dowloads\Darktide_NonMod\unreleased_sweep_oct25 index.tsv, build 139617; node names by id32
-- match, work folder export_probe.txt / maul_probe.py):
--   * content/weapons/player/melee/2h_chain_axe/wpn_2h_chain_axe_base: unnamed root (4a7aef5f), p_zoom, p_rotation,
--     j_trail_01-04 (z 0.57). Its strings are "item" and content/items/weapons/player/melee/chainaxe_2h_p1_m1, so that is
--     the item / template name.
--   * attachments shaft_01 / shaft_ml01 (ap_shaft_01 and ap_grip_01 at 0, ap_blade_01 at z 0.6044), grip_01 / grip_ml01
--     (the handle sleeve over the shaft, z -0.116 to 0.549; renders/chainaxe_withgrip_*.png), blade_01 / blade_ml01
--     (skinned, own chain state machine with forward / backward clips and set_speed script wiring; fx_weapon_special,
--     fx_sweep, fx_sawing, fx_engine, fx_block, ap_trinket_hook), trail_01 (j_trail, fx_sweep).
--   * HUD icon content/ui/materials/icons/weapons/hud/chainaxe_2h_p1_m1.
--   * NOT in the files: weapon template, master item, animations of its own.
--
-- How it is built (user 2026-10-30: "do not do crusher, use mauler atks"):
--   * Template chainaxe_2h_p1_m1 = clone of the Eviscerator chainsword_2h_p1_m1 or _m2 (setting): the released two-handed
--     chain weapon, so damage, block, chain special, chain speed and both state machines are a released chain weapon's.
--   * First person: the Mauler's (renegade_executor) attack clips from the game files, retargeted to the first-person arms
--     and baked to Lua (QIangIQsChainaxe2h_mauler.lua), played over the Eviscerator's animation by a two-bone IK on a driver
--     unit that ships in this mod (Custom/ca_fp_driver; QIangIQsChainaxe2h_arms.lua, the QIangIQsPowerAxe arms method).
--     Light attacks -> the Mauler's quick chops and upward swing, heavies -> its two cleaves; equip, idle, block, push and
--     special stay the Eviscerator's. Preview: /mnt/project-files/renders/stubrifle_chainaxe/chainaxe2h_preview_v1.mp4.
--   * Third person (0.3.0): the same Mauler clips retargeted onto the player 3p skeleton and compiled into a driver unit
--     (Custom/ca_tp_driver); the upper body and the axe follow it during attacks, the legs stay the game's
--     (QIangIQsChainaxe2h_tp.lua). Other players' chain axe attacks are shown once this client has swung its own.
--   * fx sources point at the chain blade's own nodes: _block fx_block, _sweep fx_sweep, _special_active
--     fx_weapon_special, _wielded_idling fx_engine; any other source the donor has goes to fx_sweep.
--   * Item = clone of the donor master item (grip -> body -> chain / emblems / trinket hook, trail) with base_unit = the axe
--     base. Tree: grip slot = shaft (rig root, attach_node 1: the root has no known name; visual_loadout_customization.lua
--     271-275 takes a number as the node index) -> body = blade (ap_blade_01), handle = grip sleeve (ap_grip_01); trail =
--     the axe's own trail_01 at the root. Chain, emblems and trinkets go (the blade carries its own chain).
--   * Standalone: needs no other mod. The first-person Mauler arms need the Custom Assets framework (infrastructure, like
--     QIangIQsPowerAxe); without it the axe uses the Eviscerator's arms.
-- Author: QIangIQ
local mod = get_mod("QIangIQsChainaxe2h")

local WeaponTemplates = require("scripts/settings/equipment/weapon_templates/weapon_templates")
local MasterItems = require("scripts/backend/master_items")
local NetworkLookup = require("scripts/network_lookup/network_lookup")

local AXE = "content/weapons/player/melee/2h_chain_axe/"
local RIG = AXE .. "wpn_2h_chain_axe_base"
local ROOT_NODE = 1
local ITEM_ROOT = "content/items/weapons/player/melee/"
local PART_ROOT = ITEM_ROOT .. "qiangiq_chainaxe2h/"
local HUD_ICON = "content/ui/materials/icons/weapons/hud/chainaxe_2h_p1_m1"
local TRAIL = AXE .. "attachments/trail_01/trail_01"
local DONORS = { m1 = "chainsword_2h_p1_m1", m2 = "chainsword_2h_p1_m2" }
local ARCHETYPES = { "zealot", "veteran", "psyker", "adamant" }
local FX_NODES = { _block = "fx_block", _sweep = "fx_sweep", _special_active = "fx_weapon_special", _wielded_idling = "fx_engine" }

local MARK = {
    template = "chainaxe_2h_p1_m1",
    item = ITEM_ROOT .. "chainaxe_2h_p1_m1",
    display = "loc_qiangiq_chainaxe_2h_p1_m1",
}

local function donor_name()
    return DONORS[mod:get("moveset")] or DONORS.m1
end

local function part_set()
    return mod:get("part_set") == "ml01" and "ml01" or "01"
end

local function part_unit(kind, set)
    return string.format("%sattachments/%s_%s/%s_%s", AXE, kind, set, kind, set)
end

local function parts()
    local set = part_set()

    return {
        shaft = { unit = part_unit("shaft", set), node = ROOT_NODE },
        blade = { unit = part_unit("blade", set), node = "ap_blade_01" },
        grip = { unit = part_unit("grip", set), node = "ap_grip_01" },
        trail = { unit = TRAIL, node = ROOT_NODE },
    }
end

mod:add_global_localize_strings({
    loc_qiangiq_chainaxe2h_family = { en = "2H Chain Axe (datamined)" },
    loc_qiangiq_chainaxe_2h_p1_m1 = { en = "2H Chain Axe (datamined)" },
    loc_qiangiq_chainaxe2h_desc = {
        en = "The unreleased two-handed chain axe found in the game files, swung with the Mauler's attacks on the Eviscerator's moveset.",
    },
})
local function say(fmt, ...)
    local text = string.format(fmt, ...)

    mod:echo(text)
    mod:info(text)
end

local function debug(fmt, ...)
    if mod:get("debug") then
        mod:info(fmt, ...)
    end
end

-- Network lookups (QIangIQsShardStaff append_lookup): new names go at the end so no existing id moves -------------
local function append_lookup(lookup_name, key)
    local lookup = NetworkLookup[lookup_name]

    if not lookup then
        return false, "no lookup"
    end

    local existing = rawget(lookup, key)

    if existing then
        return true, existing
    end

    local index = #lookup + 1

    rawset(lookup, index, key)
    rawset(lookup, key, index)

    return true, index
end

-- Particle / sound aliases keyed by wielded_weapon_template (QIangIQsShardStaff alias_template_keys). Keys the game
-- already has for chainaxe_2h_p1_m1 are kept.
local ALIAS_MODULES = {
    "scripts/settings/particles/player_character_particle_aliases",
    "scripts/settings/sound/player_character_sound_event_aliases",
}

local function alias_keys(root, source, target, seen, counter)
    if type(root) ~= "table" or seen[root] then
        return
    end

    seen[root] = true

    local value = rawget(root, source)

    if value ~= nil and rawget(root, target) == nil then
        root[target] = value
        counter.n = counter.n + 1
    end

    for _, child in pairs(root) do
        if type(child) == "table" then
            alias_keys(child, source, target, seen, counter)
        end
    end
end

local function copy_aliases(source, target)
    local counter = { n = 0 }

    for _, path in ipairs(ALIAS_MODULES) do
        local ok, module = pcall(require, path)

        if ok then
            alias_keys(module, source, target, {}, counter)
        else
            mod:error("alias module %s: %s", path, tostring(module))
        end
    end

    return counter.n
end

local function package_found(path)
    local ok, exists = pcall(Application.can_get_resource, "package", path)

    return ok and exists and true or false
end

-- Template ------------------------------------------------------------------------------------------------------------
local function ensure_template()
    if rawget(WeaponTemplates, MARK.template) then
        MARK.template_ok = true
        MARK.official_template = not MARK.template_ours

        return true
    end

    local donor_template = donor_name()
    local donor = WeaponTemplates[donor_template]

    if not donor then
        return false
    end

    local clone = table.clone(donor)

    clone.name = MARK.template

    for action_name, action_settings in pairs(clone.actions) do
        action_settings.name = action_name
    end

    local fx_sources = {}

    for source in pairs(clone.fx_sources or {}) do
        fx_sources[source] = FX_NODES[source] or "fx_sweep"
    end

    clone.fx_sources = fx_sources

    WeaponTemplates[MARK.template] = clone
    MARK.template_ours = true
    MARK.donor = donor_template

    local ok, index = append_lookup("weapon_templates", MARK.template)

    MARK.template_id = ok and index or nil
    MARK.aliases = copy_aliases(donor_template, MARK.template)
    MARK.template_ok = ok

    return ok
end

-- Items ---------------------------------------------------------------------------------------------------------------
local function find_item(cache, preferred, template)
    local direct = rawget(cache, preferred)

    if direct and direct.weapon_template == template then
        return preferred, direct
    end

    for name, item in pairs(cache) do
        if type(item) == "table" and item.weapon_template == template then
            return name, item
        end
    end
end

-- Only base_unit is kept: Items.base_unit can also read per-breed / first-person variants of the source part
local function only_base_unit(item, unit)
    for key in pairs(item) do
        if type(key) == "string" and key ~= "base_unit" and key:find("^base_unit") then
            item[key] = nil
        end
    end

    item.base_unit = unit
end

local function make_part(cache, name, template_item, unit, attach_node)
    local item = table.clone(template_item)

    only_base_unit(item, unit)
    item.name = name
    item.resource_dependencies = { [unit] = true }
    item.attachments = nil
    item.material_overrides = nil
    item.material_override_items = nil
    item.attach_node = attach_node
    cache[name] = item

    return name
end

-- a tree node with the donor node's flags (leaf_attach_node_override, link_map_mode_override, material fields)
local function fresh_node(node, item_name)
    local out = {}

    for key, value in pairs(node) do
        if key ~= "children" and key ~= "item" then
            out[key] = type(value) == "table" and table.clone(value) or value
        end
    end

    out.item = item_name
    out.children = {}

    return out
end

local function dump_tree(tree, prefix, out)
    for slot_name, node in pairs(tree) do
        if type(node) == "table" then
            local path = prefix .. slot_name

            out[#out + 1] = string.format("%s=%s", path, tostring(node.item))

            if type(node.children) == "table" then
                dump_tree(node.children, path .. "/", out)
            end
        end
    end

    return out
end

local function archetypes_of(source_item)
    local archetypes, seen = {}, {}

    for _, archetype in ipairs(source_item.archetypes or {}) do
        archetypes[#archetypes + 1] = archetype
        seen[archetype] = true
    end

    for _, archetype in ipairs(ARCHETYPES) do
        if mod:get("unlock_" .. archetype) and not seen[archetype] then
            archetypes[#archetypes + 1] = archetype
            seen[archetype] = true
        end
    end

    return archetypes
end

local function build_item(cache)
    local donor_template = MARK.donor or donor_name()
    local source_name, source_item = find_item(cache, ITEM_ROOT .. donor_template, donor_template)

    if not source_item then
        return false
    end

    if type(source_item.attachments) ~= "table" then
        return false, "source item has no attachments"
    end

    local PARTS = parts()

    for _, part in pairs(PARTS) do
        if not package_found(part.unit) then
            return false, part.unit .. " package not found"
        end
    end

    local item = table.clone(source_item)

    item.name = MARK.item
    item.weapon_template = MARK.template
    item.display_name = MARK.display
    item.description = "loc_qiangiq_chainaxe2h_desc"
    item.dev_description = nil
    item.archetypes = archetypes_of(source_item)

    for _, field in ipairs({ "weapon_family_display_name", "weapon_pattern_display_name", "weapon_mark_display_name" }) do
        if type(item[field]) == "table" then
            item[field].loc_id = field == "weapon_family_display_name" and "loc_qiangiq_chainaxe2h_family" or MARK.display
        end
    end

    if not MARK.tree_logged then
        MARK.tree_logged = true
        mod:info("source tree of %s: %s", tostring(source_name), table.concat(dump_tree(item.attachments, "", {}), "; "))
    end

    -- master item data of chainsword_2h_p1_m1 (http_cache.db, build 139617; QIangIQsChainsword2h): grip, grip/body with
    -- chain, emblem_left/right, slot_trinket_1 and trinket_hook under it; trail
    local grip = item.attachments.grip
    local body = grip and type(grip.children) == "table" and grip.children.body
    local trail = item.attachments.trail

    local function source_of(node)
        return node and type(node.item) == "string" and rawget(cache, node.item)
    end

    local sources = {
        shaft = source_of(grip),
        blade = source_of(body),
        grip = source_of(grip),
        trail = source_of(trail),
    }

    for key, source in pairs(sources) do
        if not source then
            return false, "no " .. key .. " slot in " .. tostring(source_name)
        end
    end

    local set = part_set()
    local names = {}

    for key, part in pairs(PARTS) do
        names[key] = PART_ROOT .. key .. "_" .. (key == "trail" and "01" or set)

        if not rawget(cache, names[key]) then
            make_part(cache, names[key], sources[key], part.unit, part.node)
        end
    end

    grip.item = names.shaft
    grip.children = {
        body = fresh_node(body, names.blade),
        handle = fresh_node(body, names.grip),
    }
    trail.item = names.trail
    trail.children = {}

    only_base_unit(item, RIG)

    local deps = item.resource_dependencies or {}

    if source_item.base_unit then
        deps[source_item.base_unit] = nil
    end

    deps[RIG] = true

    for _, part in pairs(PARTS) do
        deps[part.unit] = true
    end

    -- bottom-right weapon HUD: item.hud_icon (hud_element_player_weapon.lua:77, QIangIQsMeltagun), the game's own icon
    if package_found(HUD_ICON) then
        if type(item.hud_icon) == "string" then
            deps[item.hud_icon] = nil
        end

        item.hud_icon = HUD_ICON
        deps[HUD_ICON] = true
    end

    -- what the offline item compile adds for the weapon template (item_package.lua:239-249): state machines, sounds, effects
    local WeaponTemplateResourceDependencies = require("scripts/utilities/weapon_template_resource_dependencies")

    for _, resource in ipairs(WeaponTemplateResourceDependencies.generate(MARK.template)) do
        deps[resource] = true
    end

    item.resource_dependencies = deps

    local ok, index = append_lookup("player_item_names", MARK.item)

    if not ok then
        return false
    end

    cache[MARK.item] = item
    MARK.item_id = index
    MARK.source_item_name = source_name
    MARK.slot = item.slots and item.slots[1]
    MARK.parts = names

    return true
end

local function ensure_item()
    local ok, has_data = pcall(MasterItems.has_data)

    if not ok or not has_data then
        return false
    end

    local cache = MasterItems.get_cached()

    if rawget(cache, MARK.item) and not MARK.dirty then
        MARK.item_ok = true

        return true
    end

    local built, err = build_item(cache)

    if err and err ~= MARK.last_error then
        MARK.last_error = err
        mod:error("%s: %s", MARK.template, err)
    end

    MARK.item_ok = built and rawget(cache, MARK.item) ~= nil

    if MARK.item_ok then
        MARK.dirty = false
    end

    return MARK.item_ok
end

-- Unlock lists (weapon_unlock_settings.lua WeaponUnlockSettings[archetype][level] = { item names }); realms_loadout
-- builds its human weapon list from it
local function add_to_unlock_lists()
    if not mod:get("add_to_unlock_list") then
        return
    end

    local ok, unlocks = pcall(require, "scripts/settings/weapon_unlock/weapon_unlock_settings")

    if not ok or not unlocks then
        mod:error("WeaponUnlockSettings not found")

        return
    end

    local level = math.floor(mod:get("unlock_level") or 1)

    for _, archetype in ipairs(ARCHETYPES) do
        local list = unlocks[archetype]

        if mod:get("unlock_" .. archetype) and list then
            list[level] = list[level] or {}

            if not table.find(list[level], MARK.item) then
                table.insert(list[level], MARK.item)
            end
        end
    end
end

local next_poll = 0

local function poll()
    if next_poll > os.clock() then
        return
    end

    next_poll = os.clock() + 1

    local before_t, before_i = MARK.template_ok, MARK.item_ok
    local ok_t, err_t = pcall(ensure_template)
    local ok_i, err_i = true, nil

    if MARK.template_ok then
        ok_i, err_i = pcall(ensure_item)
    end

    if not ok_t then
        mod:error("template: %s", tostring(err_t))
    end

    if not ok_i then
        mod:error("item: %s", tostring(err_i))
    end

    if MARK.template_ok and not before_t then
        if MARK.official_template then
            mod:info("the game now has its own %s template; using it", MARK.template)
        else
            mod:info("template %s registered (clone of %s), %s alias entries", MARK.template, tostring(MARK.donor), tostring(MARK.aliases))
        end
    end

    if MARK.item_ok and not before_i then
        mod:info("item %s injected (clone of %s, slot %s)", MARK.item, tostring(MARK.source_item_name), tostring(MARK.slot))
    end
end

local ITEM_SETTINGS = {
    part_set = true, unlock_zealot = true, unlock_veteran = true, unlock_psyker = true, unlock_adamant = true,
}

mod.on_setting_changed = function(setting_id)
    if ITEM_SETTINGS[setting_id] then
        MARK.dirty = true
    end
end

-- Mauler arms (first person): QIangIQsChainaxe2h_arms.lua plays QIangIQsChainaxe2h_mauler.lua on the driver unit that
-- ships in this mod (Custom/ca_fp_driver, a rename of QIangIQsPowerAxe's pa_fp_driver; needs the Custom Assets framework)
local DRIVERS = {
    { id = "QIangIQsChainaxe2h:ca_fp_driver", unit = "content/mods/qiangiq_chainaxe2h/ca_fp_driver" },
}
local driver_loaded = {}
local baked_clips = nil
-- Mauler attacks in third person: Custom/ca_tp_driver, the clips baked on the player 3p skeleton (QIangIQsChainaxe2h_tp.lua)
local TP_DRIVER = { id = "QIangIQsChainaxe2h:ca_tp_driver", unit = "content/mods/qiangiq_chainaxe2h/ca_tp_driver" }
local tp_driver_loaded = false

local Arms = mod:io_dofile("QIangIQsChainaxe2h/scripts/mods/QIangIQsChainaxe2h/QIangIQsChainaxe2h_arms")

Arms.setup({
    fp_nodes = mod:io_dofile("QIangIQsChainaxe2h/scripts/mods/QIangIQsChainaxe2h/QIangIQsChainaxe2h_fp_nodes"),
    opt = function(key, default)
        local v = mod:get(key)

        if v == nil then
            return default
        end

        return tonumber(v) or v
    end,
    baked = function()
        baked_clips = baked_clips or mod:io_dofile("QIangIQsChainaxe2h/scripts/mods/QIangIQsChainaxe2h/QIangIQsChainaxe2h_mauler")

        return baked_clips
    end,
    driver_path = function()
        for i, d in ipairs(DRIVERS) do
            if driver_loaded[i] then
                return d.unit
            end
        end
    end,
    error = function(text)
        mod:error("%s", text)
    end,
    info = function(text)
        mod:info("%s", text)
    end,
})

local Tp = mod:io_dofile("QIangIQsChainaxe2h/scripts/mods/QIangIQsChainaxe2h/QIangIQsChainaxe2h_tp")
-- 0.3.1: ability equip guard against the 2026-10-31 "Unit not found" grenade crash (Lessons/lesson-ability-unit-not-loaded)
local Guard = mod:io_dofile("QIangIQsChainaxe2h/scripts/mods/QIangIQsChainaxe2h/QIangIQsChainaxe2h_guard")

Guard.setup(mod)
local local_action_of = nil -- set below (action_info of the local player's unit)

Tp.setup({
    opt = function(key, default)
        local v = mod:get(key)

        if v == nil then
            return default
        end

        return tonumber(v) or v
    end,
    baked = function()
        baked_clips = baked_clips or mod:io_dofile("QIangIQsChainaxe2h/scripts/mods/QIangIQsChainaxe2h/QIangIQsChainaxe2h_mauler")

        return baked_clips
    end,
    tp_driver_path = function()
        return tp_driver_loaded and TP_DRIVER.unit or nil
    end,
    enabled = function()
        return mod:get("mauler_3p") ~= false
    end,
    template_name = function()
        return MARK.template
    end,
    item_name = function()
        return MARK.item
    end,
    pick = Arms.pick_event,
    hold_share = Arms.HOLD_SHARE,
    local_action = function(unit)
        return local_action_of and local_action_of(unit)
    end,
})

-- Shaft position (QIangIQsPowerAxe place_shaft): the setting slides the shaft (and the blade and handle on it) along the rig
local tracked = {}

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function shaft_unit(names)
    if names then
        for unit, item_name in pairs(names) do
            if type(item_name) == "string" and item_name:find(PART_ROOT .. "shaft_", 1, true) == 1 and unit_ok(unit) then
                return unit
            end
        end
    end
end

local function place_shaft(ext, names)
    local unit = shaft_unit(names)

    if not unit then
        return
    end

    local offset = (mod:get("shaft_offset") or 0) / 100
    local placed = ext.__qiangiq_chainaxe2h_offset

    if not placed then
        placed = {}
        ext.__qiangiq_chainaxe2h_offset = placed
    end

    if placed[unit] == nil and offset == 0 then
        return
    end

    if placed[unit] ~= offset then
        placed[unit] = offset
        Unit.set_local_position(unit, 1, Vector3(0, 0, offset))
    end
end

-- current action of the local player: name, anim event, seconds into it, its length (scaled), damage window, the clock
local function action_info(ext)
    local ok, info = pcall(function()
        local ude = ScriptUnit.has_extension(ext._unit, "unit_data_system")
        local wa = ude and ude:read_component("weapon_action")

        if not wa then
            return nil
        end

        local t = Managers.time:time("gameplay")
        local template = WeaponTemplates[wa.template_name]
        local settings = template and template.actions and template.actions[wa.current_action_name]
        local total = settings and settings.total_time
        local scale = math.max(wa.time_scale or 1, 0.1)

        if total and total < 10 then
            total = total / scale
        else
            total = nil
        end

        local dws = settings and settings.damage_window_start
        local dwe = settings and settings.damage_window_end

        return {
            event = settings and settings.anim_event, name = wa.current_action_name, elapsed = t - (wa.start_t or t), total = total, clock = t,
            dws = dws and dws / scale or nil, dwe = dwe and dwe / scale or nil,
        }
    end)

    return ok and info or nil
end

local_action_of = function(unit)
    local ext = unit and ScriptUnit.has_extension(unit, "visual_loadout_system")

    return ext and ext._is_local_unit and action_info(ext) or nil
end

local function apply_visuals(ext, dt)
    if not ext._is_local_unit or not ext._equipment then
        return
    end

    local ours

    for _, slot in pairs(ext._equipment) do
        local item = slot.item

        if item and item.name == MARK.item then
            place_shaft(ext, slot.item_name_by_unit_3p)
            place_shaft(ext, slot.item_name_by_unit_1p)
            ours = slot
        end
    end

    if ours and mod:get("mauler_arms") ~= false then
        local ok, err = pcall(function()
            local info = action_info(ext)

            if info then
                Arms.update(ext, ours, info, dt)
            end
        end)

        if not ok then
            mod:error("arms update: %s", tostring(err))
            pcall(Arms.stop, ext)
        end
    else
        pcall(Arms.stop, ext)
    end
end

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "_update_item_visibility", function(self)
    if self._is_local_unit then
        tracked[self] = true
        apply_visuals(self)
    end
end)

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "init", function(self, extension_init_context)
    self.__qiangiq_chainaxe2h_world = extension_init_context and extension_init_context.world
end)

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "update", function(self, unit, dt)
    if tracked[self] then
        apply_visuals(self, dt)
    end
end)

mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, "destroy", function(func, self, ...)
    pcall(Arms.stop, self)
    pcall(Tp.forget, self._unit)
    tracked[self] = nil

    return func(self, ...)
end)

if CLASS.PlayerHuskVisualLoadoutExtension then
    mod:hook(CLASS.PlayerHuskVisualLoadoutExtension, "destroy", function(func, self, ...)
        pcall(Tp.forget, self._unit)

        return func(self, ...)
    end)
end

-- Third person: anim events of the weapon on the local unit (client prediction or a local server) and on other players
-- (rpc_player_anim_event*, an event index; QIangIQsChainaxe2h_tp.lua Tp.learn)
for _, class_name in ipairs({ "PlayerUnitAnimationExtension", "AuthoritativePlayerUnitAnimationExtension", "PlayerHuskAnimationExtension" }) do
    local class = CLASS[class_name]

    if class then
        mod:hook_safe(class, "inventory_slot_wielded", function(self, weapon_template)
            pcall(Tp.wielded, self._unit, weapon_template and weapon_template.name or nil)
        end)

        if class_name ~= "PlayerHuskAnimationExtension" then
            for _, method in ipairs({ "anim_event", "anim_event_with_variable_float", "anim_event_with_variable_floats",
                "anim_event_with_variable_int" }) do
                if class[method] then
                    mod:hook(class, method, function(func, self, event_name, ...)
                        local a, b = Tp.learn(func, self._unit, event_name, self, event_name, ...)
                        local ok, err = pcall(Tp.on_event, self._unit, event_name)

                        if not ok then
                            mod:error("third person: %s", tostring(err))
                        end

                        return a, b
                    end)
                end
            end
        end
    end
end

if CLASS.AnimationSystem then
    for _, rpc in ipairs({ "rpc_player_anim_event", "rpc_player_anim_event_variable_float", "rpc_player_anim_event_variable_floats",
        "rpc_player_anim_event_variable_int" }) do
        if CLASS.AnimationSystem[rpc] then
            mod:hook_safe(CLASS.AnimationSystem, rpc, function(self, channel_id, unit_id, event_index, ...)
                local is_first_person = select(select("#", ...), ...)

                if is_first_person then
                    return
                end

                local ok, err = pcall(function()
                    local unit = Managers.state.unit_spawner:unit(unit_id)

                    if unit then
                        Tp.on_husk_event(unit, event_index)
                    end
                end)

                if not ok then
                    mod:error("third person (other player): %s", tostring(err))
                end
            end)
        end
    end
end

mod.update = function()
    poll()

    local ok, err = pcall(Tp.update)

    if not ok then
        mod:error("third person update: %s", tostring(err))
        pcall(Tp.stop_all)
    end

    Guard.tick()
end

local function acquire_driver()
    local custom_assets = get_mod("CustomAssets")

    if not custom_assets or not custom_assets.is_api_compatible or not custom_assets.is_api_compatible(1) then
        mod:info("Custom Assets (API 1) not installed: no Mauler arms, the Eviscerator's arms are used")

        return
    end

    for i, d in ipairs(DRIVERS) do
        local ticket = custom_assets.acquire(mod, d.id, function(_, _, load_error)
            if load_error then
                mod:info("arm driver %s not loaded: %s", d.id, tostring(load_error))

                return
            end

            driver_loaded[i] = true
            mod:info("arm driver %s loaded", d.id)
        end, { resident = true, reference_name = d.id })

        if not ticket then
            mod:info("arm driver %s could not be requested (Custom folder not patched?)", d.id)
        end
    end

    local ticket = custom_assets.acquire(mod, TP_DRIVER.id, function(_, _, load_error)
        if load_error then
            mod:info("third-person driver %s not loaded: %s", TP_DRIVER.id, tostring(load_error))

            return
        end

        tp_driver_loaded = true
        mod:info("third-person driver %s loaded", TP_DRIVER.id)
    end, { resident = true, reference_name = TP_DRIVER.id })

    if not ticket then
        mod:info("third-person driver %s could not be requested (Custom folder not patched?)", TP_DRIVER.id)
    end
end

mod.on_all_mods_loaded = function()
    add_to_unlock_lists()
    acquire_driver()
end

mod.on_unload = function()
    Guard.unload()

    for ext in pairs(tracked) do
        pcall(Arms.stop, ext)
    end

    pcall(Tp.stop_all)

    local ok, cache = pcall(MasterItems.get_cached)

    if ok and cache then
        cache[MARK.item] = nil

        for _, name in pairs(MARK.parts or {}) do
            cache[name] = nil
        end
    end

    if MARK.template_ours then
        WeaponTemplates[MARK.template] = nil
    end
end

-- Equip without the backend (QIangIQsShardStaff override): only where this client hosts ----------------------------
local function local_player()
    local players = Managers.player

    return players and players:local_player_safe(1)
end

local function equipped_item_name(player, slot)
    local unit = player and player.player_unit

    if not unit or not Unit.alive(unit) then
        return nil
    end

    local extension = ScriptUnit.has_extension(unit, "visual_loadout_system")
    local item = extension and extension:item_from_slot(slot)

    return item and item.name
end

local previous = {}

local function override(slot, item_name)
    local player = local_player()
    local sync = Managers.profile_synchronization
    local host = sync and sync:synchronizer_host()

    if not player then
        say("no local player")

        return false
    end

    if not host then
        say("not the host here. Use the Psykhanium, a SoloPlay game or a game you host")

        return false
    end

    host:override_slot(player:peer_id(), player:local_player_id(), slot, item_name)
    say("override_slot(%s, %s) sent", slot, tostring(item_name))

    return true
end

local function status()
    say("%s: template %s (id %s, clone of %s), item %s (id %s, slot %s, part set %s)", MARK.template, tostring(MARK.template_ok),
        tostring(MARK.template_id), tostring(MARK.donor), tostring(MARK.item_ok), tostring(MARK.item_id), tostring(MARK.slot), part_set())

    local player = local_player()
    local ext = player and player.player_unit and ScriptUnit.has_extension(player.player_unit, "visual_loadout_system")

    say("  Mauler arms: %s (driver loaded: %s)", ext and Arms.debug(ext) or "no local unit", tostring(driver_loaded[1] == true))
    say("  Mauler %s", Tp.debug())
    say("  axe rig package found: %s, HUD icon found: %s", tostring(package_found(RIG)), tostring(package_found(HUD_ICON)))
end

mod:command("chainaxe2h", mod:localize("command_chainaxe2h"), function(action)
    action = action or "status"

    if action == "status" then
        status()
    elseif action == "equip" then
        if not (MARK.template_ok and MARK.item_ok and MARK.slot) then
            say("%s not ready yet (template %s, item %s)", MARK.template, tostring(MARK.template_ok), tostring(MARK.item_ok))

            return
        end

        local player = local_player()

        previous[MARK.slot] = previous[MARK.slot] or (player and equipped_item_name(player, MARK.slot))
        override(MARK.slot, MARK.item)
    elseif action == "restore" then
        local any = false

        for slot, item_name in pairs(previous) do
            if item_name and override(slot, item_name) then
                previous[slot] = nil
                any = true
            end
        end

        if not any then
            say("nothing to restore (equip first)")
        end
    else
        say("usage: /chainaxe2h [status|equip|restore]")
    end
end)
