-- First-person arm playback of the Mauler's attacks for the 2H chain axe (QIangIQsChainaxe2h 0.2.0).
--
-- Vendored from QIangIQsPowerAxe_arms.lua (QIangIQsChainLaspistol_brace.lua driver method): a skeleton-only "driver" unit with
-- the first-person bone names (Custom/ca_fp_driver, a rename of pa_fp_driver) is linked to the first-person unit; every frame
-- it copies the animated first-person pose (the Eviscerator's), the arm mesh units are re-linked to it with
-- LINK_MODE_NODE_NAME, and during attacks Lua overrides bones: both arms are solved with a two-bone IK towards hand targets and
-- the hands get their rotation from the hand's finger bones (forward = hand -> j_*handmiddle1, up = j_*handpinky1 ->
-- j_*handindex1). The targets come from QIangIQsChainaxe2h_mauler.lua: the Mauler's (renegade_executor) attack clips from
-- the game files, retargeted to the first-person arms and baked in the camera / axe frame
-- (caxe_preview_prep.py + caxe_bake.py). The axe rig is placed on the baked axe frame.
-- Outside attacks the weight goes to 0 and the arms and axe follow the Eviscerator's own first-person animation.
-- Darktide arm lengths only decide how far each hand can reach. The weapon rig is moved to the baked attach frame.
local Arms = {}
local CFG = nil

function Arms.setup(cfg)
    CFG = cfg
end

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function parent_chain(unit, node)
    local list, current, guard = {}, node, 0

    while current and guard < 64 do
        list[#list + 1] = current

        if current == 1 then
            break
        end

        current = Unit.scene_graph_parent(unit, current)
        guard = guard + 1
    end

    return list
end

local function root_relative(unit, node)
    if node == nil or node == 1 then
        return Quaternion.identity(), Vector3(0, 0, 0)
    end

    local chain = parent_chain(unit, node)
    local rotation, position = Quaternion.identity(), Vector3(0, 0, 0)
    local first = chain[#chain] == 1 and #chain - 1 or #chain

    for i = first, 1, -1 do
        position = position + Quaternion.rotate(rotation, Unit.local_position(unit, chain[i]))
        rotation = Quaternion.multiply(rotation, Unit.local_rotation(unit, chain[i]))
    end

    return rotation, position
end

local REQUIRED = {
    "j_leftarm", "j_leftforearm", "j_lefthand", "j_lefthandmiddle1", "j_lefthandindex1", "j_lefthandpinky1",
    "j_rightarm", "j_rightforearm", "j_righthand", "j_righthandmiddle1", "j_righthandindex1", "j_righthandpinky1",
    "j_rightweaponattach", "ap_camera_node",
}

local function make_fpd(driver, fp_unit)
    local fpd = { driver = driver, fp_unit = fp_unit, nodes = {}, by_node = {}, fp_chains = {} }

    for _, name in ipairs(CFG.fp_nodes) do
        if Unit.has_node(driver, name) then
            local node = Unit.node(driver, name)

            if node ~= 1 and not fpd.by_node[node] then
                local entry = { node = node, parent = Unit.scene_graph_parent(driver, node) }

                if Unit.has_node(fp_unit, name) then
                    entry.fp = Unit.node(fp_unit, name)
                    fpd.fp_chains[entry.fp] = parent_chain(fp_unit, entry.fp)
                end

                fpd.by_node[node] = entry
                fpd.nodes[#fpd.nodes + 1] = entry
            end
        end
    end

    for _, name in ipairs(REQUIRED) do
        if not Unit.has_node(driver, name) then
            return nil, name
        end
    end

    return fpd
end

local function copy_pose(fpd)
    local driver, fp_unit = fpd.driver, fpd.fp_unit
    local poses = {}

    local function pose_of(node)
        if node == nil or node == 1 then
            return Quaternion.identity(), Vector3(0, 0, 0)
        end

        local pose = poses[node]

        if pose then
            return pose[1], pose[2]
        end

        local entry = fpd.by_node[node]
        local rotation, position

        if entry and entry.fp then
            local chain = fpd.fp_chains[entry.fp]
            rotation, position = Quaternion.identity(), Vector3(0, 0, 0)

            local first = chain[#chain] == 1 and #chain - 1 or #chain

            for i = first, 1, -1 do
                position = position + Quaternion.rotate(rotation, Unit.local_position(fp_unit, chain[i]))
                rotation = Quaternion.multiply(rotation, Unit.local_rotation(fp_unit, chain[i]))
            end
        else
            local parent_rotation, parent_position = pose_of(Unit.scene_graph_parent(driver, node))

            rotation = Quaternion.multiply(parent_rotation, Unit.local_rotation(driver, node))
            position = parent_position + Quaternion.rotate(parent_rotation, Unit.local_position(driver, node))
        end

        poses[node] = { rotation, position }

        return rotation, position
    end

    for i = 1, #fpd.nodes do
        local entry = fpd.nodes[i]

        if entry.fp then
            local rotation, position = pose_of(entry.node)
            local parent_rotation, parent_position = pose_of(entry.parent)
            local inverse_parent = Quaternion.inverse(parent_rotation)

            Unit.set_local_rotation(driver, entry.node, Quaternion.multiply(inverse_parent, rotation))
            Unit.set_local_position(driver, entry.node, Quaternion.rotate(inverse_parent, position - parent_position))
        end
    end
end

-- IK helpers (driver root-relative space), QIangIQsChainLaspistol_brace.lua ----------------------------------------------
local function rotation_between(u, v)
    local lu, lv = Vector3.length(u), Vector3.length(v)

    if lu < 1e-6 or lv < 1e-6 then
        return Quaternion.identity()
    end

    u, v = u * (1 / lu), v * (1 / lv)

    local axis = Vector3.cross(u, v)
    local s = Vector3.length(axis)

    if s < 1e-6 then
        return Quaternion.identity()
    end

    return Quaternion.axis_angle(axis * (1 / s), math.atan2(s, Vector3.dot(u, v)))
end

local function turn_node(driver, node, q)
    local pr = root_relative(driver, Unit.scene_graph_parent(driver, node))
    local r = root_relative(driver, node)

    Unit.set_local_rotation(driver, node, Quaternion.multiply(Quaternion.inverse(pr), Quaternion.multiply(q, r)))
end

local function pos(driver, name)
    local _, p = root_relative(driver, Unit.node(driver, name))

    return p
end

local function two_bone(driver, side, target, pole_point)
    local arm, fore = Unit.node(driver, "j_" .. side .. "arm"), Unit.node(driver, "j_" .. side .. "forearm")
    local S, E, H = pos(driver, "j_" .. side .. "arm"), pos(driver, "j_" .. side .. "forearm"), pos(driver, "j_" .. side .. "hand")
    local a, b = Vector3.length(E - S), Vector3.length(H - E)
    local to_target = target - S
    local d = math.clamp(Vector3.length(to_target), math.abs(a - b) + 1e-3, a + b - 1e-3)
    local dir = Vector3.normalize(to_target)
    local pv = pole_point - S

    pv = pv - dir * Vector3.dot(pv, dir)

    if Vector3.length(pv) < 1e-5 then
        pv = (E - S) - dir * Vector3.dot(E - S, dir)
    end

    if Vector3.length(pv) < 1e-5 then
        return
    end

    pv = Vector3.normalize(pv)

    local cos_a = math.clamp((a * a + d * d - b * b) / (2 * a * d), -1, 1)
    local sin_a = math.sqrt(math.max(0, 1 - cos_a * cos_a))
    local elbow = S + dir * (cos_a * a) + pv * (sin_a * a)

    turn_node(driver, arm, rotation_between(E - S, elbow - S))

    local E1, H1 = pos(driver, "j_" .. side .. "forearm"), pos(driver, "j_" .. side .. "hand")

    turn_node(driver, fore, rotation_between(H1 - E1, (S + dir * d) - E1))
end

-- Baked clips ----------------------------------------------------------------------------------------------------------
local function lerp_frames(a, b, w)
    local out = {}

    for k = 1, #a do
        out[k] = a[k] + (b[k] - a[k]) * w
    end

    return out
end

local function sample(clip, t, loop)
    local frames = clip.frames
    local n = #frames
    local x = (loop and (t % clip.length) or math.clamp(t, 0, clip.length)) / clip.length * (n - 1)
    local i = math.min(math.floor(x), n - 2)

    return lerp_frames(frames[i + 1], frames[i + 2], x - i)
end

local V = {}

local function vec(f, i)
    return Vector3(f[i], f[i + 1], f[i + 2])
end

-- Hands and fingers (QIangIQsPowerAxe 0.6.0 layout): a bake may carry the hand bone's axes and every finger bone's local
-- rotation after the 33 arm values. The Mauler bake has only the 33 (hand frame from the finger bones), so the fingers keep
-- the Eviscerator's grip.
local FINGERS = {
    "inhandindex", "handindex1", "handindex2", "handindex3", "inhandmiddle", "handmiddle1", "handmiddle2", "handmiddle3",
    "inhandpinky", "handpinky1", "handpinky2", "handpinky3", "inhandring", "handring1", "handring2", "handring3",
    "handthumb1", "handthumb2",
}
local HAND_BLOCK = { right = 34, left = 34 + 6 + #FINGERS * 6 }

local function axes_rotation(f, i)
    local y = Vector3.normalize(vec(f, i))
    local z = vec(f, i + 3)

    z = Vector3.normalize(z - y * Vector3.dot(z, y))

    return Quaternion.look(y, z)
end

local function solve_hand(driver, side, f, i, t_r, t_p)
    local target_p = t_p + Quaternion.rotate(t_r, vec(f, i))
    local pole = target_p + Quaternion.rotate(t_r, vec(f, i + 9))
    local hand = Unit.node(driver, "j_" .. side .. "hand")
    local block = HAND_BLOCK[side]
    local target_r

    if f[block + 5 + #FINGERS * 6] then
        target_r = Quaternion.multiply(t_r, axes_rotation(f, block))
    else
        -- old bake without hand data: hand frame from the hand's own finger bones, as QIangIQsChainLaspistol_brace.lua
        local forward = Quaternion.rotate(t_r, Vector3.normalize(vec(f, i + 3)))
        local up = Quaternion.rotate(t_r, Vector3.normalize(vec(f, i + 6)))
        local hand_r, hand_p = root_relative(driver, hand)
        local inv_hand = Quaternion.inverse(hand_r)
        local f_local = Quaternion.rotate(inv_hand, pos(driver, "j_" .. side .. "handmiddle1") - hand_p)
        local u_local = Quaternion.rotate(inv_hand, pos(driver, "j_" .. side .. "handindex1") - pos(driver, "j_" .. side .. "handpinky1"))

        forward = Vector3.normalize(forward - up * Vector3.dot(forward, up))
        u_local = Vector3.normalize(u_local)
        f_local = Vector3.normalize(f_local - u_local * Vector3.dot(f_local, u_local))
        target_r = Quaternion.multiply(Quaternion.look(forward, up), Quaternion.inverse(Quaternion.look(f_local, u_local)))
    end

    two_bone(driver, side, target_p, pole)

    local parent_r = root_relative(driver, Unit.scene_graph_parent(driver, hand))

    Unit.set_local_rotation(driver, hand, Quaternion.multiply(Quaternion.inverse(parent_r), target_r))

    if f[block + 5 + #FINGERS * 6] then
        for k, name in ipairs(FINGERS) do
            local node_name = "j_" .. side .. name

            if Unit.has_node(driver, node_name) then
                Unit.set_local_rotation(driver, Unit.node(driver, node_name), axes_rotation(f, block + k * 6))
            end
        end
    end
end

-- start / stop / update ------------------------------------------------------------------------------------------------
local function arm_units(ext)
    local found = {}

    for slot_name, slot in pairs(ext._equipment or {}) do
        if type(slot_name) == "string" and (slot_name:find("^slot_body") or slot_name:find("^slot_gear")) and unit_ok(slot.unit_1p) then
            found[#found + 1] = slot.unit_1p
        end
    end

    return found
end

local function relink(world, unit, parent)
    World.unlink_unit(world, unit)
    World.link_unit(world, unit, 1, parent, 1, World.LINK_MODE_NODE_NAME)
end

function Arms.stop(ext)
    local data = ext.__qiangiq_chainaxe2h_arms

    if not data then
        return
    end

    ext.__qiangiq_chainaxe2h_arms = nil

    local world = ext.__qiangiq_chainaxe2h_world

    -- the axe rig back on the first-person weapon node it came from
    if world and unit_ok(data.rig) and unit_ok(data.fp_unit) and data.rig_node then
        World.unlink_unit(world, data.rig)
        World.link_unit(world, data.rig, 1, data.fp_unit, data.rig_node)
        Unit.set_local_position(data.rig, 1, Vector3(0, 0, 0))
        Unit.set_local_rotation(data.rig, 1, Quaternion.identity())
    end

    if world and unit_ok(data.fp_unit) then
        for unit in pairs(data.arms) do
            if unit_ok(unit) then
                relink(world, unit, data.fp_unit)
            end
        end
    end

    if unit_ok(data.driver) then
        local unit_spawner = Managers.state and Managers.state.unit_spawner

        if unit_spawner then
            unit_spawner:mark_for_deletion(data.driver)
        end
    end
end

local function start(ext, fp_unit, world)
    local unit_spawner = Managers.state and Managers.state.unit_spawner
    local path = CFG.driver_path()

    if not (unit_spawner and path) then
        return nil
    end

    local driver = unit_spawner:spawn_unit(path, Unit.world_pose(fp_unit, 1))

    if not driver then
        return nil
    end

    local ok, fpd, missing = pcall(make_fpd, driver, fp_unit)

    if not ok or not fpd then
        unit_spawner:mark_for_deletion(driver)
        CFG.error("arm driver lacks node " .. tostring(ok and missing or fpd) .. ": Mauler arms off")

        return nil
    end

    World.link_unit(world, driver, 1, fp_unit, 1)
    copy_pose(fpd)

    local data = { driver = driver, fpd = fpd, fp_unit = fp_unit, arms = {}, pose = nil }

    ext.__qiangiq_chainaxe2h_arms = data

    return data
end


-- Darktide action -> Mauler clip, by the Eviscerator's anim_event (chainsword_2h_p1_m1.lua): light attacks -> the quick chops
-- (attack_03 / attack_04) and the upward swing (attack_reach_up), heavies -> the two cleaves (attack_01 / attack_02), their
-- charges -> the cleave's wind-up. attack_down_01 (blade speed 2.3 m/s, a stab at the ground) and the running attacks are not
-- used. Everything else (equip, idle, block, push, special, inspect) stays the Eviscerator's own animation.
local CLIPS = {
    attack_left_down = "attack_03", attack_right_diagonal_down = "attack_04", attack_left = "attack_03",
    attack_right_down = "attack_04", attack_right = "attack_reach_up",
    heavy_attack_left = "attack_01", heavy_attack_right_down = "attack_02",
}
local CHARGES = { heavy_charge_left = "attack_01", heavy_charge_down_right = "attack_02" }
-- a charge plays the cleave's wind-up up to this share of its hit0 and holds there
local HOLD_SHARE = 0.8

-- by anim event alone (third person, QIangIQsChainaxe2h_tp.lua)
function Arms.pick_event(ev)
    if CHARGES[ev] then
        return CHARGES[ev], "charge"
    end

    return CLIPS[ev], CLIPS[ev] and "once" or nil
end

Arms.HOLD_SHARE = HOLD_SHARE

local function pick_clip(action)
    local name = action.name

    if not name or name == "none" then
        return nil
    end

    local ev = type(action.event) == "string" and action.event or ""

    if CHARGES[ev] then
        return CHARGES[ev], "charge"
    end

    return CLIPS[ev], CLIPS[ev] and "once" or nil
end

-- piecewise time warp: action time -> clip time, so the clip's fast part falls on the action's damage window; start = the
-- clip time a charge already reached
local function warp(clip, action, start)
    local e, total, L = action.elapsed or 0, math.max(action.total or clip.length, 0.05), clip.length
    local d0, d1, h0, h1 = action.dws, action.dwe, clip.hit0, clip.hit1

    start = math.min(start or 0, h0 or 0)

    if not (d0 and d1 and h0 and h1) or d1 <= d0 or d1 >= total or h1 >= L or d0 <= 0 then
        return start + e / total * (L - start)
    end

    if e < d0 then
        return start + e / d0 * (h0 - start)
    elseif e < d1 then
        return h0 + (e - d0) / (d1 - d0) * (h1 - h0)
    end

    return h1 + (e - d1) / (total - d1) * (L - h1)
end

-- The axe rig: moved from the first-person weapon node to the driver root once, keeping its pose relative to
-- j_rightweaponattach (rel_*), so with weight 0 it sits exactly where the Eviscerator's animation puts it.
local function link_weapon(data, world, slot)
    local rig, fp_unit = slot.unit_1p, data.fp_unit

    if not Unit.has_node(fp_unit, "j_rightweaponattach") then
        return false
    end

    local node = Unit.node(fp_unit, "j_rightweaponattach")
    local node_r, node_p = Unit.world_rotation(fp_unit, node), Unit.world_position(fp_unit, node)
    local inv = Quaternion.inverse(node_r)
    local rel_p = Quaternion.rotate(inv, Unit.world_position(rig, 1) - node_p)

    -- a rig that has not been placed yet gives a garbage offset: wait a few frames, then take it as on the node
    data.link_tries = (data.link_tries or 0) + 1

    if Vector3.length(rel_p) > 0.5 then
        if data.link_tries < 90 then
            return false
        end

        rel_p = Vector3(0, 0, 0)
    end

    data.rig, data.rig_node = rig, node
    data.rel_p = Vector3Box(rel_p)
    data.rel_r = QuaternionBox(Quaternion.multiply(inv, Unit.world_rotation(rig, 1)))

    World.unlink_unit(world, rig)
    World.link_unit(world, rig, 1, data.driver, 1, World.LINK_MODE_NONE)
    CFG.info(string.format("axe linked to the driver after %d tries: offset from j_rightweaponattach %.3f %.3f %.3f m",
        data.link_tries, rel_p.x, rel_p.y, rel_p.z))

    return true
end

local function push3(out, v)
    out[#out + 1] = v.x
    out[#out + 1] = v.y
    out[#out + 1] = v.z
end

-- the Eviscerator's own pose of this frame (the driver's copy, before any IK) in the bake's row layout
local function retail_row(data, cam_r, cam_p)
    local driver = data.driver
    local wa_r, wa_p = root_relative(driver, Unit.node(driver, "j_rightweaponattach"))
    local a_r = Quaternion.multiply(wa_r, data.rel_r:unbox())
    local a_p = wa_p + Quaternion.rotate(wa_r, data.rel_p:unbox())
    local inv_c, inv_a = Quaternion.inverse(cam_r), Quaternion.inverse(a_r)
    local out = {}

    push3(out, Quaternion.rotate(inv_c, a_p - cam_p))
    push3(out, Quaternion.rotate(inv_c, Quaternion.rotate(a_r, Vector3(0, 1, 0))))
    push3(out, Quaternion.rotate(inv_c, Quaternion.rotate(a_r, Vector3(0, 0, 1))))

    for _, side in ipairs({ "right", "left" }) do
        local h = pos(driver, "j_" .. side .. "hand")

        push3(out, Quaternion.rotate(inv_a, h - a_p))
        push3(out, Quaternion.rotate(inv_a, Vector3.normalize(pos(driver, "j_" .. side .. "handmiddle1") - h)))
        push3(out, Quaternion.rotate(inv_a, Vector3.normalize(pos(driver, "j_" .. side .. "handindex1") - pos(driver, "j_" .. side .. "handpinky1"))))
        push3(out, Quaternion.rotate(inv_a, pos(driver, "j_" .. side .. "forearm") - h))
    end

    return out
end

-- slot: the equipment slot of the axe; action: name, event, elapsed, total, dws, dwe, clock
function Arms.update(ext, slot, action, dt)
    local fpe = unit_ok(ext._unit) and ScriptUnit.has_extension(ext._unit, "first_person_system")
    local fp_unit = fpe and fpe:first_person_unit()
    local world = ext.__qiangiq_chainaxe2h_world
    local data = ext.__qiangiq_chainaxe2h_arms
    local want = slot ~= nil and slot.hidden_1p == false and CFG.driver_path() ~= nil and world ~= nil and unit_ok(fp_unit)
        and unit_ok(slot.unit_1p) and fpe.is_in_first_person_mode and fpe:is_in_first_person_mode()

    dt = dt or 0

    if data and (not want or data.fp_unit ~= fp_unit or not unit_ok(data.driver)) then
        Arms.stop(ext)
        data = nil
    end

    if not want then
        return
    end

    data = data or start(ext, fp_unit, world)

    if not data then
        return
    end

    for _, unit in ipairs(arm_units(ext)) do
        if not data.arms[unit] then
            relink(world, unit, data.driver)
            data.arms[unit] = true
        end
    end

    for unit in pairs(data.arms) do
        if not unit_ok(unit) then
            data.arms[unit] = nil
        end
    end

    copy_pose(data.fpd)

    if data.rig ~= slot.unit_1p and not link_weapon(data, world, slot) then
        World.update_unit_and_children(world, data.driver)

        return
    end

    local baked = CFG.baked()
    local clip_name, mode = pick_clip(action)
    local clip = clip_name and baked and baked[clip_name]

    if not clip then
        clip_name, mode = nil, nil
    end

    -- weight of the Mauler pose: eased in at the start of an attack and out after it
    data.w = data.w or 0
    data.w = data.w + ((clip and 1 or 0) - data.w) * (1 - math.exp(-dt * 12))

    local driver = data.driver
    local cam_r, cam_p = root_relative(driver, Unit.node(driver, "ap_camera_node"))
    local ok, err = pcall(function()
        local f = retail_row(data, cam_r, cam_p)

        if clip then
            local t

            if mode == "charge" then
                local hold = (clip.hit0 or clip.length * 0.4) * HOLD_SHARE

                t = hold * math.min(1, (action.elapsed or 0) / math.max(CFG.opt("charge_time", 0.5), 0.05))
                data.charged = { clip = clip_name, t = t }
            else
                local start = data.charged and data.charged.clip == clip_name and data.charged.t or 0

                t = warp(clip, action, start)
            end

            data.baked_frame = sample(clip, t, false)
            data.clip = clip_name
        else
            data.charged = nil
        end

        if data.w > 0.001 and data.baked_frame then
            f = lerp_frames(f, data.baked_frame, data.w)
        end

        local t_r = Quaternion.multiply(cam_r, Quaternion.look(Vector3.normalize(vec(f, 4)), Vector3.normalize(vec(f, 7))))
        local t_p = cam_p + Quaternion.rotate(cam_r, vec(f, 1))

        if data.w > 0.001 then
            solve_hand(driver, "right", f, 10, t_r, t_p)
            solve_hand(driver, "left", f, 22, t_r, t_p)
        end

        -- the axe rig root is the baked axe frame (the Mauler's axe unit sits on j_leftweaponattach with the same bounds)
        Unit.set_local_position(data.rig, 1, t_p)
        Unit.set_local_rotation(data.rig, 1, t_r)
    end)

    if not ok and not data.reported then
        data.reported = true
        CFG.error("arms: " .. tostring(err))
    end

    data.log_t = (data.log_t or 0) - dt

    if data.log_t <= 0 and CFG.opt("debug", false) then
        data.log_t = 3
        CFG.info(string.format("arms: clip %s mode %s weight %.2f, action %s event %s, ok=%s", tostring(clip_name), tostring(mode),
            data.w, tostring(action.name), tostring(action.event), tostring(ok)))
    end

    World.update_unit_and_children(world, driver)
end

function Arms.debug(ext)
    local data = ext.__qiangiq_chainaxe2h_arms

    if not data then
        return "arms: not active (driver asset " .. tostring(CFG.driver_path()) .. ")"
    end

    local n = 0

    for _ in pairs(data.arms) do
        n = n + 1
    end

    return string.format("arms: active, %d arm units on the driver, axe linked: %s, last clip %s, weight %.2f", n,
        tostring(data.rig ~= nil), tostring(data.clip), data.w or 0)
end

return Arms
