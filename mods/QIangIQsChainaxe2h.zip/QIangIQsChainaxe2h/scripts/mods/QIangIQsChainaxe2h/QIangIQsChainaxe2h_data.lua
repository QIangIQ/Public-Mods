local mod = get_mod("QIangIQsChainaxe2h")

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = false,
    options = {
        widgets = {
            {
                setting_id = "moveset",
                type = "dropdown",
                default_value = "m1",
                options = {
                    { text = "moveset_m1", value = "m1" },
                    { text = "moveset_m2", value = "m2" },
                },
            },
            {
                setting_id = "part_set",
                type = "dropdown",
                default_value = "01",
                options = {
                    { text = "part_01", value = "01" },
                    { text = "part_ml01", value = "ml01" },
                },
            },
            { setting_id = "mauler_arms", type = "checkbox", default_value = true },
            { setting_id = "mauler_3p", type = "checkbox", default_value = true },
            { setting_id = "charge_time", type = "numeric", default_value = 0.5, range = { 0.2, 2 }, decimals_number = 1 },
            { setting_id = "shaft_offset", type = "numeric", default_value = 0, range = { -40, 40 }, decimals_number = 0 },
            { setting_id = "add_to_unlock_list", type = "checkbox", default_value = true },
            { setting_id = "unlock_level", type = "numeric", default_value = 1, range = { 1, 30 }, decimals_number = 0 },
            { setting_id = "unlock_zealot", type = "checkbox", default_value = true },
            { setting_id = "unlock_veteran", type = "checkbox", default_value = true },
            { setting_id = "unlock_psyker", type = "checkbox", default_value = false },
            { setting_id = "unlock_adamant", type = "checkbox", default_value = false },
            { setting_id = "debug", type = "checkbox", default_value = false },
        },
    },
}
