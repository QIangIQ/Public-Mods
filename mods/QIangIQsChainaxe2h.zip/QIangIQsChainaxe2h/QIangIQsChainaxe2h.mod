return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsChainaxe2h` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsChainaxe2h", {
            mod_script = "QIangIQsChainaxe2h/scripts/mods/QIangIQsChainaxe2h/QIangIQsChainaxe2h",
            mod_data = "QIangIQsChainaxe2h/scripts/mods/QIangIQsChainaxe2h/QIangIQsChainaxe2h_data",
            mod_localization = "QIangIQsChainaxe2h/scripts/mods/QIangIQsChainaxe2h/QIangIQsChainaxe2h_localization",
        })
    end,
    version = "0.3.1",
    author = "QIangIQ",
    packages = {},
}
