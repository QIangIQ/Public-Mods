local mod = get_mod("QIangIQsDeagle")

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = true,
    options = {
        widgets = {
            { setting_id = "cs2_3p", type = "checkbox", default_value = true },
            { setting_id = "replace_phosphor", type = "checkbox", default_value = true },
            { setting_id = "replace_revolver", type = "checkbox", default_value = true },
            { setting_id = "replace_boltpistol", type = "checkbox", default_value = true },
            {
                setting_id = "group_fit",
                type = "group",
                sub_widgets = {
                    { setting_id = "model_size", type = "numeric", default_value = 1, range = { 0.5, 2 }, decimals_number = 2 },
                    { setting_id = "model_slide", type = "numeric", default_value = 0, range = { -0.5, 0.5 }, decimals_number = 2 },
                    { setting_id = "model_roll", type = "numeric", default_value = 0, range = { -180, 180 }, decimals_number = 0 },
                    { setting_id = "model_tilt", type = "numeric", default_value = 0, range = { -45, 45 }, decimals_number = 0 },
                    { setting_id = "flip_model", type = "checkbox", default_value = false },
                },
            },
            {
                setting_id = "group_cs2_arms",
                type = "group",
                sub_widgets = {
                    {
                        setting_id = "cs2_arms",
                        type = "dropdown",
                        default_value = "viewmodel",
                        options = {
                            { text = "cs2_arms_off", value = "off" },
                            { text = "cs2_arms_viewmodel", value = "viewmodel" },
                            { text = "cs2_arms_follow", value = "follow" },
                        },
                    },
                    {
                        setting_id = "cs2_sleeves",
                        type = "dropdown",
                        default_value = "character",
                        options = {
                            { text = "cs2_sleeves_ct", value = "ct" },
                            { text = "cs2_sleeves_t", value = "t" },
                            { text = "cs2_sleeves_character", value = "character" },
                        },
                    },
                    { setting_id = "cs2_vm_x", type = "numeric", default_value = 1, range = { -2, 2.5 }, decimals_number = 1 },
                    { setting_id = "cs2_vm_y", type = "numeric", default_value = 1, range = { -2, 2 }, decimals_number = 1 },
                    { setting_id = "cs2_vm_z", type = "numeric", default_value = -1, range = { -2, 2 }, decimals_number = 1 },
                    { setting_id = "index_lift", type = "numeric", default_value = 12, range = { 0, 30 }, decimals_number = 0 },
                    { setting_id = "cs2_shot_speed", type = "numeric", default_value = 1, range = { 0.5, 2 }, decimals_number = 2 },
                    { setting_id = "hide_when_aiming", type = "checkbox", default_value = false },
                },
            },
            {
                setting_id = "group_cs2_sounds",
                type = "group",
                sub_widgets = {
                    { setting_id = "cs2_sounds", type = "checkbox", default_value = true },
                    { setting_id = "cs2_sound_volume", type = "numeric", default_value = 100, range = { 0, 400 }, decimals_number = 0 },
                    { setting_id = "mute_game_shot", type = "checkbox", default_value = true },
                },
            },
            { setting_id = "hide_weapon_fx", type = "checkbox", default_value = true },
            { setting_id = "menu_previews", type = "checkbox", default_value = true },
            {
                setting_id = "toggle_deagle_keybind",
                type = "keybind",
                default_value = {},
                keybind_trigger = "pressed",
                keybind_type = "function_call",
                function_name = "toggle_deagle",
            },
        },
    },
}
