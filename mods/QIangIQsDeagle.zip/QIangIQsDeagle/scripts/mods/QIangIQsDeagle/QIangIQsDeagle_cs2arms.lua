local Arms = {}
local CFG = nil

function Arms.setup(cfg)
    CFG = cfg
end

Arms.ASSETS = { "cs2_arms_ct", "cs2_arms_t" }

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function opt(key, default)
    local v = CFG.opt(key)
    if v == nil then
        return default
    end
    return v
end

local decoded = {}

local function clip_data(name)
    local clip = CFG.data.clips[name]
    if not clip then
        return nil
    end
    local arr = decoded[name]
    if not arr then
        arr = {}
        local n, inv = 0, 1 / CFG.data.scale
        for v in string.gmatch(clip.data, "-?%d+") do
            n = n + 1
            arr[n] = tonumber(v) * inv
        end
        decoded[name] = arr
    end
    return arr, clip.frames
end

local function clip_duration(name)
    local clip = CFG.data.clips[name]
    return clip and (clip.frames - 1) / CFG.data.fps or 0
end

local function sample(name, t, out)
    local arr, frames = clip_data(name)
    if not arr then
        return nil
    end
    local stride = CFG.data.stride
    local f = math.max(0, math.min(frames - 1, t * CFG.data.fps))
    local i = math.floor(f)
    local u = f - i
    local j = math.min(frames - 1, i + 1)
    local a, b = i * stride, j * stride
    for k = 1, stride do
        local va = arr[a + k]
        out[k] = va + (arr[b + k] - va) * u
    end
    return out
end

local quat_slots = nil

local function quat_slot_list()
    if not quat_slots then
        quat_slots = {}
        local n = #CFG.data.bones + 1 + #CFG.data.parts
        for i = 0, n - 1 do
            quat_slots[#quat_slots + 1] = 7 * i + 1
        end
    end
    return quat_slots
end

local function blend(a, b, u, out)
    for k = 1, CFG.data.stride do
        out[k] = a[k] + (b[k] - a[k]) * u
    end
    for _, s in ipairs(quat_slot_list()) do
        local d = a[s] * b[s] + a[s + 1] * b[s + 1] + a[s + 2] * b[s + 2] + a[s + 3] * b[s + 3]
        if d < 0 then
            for k = 0, 3 do
                out[s + k] = a[s + k] + (-b[s + k] - a[s + k]) * u
            end
        end
    end
    return out
end

local function quat_at(p, o)
    local x, y, z, w = p[o], p[o + 1], p[o + 2], p[o + 3]
    local n = math.sqrt(x * x + y * y + z * z + w * w)
    if n < 1e-9 then
        return Quaternion.identity()
    end
    return Quaternion.from_elements(x / n, y / n, z / n, w / n)
end

local function parent_chain(unit, node)
    local list, current, guard = {}, node, 0
    while current and guard < 64 do
        list[#list + 1] = current
        if current == 1 then
            break
        end
        current = Unit.scene_graph_parent(unit, current)
        guard = guard + 1
    end
    return list
end

local function root_relative(unit, node)
    local chain = parent_chain(unit, node)
    local rotation, position = Quaternion.identity(), Vector3(0, 0, 0)
    local first = chain[#chain] == 1 and #chain - 1 or #chain
    for i = first, 1, -1 do
        position = position + Quaternion.rotate(rotation, Unit.local_position(unit, chain[i]))
        rotation = Quaternion.multiply(rotation, Unit.local_rotation(unit, chain[i]))
    end
    return rotation, position
end

local function capture(unit, names)
    local bones, by_name = {}, {}
    for i, name in ipairs(names) do
        if Unit.has_node(unit, name) then
            local node = Unit.node(unit, name)
            local r0, p0 = root_relative(unit, node)
            local parent = Unit.scene_graph_parent(unit, node)
            local pr, pp = Quaternion.identity(), Vector3(0, 0, 0)
            if parent and parent ~= 1 then
                pr, pp = root_relative(unit, parent)
            end
            local b = { index = i, name = name, node = node, r0 = QuaternionBox(r0), p0 = Vector3Box(p0),
                pinv = QuaternionBox(Quaternion.inverse(pr)), pp = Vector3Box(pp) }
            bones[#bones + 1] = b
            by_name[name] = b
        end
    end
    return bones, by_name
end

local function set_rr(unit, b, r, p)
    local pinv = b.pinv:unbox()
    Unit.set_local_rotation(unit, b.node, Quaternion.multiply(pinv, r))
    Unit.set_local_position(unit, b.node, Quaternion.rotate(pinv, p - b.pp:unbox()))
end

local function spawn(world, path, parent, node, custom_fov)
    local spawner = Managers.state and Managers.state.unit_spawner
    if not (spawner and unit_ok(parent)) then
        return nil
    end
    local unit = spawner:spawn_unit(path, Unit.world_pose(parent, node))
    if not unit then
        return nil
    end
    Unit.set_unit_culling(unit, false)
    if custom_fov then
        Unit.set_shader_pass_flag_for_meshes_in_unit_and_childs(unit, "custom_fov", true)
    end
    World.link_unit(world, unit, 1, parent, node)
    return unit
end

local function destroy(world, unit)
    if unit_ok(unit) then
        if world then
            World.unlink_unit(world, unit)
        end
        local spawner = Managers.state and Managers.state.unit_spawner
        if spawner then
            spawner:mark_for_deletion(unit)
        end
    end
end

local function classify(name)
    if not name then
        return nil
    end
    if name == "action_wield" then
        return "draw"
    elseif name == "action_reload" or name == "action_start_reload" or name == "action_reload_loop" then
        return "reload"
    elseif name == "action_inspect" or name == "action_inspect_3p" then
        return "inspect"
    end
    return nil
end

local FADE = 0.12

local function play(st, name, speed, loop)
    if not CFG.data.clips[name] then
        return
    end
    if st.pose then
        st.from = {}
        for k = 1, CFG.data.stride do
            st.from[k] = st.pose[k]
        end
        st.fade = 0
    end
    st.clip, st.t, st.speed, st.loop = name, 0, speed, loop
end

local function pick_inspect()
    local list = {}
    for _, k in ipairs({ "lookat01", "lookat02", "lookat03" }) do
        if CFG.data.clips[k] then
            list[#list + 1] = k
        end
    end
    return list[math.random(math.max(1, #list))] or "lookat01"
end

local function rest_clip(st)
    if st.empty and CFG.data.clips.idle_slide_back then
        return "idle_slide_back"
    end
    return "idle"
end

-- Inspect = a tap toggle on the inspect key (user requests 2026-11-08 22:19 and 22:22): the press starts one CS2 inspect at
-- once, every further press starts a new one, releasing the key does nothing, and any other action (attack, reload, draw) takes over.
-- Darktide's own action_inspect (it needs the key held 0.2 s) no longer drives the viewmodel.
local function inspect_held()
    local ok, held = pcall(function()
        local svc = Managers.input and Managers.input:get_input_service("Ingame")
        return svc and svc:get("weapon_inspect_hold")
    end)
    return ok and held and true or false
end

local function viewmodel_step(st, action, shots, dt)
    local name, start_t = action.name, action.start_t
    local key = tostring(name) .. ":" .. tostring(start_t)
    local kind = classify(name)
    local inspect_down = inspect_held()
    if inspect_down and not st.inspect_was_down then
        -- every press starts a fresh inspect, also during one (user request 2026-11-08 22:31: spam inspect, no cancel tap)
        if st.loop or (st.clip and string.find(st.clip, "^lookat")) then
            st.inspect_clip = pick_inspect()
            play(st, st.inspect_clip, 1, false)
        end
    end
    st.inspect_was_down = inspect_down
    st.empty = action.empty == true
    if shots ~= st.shots then
        if st.shots ~= nil then
            local c = (st.empty and CFG.data.clips.shoot_empty) and "shoot_empty" or "shoot1"
            play(st, c, opt("cs2_shot_speed", 1), false)
        end
        st.shots = shots
    end
    if key ~= st.action_key then
        st.action_key = key
        if kind == "draw" then
            play(st, "draw", 1, false)
        elseif kind == "reload" and not (st.kind == "reload" and action.reload_continue) then
            local clip = (action.empty and CFG.data.clips.reload_empty) and "reload_empty" or "reload"
            local total = action.total_time
            local speed = (total and total > 0) and clip_duration(clip) / total or 1
            play(st, clip, math.max(0.25, math.min(4, speed)), false) -- CS2 reload stretched to the Darktide reload length
        end
        st.kind = kind
    end
    if not st.clip then
        play(st, rest_clip(st), 1, true)
    elseif st.loop and (st.clip == "idle" or st.clip == "idle_slide_back") and st.clip ~= rest_clip(st) then
        play(st, rest_clip(st), 1, true)
    end
    st.t = st.t + dt * (st.speed or 1)
    local dur = clip_duration(st.clip)
    if st.t >= dur then
        if st.loop then
            st.t = dur > 1e-3 and st.t % dur or 0
        else
            play(st, rest_clip(st), 1, true)
        end
    end
    st.cur = st.cur or {}
    local pose = sample(st.clip, st.t, st.cur)
    if st.from and st.fade then
        st.fade = st.fade + dt
        local u = math.min(1, st.fade / FADE)
        u = u * u * (3 - 2 * u)
        st.blend_out = st.blend_out or {}
        pose = blend(st.from, pose, u, st.blend_out)
        if u >= 1 then
            st.from, st.fade = nil, nil
        end
    end
    st.pose = st.pose or {}
    for k = 1, CFG.data.stride do
        st.pose[k] = pose[k]
    end
    return st.pose
end

local function apply_viewmodel(data, pose)
    local unit = data.unit
    local inch = 0.0254
    local offset = Vector3(opt("cs2_vm_x", 1) * inch, opt("cs2_vm_y", 1) * inch, opt("cs2_vm_z", -1) * inch)
    Unit.set_local_position(unit, 1, offset)
    data.cs2_off = Vector3Box(offset)
    data.cs2_rr = data.cs2_rr or {}
    for _, b in ipairs(data.bones) do
        local o = 7 * (b.index - 1) + 1
        local dq = quat_at(pose, o)
        local r, pp = Quaternion.multiply(dq, b.r0:unbox()), Quaternion.rotate(dq, b.p0:unbox()) + Vector3(pose[o + 4], pose[o + 5], pose[o + 6])
        set_rr(unit, b, r, pp)
        data.cs2_rr[b.node] = { QuaternionBox(r), Vector3Box(pp), QuaternionBox(dq) }
    end
    local gun = data.gun
    if gun and unit_ok(gun.unit) then
        local nb = #CFG.data.bones
        local o = 7 * nb + 1
        local s = CFG.data.gun_scale or 1
        Unit.set_local_rotation(gun.unit, 1, quat_at(pose, o))
        Unit.set_local_position(gun.unit, 1, Vector3(pose[o + 4], pose[o + 5], pose[o + 6]))
        Unit.set_local_scale(gun.unit, 1, Vector3(s, s, s))
        for _, b in ipairs(gun.parts) do
            local q = 7 * (nb + b.index) + 1
            local dq = quat_at(pose, q)
            set_rr(gun.unit, b, Quaternion.multiply(dq, b.r0:unbox()), Quaternion.rotate(dq, b.p0:unbox()) + Vector3(pose[q + 4], pose[q + 5], pose[q + 6]))
        end
    end
end

local function perp(v, axis)
    local p = v - axis * Vector3.dot(v, axis)
    local l = Vector3.length(p)
    if l < 1e-6 then
        return nil
    end
    return p * (1 / l)
end

local function frame(dir, ref)
    local d = Vector3.normalize(dir)
    local r = ref and perp(ref, d)
    if not r then
        return nil
    end
    return Quaternion.look(d, r)
end

local FINGERS = { "index", "middle", "ring", "pinky" }

local function follow_side(data, src, to_local, side, cs)
    local dt = "j_" .. side
    local function has(n)
        return Unit.has_node(src, n)
    end
    for _, n in ipairs({ dt .. "arm", dt .. "forearm", dt .. "hand", dt .. "handmiddle1", dt .. "handindex1", dt .. "handpinky1" }) do
        if not has(n) then
            return
        end
    end
    local function P(n)
        return to_local.pos(Unit.world_position(src, Unit.node(src, n)))
    end
    local function R(n)
        return to_local.rot(Unit.world_rotation(src, Unit.node(src, n)))
    end
    local B = data.by_name
    local hand, lower, upper = B["hand_" .. cs], B["arm_lower_" .. cs], B["arm_upper_" .. cs]
    if not (hand and lower and upper and B["finger_middle_0_" .. cs] and B["finger_index_0_" .. cs] and B["finger_pinky_0_" .. cs]) then
        return
    end
    local unit = data.unit
    local function put(b, delta, pos)
        set_rr(unit, b, Quaternion.multiply(delta, b.r0:unbox()), pos)
    end
    local p_sh, p_el, p_wr = P(dt .. "arm"), P(dt .. "forearm"), P(dt .. "hand")
    local f = P(dt .. "handmiddle1") - p_wr
    local u = P(dt .. "handindex1") - P(dt .. "handpinky1")
    local r_wr = hand.p0:unbox()
    local f0 = B["finger_middle_0_" .. cs].p0:unbox() - r_wr
    local u0 = B["finger_index_0_" .. cs].p0:unbox() - B["finger_pinky_0_" .. cs].p0:unbox()
    local r_lo, r_up = lower.p0:unbox(), upper.p0:unbox()
    local hf, hf0 = frame(f, u), frame(f0, u0)
    if not (hf and hf0) then
        return
    end
    local d_hand = Quaternion.multiply(hf, Quaternion.inverse(hf0))
    local du, dl = p_el - p_sh, p_wr - p_el
    local du0, dl0 = r_lo - r_up, r_wr - r_lo
    local n = Vector3.cross(du, dl)
    local n0 = Vector3.cross(du0, dl0)
    if Vector3.length(n) < 1e-5 or Vector3.length(n0) < 1e-5 then
        n, n0 = u, u0
    end
    local fu, fu0 = frame(du, n), frame(du0, n0)
    local fl, fl0 = frame(dl, n), frame(dl0, n0)
    if not (fu and fu0 and fl and fl0) then
        return
    end
    local d_up = Quaternion.multiply(fu, Quaternion.inverse(fu0))
    local d_lo = Quaternion.multiply(fl, Quaternion.inverse(fl0))
    local pos_hand = p_wr
    local pos_lo = pos_hand - Quaternion.rotate(d_lo, r_wr - r_lo)
    local pos_up = pos_lo - Quaternion.rotate(d_up, r_lo - r_up)
    put(upper, d_up, pos_up)
    put(lower, d_lo, pos_lo)
    put(hand, d_hand, pos_hand)
    local axis = Vector3.normalize(dl)
    local x, y, z, w = Quaternion.to_elements(Quaternion.multiply(d_hand, Quaternion.inverse(d_lo)))
    local tw = 2 * math.atan2(x * axis.x + y * axis.y + z * axis.z, w)
    if tw > math.pi then
        tw = tw - 2 * math.pi
    elseif tw < -math.pi then
        tw = tw + 2 * math.pi
    end
    for name, share in pairs({ ["arm_lower_" .. cs .. "_TWIST"] = 0.5, ["arm_lower_" .. cs .. "_TWIST1"] = 1 }) do
        local b = B[name]
        if b then
            put(b, Quaternion.multiply(Quaternion.axis_angle(axis, tw * share), d_lo), pos_lo + Quaternion.rotate(d_lo, b.p0:unbox() - r_lo))
        end
    end
    for _, name in ipairs({ "arm_upper_" .. cs .. "_TWIST", "arm_upper_" .. cs .. "_TWIST1" }) do
        local b = B[name]
        if b then
            put(b, d_up, pos_up + Quaternion.rotate(d_up, b.p0:unbox() - r_up))
        end
    end
    local function tip(a, b)
        local pa, pb = P(a), P(b)
        return pb + Quaternion.rotate(Quaternion.multiply(R(b), Quaternion.inverse(R(a))), pb - pa)
    end
    local function chain(cs_names, dt_names, start)
        local parent_b, parent_pos, parent_d = start[1], start[2], start[3]
        for i, cn in ipairs(cs_names) do
            local b = B[cn]
            if not b then
                return
            end
            local pos = parent_pos + Quaternion.rotate(parent_d, b.p0:unbox() - parent_b.p0:unbox())
            local a_name, b_name = dt_names[i], dt_names[i + 1]
            local live_dir
            if b_name and has(b_name) then
                live_dir = P(b_name) - P(a_name)
            elseif has(a_name) and i > 1 and has(dt_names[i - 1]) then
                live_dir = tip(dt_names[i - 1], a_name) - P(a_name)
            end
            local nxt = B[cs_names[i + 1]]
            local rest_dir = nxt and (nxt.p0:unbox() - b.p0:unbox()) or (b.p0:unbox() - parent_b.p0:unbox())
            local fr, fr0 = live_dir and frame(live_dir, u), frame(rest_dir, u0)
            local d = (fr and fr0) and Quaternion.multiply(fr, Quaternion.inverse(fr0)) or parent_d
            put(b, d, pos)
            parent_b, parent_pos, parent_d = b, pos, d
        end
    end
    for _, fg in ipairs(FINGERS) do
        local meta = B["finger_" .. fg .. "_meta_" .. cs]
        local start = { hand, pos_hand, d_hand }
        if meta then
            local mpos = pos_hand + Quaternion.rotate(d_hand, meta.p0:unbox() - r_wr)
            put(meta, d_hand, mpos)
            start = { meta, mpos, d_hand }
        end
        local dtn = { dt .. "hand" .. fg .. "1", dt .. "hand" .. fg .. "2", dt .. "hand" .. fg .. "3" }
        if has(dtn[1]) then
            chain({ "finger_" .. fg .. "_0_" .. cs, "finger_" .. fg .. "_1_" .. cs, "finger_" .. fg .. "_2_" .. cs }, dtn, start)
        end
    end
    local tdt = { dt .. "handthumb1", dt .. "handthumb2", dt .. "handthumb3" }
    if has(tdt[1]) then
        chain({ "finger_thumb_0_" .. cs, "finger_thumb_1_" .. cs, "finger_thumb_2_" .. cs }, tdt, { hand, pos_hand, d_hand })
    end
end

local function apply_follow(data, src)
    local unit = data.unit
    Unit.set_local_position(unit, 1, Vector3(0, 0, 0))
    Unit.set_local_rotation(unit, 1, Quaternion.identity())
    local root_p, root_r = Unit.world_position(data.parent, 1), Unit.world_rotation(data.parent, 1)
    local inv = Quaternion.inverse(root_r)
    local to_local = {
        pos = function(p)
            return Quaternion.rotate(inv, p - root_p)
        end,
        rot = function(r)
            return Quaternion.multiply(inv, r)
        end,
    }
    follow_side(data, src, to_local, "right", "R")
    follow_side(data, src, to_local, "left", "L")
end

local DT_FINGERS = { "index", "middle", "ring", "pinky", "thumb" }

local function driver_rest(driver)
    local rest = {}
    for _, name in ipairs(CFG.fp_nodes) do
        if Unit.has_node(driver, name) and not rest[name] then
            local node = Unit.node(driver, name)
            if node ~= 1 then
                local r, p = root_relative(driver, node)
                rest[name] = { node = node, r0 = QuaternionBox(r), p0 = Vector3Box(p), parent = Unit.scene_graph_parent(driver, node) }
            end
        end
    end
    return rest
end

local function side_bones(rest, name_of, s)
    local root = rest["j_" .. s .. "arm"]
    if not root then
        return nil
    end
    local list = {}
    for name, b in pairs(rest) do
        local d, n = 0, b.node
        while n and n ~= root.node and n ~= 1 and d < 64 do
            local nm = name_of[n]
            n = nm and rest[nm].parent or nil
            d = d + 1
        end
        if n == root.node then
            list[#list + 1] = { name = name, depth = d }
        end
    end
    table.sort(list, function(a, b)
        return a.depth < b.depth
    end)
    local names = {}
    for i, e in ipairs(list) do
        names[i] = e.name
    end
    return names
end

local function character_side(data, s, cs)
    data.char_status = data.char_status or {}
    data.char_status[s] = "running"
    local cu, rest, driver = data.unit, data.rest, data.driver
    local function C(name)
        local full = name .. "_" .. cs
        return Unit.has_node(cu, full) and Unit.node(cu, full) or nil
    end
    local need = { C("arm_upper"), C("arm_lower"), C("hand"), C("finger_middle_0"), C("finger_index_0"), C("finger_pinky_0") }
    for i = 1, 6 do
        if not need[i] then
            data.char_status[s] = "stop 1"
            return
        end
    end
    local cam_r, cam_p = data.cam_r, data.cam_p
    local off = data.cs2_off and data.cs2_off:unbox() or Vector3(0, 0, 0)
    local function CP(n)
        local e = data.cs2_rr and data.cs2_rr[n]
        return cam_p + Quaternion.rotate(cam_r, off + (e and e[2]:unbox() or Vector3(0, 0, 0)))
    end
    local function CR(n)
        local e = data.cs2_rr and data.cs2_rr[n]
        return Quaternion.multiply(cam_r, e and e[1]:unbox() or Quaternion.identity())
    end
    local dt = "j_" .. s
    local function P0(n)
        local b = rest[n]
        return b and b.p0:unbox()
    end
    for _, n in ipairs({ dt .. "arm", dt .. "forearm", dt .. "hand", dt .. "handmiddle1", dt .. "handindex1", dt .. "handpinky1" }) do
        if not rest[n] then
            data.char_status[s] = "stop 2"
            return
        end
    end
    local names = data.side_names[s]
    if not names then
        data.char_status[s] = "stop 3"
        return
    end
    local c_up, c_lo, c_wr = CP(need[1]), CP(need[2]), CP(need[3])
    local f = CP(need[4]) - c_wr
    local u = CP(need[5]) - CP(need[6])
    local b_up, b_lo, b_wr = P0(dt .. "arm"), P0(dt .. "forearm"), P0(dt .. "hand")
    local f0 = P0(dt .. "handmiddle1") - b_wr
    local u0 = P0(dt .. "handindex1") - P0(dt .. "handpinky1")
    local hf, hf0 = frame(f, u), frame(f0, u0)
    if not (hf and hf0) then
        data.char_status[s] = "stop 4"
        return
    end
    local delta = {}
    delta[dt .. "hand"] = Quaternion.multiply(hf, Quaternion.inverse(hf0))
    local du, dl, du0, dl0 = c_lo - c_up, c_wr - c_lo, b_lo - b_up, b_wr - b_lo
    local B = data.by_name
    local function rest_of(nm)
        local b = B[nm .. "_" .. cs]
        return b and b.p0:unbox()
    end
    local function turn_of(nm)
        local b = B[nm .. "_" .. cs]
        local e = b and data.cs2_rr and data.cs2_rr[b.node]
        return e and e[3] and e[3]:unbox()
    end
    local q_up, q_lo = turn_of("arm_upper"), turn_of("arm_lower")
    local ri, rp = rest_of("finger_index_0"), rest_of("finger_pinky_0")
    if not (q_up and q_lo and ri and rp) then
        data.char_status[s] = "stop 5"
        return
    end
    local r_u = ri - rp
    local ref_up = Quaternion.rotate(cam_r, Quaternion.rotate(q_up, r_u))
    local ref_lo = Quaternion.rotate(cam_r, Quaternion.rotate(q_lo, r_u))
    local fu, fu0, fl, fl0 = frame(du, ref_up), frame(du0, u0), frame(dl, ref_lo), frame(dl0, u0)
    if not (fu and fu0 and fl and fl0) then
        data.char_status[s] = "stop 6"
        return
    end
    delta[dt .. "arm"] = Quaternion.multiply(fu, Quaternion.inverse(fu0))
    delta[dt .. "forearm"] = Quaternion.multiply(fl, Quaternion.inverse(fl0))
    local axis = Vector3.normalize(dl)
    local x, y, z, w = Quaternion.to_elements(Quaternion.multiply(delta[dt .. "hand"], Quaternion.inverse(delta[dt .. "forearm"])))
    local tw = 2 * math.atan2(x * axis.x + y * axis.y + z * axis.z, w)
    if tw > math.pi then
        tw = tw - 2 * math.pi
    elseif tw < -math.pi then
        tw = tw + 2 * math.pi
    end
    delta[dt .. "forearmroll1"] = Quaternion.multiply(Quaternion.axis_angle(axis, tw / 3), delta[dt .. "forearm"])
    delta[dt .. "forearmroll2"] = Quaternion.multiply(Quaternion.axis_angle(axis, tw * 2 / 3), delta[dt .. "forearm"])
    local function ctip(a, b)
        local pa, pb = CP(a), CP(b)
        return pb + Quaternion.rotate(Quaternion.multiply(CR(b), Quaternion.inverse(CR(a))), pb - pa)
    end
    for _, fg in ipairs(DT_FINGERS) do
        local cn = { C("finger_" .. fg .. "_0"), C("finger_" .. fg .. "_1"), C("finger_" .. fg .. "_2") }
        for k = 1, 3 do
            local dn = dt .. "hand" .. fg .. k
            if rest[dn] and cn[k] then
                local live
                if k < 3 and cn[k + 1] then
                    live = CP(cn[k + 1]) - CP(cn[k])
                elseif k == 3 and cn[2] then
                    live = ctip(cn[2], cn[3]) - CP(cn[3])
                end
                local nxt = rest[dt .. "hand" .. fg .. (k + 1)]
                local prv = rest[dt .. "hand" .. fg .. (k - 1)]
                local bind = nxt and (nxt.p0:unbox() - P0(dn)) or (prv and (P0(dn) - prv.p0:unbox()))
                local ref, ref0 = u, u0
                if fg == "thumb" then
                    ref, ref0 = Vector3.cross(f, u), Vector3.cross(f0, u0)
                end
                local fr, fr0 = live and frame(live, ref), bind and frame(bind, ref0)
                if fr and fr0 then
                    delta[dn] = Quaternion.multiply(fr, Quaternion.inverse(fr0))
                end
            end
        end
    end
    -- The Darktide index finger is shorter and thicker than CS2's: bent the CS2 way, its tip went into the gun's frame
    -- (user report 2026-11-08 22:10; top-view render tp\render_fingers_ext.py: tip about 1 cm inside the frame). It is
    -- straightened a little (about the knuckle axis) so it lies along the side of the frame. Setting index_lift, degrees.
    local lift = s == "right" and tonumber(opt("index_lift", 12)) or 0
    if lift ~= 0 then
        local turn = Quaternion.axis_angle(Vector3.normalize(u), -math.rad(lift))
        for k = 1, 3 do
            local dn = dt .. "handindex" .. k
            if delta[dn] then
                delta[dn] = Quaternion.multiply(turn, delta[dn])
            end
        end
    end
    local target = {}
    local lo_d, up_d = delta[dt .. "forearm"], delta[dt .. "arm"]
    local pos_hand = c_wr
    local pos_lo = pos_hand - Quaternion.rotate(lo_d, b_wr - b_lo)
    local pos_up = pos_lo - Quaternion.rotate(up_d, b_lo - b_up)
    local anchor = { [dt .. "arm"] = pos_up, [dt .. "forearm"] = pos_lo, [dt .. "hand"] = pos_hand }
    local name_of = data.name_of
    for _, name in ipairs(names) do
        local b = rest[name]
        local pname = name_of[b.parent]
        local pt = pname and target[pname]
        local d = delta[name] or (pt and pt.d) or up_d
        local p = anchor[name]
        if not p then
            if pt then
                p = pt.p + Quaternion.rotate(pt.d, b.p0:unbox() - rest[pname].p0:unbox())
            else
                p = b.p0:unbox()
            end
        end
        target[name] = { d = d, p = p, r = Quaternion.multiply(d, b.r0:unbox()) }
    end
    for _, name in ipairs(names) do
        local b, tg = rest[name], target[name]
        local pname = name_of[b.parent]
        local pr, pp
        if pname and target[pname] then
            pr, pp = target[pname].r, target[pname].p
        elseif b.parent and b.parent ~= 1 then
            pr, pp = root_relative(driver, b.parent)
        else
            pr, pp = Quaternion.identity(), Vector3(0, 0, 0)
        end
        local inv = Quaternion.inverse(pr)
        Unit.set_local_rotation(driver, b.node, Quaternion.multiply(inv, tg.r))
        Unit.set_local_position(driver, b.node, Quaternion.rotate(inv, tg.p - pp))
    end
    data.char_status[s] = "ok"
end

local function relink(world, unit, parent)
    World.unlink_unit(world, unit)
    World.link_unit(world, unit, 1, parent, 1, World.LINK_MODE_NODE_NAME)
end

local function character_start(data, world, fp_unit)
    local spawner = Managers.state and Managers.state.unit_spawner
    if not spawner then
        return false
    end
    local driver = spawner:spawn_unit(CFG.unit_path(CFG.driver_key), Unit.world_pose(fp_unit, 1))
    if not driver then
        return false
    end
    local ok, fpd = pcall(CFG.fingers.driver, driver, fp_unit, CFG.finger_nodes)
    if not ok or not fpd then
        spawner:mark_for_deletion(driver)
        return false
    end
    World.link_unit(world, driver, 1, fp_unit, 1)
    data.driver, data.fpd, data.rest = driver, fpd, driver_rest(driver)
    data.name_of = {}
    for name, b in pairs(data.rest) do
        data.name_of[b.node] = name
    end
    data.side_names = { right = side_bones(data.rest, data.name_of, "right"), left = side_bones(data.rest, data.name_of, "left") }
    data.linked = {}
    return true
end

-- The Darktide 1p arm units are shared by every QIangIQ mod that runs CS2 arms. Whoever linked a unit last owns it:
-- a mod that stops (e.g. the pistol you just put away) only hands back units it still owns, and the active mod
-- takes a unit back if anyone else moved it.
local ARM_OWNER = rawget(_G, "__qiangiq_cs2_arm_owner")
if type(ARM_OWNER) ~= "table" then
    ARM_OWNER = {}
    rawset(_G, "__qiangiq_cs2_arm_owner", ARM_OWNER)
end

local function character_relink(data, ext, world)
    local now = {}
    for _, u in ipairs(CFG.arm_units(ext)) do
        now[u] = true
        if not data.linked[u] or ARM_OWNER[u] ~= data.driver then
            relink(world, u, data.driver)
            data.linked[u] = true
            ARM_OWNER[u] = data.driver
        end
    end
    for u in pairs(data.linked) do
        if not now[u] or not unit_ok(u) then
            data.linked[u] = nil
            if ARM_OWNER[u] == data.driver then
                ARM_OWNER[u] = nil
            end
        end
    end
end

local function character_stop(data, world)
    if data.linked and unit_ok(data.parent) then
        for u in pairs(data.linked) do
            if unit_ok(u) and ARM_OWNER[u] == data.driver then
                relink(world, u, data.parent)
                ARM_OWNER[u] = nil
            end
        end
    end
    data.linked = nil
    destroy(world, data.driver)
end

local function apply_character(data, ext, world)
    character_relink(data, ext, world)
    CFG.fingers.update(world, data.fpd, nil, 0)
    local fp_unit = data.parent
    if not (data.cs2_rr and Unit.has_node(fp_unit, "ap_camera_node")) then
        data.char_status = { right = "no cs2 pose", left = "no cs2 pose" }
        return
    end
    data.cam_r, data.cam_p = root_relative(fp_unit, Unit.node(fp_unit, "ap_camera_node"))
    character_side(data, "right", "R")
    character_side(data, "left", "L")
    World.update_unit_and_children(world, data.driver)
end



local function sleeves()
    local s = CFG.opt("cs2_sleeves")
    if s == "t" or s == "character" then
        return s
    end
    return "ct"
end

function Arms.mode(rec)
    local m = CFG.opt("cs2_arms")
    if m ~= "viewmodel" and m ~= "follow" then
        return nil
    end
    if not (rec and rec.shown and rec.first_person) then
        return nil
    end
    local s = sleeves()
    if s == "character" then
        if m == "follow" or not (CFG.loaded("cs2_arms_ct") and CFG.loaded(CFG.driver_key)) then
            return nil
        end
        return m
    end
    if not CFG.loaded("cs2_arms_" .. s) then
        return nil
    end
    return m
end

local function set_arms_visible(ext, visible)
    for _, u in ipairs(CFG.arm_units(ext)) do
        Unit.set_unit_visibility(u, visible, true)
    end
end

function Arms.stop(ext, world)
    local data = ext[CFG.field]
    if not data then
        return
    end
    ext[CFG.field] = nil
    if data.driver then
        character_stop(data, world)
    end
    destroy(world, data.gun and data.gun.unit)
    destroy(world, data.unit)
    if unit_ok(ext._unit) and ext.force_update_item_visibility then
        pcall(ext.force_update_item_visibility, ext)
    end
end

function Arms.debug(ext)
    local data = ext[CFG.field]
    if not data then
        return "CS2 arms: not active"
    end
    local st = data.st or {}
    local linked = 0
    for _ in pairs(data.linked or {}) do
        linked = linked + 1
    end
    local cs = data.char_status or {}
    return string.format("CS2 arms: %s, sleeves %s, clip %s at %.2f s, action %s, shots %s, gun parts %d, character arms linked %d, right %s, left %s, arm units %d",
        data.mode, data.side, tostring(st.clip), st.t or 0, tostring(st.action_key), tostring(st.shots), data.gun and #data.gun.parts or 0,
        linked, tostring(cs.right), tostring(cs.left), #CFG.arm_units(ext))
end

function Arms.update(ext, rec, mode, world, dt)
    local data = ext[CFG.field]
    local side = sleeves()
    local fpe = mode and unit_ok(ext._unit) and ScriptUnit.has_extension(ext._unit, "first_person_system")
    local fp_unit = fpe and fpe:first_person_unit()
    if mode and not (fpe and fpe:is_in_first_person_mode() and unit_ok(fp_unit) and Unit.has_node(fp_unit, "ap_camera_node")) then
        mode = nil
    end
    if data and (data.mode ~= mode or data.side ~= side or not unit_ok(data.unit) or data.parent ~= fp_unit
        or (data.driver and not unit_ok(data.driver))) then
        Arms.stop(ext, world)
        data = nil
    end
    if not mode then
        return
    end
    if not data then
        local parent_node = mode == "viewmodel" and Unit.node(fp_unit, "ap_camera_node") or 1
        local unit = spawn(world, CFG.unit_path(side == "character" and "cs2_arms_ct" or "cs2_arms_" .. side), fp_unit, parent_node, mode == "viewmodel")
        if not unit then
            return
        end
        local bones, by_name = capture(unit, CFG.data.bones)
        data = { unit = unit, mode = mode, side = side, parent = fp_unit, bones = bones, by_name = by_name, st = {} }
        ext[CFG.field] = data
        if mode == "viewmodel" and CFG.loaded(CFG.gun_key) then
            local gun = spawn(world, CFG.unit_path(CFG.gun_key), unit, 1, true)
            if gun then
                local parts = capture(gun, CFG.part_nodes)
                data.gun = { unit = gun, parts = parts }
            end
        end
        if side == "character" and not character_start(data, world, fp_unit) then
            Arms.stop(ext, world)
            return
        end
    end
    local character = side == "character"
    local aiming = mode == "viewmodel" and opt("hide_when_aiming", true) and CFG.aiming(ext._unit)
    if character then
        if aiming then
            set_arms_visible(ext, false)
            data.hid_for_aim = true
        elseif data.hid_for_aim then
            data.hid_for_aim = nil
            if ext.force_update_item_visibility then
                pcall(ext.force_update_item_visibility, ext)
            end
        end
        Unit.set_unit_visibility(data.unit, false, true)
    else
        set_arms_visible(ext, false)
        Unit.set_unit_visibility(data.unit, not aiming, true)
    end
    if data.gun and unit_ok(data.gun.unit) then
        Unit.set_unit_visibility(data.gun.unit, not aiming, true)
    end
    if mode == "viewmodel" then
        if unit_ok(rec.sword) then
            Unit.set_unit_visibility(rec.sword, false, true)
        end
        local pose = viewmodel_step(data.st, CFG.action(ext._unit), CFG.shots(), dt)
        if CFG.on_clip then
            CFG.on_clip(data.st.clip, data.st.t)
        end
        if pose then
            apply_viewmodel(data, pose)
        end
    else
        apply_follow(data, fp_unit)
    end
    World.update_unit_and_children(world, data.unit)
    if character then
        apply_character(data, ext, world)
    end
end

return Arms
