local mod = get_mod("QIangIQsDeagle")

local SYNC_KEY = "deagle"
local SYNC_BOOLS = { "replace_phosphor", "replace_revolver", "flip_model", "replace_boltpistol" }
local SYNC_DEFAULTS = { replace_phosphor = true, replace_revolver = true, flip_model = false, replace_boltpistol = true }
local SYNC_VALUES = { "model_size", "model_roll", "model_slide", "model_tilt" }
local SYNC_LAYOUT = 310 + #SYNC_VALUES
local sync_ctx = nil
local sync_known = setmetatable({}, { __mode = "k" })
local sync_all = setmetatable({}, { __mode = "k" })
local sync_decoded = setmetatable({}, { __mode = "k" })
local SYNC_FALSE = { __index = function() return false end }
local SYNC_OFF = setmetatable({}, SYNC_FALSE)

local function opt(key)
    if sync_ctx then
        return sync_ctx[key]
    end
    return mod:get(key)
end

local function sync_api()
    local hub = get_mod("QIangIQsModelSync")
    return hub and hub.api
end

local function sync_me()
    local players = Managers.player
    if not players then
        return nil
    end
    local ok, player = pcall(players.local_player_safe, players, 1)
    return ok and player or nil
end

local function sync_decode(raw)
    local t = sync_decoded[raw]
    if t ~= nil then
        return t
    end
    t = false
    if type(raw) == "table" and raw[1] == SYNC_LAYOUT then
        t = setmetatable({}, SYNC_FALSE)
        local mask = tonumber(raw[2]) or 0
        for i = 1, #SYNC_BOOLS do
            t[SYNC_BOOLS[i]] = mask % 2 >= 1
            mask = math.floor(mask / 2)
        end
        for i = 1, #SYNC_VALUES do
            local v = raw[2 + i]
            if v ~= nil then
                t[SYNC_VALUES[i]] = v
            end
        end
    end
    sync_decoded[raw] = t
    return t
end

local function sync_owner(ext)
    sync_all[ext] = true
    local player = ext._player
    if player == nil or player == sync_me() then
        return nil
    end
    local api = sync_api()
    local raw = api and api.peer(SYNC_KEY, player)
    local state = raw and sync_decode(raw)
    if state then
        sync_known[ext] = true
        return state
    end
    return SYNC_OFF
end

local function sync_shown(ext)
    local player = ext._player
    return player ~= nil and (player == sync_me() or sync_known[ext] == true)
end

local function sync_pack(...)
    return { n = select("#", ...), ... }
end

local function sync_wrap(fn, ext_index)
    return function(...)
        local ext = select(ext_index, ...)
        local previous = sync_ctx
        sync_ctx = sync_owner(ext)
        local results = sync_pack(pcall(fn, ...))
        sync_ctx = previous
        if not results[1] then
            error(results[2], 0)
        end
        return unpack(results, 2, results.n)
    end
end

local SYNC_HUSK_METHODS = { init = true, update = true, _update_item_visibility = true, destroy = true }

local function vl_hook_safe(method, fn)
    mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, method, sync_wrap(fn, 1))
    if SYNC_HUSK_METHODS[method] then
        mod:hook_safe(CLASS.PlayerHuskVisualLoadoutExtension, method, sync_wrap(fn, 1))
    end
end

local function vl_hook(method, fn)
    mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, method, sync_wrap(fn, 2))
    if SYNC_HUSK_METHODS[method] then
        mod:hook(CLASS.PlayerHuskVisualLoadoutExtension, method, sync_wrap(fn, 2))
    elseif method == "_unequip_item_from_slot" then
        mod:hook(CLASS.PlayerHuskVisualLoadoutExtension, "rpc_player_unequip_item_from_slot", sync_wrap(function(func, self, channel_id, go_id, slot_id, ...)
            local NetworkLookup = require("scripts/network_lookup/network_lookup")
            local slot_name = NetworkLookup.player_inventory_slot_names[slot_id]
            return fn(function()
                return func(self, channel_id, go_id, slot_id)
            end, self, slot_name)
        end, 2))
    end
end

mod.AUTHOR = "QIangIQ"

local WeaponTemplate = require("scripts/utilities/weapon/weapon_template")

local TEMPLATES = {
    phosphor_pistol_p1_m1 = "replace_phosphor",
    stubrevolver_p1_m1 = "replace_revolver",
    stubrevolver_p1_m2 = "replace_revolver",
    boltpistol_p1_m1 = "replace_boltpistol",
    boltpistol_p1_m2 = "replace_boltpistol",
}

local GUN_KEY = "deagle_printstream"
local SCOPE_KEY = "awp_scope"
local SCOPE_DISTANCE = 0.06
local SCOPE_FOV = { math.rad(30.75), math.rad(7.5) }
local SCOPE_TEMPLATES = {}
local scope_level = 1
local GUN_LENGTH = 0.252
local PART_NODES = { "dg_slide", "dg_clip", "dg_hammer", "dg_trigger" }

local function asset_id(key)
    return "QIangIQsDeagle:" .. key
end

local function unit_path(key)
    return "content/mods/qiangiq_deagle/" .. key
end

local loaded = {}
local FIT_FRAMES = 10
local fit_generation = 0
local custom_assets = nil
local mod_on = true
local session_off = false
local shots = 0

local tracked = setmetatable({}, { __mode = "k" })
local tracked_ui = setmetatable({}, { __mode = "k" })
local tracked_wpn = setmetatable({}, { __mode = "k" })

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function wants_item(item)
    local key = item and item.weapon_template and TEMPLATES[item.weapon_template]
    if not (mod_on and key) then
        return false
    end
    if session_off and not sync_ctx then
        return false
    end
    if not opt(key) then
        return false
    end
    return loaded[GUN_KEY] == true
end

local function fmt(v)
    return string.format("(%.3f, %.3f, %.3f)", v.x, v.y, v.z)
end

local last_fit = {}

local function weapon_parts(base, attachments)
    local parts = {}
    local function add(unit)
        if unit_ok(unit) then
            local pose, ext = Unit.box(unit)
            if pose and ext then
                local half = math.max(ext.x, ext.y, ext.z)
                if half > 0.005 then
                    parts[#parts + 1] = { center = Matrix4x4.translation(pose), half = half }
                end
            end
        end
    end
    add(base)
    if attachments then
        for i = 1, #attachments do
            add(attachments[i])
        end
    end
    return parts
end

local function fit(gun, base, attachments, parent_scale, view)
    local parts = weapon_parts(base, attachments)
    if #parts == 0 then
        return false
    end
    local origin = Unit.world_position(base, 1)
    local far_d, far_c = 0, nil
    for i = 1, #parts do
        local d = Vector3.length_squared(parts[i].center - origin)
        if d > far_d then
            far_d, far_c = d, parts[i].center
        end
    end
    if not far_c or far_d < 0.0001 then
        return false
    end
    local dir = Vector3.normalize(far_c - origin)
    local source = "hand->farthest piece"
    local base_rot = Unit.world_rotation(base, 1)
    local base_axes = { Quaternion.right(base_rot), Quaternion.forward(base_rot), Quaternion.up(base_rot) }
    local best, best_axis = 0, nil
    for i = 1, 3 do
        local d = Vector3.dot(base_axes[i], dir)
        if math.abs(d) > best then
            best = math.abs(d)
            best_axis = d < 0 and -base_axes[i] or base_axes[i]
        end
    end
    if best_axis and best > 0.97 then
        dir = best_axis
        source = string.format("base unit axis (%.2f to hand->farthest)", best)
    end
    local reach = 0
    for i = 1, #parts do
        reach = math.max(reach, Vector3.dot(parts[i].center - origin, dir) + parts[i].half)
    end
    if reach <= 0 then
        return false
    end
    if opt("flip_model") then
        dir = -dir
    end
    local s_world = reach * (opt("model_size") or 1)
    local grip = origin + dir * (reach * (opt("model_slide") or 0))
    local ref = base_axes[3]
    if math.abs(Vector3.dot(ref, dir)) > 0.9 then
        ref = base_axes[1]
    end
    local up = Vector3.normalize(ref - dir * Vector3.dot(ref, dir))
    local roll = math.rad(opt("model_roll") or 0)
    if roll ~= 0 then
        local side = Vector3.cross(dir, up)
        up = up * math.cos(roll) + side * math.sin(roll)
    end
    local tilt = math.rad(opt("model_tilt") or 0)
    if tilt ~= 0 then
        local d2 = dir * math.cos(tilt) + up * math.sin(tilt)
        up = Vector3.normalize(up * math.cos(tilt) - dir * math.sin(tilt))
        dir = Vector3.normalize(d2)
    end
    local bx, by, bz = base_axes[1], base_axes[2], base_axes[3]
    local function to_local(v)
        return Vector3(Vector3.dot(v, bx), Vector3.dot(v, by), Vector3.dot(v, bz))
    end
    local k = parent_scale and parent_scale > 0 and parent_scale or 1
    local s = s_world / (GUN_LENGTH * k)
    local local_pos = to_local(grip - origin) * (1 / k)
    local local_dir = to_local(dir)
    Unit.set_local_position(gun, 1, local_pos)
    Unit.set_local_rotation(gun, 1, Quaternion.look(local_dir, to_local(up)))
    Unit.set_local_scale(gun, 1, Vector3(s, s, s))
    if view then
        last_fit[view] = string.format("%s: %d pieces, dir by %s, reach %.3f, local grip %s, local dir %s",
            view, #parts, source, reach, fmt(local_pos), fmt(local_dir))
    end
    return true
end

local function hide_originals(base, attachments)
    Unit.set_unit_visibility(base, false, true)
    if attachments then
        for i = 1, #attachments do
            if unit_ok(attachments[i]) then
                Unit.set_unit_visibility(attachments[i], false, true)
            end
        end
    end
end

local function now()
    local time = Managers.time
    local ok, t = pcall(time.time, time, "main")
    return ok and t or 0
end

local function read_comp(ude, name)
    local ok, comp = pcall(ude.read_component, ude, name)
    return ok and comp or nil
end

local function local_player()
    local players = Managers.player
    if not players then
        return nil
    end
    local ok, player = pcall(players.local_player_safe, players, 1)
    return ok and player or nil
end

local function arm_units(ext)
    local found = {}
    if not ext then
        return found
    end
    for key, value in pairs(ext) do
        if type(key) == "string" then
            if string.find(key, "^__qiangiq_.+_arms$") and not string.find(key, "_part_arms$") then
                if unit_ok(value) then
                    found[#found + 1] = value
                end
            elseif string.find(key, "^__qiangiq_.+_part_arms$") and type(value) == "table" then
                for _, part in pairs(value) do
                    if unit_ok(part) then
                        found[#found + 1] = part
                    end
                end
            end
        end
    end
    if ext._equipment then
        for slot_name, slot in pairs(ext._equipment) do
            if type(slot_name) == "string" and (string.find(slot_name, "^slot_body") or string.find(slot_name, "^slot_gear")) and unit_ok(slot.unit_1p) then
                found[#found + 1] = slot.unit_1p
            end
        end
    end
    return found
end

local function ammo_of(inv)
    if not inv then
        return nil, nil
    end
    local ok, c, m = pcall(function()
        return inv.current_ammunition_clip, inv.max_ammunition_clip
    end)
    if not ok then
        return nil, nil
    end
    if type(c) == "number" then
        return c, m
    end
    local sum, max_sum, any = 0, 0, false
    for i = 1, 4 do
        local ok_i, v = pcall(function()
            return c[i]
        end)
        if not ok_i or type(v) ~= "number" then
            break
        end
        any = true
        sum = sum + v
        local ok_m, w = pcall(function()
            return m and m[i]
        end)
        if ok_m and type(w) == "number" then
            max_sum = max_sum + w
        end
    end
    if not any then
        return nil, nil
    end
    return sum, max_sum
end

local CS2Audio = mod:io_dofile("QIangIQsDeagle/scripts/mods/QIangIQsDeagle/QIangIQsDeagle_cs2audio")
CS2Audio.setup({
    data = mod:io_dofile("QIangIQsDeagle/scripts/mods/QIangIQsDeagle/QIangIQsDeagle_cs2sounds"),
    mod_name = "QIangIQsDeagle",
    now = now,
    opt = function(key)
        return mod:get(key)
    end,
})

local Fingers = mod:io_dofile("QIangIQsDeagle/scripts/mods/QIangIQsDeagle/QIangIQsDeagle_fingers")
local FP_NODES = mod:io_dofile("QIangIQsDeagle/scripts/mods/QIangIQsDeagle/QIangIQsDeagle_fp_nodes")
Fingers.setup(FP_NODES)
local DRIVER_KEY = "dg_fp_driver"
local TP_KEY = "dg_tp_driver"
local FINGER_NODES = { "j_righthandindex1", "j_righthandindex2", "j_righthandindex3", "j_righthandmiddle1", "j_righthandmiddle2",
    "j_righthandmiddle3", "j_righthandring1", "j_righthandring2", "j_righthandring3", "j_righthandpinky1", "j_righthandpinky2",
    "j_righthandpinky3", "j_righthandthumb1", "j_righthandthumb2", "j_righthandthumb3" }
local CS2Arms = mod:io_dofile("QIangIQsDeagle/scripts/mods/QIangIQsDeagle/QIangIQsDeagle_cs2arms")
local CS2_CFG = {
    data = mod:io_dofile("QIangIQsDeagle/scripts/mods/QIangIQsDeagle/QIangIQsDeagle_cs2arms_data"),
    field = "__qiangiq_deagle_cs2arms",
    gun_key = GUN_KEY,
    part_nodes = PART_NODES,
    unit_path = unit_path,
    opt = function(key)
        return mod:get(key)
    end,
    loaded = function(key)
        return loaded[key] == true
    end,
    arm_units = arm_units,
    fingers = Fingers,
    driver_key = DRIVER_KEY,
    finger_nodes = FINGER_NODES,
    fp_nodes = FP_NODES,
    on_clip = function(clip, t)
        CS2Audio.tick("viewmodel", clip, t)
    end,
    shots = function()
        return shots
    end,
    aiming = function(holder_unit)
        local ude = unit_ok(holder_unit) and ScriptUnit.has_extension(holder_unit, "unit_data_system")
        local af = ude and read_comp(ude, "alternate_fire")
        return af and af.is_active and true or false
    end,
    action = function(holder_unit)
        local ude = unit_ok(holder_unit) and ScriptUnit.has_extension(holder_unit, "unit_data_system")
        local wa = ude and read_comp(ude, "weapon_action")
        if not wa then
            return {}
        end
        local name = wa.current_action_name
        local total = nil
        local ok, template = pcall(WeaponTemplate.current_weapon_template, wa)
        if ok and template and template.actions and name and template.actions[name] then
            total = template.actions[name].total_time
        end
        local inv = read_comp(ude, "slot_secondary")
        local clip, max_clip = ammo_of(inv)
        if ok and template and template.actions and name then
            local a = template.actions[name]
            local loop = template.actions.action_reload_loop
            if a and a.kind == "reload_state" and template.reload_template then
                local rt = template.reload_template
                local ok_st, state_name = pcall(function()
                    return inv and inv.reload_state
                end)
                local st = (ok_st and state_name and rt[state_name]) or (rt.states and rt[rt.states[1]])
                if st and type(st.time) == "number" then
                    total = st.time
                end
            elseif name == "action_start_reload" and loop and a and a.total_time and clip and max_clip then
                total = a.total_time + math.max(1, max_clip - clip) * (loop.total_time or 0)
            end
        end
        local ok_ts, ts = pcall(function()
            return wa.time_scale
        end)
        if total and ok_ts and type(ts) == "number" and ts > 0 then
            total = total / ts
        end
        return { name = name, start_t = wa.start_t, total_time = total, empty = clip == 0,
            reload_continue = name == "action_reload_loop" }
    end,
}
CS2Arms.setup(CS2_CFG)

local hide_1p_gun = false

local function holder_template(holder_unit)
    local ude = unit_ok(holder_unit) and ScriptUnit.has_extension(holder_unit, "unit_data_system")
    local wa = ude and read_comp(ude, "weapon_action")
    return wa and wa.template_name
end

local function scope_allowed(template)
    if not (mod_on and not session_off and template and loaded[GUN_KEY]) then
        return false
    end
    local setting = SCOPE_TEMPLATES[template] or (mod:get("scope_plasma") and TEMPLATES[template] and string.find(template, "^plasmagun") and TEMPLATES[template])
    return setting and mod:get(setting) and true or false
end

local function scoped(holder_unit)
    local ude = unit_ok(holder_unit) and ScriptUnit.has_extension(holder_unit, "unit_data_system")
    local af = ude and read_comp(ude, "alternate_fire")
    return af and af.is_active and scope_allowed(holder_template(holder_unit)) or false
end

local AlternateFire = require("scripts/utilities/alternate_fire")
mod:hook(AlternateFire, "camera_variables", function(func, weapon_template, camera_follow_unit, ...)
    local vertical_fov, custom_vertical_fov, near_range = func(weapon_template, camera_follow_unit, ...)
    if vertical_fov and mod:get("scope_cs2_zoom") ~= false then
        local me = local_player()
        if me and camera_follow_unit and camera_follow_unit == me.player_unit and scope_allowed(holder_template(camera_follow_unit)) then
            vertical_fov = SCOPE_FOV[scope_level] or SCOPE_FOV[1]
        end
    end
    return vertical_fov, custom_vertical_fov, near_range
end)

mod.scope_zoom = function()
    local me = local_player()
    if me and scoped(me.player_unit) then
        scope_level = scope_level == 1 and 2 or 1
        CS2Audio.fire("Weapon_AWP.Zoom")
    end
end

local function scope_update(ext, world)
    local me = local_player()
    local on = mod:get("scope_overlay") ~= false and me and ext._unit == me.player_unit and scoped(ext._unit)
    local fpe = unit_ok(ext._unit) and ScriptUnit.has_extension(ext._unit, "first_person_system")
    local fp_unit = fpe and fpe:first_person_unit()
    local first = fpe and fpe:is_in_first_person_mode() and unit_ok(fp_unit) and Unit.has_node(fp_unit, "ap_camera_node")
    local data = ext.__qiangiq_deagle_scope
    if not (on and first) then
        if data then
            ext.__qiangiq_deagle_scope = nil
            if unit_ok(data.unit) then
                World.unlink_unit(world, data.unit)
                local spawner = Managers.state and Managers.state.unit_spawner
                if spawner then
                    spawner:mark_for_deletion(data.unit)
                end
            end
            if unit_ok(ext._unit) and ext.force_update_item_visibility then
                pcall(ext.force_update_item_visibility, ext)
            end
        end
        if not (me and ext._unit == me.player_unit and scoped(ext._unit)) then
            scope_level = 1
        end
        return
    end
    if data and (data.parent ~= fp_unit or not unit_ok(data.unit)) then
        ext.__qiangiq_deagle_scope = nil
        data = nil
    end
    if not data then
        if not loaded[SCOPE_KEY] then
            return
        end
        local spawner = Managers.state and Managers.state.unit_spawner
        local node = Unit.node(fp_unit, "ap_camera_node")
        local unit = spawner and spawner:spawn_unit(unit_path(SCOPE_KEY), Unit.world_pose(fp_unit, node))
        if not unit then
            return
        end
        Unit.set_unit_culling(unit, false)
        World.link_unit(world, unit, 1, fp_unit, node)
        data = { unit = unit, parent = fp_unit }
        ext.__qiangiq_deagle_scope = data
        CS2Audio.fire("Weapon_AWP.Zoom")
    end
    local fov = SCOPE_FOV[scope_level] or SCOPE_FOV[1]
    local camera = Managers.state and Managers.state.camera
    if camera and me.viewport_name then
        local ok, v = pcall(camera.fov, camera, me.viewport_name)
        if ok and type(v) == "number" and v > 0.01 then
            fov = v
        end
    end
    local r = SCOPE_DISTANCE * math.tan(fov * 0.5)
    Unit.set_local_position(data.unit, 1, Vector3(0, 0, 0))
    Unit.set_local_rotation(data.unit, 1, Quaternion.identity())
    Unit.set_local_scale(data.unit, 1, Vector3(r, SCOPE_DISTANCE, r))
    Unit.set_unit_visibility(data.unit, true, true)
    for _, u in ipairs(arm_units(ext)) do
        Unit.set_unit_visibility(u, false, true)
    end
    for key, rec in pairs(ext.__qiangiq_deagle_records or {}) do
        if rec.first_person and unit_ok(rec.sword) then
            Unit.set_unit_visibility(rec.sword, false, true)
        end
    end
end

local function sync_record(records, key, base, attachments, item, visible, spawn_fn, destroy_fn, parent_scale, first_person)
    local rec = records[key]
    local want = unit_ok(base) and wants_item(item) and attachments ~= nil
    if rec and (not want or rec.base ~= base or not unit_ok(rec.sword)) then
        destroy_fn(rec.sword)
        records[key] = nil
        if rec.hid and rec.base == base and unit_ok(base) and visible then
            Unit.set_unit_visibility(base, true, true)
        end
        rec = nil
    end
    if not want then
        return false
    end
    if not rec then
        local gun = spawn_fn(base, unit_path(GUN_KEY))
        if not gun then
            return false
        end
        if first_person then
            Unit.set_shader_pass_flag_for_meshes_in_unit_and_childs(gun, "custom_fov", true)
        end
        rec = { sword = gun, base = base, frames = 0, count = -1, fitted = false, first_person = first_person }
        records[key] = rec
    end
    if rec.count ~= #attachments or rec.gen ~= fit_generation then
        rec.gen = fit_generation
        rec.count = #attachments
        rec.frames = 0
    end
    if rec.frames < FIT_FRAMES then
        rec.frames = rec.frames + 1
        local base_scale = Unit.local_scale(base, 1)
        local k = (parent_scale or 1) * (base_scale and base_scale.x or 1)
        rec.fitted = fit(rec.sword, base, attachments, k, key) or rec.fitted
    end
    rec.shown = (rec.fitted and visible) and true or false
    if rec.fitted and visible then
        hide_originals(base, attachments)
        rec.hid = true
        Unit.set_unit_visibility(rec.sword, not (first_person and hide_1p_gun), true)
    else
        Unit.set_unit_visibility(rec.sword, false, true)
    end
    return true
end

local function clear_records(records, destroy_fn)
    if not records then
        return
    end
    for key, rec in pairs(records) do
        destroy_fn(rec.sword)
        records[key] = nil
    end
end

local function ingame_spawn(ext, is_first_person)
    return function(parent, path)
        local world = ext.__qiangiq_deagle_world
        local unit_spawner = Managers.state and Managers.state.unit_spawner
        if not (world and unit_spawner) then
            return nil
        end
        local unit = unit_spawner:spawn_unit(path, Unit.world_pose(parent, 1))
        if not unit then
            return nil
        end
        if is_first_person then
            Unit.set_unit_culling(unit, false)
        end
        World.link_unit(world, unit, 1, parent, 1, World.LINK_MODE_NODE_NAME)
        return unit
    end
end

local function ingame_destroy(unit)
    if unit_ok(unit) then
        local unit_spawner = Managers.state and Managers.state.unit_spawner
        if unit_spawner then
            unit_spawner:mark_for_deletion(unit)
        end
    end
end

local function ingame_apply(ext)
    local records = ext.__qiangiq_deagle_records
    if not records then
        records = {}
        ext.__qiangiq_deagle_records = records
    end
    local equipment = ext._equipment
    if not equipment then
        return
    end
    local fp_rec = nil
    hide_1p_gun = not sync_ctx and ext.__qiangiq_deagle_arms_vm == true
    for slot_name, slot in pairs(equipment) do
        local item = slot.item
        if item and TEMPLATES[item.weapon_template] or records[slot_name .. ":3p"] or records[slot_name .. ":1p"] then
            local base_3p, base_1p = slot.unit_3p, slot.unit_1p
            local att_3p = base_3p and slot.attachments_by_unit_3p and slot.attachments_by_unit_3p[base_3p]
            local att_1p = base_1p and slot.attachments_by_unit_1p and slot.attachments_by_unit_1p[base_1p]
            sync_record(records, slot_name .. ":3p", base_3p, att_3p, item, slot.hidden_3p == false,
                ingame_spawn(ext, false), ingame_destroy, 1, false)
            sync_record(records, slot_name .. ":1p", base_1p, att_1p, item, slot.hidden_1p == false,
                ingame_spawn(ext, true), ingame_destroy, 1, true)
            local r = records[slot_name .. ":1p"]
            if r and r.shown then
                fp_rec = r
            end
        end
    end
    hide_1p_gun = false
    if sync_ctx then
        return
    end
    local arms_mode = CS2Arms.mode(fp_rec)
    ext.__qiangiq_deagle_arms_vm = arms_mode == "viewmodel"
    local t = now()
    local dt = ext.__qiangiq_deagle_arms_t and math.min(0.1, math.max(0, t - ext.__qiangiq_deagle_arms_t)) or 0
    ext.__qiangiq_deagle_arms_t = t
    local ok, err = pcall(CS2Arms.update, ext, fp_rec, arms_mode, ext.__qiangiq_deagle_world, dt)
    if not ok then
        mod:error("Deagle: CS2 arms stopped: %s", tostring(err))
        pcall(CS2Arms.stop, ext, ext.__qiangiq_deagle_world)
        mod:set("cs2_arms", "off", false)
    end
    if arms_mode ~= "viewmodel" then
        CS2Audio.tick("viewmodel", nil, 0)
    end
    local sok, serr = pcall(scope_update, ext, ext.__qiangiq_deagle_world)
    if not sok then
        mod:error("Deagle: scope stopped: %s", tostring(serr))
        mod:set("scope_overlay", false, false)
    end
end

vl_hook_safe("init", function(self, extension_init_context)
    self.__qiangiq_deagle_world = extension_init_context and extension_init_context.world
end)

vl_hook_safe("_update_item_visibility", function(self)
    if not sync_shown(self) then
        return
    end
    tracked[self] = true
    ingame_apply(self)
end)

vl_hook_safe("update", function(self)
    if tracked[self] then
        ingame_apply(self)
    end
end)

vl_hook("_unequip_item_from_slot", function(func, self, slot_name, ...)
    local records = self.__qiangiq_deagle_records
    if records then
        for _, view in ipairs({ ":3p", ":1p" }) do
            local rec = records[slot_name .. view]
            if rec then
                ingame_destroy(rec.sword)
                records[slot_name .. view] = nil
            end
        end
    end
    return func(self, slot_name, ...)
end)

local function scope_stop(ext)
    local data = ext.__qiangiq_deagle_scope
    ext.__qiangiq_deagle_scope = nil
    if data and unit_ok(data.unit) then
        local spawner = Managers.state and Managers.state.unit_spawner
        if spawner then
            spawner:mark_for_deletion(data.unit)
        end
    end
end

vl_hook("destroy", function(func, self, ...)
    scope_stop(self)
    pcall(CS2Arms.stop, self, self.__qiangiq_deagle_world)
    clear_records(self.__qiangiq_deagle_records, ingame_destroy)
    tracked[self] = nil
    return func(self, ...)
end)

mod:hook("ActionShootHitScan", "_play_shoot_sound", function(func, self, fire_config)
    local me = local_player()
    local unit = self._player_unit
    if mod_on and not session_off and me and unit and unit == me.player_unit and self._action_component
        and self._action_component.fire_state == "start_shooting" then
        local ude = ScriptUnit.has_extension(unit, "unit_data_system")
        local wa = ude and read_comp(ude, "weapon_action")
        local setting = wa and TEMPLATES[wa.template_name]
        if setting and mod:get(setting) and loaded[GUN_KEY] then
            shots = shots + 1
            CS2Audio.fire("Weapon_DEagle.Single")
            if mod:get("cs2_sounds") ~= false and mod:get("mute_game_shot") then
                return
            end
        end
    end
    return func(self, fire_config)
end)

local function fx_suppressed(template_name, fx_extension, owner_unit)
    if not (mod_on and not session_off and mod:get("hide_weapon_fx") ~= false and loaded[GUN_KEY]) then
        return false
    end
    local setting = template_name and TEMPLATES[template_name]
    if not (setting and mod:get(setting)) then
        return false
    end
    local me = local_player()
    local unit = me and me.player_unit
    if not unit_ok(unit) then
        return false
    end
    if owner_unit then
        return owner_unit == unit
    end
    return fx_extension ~= nil and fx_extension == ScriptUnit.has_extension(unit, "fx_system")
end

local function charge_suppressed(self)
    local wa = self._weapon_action_component
    return fx_suppressed(wa and wa.template_name, self._fx_extension, nil)
end

local function no_particles(fx_extension)
    return setmetatable({
        spawn_gear_particle_effect_with_source = function()
        end,
    }, {
        __index = function(_, k)
            local v = fx_extension[k]
            if type(v) == "function" then
                return function(_, ...)
                    return v(fx_extension, ...)
                end
            end
            return v
        end,
    })
end

mod:hook("ChargeEffects", "_start_effects", function(func, self, t)
    if charge_suppressed(self) then
        self._effects_running = true
        return true
    end
    return func(self, t)
end)

mod:hook("ChargeEffects", "_play_charged_done_effects", function(func, self)
    if charge_suppressed(self) then
        local real = self._fx_extension
        self._fx_extension = no_particles(real)
        local ok, err = pcall(func, self)
        self._fx_extension = real
        if not ok then
            error(err, 0)
        end
        return
    end
    return func(self)
end)

local function overheat_suppressed(self)
    local owner = self._owner_unit
    local ude = unit_ok(owner) and ScriptUnit.has_extension(owner, "unit_data_system")
    local wa = ude and read_comp(ude, "weapon_action")
    return fx_suppressed(wa and wa.template_name, nil, owner)
end

mod:hook("PlasmagunOverheatEffects", "_update_vfx", function(func, self, overheat_configuration, overheat_percentage)
    if overheat_suppressed(self) then
        local ids = self._vfx_threshold_effect_ids
        if ids and next(ids) ~= nil then
            for stage, id in pairs(ids) do
                pcall(World.destroy_particles, self._world, id)
                ids[stage] = nil
            end
        end
        return
    end
    return func(self, overheat_configuration, overheat_percentage)
end)

mod:hook("PlasmagunOverheatEffects", "_update_screenspace", function(func, self, overheat_percentage)
    if overheat_suppressed(self) then
        if self._on_screen_effect_id then
            pcall(World.destroy_particles, self._world, self._on_screen_effect_id)
            self._on_screen_effect_id = nil
        end
        return
    end
    return func(self, overheat_percentage)
end)

local function ui_profile_is_mine(profile)
    if not profile then
        return false
    end
    local players = Managers.player and Managers.player:players()
    local me = local_player()
    if players and profile.character_id then
        for _, player in pairs(players) do
            if player ~= me and player.character_id and player:character_id() == profile.character_id then
                return false
            end
        end
    end
    return true
end

local function ui_spawn(world)
    return function(parent, path)
        local unit = World.spawn_unit_ex(world, path, nil, Unit.world_pose(parent, 1))
        World.link_unit(world, unit, 1, parent, 1, World.LINK_MODE_NODE_NAME)
        return unit
    end
end

local function ui_destroy_fn(world)
    return function(unit)
        if unit_ok(unit) and world then
            World.destroy_unit(world, unit)
        end
    end
end

local function scale_x(unit)
    if unit_ok(unit) then
        local s = Unit.local_scale(unit, 1)
        return s and s.x or 1
    end
    return 1
end

-- menu preview diagnosis (2026-11-08, chat cannot open in the loadout screen): each state change goes to the console log
local function ui_dbg(spawner, key, msg)
    local seen = spawner.__qiangiq_ui_dbg_deagle or {}
    spawner.__qiangiq_ui_dbg_deagle = seen
    if seen[key] ~= msg then
        seen[key] = msg
        mod:info("menu preview %s: %s", tostring(key), msg)
    end
end

local function profile_apply(spawner)
    local world = spawner._world
    local records = spawner.__qiangiq_deagle_records
    if not records then
        records = {}
        spawner.__qiangiq_deagle_records = records
    end
    local data = spawner._character_spawn_data
    local allowed = data and data.slots and opt("menu_previews") and ui_profile_is_mine(data.profile)
    if not allowed then
        ui_dbg(spawner, "profile", string.format("off: slots %s, menu_previews %s, mine %s", tostring(data and data.slots ~= nil),
            tostring(opt("menu_previews")), tostring(data and ui_profile_is_mine(data.profile))))
        clear_records(records, ui_destroy_fn(world))
        return
    end
    tracked_ui[spawner] = true
    local k = scale_x(data.unit_3p)
    for slot_name, slot in pairs(data.slots) do
        local item = slot.item
        if item and TEMPLATES[item.weapon_template] or records[slot_name] then
            local base = slot.unit_3p
            local att = base and slot.attachments_by_unit_3p and slot.attachments_by_unit_3p[base]
            sync_record(records, slot_name, base, att, item, spawner._visible and slot.hidden_3p ~= true, -- menu preview: the wielded slot has hidden_3p nil (log 2026-11-09)
                ui_spawn(world), ui_destroy_fn(world), k, false)
            local r = records[slot_name]
            ui_dbg(spawner, slot_name, string.format("template %s, base %s, attachments %s, spawner visible %s, hidden_3p %s, record %s, fitted %s, shown %s",
                tostring(item and item.weapon_template), tostring(unit_ok(base)), tostring(att and #att), tostring(spawner._visible),
                tostring(slot.hidden_3p), tostring(r ~= nil), tostring(r and r.fitted), tostring(r and r.shown)))
        end
    end
end

mod:hook_safe(CLASS.UIProfileSpawner, "_update_items_visibility", function(self)
    profile_apply(self)
end)

mod:hook_safe(CLASS.UIProfileSpawner, "update", function(self)
    local data = self._character_spawn_data
    if data and data.is_ready then
        profile_apply(self)
    elseif self.__qiangiq_deagle_records then
        clear_records(self.__qiangiq_deagle_records, ui_destroy_fn(self._world))
    end
end)

mod:hook(CLASS.UIProfileSpawner, "_despawn_current_character_profile", function(func, self, ...)
    clear_records(self.__qiangiq_deagle_records, ui_destroy_fn(self._world))
    return func(self, ...)
end)

local function weapon_apply(spawner)
    local world = spawner._world
    local records = spawner.__qiangiq_deagle_records
    if not records then
        records = {}
        spawner.__qiangiq_deagle_records = records
    end
    local data = spawner._weapon_spawn_data
    if not (data and opt("menu_previews")) then
        if next(records) ~= nil then
            clear_records(records, ui_destroy_fn(world))
            if data and data.visible and unit_ok(data.item_unit_3p) then
                Unit.set_unit_visibility(data.item_unit_3p, true, true)
            end
        end
        return
    end
    tracked_wpn[spawner] = true
    local base = data.item_unit_3p
    local att = base and data.attachment_units_3p and data.attachment_units_3p[base]
    sync_record(records, "weapon", base, att, data.item, data.visible and true or false,
        ui_spawn(world), ui_destroy_fn(world), scale_x(data.link_unit), false)
end

mod:hook_safe(CLASS.UIWeaponSpawner, "update", function(self)
    weapon_apply(self)
end)

mod:hook(CLASS.UIWeaponSpawner, "_despawn_current_weapon", function(func, self, ...)
    clear_records(self.__qiangiq_deagle_records, ui_destroy_fn(self._world))
    return func(self, ...)
end)

local function refresh_all()
    for ext in pairs(tracked) do
        if unit_ok(ext._unit) then
            ingame_apply(ext)
            ext:force_update_item_visibility()
        end
    end
    for spawner in pairs(tracked_ui) do
        profile_apply(spawner)
        if spawner._character_spawn_data and spawner._visible then
            spawner:_update_items_visibility()
        end
    end
    for spawner in pairs(tracked_wpn) do
        weapon_apply(spawner)
    end
end

local function after_change()
    fit_generation = fit_generation + 1
    refresh_all()
end

mod.toggle_deagle = function()
    session_off = not session_off
    refresh_all()
    mod:echo("Deagle %s for this session", session_off and "off" or "on")
end

local function prototype_off(notify)
    local other = nil
    if other and other:get("replace_weapon") then
        other:set("replace_weapon", false, notify)
        mod:echo("QIangIQ's Prototype was switched off: the AWP now replaces the plasma gun.")
    end
end

mod:command("deagle", "Desert Eagle | Printstream: /deagle (toggle), /deagle debug", function(which)
    if which == "debug" then
        for ext in pairs(tracked) do
            if ext._player == sync_me() then
                mod:echo(CS2Arms.debug(ext))
            end
        end
        local any = false
        for _, line in pairs(last_fit) do
            mod:echo(line)
            any = true
        end
        mod:echo("shots seen: %d", shots)
        if not any then
            mod:echo("Nothing fitted yet: wield a Phosphor pistol, stub revolver or bolt pistol with the replacement switched on.")
        end
        return
    end
    mod.toggle_deagle()
end)

mod.on_setting_changed = function(setting_id)
    after_change()
end

mod.on_all_mods_loaded = function()
    if false then
        prototype_off(true)
    end
    custom_assets = get_mod("CustomAssets")
    if not custom_assets or not custom_assets.is_api_compatible or not custom_assets.is_api_compatible(1) then
        mod:error("Custom Assets (API 1) is missing. Install it and put it above QIangIQsDeagle in mod_load_order.txt.")
        return
    end
    for _, key in ipairs({ GUN_KEY, TP_KEY, DRIVER_KEY, CS2Arms.ASSETS[1], CS2Arms.ASSETS[2] }) do
        local id = asset_id(key)
        local ticket, err = custom_assets.acquire(mod, id, function(_, _, load_error)
            if load_error then
                mod:error("%s failed to load: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", id, tostring(load_error))
                return
            end
            loaded[key] = true
            refresh_all()
        end, { resident = true, reference_name = id })
        if not ticket then
            mod:error("%s could not be requested: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", id, tostring(err))
        end
    end
end

local function remove_all()
    for ext in pairs(tracked) do
        scope_stop(ext)
        pcall(CS2Arms.stop, ext, ext.__qiangiq_deagle_world)
        clear_records(ext.__qiangiq_deagle_records, ingame_destroy)
    end
    for spawner in pairs(tracked_ui) do
        clear_records(spawner.__qiangiq_deagle_records, ui_destroy_fn(spawner._world))
    end
    for spawner in pairs(tracked_wpn) do
        clear_records(spawner.__qiangiq_deagle_records, ui_destroy_fn(spawner._world))
    end
end

mod.on_disabled = function()
    mod_on = false
    remove_all()
    for ext in pairs(tracked) do
        if unit_ok(ext._unit) then
            ext:force_update_item_visibility()
        end
    end
    for spawner in pairs(tracked_ui) do
        if spawner._character_spawn_data and spawner._visible then
            spawner:_update_items_visibility()
        end
    end
    for spawner in pairs(tracked_wpn) do
        local data = spawner._weapon_spawn_data
        if data and data.visible and unit_ok(data.item_unit_3p) then
            Unit.set_unit_visibility(data.item_unit_3p, true, true)
        end
    end
end

mod.on_enabled = function()
    mod_on = true
    refresh_all()
end

mod.on_unload = function()
    -- engine may have destroyed the extensions at game exit; do not stop the unload (console log 2026-10-11)
    pcall(remove_all)
    if custom_assets and custom_assets.release_owner then
        custom_assets.release_owner(mod)
    end
end

local sync_enabled = true
local function sync_changed()
    local api = sync_api()
    if api then
        api.changed()
    end
end

mod.sync_key = SYNC_KEY
mod.sync_export = function(info)
    info = info or {}
    if not sync_enabled or session_off or not (mod:get("replace_phosphor") or mod:get("replace_revolver") or mod:get("replace_boltpistol")) then
        return nil
    end
    if info.templates ~= nil then
        local any = false
        for template in pairs(TEMPLATES) do
            any = any or (info.templates[template] and true or false)
        end
        if not any then
            return nil
        end
    end
    local mask, bit = 0, 1
    for i = 1, #SYNC_BOOLS do
        local key = SYNC_BOOLS[i]
        local v = mod:get(key)
        if v == nil then
            v = SYNC_DEFAULTS[key]
        end
        if v then
            mask = mask + bit
        end
        bit = bit * 2
    end
    local out = { SYNC_LAYOUT, mask }
    for i = 1, #SYNC_VALUES do
        local v = mod:get(SYNC_VALUES[i])
        if type(v) == "number" then
            v = math.floor(v * 100 + 0.5) / 100
        elseif type(v) ~= "string" then
            v = false
        end
        out[2 + i] = v
    end
    return out
end

mod.sync_refresh = function()
    for ext in pairs(sync_all) do
        if ext._unit and Unit.alive(ext._unit) and ext.force_update_item_visibility then
            pcall(ext.force_update_item_visibility, ext)
        end
    end
end

local sync_prev_setting_changed = mod.on_setting_changed
mod.on_setting_changed = function(...)
    if sync_prev_setting_changed then
        sync_prev_setting_changed(...)
    end
    sync_changed()
end

local sync_prev_disabled = mod.on_disabled
mod.on_disabled = function(...)
    sync_enabled = false
    if sync_prev_disabled then
        sync_prev_disabled(...)
    end
    sync_changed()
end

local sync_prev_enabled = mod.on_enabled
mod.on_enabled = function(...)
    sync_enabled = true
    if sync_prev_enabled then
        sync_prev_enabled(...)
    end
    sync_changed()
end

-- QIangIQsArmoryVis: stowed-weapon copies (see QIangIQsArmoryVis/README.md). Armory Vis calls apply every frame
-- and clear once per copy with `holder` (one table per character and stowed slot: _unit, _player, _ext,
-- _slot_name) and `equipment` ({ [slot_name] = slot-like table of the copy, hidden_3p false while shown }).
-- Only the weapon fit runs here: the arms, scope and sounds of ingame_apply belong to the weapon in hand.
mod.armory_vis = {
    apply = function(holder, world, equipment)
        holder.__qiangiq_deagle_world = world
        local records = holder.__qiangiq_deagle_records
        if not records then
            records = {}
            holder.__qiangiq_deagle_records = records
        end
        for slot_name, slot in pairs(equipment) do
            local item = slot.item
            if item and TEMPLATES[item.weapon_template] or records[slot_name .. ":3p"] then
                local base = slot.unit_3p
                local att = base and slot.attachments_by_unit_3p and slot.attachments_by_unit_3p[base]
                sync_record(records, slot_name .. ":3p", base, att, item, slot.hidden_3p == false,
                    ingame_spawn(holder, false), ingame_destroy, 1, false)
            end
        end
    end,
    clear = function(holder)
        clear_records(holder.__qiangiq_deagle_records, ingame_destroy)
        holder.__qiangiq_deagle_records = nil
    end,
}

-- Skin exclusivity with the other QIangIQ mods over the same weapons (claim_template / release_template pattern of
-- QIangIQsMMJPistol / QIangIQsMMJBat): switching a weapon on here tells them to let go of it; they call
-- mod.release_template when they take it back. A mod that is not installed is skipped.
local OTHER_MODS = { "QIangIQsMMJPistol", "QIangIQsMMJChainPistol" }
local SETTING_TEMPLATES = {}
for template, setting in pairs(TEMPLATES) do
    SETTING_TEMPLATES[setting] = SETTING_TEMPLATES[setting] or {}
    table.insert(SETTING_TEMPLATES[setting], template)
end

local function claim_setting(setting_id)
    for _, template in ipairs(SETTING_TEMPLATES[setting_id] or {}) do
        for _, name in ipairs(OTHER_MODS) do
            local other = get_mod(name)
            if other and type(other.release_template) == "function" then
                pcall(other.release_template, template)
            end
        end
    end
end

mod.release_template = function(template)
    local setting = TEMPLATES[template]
    if setting and mod:get(setting) ~= false then
        mod:set(setting, false, false)
        mod.on_setting_changed(setting)
        mod:echo("%s is now shown by another QIangIQ mod: switched off in %s.", template, mod:get_name())
    end
end

local exclusive_prev_setting_changed = mod.on_setting_changed
mod.on_setting_changed = function(setting_id, ...)
    if SETTING_TEMPLATES[setting_id] and mod:get(setting_id) then
        claim_setting(setting_id)
    end
    return exclusive_prev_setting_changed(setting_id, ...)
end

local armory_vis_registered = false
mod.update = function()
    if armory_vis_registered then
        return
    end
    armory_vis_registered = true
    local av = get_mod("QIangIQsArmoryVis")
    if av and type(av.register) == "function" then
        pcall(av.register, mod:get_name(), mod.armory_vis)
    end
    -- first time each other QIangIQ skin mod is loaded next to this one, this mod takes its weapons from it once
    -- (it can take them back). 1.1.1: per mod, so a session without that mod no longer uses up the claim.
    for _, name in ipairs(OTHER_MODS) do
        local other = get_mod(name)
        local flag = "claimed_" .. name
        if other and type(other.release_template) == "function" and not mod:get(flag) then
            mod:set(flag, true, false)
            for setting, templates in pairs(SETTING_TEMPLATES) do
                if mod:get(setting) ~= false then
                    for _, template in ipairs(templates) do
                        pcall(other.release_template, template)
                    end
                end
            end
        end
    end
end

-- CS2 moves in third person (QIangIQsDeagle_tp.lua): Custom/dg_tp_driver, the CS2 clips baked on the player 3p skeleton
local Tp = mod:io_dofile("QIangIQsDeagle/scripts/mods/QIangIQsDeagle/QIangIQsDeagle_tp")
local tp_templates = {}
for template in pairs(TEMPLATES) do
    tp_templates[template] = true
end
Tp.setup({
    spans = mod:io_dofile("QIangIQsDeagle/scripts/mods/QIangIQsDeagle/QIangIQsDeagle_tp_spans"),
    templates = tp_templates,
    tp_driver_path = function()
        return loaded[TP_KEY] and unit_path(TP_KEY) or nil
    end,
    enabled = function()
        return mod_on and not session_off and mod:get("cs2_3p") ~= false
    end,
    opt = function(key, default)
        local v = mod:get(key)
        if v == nil then
            return default
        end
        return tonumber(v) or v
    end,
    -- the CS2 weapon is shown on this unit (this mod's own 3p record; other players need the mod and model sync)
    shown = function(unit)
        local ext = unit_ok(unit) and ScriptUnit.has_extension(unit, "visual_loadout_system")
        local records = ext and ext.__qiangiq_deagle_records
        for key, rec in pairs(records or {}) do
            if type(key) == "string" and key:find(":3p$") and rec.shown then
                return true
            end
        end
        return false
    end,
    local_action = function(unit)
        local player = local_player()
        if player and player.player_unit == unit then
            local ok, info = pcall(CS2_CFG.action, unit)
            return ok and info or nil
        end
        return nil
    end,
    -- Duelling Sword heavies = CS2 light_backstab (user rule 2026-11-08); knife heavies follow cs2_heavy_light_swings
    heavy_clip = function(template_name)
        if template_name and template_name:find("^combatsword_p3") then
            return "light_backstab"
        end
        if mod:get("cs2_heavy_light_swings") ~= false then
            return "light_miss1"
        end
        return "heavy_miss1"
    end,
})

for _, class_name in ipairs({ "PlayerUnitAnimationExtension", "AuthoritativePlayerUnitAnimationExtension", "PlayerHuskAnimationExtension" }) do
    local class = CLASS[class_name]
    if class then
        mod:hook_safe(class, "inventory_slot_wielded", function(self, weapon_template)
            pcall(Tp.wielded, self._unit, weapon_template and weapon_template.name or nil)
        end)
        if class_name ~= "PlayerHuskAnimationExtension" then
            for _, method in ipairs({ "anim_event", "anim_event_with_variable_float", "anim_event_with_variable_floats",
                "anim_event_with_variable_int" }) do
                if class[method] then
                    mod:hook(class, method, function(func, self, event_name, ...)
                        local a, b = Tp.learn(func, self._unit, event_name, self, event_name, ...)
                        local ok, err = pcall(Tp.on_event, self._unit, event_name)
                        if not ok then
                            mod:error("third person: %s", tostring(err))
                        end
                        return a, b
                    end)
                end
            end
        end
    end
end

if CLASS.AnimationSystem then
    for _, rpc in ipairs({ "rpc_player_anim_event", "rpc_player_anim_event_variable_float", "rpc_player_anim_event_variable_floats",
        "rpc_player_anim_event_variable_int" }) do
        if CLASS.AnimationSystem[rpc] then
            mod:hook_safe(CLASS.AnimationSystem, rpc, function(self, channel_id, unit_id, event_index, ...)
                local is_first_person = select(select("#", ...), ...)
                if is_first_person then
                    return
                end
                local ok, err = pcall(function()
                    local unit = Managers.state.unit_spawner:unit(unit_id)
                    if unit then
                        Tp.on_husk_event(unit, event_index)
                    end
                end)
                if not ok then
                    mod:error("third person (other player): %s", tostring(err))
                end
            end)
        end
    end
end

local tp_prev_update = mod.update
mod.update = function(...)
    local ok, err = pcall(Tp.update)
    if not ok then
        mod:error("third person update: %s", tostring(err))
        pcall(Tp.stop_all)
    end
    if tp_prev_update then
        return tp_prev_update(...)
    end
end

local tp_prev_disabled = mod.on_disabled
mod.on_disabled = function(...)
    pcall(Tp.stop_all)
    if tp_prev_disabled then
        return tp_prev_disabled(...)
    end
end

local tp_prev_unload = mod.on_unload
mod.on_unload = function(...)
    pcall(Tp.stop_all)
    if tp_prev_unload then
        return tp_prev_unload(...)
    end
end

mod:command("deagle3p", "CS2 moves in third person: state", function()
    mod:echo(Tp.debug())
end)

-- Inspecting this gun does not lock the camera (user request 2026-11-08 22:11). Darktide's action_inspect sets
-- lock_view (weapon_lock orientation) and the held inspect chains into action_inspect_3p (force_look orientation);
-- while either runs on a replaced template, the normal orientation is used instead.
mod:hook("HumanGameplay", "_player_orientation_class", function(func, self, ...)
    local orientation = func(self, ...)
    if orientation ~= nil and self._default_player_orientation
        and (orientation == self._weapon_lock_view_player_orientation or orientation == self._weapon_force_view_player_orientation)
        and mod:is_enabled() and not session_off then
        local unit = self._player_unit
        local ude = unit and Unit.alive(unit) and ScriptUnit.has_extension(unit, "unit_data_system")
        local wa = ude and read_comp(ude, "weapon_action")
        local name = wa and wa.current_action_name
        if (name == "action_inspect" or name == "action_inspect_3p") and TEMPLATES[wa.template_name] and mod:get(TEMPLATES[wa.template_name]) then
            return self._default_player_orientation
        end
    end
    return orientation
end)

-- 3p: the CS2 weapon held the CS2 way during third-person CS2 moves (see QIangIQsDeagle_tp.lua apply_grip)
Tp.set_grip(mod:io_dofile("QIangIQsDeagle/scripts/mods/QIangIQsDeagle/QIangIQsDeagle_tp_grip"), function(unit)
    local ext = unit_ok(unit) and ScriptUnit.has_extension(unit, "visual_loadout_system")
    for key, rec in pairs(ext and ext.__qiangiq_deagle_records or {}) do
        if type(key) == "string" and key:find(":3p$") and rec.shown and unit_ok(rec.sword) then
            return rec.sword, rec.base, rec
        end
    end
    return nil
end)

-- Darktide-style bottom-right HUD icon (user 2026-11-09: "schematic/blueprint/lineart style of Darktide for CS2 weapons").
-- cs2_weapons\icons\render_icons.py draws the CS2 model as white line art + grey fill + glow (512x192, like the retail
-- hud icons); build_and_patch.py compiles it into Custom/hud_icon (one quad; loading it makes the texture resident).
-- hud_element_player_weapon.lua:73-80 puts item.hud_icon in widget.content.icon; here ui_default_base with
-- material_values.texture_map = the icon (Datavault technique-weapon-hud-icon-custom-texture, QIangIQsDauntlessMaul).
-- Without Custom Assets or before the patcher has run, the game's icon stays.
local HUD_ICON_ID = asset_id("hud_icon")
local HUD_ICON_MATERIAL = "content/ui/materials/base/ui_default_base"
local HUD_ICON_TEXTURE = "content/mods/qiangiq_deagle/hud_icon_material_0_bca"
local hud_icon_ready = false
local hud_icon_prev_all_loaded = mod.on_all_mods_loaded
mod.on_all_mods_loaded = function(...)
    if hud_icon_prev_all_loaded then
        hud_icon_prev_all_loaded(...)
    end
    local ca = get_mod("CustomAssets")
    if not (ca and ca.acquire) then
        return
    end
    local ok, ticket = pcall(ca.acquire, mod, HUD_ICON_ID, function(_, _, load_error)
        if load_error then
            mod:info("HUD icon %s not loaded: %s", HUD_ICON_ID, tostring(load_error))
            return
        end
        hud_icon_ready = true
        mod:info("HUD icon %s loaded", HUD_ICON_ID)
    end, { resident = true, reference_name = HUD_ICON_ID })
    if not (ok and ticket) then
        mod:info("HUD icon %s could not be requested (Custom Assets patcher not run yet?)", HUD_ICON_ID)
    end
end

-- the handler recreates the element when the slot's weapon changes (hud_element_player_weapon_handler.lua:83-120)
mod:hook_safe(CLASS.HudElementPlayerWeapon, "init", function(self, parent, draw_layer, start_scale, data)
    self.__qiangiq_qiangiq_deagle_hud_item = data and data.item
end)

mod:hook_safe(CLASS.HudElementPlayerWeapon, "update", function(self)
    local item = self.__qiangiq_qiangiq_deagle_hud_item
    local widget = item and hud_icon_ready and self._widgets_by_name and self._widgets_by_name.icon
    if not widget then
        return
    end
    local ok, want = pcall(wants_item, item)
    if not (ok and want) then
        return
    end
    local style = widget.style.icon
    style.material_values = style.material_values or {}
    if widget.content.icon ~= HUD_ICON_MATERIAL or style.material_values.texture_map ~= HUD_ICON_TEXTURE then
        widget.content.icon = HUD_ICON_MATERIAL
        style.material_values.texture_map = HUD_ICON_TEXTURE
        widget.dirty = true
    end
end)
