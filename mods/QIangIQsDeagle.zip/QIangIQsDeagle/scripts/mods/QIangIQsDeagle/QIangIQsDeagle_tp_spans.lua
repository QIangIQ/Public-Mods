-- seconds of each CS2 clip in Custom/dg_tp_driver (tp_bake_cs2.py, 650 frames at 30 fps)
return {
    draw = { start = 0.0000, length = 1.0000 },
    shoot1 = { start = 1.1000, length = 0.7000 },
    shoot_empty = { start = 1.9000, length = 0.7000 },
    reload = { start = 2.7000, length = 2.2000 },
    reload_empty = { start = 5.0000, length = 2.2000 },
    lookat01 = { start = 7.3000, length = 5.6667 },
    lookat02 = { start = 13.0667, length = 8.5000 },
}
