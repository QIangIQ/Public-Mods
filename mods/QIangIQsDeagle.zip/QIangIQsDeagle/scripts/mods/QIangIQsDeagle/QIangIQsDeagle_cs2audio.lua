local Audio = {}
local CFG = nil
local states = {}
local last_fire = {}

function Audio.setup(cfg)
    CFG = cfg
end

local function simple_audio()
    local m = get_mod and get_mod("SimpleAudio")
    return m and m.play_file and m or nil
end

local function fire(name)
    local ev = CFG.data.events[name]
    local sa = simple_audio()
    if not (ev and sa and #ev.files > 0) then
        return
    end
    local now = CFG.now()
    if last_fire[name] and now - last_fire[name] < 0.04 then
        return
    end
    last_fire[name] = now
    local file = ev.files[math.random(#ev.files)]
    local volume = (CFG.opt("cs2_sound_volume") or 100) * (ev.v or 1) * 2 -- 2x CS2 audio (user request 2026-11-08)
    pcall(sa.play_file, "mods/" .. CFG.mod_name .. "/audio/" .. file, { audio_type = "sfx", volume = volume })
end

function Audio.fire(name)
    if CFG and CFG.opt("cs2_sounds") ~= false then
        fire(name)
    end
end

function Audio.tick(key, clip, t)
    local st = states[key]
    if not st then
        st = { clip = nil, last = -math.huge, cursor = 1 }
        states[key] = st
    end
    if not CFG or CFG.opt("cs2_sounds") == false then
        st.clip = nil
        return
    end
    local events = clip and CFG.data.clips[clip]
    t = t or 0
    if clip ~= st.clip or (events and t + 1e-4 < st.last) then
        st.clip, st.cursor, st.last = clip, 1, -math.huge
    end
    if not events then
        return
    end
    if st.last == -math.huge and t > 0.1 then
        while st.cursor <= #events and events[st.cursor][1] <= t do
            st.cursor = st.cursor + 1
        end
        st.last = t
        return
    end
    while st.cursor <= #events and events[st.cursor][1] <= t do
        fire(events[st.cursor][2])
        st.cursor = st.cursor + 1
    end
    st.last = t
end

return Audio
