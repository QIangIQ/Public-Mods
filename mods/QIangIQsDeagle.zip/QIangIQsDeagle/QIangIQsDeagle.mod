return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsDeagle` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsDeagle", {
            mod_script = "QIangIQsDeagle/scripts/mods/QIangIQsDeagle/QIangIQsDeagle",
            mod_data = "QIangIQsDeagle/scripts/mods/QIangIQsDeagle/QIangIQsDeagle_data",
            mod_localization = "QIangIQsDeagle/scripts/mods/QIangIQsDeagle/QIangIQsDeagle_localization",
        })
    end,
    version = "1.1.11",
    author = "QIangIQ",
    load_after = { "CustomAssets" },
    packages = {},
}
