return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsBismuthRelicBlade` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsBismuthRelicBlade", {
            mod_script = "QIangIQsBismuthRelicBlade/scripts/mods/QIangIQsBismuthRelicBlade/QIangIQsBismuthRelicBlade",
            mod_data = "QIangIQsBismuthRelicBlade/scripts/mods/QIangIQsBismuthRelicBlade/QIangIQsBismuthRelicBlade_data",
            mod_localization = "QIangIQsBismuthRelicBlade/scripts/mods/QIangIQsBismuthRelicBlade/QIangIQsBismuthRelicBlade_localization",
        })
    end,
    version = "1.4.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
