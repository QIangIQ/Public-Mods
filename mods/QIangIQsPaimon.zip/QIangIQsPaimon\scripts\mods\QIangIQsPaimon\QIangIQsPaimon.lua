-- QIangIQ's Paimon: shows a Custom Assets Paimon in place of the local player's companion
-- servo-skull (archetype.companion_breed == "companion_servo_skull", items.lua:2014).
-- Author: QIangIQ
local mod = get_mod("QIangIQsPaimon")

-- Cross-client sync ---------------------------------------------------------------
-- QIangIQsModelSync publishes which QIangIQ replacer mods a player has on, with their options, through
-- Vox Manifold (the transport Dio's Wardrobe shares outfits with). No asset data is sent: every client shows
-- the model from its own installed files. While another player's unit is worked on, sync_ctx holds that
-- player's options and opt() answers from them; for my own unit opt() is mod:get().
local SYNC_KEY = "paimon"
local SYNC_BOOLS = { "replace_skull" }
local SYNC_DEFAULTS = { replace_skull = true }
local SYNC_VALUES = { "paimon_size", "paimon_height", "paimon_turn" }
local SYNC_LAYOUT = #SYNC_BOOLS * 100 + #SYNC_VALUES -- a peer on another version of this mod is not decoded
local sync_ctx = nil
local sync_known = setmetatable({}, { __mode = "k" })   -- other players' extensions this mod has shown something on
local sync_all = setmetatable({}, { __mode = "k" })     -- every visual loadout extension seen
local sync_decoded = setmetatable({}, { __mode = "k" }) -- published array -> options table
local SYNC_FALSE = { __index = function() return false end }
local SYNC_OFF = setmetatable({}, SYNC_FALSE)           -- "everything off": removes what was shown
local sync_extra_import = nil

local function opt(key)
    if sync_ctx then
        return sync_ctx[key]
    end
    return mod:get(key)
end

local function sync_api()
    local hub = get_mod("QIangIQsModelSync")
    return hub and hub.api
end

local function sync_me()
    local players = Managers.player
    if not players then
        return nil
    end
    local ok, player = pcall(players.local_player_safe, players, 1)
    return ok and player or nil
end

-- published array { layout, checkbox bits, value, value, ... [, extra] } -> options by setting id
local function sync_decode(raw)
    local t = sync_decoded[raw]
    if t ~= nil then
        return t
    end
    t = false
    if type(raw) == "table" and raw[1] == SYNC_LAYOUT then
        t = setmetatable({}, SYNC_FALSE)
        local mask = tonumber(raw[2]) or 0
        for i = 1, #SYNC_BOOLS do
            t[SYNC_BOOLS[i]] = mask % 2 >= 1
            mask = math.floor(mask / 2)
        end
        for i = 1, #SYNC_VALUES do
            local v = raw[2 + i]
            if v ~= nil then
                t[SYNC_VALUES[i]] = v
            end
        end
        if sync_extra_import then
            sync_extra_import(t, raw[3 + #SYNC_VALUES])
        end
    end
    sync_decoded[raw] = t
    return t
end

-- whose options apply to this extension: nil = mine, a table = that player's (SYNC_OFF when they publish
-- nothing for this mod)
local function sync_owner(ext)
    sync_all[ext] = true
    local player = ext._player
    if player == nil or player == sync_me() then
        return nil
    end
    local api = sync_api()
    local raw = api and api.peer(SYNC_KEY, player)
    local state = raw and sync_decode(raw)
    if state then
        sync_known[ext] = true
        return state
    end
    return SYNC_OFF
end

-- my own unit, or another player's unit this mod is (or was) showing something on
local function sync_shown(ext)
    local player = ext._player
    return player ~= nil and (player == sync_me() or sync_known[ext] == true)
end

local function sync_pack(...)
    return { n = select("#", ...), ... }
end

-- runs a hook body with the options of the extension's owner
local function sync_wrap(fn, ext_index)
    return function(...)
        local ext = select(ext_index, ...)
        local previous = sync_ctx
        sync_ctx = sync_owner(ext)
        local results = sync_pack(pcall(fn, ...))
        sync_ctx = previous
        if not results[1] then
            error(results[2], 0)
        end
        return unpack(results, 2, results.n)
    end
end

-- The same hook on my own unit's extension and on other players' (husk) extensions. While the mods load, the
-- classes do not exist yet: CLASS.<name> is then only the name and DMF delays the hook ("needs to be delayed"
-- in the log), so the husk class cannot be inspected here. Its methods are taken from
-- player_husk_visual_loadout_extension.lua instead.
local SYNC_HUSK_METHODS = { init = true, update = true, _update_item_visibility = true, destroy = true }

local function vl_hook_safe(method, fn)
    mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, method, sync_wrap(fn, 1))
    if SYNC_HUSK_METHODS[method] then
        mod:hook_safe(CLASS.PlayerHuskVisualLoadoutExtension, method, sync_wrap(fn, 1))
    end
end

local function vl_hook(method, fn)
    mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, method, sync_wrap(fn, 2))
    if SYNC_HUSK_METHODS[method] then
        mod:hook(CLASS.PlayerHuskVisualLoadoutExtension, method, sync_wrap(fn, 2))
    elseif method == "_unequip_item_from_slot" then
        -- a husk has no _unequip_item_from_slot: its unequip arrives as rpc_player_unequip_item_from_slot
        -- (self, channel_id, go_id, slot_id), slot name = NetworkLookup.player_inventory_slot_names[slot_id]
        -- (player_husk_visual_loadout_extension.lua)
        mod:hook(CLASS.PlayerHuskVisualLoadoutExtension, "rpc_player_unequip_item_from_slot", sync_wrap(function(func, self, channel_id, go_id, slot_id, ...)
            local NetworkLookup = require("scripts/network_lookup/network_lookup")
            local slot_name = NetworkLookup.player_inventory_slot_names[slot_id]
            return fn(function()
                return func(self, channel_id, go_id, slot_id)
            end, self, slot_name)
        end, 2))
    end
end
-- ----------------------------------------------------------------------------------

mod.AUTHOR = "QIangIQ"

local PAIMON_ID = "QIangIQsPaimon:paimon"                 -- <Mod>:<Custom folder>
local PAIMON_UNIT = "content/mods/qiangiq_paimon/paimon" -- --asset-path used at compile time
local SKULL_BREED = "companion_servo_skull"
local COMPANION_SLOT = "slot_companion_gear_full"        -- ui_profile_spawner.lua:24, equipment_component.lua

-- The compiled model is 1 unit tall, centred on its bounding box, facing local +Y, +Z up
-- (paimon/prep_paimon.py; pose = frame 1 of the source idle animation).
local FIT_FRAMES = 10
local fit_generation = 0

local custom_assets = nil
local ready = false
local mod_on = true
local session_override = nil

local tracked = setmetatable({}, { __mode = "k" })    -- PlayerUnitVisualLoadoutExtension
local tracked_ui = setmetatable({}, { __mode = "k" }) -- UIProfileSpawner

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function enabled()
    if not (mod_on and ready) then
        return false
    end
    if session_override ~= nil then
        return session_override
    end
    return opt("replace_skull") and true or false
end

local function local_player()
    local players = Managers.player
    if not players then
        return nil
    end
    local ok, player = pcall(players.local_player_safe, players, 1)
    return ok and player or nil
end

local function fmt(v)
    return string.format("(%.3f, %.3f, %.3f)", v.x, v.y, v.z)
end

local last_fit = {}

-- Biggest piece of the servo-skull (companion unit or one of its gear attachments). Only the
-- box centre (Matrix4x4.translation) and its largest half-extent are used, as in the other mods.
local function skull_box(companion, attachments)
    local best_half, best_center = 0, nil
    local function look(unit)
        if unit_ok(unit) then
            local pose, ext = Unit.box(unit)
            if pose and ext then
                local half = math.max(ext.x, ext.y, ext.z)
                if half > best_half then
                    best_half, best_center = half, Matrix4x4.translation(pose)
                end
            end
        end
    end
    look(companion)
    if attachments then
        for i = 1, #attachments do
            look(attachments[i])
        end
    end
    return best_center, best_half
end

-- Paimon is linked to the companion unit (node 1): centred on the skull's box (plus the height
-- offset along the companion's up axis), upright in the companion's own frame, turned by the
-- "turn" setting, height = skull size x size setting.
local function fit(paimon, companion, attachments, view)
    local center, half = skull_box(companion, attachments)
    if not center or half <= 0 then
        return false
    end
    local size = 2 * half
    local origin = Unit.world_position(companion, 1)
    local rot = Unit.world_rotation(companion, 1)
    local bx, by, bz = Quaternion.right(rot), Quaternion.forward(rot), Quaternion.up(rot)
    local target = center + bz * (size * (opt("paimon_height") or 0))
    local d = target - origin
    local scale = Unit.local_scale(companion, 1)
    local k = scale and scale.x > 0 and scale.x or 1
    local s = size * (opt("paimon_size") or 2) / k
    local local_pos = Vector3(Vector3.dot(d, bx), Vector3.dot(d, by), Vector3.dot(d, bz)) * (1 / k)
    Unit.set_local_position(paimon, 1, local_pos)
    -- Quaternion.from_yaw_pitch_roll takes radians (sway.lua, aim_projectile.lua)
    Unit.set_local_rotation(paimon, 1, Quaternion.from_yaw_pitch_roll(math.rad(opt("paimon_turn") or 0), 0, 0))
    Unit.set_local_scale(paimon, 1, Vector3(s, s, s))
    if view then
        last_fit[view] = string.format("%s: skull size %.3f, local centre %s, scale %.3f", view, size, fmt(local_pos), s)
    end
    return true
end

local function hide_skull(companion, attachments)
    Unit.set_unit_visibility(companion, false, true)
    if attachments then
        for i = 1, #attachments do
            if unit_ok(attachments[i]) then
                Unit.set_unit_visibility(attachments[i], false, true)
            end
        end
    end
end

-- holder.__qiangiq_paimon = { unit, companion, frames, count, gen, fitted, hid }
local function sync(holder, key, companion, attachments, want, visible, spawn_fn, destroy_fn)
    local rec = holder.__qiangiq_paimon
    want = want and enabled() and unit_ok(companion)
    if rec and (not want or rec.companion ~= companion or not unit_ok(rec.unit)) then
        destroy_fn(rec.unit)
        holder.__qiangiq_paimon = nil
        if rec.hid and unit_ok(rec.companion) and visible then
            Unit.set_unit_visibility(rec.companion, true, true)
        end
        rec = nil
    end
    if not want then
        return
    end
    if not rec then
        local unit = spawn_fn(companion)
        if not unit then
            return
        end
        rec = { unit = unit, companion = companion, frames = 0, count = -1, fitted = false }
        holder.__qiangiq_paimon = rec
    end
    local count = attachments and #attachments or 0
    if rec.count ~= count or rec.gen ~= fit_generation then
        rec.count, rec.gen, rec.frames = count, fit_generation, 0
    end
    if rec.frames < FIT_FRAMES then
        rec.frames = rec.frames + 1
        rec.fitted = fit(rec.unit, companion, attachments, key) or rec.fitted
    end
    if rec.fitted and visible then
        hide_skull(companion, attachments)
        rec.hid = true
        Unit.set_unit_visibility(rec.unit, true, true)
    else
        Unit.set_unit_visibility(rec.unit, false, true)
    end
end

-- In game ---------------------------------------------------------------------

local function ingame_spawn(ext)
    return function(parent)
        local world = ext.__qiangiq_paimon_world
        local unit_spawner = Managers.state and Managers.state.unit_spawner
        if not (world and unit_spawner) then
            return nil
        end
        local unit = unit_spawner:spawn_unit(PAIMON_UNIT, Unit.world_pose(parent, 1))
        if not unit then
            return nil
        end
        World.link_unit(world, unit, 1, parent, 1, World.LINK_MODE_NODE_NAME)
        return unit
    end
end

local function ingame_destroy(unit)
    if unit_ok(unit) then
        local unit_spawner = Managers.state and Managers.state.unit_spawner
        if unit_spawner then
            unit_spawner:mark_for_deletion(unit)
        end
    end
end

local function ingame_apply(ext)
    -- same lookup as equipment_component.lua:228-230
    local owner = ext._unit
    local spawner_ext = unit_ok(owner) and ScriptUnit.has_extension(owner, "companion_spawner_system")
    local companion_units = spawner_ext and spawner_ext:companion_units()
    local companion = companion_units and #companion_units > 0 and companion_units[1] or nil
    local slot = ext._equipment and ext._equipment[COMPANION_SLOT]
    local attachments = slot and unit_ok(companion) and slot.attachments_by_unit_3p and slot.attachments_by_unit_3p[companion]
    sync(ext, "in game", companion, attachments, ext.__qiangiq_paimon_breed == SKULL_BREED, true, ingame_spawn(ext), ingame_destroy)
end

local function is_local(ext)
    return sync_shown(ext)
end

vl_hook_safe("init", function(self, extension_init_context, unit, extension_init_data)
    self.__qiangiq_paimon_world = extension_init_context and extension_init_context.world
    -- player_unit_visual_loadout_extension.lua:207 reads extension_init_data.archetype.companion_breed
    local archetype = extension_init_data and extension_init_data.archetype
    self.__qiangiq_paimon_breed = archetype and archetype.companion_breed
end)

vl_hook_safe("update", function(self)
    if self.__qiangiq_paimon_breed ~= SKULL_BREED or not is_local(self) then
        return
    end
    tracked[self] = true
    ingame_apply(self)
end)

vl_hook("destroy", function(func, self, ...)
    local rec = self.__qiangiq_paimon
    if rec then
        ingame_destroy(rec.unit)
        self.__qiangiq_paimon = nil
    end
    tracked[self] = nil
    return func(self, ...)
end)

-- Menu previews ---------------------------------------------------------------

local function ui_profile_is_mine(profile)
    -- __qiangiq_npc: the companion NPC spawned by QIangIQsCompanionSwap is nobody's character
    if not profile or profile.__qiangiq_npc then
        return false
    end
    local players = Managers.player and Managers.player:players()
    local me = local_player()
    if players and profile.character_id then
        for _, player in pairs(players) do
            if player ~= me and player.character_id and player:character_id() == profile.character_id then
                return false
            end
        end
    end
    return true
end

local function ui_destroy_fn(world)
    return function(unit)
        if unit_ok(unit) and world then
            World.destroy_unit(world, unit)
        end
    end
end

local function ui_apply(spawner)
    local world = spawner._world
    local data = spawner._character_spawn_data
    local companion = data and data.companion_unit_3p
    local archetype = data and data.profile and data.profile.archetype
    -- ui_profile_spawner.lua:988 reads archetype.companion_breed
    local want = data ~= nil and opt("menu_previews") and archetype ~= nil and archetype.companion_breed == SKULL_BREED and ui_profile_is_mine(data.profile)
    local slot = data and data.slots and data.slots[COMPANION_SLOT]
    local attachments = slot and unit_ok(companion) and slot.attachments_by_unit_3p and slot.attachments_by_unit_3p[companion]
    -- the spawner shows the companion when it is visible itself (ui_profile_spawner.lua:1437-1448)
    local visible = spawner._visible and true or false
    if want or spawner.__qiangiq_paimon then
        tracked_ui[spawner] = true
        sync(spawner, "menu", companion, attachments, want and true or false, visible, function(parent)
            -- same calls ui_profile_spawner.lua uses for its own units
            local unit = World.spawn_unit_ex(world, PAIMON_UNIT, nil, Unit.world_pose(parent, 1))
            World.link_unit(world, unit, 1, parent, 1, World.LINK_MODE_NODE_NAME)
            return unit
        end, ui_destroy_fn(world))
    end
end

mod:hook_safe(CLASS.UIProfileSpawner, "update", function(self)
    local data = self._character_spawn_data
    if data then
        ui_apply(self)
    elseif self.__qiangiq_paimon then
        ui_destroy_fn(self._world)(self.__qiangiq_paimon.unit)
        self.__qiangiq_paimon = nil
    end
end)

mod:hook(CLASS.UIProfileSpawner, "_despawn_current_character_profile", function(func, self, ...)
    local rec = self.__qiangiq_paimon
    if rec then
        ui_destroy_fn(self._world)(rec.unit)
        self.__qiangiq_paimon = nil
    end
    return func(self, ...)
end)

-- Refresh / toggles ------------------------------------------------------------

local function refresh_all()
    for ext in pairs(tracked) do
        if unit_ok(ext._unit) then
            ingame_apply(ext)
        end
    end
    for spawner in pairs(tracked_ui) do
        ui_apply(spawner)
    end
end

mod.toggle_paimon = function()
    local now = session_override
    if now == nil then
        now = opt("replace_skull") and true or false
    end
    session_override = not now
    refresh_all()
    mod:echo("Paimon %s", session_override and "on" or "off")
end

mod:command("paimon", "Toggle Paimon in place of your servo-skull: /paimon [debug]", function(which)
    if which == "debug" then
        local any = false
        for _, line in pairs(last_fit) do
            mod:echo(line)
            any = true
        end
        if not any then
            mod:echo("Paimon has not been fitted yet: play a character with a servo-skull companion first.")
        end
        return
    end
    mod.toggle_paimon()
end)

-- QIangIQsOrdis (2026-10-05) also replaces the servo-skull: switching one on switches the other off
-- (QIangIQsDiamondSword's SWORD_MODS pattern); both saved on: the later one in SKULL_MODS keeps it.
local SKULL_MODS = { "QIangIQsPaimon", "QIangIQsOrdis" }
local ME = "QIangIQsPaimon"

local function switch_others_off()
    for _, name in ipairs(SKULL_MODS) do
        if name ~= ME then
            local other = get_mod(name)
            if other and other:get("replace_skull") then
                other:set("replace_skull", false, true)
            end
        end
    end
end

local function resolve_at_load()
    local mine = false
    for _, name in ipairs(SKULL_MODS) do
        if name == ME then
            mine = true
        elseif mine then
            local other = get_mod(name)
            if other and other:get("replace_skull") and mod:get("replace_skull") then
                mod:set("replace_skull", false, false)
            end
        end
    end
end

mod.on_setting_changed = function(setting_id)
    if setting_id == "replace_skull" then
        session_override = nil
        if mod:get("replace_skull") then
            switch_others_off()
        end
    end
    fit_generation = fit_generation + 1
    refresh_all()
end

-- Package loading through Custom Assets --------------------------------------

mod.on_all_mods_loaded = function()
    resolve_at_load()
    custom_assets = get_mod("CustomAssets")
    if not custom_assets or not custom_assets.is_api_compatible or not custom_assets.is_api_compatible(1) then
        mod:error("Custom Assets (API 1) is missing. Install it and put it above QIangIQsPaimon in mod_load_order.txt.")
        return
    end
    local ticket, err = custom_assets.acquire(mod, PAIMON_ID, function(_, _, load_error)
        if load_error then
            mod:error("%s failed to load: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", PAIMON_ID, tostring(load_error))
            return
        end
        ready = true
        refresh_all()
    end, { resident = true, reference_name = PAIMON_ID })
    if not ticket then
        mod:error("%s could not be requested: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", PAIMON_ID, tostring(err))
    end
end

local function remove_all(restore)
    for ext in pairs(tracked) do
        local rec = ext.__qiangiq_paimon
        if rec then
            ingame_destroy(rec.unit)
            ext.__qiangiq_paimon = nil
            if restore and unit_ok(rec.companion) then
                Unit.set_unit_visibility(rec.companion, true, true)
            end
        end
    end
    for spawner in pairs(tracked_ui) do
        local rec = spawner.__qiangiq_paimon
        if rec then
            ui_destroy_fn(spawner._world)(rec.unit)
            spawner.__qiangiq_paimon = nil
            if restore and unit_ok(rec.companion) and spawner._visible then
                Unit.set_unit_visibility(rec.companion, true, true)
            end
        end
    end
end

mod.on_disabled = function()
    mod_on = false
    remove_all(true)
end

mod.on_enabled = function()
    mod_on = true
    refresh_all()
end

mod.on_unload = function()
    remove_all(false)
    if custom_assets and custom_assets.release_owner then
        custom_assets.release_owner(mod)
    end
end


-- Cross-client sync: what this mod publishes about me, and the refresh when anyone's options change ---------
local function sync_applies(info)
    return (mod:get("replace_skull") and true or false) and (info.companion_breed == nil or info.companion_breed == SKULL_BREED)
end

local sync_enabled = true
local function sync_changed()
    local api = sync_api()
    if api then
        api.changed()
    end
end

mod.sync_key = SYNC_KEY
-- info = { breed, companion_breed, templates = { [weapon_template] = true } } of my own character (fields nil
-- while I have no unit). Returns the array to publish, or nil when this mod shows nothing on my character.
mod.sync_export = function(info)
    info = info or {}
    if not sync_enabled or not sync_applies(info) then
        return nil
    end
    local mask, bit = 0, 1
    for i = 1, #SYNC_BOOLS do
        local key = SYNC_BOOLS[i]
        local v = mod:get(key)
        if v == nil then
            v = SYNC_DEFAULTS[key]
        end
        if v then
            mask = mask + bit
        end
        bit = bit * 2
    end
    local out = { SYNC_LAYOUT, mask }
    for i = 1, #SYNC_VALUES do
        local v = mod:get(SYNC_VALUES[i])
        if type(v) == "number" then
            v = math.floor(v * 100 + 0.5) / 100
        elseif type(v) ~= "string" then
            v = false -- not set: the reader falls back to its default
        end
        out[2 + i] = v
    end
    return out
end

mod.sync_refresh = function()
    for ext in pairs(sync_all) do
        if ext._unit and Unit.alive(ext._unit) and ext.force_update_item_visibility then
            pcall(ext.force_update_item_visibility, ext)
        end
    end
end

local sync_prev_setting_changed = mod.on_setting_changed
mod.on_setting_changed = function(...)
    if sync_prev_setting_changed then
        sync_prev_setting_changed(...)
    end
    sync_changed()
end

local sync_prev_disabled = mod.on_disabled
mod.on_disabled = function(...)
    sync_enabled = false
    if sync_prev_disabled then
        sync_prev_disabled(...)
    end
    sync_changed()
end

local sync_prev_enabled = mod.on_enabled
mod.on_enabled = function(...)
    sync_enabled = true
    if sync_prev_enabled then
        sync_prev_enabled(...)
    end
    sync_changed()
end
