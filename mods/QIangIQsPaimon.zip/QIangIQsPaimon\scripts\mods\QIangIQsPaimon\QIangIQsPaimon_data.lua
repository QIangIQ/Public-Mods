local mod = get_mod("QIangIQsPaimon")

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = true,
    options = {
        widgets = {
            {
                setting_id = "replace_skull",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "paimon_size",
                type = "numeric",
                default_value = 2,
                range = { 0.5, 6 },
                decimals_number = 1,
            },
            {
                setting_id = "paimon_height",
                type = "numeric",
                default_value = 0,
                range = { -2, 2 },
                decimals_number = 2,
            },
            {
                setting_id = "paimon_turn",
                type = "numeric",
                default_value = 0,
                range = { -180, 180 },
                decimals_number = 0,
            },
            {
                setting_id = "menu_previews",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "toggle_keybind",
                type = "keybind",
                default_value = {},
                keybind_trigger = "pressed",
                keybind_type = "function_call",
                function_name = "toggle_paimon",
            },
        },
    },
}
