return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsPaimon` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsPaimon", {
            mod_script = "QIangIQsPaimon/scripts/mods/QIangIQsPaimon/QIangIQsPaimon",
            mod_data = "QIangIQsPaimon/scripts/mods/QIangIQsPaimon/QIangIQsPaimon_data",
            mod_localization = "QIangIQsPaimon/scripts/mods/QIangIQsPaimon/QIangIQsPaimon_localization",
        })
    end,
    version = "1.1.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
