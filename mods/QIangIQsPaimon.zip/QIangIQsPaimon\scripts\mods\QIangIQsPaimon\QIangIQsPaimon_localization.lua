return {
    mod_name = {
        en = "QIangIQ's Paimon",
    },
    mod_description = {
        en = "Shows Paimon (Custom Assets) in place of your own companion servo-skull. By QIangIQ.",
    },
    replace_skull = {
        en = "Replace your servo-skull with Paimon",
    },
    replace_skull_description = {
        en = "Companion breed companion_servo_skull, your own companion only. Chat command: /paimon",
    },
    paimon_size = {
        en = "Size (x servo-skull)",
    },
    paimon_size_description = {
        en = "Paimon's height as a multiple of the servo-skull's largest dimension.",
    },
    paimon_height = {
        en = "Height offset (x servo-skull)",
    },
    paimon_height_description = {
        en = "Moves Paimon up (+) or down (-), in servo-skull sizes. 0 = centred on the skull.",
    },
    paimon_turn = {
        en = "Turn (degrees)",
    },
    paimon_turn_description = {
        en = "Turns Paimon left/right relative to the direction the servo-skull faces.",
    },
    menu_previews = {
        en = "Show in menus (operative previews)",
    },
    menu_previews_description = {
        en = "Also swaps the servo-skull shown with your own operatives in menu previews.",
    },
    toggle_keybind = {
        en = "Toggle Paimon",
    },
}
