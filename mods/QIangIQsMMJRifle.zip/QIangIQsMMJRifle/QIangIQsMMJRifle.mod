return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsMMJRifle` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsMMJRifle", {
            mod_script = "QIangIQsMMJRifle/scripts/mods/QIangIQsMMJRifle/QIangIQsMMJRifle",
            mod_data = "QIangIQsMMJRifle/scripts/mods/QIangIQsMMJRifle/QIangIQsMMJRifle_data",
            mod_localization = "QIangIQsMMJRifle/scripts/mods/QIangIQsMMJRifle/QIangIQsMMJRifle_localization",
        })
    end,
    version = "0.1.0",
    author = "QIangIQ",
    packages = {},
}
