-- QIangIQsMMJRifle per-weapon data (gen.py spec rifle). Clips are MMJ clip names from rifle\OBJ-Weapond-Rifle Std lv1__22659.
-- Action map sources: Darktide weapon templates (Aussiemon master) via tools\dump_actions.py.
return {
    ranged = true,
    idle = "rifle-idle",
    templates = { autogun_p1_m1 = true, autogun_p1_m2 = true, autogun_p1_m3 = true },
    shot = { clips = { "rifle-shot-repeat", "rifle-shot-recover" }, sounds = { "sfx_wp_rifle_shot_01.ogg", "sfx_wp_rifle_shot_02.ogg", "sfx_wp_rifle_shot_03.ogg", "sfx_wp_rifle_shot_04.ogg", "sfx_wp_rifle_shot_05.ogg" } },
    actions = {
        action_wield = { clips = { "rifle-fastintro new" }, over_shot = true, sounds = { "sfx_wp_rifle_intro.ogg" } },
        action_reload = { clips = { "rifle-reload" }, stretch = true, reload_template = true, over_shot = true, sounds = { "sfx_wp_rifle_reload.ogg" } },
    },
}
