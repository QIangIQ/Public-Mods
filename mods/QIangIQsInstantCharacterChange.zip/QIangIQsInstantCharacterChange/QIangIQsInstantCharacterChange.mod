return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsInstantCharacterChange` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsInstantCharacterChange", {
			mod_script       = "QIangIQsInstantCharacterChange/scripts/mods/QIangIQsInstantCharacterChange/QIangIQsInstantCharacterChange",
			mod_data         = "QIangIQsInstantCharacterChange/scripts/mods/QIangIQsInstantCharacterChange/QIangIQsInstantCharacterChange_data",
			mod_localization = "QIangIQsInstantCharacterChange/scripts/mods/QIangIQsInstantCharacterChange/QIangIQsInstantCharacterChange_localization",
		})
	end,
	packages = {},
}
