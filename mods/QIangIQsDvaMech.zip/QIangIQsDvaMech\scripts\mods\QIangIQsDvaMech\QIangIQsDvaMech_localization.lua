return {
    mod_name = {
        en = "QIangIQ's D.Va Mech",
    },
    mod_description = {
        en = "Replaces your own Ogryn with the D.Va mech model (Custom Assets): third person, first-person arms and menu previews. Only one QIangIQ Ogryn model is shown at a time. By QIangIQ.",
    },
    model_enabled = {
        en = "Show the D.Va Mech model",
    },
    model_enabled_description = {
        en = "Turning this on switches the other QIangIQ Ogryn models off. Chat command: /dvamech",
    },
    hide_body = {
        en = "Hide original body and cosmetics",
    },
    hide_body_description = {
        en = "Hides your character's body, face, hair and gear slots while the model is shown. Weapons stay visible.",
    },
    first_person_arms = {
        en = "Model arms in first person",
    },
    first_person_arms_description = {
        en = "Replaces the first-person arms and gloves with the model's arms.",
    },
    menu_previews = {
        en = "Show in menus (operative select, inventory)",
    },
    menu_previews_description = {
        en = "Shows the model on your own operatives in menu previews. Other players' characters are left alone. Only Ogryns are replaced; human characters are left alone.",
    },
    toggle_keybind = {
        en = "Toggle D.Va Mech model",
    },
}
