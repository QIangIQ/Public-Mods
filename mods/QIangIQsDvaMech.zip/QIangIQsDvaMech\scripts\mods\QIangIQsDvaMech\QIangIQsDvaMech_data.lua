local mod = get_mod("QIangIQsDvaMech")

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = true,
    options = {
        widgets = {
            {
                setting_id = "model_enabled",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "hide_body",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "first_person_arms",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "menu_previews",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "toggle_keybind",
                type = "keybind",
                default_value = {},
                keybind_trigger = "pressed",
                keybind_type = "function_call",
                function_name = "toggle_model",
            },
        },
    },
}
