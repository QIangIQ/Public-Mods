return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsDvaMech` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsDvaMech", {
            mod_script = "QIangIQsDvaMech/scripts/mods/QIangIQsDvaMech/QIangIQsDvaMech",
            mod_data = "QIangIQsDvaMech/scripts/mods/QIangIQsDvaMech/QIangIQsDvaMech_data",
            mod_localization = "QIangIQsDvaMech/scripts/mods/QIangIQsDvaMech/QIangIQsDvaMech_localization",
        })
    end,
    version = "1.2.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
