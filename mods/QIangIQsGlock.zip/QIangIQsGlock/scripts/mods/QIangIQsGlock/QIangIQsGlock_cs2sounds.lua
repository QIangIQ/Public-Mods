return {
    clips = {
        draw = { { 0.0000, "Weapon_Glock.Draw" }, { 0.3000, "Weapon_Glock.Slideback_Q" }, { 0.5000, "Weapon_Glock.Sliderelease_Q" } },
        reload = { { 0.4667, "Weapon_Glock.Clipout" }, { 0.8334, "Weapon_Glock.Clipin" }, { 1.4667, "Weapon_Glock.Slideback" }, { 1.6667, "Weapon_Glock.Sliderelease" } },
        reload_empty = { { 0.4667, "Weapon_Glock.Clipout" }, { 1.1334, "Weapon_Glock.Clipin" }, { 1.5334, "Weapon_Glock.Sliderelease" } },
    },
    events = {
        ["Weapon_Glock.Clipin"] = { v = 0.6, files = { "weapons/glock18/glock_clipin.wav" } },
        ["Weapon_Glock.Clipout"] = { v = 0.6, files = { "weapons/glock18/glock_clipout.wav" } },
        ["Weapon_Glock.Draw"] = { v = 0.3, files = { "weapons/glock18/glock_draw.wav" } },
        ["Weapon_Glock.Single"] = { v = 1, files = { "weapons/glock18/glock_02.wav" } },
        ["Weapon_Glock.Slideback"] = { v = 0.6, files = { "weapons/glock18/glock_slideback.wav" } },
        ["Weapon_Glock.Slideback_Q"] = { v = 0.5, files = { "weapons/glock18/glock_slideback.wav" } },
        ["Weapon_Glock.Sliderelease"] = { v = 0.7, files = { "weapons/glock18/glock_sliderelease.wav" } },
        ["Weapon_Glock.Sliderelease_Q"] = { v = 0.7, files = { "weapons/glock18/glock_sliderelease.wav" } },
    },
}
