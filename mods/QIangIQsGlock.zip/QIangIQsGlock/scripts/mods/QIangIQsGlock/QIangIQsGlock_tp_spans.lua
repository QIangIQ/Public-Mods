-- seconds of each CS2 clip in Custom/gl_tp_driver (tp_bake_cs2.py, 401 frames at 30 fps)
return {
    draw = { start = 0.0000, length = 1.0000 },
    shoot1 = { start = 1.1000, length = 0.4000 },
    shoot_empty = { start = 1.6000, length = 0.4000 },
    reload = { start = 2.1000, length = 2.2667 },
    reload_empty = { start = 4.4667, length = 2.2667 },
    lookat01 = { start = 6.8333, length = 6.4333 },
}
