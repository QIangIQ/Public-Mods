return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsGlock` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsGlock", {
            mod_script = "QIangIQsGlock/scripts/mods/QIangIQsGlock/QIangIQsGlock",
            mod_data = "QIangIQsGlock/scripts/mods/QIangIQsGlock/QIangIQsGlock_data",
            mod_localization = "QIangIQsGlock/scripts/mods/QIangIQsGlock/QIangIQsGlock_localization",
        })
    end,
    version = "1.1.11",
    author = "QIangIQ",
    load_after = { "CustomAssets" },
    packages = {},
}
