return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsValkyrHeirloom` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsValkyrHeirloom", {
            mod_script = "QIangIQsValkyrHeirloom/scripts/mods/QIangIQsValkyrHeirloom/QIangIQsValkyrHeirloom",
            mod_data = "QIangIQsValkyrHeirloom/scripts/mods/QIangIQsValkyrHeirloom/QIangIQsValkyrHeirloom_data",
            mod_localization = "QIangIQsValkyrHeirloom/scripts/mods/QIangIQsValkyrHeirloom/QIangIQsValkyrHeirloom_localization",
        })
    end,
    version = "1.0.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
