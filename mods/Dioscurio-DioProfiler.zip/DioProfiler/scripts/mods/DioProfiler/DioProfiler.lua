--[[
    Dio's Frame Profiler 2.0

    Answers one question: which mod costs how many milliseconds per frame.

    HOW IT MEASURES
      * every mod's mod.update (dmf.mods)
      * every DMF hook, hook_safe and hook_origin that is registered AFTER this
        mod loads - so this mod has to be the FIRST line of mod_load_order.txt.
        DMFMod.hook / hook_safe / hook_origin are wrapped; each handler is
        timed on its own ("self" time): the time spent further down the hook
        chain, in the game's original function or in another mod's hook, is
        taken off and booked to whoever spent it.
      * every HUD element's update and draw (the game's and the mods'), per
        instance, so a heavy element shows up by name.

    Entries named "(game) Class.method" are the game's own functions, seen
    only where a mod hooks them. They are there for scale, not to be fixed.

    Times come from the engine's performance counter when it is there.

    Reports go to the console log every "report_seconds"; /dioprof prints the
    current one to chat. Switch the mod off in Mod Options and the wrappers
    reduce to one flag test each.
--]]
local mod = get_mod("DioProfiler")
-- The engine's performance counter (the one settings_utils.lua times itself with) has sub-millisecond
-- resolution; os.clock on Windows does not. os.clock stays as the fallback.
local clock = os.clock
do
	local app = rawget(_G, "Application")
	if app and app.query_performance_counter and app.time_since_query then
		local ok, counter = pcall(app.query_performance_counter)
		if ok and counter and pcall(app.time_since_query, counter) then
			clock = function()
				return app.time_since_query(counter) * 0.001
			end
		end
	end
end

local G = rawget(_G, "__dio_prof_state") or { orig = {} }
rawset(_G, "__dio_prof_state", G)
G.on = false

local by_mod, by_hook = {}, {}
local child = {}
local depth = 0
local frames, elapsed, worst, slow = 0, 0, 0, 0

local function finish(mod_name, key, t0, ...)
	if depth < 1 then
		return ...
	end
	local el = clock() - t0
	local self_t = el - child[depth]
	depth = depth - 1
	if depth > 0 then
		child[depth] = child[depth] + el
	end
	by_mod[mod_name] = (by_mod[mod_name] or 0) + self_t
	by_hook[key] = (by_hook[key] or 0) + self_t
	return ...
end

local function timed(mod_name, key, f)
	return function(...)
		if not G.on then
			return f(...)
		end
		depth = depth + 1
		child[depth] = 0
		return finish(mod_name, key, clock(), f(...))
	end
end

-- a normal hook gets the rest of the chain as its first argument; that is timed as a child
local function timed_hook(mod_name, key, game_key, handler)
	local inner = setmetatable({}, { __mode = "k" })
	return function(func, ...)
		if not G.on then
			return handler(func, ...)
		end
		local wf = inner[func]
		if not wf then
			wf = timed("(game)", game_key, func)
			inner[func] = wf
		end
		depth = depth + 1
		child[depth] = 0
		return finish(mod_name, key, clock(), handler(wf, ...))
	end
end

local function obj_name(obj)
	if type(obj) == "string" then
		return obj
	end
	if type(obj) == "table" then
		local ok, name = pcall(rawget, obj, "__class_name")
		return ok and type(name) == "string" and name or "table"
	end
	return type(obj)
end

local function wrap_dmf()
	local cls = rawget(_G, "DMFMod")
	if type(cls) ~= "table" then
		mod:echo("DioProfiler: DMFMod not found, hooks will not be timed")
		return
	end
	for _, kind in ipairs({ "hook", "hook_safe", "hook_origin" }) do
		local orig = G.orig[kind] or cls[kind]
		G.orig[kind] = orig
		cls[kind] = function(self, obj, method, handler)
			local ok, name = pcall(self.get_name, self)
			name = ok and name or "?"
			local suffix = kind == "hook_safe" and " [safe]" or kind == "hook_origin" and " [origin]" or ""
			if handler == nil and type(method) == "function" then
				-- global function form: mod:hook("name", handler)
				local label = "_G." .. tostring(obj)
				if kind == "hook" then
					method = timed_hook(name, name .. ": " .. label, "(game) " .. label, method)
				else
					method = timed(name, name .. ": " .. label .. suffix, method)
				end
			elseif type(handler) == "function" then
				local label = obj_name(obj) .. "." .. tostring(method)
				if kind == "hook" then
					handler = timed_hook(name, name .. ": " .. label, "(game) " .. label, handler)
				else
					handler = timed(name, name .. ": " .. label .. suffix, handler)
				end
			end
			return orig(self, obj, method, handler)
		end
	end
end

wrap_dmf()

-- mod.update of every mod; checked again now and then because some mods assign it late
local update_wrappers = setmetatable({}, { __mode = "k" })

local function wrap_mod_updates()
	local dmf = get_mod("DMF")
	local mods = dmf and dmf.mods
	if not mods then
		return
	end
	for name, m in pairs(mods) do
		if name ~= "DioProfiler" and type(m) == "table" then
			local f = rawget(m, "update")
			if type(f) == "function" and update_wrappers[m] ~= f then
				local w = timed(name, name .. ": mod.update", f)
				update_wrappers[m] = w
				m.update = w
			end
		end
	end
end

local function wrap_elements(list)
	if type(list) ~= "table" then
		return
	end
	for _, el in pairs(list) do
		if type(el) == "table" and not rawget(el, "__dio_prof") then
			local name = "HUD " .. tostring(el.__class_name)
			for _, m in ipairs({ "update", "draw" }) do
				local f = el[m]
				if type(f) == "function" then
					el[m] = timed(name, name .. "." .. m, f)
				end
			end
			rawset(el, "__dio_prof", true)
		end
	end
end

local function wrap_hud()
	local ui = Managers and Managers.ui
	if not ui then
		return
	end
	local hud = rawget(ui, "_hud")
	if hud then
		wrap_elements(rawget(hud, "_elements_array"))
	end
	local constant = rawget(ui, "_ui_constant_elements")
	if constant then
		wrap_elements(rawget(constant, "_elements"))
	end
end

local function top(tbl, n, lines, width)
	local rows = {}
	for name, total in pairs(tbl) do
		rows[#rows + 1] = { name, total * 1000 / frames }
	end
	table.sort(rows, function(a, b) return a[2] > b[2] end)
	local sum = 0
	for i = 1, #rows do
		if rows[i][1] ~= "(game)" then
			sum = sum + rows[i][2]
		end
	end
	for i = 1, math.min(n, #rows) do
		lines[#lines + 1] = string.format("%2d. %-" .. width .. "s %6.3f ms/frame", i, rows[i][1], rows[i][2])
	end
	return sum
end

local function report(to_chat)
	if frames == 0 then
		return
	end
	local head = string.format("[DioProfiler2] %d frames, %.0f s, %.1f fps avg, worst frame %.0f ms, %d frames over 33 ms",
		frames, elapsed, frames / math.max(elapsed, 0.001), worst * 1000, slow)
	local lines = { "-- by mod (self time, hooks + update + HUD elements)" }
	local sum = top(by_mod, 45, lines, 44)
	lines[#lines + 1] = string.format("-- everything measured except (game): %.2f ms/frame", sum)
	lines[#lines + 1] = "-- by hook"
	top(by_hook, 35, lines, 70)
	mod:info("%s\n%s", head, table.concat(lines, "\n"))
	if to_chat then
		mod:echo("%s\n%s", head, table.concat(lines, "\n", 1, math.min(14, #lines)))
	end
end

local function reset()
	by_mod, by_hook = {}, {}
	frames, elapsed, worst, slow = 0, 0, 0, 0
end

local scan = 0
local total = 0
local AUTO_STOP = 40 * 60 -- the wrappers cost frames themselves, so timing stops on its own after 40 minutes

mod.on_all_mods_loaded = function()
	G.on = mod:is_enabled()
	wrap_mod_updates()
end

mod.on_enabled = function()
	G.on = true
	total = 0
	reset()
end

mod.on_disabled = function()
	G.on = false
end

mod.on_unload = function()
	G.on = false
end

mod.update = function(dt)
	depth = 0 -- a handler that errored leaves frames behind; start clean every frame
	if not G.on then
		return
	end
	dt = dt or 0
	frames = frames + 1
	elapsed = elapsed + dt
	if dt > worst then
		worst = dt
	end
	if dt > 0.0333 then
		slow = slow + 1
	end
	total = total + dt
	if total > AUTO_STOP then
		report(false)
		reset()
		G.on = false
		mod:echo("DioProfiler: 40 minutes captured, timing is now off. /dioprof_on starts another run.")
		return
	end
	scan = scan - dt
	if scan <= 0 then
		scan = 2
		wrap_mod_updates()
		wrap_hud()
	end
	if elapsed >= (mod:get("report_seconds") or 60) then
		report(false)
		reset()
	end
end

mod:command("dioprof", "Show the heaviest mods per frame so far", function()
	if not G.on then
		mod:echo("DioProfiler: timing is off. /dioprof_on starts a run.")
	end
	report(true)
end)

mod:command("dioprof_on", "Start another 40 minute profiling run", function()
	total = 0
	reset()
	G.on = true
	mod:echo("DioProfiler: timing for the next 40 minutes.")
end)
