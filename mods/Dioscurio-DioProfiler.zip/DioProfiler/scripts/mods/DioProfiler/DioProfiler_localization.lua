return {
	mod_name = { en = "Dio's Frame Profiler" },
	mod_description = { en = "Measures how long each mod's per-frame update takes and writes the top 15 to the console log (and /dioprof in chat). For finding FPS costs; switch off when done." },
	report_seconds = { en = "Report every (seconds)" },
}
