local mod = get_mod("DioProfiler")
return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = { widgets = {
		{ setting_id = "report_seconds", type = "numeric", default_value = 60, range = { 10, 300 }, decimals_number = 0 },
	} },
}
