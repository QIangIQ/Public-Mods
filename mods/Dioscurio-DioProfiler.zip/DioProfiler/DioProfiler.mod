return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`DioProfiler` encountered an error loading the Darktide Mod Framework.")
		new_mod("DioProfiler", {
			mod_script       = "DioProfiler/scripts/mods/DioProfiler/DioProfiler",
			mod_data         = "DioProfiler/scripts/mods/DioProfiler/DioProfiler_data",
			mod_localization = "DioProfiler/scripts/mods/DioProfiler/DioProfiler_localization",
		})
	end,
	version = "2.0.0",
	author = "Dioscurio",
	packages = {},
}
