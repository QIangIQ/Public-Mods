# QIangIQsMortisHavocBuffs

The host picks Mortis Trials buffs (Indulgences) that players get in Havoc missions, including Havoc hosted through Realms or SoloPlay.

## Picking buffs
- Mod options, "Mortis buffs": 8 slot dropdowns listing every Mortis buff by template name.
- Chat, any number of buffs:
  - `/mhb_list [filter]` lists every buff with its number, in-game title and name (legendaries marked).
  - `/mhb_add <number or name>`, `/mhb_remove <number or name>`, `/mhb_clear`
  - `/mhb_show` shows what is selected.
  - `/mhb_apply` (host, in a Havoc mission) gives the selection to players already spawned.
- "Give buffs to": everyone / humans only / host only.

## How it works
- Buffs are added with `add_internally_controlled_buff` on every player spawn, inside Havoc's own `GameModeExtensionHavoc._on_player_unit_spawned` (game_mode_extension_havoc.lua 308-324), right after Havoc's own player buffs. So they come back after a respawn, just like Havoc's.
- Only the host adds buffs: SoloPlay singleplay, or a Realms session where this machine is the host, with a server game session (host test from ChaosWastesAtHome).
- Buff list read from the game (`mission_buffs_allowed_buffs`), the same list RickAndMortis offers.

## Crash guard
Some Mortis buffs play effects that ship only with Mortis Trials content. "Guard missing buff effects" (on) makes a missing effect show nothing instead of crashing, during Havoc only (ChaosWastesAtHome's particle guard). **Every player in the lobby should run this mod** so their game has the guard too.
"Load Mortis assets" (off) loads the Mortis mission package so the effects really show; it is a whole level package, so it costs memory.

## Limits
- Legendary buffs only work for the class and ability they belong to.
- Some Mortis buffs may rely on Mortis-only systems (waves) and do nothing in Havoc. Test them one at a time.
- Not tested in-game yet, only with a mock harness.
