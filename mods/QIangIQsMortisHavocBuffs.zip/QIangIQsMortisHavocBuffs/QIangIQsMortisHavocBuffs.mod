return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsMortisHavocBuffs` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsMortisHavocBuffs", {
			mod_script       = "QIangIQsMortisHavocBuffs/scripts/mods/QIangIQsMortisHavocBuffs/QIangIQsMortisHavocBuffs",
			mod_data         = "QIangIQsMortisHavocBuffs/scripts/mods/QIangIQsMortisHavocBuffs/QIangIQsMortisHavocBuffs_data",
			mod_localization = "QIangIQsMortisHavocBuffs/scripts/mods/QIangIQsMortisHavocBuffs/QIangIQsMortisHavocBuffs_localization",
		})
	end,
	packages = {},
}
