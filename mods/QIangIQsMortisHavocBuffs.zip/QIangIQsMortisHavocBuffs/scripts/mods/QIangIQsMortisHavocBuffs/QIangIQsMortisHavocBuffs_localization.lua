local localization = {
	mod_name = {
		en = "QIangIQ's Mortis Havoc Buffs",
	},
	mod_description = {
		en = "Host picks Mortis Trials buffs (Indulgences) that players get in Havoc missions, including Realms-hosted Havoc. Pick up to 8 in the slots below, or any number with /mhb_list and /mhb_add. Buffs are given on every spawn, like Havoc's own player buffs.",
	},
	apply_to = {
		en = "Give buffs to",
	},
	apply_to_tooltip = {
		en = "Everyone: all players and bots.\nHumans only: no bots.\nHost only: just you.",
	},
	apply_all = {
		en = "Everyone",
	},
	apply_humans = {
		en = "Humans only",
	},
	apply_host = {
		en = "Host only",
	},
	slots_group = {
		en = "Mortis buffs",
	},
	slot_tooltip = {
		en = "A Mortis buff every chosen player gets in Havoc. Names are the game's buff template names; /mhb_list shows their in-game titles. Legendary buffs only work for the class and ability they belong to.",
	},
	guard_particles = {
		en = "Guard missing buff effects",
	},
	guard_particles_tooltip = {
		en = "Some Mortis buffs play effects that only load in Mortis Trials. On: in Havoc, a missing effect shows nothing instead of crashing. Every player should run this mod with this on.",
	},
	preload_mortis_assets = {
		en = "Load Mortis assets",
	},
	preload_mortis_assets_tooltip = {
		en = "Loads the Mortis Trials mission package during Havoc so buff effects are really shown. It is a whole level package, so memory and load time go up. Off by default.",
	},
	debug_log = {
		en = "Debug log",
	},
	cmd_list = {
		en = "List Mortis buffs: /mhb_list [filter]",
	},
	cmd_add = {
		en = "Add a Mortis buff: /mhb_add <number or name>",
	},
	cmd_remove = {
		en = "Remove a chat-added Mortis buff: /mhb_remove <number or name>",
	},
	cmd_clear = {
		en = "Clear chat-added Mortis buffs",
	},
	cmd_show = {
		en = "Show the selected Mortis buffs",
	},
	cmd_apply = {
		en = "Host: give the selected Mortis buffs to players already in the Havoc mission",
	},
}

for i = 1, 8 do
	localization["slot_" .. i] = {
		en = "Buff slot " .. i,
	}
end

return localization
