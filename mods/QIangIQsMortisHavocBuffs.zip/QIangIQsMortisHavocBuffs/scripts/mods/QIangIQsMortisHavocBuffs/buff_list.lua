-- The selectable Mortis Trials buffs, read from the game at runtime.
--
-- Same list RickAndMortis offers (RickAndMortis shared.lua:74-111,
-- get_all_hordes_buffs_names): every buff_families[*].priority_buffs and
-- .buffs entry plus every name under legendary_buffs, sorted.
--
-- Require order copied from ChaosWastesAtHome buff_registry.lua:3-14:
-- BuffTemplates first, so the hordes modules are already in package.loaded
-- when the rest are asked for, instead of this mod being their first loader
-- during boot.

local M = {}

local function load_modules()
	local ok_templates = pcall(require, "scripts/settings/buff/buff_templates")
	local ok_data, HordesBuffsData = pcall(require, "scripts/settings/buff/hordes_buffs/hordes_buffs_data")
	local ok_allowed, MissionBuffsAllowedBuffs = pcall(require, "scripts/managers/mission_buffs/mission_buffs_allowed_buffs")

	if not ok_templates or not ok_data or not ok_allowed
		or type(HordesBuffsData) ~= "table" or type(MissionBuffsAllowedBuffs) ~= "table" then
		return nil, nil
	end

	return HordesBuffsData, MissionBuffsAllowedBuffs
end

local function fill_recursive(source, destination)
	for _, content in pairs(source) do
		if type(content) == "table" then
			fill_recursive(content, destination)
		elseif type(content) == "string" then
			destination[content] = true
		end
	end
end

local cache

--- @return table|nil sorted buff names, table|nil set of legendary names
function M.all()
	if cache then
		return cache.names, cache.legendary
	end

	local HordesBuffsData, MissionBuffsAllowedBuffs = load_modules()

	if not MissionBuffsAllowedBuffs then
		return nil, nil
	end

	local used = {}

	for _, family in pairs(MissionBuffsAllowedBuffs.buff_families or {}) do
		for _, buff_name in pairs(family.priority_buffs or {}) do
			used[buff_name] = true
		end

		for _, buff_name in pairs(family.buffs or {}) do
			used[buff_name] = true
		end
	end

	local legendary = {}

	fill_recursive(MissionBuffsAllowedBuffs.legendary_buffs or {}, legendary)

	for buff_name in pairs(legendary) do
		used[buff_name] = true
	end

	local names = {}

	for buff_name in pairs(used) do
		names[#names + 1] = buff_name
	end

	table.sort(names)

	cache = { names = names, legendary = legendary, data = HordesBuffsData }

	return names, legendary
end

--- Display title, the way RickAndMortis builds it (shared.lua:59).
function M.title(buff_name)
	M.all()

	local data = cache and cache.data and cache.data[buff_name]

	if not data or not data.title or data.title == "" then
		return buff_name
	end

	local ok, text = pcall(Localize, data.title)

	if not ok or type(text) ~= "string" or string.sub(text, 1, 1) == "<" then
		return buff_name
	end

	return text
end

--- True for a name in the Mortis list (RickAndMortis checks
-- MissionBuffsData[buff_name] before adding, shared.lua:55-56).
function M.is_known(buff_name)
	M.all()

	return cache ~= nil and cache.data ~= nil and cache.data[buff_name] ~= nil
end

return M
