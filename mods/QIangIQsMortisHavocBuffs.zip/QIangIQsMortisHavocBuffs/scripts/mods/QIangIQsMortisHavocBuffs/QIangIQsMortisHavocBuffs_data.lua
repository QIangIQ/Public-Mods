local mod = get_mod("QIangIQsMortisHavocBuffs")

local SLOT_COUNT = 8

-- Dropdown of every Mortis buff by its template name. Built fresh per widget
-- (ChaosWastesAtHome_data.lua:3-6: DMF localizes dropdown options in place),
-- and marked localize = false like QIangIQsUltraHavoc's condition list, since
-- the names come from the game, not from the localization file.
local function buff_options()
	local options = {
		localize = false,
		{ text = "-", value = "none" },
	}

	local ok, buff_list = pcall(mod.io_dofile, mod, "QIangIQsMortisHavocBuffs/scripts/mods/QIangIQsMortisHavocBuffs/buff_list")
	local names = ok and type(buff_list) == "table" and buff_list.all() or nil

	for i = 1, names and #names or 0 do
		options[#options + 1] = { text = names[i], value = names[i] }
	end

	return options
end

local slot_widgets = {}

for i = 1, SLOT_COUNT do
	slot_widgets[#slot_widgets + 1] = {
		setting_id = "slot_" .. i,
		type = "dropdown",
		default_value = "none",
		options = buff_options(),
		tooltip = "slot_tooltip",
	}
end

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			{
				setting_id = "apply_to",
				type = "dropdown",
				default_value = "all",
				options = {
					{ text = "apply_all", value = "all" },
					{ text = "apply_humans", value = "humans" },
					{ text = "apply_host", value = "host" },
				},
				tooltip = "apply_to_tooltip",
			},
			{
				setting_id = "slots_group",
				type = "group",
				sub_widgets = slot_widgets,
			},
			{
				setting_id = "guard_particles",
				type = "checkbox",
				default_value = true,
				tooltip = "guard_particles_tooltip",
			},
			{
				setting_id = "preload_mortis_assets",
				type = "checkbox",
				default_value = false,
				tooltip = "preload_mortis_assets_tooltip",
			},
			{
				setting_id = "debug_log",
				type = "checkbox",
				default_value = false,
			},
		},
	},
}
