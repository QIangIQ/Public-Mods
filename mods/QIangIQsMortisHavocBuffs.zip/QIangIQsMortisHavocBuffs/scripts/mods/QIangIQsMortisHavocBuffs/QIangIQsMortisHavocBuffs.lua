local mod = get_mod("QIangIQsMortisHavocBuffs")

-- QIangIQsMortisHavocBuffs
--
-- The host picks Mortis Trials buffs (Indulgences); every player gets them in
-- Havoc missions, including Havoc hosted through Realms.
--
-- How it grants them: Havoc already hands out its own player buffs on every
-- player spawn, in GameModeExtensionHavoc._on_player_unit_spawned
-- (game_mode_extension_havoc.lua:308-324, registered at line 18):
--     buff_extension:add_internally_controlled_buff(buff, Managers.time:time("gameplay"))
-- This mod hooks that function (the same class SoloPlay hooks,
-- SoloPlay workarounds/havoc.lua:2,8) and adds the selected buffs with the
-- same call, after the game's own. It runs on every spawn, so buffs come back
-- after a death and respawn the same way Havoc's own do.
-- The call is RickAndMortis's too (shared.lua:39-53); RickAndMortis only
-- works on the local player in the Psykhanium (RickAndMortis.lua:80-82).
--
-- Only the host adds buffs. Host test copied from ChaosWastesAtHome
-- (_session_role, ChaosWastesAtHome.lua:760-800, and has_authority, :120-134):
-- SoloPlay singleplay, or a Realms session (HOST_TYPES.player) where
-- Managers.connection:is_host(), and in both cases a game session that
-- reports is_server().
--
-- Crash guard: several Mortis buffs spawn particle effects that ship with the
-- Mortis mission content, and World.create_particles raises "Particle effect
-- not loaded" in a normal mission (ChaosWastesAtHome particle_guard.lua:3-13).
-- The guard below is ChaosWastesAtHome's (particle_guard.lua:24-117), scoped
-- to Havoc missions while this mod is active. Every player that can see the
-- effects needs it, so clients should run this mod too.
-- Optional: load the Mortis mission package like ChaosWastesAtHome
-- asset_loader.lua (off by default there too, it is a whole level package).

local MatchmakingConstants = require("scripts/settings/network/matchmaking_constants")
local GameModeExtensionHavoc = require("scripts/managers/game_mode/game_mode_extensions/game_mode_extension_havoc")
local HOST_TYPES = MatchmakingConstants.HOST_TYPES

local buff_list = mod:io_dofile("QIangIQsMortisHavocBuffs/scripts/mods/QIangIQsMortisHavocBuffs/buff_list")

local SLOT_COUNT = 8
local EXTRA_SETTING = "extra_buffs"
local HORDE_PACKAGE = "content/levels/horde/missions/mission_psykhanium"
local PACKAGE_REFERENCE = "QIangIQsMortisHavocBuffs"

-- True while a Havoc mission is running (set on GameplayStateRun enter).
mod._in_havoc = false

-- ---------------------------------------------------------------------------
-- Host test
-- ---------------------------------------------------------------------------

local function is_host()
	local session_manager = Managers.multiplayer_session

	if not session_manager then
		return false
	end

	local ok, host_type = pcall(session_manager.host_type, session_manager)

	if not ok then
		return false
	end

	if host_type == HOST_TYPES.singleplay then
		return true
	end

	if host_type ~= HOST_TYPES.player then
		return false
	end

	local connection = Managers.connection
	local host_ok, host = false, false

	if connection then
		host_ok, host = pcall(connection.is_host, connection)
	end

	return host_ok and host == true
end

local function has_authority()
	if not is_host() then
		return false
	end

	local game_session = Managers.state and Managers.state.game_session

	if not game_session then
		return false
	end

	local ok, is_server = pcall(game_session.is_server, game_session)

	return ok and is_server == true
end

local function in_havoc()
	local difficulty = Managers.state and Managers.state.difficulty

	if not difficulty or not difficulty.get_parsed_havoc_data then
		return false
	end

	local ok, data = pcall(difficulty.get_parsed_havoc_data, difficulty)

	return ok and data ~= nil
end

-- ---------------------------------------------------------------------------
-- Selection
-- ---------------------------------------------------------------------------

local function extra_buffs()
	local extra = mod:get(EXTRA_SETTING)

	return type(extra) == "table" and extra or {}
end

--- Slot dropdowns first, then the chat-added list; duplicates dropped.
local function selected_buffs()
	local seen, result = {}, {}

	local function add(name)
		if type(name) == "string" and name ~= "none" and not seen[name] then
			seen[name] = true
			result[#result + 1] = name
		end
	end

	for i = 1, SLOT_COUNT do
		add(mod:get("slot_" .. i))
	end

	local extra = extra_buffs()

	for i = 1, #extra do
		add(extra[i])
	end

	return result
end

local function player_wanted(player)
	local mode = mod:get("apply_to") or "all"

	if mode == "all" then
		return true
	end

	if mode == "humans" then
		return player.is_human_controlled and player:is_human_controlled() or false
	end

	local local_player = Managers.player and Managers.player:local_player(1)

	return player == local_player
end

-- ---------------------------------------------------------------------------
-- Grant
-- ---------------------------------------------------------------------------

-- Buffs already given to a unit, so "apply now" never stacks a second copy.
-- A respawn is a new unit, so it starts empty again.
local given = setmetatable({}, { __mode = "k" })

local function give(player)
	local unit = player and player.player_unit

	if not unit or not ALIVE[unit] then
		return 0
	end

	local buff_extension = ScriptUnit.has_extension(unit, "buff_system")

	if not buff_extension then
		return 0
	end

	local unit_given = given[unit] or {}
	given[unit] = unit_given

	local t = Managers.time:time("gameplay")
	local buffs = selected_buffs()
	local count = 0

	for i = 1, #buffs do
		local name = buffs[i]

		-- is_valid_target is the check MutatorBase makes before adding a
		-- buff (mutator_base.lua:116-118).
		if not unit_given[name] and buff_list.is_known(name) and buff_extension:is_valid_target(name) then
			local ok, err = pcall(buff_extension.add_internally_controlled_buff, buff_extension, name, t)

			if ok then
				unit_given[name] = true
				count = count + 1
			else
				mod:error("could not add %s: %s", name, tostring(err))
			end
		end
	end

	if count > 0 and mod:get("debug_log") then
		mod:info("gave %d Mortis buff(s) to a player", count)
	end

	return count
end

mod:hook(GameModeExtensionHavoc, "_on_player_unit_spawned", function (func, self, player)
	func(self, player)

	if not has_authority() or not player or not player_wanted(player) then
		return
	end

	local ok, err = pcall(give, player)

	if not ok then
		mod:error("Mortis buffs skipped: %s", tostring(err))
	end
end)

--- Give the current selection to everyone already spawned.
local function apply_now()
	if not mod._in_havoc or not has_authority() then
		mod:echo("Only the host can do this, during a Havoc mission.")

		return
	end

	local total = 0

	for _, player in pairs(Managers.player:players()) do
		if player_wanted(player) then
			total = total + give(player)
		end
	end

	mod:echo("Added %d buff(s) to players already in the mission.", total)
end

-- ---------------------------------------------------------------------------
-- Particle guard (ChaosWastesAtHome particle_guard.lua:24-117)
-- ---------------------------------------------------------------------------

local function guard_active()
	return mod._in_havoc and mod:get("guard_particles") ~= false
end

local world_api = rawget(_G, "World")
local failures_by_world = setmetatable({}, { __mode = "k" })

if world_api and world_api.create_particles then
	mod:hook(world_api, "create_particles", function (func, world, effect_name, ...)
		if not guard_active() then
			return func(world, effect_name, ...)
		end

		local world_failures = failures_by_world[world]

		if not world_failures then
			world_failures = {}
			failures_by_world[world] = world_failures
		end

		if world_failures[effect_name] then
			return nil
		end

		local ok, id = pcall(func, world, effect_name, ...)

		if ok then
			return id
		end

		world_failures[effect_name] = true

		mod:info("particle effect not loaded, rendering nothing: %s", tostring(effect_name))

		return nil
	end)

	local FALSE_ON_NIL = {
		are_particles_playing = true,
		has_particles_material = true,
	}
	local ID_FUNCTIONS = {
		"stop_spawning_particles",
		"destroy_particles",
		"link_particles",
		"move_particles",
		"set_particles_variable",
		"set_particles_material_vector",
		"set_particles_material_scalar",
		"are_particles_playing",
		"set_particles_use_custom_fov",
		"set_particles_emit_rate_multiplier",
		"set_particles_surface_effect",
		"has_particles_material",
		"set_particles_life_time",
	}

	for _, name in ipairs(ID_FUNCTIONS) do
		if world_api[name] then
			local returns_false = FALSE_ON_NIL[name]

			mod:hook(world_api, name, function (func, world, id, ...)
				if id == nil and guard_active() then
					if returns_false then
						return false
					end

					return nil
				end

				return func(world, id, ...)
			end)
		end
	end
end

-- ---------------------------------------------------------------------------
-- Optional Mortis package (ChaosWastesAtHome asset_loader.lua:38-121)
-- ---------------------------------------------------------------------------

mod._package = mod._package or { id = nil, loading = false, failed = false }

local package_state = mod._package

local function request_package()
	if not mod:get("preload_mortis_assets") or package_state.id or package_state.loading or package_state.failed then
		return
	end

	local package_manager = Managers.package

	if not package_manager then
		return
	end

	if Application and Application.can_get_resource then
		local ok, exists = pcall(Application.can_get_resource, "package", HORDE_PACKAGE)

		if ok and not exists then
			package_state.failed = true

			mod:error("Mortis package not found (%s)", HORDE_PACKAGE)

			return
		end
	end

	package_state.loading = true

	local ok, err = pcall(package_manager.load, package_manager, HORDE_PACKAGE, PACKAGE_REFERENCE, function (package_id)
		package_state.id = package_id
		package_state.loading = false

		mod:info("Mortis assets loaded")
	end)

	if not ok then
		package_state.loading = false
		package_state.failed = true

		mod:error("could not load Mortis assets: %s", tostring(err))
	end
end

local function release_package()
	if not package_state.id or not Managers.package then
		return
	end

	local ok, err = pcall(Managers.package.release, Managers.package, package_state.id)

	if not ok then
		mod:error("could not release Mortis assets: %s", tostring(err))
	end

	package_state.id = nil
	package_state.loading = false
end

-- ---------------------------------------------------------------------------
-- Mission lifetime
-- ---------------------------------------------------------------------------

mod.on_game_state_changed = function (status, state)
	if state ~= "GameplayStateRun" then
		return
	end

	if status == "enter" then
		mod._in_havoc = in_havoc()

		if mod._in_havoc and #selected_buffs() > 0 then
			request_package()
		end
	elseif status == "exit" then
		mod._in_havoc = false

		release_package()
	end
end

mod.on_disabled = function ()
	mod._in_havoc = false

	release_package()
end

-- ---------------------------------------------------------------------------
-- Chat commands
-- ---------------------------------------------------------------------------

local function resolve(arg)
	local names = buff_list.all()

	if not names or not arg or arg == "" then
		return nil
	end

	local index = tonumber(arg)

	if index and names[index] then
		return names[index]
	end

	for i = 1, #names do
		if names[i] == arg then
			return arg
		end
	end

	return nil
end

mod:command("mhb_list", mod:localize("cmd_list"), function (filter)
	local names, legendary = buff_list.all()

	if not names then
		mod:echo("The Mortis buff list could not be read from the game.")

		return
	end

	local shown = 0

	for i = 1, #names do
		local name = names[i]
		local title = buff_list.title(name)

		if not filter or string.find(string.lower(name .. " " .. title), string.lower(filter), 1, true) then
			mod:echo("%d  %s  (%s)%s", i, title, name, legendary[name] and "  [legendary]" or "")
			shown = shown + 1
		end
	end

	mod:echo("%d of %d buffs shown. Add with /mhb_add <number or name>.", shown, #names)
end)

mod:command("mhb_add", mod:localize("cmd_add"), function (arg)
	local name = resolve(arg)

	if not name then
		mod:echo("Unknown buff: %s (see /mhb_list)", tostring(arg))

		return
	end

	local extra = table.clone(extra_buffs())

	for i = 1, #extra do
		if extra[i] == name then
			mod:echo("Already selected: %s", name)

			return
		end
	end

	extra[#extra + 1] = name

	mod:set(EXTRA_SETTING, extra)
	mod:echo("Added %s (%s). Applies at the next spawn, or now with /mhb_apply.", buff_list.title(name), name)
end)

mod:command("mhb_remove", mod:localize("cmd_remove"), function (arg)
	local name = resolve(arg)
	local extra = extra_buffs()
	local kept = {}

	for i = 1, #extra do
		if extra[i] ~= name then
			kept[#kept + 1] = extra[i]
		end
	end

	mod:set(EXTRA_SETTING, kept)
	mod:echo("Removed %s from the chat list (slot dropdowns are changed in mod options). Already given buffs stay until the player respawns.", tostring(name or arg))
end)

mod:command("mhb_clear", mod:localize("cmd_clear"), function ()
	mod:set(EXTRA_SETTING, {})
	mod:echo("Chat list cleared (slot dropdowns are changed in mod options).")
end)

mod:command("mhb_show", mod:localize("cmd_show"), function ()
	local buffs = selected_buffs()

	if #buffs == 0 then
		mod:echo("No Mortis buffs selected.")

		return
	end

	for i = 1, #buffs do
		mod:echo("%d  %s  (%s)", i, buff_list.title(buffs[i]), buffs[i])
	end
end)

mod:command("mhb_apply", mod:localize("cmd_apply"), apply_now)
