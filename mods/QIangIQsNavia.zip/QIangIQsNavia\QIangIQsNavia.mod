return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsNavia` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsNavia", {
            mod_script = "QIangIQsNavia/scripts/mods/QIangIQsNavia/QIangIQsNavia",
            mod_data = "QIangIQsNavia/scripts/mods/QIangIQsNavia/QIangIQsNavia_data",
            mod_localization = "QIangIQsNavia/scripts/mods/QIangIQsNavia/QIangIQsNavia_localization",
        })
    end,
    version = "2.0.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
