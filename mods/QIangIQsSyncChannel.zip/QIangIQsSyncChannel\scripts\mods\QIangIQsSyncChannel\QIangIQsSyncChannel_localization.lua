return {
    mod_name = {
        en = "QIangIQ's Sync Channel",
    },
    mod_description = {
        en = "Library for QIangIQ's mods. Shares small per-player state with party members through Vox Manifold, spread over 4 presence keys (about 1 KB instead of 250 bytes), sorted into categories: characters, emotes, weapons, items, enemies, misc. Sends no asset data. Chat command: /syncchannel. By QIangIQ.",
    },
}
