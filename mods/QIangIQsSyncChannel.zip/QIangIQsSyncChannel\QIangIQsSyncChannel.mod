return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsSyncChannel` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsSyncChannel", {
            mod_script = "QIangIQsSyncChannel/scripts/mods/QIangIQsSyncChannel/QIangIQsSyncChannel",
            mod_data = "QIangIQsSyncChannel/scripts/mods/QIangIQsSyncChannel/QIangIQsSyncChannel_data",
            mod_localization = "QIangIQsSyncChannel/scripts/mods/QIangIQsSyncChannel/QIangIQsSyncChannel_localization",
        })
    end,
    version = "1.2.0",
    author = "QIangIQ",
    load_after = { "Vox Manifold" },
    require = { "Vox Manifold" },
    packages = {},
}
