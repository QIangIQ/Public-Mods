-- QIangIQ's Sync Channel: more room than one Vox Manifold key, for QIangIQ's mods.
--
-- Vox Manifold gives each consumer id one presence key and drops a value over 250 bytes (Vox Manifold.lua:
-- MAX_VALUE_BYTES, "backend limit for a single presence value"). The limit is per value, not per player, so this
-- mod registers CHUNKS consumer ids (qiangiq.ch1 .. qiangiq.ch4) and spreads one categorised table over them.
-- All keys are rebuilt in one pass and pushed in one presence update (keyset.lua build, encode_now), so a reader
-- normally sees one consistent set; every chunk carries the same checksum q, and a set whose checksums disagree
-- is ignored until the next update.
--
-- The key count is capped on purpose: every key lives in the player's one presence record on Fatshark's backend,
-- whose limit on key count is undocumented (Vox Manifold warns past CONSUMER_WARN_AT = 13 consumers).
--
-- Wire value of chunk i:  { q = checksum, n = chunks in use, c = { [category] = { [key] = value } } }
--
-- API (mod.api), for other mods:
--   provide(name, category, builder)   builder() -> { [key] = value } or nil; one builder per (name, category)
--   withdraw(name, category)           remove a builder (category nil = all of that name's builders)
--   mark_dirty()                       my state changed: rebuild and publish (Vox Manifold rate-limits to 2 s)
--   peer(player, category)             another player's { [key] = value } for a category, or nil
--   peer_by_account(account_id, category)
--   roster()                           { [account_id] = { name, running, data } } of party members
--   on_change(fn)                      fn() when any party member's data changed; returns an unsubscribe function
--   report()                           what I publish: { chunks = { bytes, ... }, used, shed = { "cat/key", ... } }
-- Author: QIangIQ
local mod = get_mod("QIangIQsSyncChannel")

mod.AUTHOR = "QIangIQ"
mod.version = mod.version or "1.2.0" -- Vox Manifold publishes it in every chunk; keep it short

local CHUNKS = 4
local ID_PREFIX = "qiangiq.ch" -- registry.lua: author.name, [a-z0-9_], 3-32 characters
local MAX_VALUE_BYTES = 250    -- Vox Manifold.lua MAX_VALUE_BYTES
local SAFETY = 6
local POLL_INTERVAL = 0.5 -- as QIangIQsEmotes polled its own key
local Q_MOD = 99999989         -- checksum kept to 8 digits, so its size is known before it is computed
local Q_PLACEHOLDER = 99999999

-- kept in this order when everything does not fit: the first categories are placed first
local CATEGORY_ORDER = { "c", "a", "w", "i", "e", "x" }
local CATEGORY_NAMES = { c = "characters", a = "emotes", w = "weapons", i = "items", e = "enemies", x = "misc" }

local Channel = {
    manifold = nil,
    unsubscribe = nil,
    loaded = false,
    providers = {},  -- [name .. "|" .. category] = { name, category, builder }
    peers = {},      -- [account_id] = { name, running, q, data }
    listeners = {},
    watching = {},   -- [account_id] = true (watched) or clock time of the last failed try
    clock = 0,
    poll_now = true,
    poll_timer = 0,
    last_report = { chunks = {}, used = 0, shed = {} },
}

local function chunk_id(i)
    return ID_PREFIX .. i
end

-- JSON exactly as Vox Manifold's json.lua writes it (sorted keys, %d / %.14g numbers, same escapes), so sizes and
-- checksums are exact and the same on every client
local ESCAPES = {
    ['"'] = '\\"',
    ['\\'] = '\\\\',
    ['\b'] = '\\b',
    ['\f'] = '\\f',
    ['\n'] = '\\n',
    ['\r'] = '\\r',
    ['\t'] = '\\t',
}

local function escape_char(c)
    return ESCAPES[c] or string.format("\\u%04x", c:byte())
end

local function encode(v)
    local t = type(v)
    if t == "string" then
        return '"' .. string.gsub(v, '[%z\1-\31\\"]', escape_char) .. '"'
    elseif t == "number" then
        if v ~= v or v == math.huge or v == -math.huge then
            return nil
        end
        if v == math.floor(v) then
            return string.format("%d", v)
        end
        return string.format("%.14g", v)
    elseif t == "boolean" then
        return v and "true" or "false"
    elseif t == "table" then
        local n = #v
        local out = {}
        if n > 0 then
            for i = 1, n do
                local s = encode(v[i])
                if not s then
                    return nil
                end
                out[i] = s
            end
            return "[" .. table.concat(out, ",") .. "]"
        end
        local keys = {}
        for k in pairs(v) do
            local kt = type(k)
            if kt ~= "string" and kt ~= "number" then
                return nil
            end
            keys[#keys + 1] = k
        end
        table.sort(keys, function(a, b)
            return tostring(a) < tostring(b)
        end)
        for i = 1, #keys do
            local s = encode(v[keys[i]])
            if not s then
                return nil
            end
            out[i] = encode(tostring(keys[i])) .. ":" .. s
        end
        return "{" .. table.concat(out, ",") .. "}"
    end
    return nil
end

local function checksum(s)
    local h = 7
    for i = 1, #s do
        h = (h * 31 + s:byte(i)) % Q_MOD
    end
    return h
end

-- room for the payload d inside Vox Manifold's envelope { v = 2, m = version, d = payload } (envelope.lua encode_one)
local function chunk_budget()
    local overhead = #'{"d":' + #',"m":' + #encode(tostring(mod.version)) + #',"v":2}'
    return MAX_VALUE_BYTES - overhead - SAFETY
end

local function category_rank(category)
    for i = 1, #CATEGORY_ORDER do
        if CATEGORY_ORDER[i] == category then
            return i
        end
    end
    return #CATEGORY_ORDER + 1
end

-- every entry I publish, in placing order: category order, then key
local function collect_entries()
    local by_category = {}
    local names = {}
    for id in pairs(Channel.providers) do
        names[#names + 1] = id
    end
    table.sort(names)
    for i = 1, #names do
        local p = Channel.providers[names[i]]
        local ok, values = pcall(p.builder)
        if ok and type(values) == "table" then
            local bucket = by_category[p.category] or {}
            by_category[p.category] = bucket
            for key, value in pairs(values) do
                if type(key) == "string" and bucket[key] == nil and encode(value) then
                    bucket[key] = value
                end
            end
        end
    end
    local categories = {}
    for category in pairs(by_category) do
        categories[#categories + 1] = category
    end
    table.sort(categories, function(a, b)
        local ra, rb = category_rank(a), category_rank(b)
        if ra ~= rb then
            return ra < rb
        end
        return a < b
    end)
    local entries = {}
    for i = 1, #categories do
        local category = categories[i]
        local keys = {}
        for key in pairs(by_category[category]) do
            keys[#keys + 1] = key
        end
        table.sort(keys)
        for j = 1, #keys do
            entries[#entries + 1] = { category = category, key = keys[j], value = by_category[category][keys[j]] }
        end
    end
    return entries
end

local function chunk_size(c, n)
    return #encode({ c = c, n = n, q = Q_PLACEHOLDER })
end

-- First fit over CHUNKS chunks. Deterministic for the same state, so the CHUNKS builders, which Vox Manifold
-- calls one after another, agree. Must stay free of side effects apart from last_report.
local function pack()
    local budget = chunk_budget()
    local entries = collect_entries()
    local bins = {}
    for i = 1, CHUNKS do
        bins[i] = {}
    end
    local used, shed = 0, {}
    for e = 1, #entries do
        local entry = entries[e]
        local placed = false
        for i = 1, CHUNKS do
            local bin = bins[i]
            local bucket = bin[entry.category]
            local fresh = bucket == nil
            if fresh then
                bucket = {}
                bin[entry.category] = bucket
            end
            bucket[entry.key] = entry.value
            if chunk_size(bin, CHUNKS) <= budget then
                placed = true
                if i > used then
                    used = i
                end
                break
            end
            bucket[entry.key] = nil
            if fresh then
                bin[entry.category] = nil
            end
        end
        if not placed then
            shed[#shed + 1] = entry.category .. "/" .. entry.key
        end
    end
    if used == 0 then
        used = 1
    end
    local all = {}
    for i = 1, used do
        all[i] = bins[i]
    end
    local q = checksum(encode(all) or "")
    local chunks, sizes = {}, {}
    for i = 1, used do
        chunks[i] = { c = bins[i], n = used, q = q }
        sizes[i] = #encode(chunks[i])
    end
    Channel.last_report = { chunks = sizes, used = used, shed = shed }
    return chunks
end

local function builder_for(i)
    return function()
        local chunks = pack()
        return chunks[i] -- nil past the chunks in use: Vox Manifold then publishes the bare envelope
    end
end

-- Reading ------------------------------------------------------------------------------

local function read_member(member)
    local Manifold = Channel.manifold
    local first = Manifold.get(member, chunk_id(1))
    if type(first) ~= "table" then
        return nil
    end
    local n, q = tonumber(first.n), first.q
    if not n or n < 1 or n > CHUNKS then
        return nil
    end
    local data = {}
    for i = 1, n do
        local chunk = i == 1 and first or Manifold.get(member, chunk_id(i))
        if type(chunk) ~= "table" or chunk.q ~= q then
            return nil, true -- set still changing: keep what I had
        end
        if type(chunk.c) == "table" then
            for category, bucket in pairs(chunk.c) do
                if type(category) == "string" and type(bucket) == "table" then
                    local merged = data[category] or {}
                    data[category] = merged
                    for key, value in pairs(bucket) do
                        merged[key] = value
                    end
                end
            end
        end
    end
    return data, false, q
end

local function notify()
    for fn in pairs(Channel.listeners) do
        local ok, err = pcall(fn)
        if not ok then
            mod:warning("[Sync Channel] listener failed: %s", tostring(err))
        end
    end
end

-- Other human players in my current game, by account id (AnotherScoreboard reads players the same way:
-- player:account_id(), player:name(), player:is_human_controlled())
local function game_players()
    local out = {}
    local players = Managers.player and Managers.player:players()
    if not players then
        return out
    end
    for _, player in pairs(players) do
        if player.remote and player.account_id then
            local ok_h, human = pcall(player.is_human_controlled, player)
            local ok_a, account_id = pcall(player.account_id, player)
            if ok_h and human and ok_a and account_id then
                local name = "?"
                pcall(function()
                    name = player:name() or "?"
                end)
                out[account_id] = name
            end
        end
    end
    return out
end

-- Players in my game who are not in my party (a Realms game, a hot join, matchmaking) are not in
-- Manifold.members(). They are read through Vox Manifold temporary watches (README "Temporary watches": accounts
-- the game put in front of me, released all together), held on chunk 1's consumer id.
local WATCH_RETRY = 10
local function sync_watches(Manifold, party)
    local wanted = {}
    for account_id, name in pairs(game_players()) do
        if not party[account_id] then
            wanted[account_id] = name
        end
    end
    -- temporary watches end only all together: when someone left, release and watch the rest again
    for account_id in pairs(Channel.watching) do
        if not wanted[account_id] then
            Manifold.release_temp(chunk_id(1))
            Channel.watching = {}
            break
        end
    end
    for account_id in pairs(wanted) do
        local state = Channel.watching[account_id]
        if state ~= true and (state == nil or Channel.clock - state >= WATCH_RETRY) then
            local ok, err = Manifold.watch_temp(chunk_id(1), { id = account_id })
            if ok then
                Channel.watching[account_id] = true
            else
                Channel.watching[account_id] = Channel.clock
                mod:info("[Sync Channel] cannot read %s yet: %s", tostring(wanted[account_id]), tostring(err))
            end
        end
    end
    return wanted
end

local function process_members()
    local Manifold = Channel.manifold
    if not Manifold then
        return
    end
    -- { member handle, account id, name, source }
    local list, party = {}, {}
    local members = Manifold.members()
    for i = 1, #members do
        local member = members[i]
        if not Manifold.is_myself(member) then
            local account_id = member.account_id and member:account_id()
            if account_id then
                local name = "?"
                pcall(function()
                    name = member:name() or "?"
                end)
                party[account_id] = true
                list[#list + 1] = { member = member, account_id = account_id, name = name, source = "party" }
            end
        end
    end
    local wanted = sync_watches(Manifold, party)
    local handles = Manifold.watched(chunk_id(1))
    for i = 1, #handles do
        local handle = handles[i]
        local account_id = handle.vm_ref and handle.vm_ref.id -- presence.lua: watch handles keep the ref
        if account_id and wanted[account_id] and not party[account_id] then
            list[#list + 1] = { member = handle, account_id = account_id, name = wanted[account_id], source = "game" }
        end
    end

    local seen, changed = {}, false
    for i = 1, #list do
        local row = list[i]
        local account_id, member = row.account_id, row.member
        seen[account_id] = true
        local running = Manifold.has_mod(member, chunk_id(1)) and true or false
        local entry = Channel.peers[account_id]
        if not entry then
            entry = { name = row.name, running = running, q = nil, data = nil }
            Channel.peers[account_id] = entry
        end
        entry.name, entry.running, entry.source = row.name, running, row.source
        if running then
            local data, settling, q = read_member(member)
            if not settling and (q ~= entry.q or (data == nil) ~= (entry.data == nil)) then
                entry.q, entry.data = q, data
                changed = true
            end
        elseif entry.data then
            entry.q, entry.data = nil, nil
            changed = true
        end
    end
    for account_id, entry in pairs(Channel.peers) do
        if not seen[account_id] then
            Channel.peers[account_id] = nil
            if entry.data then
                changed = true
            end
        end
    end
    if changed then
        notify()
    end
end

-- API ----------------------------------------------------------------------------------
mod.api = {}

mod.api.CHUNKS = CHUNKS
mod.api.CATEGORIES = CATEGORY_NAMES

mod.api.provide = function(name, category, builder)
    if type(name) ~= "string" or type(category) ~= "string" or type(builder) ~= "function" then
        return false
    end
    Channel.providers[name .. "|" .. category] = { name = name, category = category, builder = builder }
    mod.api.mark_dirty()
    return true
end

mod.api.withdraw = function(name, category)
    for id, p in pairs(Channel.providers) do
        if p.name == name and (category == nil or p.category == category) then
            Channel.providers[id] = nil
        end
    end
    mod.api.mark_dirty()
end

mod.api.mark_dirty = function()
    if Channel.manifold then
        Channel.manifold.mark_dirty(chunk_id(1))
    end
end

mod.api.peer_by_account = function(account_id, category)
    local entry = account_id and Channel.peers[account_id]
    local data = entry and entry.data
    return data and data[category] or nil
end

mod.api.peer = function(player, category)
    if not player or not player.remote or not player.account_id then
        return nil
    end
    local ok, account_id = pcall(player.account_id, player)
    return ok and mod.api.peer_by_account(account_id, category) or nil
end

mod.api.roster = function()
    return Channel.peers
end

mod.api.on_change = function(fn)
    if type(fn) ~= "function" then
        return function() end
    end
    Channel.listeners[fn] = true
    return function()
        Channel.listeners[fn] = nil
    end
end

mod.api.report = function()
    pack()
    return Channel.last_report
end

mod.api.active = function()
    return Channel.manifold ~= nil
end

-- Lifecycle (as QIangIQsModelSync / Dio's Wardrobe: start in on_all_mods_loaded) ----------
local function start()
    local vox = get_mod("Vox Manifold")
    local Manifold = vox and vox.api
    if not Manifold then
        mod:info("[Sync Channel] Vox Manifold not found; sharing is off.")
        return
    end
    for i = 1, CHUNKS do
        local ok, err = Manifold.register(chunk_id(i), mod, builder_for(i))
        if not ok then
            mod:error("[Sync Channel] Could not register %s with Vox Manifold: %s", chunk_id(i), tostring(err))
            for j = 1, i - 1 do
                Manifold.unregister(chunk_id(j))
            end
            return
        end
    end
    Channel.manifold = Manifold
    Channel.unsubscribe = Manifold.on_update(chunk_id(1), function()
        Channel.poll_now = true
    end)
    Channel.poll_now = true
    Manifold.mark_dirty(chunk_id(1))
end

local function stop()
    if Channel.manifold then
        Channel.manifold.release_temp(chunk_id(1))
        for i = 1, CHUNKS do
            Channel.manifold.unregister(chunk_id(i))
        end
    end
    if Channel.unsubscribe then
        Channel.unsubscribe()
    end
    Channel.manifold, Channel.unsubscribe = nil, nil
    Channel.watching = {}
    local had = next(Channel.peers) ~= nil
    Channel.peers = {}
    if had then
        notify()
    end
end

mod.on_all_mods_loaded = function()
    Channel.loaded = true
    start()
end

mod.update = function(dt)
    if not Channel.manifold then
        return
    end
    Channel.poll_timer = Channel.poll_timer + (dt or 0)
    Channel.clock = Channel.clock + (dt or 0)
    if Channel.poll_now or Channel.poll_timer >= POLL_INTERVAL then
        Channel.poll_now = false
        Channel.poll_timer = 0
        process_members()
    end
end

mod.on_unload = function()
    stop()
end

mod.on_disabled = function()
    stop()
end

mod.on_enabled = function()
    if Channel.loaded and not Channel.manifold then
        start()
    end
end

mod:command("syncchannel", "Show what QIangIQ's Sync Channel sends and receives", function()
    if not Channel.manifold then
        mod:echo("Sync Channel: off (Vox Manifold missing?)")
        return
    end
    local report = mod.api.report()
    local sizes = {}
    for i = 1, #report.chunks do
        sizes[i] = tostring(report.chunks[i])
    end
    mod:echo("Sync Channel: %d of %d keys in use, bytes per key: %s (limit %d)", report.used, CHUNKS, table.concat(sizes, ", "), chunk_budget())
    if #report.shed > 0 then
        mod:echo("  left out, no room: %s", table.concat(report.shed, ", "))
    end
    local any = false
    for _, entry in pairs(Channel.peers) do
        any = true
        local parts = {}
        if entry.data then
            for category, bucket in pairs(entry.data) do
                local n = 0
                for _ in pairs(bucket) do
                    n = n + 1
                end
                parts[#parts + 1] = (CATEGORY_NAMES[category] or category) .. " " .. n
            end
            table.sort(parts)
        end
        mod:echo("  %s (%s): %s", entry.name, entry.source == "game" and "in my game" or "party", entry.running and (#parts > 0 and table.concat(parts, ", ") or "runs Sync Channel, sends nothing") or "does not run Sync Channel")
    end
    if not any then
        mod:echo("  no other party members")
    end
end)
