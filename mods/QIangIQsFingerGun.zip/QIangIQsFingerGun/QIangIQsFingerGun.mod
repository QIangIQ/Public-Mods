return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsFingerGun` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsFingerGun", {
            mod_script = "QIangIQsFingerGun/scripts/mods/QIangIQsFingerGun/QIangIQsFingerGun",
            mod_data = "QIangIQsFingerGun/scripts/mods/QIangIQsFingerGun/QIangIQsFingerGun_data",
            mod_localization = "QIangIQsFingerGun/scripts/mods/QIangIQsFingerGun/QIangIQsFingerGun_localization",
        })
    end,
    version = "0.1.1",
    author = "QIangIQ",
    packages = {},
}
