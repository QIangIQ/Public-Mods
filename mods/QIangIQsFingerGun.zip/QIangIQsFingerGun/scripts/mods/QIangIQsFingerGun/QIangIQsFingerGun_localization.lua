return {
    mod_name = {
        en = "QIangIQ's Finger Gun",
    },
    mod_description = {
        en = "Replaces both Heavy Laspistol patterns (laspistol_p1_m1 and laspistol_p1_m3) with Mullet Mad Jack's finger gun. In first person the pistol and your arms are hidden and MMJ's own hand sprites play its own clips (draw, idle, shot, 12 reloads) with its shot and draw sounds; the las shots leave from the fingertip. Visual only: the weapons still shoot, reload and push as before. Contains MMJ art and audio: personal use only.",
    },
    command_desc = { en = "Finger gun status" },
    replace_m1 = { en = "Replace Heavy Laspistol (laspistol_p1_m1)" },
    replace_m3 = { en = "Replace Heavy Laspistol (laspistol_p1_m3)" },
    third_person = { en = "Third person: your character" },
    third_person_others = { en = "Third person: other players" },
    third_person_hide = { en = "Hide the laspistol" },
    third_person_retail = { en = "Show the laspistol" },
    sounds = { en = "MMJ finger gun sounds" },
    volume = { en = "Sound volume (%%)" },
    layout = { en = "Screen layout" },
    mmj_fov = { en = "MMJ weapon camera field of view (degrees)" },
    size = { en = "Size (%%)" },
    offset_x = { en = "Move right (cm)" },
    offset_y = { en = "Move up (cm)" },
}
