
-- MMJ finger gun as MMJ draws it: 2D sprites (SpriteRenderers under the weapon camera) animated by its Mecanim clips.
-- QIangIQsFingerGun_sprites.lua holds every clip baked at 60 fps as draws in the gun root's 2D space
-- (tools/mmj_clips.py + bake_sprites_lua.py). This module samples a clip and lays the draws out on screen with MMJ's
-- weapon camera projection: the gun root sits at root.x/y/z metres in the camera (OBJ-Weapond-HandGun local position),
-- scaled root.scale, seen with a vertical field of view fov (Unity cameras use a vertical FOV).
-- Pure Lua (no engine calls) so it can be checked offline (tools/check_overlay.py).
local Overlay = {}

local DATA = nil
local decoded = {}

function Overlay.setup(data)
    DATA = data
end

function Overlay.data()
    return DATA
end

local function clip(name)
    local c = DATA and DATA.clips[name]

    if not c then
        return nil
    end

    local entry = decoded[name]

    if not entry then
        local values, counts, starts = {}, {}, {}
        local n, inv = 0, 1 / DATA.scale

        for v in string.gmatch(c.data, "-?%d+") do
            n = n + 1

            local k = (n - 1) % 8

            values[n] = k > 1 and tonumber(v) * inv or tonumber(v)
        end

        local at = 0

        for v in string.gmatch(c.counts, "%d+") do
            counts[#counts + 1] = tonumber(v)
            starts[#starts + 1] = at
            at = at + tonumber(v) * 8
        end

        entry = { values = values, counts = counts, starts = starts, length = c.length, loop = c.loop, events = c.events }
        decoded[name] = entry
    end

    return entry
end

function Overlay.has(name)
    return clip(name) ~= nil
end

function Overlay.length(name)
    local c = clip(name)

    return c and c.length or 0
end

function Overlay.events(name)
    local c = clip(name)

    return c and c.events or {}
end

-- the draws of clip `name` at time t (seconds); sprite swaps are stepped, so the nearest baked frame is used
function Overlay.sample(name, t, loop)
    local c = clip(name)

    if not c then
        return nil
    end

    local n = #c.counts

    if loop and c.length > 0 then
        t = t % c.length
    end

    local i = math.max(1, math.min(n, math.floor(t * DATA.fps + 0.5) + 1))
    local v, base = c.values, c.starts[i]
    local out = {}

    for k = 0, c.counts[i] - 1 do
        local o = base + k * 8

        out[#out + 1] = {
            sprite = v[o + 1], order = v[o + 2], x = v[o + 3], y = v[o + 4], z = v[o + 5], angle = v[o + 6],
            sx = v[o + 7], sy = v[o + 8],
        }
    end

    return out
end

-- camera-space metres (Unity camera: x right, y up, z forward) of a gun-root point
local function camera_point(x, y, z, view)
    local r = DATA.root
    local s = r.scale * view.size

    return r.x + view.dx + s * x, r.y + view.dy + s * y, r.z + s * z
end

-- screen point (UI units, y down) of a camera-space point; view = { w, h, fov (rad), size, dx, dy }
local function project(cx, cy, cz, view)
    local f = view.h * 0.5 / math.tan(view.fov * 0.5)

    return view.w * 0.5 + f * cx / cz, view.h * 0.5 - f * cy / cz, f / cz
end

-- draws -> rotated_texture rectangles: { sprite, x, y (top-left), w, h, pivot_x, pivot_y, angle, mirror }, back to front
function Overlay.layout(draws, view)
    local rects = {}

    -- draws come baked back to front (sorting order, then camera distance as Unity does); table.sort is not stable and
    -- reshuffled equal orders every frame, so the baked order is kept

    for _, d in ipairs(draws) do
        local sp = DATA.sprites[d.sprite]

        if sp then
            local cx, cy, cz = camera_point(d.x, d.y, d.z, view)
            local px, py, k = project(cx, cy, cz, view)
            local units = DATA.root.scale * view.size * k -- screen units per gun-root unit at this depth
            local w = math.abs(d.sx) * sp.w / sp.ppu * units
            local h = d.sy * sp.h / sp.ppu * units
            local mirror = d.sx < 0
            local pivot_x = (mirror and (1 - sp.px) or sp.px) * w
            local pivot_y = (1 - sp.py) * h

            rects[#rects + 1] = {
                sprite = d.sprite, x = px - pivot_x, y = py - pivot_y, w = w, h = h, pivot_x = pivot_x, pivot_y = pivot_y,
                angle = d.angle * (view.angle_sign or 1), mirror = mirror,
            }
        end
    end

    return rects
end

-- MMJ's muzzle flash point on screen (UI units) and its depth in metres
function Overlay.muzzle(view)
    local m = DATA.muzzle
    local cx, cy, cz = camera_point(m.x, m.y, m.z, view)
    local x, y = project(cx, cy, cz, view)

    return x, y, cz
end

return Overlay
