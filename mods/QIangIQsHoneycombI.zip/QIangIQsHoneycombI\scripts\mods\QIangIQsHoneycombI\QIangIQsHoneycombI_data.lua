local mod = get_mod("QIangIQsHoneycombI")

-- Cache settings when they change.
mod.on_setting_changed = function(id)
	mod.settings_cache[id] = mod:get(id)
end

mod.get_cached = function(self, id)
	return self.settings_cache[id]
end

local settings = {
	{
		setting_id = "gradual_background_update",
		type = "checkbox",
		default_value = false,
	}, {
		setting_id = "use_ability_frame",
		type = "checkbox",
		default_value = false
	}, {
		setting_id = "dev_mode",
		type = "checkbox",
		default_value = false
	}
}

mod.settings_cache = {}

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	options = { widgets = settings }
}
