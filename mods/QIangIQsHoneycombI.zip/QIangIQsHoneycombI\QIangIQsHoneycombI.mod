return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQ's Honeycomb I` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsHoneycombI", {
			mod_script       = "QIangIQsHoneycombI/scripts/mods/QIangIQsHoneycombI/QIangIQsHoneycombI",
			mod_data         = "QIangIQsHoneycombI/scripts/mods/QIangIQsHoneycombI/QIangIQsHoneycombI_data",
			mod_localization = "QIangIQsHoneycombI/scripts/mods/QIangIQsHoneycombI/QIangIQsHoneycombI_localization",
		})
	end,
	packages = {},
}
