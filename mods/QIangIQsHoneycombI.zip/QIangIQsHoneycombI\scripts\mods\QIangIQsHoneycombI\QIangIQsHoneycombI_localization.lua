return {
	mod_name = {
		en = "QIangIQ's Honeycomb I",

	},
	mod_description = {
		en = "I actually have no idea what im doing lmao",
		
	},
	gradual_background_update = {
		en = "Gradual Background Update",

	},
	gradual_background_update_description = {
		en = "Copies ability backround regen",

	},
	use_ability_frame = {
		en = "hexagon frame"
	},
	use_ability_frame_description = {
		en = "if you read this u gae"
	},
	dev_mode = {
		en = "Debugging",
		
	},
	dev_mode_description = {
		en = "please tell me this inst getting read",
	}
}
