return {
    mod_name = {
        en = "QIangIQ's MMJ Uzi",
    },
    mod_description = {
        en = "Replaces the Shredder Autopistol with Mullet Mad Jack's Uzi: MMJ's sprites and clips in first person, a shot clip and sound for every round. Visual only: the weapon still works as before. Contains Mullet Mad Jack art and audio: personal use only.",
    },
    command_desc = { en = "MMJ Uzi status (add flip to turn the sprite rotation round)" },
    replace_autopistol_p1_m1 = { en = "Replace Shredder Autopistol (autopistol_p1_m1)" },
    third_person = { en = "Third person: your character" },
    third_person_others = { en = "Third person: other players" },
    third_person_hide = { en = "Hide the weapon" },
    third_person_retail = { en = "Show the weapon" },
    sounds = { en = "MMJ sounds" },
    volume = { en = "Sound volume (%%)" },
    layout = { en = "Screen layout" },
    mmj_fov = { en = "MMJ weapon camera field of view (degrees)" },
    size = { en = "Size (%%)" },
    offset_x = { en = "Move right (cm)" },
    offset_y = { en = "Move up (cm)" },
    smear_cap = { en = "Fade sprites bigger than this share of the screen (%%, 0 = off)" },
}
