-- QIangIQsMMJUzi per-weapon data (gen.py spec uzi). Clips are MMJ clip names from uzi\OBJ-Weapon-Uzi__20268.
-- Action map sources: Darktide weapon templates (Aussiemon master) via tools\dump_actions.py.
return {
    ranged = true,
    idle = "uzi-Idle",
    templates = { autopistol_p1_m1 = true },
    shot = { clips = { "uzi-shot" }, sounds = { "sfx_wp_uzi_shot_layer_01.ogg", "sfx_wp_uzi_shot_layer_2.ogg", "sfx_wp_uzi_shot_layer_3.ogg", "sfx_wp_uzi_shot_layer_4.ogg" } },
    actions = {
        action_wield = { clips = { "uzi-introfast" }, over_shot = true, sounds = { "sfx_wp_uzi_intro.ogg" } },
        action_reload = { clips = { "uzi-reload" }, stretch = true, reload_template = true, over_shot = true, sounds = { "sfx_wp_uzi_reload.ogg" } },
    },
}
