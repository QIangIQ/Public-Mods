return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsMMJUzi` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsMMJUzi", {
            mod_script = "QIangIQsMMJUzi/scripts/mods/QIangIQsMMJUzi/QIangIQsMMJUzi",
            mod_data = "QIangIQsMMJUzi/scripts/mods/QIangIQsMMJUzi/QIangIQsMMJUzi_data",
            mod_localization = "QIangIQsMMJUzi/scripts/mods/QIangIQsMMJUzi/QIangIQsMMJUzi_localization",
        })
    end,
    version = "0.1.0",
    author = "QIangIQ",
    packages = {},
}
