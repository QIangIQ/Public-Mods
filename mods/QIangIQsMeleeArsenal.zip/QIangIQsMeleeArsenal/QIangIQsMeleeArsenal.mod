return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsMeleeArsenal` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsMeleeArsenal", {
            mod_script = "QIangIQsMeleeArsenal/scripts/mods/QIangIQsMeleeArsenal/QIangIQsMeleeArsenal",
            mod_data = "QIangIQsMeleeArsenal/scripts/mods/QIangIQsMeleeArsenal/QIangIQsMeleeArsenal_data",
            mod_localization = "QIangIQsMeleeArsenal/scripts/mods/QIangIQsMeleeArsenal/QIangIQsMeleeArsenal_localization",
        })
    end,
    version = "1.0.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
