return {
    mod_name = {
        en = "QIangIQ's Melee Arsenal",
    },
    mod_description = {
        en = "Shows Genshin Impact swords and polearms (59, Custom Assets) in place of any melee weapon. Each melee weapon has its own profile: on/off, which model (or a random one each session), length, grip, spin, tilt and flip. /melee which lists them, /melee reroll rolls the equipped weapon again. By QIangIQ.",
    },
    staff_selection = {
        en = "Melee weapon",
    },
    staff_selection_description = {
        en = "The melee weapon (by weapon template) whose profile the settings below show and change.",
    },
    chainaxe_p1_m1 = {
        en = "chainaxe_p1_m1",
    },
    chainaxe_p1_m2 = {
        en = "chainaxe_p1_m2",
    },
    chainsword_p1_m1 = {
        en = "chainsword_p1_m1",
    },
    chainsword_p1_m2 = {
        en = "chainsword_p1_m2",
    },
    chainsword_2h_p1_m1 = {
        en = "chainsword_2h_p1_m1",
    },
    chainsword_2h_p1_m2 = {
        en = "chainsword_2h_p1_m2",
    },
    combataxe_p1_m1 = {
        en = "combataxe_p1_m1",
    },
    combataxe_p1_m2 = {
        en = "combataxe_p1_m2",
    },
    combataxe_p1_m3 = {
        en = "combataxe_p1_m3",
    },
    combataxe_p2_m1 = {
        en = "combataxe_p2_m1",
    },
    combataxe_p2_m2 = {
        en = "combataxe_p2_m2",
    },
    combataxe_p2_m3 = {
        en = "combataxe_p2_m3",
    },
    combataxe_p3_m1 = {
        en = "combataxe_p3_m1",
    },
    combataxe_p3_m2 = {
        en = "combataxe_p3_m2",
    },
    combataxe_p3_m3 = {
        en = "combataxe_p3_m3",
    },
    ogryn_combatblade_p1_m1 = {
        en = "ogryn_combatblade_p1_m1",
    },
    ogryn_combatblade_p1_m2 = {
        en = "ogryn_combatblade_p1_m2",
    },
    ogryn_combatblade_p1_m3 = {
        en = "ogryn_combatblade_p1_m3",
    },
    combatknife_p1_m1 = {
        en = "combatknife_p1_m1",
    },
    combatknife_p1_m2 = {
        en = "combatknife_p1_m2",
    },
    combatsword_p1_m1 = {
        en = "combatsword_p1_m1",
    },
    combatsword_p1_m2 = {
        en = "combatsword_p1_m2",
    },
    combatsword_p1_m3 = {
        en = "combatsword_p1_m3",
    },
    combatsword_p2_m1 = {
        en = "combatsword_p2_m1",
    },
    combatsword_p2_m2 = {
        en = "combatsword_p2_m2",
    },
    combatsword_p2_m3 = {
        en = "combatsword_p2_m3",
    },
    combatsword_p3_m1 = {
        en = "combatsword_p3_m1",
    },
    combatsword_p3_m2 = {
        en = "combatsword_p3_m2",
    },
    combatsword_p3_m3 = {
        en = "combatsword_p3_m3",
    },
    forcesword_p1_m1 = {
        en = "forcesword_p1_m1",
    },
    forcesword_p1_m2 = {
        en = "forcesword_p1_m2",
    },
    forcesword_p1_m3 = {
        en = "forcesword_p1_m3",
    },
    forcesword_2h_p1_m1 = {
        en = "forcesword_2h_p1_m1",
    },
    forcesword_2h_p1_m2 = {
        en = "forcesword_2h_p1_m2",
    },
    ogryn_gauntlet_p1_m1 = {
        en = "ogryn_gauntlet_p1_m1",
    },
    ogryn_club_p1_m1 = {
        en = "ogryn_club_p1_m1",
    },
    ogryn_club_p1_m2 = {
        en = "ogryn_club_p1_m2",
    },
    ogryn_club_p1_m3 = {
        en = "ogryn_club_p1_m3",
    },
    ogryn_club_p2_m1 = {
        en = "ogryn_club_p2_m1",
    },
    ogryn_club_p2_m2 = {
        en = "ogryn_club_p2_m2",
    },
    ogryn_club_p2_m3 = {
        en = "ogryn_club_p2_m3",
    },
    ogryn_pickaxe_2h_p1_m1 = {
        en = "ogryn_pickaxe_2h_p1_m1",
    },
    ogryn_pickaxe_2h_p1_m2 = {
        en = "ogryn_pickaxe_2h_p1_m2",
    },
    ogryn_pickaxe_2h_p1_m3 = {
        en = "ogryn_pickaxe_2h_p1_m3",
    },
    ogryn_powermaul_p1_m1 = {
        en = "ogryn_powermaul_p1_m1",
    },
    ogryn_powermaul_p1_m2 = {
        en = "ogryn_powermaul_p1_m2",
    },
    ogryn_powermaul_p1_m3 = {
        en = "ogryn_powermaul_p1_m3",
    },
    ogryn_powermaul_slabshield_p1_m1 = {
        en = "ogryn_powermaul_slabshield_p1_m1",
    },
    powermaul_p1_m1 = {
        en = "powermaul_p1_m1",
    },
    powermaul_p1_m2 = {
        en = "powermaul_p1_m2",
    },
    powermaul_shield_p1_m1 = {
        en = "powermaul_shield_p1_m1",
    },
    powermaul_shield_p1_m2 = {
        en = "powermaul_shield_p1_m2",
    },
    powermaul_p2_m1 = {
        en = "powermaul_p2_m1",
    },
    powermaul_2h_p1_m1 = {
        en = "powermaul_2h_p1_m1",
    },
    powersword_p1_m1 = {
        en = "powersword_p1_m1",
    },
    powersword_p1_m2 = {
        en = "powersword_p1_m2",
    },
    powersword_p2_m1 = {
        en = "powersword_p2_m1",
    },
    powersword_p2_m2 = {
        en = "powersword_p2_m2",
    },
    powersword_2h_p1_m1 = {
        en = "powersword_2h_p1_m1",
    },
    powersword_2h_p1_m2 = {
        en = "powersword_2h_p1_m2",
    },
    thunderhammer_2h_p1_m1 = {
        en = "thunderhammer_2h_p1_m1",
    },
    thunderhammer_2h_p1_m2 = {
        en = "thunderhammer_2h_p1_m2",
    },
    saw_p1_m1 = {
        en = "saw_p1_m1",
    },
    crowbar_p1_m1 = {
        en = "crowbar_p1_m1",
    },
    dual_shivs_p1_m1 = {
        en = "dual_shivs_p1_m1",
    },
    dual_shivs_p1_m2 = {
        en = "dual_shivs_p1_m2",
    },
    transonic_sword_transonic_knife_p1_m1 = {
        en = "transonic_sword_transonic_knife_p1_m1",
    },
    powermaul_p3_m1 = {
        en = "powermaul_p3_m1",
    },
    powersword_p3_m1 = {
        en = "powersword_p3_m1",
    },
    current_weapon = {
        en = "Select equipped melee weapon",
    },
    current_weapon_description = {
        en = "Tick to pick the melee weapon you are holding in the list.",
    },
    profile_enabled = {
        en = "Replace this weapon",
    },
    profile_enabled_description = {
        en = "Show a Genshin weapon in place of the selected melee weapon.",
    },
    profile_spear = {
        en = "Model",
    },
    profile_spear_description = {
        en = "Random = a new random model each game session (the reroll keybind or /melee reroll picks another). Or pick one model for this weapon.",
    },
    spear_random = {
        en = "Random each session",
    },
    spear_amenoma_kageuchi = {
        en = "Amenoma Kageuchi",
    },
    spear_aquila_favonia = {
        en = "Aquila Favonia",
    },
    spear_amenoma_kageuchi_ascended = {
        en = "Amenoma Kageuchi (ascended)",
    },
    spear_blackcliff_longsword = {
        en = "Blackcliff Longsword",
    },
    spear_boreas = {
        en = "Boreas",
    },
    spear_cinnabar_spindle = {
        en = "Cinnabar Spindle",
    },
    spear_cool_steel = {
        en = "Cool Steel",
    },
    spear_dark_iron_sword = {
        en = "Dark Iron Sword",
    },
    spear_dull_blade = {
        en = "Dull Blade",
    },
    spear_favonius_sword = {
        en = "Favonius Sword",
    },
    spear_festering_desire = {
        en = "Festering Desire",
    },
    spear_fillet_blade = {
        en = "Fillet Blade",
    },
    spear_freedom_sworn = {
        en = "Freedom-Sworn",
    },
    spear_harbinger_of_dawn = {
        en = "Harbinger of Dawn",
    },
    spear_iron_sting = {
        en = "Iron Sting",
    },
    spear_musou_isshin_raiden_shogun_skill_katana = {
        en = "Musou Isshin (Raiden Shogun skill katana)",
    },
    spear_lions_roar = {
        en = "Lion's Roar",
    },
    spear_mistsplitter_reforged = {
        en = "Mistsplitter Reforged",
    },
    spear_mistsplitter_reforged_variant_mesh = {
        en = "Mistsplitter Reforged (variant mesh)",
    },
    spear_norse_sword_codename = {
        en = "Norse Sword (codename)",
    },
    spear_primordial_jade_cutter = {
        en = "Primordial Jade Cutter",
    },
    spear_prototype_rancour = {
        en = "Prototype Rancour",
    },
    spear_royal_longsword = {
        en = "Royal Longsword",
    },
    spear_sacrificial_sword = {
        en = "Sacrificial Sword",
    },
    spear_silver_sword = {
        en = "Silver Sword",
    },
    spear_skyrider_sword = {
        en = "Skyrider Sword",
    },
    spear_skyward_blade = {
        en = "Skyward Blade",
    },
    spear_star_sword_aether = {
        en = "Star Sword (Aether)",
    },
    spear_summit_shaper = {
        en = "Summit Shaper",
    },
    spear_sword_of_descension = {
        en = "Sword of Descension",
    },
    spear_the_alley_flash = {
        en = "The Alley Flash",
    },
    spear_the_black_sword = {
        en = "The Black Sword",
    },
    spear_the_flute = {
        en = "The Flute",
    },
    spear_transcend = {
        en = "Transcend",
    },
    spear_travelers_handy_sword = {
        en = "Traveler's Handy Sword",
    },
    spear_wooden_sword = {
        en = "Wooden Sword",
    },
    spear_beginners_protector = {
        en = "Beginner's Protector",
    },
    spear_black_tassel = {
        en = "Black Tassel",
    },
    spear_blackcliff_pole = {
        en = "Blackcliff Pole",
    },
    spear_crescent_pike = {
        en = "Crescent Pike",
    },
    spear_deathmatch = {
        en = "Deathmatch",
    },
    spear_dragons_bane = {
        en = "Dragon's Bane",
    },
    spear_dragonspine_spear = {
        en = "Dragonspine Spear",
    },
    spear_engulfing_lightning = {
        en = "Engulfing Lightning",
    },
    spear_favonius_lance = {
        en = "Favonius Lance",
    },
    spear_halberd = {
        en = "Halberd",
    },
    spear_iron_point = {
        en = "Iron Point",
    },
    spear_kitain_cross_spear = {
        en = "Kitain Cross Spear",
    },
    spear_lithic_spear = {
        en = "Lithic Spear",
    },
    spear_primordial_jade_winged_spear = {
        en = "Primordial Jade Winged-Spear",
    },
    spear_prototype_grudge = {
        en = "Prototype Grudge",
    },
    spear_regicide = {
        en = "Regicide",
    },
    spear_royal_spear = {
        en = "Royal Spear",
    },
    spear_skyward_spine = {
        en = "Skyward Spine",
    },
    spear_staff_of_homa = {
        en = "Staff of Homa",
    },
    spear_the_catch = {
        en = "The Catch",
    },
    spear_vortex_vanquisher = {
        en = "Vortex Vanquisher",
    },
    spear_wavebreakers_fin = {
        en = "Wavebreaker's Fin",
    },
    spear_white_tassel = {
        en = "White Tassel",
    },
    profile_scale = {
        en = "Length (x original weapon)",
    },
    profile_scale_description = {
        en = "1 = same length as the weapon it replaces (pommel to tip). The hand stays on the same point.",
    },
    profile_grip = {
        en = "Grip location",
    },
    profile_grip_description = {
        en = "Where the hand holds it, in model lengths. 0 = the same point as on the original weapon. Positive = nearer the tip, negative = nearer the pommel.",
    },
    profile_roll = {
        en = "Spin around the length (degrees)",
    },
    profile_roll_description = {
        en = "Turns the model around its own length, e.g. to turn the cutting edge or the flat of the blade.",
    },
    profile_tilt = {
        en = "Tilt (degrees)",
    },
    profile_tilt_description = {
        en = "Leans the model about the hand, in the plane of the blade's flat side.",
    },
    profile_flip = {
        en = "Flip end to end",
    },
    profile_flip_description = {
        en = "Use this if the tip points the wrong way (towards the pommel of the original weapon).",
    },
    reset_weapon = {
        en = "Reset selected weapon",
    },
    reset_weapon_description = {
        en = "Tick to put the selected weapon's profile back to the defaults (not replaced).",
    },
    reset_all = {
        en = "Reset all weapons",
    },
    reset_all_description = {
        en = "Tick to put every weapon's profile back to the defaults (none replaced).",
    },
    glow_brightness = {
        en = "Glow brightness",
    },
    glow_brightness_description = {
        en = "Brightness of the glowing parts of the polearms that have them (Staff of Homa, Engulfing Lightning, Skyward Spine, The Catch, Primordial Jade Winged-Spear, Lithic Spear, Royal Spear, Regicide, Blackcliff Pole). 2 = as built, 0 = off.",
    },
    menu_previews = {
        en = "Show in menus (inventory, operative previews)",
    },
    menu_previews_description = {
        en = "Also swaps the weapons in menu previews of your own operatives and in the weapon inspect view.",
    },
    toggle_staff_keybind = {
        en = "Toggle Melee Arsenal replacement",
    },
    reroll_spear_keybind = {
        en = "Reroll model",
    },
    reroll_spear_keybind_description = {
        en = "A new random model for the melee weapon you are holding, for the rest of the session. A weapon set to a fixed model goes back to random.",
    },
}
