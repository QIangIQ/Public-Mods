return {
    mod_name = {
        en = "QIangIQ's Diamond Sword",
    },
    mod_description = {
        en = "Shows your Diamond Sword model (Custom Assets) in place of the Maccabian Duelling Sword Mk IV and/or the Relic Blade Mk II. Each weapon has its own toggle. By QIangIQ.",
    },
    replace_duelling_sword = {
        en = "Replace Maccabian Duelling Sword Mk IV",
    },
    replace_duelling_sword_description = {
        en = "Weapon template combatsword_p3_m2.",
    },
    replace_relic_blade = {
        en = "Replace Relic Blade Mk II",
    },
    replace_relic_blade_description = {
        en = "Weapon template powersword_2h_p1_m2.",
    },
    duelling_tilt = {
        en = "Duelling Sword tilt (degrees)",
    },
    duelling_tilt_description = {
        en = "Turns the diamond sword in the plane of its flat side, pivoting on the hand. Positive = tip away from your body / view centre, negative = towards it.",
    },
    relic_tilt = {
        en = "Relic Blade tilt (degrees)",
    },
    relic_tilt_description = {
        en = "Turns the diamond sword in the plane of its flat side, pivoting on the hand. Positive = tip away from your body / view centre, negative = towards it.",
    },
    menu_previews = {
        en = "Show in menus (inventory, operative previews)",
    },
    menu_previews_description = {
        en = "Also swaps the weapon in menu previews of your own operatives and in the weapon inspect view.",
    },
    toggle_duelling_keybind = {
        en = "Toggle Duelling Sword replacement",
    },
    toggle_relic_keybind = {
        en = "Toggle Relic Blade replacement",
    },
}
