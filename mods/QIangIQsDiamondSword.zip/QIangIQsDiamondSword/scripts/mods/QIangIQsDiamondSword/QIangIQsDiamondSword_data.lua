local mod = get_mod("QIangIQsDiamondSword")

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = true,
    options = {
        widgets = {
            {
                setting_id = "replace_duelling_sword",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "replace_relic_blade",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "duelling_tilt",
                type = "numeric",
                default_value = 45,
                range = { -90, 90 },
                decimals_number = 0,
            },
            {
                setting_id = "relic_tilt",
                type = "numeric",
                default_value = 0,
                range = { -90, 90 },
                decimals_number = 0,
            },
            {
                setting_id = "menu_previews",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "toggle_duelling_keybind",
                type = "keybind",
                default_value = {},
                keybind_trigger = "pressed",
                keybind_type = "function_call",
                function_name = "toggle_duelling_sword",
            },
            {
                setting_id = "toggle_relic_keybind",
                type = "keybind",
                default_value = {},
                keybind_trigger = "pressed",
                keybind_type = "function_call",
                function_name = "toggle_relic_blade",
            },
        },
    },
}
