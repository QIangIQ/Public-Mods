return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsDiamondSword` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsDiamondSword", {
            mod_script = "QIangIQsDiamondSword/scripts/mods/QIangIQsDiamondSword/QIangIQsDiamondSword",
            mod_data = "QIangIQsDiamondSword/scripts/mods/QIangIQsDiamondSword/QIangIQsDiamondSword_data",
            mod_localization = "QIangIQsDiamondSword/scripts/mods/QIangIQsDiamondSword/QIangIQsDiamondSword_localization",
        })
    end,
    version = "1.1.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
