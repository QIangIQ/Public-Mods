local mod = get_mod("QIangIQsGeneralEnemyOutliner")

local OutlineSettings = require("scripts/settings/outline/outline_settings")
local ModUtils = mod:io_dofile("QIangIQsGeneralEnemyOutliner/scripts/mods/QIangIQsGeneralEnemyOutliner/ModUtils/ModUtils")
local Breeds = require("scripts/settings/breed/breeds")

local ENABLE_MOD_SETTING = "enable_mod"

-- Rave mode: every outlined enemy cycles through the rainbow, set each frame.
local rave_units = setmetatable({}, { __mode = "k" })
local TRAPPER_BREED = "renegade_netgunner"
local rave_clock = 0
local rave_was_on = false
local rave_index = setmetatable({}, { __mode = "k" })
local rave_next = 0

local function hsv_rgb(h)
    h = (h % 1) * 6
    local i = math.floor(h)
    local f = h - i
    local q = 1 - f
    if i == 0 then return 1, f, 0 end
    if i == 1 then return q, 1, 0 end
    if i == 2 then return 0, 1, f end
    if i == 3 then return 0, q, 1 end
    if i == 4 then return f, 0, 1 end
    return 1, 0, q
end

local OUTLINE_MATERIAL_LAYERS = {
    "minion_outline",
    -- "minion_outline_reversed_depth",
}


-- Outline thickness (experimental). The outline shader's variable names are not
-- in the game's Lua source, so a few likely names are tried; unknown names are
-- ignored by the engine. Only applied when "Apply thickness" is on.
local THICKNESS_VARS = { "outline_thickness", "outline_width", "outline_size", "outline_scale", "thickness" }
local applied_global = nil
local thickness_logged = false

-- The thickness value turned out to be shared by every outlined character, so
-- it is a single global value applied once per change (to any outlined unit).
local function apply_thickness(unit)
    if not mod:get("thickness_enabled") then return end
    local value = (tonumber(mod:get("global_thickness")) or 100) / 100
    if applied_global == value then return end
    applied_global = value

    local var_setting = mod:get("thickness_var") or "all"
    local method = mod:get("thickness_method") or "materials"
    for i = 1, #THICKNESS_VARS do
        local var = THICKNESS_VARS[i]
        if var_setting == "all" or var_setting == var then
            if method == "layer" then
                pcall(Unit.set_scalar_for_material, unit, "minion_outline", var, value)
            else
                pcall(Unit.set_scalar_for_materials, unit, var, value, true)
            end
        end
    end
    if not thickness_logged then
        thickness_logged = true
        mod:echo("Outliner thickness: var=" .. tostring(var_setting) .. " method=" .. tostring(method) .. " value=" .. tostring(value))
    end
end

local function round(num, decimal_places)
    local mult = 10^(decimal_places or 0)
    return math.floor(num * mult + 0.5) / mult
end

local function visibility_check(unit)
    if not unit or not HEALTH_ALIVE[unit] then
        return false
    end
    return true
end

mod.get_color_array = function(self, breed_name)
    -- Handle mutator breeds by using base breed settings
    local base_breed_name = breed_name
    if string.match(breed_name, "mutator") then
        base_breed_name = breed_name:gsub("_mutator", "")
    end
    
    -- Safely get color values with defaults to prevent nil errors
    local r = tonumber(self:get(base_breed_name .. "_r")) or 128
    local g = tonumber(self:get(base_breed_name .. "_g")) or 128
    local b = tonumber(self:get(base_breed_name .. "_b")) or 128

    return {
        round(r / 255, 3),
        round(g / 255, 3), 
        round(b / 255, 3)
    }
end

mod.update_outline_settings = function(self, instance)
    if not instance then return end

    -- Ensure MinionOutlineExtension exists
    if not instance.MinionOutlineExtension then
        instance.MinionOutlineExtension = {}
    end

    -- Clear any old outline settings from our mod
    for name, _ in pairs(instance.MinionOutlineExtension) do
        if string.find(name, "_outline") then
            instance.MinionOutlineExtension[name] = nil
        end
    end

    -- Register outline settings for each breed (including mutators)
    for breed_name, breed in pairs(Breeds) do
        if breed.tags and breed.tags.minion then
            local outline_name = breed_name .. "_outline"
            
            -- Handle mutator breeds by using base breed settings
            local base_breed_name = breed_name
            if string.match(breed_name, "mutator") then
                base_breed_name = breed_name:gsub("_mutator", "")
            end
            
            -- Safely get priority with default
            local priority = tonumber(self:get(base_breed_name .. "_priority")) or 4
            
            instance.MinionOutlineExtension[outline_name] = {
                priority = priority,
                color = self:get_color_array(breed_name),
                material_layers = OUTLINE_MATERIAL_LAYERS,
                visibility_check = visibility_check
            }
        end
    end
end

mod.on_setting_changed = function(setting_id)
    applied_global = nil
    mod:update_outline_settings(OutlineSettings)
end

mod:hook_require("scripts/settings/outline/outline_settings", function(instance)
    mod:update_outline_settings(instance)
end)

local function set_outline_color(unit, outline_unit_data_extension)
    if not unit or not outline_unit_data_extension then return end

    if outline_unit_data_extension.outlines then
        for _, outline in ipairs(outline_unit_data_extension.outlines) do
            if string.find(outline.name, "_outline") then
                local color = outline_unit_data_extension.settings[outline.name].color
                if color then
                    Unit.set_vector3_for_materials(unit, "outline_color", Vector3(color[1], color[2], color[3]), true)
                end
                break
            end
        end
    end
end

function mod.tick(self)
    if not self:get(ENABLE_MOD_SETTING) then return end
    
    local outline_system = ModUtils.get_outline_system()
    if not outline_system then return end

    local enemy_units_lookup = ModUtils.get_enemy_units_lookup()
    if not enemy_units_lookup then return end

    for enemy_unit, _ in pairs(enemy_units_lookup) do
        if not HEALTH_ALIVE[enemy_unit] then goto continue end

        local outline_unit_data_extension = outline_system._unit_extension_data[enemy_unit]
        if not outline_unit_data_extension then goto continue end

        local enemy_unit_data_extension = ScriptUnit.extension(enemy_unit, "unit_data_system")
        local breed = enemy_unit_data_extension:breed()
        if not breed then goto continue end

        local breed_name = breed.name
        local outline_name = breed_name .. "_outline"
        
        -- Handle mutator breeds by using base breed settings
        local base_breed_name = breed_name
        if string.match(breed_name, "mutator") then
            base_breed_name = breed_name:gsub("_mutator", "")
        end
        
        local is_enabled = self:get(base_breed_name .. "_enabled") or false

        -- Check if this unit currently has our outline
        local has_our_outline = false
        if outline_unit_data_extension.outlines then
            for _, outline in ipairs(outline_unit_data_extension.outlines) do
                if outline.name == outline_name then
                    has_our_outline = true
                    break
                end
            end
        end

        if is_enabled and breed_name == TRAPPER_BREED then
            rave_units[enemy_unit] = breed_name
        else
            rave_units[enemy_unit] = nil
        end

        -- Apply or remove outline based on setting
        if is_enabled and not has_our_outline then
            outline_system:add_outline(enemy_unit, outline_name)
            
            -- Update the color
            local updated_outline_extension = outline_system._unit_extension_data[enemy_unit]
            if updated_outline_extension then
                set_outline_color(enemy_unit, updated_outline_extension)
            end
        elseif not is_enabled and has_our_outline then
            outline_system:remove_outline(enemy_unit, outline_name)
        end

        if is_enabled then
            apply_thickness(enemy_unit)
        end

        ::continue::
    end
end

local cooldown = 0.0
function mod.update(dt)
    local rave_on = mod:get("rave_mode") and mod:get(ENABLE_MOD_SETTING)
    if rave_on then
        rave_was_on = true
        rave_clock = rave_clock + dt
        local speed = (tonumber(mod:get("rave_speed")) or 30) / 100
        for unit in pairs(rave_units) do
            if HEALTH_ALIVE[unit] then
                local idx = rave_index[unit]
                if not idx then
                    rave_next = rave_next + 1
                    idx = rave_next
                    rave_index[unit] = idx
                end
                local r, g, b = hsv_rgb(rave_clock * speed + idx * 0.11)
                pcall(Unit.set_vector3_for_materials, unit, "outline_color", Vector3(r, g, b), true)
            else
                rave_units[unit] = nil
            end
        end
    elseif rave_was_on then
        -- rave switched off: give the trappers their own colour back
        rave_was_on = false
        for unit, breed_name in pairs(rave_units) do
            if HEALTH_ALIVE[unit] then
                local c = mod:get_color_array(breed_name)
                pcall(Unit.set_vector3_for_materials, unit, "outline_color", Vector3(c[1], c[2], c[3]), true)
            end
        end
    end
    if cooldown > 0 then
        cooldown = cooldown - dt
    else
        cooldown = 0.3 -- 300ms
        mod:tick()
    end
end