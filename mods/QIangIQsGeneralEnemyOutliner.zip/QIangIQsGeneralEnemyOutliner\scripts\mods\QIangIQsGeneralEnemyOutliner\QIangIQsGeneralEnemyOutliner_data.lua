local mod = get_mod("QIangIQsGeneralEnemyOutliner")
local Breeds = require("scripts/settings/breed/breeds")

local horde_and_roamers = {}
local elites = {}
local specials = {}
local monsters = {}
local ritualists = {}

local function add_breed_widgets(tbl, breed_name, default_value)
    -- Main toggle for this breed
    tbl[#tbl + 1] = {
        setting_id = breed_name .. "_enabled",
        title = breed_name .. "_title",
        type = "checkbox",
        default_value = default_value
    }
    
    -- Priority setting
    tbl[#tbl + 1] = {
        setting_id = breed_name .. "_priority",
        tooltip = "priority_tooltip",
        title = "priority_title",
        type = "numeric",
        default_value = 4,
        range = {1, 10},
        decimals_number = 0
    }
    
    -- Color settings
    tbl[#tbl + 1] = {
        setting_id = breed_name .. "_r",
        title = "title_r",
        type = "numeric",
        default_value = 128,
        range = {0, 255},
        decimals_number = 0
    }
    
    tbl[#tbl + 1] = {
        setting_id = breed_name .. "_g",
        title = "title_g",
        type = "numeric",
        default_value = 128,
        range = {0, 255},
        decimals_number = 0
    }
    
    tbl[#tbl + 1] = {
        setting_id = breed_name .. "_b",
        title = "title_b",
        type = "numeric",
        default_value = 128,
        range = {0, 255},
        decimals_number = 0
    }
end

-- Generate widgets for all enemy breeds (excluding mutators)
for breed_name, breed in pairs(Breeds) do
    if breed.tags and breed.tags.minion and not string.match(breed_name, "mutator") then
        local default_value = false
        
        -- Enable by default for important enemies
        if breed.tags.elite or breed.tags.special or breed.tags.ritualist then
            default_value = true
        end
        
        -- Categorize based on tags
        if breed.tags.horde or breed.tags.roamer then
            add_breed_widgets(horde_and_roamers, breed_name, default_value)
        elseif breed.tags.elite then
            add_breed_widgets(elites, breed_name, default_value)
        elseif breed.tags.special then
            add_breed_widgets(specials, breed_name, default_value)
        elseif breed.tags.monster or breed.tags.captain or breed.tags.cultist_captain then
            add_breed_widgets(monsters, breed_name, default_value)
        elseif breed.tags.ritualist then
            add_breed_widgets(ritualists, breed_name, default_value)
        end
    end
end

local widgets = {
    {
        setting_id = "mod_toggles",
        type = "group",
        sub_widgets = {
            {
                setting_id = "enable_mod",
                title = "enable",
                tooltip = "enable_mod_tooltip",
                type = "checkbox",
                default_value = true
            },
            {
                setting_id = "thickness_enabled",
                title = "thickness_enable_title",
                tooltip = "thickness_enable_tooltip",
                type = "checkbox",
                default_value = false
            },
            {
                setting_id = "global_thickness",
                title = "global_thickness_title",
                tooltip = "global_thickness_tooltip",
                type = "numeric",
                default_value = 100,
                range = {1, 500},
                decimals_number = 0
            },
            {
                setting_id = "thickness_var",
                title = "thickness_var_title",
                tooltip = "thickness_var_tooltip",
                type = "dropdown",
                default_value = "all",
                options = {
                    { text = "thickness_opt_all", value = "all" },
                    { text = "thickness_opt_outline_thickness", value = "outline_thickness" },
                    { text = "thickness_opt_outline_width", value = "outline_width" },
                    { text = "thickness_opt_outline_size", value = "outline_size" },
                    { text = "thickness_opt_outline_scale", value = "outline_scale" },
                    { text = "thickness_opt_thickness", value = "thickness" },
                }
            },
            {
                setting_id = "thickness_method",
                title = "thickness_method_title",
                tooltip = "thickness_method_tooltip",
                type = "dropdown",
                default_value = "materials",
                options = {
                    { text = "thickness_method_materials", value = "materials" },
                    { text = "thickness_method_layer", value = "layer" },
                }
            },
            {
                setting_id = "rave_mode",
                title = "rave_title",
                tooltip = "rave_tooltip",
                type = "checkbox",
                default_value = false
            },
            {
                setting_id = "rave_speed",
                title = "rave_speed_title",
                tooltip = "rave_speed_tooltip",
                type = "numeric",
                default_value = 30,
                range = {5, 200},
                decimals_number = 0
            }
        }
    },
    {
        setting_id = "horde_breeds",
        type = "group",
        sub_widgets = horde_and_roamers
    },
    {
        setting_id = "elite_breeds",
        type = "group",
        sub_widgets = elites
    },
    {
        setting_id = "special_breeds",
        type = "group",
        sub_widgets = specials
    },
    {
        setting_id = "monster_breeds",
        type = "group",
        sub_widgets = monsters
    },
    {
        setting_id = "ritualist_breeds",  -- Added ritualists group
        type = "group",
        sub_widgets = ritualists
    }
}

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = true,
    allow_rehooking = true,
    options = {
        widgets = widgets
    }
}