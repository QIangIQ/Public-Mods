local Breeds = require("scripts/settings/breed/breeds")

local localization = {
    rave_title = {
        en = "Rave trappers (rainbow outline)",
    },
    rave_tooltip = {
        en = "Only trappers: their outline constantly cycles through the colours, so they stand out from every other enemy.",
    },
    thickness_enable_title = {
        en = "Apply thickness settings (experimental)",
    },
    thickness_enable_tooltip = {
        en = "Off by default so outlines look exactly as before. When on, the per-enemy and global thickness below are sent to the outline material.",
    },
    thickness_var_title = { en = "Thickness variable (experimental)" },
    thickness_var_tooltip = { en = "Which outline material variable receives the thickness. 'All' tries every candidate. If thickness changes the wrong enemies, try one at a time." },
    thickness_opt_all = { en = "All candidates" },
    thickness_opt_outline_thickness = { en = "outline_thickness" },
    thickness_opt_outline_width = { en = "outline_width" },
    thickness_opt_outline_size = { en = "outline_size" },
    thickness_opt_outline_scale = { en = "outline_scale" },
    thickness_opt_thickness = { en = "thickness" },
    thickness_method_title = { en = "Thickness method (experimental)" },
    thickness_method_tooltip = { en = "All materials: set on every material of the unit. Outline layer only: set only on the unit's 'minion_outline' layer, the way the game sets outline colour per unit." },
    thickness_method_materials = { en = "All materials" },
    thickness_method_layer = { en = "Outline layer only" },
    global_thickness_title = {
        en = "Outline thickness (percent, all enemies)",
    },
    global_thickness_tooltip = {
        en = "Thickness of every outlined character at once, 100 = normal. The game shares this value between all outlines, so it cannot be set per enemy.",
    },
    title_thickness = {
        en = "Outline thickness (percent)",
    },
    thickness_tooltip = {
        en = "This enemy's outline thickness, 100 = normal. Needs 'Apply thickness settings' on.",
    },
    rave_speed_title = {
        en = "Rave speed",
    },
    rave_speed_tooltip = {
        en = "How fast the colours cycle (cycles per 100 seconds).",
    },
    mod_name = {
        en = "QIangIQ's General Enemy Outliner",
        
    },
    mod_description = {
        en = "take a MASSIVE guess on what this does",
        
    },
    enable = {
        en = "Enable",
       
    },
    enable_mod_tooltip = {
        en = "im going insane",
       
    },
    priority_title = {
        en = "Priority",
       
    },
    priority_tooltip = {
        en = "lower value = higher priority",
        
    },
    title_r = {
        en = "R",
        de = "Rot",
        ["zh-cn"] = "红",
        ["zh-tw"] = "紅",
        ru = "Красный",
        fr = "R",
    },
    title_g = {
        en = "G", 
        de = "Grün",
        ["zh-cn"] = "绿",
        ["zh-tw"] = "綠",
        ru = "Зелёный",
        fr = "V",
    },
    title_b = {
        en = "B",
        de = "Blau",
        ["zh-cn"] = "蓝",
        ["zh-tw"] = "藍",
        ru = "Синий",
        fr = "B",
    },
    -- Category headers
    horde_breeds = {
        en = "Horde & Roamers",
        ["zh-cn"] = "群怪 & 游荡",
        ["zh-tw"] = "群怪 & 遊蕩",
        ru = "Орда & Бродяги",
        fr = "Horde & Rôdeurs",
    },
    elite_breeds = {
        en = "Elites",
        ["zh-cn"] = "精英", 
        ["zh-tw"] = "菁英",
        ru = "Элиты",
        fr = "Élites",
    },
    special_breeds = {
        en = "Specials",
        ["zh-cn"] = "专家",
        ["zh-tw"] = "專家",
        ru = "Специалисты",
        fr = "Spéciaux",
    },
    monster_breeds = {
        en = "Monsters & Captains",
        ["zh-cn"] = "怪物 & 连长",
        ["zh-tw"] = "怪物 & 連長",
        ru = "Монстры & Капитаны",
        fr = "Monstres & Capitaines",
    },
    ritualist_breeds = {
        en = "Ritualists",
        ["zh-cn"] = "仪式师",
        ["zh-tw"] = "儀式師",
        ru = "Ритуалисты",
        fr = "Ritualistes",
    }
}

-- Handle unlocalized breeds like Healthbars does
local unlocalized_breeds = {
    chaos_lesser_mutated_poxwalker = {
        en = "Lesser mutated poxwalker",
        ru = "Малый мутировавший чумной ходок",
        fr = "Scrofuleux inférieure muté",
        ["zh-cn"] = "次级变异poxwalker",
        ["zh-tw"] = "次級變異poxwalker"
    },
    chaos_mutated_poxwalker = {
        en = "Mutated poxwalker",
        ru = "Мутировавший чумной ходок",
        fr = "Scrofuleux muté",
        ["zh-cn"] = "变异poxwalker",
        ["zh-tw"] = "變異poxwalker"
    },
}

-- Add localization for each breed
for breed_name, breed in pairs(Breeds) do
    if breed.tags and breed.tags.minion then
        local display_name = Localize(breed.display_name)
        
        -- Handle unlocalized breeds
        if string.find(display_name, "<unlocalized") then
            if unlocalized_breeds[breed_name] then
                localization[breed_name .. "_title"] = unlocalized_breeds[breed_name]
            else
                localization[breed_name .. "_title"] = {
                    en = breed_name,
                    ["zh-cn"] = breed_name,
                    ["zh-tw"] = breed_name,
                    ru = breed_name,
                    fr = breed_name
                }
            end
        else
            localization[breed_name .. "_title"] = {
                en = display_name,
                ["zh-cn"] = display_name,
                ["zh-tw"] = display_name,
                ru = display_name,
                fr = display_name
            }
        end
        
        -- Tooltip for the enable setting
        localization[breed_name .. "_enabled"] = {
            en = "Outline " .. display_name,
            ["zh-cn"] = "轮廓 " .. display_name,
            ["zh-tw"] = "輪廓 " .. display_name,
            ru = "Контур " .. display_name,
            fr = "Contour " .. display_name
        }
    end
end

return localization