return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsGeneralEnemyOutliner` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsGeneralEnemyOutliner", {
			mod_script       = "QIangIQsGeneralEnemyOutliner/scripts/mods/QIangIQsGeneralEnemyOutliner/QIangIQsGeneralEnemyOutliner",
			mod_data         = "QIangIQsGeneralEnemyOutliner/scripts/mods/QIangIQsGeneralEnemyOutliner/QIangIQsGeneralEnemyOutliner_data",
			mod_localization = "QIangIQsGeneralEnemyOutliner/scripts/mods/QIangIQsGeneralEnemyOutliner/QIangIQsGeneralEnemyOutliner_localization",
		})
	end,
	packages = {},
}
