return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsGuaranteeSuite` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsGuaranteeSuite", {
			mod_script       = "QIangIQsGuaranteeSuite/scripts/mods/QIangIQsGuaranteeSuite/QIangIQsGuaranteeSuite",
			mod_data         = "QIangIQsGuaranteeSuite/scripts/mods/QIangIQsGuaranteeSuite/QIangIQsGuaranteeSuite_data",
			mod_localization = "QIangIQsGuaranteeSuite/scripts/mods/QIangIQsGuaranteeSuite/QIangIQsGuaranteeSuite_localization",
		})
	end,
	-- Union of the load_after lists of the three guarantee mods.
	load_after = {
		"modding_tools",
		"MultiBind",
		"Skitarius",
		"ToggleAltFire",
		"weapon_customization",
	},
	packages = {},
}
