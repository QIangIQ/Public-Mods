local mod = get_mod("QIangIQsGuaranteeSuite")

-- Every module's widgets are the original mod's widgets, unchanged except that
-- setting ids, group ids and dropdown option texts get the module's prefix
-- (so two modules can both have e.g. "enable_debug_modding_tools").

local function prefix_widgets(prefix, widgets)
	for _, widget in ipairs(widgets) do
		widget.setting_id = prefix .. widget.setting_id
		if widget.options then
			for _, option in ipairs(widget.options) do
				if not option.raw then
					option.text = prefix .. option.text
				end
				option.raw = nil
			end
		end
		if widget.sub_widgets then
			prefix_widgets(prefix, widget.sub_widgets)
		end
	end
	return widgets
end

local function module_group(prefix, default_enabled, widgets)
	local sub_widgets = {
		{
			setting_id = prefix .. "enabled",
			type = "checkbox",
			default_value = default_enabled,
			title = "module_enabled",
			tooltip = "module_enabled_description",
		},
	}
	for _, widget in ipairs(prefix_widgets(prefix, widgets)) do
		sub_widgets[#sub_widgets + 1] = widget
	end
	return {
		setting_id = prefix .. "group",
		type = "group",
		title = prefix .. "mod_name",
		tooltip = prefix .. "mod_description",
		sub_widgets = sub_widgets,
	}
end

---------------------------------------------------------------------------
-- Guarantee Ability Activation (KamiUnitY) - original widgets
---------------------------------------------------------------------------
local gaa = {
	{
		setting_id = "enable_prevent_relic_cancel",
		type = "checkbox",
		default_value = false,
	},
	{
		setting_id = "enable_prevent_relic_sprint",
		type = "checkbox",
		default_value = false,
	},
	{
		setting_id = "enable_prevent_ability_aiming",
		type = "checkbox",
		default_value = false,
	},
	{
		setting_id  = "debug_group",
		type        = "group",
		sub_widgets = {
			{
				setting_id = "enable_debug_modding_tools",
				type = "checkbox",
				default_value = false,
			},
		}
	},
}

---------------------------------------------------------------------------
-- Guarantee Special Action (KamiUnitY) - original widgets
---------------------------------------------------------------------------
local gsa = {
	{
		setting_id = "enable_blocking_cancel_special",
		type = "checkbox",
		default_value = true,
	},
	{
		setting_id = "enable_ads_cancel_special",
		type = "checkbox",
		default_value = true,
	},
	{
		setting_id  = "debug_group",
		type        = "group",
		sub_widgets = {
			{
				setting_id = "enable_debug_modding_tools",
				type = "checkbox",
				default_value = false,
			},
		}
	},
}

---------------------------------------------------------------------------
-- Guarantee Weapon Swap (KamiUnitY) - original widgets
---------------------------------------------------------------------------
local gws = {
	{
		setting_id = "queue_limit",
		type            = "numeric",
		default_value   = 3,
		range           = { 1, 5 }
	},
	{
		setting_id = "enable_quick_grenades",
		type = "checkbox",
		default_value = true,
	},
	{
		setting_id  = "debug_group",
		type        = "group",
		sub_widgets = {
			{
				setting_id = "enable_debug_modding_tools",
				type = "checkbox",
				default_value = false,
			},
		}
	},
}

---------------------------------------------------------------------------
-- Instant Ability (Seph) - had no settings; the Chordclaw exception is ours
---------------------------------------------------------------------------
local ia = {
	{
		setting_id = "chordclaw_exception",
		type = "dropdown",
		default_value = "axial",
		options = {
			{ text = "exception_axial", value = "axial" },
			{ text = "exception_any_chordclaw", value = "any_chordclaw" },
			{ text = "exception_never", value = "never" },
		},
	},
}

---------------------------------------------------------------------------
-- Audible Ability Recharge (demba) - original widgets
-- Custom sound files now go in mods\QIangIQsGuaranteeSuite\audio
-- (Audio plugin mod required for files, as before).
---------------------------------------------------------------------------
local function getFolderContents(dir)
	local ok, files = pcall(function()
		local handle = Mods.lua.io.popen("dir " .. dir .. " /b /a-d 2>nul")
		local result = handle:read("*a")
		handle:close()
		local list = {}
		for filename in result:gmatch("[^\r\n]+") do
			table.insert(list, filename)
		end
		return list
	end)
	return ok and files or {}
end

local function fillDropdown(options)
	local a = getFolderContents("..\\mods\\QIangIQsGuaranteeSuite\\audio")
	for _, t in ipairs(a) do table.insert(options, { text = t, value = t, raw = true }) end
	return options
end

local function aar_sound_options()
	return fillDropdown({
		{text = "chaos_spawn_ground_impact_large_default", value = "wwise/events/minions/play_chaos_spawn_ground_impact_large_default"},
		{text = "auspex_bio_minigame_selection_right", value = "wwise/events/player/play_device_auspex_bio_minigame_selection_right"},
		{text = "auspex_bio_minigame_selection_wrong", value = "wwise/events/player/play_device_auspex_bio_minigame_selection_wrong"},
		{text = "psyker_lightning_bolt_impact_death", value = "wwise/events/weapon/play_psyker_lightning_bolt_impact_death"},
		{text = "bullet_hits_explosive_gen", value = "wwise/events/weapon/play_bullet_hits_explosive_gen"},
		{text = "plague_ogryn_stomp_metal", value = "wwise/events/minions/play_enemy_character_foley_plague_ogryn_stomp_metal"},
		{text = "plasma_gun_overheat_intensity", value = "wwise/events/weapon/play_plasmagun_overheat_intensity_01"},
		{text = "psyker_lightning_bolt", value = "wwise/events/weapon/play_psyker_lightning_bolt"},
		{text = "hits_blunt_shield", value = "wwise/events/weapon/melee_hits_blunt_shield"},
		{text = "zealot_bolstering_prayer", value = "wwise/events/player/play_ability_zealot_bolstering_prayer"},
		{text = "netgun_shot", value = "wwise/events/minions/play_weapon_netgunner"},
		{text = "ogryn_taunt_shout", value = "wwise/events/player/play_ogryn_ability_taunt"},
		{text = "psyker_shout", value = "wwise/events/player/play_psyker_ability_shout"},
		{text = "veteran_shout", value = "wwise/events/player/play_veteran_ability_shout"},
	})
end

local aar = {
	{
		setting_id = "in_gameSounds",
		type = "group",
		sub_widgets = {
			{
				setting_id = "ability_charge1_sound", type = "dropdown", default_value = "wwise/events/player/play_device_auspex_bio_minigame_selection_wrong", options = aar_sound_options(),
			},
			{
				setting_id = "ability_charge2_sound", type = "dropdown", default_value = "wwise/events/player/play_device_auspex_bio_minigame_selection_right", options = aar_sound_options(),
			},
		},
	},
}

---------------------------------------------------------------------------
-- Audible Grenade Regen (demba) - original widgets
---------------------------------------------------------------------------
local function agr_sound_options(with_foley)
	local options = {
		{text = "pick_up_grenade", value = "wwise/events/player/play_pick_up_grenade"},
		{text = "pick_up_forge_material_small", value = "wwise/events/player/play_pick_up_forge_material_small"},
		{text = "pick_up_forge_material_large", value = "wwise/events/player/play_pick_up_forge_material_large"},
		{text = "pick_up_forge_material_platinum_small", value = "wwise/events/player/play_pick_up_forge_material_platinum_small"},
		{text = "pick_up_forge_material_platinum_large", value = "wwise/events/player/play_pick_up_forge_material_platinum_large"},
		{text = "pick_up_syringe", value = "wwise/events/player/play_pick_up_syringe"},
		{text = "pick_up_tome", value = "wwise/events/player/play_pick_up_tome"},
		{text = "pick_up_ammo_pack", value = "wwise/events/player/play_pick_up_ammopack"},
	}
	if with_foley then
		options[#options + 1] = {text = "player_foley_receive_item", value = "wwise/events/player/play_player_foley_receive_item_gen"}
	end
	local rest = {
		{text = "chaos_spawn_ground_impact_large", value = "wwise/events/minions/play_chaos_spawn_ground_impact_large_default"},
		{text = "bullet_hits_explosive_gen", value = "wwise/events/weapon/play_bullet_hits_explosive_gen"},
		{text = "hits_blunt_shield", value = "wwise/events/weapon/melee_hits_blunt_shield"},
		{text = "auspex_bio_minigame_selection_right", value = "wwise/events/player/play_device_auspex_bio_minigame_selection_right"},
		{text = "auspex_bio_minigame_selection_wrong", value = "wwise/events/player/play_device_auspex_bio_minigame_selection_wrong"},
		{text = "plague_ogryn_stomp_metal", value = "wwise/events/minions/play_enemy_character_foley_plague_ogryn_stomp_metal"},
		{text = "psyker_lightning_bolt_impact_death", value = "wwise/events/weapon/play_psyker_lightning_bolt_impact_death"},
	}
	for _, option in ipairs(rest) do
		options[#options + 1] = option
	end
	return options
end

local agr = {
	{
		setting_id = "rock_and_demolition_stockpile_alternate_sound", type = "dropdown", default_value = "wwise/events/player/play_pick_up_grenade", options = agr_sound_options(true),
	},
	{
		setting_id = "demolition_team_alternate_sound_toggle", type = "checkbox", default_value = false,
	},
	{
		setting_id = "demolition_team_alternate_sound", type = "dropdown", default_value = "wwise/events/player/play_pick_up_grenade", options = agr_sound_options(false),
	},
}

---------------------------------------------------------------------------
-- Ability God (Kevinna) - original widgets; "master_enable" is the module
-- switch above.
---------------------------------------------------------------------------
local MODE = {
	never=1,
	tough=2,
	peril=3,
	health=4,
	tough_or_peril=5, -- legacy "both"
	tough_or_health=6,
	peril_or_health=7,
	tough_or_peril_or_health=8,
}

local function opts_psyker()
	return {
		{ text = "mode_never", value = MODE.never },
		{ text = "mode_tough", value = MODE.tough },
		{ text = "mode_peril", value = MODE.peril },
		{ text = "mode_health", value = MODE.health },
		{ text = "mode_tough_or_peril", value = MODE.tough_or_peril },
		{ text = "mode_tough_or_health", value = MODE.tough_or_health },
		{ text = "mode_peril_or_health", value = MODE.peril_or_health },
		{ text = "mode_tough_or_peril_or_health", value = MODE.tough_or_peril_or_health },
	}
end
local function opts_other()
	return {
		{ text = "mode_never", value = MODE.never },
		{ text = "mode_tough", value = MODE.tough },
		{ text = "mode_health", value = MODE.health },
		{ text = "mode_tough_or_health", value = MODE.tough_or_health },
	}
end

local function ag_group(header, ids, opts)
	local sub_widgets = {}
	for _, id in ipairs(ids) do
		sub_widgets[#sub_widgets + 1] = { setting_id = id, type = "dropdown", default_value = MODE.never, options = opts() }
	end
	return { setting_id = header, type = "group", sub_widgets = sub_widgets }
end

local ag = {
	{ setting_id = "toughness_thresh", type = "numeric", default_value = 20, range = { 1, 100 } },
	{ setting_id = "peril_thresh", type = "numeric", default_value = 90, range = { 1, 100 } },
	{ setting_id = "health_thresh", type = "numeric", default_value = 50, range = { 1, 100 } },
	ag_group("header_veteran", { "veteran_exec", "veteran_voice", "veteran_infil" }, opts_other),
	ag_group("header_psyker", { "psyker_shout", "psyker_shield", "psyker_over" }, opts_psyker),
	ag_group("header_zealot", { "zealot_dash", "zealot_prayer", "zealot_stealth" }, opts_other),
	ag_group("header_ogryn", { "ogryn_rush", "ogryn_taunt", "ogryn_ammo" }, opts_other),
	ag_group("header_arbiter", { "arbiter_stance", "arbiter_drone", "arbiter_charge" }, opts_other),
	ag_group("header_broker", { "broker_focus", "broker_punk", "broker_stimm" }, opts_other),
}

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			-- Default on/off matches what was in mod_load_order.txt: the three
			-- guarantee mods (weapon swap was not loaded, but is requested here),
			-- Instant Ability, Audible Ability Recharge and Ability God were on;
			-- Audible Grenade Regen was installed but not loaded.
			module_group("gaa_", true, gaa),
			module_group("gsa_", true, gsa),
			module_group("gws_", true, gws),
			module_group("ia_", true, ia),
			module_group("aar_", true, aar),
			module_group("agr_", false, agr),
			module_group("ag_", true, ag),
		},
	},
}
