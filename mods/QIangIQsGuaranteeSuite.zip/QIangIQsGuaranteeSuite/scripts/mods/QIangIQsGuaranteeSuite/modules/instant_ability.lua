--[[
┌───────────────────────────────────────────────────────────────────────────────────────────┐
│ Mod Name: Instant Ability                                                                 │
│ Mod Description: Actives your ability the moment you press the button.                    |
│ Mod Author: Seph (Steam: Concoction of Constitution)                                      │
└───────────────────────────────────────────────────────────────────────────────────────────┘
--]]
-- Ported into QIangIQs Guarantee Suite. The input logic below is Seph's, unchanged.
-- Added: while the suite reports the Chordclaw exception (Axial Slash by
-- default, see QIangIQsGuaranteeSuite.lua), the ability key is passed through
-- untouched, so holding it aims the Chordclaw lunge as in the base game.
local suite = get_mod("QIangIQsGuaranteeSuite")
local mod = suite.sub("instant_ability")
local ca = false
mod:hook("InputService", "_get", function(f, s, action_name)
    if suite.instant_ability_paused() then
        ca = false
        return f(s, action_name)
    end
    local x = f(s, action_name)
    if action_name == "combat_ability_hold" then
        ca = x
        return false
    end
    if x == true and action_name == "combat_ability_release" and ca then return true end
    -- if x == true then mod:echo(action_name) end
    return x
end)
