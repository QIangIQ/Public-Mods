--audible_grenade_regen
--created by demba

local mod = get_mod("QIangIQsGuaranteeSuite").sub("audible_grenade_regen")
local enabled = true
function mod.on_enabled() enabled = true end
function mod.on_disabled() enabled = false end
local playSound = function(soundfile)
    local world = Managers.world:world("level_world")
    local wwise_world = Managers.world:wwise_world(world)
    WwiseWorld.trigger_resource_event(wwise_world, soundfile)
end

local CharacterSheet = require("scripts/utilities/character_sheet")
mod:hook_safe("WwiseWorld","trigger_resource_event",function(s, file_path, ...)
    if file_path == "wwise/events/player/play_player_grenade_charge_restored_gen" then
        if enabled then playSound(mod:get("rock_and_demolition_stockpile_alternate_sound")) end
    elseif file_path == "wwise/events/player/play_pick_up_ammo_01" then
        if mod:get("demolition_team_alternate_sound_toggle") then playSound(mod:get("demolition_team_alternate_sound")) end
    end       
end)
