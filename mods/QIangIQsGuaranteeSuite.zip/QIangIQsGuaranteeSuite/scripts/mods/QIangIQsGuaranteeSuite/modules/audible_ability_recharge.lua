--audible_ability_recharge
--created by demba

local mod = get_mod("QIangIQsGuaranteeSuite").sub("audible_ability_recharge")
local once = false
mod.playSound = function(sound)
    local world = Managers.world:world("level_world")
    local wwise_world = Managers.world:wwise_world(world)
    WwiseWorld.trigger_resource_event(wwise_world, sound)
end
local Audio = get_mod("Audio")
mod.on_all_mods_loaded = function()
    Audio = get_mod("Audio")  
end
-- Local change for Darktide 1.13: PlayerUnitAbilityExtension.remaining_ability_cooldown
-- no longer exists (log: "trying to hook function or method that doesn't exist"),
-- so the old hook never ran and no sound played. 1.13 abilities regenerate charges
-- instead (Dio's Handholder DHT_teammate_ability.lua:213-216), and
-- remaining_ability_charges still exists (same file, line 273). A recharge is the
-- charge count going up, which is also the moment the old hook fired, so the same
-- two sounds play at the same times.
local function play_charge_sound(r)
    local setting = r == 1 and "ability_charge1_sound" or r == 2 and "ability_charge2_sound" or nil
    if not setting then
        return
    end

    local sound = mod:get(setting)
    if type(sound) ~= "string" then
        return
    end

    if string.find(sound, "%.") then
        if Audio ~= nil then Audio.play_file(sound, { audio_type = "sfx" }) end
    elseif string.sub(sound, 1, 5) == "wwise" then
        mod.playSound(sound)
    end
end

local last_unit = nil
local last_charges = nil

mod.update = function(dt)
    local player = Managers.player and Managers.player:local_player_safe(1)
    local unit = player and player.player_unit

    if not unit or not ALIVE[unit] then
        last_unit, last_charges = nil, nil
        return
    end

    local ability_extension = ScriptUnit.has_extension(unit, "ability_system")
    if not ability_extension or not ability_extension.remaining_ability_charges then
        return
    end

    local ok, charges = pcall(ability_extension.remaining_ability_charges, ability_extension, "combat_ability")
    if not ok or type(charges) ~= "number" then
        return
    end

    if unit ~= last_unit then
        -- New unit (spawn / respawn): take the current count as the baseline.
        last_unit, last_charges = unit, charges
        return
    end

    if last_charges and charges > last_charges then
        pcall(play_charge_sound, charges)
    end

    last_charges = charges
end
