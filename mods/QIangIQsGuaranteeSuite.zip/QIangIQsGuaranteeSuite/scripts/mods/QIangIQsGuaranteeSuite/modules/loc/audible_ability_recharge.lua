return {
	mod_description = {
		en = "Choose from a list of alternate in-game sounds or upload a custom sound file in the audio folder of this mod (Audio Plugin Mod required), to play when gaining first and second ability charge. If you add a new sound in the audio folder while the game is running, ensure you reload mods (CTRL+SHIFT+R) to update dropdowns."
	},
	mod_name = {
		en = "Audible Ability Recharge",
	},
	ability_charge1_sound = {
		en = "Ability Charge 1",
	},
	ability_charge2_sound = {
		en = "Ability Charge 2",
	},
	ability_charge1_sound_description = {
		en = "Choose an alternate in-game sound to play when gaining Ability Charge 1",
	},
	ability_charge2_sound_description = {
		en = "Choose an alternate in-game sound to play when gaining Ability Charge 2",
	},
	auspex_bio_minigame_selection_right = {
		en = "auspex bio minigame selection right",
	},
	auspex_bio_minigame_selection_wrong = {
		en = "auspex bio minigame selection wrong",
	},
	chaos_spawn_ground_impact_large_default = {
		en = "chaos spawn large ground impact",
	},
	plague_ogryn_stomp_metal = {
		en = "plague ogryn stomp metal",
	},
	bullet_hits_explosive_gen = {
		en = "bullet hits explosive gen",
	},
	psyker_lightning_bolt_impact_death = {
		en = "psyker lightning bolt impact death",
	},
	plasma_gun_overheat_intensity = {
		en = "plasma gun overhead intensity",
	},
	psyker_lightning_bolt = {
		en = "psyker lightning bolt",
	},
	hits_blunt_shield = {
		en = "hits blunt shield"
	},
	zealot_bolstering_prayer = {
		en = "zealot bolstering prayer",
	},
	netgun_shot = {
		en = "netgun shot",
	},
	ogryn_taunt_shout = {
		en = "ogryn taunt shout",
	},
	veteran_shout = {
		en = "veteran shout",
	},
	psyker_shout = {
		en = "psyker venting shriek",
	},
	psyker_equip_single_shard = {
		en = "psyker equip single shard",
	},
	psyker_restored_final_shard = {
		en = "psyker restored final shard",
	},
	use_custom_sounds1 = {
		en = "Ability Charge 1",
	},
	use_custom_sounds2 = {
		en = "Ability Charge 2",
	},
	use_custom_sounds1_description = {
		en = "Enable/Disable Custom Sound File charge1.opus for Ability Charge 1, overrides dropdown.",
	},
	use_custom_sounds2_description = {
		en = "Enable/Disable Custom Sound File charge2.opus for Ability Charge 2, overrides dropdown.",
	},
	CustomSoundFileToggles = {
		en = "Custom Sound File Toggles (Audio Plugin required)",
	},
	in_gameSoundToggles = {
		en = "In-Game Sound Toggles"
	},
	in_gameSounds = {
		en = "In-Game Sounds",
	},
}
