return {
	mod_description = {
		en = "Configure an alternate sound for Big Friendly Rock, Demolition Stockpile, Lone Wolf Keystone (Arbites Grenade/Shock Mine) regeneration sound. OPTIONAL: Configure an alternate sound for Demolition Team.",
	},
	mod_name = {
		en = "Audible Grenade Regen",
	},
	rock_and_demolition_stockpile_alternate_sound = {
		en = "Demolition Stockpile, Rock & Lone Wolf Alternate Regeneration Sound",
	},
	rock_and_demolition_stockpile_alternate_sound_description = {
		en = "Always enabled, pick_up_grenade by default, does not apply to Lone Wolf Remote Detonation regeneration sounds."
	},
	demolition_team_alternate_sound_toggle = {
		en = "Demolition Team Alternate Regeneration Sound Toggle",
	},
	demolition_team_alternate_sound = {
		en = "Demolition Team Alternate Regeneration Sound",
	},
	demolition_team_alternate_sound_description = {
		en = "The vanilla sound for Demolition Team is play_pick_up_ammo_01 which is the sound that plays when you pick up a small ammo tin, AND when you resupply from an ammo crate. This means if you enable the Demolition Team Alternate Sound, whichever sound you choose in this dropdown will play on those events as well.",
	},
	chaos_spawn_ground_impact_large = {
		en = "chaos spawn ground impact",
	},
	hits_blunt_shield = {
		en = "hits blunt shield",
	},
	bullet_hits_explosive_gen = {
		en = "bullet hits explosive gen",
	},
	player_foley_receive_item = {
		en = "player foley receive item",
	},
	pick_up_forge_material_large = {
		en = "pick up forge material large",
	},
	pick_up_forge_material_small = {
		en = "pick up forge material small",
	},
	pick_up_forge_material_platinum_small = {
		en = "pick up forge material platinum small",
	},
	pick_up_forge_material_platinum_large = {
		en = "pick up forge material platinum large",
	},
	pick_up_grenade = {
		en = "pick up grenade",
	},
	pick_up_syringe = {
		en = "pick up syringe",
	},
	pick_up_tome = {
		en = "pick up tome",
	},
	pick_up_ammo_pack = {
		en = "pickup ammo pack",
	},
	plague_ogryn_stomp_metal = {
		en = "plague ogryn stomp metal",
	},
	psyker_lightning_bolt_impact_death = {
		en = "psyker lightning bolt impact death"
	},
	auspex_bio_minigame_selection_right = {
		en = "auspex bio minigame selection right"
	},
	auspex_bio_minigame_selection_wrong = {
		en = "auspex bio minigame selection wrong"
	},
	psyker_equip_single_shard = {
		en = "psyker equip single shard",
	},
	psyker_restored_final_shard = {
		en = "psyker restored final shard",
	},
	use_custom_sounds = {
		en = "Use Custom Sounds",
	},
}