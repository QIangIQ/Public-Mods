-- QIangIQs Guarantee Suite
-- One mod that runs, unchanged in behaviour, these mods as modules:
--   guarantee_ability_activation, guarantee_special_action, guarantee_weapon_swap (KamiUnitY)
--   InstantAbility (Seph)
--   audible_ability_recharge, audible_grenade_regen (demba)
--   AbilityGod (Kevinna)
-- plus one rule of our own: Instant Ability stands down while the Skitarii
-- Chordclaw "Axial Slash" augment is equipped.
--
-- Why a dispatcher: DMF keeps one hook per mod per function. A second
-- mod:hook / mod:hook_safe on the same function from the same mod replaces the
-- first handler ("Attempting to rehook active hook", dmf hooks.lua create_hook).
-- The three guarantee mods all hook InputService._get, CharacterStateMachine,
-- PlayerUnitWeaponExtension and PlayerUnitAbilityExtension, so each module
-- registers into a list here and this file owns the single DMF hook.

local mod = get_mod("QIangIQsGuaranteeSuite")

local PATH = "QIangIQsGuaranteeSuite/scripts/mods/QIangIQsGuaranteeSuite/"

-- Load order matters for the input chain: DMF calls the newest hook first
-- (get_hook_chain returns hooks[#hooks]), so modules are registered in the
-- order the separate mods sat in mod_load_order.txt. The last one registered
-- runs first, exactly as before.
local MODULES = {
    { name = "ability_god",                  prefix = "ag_",  file = "modules/ability_god" },
    { name = "audible_ability_recharge",     prefix = "aar_", file = "modules/audible_ability_recharge" },
    { name = "audible_grenade_regen",        prefix = "agr_", file = "modules/audible_grenade_regen" },
    { name = "guarantee_ability_activation", prefix = "gaa_", file = "modules/guarantee_ability_activation" },
    { name = "guarantee_special_action",     prefix = "gsa_", file = "modules/guarantee_special_action" },
    { name = "guarantee_weapon_swap",        prefix = "gws_", file = "modules/guarantee_weapon_swap" },
    { name = "instant_ability",              prefix = "ia_",  file = "modules/instant_ability" },
}

-- Old mod name for each module, used once to carry settings across.
local OLD_MOD_NAME = {
    ability_god                  = "AbilityGod",
    audible_ability_recharge     = "audible_ability_recharge",
    audible_grenade_regen        = "audible_grenade_regen",
    guarantee_ability_activation = "guarantee_ability_activation",
    guarantee_special_action     = "guarantee_special_action",
    guarantee_weapon_swap        = "guarantee_weapon_swap",
    instant_ability              = "InstantAbility",
}

local subs = {}
local subs_in_order = {}

---------------------------------------------------------------------------
-- Error reporting: one line per distinct error, so a broken module cannot
-- flood the console log every frame.
---------------------------------------------------------------------------

local _reported = {}

local function report(sub, where, err)
    local key = sub._name .. "|" .. where .. "|" .. tostring(err)
    if _reported[key] then
        return
    end
    _reported[key] = true
    mod:error("[%s] %s: %s", sub._name, where, tostring(err))
end

---------------------------------------------------------------------------
-- Hook registries
---------------------------------------------------------------------------

local function key_of(obj, method)
    return tostring(obj) .. "\0" .. method
end

local function entry_on(e)
    return e.active and e.sub._enabled
end

-- hook_safe: every module's handler runs after the original, each in its own
-- pcall so one module's error cannot stop the others.
local safe_lists = {}

local function register_safe(sub, obj, method, fn)
    local key = key_of(obj, method)
    local list = safe_lists[key]
    if not list then
        list = {}
        safe_lists[key] = list
        mod:hook_safe(obj, method, function(...)
            for i = 1, #list do
                local e = list[i]
                if entry_on(e) then
                    local ok, err = pcall(e.fn, ...)
                    if not ok then
                        report(e.sub, "hook_safe " .. method, err)
                    end
                end
            end
        end)
    end
    list[#list + 1] = { sub = sub, fn = fn, active = true }
end

-- hook: modules are chained like separate DMF mods would be. Entry i receives
-- as "func" a function that runs entries i-1 .. 1 and then the original.
-- The "next" functions are built once per original: DMF passes the same
-- previous_hook every call (create_specialized_hook), so nothing is allocated
-- per call on hot paths such as InputService._get.
local hook_lists = {}

local function build_chain(list, func)
    local nexts = {}
    nexts[0] = func
    for i = 1, #list do
        local e = list[i]
        local inner = nexts[i - 1]
        nexts[i] = function(...)
            if entry_on(e) then
                return e.fn(inner, ...)
            end
            return inner(...)
        end
    end
    list._func = func
    list._top = nexts[#list]
end

local function register_hook(sub, obj, method, fn)
    local key = key_of(obj, method)
    local list = hook_lists[key]
    if not list then
        list = {}
        hook_lists[key] = list
        mod:hook(obj, method, function(func, ...)
            if list._func ~= func or list._n ~= #list then
                build_chain(list, func)
                list._n = #list
            end
            return list._top(...)
        end)
    end
    list[#list + 1] = { sub = sub, fn = fn, active = true }
end

local function disable_entry(sub, obj, method)
    local key = key_of(obj, method)
    for _, lists in ipairs({ safe_lists, hook_lists }) do
        local list = lists[key]
        if list then
            for i = 1, #list do
                if list[i].sub == sub then
                    list[i].active = false
                end
            end
        end
    end
end

---------------------------------------------------------------------------
-- Module object: the part of the DMF mod API the original files use, with
-- settings and localization kept under the module's prefix.
---------------------------------------------------------------------------

local function make_sub(def)
    local prefix = def.prefix
    local sub = { _name = def.name, _prefix = prefix, _enabled = true }

    function sub:get(setting_id)
        return mod:get(prefix .. setting_id)
    end
    function sub:set(setting_id, value, notify)
        return mod:set(prefix .. setting_id, value, notify)
    end
    function sub:localize(text_id, ...)
        return mod:localize(prefix .. text_id, ...)
    end
    function sub:is_enabled()
        return mod:is_enabled() and self._enabled
    end
    function sub:io_dofile(path)
        return mod:io_dofile(path)
    end
    function sub:hook(obj, method, fn)
        register_hook(self, obj, method, fn)
    end
    function sub:hook_safe(obj, method, fn)
        register_safe(self, obj, method, fn)
    end
    function sub:hook_disable(obj, method)
        disable_entry(self, obj, method)
    end
    function sub:echo(...)
        return mod:echo(...)
    end
    function sub:notify(...)
        return mod:notify(...)
    end
    function sub:info(...)
        return mod:info(...)
    end
    function sub:error(...)
        return mod:error(...)
    end
    function sub:get_name()
        return def.name
    end

    return sub
end

function mod.sub(name)
    return subs[name]
end

---------------------------------------------------------------------------
-- One-time settings migration from the separate mods.
-- DMF keeps every mod's settings in Application.user_setting("mods_settings")
-- under the mod's name (dmf settings.lua), readable through
-- dmf._get_setting_value(mod_name, setting_id).
---------------------------------------------------------------------------

local MIGRATE_KEYS = {
    ability_god = {
        "toughness_thresh", "peril_thresh", "health_thresh",
        "veteran_exec", "veteran_voice", "veteran_infil",
        "psyker_shout", "psyker_shield", "psyker_over",
        "zealot_dash", "zealot_prayer", "zealot_stealth",
        "ogryn_rush", "ogryn_taunt", "ogryn_ammo",
        "arbiter_stance", "arbiter_drone", "arbiter_charge",
        "broker_focus", "broker_punk", "broker_stimm",
    },
    audible_ability_recharge = { "ability_charge1_sound", "ability_charge2_sound" },
    audible_grenade_regen = {
        "rock_and_demolition_stockpile_alternate_sound",
        "demolition_team_alternate_sound_toggle",
        "demolition_team_alternate_sound",
    },
    guarantee_ability_activation = {
        "enable_prevent_relic_cancel", "enable_prevent_relic_sprint",
        "enable_prevent_ability_aiming", "enable_debug_modding_tools",
    },
    guarantee_special_action = {
        "enable_blocking_cancel_special", "enable_ads_cancel_special", "enable_debug_modding_tools",
    },
    guarantee_weapon_swap = { "queue_limit", "enable_quick_grenades", "enable_debug_modding_tools" },
}

local function migrate_old_settings()
    if mod:get("migrated_v1") then
        return
    end
    local dmf = get_mod("DMF")
    local read = dmf and dmf._get_setting_value
    if type(read) ~= "function" then
        return
    end
    local moved = 0
    for _, def in ipairs(MODULES) do
        local old_name = OLD_MOD_NAME[def.name]
        for _, setting_id in ipairs(MIGRATE_KEYS[def.name] or {}) do
            local ok, value = pcall(read, old_name, setting_id)
            if ok and value ~= nil then
                mod:set(def.prefix .. setting_id, value)
                moved = moved + 1
            end
        end
    end
    -- AbilityGod's own on/off switch becomes the module switch.
    local ok, ag_master = pcall(read, "AbilityGod", "master_enable")
    if ok and ag_master == false then
        mod:set("ag_enabled", false)
    end
    mod:set("migrated_v1", true)
    if moved > 0 then
        mod:info("Carried over %d settings from the separate mods.", moved)
    end
end

---------------------------------------------------------------------------
-- Chordclaw / Axial Slash detection (our addition)
--
-- The Chordclaw (cryptic_chordclaw) has three augments, each a talent that
-- adds a special rule read by weapon_action_handler_data.lua:
--   cryptic_chordclaw_do_quick_stab_combo  -> chained stabs (attack_stab_01/02/03)
--   cryptic_chordclaw_do_horizontal_swipe  -> "heavy_attack_left_horizontal_swipe"
--   neither                                 -> big sticky stab
-- The horizontal swipe is the only slash among them, so it is the one this
-- file treats as Axial Slash (talent cryptic_chordclaw_horizontal_swipe in
-- cryptic_talents.lua). The "Any Chordclaw" choice covers the other two.
---------------------------------------------------------------------------

local AXIAL_RULE = "cryptic_chordclaw_do_horizontal_swipe"

mod.chordclaw_equipped = false
mod.axial_slash_equipped = false

local _check_t = 0

local function refresh_chordclaw_state(dt)
    _check_t = _check_t - (dt or 0)
    if _check_t > 0 then
        return
    end
    _check_t = 0.25

    local player = Managers.player and Managers.player:local_player_safe(1)
    local unit = player and player.player_unit
    if not unit or not ALIVE[unit] then
        mod.chordclaw_equipped = false
        mod.axial_slash_equipped = false
        return
    end

    local ability_extension = ScriptUnit.has_extension(unit, "ability_system")
    local equipped = ability_extension and ability_extension._equipped_abilities
    local combat = equipped and equipped.combat_ability
    mod.chordclaw_equipped = combat and combat.name == "cryptic_chordclaw" or false

    local talent_extension = ScriptUnit.has_extension(unit, "talent_system")
    local has_axial = false
    if talent_extension and talent_extension.has_special_rule then
        local ok, result = pcall(talent_extension.has_special_rule, talent_extension, AXIAL_RULE)
        has_axial = ok and result and true or false
    end
    mod.axial_slash_equipped = has_axial
end

-- True while Instant Ability should leave the ability key alone.
function mod.instant_ability_paused()
    local rule = mod:get("ia_chordclaw_exception") or "axial"
    if rule == "axial" then
        return mod.axial_slash_equipped
    elseif rule == "any_chordclaw" then
        return mod.chordclaw_equipped
    end
    return false
end

---------------------------------------------------------------------------
-- Load the modules
---------------------------------------------------------------------------

local function module_setting_enabled(def)
    return mod:get(def.prefix .. "enabled") ~= false
end

for _, def in ipairs(MODULES) do
    local sub = make_sub(def)
    sub._enabled = module_setting_enabled(def)
    subs[def.name] = sub
    subs_in_order[#subs_in_order + 1] = sub
end

migrate_old_settings()

for _, def in ipairs(MODULES) do
    subs[def.name]._enabled = module_setting_enabled(def)
end

for _, def in ipairs(MODULES) do
    local ok, err = pcall(mod.io_dofile, mod, PATH .. def.file)
    if not ok then
        mod:error("Module %s failed to load: %s", def.name, tostring(err))
        subs[def.name]._enabled = false
        subs[def.name]._failed = true
    end
end

---------------------------------------------------------------------------
-- Event forwarding
---------------------------------------------------------------------------

local function call(sub, fn_name, ...)
    local fn = rawget(sub, fn_name)
    if type(fn) ~= "function" then
        return
    end
    local ok, err = pcall(fn, ...)
    if not ok then
        report(sub, fn_name, err)
    end
end

mod.on_setting_changed = function(setting_id)
    for _, sub in ipairs(subs_in_order) do
        local prefix = sub._prefix
        if string.sub(setting_id, 1, #prefix) == prefix then
            local local_id = string.sub(setting_id, #prefix + 1)
            if local_id == "enabled" then
                local now = mod:get(setting_id) ~= false and not sub._failed
                if now ~= sub._enabled then
                    sub._enabled = now
                    call(sub, now and "on_enabled" or "on_disabled")
                end
            else
                call(sub, "on_setting_changed", local_id)
            end
            return
        end
    end
end

mod.on_all_mods_loaded = function()
    for _, sub in ipairs(subs_in_order) do
        call(sub, "on_all_mods_loaded")
    end
end

mod.on_game_state_changed = function(status, state_name)
    for _, sub in ipairs(subs_in_order) do
        call(sub, "on_game_state_changed", status, state_name)
    end
end

mod.update = function(dt)
    local ok, err = pcall(refresh_chordclaw_state, dt)
    if not ok then
        report({ _name = "suite" }, "chordclaw check", err)
    end
    for _, sub in ipairs(subs_in_order) do
        if sub._enabled then
            call(sub, "update", dt)
        end
    end
end

mod.on_enabled = function()
    for _, sub in ipairs(subs_in_order) do
        if sub._enabled then
            call(sub, "on_enabled")
        end
    end
end

mod.on_disabled = function()
    for _, sub in ipairs(subs_in_order) do
        call(sub, "on_disabled")
    end
end
