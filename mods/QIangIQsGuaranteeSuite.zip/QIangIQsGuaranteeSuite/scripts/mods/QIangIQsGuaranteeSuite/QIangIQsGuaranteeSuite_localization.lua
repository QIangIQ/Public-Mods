local mod = get_mod("QIangIQsGuaranteeSuite")

local LOC = "QIangIQsGuaranteeSuite/scripts/mods/QIangIQsGuaranteeSuite/modules/loc/"

local localization = {
	mod_name = {
		en = "QIangIQ's Guarantee Suite",
	},
	mod_description = {
		en = "Guarantee Ability Activation, Guarantee Special Action, Guarantee Weapon Swap, Instant Ability, Audible Ability Recharge, Audible Grenade Regen and Ability God in one mod. Each part keeps its own settings group and can be switched off on its own. Remove the separate mods from your load order.",
	},
	module_enabled = {
		en = "Enabled",
	},
	module_enabled_description = {
		en = "Switch this part of the suite on or off. Off behaves as if the separate mod were not loaded.",
	},

	-- Instant Ability (Seph) had no settings; its group is new.
	ia_mod_name = {
		en = "Instant Ability",
	},
	ia_mod_description = {
		en = "Author: Seph. Activates your combat ability the moment you press the button instead of letting you hold it to aim.",
	},
	ia_chordclaw_exception = {
		en = "Skitarii Chordclaw exception",
	},
	ia_chordclaw_exception_description = {
		en = "While this applies, Instant Ability leaves the ability key alone so holding it aims the Chordclaw lunge as normal.\n\nAxial Slash: only with the Axial Slash augment (the horizontal-swipe augment, special rule cryptic_chordclaw_do_horizontal_swipe).\nAny Chordclaw: with any Chordclaw augment.\nNever: Instant Ability always applies.",
	},
	ia_exception_axial = {
		en = "Axial Slash only",
	},
	ia_exception_any_chordclaw = {
		en = "Any Chordclaw",
	},
	ia_exception_never = {
		en = "Never",
	},
}

-- Each module's original localization table, with every key under the
-- module's prefix (settings, option texts, group names, mod_name).
local MODULE_LOC = {
	{ prefix = "gaa_", file = "guarantee_ability_activation" },
	{ prefix = "gsa_", file = "guarantee_special_action" },
	{ prefix = "gws_", file = "guarantee_weapon_swap" },
	{ prefix = "aar_", file = "audible_ability_recharge" },
	{ prefix = "agr_", file = "audible_grenade_regen" },
	{ prefix = "ag_",  file = "ability_god" },
}

for _, entry in ipairs(MODULE_LOC) do
	local ok, strings = pcall(mod.io_dofile, mod, LOC .. entry.file)
	if ok and type(strings) == "table" then
		for key, value in pairs(strings) do
			localization[entry.prefix .. key] = value
		end
	end
end

-- Group titles for modules whose original file has no mod_name.
localization.agr_mod_name = localization.agr_mod_name or { en = "Audible Grenade Regen" }

return localization
