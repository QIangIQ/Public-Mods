return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsRoadhog` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsRoadhog", {
            mod_script = "QIangIQsRoadhog/scripts/mods/QIangIQsRoadhog/QIangIQsRoadhog",
            mod_data = "QIangIQsRoadhog/scripts/mods/QIangIQsRoadhog/QIangIQsRoadhog_data",
            mod_localization = "QIangIQsRoadhog/scripts/mods/QIangIQsRoadhog/QIangIQsRoadhog_localization",
        })
    end,
    version = "1.0.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
