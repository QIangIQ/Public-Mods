return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsBoltgunFlamer` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsBoltgunFlamer", {
            mod_script = "QIangIQsBoltgunFlamer/scripts/mods/QIangIQsBoltgunFlamer/QIangIQsBoltgunFlamer",
            mod_data = "QIangIQsBoltgunFlamer/scripts/mods/QIangIQsBoltgunFlamer/QIangIQsBoltgunFlamer_data",
            mod_localization = "QIangIQsBoltgunFlamer/scripts/mods/QIangIQsBoltgunFlamer/QIangIQsBoltgunFlamer_localization",
        })
    end,
    version = "0.1.0",
    author = "QIangIQ",
    packages = {},
}
