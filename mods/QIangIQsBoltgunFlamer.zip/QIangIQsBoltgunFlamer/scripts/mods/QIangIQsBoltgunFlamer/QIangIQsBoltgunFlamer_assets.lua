-- Texture loading without other mods: SimpleAssets' runtime ships renamed in this mod's bin folder
-- (bin/boltgunflamer-assets-runtime.dll). It serves files under the game folder over http://127.0.0.1:<random port>, and
-- Managers.url_loader:load_texture turns that URL into a texture userdata (UrlLoaderManager -> Backend url_request).
-- The ffi declarations are SimpleAssets' runtime/cdef.lua word for word behind the same guard type, so whichever
-- mod loads first declares them and the other still finds every function it needs.
local Assets = {}

local ffi = rawget(_G, "Mods") and Mods.lua and Mods.lua.ffi
local RUNTIME_PATH = "..\\mods\\QIangIQsBoltgunFlamer\\bin\\boltgunflamer-assets-runtime.dll"
local MOD_ASSETS = "mods/QIangIQsBoltgunFlamer/assets/"

local persist -- survives mod reloads (Ctrl+Shift+R): the DLL must not be loaded or started twice
local log = function() end

local function declare()
	if pcall(ffi.typeof, "SimpleAssetsRuntime_CDEF") then
		return
	end

	ffi.cdef([[
		typedef void* SimpleAssets_HANDLE;
		typedef unsigned long SimpleAssets_DWORD;
		typedef int SimpleAssets_BOOL;
		typedef unsigned short SimpleAssets_WCHAR;

		typedef struct {
			SimpleAssets_DWORD dwLowDateTime;
			SimpleAssets_DWORD dwHighDateTime;
		} SimpleAssets_FILETIME;

		typedef struct {
			SimpleAssets_DWORD dwFileAttributes;
			SimpleAssets_FILETIME ftCreationTime;
			SimpleAssets_FILETIME ftLastAccessTime;
			SimpleAssets_FILETIME ftLastWriteTime;
			SimpleAssets_DWORD nFileSizeHigh;
			SimpleAssets_DWORD nFileSizeLow;
			SimpleAssets_DWORD dwReserved0;
			SimpleAssets_DWORD dwReserved1;
			SimpleAssets_WCHAR cFileName[260];
			SimpleAssets_WCHAR cAlternateFileName[14];
		} SimpleAssets_WIN32_FIND_DATAW;

		int SimpleAssetsRuntime_Start(void);
		int SimpleAssetsRuntime_DetectImageFormat(const char* path);
		int SimpleAssetsRuntime_AnimationLoad(const char* asset_path);
		int SimpleAssetsRuntime_AnimationReplace(const char* target_resource_path, const char* source_asset_path);
		int SimpleAssetsRuntime_FontLoad(const char* asset_path);
		int SimpleAssetsRuntime_FontReplace(const char* target_resource_path, const char* source_asset_path);
		int SimpleAssetsRuntime_MaterialLoad(const char* asset_path);
		int SimpleAssetsRuntime_MaterialReplace(const char* target_resource_path, const char* source_asset_path);
		int SimpleAssetsRuntime_MouseCursorLoad(const char* asset_path, unsigned int hotspot_x, unsigned int hotspot_y);
		int SimpleAssetsRuntime_MouseCursorReplace(const char* target_resource_path, const char* source_asset_path);
		int SimpleAssetsRuntime_ParticlesLoad(const char* asset_path);
		int SimpleAssetsRuntime_ParticlesReplace(const char* target_resource_path, const char* source_asset_path);
		int SimpleAssetsRuntime_ResourceState(const char* resource_type, const char* asset_path);
		int SimpleAssetsRuntime_SlugAlbumLoad(const char* asset_path);
		int SimpleAssetsRuntime_SlugAlbumReplace(const char* target_resource_path, const char* source_asset_path);
		int SimpleAssetsRuntime_TextureLoad(const char* asset_path);
		int SimpleAssetsRuntime_TextureReplace(const char* target_resource_path, const char* source_asset_path);
		int SimpleAssetsRuntime_UnitLoad(const char* asset_path);
		int SimpleAssetsRuntime_UnitReplace(const char* target_resource_path, const char* source_asset_path);
		int SimpleAssetsRuntime_VideoLoad(const char* asset_path);
		int SimpleAssetsRuntime_VideoReplace(const char* target_resource_path, const char* source_asset_path);
		const char* SimpleAssetsRuntime_GameDir(void);
		const char* SimpleAssetsRuntime_UserDir(void);
		const char* SimpleAssetsRuntime_CanonicalAssetPath(const char* path);
		const char* SimpleAssetsRuntime_AssetUrl(const char* path);
		const char* SimpleAssetsRuntime_LastError(void);
		void SimpleAssetsRuntime_Shutdown(void);
		SimpleAssets_DWORD SimpleAssetsRuntime_GetLastError(void);
		SimpleAssets_DWORD SimpleAssetsRuntime_GetFileAttributesW(const SimpleAssets_WCHAR* lpFileName);
		int SimpleAssetsRuntime_MultiByteToWideChar(unsigned int CodePage, unsigned long dwFlags, const char* lpMultiByteStr, int cbMultiByte, SimpleAssets_WCHAR* lpWideCharStr, int cchWideChar);
		int SimpleAssetsRuntime_WideCharToMultiByte(unsigned int CodePage, unsigned long dwFlags, const SimpleAssets_WCHAR* lpWideCharStr, int cchWideChar, char* lpMultiByteStr, int cbMultiByte, const char* lpDefaultChar, SimpleAssets_BOOL* lpUsedDefaultChar);
		SimpleAssets_HANDLE SimpleAssetsRuntime_FindFirstFileW(const SimpleAssets_WCHAR* lpFileName, SimpleAssets_WIN32_FIND_DATAW* lpFindFileData);
		SimpleAssets_BOOL SimpleAssetsRuntime_FindNextFileW(SimpleAssets_HANDLE hFindFile, SimpleAssets_WIN32_FIND_DATAW* lpFindFileData);
		SimpleAssets_BOOL SimpleAssetsRuntime_FindClose(SimpleAssets_HANDLE hFindFile);

		typedef struct { int unused; } SimpleAssetsRuntime_CDEF;
]])
end

local function cstring(p)
	if p == nil then
		return nil
	end

	local v = ffi.string(p)

	return v ~= "" and v or nil
end

function Assets.setup(persist_table, log_fn)
	persist = persist_table
	log = log_fn or log
end

-- Loads and starts the runtime once per game session. Returns the library or nil, error.
function Assets.runtime()
	if persist.assets_rt then
		return persist.assets_rt
	end

	if persist.assets_failed then
		return nil, persist.assets_failed
	end

	if not ffi then
		persist.assets_failed = "ffi unavailable"
		return nil, persist.assets_failed
	end

	-- one runtime for every QIangIQs MMJ weapon mod: the first mod to start one registers it, the others reuse it (the
	-- runtime serves any file under the game folder), so only one copy loads however many of the mods are installed
	local shared = rawget(_G, "__qiangiq_mmj_runtimes")

	if shared and shared.assets then
		persist.assets_rt = shared.assets

		return persist.assets_rt
	end

	local ok, err = pcall(function()
		declare()

		local rt = ffi.load(RUNTIME_PATH)

		if rt.SimpleAssetsRuntime_Start() == 0 then
			error(cstring(rt.SimpleAssetsRuntime_LastError()) or "runtime failed to start")
		end

		persist.assets_rt = rt
		shared = rawget(_G, "__qiangiq_mmj_runtimes") or {}
		shared.assets = rt
		rawset(_G, "__qiangiq_mmj_runtimes", shared)
	end)

	if not ok then
		persist.assets_failed = tostring(err)
		log("assets: runtime unavailable: " .. persist.assets_failed)

		return nil, persist.assets_failed
	end

	log("assets: runtime started, game dir " .. tostring(cstring(persist.assets_rt.SimpleAssetsRuntime_GameDir())))

	return persist.assets_rt
end

-- relative_path is under this mod's assets folder, e.g. "ui/live_icon.png"
function Assets.url(relative_path)
	local rt, err = Assets.runtime()

	if not rt then
		return nil, err
	end

	local virtual = (MOD_ASSETS .. relative_path):gsub("/", "\\")
	local canonical = cstring(rt.SimpleAssetsRuntime_CanonicalAssetPath(virtual))

	if not canonical then
		return nil, cstring(rt.SimpleAssetsRuntime_LastError()) or "bad asset path"
	end

	local url = cstring(rt.SimpleAssetsRuntime_AssetUrl((canonical:gsub("/", "\\"))))

	if not url then
		return nil, cstring(rt.SimpleAssetsRuntime_LastError()) or "no asset url"
	end

	return url
end

-- Starts loading; returns a table that gets .texture (userdata), .w, .h when ready, or .error.
-- Repeated calls for one path share the same entry.
function Assets.texture(relative_path)
	persist.textures = persist.textures or {}

	local entry = persist.textures[relative_path]

	if entry then
		return entry
	end

	entry = {}
	persist.textures[relative_path] = entry

	if not Managers.url_loader then
		entry.error = "url_loader not ready"
		persist.textures[relative_path] = nil
		return entry
	end

	local url, err = Assets.url(relative_path)

	if not url then
		entry.error = err
		log("assets: " .. relative_path .. ": " .. tostring(err))
		return entry
	end

	entry.url = url

	local ok, promise = pcall(Managers.url_loader.load_texture, Managers.url_loader, url, false)

	if not ok or not promise then
		entry.error = tostring(promise)
		log("assets: load_texture " .. relative_path .. ": " .. entry.error)
		return entry
	end

	promise:next(function(data)
		if data and data.texture then
			entry.texture = data.texture
			entry.w = data.width
			entry.h = data.height
		else
			entry.error = "no texture"
		end
	end, function(data)
		entry.error = "load failed"
		log("assets: texture failed: " .. relative_path)
	end)

	return entry
end

-- Releases url_loader references (the loader frees the texture at zero references).
function Assets.release_all()
	local textures = persist and persist.textures

	if not textures or not Managers.url_loader then
		return
	end

	for _, entry in pairs(textures) do
		if entry.url and entry.texture then
			pcall(Managers.url_loader.unload_texture, Managers.url_loader, entry.url)
		end
	end

	persist.textures = {}
end

return Assets
