-- QIangIQsBoltgunFlamer per-weapon data (weapons\gen.py spec flamer). Clips are the Animations keys of BP_WeaponAnimations_Flamer.
-- Action names and kinds: Darktide weapon templates (Aussiemon master), read by gen.py actions_of.
return {
    ranged = true,
    idle = "Idle",
    templates = { flamer_p1_m1 = true },
    actions = {
        action_reload = { clips = { "Reload" }, stretch = true, reload_template = true, tempo = true, sounds = { "WPN_SOB_Flamer_Reload.ogg" } },
        action_shoot = { clips = { "Fire" }, loop = true, sounds = { "WPN_SOB_Flamer_In-001.ogg", "WPN_SOB_Flamer_In-002.ogg", "WPN_SOB_Flamer_In-003.ogg", "WPN_SOB_Flamer_In-004.ogg" }, end_sounds = { "WPN_SOB_Flamer_Out-001.ogg", "WPN_SOB_Flamer_Out-002.ogg", "WPN_SOB_Flamer_Out-003.ogg" }, loop_sound = "WPN_SOB_Flamer_Loop.ogg" },
        action_shoot_braced = { clips = { "Fire" }, loop = true, sounds = { "WPN_SOB_Flamer_In-001.ogg", "WPN_SOB_Flamer_In-002.ogg", "WPN_SOB_Flamer_In-003.ogg", "WPN_SOB_Flamer_In-004.ogg" }, end_sounds = { "WPN_SOB_Flamer_Out-001.ogg", "WPN_SOB_Flamer_Out-002.ogg", "WPN_SOB_Flamer_Out-003.ogg" }, loop_sound = "WPN_SOB_Flamer_Loop.ogg" },
        action_wield = { clips = { "PickUp" }, tempo = true, speed_to = 1.7, sounds = { "WPN_SOB_Flamer_PickupAnim.ogg" } },
    },
}
