return {
    mod_name = {
        en = "QIangIQ's Boltgun Flamer",
    },
    mod_description = {
        en = "Replaces the Flamer with Boltgun 2's flamer: its sprites and clips in first person with its sounds. Visual only: the weapon still works as before. Contains Boltgun 2 art and audio: personal use only.",
    },
    command_desc = { en = "Boltgun Flamer status (add flip to turn the sprite rotation round)" },
    replace_flamer_p1_m1 = { en = "Replace Purgation Flamer (flamer_p1_m1)" },
    third_person = { en = "Third person: your character" },
    third_person_others = { en = "Third person: other players" },
    third_person_hide = { en = "Hide the weapon" },
    third_person_retail = { en = "Show the weapon" },
    sounds = { en = "Boltgun sounds" },
    volume = { en = "Sound volume (%%)" },
    layout = { en = "Screen layout" },
    mmj_fov = { en = "Weapon camera field of view (degrees)" },
    size = { en = "Size (%%)" },
    offset_x = { en = "Move right (cm)" },
    offset_y = { en = "Move up (cm)" },
    smear_cap = { en = "Fade sprites bigger than this share of the screen (%%, 0 = off)" },
}
