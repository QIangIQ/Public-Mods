return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsMarieGemini` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsMarieGemini", {
            mod_script = "QIangIQsMarieGemini/scripts/mods/QIangIQsMarieGemini/QIangIQsMarieGemini",
            mod_data = "QIangIQsMarieGemini/scripts/mods/QIangIQsMarieGemini/QIangIQsMarieGemini_data",
            mod_localization = "QIangIQsMarieGemini/scripts/mods/QIangIQsMarieGemini/QIangIQsMarieGemini_localization",
        })
    end,
    version = "1.0.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
