-- Dio's Fixed CaptainShield: original mod by Seph (Steam: Concoction of Constitution), fixed by Dioscurio.
return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`CaptainShield` encountered an error loading the Darktide Mod Framework.")

		new_mod("CaptainShield", {
			mod_script       = "Dio's Fixed CaptainShield/scripts/mods/CaptainShield/CaptainShield",
			mod_data         = "Dio's Fixed CaptainShield/scripts/mods/CaptainShield/CaptainShield_data",
			mod_localization = "Dio's Fixed CaptainShield/scripts/mods/CaptainShield/CaptainShield_localization",
		})
	end,
	version = "1.0.0",
	packages = {},
}
