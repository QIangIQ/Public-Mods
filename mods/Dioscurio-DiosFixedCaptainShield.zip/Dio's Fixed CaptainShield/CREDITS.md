# Dio's Fixed CaptainShield

Original mod: Captain Shield by Seph (Steam: Concoction of Constitution).
Fixes: Dioscurio.

The original mod did not come with a license file. Seph gave Dioscurio permission to redistribute this fixed version (2026-11-20).

This replaces Seph's Captain Shield: it registers under the same mod id ("CaptainShield"). Remove Seph's original CaptainShield folder and its line in mod_load_order.txt before installing this one.
