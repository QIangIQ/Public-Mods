--[[
┌───────────────────────────────────────────────────────────────────────────────────────────┐
│ Mod Name: Captain Shield                                                                  │
│ Mod Description: Provides a bubble shield for your character and special block fx.        │
│ Mod Author: Seph (Steam: Concoction of Constitution)                                      │
└───────────────────────────────────────────────────────────────────────────────────────────┘
--]]

--Todo: disable on mod disable

local mod = get_mod("CaptainShield")
local mission = ""

local shieldEnabled = mod:get("shield_enabled")
local shieldScale = mod:get("shield_scale")
local shieldMaxScale = mod:get("shield_max_scale")
local shieldStrength = mod:get("shield_strength")
local shieldNRGB = Vector3Box(mod:get("shield_normal_r"),mod:get("shield_normal_g"),mod:get("shield_normal_b"))
local shieldORGB = Vector3Box(mod:get("shield_overcharged_r"),mod:get("shield_overcharged_g"),mod:get("shield_overcharged_b"))
local shieldFlickerStrength = mod:get("shield_flicker_strength")
local shieldFlickerDuration = mod:get("shield_flicker_duration")

function mod.on_setting_changed(setting_id)
  shieldEnabled = mod:get("shield_enabled")
  shieldScale = mod:get("shield_scale")
  shieldMaxScale = mod:get("shield_max_scale")
  shieldStrength = mod:get("shield_strength")
  shieldNRGB = Vector3Box(mod:get("shield_normal_r"),mod:get("shield_normal_g"),mod:get("shield_normal_b"))
  shieldORGB = Vector3Box(mod:get("shield_overcharged_r"),mod:get("shield_overcharged_g"),mod:get("shield_overcharged_b"))
  shieldFlickerStrength = mod:get("shield_flicker_strength")
  shieldFlickerDuration = mod:get("shield_flicker_duration")

  if setting_id == "shield_enabled" then
    if shieldEnabled and mission ~= "hub_ship" then mod:spawn_shield()
    elseif not shieldEnabled and mission ~= "hub_ship" then
      mod:despawn_shield()
    end
  elseif setting_id == "shield_size" and mod.shield_unit ~= nil then
    Unit.set_local_scale(mod.shield_unit, 1, Vector3.one() * mod:get("shield_size"))
  end
end





local lastSound
local playSound = function(sound, stoppable)
  local world = Managers.world:world("level_world")
	local wwise_world = Managers.world:wwise_world(world)
  if stoppable then
    lastSound = WwiseWorld.trigger_resource_event(wwise_world, sound)
  else
    WwiseWorld.trigger_resource_event(wwise_world, sound)
  end
end

local createLocalParticles = function(vfx, node)
  local player = Managers.player:local_player_safe(1).player_unit -- Get player unit
  local _fx_extension = ScriptUnit.extension(player, "fx_system") -- Get fx extension
  local vfx_unit, vfx_node = _fx_extension:vfx_spawner_unit_and_node(node)
  local vfx_particle_id = World.create_particles(Application.main_world(), vfx, Vector3.zero())
  World.link_particles(Application.main_world(), vfx_particle_id, vfx_unit, vfx_node, Matrix4x4.identity(), "destroy")
  return vfx_particle_id
end


local screenParticle = function(particle_name)
    local position = Vector3(0, 0, 1)
      local rotation = Quaternion.identity()
      local scale = Vector3.one()
      local particle_id = World.create_particles(Application.main_world(), particle_name, position, rotation, scale)
  
  end


local createParticles = function(vfx, node)
    local player = Managers.player:local_player_safe(1).player_unit
    --local viewport_name = player.viewport_name
    --local pos = Managers.state.camera:camera_position(viewport_name)
    if not player or not Unit.alive(player) then return nil end
    -- Resolve bone name to an index; fall back to root if the rig no longer has it
    local node_index = Unit.has_node(player, node) and Unit.node(player, node) or 1
    local pos = Unit.world_position(player, node_index)
    local vfx_particle_id = World.create_particles(Application.main_world(), vfx, pos, Quaternion.identity())
    World.link_particles(Application.main_world(), vfx_particle_id, player, node_index, Matrix4x4.identity(), "destroy")
    return vfx_particle_id
end
  


local breakCD = 0
local blockCD = 0
local shieldHitCD = 0
local shieldBreakCD = 0
local lastTime
local rechargeCD = 0
local hitCD = 0
local hitCD2 = 0
local p
local toughness_extension
local maxToughness
local damage
local buffs
local waitTime = 0
local strength = 0

mod:hook_safe("CutsceneView", "on_enter", function(self)
  --mod:echo("Cutscene")
  mod:despawn_shield()
end)




















local waitingSpawn = false
local camName
mod.update = function()
  
  if lastTime ~= nil then 
      dt = os.clock() - lastTime
  else
      dt = 0
  end
  lastTime = os.clock()

  local Player = Managers.player:local_player_safe(1)
  local PlayerUnit = nil
  local Cam = Managers.state.camera
  if Cam ~= nil then
    if mod.shield_unit ~= nil then 
      camName = Cam:current_camera_node(Player.viewport_name)
      if camName == nil or camName == "dead" then
        mod:despawn_shield()
        return
      end
    end
  else
    return
  end
  
  if waitTime > 0 then
    waitTime = waitTime - dt
    if waitTime <= 0 and mod.shield_unit == nil then
      if Managers.state.camera and Managers.state.camera:current_camera_node(Player.viewport_name) ~= "story_slave" then
        if shieldEnabled then mod:spawn_shield() end
      else
        waitTime = 1
      end
    end
  end
  if blockCD > 0 then
    blockCD = blockCD - dt
  end
  if breakCD > 0 then
    breakCD = breakCD - dt
  end
  if shieldHitCD > 0 then
    shieldHitCD = shieldHitCD - dt
  end
  if shieldBreakCD > 0 then
    shieldBreakCD = shieldBreakCD - dt
  end
  if Player ~= nil then
    PlayerUnit = Player.player_unit
    if not Unit.alive(PlayerUnit) or not Unit.is_valid(PlayerUnit) then
      --mod:echo("Not alive")
      mod:despawn_shield()
      waitingSpawn = false
    elseif not waitingSpawn and Managers.state.camera ~= nil and mod.shield_unit == nil and Managers.state.mission._mission_name ~= "hub_ship" then
      waitTime = 1
      waitingSpawn = true
    end
  end

  if toughness_extension ~= nil then
    if damage ~= toughness_extension:toughness_damage() then
      if damage < toughness_extension:toughness_damage() then
        if shieldHitCD <= 0 then
          strength = toughness_extension:toughness_damage() - damage
          --screenParticle("content/fx/particles/screenspace/screen_disturbance_scanlines_pulse")
          playSound("wwise/events/minions/play_traitor_captain_shield_bullet_hits")
          hitCD = shieldFlickerDuration
          hitCD2 = shieldFlickerDuration/4
          shieldHitCD = mod:get("shield_hit_cd")
        end
        if toughness_extension:remaining_toughness() == 0 and shieldBreakCD <= 0 then -- Shield explosion when toughness is broken
          if mod:get("shield_break_vfx") then createParticles("content/fx/particles/enemies/renegade_captain/renegade_captain_shield_burst", "root_point") end
          if mod:get("shield_break_sfx") then playSound("wwise/events/minions/play_traitor_captain_shield_break") end
          shieldBreakCD = mod:get("shield_break_cd")
        end
      end
      damage = toughness_extension:toughness_damage()
    end
    if maxToughness ~= toughness_extension:max_toughness() then
      if maxToughness < toughness_extension:max_toughness() then
        if mod.shield_unit ~= nil and mod:get("shield_overcharge_vfx") then
          if p ~= nil then 
            World.stop_spawning_particles(Application.main_world(), p)
            if mod:get("shield_overcharge_sfx_repeat") and mod:get("shield_overcharge_sfx") then
              playSound("wwise/events/minions/stop_minion_twins_void_shield_link")
              lastSound = nil
            end
          end
          p = createParticles("content/fx/particles/enemies/twins/twins_shield_recharge", "j_hips")
        end
        if mod.shield_unit ~= nil and mod:get("shield_overcharge_sfx") then
          if lastSound == nil then playSound("wwise/events/minions/play_minion_twins_void_shield_link", true) end
        end
        rechargeCD = mod:get("shield_overcharge_duration")
      elseif buffs.toughness_bonus_flat == 0 then
        if mod:get("shield_overcharge_sfx_long") then 
          playSound("wwise/events/minions/stop_minion_twins_void_shield_link")
          lastSound = nil
        end
      end
      maxToughness = toughness_extension:max_toughness()
    end

    if buffs.toughness_bonus_flat == 0 and lastSound ~= nil and mod:get("shield_overcharge_sfx_long") then
      playSound("wwise/events/minions/stop_minion_twins_void_shield_link")
      lastSound = nil
    end

    if mod.shield_unit ~= nil and buffs ~= nil and toughness_extension ~= nil then 
      local toughnessScale
      local maxToughnessScale = 1
      if shieldScale then toughnessScale = (toughness_extension:toughness_damage() / toughness_extension:max_toughness())
      else if toughness_extension:remaining_toughness() > 0 then toughnessScale = 0 else toughnessScale = 1 end end
      if shieldMaxScale then maxToughnessScale = toughness_extension:max_toughness()/100 end
      Unit.set_scalar_for_materials(mod.shield_unit, "shield_power", math.clamp(1-shieldStrength*maxToughnessScale + toughnessScale*shieldStrength,0,1), true)
      if buffs.toughness_bonus_flat == 0 then
        Unit.set_vector3_for_materials(mod.shield_unit, "color_a", shieldNRGB:unbox(), true)
      else
        Unit.set_vector3_for_materials(mod.shield_unit, "color_a", shieldORGB:unbox(), true)
      end
    end
  end
  if hitCD > 0 then
    hitCD = hitCD - dt
    hitCD2 = hitCD2 - dt
    if mod.shield_unit ~= nil then
      --mod:echo(hitCD)
      -- 1000 default
      local toughnessScale
      local maxToughnessScale = 1
      if shieldScale then toughnessScale = (toughness_extension:toughness_damage() / toughness_extension:max_toughness())
      else if toughness_extension:remaining_toughness() > 0 then toughnessScale = 0 else toughnessScale = 1 end end
      if shieldMaxScale then maxToughnessScale = toughness_extension:max_toughness()/100 end
      if not mod:get("shield_hit_scale") then strength = 100 end
      local v = strength*(shieldFlickerStrength/4)*(hitCD/shieldFlickerDuration)
      Unit.set_scalar_for_materials(mod.shield_unit, "shield_power", math.min(1-(hitCD2/(shieldFlickerDuration/4)), math.clamp(1-shieldStrength*maxToughnessScale + toughnessScale*shieldStrength,0,1)), true)
      Unit.set_vector2_for_materials(mod.shield_unit, "impact_start_duration_01", Vector2(0,v), true)
      Unit.set_vector2_for_materials(mod.shield_unit, "impact_start_duration_02", Vector2(0,v), true)
      Unit.set_vector2_for_materials(mod.shield_unit, "impact_start_duration_03", Vector2(0,v), true)
      Unit.set_vector2_for_materials(mod.shield_unit, "impact_start_duration_04", Vector2(0,v), true)
      if hitCD <= 0 then
        Unit.set_vector2_for_materials(mod.shield_unit, "impact_start_duration_01", Vector2(0,0), true)
        Unit.set_vector2_for_materials(mod.shield_unit, "impact_start_duration_02", Vector2(0,0), true)
        Unit.set_vector2_for_materials(mod.shield_unit, "impact_start_duration_03", Vector2(0,0), true)
        Unit.set_vector2_for_materials(mod.shield_unit, "impact_start_duration_04", Vector2(0,0), true)
      end
    end
  end
  -- Stop overcharge particles for a short-time effect
  if rechargeCD > 0 then
    rechargeCD = rechargeCD - dt
    if rechargeCD <= 0 then
      if p ~= nil and mod.shield_unit ~= nil then World.stop_spawning_particles(Application.main_world(), p) end
      if not mod:get("shield_overcharge_sfx_long") and mod:get("shield_overcharge_sfx") then playSound("wwise/events/minions/stop_minion_twins_void_shield_link") end
    end
  end
  -- Move shield to player camera and rotate left/right based on look direction
  if mod.shield_unit ~= nil then
    if camName == "first_person" or camName == "sprint" or camName == "sprint_overtime" or camName == "aim_down_sight" or camName == "lunge" then
      local camPos = Managers.state.camera:camera_position(Player.viewport_name)
      local camRot = Managers.state.camera:camera_rotation(Player.viewport_name)
      camRot[1] = 0
      camRot[2] = 0
      Unit.set_local_rotation(mod.shield_unit, 1, camRot)
      --mod:echo(Unit.local_rotation(mod.shield_unit, 1))
      Unit.set_local_position(mod.shield_unit, 1, camPos)
    elseif Unit.is_valid(PlayerUnit) then -- If in third person, keep shield around player model
      --mod:echo(camName)
      local playerPos = Unit.local_position(PlayerUnit, 1)
      -- Node 33 is a hard-coded bone index; if the rig changes it may not exist.
      local ok_h, headPos = pcall(Unit.local_position, PlayerUnit, 33)
      playerPos[3] = playerPos[3] + ((ok_h and headPos and headPos[3]) or 1.6) + 0.25
      local playerRot = Unit.local_rotation(PlayerUnit, 1)
      --playerRot[1] = 0
      --playerRot[2] = 0
      Unit.set_local_rotation(mod.shield_unit, 1, playerRot)
      --mod:echo(Unit.local_rotation(mod.shield_unit, 1))
      Unit.set_local_position(mod.shield_unit, 1, playerPos)
    end
  end
end

local lefthandedWeapons = {
  "content/items/weapons/player/melee/chainsword_2h_p1_m2",
  "content/items/weapons/player/melee/chainsword_p1_m1",
  "content/items/weapons/player/melee/chainsword_p1_m2",
  "content/items/weapons/player/melee/forcesword_p1_m1",
  "content/items/weapons/player/melee/forcesword_p1_m2",
  "content/items/weapons/player/melee/forcesword_p1_m3",
  "content/items/weapons/player/melee/combataxe_p3_m1",
  "content/items/weapons/player/melee/combataxe_p3_m2",
  "content/items/weapons/player/melee/combataxe_p3_m3"
}
function isLefthanded(value)
  for _, v in ipairs(lefthandedWeapons) do
      if v == value then
          return true
      end
  end
  return false
end

-- Block shield effect
-- Todo: Ogryn weapons, powersword, shovel (Not sure how to get proper nodes for those)
local animHandler = function(event_name)
    if event_name == "parry_hit_reaction" and blockCD <= 0 then
      if mod:get("scanlines_vfx") then screenParticle("content/fx/particles/screenspace/screen_disturbance_scanlines_pulse") end
      local weapon = Managers.player:local_player_safe(1)._profile.loadout.slot_primary.__master_item.name
      
      if isLefthanded(weapon) then 
        if mod:get("block_vfx") then createLocalParticles("content/fx/particles/impacts/enemies/renegade_captain/renegade_captain_shield_impact", "fx_left_hand") end
      else
        if mod:get("block_vfx") then createLocalParticles("content/fx/particles/impacts/enemies/renegade_captain/renegade_captain_shield_impact", "fx_anim_01") end
      end
      if mod:get("block_sfx") then playSound("wwise/events/minions/play_traitor_captain_shield_reactivate") end
      blockCD = mod:get("block_cd")
    elseif event_name == "parry_break" and breakCD <= 0 then
      if mod:get("scanlines_vfx") then screenParticle("content/fx/particles/screenspace/screen_disturbance_scanlines_pulse") end
      if mod:get("block_break_vfx") then createParticles("content/fx/particles/enemies/renegade_captain/renegade_captain_aoe_push", "j_hips") end
      if mod:get("block_break_sfx") then playSound("wwise/events/minions/play_traitor_captain_shield_overload") end
      breakCD = mod:get("block_break_cd")
    end
end

-- Local server player event handler
mod:hook_safe("AuthoritativePlayerUnitAnimationExtension", "anim_event", function(self, event_name, ...)
    animHandler(event_name)
end) 
-- Online server player event handler
mod:hook_safe("PlayerUnitAnimationExtension", "anim_event", function(self, event_name, ...)
    animHandler(event_name)
end) 





-- mod:command("getW", "", function()
--   mod:echo(Managers.player:local_player_safe(1)._profile.loadout.slot_primary.__master_item.name)
-- end)






-- #################################################
mod.shield_unit = nil



mod.despawn_shield = function()
	if mod.shield_unit ~= nil then
		if Unit.alive(mod.shield_unit) then World.destroy_unit(Managers.world:world("level_world"), mod.shield_unit) end
	end
  toughness_extension = nil
  buffs = nil
	mod.shield_unit = nil
end
mod:hook_safe("MissionManager", "init", function(self, mission_name, level, level_name, side_mission_name)
  --mod:echo("Mission")
  mission = mission_name
  if mission ~= "hub_ship" and shieldEnabled then
    waitTime = 15
  end
end)

mod:hook_safe("MissionManager", "destroy", function(s)
  --mod:echo("MissionE")
  if shieldEnabled then
    mod:despawn_shield()
  end
end)

local MasterItems = require("scripts/backend/master_items")

mod.spawn_shield = function()
  local shield_item = MasterItems.get_item("content/items/characters/minions/chaos_traitor_guard/attachments_gear/captain_fx_bubble")
	local world = Managers.world:world("level_world")
	local player = Managers.player:local_player_safe(1)
	local player_unit = player.player_unit

  local _fx_extension = ScriptUnit.extension(player_unit, "fx_system") -- Get fx extension
  if _fx_extension == nil then return end
  local vfx_unit, vfx_node = _fx_extension:vfx_spawner_unit_and_node("fx_anim_01")

  -- Unit.node on a bone the rig does not have is a hard engine crash (see j_hips); fall back to the root.
  local hand_node = Unit.has_node(player_unit, "j_neck") and Unit.node(player_unit, "j_neck") or 1
  toughness_extension = ScriptUnit.has_extension(player_unit, "toughness_system")
  local buff_extension = ScriptUnit.has_extension(player_unit, "buff_system")
  buffs = buff_extension and buff_extension:stat_buffs()
  damage = toughness_extension:toughness_damage()
  maxToughness = toughness_extension:max_toughness()

  --local viewport_name = player.viewport_name
  --local cameraNode = Managers.state.camera:current_camera_node(viewport_name)
  --local camera = Managers.state.camera:camera(viewport_name)
  --local cameraIndex = Unit.node(Managers.state.camera._camera_nodes.player1[1].node._root_unit, "j_camera_attach")
  --local cameraIndex = Unit.node(Managers.state.camera._camera_nodes.player1[1].node._root_unit, "j_camera_attach")
  
	--mod:dtf(World.units(world), "dump", 6)

  local pos = Unit.world_position(player_unit, hand_node)
  local rot = Unit.world_rotation(player_unit, hand_node)

  mod.shield_unit = World.spawn_unit(world, shield_item.base_unit, pos, rot)

  --World.link_unit(world, mod.shield_unit, 1, Managers.state.camera._camera_nodes.player1[1].node._root_unit, cameraIndex)
  Unit.set_local_scale(mod.shield_unit, 1, Vector3.one() * mod:get("shield_size"))
  Unit.set_scalar_for_materials(mod.shield_unit, "shield_power", 1, true)
  Unit.set_vector3_for_materials(mod.shield_unit, "color_a", Vector3(1,1,1), true)
  Unit.set_scalar_for_materials(mod.shield_unit, "redness", 0, false)
  Unit.set_vector3_for_materials(mod.shield_unit, "impact_position_01", Vector3(0,0,0), true)
  Unit.set_vector3_for_materials(mod.shield_unit, "impact_position_02", Vector3(0,0,0), true)
  Unit.set_vector3_for_materials(mod.shield_unit, "impact_position_03", Vector3(0,0,0), true)
  Unit.set_vector3_for_materials(mod.shield_unit, "impact_position_04", Vector3(0,0,0), true)
  Unit.set_vector2_for_materials(mod.shield_unit, "impact_start_duration_01", Vector2(0,0), true)
  Unit.set_vector2_for_materials(mod.shield_unit, "impact_start_duration_02", Vector2(0,0), true)
  Unit.set_vector2_for_materials(mod.shield_unit, "impact_start_duration_03", Vector2(0,0), true)
  Unit.set_vector2_for_materials(mod.shield_unit, "impact_start_duration_04", Vector2(0,0), true)
  -- mod:enable_shield(mod.shield_unit)
end

-- mod:command("shield", "", function()
-- 	mod:despawn_shield()
--   mod:spawn_shield()
-- end)
-- mod:command("dshield", "", function()
-- 	mod:despawn_shield()
-- end)








--mod:hook_safe("PlayerUnitToughnessExtension", "_update_toughness", function(self, dt, t)
  --mod:echo(self:max_toughness())
  --local buffs = self._buff_extension and self._buff_extension:stat_buffs()
  --mod:echo(buffs.toughness_bonus_flat)
  -- if mod.shield_unit ~= nil then 
  --   Unit.set_scalar_for_materials(mod.shield_unit, "shield_power", math.clamp(0.75 + (self._toughness_damage / self:max_toughness())/4,0,1), true)
  --   if buffs.toughness_bonus_flat == 0 then
  --     Unit.set_vector3_for_materials(mod.shield_unit, "color_a", Vector3(0,1,0.2), true)
  --   else
  --     Unit.set_vector3_for_materials(mod.shield_unit, "color_a", Vector3(0.9,1,0), true)
  --   end
  -- end
--end)


--mod:hook_safe("PlayerUnitToughnessExtension", "handle_max_toughness_changes_due_to_buffs", function(self, max_toughness_before, max_toughness_after)
--  if max_toughness_before < max_toughness_after then
--    if mod.shield_unit ~= nil then
--      if p ~= nil then 
--        World.stop_spawning_particles(Application.main_world(), p)
--      end
--      p = createParticles("content/fx/particles/enemies/twins/twins_shield_recharge", "j_hips")
--    end
--    rechargeCD = 0.15
--  end
--end)

-- Shield explosion when toughness breaks
--mod:hook_safe("PlayerUnitToughnessExtension", "set_toughness_broken_time", function(self)
--  createParticles("content/fx/particles/enemies/renegade_captain/renegade_captain_aoe_push", "root_point")
--  playSound("wwise/events/minions/play_traitor_captain_shield_break")
--end)

--mod:hook_safe("PlayerUnitToughnessExtension", "add_damage", function(self)
--  screenParticle("content/fx/particles/screenspace/screen_disturbance_scanlines_pulse")
--  playSound("wwise/events/minions/play_traitor_captain_shield_bullet_hits")
--  hitCD = 0.5
--end)



-- #################################################
