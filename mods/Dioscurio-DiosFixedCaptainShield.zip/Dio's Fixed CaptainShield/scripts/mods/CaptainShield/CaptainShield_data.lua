local mod = get_mod("CaptainShield")

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	allow_rehooking = true,
	options = {
		widgets = {
		{
			setting_id = "block",
			type = "group",
			sub_widgets = {
			{
				setting_id = "block_vfx",
				type = "checkbox",
				default_value = true
			},
			{
				setting_id = "block_sfx",
				type = "checkbox",
				default_value = true
			},
			{
				setting_id = "block_cd",
				type = "numeric",
				default_value = 0.5,
				range = {0, 10},
				decimals_number = 1,  
			},
			{
				setting_id = "scanlines_vfx",
				type = "checkbox",
				default_value = false
			},
		},
	},
		{
			setting_id = "block_break",
			type = "group",
			sub_widgets = {
			{
				setting_id = "block_break_vfx",
				type = "checkbox",
				default_value = true
			},
			{
				setting_id = "block_break_sfx",
				type = "checkbox",
				default_value = true
			},
			{
				setting_id = "block_break_cd",
				type = "numeric",
				default_value = 20,
				range = {0, 120},
				decimals_number = 1,
			},
		},
	},
		{
			setting_id = "shield",
			type = "group",
			sub_widgets = {
			{
				setting_id = "shield_enabled",
				type = "checkbox",
				default_value = true
			},
			{
				setting_id = "shield_strength",
				type = "numeric",
				default_value = 0.3,
				range = {0, 1},
				decimals_number = 2,                           
			},
			{
				setting_id = "shield_size",
				type = "numeric",
				default_value = 1,
				range = {0.25, 3},
				decimals_number = 2,  
			},
			{
				setting_id = "shield_scale",
				type = "checkbox",
				default_value = true
			},
			{
				setting_id = "shield_max_scale",
				type = "checkbox",
				default_value = false
			},
		},
	},
		{
			setting_id = "shield_hit",
			type = "group",
			sub_widgets = {
			{
				setting_id = "shield_hit_vfx",
				type = "checkbox",
				default_value = true
			},
			{
				setting_id = "shield_hit_sfx",
				type = "checkbox",
				default_value = true
			},
			{
				setting_id = "shield_hit_cd",
				type = "numeric",
				default_value = 0,
				range = {0, 10},
				decimals_number = 1,
			},
			{
				setting_id = "shield_hit_scale",
				type = "checkbox",
				default_value = true
			},
			{
				setting_id = "shield_flicker_strength",
				type = "numeric",
				default_value = 0.5,
				range = {0, 3},
				decimals_number = 2,  
			},
			{
				setting_id = "shield_flicker_duration",
				type = "numeric",
				default_value = 1,
				range = {0, 3},
				decimals_number = 2,  
			},
		},
	},
		{
			setting_id = "shield_break",
			type = "group",
			sub_widgets = {
				{
					setting_id = "shield_break_vfx",
					type = "checkbox",
					default_value = true
				},
				{
					setting_id = "shield_break_sfx",
					type = "checkbox",
					default_value = true
				},
				{
					setting_id = "shield_break_cd",
					type = "numeric",
					default_value = 20,
					range = {0, 120},
				},
			},
		},
		{
			setting_id = "shield_overcharge",
			type = "group",
			sub_widgets = {
			{
				setting_id = "shield_overcharge_vfx",
				type = "checkbox",
				default_value = true
			},
			{
				setting_id = "shield_overcharge_sfx",
				type = "checkbox",
				default_value = false
			},
			{
				setting_id = "shield_overcharge_sfx_long",
				type = "checkbox",
				default_value = false
			},
			{
				setting_id = "shield_overcharge_sfx_repeat",
				type = "checkbox",
				default_value = false
			},
			{
				setting_id = "shield_overcharge_duration",
				type = "numeric",
				default_value = 0.1,
				range = {0.1, 1},
				decimals_number = 2,  
			},
			},
		},
		{
			setting_id = "shield_normal",
			type = "group",
			sub_widgets = {
				{
					setting_id = "shield_normal_r",
					type = "numeric",
					default_value = 0,
					range = {0, 1},
					decimals_number = 2,
				},
				{
					setting_id = "shield_normal_g",
					type = "numeric",
					default_value = 0.4,
					range = {0, 1},
					decimals_number = 2,
				},
				{
					setting_id = "shield_normal_b",
					type = "numeric",
					default_value = 1,
					range = {0, 1},
					decimals_number = 2,
				},
			},
		},
		{
			setting_id = "shield_overcharged",
			type = "group",
			sub_widgets = {
				{
					setting_id = "shield_overcharged_r",
					type = "numeric",
					default_value = 1,
					range = {0, 1},
					decimals_number = 2,
				},
				{
					setting_id = "shield_overcharged_g",
					type = "numeric",
					default_value = 1,
					range = {0, 1},
					decimals_number = 2,
				},
				{
					setting_id = "shield_overcharged_b",
					type = "numeric",
					default_value = 0,
					range = {0, 1},
					decimals_number = 2,
				},
			},
		},
	}
	}
}
