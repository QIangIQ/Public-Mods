return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsBayonet` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsBayonet", {
            mod_script = "QIangIQsBayonet/scripts/mods/QIangIQsBayonet/QIangIQsBayonet",
            mod_data = "QIangIQsBayonet/scripts/mods/QIangIQsBayonet/QIangIQsBayonet_data",
            mod_localization = "QIangIQsBayonet/scripts/mods/QIangIQsBayonet/QIangIQsBayonet_localization",
        })
    end,
    version = "1.1.11",
    author = "QIangIQ",
    load_after = { "CustomAssets" },
    packages = {},
}
