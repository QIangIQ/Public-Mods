-- seconds of each CS2 clip in Custom/by_tp_driver (tp_bake_cs2.py, 378 frames at 30 fps)
return {
    draw = { start = 0.0000, length = 1.1667 },
    light_miss1 = { start = 1.2667, length = 1.1667 },
    light_miss2 = { start = 2.5333, length = 1.1667 },
    heavy_miss1 = { start = 3.8000, length = 1.1333 },
    light_backstab = { start = 5.0333, length = 1.1667 },
    lookat01 = { start = 6.3000, length = 6.2000 },
}
