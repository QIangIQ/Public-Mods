return {
	mod_name = {
		en = "Dio's Simple Powah",
	},
	mod_description = {
		en = "Shows the cooldown of the Ogryn power maul special. Author: Dioscurio",
	},
}
