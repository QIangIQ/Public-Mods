local mod = get_mod("DiosSimplePowah")

local UIWidget = require("scripts/managers/ui/ui_widget")
local UIWorkspaceSettings = require("scripts/settings/ui/ui_workspace_settings")

local HudElementDiosSimplePowah = class("HudElementDiosSimplePowah", "HudElementBase")

local SIZE = { 300, 32 }

local COLOR_READY    = { 255, 142, 208, 156 }
local COLOR_ACTIVE   = { 255, 232, 194, 92 }
local COLOR_COOLDOWN = { 255, 230, 230, 230 }

-- Hide the counter if the special hasn't updated recently (maul not equipped, dead, loading)
local STALE_AFTER = 0.5

local scenegraph_definition = {
	screen = UIWorkspaceSettings.screen,
	powah = {
		parent = "screen",
		vertical_alignment = "bottom",
		horizontal_alignment = "center",
		size = SIZE,
		position = { 0, -180, 100 },
	},
}

local widget_definitions = {
	powah = UIWidget.create_definition({
		{
			value_id = "text",
			style_id = "text",
			pass_type = "text",
			value = "",
			style = {
				font_size = 22,
				font_type = "proxima_nova_bold",
				drop_shadow = true,
				text_color = COLOR_COOLDOWN,
				text_horizontal_alignment = "center",
				text_vertical_alignment = "center",
				size = SIZE,
				offset = { 0, 0, 10 },
			},
		},
	}, "powah"),
}

HudElementDiosSimplePowah.init = function(self, parent, draw_layer, start_scale)
	HudElementDiosSimplePowah.super.init(self, parent, draw_layer, start_scale, {
		scenegraph_definition = scenegraph_definition,
		widget_definitions = widget_definitions,
	})
end

HudElementDiosSimplePowah.update = function(self, dt, t, ui_renderer, render_settings, input_service)
	HudElementDiosSimplePowah.super.update(self, dt, t, ui_renderer, render_settings, input_service)

	local widget = self._widgets_by_name.powah
	local p = mod.powah

	if not p or not p.state or os.clock() - p.last_seen > STALE_AFTER then
		widget.content.text = ""
		return
	end

	local style = widget.style.text
	if p.state == "ready" then
		widget.content.text = "POWAH READY"
		style.text_color = COLOR_READY
	elseif p.state == "active" then
		widget.content.text = "POWAH ON"
		style.text_color = COLOR_ACTIVE
	else
		widget.content.text = string.format("POWAH %.1f", p.remaining)
		style.text_color = COLOR_COOLDOWN
	end
end

return HudElementDiosSimplePowah
