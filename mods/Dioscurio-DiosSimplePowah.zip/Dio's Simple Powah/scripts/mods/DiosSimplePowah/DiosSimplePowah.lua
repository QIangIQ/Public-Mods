local mod = get_mod("DiosSimplePowah")

-- Shared state, written by the weapon special hook and read by the HUD element.
-- state: nil (maul not equipped), "ready", "active", "cooldown"
mod.powah = {
	state = nil,
	remaining = 0,
	last_seen = 0,
}

local function local_player_unit()
	local player = Managers.player and Managers.player:local_player_safe(1)
	return player and player.player_unit
end

-- Only the base Ogryn power maul (ogryn_powermaul_p1_m1) uses this special class.
-- It updates even while the maul is holstered, so the counter keeps running on ranged.
mod:hook_safe("WeaponSpecialExplodeOnImpactCooldown", "fixed_update", function(self, dt, t)
	if self._player_unit ~= local_player_unit() then
		return
	end

	local slot = self._inventory_slot_component
	local tweak = self._tweak_data
	if not slot or not tweak then
		return
	end

	local p = mod.powah
	p.last_seen = os.clock()

	if slot.special_active then
		p.state = "active"
		p.remaining = 0
	elseif slot.num_special_charges >= tweak.max_num_charges then
		p.state = "ready"
		p.remaining = 0
	else
		p.state = "cooldown"
		p.remaining = math.max((self._next_charge_recovery_time or t) - t, 0)
	end
end)

-- HUD element registration
local hud_element = {
	class_name = "HudElementDiosSimplePowah",
	filename = "Dio's Simple Powah/scripts/mods/DiosSimplePowah/DiosSimplePowah_HUDElement",
	use_hud_scale = true,
	visibility_groups = { "alive" },
}

mod:add_require_path(hud_element.filename)

local function add_hud_element(elements)
	local i, existing = table.find_by_key(elements, "class_name", hud_element.class_name)
	if not i or not existing then
		table.insert(elements, hud_element)
	else
		elements[i] = hud_element
	end
end

mod:hook_require("scripts/ui/hud/hud_elements_player", add_hud_element)
mod:hook_require("scripts/ui/hud/hud_elements_player_onboarding", add_hud_element)
