return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`DiosSimplePowah` encountered an error loading the Darktide Mod Framework.")

		new_mod("DiosSimplePowah", {
			mod_script       = "Dio's Simple Powah/scripts/mods/DiosSimplePowah/DiosSimplePowah",
			mod_data         = "Dio's Simple Powah/scripts/mods/DiosSimplePowah/DiosSimplePowah_data",
			mod_localization = "Dio's Simple Powah/scripts/mods/DiosSimplePowah/DiosSimplePowah_localization",
		})
	end,
	version = "1.0.0",
	packages = {},
}
