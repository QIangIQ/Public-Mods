return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsToughnessGauge` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsToughnessGauge", {
			mod_script       = "QIangIQsToughnessGauge/scripts/mods/QIangIQsToughnessGauge/QIangIQsToughnessGauge",
			mod_data         = "QIangIQsToughnessGauge/scripts/mods/QIangIQsToughnessGauge/QIangIQsToughnessGauge_data",
			mod_localization = "QIangIQsToughnessGauge/scripts/mods/QIangIQsToughnessGauge/QIangIQsToughnessGauge_localization",
		})
	end,
	packages = {},
}
