local mod = get_mod("QIangIQsToughnessGauge")

--[[
    TOUGHNESS GAUGE  (QIangIQsToughnessGauge 0.3.0)

    0.3.0: weapon blessings (base_weapon_trait_buff_templates.lua: toughness on crit kills,
    elite kills, close kills, chained hits, multiple hits, continuous fire) and the
    Skitarii (cryptic) toughness talents are counted on clients too; the breakdown shows
    the game's own English talent and blessing names.

    A half dial (speedometer) in TN per second. Top = 0, right = gain, left = loss.
      green needle  theoretical regeneration: every toughness source active now,
                    counted even while toughness is full
      red needle    toughness being lost
      white needle  net (theoretical regen - loss, or the actual change; setting)

    Every number comes from the game's own code (Aussiemon Darktide-Source-Code master):
      scripts/extension_systems/toughness/player_unit_toughness_extension.lua
        _update_toughness       passive (coherency) regen and toughness_regen_percent
        recover_toughness       replenish by type (melee_kill ...)
        recover_percentage_toughness / recover_flat_toughness / recover_max_toughness
        _toughness_regen_disabled  (knocked down, dead, prevent_* keywords)
        add_damage              regen delay after a hit
        _handle_procs           called with the WANTED amount, even at full toughness
      scripts/settings/toughness/archetype_toughness_templates.lua (5 TN/s, 3 s delay, 5 percent melee kill)
      scripts/settings/buff/player_buff_templates.lua (coherency 0 / 0.5 / 0.75 / 1 ...)

    Host (solo / you are the server): the player's real PlayerUnitToughnessExtension
    runs here. _handle_procs gives the wanted amount of every replenish (kills, talents,
    abilities, over-time buffs), the regen delay and combat state (slot_system) are read
    directly. Exact.

    Client on a Fatshark server: the local unit has PlayerHuskToughnessExtension, which
    only reads the networked "toughness" and "toughness_damage" fields; replenishes run
    on the server. The client rebuilds what it can see:
      * passive formula from the local (synced) stat buffs, weapon toughness template;
        regen delay from the observed hit time; combat state is unknown (setting)
      * Toughness.replenish* calls made by buffs whose update runs on the client too
      * melee kills (attack reports from the server) -> recover_toughness(melee_kill)
      * server-only talent buffs mirrored from their templates and TalentSettings:
          veteran_toughness_on_elite_kill_effect   instant + per second, per instance
          adamant_toughness_on_elite_kill_effect   instant + per second, per instance
          veteran_toughness_regen_out_of_melee     per second, 5 s after a melee hit
          zealot_toughness_while_shooting          per second while shooting
          ogryn_regen_toughness_on_braced          per second while braced or shooting
      * anything else: the regeneration actually observed is a floor for the green needle.

    Instant amounts are spread with an exponential window (setting "smoothing") so the
    integral of the needle equals the amount. Over-time sources show their exact rate.
--]]

local Toughness = require("scripts/utilities/toughness/toughness")
local TalentSettings = require("scripts/settings/talent/talent_settings")
local PlayerUnitStatus = require("scripts/utilities/attack/player_unit_status")
local ToughnessSettings = require("scripts/settings/toughness/toughness_settings")
local BuffSettings = require("scripts/settings/buff/buff_settings")

local replenish_types = ToughnessSettings.replenish_types
local buff_keywords = BuffSettings.keywords

local FONT = "content/ui/fonts/proxima_nova_bold"
local LAYER = 950
local STANDING_STILL_EPSILON = 0.001 -- player_unit_toughness_extension.lua
local MAX_RECTS = 1500

-- Copied from player_unit_toughness_extension.lua (both lists are identical there,
-- except ogryn_ranged_stance_shoot, which only the first allows).
local ABILITIES_ALLOW_RECOVERY_REASONS = {
	ability_shout = true, ability_stance = true, adamant_buff_drone = true, adamant_charge = true,
	bull_rush_toughness_talent = true, cryptic_precision_stance = true, lunging = true,
	ogryn_ranged_stance_reload = true, ogryn_ranged_stance_shoot = true, ogryn_taunt_restore_toughness = true,
	ogryn_taunt_restore_toughness_over_time = true, overcharge_stance = true, psyker_sphere = true,
	veteran_ranged_stance = true, zealot_channel = true, zealot_stealth = true,
}
local COMBAT_ABILITIES_ALLOWED_RECOVERY_REASONS = {
	ability_shout = true, ability_stance = true, adamant_buff_drone = true, adamant_charge = true,
	bull_rush_toughness_talent = true, cryptic_precision_stance = true, lunging = true,
	ogryn_ranged_stance_reload = true, ogryn_taunt_restore_toughness = true,
	ogryn_taunt_restore_toughness_over_time = true, overcharge_stance = true, psyker_sphere = true,
	veteran_ranged_stance = true, zealot_channel = true, zealot_stealth = true,
}

-- ---------------------------------------------------------------------------
-- Settings
-- ---------------------------------------------------------------------------

local settings = {}

local function _read_settings()
	settings.scale_mode = mod:get("scale_mode") or "percent"
	settings.scale_percent_value = mod:get("scale_percent_value") or 15
	settings.scale_fixed_value = mod:get("scale_fixed_value") or 30
	settings.tau = math.max((mod:get("smoothing") or 15) / 10, 0.1)
	settings.net_mode = mod:get("net_mode") or "theoretical"
	settings.client_coherency = mod:get("client_coherency") and true or false
	settings.show_fills = mod:get("show_fills") ~= false
	settings.show_text = mod:get("show_text") ~= false
	settings.show_breakdown = mod:get("show_breakdown") and true or false
	settings.pos_x = (mod:get("pos_x") or 50) / 100
	settings.pos_y = (mod:get("pos_y") or 78) / 100
	settings.size = mod:get("size") or 110
end

_read_settings()

mod.on_setting_changed = function ()
	_read_settings()
end

local view_on = true

mod.toggle_view = function ()
	view_on = not view_on
end

-- ---------------------------------------------------------------------------
-- State
-- ---------------------------------------------------------------------------

local state = {}

local function _reset(unit)
	state.unit = unit
	state.host = false
	state.last_damage = nil
	state.last_max = nil
	state.loss_rate = 0
	state.obs_regen = 0
	state.client_delay_end = -math.huge
	state.last_melee_hit_t = -math.huge
	state.cooldowns = {}
	state.windows = {}
	state.events = {}            -- reason -> smoothed TN/s from instant / per-frame amounts
	state.seen = setmetatable({}, { __mode = "k" }) -- mirrored buff instances already counted
	state.chain = setmetatable({}, { __mode = "k" }) -- chained-hits blessing counter per buff instance
	state.fire = setmetatable({}, { __mode = "k" })  -- continuous-fire blessing steps per buff instance
	state.primed = false         -- first frame: buffs that already exist are not new kills
	state.parts = {}             -- label -> TN/s, rebuilt each frame
	state.theo = 0
	state.theo_model = 0
	state.net = 0
	state.max = 0
	state.scale = 1
	state.t = 0
end

_reset(nil)

local function _gameplay_time()
	local time_manager = Managers.time

	if time_manager and time_manager:has_timer("gameplay") then
		return time_manager:time("gameplay")
	end

	return nil
end

local function _local_player_unit()
	local player = Managers.player and Managers.player:local_player(1)
	local unit = player and player.player_unit

	if unit and Unit.alive(unit) then
		return unit
	end

	return nil
end

local function _impulse(reason, amount)
	if type(amount) ~= "number" or amount <= 0 then
		return
	end

	local key = reason or "other"

	state.events[key] = (state.events[key] or 0) + amount / settings.tau
end

local function _stat_buffs(unit)
	local buff_extension = ScriptUnit.has_extension(unit, "buff_system")

	return buff_extension and buff_extension:stat_buffs(), buff_extension
end

local function _weapon_toughness_template(unit)
	local weapon_extension = ScriptUnit.has_extension(unit, "weapon_system")

	if weapon_extension and weapon_extension.toughness_template then
		local ok, template = pcall(weapon_extension.toughness_template, weapon_extension)

		return ok and template or nil
	end

	return nil
end

local function _num(value, default)
	return type(value) == "number" and value or default
end

-- PlayerUnitToughnessExtension._toughness_regen_disabled
local function _regen_disabled(unit, optional_reason)
	local health_alive = rawget(_G, "HEALTH_ALIVE")

	if health_alive and not health_alive[unit] then
		return true
	end

	local unit_data_extension = ScriptUnit.has_extension(unit, "unit_data_system")

	if unit_data_extension then
		local character_state = unit_data_extension:read_component("character_state")
		local assisted = unit_data_extension:read_component("assisted_state_input")

		if character_state and PlayerUnitStatus.is_knocked_down(character_state) and not (assisted and assisted.force_assist) then
			return true
		end
	end

	local _, buff_extension = _stat_buffs(unit)

	if not buff_extension then
		return false
	end

	if buff_extension:has_keyword(buff_keywords.prevent_toughness_replenish) then
		return true
	end

	if buff_extension:has_keyword(buff_keywords.prevent_toughness_replenish_except_all_combat_abilities) and not COMBAT_ABILITIES_ALLOWED_RECOVERY_REASONS[optional_reason] then
		return true
	end

	if buff_extension:has_keyword(buff_keywords.prevent_toughness_replenish_except_abilities) and not ABILITIES_ALLOW_RECOVERY_REASONS[optional_reason] then
		return true
	end

	return false
end

local function _replenish_mult(stat_buffs)
	return _num(stat_buffs.toughness_replenish_modifier, 1) * _num(stat_buffs.toughness_replenish_multiplier, 1)
end

-- PlayerUnitToughnessExtension.recover_toughness: wanted amount for a replenish type
local function _wanted_for_type(unit, recovery_type)
	local toughness_extension = ScriptUnit.has_extension(unit, "toughness_system")
	local stat_buffs = _stat_buffs(unit)

	if not toughness_extension or not stat_buffs then
		return 0
	end

	local template = toughness_extension:toughness_templates()
	local percentage = template and template.recovery_percentages and template.recovery_percentages[recovery_type]

	if not percentage then
		return 0
	end

	local weapon_template = _weapon_toughness_template(unit)
	local modifier = weapon_template and weapon_template.recovery_percentage_modifiers and _num(weapon_template.recovery_percentage_modifiers[recovery_type], 1) or 1
	local melee = recovery_type == replenish_types.melee_kill and _num(stat_buffs.toughness_melee_replenish, 1) or 1
	local multiplier = (melee + _num(stat_buffs.toughness_replenish_modifier, 1) - 1) * _num(stat_buffs.toughness_replenish_multiplier, 1)

	return toughness_extension:max_toughness() * percentage * multiplier * modifier
end

-- ---------------------------------------------------------------------------
-- Host: every replenish passes through _handle_procs with the wanted amount
-- ---------------------------------------------------------------------------

mod:hook_safe("PlayerUnitToughnessExtension", "_handle_procs", function (self, amount, recovered_amount, reason)
	if self._unit ~= state.unit or not state.unit then
		return
	end

	-- The passive "coherency" tick also carries toughness_regen_percent; both are
	-- computed by the formula below, so they are not counted twice.
	if reason == "coherency" then
		return
	end

	_impulse(reason or "other", amount)
end)

-- ---------------------------------------------------------------------------
-- Client: replenish calls made by buffs whose update also runs on the client
-- (on a husk these calls do nothing in the game; the server does the real one)
-- ---------------------------------------------------------------------------

mod:hook_safe(Toughness, "replenish", function (unit, recovery_type)
	if state.host or unit ~= state.unit or not unit then
		return
	end

	if not _regen_disabled(unit, nil) then
		_impulse(recovery_type, _wanted_for_type(unit, recovery_type))
	end
end)

mod:hook_safe(Toughness, "replenish_percentage", function (unit, fixed_percentage, ignore_stat_buffs, reason)
	if state.host or unit ~= state.unit or not unit or type(fixed_percentage) ~= "number" then
		return
	end

	if _regen_disabled(unit, reason) then
		return
	end

	local toughness_extension = ScriptUnit.has_extension(unit, "toughness_system")
	local stat_buffs = _stat_buffs(unit)

	if toughness_extension and stat_buffs then
		local percentage = ignore_stat_buffs and fixed_percentage or fixed_percentage * _replenish_mult(stat_buffs)

		_impulse(reason or "talent", toughness_extension:max_toughness() * percentage)
	end
end)

mod:hook_safe(Toughness, "replenish_flat", function (unit, amount, ignore_stat_buffs, reason)
	if state.host or unit ~= state.unit or not unit or type(amount) ~= "number" then
		return
	end

	if _regen_disabled(unit, reason) then
		return
	end

	local stat_buffs = _stat_buffs(unit)

	if stat_buffs then
		_impulse(reason or "talent", ignore_stat_buffs and amount or amount * _replenish_mult(stat_buffs))
	end
end)

mod:hook_safe(Toughness, "recover_max_toughness", function (unit, reason, ignore_state_block)
	if state.host or unit ~= state.unit or not unit then
		return
	end

	local toughness_extension = ScriptUnit.has_extension(unit, "toughness_system")

	if toughness_extension and not _regen_disabled(unit, reason) then
		_impulse(reason or "max", toughness_extension:max_toughness())
	end
end)

local function _ts(path)
	local node = TalentSettings

	for key in string.gmatch(path, "[^%.]+") do
		node = type(node) == "table" and node[key] or nil
	end

	return _num(node, 0)
end

-- ---------------------------------------------------------------------------
-- Client mirrors of INSTANT talent replenishes (0.2.0)
--
-- On a client, non-predicted proc buffs never run their proc_func
-- (BuffExtensionBase._update_proc_events: is_server or is_predicted), so their
-- Toughness.replenish_percentage calls happen only on the server. Each entry
-- below copies one template's trigger and amount from the game files
-- (scripts/settings/buff/archetype_buff_templates/*.lua) and is fed by what the
-- client does see:
--   * attack reports from the server (kills, weakspot, attack type, damage profile)
--   * the local unit's own proc events (on_sweep_finish, on_successful_dodge,
--     on_shoot, on_reload, on_warp_charge_changed, on_perfect_block), which the
--     client's predicted actions still raise (action_sweep.lua, dodge.lua ...)
-- A source counts when its buff is on the unit or the talent loadout lists it
-- (talent_extension:buff_template_tier).
-- ---------------------------------------------------------------------------

local BuffTemplates
local DamageSettings

pcall(function ()
	BuffTemplates = require("scripts/settings/buff/buff_templates")
end)
pcall(function ()
	DamageSettings = require("scripts/settings/damage/damage_settings")
end)

local function _template(name)
	return BuffTemplates and BuffTemplates[name]
end

local function _has_source(unit, name)
	local talent_extension = ScriptUnit.has_extension(unit, "talent_system")
	local tier

	if talent_extension and talent_extension.buff_template_tier then
		local ok, value = pcall(talent_extension.buff_template_tier, talent_extension, name)

		tier = ok and value or nil
	end

	if tier then
		return true, _num(tier, 1)
	end

	local _, buff_extension = _stat_buffs(unit)

	if buff_extension and buff_extension.has_buff_using_buff_template then
		local ok, has = pcall(buff_extension.has_buff_using_buff_template, buff_extension, name)

		if ok and has then
			return true, 1
		end
	end

	return false
end

local function _has_rule(unit, rule)
	local talent_extension = unit and ScriptUnit.has_extension(unit, "talent_system")

	if not talent_extension or not talent_extension.has_special_rule then
		return false
	end

	local ok, has = pcall(talent_extension.has_special_rule, talent_extension, rule)

	return ok and has and true or false
end

-- ---------------------------------------------------------------------------
-- 0.3.0 weapon blessings (scripts/settings/buff/weapon_traits_buff_templates/
-- base_weapon_trait_buff_templates.lua). Every toughness blessing is a clone of one
-- base template, so its kind is found by function identity (table.clone keeps the
-- function references). The buff is on the client too (rpc_add_buff carries the
-- item slot), so its rarity values are in the instance's _template_override_data.
-- All of them are proc buffs with predicted = false: their proc runs on the server.
-- ---------------------------------------------------------------------------

local BaseTraitBuffs

pcall(function ()
	BaseTraitBuffs = require("scripts/settings/buff/weapon_traits_buff_templates/base_weapon_trait_buff_templates")
end)

local TRAIT_KINDS = {}

local function _trait_kind(template)
	local name = template and template.name

	if not name or not BaseTraitBuffs then
		return nil
	end

	local cached = TRAIT_KINDS[name]

	if cached ~= nil then
		return cached or nil
	end

	local b = BaseTraitBuffs
	local kind = false

	local function same(base, field)
		return base ~= nil and template[field] ~= nil and template[field] == base[field]
	end

	if same(b.toughness_on_crit_kills, "check_proc_func") then
		kind = "crit_kill"
	elseif same(b.toughness_on_elite_kills, "check_proc_func") then
		kind = "elite_kill"
	elseif same(b.toughness_recovery_on_close_kill, "check_proc_func") then
		kind = "close_kill"
	elseif same(b.toughness_recovery_on_chained_attacks, "proc_func") then
		kind = "chained"
	elseif same(b.toughness_recovery_on_multiple_hits, "proc_func") then
		kind = "multi_hit"
	else
		local base = b.toughness_on_continuous_fire
		local mine = template.specific_proc_func
		local theirs = base and base.specific_proc_func

		if mine and theirs and mine.on_ammo_consumed ~= nil and mine.on_ammo_consumed == theirs.on_ammo_consumed then
			kind = "continuous_fire"
		end
	end

	TRAIT_KINDS[name] = kind

	return kind or nil
end

-- toughness_fixed_percentage by rarity (recover_percentage_toughness, ignore_stat_buffs = true)
local function _trait_pct(instance, template)
	local override = instance._template_override_data

	return _num(override and override.toughness_fixed_percentage, _num(template.toughness_fixed_percentage, 0))
end

-- toughness_recovery_on_multiple_hits: buff_data.replenish_percentage (Toughness.replenish_percentage, stat buffs apply)
local function _multi_pct(instance, template)
	local override = instance._template_override_data
	local buff_data = override and override.buff_data or template.buff_data

	return buff_data and _num(buff_data.replenish_percentage, 0) or 0
end

-- ConditionalFunctions.is_item_slot_wielded
local function _slot_wielded(unit, instance)
	local ok, slot = pcall(instance.item_slot_name, instance)

	if not ok or not slot then
		return true
	end

	local unit_data_extension = ScriptUnit.has_extension(unit, "unit_data_system")
	local inventory = unit_data_extension and unit_data_extension:read_component("inventory")

	return inventory and inventory.wielded_slot == slot or false
end

local function _each_trait(unit, fn)
	local _, buff_extension = _stat_buffs(unit)
	local buffs = buff_extension and buff_extension:buffs()

	if not buffs then
		return
	end

	for i = 1, #buffs do
		local instance = buffs[i]
		local ok, template = pcall(instance.template, instance)
		local kind = ok and _trait_kind(template)

		if kind and _slot_wielded(unit, instance) then
			fn(instance, template, kind)
		end
	end
end

-- _number_of_continuous_fire_steps (not use_combo): floor(num_shots / step),
-- step from the template's continuous_fire_step_func (fire_step_functions.lua: 10 percent of the clip)
local function _fire_steps(unit, instance, template)
	local unit_data_extension = ScriptUnit.has_extension(unit, "unit_data_system")
	local shooting_status = unit_data_extension and unit_data_extension:read_component("shooting_status")
	local num_shots = shooting_status and _num(shooting_status.num_shots, 0) or 0
	local step

	if template.continuous_fire_step_func then
		local ok, value = pcall(template.continuous_fire_step_func, instance._template_data, instance._template_context)

		step = ok and value or nil
	end

	step = _num(step, _num(template.continuous_fire_step, 1))

	if step <= 0 then
		return 0
	end

	return math.floor(num_shots / step)
end

-- replenish_percentage(unit, pct, ignore_stat_buffs, reason) as the server would run it
local function _instant(unit, name, percentage, reason, ignore_stat_buffs)
	if type(percentage) ~= "number" or percentage <= 0 or _regen_disabled(unit, reason) then
		return
	end

	local toughness_extension = ScriptUnit.has_extension(unit, "toughness_system")
	local stat_buffs = _stat_buffs(unit)

	if toughness_extension and stat_buffs then
		local amount = toughness_extension:max_toughness() * (ignore_stat_buffs and percentage or percentage * _replenish_mult(stat_buffs))

		_impulse(name, amount)
	end
end

local function _cooldown_ok(name, cooldown)
	state.cooldowns = state.cooldowns or {}

	local last = state.cooldowns[name]

	if last and state.t < last + cooldown then
		return false
	end

	state.cooldowns[name] = state.t

	return true
end

local function _is_ranged(attack_type, damage_profile)
	return attack_type == "ranged" or (damage_profile and damage_profile.count_as_ranged_attack) and true or false
end

local function _is_close(me, hit_world_position)
	-- Unit.world_position, not POSITION_LOOKUP: its entries can be stale handles ("Vector3 expected, got userdata",
	-- lesson-position-lookup-stale-handle)
	local position = me and Unit.alive(me) and Unit.world_position(me, 1)
	local close_squared = DamageSettings and DamageSettings.ranged_close_squared

	if not position or not hit_world_position or not close_squared then
		return false
	end

	return Vector3.distance_squared(hit_world_position, position) <= close_squared
end

-- kills reported by the server (attacking_unit == me, attack_result "died")
local KILL_MIRRORS = {
	-- veteran: any kill (check on_kill on on_hit); talent_overrides by tier
	veteran_all_kills_replenish_bonus_toughness = function (k, tier)
		local template = _template("veteran_all_kills_replenish_bonus_toughness")
		local overrides = template and template.talent_overrides
		local entry = overrides and (overrides[tier] or overrides[1])

		return entry and entry.toughness_percentage or _ts("veteran_3.toughness_3.toughness"), "talent_toughness_3"
	end,
	-- veteran: ranged weakspot kill
	veteran_ranged_weakspot_toughness_recovery = function (k)
		if k.weakspot and k.ranged then
			return _ts("veteran_2.toughness_2.toughness"), "talent_toughness_2"
		end
	end,
	-- zealot: heavy (melee_attack_strength) kill, template.toughness_percentage
	zealot_toughness_on_heavy_kills = function (k)
		if k.heavy then
			local template = _template("zealot_toughness_on_heavy_kills")

			return template and template.toughness_percentage, "zealot_heavy_kill"
		end
	end,
	-- zealot: ranged kill
	zealot_toughness_on_ranged_kill = function (k)
		if k.ranged then
			local template = _template("zealot_toughness_on_ranged_kill")

			return template and template.toughness_percentage, "zealot_ranged_kill"
		end
	end,
	-- psyker: warp damage kill (only when the damage profile names its damage type)
	psyker_toughness_on_warp_kill = function (k)
		if k.warp then
			return _ts("psyker_2.toughness_2.percent_toughness"), "talent_toughness_2"
		end
	end,
	-- arbites: kill within 12.5 m (DamageSettings.ranged_close_squared)
	adamant_close_kills_restore_toughness = function (k)
		if k.close then
			return _ts("adamant.close_kills_restore_toughness.toughness"), nil
		end
	end,
	-- skitarii: weakspot kill, template.toughness_restored_on_proc
	cryptic_weakspot_kills_restore_toughness = function (k)
		if k.weakspot then
			local template = _template("cryptic_weakspot_kills_restore_toughness")

			return template and template.toughness_restored_on_proc, "cryptic_talent"
		end
	end,
	-- skitarii dissector keystone (server_only_proc_buff): elite or special kill
	cryptic_dissector = function (k)
		if k.tags and (k.tags.elite or k.tags.special) then
			return _ts("cryptic.dissector.toughness_regen_percent_per_elite_or_special_kill"), "cryptic_talent"
		end
	end,
	-- hive scum: close ranged kill, more on elites/specials
	broker_passive_restore_toughness_on_close_ranged_kill = function (k)
		if k.ranged and k.close then
			if k.tags and (k.tags.elite or k.tags.special) then
				return _ts("broker.broker_passive_restore_toughness_on_close_ranged_kill.toughness_elites"), nil
			end

			return _ts("broker.broker_passive_restore_toughness_on_close_ranged_kill.toughness_percentage"), nil
		end
	end,
}

-- over-time windows started by a kill (proc active_duration, server update_func)
-- (0.3.0: cryptic_elite_kills_toughness moved to PROC_WINDOWS, read from the server's proc time)
local KILL_WINDOWS = {}

-- the local unit's own proc events
local EVENT_MIRRORS = {
	on_sweep_finish = {
		-- ogryn: one enemy hit, heavy -> toughness, light -> reduced_toughness
		ogryn_heavy_hits_toughness = function (params)
			if params.num_hit_units == 1 then
				local heavy = params.is_heavy or params.melee_attack_strength == "heavy"

				return _ts(heavy and "ogryn_2.toughness_2.toughness" or "ogryn_2.toughness_2.reduced_toughness"), "talent_toughness_2"
			end
		end,
		-- ogryn: several enemies hit, heavy -> heavy_toughness, light -> toughness
		ogryn_multiple_enemy_heavy_hits_restore_toughness = function (params)
			if _num(params.num_hit_units, 0) > 1 then
				local heavy = params.is_heavy or params.melee_attack_strength == "heavy"

				return _ts(heavy and "ogryn_2.toughness_3.heavy_toughness" or "ogryn_2.toughness_3.toughness"), "talent_toughness_3"
			end
		end,
		-- psyker: first melee target hit -> instant_toughness (the server runs it per on_hit with target_index 1)
		psyker_toughness_on_melee = function (params)
			if _num(params.num_hit_units, 0) >= 1 then
				return _ts("psyker.melee_toughness.instant_toughness"), "psyker_melee_toughness"
			end
		end,
	},
	on_successful_dodge = {
		-- zealot: template.toughness_percentage, cooldown_duration 0.5
		zealot_toughness_on_dodge = function (params)
			local template = _template("zealot_toughness_on_dodge")

			if template and _cooldown_ok("zealot_toughness_on_dodge", _num(template.cooldown_duration, 0)) then
				return template.toughness_percentage, "zealot_dodge"
			end
		end,
	},
	on_shoot = {
		-- ogryn ranged stance (buff present only during the stance): 0.025 per shot
		ogryn_ranged_stance_toughness_regen = function (params)
			return 0.025, "ogryn_ranged_stance_shoot", true
		end,
	},
	on_shoot_projectile = {
		ogryn_ranged_stance_toughness_regen = function (params)
			return 0.025, "ogryn_ranged_stance_shoot", true
		end,
	},
	on_reload = {
		ogryn_ranged_stance_toughness_regen = function (params)
			return 0.15, "ogryn_ranged_stance_reload", true
		end,
	},
	on_warp_charge_changed = {
		-- psyker: venting (percentage_change > 0) * toughness_3.multiplier
		psyker_toughness_on_vent = function (params)
			local change = _num(params.percentage_change, 0)

			if change > 0 then
				return change * _ts("psyker_2.toughness_3.multiplier"), "toughness_on_vent"
			end
		end,
		-- psyker: generating peril (percentage_change < 0) * multiplier
		psyker_toughness_on_warp_generation = function (params)
			local change = _num(params.percentage_change, 0)

			if change < 0 then
				return math.abs(change * _ts("psyker_2.toughness_3.multiplier")), "toughness_on_warp_generation"
			end
		end,
	},
	on_combat_ability = {
		-- skitarii (server_only_proc_buff): toughness_replenish_percent to everyone in coherency, you included
		cryptic_coherency_toughness_on_ability = function (params)
			return _ts("cryptic.cryptic_coherency_toughness_on_ability.toughness_replenish_percent"), "cryptic_talent"
		end,
		-- skitarii discharge (action_cryptic_discharge.lua, server only): charges used * toughness_percent_on_use
		-- (special rule cryptic_discharge_restores_toughness_on_use comes with this talent)
		cryptic_discharge_toughness = function (params)
			local me = state.unit
			local _, buff_extension = _stat_buffs(me)
			local full = buff_extension and buff_extension:has_keyword("cryptic_discharge_ability_always_full_charges_bonus")
			local charges = full and 3 or _num(params.ability_cost, 0)

			if charges > 0 and _has_rule(me, "cryptic_discharge_restores_toughness_on_use") then
				return charges * _ts("cryptic.discharge_ability.cryptic_discharge_toughness.toughness_percent_on_use"), "ability_shout"
			end
		end,
	},
	on_perfect_block = {
		-- arbites shield plates: perfect_toughness, internal cooldown icd
		adamant_shield_plates = function (params)
			if _cooldown_ok("adamant_shield_plates", _ts("adamant.shield_plates.icd")) then
				return _ts("adamant.shield_plates.perfect_toughness"), nil
			end
		end,
	},
}

-- buffs that exist only while active (not talent buffs): require the buff itself
local BUFF_ONLY = {
	ogryn_ranged_stance_toughness_regen = true,
}

local function _source_active(unit, name)
	if BUFF_ONLY[name] then
		local _, buff_extension = _stat_buffs(unit)
		local ok, has = pcall(function ()
			return buff_extension:has_buff_using_buff_template(name)
		end)

		return ok and has or false, 1
	end

	return _has_source(unit, name)
end

local function _on_kill_report(me, attacked_unit, damage_profile, hit_world_position, hit_weakspot, attack_type)
	local unit_data_extension = ScriptUnit.has_extension(attacked_unit, "unit_data_system")
	local breed = unit_data_extension and unit_data_extension.breed and unit_data_extension:breed()
	local damage_type = damage_profile and damage_profile.damage_type
	local warp_types = DamageSettings and DamageSettings.warp_damage_types
	local k = {
		tags = breed and breed.tags,
		weakspot = hit_weakspot and true or false,
		ranged = _is_ranged(attack_type, damage_profile),
		heavy = damage_profile and damage_profile.melee_attack_strength == "heavy" or false,
		warp = damage_type and warp_types and warp_types[damage_type] and true or false,
		close = _is_close(me, hit_world_position),
	}

	-- blessings: toughness on elite kills / on crit kills (on_item_match ~ the wielded weapon)
	local unit_data_extension_me = ScriptUnit.has_extension(me, "unit_data_system")
	local critical_strike = unit_data_extension_me and unit_data_extension_me:read_component("critical_strike")
	local crit = critical_strike and critical_strike.is_active or false

	_each_trait(me, function (instance, template, kind)
		if kind == "elite_kill" and k.tags and k.tags.elite or kind == "crit_kill" and crit then
			_instant(me, template.name, _trait_pct(instance, template), "blessing", true)
		end
	end)

	for name, fn in pairs(KILL_MIRRORS) do
		local active, tier = _source_active(me, name)

		if active then
			local ok, percentage, reason, ignore = pcall(fn, k, tier)

			if ok and percentage then
				_instant(me, name, percentage, reason, ignore)
			end
		end
	end

	for name, fn in pairs(KILL_WINDOWS) do
		local active = _source_active(me, name)

		if active then
			local ok, per_second, duration, reason = pcall(fn, k)

			if ok and per_second and duration then
				state.windows = state.windows or {}
				state.windows[name] = { end_t = state.t + duration, per_second = per_second, reason = reason }
			end
		end
	end
end

local function _windows_rate(unit, max_toughness, stat_buffs, parts)
	local total = 0

	for name, w in pairs(state.windows or {}) do
		if state.t > w.end_t then
			state.windows[name] = nil
		elseif not _regen_disabled(unit, w.reason) then
			local rate = max_toughness * w.per_second * _replenish_mult(stat_buffs)

			total = total + rate
			parts[name] = (parts[name] or 0) + rate
		end
	end

	return total
end

mod:hook_safe("PlayerUnitBuffExtension", "add_proc_event", function (self, event, params)
	local me = state.unit

	if not me or state.host or self._unit ~= me or type(params) ~= "table" then
		return
	end

	if event == "on_sweep_finish" then
		-- toughness_recovery_on_chained_attacks: counter + 1 while the sweep hit something on
		-- a combo, else reset to 1; recovers when counter > 1
		_each_trait(me, function (instance, template, kind)
			if kind == "chained" then
				local active = _num(params.num_hit_units, 0) > 0 and _num(params.combo_count, 0) > 0
				local counter = active and (state.chain[instance] or 0) + 1 or 1

				state.chain[instance] = counter

				if counter > 1 then
					_instant(me, template.name, _trait_pct(instance, template), "blessing", true)
				end
			end
		end)
	elseif event == "on_ammo_consumed" then
		-- toughness_on_continuous_fire: each new fire step gives fixed * min(steps, 5)
		_each_trait(me, function (instance, template, kind)
			if kind == "continuous_fire" then
				local steps = _fire_steps(me, instance, template)
				local last = state.fire[instance] or 0

				state.fire[instance] = steps

				if last < steps then
					_instant(me, template.name, _trait_pct(instance, template) * math.min(steps, 5), "blessing", true)
				end
			end
		end)
	end

	local mirrors = EVENT_MIRRORS[event]

	if not mirrors then
		return
	end

	for name, fn in pairs(mirrors) do
		local active = _source_active(me, name)

		if active then
			local ok, percentage, reason, ignore = pcall(fn, params)

			if ok and percentage then
				_instant(me, name, percentage, reason, ignore)
			end
		end
	end
end)

-- ---------------------------------------------------------------------------
-- Attack reports (server -> every client): kills by me, melee hits on me
-- ---------------------------------------------------------------------------

mod:hook_safe("AttackReportManager", "add_attack_result", function (self, damage_profile, attacked_unit, attacking_unit, attack_direction, hit_world_position, hit_weakspot, damage, attack_result, attack_type)
	local me = state.unit

	if not me or state.host then
		return
	end

	if attacked_unit == me and attack_type == "melee" then
		-- veteran_toughness_regen_out_of_melee: proc on_player_hit_received + on_melee_hit
		state.last_melee_hit_t = state.t
	end

	-- skitarii cryptic_discharge_toughness (server_only_proc_buff): each discharge explosion
	-- hit on a target that survives -> toughness_percent_per_hit
	if attacking_unit == me and attack_result ~= "died" and damage_profile and damage_profile.name == "cryptic_discharge_explosion" then
		if _has_source(me, "cryptic_discharge_toughness") then
			_instant(me, "cryptic_discharge_toughness", _ts("cryptic.discharge_ability.cryptic_discharge_toughness.toughness_percent_per_hit"), "ability_shout")
		end
	end

	if attacking_unit ~= me or attack_result ~= "died" or not attacked_unit then
		return
	end

	local side_system = Managers.state.extension and Managers.state.extension:system("side_system")
	local ok, is_enemy = pcall(function ()
		return side_system:is_enemy(me, attacked_unit)
	end)

	if not ok or not is_enemy then
		return
	end

	-- attack.lua: melee kill by a player on an enemy -> Toughness.replenish(attacker, melee_kill)
	if attack_type == "melee" and not _regen_disabled(me, nil) then
		_impulse(replenish_types.melee_kill, _wanted_for_type(me, replenish_types.melee_kill))
	end

	local ok_kill, err = pcall(_on_kill_report, me, attacked_unit, damage_profile, hit_world_position, hit_weakspot, attack_type)

	if not ok_kill then
		mod:info("kill mirror: %s", tostring(err))
	end
end)

-- ---------------------------------------------------------------------------
-- Client mirrors of server-only talent buffs (values read from TalentSettings)
-- ---------------------------------------------------------------------------


local function _shooting(unit_data_extension, t)
	local shooting_status = unit_data_extension:read_component("shooting_status")

	return shooting_status and (shooting_status.shooting or t <= _num(shooting_status.shooting_end_time, -math.huge) + 0.5)
end

local MIRRORS = {
	-- veteran_buff_templates.lua: veteran_toughness_on_elite_kill (server_only_proc_buff) adds the
	-- effect and replenishes instant_toughness; each effect instance replenishes toughness * dt.
	veteran_toughness_on_elite_kill_effect = {
		reason = "talent_toughness_1",
		instant = function () return _ts("veteran_2.toughness_1.instant_toughness") end,
		per_second = function () return _ts("veteran_2.toughness_1.toughness") end,
	},
	-- adamant_buff_templates.lua: adamant_toughness_on_elite_kill -> _effect, same pattern
	adamant_toughness_on_elite_kill_effect = {
		reason = nil,
		instant = function () return _ts("adamant.elite_special_kills_replenish_toughness.instant_toughness") end,
		per_second = function () return _ts("adamant.elite_special_kills_replenish_toughness.toughness") end,
	},
	-- veteran_buff_templates.lua: active when t > last melee hit received + cooldown (5 s)
	veteran_toughness_regen_out_of_melee = {
		reason = "talent_toughness_3",
		per_second = function (unit, unit_data_extension, t)
			if t > state.last_melee_hit_t + _ts("veteran_2.toughness_3.cooldown") then
				return _ts("veteran_2.toughness_3.toughness")
			end

			return 0
		end,
	},
	-- zealot_buff_templates.lua: server replenishes while is_shooting (wielded or not)
	zealot_toughness_while_shooting = {
		reason = nil,
		per_second = function (unit, unit_data_extension, t)
			return _shooting(unit_data_extension, t) and _ts("zealot.zealot_toughness_while_shooting.toughness") or 0
		end,
	},
	-- ogryn_buff_templates.lua: server replenishes while braced or shooting
	ogryn_regen_toughness_on_braced = {
		reason = nil,
		per_second = function (unit, unit_data_extension, t)
			local alternate_fire = unit_data_extension:read_component("alternate_fire")
			local braced = alternate_fire and alternate_fire.is_active

			return (braced or _shooting(unit_data_extension, t)) and _ts("ogryn_1.defensive_3.braced_toughness_regen") or 0
		end,
	},
	-- cryptic_buff_templates.lua (0.3.0): server replenishes per second per stack while the stack buff is on you
	cryptic_ranged_stacking_toughness_stack = {
		reason = "cryptic_talent",
		per_second = function (unit, unit_data_extension, t, instance, template)
			return _num(template and template.toughness_regen_per_second_per_stack, 0)
		end,
	},
	-- server replenishes (base + per remaining combat ability charge) per second
	cryptic_toughness_per_charge = {
		reason = "cryptic_talent",
		per_second = function (unit, unit_data_extension, t, instance, template)
			local ability_extension = ScriptUnit.has_extension(unit, "ability_system")
			local charges = 0

			if ability_extension and ability_extension.remaining_ability_charges then
				local ok, value = pcall(ability_extension.remaining_ability_charges, ability_extension, "combat_ability")

				charges = ok and _num(value, 0) or 0
			end

			return _num(template and template.toughness_regen_per_second, 0) + _num(template and template.increased_toughness_regen_per_charge, 0) * charges
		end,
	},
	-- overload keystone trigger gives this buff to everyone in coherency; with the
	-- "explosion restores toughness and stamina" talent the server also replenishes
	-- toughness_percent_restored (counted on a new or refreshed buff, your talent only)
	cryptic_overload_keystone_allies_buff = {
		reason = "cryptic_talent",
		rule = "cryptic_overload_keystone_explosion_restores_toughness_and_stamina",
		refresh = true,
		instant = function () return _ts("cryptic.overload.toughness_percent_restored") end,
		per_second = function () return 0 end,
	},
}

-- proc buffs whose server update_func replenishes toughness_regen_per_second while the
-- proc is active. The server sends the proc time to the owner
-- (rpc_buff_batched_proc_set_active_time, proc_buff.lua: active_duration > 0), so
-- buff:is_proc_active() on the client is the server's own window. Exact.
local PROC_WINDOWS = {
	cryptic_multi_hits_restore_toughness = true,
	cryptic_elite_kills_toughness = true,
	cryptic_electrocution_toughness = true,
	cryptic_redline_toughness = true,
	cryptic_crits_grant_tdr = true,
	cryptic_toughness_on_damage_taken = true,
}

-- instant proc buffs with a cooldown or active time: the same rpc tells the client the
-- server procced them
mod:hook_safe("PlayerUnitBuffExtension", "_set_proc_active_start_time", function (self, index, activation_time)
	local me = state.unit

	if not me or state.host or self._unit ~= me or self._is_server then
		return
	end

	local instance = self._buffs_by_index and self._buffs_by_index[index]

	if not instance then
		return
	end

	local ok, template = pcall(instance.template, instance)

	if not ok or not template then
		return
	end

	local kind = _trait_kind(template)

	if kind == "close_kill" then
		-- toughness_recovery_on_close_kill: active_duration 2
		_instant(me, template.name, _trait_pct(instance, template), "blessing", true)
	elseif kind == "multi_hit" then
		-- toughness_recovery_on_multiple_hits: cooldown 0.12, third target of one swing
		_instant(me, template.name, _multi_pct(instance, template), "blessing", false)
	elseif template.name == "cryptic_ally_coherency_defenses_toughness" then
		_instant(me, template.name, _ts("cryptic.cryptic_ally_coherency_defenses.toughness_percent_to_regen"), "cryptic_talent")
	end
end)

local function _mirrored_rate(unit, max_toughness, stat_buffs, buff_extension, t, parts)
	local unit_data_extension = ScriptUnit.has_extension(unit, "unit_data_system")
	local buffs = buff_extension and buff_extension:buffs()

	if not buffs or not unit_data_extension then
		return 0
	end

	local mult = _replenish_mult(stat_buffs)
	local total = 0

	for i = 1, #buffs do
		local instance = buffs[i]
		local ok, template = pcall(instance.template, instance)
		local name = ok and template and template.name
		local mirror = name and MIRRORS[name]

		if mirror and (not mirror.rule or _has_rule(unit, mirror.rule)) then
			local stacks = 1

			if instance.stack_count then
				local ok_stacks, count = pcall(instance.stack_count, instance)

				stacks = ok_stacks and _num(count, 1) or 1
			end

			local disabled = _regen_disabled(unit, mirror.reason)

			if mirror.instant then
				-- refresh mirrors key on the buff's start time (a refresh re-syncs it)
				local mark = true

				if mirror.refresh and instance.start_time then
					local ok_start, start = pcall(instance.start_time, instance)

					mark = ok_start and start or true
				end

				if state.seen[instance] ~= mark then
					state.seen[instance] = mark

					if not disabled and state.primed then
						_impulse(name, max_toughness * mirror.instant() * mult)
					end
				end
			end

			if not disabled then
				local rate = max_toughness * mirror.per_second(unit, unit_data_extension, t, instance, template) * mult * stacks

				if rate > 0 then
					total = total + rate
					parts[name] = (parts[name] or 0) + rate
				end
			end
		elseif name and PROC_WINDOWS[name] and instance.is_proc_active then
			-- server proc window (see PROC_WINDOWS); rate replenish_percentage(per_second * dt, false)
			local ok_active, active = pcall(instance.is_proc_active, instance, t)

			if ok_active and active and not _regen_disabled(unit, "cryptic_talent") then
				local rate = max_toughness * _num(template.toughness_regen_per_second, 0) * mult

				if rate > 0 then
					total = total + rate
					parts[name] = (parts[name] or 0) + rate
				end
			end
		end
	end

	return total
end

-- ---------------------------------------------------------------------------
-- Passive regen: PlayerUnitToughnessExtension._update_toughness, without the
-- "toughness_damage > 0" condition (theoretical: counted at full toughness too)
-- ---------------------------------------------------------------------------

local function _passive(unit, toughness_extension, stat_buffs, buff_extension, t, max_toughness)
	if _regen_disabled(unit, nil) then
		return 0, 0
	end

	local template = toughness_extension:toughness_templates()
	local coherency_rate_modifier = _num(stat_buffs.toughness_coherency_regen_rate_modifier, 0)
	local min_modifier = math.max(_num(stat_buffs.min_toughness_coherency_regen_rate_modifier, 1) - 1, 0)
	local at_all_times = coherency_rate_modifier > 0 and min_modifier > 0
	local out_of_combat, delay_over

	if state.host then
		local slot_extension = ScriptUnit.has_extension(unit, "slot_system")

		out_of_combat = slot_extension and slot_extension.num_occupied_slots == 0 or false
		delay_over = _num(toughness_extension._toughness_regen_delay, -math.huge) < t
	else
		out_of_combat = settings.client_coherency
		delay_over = state.client_delay_end < t
	end

	local coherency = 0

	if template and template.regeneration_speed and (out_of_combat or at_all_times) and delay_over then
		local unit_data_extension = ScriptUnit.has_extension(unit, "unit_data_system")
		local locomotion = unit_data_extension and unit_data_extension:read_component("locomotion")
		local standing_still = locomotion and Vector3.length_squared(locomotion.velocity_current) < STANDING_STILL_EPSILON

		-- the game reads .moving when standing still and .still when moving; kept as is
		local base_rate = standing_still and template.regeneration_speed.moving or template.regeneration_speed.still
		local weapon_template = _weapon_toughness_template(unit)
		local speed = weapon_template and weapon_template.regeneration_speed_modifier
		local weapon_rate_modifier = speed and _num(standing_still and speed.moving or speed.still, 1) or 1
		local buff_rate_modifier = _num(stat_buffs.toughness_regen_rate_modifier, 1) * _num(stat_buffs.toughness_regen_rate_multiplier, 1)

		if not out_of_combat and at_all_times then
			coherency_rate_modifier = coherency_rate_modifier * min_modifier
		end

		coherency_rate_modifier = coherency_rate_modifier + _num(stat_buffs.toughness_extra_regen_rate, 0)
		coherency_rate_modifier = coherency_rate_modifier * _num(stat_buffs.toughness_coherency_regen_rate_multiplier, 1)
		coherency = _num(base_rate, 0) * weapon_rate_modifier * buff_rate_modifier * coherency_rate_modifier
	end

	local percent = _num(stat_buffs.toughness_regen_percent, 0) * max_toughness

	if buff_extension:has_keyword(buff_keywords.prevent_toughness_regen_when_depleted) and toughness_extension:current_toughness_percent() <= 0 then
		return 0, 0
	end

	return math.max(coherency, 0), math.max(percent, 0)
end

-- ---------------------------------------------------------------------------
-- Per-frame model
-- ---------------------------------------------------------------------------

local function _decay(value, factor)
	return value * factor
end

local function _update_model(dt, t)
	local unit = _local_player_unit()

	if unit ~= state.unit then
		_reset(unit)
	end

	if not unit then
		return false
	end

	local toughness_extension = ScriptUnit.has_extension(unit, "toughness_system")
	local stat_buffs, buff_extension = _stat_buffs(unit)

	if not toughness_extension or not stat_buffs or not toughness_extension.toughness_damage then
		return false
	end

	state.t = t
	state.host = toughness_extension.add_damage ~= nil -- PlayerUnitToughnessExtension (server side)

	local max_toughness = _num(toughness_extension:max_toughness(), 0)
	local damage = _num(toughness_extension:toughness_damage(), 0)
	local factor = math.exp(-dt / settings.tau)

	state.loss_rate = _decay(state.loss_rate, factor)
	state.obs_regen = _decay(state.obs_regen, factor)

	for key, value in pairs(state.events) do
		local v = value * factor

		state.events[key] = v > 0.01 and v or nil
	end

	-- observed change of the networked toughness_damage
	if state.last_damage and state.last_max == max_toughness then
		local delta = damage - state.last_damage

		if delta > 0 then
			state.loss_rate = state.loss_rate + delta / settings.tau

			-- PlayerUnitToughnessExtension.add_damage: regen delay
			local template = toughness_extension:toughness_templates()
			local weapon_template = _weapon_toughness_template(unit)
			local weapon_modifier = weapon_template and _num(weapon_template.regeneration_delay_modifier, 1) or 1
			local buff_modifier = _num(stat_buffs.toughness_regen_delay_modifier, 1) * _num(stat_buffs.toughness_regen_delay_multiplier, 1)

			state.client_delay_end = t + _num(template and template.regeneration_delay, 3) * weapon_modifier * buff_modifier
		elseif delta < 0 then
			state.obs_regen = state.obs_regen + -delta / settings.tau
		end
	end

	state.last_damage, state.last_max = damage, max_toughness

	local parts = state.parts

	table.clear(parts)

	local coherency, percent = _passive(unit, toughness_extension, stat_buffs, buff_extension, t, max_toughness)
	local total = coherency + percent

	if coherency > 0 then
		parts.coherency = coherency
	end

	if percent > 0 then
		parts.toughness_regen_percent = percent
	end

	if not state.host then
		total = total + _mirrored_rate(unit, max_toughness, stat_buffs, buff_extension, t, parts)
		total = total + _windows_rate(unit, max_toughness, stat_buffs, parts)
	end

	state.primed = true

	for key, value in pairs(state.events) do
		total = total + value
		parts[key] = (parts[key] or 0) + value
	end

	state.theo_model = total
	state.theo = math.max(total, state.obs_regen)

	if settings.net_mode == "actual" then
		state.net = state.obs_regen - state.loss_rate
	else
		state.net = state.theo - state.loss_rate
	end

	state.max = max_toughness
	state.scale = settings.scale_mode == "fixed" and settings.scale_fixed_value or math.max(max_toughness * settings.scale_percent_value / 100, 1)

	return true
end

local model_ok = false

mod.update = function (dt)
	if not mod:is_enabled() then
		model_ok = false

		return
	end

	local t = _gameplay_time()
	local game_mode_manager = Managers.state and Managers.state.game_mode
	local ok_mode, mode_name = pcall(function ()
		return game_mode_manager and game_mode_manager:game_mode_name()
	end)

	if not t or not game_mode_manager or (ok_mode and mode_name == "hub") then
		model_ok = false

		return
	end

	local ok, result = pcall(_update_model, dt, t)

	if not ok then
		mod:info("model: %s", tostring(result))
	end

	model_ok = ok and result or false
end

-- ---------------------------------------------------------------------------
-- Drawing (HUD gui, as QIangIQsEnemyBeams: HudElementCrosshair.update)
-- ---------------------------------------------------------------------------

local rect_count = 0

local function _rect(gui, x, y, w, h, color)
	if rect_count >= MAX_RECTS then
		return
	end

	rect_count = rect_count + 1

	Gui.rect(gui, Vector3(x, y, LAYER), Vector2(w, h), color)
end

local function _rect_layer(gui, x, y, w, h, color, layer)
	if rect_count >= MAX_RECTS then
		return
	end

	rect_count = rect_count + 1

	Gui.rect(gui, Vector3(x, y, layer), Vector2(w, h), color)
end

-- angle 0 = straight up, -pi/2 = left end, +pi/2 = right end
local function _point(cx, cy, radius, angle)
	return cx + radius * math.sin(angle), cy - radius * math.cos(angle)
end

local function _arc(gui, cx, cy, radius, a1, a2, thickness, color, layer)
	if a2 < a1 then
		a1, a2 = a2, a1
	end

	local length = (a2 - a1) * radius
	local steps = math.max(1, math.ceil(length / math.max(thickness * 0.5, 1)))
	local half = thickness / 2

	for i = 0, steps do
		local x, y = _point(cx, cy, radius, a1 + (a2 - a1) * i / steps)

		_rect_layer(gui, x - half, y - half, thickness, thickness, color, layer)
	end
end

local function _line(gui, x1, y1, x2, y2, thickness, color, layer)
	local dx, dy = x2 - x1, y2 - y1
	local length = math.sqrt(dx * dx + dy * dy)
	local steps = math.max(1, math.ceil(length / math.max(thickness * 0.5, 1)))
	local half = thickness / 2

	for i = 0, steps do
		local f = i / steps

		_rect_layer(gui, x1 + dx * f - half, y1 + dy * f - half, thickness, thickness, color, layer)
	end
end

local function _angle(value, scale)
	local f = math.clamp(value / scale, -1, 1)

	return f * math.pi / 2
end

local function _text(gui, text, x, y, size, color, align)
	local ok_extents, min, max = pcall(Gui.slug_text_extents, gui, text, FONT, size)
	local width = ok_extents and min and max and (max.x - min.x) or 0
	local left = align == "center" and x - width / 2 or align == "right" and x - width or x

	pcall(Gui.slug_text, gui, text, FONT, size, Vector3(left, y, LAYER + 5), nil, color, "shadow", Color(200, 0, 0, 0))
end

local COLOR_TRACK = Color(150, 20, 20, 20)
local COLOR_TICK = Color(200, 200, 200, 200)
local COLOR_REGEN = Color(255, 80, 220, 110)
local COLOR_REGEN_FILL = Color(150, 80, 220, 110)
local COLOR_LOSS = Color(255, 235, 70, 60)
local COLOR_LOSS_FILL = Color(150, 235, 70, 60)
local COLOR_NET = Color(255, 245, 245, 245)
local COLOR_TEXT = Color(255, 230, 230, 230)

local function _fmt(value)
	return string.format("%.1f", value)
end

-- English names from the game's own localization: talents through ArchetypeTalents
-- (talent name or passive.buff_template_name -> display_name), blessings through the
-- trait master items (item.trait == buff template name -> display_name).
local LABELS = {}
local talent_names

local function _talent_names()
	if talent_names then
		return talent_names
	end

	talent_names = {}

	pcall(function ()
		local ArchetypeTalents = require("scripts/settings/ability/archetype_talents/archetype_talents")

		for _, talents in pairs(ArchetypeTalents) do
			if type(talents) == "table" then
				for talent_name, talent in pairs(talents) do
					if type(talent) == "table" and talent.display_name then
						talent_names[talent_name] = talent_names[talent_name] or talent.display_name

						local passive = talent.passive
						local buff_name = passive and passive.buff_template_name

						if type(buff_name) == "string" then
							talent_names[buff_name] = talent_names[buff_name] or talent.display_name
						end
					end
				end
			end
		end
	end)

	return talent_names
end

local function _blessing_display_name(key)
	if not string.find(key, "^weapon_trait_") then
		return nil
	end

	local MasterItems = require("scripts/backend/master_items")
	local items = MasterItems.get_cached()

	for _, item in pairs(items or {}) do
		if type(item) == "table" and item.trait == key and item.display_name and item.display_name ~= "" then
			return item.display_name
		end
	end

	return nil
end

local function _label(key)
	local cached = LABELS[key]

	if cached then
		return cached
	end

	local label = key
	local ok, result = pcall(function ()
		local loc_key = _talent_names()[key] or _blessing_display_name(key)

		if loc_key and Localize then
			local text = Localize(loc_key)

			if type(text) == "string" and text ~= "" and not string.find(text, "^<") then
				return text
			end
		end
	end)

	if ok and result then
		label = result
	end

	LABELS[key] = label

	return label
end

local function _draw(gui)
	local width = RESOLUTION_LOOKUP and RESOLUTION_LOOKUP.width
	local height = RESOLUTION_LOOKUP and RESOLUTION_LOOKUP.height

	if not width or not height then
		width, height = Gui.resolution()
	end

	local s = height / 1080
	local cx, cy = width * settings.pos_x, height * settings.pos_y
	local radius = settings.size * s
	local band = math.max(6 * s, 2)
	local scale = state.scale
	local pi2 = math.pi / 2

	rect_count = 0

	-- track and ticks
	_arc(gui, cx, cy, radius, -pi2, pi2, band, COLOR_TRACK, LAYER)

	for i = -2, 2 do
		local a = i * pi2 / 2
		local x1, y1 = _point(cx, cy, radius + band, a)
		local x2, y2 = _point(cx, cy, radius + band + (i == 0 and 10 or 6) * s, a)

		_line(gui, x1, y1, x2, y2, math.max(2 * s, 1), COLOR_TICK, LAYER + 1)
	end

	local a_regen = _angle(state.theo, scale)
	local a_loss = _angle(-state.loss_rate, scale)
	local a_net = _angle(state.net, scale)

	if settings.show_fills then
		if a_regen > 0.005 then
			_arc(gui, cx, cy, radius, 0, a_regen, band, COLOR_REGEN_FILL, LAYER + 1)
		end

		if a_loss < -0.005 then
			_arc(gui, cx, cy, radius, a_loss, 0, band, COLOR_LOSS_FILL, LAYER + 1)
		end
	end

	-- needles
	local needle_thin = math.max(3 * s, 1.5)
	local needle_thick = math.max(5 * s, 2)
	local xr, yr = _point(cx, cy, radius * 0.95, a_regen)
	local xl, yl = _point(cx, cy, radius * 0.95, a_loss)
	local xn, yn = _point(cx, cy, radius * 0.8, a_net)

	_line(gui, cx, cy, xr, yr, needle_thin, COLOR_REGEN, LAYER + 2)
	_line(gui, cx, cy, xl, yl, needle_thin, COLOR_LOSS, LAYER + 2)
	_line(gui, cx, cy, xn, yn, needle_thick, COLOR_NET, LAYER + 3)

	local hub = 10 * s

	_rect_layer(gui, cx - hub / 2, cy - hub / 2, hub, hub, COLOR_NET, LAYER + 4)

	if settings.show_text then
		local size_small = 14 * s
		local size_big = 20 * s
		local y = cy + 8 * s + size_big
		local net_text = string.format("net %s%s TN/s", state.net >= 0 and "+" or "", _fmt(state.net))

		_text(gui, net_text, cx, y, size_big, COLOR_NET, "center")

		y = y + size_small * 1.4

		_text(gui, "regen +" .. _fmt(state.theo), cx - 8 * s, y, size_small, COLOR_REGEN, "right")
		_text(gui, "loss -" .. _fmt(state.loss_rate), cx + 8 * s, y, size_small, COLOR_LOSS, "left")

		local lx, ly = _point(cx, cy, radius + band + 8 * s, -pi2)
		local rx, ry = _point(cx, cy, radius + band + 8 * s, pi2)

		_text(gui, "-" .. _fmt(scale), lx, ly + size_small, size_small, COLOR_TICK, "right")
		_text(gui, "+" .. _fmt(scale), rx, ry + size_small, size_small, COLOR_TICK, "left")

		if settings.show_breakdown then
			local keys = {}

			for key in pairs(state.parts) do
				keys[#keys + 1] = key
			end

			table.sort(keys, function (a, b)
				return state.parts[a] > state.parts[b]
			end)

			for i = 1, math.min(#keys, 8) do
				y = y + size_small * 1.3

				_text(gui, string.format("%s  %s", _label(keys[i]), _fmt(state.parts[keys[i]])), cx, y, size_small, COLOR_TEXT, "center")
			end

			if state.obs_regen > state.theo_model + 0.05 then
				y = y + size_small * 1.3

				_text(gui, "observed (unmodelled) " .. _fmt(state.obs_regen), cx, y, size_small, COLOR_TEXT, "center")
			end
		end
	end
end

mod:hook_safe("HudElementCrosshair", "update", function (self, dt, t, ui_renderer)
	if not view_on or not model_ok or not mod:is_enabled() or not ui_renderer or not ui_renderer.gui then
		return
	end

	local ok, err = pcall(_draw, ui_renderer.gui)

	if not ok then
		mod:info("draw: %s", tostring(err))
	end
end)

-- ---------------------------------------------------------------------------
-- Lifecycle and commands
-- ---------------------------------------------------------------------------

mod.on_game_state_changed = function (status, state_name)
	_reset(nil)
end

mod:command("tgauge_info", "Toughness Gauge: print the current regen sources, loss and net.", function ()
	mod:echo(string.format("%s | max %d | scale %s TN/s | regen %s (model %s, observed %s) | loss %s | net %s",
		state.host and "host (exact)" or "client (rebuilt)", state.max or 0, _fmt(state.scale or 0),
		_fmt(state.theo or 0), _fmt(state.theo_model or 0), _fmt(state.obs_regen or 0), _fmt(state.loss_rate or 0), _fmt(state.net or 0)))

	for key, value in pairs(state.parts or {}) do
		mod:echo(string.format("  %s (%s): %s TN/s", _label(key), key, _fmt(value)))
	end
end)
