local mod = get_mod("QIangIQsToughnessGauge")

local function checkbox(id, default)
	return { setting_id = id, type = "checkbox", default_value = default, tooltip = id .. "_tooltip" }
end

local function numeric(id, default, low, high)
	return { setting_id = id, type = "numeric", default_value = default, range = { low, high }, tooltip = id .. "_tooltip" }
end

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			{
				setting_id = "toggle_key",
				type = "keybind",
				default_value = {},
				keybind_trigger = "pressed",
				keybind_type = "function_call",
				function_name = "toggle_view",
				tooltip = "toggle_key_tooltip",
			},
			{
				setting_id = "scale_mode",
				type = "dropdown",
				default_value = "percent",
				tooltip = "scale_mode_tooltip",
				options = {
					{ text = "scale_percent", value = "percent" },
					{ text = "scale_fixed", value = "fixed" },
				},
			},
			numeric("scale_percent_value", 15, 2, 100),
			numeric("scale_fixed_value", 30, 2, 300),
			numeric("smoothing", 15, 2, 60),
			{
				setting_id = "net_mode",
				type = "dropdown",
				default_value = "theoretical",
				tooltip = "net_mode_tooltip",
				options = {
					{ text = "net_theoretical", value = "theoretical" },
					{ text = "net_actual", value = "actual" },
				},
			},
			checkbox("client_coherency", false),
			checkbox("show_fills", true),
			checkbox("show_text", true),
			checkbox("show_breakdown", false),
			numeric("pos_x", 50, 0, 100),
			numeric("pos_y", 78, 0, 100),
			numeric("size", 110, 40, 400),
		},
	},
}
