-- No percent signs in any string here: DMF passes localize text through string.format.
return {
	mod_name = { en = "QIangIQs Toughness Gauge" },
	mod_description = { en = "Speedometer-style half dial for toughness, in TN per second. Middle (top) is 0, right is gain, left is loss. Three needles: green = theoretical toughness regeneration (every source active right now, counted even when your toughness is full), red = toughness being lost, white = net. Numbers follow the game's own toughness code. Exact when you host (solo); on Fatshark servers the client rebuilds the server-side sources it can see (coherency, melee kills, Confirmed Kill and other over-time talents, instant talent replenishes on kills, weakspot kills, heavy hits, dodges, venting, perfect blocks and stance shots, bracing and shooting talents, weapon blessings such as Confident Strike, and the Skitarii toughness talents) and never shows less than the regeneration it actually observes. The breakdown uses the game's own talent and blessing names. /tgauge_info prints it." },

	toggle_key = { en = "Toggle key" },
	toggle_key_tooltip = { en = "Show or hide the dial without opening the mod menu." },

	scale_mode = { en = "Dial full scale" },
	scale_mode_tooltip = { en = "What the ends of the dial stand for." },
	scale_percent = { en = "Share of max toughness per second" },
	scale_fixed = { en = "Fixed TN per second" },
	scale_percent_value = { en = "Full scale (share of max toughness, per second)" },
	scale_percent_value_tooltip = { en = "With the share mode, each end of the dial is this many hundredths of your max toughness per second. 15 on a 120 toughness Veteran = 18 TN/s." },
	scale_fixed_value = { en = "Full scale (TN/s)" },
	scale_fixed_value_tooltip = { en = "With the fixed mode, each end of the dial is this many TN per second." },

	smoothing = { en = "Smoothing (tenths of a second)" },
	smoothing_tooltip = { en = "Instant gains and losses (a kill that restores 10 percent, a hit) are spread over this time so they read as TN per second. Over-time sources (coherency, Confirmed Kill's per-second part) are shown at their exact rate. 15 = 1.5 s." },

	net_mode = { en = "Net needle" },
	net_mode_tooltip = { en = "Theoretical: green needle minus red needle. Actual: the change in toughness you really get (regeneration you observe minus loss)." },
	net_theoretical = { en = "Theoretical regen minus loss" },
	net_actual = { en = "Actual change" },

	client_coherency = { en = "Client: count coherency in combat" },
	client_coherency_tooltip = { en = "Coherency regeneration only runs out of combat (no enemy holding a slot on you), unless a talent allows it at all times. The host knows this; a client on a Fatshark server does not. Off: a client counts coherency only when it can run at all times, or when it is observed. On: a client always counts it." },

	show_fills = { en = "Colour bands" },
	show_fills_tooltip = { en = "Fill the dial from 0 to the regen needle (green) and from 0 to the loss needle (red)." },
	show_text = { en = "Numbers" },
	show_text_tooltip = { en = "Regen, loss and net in TN/s under the dial." },
	show_breakdown = { en = "Breakdown" },
	show_breakdown_tooltip = { en = "List each regeneration source and its TN/s under the dial." },

	pos_x = { en = "Position across (share of screen width)" },
	pos_x_tooltip = { en = "Centre of the dial, 0 = left edge, 100 = right edge." },
	pos_y = { en = "Position down (share of screen height)" },
	pos_y_tooltip = { en = "Centre of the dial, 0 = top edge, 100 = bottom edge." },
	size = { en = "Radius (pixels at 1080p)" },
	size_tooltip = { en = "Radius of the half dial." },
}
