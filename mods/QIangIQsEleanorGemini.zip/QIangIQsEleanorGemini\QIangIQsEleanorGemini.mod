return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsEleanorGemini` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsEleanorGemini", {
            mod_script = "QIangIQsEleanorGemini/scripts/mods/QIangIQsEleanorGemini/QIangIQsEleanorGemini",
            mod_data = "QIangIQsEleanorGemini/scripts/mods/QIangIQsEleanorGemini/QIangIQsEleanorGemini_data",
            mod_localization = "QIangIQsEleanorGemini/scripts/mods/QIangIQsEleanorGemini/QIangIQsEleanorGemini_localization",
        })
    end,
    version = "1.0.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
