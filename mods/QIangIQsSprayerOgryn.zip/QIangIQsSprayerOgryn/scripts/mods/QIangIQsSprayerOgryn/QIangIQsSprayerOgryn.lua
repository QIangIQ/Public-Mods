-- QIangIQ's Sprayer Ogryn: a custom ranged boss built from the unreleased plague ogryn "sprayer" body (triple-barrel left arm).
-- Plague ogryn size and health, ranged like Rodin Karnak: cycles Beast of Nurgle vomit, flamer fire and tox gas out of the arm,
-- stomps and charges away when players get close, and detonates in a massive beeping explosion 10 s after death.
-- Standalone: retail assets only, no other mods required. Every client in the session needs this mod (the breed, effect templates
-- and explosion template are added to the network lookups); host-only logic otherwise. Spawn with /sprayer.
-- EXTENSIVE DEBUGGING: see QIangIQsSprayerOgryn_debug.log in %APPDATA%\Fatshark\Darktide\, /sprayer debug, /sprayer log.
local mod = get_mod("QIangIQsSprayerOgryn")

local Sog = {
    BREED = "qiangiqs_sprayer_ogryn",
    SRC_BREED = "chaos_plague_ogryn",
    EXPLOSION = "qiangiqs_sprayer_ogryn_death",
    counters = {},
    steps = {},
    force = nil,
}
mod.sog = Sog

local DEFAULTS = {
    health_multiplier = 1,
    explosion_delay = 10,
    explosion_power = 4,
    retreat_distance = 12,
    attack_cooldown = 2.5,
    spawn_distance = 24,
    beam_range = 22,
    retreat_speed = 9,
    game_object_type = "auto",
    verbose = false,
    snapshots = true,
    notify_errors = true,
}

Sog.setting = function(id)
    local ok, v = pcall(mod.get, mod, id)
    if ok and v ~= nil then
        return v
    end
    return DEFAULTS[id]
end

local function build_cfg()
    local s = Sog.setting
    Sog.cfg = {
        health_multiplier = s("health_multiplier"),
        explosion_delay = s("explosion_delay"),
        explosion_power = s("explosion_power"),
        retreat_distance = s("retreat_distance"),
        attack_cooldown = s("attack_cooldown"),
        spawn_distance = s("spawn_distance"),
        snapshots = s("snapshots") ~= false,
        retreat_cooldown = 2.5,
        stomp_range = 4,
        mine_cooldown = 7,
        mine_min_dist = 6,
        mine_max_dist = 26,
        mine_duration = 1.4,
        mine_flight = 1.4,
        mine_scatter = 2.5,
        mine_power = 1,
        stomp_cooldown = 8,
        min_shoot = 2.5,
        max_shoot = s("beam_range") or 22,
        gas_pools_per_attack = 3,
        gas_interval = 1.1,
    }
end
build_cfg()

-- ------------------------------------------------------------------------------------------------ logging
local function load_sub(name)
    local ok, res = pcall(mod.io_dofile, mod, "QIangIQsSprayerOgryn/scripts/mods/QIangIQsSprayerOgryn/" .. name)
    if not ok then
        mod:error("[SOG] %s failed to load: %s", name, tostring(res))
        return nil
    end
    return res
end

local Log = load_sub("sog_log")
if type(Log) ~= "table" then
    -- minimal stand-in so the rest still reports something
    local function out(level)
        return function(cat, f, ...)
            local ok, s = pcall(string.format, f, ...)
            mod:echo("[SOG][%s][%s] %s", level, cat, ok and s or tostring(f))
        end
    end
    Log = { i = out("I"), w = out("W"), e = out("E"), d = out("D"), every = function(_, _, _, cat, f, ...) mod:echo("[SOG] " .. tostring(f)) end,
        once = function() end, tail = function() return {} end, summary = function() return "log module missing" end, lines = {} }
    Log.guard = function(cat, label, fn, ...) return pcall(fn, ...) end
    Log.guard_quiet = Log.guard
end
Sog.Log = Log

Log.i("BOOT", "QIangIQsSprayerOgryn loading (breed %s)", Sog.BREED)

local function traceback(e)
    local dbg = rawget(_G, "debug")
    if dbg and dbg.traceback then
        return dbg.traceback(tostring(e), 2)
    end
    return tostring(e)
end

Sog.step = function(name, fn)
    local ok, err = xpcall(fn, traceback)
    Sog.steps[#Sog.steps + 1] = { name = name, ok = ok, err = (not ok) and tostring(err) or nil }
    if ok then
        Log.i("BOOT", "step ok: %s", name)
    else
        Log.e("BOOT", "step FAILED: %s -> %s", name, tostring(err))
    end
    return ok
end

Sog.ok = function()
    for _, s in ipairs(Sog.steps) do
        if not s.ok then
            return false
        end
    end
    return Sog.AI ~= nil and Sog.Boss ~= nil and Sog.C ~= nil and Sog.C.g ~= nil
end

Sog.failed_steps = function()
    local out = {}
    for _, s in ipairs(Sog.steps) do
        if not s.ok then
            out[#out + 1] = s.name
        end
    end
    if not Sog.AI then out[#out + 1] = "sog_ai module" end
    if not Sog.Boss then out[#out + 1] = "sog_boss module" end
    if not Sog.C then out[#out + 1] = "sog_content module" end
    return #out > 0 and table.concat(out, "; ") or "none"
end

-- ------------------------------------------------------------------------------------------------ modules
-- order matters: content registers the breed, ai registers the tree and conditions, boss owns spawn and death
Sog.step("load sog_content", function()
    local m = load_sub("sog_content")
    if type(m) ~= "table" then
        error("sog_content did not return a table")
    end
end)
Sog.step("load sog_ai", function()
    local m = load_sub("sog_ai")
    if type(m) ~= "table" then
        error("sog_ai did not return a table")
    end
end)
Sog.step("load sog_boss", function()
    local m = load_sub("sog_boss")
    if type(m) ~= "table" then
        error("sog_boss did not return a table")
    end
end)

if Sog.ok() then
    Log.i("BOOT", "READY: all steps ok. /sprayer to spawn, /sprayer debug for state")
else
    Log.e("BOOT", "NOT READY: %s", Sog.failed_steps())
end

-- ------------------------------------------------------------------------------------------------ localization
mod:add_global_localize_strings({
    loc_sog_boss_name = { en = "Sprayer Ogryn" },
})

-- ------------------------------------------------------------------------------------------------ commands
local function say(f, ...)
    local ok, s = pcall(string.format, f, ...)
    mod:echo("[Sprayer] " .. (ok and s or tostring(f)))
end

local function debug_report()
    local lines = {}
    local function add(f, ...) lines[#lines + 1] = string.format(f, ...) end
    add("ready=%s failed=%s", tostring(Sog.ok()), Sog.failed_steps())
    for _, s in ipairs(Sog.steps) do
        add("  step %-42s %s%s", s.name, s.ok and "ok" or "FAILED", s.err and (": " .. s.err:sub(1, 160):gsub("\n", " ")) or "")
    end
    local breed = Sog.C and Sog.C.breed
    if breed then
        add("breed %s game_object_type=%s tree=%s", breed.name, tostring(breed.game_object_type), tostring(breed.behavior_tree_name))
    end
    local counters = {}
    for k, v in pairs(Sog.counters) do counters[#counters + 1] = k .. "=" .. tostring(v) end
    table.sort(counters)
    add("counters: %s", #counters > 0 and table.concat(counters, " ") or "none")
    add("force=%s item_injected=%s item_ver=%s beep_event=%s", tostring(Sog.force), tostring(Sog.Boss and Sog.Boss.item_injected),
        tostring(Sog.Boss and Sog.Boss.item_ver), tostring(Sog.Boss and Sog.Boss.beep_event))
    if Sog.Boss then
        local n = 0
        for unit, info in pairs(Sog.Boss.tracked) do
            n = n + 1
            local s = Sog.AI.S(unit)
            add("boss %s alive=%s act=%s cycle=%d | %s", tostring(unit), tostring(Unit.alive(unit)), tostring(s.current), s.cycle, Sog.AI.explain(unit))
        end
        add("tracked bosses=%d pending explosions=%d package load running=%s", n, #Sog.Boss.pending, tostring(Sog.Boss.load_job ~= nil))
    end
    add("cfg: hp x%.2f explode %.0fs power x%.1f retreat<%.0fm atk cd %.1fs shoot %.1f-%.1fm", Sog.cfg.health_multiplier, Sog.cfg.explosion_delay,
        Sog.cfg.explosion_power, Sog.cfg.retreat_distance, Sog.cfg.attack_cooldown, Sog.cfg.min_shoot, Sog.cfg.max_shoot)
    add("log: %s", Log.summary())
    return lines
end

mod:command("sprayer", "Sprayer Ogryn: /sprayer [spawn N] | debug | log [N] | force vomit|flame|tox|mine|retreat|stomp|hold|off | boom | kill | item | pkg | reset", function(sub, a, b)
    sub = sub or "spawn"
    Log.i("CMD", "/sprayer %s %s %s", tostring(sub), tostring(a), tostring(b))
    local ok_all, err_all = pcall(function()
        if sub == "spawn" then
            local n = tonumber(a) or 1
            local ok, why = false, "boss module missing"
            if Sog.Boss then
                ok, why = Sog.Boss.spawn(n)
            end
            if ok then
                say("spawning %d (loading packages first if needed; watch the log)", n)
            else
                say("cannot spawn: %s", tostring(why or "boss module missing"))
            end
        elseif sub == "debug" or sub == "status" then
            for _, line in ipairs(debug_report()) do
                mod:echo(line)
                Log.i("DEBUG", "%s", line)
            end
        elseif sub == "log" then
            for _, line in ipairs(Log.tail(tonumber(a) or 25)) do
                mod:echo(line)
            end
        elseif sub == "force" then
            if a == nil or a == "off" or a == "auto" then
                Sog.force = nil
                say("force off: automatic cycle")
            else
                Sog.force = a
                say("forcing action %s (ignores range and cooldown; needs line of sight for beams)", a)
            end
            Log.i("CMD", "force = %s", tostring(Sog.force))
        elseif sub == "boom" then
            local pos
            local Boss = Sog.Boss
            local player = Managers.player and Managers.player:local_player_safe(1)
            local unit = player and player.player_unit
            if unit and Unit.alive(unit) then
                local fwd = Vector3.flat(Quaternion.forward(Unit.local_rotation(unit, 1)))
                pos = Unit.world_position(unit, 1) + Vector3.normalize(fwd) * 22
            end
            if pos then
                local t = Managers.time:time("gameplay")
                local delay = Sog.cfg.explosion_delay
                Boss.pending[#Boss.pending + 1] = { unit = false, pos = Vector3Box(pos), t0 = t, boom = t + delay, next_beep = t + 0.2, beeps = 0, delay = delay }
                say("test explosion 22 m ahead in %.0fs", delay)
            else
                say("no player unit")
            end
        elseif sub == "kill" then
            say("killed %d boss(es)", Sog.Boss and Sog.Boss.kill_all() or 0)
        elseif sub == "item" then
            local ok, why = Sog.Boss.ensure_item()
            say("item: %s", ok and "ok" or tostring(why))
        elseif sub == "pkg" then
            local pk, err = Sog.Boss.package_list()
            if not pk then
                say("package list failed: %s", tostring(err))
            else
                local pm, total, missing = Managers.package, 0, 0
                for name in pairs(pk) do
                    total = total + 1
                    if not pm:has_loaded(name) then
                        missing = missing + 1
                        Log.i("PKG", "not loaded: %s", name)
                    end
                end
                say("%d packages, %d not loaded (listed in the log)", total, missing)
            end
        elseif sub == "reset" then
            for unit, s in pairs(Sog.AI.state) do
                s.attack_ready, s.retreat_ready, s.stomp_ready = 0, 0, 0
            end
            say("cooldowns reset")
        else
            say("unknown subcommand %s", tostring(sub))
        end
    end)
    if not ok_all then
        Log.e("CMD", "command /sprayer %s threw: %s", tostring(sub), tostring(err_all))
        say("error: %s", tostring(err_all))
    end
end)

-- ------------------------------------------------------------------------------------------------ callbacks
local cfg_timer = 0
mod.update = function(dt)
    cfg_timer = cfg_timer - dt
    if cfg_timer <= 0 then
        cfg_timer = 1
        build_cfg()
    end
    if not Sog.ok() then
        return
    end
    local t = Managers.time and Managers.time:has_timer("gameplay") and Managers.time:time("gameplay")
    if not t then
        return
    end
    Log.guard_quiet("UPDATE", "Boss.update", Sog.Boss.update, dt)
    Log.guard_quiet("UPDATE", "AI.update", Sog.AI.update, dt, t)
end

mod.on_unload = function()
    Log.i("BOOT", "unloading; releasing packages")
    if Sog.Boss then
        pcall(Sog.Boss.unload)
    end
end

mod.on_game_state_changed = function(status, state_name)
    Log.d("STATE", "game state %s %s", tostring(status), tostring(state_name))
end

mod.on_all_mods_loaded = function()
    Log.i("BOOT", "all mods loaded; ready=%s", tostring(Sog.ok()))
end
