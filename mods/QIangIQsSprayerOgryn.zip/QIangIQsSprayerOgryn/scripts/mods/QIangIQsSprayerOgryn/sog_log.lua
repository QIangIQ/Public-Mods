-- QIangIQsSprayerOgryn debug log: console + file + in-memory ring buffer.
-- File: %APPDATA%\Fatshark\Darktide\QIangIQsSprayerOgryn_debug.log (flushed on every line, so a crash leaves the last breadcrumbs).
-- Levels: I info, W warning, E error, D debug (debug only when the "verbose" option is on; default on).
local mod = get_mod("QIangIQsSprayerOgryn")

local io_lib = (Mods and Mods.lua and Mods.lua.io) or rawget(_G, "io")
local os_lib = (Mods and Mods.lua and Mods.lua.os) or rawget(_G, "os")

local Log = {
    lines = {},
    max_lines = 1000,
    counts = {},            -- category -> number of lines
    levels = { I = 0, W = 0, E = 0, D = 0 },
    rate = {},              -- key -> { t = last, skipped = n }
    seen = {},
    path = nil,
    file_ok = false,
    last_error = nil,
    last_notify = 0,
}

local function now_clock()
    if os_lib and os_lib.clock then
        return os_lib.clock()
    end
    return 0
end

local function game_time()
    local ok, t = pcall(function()
        return Managers.time and Managers.time:has_timer("gameplay") and Managers.time:time("gameplay")
    end)
    if ok and type(t) == "number" then
        return t
    end
    return nil
end

local function fmt(f, ...)
    if select("#", ...) == 0 then
        return tostring(f)
    end
    local ok, s = pcall(string.format, f, ...)
    if ok then
        return s
    end
    local parts = { tostring(f) }
    for i = 1, select("#", ...) do
        parts[#parts + 1] = tostring((select(i, ...)))
    end
    return table.concat(parts, " | ")
end
Log.fmt = fmt

local function open_file()
    if not io_lib or not os_lib or not os_lib.getenv then
        return
    end
    local appdata = os_lib.getenv("APPDATA")
    if not appdata then
        return
    end
    Log.path = appdata .. "\\Fatshark\\Darktide\\QIangIQsSprayerOgryn_debug.log"
    local ok, f = pcall(io_lib.open, Log.path, "a")
    if ok and f then
        Log.file_ok = true
        pcall(function()
            f:write(string.format("\n===== session start %s =====\n", os_lib.date and os_lib.date("%Y-%m-%d %H:%M:%S") or "?"))
            f:close()
        end)
    end
end
open_file()

local function verbose()
    local ok, v = pcall(function() return mod:get("verbose") end)
    return not ok or v == nil or v == true
end

local function emit(level, cat, msg)
    if level == "D" and not verbose() then
        return
    end
    Log.levels[level] = (Log.levels[level] or 0) + 1
    Log.counts[cat] = (Log.counts[cat] or 0) + 1
    local t = game_time()
    local stamp = os_lib and os_lib.date and os_lib.date("%H:%M:%S") or "--:--:--"
    local line = string.format("[%s][%s][%s]%s %s", stamp, level, cat, t and string.format("[t=%.2f]", t) or "", msg)

    local lines = Log.lines
    lines[#lines + 1] = line
    if #lines > Log.max_lines then
        table.remove(lines, 1)
    end

    if Log.file_ok and io_lib then
        pcall(function()
            local f = io_lib.open(Log.path, "a")
            if f then
                f:write(line, "\n")
                f:close()
            end
        end)
    end

    local full = "[SOG]" .. line
    if level == "E" then
        Log.last_error = line
        pcall(mod.error, mod, "%s", full)
        if now_clock() - Log.last_notify > 3 then
            local ok, v = pcall(function() return mod:get("notify_errors") end)
            if not ok or v ~= false then
                Log.last_notify = now_clock()
                pcall(mod.notify, mod, "SprayerOgryn error: " .. cat .. " (see log)")
            end
        end
    elseif level == "W" then
        pcall(mod.warning, mod, "%s", full)
    else
        pcall(mod.info, mod, "%s", full)
    end
end

Log.i = function(cat, f, ...) emit("I", cat, fmt(f, ...)) end
Log.w = function(cat, f, ...) emit("W", cat, fmt(f, ...)) end
Log.e = function(cat, f, ...) emit("E", cat, fmt(f, ...)) end
Log.d = function(cat, f, ...) emit("D", cat, fmt(f, ...)) end

-- at most one line per `interval` seconds per key; says how many were swallowed
Log.every = function(key, interval, level, cat, f, ...)
    local r = Log.rate[key]
    local c = now_clock()
    if r and c - r.t < interval then
        r.skipped = r.skipped + 1
        return
    end
    local extra = ""
    if r and r.skipped > 0 then
        extra = string.format(" (+%d similar suppressed)", r.skipped)
    end
    Log.rate[key] = { t = c, skipped = 0 }
    emit(level, cat, fmt(f, ...) .. extra)
end

Log.once = function(key, level, cat, f, ...)
    if Log.seen[key] then
        return
    end
    Log.seen[key] = true
    emit(level, cat, fmt(f, ...))
end

local function pack(...)
    return { n = select("#", ...), ... }
end

local function traceback(e)
    local dbg = rawget(_G, "debug")
    if dbg and dbg.traceback then
        return dbg.traceback(tostring(e), 2)
    end
    return tostring(e)
end

-- pcall with a logged traceback. Returns ok, results...
Log.guard = function(cat, label, fn, ...)
    local res = pack(xpcall(fn, traceback, ...))
    if not res[1] then
        Log.e(cat, "%s threw: %s", label, tostring(res[2]))
    end
    return unpack(res, 1, res.n)
end

-- error-rate-limited variant for per-frame code (conditions, hooks, effect updates)
Log.guard_quiet = function(cat, label, fn, ...)
    local res = pack(xpcall(fn, traceback, ...))
    if not res[1] then
        Log.every("guard:" .. label, 5, "E", cat, "%s threw: %s", label, tostring(res[2]))
    end
    return unpack(res, 1, res.n)
end

Log.tail = function(n)
    n = n or 40
    local out = {}
    local lines = Log.lines
    for i = math.max(1, #lines - n + 1), #lines do
        out[#out + 1] = lines[i]
    end
    return out
end

Log.summary = function()
    local cats = {}
    for cat, n in pairs(Log.counts) do
        cats[#cats + 1] = cat .. "=" .. n
    end
    table.sort(cats)
    return string.format("lines I=%d W=%d E=%d D=%d | %s | file=%s", Log.levels.I, Log.levels.W, Log.levels.E, Log.levels.D,
        table.concat(cats, " "), tostring(Log.file_ok and Log.path or "none"))
end

return Log
