-- QIangIQsSprayerOgryn boss runtime: master item injection, package loading, spawning, the 10 s beeping death explosion, and the
-- per-second monitor (extension audit, snapshots, stuck detection). Nothing here runs unless the registration steps succeeded.
local mod = get_mod("QIangIQsSprayerOgryn")
local Sog = mod.sog
local Log = Sog.Log
local C = Sog.C
local G = C and C.g
local AI = Sog.AI
local NEW = Sog.BREED

local Boss = { tracked = {}, pending = {}, package_ids = {}, load_job = nil, item_ver = nil, item_injected = false }
Sog.Boss = Boss

local function req(path)
    local ok, m = pcall(require, path)
    if ok then
        return m
    end
    Log.e("BOOT", "require(%s) failed: %s", path, tostring(m))
    return nil
end

local MasterItems = req("scripts/backend/master_items")
local ItemPackage = req("scripts/foundation/managers/package/utilities/item_package")
local BreedResourceDependencies = req("scripts/utilities/breed_resource_dependencies")
local Explosion = req("scripts/utilities/attack/explosion")
local NavQueries = req("scripts/utilities/nav_queries")

local ITEM = "content/items/characters/minions/chaos_plague_ogryn/attachments_base/sprayer"
local SRC_ITEM = "content/items/characters/minions/chaos_plague_ogryn/attachments_base/body_skin_02"
local UNIT = "content/characters/enemy/chaos_plague_ogryn/attachments_base/sprayer/sprayer"
Boss.ITEM = ITEM

local function now()
    return Managers.time:has_timer("gameplay") and Managers.time:time("gameplay") or 0
end

local function clock()
    return os.clock()
end

local function cfg()
    return Sog.cfg
end

local function is_server()
    local gs = Managers.state and Managers.state.game_session
    if not gs then
        return false
    end
    local ok, res = pcall(gs.is_server, gs)
    return ok and res == true
end

local function local_player_unit()
    local players = Managers.player
    local player = players and players:local_player_safe(1)
    local unit = player and player.player_unit
    if unit and Unit.alive(unit) then
        return unit
    end
    return nil
end

local function fmt_pos(p)
    if not p then
        return "nil"
    end
    if type(p) == "userdata" and not pcall(Vector3.x, p) then
        local ok, v = pcall(function() return p:unbox() end)
        if ok then
            p = v
        end
    end
    local ok, s = pcall(function()
        return string.format("(%.1f, %.1f, %.1f)", Vector3.x(p), Vector3.y(p), Vector3.z(p))
    end)
    return ok and s or tostring(p)
end

-- ------------------------------------------------------------------------------------------------ master item
-- The sprayer body item exists in the shipped bundles but not in the live master item list, and creature_spawner-style loadout
-- code silently drops items missing from MasterItems.get_cached(). Clone the stock body item and point it at the sprayer unit.
Boss.ensure_item = function()
    if not MasterItems then
        return false, "master_items module missing"
    end
    local ok_data, has = pcall(MasterItems.has_data)
    if not ok_data or not has then
        return false, "master items not loaded yet"
    end
    local cache = MasterItems.get_cached()
    local ver = MasterItems.get_cached_version and MasterItems.get_cached_version() or 0
    local existing = rawget(cache, ITEM)
    if existing and (Boss.item_ver == ver or not Boss.item_injected) then
        if not Boss.item_injected and Boss.item_ver == nil then
            Log.i("ITEM", "sprayer item already present in the master item list (retail added it); not injecting")
        end
        Boss.item_ver = ver
        return true
    end

    local src = rawget(cache, SRC_ITEM)
    local item
    if src then
        item = table.clone(src)
        Log.d("ITEM", "cloned %s as the template", SRC_ITEM)
    else
        Log.w("ITEM", "%s not in the master list; building the item from the known definition", SRC_ITEM)
        item = {
            attach_node = "j_hips",
            event_in_parent_state_machine = "",
            feature_flags = { "FEATURE_item_retained" },
            is_fallback_item = false,
            item_list_faction = "Minion",
            material_override_items = {},
            material_overrides = {},
            tags = {},
            workflow_checklist = {},
            workflow_state = "RELEASABLE",
        }
    end
    item.name = ITEM
    item.base_unit = UNIT
    item.display_name = item.display_name or "n/a"
    item.attachments = nil
    item.resource_dependencies = {}
    local ok_compile, err = pcall(ItemPackage.compile_resource_dependencies, item, item.resource_dependencies)
    local n = 0
    for _ in pairs(item.resource_dependencies) do
        n = n + 1
    end
    if not ok_compile or n == 0 or not item.resource_dependencies[UNIT] then
        Log.w("ITEM", "compile_resource_dependencies gave %d entries (ok=%s err=%s, unit key present=%s); forcing the unit dependency",
            n, tostring(ok_compile), tostring(err), tostring(item.resource_dependencies[UNIT]))
        item.resource_dependencies[UNIT] = true
    end

    local ok_set, set_err = pcall(function() cache[ITEM] = item end)
    if not ok_set or rawget(cache, ITEM) ~= item then
        rawset(cache, ITEM, item)
    end
    if rawget(cache, ITEM) ~= item then
        Log.e("ITEM", "could not write the sprayer item into the master item cache (%s)", tostring(set_err))
        return false, "cache is read-only"
    end
    Boss.item_ver = ver
    Boss.item_injected = true
    Sog.counters.item_injections = (Sog.counters.item_injections or 0) + 1
    Log.i("ITEM", "injected %s -> %s (cache version %s, %d resource dependencies)", ITEM, UNIT, tostring(ver), n)
    return true
end

-- ------------------------------------------------------------------------------------------------ packages
Boss.package_list = function()
    local breed = G.Breeds[NEW]
    local ok, packages = pcall(BreedResourceDependencies.generate, { [NEW] = breed }, MasterItems.get_cached())
    if not ok or type(packages) ~= "table" then
        return nil, tostring(packages)
    end
    return packages
end

Boss.ensure_packages = function(callback)
    local pm = Managers.package
    if not pm then
        callback(false, "no package manager")
        return
    end
    local packages, err = Boss.package_list()
    if not packages then
        Log.e("PKG", "BreedResourceDependencies.generate failed: %s", tostring(err))
        callback(false, err)
        return
    end
    local missing, total = {}, 0
    for name in pairs(packages) do
        total = total + 1
        if not pm:has_loaded(name) then
            missing[#missing + 1] = name
        end
    end
    table.sort(missing)
    Log.i("PKG", "boss needs %d packages, %d not loaded", total, #missing)
    for i = 1, math.min(#missing, 80) do
        Log.d("PKG", "missing: %s", missing[i])
    end
    if #missing == 0 then
        callback(true)
        return
    end
    if Boss.load_job then
        Log.w("PKG", "a package load is already running (%d left)", Boss.load_job.remaining)
        callback(false, "already loading")
        return
    end
    local job = { remaining = #missing, total = #missing, started = clock(), names = missing, callback = callback, done = {} }
    Boss.load_job = job
    for i = 1, #missing do
        local name = missing[i]
        local ok, id = pcall(pm.load, pm, name, "QIangIQsSprayerOgryn", function()
            job.done[name] = true
            job.remaining = job.remaining - 1
            Log.d("PKG", "loaded %s (%d left)", name, job.remaining)
            if job.remaining <= 0 and Boss.load_job == job then
                Boss.load_job = nil
                Log.i("PKG", "all %d packages loaded in %.1fs", job.total, clock() - job.started)
                Log.guard("PKG", "load callback", job.callback, true)
            end
        end)
        if ok then
            Boss.package_ids[#Boss.package_ids + 1] = id
        else
            Log.e("PKG", "Managers.package:load(%s) threw: %s", name, tostring(id))
            job.remaining = job.remaining - 1
            job.done[name] = "error"
        end
    end
    if job.remaining <= 0 and Boss.load_job == job then
        Boss.load_job = nil
        callback(false, "every package load threw")
    end
end

local function check_load_timeout()
    local job = Boss.load_job
    if job and clock() - job.started > 30 then
        local pm = Managers.package
        local still = {}
        for _, name in ipairs(job.names) do
            if not job.done[name] and not (pm and pm:has_loaded(name)) then
                still[#still + 1] = name
            end
        end
        Log.e("PKG", "package load timed out after 30s, %d still missing: %s", #still, table.concat(still, ", "))
        Boss.load_job = nil
        pcall(job.callback, false, "timeout")
    end
end

Boss.release_packages = function()
    local pm = Managers.package
    for i = #Boss.package_ids, 1, -1 do
        local id = Boss.package_ids[i]
        Boss.package_ids[i] = nil
        if pm then
            pcall(pm.release, pm, id)
        end
    end
    Boss.load_job = nil
end

-- ------------------------------------------------------------------------------------------------ spawn
local function find_spawn_position(distance)
    local pu = local_player_unit()
    if not pu then
        return nil, nil, "no local player unit"
    end
    local ppos = Unit.world_position(pu, 1)
    local rot = Unit.local_rotation(pu, 1)
    local fwd = Vector3.flat(Quaternion.forward(rot))
    if Vector3.length(fwd) < 0.01 then
        fwd = Vector3(0, 1, 0)
    end
    fwd = Vector3.normalize(fwd)
    local nav_world = Managers.state.nav_mesh:nav_world()
    for _, d in ipairs({ distance, distance * 0.75, distance * 0.5, distance * 0.3 }) do
        for _, angle in ipairs({ 0, 0.4, -0.4, 0.9, -0.9, 1.6, -1.6 }) do
            local dir = Quaternion.rotate(Quaternion(Vector3.up(), angle), fwd)
            local p = NavQueries.position_on_mesh(nav_world, ppos + dir * d, 3, 3)
            if p then
                -- face the player
                local look = Quaternion.look(Vector3.flat(ppos - p), Vector3.up())
                return p, look, string.format("%.0fm at angle %.1f", d, angle)
            end
        end
    end
    return nil, nil, "no navmesh point within " .. distance .. "m of the player"
end

local function do_spawn(position, rotation, how)
    local breed = G.Breeds[NEW]
    local ms = Managers.state.minion_spawn
    local side = Managers.state.extension:system("side_system"):get_side_from_name("villains")
    if not side then
        Log.e("SPAWN", "no 'villains' side")
        return nil
    end
    local param = ms:request_param_table()
    local base_hp = Managers.state.difficulty:get_minion_max_health(NEW)
    param.optional_health_modifier = cfg().health_multiplier
    -- spawn already aggroed on the local player: in the Psykhanium the boss otherwise never picked a target (dist=inf, idle forever)
    param.optional_aggro_state = "aggroed"
    local lp = Managers.player and Managers.player:local_player_safe(1)
    local pu = lp and lp.player_unit
    if pu and Unit.alive(pu) then
        param.optional_target_unit = pu
    end
    Log.i("SPAWN", "spawning %s at %s (%s) side=%s base_hp=%s hp_mult=%.2f", NEW, fmt_pos(position), how, tostring(side.side_id), tostring(base_hp), cfg().health_multiplier)
    local ok, unit = pcall(ms.spawn_minion, ms, NEW, position, rotation, side.side_id, param)
    if not ok then
        Log.e("SPAWN", "spawn_minion threw: %s", tostring(unit))
        return nil
    end
    if not unit then
        Log.e("SPAWN", "spawn_minion returned nil")
        return nil
    end
    Sog.counters.spawned = (Sog.counters.spawned or 0) + 1
    Boss.tracked[unit] = { t0 = now(), clock0 = clock(), audited = false, last_pos = nil, last_move_t = now(), next_snap = 0, base_hp = base_hp }
    Log.i("SPAWN", "spawned unit %s (#%d)", tostring(unit), Sog.counters.spawned)
    return unit
end

Boss.spawn = function(count, distance)
    if not Sog.ok() then
        Log.e("SPAWN", "registration incomplete, refusing to spawn: %s", Sog.failed_steps())
        return false, "registration incomplete: " .. Sog.failed_steps()
    end
    if not is_server() then
        Log.e("SPAWN", "not the server; only the host can spawn the boss")
        return false, "host only"
    end
    if not Managers.state or not Managers.state.minion_spawn then
        return false, "no minion spawn manager (not in a mission?)"
    end
    local ok_item, why = Boss.ensure_item()
    if not ok_item then
        Log.e("SPAWN", "sprayer item not available: %s", tostring(why))
        return false, "item: " .. tostring(why)
    end
    count = count or 1
    distance = distance or cfg().spawn_distance
    Boss.ensure_packages(function(ok, err)
        if not ok then
            Log.e("SPAWN", "packages not ready (%s); not spawning", tostring(err))
            mod:notify("Sprayer Ogryn: packages failed to load, see the log")
            return
        end
        for i = 1, count do
            local pos, rot, how = find_spawn_position(distance + (i - 1) * 4)
            if not pos then
                Log.e("SPAWN", "no spawn position: %s", tostring(how))
                mod:notify("Sprayer Ogryn: no spawn position (" .. tostring(how) .. ")")
                return
            end
            do_spawn(pos, rot, how)
        end
    end)
    return true
end

-- ------------------------------------------------------------------------------------------------ audit (what actually got built)
local EXTENSIONS = { "behavior_system", "perception_system", "navigation_system", "locomotion_system", "animation_system",
    "health_system", "visual_loadout_system", "buff_system", "fx_system", "unit_data_system", "dialogue_system" }

Boss.audit = function(unit)
    local missing = {}
    for _, name in ipairs(EXTENSIONS) do
        if not ScriptUnit.has_extension(unit, name) then
            missing[#missing + 1] = name
        end
    end
    if #missing > 0 then
        Log.w("AUDIT", "extensions missing on the boss: %s", table.concat(missing, ", "))
    else
        Log.i("AUDIT", "all %d expected extensions present", #EXTENSIONS)
    end
    pcall(function()
        local ext = ScriptUnit.extension(unit, "visual_loadout_system")
        -- slot_item returns the slot entry (a table with the item, unit, state), not the item itself
        local slot = ext:slot_item("slot_body")
        local item = slot and (slot.item or slot)
        local name = item and (item.name or slot.item_name or slot.name) or nil
        local keys = {}
        for k in pairs(slot or {}) do keys[#keys + 1] = tostring(k) end
        table.sort(keys)
        Log.i("AUDIT", "slot_body entry keys: %s unit=%s", table.concat(keys, ","), tostring(slot and slot.unit))
        if name == ITEM then
            Log.i("AUDIT", "slot_body = sprayer item (good)")
        else
            Log.e("AUDIT", "slot_body = %s (expected the sprayer item); the sprayer body is NOT attached", tostring(name))
        end
    end)
    pcall(function()
        local blackboards = rawget(_G, "BLACKBOARDS")
        local bb = blackboards and blackboards[unit]
        local comps = {}
        for _, name in ipairs({ "behavior", "perception", "aim", "statistics", "spawn", "nav_smart_object", "slot" }) do
            comps[#comps + 1] = name .. "=" .. tostring(bb and bb[name] ~= nil)
        end
        Log.i("AUDIT", "blackboard components: %s", table.concat(comps, " "))
    end)
    pcall(function()
        local ext = ScriptUnit.extension(unit, "unit_data_system")
        local breed = ext:breed()
        Log.i("AUDIT", "breed on the unit: %s game_object_type=%s", tostring(breed and breed.name), tostring(breed and breed.game_object_type))
    end)
    pcall(function()
        local id = Managers.state.unit_spawner:game_object_id(unit)
        Log.i("AUDIT", "game object id: %s", tostring(id))
    end)
    pcall(function()
        local h = ScriptUnit.extension(unit, "health_system")
        Log.i("AUDIT", "health %s / %s", tostring(h:current_health()), tostring(h:max_health()))
    end)
    pcall(function()
        for _, node in ipairs({ "j_lefthand", "j_neck", "j_head", "j_leftfoot", "enemy_aim_target_03" }) do
            Log.d("AUDIT", "node %s: %s", node, tostring(Unit.has_node and Unit.has_node(unit, node)))
        end
    end)
end

-- ------------------------------------------------------------------------------------------------ death explosion
Boss.on_death = function(unit)
    local pos = (Unit.alive(unit) and Unit.world_position(unit, 1)) or nil
    if not pos then
        Log.e("DEATH", "no position for the dead boss; cannot schedule the explosion")
        return
    end
    local t = now()
    local delay = cfg().explosion_delay
    Boss.pending[#Boss.pending + 1] = { unit = unit, pos = Vector3Box(pos), t0 = t, boom = t + delay, next_beep = t + 0.2, beeps = 0, delay = delay }
    Sog.counters.deaths = (Sog.counters.deaths or 0) + 1
    Log.i("DEATH", "boss died at %s; explosion in %.1fs", fmt_pos(pos), delay)
    local s = AI and AI.state[unit]
    if s then
        local parts = {}
        for name, n in pairs(s.counts) do
            parts[#parts + 1] = name .. "=" .. n
        end
        table.sort(parts)
        Log.i("DEATH", "action counts over the fight: %s", table.concat(parts, " "))
    end
end

-- The retail beep events are not in NetworkLookup.sound_events, so fx_system can not play them (it throws on the lookup). They are
-- triggered locally on the level world's WwiseWorld instead, which needs no lookup entry (audible on this client only).
-- BEEP_EVENTS are played together; whichever have their sound bank loaded will sound.
Boss.beep = function(p)
    local pos = p.pos:unbox()
    local world = Managers.world and Managers.world:world("level_world")
    local wwise_world = world and Managers.world:wwise_world(world)
    if not wwise_world then
        Log.once("beep:nowwise", "E", "EXPL", "no wwise world; the beep cannot play")
        return false
    end
    local played = 0
    for _, event in ipairs(C.BEEP_EVENTS) do
        local ok, res = pcall(WwiseWorld.trigger_resource_event, wwise_world, event, pos)
        if ok then
            played = played + 1
            if not Boss.beep_logged then
                Log.i("EXPL", "beep event triggered locally: %s (id %s)", event, tostring(res))
            end
        else
            Log.once("beep:" .. event, "W", "EXPL", "beep event %s failed: %s", event, tostring(res))
        end
    end
    Boss.beep_logged = true
    return played > 0
end

Boss.detonate = function(pos, template_name, power_mult, attacker_unit)
    local world = Managers.world:world("level_world")
    local physics_world = World.physics_world(world)
    local tpl = G.ExplosionTemplates[template_name]
    if not tpl then
        Log.e("EXPL", "explosion template %s missing", tostring(template_name))
        return false
    end
    local breed = G.Breeds[NEW]
    local ok_pl, base_power = pcall(function() return Managers.state.difficulty:get_minion_attack_power_level(breed) end)
    local power = (ok_pl and base_power or 500) * (power_mult or 1)
    local attackers = {}
    if attacker_unit and Unit.alive(attacker_unit) then
        attackers[#attackers + 1] = attacker_unit
    end
    attackers[#attackers + 1] = false
    for _, a in ipairs(attackers) do
        local ok, err = pcall(Explosion.create_explosion, world, physics_world, pos, Quaternion.look(Vector3.up()), a or nil, tpl, power, 1, nil, false, nil)
        if ok then
            Sog.counters.detonations = (Sog.counters.detonations or 0) + 1
            Log.i("EXPL", "detonate %s at %s power=%.0f", template_name, fmt_pos(pos), power)
            return true
        end
        Log.e("EXPL", "detonate %s threw: %s", template_name, tostring(err))
    end
    return false
end

local function update_pending(t)
    for i = #Boss.pending, 1, -1 do
        local p = Boss.pending[i]
        if p.unit and Unit.alive(p.unit) then
            local live = Unit.world_position(p.unit, 1)
            if live then
                p.pos:store(live)
            end
        end
        if t >= p.boom then
            Log.guard("EXPL", "explode", Boss.explode, p)
            table.remove(Boss.pending, i)
        elseif t >= p.next_beep then
            local progress = math.min(1, (t - p.t0) / p.delay)
            local interval = 1.0 - 0.88 * progress * progress
            p.next_beep = t + interval
            p.beeps = p.beeps + 1
            Log.guard_quiet("EXPL", "beep", Boss.beep, p)
            Log.d("EXPL", "beep #%d, %.1fs left, next in %.2fs", p.beeps, p.boom - t, interval)
        end
    end
end

-- ------------------------------------------------------------------------------------------------ monitor
local function snapshot(unit, info, t)
    local s = AI.S(unit)
    local pos = Unit.alive(unit) and Unit.world_position(unit, 1) or nil
    local hp, max
    pcall(function()
        local h = ScriptUnit.extension(unit, "health_system")
        hp, max = h:current_health(), h:max_health()
    end)
    local dist, aggro, los, move
    pcall(function()
        local blackboards = rawget(_G, "BLACKBOARDS")
        local bb = blackboards and blackboards[unit]
        dist, aggro, los = bb.perception.target_distance, bb.perception.aggro_state, bb.perception.has_line_of_sight
        move = bb.behavior.move_state
    end)
    local msg = string.format("pos=%s hp=%s/%s dist=%s aggro=%s los=%s move=%s act=%s(%.1fs) cycle=%d cd[atk=%.1f ret=%.1f stomp=%.1f] | %s",
        fmt_pos(pos), hp and string.format("%.0f", hp) or "?", max and string.format("%.0f", max) or "?",
        dist and string.format("%.1f", dist) or "-", tostring(aggro), tostring(los), tostring(move), tostring(s.current),
        s.current_t and (t - s.current_t) or 0, s.cycle, math.max(0, s.attack_ready - t), math.max(0, s.retreat_ready - t),
        math.max(0, s.stomp_ready - t), AI.explain(unit))
    Log.every("snap:" .. tostring(unit), 0.9, "I", "SNAP", "%s", msg)

    -- stuck detection: position barely changes while a moving action runs
    if pos then
        if not info.last_pos or Vector3.distance(pos, info.last_pos:unbox()) > 0.6 then
            info.last_pos = Vector3Box(pos)
            info.last_move_t = t
        elseif (s.current == "follow" or s.current == "retreat") and t - info.last_move_t > 6 then
            Log.every("stuck:" .. tostring(unit), 6, "W", "STUCK", "boss has not moved for %.0fs during %s (nav problem?)", t - info.last_move_t, s.current)
        end
    end
    if s.current_t and s.current and t - s.current_t > 16 and s.current ~= "hold" and s.current ~= "idle" then
        Log.every("long:" .. tostring(unit), 8, "W", "STUCK", "action %s has run %.0fs", s.current, t - s.current_t)
    end
end

Boss.update = function(dt)
    local t = now()
    check_load_timeout()
    update_pending(t)

    for unit, info in pairs(Boss.tracked) do
        if not Unit.alive(unit) then
            Log.i("SPAWN", "tracked boss unit %s is gone (lived %.1fs)", tostring(unit), t - info.t0)
            Boss.tracked[unit] = nil
        else
            if not info.audited and t - info.t0 > 0.75 then
                info.audited = true
                Log.guard("AUDIT", "audit", Boss.audit, unit)
            end
            if cfg().snapshots and t >= info.next_snap then
                info.next_snap = t + 1
                Log.guard_quiet("SNAP", "snapshot", snapshot, unit, info, t)
            end
        end
    end

    -- the item can vanish when the backend reloads the master list: put it back
    Boss.item_poll = (Boss.item_poll or 0) - dt
    if Boss.item_poll <= 0 then
        Boss.item_poll = 2
        if Sog.ok() and MasterItems then
            local ok, has = pcall(MasterItems.has_data)
            if ok and has then
                local ok2, res, why = pcall(Boss.ensure_item)
                if not ok2 then
                    Log.every("item_poll_err", 10, "E", "ITEM", "ensure_item threw: %s", tostring(res))
                elseif res == false then
                    Log.every("item_poll_fail", 10, "W", "ITEM", "ensure_item failed: %s", tostring(why))
                end
            end
        end
    end
end

Boss.unload = function()
    if Sog.AI and Sog.AI.clear_mines then
        pcall(Sog.AI.clear_mines)
    end
    Boss.release_packages()
    Boss.pending = {}
    Boss.tracked = {}
end

Boss.kill_all = function()
    local n = 0
    local dp = req("scripts/settings/damage/damage_profile_templates")
    for unit in pairs(Boss.tracked) do
        if Unit.alive(unit) then
            local ok, err = pcall(function()
                local profile = dp.default
                Managers.state.minion_death:die(unit, nil, Vector3.up(), nil, profile, nil, nil, nil, nil)
            end)
            if ok then
                n = n + 1
            else
                Log.e("DEATH", "minion_death:die threw: %s", tostring(err))
            end
        end
    end
    return n
end

-- ------------------------------------------------------------------------------------------------ boss health bar
-- The HUD skips the boss bar in the Psykhanium ("shooting_range" game mode). For this breed only, report a normal game mode while
-- the HUD handles the encounter start so the bar shows there too.
-- optional: a failure here only costs the boss bar, so it must not mark the whole mod as not ready
Log.guard("BOOT", "boss bar hook", function()
    mod:hook("HudElementBossHealth", "event_boss_encounter_start", function(func, self, unit, boss_extension, ...)
        local is_ours = false
        pcall(function()
            local breed = ScriptUnit.extension(unit, "unit_data_system"):breed()
            is_ours = breed and breed.sog_boss == true
        end)
        if not is_ours then
            return func(self, unit, boss_extension, ...)
        end
        local gm = Managers.state and Managers.state.game_mode
        if not gm then
            return func(self, unit, boss_extension, ...)
        end
        local real = gm.game_mode_name
        gm.game_mode_name = function(g)
            local name = real(g)
            if name == "shooting_range" then
                return "coop_complete_objective"
            end
            return name
        end
        local ok, err = pcall(func, self, unit, boss_extension, ...)
        gm.game_mode_name = nil -- remove the instance override; the class method is untouched
        Sog.counters.boss_bar_started = (Sog.counters.boss_bar_started or 0) + 1
        Log.i("HUD", "boss bar encounter start for the sprayer ogryn (ok=%s %s)", tostring(ok), ok and "" or tostring(err))
        if not ok then
            error(err)
        end
    end)
end)

return Boss
