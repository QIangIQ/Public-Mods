-- QIangIQsSprayerOgryn content registration: breed, network lookups, difficulty rows, effect templates, explosion template,
-- action data. Every step is isolated (Sog.step) and logged; a failed step is reported in /sprayer debug and the boss refuses to
-- spawn if a required step failed. Nothing here spawns anything.
local mod = get_mod("QIangIQsSprayerOgryn")
local Sog = mod.sog
local Log = Sog.Log

local NEW = Sog.BREED
local SRC = Sog.SRC_BREED
local G = {}   -- game modules
local C = { g = G }
Sog.C = C

local function req(path)
    local ok, m = pcall(require, path)
    if ok then
        return m
    end
    Log.e("BOOT", "require(%s) failed: %s", path, tostring(m))
    return nil
end

local function shallow(t)
    local c = {}
    for k, v in pairs(t) do
        c[k] = v
    end
    return c
end

local function lookup_add(lookup_name, key)
    local lookup = G.NetworkLookup[lookup_name]
    if not lookup then
        error("NetworkLookup." .. lookup_name .. " is missing")
    end
    local existing = rawget(lookup, key)
    if existing ~= nil then
        Log.d("NET", "NetworkLookup.%s already has %s = %s", lookup_name, key, tostring(existing))
        return existing
    end
    local index = #lookup + 1
    rawset(lookup, index, key)
    rawset(lookup, key, index)
    Log.i("NET", "NetworkLookup.%s += %s (index %d, size now %d)", lookup_name, key, index, #lookup)
    return index
end

-- ------------------------------------------------------------------------------------------------ modules
Sog.step("content: load game modules", function()
    G.Breeds = req("scripts/settings/breed/breeds")
    G.BreedActions = req("scripts/settings/breed/breed_actions")
    G.BehaviorTrees = req("scripts/extension_systems/behavior/trees/behavior_trees")
    G.BtConditions = req("scripts/extension_systems/behavior/utilities/bt_conditions")
    G.BtEnterHooks = req("scripts/extension_systems/behavior/utilities/bt_enter_hooks")
    G.BtLeaveHooks = req("scripts/extension_systems/behavior/utilities/bt_leave_hooks")
    G.NetworkLookup = req("scripts/network_lookup/network_lookup")
    G.MinionDifficultySettings = req("scripts/settings/difficulty/minion_difficulty_settings")
    G.DialogueBreedSettings = req("scripts/settings/dialogue/dialogue_breed_settings")
    G.MinionVisualLoadoutTemplates = req("scripts/settings/minion_visual_loadout/minion_visual_loadout_templates")
    G.EffectTemplates = req("scripts/settings/fx/effect_templates")
    G.ExplosionTemplates = req("scripts/settings/damage/explosion_templates")
    G.LiquidAreaTemplates = req("scripts/settings/liquid_area/liquid_area_templates")
    G.BreedShootTemplates = req("scripts/settings/breed/breed_shoot_templates")
    G.BuffTemplates = req("scripts/settings/buff/buff_templates")
    G.DamageProfileTemplates = req("scripts/settings/damage/damage_profile_templates")
    G.DamageSettings = req("scripts/settings/damage/damage_settings")
    G.BlackboardTemplates = req("scripts/settings/breed/breed_blackboard_component_templates")
    G.BoNSettings = req("scripts/settings/monster/chaos_beast_of_nurgle_settings")
    G.RenegadeFlamerSettings = req("scripts/settings/specials/renegade_flamer_settings")
    G.CultistFlamerSettings = req("scripts/settings/specials/cultist_flamer_settings")
    G.Flamer = req("scripts/utilities/flamer")

    local missing = {}
    for name, value in pairs(G) do
        if value == nil then
            missing[#missing + 1] = name
        end
    end
    local required = { "Breeds", "BreedActions", "BehaviorTrees", "BtConditions", "BtEnterHooks", "BtLeaveHooks", "NetworkLookup",
        "MinionDifficultySettings", "MinionVisualLoadoutTemplates", "EffectTemplates", "ExplosionTemplates", "LiquidAreaTemplates",
        "BreedShootTemplates", "BlackboardTemplates", "BoNSettings", "Flamer" }
    for _, name in ipairs(required) do
        if G[name] == nil then
            missing[#missing + 1] = name
        end
    end
    if #missing > 0 then
        error("required game modules missing: " .. table.concat(missing, ", "))
    end
end)

-- ------------------------------------------------------------------------------------------------ game object type
-- The liquid beam writes the game-object fields state/aim_position/control_point_1/control_point_2. Pick the first type that has
-- all of them (the plague ogryn's own "minion_monster" if it does, else the Beast of Nurgle's), logged either way.
local BEAM_FIELDS = { "state", "aim_position", "control_point_1", "control_point_2" }

local function pick_game_object_type()
    local choice = Sog.setting("game_object_type") or "auto"
    if choice == "monster" then
        Log.i("BREED", "game_object_type forced to minion_monster by the option")
        return "minion_monster"
    elseif choice == "bon" then
        Log.i("BREED", "game_object_type forced to minion_beast_of_nurgle by the option")
        return "minion_beast_of_nurgle"
    end
    local report = {}
    for _, type_name in ipairs({ "minion_monster", "minion_beast_of_nurgle" }) do
        local all = true
        local parts = {}
        for _, field in ipairs(BEAM_FIELDS) do
            local ok, has = pcall(function()
                return Network.object_has_field(type_name, field)
            end)
            parts[#parts + 1] = field .. "=" .. (ok and tostring(has) or ("ERR:" .. tostring(has)))
            if not ok or not has then
                all = false
            end
        end
        report[#report + 1] = type_name .. "{" .. table.concat(parts, ",") .. "}"
        if all then
            Log.i("BREED", "game_object_type = %s (has every beam field) | %s", type_name, table.concat(report, " "))
            return type_name
        end
    end
    Log.w("BREED", "no game object type could be verified (%s); falling back to minion_beast_of_nurgle", table.concat(report, " "))
    return "minion_beast_of_nurgle"
end

-- ------------------------------------------------------------------------------------------------ breed
Sog.step("content: breed", function()
    local src = G.Breeds[SRC]
    if not src then
        error("source breed " .. SRC .. " not found in Breeds")
    end
    local bon = G.Breeds.chaos_beast_of_nurgle
    local breed = shallow(src)

    breed.name = NEW
    breed.behavior_tree_name = NEW
    breed.look_at_tag = SRC          -- dynamic smart tag lookups must keep resolving
    breed.game_object_type = pick_game_object_type()
    breed.sog_boss = true
    breed.boss_display_name = "loc_sog_boss_name"

    -- Start from the stock plague ogryn loadout (it carries slot_flesh, which the wounds extension toggles on every hit; the retail
    -- sprayer template omits it and the first melee hit crashed with "slot_data is nil"), then swap the body for the sprayer item
    -- and drop the vent slot (the sprayer body has its own).
    local SPRAYER_ITEM = "content/items/characters/minions/chaos_plague_ogryn/attachments_base/sprayer"
    local stock = G.MinionVisualLoadoutTemplates[SRC]
    if stock then
        local clone = (table and table.clone) and table.clone(stock) or nil
        if not clone then
            error("table.clone unavailable; cannot build the sprayer loadout")
        end
        local variants, slots_fixed = 0, 0
        for zone, list in pairs(clone) do
            for _, loadout in ipairs(list) do
                variants = variants + 1
                local slots = loadout.slots
                if slots then
                    slots.slot_vent = nil
                    slots.slot_body = slots.slot_body or { use_outline = true }
                    slots.slot_body.items = { SPRAYER_ITEM }
                    slots_fixed = slots_fixed + 1
                    if not slots.slot_flesh then
                        Log.w("BREED", "stock loadout %s has no slot_flesh; wounds may fail", tostring(zone))
                    end
                end
            end
        end
        breed.inventory = clone
        Log.i("BREED", "inventory = clone of stock %s loadouts (%d variants, %d with slot_body -> sprayer, vent removed, slot_flesh kept)", SRC, variants, slots_fixed)
    else
        Log.w("BREED", "MinionVisualLoadoutTemplates.%s is missing; the boss keeps the stock inventory field", SRC)
    end

    -- The plague ogryn skeleton has no "aim_target" constraint, so the ranged aim extension (created whenever breed.aim_config is set,
    -- and which looks that constraint up) must not exist for this breed: spawn_minion threw and froze the game when aim_config was
    -- copied from the Beast of Nurgle. But the liquid beam action reads breed.aim_config.node when it starts. So aim_config is hidden
    -- by default and only exposed while a beam action's enter runs (see the enter wrapper in sog_ai.lua).
    Sog.aim_config = { node = "j_neck", target_node = "enemy_aim_target_03", target = "aim_target", distance = 5, lerp_speed = 200, aim_on_target = true }
    Sog.expose_aim = false
    breed.aim_config = nil
    setmetatable(breed, {
        __index = function(_, key)
            if key == "aim_config" and Sog.expose_aim then
                return Sog.aim_config
            end
            return nil
        end,
    })
    Log.i("BREED", "aim_config hidden except during beam enter (plague ogryn has no aim constraint target); body turns via locomotion instead")

    local monster = G.BlackboardTemplates.monster
    if not monster then
        error("BreedBlackboardComponentTemplates.monster missing")
    end
    local cfg = shallow(monster)
    cfg.aim = { controlled_aim_position = "Vector3Box", controlled_aiming = "boolean", lean_dot = "number" }
    cfg.statistics = { num_attacks_done = "number", num_in_liquid = "number" }
    breed.blackboard_component_config = cfg

    local ok = pcall(function() G.Breeds[NEW] = breed end)
    if not ok or rawget(G.Breeds, NEW) ~= breed then
        rawset(G.Breeds, NEW, breed)
    end
    if rawget(G.Breeds, NEW) ~= breed then
        error("could not register the breed in Breeds")
    end
    C.breed = breed
    Log.i("BREED", "registered breed %s (clone of %s) game_object_type=%s", NEW, SRC, breed.game_object_type)
end)

Sog.step("content: network lookups (breed, dialogue)", function()
    lookup_add("breed_names", NEW)
    pcall(lookup_add, "dialogue_breed_names", NEW)
end)

Sog.step("content: difficulty and dialogue rows", function()
    local copied = {}
    for key, sub in pairs(G.MinionDifficultySettings) do
        if type(sub) == "table" then
            local v = rawget(sub, SRC)
            if v ~= nil and rawget(sub, NEW) == nil then
                local ok = pcall(function() sub[NEW] = v end)
                if not ok then
                    rawset(sub, NEW, v)
                end
                copied[#copied + 1] = key
            end
        end
    end
    Log.i("BREED", "MinionDifficultySettings rows copied: %s", #copied > 0 and table.concat(copied, ",") or "NONE (health lookups will fail!)")
    if rawget(G.MinionDifficultySettings.health or {}, NEW) == nil then
        error("MinionDifficultySettings.health has no row for the new breed")
    end

    if G.DialogueBreedSettings and G.DialogueBreedSettings[SRC] and G.DialogueBreedSettings[NEW] == nil then
        local ok = pcall(function() G.DialogueBreedSettings[NEW] = shallow(G.DialogueBreedSettings[SRC]) end)
        Log.i("BREED", "DialogueBreedSettings row %s", ok and "copied" or "FAILED (spawn VO may error)")
    end
    -- the boss health bar name
    pcall(function()
        local BreedTerrorEventSettings = require("scripts/settings/breed/breed_terror_event_settings")
        if BreedTerrorEventSettings[SRC] and BreedTerrorEventSettings[NEW] == nil then
            BreedTerrorEventSettings[NEW] = BreedTerrorEventSettings[SRC]
        end
    end)
end)

-- ------------------------------------------------------------------------------------------------ effect templates
local FROM_NODE = "j_lefthand"
C.FROM_NODE = FROM_NODE

local function make_beam_effect(name, vfx, sfx, range, radius)
    local STATES = G.BoNSettings.states
    local Flamer = G.Flamer
    local function field(game_session, game_object_id, key)
        return GameSession.game_object_field(game_session, game_object_id, key)
    end
    local function switch_state(previous_state, new_state, template_data, template_context)
        local wwise_world = template_context.wwise_world
        local world = template_context.world
        local unit = template_data.unit
        if previous_state == STATES.shooting then
            Flamer.stop_fx(unit, vfx, sfx, wwise_world, world, template_data.data)
        end
        if new_state == STATES.aiming then
            Flamer.start_aiming_fx(Managers.time:time("gameplay"), unit, vfx, sfx, wwise_world, world, template_data.data, template_data.particle_group)
        elseif new_state == STATES.shooting then
            Flamer.start_shooting_fx(Managers.time:time("gameplay"), unit, vfx, sfx, wwise_world, world, template_data.data, template_data.particle_group)
        end
        template_data.state = new_state
    end

    return {
        name = name,
        resources = { resources_vfx = vfx, resources_sfx = sfx },
        start = function(template_data, template_context)
            Log.guard_quiet("FX", name .. ".start", function()
                local unit = template_data.unit
                template_data.physics_world = World.physics_world(template_context.world)
                local game_session = Managers.state.game_session:game_session()
                local game_object_id = Managers.state.unit_spawner:game_object_id(unit)
                template_data.game_session, template_data.game_object_id = game_session, game_object_id
                local node_name = FROM_NODE
                if Unit.has_node and not Unit.has_node(unit, node_name) then
                    Log.once("fxnode:" .. name, "W", "FX", "%s: unit has no node %s, using the first node", name, node_name)
                    node_name = nil
                end
                local node = node_name and Unit.node(unit, node_name) or 1
                template_data.data = { from_unit = unit, from_node = node, radius = radius, range = range }
                template_data.sog_ok = true
                Log.d("FX", "%s started on unit (go_id=%s node=%s)", name, tostring(game_object_id), tostring(node))
                switch_state(nil, field(game_session, game_object_id, "state"), template_data, template_context)
            end)
        end,
        update = function(template_data, template_context, dt, t)
            if not template_data.sog_ok then
                return
            end
            Log.guard_quiet("FX", name .. ".update", function()
                local game_session, game_object_id = template_data.game_session, template_data.game_object_id
                local wanted = field(game_session, game_object_id, "state")
                local aim_position = field(game_session, game_object_id, "aim_position")
                local cp1 = field(game_session, game_object_id, "control_point_1")
                local cp2 = field(game_session, game_object_id, "control_point_2")
                if template_data.state ~= wanted then
                    Log.d("FX", "%s state %s -> %s", name, tostring(template_data.state), tostring(wanted))
                    switch_state(template_data.state, wanted, template_data, template_context)
                end
                if template_data.state == STATES.shooting then
                    Flamer.update_shooting_fx(t, template_data.unit, vfx, sfx, template_context.wwise_world, template_context.world,
                        template_data.physics_world, aim_position, cp1, cp2, template_data.data, template_data.particle_group)
                end
            end)
        end,
        stop = function(template_data, template_context)
            if not template_data.sog_ok then
                return
            end
            Log.guard_quiet("FX", name .. ".stop", function()
                Flamer.stop_fx(template_data.unit, vfx, sfx, template_context.wwise_world, template_context.world, template_data.data)
                Log.d("FX", "%s stopped", name)
            end)
        end,
    }
end

Sog.step("content: effect templates", function()
    local bon_range = G.BoNSettings.range
    local defs = {
        { name = "sog_vomit_beam", vfx = G.BoNSettings.vfx, sfx = G.BoNSettings.sfx, range = bon_range, radius = G.BoNSettings.radius },
        { name = "sog_flame_beam", vfx = G.RenegadeFlamerSettings and G.RenegadeFlamerSettings.vfx, sfx = G.RenegadeFlamerSettings and G.RenegadeFlamerSettings.sfx, range = 22, radius = 0.2 },
        { name = "sog_tox_beam", vfx = G.CultistFlamerSettings and G.CultistFlamerSettings.vfx, sfx = G.CultistFlamerSettings and G.CultistFlamerSettings.sfx, range = 22, radius = 0.2 },
    }
    C.effects = {}
    for _, d in ipairs(defs) do
        if d.vfx and d.sfx then
            local tpl = make_beam_effect(d.name, d.vfx, d.sfx, d.range, d.radius)
            G.EffectTemplates[d.name] = tpl
            lookup_add("effect_templates", d.name)
            C.effects[d.name] = true
        else
            Log.e("FX", "%s not created: vfx/sfx settings missing (vfx=%s sfx=%s)", d.name, tostring(d.vfx), tostring(d.sfx))
        end
    end
end)

-- ------------------------------------------------------------------------------------------------ explosion template
-- played locally with WwiseWorld.trigger_resource_event (not networked: these events are not in NetworkLookup.sound_events)
C.BEEP_EVENTS = {
    "wwise/events/weapon/play_minion_twin_captain_throw_beep",
    "wwise/events/weapon/play_minion_grenadier_fire_grenade_throw_beep",
    "wwise/events/weapon/play_minion_frag_grenade_throw_beep",
}
C.MINE_ARM_EVENT = "wwise/events/weapon/play_minion_grenadier_gas_grenade_fuse"
C.MINE_VFX = "content/fx/particles/weapons/grenades/shock_mine/shock_mine_idle_01"

Sog.step("content: death explosion template", function()
    local base = G.ExplosionTemplates.poxwalker_bomber
    if not base then
        error("ExplosionTemplates.poxwalker_bomber missing")
    end
    local tpl = shallow(base)
    tpl.name = Sog.EXPLOSION
    tpl.radius = 16
    tpl.close_radius = 7
    tpl.min_radius = 7
    tpl.min_close_radius = 3
    tpl.damage_falloff = true
    tpl.scalable_radius = false
    tpl.override_friendly_fire = true
    tpl.vfx = {
        "content/fx/particles/explosions/poxwalker_explode",
        "content/fx/particles/enemies/beast_of_nurgle/bon_death_splatter",
    }
    tpl.sfx = {
        "wwise/events/minions/play_explosion_bomber",
        "wwise/events/weapon/play_explosion_refl_gen",
        "wwise/events/minions/play_beast_of_nurgle_death_explode",
    }
    G.ExplosionTemplates[Sog.EXPLOSION] = tpl
    C.explosion = tpl
    lookup_add("explosion_templates", Sog.EXPLOSION)
    Log.i("EXPL", "explosion template %s radius=%s close=%s", Sog.EXPLOSION, tostring(tpl.radius), tostring(tpl.close_radius))
end)

-- ------------------------------------------------------------------------------------------------ action data
Sog.step("content: action data", function()
    local plague = G.BreedActions[SRC]
    if not plague then
        error("BreedActions." .. SRC .. " missing")
    end
    local A = shallow(plague)
    A.name = NEW

    local liquids = G.LiquidAreaTemplates
    local shoots = G.BreedShootTemplates
    local buffs = G.BuffTemplates or {}
    local function pick(tbl, key, fallback_key, what)
        local v = tbl[key]
        if v == nil then
            Log.e("ACT", "%s %s is missing%s", what, key, fallback_key and (", falling back to " .. fallback_key) or "")
            v = fallback_key and tbl[fallback_key] or nil
        end
        return v
    end
    local function buff(name)
        if name and buffs[name] == nil then
            Log.w("ACT", "buff %s not found in BuffTemplates; on_hit_buff dropped", name)
            return nil
        end
        return name
    end

    local damage_types = G.DamageSettings and G.DamageSettings.damage_types or {}

    local function beam(name, o)
        local d = {
            name = name,
            aoe_bot_threat_duration = 1.5,
            aoe_bot_threat_timing = 0.05,
            aoe_bot_threat_size = Vector3Box(2.5, 8, 3),
            attack_duration = o.duration,
            attack_finished_grace_period = 0.35,
            attack_intensity_type = "ranged",
            attack_intensities = { elite_ranged = 50, ranged = 50 },
            collision_filter = "filter_minion_shooting_no_friendly_fire",
            dont_follow_target = o.fixed or nil,
            effect_template_name = o.effect,
            exit_after_cooldown = true,
            ground_normal_rotation = o.fixed or nil,
            liquid_paint_brush_size = 2,
            max_liquid_paint_distance = o.paint_distance or 6,
            on_hit_buff = buff(o.buff),
            only_apply_buff_once = true,
            place_liquid_timing_speed = o.speed or 20,
            range_back = 2.75,
            range_percentage_front = 0.5,
            rotation_speed = 8,
            sphere_cast_frequency = 0.2,
            skip_liquid = o.skip_liquid,
            aim_anim_events = { "idle" },
            aim_duration = { idle = o.aim or 0.9 },
            aim_stances = { idle = "standing" },
            end_anim_events = { "idle" },
            end_durations = { idle = 0.4 },
            from_node = FROM_NODE,
            range = o.range,
            min_range = 0,
            radius = o.radius,
            dodge_radius = 0.5,
            liquid_area_template = o.liquid,
            shoot_template = o.shoot,
            trajectory_config = o.trajectory,
            damage_type = o.damage_type,
            stagger_type_reduction = { killshot = 20, ranged = 20 },
        }
        return d
    end

    local bon_traj = G.BoNSettings.trajectory_config
    local ren_traj = G.RenegadeFlamerSettings and G.RenegadeFlamerSettings.trajectory_config or bon_traj
    local cul_traj = G.CultistFlamerSettings and G.CultistFlamerSettings.trajectory_config or ren_traj
    local range = Sog.setting("beam_range") or 22

    A.vomit = beam("vomit", {
        duration = 2.6, effect = C.effects.sog_vomit_beam and "sog_vomit_beam" or "chaos_beast_of_nurgle_vomit", buff = "chaos_beast_of_nurgle_hit_by_vomit",
        liquid = pick(liquids, "beast_of_nurgle_slime", nil, "LiquidAreaTemplates"),
        shoot = pick(shoots, "chaos_beast_of_nurgle_default", nil, "BreedShootTemplates"),
        trajectory = bon_traj, range = range, radius = G.BoNSettings.radius, damage_type = damage_types.minion_vomit, speed = 20, paint_distance = 6, fixed = true,
    })
    A.flame = beam("flame", {
        duration = 3.0, effect = "sog_flame_beam", buff = "renegade_flamer_hit_by_flame",
        liquid = pick(liquids, "renegade_flamer_liquid_paint", nil, "LiquidAreaTemplates"),
        shoot = pick(shoots, "renegade_flamer_default", "chaos_beast_of_nurgle_default", "BreedShootTemplates"),
        trajectory = ren_traj, range = range, radius = 0.2, speed = 7, paint_distance = 4,
    })
    A.tox = beam("tox", {
        duration = 3.4, effect = "sog_tox_beam", buff = "cultist_flamer_hit_by_flame", skip_liquid = true,
        liquid = pick(liquids, "cultist_flamer_liquid_paint", nil, "LiquidAreaTemplates"),
        shoot = pick(shoots, "cultist_flamer_default", "chaos_beast_of_nurgle_default", "BreedShootTemplates"),
        trajectory = cul_traj, range = range, radius = 0.2, speed = 7, paint_distance = 4,
    })

    for _, key in ipairs({ "vomit", "flame", "tox" }) do
        local d = A[key]
        if not d.shoot_template or not d.liquid_area_template then
            error("action " .. key .. " lacks a shoot template or liquid area template")
        end
        if d.effect_template_name == nil or G.EffectTemplates[d.effect_template_name] == nil then
            error("action " .. key .. " effect template " .. tostring(d.effect_template_name) .. " not registered")
        end
    end

    -- the charge away: BtRunAwayAction subclass, see sog_ai.lua
    A.retreat = {
        name = "retreat",
        allow_fallback_movement = false,
        dont_rotate_towards_target = true,
        ground_normal_rotation = false,
        leave_when_reached_destination = false,
        max_duration = 4.2,
        move_anim_event = "move_fwd",
        -- the plague ogryn's own move-start animations (copied from its follow action); BtRunAwayAction wants them keyed by direction
        start_move_anim_events = { fwd = "move_start_fwd", bwd = "move_start_bwd", left = "move_start_left", right = "move_start_right" },
        start_move_anim_data = {
            move_start_fwd = {},
            move_start_bwd = { sign = -1, rad = math.pi },
            move_start_left = { sign = 1, rad = math.pi / 2 },
            move_start_right = { sign = -1, rad = math.pi / 2 },
        },
        start_move_rotation_timings = { move_start_bwd = 0, move_start_fwd = 0, move_start_left = 0, move_start_right = 0 },
        start_rotation_durations = { move_start_bwd = 0.9333333333333333, move_start_fwd = 0, move_start_left = 0.9, move_start_right = 0.9 },
        start_move_event_anim_speed_durations = { move_start_fwd = 0.9333333333333333 },
        speed = Sog.setting("retreat_speed") or 9,
        move_type = "combat_vector",   -- ignored: the node picks its own point; kept so the base class never reads nil
        run_speed = Sog.setting("retreat_speed") or 9,
        stop_distance = 18,
        disable_nav_tag_layers = { "doors", "teleporters", "jumps", "ledges", "ledges_with_fence" },
        main_path_move_settings = { direction = "bwd", min_distance = 2, position_target_side_id = 1,
            travel_distance_random_range = { -20, -10 }, fallback_distance_random_range = { -10, 0 } },
    }

    -- hold position between attacks
    A.hold = { name = "hold", anim_events = "idle" }
    -- the toxbomber-style gas grenade throw: a short pause (the mine itself is simulated in sog_ai), no animation of its own
    A.mine = { name = "mine", anim_events = "idle" }

    -- the close-range stomp is the plague ogryn's own (anim attack_stomp); renamed copy so the tree owns its name
    if plague.plague_stomp then
        A.stomp = shallow(plague.plague_stomp)
        A.stomp.name = "stomp"
    else
        error("plague_stomp action missing from the source actions")
    end

    -- resources (strings under "content/" or "wwise/") the boss needs loaded: explosion, beeps, gas
    local gas_template = liquids.cultist_grenadier_gas
    A.sog_resources = {
        explosion = C.explosion,
        beeps = { events = C.BEEP_EVENTS },
        gas = gas_template,
        mine = { explosion = G.ExplosionTemplates.cultist_grenadier_gas_grenade_impact, gas = liquids.cultist_grenadier_gas, arm = C.MINE_ARM_EVENT, vfx = C.MINE_VFX },
    }
    if not G.ExplosionTemplates.cultist_grenadier_gas_grenade_impact or not liquids.cultist_grenadier_gas then
        Log.e("ACT", "cultist gas grenade templates missing (explosion=%s gas=%s); mines will be disabled", tostring(G.ExplosionTemplates.cultist_grenadier_gas_grenade_impact ~= nil), tostring(liquids.cultist_grenadier_gas ~= nil))
    end
    if not gas_template then
        Log.e("ACT", "LiquidAreaTemplates.cultist_grenadier_gas missing; tox gas pools are disabled")
    end

    pcall(function() G.BreedActions[NEW] = A end)
    if rawget(G.BreedActions, NEW) ~= A then
        rawset(G.BreedActions, NEW, A)
    end
    if rawget(G.BreedActions, NEW) ~= A then
        error("could not register BreedActions")
    end
    C.actions = A
    for _, key in ipairs({ "follow", "idle", "death", "stagger", "change_target", "exit_spawner", "climb", "jump_across", "smash_obstacle", "open_door" }) do
        local d = A[key]
        Log.d("ACT", "reused action %s: %s (name=%s)", key, d and "present" or "MISSING", d and tostring(d.name) or "-")
    end
    Log.i("ACT", "BreedActions.%s registered (%d actions)", NEW, (function() local n = 0 for _ in pairs(A) do n = n + 1 end return n end)())
end)

return C
