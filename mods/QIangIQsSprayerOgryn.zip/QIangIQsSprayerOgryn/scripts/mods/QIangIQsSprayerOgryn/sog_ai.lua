-- QIangIQsSprayerOgryn AI: behaviour tree (plague ogryn tree with the combat node replaced), conditions, enter/leave hooks, the
-- retreat node (BtRunAwayAction subclass) and the tox gas pools. Everything per-frame is wrapped so an error can never crash the
-- behaviour system; errors are logged (rate-limited) and the condition simply reads false.
local mod = get_mod("QIangIQsSprayerOgryn")
local Sog = mod.sog
local Log = Sog.Log
local C = Sog.C
local G = C and C.g
local NEW = Sog.BREED
local SRC = Sog.SRC_BREED

local AI = { state = {} }
Sog.AI = AI
local STATE = AI.state

local function req(path)
    local ok, m = pcall(require, path)
    if ok then
        return m
    end
    Log.e("BOOT", "require(%s) failed: %s", path, tostring(m))
    return nil
end

local function now()
    return Managers.time:has_timer("gameplay") and Managers.time:time("gameplay") or 0
end

-- POSITION_LOOKUP values are frame-temporary vectors; reading one outside the frame it was written in gives a "Stale Vector3"
-- that throws on any use. Always read the live unit position instead.
local function P(unit)
    if unit and Unit.alive(unit) then
        return Unit.world_position(unit, 1)
    end
    return nil
end
AI.P = P

local function S(unit)
    local s = STATE[unit]
    if not s then
        s = { cycle = 1, attack_ready = 0, retreat_ready = 0, stomp_ready = 0, mine_ready = 0, mine_until = 0, counts = {}, born = now(), next_gas = 0, gas_drops = 0 }
        STATE[unit] = s
    end
    return s
end
AI.S = S

local function cfg()
    return Sog.cfg
end

local function target_info(blackboard)
    local p = blackboard.perception
    if not p then
        return nil
    end
    local tu = p.target_unit
    if not tu or not ALIVE[tu] then
        return nil
    end
    return tu, p.target_distance or 999, p.has_line_of_sight
end

-- ------------------------------------------------------------------------------------------------ conditions
local conditions = {}

conditions.sog_stomp = function(unit, bb, sp, args, ad, is_running)
    if is_running then
        return true
    end
    local tu, dist = target_info(bb)
    if not tu then
        return false
    end
    if Sog.force then
        return Sog.force == "stomp"
    end
    return dist <= cfg().stomp_range and now() >= S(unit).stomp_ready
end

conditions.sog_retreat = function(unit, bb, sp, args, ad, is_running)
    if is_running then
        return true
    end
    local tu, dist = target_info(bb)
    if not tu then
        return false
    end
    if Sog.force then
        return Sog.force == "retreat"
    end
    return dist <= cfg().retreat_distance and now() >= S(unit).retreat_ready
end

-- toxbomber-style gas grenade (the "mine" action): lobbed at the target's feet now and then while there is line of sight and some distance
conditions.sog_mine = function(unit, bb, sp, args, ad, is_running)
    local s = S(unit)
    if is_running then
        return now() < s.mine_until
    end
    local tu, dist, los = target_info(bb)
    if not tu then
        return false
    end
    if Sog.force then
        return Sog.force == "mine"
    end
    local c = cfg()
    if now() < s.mine_ready or not los then
        return false
    end
    return dist >= c.mine_min_dist and dist <= c.mine_max_dist
end

local function shoot_condition(kind, index)
    return function(unit, bb, sp, args, ad, is_running)
        if is_running then
            return true
        end
        local tu, dist, los = target_info(bb)
        if not tu then
            return false
        end
        if Sog.force then
            return Sog.force == kind and los == true
        end
        local s = S(unit)
        if now() < s.attack_ready or not los then
            return false
        end
        local c = cfg()
        if dist < c.min_shoot or dist > c.max_shoot then
            return false
        end
        return s.cycle == index
    end
end
conditions.sog_vomit = shoot_condition("vomit", 1)
conditions.sog_flame = shoot_condition("flame", 2)
conditions.sog_tox = shoot_condition("tox", 3)

conditions.sog_hold = function(unit, bb, sp, args, ad, is_running)
    local tu, dist, los = target_info(bb)
    if not tu then
        return false
    end
    if Sog.force == "hold" then
        return true
    end
    return los == true and dist <= cfg().max_shoot
end

conditions.sog_follow = function(unit, bb, sp, args, ad, is_running)
    local tu = target_info(bb)
    return tu ~= nil
end

local function safe(name, fn)
    return function(...)
        local ok, res = pcall(fn, ...)
        if not ok then
            Log.every("cond:" .. name, 5, "E", "BT", "condition %s threw: %s", name, tostring(res))
            return false
        end
        return res
    end
end

-- /sprayer debug and the 1 s snapshots print why each combat condition is or is not true
AI.explain = function(unit)
    local blackboards = rawget(_G, "BLACKBOARDS")
    local bb = blackboards and blackboards[unit]
    if not bb then
        return "no blackboard"
    end
    local out = {}
    for _, name in ipairs({ "sog_stomp", "sog_retreat", "sog_mine", "sog_vomit", "sog_flame", "sog_tox", "sog_hold", "sog_follow" }) do
        local ok, res = pcall(conditions[name], unit, bb, nil, nil, nil, false)
        out[#out + 1] = name:sub(5) .. "=" .. (ok and (res and "Y" or "n") or "ERR")
    end
    return table.concat(out, " ")
end

-- ------------------------------------------------------------------------------------------------ hooks
local function enter_hook(unit, breed, bb, sp, ad, t, args)
    Log.guard_quiet("BT", "sog_enter", function()
        local s = S(unit)
        local name = args and args.name or (ad and ad.name) or "?"
        s.previous = s.current
        s.current, s.current_t = name, t
        s.counts[name] = (s.counts[name] or 0) + 1
        local _, dist, los = target_info(bb)
        Log.d("BT", "ENTER %-9s #%d | dist=%s los=%s cycle=%d unit=%s", name, s.counts[name], dist and string.format("%.1f", dist) or "-", tostring(los), s.cycle, tostring(unit))
        if name == "tox" then
            s.next_gas = t + 0.6
            s.gas_drops = 0
        elseif name == "mine" then
            s.mine_until = t + cfg().mine_duration
            AI.throw_mine(unit, s, t, bb)
        end
    end)
end

local function leave_hook(unit, breed, bb, sp, ad, t, args, reason)
    Log.guard_quiet("BT", "sog_leave", function()
        local s = S(unit)
        local name = args and args.name or "?"
        local c = cfg()
        local dur = s.current_t and (t - s.current_t) or 0
        Log.d("BT", "LEAVE %-9s after %.2fs reason=%s", name, dur, tostring(reason))
        if name == "vomit" or name == "flame" or name == "tox" then
            s.attack_ready = t + c.attack_cooldown
            s.cycle = s.cycle % 3 + 1
            s.last_attack = name
        elseif name == "mine" then
            s.mine_ready = t + c.mine_cooldown
        elseif name == "retreat" then
            s.retreat_ready = t + c.retreat_cooldown
        elseif name == "stomp" then
            s.stomp_ready = t + c.stomp_cooldown
            s.retreat_ready = 0   -- stomp, then charge away
        end
        if s.current == name then
            s.current = nil
        end
        if name ~= "retreat" and dur > 14 then
            Log.w("BT", "action %s ran %.1fs (long); check for a stuck action", name, dur)
        end
    end)
end

local function death_hook(unit, breed, bb, sp, ad, t, args)
    Log.guard("DEATH", "sog_death hook", function()
        Log.i("DEATH", "death node entered for unit %s (last action %s)", tostring(unit), tostring(S(unit).current))
        if Sog.Boss and Sog.Boss.on_death then
            Sog.Boss.on_death(unit)
        else
            Log.e("DEATH", "Sog.Boss.on_death missing; the explosion will not happen")
        end
    end)
end

-- ------------------------------------------------------------------------------------------------ retreat node
local NavQueries = req("scripts/utilities/nav_queries")

Sog.step("ai: retreat node class", function()
    req("scripts/extension_systems/behavior/nodes/actions/bt_run_away")
    local Retreat = rawget(CLASSES, "BtSogRetreatAction") or class("BtSogRetreatAction", "BtRunAwayAction")

    local ANGLES = { 0, 0.5, -0.5, 1.0, -1.0, 1.6, -1.6 }
    local DISTANCES = { 22, 16, 10, 6 }

    Retreat._get_wanted_position = function(self, unit, scratchpad, action_data)
        local pos = P(unit)
        local target = scratchpad.perception_component and scratchpad.perception_component.target_unit
        local away
        if target and ALIVE[target] then
            away = Vector3.flat(pos - P(target))
        else
            away = Vector3.flat(Quaternion.forward(Unit.local_rotation(unit, 1)))
        end
        if Vector3.length(away) < 0.01 then
            away = Vector3(1, 0, 0)
        end
        away = Vector3.normalize(away)
        local nav_world = scratchpad.nav_world
        for _, dist in ipairs(DISTANCES) do
            for _, angle in ipairs(ANGLES) do
                local dir = Quaternion.rotate(Quaternion(Vector3.up(), angle), away)
                local candidate = pos + dir * dist
                local p = NavQueries.position_on_mesh(nav_world, candidate, 2, 2)
                if p then
                    local reachable = true
                    if GwNavQueries and GwNavQueries.raycango then
                        local ok, res = pcall(GwNavQueries.raycango, nav_world, pos, p)
                        if ok and res == false then
                            reachable = false
                        end
                    end
                    if reachable then
                        Log.every("retreat_pick", 1, "D", "BT", "retreat point %.0fm at angle %.1f: %s", dist, angle, tostring(p))
                        return p
                    end
                end
            end
        end
        Log.every("retreat_none", 2, "W", "BT", "retreat found no navmesh point; staying put")
        return pos
    end

    Retreat.run = function(self, unit, breed, blackboard, scratchpad, action_data, dt, t)
        local result, evaluate, update_rate = Retreat.super.run(self, unit, breed, blackboard, scratchpad, action_data, dt, t)
        if result == "running" then
            local target = scratchpad.perception_component and scratchpad.perception_component.target_unit
            if target and ALIVE[target] then
                local dist = Vector3.distance(P(unit), P(target))
                if dist >= action_data.stop_distance then
                    Log.d("BT", "retreat done: %.1fm from the target", dist)
                    return "done"
                end
            end
        elseif result == "failed" then
            Log.w("BT", "retreat failed (no path); falling back to the other actions")
        end
        return result, evaluate, update_rate
    end
    C.RetreatClass = Retreat
end)

-- ------------------------------------------------------------------------------------------------ tox gas pools
local LiquidArea = nil
local function drop_gas(unit, s, t)
    local template = G.LiquidAreaTemplates.cultist_grenadier_gas
    if not template then
        return
    end
    LiquidArea = LiquidArea or req("scripts/extension_systems/liquid_area/utilities/liquid_area")
    local blackboards = rawget(_G, "BLACKBOARDS")
    local bb = blackboards and blackboards[unit]
    local tu = bb and bb.perception and bb.perception.target_unit
    if not tu or not ALIVE[tu] then
        return
    end
    local pos = P(tu)
    local nav_world = Managers.state.nav_mesh:nav_world()
    local liquid_unit = LiquidArea.try_create(pos, Vector3.down(), nav_world, template, unit, nil, true)
    s.gas_drops = s.gas_drops + 1
    Sog.counters.gas_pools = (Sog.counters.gas_pools or 0) + 1
    Log.d("BT", "tox gas pool #%d at target: %s", s.gas_drops, liquid_unit and "created" or "refused (no navmesh or already in liquid)")
end

-- ------------------------------------------------------------------------------------------------ gas mines
-- A toxbomber-style gas grenade is simulated here (no game unit): the marker particle flies a lobbed arc from the boss to the
-- target's feet, then the cultist grenadier gas explosion and gas pool go off where it lands.
local mines = {}
AI.mines = mines

local function destroy_marker(m)
    if m.fx and m.world then
        pcall(World.destroy_particles, m.world, m.fx)
    end
    m.fx = nil
end

local function mine_sound(m)
    local fx = Managers.state.extension and Managers.state.extension:system("fx_system")
    if fx then
        local ok, err = pcall(fx.trigger_wwise_event, fx, C.MINE_ARM_EVENT, m.from:unbox())
        if not ok then
            Log.once("mine:armsound", "W", "BT", "grenade throw sound failed: %s", tostring(err))
        end
    end
end

AI.throw_mine = function(unit, s, t, bb)
    Log.guard("BT", "throw mine", function()
        local tu = bb and bb.perception and bb.perception.target_unit
        if not tu or not ALIVE[tu] then
            Log.w("BT", "mine: no target")
            return
        end
        local c = cfg()
        local tpos = P(tu)
        local angle = math.random() * math.pi * 2
        local radius = (0.4 + math.random() * 0.6) * c.mine_scatter
        local pos = tpos + Vector3(math.cos(angle) * radius, math.sin(angle) * radius, 0)
        local nav_world = Managers.state.nav_mesh:nav_world()
        local on_mesh = NavQueries.position_on_mesh(nav_world, pos, 2, 2) or NavQueries.position_on_mesh(nav_world, tpos, 2, 2)
        if not on_mesh then
            Log.w("BT", "mine: no navmesh point near the target; skipped")
            return
        end
        local from = P(unit) + Vector3(0, 0, 3.2)
        local m = { pos = Vector3Box(on_mesh), from = Vector3Box(from), owner = unit, t0 = t, land = t + c.mine_flight, expire = t + c.mine_flight + 2 }
        local world = Managers.world and Managers.world:world("level_world")
        m.world = world
        local vfx_ok = pcall(function() return Application.can_get("particles", C.MINE_VFX) end)
        if world and vfx_ok and Application.can_get("particles", C.MINE_VFX) then
            local created, id = pcall(World.create_particles, world, C.MINE_VFX, from)
            if created then
                m.fx = id
            else
                Log.w("BT", "mine marker particle failed: %s", tostring(id))
            end
        else
            Log.once("mine:novfx", "W", "BT", "mine marker particle not loaded; mines will be invisible")
        end
        mines[#mines + 1] = m
        Sog.counters.mines_thrown = (Sog.counters.mines_thrown or 0) + 1
        Log.i("BT", "gas grenade #%d thrown, lands %.1fm from the target at (%.1f, %.1f, %.1f) in %.1fs", Sog.counters.mines_thrown, radius,
            Vector3.x(on_mesh), Vector3.y(on_mesh), Vector3.z(on_mesh), c.mine_flight)
        Log.guard_quiet("BT", "grenade throw sound", mine_sound, m)
    end)
end

local function mine_detonate(m)
    local pos = m.pos:unbox()
    local Boss = Sog.Boss
    if Boss and Boss.detonate then
        Boss.detonate(pos, "cultist_grenadier_gas_grenade_impact", Sog.cfg.mine_power, m.owner)
    end
    local template = G.LiquidAreaTemplates.cultist_grenadier_gas
    if template then
        LiquidArea = LiquidArea or req("scripts/extension_systems/liquid_area/utilities/liquid_area")
        local nav_world = Managers.state.nav_mesh:nav_world()
        local owner = m.owner and Unit.alive(m.owner) and m.owner or nil
        local ok, res = pcall(LiquidArea.try_create, pos, Vector3.down(), nav_world, template, owner, nil, true)
        Log.d("BT", "grenade gas pool: %s", ok and (res and "created" or "refused") or tostring(res))
    end
    Sog.counters.mines_detonated = (Sog.counters.mines_detonated or 0) + 1
end

local function update_mines(t)
    for i = #mines, 1, -1 do
        local m = mines[i]
        local remove = false
        if t >= m.land then
            Log.d("BT", "gas grenade landed")
            Log.guard("BT", "grenade detonate", mine_detonate, m)
            remove = true
        elseif m.fx and m.world then
            local frac = math.max(0, math.min(1, (t - m.t0) / (m.land - m.t0)))
            local from, to = m.from:unbox(), m.pos:unbox()
            local pos = Vector3.lerp(from, to, frac) + Vector3(0, 0, 4 * frac * (1 - frac) * 6)
            pcall(World.move_particles, m.world, m.fx, pos)
        end
        if not remove and t >= m.expire then
            remove = true
        end
        if remove then
            destroy_marker(m)
            table.remove(mines, i)
        end
    end
end

AI.clear_mines = function()
    for i = #mines, 1, -1 do
        destroy_marker(mines[i])
        mines[i] = nil
    end
end

-- Turn the body to face the current target while holding, shooting or between actions. The beam action also turns the body
-- while it fires; this covers the rest (the retreat node and stomp steer themselves). No ranged aim extension exists for this
-- breed, so facing is the only tracking.
local FACING = { hold = true, mine = true, vomit = true, flame = true, tox = true, idle = true, none = true }

local function face_target(unit, s)
    local current = s.current or "none"
    if not FACING[current] then
        return
    end
    local blackboards = rawget(_G, "BLACKBOARDS")
    local bb = blackboards and blackboards[unit]
    local tu = bb and bb.perception and bb.perception.target_unit
    if not tu or not ALIVE[tu] then
        return
    end
    local from, to = P(unit), P(tu)
    if not from or not to then
        return
    end
    local flat = Vector3.flat(to - from)
    if Vector3.length_squared(flat) < 0.01 then
        return
    end
    local loco = ScriptUnit.has_extension(unit, "locomotion_system") and ScriptUnit.extension(unit, "locomotion_system")
    if loco and loco.set_wanted_rotation then
        loco:set_wanted_rotation(Quaternion.look(Vector3.normalize(flat), Vector3.up()))
        Sog.counters.face_updates = (Sog.counters.face_updates or 0) + 1
    else
        Log.every("face:noloco", 10, "W", "BT", "no locomotion extension with set_wanted_rotation; cannot face target")
    end
end

AI.update = function(dt, t)
    if #mines > 0 then
        Log.guard_quiet("BT", "update mines", update_mines, t)
    end
    for unit, s in pairs(STATE) do
        if not Unit.alive(unit) then
            STATE[unit] = nil
        else
            if HEALTH_ALIVE and HEALTH_ALIVE[unit] then
                Log.guard_quiet("BT", "face target", face_target, unit, s)
            end
            if s.current == "tox" and t >= s.next_gas and s.gas_drops < cfg().gas_pools_per_attack then
                s.next_gas = t + cfg().gas_interval
                Log.guard_quiet("BT", "tox gas pool", drop_gas, unit, s, t)
            end
        end
    end
end

-- ------------------------------------------------------------------------------------------------ tree
local function hooked(class_name, name, condition, action_data)
    return {
        class_name,
        name = name,
        condition = condition,
        action_data = action_data,
        enter_hook = { hook = "sog_enter", args = { name = name } },
        leave_hook = { hook = "sog_leave", args = { name = name } },
    }
end

Sog.step("ai: conditions and hooks", function()
    for name, fn in pairs(conditions) do
        G.BtConditions[name] = safe(name, fn)
    end
    G.BtEnterHooks.sog_enter = enter_hook
    G.BtLeaveHooks.sog_leave = leave_hook
    G.BtEnterHooks.sog_death = death_hook
    for _, name in ipairs({ "sog_stomp", "sog_retreat", "sog_mine", "sog_vomit", "sog_flame", "sog_tox", "sog_hold", "sog_follow" }) do
        if G.BtConditions[name] == nil then
            error("condition " .. name .. " did not register")
        end
    end
    if G.BtEnterHooks.sog_enter ~= enter_hook or G.BtLeaveHooks.sog_leave ~= leave_hook then
        error("hook tables are read-only")
    end
end)

-- The liquid beam action reads breed.aim_config.node in enter (minion_attack.init_scratchpad_shooting_variables); the aim config is
-- hidden on this breed (see sog_content), so expose it just for that call.
Sog.step("ai: beam enter exposes aim_config", function()
    req("scripts/extension_systems/behavior/nodes/actions/bt_shoot_liquid_beam_action")
    local Beam = rawget(CLASSES, "BtShootLiquidBeamAction")
    if not Beam or type(Beam.enter) ~= "function" then
        error("BtShootLiquidBeamAction.enter not found")
    end
    if not Beam.__sog_wrapped then
        local orig = Beam.enter
        Beam.enter = function(self, unit, breed, ...)
            if breed and breed.sog_boss then
                Sog.expose_aim = true
                local ok, err = pcall(orig, self, unit, breed, ...)
                Sog.expose_aim = false
                if not ok then
                    Log.e("BT", "beam enter threw: %s", tostring(err))
                    error(err)
                end
                return
            end
            return orig(self, unit, breed, ...)
        end
        Beam.__sog_wrapped = true
    end
end)

Sog.step("ai: behaviour tree", function()
    local plague_tree = G.BehaviorTrees[SRC]
    local A = C.actions
    if not plague_tree then
        error("BehaviorTrees." .. SRC .. " missing")
    end
    if not A then
        error("action data missing (content step failed)")
    end

    local combat = {
        "BtSelectorNode",
        hooked("BtMeleeAttackAction", "stomp", "sog_stomp", A.stomp),
        hooked("BtSogRetreatAction", "retreat", "sog_retreat", A.retreat),
        hooked("BtIdleAction", "mine", "sog_mine", A.mine or A.hold or A.idle),
        hooked("BtShootLiquidBeamAction", "vomit", "sog_vomit", A.vomit),
        hooked("BtShootLiquidBeamAction", "flame", "sog_flame", A.flame),
        hooked("BtShootLiquidBeamAction", "tox", "sog_tox", A.tox),
        hooked("BtIdleAction", "hold", "sog_hold", A.hold or A.idle),
        hooked("BtMeleeFollowTargetAction", "follow", "sog_follow", A.follow),
        condition = "is_aggroed",
        name = "sog_combat",
    }

    local tree = {}
    local replaced, death_hooked = false, false
    for i, child in ipairs(plague_tree) do
        if i == 1 then
            tree[1] = child
        elseif type(child) == "table" and child.name == "melee_combat" then
            tree[i] = combat
            replaced = true
        elseif type(child) == "table" and child.name == "death" then
            local d = {}
            for k, v in pairs(child) do
                d[k] = v
            end
            d.enter_hook = { hook = "sog_death", args = { name = "death" } }
            tree[i] = d
            death_hooked = true
        elseif type(child) == "table" and child.name == "idle" then
            local d = {}
            for k, v in pairs(child) do
                d[k] = v
            end
            d.enter_hook = { hook = "sog_enter", args = { name = "idle" } }
            tree[i] = d
        else
            tree[i] = child
        end
    end
    tree.name = NEW
    if not replaced then
        error("the plague ogryn tree has no melee_combat node to replace")
    end
    if not death_hooked then
        Log.w("BT", "no death node found; the death explosion will not trigger")
    end
    G.BehaviorTrees[NEW] = tree
    if rawget(G.BehaviorTrees, NEW) ~= tree then
        rawset(G.BehaviorTrees, NEW, tree)
    end
    if rawget(G.BehaviorTrees, NEW) ~= tree then
        error("could not register the behaviour tree")
    end
    C.tree = tree
    Log.i("BT", "behaviour tree %s registered: %d root children, combat node replaced, death hooked=%s", NEW, #tree, tostring(death_hooked))
end)

return AI
