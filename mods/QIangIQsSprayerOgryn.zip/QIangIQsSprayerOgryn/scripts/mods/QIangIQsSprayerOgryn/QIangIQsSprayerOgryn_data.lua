local mod = get_mod("QIangIQsSprayerOgryn")

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = false,
    options = {
        widgets = {
            { setting_id = "health_multiplier", type = "numeric", default_value = 1, range = { 0.1, 10 }, decimals_number = 1 },
            { setting_id = "explosion_delay", type = "numeric", default_value = 10, range = { 2, 30 }, decimals_number = 0 },
            { setting_id = "explosion_power", type = "numeric", default_value = 4, range = { 0.5, 20 }, decimals_number = 1 },
            { setting_id = "retreat_distance", type = "numeric", default_value = 12, range = { 5, 18 }, decimals_number = 0 },
            { setting_id = "attack_cooldown", type = "numeric", default_value = 2.5, range = { 0.5, 10 }, decimals_number = 1 },
            { setting_id = "spawn_distance", type = "numeric", default_value = 24, range = { 10, 45 }, decimals_number = 0 },
            { setting_id = "beam_range", type = "numeric", default_value = 22, range = { 10, 30 }, decimals_number = 0 },
            { setting_id = "retreat_speed", type = "numeric", default_value = 9, range = { 4, 14 }, decimals_number = 0 },
            {
                setting_id = "game_object_type", type = "dropdown", default_value = "auto",
                options = {
                    { text = "got_auto", value = "auto" },
                    { text = "got_monster", value = "monster" },
                    { text = "got_bon", value = "bon" },
                },
            },
            { setting_id = "verbose", type = "checkbox", default_value = false },
            { setting_id = "snapshots", type = "checkbox", default_value = true },
            { setting_id = "notify_errors", type = "checkbox", default_value = true },
        },
    },
}
