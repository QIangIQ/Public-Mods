
return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsSprayerOgryn` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsSprayerOgryn", {
            mod_script = "QIangIQsSprayerOgryn/scripts/mods/QIangIQsSprayerOgryn/QIangIQsSprayerOgryn",
            mod_data = "QIangIQsSprayerOgryn/scripts/mods/QIangIQsSprayerOgryn/QIangIQsSprayerOgryn_data",
            mod_localization = "QIangIQsSprayerOgryn/scripts/mods/QIangIQsSprayerOgryn/QIangIQsSprayerOgryn_localization",
        })
    end,
    version = "0.1.0",
    author = "QIangIQ",
    packages = {},
}
