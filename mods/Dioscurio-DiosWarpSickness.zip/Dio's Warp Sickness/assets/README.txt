Some of this folder is missing from git on purpose.

Everything drawn for the mod is here: the wheel and its pointer, the void, the
halo, the lasso, the crossbones, the "default" skeleton set. What is NOT here
is the third-party art and audio, and every sound file:

  hogrider/ride_*.png, yell_*.png, hogrider.wav   Clash of Clans, Supercell
  judas/judas.mp3                                 Lady Gaga
  dog/dog.png                                     a photo, source unknown
  skeletons/runner/*.png                          a gif, source unknown
  sniped/sniped.png                               whatever you want it to be
  every .wav                                      skeleton and alert noises

The mod runs without them. Each missing piece simply does not draw or does not
make a noise - nothing errors. To get a complete, working copy, use the release
zip rather than this source tree.

To put your own files in, see the notes in CREDITS.txt and the top of each
module. /warprescan re-reads the asset folders without restarting the game.
