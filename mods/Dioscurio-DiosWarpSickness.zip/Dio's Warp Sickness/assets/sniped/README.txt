sniped.png is whatever you want it to be.

It is drawn in the middle of the screen for about a second and a half when a
sniper hits you. Replace this file with any PNG (transparency works best),
then run /warprescan in chat - no restart needed. It is drawn at the file's
own shape, so it will not be stretched.
