#!/usr/bin/env python3
"""
Generate the Hog Rider's lasso loop: assets/hogrider/lasso_1..N.png

WHY THIS EXISTS
The old lasso was a single flat circle, spun with a rotation angle. Rotating a
circle about its own centre changes nothing on screen, so the "spinning loop"
sat there perfectly still and read as a brown doughnut.

A lasso reads as a lasso because of three things, none of which a circle has:

  1. PERSPECTIVE. The loop is a circle in a near-horizontal plane, so you see
     it as an ellipse squashed vertically. Here that is a 3D circle tilted by
     TILT and projected, which is the same thing but gives the next two for
     free.
  2. THE CROSSING. The near half of the rope passes IN FRONT of the far half.
     Drawing the far half first and the near half over it is what makes it a
     loop in space rather than a ring drawn on glass.
  3. THE TWIST TRAVELLING. The strand marks run around the loop as it turns.
     That is the motion the eye actually tracks; the ellipse itself barely
     changes shape, which is why a plain rotation angle showed nothing.

The honda (the knot the rope runs through) stays at the near-bottom of every
frame on purpose. It is where the mod attaches the rope from the rider's hand,
so it has to be in a known place - a knot wandering round the loop would drag
the rope's end with it.

Frames are a full turn of the loop, so the mod can play them at any speed and
they tile seamlessly.

    python3 gen_lasso.py            # writes into ../assets/hogrider/
"""

import math
import os

from PIL import Image, ImageDraw, ImageFilter

FRAMES = 16
SIZE = 320                  # px, square
CX, CY = SIZE / 2, SIZE / 2

RADIUS = 128.0              # the loop's radius in its own plane
TILT = math.radians(30.0)   # how far the loop is tipped away from edge-on
ROPE = 13.0                 # rope thickness at the near edge

# a bit of life, so it is not a machined ellipse
WOBBLE = 0.035
MARKS = 34                  # strand marks round the loop

DARK = (118, 74, 30)
MID = (167, 112, 44)
LIGHT = (214, 160, 78)
SHADOW = (40, 24, 8)

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets", "hogrider")


def project(phi, spin, wob, tilt=None):
    """A point on the tilted circle, in screen pixels, plus its depth.

    depth is +1 at the nearest point of the loop and -1 at the furthest; it
    drives both the draw order and how thick the rope looks.

    phi is the position round the loop and does NOT include the spin: the
    ellipse keeps its place on screen while the rope runs round inside it.
    """
    t = TILT if tilt is None else tilt
    r = RADIUS * (1.0 + wob * math.sin(2.0 * phi + spin))
    x = CX + r * math.cos(phi)
    depth = math.sin(phi)
    y = CY + r * depth * math.sin(t)
    return x, y, depth


def rope_width(depth):
    # nearer rope is thicker: a plain perspective cue, and it keeps the
    # crossing readable where the two halves meet
    return ROPE * (0.72 + 0.28 * (depth * 0.5 + 0.5))


def draw_strand(d, p0, p1, depth, colour, width):
    d.line([p0, p1], fill=colour, width=max(1, int(round(width))))


def draw_arc(d, spin, wob, lo, hi, steps=90, tilt=None, bias=0.0):
    """Draw the piece of the loop between angles lo..hi, back to front."""
    pts = []
    for i in range(steps + 1):
        phi = lo + (hi - lo) * i / steps
        x, y, dep = project(phi, spin, wob, tilt)
        pts.append((x, y + bias, dep))

    # the rope body
    for i in range(len(pts) - 1):
        x0, y0, d0 = pts[i]
        x1, y1, d1 = pts[i + 1]
        depth = (d0 + d1) * 0.5
        w = rope_width(depth)
        shade = DARK if depth < -0.15 else MID
        draw_strand(d, (x0, y0), (x1, y1), depth, shade, w)

    # the twist: short marks across the rope, lighter on the near side
    # The marks are placed at real angles that advance with the spin, not at
    # integer steps along the point list. Indexing the list quantised the
    # travel to almost nothing over a full turn, which looked frozen - the
    # same failure as the old rotating circle, one level down.
    #
    # Over one full cycle of `spin` each mark moves exactly one mark spacing,
    # so the frames loop seamlessly.
    span = hi - lo
    gap = 2.0 * math.pi / MARKS
    j0 = math.ceil((lo - spin / MARKS) / gap)

    for j in range(j0, j0 + int(span / gap) + 2):
        phi = j * gap + spin / MARKS

        if phi < lo or phi > hi:
            continue

        x0, y0, d0 = project(phi, spin, wob, tilt)
        x1, y1, _ = project(phi + 0.02, spin, wob, tilt)
        y0 += bias
        y1 += bias

        dx, dy = x1 - x0, y1 - y0
        n = math.hypot(dx, dy) or 1.0
        dx, dy = dx / n, dy / n
        ax, ay = -dy, dx
        lean = 0.55
        w = rope_width(d0)
        hx = (ax + dx * lean) * w * 0.46
        hy = (ay + dy * lean) * w * 0.46
        col = LIGHT if d0 > -0.15 else MID
        draw_strand(d, (x0 - hx, y0 - hy), (x0 + hx, y0 + hy), d0, col, max(1, w * 0.42))


def honda_xy(spin, wob, tilt):
    """Where the rope from the hand meets the loop. Always the near-bottom."""
    return project(math.pi / 2, spin, wob, tilt)


def draw_knot(d, spin, wob, tilt, bias):
    """The honda: the small ring the rope runs through, at the near edge."""
    x, y, depth = honda_xy(spin, wob, tilt)
    y += bias
    w = rope_width(depth)
    r = w * 0.95

    d.ellipse([x - r, y - r * 0.78, x + r, y + r * 0.78],
              fill=MID, outline=(60, 36, 14), width=2)
    d.ellipse([x - r * 0.40, y - r * 0.32, x + r * 0.40, y + r * 0.32],
              fill=(70, 44, 18, 255))


def frame(k):
    spin = 2.0 * math.pi * k / FRAMES
    wob = WOBBLE

    # the loop tips a little as it goes round, which is most of what stops it
    # looking like a decal
    tilt = TILT * (1.0 + 0.16 * math.sin(spin))
    bias = 3.0 * math.sin(spin + 0.6)

    img = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))

    # a soft shadow under the loop so it sits in the air rather than on glass
    shade = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    ImageDraw.Draw(shade).ellipse(
        [CX - RADIUS * 1.02, CY - RADIUS * math.sin(tilt) * 1.25,
         CX + RADIUS * 1.02, CY + RADIUS * math.sin(tilt) * 1.25],
        outline=(0, 0, 0, 105), width=int(ROPE * 1.4))
    img.alpha_composite(shade.filter(ImageFilter.GaussianBlur(5)), (0, 6))

    d = ImageDraw.Draw(img, "RGBA")

    # The far half first, then the near half over the top. The two arcs overlap
    # slightly past the honda, so the rope genuinely crosses itself there
    # instead of the ends meeting in a seam - that overlap is what reads as a
    # loop in space rather than a ring drawn flat.
    draw_arc(d, spin, wob, -math.pi, 0.0, steps=120, tilt=tilt, bias=bias)
    draw_arc(d, spin, wob, 0.0 - 0.30, math.pi + 0.30, steps=130, tilt=tilt, bias=bias)
    draw_knot(d, spin, wob, tilt, bias)

    return img


def main():
    os.makedirs(OUT, exist_ok=True)
    for k in range(FRAMES):
        img = frame(k)
        path = os.path.join(OUT, "lasso_%d.png" % (k + 1))
        img.save(path)
    print("wrote %d frames to %s" % (FRAMES, os.path.normpath(OUT)))
    print("FRAMES = %d  (DWS_hog.lua LASSO_FRAMES must match)" % FRAMES)


if __name__ == "__main__":
    main()
