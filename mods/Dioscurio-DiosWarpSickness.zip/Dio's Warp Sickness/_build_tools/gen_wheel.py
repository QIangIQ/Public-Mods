# Generates assets/wheel/wheel.png AND the SEGMENTS table for DWS_wheel.lua from one list,
# so the picture and the code can never drift apart.
# Slice widths are the real odds: NORMAL takes its chance setting, the rest share the remainder.
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import math, sys

NORMAL_PCT = 20.0
SEG = [("whirlpool","WHIRLPOOL"),("skarmy","SKARMY"),("flip","UPSIDE DOWN"),("hog","HOG RIDER"),
       ("blackhole","BLACK HOLE"),("void","THE VOID"),("rave","RAVE"),("dyslexia","DYSLEXIA"),
       ("mirror","MIRROR"),("badtrip","BAD TRIP"),("melt","MELT"),("spin","SPIN"),("normal","NORMAL")]
COL = {"normal": (40,150,70), "hog": (225,120,150)}
ALT = [(150,20,20),(28,24,24),(190,140,40)]

others = [s for s in SEG if s[0] != "normal"]
share = (100.0 - NORMAL_PCT) / len(others)
pct = {k: (NORMAL_PCT if k == "normal" else share) for k, _ in SEG}

S, R, C = 1024, 490, 512
im = Image.new("RGBA", (S, S), (0,0,0,0)); d = ImageDraw.Draw(im)
font  = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansCondensed-Bold.ttf", 46)
fsmall= ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansCondensed-Bold.ttf", 38)

d.ellipse([C-R-18,C-R-18,C+R+18,C+R+18], fill=(70,50,20,255))
d.ellipse([C-R-10,C-R-10,C+R+10,C+R+10], fill=(212,170,60,255))

a = -90.0
spans = []
for k,(key,label) in enumerate(SEG):
    span = 360.0 * pct[key] / 100.0
    col = COL.get(key, ALT[k % 3])
    d.pieslice([C-R,C-R,C+R,C+R], a, a+span, fill=col+(255,), outline=(20,10,5,255), width=4)
    spans.append((key, label, a, a+span))
    a += span

for key,label,s,e in spans:
    mid = math.radians((s+e)/2)
    f = font if (e-s) > 20 else fsmall
    tw = d.textlength(label, font=f); th = f.getbbox(label)[3]
    t = Image.new("RGBA", (int(tw)+12, th+14), (0,0,0,0)); td = ImageDraw.Draw(t)
    fill = (60,20,30,255) if key == "hog" else (230,255,230,255) if key == "normal" else (255,240,200,255)
    td.text((6,4), label, font=f, fill=fill, stroke_width=3,
            stroke_fill=(255,230,240,255) if key == "hog" else (0,0,0,255))
    rt = t.rotate(-math.degrees(mid)+180, expand=True, resample=Image.BICUBIC)
    rr = R - 40 - tw/2
    im.alpha_composite(rt, (int(C+rr*math.cos(mid)-rt.width/2), int(C+rr*math.sin(mid)-rt.height/2)))

for k in range(24):
    ang = 2*math.pi*k/24; x = C+(R+4)*math.cos(ang); y = C+(R+4)*math.sin(ang)
    d.ellipse([x-7,y-7,x+7,y+7], fill=(255,240,180,255), outline=(90,60,20,255), width=2)
d.ellipse([C-80,C-80,C+80,C+80], fill=(212,170,60,255), outline=(70,50,20,255), width=8)
d.ellipse([C-58,C-58,C+58,C+58], fill=(30,20,20,255))
q = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 84)
tw = d.textlength("?", font=q); d.text((C-tw/2, C-52), "?", font=q, fill=(212,170,60,255))
im.save(sys.argv[1] if len(sys.argv) > 1 else "wheel.png")

print("local SEGMENTS = {")
for key,label,s,e in spans:
    print('\t{ "%s", "%s", %.5f, %.5f },' % (key, label, math.radians(s), math.radians(e)))
print("}")
print("-- widths (deg / percent):", [(round(e-s,2), round(pct[k],2)) for k,_,s,e in spans])
