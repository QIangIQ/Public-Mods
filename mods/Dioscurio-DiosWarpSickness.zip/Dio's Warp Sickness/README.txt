DIO'S WARP SICKNESS  1.0.1
by Dioscurio

A joke HUD mod. Your HUD hallucinates. It drifts around the screen, spins,
changes colour and the text goes dyslexic. Skeletons run across the screen in
every direction. Every half minute or so a prize wheel turns up and decides
what happens to you next.

Everything stays readable on purpose: elements are kept inside the screen,
teammate panels snap back to the bottom left for a few seconds when that
teammate's ability comes up, the peril gauge keeps its real colours, and the
specials tracker stays dark and legible while everything around it changes.

Private build. Please do not upload it anywhere.


WHAT YOU NEED FIRST

  Darktide Mod Framework    required
  SimpleAssets              required - this is what loads the pictures
  SimpleAudio               optional - sound

Both of the optional/required extras are on Nexus Mods.

Without SimpleAssets nothing draws at all: no skeletons, no wheel, no dog, no
void, no Hog Rider. The mod will load and look like it is doing nothing.

Without SimpleAudio it all still works, it is just silent. (Dio's Handholder
carries its own copy of the same audio runtime, so that works too if you
happen to have it.) Judas mode needs a backend that can stop a sound; if it
cannot, the track plays through once instead of looping.


INSTALL

  1. Put the "Dio's Warp Sickness" folder into
       ...\steamapps\common\Warhammer 40,000 DARKTIDE\mods\

  2. Open mods\mod_load_order.txt and add this line somewhere below
     SimpleAssets:

       Dio's Warp Sickness

  3. Start the game. Everything is in Mod Options, under Dio's Warp Sickness.

Keep the folder named exactly "Dio's Warp Sickness". The script paths inside
point at that name.


WHAT IT DOES

Reactive mode ties the madness to what is happening: gas, corruption, peril,
stimms, low health, being in a fight. Constant mode just runs it all the
time. Both are switches in the options.

Episodes land every so often and last a few seconds each: whirlpool, black
hole, upside down, spin, carousel, quake, scatter, mirror, melt, rave. Each
one has its own likelihood slider, plus an overall frequency slider.

Skeletons run across the screen at any angle and any size, with a noise. You
can add your own set: see assets\skeletons\spooky\PUT_FILES_HERE.txt.

Alerts fly across the middle with a pinging red and white crossbones.

Motion follow is off by default. Turn it on and the HUD gets thrown around
when you jump, fall and dodge.

The Wheel of Misfortune spins up every 30 seconds or so and does whatever it
lands on. Thirteen slices. The widths are the real odds, so the big green
NORMAL wedge really is a 1 in 5 chance of everything switching off for a
while - and the dog turning up to tell you it is going to be alright.

The Hog Rider screams, charges in on his pig, throws a lasso around a piece
of your HUD and drags it off the side of the screen. It falls back in a
couple of seconds later.

The Void opens as a black dot somewhere on the screen and slowly grows until
it has eaten a fifth of it. Nothing shows through.

Judas mode is the one that is not a joke. When you are the only one left
standing, or three bosses are on you at once, or you hit the sober keybind,
the HUD snaps back to completely normal, the dog appears on the right, and
Judas loops until it is over.


CHAT COMMANDS

  /warpsick        what the mod currently thinks is going on
  /warpwheel       spin the wheel now; on, off or a slice name
  /warpjudas       Judas mode: shows its state, or on / off / auto
  /warphog         HOG RIDAAAA
  /warpvoid        open the void
  /warpdog         the dog
  /warpsniped      the sniped picture
  /warpskel        summon skeletons
  /warpalert       fire an alert
  /warpep          start an episode by name
  /warptrip        set the trip intensity
  /warprescan      re-read the asset folders without restarting
  /warpsober       there is also a keybind for this in the options


SETTINGS WORTH KNOWING

  Wheel size            raise it if you play at a low resolution
  Episode frequency     how often anything happens at all
  Colour strength       and Colour speed, if the rainbow is too much
  Judas volume          goes to 400, with a switch to ignore the game's
                        own volume sliders if you want to feel it
  Bosses needed         how many bosses trigger Judas mode
  Dog size              he is the best part


ADDING YOUR OWN STUFF

  assets\skeletons\<name>\     numbered PNG frames plus a set.txt
  assets\sniped\sniped.png     the picture when a sniper hits you
  assets\alerts\alerts.txt     one alert line per line of the file
  assets\wheel\                regenerate with _build_tools\gen_wheel.py if
                               you change the slice list

Run /warprescan after changing any of it.


CREDITS AND LICENCE

See CREDITS.txt. Short version: several of the assets are third party and are
not mine to give away, which is why this is a private build and not something
to post. Parts of the drawing code came from Hud Studio, which is GPLv3.
