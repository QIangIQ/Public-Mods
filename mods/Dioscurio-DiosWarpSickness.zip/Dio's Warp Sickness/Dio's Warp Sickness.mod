return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`Dio's Warp Sickness` encountered an error loading the Darktide Mod Framework.")

		new_mod("DiosWarpSickness", {
			mod_script       = "Dio's Warp Sickness/scripts/mods/DiosWarpSickness/DiosWarpSickness",
			mod_data         = "Dio's Warp Sickness/scripts/mods/DiosWarpSickness/DiosWarpSickness_data",
			mod_localization = "Dio's Warp Sickness/scripts/mods/DiosWarpSickness/DiosWarpSickness_localization",
		})
	end,
	version = "1.2.1",
	packages = {},
}
