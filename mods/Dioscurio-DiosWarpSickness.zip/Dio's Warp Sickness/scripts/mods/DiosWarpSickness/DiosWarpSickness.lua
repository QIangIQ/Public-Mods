local mod = get_mod("DiosWarpSickness")

--[[
    ========================================================================
    DIO'S WARP SICKNESS
    ========================================================================

    One number drives everything: W.intensity, 0 to 1.

        constant mode  a steady baseline that slowly breathes
        reactive mode  rises with gas, corruption, peril, stimms, low health
                       and heavy fighting, then wears off slowly
        both on        combined, so the triggers stack on top of the baseline

    The effects read that number:

        DWS_motion     floating, orbiting, rotating, recoloured HUD; episodes
        DWS_passes     draws HUD passes rotated, and scrambled text
        DWS_alerts     the flying skull-and-crossbones alerts
        DWS_scramble   scrambled HUD and subtitle text
        DWS_outlines   breathing / rainbow enemy outlines
        DWS_skeleton   skeletons, drawn by HudElementDiosWarpSickness
        DWS_wheel      the Wheel of Misfortune and the dog
        DWS_void       the void: a black hole in the screen itself
        DWS_sniped     the picture that lands when a sniper hits you
        DWS_judas      Judas mode: HUD back to normal when it gets serious
        DWS_hog        the Hog Rider, who lassoes HUD elements

    Everything is client side and visual. Nothing is sent to the server or
    to other players.

    Nothing native is loaded at mod load. Textures and sound go through
    SimpleAssets and Handholder's audio module, and both are first touched on
    an ordinary frame inside a mission.
--]]

local PlayerUnitStatus = require("scripts/utilities/attack/player_unit_status")

local W = mod.__dws or {}

mod.__dws = W

W.S = W.S or {}
W.t = W.t or 0
W.intensity = 0
W.constant = 0
W.reactive = 0
W.reactive_target = 0
W.sources = W.sources or {}
W.downed = setmetatable({}, { __mode = "k" })
W.active = false
W.in_mission = false
W.motion_live = false
W.motion_on = false
W.scramble_live = false
W.in_hud = false
W.in_text_scope = false
W.force_dirty = false
W.episode = nil
W.tint = 0
W.hue_speed = 0.1
W.xf = nil
W.follow_x, W.follow_y, W.follow_zoom = 0, 0, 0
W.hub_chat = false
W.sober = W.sober or false
W.kid = nil
W.calm_until = nil
W.dyslexia_until = nil

local SETTING_IDS = {
	"throw_aim", "throw_input", "throw_world", "throw_fullscreen", "throw_spectate", "throw_prologue",
	"constant_mode", "constant_strength", "reactive_mode", "reactive_strength", "anim_rate", "chaos_level",
	"fx_motion", "motion_size", "fx_rotate", "fx_colors", "fx_episodes", "fx_sink", "fx_scramble",
	"scramble_numbers", "fx_outlines",
	"fx_skeleton", "skeletons_per_minute", "skeleton_on_downed", "skeleton_on_peak", "skeleton_volume",
	"fx_alerts", "alerts_per_minute", "fx_follow", "follow_strength", "fx_chat_chaos", "fx_chat_pong", "fx_menus",
	"colour_strength", "colour_speed", "episode_frequency",
	"fx_wheel", "wheel_interval", "wheel_normal_chance", "normal_duration", "fx_hog", "hog_interval", "hog_volume",
	"fx_void", "void_size", "void_grow", "void_interval", "fx_dog", "dog_size", "fx_sniped", "sniped_size",
	"fx_judas", "judas_bosses", "judas_volume", "judas_absolute", "wheel_size",
	"ep_whirlpool", "ep_blackhole", "ep_flip", "ep_spin", "ep_carousel", "ep_quake", "ep_scatter", "ep_mirror", "ep_melt", "ep_rave",
	"trig_gas", "trig_corruption", "trig_peril", "trig_stimm", "trig_health", "trig_combat",
}

local function refresh_settings()
	local S = W.S

	for i = 1, #SETTING_IDS do
		local id = SETTING_IDS[i]
		S[id] = mod:get(id)
	end
end

refresh_settings()

local Warning = mod:io_dofile("Dio's Warp Sickness/scripts/mods/DiosWarpSickness/DWS_warning")
local Motion = mod:io_dofile("Dio's Warp Sickness/scripts/mods/DiosWarpSickness/DWS_motion")
local Scramble = mod:io_dofile("Dio's Warp Sickness/scripts/mods/DiosWarpSickness/DWS_scramble")
local Outlines = mod:io_dofile("Dio's Warp Sickness/scripts/mods/DiosWarpSickness/DWS_outlines")
local Skel = mod:io_dofile("Dio's Warp Sickness/scripts/mods/DiosWarpSickness/DWS_skeleton")
local Alerts = mod:io_dofile("Dio's Warp Sickness/scripts/mods/DiosWarpSickness/DWS_alerts")
local Passes = mod:io_dofile("Dio's Warp Sickness/scripts/mods/DiosWarpSickness/DWS_passes")
local Wheel = mod:io_dofile("Dio's Warp Sickness/scripts/mods/DiosWarpSickness/DWS_wheel")
local Hog = mod:io_dofile("Dio's Warp Sickness/scripts/mods/DiosWarpSickness/DWS_hog")
local Void = mod:io_dofile("Dio's Warp Sickness/scripts/mods/DiosWarpSickness/DWS_void")
local Sniped = mod:io_dofile("Dio's Warp Sickness/scripts/mods/DiosWarpSickness/DWS_sniped")
local Judas = mod:io_dofile("Dio's Warp Sickness/scripts/mods/DiosWarpSickness/DWS_judas")

Passes.init(Scramble)

mod:register_hud_element({
	class_name = "HudElementDiosWarpSickness",
	filename = "Dio's Warp Sickness/scripts/mods/DiosWarpSickness/HudElementDiosWarpSickness",
	use_hud_scale = false,
	visibility_groups = {
		"alive",
		"dead",
		"communication_wheel",
		"tactical_overlay",
		"player_in_danger_zone",
	},
})

--[[
    The HUD draw is the one scope where text gets scrambled and offsets are
    applied. The stack is reset here every frame, so a draw that ever errored
    mid-way cannot leave a stale offset behind for the next one.
--]]
mod:hook("UIHud", "draw", function(func, self, ...)
	Motion.reset_stack()

	W.in_hud = true
	W.in_text_scope = true

	func(self, ...)

	W.in_hud = false
	W.in_text_scope = false
end)

-- ---------------------------------------------------------------- helpers

local HUB_MODES = { hub = true, prologue_hub = true }

local function in_mission()
	local state = Managers.state
	local gm = state and state.game_mode

	if not gm or not gm.game_mode_name then
		return false
	end

	local ok, name = pcall(gm.game_mode_name, gm)

	return ok and name ~= nil and not HUB_MODES[name]
end

--[[
    The same destroyed-object guard as the teammate scan below. This is the
    local player rather than a remote one, which is safer, but a host
    migration can leave even this object dead, and reading a property off a
    dead one raises instead of returning nil. It is called every frame, so the
    pcall is on a plain function rather than a closure.
--]]
local function read_unit_of(player)
	return player.player_unit
end

local function local_unit()
	local pm = Managers.player
	local ok_p, player = pcall(function()
		return pm and pm.local_player_safe and pm:local_player_safe(1)
	end)

	if not ok_p then
		return nil, nil
	end

	if not player then
		return nil, nil
	end

	local ok, unit = pcall(read_unit_of, player)

	if not ok then
		return nil, nil
	end

	if unit and Unit.alive(unit) then
		return unit, player
	end

	return nil, player
end

--[[
    BEING SNIPED

    Only the attack report knows who shot you: the damage indicator event
    carries an angle and nothing else (attack_report_manager.lua
    _trigger_damage_indicator). So the report is hooked instead, and the first
    thing the handler does is compare the attacked unit against the cached one
    - this runs for every attack result the client is told about, which in a
    horde is a lot, so it has to stay that cheap.
--]]
local SNIPER_BREEDS = {
	renegade_sniper = true,
}

local SNIPED_LINES = {
	"SNIPED",
	"YOU HAVE BEEN SNIPED",
	"THAT RED LINE WAS A CLUE",
	"SKELETON SNIPER 1, BOBBYMAN 0",
	"SHOT FROM A POSTCODE AWAY",
	"THE SNIPER SENDS HIS REGARDS",
	"SOMEBODY IS WATCHING YOU THROUGH A SCOPE",
	"GET BEHIND SOMETHING",
}

local last_sniped = -100

mod:hook_safe("AttackReportManager", "_process_attack_result", function(self, buffer_data)
	local S = W.S

	if not (W.active and S.fx_sniped) or type(buffer_data) ~= "table" then
		return
	end

	local me = W.me

	if not me or buffer_data.attacked_unit ~= me or (buffer_data.damage or 0) <= 0 then
		return
	end

	local attacker = buffer_data.attacking_unit
	local unit_data = attacker and ScriptUnit.has_extension(attacker, "unit_data_system")
	local breed = unit_data and unit_data.breed and unit_data:breed()

	if not breed or not SNIPER_BREEDS[breed.name] then
		return
	end

	if W.t - last_sniped < 4 then
		return
	end

	last_sniped = W.t

	Sniped.hit()

	if S.fx_alerts then
		Alerts.fire(SNIPED_LINES[math.random(#SNIPED_LINES)], "center")
	end

	if S.fx_skeleton then
		Skel.summon(nil, math.random(1, 2))
	end
end)

local function clamp01(v)
	if v ~= v or v < 0 then
		return 0
	elseif v > 1 then
		return 1
	end

	return v
end

-- ---------------------------------------------------------------- reactive

--[[
    Each source is 0..1; they combine as 1 - product(1 - s), so two medium
    sources make a strong trip and nothing ever passes 1.
--]]
local function sample_reactive()
	local S = W.S
	local src = W.sources

	for k in pairs(src) do
		src[k] = nil
	end

	local unit = local_unit()

	if not unit then
		return 0
	end

	local buff = ScriptUnit.has_extension(unit, "buff_system")
	local health = ScriptUnit.has_extension(unit, "health_system")
	local unit_data = ScriptUnit.has_extension(unit, "unit_data_system")
	local music = ScriptUnit.has_extension(unit, "music_parameter_system")

	local function has_keyword(keyword)
		if not buff or not buff.has_keyword then
			return false
		end

		local ok, result = pcall(buff.has_keyword, buff, keyword)

		return ok and result
	end

	if S.trig_gas then
		if has_keyword("in_toxic_gas") then
			src.gas = 0.85
		end

		if has_keyword("puked_on") then
			src.vomit = 0.7
		end
	end

	if S.trig_stimm and has_keyword("stimmed") then
		src.stimm = 0.45
	end

	if health then
		if S.trig_corruption and health.permanent_damage_taken_percent then
			local ok, c = pcall(health.permanent_damage_taken_percent, health)

			if ok and c and c > 0.01 then
				src.corruption = clamp01(c * 1.4)
			end
		end

		if S.trig_health and health.current_health_percent then
			local ok, hp = pcall(health.current_health_percent, health)

			if ok and hp and hp < 0.3 then
				src.low_health = clamp01((0.3 - hp) / 0.3) * 0.55
			end
		end
	end

	if S.trig_peril and unit_data then
		local ok, wc = pcall(unit_data.read_component, unit_data, "warp_charge")
		local peril = ok and wc and wc.current_percentage or 0

		if peril > 0.5 then
			src.peril = clamp01((peril - 0.5) * 2) * 0.9
		end
	end

	if S.trig_combat and music then
		local ok_b, boss = pcall(music.boss_near, music)

		if ok_b and boss then
			src.boss = 0.3
		end

		local ok_i, ip = pcall(music.intensity_percent, music)

		if ok_i and type(ip) == "number" then
			if ip > 1 then
				ip = ip / 100
			end

			if ip > 0.2 then
				src.combat = clamp01(ip) * 0.3
			end
		end
	end

	local keep = 1

	for _, v in pairs(src) do
		keep = keep * (1 - v)
	end

	return 1 - keep
end

-- ---------------------------------------------------------------- teammates

--[[
    A Player who has left the game is a destroyed object: reading ANY property
    off one raises rather than returning nil, player_unit included. A
    disconnect used to throw here every frame, which aborted the whole mod
    update - so nothing else in it ran, including the code that stops the
    Judas track. See DWS_motion.lua for the same guard.
--]]
local function read_player_unit(player)
	return player.player_unit
end

local function safe_player_unit(player)
	if not player then
		return nil
	end

	local ok, unit = pcall(read_player_unit, player)

	return ok and unit or nil
end

local function scan_teammates(on_downed)
	local pm = Managers.player

	if not pm or not pm.players then
		return
	end

	local own = local_unit()
	local seen = {}

	for _, player in pairs(pm:players()) do
		local unit = safe_player_unit(player)

		if unit and unit ~= own and Unit.alive(unit) then
			seen[unit] = true

			local unit_data = ScriptUnit.has_extension(unit, "unit_data_system")
			local ok, cs = pcall(unit_data and unit_data.read_component or function() end, unit_data, "character_state")
			local down = false

			if ok and cs then
				down = PlayerUnitStatus.is_knocked_down(cs) or PlayerUnitStatus.is_hogtied(cs)
			end

			if down and not W.downed[unit] then
				on_downed(unit)
			end

			W.downed[unit] = down or nil
		end
	end

	for unit in pairs(W.downed) do
		if not seen[unit] then
			W.downed[unit] = nil
		end
	end
end

-- ---------------------------------------------------------------- episodes

--[[
    The chaos director. Between episodes there is a short random gap that
    shrinks as intensity and the chaos level go up; at the defaults something
    new starts every few seconds. Each episode is read by DWS_motion.
--]]
local EPISODES = {
	{ "whirlpool", 40, 4.5, 6.5 },
	{ "blackhole", 35, 4.5, 6.5 },
	{ "flip", 30, 3, 5 },
	{ "spin", 30, 3, 5 },
	{ "carousel", 25, 3, 4 },
	{ "quake", 25, 2, 3 },
	{ "scatter", 25, 3, 4.5 },
	{ "mirror", 25, 3, 5 },
	{ "melt", 25, 3, 4 },
	{ "rave", 30, 3, 5 },
}

local EPISODE_WARNINGS = {
	whirlpool = { "WHIRLPOOL DETECTED", "SPIN CYCLE ENGAGED", "HUD FLUSH IN PROGRESS", "WARP VORTEX FORMING" },
	blackhole = { "BLACK HOLE INCOMING", "GRAVITATIONAL ANOMALY DETECTED", "HUD SPAGHETTIFICATION IMMINENT", "EVENT HORIZON REACHED" },
	flip = { "GRAVITY REVERSED", "AUSTRALIA MODE" },
	spin = { "SPIN TO WIN", "ROTATIONAL INCURSION" },
	carousel = { "ALL ABOARD THE CAROUSEL" },
	quake = { "SEISMIC ACTIVITY DETECTED", "THE HIVE IS SHAKING" },
	scatter = { "HUD DISPERSAL EVENT" },
	mirror = { "REALITY MIRRORED" },
	melt = { "THE HUD IS MELTING" },
	rave = { "WARP RAVE IN PROGRESS" },
}

local EPISODE_BY_NAME = {}
local EPISODE_WEIGHT = 0

for _, e in ipairs(EPISODES) do
	EPISODE_BY_NAME[e[1]] = e
	EPISODE_WEIGHT = EPISODE_WEIGHT + e[2]
end

local episode_gap = 3

-- each episode's weight is its own slider (0 turns that episode off)
local function episode_weight(e)
	local v = W.S["ep_" .. e[1]]

	return type(v) == "number" and v or e[2]
end

local function start_episode(name, forced)
	local e = name and EPISODE_BY_NAME[name]

	if not e then
		local total = 0

		for _, cand in ipairs(EPISODES) do
			total = total + episode_weight(cand)
		end

		if total <= 0 then
			return nil
		end

		local roll = math.random() * total

		for _, cand in ipairs(EPISODES) do
			roll = roll - episode_weight(cand)

			if roll <= 0 then
				e = cand
				break
			end
		end

		e = e or EPISODES[1]
	end

	W.episode = {
		name = e[1],
		t = 0,
		p = 0,
		dur = e[3] + math.random() * (e[4] - e[3]),
		dir = math.random() < 0.5 and 1 or -1,
		corner = math.random(4),
		forced = forced,
	}

	local S = W.S

	if S.fx_skeleton and math.random() < 0.4 then
		Skel.summon(nil, math.random(1, 3))
	end

	-- whirlpools and black holes always announce themselves; the rest sometimes
	local warnings = EPISODE_WARNINGS[e[1]]

	if S.fx_alerts and warnings and (e[1] == "whirlpool" or e[1] == "blackhole" or math.random() < 0.35) then
		Alerts.fire(warnings[math.random(#warnings)], "center")
	elseif S.fx_alerts and math.random() < 0.2 then
		Alerts.fire()
	end

	return W.episode
end

local function skeleton_army()
	if W.S.fx_skeleton then
		Skel.summon(nil, 6)
	end

	if W.S.fx_alerts then
		Alerts.fire("SKARMY ALERT")
	end
end

local function update_episodes(dt)
	local S = W.S
	local ep = W.episode

	if ep then
		ep.t = ep.t + dt
		ep.p = math.min(1, ep.t / ep.dur)

		-- the wheel's episodes run even with random episodes switched off
		if ep.t >= ep.dur or not W.active or (not S.fx_episodes and not ep.forced) then
			W.episode = nil
		end

		return
	end

	if not (W.active and S.fx_episodes) then
		return
	end

	local chaos = (S.chaos_level or 80) / 100

	if chaos <= 0 then
		return
	end

	episode_gap = episode_gap - dt

	if episode_gap <= 0 then
		start_episode()

		-- "Episode frequency" 50 is the old pace; 100 is twice as often, 10 is five times rarer
		local freq = math.max((S.episode_frequency or 40) / 50, 0.05)

		episode_gap = (1 + math.random() * (1.5 + 5 * (1 - W.intensity))) / chaos / freq
	end
end

-- ---------------------------------------------------------------- follow mode

--[[
    The HUD is thrown the way you move. Your velocity (the "locomotion"
    component, velocity_current, m/s) is turned into your own frame using the
    camera's rotation (the "first_person" component), so:

        moving up   (jump)      everything slams to the top
        moving down (falling)   everything drops to the bottom
        left / right (dodges)   everything slams left / right
        fast forward (lunge, slide)   everything rushes to the middle
        backwards (back dodge)        everything is blown out to the edges

    Targets are bigger than the screen on purpose: DWS_motion keeps every
    element inside the screen, so they pile up hard against the edge. The
    offset follows the target on an underdamped spring, so it overshoots and
    bounces when you stop, and a hard landing kicks it downward.
--]]
local follow = { vx = 0, vy = 0, vz = 0, was_on_ground = true, fall_speed = 0 }

local function follow_update(dt)
	local S = W.S
	local strength = (S.follow_strength or 100) / 100
	local tx, ty, tz = 0, 0, 0

	local unit = W.active and S.fx_follow and local_unit()
	local unit_data = unit and ScriptUnit.has_extension(unit, "unit_data_system")

	if unit_data then
		local ok_l, loco = pcall(unit_data.read_component, unit_data, "locomotion")
		local ok_f, fp = pcall(unit_data.read_component, unit_data, "first_person")
		local velocity = ok_l and loco and loco.velocity_current
		local rotation = ok_f and fp and fp.rotation

		if velocity and rotation then
			--[[
                Flattened right vector (the camera never rolls, so it is never
                zero), and forward from it as up x right. Taking forward from
                the camera directly breaks when looking straight up or down.
            --]]
			local r = Quaternion.right(rotation)
			local rx, ry = r.x, r.y
			local len = math.sqrt(rx * rx + ry * ry)

			if len < 0.001 then
				rx, ry, len = 1, 0, 1
			end

			rx, ry = rx / len, ry / len

			local vxw, vyw = velocity.x, velocity.y
			local vr = vxw * rx + vyw * ry
			local vf = vxw * -ry + vyw * rx
			local vz = velocity.z

			--[[
                Toned down: a full dodge throws things about a third of the
                screen instead of pinning everything into the edge, and slides
                (which happen constantly) barely pull inward.
            --]]
			tx = math.max(-1, math.min(1, vr / 4)) * 650
			ty = -math.max(-1, math.min(1, vz / 3)) * 480

			if vf > 7.5 then
				tz = math.min(1, (vf - 7.5) / 3) * 0.3
			elseif vf < -3 then
				tz = -math.min(1, (-vf - 3) / 3) * 0.35
			end

			-- hard landing: kick everything down so it bounces
			local ok_a, air = pcall(unit_data.read_component, unit_data, "inair_state")
			local on_ground = ok_a and air and air.on_ground

			if on_ground ~= nil then
				if not on_ground then
					follow.fall_speed = math.max(follow.fall_speed, -vz)
				elseif not follow.was_on_ground and follow.fall_speed > 4 then
					follow.vy = follow.vy + math.min(follow.fall_speed, 12) * 150 * strength
				end

				if on_ground then
					follow.fall_speed = 0
				end

				follow.was_on_ground = on_ground
			end
		end
	end

	tx, ty, tz = tx * strength, ty * strength, tz * strength

	-- underdamped springs: fast, and they overshoot on the way back
	local k, damping = 70, 7
	local function spring(pos, vel, target)
		local acc = k * (target - pos) - damping * vel

		vel = vel + acc * dt

		return pos + vel * dt, vel
	end

	W.follow_x, follow.vx = spring(W.follow_x, follow.vx, tx)
	W.follow_y, follow.vy = spring(W.follow_y, follow.vy, ty)
	W.follow_zoom, follow.vz = spring(W.follow_zoom, follow.vz, tz)

	-- settle exactly to zero so an idle HUD stops being redrawn
	if tx == 0 and ty == 0 and tz == 0
		and math.abs(W.follow_x) < 0.5 and math.abs(W.follow_y) < 0.5 and math.abs(W.follow_zoom) < 0.002
		and math.abs(follow.vx) < 1 and math.abs(follow.vy) < 1 and math.abs(follow.vz) < 0.01 then
		W.follow_x, W.follow_y, W.follow_zoom = 0, 0, 0
		follow.vx, follow.vy, follow.vz = 0, 0, 0
	end
end

-- ---------------------------------------------------------------- update

local reactive_timer = 0
local team_timer = 0
local roll_timer = 0
local spike = 0

--[[
    Sober on and off, from the keybind or from the wheel's NORMAL slice.
    A NORMAL lasts "Normal duration" seconds and ends by itself; pressing the
    keybind during one cancels the timer and leaves you where you chose.
--]]
--[[
    Put everything back the way the game draws it. Used by sober mode, by the
    wheel's NORMAL and by Judas mode, which all want the same clean HUD.
--]]
local function calm_everything()
	W.intensity = 0
	W.episode = nil
	W.tint = 0
	W.kid = nil
	W.dyslexia_until = nil
	Motion.untint_all()
	Skel.clear()
	Alerts.clear()
	Hog.clear()
	Void.clear()
	Sniped.clear()
	Wheel.clear()
	Wheel.dog_clear()
	Outlines.restore()
end

local function set_sober(on, quiet)
	W.sober = on

	if on then
		calm_everything()
	else
		--[[
            Coming off sober mode on purpose. Without this the track drifted
            on for fifteen seconds - five of Judas's hold plus ten of its
            linger - and toggling sober again refreshed both, so it stacked
            up to half a minute. Those delays are there to ride out an
            automatic trigger that flickers, not a button press.
        --]]
		Judas.release()
	end

	if not quiet then
		mod:echo(on and "Sober." or "Back on the warp.")
	end
end

-- what each wheel slice does
mod.__dws_fx = {
	whirlpool = function() start_episode("whirlpool", true) end,
	blackhole = function() start_episode("blackhole", true) end,
	flip = function() start_episode("flip", true) end,
	rave = function() start_episode("rave", true) end,
	mirror = function() start_episode("mirror", true) end,
	melt = function() start_episode("melt", true) end,
	spin = function() start_episode("spin", true) end,
	skarmy = function() skeleton_army() end,
	hog = function()
		if not Hog.start() then
			start_episode(nil, true)
		end
	end,
	dyslexia = function()
		W.dyslexia_until = W.t + 12
	end,
	void = function()
		if not Void.start() then
			start_episode(nil, true)
		end
	end,
	badtrip = function()
		spike = 1
		start_episode(nil, true)

		if W.S.fx_skeleton then
			Skel.summon(nil, 3)
		end
	end,
	normal = function()
		if not W.sober then
			W.calm_until = W.t + (W.S.normal_duration or 20)
			set_sober(true, true)
		end

		-- the dog comes AFTER going sober, because going sober clears him
		Wheel.dog(math.min(6, W.S.normal_duration or 20))
	end,
}

--[[
    Run one part of the update without letting it take the rest with it.

    This mod is a dozen independent toys sharing one update. Run in a plain
    sequence, a bug in any one of them aborts mod.update at that line, and
    everything after it silently stops running - which is how a crash in the
    teammate panels ended up being the reason the Judas track could not be
    stopped. One part failing should cost that part, nothing else.

    The error is reported the first time and then once in a while, rather than
    sixty times a second: a repeating fault produced hundreds of lines on
    screen and buried everything else.

    pcall on a plain function with its arguments, not a closure, because this
    runs ten times a frame.
--]]
--[[
    Each teardown step is on its own. Letting one throw used to mean the ones
    after it never ran, and the one that stops the music is near the end.
--]]
local function teardown(fn, a)
	if type(fn) == "function" then
		pcall(fn, a)
	end
end

local gate_cleared = false

local step_fails = {}

local function step(name, fn, a, b)
	if type(fn) ~= "function" then
		return
	end

	local ok, err = pcall(fn, a, b)

	if ok then
		return
	end

	local n = (step_fails[name] or 0) + 1
	step_fails[name] = n

	if n == 1 or n % 600 == 0 then
		mod:error("[%s] update failed (%d time%s): %s", name, n, n == 1 and "" or "s", tostring(err))
	end
end

function mod.update(dt)
	if type(dt) ~= "number" or dt <= 0 or not mod:is_enabled() then
		return
	end

	dt = math.min(dt, 0.25)
	W.t = W.t + dt

	local S = W.S
	local mission = in_mission()

	-- the wheel's NORMAL wears off
	if W.calm_until and (W.t >= W.calm_until or not mission) then
		W.calm_until = nil

		if W.sober then
			set_sober(false, true)

			if mission and S.fx_alerts then
				Alerts.fire("BACK ON THE WARP", "center")
			end
		end
	end

	W.in_mission = mission
	W.me = mission and local_unit() or nil

	--[[
        The warning gate. Until it has been accepted once, nothing runs: this
        is checked before W.active is worked out, and everything downstream
        reads W.active. An "acknowledgement" that let the effects play anyway
        would be worth nothing.
    --]]
	step("warning", Warning.update, dt)

	if not W.gate_closed then
		gate_cleared = false
	end

	if W.gate_closed then
		--[[
            Put away anything already on screen, once. Only reachable through
            /warpwarning mid-session, since on a fresh install nothing has
            started yet - but a gate that leaves a skeleton running is not a
            gate.
        --]]
		if not gate_cleared then
			gate_cleared = true

			teardown(Judas.clear)
			teardown(Hog.clear)
			teardown(Void.clear)
			teardown(Sniped.clear)
			teardown(Wheel.clear)
			teardown(Wheel.dog_clear)
			teardown(Skel.clear)
			teardown(Alerts.clear)
			teardown(Outlines.restore)
		end

		W.active = false
		W.light_text = false
		W.hub_chat = false
		W.intensity = 0
		W.episode = nil
		W.tint = 0
		W.follow_x, W.follow_y, W.follow_zoom = 0, 0, 0

		step("motion", Motion.update, dt)
		step("alerts", Alerts.update, dt)

		return
	end

	--[[
        Judas mode before W.active, because it is one of the things that can
        switch the chaos off. On the way in the HUD is calmed and the dog is
        put on the side of the screen; on the way out both are undone.
    --]]
	local ok_judas, judas_changed = pcall(Judas.update, dt, mission)

	if not ok_judas then
		judas_changed = false
		local n = (step_fails.judas or 0) + 1
		step_fails.judas = n

		if n == 1 or n % 600 == 0 then
			mod:error("[judas] update failed (%d time%s): %s", n, n == 1 and "" or "s", tostring(judas_changed))
		end
	end

	if judas_changed then
		if Judas.on() then
			calm_everything()
			Wheel.dog(nil, "watch")
		else
			Wheel.dog_clear()
		end
	end

	W.clutch = Judas.on() and not W.sober or nil
	W.active = mission and not W.sober and not Judas.on()
	W.light_text = not mission and not W.sober
	W.hub_chat = not mission and not W.sober and S.fx_chat_chaos and S.fx_chat_pong and true or false
	W.motion_on = S.fx_motion and true or false

	-- constant: a baseline that drifts 80%..120% over about 20 seconds
	local constant = 0

	if W.active and S.constant_mode then
		constant = (S.constant_strength or 0) / 100 * (1 + 0.15 * math.sin(W.t * 0.31))
	end

	W.constant = constant

	-- reactive: sampled at 5 Hz, fast to rise, slow to wear off
	if W.active and S.reactive_mode then
		reactive_timer = reactive_timer - dt

		if reactive_timer <= 0 then
			reactive_timer = 0.2
			W.reactive_target = sample_reactive()
		end
	else
		W.reactive_target = 0
	end

	local target = math.max(W.reactive_target, spike)
	local rate = target > W.reactive and 2.5 or 0.35

	W.reactive = W.reactive + (target - W.reactive) * math.min(1, dt * rate)
	spike = math.max(0, spike - dt * 0.25)

	local reactive = S.reactive_mode and W.reactive * ((S.reactive_strength or 0) / 100) or 0
	local wanted = W.active and clamp01(1 - (1 - constant) * (1 - reactive)) or 0

	-- when sober or out of a mission, come down fast so the HUD settles
	if wanted < W.intensity and not W.active then
		W.intensity = math.max(wanted, W.intensity - dt * 2)
	else
		W.intensity = wanted
	end

	-- colour layer
	local chaos = (S.chaos_level or 80) / 100

	local colour = (S.colour_strength or 60) / 100
	local colour_speed = (S.colour_speed or 50) / 50

	if W.active and S.fx_colors then
		W.tint = math.min(1, chaos * (0.3 + 0.9 * W.intensity)) * colour
		W.hue_speed = (0.06 + 0.4 * W.intensity) * colour_speed
	else
		W.tint = 0
	end

	if W.episode and W.episode.name == "rave" and S.fx_colors then
		W.tint = math.max(W.tint, colour)
		W.hue_speed = 0.9 * colour_speed
	end

	update_episodes(dt)
	follow_update(dt)

	-- a big reactive spike gets an army
	if W.active and S.skeleton_on_peak and W.intensity > 0.85 and W.t - (W.last_army or -100) > 30 then
		W.last_army = W.t
		skeleton_army()
	end

	-- random skeletons and alerts, once a second
	if W.active then
		roll_timer = roll_timer + dt

		if roll_timer >= 1 then
			roll_timer = roll_timer - 1

			local boost = 0.5 + W.intensity

			if S.fx_skeleton and math.random() < (S.skeletons_per_minute or 0) / 60 * boost then
				Skel.summon(nil, math.random() < 0.25 and math.random(2, 4) or 1)
			end

			if S.fx_alerts and math.random() < (S.alerts_per_minute or 0) / 60 * boost then
				Alerts.fire()
			end
		end

		team_timer = team_timer - dt

		if team_timer <= 0 then
			team_timer = 0.25
			scan_teammates(function()
				if S.fx_skeleton and S.skeleton_on_downed then
					Skel.summon(nil, 2)
				end

				if S.fx_alerts then
					Alerts.fire()
				end
			end)
		end
	end

	if not W.active then
		Skel.clear()
		Alerts.clear()
	end

	--[[
        Pumped everywhere, not just in a mission. A stop with a fade only
        finishes when the runtime is ticked, so skipping this in the hub left
        a fading track playing in the Mourningstar for ever.
    --]]
	Skel.warm_audio(dt)

	step("motion", Motion.update, dt)
	step("census", Motion.announce)
	step("scramble", Scramble.update, W.t)
	step("outlines", Outlines.update, dt)
	step("wheel", Wheel.update, dt)
	step("dog", Wheel.dog_update, dt)
	step("hog", Hog.update, dt)
	step("void", Void.update, dt)
	step("sniped", Sniped.update, dt)
	step("skeletons", Skel.update, dt)
	step("alerts", Alerts.update, dt)
end

-- ---------------------------------------------------------------- lifecycle

mod.on_setting_changed = function(id)
	refresh_settings()

	-- the track's volume is fixed when it starts, so restart it to hear a change
	if id == "judas_volume" or id == "judas_absolute" then
		Judas.volume_changed()
	end
end

mod.on_disabled = function()
	W.active = false
	W.light_text = false
	W.hub_chat = false
	W.intensity = 0
	W.episode = nil
	W.tint = 0
	W.follow_x, W.follow_y, W.follow_zoom = 0, 0, 0
	W.kid = nil
	W.calm_until = nil
	W.dyslexia_until = nil
	-- the music first, because that is the one somebody switching the mod
	-- off in a hurry is actually trying to stop
	teardown(Judas.clear)
	teardown(Judas.forget_listener)
	teardown(Hog.clear)
	teardown(Void.clear)
	teardown(Sniped.clear)
	teardown(Wheel.clear)
	teardown(Wheel.dog_clear)
	teardown(Motion.reset)
	teardown(Outlines.restore)
	teardown(Skel.clear)
	teardown(Alerts.clear)
end

--[[
    A reload or a game shutdown. Same teardown as being switched off, but
    every step is pcall'd and the whole thing is pcall'd again: by the time
    this runs the managers may already be destroyed, and reading a property
    off a destroyed one raises. Another mod in this load order dies here
    every session for exactly that reason ("Cannot access property
    'unregister' on destroyed object of type EventManager"), and a sound left
    playing because teardown threw halfway is the worst version of it.
--]]
mod.on_unload = function()
	pcall(mod.on_disabled)
end

mod.on_game_state_changed = function(status)
	if status == "exit" then
		W.downed = setmetatable({}, { __mode = "k" })
		Skel.clear()
	end
end

-- ---------------------------------------------------------------- keybinds and commands

--[[
    The warning's accept action, bound to a key in Mod Options. Also
    /warpagree, because a fresh install has no key bound to it yet and the
    gate has to be passable without one.
--]]
mod.accept_warning = function()
	Warning.accept()
end

mod.toggle_sober = function()
	W.calm_until = nil
	set_sober(not W.sober)
end

mod.toggle_follow = function()
	local on = not mod:get("fx_follow")

	mod:set("fx_follow", on, true)
	W.S.fx_follow = on
	mod:echo(on and "Motion follow on." or "Motion follow off.")
end

mod.summon_skeleton = function()
	if not Skel.summon() then
		mod:echo("No skeleton set has frames. /warpsick says why.")
	end
end

mod:command("warpsick", "Dio's Warp Sickness: show the current trip and what feeds it", function()
	mod:echo("%s", string.format("intensity %.2f (constant %.2f, reactive %.2f)%s%s",
		W.intensity, W.constant, W.reactive, W.sober and " SOBER" or "", W.in_mission and "" or " (not in a mission)"))

	local parts = {}

	for k, v in pairs(W.sources) do
		parts[#parts + 1] = string.format("%s %.2f", k, v)
	end

	mod:echo("%s", "sources: " .. (#parts > 0 and table.concat(parts, ", ") or "none"))
	mod:echo("%s", string.format("episode: %s, colour %.2f, rotation %s",
		W.episode and W.episode.name or "none", W.tint, W.rotation_broken and "OFF (engine refused)" or "on"))

	for _, line in ipairs(Skel.describe()) do
		mod:echo("%s", line)
	end
end)

mod:command("warpskel", "Dio's Warp Sickness: summon skeletons. Optional: set name, count", function(set_name, count)
	if not Skel.summon(set_name ~= "" and set_name or nil, tonumber(count) or 1) then
		mod:echo("No skeleton set has frames. /warpsick says why.")
	end
end)

mod:command("warptrip", "Dio's Warp Sickness: force a peak: max intensity, an episode, a skeleton army and an alert", function()
	spike = 1
	start_episode()
	skeleton_army()
end)

mod:command("warpep", "Dio's Warp Sickness: start an episode. whirlpool blackhole flip spin carousel quake scatter mirror melt rave", function(name)
	local ep = start_episode(name ~= "" and name or nil)
	mod:echo("%s", ep and ("episode: " .. ep.name) or "every episode slider is at 0")
end)

mod:command("warpalert", "Dio's Warp Sickness: fire an alert. Optional: your own text", function(...)
	local text = table.concat({ ... }, " ")
	Alerts.fire(text ~= "" and text or nil)
end)

mod:command("warpwheel", "Dio's Warp Sickness: spin the wheel now. Optional: whirlpool skarmy flip hog blackhole rave dyslexia mirror badtrip melt spin normal", function(key)
	if not W.active then
		mod:echo("The wheel only spins in a mission (and not while sober).")
	elseif not W.S.fx_wheel then
		mod:echo("The Wheel of Misfortune is switched off in Mod Options.")
	elseif not Wheel.spin(key ~= "" and key or nil) then
		mod:echo("The wheel is already spinning.")
	end
end)

mod:command("warphog", "Dio's Warp Sickness: HOG RIDAAAAA", function()
	if not W.active then
		mod:echo("The Hog Rider only rides in a mission (and not while sober).")
	elseif not W.S.fx_hog then
		mod:echo("The Hog Rider is switched off in Mod Options.")
	elseif not Hog.start() then
		mod:echo("The Hog Rider is already busy.")
	end
end)

mod:command("warpjudas", "Dio's Warp Sickness: Judas mode state, or on / off / auto / stop", function(what)
	what = what ~= "" and string.lower(what) or nil

	if what == "on" then
		Judas.force(true)
		mod:echo("Judas mode pinned on. /warpjudas auto hands it back to the conditions.")
	elseif what == "off" then
		Judas.force(false)
		mod:echo("Judas mode pinned off. /warpjudas auto hands it back to the conditions.")
	elseif what == "auto" then
		Judas.force(nil)
		mod:echo("Judas mode back on the conditions.")
	elseif what == "stop" then
		local tracked, nuked = Judas.silence()

		mod:echo("%s", string.format(
			"Silenced %d tracked sound(s)%s. Judas mode is pinned off: /warpjudas auto turns it back on.",
			tracked,
			nuked and " and told the audio backend to stop everything it has, handle or no handle"
				or " (the backend has no stop-everything, so anything whose id was lost needs a restart)"))
	else
		mod:echo("%s", Judas.describe())
	end
end)

mod:command("warpwho", "Dio's Warp Sickness: list every HUD element it can see and whether it is being thrown", function()
	local rows, base_n, mod_n, thrown_n = Motion.census()

	if #rows == 0 then
		mod:echo("Nothing in reach yet. The scan runs while a HUD is up - try it in a mission.")

		return
	end

	mod:echo("%d HUD elements in reach: %d base game, %d from mods. %d being thrown.",
		#rows, base_n, mod_n, thrown_n)

	local others, spared = {}, {}

	for i = 1, #rows do
		local r = rows[i]

		if not r.base then
			others[#others + 1] = r.name
		end

		if not r.thrown then
			spared[#spared + 1] = string.format("%s (%s)", r.name, r.group or "?")
		end
	end

	if #others > 0 then
		mod:echo("From mods, always thrown: %s", table.concat(others, ", "))
	else
		mod:echo("No mod HUD elements found - only the base game's.")
	end

	if #spared > 0 then
		mod:echo("Spared by a setting: %s", table.concat(spared, ", "))
	else
		mod:echo("Nothing is being spared. Nobody is safe.")
	end
end)

mod:command("warpagree", "Dio's Warp Sickness: accept the warning screen", function()
	if not Warning.pending() then
		mod:echo("The warning has already been accepted. /warpwarning brings it back.")
	elseif not Warning.accept() then
		mod:echo("Read it first.")
	end
end)

mod:command("warpwarning", "Dio's Warp Sickness: show the warning screen again", function()
	Warning.reset()
	mod:echo("Warning screen is back up. Everything is switched off until it is accepted again.")
end)

mod:command("warpvoid", "Dio's Warp Sickness: open the void now", function()
	if not W.active then
		mod:echo("The void only opens in a mission (and not while sober).")
	elseif not W.S.fx_void then
		mod:echo("The void is switched off in Mod Options.")
	elseif not Void.start() then
		mod:echo("The void is already open.")
	end
end)

mod:command("warpsniped", "Dio's Warp Sickness: show the sniped picture now", function()
	if not W.active then
		mod:echo("Only in a mission (and not while sober).")
	elseif not W.S.fx_sniped then
		mod:echo("The sniped picture is switched off in Mod Options.")
	else
		Sniped.hit()
	end
end)

mod:command("warpdog", "Dio's Warp Sickness: the dog", function()
	if not Wheel.dog(6) then
		mod:echo("The dog is switched off in Mod Options.")
	end
end)

mod:command("warprescan", "Dio's Warp Sickness: re-read assets/skeletons after adding files", function()
	Skel.rescan()
	Alerts.reload()
	mod:echo("Skeleton sets, loose pictures and alert lines will be re-read on the next frame in a mission.")
end)
