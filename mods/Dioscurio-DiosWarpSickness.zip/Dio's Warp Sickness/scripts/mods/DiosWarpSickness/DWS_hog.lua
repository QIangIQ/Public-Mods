local mod = get_mod("DiosWarpSickness")

--[[
    ========================================================================
    HOG RIDER
    ========================================================================

    He pops up from the bottom of the screen screaming, then rides in from
    the same side, throws a lasso round a piece of your HUD and drags it off
    the far edge. A couple of seconds later it falls back in from the top.

    Timeline (seconds from the start):
        0.0   scream; the yelling portrait slides up from the bottom edge
        0.9   the rider enters at the height of his target
        ~     lasso thrown when he is LASSO_RANGE away, lands 0.3s later
        ~     the element is yanked onto the rope and trails behind him
        ~     both leave the screen; GONE_TIME seconds of "where is it"
        ~     it drops back in from above over RETURN_TIME

    This module only keeps the state. HudElementDiosWarpSickness draws it,
    and DWS_motion moves the stolen element through W.kid:
        W.kid = { c = <motion ctx>, k = 0..1, x, y, angle }
    with x, y the element centre wanted in UI space.

    The rider's coordinates are the HUD element's 1920x1080 "fit" space;
    W.kid is converted to UI space with the same centring the fit node uses.
--]]

local Hog = {}

local W = mod.__dws

local sin, cos, abs, min, max, floor, pi, sqrt = math.sin, math.cos, math.abs, math.min, math.max, math.floor, math.pi, math.sqrt

local RIDE_FRAMES = 10
local RIDE_FPS = 14
local LASSO_FRAMES = 16
local LASSO_FPS = 26

-- how many straight pieces the rope is drawn in; more is smoother
local ROPE_SEGMENTS = 16
local YELL_FRAMES = 12
local YELL_FPS = 8

local RIDE_SCALE = 1.2
local RIDE_W, RIDE_H = 280 * RIDE_SCALE, 360 * RIDE_SCALE
-- the hand holding the rope, in ride-frame pixels (frames are 280x360, centre 140,180)
local HAND_X, HAND_Y = 20, -35
local YELL_W, YELL_H = 545 * 1.35, 351 * 1.35

local YELL_TIME = 2.3
local RIDE_START = 0.9
local RIDE_SPEED = 1250
local LASSO_RANGE = 1150
local SPIN_TIME = 0.75 -- he winds it up over his head before throwing
local THROW_TIME = 0.34
local YANK_TIME = 0.3
local GONE_TIME = 1.7
local RETURN_TIME = 0.9

local NAMES = {
	HudElementPerilGauge = "PERIL BAR",
	HudElementOvercharge = "PERIL BAR",
	HudElementSpecialsTracker = "SPECIALS TRACKER",
	HudElementTeamPlayerPanel = "TEAMMATE",
	HudElementTeamPanelHandler = "TEAM",
	HudElementPersonalPlayerPanel = "HEALTH BAR",
	HudElementPlayerAbility = "ABILITY",
	HudElementPlayerWeapon = "GUN",
	HudElementPlayerWeaponHandler = "AMMO",
	HudElementBlocking = "STAMINA",
	HudElementMissionObjectiveFeed = "OBJECTIVES",
	HudElementMissionObjective = "OBJECTIVE",
	HudElementCombatFeed = "KILL FEED",
	HudElementBossHealth = "BOSS BAR",
	ConstantElementChat = "CHAT",
}

local STOLE = {
	"HOG RIDER STOLE YOUR %s",
	"YOUR %s HAS BEEN HOG RIDDEN",
	"%s KIDNAPPED BY HOG RIDER",
	"HOG RIDER TOOK THE %s TO THE GOBLIN VILLAGE",
	"RANSOM NOTE: GIVE HOG RIDER 300 GOLD FOR YOUR %s",
	"YOUR %s IS ON A HOG NOW",
}

local SCREAMS = { "HOG RIDAAAAAA!", "HOOOOG RIDAAAAAAA!", "HOG RIDERRRRR!", "HOOOG RIIIIDAAAA!!" }

local state = nil
local hog_timer = nil
local preloaded = false

local function smooth(p)
	p = max(0, min(1, p))

	return p * p * (3 - 2 * p)
end

-- the fit node is 1920x1080 centred on the UI space (W.sw x W.sh)
local function ui_offset()
	local sw, sh = W.sw or 1920, W.sh or 1080

	return (sw - 1920) / 2, (sh - 1080) / 2
end

local function preload()
	local Skel = mod.__dws_skeleton

	if preloaded or not Skel then
		return
	end

	preloaded = true

	for i = 1, RIDE_FRAMES do
		Skel.texture("hogrider/ride_" .. i .. ".png")
	end

	for i = 1, YELL_FRAMES do
		Skel.texture("hogrider/yell_" .. i .. ".png")
	end

	Skel.texture("hogrider/lasso.png")
end

function Hog.active()
	return state ~= nil
end

local function centre(c)
	return (c.bb_x0 + c.bb_x1) / 2, (c.bb_y0 + c.bb_y1) / 2
end

function Hog.start()
	if state or not W.active or not W.S.fx_hog then
		return false
	end

	preload()

	local Motion = mod.__dws_motion
	local victims = Motion and Motion.victims() or {}
	local c = #victims > 0 and victims[math.random(#victims)] or nil
	local ox, oy = ui_offset()
	local vy, vx = 600, 960

	if c then
		local cx, cy = centre(c)
		vx, vy = cx - ox, cy - oy
	end

	-- usually from the near side, so the loot gets dragged across the whole screen
	local dir = vx > 960 and -1 or 1

	if math.random() < 0.2 then
		dir = -dir
	end

	state = {
		t = 0,
		dir = dir,
		c = c,
		ride_y = max(200, min(880, vy + 60)),
		x = dir > 0 and -RIDE_W or 1920 + RIDE_W,
		phase = "yell",
		scream = SCREAMS[math.random(#SCREAMS)],
		bob = math.random() * 6,
	}

	local Skel = mod.__dws_skeleton

	if Skel then
		Skel.play("hogrider/hogrider.wav", W.S.hog_volume or 80)
	end

	local Alerts = mod.__dws_alerts

	if Alerts and W.S.fx_alerts then
		Alerts.fire(state.scream, "center", true)
	end

	return true
end

function Hog.clear()
	state = nil
	W.kid = nil
end

local function hand(s)
	local bob = 10 * sin(s.t * 14 + s.bob)

	return s.x + s.dir * HAND_X * RIDE_SCALE, s.ride_y + bob + HAND_Y * RIDE_SCALE
end

function Hog.update(dt)
	local S = W.S

	if not W.active or not S.fx_hog then
		if state then
			Hog.clear()
		end

		hog_timer = nil

		return
	end

	preload()

	-- random visits; 0 means only when the wheel says so
	local interval = S.hog_interval or 90

	if interval > 0 then
		hog_timer = hog_timer or interval * (0.5 + math.random())
		hog_timer = hog_timer - dt

		if hog_timer <= 0 then
			hog_timer = interval * (0.6 + 0.8 * math.random())
			Hog.start()
		end
	end

	local s = state

	if not s then
		return
	end

	s.t = s.t + dt

	local t = s.t
	local ox, oy = ui_offset()

	-- the rider
	if t >= RIDE_START then
		-- hauling something slows him down
		s.x = s.x + s.dir * RIDE_SPEED * (s.throw_t and 0.6 or (s.spin_t and 0.42 or 1)) * dt
	end

	local c = s.c

	-- the element he wants (it may have stopped being drawn: then he just rides through)
	if c and (not c.bb_x0 or (c.drawn_t and W.t - c.drawn_t > 1)) then
		s.c, c = nil, nil
		W.kid = nil
	end

	local hx, hy = hand(s)

	if c then
		local cx, cy = centre(c)
		cx, cy = cx - ox, cy - oy

		--[[
		    He winds it up before he throws it. The old version had the rope
		    leave his hand the instant he came into range, which is most of
		    why it read as a brown ring being slid across the screen rather
		    than a lasso being thrown.
		--]]
		if not s.spin_t and t >= RIDE_START and (s.dir * (cx - s.x) < LASSO_RANGE) then
			s.spin_t = t
		end

		if s.spin_t and not s.throw_t and t - s.spin_t >= SPIN_TIME then
			s.throw_t = t
		end

		-- spinning it over his head: the loop rides just above the hand
		if s.spin_t and not s.throw_t then
			-- over the shoulder, behind the direction of travel: you wind
			-- up behind you and throw forward
			local wind = (t - s.spin_t) / SPIN_TIME

			s.rope_x = hx - s.dir * (18 + 26 * wind)
			s.rope_y = hy - 92 + 7 * sin(t * 11 + s.bob)
		end

		if s.throw_t then
			local tp = (t - s.throw_t) / THROW_TIME

			if tp < 1 then
				-- the rope flies out to the element
				local e = smooth(tp)

				s.rope_x, s.rope_y = hx + (cx - hx) * e, hy + (cy - hy) * e
			elseif not s.land_t then
				s.land_t = t
				s.rope_len = sqrt((cx - hx) ^ 2 + (cy - hy) ^ 2)
			end
		end

		if s.land_t then
			local lt = t - s.land_t
			local yank = smooth(lt / YANK_TIME)
			local len = s.rope_len + (260 - s.rope_len) * smooth(lt / 0.8)
			local tx = hx - s.dir * len
			local ty = hy + 50 + 35 * sin(lt * 8)
			local half_w = (c.bb_x1 - c.bb_x0) / 2

			-- the rope ends where the element actually is, partway through the yank
			s.rope_x, s.rope_y = cx + (tx - cx) * yank, cy + (ty - cy) * yank

			if s.phase ~= "gone" and s.phase ~= "return" then
				s.phase = "drag"

				W.kid = W.kid or { c = c }
				W.kid.c = c
				W.kid.k = yank
				W.kid.x, W.kid.y = tx + ox, ty + oy
				W.kid.angle = s.dir * 2.6 * lt

				-- the element has left the screen: start the countdown
				if (s.dir > 0 and tx - half_w > 1920 + 60) or (s.dir < 0 and tx + half_w < -60) then
					s.phase = "gone"
					s.gone_t = t

					local Alerts = mod.__dws_alerts

					if Alerts and W.S.fx_alerts then
						local name = NAMES[c.name] or "HUD"
						Alerts.fire(string.format(STOLE[math.random(#STOLE)], name))
					end
				end
			end
		end

		if s.phase == "gone" then
			W.kid.k = 1
			W.kid.x = (s.dir > 0 and 1920 + 900 or -900) + ox

			if t - s.gone_t >= GONE_TIME then
				s.phase = "return"
				s.return_t = t
			end
		elseif s.phase == "return" then
			local p = (t - s.return_t) / RETURN_TIME
			local home_x, home_y = centre(c)
			local h = c.bb_y1 - c.bb_y0

			-- dropped back in from above: k eases to 0 with the target above its home
			W.kid.x, W.kid.y = home_x, -h - 120
			W.kid.k = 1 - smooth(p)
			W.kid.angle = (W.kid.angle or 0) * 0.85

			if p >= 1 then
				Hog.clear()
				return
			end
		end
	end

	-- nothing taken: done once he is off screen
	local gone_x = s.dir > 0 and s.x > 1920 + RIDE_W or s.dir < 0 and s.x < -RIDE_W

	if not c and gone_x and t > YELL_TIME then
		Hog.clear()
	end

	-- hard cap, whatever happens
	if state and t > 20 then
		Hog.clear()
	end
end

--[[
    What the HUD element should draw this frame (1920x1080 top-left space).
--]]
function Hog.view(out)
	local s = state
	local Skel = mod.__dws_skeleton

	if not s or not Skel then
		return nil
	end

	local t = s.t

	-- yelling portrait
	if t < YELL_TIME then
		local rise = smooth(t / 0.25) * (1 - smooth((t - (YELL_TIME - 0.3)) / 0.3))
		local fi = floor(t * YELL_FPS)

		if fi >= YELL_FRAMES then
			fi = YELL_FRAMES - 4 + (fi % 4)
		end

		out.yell_tex = Skel.texture("hogrider/yell_" .. (fi + 1) .. ".png")
		out.yell_w, out.yell_h = YELL_W, YELL_H
		out.yell_x = (s.dir > 0 and 40 or 1920 - 40 - YELL_W) + (math.random() * 2 - 1) * 6
		out.yell_y = 1080 - YELL_H * rise + (math.random() * 2 - 1) * 6
		out.yell_flip = s.dir < 0
	else
		out.yell_tex = nil
	end

	-- rider
	if t >= RIDE_START and s.x > -RIDE_W and s.x < 1920 + RIDE_W then
		local fi = floor(t * RIDE_FPS) % RIDE_FRAMES

		out.ride_tex = Skel.texture("hogrider/ride_" .. (fi + 1) .. ".png")
		out.ride_w, out.ride_h = RIDE_W, RIDE_H
		out.ride_x = s.x - RIDE_W / 2
		out.ride_y = s.ride_y + 10 * sin(t * 14 + s.bob) - RIDE_H / 2
		out.ride_flip = s.dir < 0
		out.ride_angle = 0.06 * sin(t * 7)
	else
		out.ride_tex = nil
	end

	-- rope and lasso
	if s.rope_x and s.phase ~= "gone" and s.phase ~= "return" and s.c then
		local hx, hy = hand(s)
		local c = s.c

		--[[
            THE ROPE

            Drawn as a run of short pieces along a curve rather than one
            stretched rectangle. A rope is never a straight line: it sags
            under its own weight when there is slack, and it whips when it
            is thrown.

            The curve is a quadratic Bezier from the hand to the far end,
            with the control point pulled down by `sag`. On top of that, a
            travelling wave that dies away over the throw, so the rope snakes
            out rather than appearing fully extended.
        --]]
		local dx, dy = s.rope_x - hx, s.rope_y - hy
		local span = sqrt(dx * dx + dy * dy)

		local sag, whip, whip_phase = 0, 0, 0

		if s.land_t then
			-- hauling: taut, with a little give that settles
			sag = 26 * max(0, 1 - (t - s.land_t) / 0.9)
		elseif s.throw_t then
			local tp = min(1, (t - s.throw_t) / THROW_TIME)

			sag = 70 * (1 - tp)
			whip = 42 * (1 - tp) * (1 - tp)
			whip_phase = t * 26
		else
			-- winding up: a short loose length between hand and loop
			sag = 34 + 6 * sin(t * 9)
		end

		-- unit vector along the rope, and the one across it
		local ux, uy = 1, 0

		if span > 0.001 then
			ux, uy = dx / span, dy / span
		end

		local nx, ny = -uy, ux

		-- the Bezier control point: midway, pulled down the screen
		local mx = (hx + s.rope_x) / 2
		local my = (hy + s.rope_y) / 2 + sag

		local pts = out.rope_pts or {}
		out.rope_pts = pts

		for i = 0, ROPE_SEGMENTS do
			local u = i / ROPE_SEGMENTS
			local v = 1 - u
			local bx = v * v * hx + 2 * v * u * mx + u * u * s.rope_x
			local by = v * v * hy + 2 * v * u * my + u * u * s.rope_y

			-- the whip, biggest in the middle and zero at both ends
			if whip > 0 then
				local env = sin(u * pi)
				local w = whip * env * sin(u * 9 - whip_phase)

				bx = bx + nx * w
				by = by + ny * w
			end

			local k = i * 2 + 1

			pts[k], pts[k + 1] = bx, by
		end

		out.rope = true
		out.rope_n = ROPE_SEGMENTS
		-- the rope is thicker at the hand and thins towards the loop
		out.rope_w0, out.rope_w1 = 8, 5.5

		local lw, lh, la, tex

		if s.land_t then
			--[[
                Cinched round the element. A flat ring is right here: it has
                been pulled tight round a rectangle and is no longer a loop
                hanging in the air.
            --]]
			lw = min(c.bb_x1 - c.bb_x0, 900) * 1.12 + 34
			lh = min(c.bb_y1 - c.bb_y0, 600) * 1.12 + 40
			la = c.rotating and c.angle or 0
			tex = Skel.texture("hogrider/lasso.png")
		else
			--[[
                In the air, turning. The frames ARE the spin - the loop is
                drawn in perspective and the strands run round it. Rotating a
                circle about its centre, which is what this used to do, shows
                nothing at all.
            --]]
			local fi = floor(t * LASSO_FPS * s.dir) % LASSO_FRAMES

			tex = Skel.texture("hogrider/lasso_" .. (fi + 1) .. ".png")

			-- no frames on this install: fall back to the flat ring
			if not tex then
				tex = Skel.texture("hogrider/lasso.png")
			end

			if s.throw_t then
				--[[
                    Thrown: it shrinks a little as it travels away, and tips
                    up towards the thing it is about to drop over.
                --]]
				local tp = min(1, (t - s.throw_t) / THROW_TIME)
				local size = 230 - 46 * tp

				lw, lh = size, size
				la = -math.atan2(dy, dx) * 0.45 * (1 - tp)
			else
				-- over his head, leaning with the swing
				lw, lh = 186, 186
				la = 0.17 * sin(t * 11 + s.bob)
			end
		end

		out.lasso_tex = tex
		out.lasso_w, out.lasso_h = lw, lh
		out.lasso_x, out.lasso_y = s.rope_x - lw / 2, s.rope_y - lh / 2
		out.lasso_angle = la
	else
		out.rope = false
		out.rope_n = 0
		out.lasso_tex = nil
	end

	return out
end

mod.__dws_hog = Hog

return Hog
