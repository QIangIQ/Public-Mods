local mod = get_mod("DiosWarpSickness")

--[[
    ========================================================================
    THE VOID
    ========================================================================

    A black point opens somewhere on the screen, slowly grows until it covers
    a share of the screen, drifts while it sits there, then fades out.
    Pitch black: nothing shows through it.

    "Void size" is a share of the screen AREA, not a width, so 20 really is a
    fifth of the screen:

        area  = 1920 * 1080 * pct / 100
        r     = sqrt(area / pi)          -- 20 percent -> 363 px radius

    This module only keeps the state; HudElementDiosWarpSickness draws it,
    on top of everything else that element owns.
--]]

local Void = {}

local W = mod.__dws

local sin, cos, sqrt, min, max, pi, random = math.sin, math.cos, math.sqrt, math.min, math.max, math.pi, math.random

local HOLD = 2.5 -- seconds at full size before it starts to go
local FADE = 1.2
local DRIFT = 14 -- pixels a second
local SEED = 3 -- the radius it opens at, so it starts as a point rather than nothing

local state = nil
local timer = nil
local preloaded = false

local function preload()
	local Skel = mod.__dws_skeleton

	if preloaded or not Skel then
		return
	end

	preloaded = true
	Skel.texture("void/void.png")
end

local function smooth(p)
	p = max(0, min(1, p))

	return p * p * (3 - 2 * p)
end

function Void.active()
	return state ~= nil
end

function Void.clear()
	state = nil
end

function Void.start(pct_override)
	if state or not W.active or not W.S.fx_void then
		return false
	end

	preload()

	local pct = max(pct_override or W.S.void_size or 20, 1)
	local r = sqrt(pct / 100 * 1920 * 1080 / pi)
	-- the centre may sit close enough to an edge that the void eats a corner
	local margin = r * 0.45
	local angle = random() * 2 * pi

	state = {
		t = 0,
		r = r,
		grow = max(W.S.void_grow or 8, 0.5),
		x = margin + random() * (1920 - 2 * margin),
		y = margin + random() * (1080 - 2 * margin),
		vx = cos(angle) * DRIFT,
		vy = sin(angle) * DRIFT,
		phase = random() * 2 * pi,
	}

	return true
end

function Void.update(dt)
	local S = W.S

	if not W.active or not S.fx_void then
		state = nil
		timer = nil

		return
	end

	preload()

	-- random openings; 0 means only from the wheel or /warpvoid
	local interval = S.void_interval or 70

	if interval > 0 then
		timer = timer or interval * (0.5 + random())
		timer = timer - dt

		if timer <= 0 then
			timer = interval * (0.6 + 0.8 * random())
			Void.start()
		end
	end

	local s = state

	if not s then
		return
	end

	s.t = s.t + dt
	s.x = s.x + s.vx * dt
	s.y = s.y + s.vy * dt

	if s.t >= s.grow + HOLD + FADE then
		state = nil
	end
end

--[[
    What the HUD element should draw this frame (1920x1080 top-left space).
--]]
function Void.view(out)
	local s = state
	local Skel = mod.__dws_skeleton

	if not s or not Skel then
		return nil
	end

	local tex = Skel.texture("void/void.png")

	if not tex then
		return nil
	end

	local t = s.t
	local p = min(1, t / s.grow)
	-- eases in a little, so it hangs around as a dot before it really opens
	local r = SEED + (s.r - SEED) * p ^ 1.3

	r = r * (1 + 0.02 * sin(t * 1.7 + s.phase))

	local gone = t - s.grow - HOLD
	local alpha = gone > 0 and (1 - gone / FADE) or 1

	out.texture = tex
	out.alpha = 255 * max(0, min(1, alpha))
	out.size = r * 2
	out.x = s.x - r
	out.y = s.y - r

	return out
end

mod.__dws_void = Void

return Void
