local mod = get_mod("DiosWarpSickness")

--[[
    Widget types are kept to checkbox, numeric, keybind and group only.
    A public HavocTracker build once used dropdown/button widgets and an
    options field older DMF installs could not read, and the mod vanished
    from Mod Options on someone else's machine. Same rule here.
--]]

local function checkbox(id, default)
	return { setting_id = id, type = "checkbox", default_value = default, tooltip = id .. "_tooltip" }
end

local function numeric(id, default, range)
	return {
		setting_id = id,
		type = "numeric",
		default_value = default,
		range = range,
		decimals_number = 0,
		tooltip = id .. "_tooltip",
	}
end

local function keybind(id, function_name, global)
	return {
		setting_id = id,
		type = "keybind",
		default_value = {},
		keybind_global = global or false,
		keybind_trigger = "pressed",
		keybind_type = "function_call",
		function_name = function_name,
		tooltip = id .. "_tooltip",
	}
end

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			{
				setting_id = "group_modes",
				type = "group",
				sub_widgets = {
					keybind("accept_keybind", "accept_warning", true),
					numeric("chaos_level", 80, { 0, 100 }),
					checkbox("constant_mode", true),
					numeric("constant_strength", 45, { 0, 100 }),
					checkbox("reactive_mode", true),
					numeric("reactive_strength", 100, { 0, 100 }),
					keybind("sober_keybind", "toggle_sober", true),
					numeric("anim_rate", 30, { 10, 60 }),
				},
			},
			{
				setting_id = "group_who",
				type = "group",
				sub_widgets = {
					checkbox("throw_aim", true),
					checkbox("throw_input", true),
					checkbox("throw_world", true),
					checkbox("throw_fullscreen", true),
					checkbox("throw_spectate", true),
					checkbox("throw_prologue", true),
				},
			},
			{
				setting_id = "group_effects",
				type = "group",
				sub_widgets = {
					checkbox("fx_motion", true),
					numeric("motion_size", 100, { 0, 200 }),
					checkbox("fx_rotate", true),
					checkbox("fx_colors", true),
					numeric("colour_strength", 60, { 0, 100 }),
					numeric("colour_speed", 50, { 0, 100 }),
					checkbox("fx_episodes", true),
					checkbox("fx_follow", true),
					numeric("follow_strength", 100, { 0, 200 }),
					keybind("follow_keybind", "toggle_follow"),
					checkbox("fx_menus", true),
					checkbox("fx_sink", true),
					checkbox("fx_scramble", true),
					checkbox("scramble_numbers", false),
					checkbox("fx_outlines", true),
					checkbox("fx_chat_chaos", true),
					checkbox("fx_chat_pong", true),
				},
			},
			{
				setting_id = "group_episodes",
				type = "group",
				sub_widgets = {
					numeric("episode_frequency", 40, { 0, 100 }),
					numeric("ep_whirlpool", 40, { 0, 100 }),
					numeric("ep_blackhole", 35, { 0, 100 }),
					numeric("ep_flip", 30, { 0, 100 }),
					numeric("ep_spin", 30, { 0, 100 }),
					numeric("ep_carousel", 25, { 0, 100 }),
					numeric("ep_quake", 25, { 0, 100 }),
					numeric("ep_scatter", 25, { 0, 100 }),
					numeric("ep_mirror", 25, { 0, 100 }),
					numeric("ep_melt", 25, { 0, 100 }),
					numeric("ep_rave", 30, { 0, 100 }),
				},
			},
			{
				setting_id = "group_wheel",
				type = "group",
				sub_widgets = {
					checkbox("fx_wheel", true),
					numeric("wheel_interval", 30, { 10, 120 }),
					numeric("wheel_normal_chance", 5, { 0, 50 }),
					numeric("wheel_size", 130, { 60, 220 }),
					numeric("normal_duration", 20, { 5, 60 }),
					checkbox("fx_hog", true),
					numeric("hog_interval", 90, { 0, 300 }),
					numeric("hog_volume", 80, { 0, 100 }),
					checkbox("fx_dog", true),
					numeric("dog_size", 40, { 15, 80 }),
				},
			},
			{
				setting_id = "group_judas",
				type = "group",
				sub_widgets = {
					checkbox("fx_judas", true),
					numeric("judas_bosses", 3, { 1, 6 }),
					numeric("judas_volume", 100, { 0, 400 }),
					checkbox("judas_absolute", false),
				},
			},
			{
				setting_id = "group_void",
				type = "group",
				sub_widgets = {
					checkbox("fx_void", true),
					numeric("void_size", 20, { 5, 60 }),
					numeric("void_grow", 8, { 2, 30 }),
					numeric("void_interval", 70, { 0, 300 }),
				},
			},
			{
				setting_id = "group_skeleton",
				type = "group",
				sub_widgets = {
					checkbox("fx_skeleton", true),
					numeric("skeletons_per_minute", 4, { 0, 30 }),
					checkbox("skeleton_on_downed", true),
					checkbox("skeleton_on_peak", true),
					numeric("skeleton_volume", 80, { 0, 100 }),
					keybind("skeleton_keybind", "summon_skeleton"),
					checkbox("fx_alerts", true),
					numeric("alerts_per_minute", 2, { 0, 20 }),
					checkbox("fx_sniped", true),
					numeric("sniped_size", 45, { 10, 90 }),
				},
			},
			{
				setting_id = "group_triggers",
				type = "group",
				sub_widgets = {
					checkbox("trig_gas", true),
					checkbox("trig_corruption", true),
					checkbox("trig_peril", true),
					checkbox("trig_stimm", true),
					checkbox("trig_health", true),
					checkbox("trig_combat", true),
				},
			},
		},
	},
}
