local mod = get_mod("DiosWarpSickness")

--[[
    ========================================================================
    SCRAMBLED TEXT
    ========================================================================

    Keeps the first and last letter of each word and shuffles the middle,
    which stays just about readable. Low letters also flip b/d and p/q now and
    then. Numbers are left alone unless the overdose setting is on.

    The text pass hook lives in DWS_passes (it also rotates text). It swaps
    the content value for the length of the draw and puts it back, so nothing
    that reads the content later sees the scrambled string.

    Only while W.in_text_scope is set, which is only inside UIHud.draw and the
    subtitles draw. Menus, chat and Mod Options stay readable.

    THE CACHE IS THE POINT. The profiler overlay already shows heavy Lua heap
    churn on this machine. Building a new string for every text pass every
    frame would add to exactly that, so each source string is scrambled once
    per reshuffle window and the result reused until the window ends.

    Markup such as {#color(255,0,0)} in subtitles is copied through untouched.
--]]

local Scramble = {}

local W = mod.__dws

local random = math.random
local concat = table.concat
local byte, char, sub = string.byte, string.char, string.sub

local cache = {}
local cache_count = 0
local CACHE_MAX = 600
local last_regen = 0
local was_live = false

local MIRROR = { b = "d", d = "b", p = "q", q = "p" }

local function word(w, p, I)
	local n = #w

	if n >= 4 and random() < p then
		local mid = {}

		for i = 2, n - 1 do
			mid[#mid + 1] = sub(w, i, i)
		end

		-- Fisher-Yates, retried once so a short word usually comes out changed
		for _ = 1, 2 do
			for i = #mid, 2, -1 do
				local j = random(i)
				mid[i], mid[j] = mid[j], mid[i]
			end

			local candidate = sub(w, 1, 1) .. concat(mid) .. sub(w, n, n)

			if candidate ~= w then
				w = candidate
				break
			end
		end
	end

	if I > 0.3 and random() < 0.25 * I then
		w = w:gsub("[bdpq]", function(c)
			if random() < 0.5 then
				return MIRROR[c]
			end
		end)
	end

	return w
end

local function plain(seg, p, I, numbers)
	seg = seg:gsub("%a+", function(w)
		return word(w, p, I)
	end)

	if numbers then
		seg = seg:gsub("%d%d+", function(d)
			if random() < 0.5 * I then
				local i = random(#d - 1)
				return sub(d, 1, i - 1) .. sub(d, i + 1, i + 1) .. sub(d, i, i) .. sub(d, i + 2)
			end
		end)
	end

	return seg
end

local function build(s, p_override)
	local I = W.intensity
	local p = p_override or (0.4 + 0.6 * I)
	local numbers = W.S.scramble_numbers

	-- fast path: no markup
	if not s:find("{", 1, true) then
		return plain(s, p, I, numbers)
	end

	local out = {}
	local pos = 1
	local len = #s

	while pos <= len do
		local open = s:find("{", pos, true)

		if not open then
			out[#out + 1] = plain(sub(s, pos), p, I, numbers)
			break
		end

		if open > pos then
			out[#out + 1] = plain(sub(s, pos, open - 1), p, I, numbers)
		end

		local close = s:find("}", open, true)

		if not close then
			out[#out + 1] = sub(s, open)
			break
		end

		out[#out + 1] = sub(s, open, close)
		pos = close + 1
	end

	return concat(out)
end

--[[
    HEAVY: for chat. Every word of 2+ letters is fully shuffled (first and last
    letters too), letters flip case at random, and b/d/p/q mirror half the
    time. Numbers get swapped too. Its own cache, reshuffled on its own timer,
    so chat keeps changing even outside a mission where the trip is off.
--]]
local heavy_cache = {}
local heavy_count = 0
local heavy_regen = 0

local function heavy_word(w)
	local n = #w
	local letters = {}

	for i = 1, n do
		letters[i] = sub(w, i, i)
	end

	for i = n, 2, -1 do
		local j = random(i)
		letters[i], letters[j] = letters[j], letters[i]
	end

	for i = 1, n do
		local ch = letters[i]

		if MIRROR[ch:lower()] and random() < 0.5 then
			ch = MIRROR[ch:lower()]
		end

		if random() < 0.35 then
			ch = ch == ch:upper() and ch:lower() or ch:upper()
		end

		letters[i] = ch
	end

	return concat(letters)
end

local function heavy_plain(seg)
	seg = seg:gsub("%a%a+", heavy_word)
	seg = seg:gsub("%d%d+", function(d)
		local i = random(#d - 1)
		return sub(d, 1, i - 1) .. sub(d, i + 1, i + 1) .. sub(d, i, i) .. sub(d, i + 2)
	end)

	return seg
end

local function heavy_build(s)
	if not s:find("{", 1, true) then
		return heavy_plain(s)
	end

	local out = {}
	local pos = 1
	local len = #s

	while pos <= len do
		local open = s:find("{", pos, true)

		if not open then
			out[#out + 1] = heavy_plain(sub(s, pos))
			break
		end

		if open > pos then
			out[#out + 1] = heavy_plain(sub(s, pos, open - 1))
		end

		local close = s:find("}", open, true)

		if not close then
			out[#out + 1] = sub(s, open)
			break
		end

		out[#out + 1] = sub(s, open, close)
		pos = close + 1
	end

	return concat(out)
end

--[[
    LIGHT: chat. About a third of the longer words get their middle letters
    shuffled and the odd b/d flips - readable with a squint. Fixed strength,
    so it is the same in a mission and in the Mourningstar.
--]]
local light_cache = {}
local light_count = 0
local light_regen = 0

local function light_build(s)
	local saved_intensity = W.intensity
	local out

	W.intensity = 0.15
	out = build(s, 0.3)
	W.intensity = saved_intensity

	return out
end

function Scramble.text(s, heavy)
	if heavy == "light" then
		if W.t - light_regen > 1.5 or light_count >= CACHE_MAX then
			light_cache = {}
			light_count = 0
			light_regen = W.t
		end

		local hit = light_cache[s]

		if not hit then
			hit = light_build(s)
			light_cache[s] = hit
			light_count = light_count + 1
		end

		return hit
	end

	if heavy then
		if W.t - heavy_regen > 0.7 or heavy_count >= CACHE_MAX then
			heavy_cache = {}
			heavy_count = 0
			heavy_regen = W.t
		end

		local hit = heavy_cache[s]

		if not hit then
			hit = heavy_build(s)
			heavy_cache[s] = hit
			heavy_count = heavy_count + 1
		end

		return hit
	end

	local hit = cache[s]

	if hit then
		return hit
	end

	if cache_count >= CACHE_MAX then
		cache = {}
		cache_count = 0
	end

	local result = build(s)

	cache[s] = result
	cache_count = cache_count + 1

	return result
end

--[[
    Called once a frame from mod.update. Clears the cache at the reshuffle
    interval and raises W.force_dirty for one HUD frame so retained text
    passes pick up the new spelling (or the real one, when scrambling stops).
--]]
function Scramble.update(t)
	W.force_dirty = false

	local live = W.active and W.S.fx_scramble and W.intensity > 0.05

	W.scramble_live = live

	if live ~= was_live then
		was_live = live
		cache = {}
		cache_count = 0
		W.force_dirty = true
		last_regen = t
		return
	end

	if not live then
		return
	end

	local interval = 0.9 - 0.5 * W.intensity

	if t - last_regen >= interval then
		last_regen = t
		cache = {}
		cache_count = 0
		W.force_dirty = true
	end
end

--[[
    Subtitles are a constant element, not part of the HUD, so they need their
    own scope flag. hook_require because the class file is not loaded yet
    when this mod is.
--]]
local hooked_subtitles = false

mod:hook_require("scripts/ui/constant_elements/elements/subtitles/constant_element_subtitles", function(cls)
	if hooked_subtitles or type(cls) ~= "table" or type(cls.draw) ~= "function" then
		return
	end

	hooked_subtitles = true

	mod:hook(cls, "draw", function(func, self, ...)
		local before = W.in_text_scope

		W.in_text_scope = true
		func(self, ...)
		W.in_text_scope = before
	end)
end)

mod.__dws_scramble = Scramble

return Scramble
