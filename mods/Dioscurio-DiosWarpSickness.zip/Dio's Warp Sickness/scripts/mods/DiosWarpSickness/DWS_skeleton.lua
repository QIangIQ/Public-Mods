local mod = get_mod("DiosWarpSickness")

--[[
    ========================================================================
    SKELETONS
    ========================================================================

    SETS

    assets/skeletons/sets.txt lists set folders, one per line. A set is a
    folder of 1.png, 2.png ... (what Hud Studio's gif splitter writes), an
    optional sound file and an optional set.txt of key=value lines:

        fps, size (px tall at 1080p), facing (right/left, which way the art
        faces), duration (seconds on screen), sound, sound_start,
        sound_length, paths (run,tumble,spiral,peek,dance)

    A set whose 1.png is missing is skipped, so an empty "spooky" folder just
    falls back to the default skeleton.

    IMAGES: SimpleAssets is installed and enabled in this mods folder, so it
    is the loader. Handholder's exported loader (mod.__dio_assets) is the
    fallback. This mod ships no native runtime of its own: a second copy of
    either DLL in one process is exactly the conflict Handholder's
    DiosHandholder_assets.lua header explains.

    SOUND: real SimpleAudio if installed, otherwise Handholder's exported
    audio module (DiosHandholder_audio.lua), which carries the vendored
    runtime. With neither, skeletons still run, silently, and /warpsick says
    why.

    Nothing touches either backend during mod load. Frames are requested on
    the first update inside a mission, a few per frame, the same rule
    Handholder follows after the SoloPlay breakage.
--]]

local Skel = {}

local W = mod.__dws

local MOD_FOLDER = "Dio's Warp Sickness"
local ASSET_PREFIX = "mods/" .. MOD_FOLDER .. "/assets/skeletons/"
local DISK_PREFIX = ".\\..\\mods\\" .. MOD_FOLDER .. "\\assets\\skeletons\\"

local MAX_FRAMES = 240
local MAX_ATTEMPTS = 3
local REQUESTS_PER_FRAME = 4
local MAX_ACTIVE = 8

local sin, cos, abs, pi, min, max = math.sin, math.cos, math.abs, math.pi, math.min, math.max

local sets = nil          -- array of set tables once scanned
local pending = {}        -- frame load queue
local active = {}         -- running skeleton instances
local queued_spawns = {}  -- delayed spawns for the army
local last_sound_t = -100
local sound_note = "not tried yet"
local image_note = "not started"

--[[
    Textures handed out by url_loader are reference counted. On a mod reload
    the old frame table is gone but the references are not, so they are
    counted here in a table DMF keeps across reloads and released at the
    start of the next load. Same pattern as Hud Studio's simple_assets.lua.
--]]
local held = mod:persistent_table("held_urls")

if Managers.url_loader then
	for url, count in pairs(held) do
		for _ = 1, count do
			pcall(Managers.url_loader.unload_texture, Managers.url_loader, url)
		end

		held[url] = nil
	end
end

local function io_lib()
	return Mods and Mods.lua and Mods.lua.io or nil
end

local function file_exists(path)
	local io = io_lib()

	if not io then
		return false
	end

	local f = io.open(path, "rb")

	if f then
		f:close()
		return true
	end

	return false
end

local function read_lines(path)
	local io = io_lib()
	local f = io and io.open(path, "r")
	local lines = {}

	if not f then
		return lines
	end

	for line in f:lines() do
		line = line:gsub("\r", ""):match("^%s*(.-)%s*$")

		if line ~= "" and line:sub(1, 1) ~= "#" then
			lines[#lines + 1] = line
		end
	end

	f:close()

	return lines
end

local ALL_PATHS = { "run", "moonwalk", "ceiling", "wall", "any", "charge", "tumble", "spiral", "peek", "dance" }

local function scan_sets()
	sets = {}

	local names = read_lines(DISK_PREFIX .. "sets.txt")

	if #names == 0 then
		names = { "default" }
	end

	for i = 1, #names do
		local name = names[i]
		local disk = DISK_PREFIX .. name .. "\\"
		local count = 0

		while count < MAX_FRAMES and file_exists(disk .. (count + 1) .. ".png") do
			count = count + 1
		end

		if count > 0 then
			local cfg = {}

			for _, line in ipairs(read_lines(disk .. "set.txt")) do
				local k, v = line:match("^([%w_]+)%s*=%s*(.-)$")

				if k then
					cfg[k] = v
				end
			end

			local paths = {}

			for p in (cfg.paths or ""):gmatch("[%a]+") do
				paths[#paths + 1] = p
			end

			if #paths == 0 then
				paths = ALL_PATHS
			end

			local sound = cfg.sound and cfg.sound ~= "" and cfg.sound or nil

			if sound and not file_exists(disk .. sound) then
				sound = nil
			end

			sets[#sets + 1] = {
				name = name,
				count = count,
				frames = {},
				fps = tonumber(cfg.fps) or 12,
				size = tonumber(cfg.size) or 300,
				facing = cfg.facing == "left" and "left" or "right",
				duration = tonumber(cfg.duration) or 4,
				sound = sound,
				sound_start = tonumber(cfg.sound_start) or 0,
				sound_length = tonumber(cfg.sound_length),
				paths = paths,
				aspect = nil,
			}

			for f = 1, count do
				pending[#pending + 1] = { set = sets[#sets], index = f, attempts = 0 }
			end
		end
	end

	image_note = #sets > 0 and "loading" or "no set has a 1.png"
end

local function texture_loader()
	local sa = get_mod("SimpleAssets")

	if sa and type(sa.load_texture) == "function" then
		return sa.load_texture, "SimpleAssets"
	end

	local hh = get_mod("DiosHandholder")
	local assets = hh and rawget(hh, "__dio_assets")

	if assets and type(assets.load_texture) == "function" and assets.backend() ~= "none" then
		return assets.load_texture, "Handholder's bundled SimpleAssets"
	end

	return nil, "none"
end

-- Handholder's forget_failed_url: url_loader caches failures permanently.
local function forget_failed_url(url)
	if type(url) == "string" and url ~= "" and Managers.url_loader then
		pcall(Managers.url_loader.unload_texture, Managers.url_loader, url)
	end
end

local function request(load_texture, entry)
	local set = entry.set
	local ok, promise = pcall(load_texture, ASSET_PREFIX .. set.name .. "/" .. entry.index .. ".png")

	if not ok or not promise then
		image_note = "texture loader refused a request: " .. tostring(promise)
		return
	end

	promise:next(function(data)
		if data and data.texture then
			set.frames[entry.index] = data.texture

			if not set.aspect and data.width and data.height and data.height > 0 then
				set.aspect = data.width / data.height
			end

			if data.url then
				held[data.url] = (held[data.url] or 0) + 1
			end
		else
			mod:error("could not decode %s/%d.png", set.name, entry.index)
		end
	end, function(err)
		forget_failed_url(type(err) == "table" and err.url or nil)

		entry.attempts = entry.attempts + 1

		if entry.attempts < MAX_ATTEMPTS then
			pending[#pending + 1] = entry
		else
			mod:error("gave up on %s/%d.png", set.name, entry.index)
		end
	end)
end

local function pump()
	if #pending == 0 then
		return
	end

	local load_texture, backend = texture_loader()

	W.image_backend = backend

	if not load_texture then
		image_note = "no texture backend (SimpleAssets missing and Handholder not loaded)"
		return
	end

	local batch = {}

	for i = 1, min(REQUESTS_PER_FRAME, #pending) do
		batch[i] = table.remove(pending, 1)
	end

	for i = 1, #batch do
		request(load_texture, batch[i])
	end
end

-- ---------------------------------------------------------------- audio

local function audio_backend()
	local sa = get_mod("SimpleAudio")

	if sa and type(sa.play_file) == "function" and sa:is_enabled() then
		return sa, "SimpleAudio"
	end

	local hh = get_mod("DiosHandholder")
	local audio = hh and rawget(hh, "__dio_audio")

	if audio and type(audio.play_file) == "function" then
		return audio, "Handholder", hh
	end

	return nil, "none"
end

local warmed = false

function Skel.warm_audio(dt)
	local audio, kind, hh = audio_backend()

	W.audio_backend = kind

	if kind ~= "Handholder" then
		return
	end

	if not warmed then
		warmed = true
		pcall(audio.warm)
	end

	--[[
        Handholder pumps its own runtime from its own update. When Handholder
        is switched off in Mod Options that update stops, so pump it from
        here instead - never both, or the event queue is drained twice.
    --]]
	if not hh:is_enabled() then
		pcall(audio.update, dt)
	end
end

local function play_sound(set)
	if not set.sound then
		sound_note = "set '" .. set.name .. "' has no sound file"
		return
	end

	if W.t - last_sound_t < 2 then
		return
	end

	local audio, kind = audio_backend()

	if not audio then
		sound_note = "no audio backend: enable Dio's Handholder or install SimpleAudio"
		return
	end

	local settings = {
		audio_type = "sfx",
		volume = W.S.skeleton_volume or 80,
		pos = set.sound_start > 0 and set.sound_start or nil,
		duration = set.sound_length,
	}

	local path = ASSET_PREFIX .. set.name .. "/" .. set.sound
	local ok, id = pcall(audio.play_file, path, settings)

	last_sound_t = W.t
	sound_note = (ok and id) and ("playing via " .. kind) or ("play failed via " .. kind .. ": " .. tostring(id))
end

-- ---------------------------------------------------------------- spawning

local function pick_set(name)
	if not sets or #sets == 0 then
		return nil
	end

	if name then
		for i = 1, #sets do
			if sets[i].name == name then
				return sets[i]
			end
		end
	end

	-- prefer any set other than the default one when it exists
	local custom = {}

	for i = 1, #sets do
		if sets[i].name ~= "default" then
			custom[#custom + 1] = sets[i]
		end
	end

	if #custom > 0 and math.random() < 0.75 then
		return custom[math.random(#custom)]
	end

	return sets[math.random(#sets)]
end

--[[
    RUNNING IN ANY DIRECTION

    The rotation convention was read off the game's own world markers
    (hud_element_world_markers.lua ~line 414): an edge arrow clamped left is
    angle 0, up is +pi/2, right is pi. So a positive angle turns the image
    clockwise on screen, and with y pointing down the image's +x axis lands
    on (cos a, sin a) and its "down" (0, 1) lands on (-sin a, cos a).

    So for any surface the skeleton runs on, pick the angle that points its
    feet at that surface, then run along (cos a, sin a) one way or the other.
    Mirroring the uvs is what makes it face the way it runs - or the other
    way, for a moonwalk.

        floor     a = 0          feet down
        ceiling   a = pi         upside down
        left wall a = pi/2       feet on the left edge
        right wall a = -pi/2
        any       a = random     straight through a random point on screen
--]]
local function line_path(s, set, path, h, w)
	local a, px, py, L

	if path == "run" or path == "moonwalk" then
		a, px, py, L = 0, 960, 1080 - h / 2 - 30, 960 + w
	elseif path == "ceiling" then
		a, px, py, L = pi, 960, h / 2 + 20, 960 + w
	elseif path == "wall" then
		if math.random() < 0.5 then
			a, px, py = pi / 2, h / 2 + 20, 540
		else
			a, px, py = -pi / 2, 1920 - h / 2 - 20, 540
		end

		L = 540 + w
	else -- any
		a = math.random() * 2 * pi
		px, py = 560 + math.random() * 800, 290 + math.random() * 500
		L = 1250 + h
	end

	local sign = math.random() < 0.5 and 1 or -1
	local backwards = path == "moonwalk" or (path ~= "run" and math.random() < 0.2)

	s.a = a
	s.px, s.py, s.L = px, py, L
	s.tx, s.ty = sign * cos(a), sign * sin(a)
	-- facing on screen = art facing * mirror, rotated by a; make it match the travel sign
	local art = set.facing == "right" and 1 or -1
	local want = backwards and -sign or sign

	s.flip = art ~= want
	s.nx, s.ny = sin(a), -cos(a) -- the image's "up" on screen, for the running bob
end

local LINE_PATHS = { run = true, moonwalk = true, ceiling = true, wall = true, any = true }

local function spawn(set, path, with_sound)
	if #active >= MAX_ACTIVE then
		return
	end

	path = path or set.paths[math.random(#set.paths)]

	local dir = math.random() < 0.5 and 1 or -1

	--[[
        Size: mostly between a third and double size, sometimes a giant.
        The power curve keeps most of them small-to-normal so the giants
        stay a surprise.
    --]]
	local size_roll = math.random()
	local scale = size_roll < 0.1 and (2.6 + math.random() * 1.4) or (0.35 + math.random() ^ 1.5 * 1.8)

	local dur = path == "dance" and set.duration or min(set.duration, 4.5)

	if path == "charge" then
		dur = 2 + math.random() * 0.8
	elseif scale > 2 then
		dur = dur * 1.4 -- giants lumber
	elseif scale < 0.6 then
		dur = dur * 0.75 -- little ones scurry
	end

	local s = {
		set = set,
		path = path,
		t = 0,
		scale = path == "charge" and 1 or scale,
		dur = dur,
		vx = 760 + math.random() * 400,
		vy = 380 + math.random() * 260,
		drift = (math.random() * 2 - 1) * 900,
		dir = dir,
		x0 = 200 + math.random() * 1400,
		spin = (math.random() < 0.5 and -1 or 1) * (4 + math.random() * 4),
	}

	if LINE_PATHS[path] then
		local h = set.size * s.scale
		line_path(s, set, path, h, h * (set.aspect or 0.8))
	end

	active[#active + 1] = s

	if with_sound then
		play_sound(set)
	end
end

function Skel.summon(set_name, count)
	if not sets then
		scan_sets()
	end

	local set = pick_set(set_name)

	if not set then
		return false
	end

	count = count or 1
	spawn(set, nil, true)

	for i = 2, count do
		queued_spawns[#queued_spawns + 1] = { at = W.t + 0.45 * (i - 1), set = set }
	end

	return true
end

-- ---------------------------------------------------------------- per frame

function Skel.update(dt)
	if not W.in_mission then
		return
	end

	if not sets then
		scan_sets()
	end

	pump()

	for i = #queued_spawns, 1, -1 do
		local q = queued_spawns[i]

		if W.t >= q.at then
			table.remove(queued_spawns, i)
			spawn(q.set, nil, false)
		end
	end

	for i = #active, 1, -1 do
		local s = active[i]

		s.t = s.t + dt

		if s.t >= s.dur then
			table.remove(active, i)
		end
	end
end

function Skel.clear()
	active = {}
	queued_spawns = {}
end

local UV_NORMAL = { { 0, 0 }, { 1, 1 } }
local UV_FLIP = { { 1, 0 }, { 0, 1 } }

--[[
    Returns what slot i should draw this frame, in 1920x1080 space with a
    top-left origin (the fullscreen "fit" node never aligns - see
    HudElementDiosJumpscare's header in Handholder).
--]]
function Skel.slot(i, out)
	local s = active[i]

	if not s then
		return nil
	end

	local set = s.set
	local count = set.count
	local frame = (math.floor(s.t * set.fps) % count) + 1
	local tex = set.frames[frame]

	-- hold the last frame that did arrive rather than flicker (Hud Studio's sequence.shown)
	if not tex then
		tex = s.shown
	else
		s.shown = tex
	end

	local h = set.size * (s.scale or 1)
	local w = h * (set.aspect or 0.8)
	local p = s.t / s.dur
	local x, y, angle, scale, alpha = 0, 0, 0, 1, 255
	local moving_right = s.dir > 0
	local forced_flip = nil

	if s.a then
		local k = s.L * (2 * p - 1)
		local bob = abs(sin(s.t * 9)) * 16
		local cx = s.px + s.tx * k + s.nx * bob
		local cy = s.py + s.ty * k + s.ny * bob

		x, y = cx - w / 2, cy - h / 2
		angle = s.a + 0.06 * sin(s.t * 9)
		forced_flip = s.flip
	elseif s.path == "charge" then
		--[[
            Running straight at the camera: starts tiny at a vanishing point
            near the middle and grows exponentially until it is bigger than
            the screen, drifting off to one side as it "passes" you.
        --]]
		local k = 0.06 * (5.5 / 0.06) ^ (p ^ 1.6)
		local cx = s.vx + s.drift * p ^ 2
		local cy = s.vy + 260 * p ^ 2 - abs(sin(s.t * 10)) * 12 * k

		scale = k
		x, y = cx - w * k / 2, cy - h * k / 2
		angle = 0.05 * sin(s.t * 10)
		alpha = 255 * min(1, (1 - p) / 0.12, s.t / 0.15)
		forced_flip = (set.facing == "right") ~= (s.drift > 0)
	elseif s.path == "tumble" then
		local from, to = -w, 1920

		if not moving_right then
			from, to = 1920, -w
		end

		x = from + (to - from) * p
		y = -h + (1080 + h) * p
		angle = s.spin * s.t
		scale = 0.8
	elseif s.path == "spiral" then
		local r = 760 * (1 - p)
		local th = s.dir * 3 * pi * p

		scale = 0.25 + 1.0 * (1 - p)
		x = 960 + r * cos(th) - w * scale / 2
		y = 540 + 0.55 * r * sin(th) - h * scale / 2
		angle = th * 1.5
		moving_right = sin(th) * s.dir < 0
	elseif s.path == "peek" then
		local show

		if p < 0.25 then
			show = p / 0.25
		elseif p > 0.75 then
			show = (1 - p) / 0.25
		else
			show = 1
		end

		x = s.x0
		y = 1080 - h * 0.7 * show
		angle = 0.25 * sin(s.t * 7)
	else -- dance
		local fade = min(1, s.t / 0.4, (s.dur - s.t) / 0.6)

		x = s.x0 + 40 * sin(s.t * 2)
		y = 1080 - h - 20
		angle = 0.12 * sin(s.t * 4)
		alpha = 255 * max(0, fade)
	end

	-- the art faces set.facing; flip it when moving the other way
	local flip = forced_flip

	if flip == nil then
		flip = (set.facing == "right") ~= moving_right
	end

	out.texture = tex
	out.x, out.y = x, y
	out.w, out.h = w * scale, h * scale
	out.angle = angle
	out.alpha = alpha
	out.uvs = flip and UV_FLIP or UV_NORMAL

	return out
end

function Skel.describe()
	local lines = {}

	if not sets then
		lines[1] = "sets not scanned yet (enter a mission)"
		return lines
	end

	for i = 1, #sets do
		local set = sets[i]
		local n = 0

		for f = 1, set.count do
			if set.frames[f] then
				n = n + 1
			end
		end

		lines[#lines + 1] = string.format("set %s: %d/%d frames, %s fps, sound %s", set.name, n, set.count,
			tostring(set.fps), set.sound or "none")
	end

	local total, got = 0, 0

	for i = 1, #sets do
		total = total + sets[i].count

		for f = 1, sets[i].count do
			if sets[i].frames[f] then
				got = got + 1
			end
		end
	end

	local note = (total > 0 and got == total) and "all loaded" or image_note

	lines[#lines + 1] = "images: " .. note .. " (" .. tostring(W.image_backend or "?") .. ")"
	lines[#lines + 1] = "sound: " .. sound_note .. " (" .. tostring(W.audio_backend or "?") .. ")"

	return lines
end

--[[
    One-off textures (the alert crossbones) through the same loader and the
    same reload bookkeeping as the frames.
--]]
local singles = {}

function Skel.texture(relative)
	local entry = singles[relative]

	if entry then
		return entry.texture
	end

	entry = {}
	singles[relative] = entry

	local load_texture = texture_loader()

	if not load_texture then
		singles[relative] = nil
		return nil
	end

	local ok, promise = pcall(load_texture, "mods/" .. MOD_FOLDER .. "/assets/" .. relative)

	if ok and promise then
		promise:next(function(data)
			if data and data.texture then
				entry.texture = data.texture
				-- the real pixel size, so a replaced file is drawn at its own shape
				entry.w, entry.h = data.width, data.height

				if data.url then
					entry.url = data.url
					held[data.url] = (held[data.url] or 0) + 1
				end
			end
		end, function(err)
			forget_failed_url(type(err) == "table" and err.url or nil)
			singles[relative] = nil
		end)
	else
		singles[relative] = nil
	end

	return nil
end

--[[
    The width and height of a loaded single texture, or nil while it is still
    on its way. Callers use it to keep a picture's proportions.
--]]
function Skel.texture_size(relative)
	local entry = singles[relative]

	if not entry or not entry.w or not entry.h or entry.h == 0 then
		return nil
	end

	return entry.w, entry.h
end

--[[
    Drop every single texture so the files are read again. Their url_loader
    references are given back first, or the old image stays in memory and the
    count in `held` never comes down.
--]]
function Skel.forget_singles()
	for relative, entry in pairs(singles) do
		local url = entry.url

		if url and Managers.url_loader then
			pcall(Managers.url_loader.unload_texture, Managers.url_loader, url)

			local count = (held[url] or 0) - 1
			held[url] = count > 0 and count or nil
		end

		singles[relative] = nil
	end
end

function Skel.play(relative, volume)
	local audio, kind = audio_backend()

	if not audio then
		return false
	end

	local ok, id = pcall(audio.play_file, "mods/" .. MOD_FOLDER .. "/assets/" .. relative, {
		audio_type = "sfx",
		volume = volume or W.S.skeleton_volume or 80,
	})

	return ok and id
end

--[[
    A long track rather than a one-shot: loop is passed to the backend, which
    turns it into loop_count -1, and the play id comes back so it can be
    stopped. audio_type "sfx" rather than "music", so it follows the effects
    slider the way the skeleton noises do.
--]]
function Skel.play_loop(relative, volume, loop)
	local audio = audio_backend()

	if not audio then
		return false
	end

	local ok, id = pcall(audio.play_file, "mods/" .. MOD_FOLDER .. "/assets/" .. relative, {
		audio_type = "sfx",
		volume = volume or 100,
		loop = loop and true or nil,
	})

	return ok and id
end

function Skel.stop_sound(id, fade)
	local audio = audio_backend()

	if not audio or not id or type(audio.stop) ~= "function" then
		return false
	end

	local ok, stopped = pcall(audio.stop, id, fade or 0.4)

	return ok and stopped
end

--[[
    Whether this backend can stop a sound once it has started. Nothing should
    start an endless loop without it.
--]]
--[[
    How long a sound file runs, in seconds, or nil if the backend will not
    say. Only needed by callers that cannot loop and have to restart a track
    themselves.
--]]
function Skel.sound_length(relative)
	local audio = audio_backend()

	if not audio then
		return nil
	end

	local path = "mods/" .. MOD_FOLDER .. "/assets/" .. relative

	if type(audio.duration) == "function" then
		local ok, secs = pcall(audio.duration, path)

		return ok and tonumber(secs) or nil
	end

	if type(audio.file_info) == "function" then
		local ok, info = pcall(audio.file_info, path)

		if ok and type(info) == "table" then
			return tonumber(info.duration)
		end
	end

	return nil
end

--[[
    Stop every sound the backend has going, including any whose play id was
    lost. For the panic button only: it stops other mods' sounds too.
--]]
function Skel.stop_all(fade)
	local audio = audio_backend()

	if not audio then
		return false
	end

	if type(audio.stop_all) == "function" then
		local ok, stopped = pcall(audio.stop_all, fade or 0.3)

		return ok and stopped and true or false
	end

	-- SimpleAudio's own stop takes a nil id as "all of them"
	if type(audio.stop) == "function" then
		local ok, stopped = pcall(audio.stop, nil, fade or 0.3)

		return ok and stopped and true or false
	end

	return false
end

--[[
    Can this backend give a straight answer about whether a sound is still
    going? Without one there is no way to tell a sound that has stopped from
    a sound nothing can reach, so nothing endless gets started.
--]]
function Skel.can_verify()
	local audio = audio_backend()

	if not audio then
		return false
	end

	-- Handholder answers for itself: only its vendored runtime can report
	if type(audio.can_verify) == "function" then
		local ok, can = pcall(audio.can_verify)

		return ok and can and true or false
	end

	return type(audio.is_playing) == "function"
end

--[[
    true / false, or nil when the backend cannot answer. Callers must treat
    nil as "no idea" rather than "stopped".

    This used to end `return playing and true or false`, which turned every
    "no idea" into "stopped". The caller then dropped the id believing the
    sound had ended, and the sound played on with nothing left to stop it.
--]]
function Skel.is_playing(id)
	local audio = audio_backend()

	if not audio or not id or not Skel.can_verify() then
		return nil
	end

	local ok, playing = pcall(audio.is_playing, id)

	if not ok or playing == nil then
		return nil
	end

	return playing and true or false
end

function Skel.can_stop()
	local audio = audio_backend()

	if not audio then
		return false
	end

	if type(audio.can_stop) == "function" then
		local ok, can = pcall(audio.can_stop)

		return ok and can and true or false
	end

	return type(audio.stop) == "function"
end

function Skel.rescan()
	sets = nil
	pending = {}
	Skel.clear()
	Skel.forget_singles()
end

mod.__dws_skeleton = Skel

return Skel
