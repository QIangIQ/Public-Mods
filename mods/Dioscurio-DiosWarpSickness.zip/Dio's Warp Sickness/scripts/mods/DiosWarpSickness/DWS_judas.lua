local mod = get_mod("DiosWarpSickness")

--[[
    ========================================================================
    JUDAS MODE
    ========================================================================

    When things are actually serious the joke stops: the HUD goes back to
    normal, the dog turns up on the side of the screen, and Judas plays on
    a loop.

    It switches on when any of these is true:
      * you are the only player still up (everybody else dead, downed or
        grabbed), and there is more than one player in the mission
      * at least "Bosses needed" bosses are in an encounter with you, which
        is the same thing as that many boss health bars on your screen
      * you put the mod in sober mode yourself

    It switches off when none of them is true any more, after a short hold so
    a teammate being picked up and going straight back down does not chop the
    music in half.

    BOSSES
    BossExtension triggers "boss_encounter_start" and "boss_encounter_end"
    with the unit (boss_extension.lua:89,97); that pair is what puts a boss
    health bar on the screen, so counting it counts what you can see. Dead
    units are pruned as well, in case an end event is ever missed.

    MUSIC
    The audio backend loops natively (loop_count -1). A loop has to be
    stoppable or it runs until the game closes, so if the backend cannot stop
    a sound the track is played once instead of looped.
--]]

local Judas = {}

local W = mod.__dws

-- required, not global: the game does not put these utilities in _G
local PlayerUnitStatus = require("scripts/utilities/attack/player_unit_status")

local min, max = math.min, math.max

local TRACK = "judas/judas.mp3"
local TRACK_LEN = 249 -- judas.mp3 is 4:09; the fallback when the backend will not give a length
--[[
    Two different waits, for two different jobs.

    START_GAP debounces the start itself, so a condition that flips on and
    off inside a few frames cannot fire the track twice. It is short, because
    the real protection against stacking is the rule that nothing starts
    while any handle is outstanding.

    BLIND_WAIT is the long one, and it only applies when the backend could
    not confirm a stop. There the old copy may well still be audible and
    cannot be cut short, so the only safe thing is to wait it out. Using the
    long wait for both made a legitimate re-trigger sit in silence for eight
    seconds.
--]]
local START_GAP = 1.5
local BLIND_WAIT = 8
local ASKS = 4 -- how many times a sound is asked to stop before it is let go
local CHECK = 0.25 -- seconds between condition checks
local HOLD = 5 -- seconds the mode stays on after the conditions clear
local RETRY = 6 -- seconds before another attempt at starting the track
local TRIES = 3
--[[
    The music outlives the mode by this much. Somebody being revived and going
    straight back down flips the mode on and off; without this the track would
    be cut off and restarted from the top every time.
--]]
local LINGER = 10

local bosses = {}
local listener = nil
local check_in = 0
local hold_left = 0
local on = false
local play_id = nil
local music_until = 0
local tries = 0
local retry_in = 0
local block_until = 0 -- nothing new starts before this
local replay_at = 0 -- when a one-shot will have finished on its own
local looping = false
local no_stop_warned = false
local forced = nil -- nil = decide from the conditions, true/false = /warpjudas

-- ------------------------------------------------------------------ bosses

local function boss_handle()
	if listener then
		return listener
	end

	local events = Managers and Managers.event

	if not events then
		return nil
	end

	--[[
        A reload leaves the old table registered, and the event manager keeps
        it alive. The handle is parked in a DMF persistent table so the next
        load can take it back off again first.
    --]]
	local keep = mod:persistent_table("judas_listener")
	local old = keep.handle

	if old then
		pcall(events.unregister, events, old, "boss_encounter_start")
		pcall(events.unregister, events, old, "boss_encounter_end")
		keep.handle = nil
	end

	listener = {
		boss_start = function(_, unit)
			if unit then
				bosses[unit] = true
			end
		end,
		boss_end = function(_, unit)
			if unit then
				bosses[unit] = nil
			end
		end,
	}

	local ok = pcall(events.register, events, listener, "boss_encounter_start", "boss_start")

	if not ok then
		listener = nil

		return nil
	end

	pcall(events.register, events, listener, "boss_encounter_end", "boss_end")
	keep.handle = listener

	return listener
end

function Judas.forget_listener()
	local events = Managers and Managers.event

	if listener and events then
		pcall(events.unregister, events, listener, "boss_encounter_start")
		pcall(events.unregister, events, listener, "boss_encounter_end")
	end

	local keep = mod:persistent_table("judas_listener")
	keep.handle = nil
	listener = nil

	for unit in pairs(bosses) do
		bosses[unit] = nil
	end
end

local function boss_count()
	local n = 0

	for unit in pairs(bosses) do
		if Unit.alive(unit) then
			n = n + 1
		else
			bosses[unit] = nil
		end
	end

	return n
end

-- ----------------------------------------------------------------- players

--[[
    How many players are still on their feet, and whether I am one of them.
    Knocked down, hogtied, pounced, netted, grabbed and ledge hanging all
    count as not up: PlayerUnitStatus.is_disabled covers the lot.
--]]
local function is_down(unit)
	local unit_data = ScriptUnit.has_extension(unit, "unit_data_system")

	if not unit_data then
		return false
	end

	-- guards itself rather than relying on the caller's pcall: a unit being
	-- torn down can raise in here, and this is called for every player
	local ok_cs, cs = pcall(unit_data.read_component, unit_data, "character_state")

	if not ok_cs or not cs then
		return false
	end

	return PlayerUnitStatus.is_disabled(cs) or PlayerUnitStatus.is_dead(cs) or false
end

local function read_player_unit(player)
	return player.player_unit
end

-- a player who has left is a destroyed object; any property read raises
local function player_unit(player)
	if not player then
		return nil
	end

	local ok, unit = pcall(read_player_unit, player)

	return ok and unit or nil
end

local function players_up()
	local pm = Managers and Managers.player

	if not pm or not pm.players then
		return 0, 0, false
	end

	local ok_list, players = pcall(pm.players, pm)

	if not ok_list or type(players) ~= "table" then
		return 0, 0, false
	end

	local me = W.me
	local total, up, me_up = 0, 0, false

	for _, player in pairs(players) do
		local unit = player_unit(player)

		if unit then
			total = total + 1

			if Unit.alive(unit) then
				local ok, down = pcall(is_down, unit)

				--[[
                    If the state cannot be read, treat them as on their feet.
                    Guessing the other way would announce you as the last one
                    standing on the strength of a failed lookup.
                --]]
				if not ok then
					down = false
				end

				if not down then
					up = up + 1

					if unit == me then
						me_up = true
					end
				end
			end
		end
	end

	-- the number on their feet who are not me: 0 means I am the only one left,
	-- whether I am still up or crawling about waiting for a rescue that is not coming
	return total, up, me_up, up - (me_up and 1 or 0)
end

-- ------------------------------------------------------------------- music

local function audio()
	local Skel = mod.__dws_skeleton

	return Skel
end

--[[
    EVERY id this mod has started and not seen the end of.

    It lives in a DMF persistent table so that a mod reload, which builds a
    fresh copy of this file, can still find and stop whatever the previous
    copy left playing. Losing a handle means a track nothing can ever stop.
--]]
local sounds = mod:persistent_table("judas_sounds")

sounds.live = sounds.live or {}

local live = sounds.live

local function live_count()
	local n = 0

	for _ in pairs(live) do
		n = n + 1
	end

	return n
end

--[[
    ONE sound at a time, and never one that cannot be accounted for.

    `live` holds every id started and not yet seen the end of. While anything
    is in it nothing new starts, so a copy that could not be stopped can never
    be joined by a second. That single rule is what stops the stacking: before
    it, each failed stop quietly left a track playing and freed the slot for
    another one.
--]]
local function start_track()
	local Skel = audio()

	if not Skel or play_id or next(live) or tries >= TRIES then
		return
	end

	if retry_in > 0 or W.t < block_until then
		return
	end

	local volume = W.S.judas_volume or 100

	--[[
        "Ignore the game's volume sliders" divides the master and effects
        sliders back out, so the number in the options is the whole story.
        options.lua multiplies them in, so this cancels exactly.
    --]]
	local app = rawget(_G, "Application")

	if W.S.judas_absolute and app and app.user_setting then
		local ok, master = pcall(app.user_setting, "sound_settings", "option_master_slider")
		local ok2, sfx = pcall(app.user_setting, "sound_settings", "options_sfx_slider")
		local factor = ((ok and master or 100) / 100) * ((ok2 and sfx or 100) / 100)

		if factor > 0.01 then
			volume = min(volume / factor, 2000)
		end
	end

	--[[
        An endless loop is only safe when the backend can both stop a sound
        AND say whether it is still going. Without the second half a stop that
        quietly failed is indistinguishable from one that worked, and the
        track runs to the end of the session.

        So when the backend cannot answer, the track is played as a one-shot
        and started again when it has run its length. That ends by itself
        whatever happens, which is the point.
    --]]
	local loop = Skel.can_stop() and Skel.can_verify()

	if not loop and not no_stop_warned then
		no_stop_warned = true
		mod:warning("[judas] this audio backend cannot confirm a sound has stopped, so the track is replayed in one-shots rather than looped")
	end

	local id = Skel.play_loop(TRACK, volume, loop)

	if id then
		play_id = id
		looping = loop
		live[id] = { asked = nil, fade = 0, asks = 0 }
		--[[
            Ask the backend how long the file actually is, so swapping
            judas.mp3 for something else does not leave a silent gap or an
            overlap. TRACK_LEN is only the fallback for a backend that will
            not say.
        --]]
		if not loop then
			local secs = Skel.sound_length(TRACK)

			replay_at = W.t + (secs and secs > 1 and secs or TRACK_LEN)
			live[id].ends_at = replay_at
		else
			replay_at = 0
		end
		tries = 0
		block_until = W.t + START_GAP
	else
		tries = tries + 1
		retry_in = RETRY
	end
end

--[[
    Ask every live sound to stop, and keep asking.

    The id is only forgotten once the backend says the sound has ended, or
    says it cannot tell. Dropping the handle on an unconfirmed stop is what
    made the track unstoppable: nothing was left to ask again, and the next
    trigger started a second copy over the top of the first.
--]]
local function stop_track(fade)
	local Skel = audio()

	play_id = nil
	tries = 0
	retry_in = 0

	if not Skel then
		return
	end

	fade = fade or 0.6

	for id, state in pairs(live) do
		--[[
            Ask first, every time, before deciding anything. The old order
            looked at the backend first and dropped the id when it answered
            "not playing" - which is also what it answered when it had no way
            to tell. The sound was never actually asked to stop, and the
            handle was gone.
        --]]
		if not state.asked or W.t - state.asked > state.fade + 1.5 then
			state.asked = W.t
			state.fade = fade
			state.asks = (state.asks or 0) + 1
			Skel.stop_sound(id, fade)
		end

		local playing = Skel.is_playing(id)

		if playing == false then
			-- the backend says it has ended; this is the only clean exit
			live[id] = nil
		elseif state.asks >= (playing == nil and 1 or ASKS) then
			--[[
                Either the backend cannot tell us, or it has been asked enough
                times and still says the sound is going. Let the handle go so
                the mode is not wedged shut for good, but hold off starting
                anything until that sound must be over.

                For a one-shot we know exactly when that is, because the
                length was read when it started: a track that cannot be cut
                short has to be waited out, or the next trigger lands on top
                of it. Without a length, a short pause is the best that can be
                done.
            --]]
			live[id] = nil
			block_until = max(block_until, state.ends_at or (W.t + fade + BLIND_WAIT))
		end
	end
end

-- ------------------------------------------------------------------- state

function Judas.on()
	return on
end

function Judas.boss_count()
	return boss_count()
end

function Judas.describe()
	local total, up, me_up, others_up = players_up()

	local Skel = audio()

	return string.format("judas %s%s | bosses on screen %d (need %d) | players up %d of %d (%d of them not you), you up %s | track %s | backend can stop: %s, can confirm a stop: %s",
		on and "ON" or "off", forced ~= nil and (forced and " (forced on)" or " (forced off)") or "",
		boss_count(), W.S.judas_bosses or 3, up, total, others_up, tostring(me_up),
		play_id and "playing" or "silent", tostring(Skel and Skel.can_stop()),
		tostring(Skel and Skel.can_verify())) ..
		string.format(" | sounds being tracked: %d%s", live_count(),
			W.t < block_until and string.format(" | no new start for %.0fs", block_until - W.t) or "")
end

--[[
    Should the mode be on right now? Kept apart from the update loop so the
    whole thing can be pcall'd: a lookup that throws must not be able to leave
    the mode stuck on with the music running.
--]]
local function wants_judas()
	local S = W.S

	if forced ~= nil then
		return forced
	end

	-- sober mode you chose yourself counts; the wheel's NORMAL does not
	if W.sober and not W.calm_until then
		return true
	end

	if boss_count() >= max(S.judas_bosses or 3, 1) then
		return true
	end

	local total, _, _, others_up = players_up()

	if total >= 2 and others_up == 0 and W.me then
		return true
	end

	return false
end

--[[
    Returns true when the mode changed this tick, so the caller can calm the
    HUD down or let it loose again.
--]]
function Judas.update(dt, mission)
	local S = W.S

	if retry_in > 0 then
		retry_in = max(0, retry_in - dt)
	end

	if not mission or not S.fx_judas then
		local was = on

		on = false
		music_until = 0
		-- called every frame, not once: a stop that did not take is retried
		stop_track()

		if not mission then
			Judas.forget_listener()
		end

		return was
	end

	boss_handle()

	check_in = check_in - dt

	if check_in <= 0 then
		check_in = CHECK

		local ok_want, want = pcall(wants_judas)

		if not ok_want then
			want = false
		end

		if want then
			hold_left = HOLD
		else
			hold_left = max(0, hold_left - CHECK)
		end
	end

	local now = hold_left > 0

	if now then
		music_until = W.t + LINGER
	end

	--[[
        The music runs on its own clock rather than the mode's. Somebody being
        picked up and going straight back down flicks the mode on and off;
        letting the track run on for LINGER seconds means it carries through
        instead of being cut off and restarted from the top each time.
    --]]
	--[[
        A one-shot ends on its own. Retire the handle at that point so the
        next start is allowed, which is what makes the no-loop path repeat.
    --]]
	if play_id and not looping and replay_at > 0 and W.t >= replay_at then
		live[play_id] = nil
		play_id = nil
		replay_at = 0
	end

	if W.t < music_until then
		start_track()
	elseif play_id or next(live) then
		stop_track()
	end

	if now ~= on then
		on = now

		return true
	end

	return false
end

--[[
    The volume is fixed when the sound starts, so a slider moved mid-track
    only counts after a restart. Do that restart rather than make him wait.
--]]
--[[
    The volume is fixed when the sound starts, so the track has to be
    restarted for a new slider position to be heard.

    Stop only - the update loop starts the next one. Starting here would mean
    starting on top of a sound that is still fading, which is how the slider
    appeared not to work before: the old copy was never actually stopped, so
    the new one just played over the top of it.

    This is a restart of the same track rather than a fresh trigger, so the
    usual gap between starts does not apply - but only once the stop has been
    confirmed. If the backend cannot confirm it, the wait stands, because
    there the old copy is still audible and cannot be cut short.
--]]
function Judas.volume_changed()
	if not play_id and not next(live) then
		return
	end

	stop_track(0.15)

	if not next(live) then
		block_until = 0
	end
end

--[[
    /warpjudas: true pins it on, false pins it off, nil hands it back to the
    conditions.
--]]
function Judas.force(state)
	forced = state
	check_in = 0
	tries = 0
	retry_in = 0

	if state == false then
		hold_left = 0
		music_until = 0
		stop_track(0)
	end
end

--[[
    Panic button: stop every sound this mod has going and pin the mode off,
    because otherwise the next tick would see the same conditions and start
    the track again a sixtieth of a second later.
--]]
function Judas.silence()
	local before = live_count()

	forced = false
	hold_left = 0
	music_until = 0
	check_in = 0
	stop_track(0)

	--[[
        Then the blunt instrument: stop every sound the backend has, whether
        this mod knows its id or not. A copy whose handle was lost cannot be
        reached any other way, and that is exactly what a panic button is for.
        It silences the skeletons too, which is a fair price.
    --]]
	local Skel = audio()
	local nuked = Skel and Skel.stop_all(0.3) or false

	for id in pairs(live) do
		live[id] = nil
	end

	play_id = nil

	-- nothing starts again until it is asked for, so the conditions coming
	-- back a tenth of a second later cannot undo this
	block_until = W.t + 30

	return before, nuked
end

--[[
    You have deliberately stopped asking for Judas mode.

    HOLD and LINGER exist for the automatic triggers, which flicker: a
    teammate revived and downed again a second later would otherwise chop the
    track and restart it from the top. A button press is not flicker - it
    means now.

    This does NOT force the music off. It drops the hold and the linger and
    asks for the conditions to be re-checked on the next update, so if
    something else still wants Judas (you are the last one standing, bosses
    are up) the track carries straight on without a gap.
--]]
function Judas.release()
	hold_left = 0
	music_until = 0
	check_in = 0
end

function Judas.forced()
	return forced
end

--[[
    Shutdown: the mod is being switched off or unloaded. Ask for the tracked
    handles first, then tell the backend to stop everything, because an
    orphaned copy is exactly what someone switching the mod off in a panic is
    trying to get rid of.
--]]
function Judas.clear()
	hold_left = 0
	music_until = 0
	on = false
	block_until = 0
	stop_track(0)

	local Skel = audio()

	if Skel then
		pcall(Skel.stop_all, 0.2)
	end

	for id in pairs(live) do
		live[id] = nil
	end

	play_id = nil
end

function Judas.boss_seen(unit)
	bosses[unit] = true
end

mod.__dws_judas = Judas

return Judas
