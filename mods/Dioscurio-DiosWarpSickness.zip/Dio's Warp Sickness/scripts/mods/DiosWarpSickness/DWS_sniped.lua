local mod = get_mod("DiosWarpSickness")

--[[
    ========================================================================
    SNIPED
    ========================================================================

    A picture punches onto the middle of the screen when a sniper hits you,
    shakes for a moment and fades. Short on purpose: you have just been shot
    and you still need to see where it came from.

    The picture is assets/sniped/sniped.png, whatever that file happens to
    be. Its shape is read from the loaded texture rather than assumed, so a
    replacement of any proportions is drawn at its own aspect ratio instead
    of being stretched. /warprescan re-reads it without restarting the game.

    This module only keeps the state; HudElementDiosWarpSickness draws it.
--]]

local Sniped = {}

local W = mod.__dws

local sin, min, max, random = math.sin, math.min, math.max, math.random

local PATH = "sniped/sniped.png"
local PUNCH = 0.14 -- scale-down from oversized, so it lands like a slap
local HOLD = 1.1
local FADE = 0.4

local state = nil
local preloaded = false

local function preload()
	local Skel = mod.__dws_skeleton

	if preloaded or not Skel then
		return
	end

	preloaded = true
	Skel.texture(PATH)
end

function Sniped.clear()
	state = nil
end

function Sniped.hit()
	preload()

	state = {
		t = 0,
		tilt = (random() < 0.5 and -1 or 1) * (0.04 + random() * 0.05),
		phase = random() * 6.2832,
	}

	return true
end

function Sniped.update(dt)
	if not W.active or not W.S.fx_sniped then
		state = nil

		return
	end

	preload()

	local s = state

	if not s then
		return
	end

	s.t = s.t + dt

	if s.t >= PUNCH + HOLD + FADE then
		state = nil
	end
end

--[[
    What the HUD element should draw this frame (1920x1080 top-left space).
--]]
function Sniped.view(out)
	local s = state
	local Skel = mod.__dws_skeleton

	if not s or not Skel then
		return nil
	end

	local tex = Skel.texture(PATH)
	local tw, th = Skel.texture_size(PATH)

	if not tex or not tw or th == 0 then
		return nil
	end

	local t = s.t
	local h = max((W.S.sniped_size or 45) / 100, 0.05) * 1080
	local scale = 1

	if t < PUNCH then
		-- lands from oversized
		scale = 1 + 0.75 * (1 - t / PUNCH) ^ 2
	end

	h = h * scale

	local w = h * (tw / th)
	local shake = max(0, 1 - t / 0.25)
	local cx = 960 + sin(t * 47 + s.phase) * 18 * shake
	local cy = 500 + sin(t * 39 + s.phase * 2) * 14 * shake

	local gone = t - PUNCH - HOLD
	local alpha = gone > 0 and (1 - gone / FADE) or 1

	out.texture = tex
	out.alpha = 255 * max(0, min(1, alpha))
	out.w, out.h = w, h
	out.x, out.y = cx - w / 2, cy - h / 2
	out.angle = s.tilt * (1 + shake)

	return out
end

mod.__dws_sniped = Sniped

return Sniped
