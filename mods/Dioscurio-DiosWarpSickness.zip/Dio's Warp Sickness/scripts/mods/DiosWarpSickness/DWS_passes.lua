local mod = get_mod("DiosWarpSickness")

--[[
    ========================================================================
    ROTATING AND CLAMPING HUD PASSES
    ========================================================================

    While DWS_motion has set W.xf for the widget being drawn:

    1. CLAMP. Every pass (texture, texture_uv, rect, slug_icon, text) has its
       box pushed back inside the screen before it is drawn. The box used is
       the rotated bounding box, so a spun health bar is kept on screen too.
       Skeletons and alerts are a different element and are never clamped.

    2. SPIN. texture / texture_uv / rect / slug_icon are drawn through the
       game's own rotated variants (rotated_texture ui_passes.lua:486,
       rotated_rect :589, rotated_slug_icon :440), always around their own
       centre. UIWidget looks the pass up by NAME at draw time, which is
       what makes the swap possible.

    TEXT IS NOT ROTATED. The first build tried UIRenderer.script_draw_text_3d
    with the same transform rotated textures use. Nothing in the game calls
    that function, and in game it drew nothing in the boxes and huge stray
    numbers elsewhere, with no error to catch. So text is drawn the normal
    way, upright, at its moved and clamped position.

    RETAINED PASSES are taken out of retained mode before a rotated draw: a
    retained texture holds a 2D bitmap id that the 3D bitmap call cannot
    update. Their own destroy() runs first, the rotated draw happens in
    immediate mode, and when rotation stops destroy() runs again and the pass
    is marked dirty so the next normal draw rebuilds it retained. Every
    rotated draw is in pcall; if the engine refuses one, rotation turns
    itself off for the session instead of crashing.
--]]

local Passes = {}

local UIPasses = require("scripts/managers/ui/ui_passes")

local W = mod.__dws


local converted = setmetatable({}, { __mode = "k" })
local pivot = { 0, 0 }
local warned = false

local function broke(what, err)
	W.rotation_broken = true

	if not warned then
		warned = true
		mod:warning("%s", "rotation switched off for this session: " .. tostring(what) .. ": " .. tostring(err))
	end
end

local function restore_normal(pass, base, ui_renderer, widget)
	converted[pass] = nil

	local destroy = base.destroy

	if destroy then
		pcall(destroy, pass, ui_renderer, widget)
	end

	if pass.data then
		pass.data.dirty = true
	end
end

local function prepare(pass, base, ui_renderer, widget)
	if not converted[pass] then
		converted[pass] = true

		local destroy = base.destroy

		if destroy then
			pcall(destroy, pass, ui_renderer, widget)
		end
	end
end

local abs, cos, sin, min = math.abs, math.cos, math.sin, math.min

--[[
    Returns a position whose (rotated) box lies inside the screen. A box
    bigger than the screen is centred on it instead.
--]]
--[[
    Records the pass's box, minus this frame's move, into the element's
    outline so DWS_motion can keep the whole element on screen. Full-screen
    passes (backgrounds, vignettes) are left out or they would pin it.
--]]
local function track(xf, position, size)
	local c = xf.ctx

	if not c or not size then
		return
	end

	local w, h = size[1], size[2]

	if w >= xf.sw * 0.9 and h >= xf.sh * 0.9 then
		return
	end

	local x0, y0 = position[1] - xf.dx, position[2] - xf.dy
	local x1, y1 = x0 + w, y0 + h

	if not c.nb_x0 then
		c.nb_x0, c.nb_y0, c.nb_x1, c.nb_y1 = x0, y0, x1, y1
	else
		if x0 < c.nb_x0 then c.nb_x0 = x0 end
		if y0 < c.nb_y0 then c.nb_y0 = y0 end
		if x1 > c.nb_x1 then c.nb_x1 = x1 end
		if y1 > c.nb_y1 then c.nb_y1 = y1 end
	end
end

local function clamp(position, size, angle, xf)
	if xf.noclamp then
		return position
	end

	local w, h = size[1], size[2]
	local hx, hy = w / 2, h / 2

	if angle ~= 0 then
		local ca, sa = abs(cos(angle)), abs(sin(angle))

		hx, hy = (w * ca + h * sa) / 2, (w * sa + h * ca) / 2
	end

	local cx, cy = position[1] + w / 2, position[2] + h / 2
	local sw, sh = xf.sw, xf.sh
	local nx = hx * 2 >= sw and sw / 2 or math.max(hx, min(sw - hx, cx))
	local ny = hy * 2 >= sh and sh / 2 or math.max(hy, min(sh - hy, cy))

	if nx == cx and ny == cy then
		return position
	end

	return Vector3(position[1] + (nx - cx), position[2] + (ny - cy), position[3])
end

local function hook_rotatable(name, rotated_name)
	local base = UIPasses[name]
	local rotated = UIPasses[rotated_name]

	if not base or not rotated or type(base.draw) ~= "function" then
		return
	end

	mod:hook(base, "draw", function(func, pass, ui_renderer, ui_style, ui_content, position, size, clip_uvs, widget)
		local xf = W.xf

		if not xf or not ui_style or not size then
			if converted[pass] then
				restore_normal(pass, base, ui_renderer, widget)
			end

			return func(pass, ui_renderer, ui_style, ui_content, position, size, clip_uvs, widget)
		end

		track(xf, position, size)

		if xf.angle == 0 or W.rotation_broken then
			if converted[pass] then
				restore_normal(pass, base, ui_renderer, widget)
			end

			return func(pass, ui_renderer, ui_style, ui_content, clamp(position, size, 0, xf), size, clip_uvs, widget)
		end

		prepare(pass, base, ui_renderer, widget)

		local rs = ui_renderer.render_settings
		local prev_force = rs and rs.force_retained_mode
		local prev_retained = pass.retained_mode
		local prev_angle, prev_pivot = ui_style.angle, ui_style.pivot
		local pos, sz = clamp(position, size, xf.angle, xf), size

		pivot[1], pivot[2] = sz[1] / 2, sz[2] / 2

		if rs then
			rs.force_retained_mode = false
		end

		pass.retained_mode = false
		ui_style.angle = xf.angle
		ui_style.pivot = pivot

		local ok, err = pcall(rotated.draw, pass, ui_renderer, ui_style, ui_content, pos, sz, clip_uvs)

		ui_style.angle, ui_style.pivot = prev_angle, prev_pivot
		pass.retained_mode = prev_retained

		if rs then
			rs.force_retained_mode = prev_force
		end

		if not ok then
			broke(name, err)
			restore_normal(pass, base, ui_renderer, widget)

			return func(pass, ui_renderer, ui_style, ui_content, position, size, clip_uvs, widget)
		end
	end)
end

hook_rotatable("texture", "rotated_texture")
hook_rotatable("texture_uv", "rotated_texture")
hook_rotatable("rect", "rotated_rect")
hook_rotatable("slug_icon", "rotated_slug_icon")

-- ---------------------------------------------------------------- text

local Scramble -- set by Passes.init

mod:hook(UIPasses.text, "draw", function(func, pass, ui_renderer, ui_style, ui_content, position, size, clip_uvs, widget)
	if ui_style and ui_style.dws_noscramble then
		return func(pass, ui_renderer, ui_style, ui_content, position, size, clip_uvs, widget)
	end

	local xf = W.xf -- only ever set inside a wrapped element's draw, chat included
	local profile = xf and xf.ctx and xf.ctx.profile
	local is_chat = profile == "chat" and W.S.fx_chat_chaos
	local is_view = profile == "view"
	local in_scope = W.in_text_scope or is_chat or is_view

	--[[
        Light scramble (readable with a squint) for chat, for menus, and for
        all HUD and subtitle text outside a mission. In a mission the HUD
        uses the normal scramble, which follows the trip intensity.
    --]]
	local light = is_chat or is_view or (W.in_text_scope and W.light_text)

	if xf and size then
		track(xf, position, size)
		position = clamp(position, size, 0, xf)
	end

	local pass_data = pass.data
	local value_id = pass_data and pass_data.value_id or pass.value_id
	local text = value_id and ui_content[value_id]

	-- the wheel's DYSLEXIA slice: everything at full scramble for a while
	local heavy = W.dyslexia_until ~= nil and W.t < W.dyslexia_until and W.active

	if in_scope and (W.scramble_live or light or heavy) and W.S.fx_scramble and not W.sober
		and type(text) == "string" and #text >= 2 and Scramble then
		local scrambled = Scramble.text(text, heavy or (light and "light" or nil))

		if scrambled ~= text then
			ui_content[value_id] = scrambled

			func(pass, ui_renderer, ui_style, ui_content, position, size, clip_uvs, widget)

			if ui_content[value_id] == scrambled then
				ui_content[value_id] = text
			end

			return
		end
	end

	return func(pass, ui_renderer, ui_style, ui_content, position, size, clip_uvs, widget)
end)

function Passes.init(scramble_module)
	Scramble = scramble_module
end

mod.__dws_passes = Passes

return Passes
