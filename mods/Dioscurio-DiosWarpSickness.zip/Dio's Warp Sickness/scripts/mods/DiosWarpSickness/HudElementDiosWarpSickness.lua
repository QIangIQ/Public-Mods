local mod = get_mod("DiosWarpSickness")

local UIWidget = require("scripts/managers/ui/ui_widget")
local UIWorkspaceSettings = require("scripts/settings/ui/ui_workspace_settings")

--[[
    Draws the skeletons and the alerts. Built on Handholder's
    HudElementDiosJumpscare:

      * content/ui/materials/base/ui_default_base with texture_map as the
        slot, because a userdata material value is bound through
        Material.set_resource (ui_passes.lua apply_material_values)
      * material_values must already exist in the style at definition time,
        or the pass never builds its own material and the texture never binds
      * a fullscreen "fit" node, which never aligns, so every position below
        is an absolute 1920x1080 offset from the top-left

    rotated_texture rather than texture so skeletons and the crossbones can
    spin and be mirrored (angle, pivot and uvs; ui_passes.lua:486).

    The class string matches the registered class_name; UIHud looks the
    element up by both, and a mismatch leaves it permanently invisible.
--]]

local HudElementDiosWarpSickness = class("HudElementDiosWarpSickness", "HudElementBase")

local IMAGE_MATERIAL = "content/ui/materials/base/ui_default_base"
local W_REF, H_REF = 1920, 1080
local SKELETON_SLOTS = 8
local ALERT_SLOTS = 2

local scenegraph_definition = {
	screen = UIWorkspaceSettings.screen,
	fullscreen = {
		parent = "screen",
		scale = "fit",
		vertical_alignment = "center",
		horizontal_alignment = "center",
		size = { W_REF, H_REF },
		position = { 0, 0, 850 },
	},
}

local function skeleton_definition()
	return UIWidget.create_definition({
		{
			pass_type = "rotated_texture",
			value_id = "texture",
			style_id = "image",
			value = IMAGE_MATERIAL,
			style = {
				color = { 0, 255, 255, 255 },
				size = { 300, 300 },
				offset = { 0, 0, 1 },
				angle = 0,
				pivot = { 150, 150 },
				uvs = { { 0, 0 }, { 1, 1 } },
				material_values = {},
			},
		},
	}, "fullscreen")
end

local function alert_definition()
	return UIWidget.create_definition({
		{
			pass_type = "rotated_texture",
			value_id = "texture",
			style_id = "icon",
			value = IMAGE_MATERIAL,
			style = {
				color = { 0, 255, 255, 255 },
				size = { 190, 190 },
				offset = { 0, 0, 20 },
				angle = 0,
				pivot = { 95, 95 },
				uvs = { { 0, 0 }, { 1, 1 } },
				material_values = {},
			},
		},
		{
			pass_type = "text",
			value_id = "text",
			style_id = "text",
			value = "",
			style = {
				font_type = "machine_medium",
				font_size = 88,
				text_color = { 0, 255, 255, 255 },
				size = { 1800, 140 },
				offset = { 0, 0, 21 },
				text_horizontal_alignment = "center",
				text_vertical_alignment = "center",
				drop_shadow = true,
				dws_noscramble = true,
			},
		},
	}, "fullscreen")
end

local function image_pass(style_id, z)
	return {
		pass_type = "rotated_texture",
		value_id = style_id .. "_texture",
		style_id = style_id,
		value = IMAGE_MATERIAL,
		style = {
			color = { 0, 255, 255, 255 },
			size = { 100, 100 },
			offset = { 0, 0, z },
			angle = 0,
			pivot = { 50, 50 },
			uvs = { { 0, 0 }, { 1, 1 } },
			material_values = {},
		},
	}
end

local function text_pass(style_id, z, font_size)
	return {
		pass_type = "text",
		value_id = style_id,
		style_id = style_id,
		value = "",
		style = {
			font_type = "machine_medium",
			font_size = font_size,
			text_color = { 0, 255, 255, 255 },
			size = { 1800, 140 },
			offset = { 0, 0, z },
			text_horizontal_alignment = "center",
			text_vertical_alignment = "center",
			drop_shadow = true,
			dws_noscramble = true,
		},
	}
end

-- the wheel: wheel, pointer, title above, subtitle below
local function wheel_definition()
	return UIWidget.create_definition({
		image_pass("wheel", 30),
		image_pass("pointer", 31),
		text_pass("title", 32, 44),
		text_pass("sub", 32, 40),
	}, "fullscreen")
end

--[[
    The Hog Rider: the rope, then the lasso, then the rider, with the
    screaming portrait on top.

    The rope is a run of short rotated rects rather than one long one. A
    single stretched rect can only ever be a straight line, and a rope that
    is dead straight while it is being thrown is the main thing that made
    this look like a toy.
--]]
local ROPE_SEGMENTS = 16

local function hog_definition()
	local passes = {}

	for i = 1, ROPE_SEGMENTS do
		passes[#passes + 1] = {
			pass_type = "rotated_rect",
			style_id = "rope_" .. i,
			style = {
				color = { 0, 150, 100, 45 },
				size = { 10, 7 },
				offset = { 0, 0, 40 },
				angle = 0,
				pivot = { 0, 3.5 },
			},
		}
	end

	passes[#passes + 1] = image_pass("lasso", 41)
	passes[#passes + 1] = image_pass("ride", 42)
	passes[#passes + 1] = image_pass("yell", 43)

	return UIWidget.create_definition(passes, "fullscreen")
end

-- the dog: halo behind him, him in front
local function dog_definition()
	return UIWidget.create_definition({
		image_pass("halo", 50),
		image_pass("dog", 51),
	}, "fullscreen")
end

-- the sniped picture
local function sniped_definition()
	return UIWidget.create_definition({
		image_pass("sniped", 55),
	}, "fullscreen")
end

-- the void sits over everything else this element draws
local function void_definition()
	return UIWidget.create_definition({
		image_pass("void", 60),
	}, "fullscreen")
end

--[[
    The warning gate. Plain rect and text only - no textures, because this is
    the one thing that must draw on an install with no SimpleAssets, which is
    exactly the install most likely to have been handed the mod by somebody
    else.

    z is above everything else this element draws (the void is 60), and
    dws_noscramble keeps the scrambler off it: a warning you cannot read is
    not a warning.
--]]
local GATE_LINES = 14

local function gate_text(style_id, z, font_size, font_type)
	return {
		pass_type = "text",
		value_id = style_id,
		style_id = style_id,
		value = "",
		style = {
			font_type = font_type or "machine_medium",
			font_size = font_size,
			text_color = { 0, 255, 255, 255 },
			size = { 1500, font_size + 14 },
			offset = { 210, 0, z },
			text_horizontal_alignment = "center",
			text_vertical_alignment = "center",
			drop_shadow = true,
			dws_noscramble = true,
		},
	}
end

local function gate_definition()
	local passes = {
		{
			pass_type = "rect",
			style_id = "shade",
			style = {
				color = { 0, 4, 2, 2 },
				size = { W_REF, H_REF },
				offset = { 0, 0, 90 },
			},
		},
		{
			pass_type = "rect",
			style_id = "bar",
			style = {
				color = { 0, 120, 20, 20 },
				size = { W_REF, 8 },
				offset = { 0, 236, 91 },
			},
		},
		gate_text("head", 92, 96),
		gate_text("foot", 93, 40),
	}

	for i = 1, GATE_LINES do
		passes[#passes + 1] = gate_text("line_" .. i, 92, 30, "itc_novarese_medium")
	end

	return UIWidget.create_definition(passes, "fullscreen")
end

local widget_definitions = {}

widget_definitions.gate = gate_definition()

widget_definitions.wheel = wheel_definition()
widget_definitions.hog = hog_definition()
widget_definitions.dog = dog_definition()
widget_definitions.sniped = sniped_definition()
widget_definitions.void = void_definition()

for i = 1, SKELETON_SLOTS do
	widget_definitions["skeleton_" .. i] = skeleton_definition()
end

for i = 1, ALERT_SLOTS do
	widget_definitions["alert_" .. i] = alert_definition()
end

HudElementDiosWarpSickness.init = function(self, parent, draw_layer, start_scale)
	HudElementDiosWarpSickness.super.init(self, parent, draw_layer, start_scale, {
		scenegraph_definition = scenegraph_definition,
		widget_definitions = widget_definitions,
	})

	self._slot_out = {}
	self._alert_out = {}
	self._wheel_out = {}
	self._hog_out = {}
	self._dog_out = {}
	self._sniped_out = {}
	self._void_out = {}
	self._gate_out = {}

	for _, widget in pairs(self._widgets_by_name) do
		widget.visible = false
	end
end

HudElementDiosWarpSickness.update = function(self, dt, t, ui_renderer, render_settings, input_service)
	HudElementDiosWarpSickness.super.update(self, dt, t, ui_renderer, render_settings, input_service)

	local Skel = mod.__dws_skeleton
	local Alerts = mod.__dws_alerts
	local out = self._slot_out
	local by_name = self._widgets_by_name

	--[[
        While the warning is up it is the only thing this element draws. It
        would be a poor warning about flashing images that had skeletons
        running across it.
    --]]
	if self:_update_gate(by_name.gate) then
		for name, widget in pairs(by_name) do
			if name ~= "gate" then
				widget.visible = false
			end
		end

		return
	end

	for i = 1, SKELETON_SLOTS do
		local widget = by_name["skeleton_" .. i]
		local slot = widget and Skel and Skel.slot(i, out)

		if widget then
			if not slot then
				widget.visible = false
			else
				widget.visible = true

				local style = widget.style.image
				local tex = slot.texture

				style.material_values.texture_map = tex
				style.color[1] = tex and math.floor(slot.alpha) or 0
				style.size[1], style.size[2] = slot.w, slot.h
				style.pivot[1], style.pivot[2] = slot.w / 2, slot.h / 2
				style.offset[1], style.offset[2] = slot.x, slot.y
				style.angle = slot.angle
				style.uvs = slot.uvs
			end
		end
	end

	self:_update_wheel(by_name.wheel)
	self:_update_hog(by_name.hog)
	self:_update_dog(by_name.dog)
	self:_update_sniped(by_name.sniped)
	self:_update_void(by_name.void)

	local aout = self._alert_out

	for i = 1, ALERT_SLOTS do
		local widget = by_name["alert_" .. i]
		local a = widget and Alerts and Alerts.slot(i, aout)

		if widget then
			if not a then
				widget.visible = false
			else
				widget.visible = true

				local icon = widget.style.icon
				local tex = a.texture

				icon.material_values.texture_map = tex
				icon.color[1] = tex and math.floor(a.alpha) or 0
				icon.color[2], icon.color[3], icon.color[4] = a.icon_r, a.icon_g, a.icon_b
				icon.size[1], icon.size[2] = a.icon_size, a.icon_size
				icon.pivot[1], icon.pivot[2] = a.icon_size / 2, a.icon_size / 2
				icon.offset[1], icon.offset[2] = a.icon_x, a.icon_y
				icon.angle = a.icon_angle

				local text = widget.style.text

				widget.content.text = a.text
				text.text_color[1] = math.floor(a.alpha)
				text.text_color[2], text.text_color[3], text.text_color[4] = a.text_r, a.text_g, a.text_b
				text.font_size = a.text_size
				text.offset[1], text.offset[2] = a.text_x, a.text_y
			end
		end
	end
end

local NO_FLIP = { { 0, 0 }, { 1, 1 } }
local FLIP = { { 1, 0 }, { 0, 1 } }

local function set_image(style, tex, alpha, x, y, w, h, angle, flip)
	style.material_values.texture_map = tex
	style.color[1] = tex and math.floor(alpha) or 0
	style.size[1], style.size[2] = w, h
	style.pivot[1], style.pivot[2] = w / 2, h / 2
	style.offset[1], style.offset[2] = x, y
	style.angle = angle or 0
	style.uvs = flip and FLIP or NO_FLIP
end

--[[
    Returns true while the gate is up, which tells update() to draw nothing
    else at all.
--]]
HudElementDiosWarpSickness._update_gate = function(self, widget)
	local Warning = mod.__dws_warning
	local W = mod.__dws

	if not widget or not Warning or not W then
		return false
	end

	local v = Warning.view(self._gate_out)

	if not v or not v.gate then
		widget.visible = false

		return false
	end

	widget.visible = true

	local st = widget.style
	local a = v.gate_alpha or 238

	st.shade.color[1] = a
	st.bar.color[1] = a

	widget.content.head = v.gate_head or ""
	st.head.text_color[1] = v.gate_text_alpha or 255
	st.head.offset[2] = 150

	local lines = v.gate_lines or {}

	for i = 1, GATE_LINES do
		local id = "line_" .. i
		local text = lines[i] or ""

		widget.content[id] = text
		st[id].text_color[1] = v.gate_text_alpha or 255
		st[id].offset[2] = 300 + (i - 1) * 42

		--[[
            A line with no leading spaces that is not blank is a heading:
            brighter and larger, so the three sections are findable without
            reading every line.
        --]]
		local heading = text ~= "" and text == string.upper(text)

		st[id].font_size = heading and 36 or 30
		st[id].font_type = heading and "machine_medium" or "itc_novarese_medium"
		st[id].text_color[2] = heading and 255 or 205
		st[id].text_color[3] = heading and 190 or 205
		st[id].text_color[4] = heading and 170 or 205
	end

	widget.content.foot = v.gate_foot or ""
	st.foot.offset[2] = 920

	if v.gate_foot_ready then
		-- a slow pulse, nowhere near a rate that could set anything off
		local pulse = 200 + 55 * math.sin((W.t or 0) * 2.2)

		st.foot.text_color[1] = v.gate_text_alpha or 255
		st.foot.text_color[2] = math.floor(pulse)
		st.foot.text_color[3] = math.floor(pulse)
		st.foot.text_color[4] = 150
	else
		st.foot.text_color[1] = math.floor((v.gate_text_alpha or 255) * 0.75)
		st.foot.text_color[2] = 170
		st.foot.text_color[3] = 170
		st.foot.text_color[4] = 170
	end

	return true
end

HudElementDiosWarpSickness._update_wheel = function(self, widget)
	local Wheel = mod.__dws_wheel
	local v = widget and Wheel and Wheel.view(self._wheel_out)

	if not widget then
		return
	end

	if not v then
		widget.visible = false
		return
	end

	widget.visible = true

	local st = widget.style

	set_image(st.wheel, v.tex, v.alpha, v.x, v.y, v.size, v.size, v.angle)
	set_image(st.pointer, v.pointer_tex, v.alpha, v.pointer_x, v.pointer_y, v.pointer_w, v.pointer_h, v.pointer_angle)

	widget.content.title = v.title
	st.title.font_size = v.title_size
	st.title.offset[1], st.title.offset[2] = v.title_x, v.title_y
	st.title.text_color[1] = math.floor(v.alpha)
	st.title.text_color[2], st.title.text_color[3], st.title.text_color[4] = v.title_r, v.title_g, v.title_b

	widget.content.sub = v.sub
	st.sub.offset[1], st.sub.offset[2] = v.sub_x, v.sub_y
	st.sub.text_color[1] = math.floor(v.alpha)
end

HudElementDiosWarpSickness._update_hog = function(self, widget)
	local Hog = mod.__dws_hog
	local v = widget and Hog and Hog.view(self._hog_out)

	if not widget then
		return
	end

	if not v then
		widget.visible = false
		return
	end

	widget.visible = true

	local st = widget.style

	if v.yell_tex then
		set_image(st.yell, v.yell_tex, 255, v.yell_x, v.yell_y, v.yell_w, v.yell_h, 0, v.yell_flip)
	else
		st.yell.color[1] = 0
	end

	if v.ride_tex then
		set_image(st.ride, v.ride_tex, 255, v.ride_x, v.ride_y, v.ride_w, v.ride_h, v.ride_angle, v.ride_flip)
	else
		st.ride.color[1] = 0
	end

	if v.lasso_tex then
		set_image(st.lasso, v.lasso_tex, 255, v.lasso_x, v.lasso_y, v.lasso_w, v.lasso_h, v.lasso_angle)
	else
		st.lasso.color[1] = 0
	end

	--[[
        Each piece spans two points of the curve the Hog module worked out.
        The pivot is the left-hand end, so a piece is positioned at its start
        point and turned to face the next one - laid end to end they follow
        the curve.

        The angle is negated: a positive pass angle turns anti-clockwise on
        screen, while atan2 with y pointing down grows clockwise. See
        DWS_wheel.lua.
    --]]
	local pts = v.rope_pts
	local n = v.rope and (v.rope_n or 0) or 0

	for i = 1, ROPE_SEGMENTS do
		local rope = st["rope_" .. i]

		if i > n or not pts then
			rope.color[1] = 0
		else
			local k = (i - 1) * 2 + 1
			local x0, y0 = pts[k], pts[k + 1]
			local x1, y1 = pts[k + 2], pts[k + 3]

			if not x0 or not x1 then
				rope.color[1] = 0
			else
				local dx, dy = x1 - x0, y1 - y0
				-- a shade over the gap, so the joins do not show as notches
				local len = math.sqrt(dx * dx + dy * dy) + 1.5
				local u = (i - 1) / math.max(n - 1, 1)
				local w = (v.rope_w0 or 8) + ((v.rope_w1 or 5.5) - (v.rope_w0 or 8)) * u

				rope.color[1] = 255
				rope.size[1], rope.size[2] = math.max(len, 1), w
				rope.pivot[1], rope.pivot[2] = 0, w / 2
				rope.offset[1], rope.offset[2] = x0, y0 - w / 2
				rope.angle = -math.atan2(dy, dx)
			end
		end
	end

end

HudElementDiosWarpSickness._update_dog = function(self, widget)
	local Wheel = mod.__dws_wheel
	local v = widget and Wheel and Wheel.dog_view(self._dog_out)

	if not widget then
		return
	end

	if not v then
		widget.visible = false
		return
	end

	widget.visible = true

	local st = widget.style

	set_image(st.halo, v.halo_tex, v.halo_alpha, v.halo_x, v.halo_y, v.halo_size, v.halo_size, v.halo_angle)
	set_image(st.dog, v.dog_tex, v.alpha, v.dog_x, v.dog_y, v.dog_w, v.dog_h, 0)
end

HudElementDiosWarpSickness._update_sniped = function(self, widget)
	local Sniped = mod.__dws_sniped
	local v = widget and Sniped and Sniped.view(self._sniped_out)

	if not widget then
		return
	end

	if not v then
		widget.visible = false
		return
	end

	widget.visible = true

	set_image(widget.style.sniped, v.texture, v.alpha, v.x, v.y, v.w, v.h, v.angle)
end

HudElementDiosWarpSickness._update_void = function(self, widget)
	local Void = mod.__dws_void
	local v = widget and Void and Void.view(self._void_out)

	if not widget then
		return
	end

	if not v then
		widget.visible = false
		return
	end

	widget.visible = true

	local st = widget.style

	set_image(st.void, v.texture, v.alpha, v.x, v.y, v.size, v.size, 0)
	-- pitch black: the texture is a black disc, so only the alpha channel matters
	st.void.color[2], st.void.color[3], st.void.color[4] = 255, 255, 255
end

return HudElementDiosWarpSickness
