local mod = get_mod("DiosWarpSickness")

--[[
    ========================================================================
    CHAOS ENGINE: MOVING, ROTATING AND RECOLOURING THE HUD
    ========================================================================

    THREE LAYERS, ALL APPLIED ONLY FOR THE LENGTH OF ONE DRAW

    1. widget.offset   every widget an element draws gets a delta added to
                       its offset (ui_widget.lua:732-736 adds offset to the
                       scenegraph position) and the old value put back after.
    2. rotation        DWS_passes swaps texture / texture_uv / rect /
                       slug_icon / text passes for the game's own rotated
                       versions while W.xf says to. UIWidget looks the pass up
                       by NAME at draw time (ui_widget.lua "UIPasses[pass_type]"),
                       which is what makes that swap possible.
    3. colour          every style.color / style.text_color in the widget is
                       hue-shifted, drawn, then restored - HUDTweaker's idea of
                       editing style values, made temporary.

    PER INSTANCE, NOT PER CLASS: class() copies parent methods into every
    subclass at creation (foundation/utilities/class.lua), so hooking
    HudElementBase.draw would reach almost nothing. UIThrottle wraps
    instances for the same reason and this follows it.

    RETAINED MODE: while an element is being messed with, every widget it
    draws is marked dirty so retained passes re-submit. Rotated passes are
    drawn in immediate mode (see DWS_passes for why and how they are put back).
--]]

local Motion = {}

local UIWidget = require("scripts/managers/ui/ui_widget")
local UIScenegraph = require("scripts/managers/ui/ui_scenegraph")

local W = mod.__dws

local sin, cos, floor, abs, pi, min, max = math.sin, math.cos, math.floor, math.abs, math.pi, math.min, math.max
local random = math.random

--[[
    WHO GETS THROWN

    An element in no group here is thrown. That is the default on purpose:
    this file has no idea what other people's mods are called, and the only
    way to catch RitualZones, huntsalvage, Spidey Sense, a scoreboard or
    whatever gets installed next week is to treat "not recognised" as "fair
    game" rather than the other way round.

    The named ones are grouped only so each can be switched off from Mod
    Options when it stops being funny. Every group defaults to ON.
--]]
--[[
    Darktide's own HUD elements, from scripts/ui/hud/hud_elements_*.lua plus
    the child panels the handlers create.

    This list exists to answer one question: is this element the base game's,
    or did a mod put it there? Anything NOT in here came from a mod - yours,
    mine, or one neither of us has installed - and is always thrown. No
    grouping, no pattern rule, no way to protect it.

    That is the point. The pattern rules below ("Overlay", "Fading") are
    guesses about the base game's naming, and a mod called
    HudElementSomethingOverlay would otherwise be spared by accident. Only
    base-game names are measured against them.
--]]
local BASE_GAME = {
	ConstantElementChat = true,
	ConstantElementChatWheel = true,
	ConstantElementNotificationFeed = true,
	ConstantElementPopupHandler = true,
	ConstantElementSubtitles = true,
	HudElementAreaNotificationPopup = true,
	HudElementBossHealth = true,
	HudElementCharacterNewsFeed = true,
	HudElementCombatFeed = true,
	HudElementCrosshair = true,
	HudElementCutsceneFading = true,
	HudElementCutsceneOverlay = true,
	HudElementDamageIndicator = true,
	HudElementDangerZoneOverlay = true,
	HudElementDodgeCounter = true,
	HudElementEmoteWheel = true,
	HudElementInteraction = true,
	HudElementMinionShieldHealth = true,
	HudElementMissionObjectiveFeed = true,
	HudElementMissionObjectivePopup = true,
	HudElementMissionSpeakerPopup = true,
	HudElementNameplates = true,
	HudElementObjectiveProgressBar = true,
	HudElementOnboardingPopup = true,
	HudElementOvercharge = true,
	HudElementPerilGauge = true,
	HudElementPersonalPlayerPanel = true,
	HudElementPlayerAbility = true,
	HudElementPlayerAbilityHandler = true,
	HudElementPlayerBuffs = true,
	HudElementPlayerCompass = true,
	HudElementPlayerWeapon = true,
	HudElementPlayerWeaponHandler = true,
	HudElementPrologueStepTracker = true,
	HudElementPrologueTutorialInfoBox = true,
	HudElementPrologueTutorialSequenceTransitionEnd = true,
	HudElementSmartTagging = true,
	HudElementSpecialsTracker = true,
	HudElementSpectateFading = true,
	HudElementSpectatorText = true,
	HudElementStamina = true,
	HudElementTacticalOverlay = true,
	HudElementTeamPanelHandler = true,
	HudElementTeamPlayerPanel = true,
	HudElementWeaponCounter = true,
	HudElementWieldInfo = true,
	HudElementWorldMarkers = true,
	ScannerDisplayView = true,
}

local GROUP = {
	-- things you aim and react with
	HudElementCrosshair = "aim",
	Crosshair = "aim", -- Handholder's jumpscare registers under this name
	HudElementDamageIndicator = "aim",

	-- things you have to click or hold a key on
	HudElementSmartTagging = "input",
	HudElementInteraction = "input",
	HudElementEmoteWheel = "input",

	-- drawn over the whole screen, so moving one shows its edges
	HudElementTacticalOverlay = "fullscreen",

	-- positioned by projecting a point in the world, so once thrown they no
	-- longer point at the thing they are marking. That is the joke.
	HudElementWorldMarkers = "world",
	HudElementNameplates = "world",

	HudElementSpectatorText = "spectate",
}

local PATTERN_GROUP = {
	{ "Overlay", "fullscreen" },
	{ "Fading", "fullscreen" },
	{ "Prologue", "prologue" },
	{ "Spectate", "spectate" },
}

--[[
    Never thrown, whatever the settings say: this is the element that draws
    the warning screen, the wheel, the dog and the hog rider. Throwing the
    thing that does the throwing just hides it.
--]]
local NEVER = {
	HudElementDiosWarpSickness = true,
}

local function group_of(name)
	if not name then
		return nil
	end

	local g = GROUP[name]

	if g then
		return g
	end

	-- not the base game's: it came from a mod, so it is fair game
	if not BASE_GAME[name] then
		return nil
	end

	for i = 1, #PATTERN_GROUP do
		if name:find(PATTERN_GROUP[i][1], 1, true) then
			return PATTERN_GROUP[i][2]
		end
	end

	return nil
end

Motion.is_base_game = function(name)
	return name ~= nil and BASE_GAME[name] == true
end

--[[
    Is this group switched off right now? Read every frame rather than cached
    at wrap time, so a checkbox in Mod Options takes effect on the next frame
    instead of needing a reload.
--]]
local function group_off(group)
	if not group then
		return false
	end

	return W.S["throw_" .. group] == false
end

Motion.group_of = group_of

-- Menus that must stay usable: settings (incl. Mod Options, so this can be
-- switched off), anything that spends money, loading and video screens.
local VIEW_EXCLUDE = {
	dmf_options_view = true,
	options_view = true,
	custom_settings_view = true,
	loading_view = true,
	splash_view = true,
	splash_video_view = true,
	title_view = true,
	video_view = true,
	cutscene_view = true,
	mission_intro_view = true,
	store_view = true,
	store_item_detail_view = true,
	premium_currency_purchase_view = true,
	dlc_purchase_view = true,
	report_player_view = true,
	player_survey_view = true,
	blank_view = true,
}

--[[
    Elements whose colours carry information keep them: the peril bars (how
    close you are to exploding is the colour) and the specials tracker text.
--]]
local KEEP_COLOURS = {
	HudElementOvercharge = "all",
	HudElementPerilGauge = "all",
	HudElementSpecialsTracker = "text",
}

local PROFILE = {
	HudElementTeamPlayerPanel = "seaweed",
	HudElementPersonalPlayerPanel = "self",
	HudElementPlayerAbility = "bob",
	HudElementPlayerWeapon = "boat",
	HudElementSpecialsTracker = "jitter",
	ConstantElementChat = "chat",
}

local ctxs = setmetatable({}, { __mode = "k" })
local home_factor -- defined below, used by compute
local stack = {}
local depth = 0
local any_live = false
local compute_timer = 0
local colour_timer = 0
local discover_timer = 0

function Motion.reset_stack()
	depth = 0
	W.xf = nil
end

--[[
    Elements that only draw widgets flagged dirty, and only redraw their
    health bar when health changes (player_panel_base _draw_widgets and
    _draw_health_bar; buffs, overcharge and player_weapon do the same). They
    rely on retained mode to keep the last drawing on screen. While an element
    is being rotated its passes are drawn in immediate mode, which nothing
    keeps, so every widget it owns is flagged dirty before its draw - and the
    health bar flag set - or those pieces vanish. That was the missing health
    bars and teammate panels.
--]]
local function widget_lists(c, element)
	if c.lists and W.t - (c.lists_t or 0) < 2 then
		return c.lists
	end

	local lists = {}

	for key, value in pairs(element) do
		if type(key) == "string" and type(value) == "table" and key:find("widgets", 1, true)
			and key ~= "_widgets_by_name" then
			lists[#lists + 1] = value
		end
	end

	c.lists, c.lists_t = lists, W.t

	return lists
end

local function mark_dirty(c, element)
	local lists = widget_lists(c, element)

	for i = 1, #lists do
		for _, widget in pairs(lists[i]) do
			if type(widget) == "table" and widget.passes then
				widget.dirty = true
			end
		end
	end

	if rawget(element, "_health_bar_segment_widgets") then
		element._draw_health_segments = true
	end
end

local function wrap(element, player, profile_override)
	if type(element) ~= "table" then
		return
	end

	local existing = ctxs[element]

	if existing then
		existing.player = player or existing.player
		return
	end

	if rawget(element, "_dws_skip") then
		return
	end

	local name = element.__class_name

	if not name or NEVER[name] then
		element._dws_skip = true
		return
	end

	local profile = profile_override or PROFILE[name] or "float"
	local offscreen = name == "ScannerDisplayView"

	ctxs[element] = {
		name = name,
		group = group_of(name),
		profile = profile,
		phase = random() * 2 * pi,
		spin = (random() < 0.5 and -1 or 1) * (0.6 + random() * 1.4),
		orbit = 0.7 + random() * 0.9,
		hue = random(),
		tint = 0,
		dx = 0, dy = 0, angle = 0,
		pull = 0, mirror = 0, shrink = 1,
		pmode = "element",
		live = false,
		changed = false,
		sink = 0,
		player = player,
		offscreen = offscreen,
		scatter_x = 0, scatter_y = 0,
	}

	--[[
        The draw this element would have run if we had not touched it.

        class() copies parent methods into each subclass at creation, so most
        elements carry their own 'draw' field and rawget finds it. Not all do:
        HudElementNameplates has none, and reaches draw through its
        metatable's __index - which is NOT the same thing as the metatable's
        own 'draw' field. The old code tried rawget and then
        getmetatable(self).draw, both nil for that element, and calling nil
        crashed the game the moment it drew.

        It never showed up before because Nameplates was on the old exclusion
        list and was never wrapped. Widening the net to catch other people's
        mods caught this too.

        A plain index lookup resolves whatever would really have been called,
        own or inherited, and it runs before the field below replaces it.
    --]]
	local previous = element.draw

	if type(previous) ~= "function" then
		local mt = getmetatable(element)
		local idx = mt and rawget(mt, "__index")

		previous = (type(idx) == "table" and idx.draw) or (mt and rawget(mt, "draw")) or nil
	end

	--[[
        Nothing callable found. Leave the element completely alone rather than
        replacing its draw with a wrapper that cannot do its job.
    --]]
	if type(previous) ~= "function" then
		element._dws_skip = true

		return
	end

	element.draw = function(self, ...)
		local c = ctxs[self]

		-- group_off is checked here, not at wrap time, so toggling a
		-- checkbox takes effect next frame and the element snaps back to
		-- where the game drew it
		if not c or not W.motion_live or group_off(c.group) then
			return previous(self, ...)
		end

		depth = depth + 1
		stack[depth] = c
		c.nb_x0, c.nb_y0, c.nb_x1, c.nb_y1 = nil, nil, nil, nil
		c.drawn_t = W.t

		-- redraw everything only when something will actually look different
		-- (a kidnapped element moves every frame, so it always redraws)
		local kid = W.kid
		c.redraw = c.live and (c.rotating or c.changed or (kid ~= nil and kid.c == c))

		if c.redraw or (c.changed and not c.live) then
			mark_dirty(c, self)
		end

		previous(self, ...)

		-- the element's real outline this frame (unmoved), used to keep it on screen next frame
		if c.nb_x0 then
			c.bb_x0, c.bb_y0, c.bb_x1, c.bb_y1 = c.nb_x0, c.nb_y0, c.nb_x1, c.nb_y1
		end

		c.changed = false
		stack[depth] = nil
		depth = depth - 1
	end
end

-- Handler children, by the field names in the game source (see the header of
-- the first version of this file for where each comes from).
local function discover()
	local ui = Managers.ui

	--[[
        Chat is not part of the HUD: it is a constant element, drawn by
        UIConstantElements.draw (ui_constant_elements.lua:237). Same wrapper,
        found through the manager's own lookup table.
    --]]
	local constant = ui and ui._ui_constant_elements
	local chat = constant and constant._elements and constant._elements.ConstantElementChat

	if chat then
		wrap(chat)
	end

	-- menus: Esc menu, inventory, talents, inspect, vendors...
	if W.S.fx_menus and ui and ui.active_views then
		local ok, names = pcall(ui.active_views, ui)

		if ok and type(names) == "table" then
			for i = 1, #names do
				local name = names[i]

				if not VIEW_EXCLUDE[name] then
					local ok_v, view = pcall(ui.view_instance, ui, name)

					if ok_v and view then
						wrap(view, nil, "view")
					end
				end
			end
		end
	end

	local hud = ui and ui._hud
	local elements = hud and hud._elements_array

	if not elements then
		return
	end

	for i = 1, #elements do
		local element = elements[i]

		wrap(element)

		local panels = rawget(element, "_player_panels_array")

		if panels then
			for j = 1, #panels do
				local data = panels[j]

				if data and data.panel then
					wrap(data.panel, data.player)
				end
			end
		end

		local abilities = rawget(element, "_instance_data_tables")

		if abilities then
			for _, data in pairs(abilities) do
				if data and data.instance then
					wrap(data.instance)
				end
			end
		end

		local weapons = rawget(element, "_player_weapons")

		if weapons then
			for _, data in pairs(weapons) do
				if data and data.hud_element_player_weapon then
					wrap(data.hud_element_player_weapon)
				end
			end
		end
	end
end

local function smooth(p)
	return p * p * (3 - 2 * p)
end

-- 0 -> 1 -> 0 over an episode, with flat-ish ends
local function hump(p)
	return sin(pi * min(max(p, 0), 1))
end

-- in fast, hold, out fast
local function hold(p, edge)
	edge = edge or 0.15

	if p < edge then
		return smooth(p / edge)
	elseif p > 1 - edge then
		return smooth((1 - p) / edge)
	end

	return 1
end

--[[
    PONG. Outside a mission (Mourningstar, menus, character select) only chat
    is touched: it flies in a straight line, bounces off the screen edges like
    a DVD logo, spins, and changes colour and spin direction on every hit.
    The edges are tested with the chat's measured outline from DWS_passes.
--]]
local pong = { x = 0, y = 0, vx = 340, vy = 250, angle = 0, spin = 1.6 }

local function pong_step(c, dt)
	pong.x = pong.x + pong.vx * dt
	pong.y = pong.y + pong.vy * dt
	pong.angle = pong.angle + pong.spin * dt

	if not c.bb_x0 then
		return
	end

	local sw, sh = W.sw or 1920, W.sh or 1080
	local hit = false

	if c.bb_x0 + pong.x < 0 then
		pong.x, pong.vx, hit = -c.bb_x0, abs(pong.vx), true
	elseif c.bb_x1 + pong.x > sw then
		pong.x, pong.vx, hit = sw - c.bb_x1, -abs(pong.vx), true
	end

	if c.bb_y0 + pong.y < 0 then
		pong.y, pong.vy, hit = -c.bb_y0, abs(pong.vy), true
	elseif c.bb_y1 + pong.y > sh then
		pong.y, pong.vy, hit = sh - c.bb_y1, -abs(pong.vy), true
	end

	if hit then
		c.hue = random()
		pong.spin = -pong.spin * (0.8 + random() * 0.5)
		pong.spin = max(-4, min(4, pong.spin))

		-- a little english on every bounce so it never settles into one loop
		local speed = 300 + random() * 180
		local a = math.atan2(pong.vy, pong.vx) + (random() - 0.5) * 0.5

		pong.vx, pong.vy = speed * cos(a), speed * sin(a)
	end
end

local ROT_MIN = 0.03 -- below ~2 degrees, not worth taking a pass out of retained mode

local function finish(c, dx, dy, angle, tint)
	if c.profile == "chat" then
		angle = 0 -- the letters cannot rotate, so the box does not either
	end

	local rotating = W.S.fx_rotate and not W.rotation_broken and abs(angle) > ROT_MIN

	if not rotating then
		angle = 0
	end

	local kidnapped = c.kidnapped
	local live = dx ~= 0 or dy ~= 0 or rotating or c.pull > 0.001 or c.mirror > 0.001 or tint > 0.01
		or (c.profile ~= "view" and abs(W.follow_zoom) > 0.002) or c.profile == "view" or kidnapped

	if live ~= c.live or dx ~= c.dx or dy ~= c.dy or abs(angle - c.angle) > 0.001 or tint > 0.01
		or (c.tint or 0) > 0.01 or kidnapped then
		c.changed = true
	end

	c.dx, c.dy, c.angle, c.tint, c.rotating, c.live = dx, dy, angle, tint, rotating, live
	c.shift = floor(((c.hue + W.t * W.hue_speed) % 1) * 96) / 96
	c.strength = floor(tint * 32 + 0.5) / 32

	if live then
		any_live = true
	end
end

-- menus: the view itself does not move as one piece; each widget flies on its
-- own (see the widget hook) and every icon rocks
local function view_ctx(c)
	local chaos = (W.S.chaos_level or 80) / 100
	local on = W.S.fx_menus and not W.sober

	c.pull, c.mirror, c.shrink, c.pmode = 0, 0, 1, "self"

	if not on then
		finish(c, 0, 0, 0, 0)
		c.live = false
		return
	end

	finish(c, 0, 0, 0.7 * chaos * sin(1.3 * W.t + c.phase), 0.6 * chaos)
end

local function compute_hub(dt_since)
	any_live = false

	for _, c in pairs(ctxs) do
		c.pull, c.mirror, c.shrink, c.pmode = 0, 0, 1, "element"

		if c.profile == "view" then
			view_ctx(c)
		elseif c.profile == "chat" and W.hub_chat then
			pong_step(c, dt_since)
			finish(c, floor(pong.x * 2 + 0.5) / 2, floor(pong.y * 2 + 0.5) / 2, 0, 1)
		else
			finish(c, 0, 0, 0, 0)
			c.live = false
		end
	end
end

--[[
    TEAMMATE ABILITY READY -> PANEL GOES HOME.

    The panel's player has an ability extension (husk or local) with
    remaining_ability_charges("combat_ability") - the same call the game's
    own panels use for grenades (player_panel_base _get_grenade_ability_status).
    When that count goes up, the panel eases back to its normal spot with its
    normal colours for HOME_TIME seconds so you can see the ability is ready,
    then is released back into the chaos.
--]]
local HOME_TIME = 2.75
local HOME_IN, HOME_OUT = 0.25, 0.5

--[[
    A Player that has left the game is a destroyed object, and reading ANY
    property off one raises rather than returning nil - including
    player_unit. A disconnect used to throw here every frame, which aborted
    the whole mod update before anything else in it could run.

    pcall on a plain function rather than a closure, because this is called
    every frame per player and a closure would be garbage each time.
--]]
local function read_player_unit(player)
	return player.player_unit
end

local function player_unit(player)
	if not player then
		return nil
	end

	local ok, unit = pcall(read_player_unit, player)

	return ok and unit or nil
end

local function combat_charges(player)
	local unit = player_unit(player)

	if not unit or not Unit.alive(unit) then
		return nil
	end

	local ext = ScriptUnit.has_extension(unit, "ability_system")

	if not ext or not ext.remaining_ability_charges then
		return nil
	end

	local ok, charges = pcall(ext.remaining_ability_charges, ext, "combat_ability")

	return ok and charges or nil
end

home_factor = function(c)
	local charges = combat_charges(c.player)

	if charges then
		if c.last_charges and charges > c.last_charges then
			c.home_start = W.t
			c.home_until = W.t + HOME_TIME
		end

		c.last_charges = charges
	end

	if not c.home_until or W.t >= c.home_until then
		return 0
	end

	local into = (W.t - c.home_start) / HOME_IN
	local out = (c.home_until - W.t) / HOME_OUT

	return max(0, min(1, into, out))
end

local function compute(dt_since)
	local S = W.S
	local I = W.intensity
	local t = W.t
	local chaos = (S.chaos_level or 80) / 100
	local size = (S.motion_size or 100) / 100
	local motion = W.motion_on and W.active
	local rotate = motion and S.fx_rotate
	local ep = W.episode
	local p = ep and ep.p or 0
	local en = ep and ep.name

	-- the always-on layer: elements orbit in circles and rock back and forth
	local R = motion and (40 + 170 * I) * chaos * size or 0
	local wobble = rotate and (0.25 + 1.1 * I) * chaos or 0

	any_live = false

	for _, c in pairs(ctxs) do
		if c.profile == "view" then
			view_ctx(c)
			goto continue
		end

		local ph = c.phase
		local w = (0.8 + 0.6 * I) * c.orbit
		local dx, dy, angle = 0, 0, 0
		local pull, mirror, shrink = 0, 0, 1
		local pmode = "element"

		if R > 0 then
			local r = R

			if c.profile == "bob" then
				dx = 0.35 * r * sin(1.7 * t + ph)
				dy = r * sin(2.3 * t + ph)
			elseif c.profile == "boat" then
				dx = r * sin(0.8 * t)
				dy = 0.45 * r * sin(1.6 * t)
			elseif c.profile == "jitter" then
				dx = 0.5 * r * (sin(7.3 * t + ph) + sin(2.1 * t))
				dy = 0.5 * r * (sin(6.1 * t + 2 * ph) + sin(1.7 * t))
			else
				dx = r * cos(w * t + ph)
				dy = 0.8 * r * sin(w * t + ph)
			end
		end

		if wobble > 0 then
			angle = wobble * sin(0.9 * c.orbit * t + ph)
		end

		-- episodes stack on top of the base layer
		if ep and motion then
			if en == "whirlpool" then
				pmode = "screen"
				angle = angle + ep.dir * 4 * pi * smooth(p)
				pull = 0.45 * hump(p)
			elseif en == "blackhole" then
				pmode = "corner"
				angle = angle + ep.dir * 6 * pi * p
				pull = 0.85 * (hump(p) ^ 0.6)
			elseif en == "flip" then
				pmode = "self"
				angle = pi * hold(p)
			elseif en == "spin" then
				pmode = "self"
				angle = c.spin * 4 * pi * p
			elseif en == "carousel" then
				angle = ep.dir * 2 * pi * smooth(p)
			elseif en == "quake" then
				local q = 45 * hump(p) * size
				dx = dx + (random() * 2 - 1) * q
				dy = dy + (random() * 2 - 1) * q
			elseif en == "scatter" then
				if not c.scatter_ep or c.scatter_ep ~= ep then
					c.scatter_ep = ep
					c.scatter_x = (random() * 2 - 1) * 700
					c.scatter_y = (random() * 2 - 1) * 380
				end

				local k = hump(p)
				dx = dx + c.scatter_x * k
				dy = dy + c.scatter_y * k
				angle = angle + c.spin * 2 * pi * k
			elseif en == "mirror" then
				mirror = hold(p, 0.25)
			elseif en == "melt" then
				dy = dy + 1100 * (hump(p) ^ 1.5) * (0.6 + 0.4 * sin(ph))
				angle = angle + 0.6 * hump(p) * sin(ph)
			end
		end

		if not rotate then
			angle = 0
		end

		-- team and personal panels: tilt, never flip or spin, so names, HP and timers stay readable
		if c.profile == "seaweed" or c.profile == "self" then
			angle = max(-0.35, min(0.35, angle))
		end

		-- downed teammates sink
		if c.profile == "seaweed" then
			local unit = player_unit(c.player)

			-- the player left: drop the cached object so it is looked up again
			if c.player and not unit then
				c.player = nil
			end

			local target = (motion and S.fx_sink and unit and W.downed[unit]) and 90 or 0
			local rate = target > c.sink and 15 or 120

			c.sink = c.sink + max(-rate * dt_since, min(rate * dt_since, target - c.sink))

			if c.sink > 0.5 then
				dy = dy + c.sink
				angle = angle + 0.3 * (c.sink / 90) * sin(3 * t + ph)
			end
		end

		-- follow mode: the whole HUD is thrown the way you move
		dx = dx + W.follow_x
		dy = dy + W.follow_y

		-- chat gets every colour at full strength; everything else follows the trip
		local tint = W.tint

		if c.profile == "chat" and W.S.fx_chat_chaos then
			tint = math.max(tint, 0.9)
		end

		-- teammate's combat ability just came back: home for a few seconds
		local home = c.profile == "seaweed" and home_factor(c) or 0

		if home > 0 then
			local keep = 1 - home

			dx, dy, angle = dx * keep, dy * keep, angle * keep
			pull, mirror, tint = pull * keep, mirror * keep, tint * keep
		end

		c.homek = home

		-- carried off by the Hog Rider: tumbles on the rope (any element, panels included)
		local kid = W.kid
		local kidnapped = kid ~= nil and kid.c == c and (kid.k or 0) > 0

		if kidnapped and S.fx_rotate then
			local k = kid.k
			angle = angle * (1 - k) + (kid.angle or 0) * k
		end

		c.kidnapped = kidnapped

		dx, dy = floor(dx * 2 + 0.5) / 2, floor(dy * 2 + 0.5) / 2

		c.pull, c.mirror, c.shrink, c.pmode = pull, mirror, shrink, pmode
		finish(c, dx, dy, angle, tint)

		::continue::
	end
end

function Motion.update(dt)
	discover_timer = discover_timer - dt

	if discover_timer <= 0 then
		discover_timer = 0.5

		if W.active or W.hub_chat or (W.S.fx_menus and not W.sober) then
			discover()
		end
	end

	local wants = (W.active and (W.motion_on or W.tint > 0.01 or W.S.fx_follow or W.S.fx_chat_chaos or W.kid ~= nil)) or W.hub_chat
		or (W.S.fx_menus and not W.sober and Managers.ui and Managers.ui.has_active_view and Managers.ui:has_active_view())
	local live = wants or any_live

	W.motion_live = live

	if not live then
		return
	end

	compute_timer = compute_timer + dt
	colour_timer = colour_timer + dt
	W.colour_frame = false

	local interval = 1 / max(W.S.anim_rate or 30, 1)

	if compute_timer >= interval * 0.9 then
		-- colours step at 15 Hz, always on a frame where everything redraws
		if colour_timer >= 1 / 15 then
			colour_timer = 0
			W.colour_frame = true
		end

		if W.hub_chat then
			compute_hub(compute_timer)
		else
			compute(compute_timer)
		end
		compute_timer = 0
	end
end

--[[
    Elements the Hog Rider can take: HUD elements drawn in the last half
    second with a measured outline of a sensible size. Menus are not HUD.
--]]
local victims = {}

function Motion.victims()
	local n = 0
	local sw, sh = W.sw or 1920, W.sh or 1080

	for i = #victims, 1, -1 do
		victims[i] = nil
	end

	for _, c in pairs(ctxs) do
		if c.profile ~= "view" and not c.offscreen and c.bb_x0 and c.drawn_t and W.t - c.drawn_t < 0.5 then
			local w, h = c.bb_x1 - c.bb_x0, c.bb_y1 - c.bb_y0

			if w > 16 and h > 8 and w < sw * 0.7 and h < sh * 0.7 then
				n = n + 1
				victims[n] = c
			end
		end
	end

	return victims
end

function Motion.reset()
	any_live = false
	W.motion_live = false
	W.xf = nil
	Motion.untint_all()

	for element, c in pairs(ctxs) do
		c.dx, c.dy, c.angle, c.sink, c.pull, c.mirror, c.shrink = 0, 0, 0, 0, 0, 0, 1
		c.live, c.changed = false, false

		if element.set_dirty then
			pcall(element.set_dirty, element)
		end
	end
end

-- ---------------------------------------------------------------- colour

local bright = false

local function hue_shift(col, shift, strength)
	local r, g, b = col[2] / 255, col[3] / 255, col[4] / 255
	local mx, mn = max(r, g, b), min(r, g, b)
	local d = mx - mn
	local h = 0

	if d > 0 then
		if mx == r then
			h = ((g - b) / d) % 6
		elseif mx == g then
			h = (b - r) / d + 2
		else
			h = (r - g) / d + 4
		end

		h = h / 6
	end

	local s = mx > 0 and d / mx or 0
	local v = mx

	-- greys and whites get colour too, or the white text would never change.
	-- Chat is pushed to full saturation and brightness so it never reads grey.
	h = (h + shift) % 1
	s = s + ((bright and 1 or 0.85) - s) * strength
	v = v + (max(v, bright and 1 or 0.75) - v) * strength

	local i = floor(h * 6)
	local f = h * 6 - i
	local p, q, tt = v * (1 - s), v * (1 - s * f), v * (1 - s * (1 - f))

	i = i % 6

	local nr, ng, nb

	if i == 0 then
		nr, ng, nb = v, tt, p
	elseif i == 1 then
		nr, ng, nb = q, v, p
	elseif i == 2 then
		nr, ng, nb = p, v, tt
	elseif i == 3 then
		nr, ng, nb = p, q, v
	elseif i == 4 then
		nr, ng, nb = tt, p, v
	else
		nr, ng, nb = v, p, q
	end

	col[2] = floor(r * 255 + (nr * 255 - r * 255) * strength)
	col[3] = floor(g * 255 + (ng * 255 - g * 255) * strength)
	col[4] = floor(b * 255 + (nb * 255 - b * 255) * strength)
end

--[[
    COLOUR, WITHOUT SAVE AND RESTORE

    The first version saved every colour before a draw and put it back after,
    every frame, for every widget: about two thirds of the mod's CPU time.

    Now the tinted value is written into the colour table and left there. The
    cache remembers the original and the value last written. If the colour
    no longer holds the value we wrote, the game changed it (a health bar
    turning red on knockdown, say), so that becomes the new original. The hue
    only steps at the animation rate, so most frames a colour costs three
    comparisons. Originals are written back when tinting stops for that
    element, when sobering up, and when the mod is disabled.
--]]
local colour_cache = setmetatable({}, { __mode = "k" })
local colour_cache_seen = setmetatable({}, { __mode = "k" }) -- widgets tinted at least once

local function tint_colour(col, shift, strength)
	local e = colour_cache[col]
	local r, g, b = col[2], col[3], col[4]

	if not e then
		e = { r, g, b, -1, -1, r, g, b, false }
		colour_cache[col] = e
	elseif r ~= e[6] or g ~= e[7] or b ~= e[8] then
		e[1], e[2], e[3], e[4] = r, g, b, -1 -- the game set a new colour
	end

	if e[4] ~= shift or e[5] ~= strength or e[9] ~= bright then
		col[2], col[3], col[4] = e[1], e[2], e[3]
		hue_shift(col, shift, strength)
		e[4], e[5], e[9] = shift, strength, bright
		e[6], e[7], e[8] = col[2], col[3], col[4]
	else
		col[2], col[3], col[4] = e[6], e[7], e[8]
	end
end

local function untint_colour(col)
	local e = colour_cache[col]

	if e then
		if col[2] == e[6] and col[3] == e[7] and col[4] == e[8] then
			col[2], col[3], col[4] = e[1], e[2], e[3]
		end

		colour_cache[col] = nil
	end
end

local skip_text = false

local function for_colours(widget, fn, shift, strength)
	local style = widget.style

	if type(style) ~= "table" then
		return
	end

	for _, s in pairs(style) do
		if type(s) == "table" then
			local col = rawget(s, "color")

			if type(col) == "table" and type(col[4]) == "number" and col[1] ~= 0 then
				fn(col, shift, strength)
			end

			col = rawget(s, "text_color")

			if type(col) == "table" and type(col[4]) == "number" and col[1] ~= 0 then
				if skip_text then
					-- readable text: own colour, fully opaque, with a shadow
					if col[1] < 255 then
						col[1] = 255
					end

					s.drop_shadow = true
				else
					fn(col, shift, strength)
				end
			end
		end
	end
end

function Motion.untint_all()
	for col in pairs(colour_cache) do
		untint_colour(col)
	end
end


-- ---------------------------------------------------------------- the widget hook

local temp_offset = { 0, 0, 0 }
local widget_phase = setmetatable({}, { __mode = "k" })
local xf = { angle = 0, sw = 1920, sh = 1080 }

mod:hook(UIWidget, "draw", function(func, widget, ui_renderer)
	if W.force_dirty and W.in_hud then
		widget.dirty = true
	end

	local c = depth > 0 and stack[depth]

	if not c or not c.live then
		if c and c.changed then
			widget.dirty = true
			for_colours(widget, untint_colour)
		end

		return func(widget, ui_renderer)
	end

	-- retained widgets are only re-submitted on frames where they change
	if c.redraw then
		widget.dirty = true
	end

	local scale = ui_renderer.scale or 1
	local sw = (RESOLUTION_LOOKUP and RESOLUTION_LOOKUP.width or 1920) / scale
	local sh = (RESOLUTION_LOOKUP and RESOLUTION_LOOKUP.height or 1080) / scale

	W.sw, W.sh = sw, sh

	--[[
        ONE DELTA PER ELEMENT. Every widget of an element gets the same move,
        worked out from the element's centre, so a team panel's name, bars,
        ability icon and timer travel together and stay readable. The centre
        and size come from the outline DWS_passes measured last frame; before
        the first measurement the widget's own scenegraph position stands in.
    --]]
	local ex, ey

	if c.bb_x0 then
		ex, ey = (c.bb_x0 + c.bb_x1) / 2, (c.bb_y0 + c.bb_y1) / 2
	else
		local sg = ui_renderer.ui_scenegraph
		local scenegraph_id = widget.scenegraph_id
		local wp = sg and scenegraph_id and UIScenegraph.world_position(sg, scenegraph_id)
		local offset = widget.offset

		ex = (wp and wp[1] or 0) + (offset and offset[1] or 0)
		ey = (wp and wp[2] or 0) + (offset and offset[2] or 0)
	end

	local offset = widget.offset

	local dx, dy = c.dx, c.dy
	local angle = c.angle
	local tx, ty

	if c.pmode == "screen" then
		tx, ty = sw / 2, sh / 2
	elseif c.pmode == "corner" then
		local k = W.episode and W.episode.corner or 1
		tx = (k == 1 or k == 4) and 60 or sw - 60
		ty = (k == 1 or k == 2) and 60 or sh - 60
	end

	-- whirlpool / black hole: the element's centre is carried round the target point
	if tx and abs(angle) > 0.002 then
		local rx, ry = ex - tx, ey - ty
		local ca, sa = cos(angle), sin(angle)

		dx = dx + (tx + rx * ca - ry * sa) - ex
		dy = dy + (ty + rx * sa + ry * ca) - ey
	end

	if tx and c.pull > 0 then
		dx = dx + (tx - ex) * c.pull
		dy = dy + (ty - ey) * c.pull
	end

	if c.mirror > 0 then
		dx = dx + (sw - 2 * ex) * c.mirror
	end

	-- follow mode, forward/back: rush to the middle, or blown out to the edges
	local zoom = W.follow_zoom * (1 - (c.homek or 0))

	if zoom ~= 0 then
		dx = dx + (sw / 2 - ex) * zoom
		dy = dy + (sh / 2 - ey) * zoom
	end

	-- menus: every widget (each talent node, each button) flies its own loop
	if c.profile == "view" then
		local wp = widget_phase[widget]

		if not wp then
			wp = { random() * 2 * pi, 0.6 + random() * 1.2, 30 + random() * 70 }
			widget_phase[widget] = wp
		end

		local r = wp[3] * ((W.S.chaos_level or 80) / 100) * (c.offscreen and 0.6 or 1)
		local tt = W.t * wp[2] + wp[1]

		dx = dx + r * cos(tt)
		dy = dy + 0.8 * r * sin(tt * 1.3)
	end

	-- keep the whole element on screen
	if c.bb_x0 and c.profile ~= "view" then
		local margin = 4

		if c.bb_x1 - c.bb_x0 < sw then
			dx = max(margin - c.bb_x0, min(sw - margin - c.bb_x1, dx))
		else
			dx = 0
		end

		if c.bb_y1 - c.bb_y0 < sh then
			dy = max(margin - c.bb_y0, min(sh - margin - c.bb_y1, dy))
		else
			dy = 0
		end
	end

	-- Hog Rider: the element's centre is dragged to the rope's end, off screen and all
	local kid = W.kid
	local kidnapped = kid ~= nil and kid.c == c and (kid.k or 0) > 0

	if kidnapped then
		local k = kid.k

		dx = dx * (1 - k) + (kid.x - ex) * k
		dy = dy * (1 - k) + (kid.y - ey) * k
	end

	xf.angle = c.rotating and angle or 0
	-- chat keeps its box whole (the element clamp still holds it on screen);
	-- the auspex screen is a 1024px render target, so the monitor's edges mean nothing there
	xf.noclamp = c.profile == "chat" or c.offscreen or kidnapped
	xf.sw, xf.sh = sw, sh
	xf.ctx, xf.dx, xf.dy = c, dx, dy
	W.xf = xf

	local keep = KEEP_COLOURS[c.name]

	if (c.tint or 0) > 0.01 and keep ~= "all" then
		if not W.colour_frame and colour_cache_seen[widget] then
			goto tinted
		end

		colour_cache_seen[widget] = true
		bright = c.profile == "chat"
		skip_text = keep == "text"
		for_colours(widget, tint_colour, c.shift or 0, c.strength or c.tint)
		skip_text = false
		bright = false
	elseif c.changed then
		colour_cache_seen[widget] = nil
		for_colours(widget, untint_colour)
	end

	::tinted::

	if offset then
		local ox, oy = offset[1] or 0, offset[2] or 0
		local nx, ny = ox + dx, oy + dy

		offset[1], offset[2] = nx, ny

		func(widget, ui_renderer)

		if offset[1] == nx and offset[2] == ny then
			offset[1], offset[2] = ox, oy
		end
	else
		temp_offset[1], temp_offset[2], temp_offset[3] = dx, dy, 0
		widget.offset = temp_offset

		func(widget, ui_renderer)

		if widget.offset == temp_offset then
			widget.offset = nil
		end
	end

	W.xf = nil
end)

--[[
    THE CENSUS

    Everything the mod currently has its hands on, and for each one whether
    it is the base game's or came from a mod, and whether it is being thrown
    right now.

    Elements are found by walking the live hud element list every scan, not
    from a list written here, so a mod installed next week shows up without
    this file changing. This is what /warpwho prints, and it is the honest
    answer to "is it really reading everything".
--]]
function Motion.census()
	local rows = {}
	local base_n, mod_n, thrown_n = 0, 0, 0

	for element, c in pairs(ctxs) do
		local base = Motion.is_base_game(c.name)
		local thrown = not group_off(c.group)

		rows[#rows + 1] = {
			name = c.name or "?",
			base = base,
			group = c.group,
			thrown = thrown,
			seen = c.drawn_t,
		}

		if base then base_n = base_n + 1 else mod_n = mod_n + 1 end
		if thrown then thrown_n = thrown_n + 1 end
	end

	table.sort(rows, function(a, b)
		if a.base ~= b.base then
			return not a.base
		end

		return a.name < b.name
	end)

	return rows, base_n, mod_n, thrown_n
end

--[[
    Logged once, the first time a scan finds elements this session, so the
    console log says what was on screen without anyone having to ask. Mostly
    so that "it did not throw X" can be checked against what the mod could
    actually see.
--]]
local announced = false

function Motion.announce()
	if announced then
		return
	end

	--[[
        Counts the contexts in place rather than calling census(), which
        builds a table per element and sorts them. announce() runs every
        frame until it has something to say, and census() on that path was
        allocating a few hundred KB a frame.
    --]]
	local total, mod_n = 0, 0

	for _, c in pairs(ctxs) do
		total = total + 1

		if not Motion.is_base_game(c.name) then
			mod_n = mod_n + 1
		end
	end

	if total == 0 then
		return
	end

	announced = true

	mod:info("[warp] %d HUD elements in reach: %d from the base game, %d from mods",
		total, total - mod_n, mod_n)

	if mod_n > 0 then
		-- the list itself is worth one allocation, once per session
		local others = {}

		for _, c in pairs(ctxs) do
			if not Motion.is_base_game(c.name) then
				others[#others + 1] = c.name
			end
		end

		table.sort(others)
		mod:info("[warp] not base game, so always thrown: %s", table.concat(others, ", "))
	end
end

mod.__dws_motion = Motion

return Motion
