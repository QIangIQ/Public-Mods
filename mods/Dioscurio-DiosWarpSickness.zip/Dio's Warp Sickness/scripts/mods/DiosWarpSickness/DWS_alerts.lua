local mod = get_mod("DiosWarpSickness")

--[[
    ========================================================================
    ALERTS
    ========================================================================

    A pinging skull-and-crossbones and a big line of text that fly across the
    middle of the screen. The icon flashes red/white and pulses, the text
    cycles through colours. Lines come from assets/alerts/alerts.txt.

    Drawn by HudElementDiosWarpSickness; this module only keeps the state.
    The text style carries dws_noscramble so the scrambler leaves it alone.
--]]

local Alerts = {}

local W = mod.__dws

local sin, abs, floor, min, max, pi = math.sin, math.abs, math.floor, math.min, math.max, math.pi

local MAX_ALERTS = 2
local DISK = ".\\..\\mods\\Dio's Warp Sickness\\assets\\alerts\\alerts.txt"

local lines = nil
local last_line = nil
local active = {}
local last_sound_t = -100

local function load_lines()
	lines = {}

	local io = Mods and Mods.lua and Mods.lua.io
	local f = io and io.open(DISK, "r")

	if f then
		for line in f:lines() do
			line = line:gsub("\r", ""):match("^%s*(.-)%s*$")

			if line ~= "" and line:sub(1, 1) ~= "#" then
				lines[#lines + 1] = line
			end
		end

		f:close()
	end

	if #lines == 0 then
		lines = { "SKARMY ALERT" }
	end
end

--[[
    Generated lines, so the same alert rarely comes up twice. Half of all
    alerts are built from these parts, the other half come from alerts.txt.
--]]
local GEN = {
	num = { "1", "2", "7", "12", "40", "69", "420", "9000", "ALL THE", "INFINITE", "TOO MANY", "A SUSPICIOUS NUMBER OF" },
	who = { "SKELETONS", "SKELETON OGRYNS", "BONE BOYS", "SPOOKY SKELETONS", "SKELETON SNIPERS", "TINY SKELETONS",
		"GIANT SKELETONS", "SKELETON HERETICS", "UNION SKELETONS", "SKELETON ZEALOTS", "CALCIUM CULTISTS" },
	verb = { "SPOTTED", "DANCING", "RATTLING", "MOONWALKING", "DOING A KICKFLIP", "STEALING AMMO", "HOLDING HANDS",
		"REVIVING EACH OTHER", "PLAYING THE XYLOPHONE", "FILING TAXES", "SPRINTING", "IN COHERENCY", "SCREAMING" },
	place = { "BEHIND YOU", "IN THE VENTS", "ON THE CEILING", "IN YOUR HUD", "AT THE ELEVATOR", "IN SECTOR 7",
		"IN THE MEAT GRINDER", "UNDER YOUR BED", "ON THE MOURNINGSTAR", "INSIDE THE DAEMONHOST", "IN TERTIUM", "EVERYWHERE" },
	thing = { "YOUR HUD", "THE CROSSHAIR", "YOUR PERIL BAR", "THE SPECIALS TRACKER", "YOUR TEAM PANEL", "THE MACHINE SPIRIT",
		"YOUR AMMO", "YOUR LEFT FEMUR", "THE COHERENCY RING", "YOUR SPINE", "CHAT" },
	state = { "HAUNTED", "UPSIDE DOWN", "ON FIRE", "A SKELETON NOW", "LEAVING", "DANCING", "MELTING", "CRITICAL",
		"SPOOKED", "IN THE WALLS", "FULL OF BONES" },
	level = { "LOW", "MODERATE", "HIGH", "SEVERE", "CRITICAL", "ABSOLUTELY UNHINGED", "BEYOND THE WARP", "MAXIMUM BONE" },
}

local TEMPLATES = {
	"{num} {who} {verb} {place}",
	"WARNING: {thing} IS {state}",
	"{who} {verb} {place}!",
	"SKELETON THREAT LEVEL: {level}",
	"ALERT: {num} {who} {place}",
	"{thing} HAS BEEN {state}",
	"REPORT: {who} {verb}",
	"BONE LEVEL {level}. {num} {who} {place}",
}

local function generate()
	local template = TEMPLATES[math.random(#TEMPLATES)]

	return (template:gsub("{(%a+)}", function(key)
		local list = GEN[key]

		return list and list[math.random(#list)] or key
	end))
end

local function pick()
	if not lines then
		load_lines()
	end

	if math.random() < 0.5 then
		return generate()
	end

	local line

	for _ = 1, 4 do
		line = lines[math.random(#lines)]

		if line ~= last_line then
			break
		end
	end

	last_line = line

	return line
end

function Alerts.fire(text, mode, silent)
	if #active >= MAX_ALERTS then
		table.remove(active, 1)
	end

	local dir = math.random() < 0.5 and 1 or -1

	active[#active + 1] = {
		mode = mode,
		text = text or pick(),
		t = 0,
		dur = 3.2 + math.random() * 1.2,
		dir = dir,
		y = 360 + math.random() * 260,
		hue = math.random(),
		spin = (math.random() < 0.5 and -1 or 1) * (1 + math.random() * 2),
	}

	-- the crossbones texture is requested on first use
	if mod.__dws_skeleton then
		mod.__dws_skeleton.texture("alerts/crossbones.png")

		if not silent and W.t - last_sound_t > 1.2 then
			last_sound_t = W.t
			mod.__dws_skeleton.play("alerts/alert.wav")
		end
	end
end

function Alerts.update(dt)
	for i = #active, 1, -1 do
		local a = active[i]

		a.t = a.t + dt

		if a.t >= a.dur then
			table.remove(active, i)
		end
	end
end

function Alerts.clear()
	active = {}
end

function Alerts.reload()
	lines = nil
end

local function hsv(h, s, v)
	h = (h % 1) * 6

	local i = floor(h)
	local f = h - i
	local p, q, t = v * (1 - s), v * (1 - s * f), v * (1 - s * (1 - f))

	if i == 0 then return v, t, p
	elseif i == 1 then return q, v, p
	elseif i == 2 then return p, v, t
	elseif i == 3 then return p, q, v
	elseif i == 4 then return t, p, v
	end

	return v, p, q
end

--[[
    What alert i should look like this frame, in 1920x1080 top-left space.
--]]
function Alerts.slot(i, out)
	local a = active[i]

	if not a then
		return nil
	end

	local p = a.t / a.dur
	local fade = min(1, a.t / 0.15, (a.dur - a.t) / 0.25)
	local speed = (W.S.colour_speed or 50) / 50
	local cx, cy, icon_angle

	if a.mode == "center" then
		-- episode warnings stay in the middle and twirl in a small circle
		cx = 960 + 70 * math.cos(a.t * 4.5)
		cy = 470 + 45 * sin(a.t * 4.5)
		icon_angle = a.t * a.spin * 3
	else
		-- fly across: fast in, slow through the middle, fast out
		local q = p < 0.5 and (0.5 - 0.5 * (1 - 2 * p) ^ 2.2) or (0.5 + 0.5 * (2 * p - 1) ^ 2.2)

		cx = a.dir > 0 and (-700 + 3320 * q) or (2620 - 3320 * q)
		cy = a.y + 18 * sin(a.t * 7)
		icon_angle = 0.35 * sin(a.t * a.spin * 2)
	end

	-- ping: red/white flash, 2.5 to 5 times a second depending on Colour speed
	local ping_rate = 2.5 + 2.5 * min(speed, 1)
	local ping = (floor(a.t * ping_rate) % 2 == 0)
	local pulse = 1 + 0.22 * abs(sin(a.t * pi * ping_rate * 0.5))
	local icon = 190 * pulse

	out.alpha = 255 * max(0, fade)
	out.icon_size = icon
	out.icon_x = cx - icon / 2
	out.icon_y = cy - icon - 10
	out.icon_angle = icon_angle
	out.icon_r, out.icon_g, out.icon_b = 255, ping and 255 or 30, ping and 255 or 30

	local r, g, b = hsv(a.hue + a.t * 0.9 * speed, 1, 1)

	out.text = a.text
	out.text_r, out.text_g, out.text_b = floor(r * 255), floor(g * 255), floor(b * 255)
	out.text_x = cx - 900
	out.text_y = cy + 10
	out.text_size = floor(88 + 14 * sin(a.t * 9))
	out.texture = mod.__dws_skeleton and mod.__dws_skeleton.texture("alerts/crossbones.png")

	return out
end

mod.__dws_alerts = Alerts

return Alerts
