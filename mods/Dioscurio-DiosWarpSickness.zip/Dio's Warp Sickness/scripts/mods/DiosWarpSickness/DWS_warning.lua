local mod = get_mod("DiosWarpSickness")

--[[
    ========================================================================
    THE WARNING GATE
    ========================================================================

    This mod strobes, flashes, shakes the screen and rotates the whole HUD,
    and it is handed to people who have no idea any of that is coming. So
    nothing happens until the warning has been read and accepted once.

    "Accepted" has to mean something, or it is decoration: until it is, the
    effects do not run at all. W.gate_closed is read in mod.update, which
    leaves W.active false while this is up - the HUD stays exactly as the
    game drew it.

    The answer is kept in the mod's own settings (mod:set), which DMF writes
    to the user settings file, so it survives a restart. It is stored as the
    version number of the text that was accepted: raising ACCEPT_VERSION
    below shows the warning again to everybody, which is what to do if the
    mod ever gains an effect the old text did not cover.

    It is deliberately NOT a Mod Options checkbox. Somebody clicking through
    a settings page is not the same as somebody who has read this.
--]]

local Warning = {}

local W = mod.__dws

local min, max = math.min, math.max

-- raise this when the warning text needs to be seen again by everyone
local ACCEPT_VERSION = 1

local SETTING = "warning_accepted"

-- the overlay fades in rather than appearing, so it does not itself flash
local FADE = 0.45

local shown_t = 0
local accepted = nil
local hold = 0

--[[
    A deliberate hold before the button works. The whole point is that it is
    read, and an overlay that can be dismissed in the same motion as the click
    that opened the game is not read.
--]]
local ARM_TIME = 4

local HEAD = "WARNING"

local LINES = {
	"PHOTOSENSITIVE SEIZURE WARNING",
	"This mod makes the screen flash, strobe and change colour rapidly, and",
	"shakes and spins the whole interface. A very small number of people can",
	"have a seizure from flashing light and patterns, with no history of it.",
	"If you feel dizzy, sick, or your vision changes, STOP AND LOOK AWAY.",
	"",
	"IT HIDES YOUR HUD ON PURPOSE",
	"Your health, ammo and objectives move, spin and become unreadable. Do",
	"not use it on a run you care about, or with people who have not agreed",
	"to it. It can also cause motion sickness.",
	"",
	"USE IT AT YOUR OWN RISK",
	"Dioscurio is not responsible for anything that happens while you use",
	"this mod. It is a joke mod. Nobody made you install it.",
}

local FOOT_ARMED = "PRESS  %s  TO ACCEPT        or switch the mod off in Mod Options"
local FOOT_WAIT = "READ IT  (%d)"
local FOOT_NOKEY = "TYPE  /warpagree  IN CHAT TO ACCEPT        or switch the mod off in Mod Options"

--[[
    What key is bound to the accept action, for the footer. DMF stores a
    keybind setting as a list of key names.
--]]
local function accept_key()
	local ok, keys = pcall(mod.get, mod, "accept_keybind")

	if not ok or type(keys) ~= "table" or #keys == 0 then
		return nil
	end

	local parts = {}

	for i = 1, #keys do
		parts[#parts + 1] = string.upper(tostring(keys[i]))
	end

	return table.concat(parts, " + ")
end

local function load_answer()
	local ok, v = pcall(mod.get, mod, SETTING)

	return ok and tonumber(v) or 0
end

--[[
    Has the current text been accepted? Cached, because this is asked every
    frame and mod:get goes to the settings table.
--]]
function Warning.accepted()
	if accepted == nil then
		accepted = load_answer() >= ACCEPT_VERSION
	end

	return accepted
end

function Warning.pending()
	return not Warning.accepted()
end

function Warning.accept()
	if Warning.accepted() then
		return false
	end

	-- do not let it be dismissed before it can have been read
	if hold > 0 then
		return false
	end

	accepted = true
	pcall(mod.set, mod, SETTING, ACCEPT_VERSION, true)
	mod:echo("Warp Sickness: warning accepted. /warpwarning brings it back.")

	return true
end

--[[
    Put the gate back up. For /warpwarning, and so raising ACCEPT_VERSION is
    testable without editing the settings file by hand.
--]]
function Warning.reset()
	accepted = false
	shown_t = 0
	hold = ARM_TIME
	pcall(mod.set, mod, SETTING, 0, true)
end

function Warning.update(dt)
	if Warning.accepted() then
		W.gate_closed = nil

		return
	end

	--[[
        Only count down while it is actually on screen. The timer is meant to
        be time spent looking at it, not time the game has been open.
    --]]
	W.gate_closed = true
	shown_t = shown_t + dt

	if hold <= 0 and shown_t <= dt then
		hold = ARM_TIME
	end

	if hold > 0 then
		hold = max(0, hold - dt)
	end
end

--[[
    Drawn by the HUD element. Plain rect and text, no textures: this has to
    work on an install with no SimpleAssets, which is exactly the install
    most likely to have got the mod from someone else.
--]]
function Warning.view(out)
	if Warning.accepted() then
		out.gate = false

		return out
	end

	local fade = min(1, shown_t / FADE)

	out.gate = true
	out.gate_alpha = math.floor(238 * fade)
	out.gate_head = HEAD
	out.gate_lines = LINES
	out.gate_text_alpha = math.floor(255 * fade)

	local key = accept_key()

	if hold > 0 then
		out.gate_foot = string.format(FOOT_WAIT, math.ceil(hold))
		out.gate_foot_ready = false
	elseif key then
		out.gate_foot = string.format(FOOT_ARMED, key)
		out.gate_foot_ready = true
	else
		out.gate_foot = FOOT_NOKEY
		out.gate_foot_ready = true
	end

	return out
end

mod.__dws_warning = Warning

return Warning
