local mod = get_mod("DiosWarpSickness")

--[[
    ========================================================================
    WHEEL OF MISFORTUNE
    ========================================================================

    Every "Wheel interval" seconds in a mission a prize wheel pops up, spins,
    lands on something and does it.

    The result is picked first, then the wheel is spun so it stops with that
    slice under the pointer. So the chances are the settings, not the slice
    sizes: NORMAL is a thin slice but its chance is "Normal chance"; the
    other eleven share the rest equally.

    SEGMENTS and assets/wheel/wheel.png are produced by the same script
    (_build_tools/gen_wheel.py), so the picture and the odds cannot drift
    apart. Slice widths ARE the odds at the default settings: NORMAL is 20
    percent of the wheel because that is its chance.

    Angles are radians in the image, measured the atan2 way from +x with y
    pointing down, so they grow clockwise on screen.

    THE UI ROTATES THE OTHER WAY. A positive style.angle turns a pass
    ANTI-clockwise on screen. The game's own emote wheel shows it: it places
    an entry at (sin(a)*r, cos(a)*r), which is screen angle pi/2 - a, rotates
    that same entry with style.angle = pi + a, and then has to NEGATE the
    widget angle to compare it against a cursor direction read with atan2
    (hud_element_emote_wheel.lua:440,535). So a point at image angle phi is
    drawn at screen angle phi - angle, and the slice under the pointer
    (straight up, -pi/2) is phi = angle - pi/2.

    Getting this backwards mirrors the whole wheel about the pointer, which
    lands every result on a neighbouring slice - closest, and most visible,
    on NORMAL.

    Timeline: pop in 0.35s, spin 3.4s, show the result 1.3s, then the effect
    starts while the wheel spins away over 0.4s.
--]]

local Wheel = {}

local W = mod.__dws

local sin, abs, min, max, floor, pi = math.sin, math.abs, math.min, math.max, math.floor, math.pi

local SEGMENTS = {
	{ "whirlpool", "WHIRLPOOL", -1.57080, -1.15192 },
	{ "skarmy", "SKARMY", -1.15192, -0.73304 },
	{ "flip", "UPSIDE DOWN", -0.73304, -0.31416 },
	{ "hog", "HOG RIDER", -0.31416, 0.10472 },
	{ "blackhole", "BLACK HOLE", 0.10472, 0.52360 },
	{ "void", "THE VOID", 0.52360, 0.94248 },
	{ "rave", "RAVE", 0.94248, 1.36136 },
	{ "dyslexia", "DYSLEXIA", 1.36136, 1.78024 },
	{ "mirror", "MIRROR", 1.78024, 2.19911 },
	{ "badtrip", "BAD TRIP", 2.19911, 2.61799 },
	{ "melt", "MELT", 2.61799, 3.03687 },
	{ "spin", "SPIN", 3.03687, 3.45575 },
	{ "normal", "NORMAL", 3.45575, 4.71239 },
}

local BY_KEY = {}

for _, seg in ipairs(SEGMENTS) do
	BY_KEY[seg[1]] = seg
end

local SUBTITLES = {
	whirlpool = "INTO THE DRAIN",
	skarmy = "THE BONES ARE COMING",
	flip = "AUSTRALIA MODE",
	hog = "HOG RIDAAAAAA",
	blackhole = "SPAGHETTIFICATION",
	void = "SOMETHING IS MISSING",
	rave = "UNTZ UNTZ UNTZ",
	dyslexia = "RAED THIS",
	mirror = "EVERYTHING IS BACKWARDS",
	badtrip = "MAXIMUM WARP",
	melt = "IT IS GETTING HOT",
	spin = "YOU SPIN ME RIGHT ROUND",
	normal = "A BRIEF MOMENT OF PEACE",
}

local POP_TIME = 0.35
local SPIN_TIME = 3.4
local SHOW_TIME = 1.3
local OUT_TIME = 0.4
local SIZE = 460 -- scaled by the "Wheel size" setting

local state = nil
local timer = nil
local angle = 0
local preloaded = false

local function smooth(p)
	p = max(0, min(1, p))

	return p * p * (3 - 2 * p)
end

local function choose()
	local S = W.S
	local normal = (S.wheel_normal_chance or 5) / 100

	if math.random() < normal then
		return "normal"
	end

	local pool = {}

	for _, seg in ipairs(SEGMENTS) do
		local key = seg[1]
		local ok = key ~= "normal"

		if key == "hog" and not S.fx_hog then
			ok = false
		elseif key == "skarmy" and not S.fx_skeleton then
			ok = false
		elseif key == "void" and not S.fx_void then
			ok = false
		end

		if ok then
			pool[#pool + 1] = key
		end
	end

	return pool[math.random(#pool)]
end

function Wheel.active()
	return state ~= nil
end

function Wheel.spin(key)
	if state or not W.active or not W.S.fx_wheel then
		return false
	end

	local Skel = mod.__dws_skeleton

	if Skel and not preloaded then
		preloaded = true
		Skel.texture("wheel/wheel.png")
		Skel.texture("wheel/pointer.png")
	end

	key = key and BY_KEY[key] and key or choose()

	local seg = BY_KEY[key]
	local phi = seg[3] + (seg[4] - seg[3]) * (0.2 + 0.6 * math.random())
	local land = phi + pi / 2
	local start = angle % (2 * pi)
	local turns = 5 + math.random(0, 2)
	local finish = land + 2 * pi * math.ceil((start + 2 * pi * turns - land) / (2 * pi))

	state = {
		t = 0,
		key = key,
		label = seg[2],
		sub = SUBTITLES[key] or "",
		from = start,
		to = finish,
		x = 560 + math.random() * 800,
		y = 360 + math.random() * 70,
		done = false,
		hue = math.random(),
	}

	return true
end

function Wheel.clear()
	state = nil
end

local function apply(key)
	local fx = mod.__dws_fx

	if fx and fx[key] then
		fx[key]()
	end
end

function Wheel.update(dt)
	local S = W.S

	if not W.active or not S.fx_wheel then
		state = nil
		-- next wheel a full interval after coming back (or after a NORMAL)
		timer = nil

		return
	end

	local interval = max(S.wheel_interval or 30, 5)

	timer = timer or interval * (0.5 + 0.5 * math.random())

	local s = state

	if not s then
		timer = timer - dt

		if timer <= 0 then
			timer = interval * (0.85 + 0.3 * math.random())
			Wheel.spin()
		end

		return
	end

	s.t = s.t + dt

	local spin_end = POP_TIME + SPIN_TIME

	if s.t < POP_TIME then
		angle = s.from
	elseif s.t < spin_end then
		local p = (s.t - POP_TIME) / SPIN_TIME

		angle = s.from + (s.to - s.from) * (1 - (1 - p) ^ 4)
	else
		angle = s.to
	end

	if not s.done and s.t >= spin_end + SHOW_TIME then
		s.done = true
		apply(s.key)
	end

	if s.t >= spin_end + SHOW_TIME + OUT_TIME then
		state = nil
	end
end

local function hsv(h)
	h = (h % 1) * 6

	local i = floor(h)
	local f = h - i

	if i == 0 then return 1, f, 0
	elseif i == 1 then return 1 - f, 1, 0
	elseif i == 2 then return 0, 1, f
	elseif i == 3 then return 0, 1 - f, 1
	elseif i == 4 then return f, 0, 1
	end

	return 1, 0, 1 - f
end

--[[
    What the HUD element should draw this frame (1920x1080 top-left space).
--]]
function Wheel.view(out)
	local s = state
	local Skel = mod.__dws_skeleton

	if not s or not Skel then
		return nil
	end

	local t = s.t
	local spin_end = POP_TIME + SPIN_TIME
	local scale

	if t < POP_TIME then
		-- pop in with a little overshoot
		local p = t / POP_TIME
		scale = smooth(p) * (1 + 0.25 * sin(p * pi))
	elseif t < spin_end + SHOW_TIME then
		scale = 1

		if t >= spin_end then
			scale = 1 + 0.06 * abs(sin((t - spin_end) * 10))
		end
	else
		scale = 1 - smooth((t - spin_end - SHOW_TIME) / OUT_TIME)
	end

	local ws = max((W.S.wheel_size or 130) / 100, 0.1)
	local size = SIZE * ws * scale
	local leaving = t >= spin_end + SHOW_TIME
	local a = angle + (leaving and (t - spin_end - SHOW_TIME) * 14 or 0)

	out.alpha = 255 * min(1, scale * 1.5)
	out.tex = Skel.texture("wheel/wheel.png")
	out.pointer_tex = Skel.texture("wheel/pointer.png")
	out.size = size
	out.x, out.y = s.x - size / 2, s.y - size / 2
	out.angle = a

	-- the pointer ticks back each time a slice boundary passes under it
	local tick = 0

	if t >= POP_TIME and t < spin_end then
		local local_top = (angle - pi / 2) % (2 * pi)
		local nearest = 1

		for _, seg in ipairs(SEGMENTS) do
			local d = abs(((local_top - seg[3]) + pi) % (2 * pi) - pi)
			nearest = min(nearest, d)
		end

		tick = max(0, 0.45 - nearest * 4)
	end

	out.pointer_w, out.pointer_h = 64 * ws * scale, 80 * ws * scale
	out.pointer_x = s.x - out.pointer_w / 2
	out.pointer_y = s.y - size / 2 - out.pointer_h * 0.55
	out.pointer_angle = tick

	local r, g, b = hsv(s.hue + t * 0.8)

	out.title = t < spin_end and "WHEEL OF MISFORTUNE" or s.label
	out.title_size = t < spin_end and 44 or floor(76 + 10 * sin(t * 12))
	out.title_x, out.title_y = s.x - 900, s.y - size / 2 - 150
	out.title_r, out.title_g, out.title_b = floor(r * 255), floor(g * 255), floor(b * 255)
	out.sub = t >= spin_end and s.sub or ""
	out.sub_x, out.sub_y = s.x - 900, s.y + size / 2 + 6

	if s.key == "normal" and t >= spin_end then
		out.title_r, out.title_g, out.title_b = 120, 255, 140
	end

	return out
end

-- ---------------------------------------------------------------- the dog

--[[
    The wheel's NORMAL slice turns everything off for a while. The dog comes
    up from the bottom of the screen with a halo and sits there for a few
    seconds while it is quiet.

    He is drawn by the same HUD element, and he is not cleared when the mod
    goes sober, because going sober is exactly when he turns up.
--]]
local DOG_ASPECT = 228 / 271 -- dog.png as shipped; a replaced file is measured instead
local DOG_IN, DOG_OUT, DOG_RISE = 0.5, 0.8, 0.6

local dog = nil
local dog_loaded = false

--[[
    Two ways he turns up:
      "hero"  the wheel's NORMAL. Big, middle of the screen, rises from the
              bottom, goes after a few seconds.
      "watch" Judas mode. Smaller, parked on the right where there is nothing
              to cover, slides in from the edge and stays until cleared.
--]]
function Wheel.dog(seconds, mode)
	if not W.S.fx_dog then
		return false
	end

	local Skel = mod.__dws_skeleton

	if Skel and not dog_loaded then
		dog_loaded = true
		Skel.texture("dog/dog.png")
		Skel.texture("dog/halo.png")
	end

	dog = {
		t = 0,
		mode = mode or "hero",
		dur = seconds and max(seconds, DOG_IN + DOG_OUT + 0.5) or nil,
	}

	return true
end

function Wheel.dog_clear()
	dog = nil
end

function Wheel.dog_update(dt)
	if not dog then
		return
	end

	dog.t = dog.t + dt

	if (dog.dur and dog.t >= dog.dur) or not W.S.fx_dog then
		dog = nil
	end
end

function Wheel.dog_view(out)
	local Skel = mod.__dws_skeleton

	if not dog or not Skel then
		return nil
	end

	local t = dog.t
	local watching = dog.mode == "watch"
	-- a dog with no end time never fades out
	local fade = min(t / DOG_IN, dog.dur and (dog.dur - t) / DOG_OUT or 1, 1)

	if fade <= 0 then
		return nil
	end

	local h = max((W.S.dog_size or 40) / 100, 0.05) * 1080

	if watching then
		h = h * 0.6
	end

	local tw, th = Skel.texture_size("dog/dog.png")
	local w = h * ((tw and th and th > 0) and tw / th or DOG_ASPECT)
	local cx, cy, halo, halo_alpha

	if watching then
		-- parked on the right, sliding in from off the edge
		local slide = 1 - smooth(min(1, t / 0.45))
		cx = 1920 - w / 2 - 100 + (w + 140) * slide
		cy = 430 + 7 * sin(t * 1.4)
		halo = h * 1.6 * (1 + 0.025 * sin(t * 2.0))
		halo_alpha = 175 * fade
	else
		cx = 960
		-- rises from below, settles, then breathes
		cy = 1080 - h * 0.52 - (h * 0.42) * smooth(min(1, t / DOG_RISE)) + 9 * sin(t * 1.6)
		halo = h * 1.9 * (1 + 0.03 * sin(t * 2.2))
		halo_alpha = 215 * fade
	end

	out.alpha = 255 * fade
	out.dog_tex = Skel.texture("dog/dog.png")
	out.dog_w, out.dog_h = w, h
	out.dog_x, out.dog_y = cx - w / 2, cy - h / 2
	out.halo_tex = Skel.texture("dog/halo.png")
	out.halo_alpha = halo_alpha
	out.halo_size = halo
	out.halo_x = cx - halo / 2
	out.halo_y = cy - h * 0.14 - halo / 2
	out.halo_angle = t * 0.35

	return out
end

mod.__dws_wheel = Wheel

return Wheel
