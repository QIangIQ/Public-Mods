local mod = get_mod("DiosWarpSickness")

--[[
    ========================================================================
    BREATHING ENEMY OUTLINES
    ========================================================================

    OutlineSystem writes an outline's colour once, when the outline is added
    or shown (outline_system.lua: add_outline and _apply_outline_visibility,
    both through the local _update_material_layers_color). Nothing rewrites
    it per frame, so this module rewrites it itself at 10 Hz, only on units
    whose top outline is visible and is a minion outline.

    The write is the exact call QIangIQsGeneralEnemyOutliner uses:
        Unit.set_vector3_for_materials(unit, "outline_color", Vector3(r, g, b), true)

    The base colour always comes from the unit's CURRENT top outline, so a
    tagged enemy still reads as tagged, and Q's per-breed colours are what
    get pulsed. When the trip ends every touched unit gets its top outline
    colour written back once.
--]]

local Outlines = {}

local W = mod.__dws

local sin, floor, min, max = math.sin, math.floor, math.min, math.max

local touched = setmetatable({}, { __mode = "k" }) -- unit -> phase
local timer = 0
local had_any = false

local function outline_system()
	local state = Managers.state
	local ext = state and state.extension

	if not ext or not ext:has_system("outline_system") then
		return nil
	end

	return ext:system("outline_system")
end

local function is_minion_outline(layers)
	if type(layers) ~= "table" then
		return false
	end

	for i = 1, #layers do
		local l = layers[i]

		if type(l) == "string" and l:find("minion", 1, true) then
			return true
		end
	end

	return false
end

local function rgb_to_hsv(r, g, b)
	local mx, mn = max(r, g, b), min(r, g, b)
	local d = mx - mn
	local h = 0

	if d > 0 then
		if mx == r then
			h = ((g - b) / d) % 6
		elseif mx == g then
			h = (b - r) / d + 2
		else
			h = (r - g) / d + 4
		end

		h = h / 6
	end

	return h, mx > 0 and d / mx or 0, mx
end

local function hsv_to_rgb(h, s, v)
	h = (h % 1) * 6

	local i = floor(h)
	local f = h - i
	local p, q, t = v * (1 - s), v * (1 - s * f), v * (1 - s * (1 - f))

	if i == 0 then
		return v, t, p
	elseif i == 1 then
		return q, v, p
	elseif i == 2 then
		return p, v, t
	elseif i == 3 then
		return p, q, v
	elseif i == 4 then
		return t, p, v
	end

	return v, p, q
end

local function write(unit, r, g, b)
	pcall(Unit.set_vector3_for_materials, unit, "outline_color", Vector3(r, g, b), true)
end

function Outlines.restore()
	local sys = outline_system()
	local data = sys and sys._unit_extension_data

	for unit in pairs(touched) do
		local ext = data and data[unit]
		local top = ext and ext.outlines and ext.outlines[1]
		local c = top and top.color

		if c and Unit.alive(unit) then
			write(unit, c[1], c[2], c[3])
		end

		touched[unit] = nil
	end

	had_any = false
end

function Outlines.update(dt)
	local I = W.intensity
	local live = W.active and W.S.fx_outlines and I > 0.03

	if not live then
		if had_any then
			Outlines.restore()
		end

		return
	end

	timer = timer + dt

	if timer < 0.1 then
		return
	end

	timer = 0

	local sys = outline_system()
	local data = sys and sys._unit_extension_data

	if not data then
		return
	end

	local t = W.t
	local alive = rawget(_G, "HEALTH_ALIVE")
	local colour = (W.S.colour_strength or 60) / 100
	local rainbow = (I > 0.75 and (I - 0.75) / 0.25 or 0) * colour

	for unit, ext in pairs(data) do
		local top = ext.outlines and ext.outlines[1]
		local c = top and top.color

		if c and ext.visible_material_layers and is_minion_outline(top.material_layers)
			and (not alive or alive[unit]) then
			local phase = touched[unit]

			if not phase then
				phase = math.random() * 6.283
				touched[unit] = phase
			end

			local h, s, v = rgb_to_hsv(c[1], c[2], c[3])

			-- breathe: brightness pulse plus a small hue wobble
			v = v * (1 + 0.6 * I * colour * sin(4 * t + phase))
			h = h + 0.12 * I * colour * sin(1.3 * t + phase)

			if rainbow > 0 then
				local rh = (t * 0.35 + phase / 6.283) % 1

				h = h + (rh - h) * rainbow
				s = max(s, 0.85 * rainbow)
				v = max(v, 0.9)
			end

			write(unit, hsv_to_rgb(h, s, max(v, 0.05)))
			had_any = true
		end
	end
end

mod.__dws_outlines = Outlines

return Outlines
