return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsCitrinePrime` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsCitrinePrime", {
            mod_script = "QIangIQsCitrinePrime/scripts/mods/QIangIQsCitrinePrime/QIangIQsCitrinePrime",
            mod_data = "QIangIQsCitrinePrime/scripts/mods/QIangIQsCitrinePrime/QIangIQsCitrinePrime_data",
            mod_localization = "QIangIQsCitrinePrime/scripts/mods/QIangIQsCitrinePrime/QIangIQsCitrinePrime_localization",
        })
    end,
    version = "1.0.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
