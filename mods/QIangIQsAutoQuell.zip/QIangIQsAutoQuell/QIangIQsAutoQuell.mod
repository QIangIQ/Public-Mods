return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsAutoQuell` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsAutoQuell", {
			mod_script       = "QIangIQsAutoQuell/scripts/mods/QIangIQsAutoQuell/QIangIQsAutoQuell",
			mod_data         = "QIangIQsAutoQuell/scripts/mods/QIangIQsAutoQuell/QIangIQsAutoQuell_data",
			mod_localization = "QIangIQsAutoQuell/scripts/mods/QIangIQsAutoQuell/QIangIQsAutoQuell_localization",
		})
	end,
	packages = {},
}
