local mod = get_mod("QIangIQsAutoQuell")

local function checkbox(id, default)
	return { setting_id = id, type = "checkbox", default_value = default, tooltip = id .. "_tooltip" }
end

local function numeric(id, default, low, high, decimals)
	return { setting_id = id, type = "numeric", default_value = default, range = { low, high }, decimals_number = decimals or 0, tooltip = id .. "_tooltip" }
end

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			{
				setting_id = "group_general",
				type = "group",
				sub_widgets = {
					{
						setting_id = "toggle_key",
						type = "keybind",
						default_value = {},
						keybind_global = true,
						keybind_trigger = "pressed",
						keybind_type = "function_call",
						function_name = "toggle_active",
						tooltip = "toggle_key_tooltip",
					},
					{
						setting_id = "active_profile",
						type = "dropdown",
						default_value = 1,
						tooltip = "active_profile_tooltip",
						options = {
							{ text = "profile_1", value = 1 },
							{ text = "profile_2", value = 2 },
							{ text = "profile_3", value = 3 },
							{ text = "profile_4", value = 4 },
							{ text = "profile_5", value = 5 },
						},
					},
					{
						setting_id = "next_profile_key",
						type = "keybind",
						default_value = {},
						keybind_global = true,
						keybind_trigger = "pressed",
						keybind_type = "function_call",
						function_name = "next_profile",
						tooltip = "next_profile_key_tooltip",
					},
					checkbox("auto_ability", false),
				},
			},
			{
				setting_id = "group_weapon",
				type = "group",
				sub_widgets = {
					checkbox("jump_to_current", false),
					{
						setting_id = "weapon_selection",
						type = "dropdown",
						default_value = "global",
						tooltip = "weapon_selection_tooltip",
						options = {
							{ text = "weapon_global", value = "global" },
							{ text = "forcestaff_p1_m1", value = "forcestaff_p1_m1" },
							{ text = "forcestaff_p2_m1", value = "forcestaff_p2_m1" },
							{ text = "forcestaff_p3_m1", value = "forcestaff_p3_m1" },
							{ text = "forcestaff_p4_m1", value = "forcestaff_p4_m1" },
							{ text = "weapon_other", value = "other" },
						},
					},
					checkbox("w_custom", false),
					numeric("w_stop", 30, 0, 95),
					checkbox("w_never_below", true),
					checkbox("w_auto", true),
					numeric("w_auto_margin", 10, 1, 50),
					numeric("w_idle_delay", 0.75, 0, 3, 2),
					checkbox("w_allow_sprint", false),
					checkbox("w_allow_gaze", false),
					checkbox("w_siphon", false),
					numeric("w_siphon_per", 5, -15, 15),
					numeric("w_siphon_max", 90, 0, 99),
					checkbox("w_protect", true),
					checkbox("w_overload_shriek", true),
					checkbox("w_overload_gaze", true),
					numeric("w_overload_window", 3, 0, 10, 1),
					checkbox("reset_weapon", false),
					checkbox("reset_profile", false),
				},
			},
			{
				setting_id = "group_display",
				type = "group",
				sub_widgets = {
					checkbox("show_hud", true),
					checkbox("show_estimate", true),
					numeric("hud_x", 0, -1200, 1200),
					numeric("hud_y", 170, -600, 600),
					numeric("hud_font_size", 22, 12, 48),
				},
			},
			checkbox("debug_echo", false),
		},
	},
}
