local mod = get_mod("QIangIQsAutoQuell")

local Definitions = mod:io_dofile("QIangIQsAutoQuell/scripts/mods/QIangIQsAutoQuell/HudElementQIangIQsAutoQuell_definitions")

local HudElementQIangIQsAutoQuell = class("HudElementQIangIQsAutoQuell", "HudElementBase")

HudElementQIangIQsAutoQuell.init = function (self, parent, draw_layer, start_scale)
	HudElementQIangIQsAutoQuell.super.init(self, parent, draw_layer, start_scale, Definitions)

	self._last_x = nil
	self._last_y = nil
end

HudElementQIangIQsAutoQuell.update = function (self, dt, t, ui_renderer, render_settings, input_service)
	HudElementQIangIQsAutoQuell.super.update(self, dt, t, ui_renderer, render_settings, input_service)

	local x = mod:get("hud_x") or 0
	local y = mod:get("hud_y") or 170

	if x ~= self._last_x or y ~= self._last_y then
		self._last_x = x
		self._last_y = y

		self:set_scenegraph_position("area", x, y)
	end

	local widget = self._widgets_by_name.quell_text
	local counting, seconds, landing, overload_ok = mod.quell_readout()

	if counting == nil then
		widget.visible = false

		return
	end

	widget.visible = true

	local style = widget.style.text

	style.font_size = mod:get("hud_font_size") or 22
	style.text_color = counting and Definitions.color_counting or Definitions.color_estimate

	local label = mod:localize(counting and "hud_counting" or "hud_estimate")
	local text = string.format("%s %.1fs > %d%%", label, seconds, math.floor(landing * 100 + 0.5))

	if overload_ok then
		text = text .. "  " .. mod:localize("hud_overload_ok")
	end

	widget.content.text = text
end

return HudElementQIangIQsAutoQuell
