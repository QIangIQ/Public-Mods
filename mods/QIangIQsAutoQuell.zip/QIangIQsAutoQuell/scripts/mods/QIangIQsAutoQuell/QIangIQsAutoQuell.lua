local mod = get_mod("QIangIQsAutoQuell")

-- Auto quell for Psyker force staves, 0.3.0.
-- Profiles and per-staff settings (weapon selection like QIangIQsCookedMacroManager), quell stop on tap
-- and hold, built-in overload protection (behaviour of TheEmperorProtects), overload allowed when the
-- combat ability is ready or nearly ready.
--
-- Input route (GuaranteeQuell by NullRune): hook_safe on HumanInputHandler._parse_input, write into the
-- per-frame input cache, which is what the client sends (human_input_handler.lua 232-286, 305-331).
--
-- Game source: Aussiemon/Darktide-Source-Code master e46b8926.

local FixedFrame = require("scripts/utilities/fixed_frame")
local BuffSettings = require("scripts/settings/buff/buff_settings")

local PSYCHIC_FORTRESS = BuffSettings.keywords.psychic_fortress

local WIELD_GUARD = 0.3     -- GuaranteeQuell WIELD_VENT_GUARD
local MAX_WAIT = 0.6        -- GuaranteeQuell MAX_VENT_WAIT_TIME
local NO_DROP_LIMIT = 1.5
local RETRY_DELAY = 1
local HOLD_SECONDS = 0.35   -- a press held this long is a hold: letting go ends the quell
local EPSILON = 0.0005
local NUM_PROFILES = 5

local IDLE_GAME_MODES = { hub = true, prologue_hub = true }

local WEAPON_KEYS = {
	global = true,
	forcestaff_p1_m1 = true,
	forcestaff_p2_m1 = true,
	forcestaff_p3_m1 = true,
	forcestaff_p4_m1 = true,
	other = true,
}

-- TheEmperorProtects WEAPON_PERIL_THRESHOLDS: starting a charge this close to full is blocked.
local CHARGE_MARGIN = {
	forcestaff_p1_m1 = 0.08,
	forcestaff_p2_m1 = 0.06,
	forcestaff_p3_m1 = 0.08,
}

-- TheEmperorProtects FORCE_VENT_ACTION_NAMES: actions the quell can start from at full peril.
local VENT_FROM_ACTIONS = {
	action_rapid_right = true,
	action_charge_flame = true,
	action_charge = true,
}

-- psyker_abilities.lua: psyker_discharge_shout = base_shout, psyker_discharge_shout_improved; psyker_overcharge_stance.
local SHRIEK_ABILITIES = { psyker_discharge_shout = true, psyker_discharge_shout_improved = true }
local GAZE_ABILITIES = { psyker_overcharge_stance = true }

-- Character states where a running quell is left alone (character_states/player_character_state_*.lua).
local RUNNING_OK = {
	walking = true,
	sprinting = true,
	dodging = true,
	sliding = true,
	jumping = true,
	falling = true,
}

-- input_handler_settings.lua names.
local CANCEL_PRESSES = {
	"action_one_pressed",
	"action_two_pressed",
	"weapon_extra_pressed",
	"combat_ability_pressed",
	"grenade_ability_pressed",
	"interact_pressed",
	"quick_wield",
	"wield_scroll_down",
	"wield_scroll_up",
	"wield_1",
	"wield_2",
	"wield_3",
	"wield_3_gamepad",
	"wield_4",
	"wield_5",
}

local BUSY_HOLDS = {
	"action_one_hold",
	"action_two_hold",
	"weapon_reload_hold",
	"interact_hold",
	"combat_ability_hold",
	"grenade_ability_hold",
	"weapon_extra_hold",
}

local BLOCK_AT_FULL = {
	"action_one_pressed",
	"action_one_hold",
	"action_two_pressed",
	"action_two_hold",
}

-- Per-staff settings stored in each profile. Same ids as the widgets.
local FIELDS = {
	w_custom = false,
	w_stop = 30,
	w_auto = true,
	w_never_below = true,
	w_auto_margin = 10,
	w_idle_delay = 0.75,
	w_allow_sprint = false,
	w_allow_gaze = false,
	w_siphon = false,
	w_siphon_per = 5,
	w_siphon_max = 90,
	w_protect = true,
	w_overload_shriek = true,
	w_overload_gaze = true,
	w_overload_window = 3, -- unarmed.lua action_warp_charge_explode total_time = 3
}

local function default_entry()
	local entry = {}

	for key, value in pairs(FIELDS) do
		entry[key] = value
	end

	return entry
end

local function copy_entry(source)
	local entry = default_entry()

	for key in pairs(FIELDS) do
		if source and source[key] ~= nil then
			entry[key] = source[key]
		end
	end

	return entry
end

-- ---------------------------------------------------------------------------
-- Profiles
-- ---------------------------------------------------------------------------

local data = mod:get("profile_data")

if type(data) ~= "table" then
	data = {}
end

local function profile_table(index)
	local key = tostring(index)
	local profile = data[key]

	if type(profile) ~= "table" then
		profile = {}
		data[key] = profile
	end

	if type(profile.global) ~= "table" then
		profile.global = default_entry()
	end

	return profile
end

local function save_data()
	mod:set("profile_data", data, false)
end

local function active_profile()
	local index = tonumber(mod:get("active_profile")) or 1

	if index < 1 or index > NUM_PROFILES then
		index = 1
	end

	return index
end

local function selected_weapon()
	local key = mod:get("weapon_selection") or "global"

	return WEAPON_KEYS[key] and key or "global"
end

-- The settings a staff uses: its own entry if marked custom, otherwise the profile's global entry.
local function weapon_settings(weapon_key)
	local profile = profile_table(active_profile())
	local entry = profile[weapon_key]

	if type(entry) == "table" and entry.w_custom then
		return entry
	end

	return profile.global
end

local function load_widgets()
	local profile = profile_table(active_profile())
	local weapon_key = selected_weapon()
	local entry = profile[weapon_key]

	if type(entry) ~= "table" then
		entry = copy_entry(profile.global)
		entry.w_custom = false
	end

	for key in pairs(FIELDS) do
		local value = entry[key]

		if value == nil then
			value = FIELDS[key]
		end

		mod:set(key, value, false)
	end
end

-- ---------------------------------------------------------------------------
-- Global settings
-- ---------------------------------------------------------------------------

local cfg = {}

local function refresh_globals()
	cfg.debug_echo = mod:get("debug_echo") == true
	cfg.show_hud = mod:get("show_hud") ~= false
	cfg.show_estimate = mod:get("show_estimate") ~= false
	cfg.auto_ability = mod:get("auto_ability") == true
end

refresh_globals()

local paused = false

local state = {
	active = false,
	stage = "idle",
	source = nil,
	target_zero = false,
	request_t = 0,
	press_t = 0,
	long_hold = false,
	last_peril = 0,
	last_drop_t = 0,
	last_input_t = 0,
	last_slot = nil,
	guard_t = 0,
	retry_t = 0,
	latched = false,
	raw_hold = false,
	overload_ok = false,
	ability_left = nil,
	auto_block = "",
	weapon_key = nil,
}

local function debug_echo(text)
	if cfg.debug_echo then
		mod:echo(text)
	end
end

-- Diagnostics into the console log (not chat): on every change of state, and once a second.
local diag_t, diag_key = -1, ""

local function diag(now, key, text)
	now = now or 0

	if key ~= diag_key or now - diag_t >= 1 then
		diag_t = now
		diag_key = key

		mod:info(text or key)
	end
end

local function pct(fraction)
	return string.format("%.1f", fraction * 100)
end

local function stop_quell(reason)
	if state.active then
		debug_echo("stop: " .. reason)

		-- A quell to empty used up the second press.
		if state.target_zero then
			state.armed = false
		end
	end

	state.active = false
	state.stage = "idle"
	state.source = nil
	state.target_zero = false
	state.long_hold = false
end

mod.on_setting_changed = function (setting_id)
	if setting_id == "debug_echo" or setting_id == "show_hud" or setting_id == "show_estimate" or setting_id == "auto_ability" then
		refresh_globals()
	elseif setting_id == "active_profile" or setting_id == "weapon_selection" then
		load_widgets()
	elseif setting_id == "jump_to_current" then
		local current = state.weapon_key
		local target = (current and selected_weapon() ~= current) and current or "global"

		mod:set("jump_to_current", false, false)
		mod:set("weapon_selection", target, false)
		load_widgets()
	elseif setting_id == "reset_weapon" then
		local profile = profile_table(active_profile())
		local weapon_key = selected_weapon()

		if weapon_key == "global" then
			profile.global = default_entry()
		else
			profile[weapon_key] = nil
		end

		save_data()
		mod:set("reset_weapon", false, false)
		load_widgets()
	elseif setting_id == "reset_profile" then
		data[tostring(active_profile())] = nil
		profile_table(active_profile())
		save_data()
		mod:set("reset_profile", false, false)
		load_widgets()
	elseif FIELDS[setting_id] ~= nil then
		local profile = profile_table(active_profile())
		local weapon_key = selected_weapon()
		local entry = profile[weapon_key]

		if type(entry) ~= "table" then
			entry = copy_entry(profile.global)
			profile[weapon_key] = entry
		end

		entry[setting_id] = mod:get(setting_id)

		-- Changing any value of a staff gives it its own settings, as in Cooked Macro Manager.
		if weapon_key ~= "global" and setting_id ~= "w_custom" and not entry.w_custom then
			entry.w_custom = true
			mod:set("w_custom", true, false)
		end

		save_data()
	end

	stop_quell("settings changed")
end

mod.next_profile = function ()
	local index = active_profile() % NUM_PROFILES + 1

	mod:set("active_profile", index, false)
	load_widgets()
	stop_quell("profile")
	mod:echo(mod:localize("profile_switched") .. " " .. tostring(index))
end

-- ---------------------------------------------------------------------------
-- Game reads
-- ---------------------------------------------------------------------------

local function read_input(cache, lookup, name, index)
	local i = lookup[name]
	local slot = i and cache[i]

	return slot and slot[index]
end

local function any_input(cache, lookup, names, index)
	for i = 1, #names do
		if read_input(cache, lookup, names[i], index) then
			return true
		end
	end

	return false
end

local function write_input(cache, lookup, name, index, value)
	local i = lookup[name]
	local slot = i and cache[i]

	if slot then
		slot[index] = value
	end
end

-- Force staff with a quell action (keywords: forcestaff_p1_m1.lua 1024, p2 1078, p3 1106, p4 1030).
local function is_quell_staff(template)
	local keywords = template and template.keywords

	if not keywords then
		return false
	end

	local is_staff = false

	for i = 1, #keywords do
		if keywords[i] == "force_staff" then
			is_staff = true
		end
	end

	if not is_staff or not template.actions then
		return false
	end

	for _, action in pairs(template.actions) do
		if type(action) == "table" and action.kind == "vent_warp_charge" then
			return true
		end
	end

	return false
end

local function weapon_key_for(template_name)
	if template_name and WEAPON_KEYS[template_name] and template_name ~= "global" then
		return template_name
	end

	return "other"
end

local function is_venting(template, action_name)
	if not action_name or action_name == "none" then
		return false
	end

	local action = template.actions and template.actions[action_name]

	return action ~= nil and action.kind == "vent_warp_charge"
end

local function siphon_charges(player, unit_data)
	local profile = player:profile()
	local talents = profile and profile.talents

	if not talents or not talents.psyker_passive_souls_from_elite_kills then
		return 0
	end

	local resource = unit_data:read_component("talent_resource")

	return resource and resource.current_resource or 0
end

local function stop_fraction(settings, player, unit_data)
	local base = (settings.w_stop or 30) * 0.01

	if not settings.w_siphon then
		return base
	end

	local charges = siphon_charges(player, unit_data)
	local shifted = base + charges * (settings.w_siphon_per or 5) * 0.01
	local cap = (settings.w_siphon_max or 90) * 0.01

	if shifted > cap then
		shifted = math.max(base, cap)
	end

	return math.max(shifted, 0)
end

-- Vent numbers, same sum as WarpCharge.update_venting (warp_charge.lua 277-310).
-- Weapon quell stat: vent_duration_modifier (1.5 to 0.5). Talents and buffs: vent_warp_charge_speed,
-- multiplicative, lower is faster (buff_settings.lua 1020). vent_warp_charge_multiplier: bigger steps.
local function vent_numbers(player, unit, weapon_ext, starting)
	local profile = player:profile()
	local archetype = profile and profile.archetype
	local base = archetype and archetype.warp_charge

	if not base or not base.vent_duration or not base.vent_interval then
		return 0, 0, 1, 1, 1
	end

	local weapon_template = weapon_ext.warp_charge_template and weapon_ext:warp_charge_template() or nil
	local duration_mod = weapon_template and weapon_template.vent_duration_modifier
	local interval_mod = weapon_template and weapon_template.vent_interval_modifier

	duration_mod = type(duration_mod) == "number" and duration_mod or 1
	interval_mod = type(interval_mod) == "number" and interval_mod or 1

	local buff_ext = ScriptUnit.has_extension(unit, "buff_system")
	local stat_buffs = buff_ext and buff_ext:stat_buffs()
	local speed = stat_buffs and stat_buffs.vent_warp_charge_speed or 1
	local multiplier = stat_buffs and stat_buffs.vent_warp_charge_multiplier or 1
	local fraction = base.min_vent_time_fraction or 0.2
	local base_duration = base.vent_duration * fraction + base.vent_duration * (1 - fraction) * starting
	local duration = base_duration * duration_mod * speed
	local interval = base.vent_interval * interval_mod * speed

	if duration <= 0 then
		return 0, interval, duration_mod, speed, multiplier
	end

	return starting / duration * interval * multiplier, interval, duration_mod, speed, multiplier
end

local function tick_size(player, unit, weapon_ext, starting)
	local step = vent_numbers(player, unit, weapon_ext, starting)

	return step
end

local function another_tick_wanted(peril, tick, stop, never_below)
	if stop <= 0 then
		return peril > 0.001
	end

	if never_below then
		return tick < peril and peril - tick >= stop - EPSILON
	end

	return peril > stop
end

local function ticks_needed(peril, step, stop, never_below)
	if step <= 0 then
		return 0, peril
	end

	local count, landing = 0, peril

	while count < 400 and another_tick_wanted(landing, step, stop, never_below) do
		landing = math.max(landing - step, 0)
		count = count + 1
	end

	return count, landing
end

-- update_venting waits while t < remove_at_t, then sets t + interval: the gap rounds up to fixed steps.
local function real_interval(interval)
	local game_session = Managers.state and Managers.state.game_session
	local fixed_step = game_session and game_session.fixed_time_step

	if not fixed_step or fixed_step <= 0 then
		return interval
	end

	return math.ceil(interval / fixed_step - 0.000001) * fixed_step
end

local function minimum_hold(template)
	for _, action in pairs(template.actions or {}) do
		if type(action) == "table" and action.kind == "vent_warp_charge" then
			return action.minimum_hold_time or 0
		end
	end

	return 0
end

-- Seconds until the combat ability can be used. 0 = ready now, math.huge = not regenerating
-- (Scrier's Gaze pauses it while active: psyker_abilities.lua pause_cooldown_settings).
-- Same regen sum as PlayerUnitAbilityExtension._update_ability_resources (player_unit_ability_extension.lua 771-887).
local function ability_seconds_left_unsafe(unit)
	local ability_ext = ScriptUnit.has_extension(unit, "ability_system")

	if not ability_ext then
		return nil
	end

	if ability_ext:can_use_ability("combat_ability") then
		return 0
	end

	local ability = ability_ext:equipped_abilities().combat_ability

	if not ability or ability.only_uses_charges or ability_ext:is_ability_resource_regen_paused("combat_ability") then
		return math.huge
	end

	local missing = ability_ext:missing_ability_resource_until_next_charge("combat_ability")
	local max_resource = ability_ext:max_ability_resource("combat_ability")
	local buff_ext = ScriptUnit.has_extension(unit, "buff_system")
	local stat_buffs = buff_ext and buff_ext:stat_buffs() or {}
	local regen = (ability.resource_regen_per_second or 0) + max_resource * (ability.resource_regen_percent_per_second or 0)

	regen = (regen + (stat_buffs.combat_ability_resource_flat_regen or 0)) * (stat_buffs.combat_ability_resource_regen_modifier or 1)
	regen = regen - (ability_ext:get_ability_resource_cost_per_second("combat_ability") or 0)

	if regen <= 0 then
		return math.huge
	end

	return missing / regen
end

local function ability_seconds_left(unit)
	local ok, seconds = pcall(ability_seconds_left_unsafe, unit)

	return ok and seconds or nil
end

-- Overload is allowed when Venting Shriek or Scrier's Gaze is equipped (and allowed in the settings)
-- and is ready, or will be ready within the window.
local function overload_allowed(settings, unit, unit_data)
	local equipped = unit_data:read_component("equipped_abilities")
	local name = equipped and equipped.combat_ability

	state.ability_left = nil

	if not (SHRIEK_ABILITIES[name] and settings.w_overload_shriek or GAZE_ABILITIES[name] and settings.w_overload_gaze) then
		return false
	end

	local seconds = ability_seconds_left(unit)

	state.ability_left = seconds

	return seconds ~= nil and seconds <= (settings.w_overload_window or 3)
end

local function in_active_session()
	local game_state = Managers.state
	local game_mode = game_state and game_state.game_mode

	if not game_mode or not game_mode.game_mode_name then
		return false
	end

	local name = game_mode:game_mode_name()

	return name ~= nil and not IDLE_GAME_MODES[name]
end

local function game_time()
	local time = Managers.time

	if time and time:has_timer("gameplay") then
		return time:time("gameplay")
	end

	return nil
end

local function start_quell(source, now, peril, target_zero, raw_hold)
	state.active = true
	state.stage = "waiting"
	state.source = source
	state.target_zero = target_zero
	state.request_t = now
	state.press_t = now
	state.long_hold = false
	state.last_peril = peril
	state.last_drop_t = now
	state.latched = false

	debug_echo(source .. " start at " .. pct(peril) .. (target_zero and ", to empty" or ""))
end

-- ---------------------------------------------------------------------------
-- Main hook
-- ---------------------------------------------------------------------------

mod:hook_safe("HumanInputHandler", "_parse_input", function (self, input_cache, input_service, index)
	local lookup = self._action_lookup

	if not lookup then
		return
	end

	if not mod:is_enabled() or paused or not in_active_session() then
		stop_quell("off")
		diag(nil, "exit: off or not in a mission")

		return
	end

	local player = self._player
	local player_manager = Managers.player

	if not player or player ~= (player_manager and player_manager:local_player_safe(1)) then
		diag(nil, "exit: input handler is not the local player")

		return
	end

	local unit = player.player_unit
	local now = game_time()

	if not unit or not ALIVE[unit] or not now then
		stop_quell("no unit")

		return
	end

	local unit_data = ScriptUnit.has_extension(unit, "unit_data_system")
	local weapon_ext = ScriptUnit.has_extension(unit, "weapon_system")

	if not unit_data or not weapon_ext then
		stop_quell("no extensions")

		return
	end

	-- Optional: use Venting Shriek or Scrier's Gaze during a warp overload (TheEmperorProtects auto_use_ability).
	if cfg.auto_ability then
		local exploding = unit_data:read_component("exploding_character_state")

		if exploding and exploding.is_exploding and exploding.reason == "warp_charge" then
			local equipped = unit_data:read_component("equipped_abilities")
			local name = equipped and equipped.combat_ability

			if (SHRIEK_ABILITIES[name] or GAZE_ABILITIES[name]) and ability_seconds_left(unit) == 0 then
				write_input(input_cache, lookup, "combat_ability_pressed", index, true)
			end
		end
	end

	local inventory = unit_data:read_component("inventory")
	local slot = inventory and inventory.wielded_slot or "none"

	if slot ~= state.last_slot then
		state.last_slot = slot
		state.guard_t = now + WIELD_GUARD

		stop_quell("weapon swap")
	end

	local template = weapon_ext:weapon_template()
	local weapon_action = unit_data:read_component("weapon_action")

	if not is_quell_staff(template) or not weapon_action then
		state.weapon_key = nil

		stop_quell("not a staff")
		diag(now, "exit: not a staff")

		return
	end

	local weapon_key = weapon_key_for(weapon_action.template_name)
	local settings = weapon_settings(weapon_key)

	state.weapon_key = weapon_key

	local warp_charge = unit_data:read_component("warp_charge")
	local character_state = unit_data:read_component("character_state")

	if not warp_charge or not character_state then
		stop_quell("no components")

		return
	end

	local peril = warp_charge.current_percentage or 0
	local state_name = character_state.state_name
	local action_name = weapon_action.current_action_name
	local venting = is_venting(template, action_name)
	-- UIManager.inputs_in_use returns a table of locked inputs (always truthy); using_input is the boolean (ui_manager.lua).
	local ui_busy = Managers.ui and Managers.ui:using_input() or false
	local exploding = warp_charge.state == "exploding"
	local buff_ext = ScriptUnit.has_extension(unit, "buff_system")
	local fortress = buff_ext and buff_ext:has_keyword(PSYCHIC_FORTRESS)
	local overload_ok = overload_allowed(settings, unit, unit_data)
	local protect = settings.w_protect and not overload_ok and not fortress

	state.overload_ok = overload_ok or fortress

	-- Overload protection, the rules of TheEmperorProtects prevent_explosion for staves.
	-- A warp action that starts at full peril explodes (warp_charge.lua check_new_state: current >= 1 and starting >= 1).
	if protect and not exploding then
		if peril >= 1 then
			for i = 1, #BLOCK_AT_FULL do
				write_input(input_cache, lookup, BLOCK_AT_FULL[i], index, false)
			end
		elseif action_name == "none" and CHARGE_MARGIN[weapon_action.template_name] then
			local stat_buffs = buff_ext and buff_ext:stat_buffs()
			local multiplier = stat_buffs and (stat_buffs.warp_charge_amount or 1) * (stat_buffs.warp_charge_over_time_amount or 1) or 1

			if peril >= 1 - CHARGE_MARGIN[weapon_action.template_name] * multiplier then
				write_input(input_cache, lookup, "action_two_hold", index, false)
				write_input(input_cache, lookup, "action_two_pressed", index, false)
			end
		end
	end

	local raw_hold = read_input(input_cache, lookup, "weapon_reload_hold", index) == true
	-- A new press: the ephemeral pressed flag, or the hold going from up to down.
	local raw_pressed = read_input(input_cache, lookup, "weapon_reload_pressed", index) == true or (raw_hold and not state.prev_raw_hold)

	state.prev_raw_hold = raw_hold
	state.raw_hold = raw_hold

	if state.latched and not raw_hold then
		state.latched = false
	end

	if any_input(input_cache, lookup, BUSY_HOLDS, index) or any_input(input_cache, lookup, CANCEL_PRESSES, index) then
		state.last_input_t = now
	end

	local stop = stop_fraction(settings, player, unit_data)
	local never_below = settings.w_never_below ~= false

	if not state.active and now >= state.guard_t and now >= state.retry_t and not ui_busy and not exploding then
		local next_tick = tick_size(player, unit, weapon_ext, peril)
		local above_stop = another_tick_wanted(peril, next_tick, stop, never_below)
		local emergency = protect and peril >= 1 - EPSILON

		-- Peril back above the stop: a new cycle, the next press stops at the stop again.
		if above_stop then
			state.armed = false
		end

		if raw_pressed and RUNNING_OK[state_name] and peril > 0.001 then
			if above_stop then
				-- Quell to the stop.
				start_quell("press", now, peril, false, raw_hold)
			elseif state.armed then
				-- Already at the stop and pressed again: quell to empty.
				start_quell("press", now, peril, true, raw_hold)
			else
				-- At or under the stop with no stop yet this cycle: hold the key off. The next press quells to empty.
				state.armed = true
				state.latched = raw_hold

				debug_echo("held at the stop, press again to quell to empty")
			end
		elseif emergency and RUNNING_OK[state_name] and (action_name == "none" or VENT_FROM_ACTIONS[action_name]) and not venting then
			start_quell("full peril", now, peril, false, raw_hold)
		elseif settings.w_auto and above_stop then
			local allow_sprint = settings.w_allow_sprint
			local reason = nil

			if raw_hold or venting or action_name ~= "none" then
				reason = "busy"
			elseif not (state_name == "walking" or (allow_sprint and state_name == "sprinting")) then
				reason = "state " .. tostring(state_name)
			elseif not allow_sprint and read_input(input_cache, lookup, "sprinting", index) then
				reason = "sprint held"
			elseif now - state.last_input_t < (settings.w_idle_delay or 0.75) then
				reason = "idle delay"
			elseif peril < stop + (settings.w_auto_margin or 10) * 0.01 - EPSILON then
				reason = "under start margin"
			elseif not settings.w_allow_gaze and buff_ext and buff_ext:has_buff_using_buff_template("psyker_overcharge_stance") then
				reason = "Scrier's Gaze"
			end

			state.auto_block = reason or ""

			if not reason then
				start_quell("auto", now, peril, false, raw_hold)
			end
		end
	end

	if state.active then
		local keep = true

		if ui_busy or exploding or not RUNNING_OK[state_name] then
			stop_quell("state " .. tostring(state_name))

			keep = false
		elseif any_input(input_cache, lookup, CANCEL_PRESSES, index) then
			stop_quell("player input")

			keep = false
		elseif state.source == "auto" then
			local sprint = not settings.w_allow_sprint and (read_input(input_cache, lookup, "sprinting", index) or read_input(input_cache, lookup, "sprint", index))

			if sprint or read_input(input_cache, lookup, "action_one_hold", index) or read_input(input_cache, lookup, "action_two_hold", index) then
				stop_quell("player input")

				keep = false
			end
		elseif state.source == "press" then
			-- Held past HOLD_SECONDS: a hold. Letting go ends it. A short tap keeps going to the target.
			if raw_hold and now - state.press_t >= HOLD_SECONDS then
				state.long_hold = true
			elseif not raw_hold and state.long_hold then
				stop_quell("released")

				keep = false
			end
		end

		if keep then
			if state.stage == "waiting" then
				if venting then
					state.stage = "venting"
					state.last_peril = peril
					state.last_drop_t = now
				elseif now - state.request_t > MAX_WAIT then
					state.retry_t = now + RETRY_DELAY

					stop_quell("vent did not start")

					keep = false
				end
			elseif not venting then
				state.stage = "waiting"
				state.request_t = now
			end
		end

		if keep then
			if peril < state.last_peril - EPSILON then
				state.last_drop_t = now
			end

			state.last_peril = peril

			if state.stage == "venting" and now - state.last_drop_t > NO_DROP_LIMIT then
				state.retry_t = now + RETRY_DELAY

				stop_quell("peril stopped falling")

				keep = false
			end
		end

		if keep then
			local starting = state.stage == "venting" and warp_charge.starting_percentage or peril
			local tick = tick_size(player, unit, weapon_ext, starting or peril)
			local target = state.target_zero and 0 or stop

			if not another_tick_wanted(peril, tick, target, never_below) then
				local was_to_empty = state.target_zero

				stop_quell("reached " .. pct(peril))

				-- The key is still down: hold it off until it is let go. The next press quells to empty.
				state.latched = raw_hold
				state.armed = not was_to_empty
			else
				write_input(input_cache, lookup, "weapon_reload_hold", index, true)
			end
		end
	end

	if not state.active and state.latched and raw_hold then
		write_input(input_cache, lookup, "weapon_reload_hold", index, false)
	end

	local wrote = read_input(input_cache, lookup, "weapon_reload_hold", index)
	local key = string.format("%s act=%s src=%s zero=%s raw=%s latch=%s armed=%s sent=%s action=%s state=%s protect=%s",
		weapon_key, tostring(state.active), tostring(state.source), tostring(state.target_zero), tostring(raw_hold), tostring(state.latched),
		tostring(state.armed), tostring(wrote), tostring(action_name), tostring(state_name), tostring(protect))

	diag(now, key, string.format("peril=%.3f stop=%.3f %s", peril, stop, key))
end)

-- ---------------------------------------------------------------------------
-- HUD readout
-- ---------------------------------------------------------------------------

-- Returns counting, seconds, landing, overload_ok. nil hides the HUD.
mod.quell_readout = function ()
	if not cfg.show_hud or not mod:is_enabled() or paused or not in_active_session() then
		return nil
	end

	local player = Managers.player and Managers.player:local_player_safe(1)
	local unit = player and player.player_unit

	if not unit or not ALIVE[unit] then
		return nil
	end

	local unit_data = ScriptUnit.has_extension(unit, "unit_data_system")
	local weapon_ext = ScriptUnit.has_extension(unit, "weapon_system")

	if not unit_data or not weapon_ext then
		return nil
	end

	local template = weapon_ext:weapon_template()
	local warp_charge = unit_data:read_component("warp_charge")
	local weapon_action = unit_data:read_component("weapon_action")

	if not is_quell_staff(template) or not warp_charge or not weapon_action or warp_charge.state == "exploding" then
		return nil
	end

	local settings = weapon_settings(weapon_key_for(weapon_action.template_name))
	local never_below = settings.w_never_below ~= false
	local peril = warp_charge.current_percentage or 0
	local stop = stop_fraction(settings, player, unit_data)

	if is_venting(template, weapon_action.current_action_name) then
		if not state.active then
			return nil
		end

		local starting = warp_charge.starting_percentage or peril
		local step, interval = vent_numbers(player, unit, weapon_ext, starting)
		local count, landing = ticks_needed(peril, step, state.target_zero and 0 or stop, never_below)

		if count == 0 then
			return nil
		end

		local to_next = (warp_charge.remove_at_t or 0) - FixedFrame.get_latest_fixed_time()

		to_next = math.max(math.min(to_next, interval), 0)

		return true, to_next + (count - 1) * real_interval(interval), landing, state.overload_ok
	end

	if not state.active and not cfg.show_estimate then
		return nil
	end

	local step, interval = vent_numbers(player, unit, weapon_ext, peril)
	local count, landing = ticks_needed(peril, step, state.target_zero and 0 or stop, never_below)

	-- At the stop after a stop: show what the next press does (quell to empty).
	if count == 0 and not state.active and state.armed then
		count, landing = ticks_needed(peril, step, 0, never_below)
	end

	if count == 0 then
		return nil
	end

	return state.active, math.max(count * real_interval(interval), minimum_hold(template)), landing, state.overload_ok
end

local hud_element = {
	use_hud_scale = true,
	class_name = "HudElementQIangIQsAutoQuell",
	filename = "QIangIQsAutoQuell/scripts/mods/QIangIQsAutoQuell/HudElementQIangIQsAutoQuell",
	visibility_groups = {
		"alive",
	},
}

mod:add_require_path(hud_element.filename)

local function add_hud_element(element_pool)
	local found_key = table.find_by_key(element_pool, "class_name", hud_element.class_name)

	if found_key then
		element_pool[found_key] = hud_element
	else
		table.insert(element_pool, hud_element)
	end
end

mod:hook_require("scripts/ui/hud/hud_elements_player", add_hud_element)
mod:hook_require("scripts/ui/hud/hud_elements_player_onboarding", add_hud_element)

mod.toggle_active = function ()
	paused = not paused

	stop_quell("toggle")
	mod:echo(mod:localize(paused and "toggled_off" or "toggled_on"))
end

mod.on_disabled = function ()
	stop_quell("disabled")
end

mod.on_all_mods_loaded = function ()
	load_widgets()
end

mod:command("autoquell_info", mod:localize("info_command"), function ()
	local player = Managers.player and Managers.player:local_player_safe(1)
	local unit = player and player.player_unit
	local unit_data = unit and ScriptUnit.has_extension(unit, "unit_data_system")
	local weapon_ext = unit and ScriptUnit.has_extension(unit, "weapon_system")

	if not unit_data or not weapon_ext then
		mod:echo("No player unit.")

		return
	end

	local template = weapon_ext:weapon_template()
	local weapon_action = unit_data:read_component("weapon_action")
	local warp_charge = unit_data:read_component("warp_charge")
	local peril = warp_charge and warp_charge.current_percentage or 0

	if not is_quell_staff(template) or not weapon_action then
		mod:echo("Wielded weapon is not a force staff. Peril " .. pct(peril))

		return
	end

	local weapon_key = weapon_key_for(weapon_action.template_name)
	local settings = weapon_settings(weapon_key)
	local never_below = settings.w_never_below ~= false
	local stop = stop_fraction(settings, player, unit_data)
	local step_now, interval, duration_mod, speed, multiplier = vent_numbers(player, unit, weapon_ext, peril)
	local step_full = vent_numbers(player, unit, weapon_ext, 1)
	local count_now, landing_now = ticks_needed(peril, step_now, stop, never_below)
	local count_full, landing_full = ticks_needed(1, step_full, stop, never_below)
	local gap = real_interval(interval)
	local left = ability_seconds_left(unit)

	mod:echo(string.format("Profile %d, %s (%s), peril %s, stop %s, siphon charges %d, paused %s, state %s", active_profile(), weapon_key, settings.w_custom and "own settings" or "global settings", pct(peril), pct(stop), siphon_charges(player, unit_data), tostring(paused), state.stage))
	mod:echo(string.format("Weapon quell stat x%.2f, talents and buffs speed x%.2f, step multiplier x%.2f, one step every %.3f s", duration_mod, speed, multiplier, gap))
	mod:echo(string.format("From now: %.2f s, %d steps of %s, lands at %s", count_now * gap, count_now, pct(step_now), pct(landing_now)))
	mod:echo(string.format("From full peril: %.2f s, %d steps of %s, lands at %s", count_full * gap, count_full, pct(step_full), pct(landing_full)))
	mod:echo(string.format("Overload allowed: %s, combat ability in %s s, protection %s, auto start blocked by: %s", tostring(state.overload_ok), left == nil and "?" or (left == math.huge and "never" or string.format("%.1f", left)), tostring(settings.w_protect), state.auto_block ~= "" and state.auto_block or "nothing"))
end)
