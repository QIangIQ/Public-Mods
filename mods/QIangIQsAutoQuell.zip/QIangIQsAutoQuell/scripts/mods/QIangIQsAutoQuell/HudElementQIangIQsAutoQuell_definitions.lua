-- Layout pattern from PerilGauge UIDefinitions.lua.
local UIFontSettings = require("scripts/managers/ui/ui_font_settings")
local UIHudSettings = require("scripts/settings/ui/ui_hud_settings")
local UIWorkspaceSettings = require("scripts/settings/ui/ui_workspace_settings")
local UIWidget = require("scripts/managers/ui/ui_widget")

local text_style = table.clone(UIFontSettings.body_small)

text_style.size = { 600, 60 }
text_style.offset = { 0, 0, 3 }
text_style.horizontal_alignment = "center"
text_style.vertical_alignment = "center"
text_style.text_horizontal_alignment = "center"
text_style.text_vertical_alignment = "center"
text_style.drop_shadow = true

return {
	color_counting = table.clone(UIHudSettings.color_tint_main_1),
	color_estimate = table.clone(UIHudSettings.color_tint_main_2),
	scenegraph_definition = {
		screen = UIWorkspaceSettings.screen,
		area = {
			vertical_alignment = "center",
			parent = "screen",
			horizontal_alignment = "center",
			size = { 600, 60 },
			position = { 0, 170, 1 },
		},
	},
	widget_definitions = {
		quell_text = UIWidget.create_definition({
			{
				value_id = "text",
				style_id = "text",
				pass_type = "text",
				value = "",
				style = text_style,
			},
		}, "area"),
	},
}
