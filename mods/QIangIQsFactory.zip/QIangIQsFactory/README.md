# QIangIQsFactory (personal use only, do not share)

The whole of Escape from Tarkov's Factory, converted from an Atlas pack built on this PC, inside Darktide.
The geometry and textures belong to Battlestate Games: personal use only, never upload or share this folder.
Nothing spawns outside a SoloPlay local session (host type singleplay); Realms and official servers are refused.

Use:
- SoloPlay mission list: "Factory (Tarkov) - QIangIQ" (a copy of the prologue; Factory loads above it and you are
  put in the main hall after a few seconds). Set SoloPlay bots to 0: bots and enemies cannot walk in Factory.
- Or `/factory` in any SoloPlay mission. `/factory back` returns, `/factory debug` shows state,
  `/factory realms` turns the Realms server back on if /factory switched it off.
- After any rebuild: run CUSTOM_ASSETS_PATCH.bat with the game closed and check CustomAssets/generated/last_patch.log.

Built with A:\Dowloads\QIangIQsMapViewer\factory (build_full.py, compile_full.py); notes in
_QIangIQ_notes/utility/46_*. QIangIQsFactory must stay above SoloPlay in mod_load_order.txt.
