return {
    mod_name = { en = "QIangIQ's Factory (Tarkov, SoloPlay only)" },
    mod_description = { en = "Personal use only: the whole of Tarkov's Factory, spawned above you. Adds the SoloPlay mission 'Factory (Tarkov) - QIangIQ'. SoloPlay local sessions only; refused on Realms and official servers. /factory, /factory back, /factory debug." },
    cmd_desc = { en = "Tarkov Factory (SoloPlay only): /factory, /factory back, /factory debug, /factory realms" },
    spawn_height = { en = "Spawn height above you (m)" },
    keep_room = { en = "Keep Factory loaded after /factory back" },
}
