-- QIangIQ's Factory: the whole of Tarkov's Factory inside Darktide (SoloPlay only).
-- PERSONAL USE ONLY. Geometry and textures are converted from Battlestate Games' assets (Atlas pack built on this
-- PC); they must never be shared. That is why nothing ever spawns outside a SoloPlay local session:
--   SoloPlay's own check   get_mod("SoloPlay").is_soloplay()  (SoloPlay.lua:30, host type "singleplay")
--   and our own check      Managers.multiplayer_session:host_type() == HOST_TYPES.singleplay
--                          (matchmaking_constants.lua:5: player = Realms, mission_server = official servers)
-- Assets: QIangIQsFactory:factory_lib (757 shared materials) + 150 chunk units (factory_layout.lua), built by
-- A:\Dowloads\QIangIQsMapViewer\factory (build_full.py, compile_full.py). See _QIangIQ_notes/utility/46_*.
-- Mission: "factory_tarkov" in SoloPlay's list = a copy of the prologue mission (user's choice of host level);
-- Factory loads 300 m above the prologue and you are put in its main hall. Enemies cannot path in Factory.
-- Commands: /factory        load Factory above you and stand in it (any SoloPlay mission)
--           /factory back   return to where you were
--           /factory debug  print state and a collision probe
--           /factory realms switch the Realms server back on (see pause_realms)
local mod = get_mod("QIangIQsFactory")
local MatchmakingConstants = require("scripts/settings/network/matchmaking_constants")
local PlayerMovement = require("scripts/utilities/player_movement")
local HOST_TYPES = MatchmakingConstants.HOST_TYPES
-- io_dofile reads the loose file from the mods folder (dmf io.lua: "IO version of the dofile method");
-- mod:dofile looks for a bundled resource and reported "Resource not found" for this file.
local Layout = mod:io_dofile("QIangIQsFactory/scripts/mods/QIangIQsFactory/factory_layout")
if type(Layout) ~= "table" or type(Layout.chunks) ~= "table" then
    mod:error("factory_layout.lua could not be read; the Factory map is unavailable")
    Layout = { chunks = {}, spawn = { 0, 0, 0 } }
end

local LIB_ID = "QIangIQsFactory:factory_lib"
local UNIT_PREFIX = "content/mods/qiangiq_factory/"
local MISSION_KEY = "factory_tarkov"
local HOST_MISSION = "prologue"
local RESCUE_BELOW = 14 -- metres below the map origin (Factory's lowest floor is about -12 m)
local SPAWNS_PER_FRAME = 8

-- ---------------------------------------------------------------------------------------------------- mission entry
-- Runs when this file loads, which must be before SoloPlay builds its mission list (SoloPlaySettings.lua:196
-- iterates MissionTemplates at SoloPlay's load): QIangIQsFactory sits above SoloPlay in mod_load_order.txt.
local function register_mission()
    local ok, err = pcall(function()
        local MissionTemplates = require("scripts/settings/mission/mission_templates")
        local host = MissionTemplates[HOST_MISSION]
        if not host or MissionTemplates[MISSION_KEY] then
            return
        end
        local template = table.clone(host)
        template.name = MISSION_KEY
        template.mission_name = "loc_mission_name_factory_tarkov"
        MissionTemplates[MISSION_KEY] = template
        -- mission names are networked by index (network_lookup.lua:314); the table errors on unknown keys
        -- (network_lookup.lua:576), so append ours the way _init does: array entry + reverse index
        local NetworkLookup = require("scripts/network_lookup/network_lookup")
        local lookup = rawget(NetworkLookup, "missions")
        if lookup and rawget(lookup, MISSION_KEY) == nil then
            local index = #lookup + 1
            rawset(lookup, index, MISSION_KEY)
            rawset(lookup, MISSION_KEY, index)
        end
        -- dialogue files are chosen by mission name (dialogue_system.lua:110/116): mirror the prologue's
        local DialogueSettings = require("scripts/settings/dialogue/dialogue_settings")
        if DialogueSettings.blocked_auto_load_files then
            DialogueSettings.blocked_auto_load_files[MISSION_KEY] = DialogueSettings.blocked_auto_load_files[HOST_MISSION]
        end
        if DialogueSettings.level_specific_load_files then
            DialogueSettings.level_specific_load_files[MISSION_KEY] = DialogueSettings.level_specific_load_files[HOST_MISSION]
        end
    end)
    if not ok then
        mod:error("could not add the Factory mission: %s", tostring(err))
    end
end

mod:add_global_localize_strings({
    loc_mission_name_factory_tarkov = { en = "Factory (Tarkov) - QIangIQ" },
})
register_mission()

-- ---------------------------------------------------------------------------------------------------- state
local custom_assets = nil
local lib_ticket = nil
local chunk_tickets = {}
local loaded_chunks = {}  -- name -> true once its package is ready
local load_state = "idle" -- idle | loading | ready
local units = {}          -- spawned chunk units
local unit_set = {}
local spawn_queue = nil   -- chunk rows still to spawn
local base_box = nil      -- Vector3Box: map origin in the world
local return_pos = nil
local release_pending = false
local auto_enter = nil    -- seconds left before the automatic entry in the Factory mission

local function say(fmt, ...)
    mod:echo("[Factory] " .. string.format(fmt, ...))
end

local function local_player()
    local players = Managers.player
    if not players then
        return nil
    end
    local ok, player = pcall(players.local_player_safe, players, 1)
    return ok and player or nil
end

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function current_mission()
    local m = Managers.state and Managers.state.mission
    local ok, name = pcall(function() return m and m:mission_name() end)
    return ok and name or nil
end

-- ---------------------------------------------------------------------------------------------------- the gate
local function soloplay_only()
    local soloplay = get_mod("SoloPlay")
    if not soloplay or type(soloplay.is_soloplay) ~= "function" then
        return false, "SoloPlay is not installed"
    end
    local session0 = Managers.multiplayer_session
    if session0 and session0:host_type() == HOST_TYPES.player then
        -- the Realms mod re-hosts SoloPlay missions as a listen server (console: "Created listen host lobby")
        return false, "realms"
    end
    local ok, is_solo = pcall(soloplay.is_soloplay)
    if not ok or not is_solo then
        return false, "not in a SoloPlay mission"
    end
    local session = Managers.multiplayer_session
    if not session or session:host_type() ~= HOST_TYPES.singleplay then
        return false, "session is not single-player (Realms and official servers are refused)"
    end
    local game_mode = Managers.state and Managers.state.game_mode
    local mode = game_mode and game_mode:game_mode_name()
    if mode == "hub" or mode == "prologue_hub" then
        return false, "missions only (not the Mourningstar)"
    end
    return true
end

-- Temporary Realms pause. Realms re-hosts SoloPlay missions as a listen server unless its "Enable Realms server"
-- option (setting enable_server, read when a session starts: Realms core/session.lua:416/457) is off.
local function realms_mod()
    local realms = get_mod("Realms")
    return realms and type(realms.get) == "function" and realms or nil
end

local function pause_realms()
    local realms = realms_mod()
    if not realms then
        return false
    end
    if realms:get("enable_server") then
        realms:set("enable_server", false, true)
        mod:set("realms_paused", true, false)
    end
    return true
end

local function restore_realms(quiet)
    if not mod:get("realms_paused") then
        return
    end
    local realms = realms_mod()
    if realms then
        realms:set("enable_server", true, true)
    end
    mod:set("realms_paused", false, false)
    if not quiet then
        mod:echo("[Factory] Realms server switched back on.")
    end
end

local factory_session = false -- current mission is the single-player one we paused Realms for

-- ---------------------------------------------------------------------------------------------------- units
-- spawned straight into the level world (unit_spawner.spawn_unit is World.spawn_unit_ex too,
-- unit_spawner_manager.lua:454) and destroyed straight from it on exit (v0.1 CTD, note 46)
local function despawn_all()
    for _, unit in ipairs(units) do
        if unit_ok(unit) then
            local world = Unit.world(unit)
            if world then
                World.destroy_unit(world, unit)
            end
        end
    end
    units, unit_set, spawn_queue, base_box = {}, {}, nil, nil
end

local function release_all()
    if custom_assets and custom_assets.release then
        for _, t in pairs(chunk_tickets) do
            custom_assets.release(t)
        end
        if lib_ticket then
            custom_assets.release(lib_ticket)
        end
    end
    chunk_tickets, loaded_chunks, lib_ticket, load_state = {}, {}, nil, "idle"
end

local function spawn_point()
    local b = base_box:unbox()
    return b + Vector3(Layout.spawn[1], Layout.spawn[2], Layout.spawn[3] + 0.2)
end

local function clear_fall_speed(player_unit)
    -- the engine teleport only zeroes velocity_wanted (player_movement.lua:40); clear the fall speed too
    local ude = ScriptUnit.has_extension(player_unit, "unit_data_system")
    if ude then
        pcall(function()
            ude:write_component("locomotion").velocity_current = Vector3.zero()
        end)
    end
end

local function teleport_in()
    local player = local_player()
    local player_unit = player and player.player_unit
    if not (unit_ok(player_unit) and base_box) then
        return
    end
    PlayerMovement.teleport(player, spawn_point(), Unit.world_rotation(player_unit, 1))
    clear_fall_speed(player_unit)
end

-- all chunk packages are ready: queue the units and spawn a few per frame (update)
local function start_spawning()
    local player = local_player()
    local player_unit = player and player.player_unit
    local world = Managers.world and Managers.world:world("level_world")
    if not (unit_ok(player_unit) and world) then
        say("no player unit or level world yet")
        return
    end
    local here = Unit.world_position(player_unit, 1)
    if #units > 0 and base_box then
        if not return_pos then
            return_pos = Vector3Box(here)
        end
        teleport_in()
        say("back in Factory. /factory back to return")
        return
    end
    if not return_pos then
        return_pos = Vector3Box(here)
    end
    local height = mod:get("spawn_height") or 300
    base_box = Vector3Box(Vector3(Vector3.x(here), Vector3.y(here), Vector3.z(here) + height))
    spawn_queue = {}
    for _, row in ipairs(Layout.chunks) do
        if loaded_chunks[row[1]] then
            spawn_queue[#spawn_queue + 1] = row
        end
    end
    say("building Factory: %d chunks", #spawn_queue)
end

local function load_map()
    custom_assets = custom_assets or get_mod("CustomAssets")
    if not custom_assets or not custom_assets.is_api_compatible or not custom_assets.is_api_compatible(1) then
        say("Custom Assets (API 1) is missing")
        return
    end
    load_state = "loading"
    local pending = #Layout.chunks
    local failed = 0
    local function chunk_done()
        pending = pending - 1
        if pending == 0 then
            load_state = "ready"
            if failed > 0 then
                say("%d chunk(s) failed to load (run CUSTOM_ASSETS_PATCH.bat with the game closed)", failed)
            end
            if soloplay_only() then
                start_spawning()
            end
        end
    end
    local t, err = custom_assets.acquire(mod, LIB_ID, function(_, _, load_error)
        if load_error then
            load_state = "idle"
            say("%s failed to load: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", LIB_ID, tostring(load_error))
            return
        end
        -- chunks reference the library's materials, so they are requested after it
        for _, row in ipairs(Layout.chunks) do
            local name = row[1]
            local id = "QIangIQsFactory:" .. name
            local ct, cerr = custom_assets.acquire(mod, id, function(_, _, chunk_error)
                if chunk_error then
                    failed = failed + 1
                else
                    loaded_chunks[name] = true
                end
                chunk_done()
            end, { reference_name = id })
            if ct then
                chunk_tickets[name] = ct
            else
                failed = failed + 1
                mod:info("%s could not be requested: %s", id, tostring(cerr))
                chunk_done()
            end
        end
    end, { reference_name = LIB_ID })
    if not t then
        load_state = "idle"
        say("%s could not be requested: %s", LIB_ID, tostring(err))
        return
    end
    lib_ticket = t
    say("loading Factory (151 packages)...")
end

local function request_enter()
    local ok, why = soloplay_only()
    if not ok then
        if why == "realms" then
            if pause_realms() then
                say("this mission is hosted by Realms. Realms server is now OFF until your next SoloPlay mission ends: " ..
                    "leave, start the mission again through SoloPlay, then /factory. (/factory realms turns it back on now)")
            else
                say("this mission is hosted by Realms; turn off its server in Realms' mod options")
            end
        else
            say("SoloPlay only: %s", why)
        end
        return
    end
    if load_state == "ready" then
        start_spawning()
    elseif load_state == "loading" then
        say("still loading...")
    else
        load_map()
    end
end

local function go_back()
    local player = local_player()
    local player_unit = player and player.player_unit
    if return_pos and unit_ok(player_unit) then
        PlayerMovement.teleport(player, return_pos:unbox(), Unit.world_rotation(player_unit, 1))
        clear_fall_speed(player_unit)
        say("back")
    end
    return_pos = nil
    if not mod:get("keep_room") then
        despawn_all()
    end
end

local function debug()
    local ok, why = soloplay_only()
    local session = Managers.multiplayer_session
    say("gate: %s%s | host type: %s | mission: %s", tostring(ok), why and (" (" .. why .. ")") or "",
        session and tostring(session:host_type()) or "none", tostring(current_mission()))
    local n_loaded = 0
    for _ in pairs(loaded_chunks) do
        n_loaded = n_loaded + 1
    end
    say("load state: %s, chunks loaded %d / %d, spawned %d, queued %d", load_state, n_loaded, #Layout.chunks,
        #units, spawn_queue and #spawn_queue or 0)
    if base_box and #units > 0 then
        local world = Unit.world(units[1])
        local pw = world and World.physics_world(world)
        local from = spawn_point() + Vector3(0, 0, 1.3)
        local dirs = { down = Vector3(0, 0, -1), up = Vector3(0, 0, 1), fwd = Vector3(0, 1, 0), back = Vector3(0, -1, 0),
            left = Vector3(-1, 0, 0), right = Vector3(1, 0, 0) }
        local parts = {}
        for _, name in ipairs({ "down", "up", "fwd", "back", "left", "right" }) do
            local rok, hit, _, dist, _, actor = pcall(PhysicsWorld.raycast, pw, from, dirs[name], 40, "closest",
                "collision_filter", "filter_player_mover")
            if not rok then
                parts[#parts + 1] = name .. "=err"
            elseif hit then
                local mine = actor and unit_set[Actor.unit(actor)]
                parts[#parts + 1] = string.format("%s=%.1f%s", name, dist or -1, mine and "(factory)" or "(other)")
            else
                parts[#parts + 1] = name .. "=none"
            end
        end
        say("mover probe at spawn: %s", table.concat(parts, " "))
    end
end

-- ---------------------------------------------------------------------------------------------------- per frame
local rescue_t = 0
mod.update = function(dt)
    -- spawn queued chunks a few per frame, then put the player in
    if spawn_queue then
        local world = Managers.world and Managers.world:world("level_world")
        if world and base_box then
            local base = base_box:unbox()
            for _ = 1, SPAWNS_PER_FRAME do
                local row = table.remove(spawn_queue)
                if not row then
                    break
                end
                local unit = World.spawn_unit_ex(world, UNIT_PREFIX .. row[1], nil, base + Vector3(row[2], row[3], 0),
                    Quaternion.identity())
                if unit then
                    units[#units + 1] = unit
                    unit_set[unit] = true
                end
            end
            if #spawn_queue == 0 then
                spawn_queue = nil
                teleport_in()
                say("Factory ready (%d chunks). /factory back to return", #units)
            end
        end
        return
    end
    -- automatic entry in the Factory mission
    if auto_enter then
        local player = local_player()
        if player and unit_ok(player.player_unit) then
            auto_enter = auto_enter - dt
            if auto_enter <= 0 then
                auto_enter = nil
                request_enter()
            end
        end
    end
    -- catch the player if they drop out of the map
    if not (return_pos and base_box and #units > 0) then
        return
    end
    rescue_t = rescue_t + dt
    if rescue_t < 0.25 then
        return
    end
    rescue_t = 0
    local player = local_player()
    local player_unit = player and player.player_unit
    if not unit_ok(player_unit) then
        return
    end
    local pz = Vector3.z(Unit.world_position(player_unit, 1))
    if pz < Vector3.z(base_box:unbox()) - RESCUE_BELOW then
        teleport_in()
        say("caught you falling; back in the main hall")
    end
end

mod:command("factory", mod:localize("cmd_desc"), function(arg)
    if arg == "back" then
        go_back()
    elseif arg == "debug" then
        debug()
    elseif arg == "realms" then
        if mod:get("realms_paused") then
            restore_realms(false)
        else
            say("Realms server was not paused by Factory")
        end
    else
        request_enter()
    end
end)

mod.on_game_state_changed = function(status, state_name)
    if state_name == "StateGameplay" and status == "exit" then
        -- the level world is torn down after this (and the render thread lags further): destroy our units now,
        -- but keep the packages until the next gameplay state, or the engine unloads resources still in use
        despawn_all()
        return_pos, auto_enter = nil, nil
        if lib_ticket or next(chunk_tickets) then
            release_pending = true
        end
        if factory_session then
            factory_session = false
            restore_realms(false)
        end
    elseif state_name == "StateGameplay" and status == "enter" then
        if release_pending then
            release_pending = false
            release_all()
        end
        local session = Managers.multiplayer_session
        local game_mode = Managers.state and Managers.state.game_mode
        local mode = game_mode and game_mode:game_mode_name()
        if mod:get("realms_paused") and session and session:host_type() == HOST_TYPES.singleplay
            and mode ~= "hub" and mode ~= "prologue_hub" and mode ~= "shooting_range" and mode ~= "training_grounds" then
            factory_session = true
        end
        if current_mission() == MISSION_KEY then
            auto_enter = 3 -- seconds after the player unit exists
        end
    end
end

mod.on_all_mods_loaded = function()
    -- the game was closed while Realms was paused: switch it back on
    restore_realms(true)
end

mod.on_disabled = function()
    despawn_all()
end

mod.on_unload = function()
    despawn_all()
    -- no release here: unloading mid-frame is what crashed v0.1; the game frees packages on shutdown
end
