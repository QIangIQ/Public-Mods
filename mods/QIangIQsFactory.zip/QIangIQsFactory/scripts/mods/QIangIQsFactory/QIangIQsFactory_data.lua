local mod = get_mod("QIangIQsFactory")

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = true,
    options = {
        widgets = {
            { setting_id = "spawn_height", type = "numeric", default_value = 300, range = { 50, 1000 }, decimals_number = 0 },
            { setting_id = "keep_room", type = "checkbox", default_value = false },
        },
    },
}
