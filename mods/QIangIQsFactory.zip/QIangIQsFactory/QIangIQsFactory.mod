return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsFactory` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsFactory", {
            mod_script = "QIangIQsFactory/scripts/mods/QIangIQsFactory/QIangIQsFactory",
            mod_data = "QIangIQsFactory/scripts/mods/QIangIQsFactory/QIangIQsFactory_data",
            mod_localization = "QIangIQsFactory/scripts/mods/QIangIQsFactory/QIangIQsFactory_localization",
        })
    end,
    version = "1.0.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" }, -- must load BEFORE SoloPlay so its mission list sees factory_tarkov
    packages = {},
}
