return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsJade` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsJade", {
            mod_script = "QIangIQsJade/scripts/mods/QIangIQsJade/QIangIQsJade",
            mod_data = "QIangIQsJade/scripts/mods/QIangIQsJade/QIangIQsJade_data",
            mod_localization = "QIangIQsJade/scripts/mods/QIangIQsJade/QIangIQsJade_localization",
        })
    end,
    version = "1.0.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
