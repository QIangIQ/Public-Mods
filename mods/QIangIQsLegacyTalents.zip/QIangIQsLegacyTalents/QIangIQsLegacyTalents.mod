return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsLegacyTalents` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsLegacyTalents", {
			mod_script       = "QIangIQsLegacyTalents/scripts/mods/QIangIQsLegacyTalents/QIangIQsLegacyTalents",
			mod_data         = "QIangIQsLegacyTalents/scripts/mods/QIangIQsLegacyTalents/QIangIQsLegacyTalents_data",
			mod_localization = "QIangIQsLegacyTalents/scripts/mods/QIangIQsLegacyTalents/QIangIQsLegacyTalents_localization",
		})
	end,
	packages = {},
}
