# QIangIQsLegacyTalents

Puts older talent trees, talents, abilities, buffs and base stats back on six classes, for Realms play. Every value comes from verbatim copies of files in the Aussiemon/Darktide-Source-Code history, shipped under `scripts/mods/QIangIQsLegacyTalents/legacy/<version>/`. Nothing is hand-written.

| Class | Source version | Commit | Tree version |
|---|---|---|---|
| Veteran | 1.6.1 (12-05-24) | c3b51ce6 | v24 (99 nodes), replaces current v34 |
| Zealot | 1.6.1 | c3b51ce6 | v15 (81 nodes) |
| Psyker | 1.6.1 | c3b51ce6 | v20 (95 nodes) |
| Ogryn | 1.7.1 (03-27-25) | edcd85d1 | v23 (95 nodes) |
| Arbitrator (adamant) | 1.8.0 (06-23-25) | 0765b12c | v17 (88 nodes) |
| Hive Scum (broker) | 1.10.0 (12-02-25) | 622281b0 | v13 (80 nodes) + stimm tree |

**Ogryn:** Nightmares and Visions was released on March 25, 2025. The source history has no 1.7.0 commit, so the mod uses 1.7.1. That is Hotfix #63, released two days after launch.

## Install

1. Copy the `QIangIQsLegacyTalents` folder into `Warhammer 40,000 DARKTIDE/mods/`.
2. Add `QIangIQsLegacyTalents` to `mod_load_order.txt`.
3. Each class has its own toggle in the mod options, and all are on by default. After changing a class toggle, restart the game.

## Where the legacy trees are used

The mod switches between the legacy data and the current game's data when you connect somewhere:

| Where | Trees, talents and stats | Build used |
|---|---|---|
| Fatshark missions (mission servers) | Official | Your official build from the backend |
| Mourning Star | Legacy (setting "Legacy trees in the Mourning Star", on by default) | Your legacy build on this PC |
| Psykhanium, SoloPlay | Legacy | Your legacy build on this PC |
| Realms | Legacy | Each player's legacy build, shared through QIangIQsSyncChannel |

To switch trees in the Mourning Star, open the Operative's talents page and press **Q** (controller: **Y** / **Triangle**), shown as "Switch to official tree" or "Switch to legacy tree" in the bottom bar. The page closes, the game data and your presets switch, the Mourning Star sends your profile again, and the page reopens on the other tree with that tree's build. The button flips the "Legacy trees in the Mourning Star" setting, so the choice is kept, and changing that setting in Mod Options also applies at once. The button is not shown in missions, the Psykhanium or Realms, because there the talent data has to match the host.

## Saving builds

- **Legacy builds are saved on this PC.** Saving a legacy tree in the talent menu stores it in the game's local save file (next to your profile presets) and does not send it to Fatshark. Your official build stays as it was, so live games always have a working build.
- **Presets (and BetterLoadouts) keep two talent sets.** Each preset has an official set and a legacy set. The menu shows the set that matches the tree in use, and saving a preset writes to that set. Presets saved with a legacy tree before this version are recognised by their tree version.
- **Realms Loadout's own talent editor** (`/rl` Talents tab) still works as before and keeps its builds separately.

## Playing on Realms

- **Everyone needs the same setup.** Every player in the session needs this mod, with the same class toggles. The mod adds talent, node and buff names to the game's network lookup tables. If two players have different tables, ids go out of sync. To check, type `/legacy_talents`: it prints a network signature that must match for every player. With all six classes on, the signature is `68857ff2`.
- **Other players' legacy builds are shared through QIangIQsSyncChannel.** Each player publishes the legacy build of the character they are playing, in a compact form (about 90 bytes at most, under Sync Channel's 250-byte limit per value). The host builds each player's profile with the build that player shared, and rebuilds it when the player saves a new one. Realms Loadout is not needed for this. Every player needs QIangIQsSyncChannel and Vox Manifold; without them, the host gives that player an empty legacy tree. Tested in the harness with a stand-in for Sync Channel, not in a real Realms game. Builds reach the host at Vox Manifold's update rate (at most every 2 seconds), so set your build before the mission starts.

## What the mod changes

- **Talent trees.** Layouts are replaced with the legacy ones, including node costs and ability slots.
- **Talents.** Legacy talents are merged into the class talent list. Current talents are kept, so the other classes still work.
- **Talent settings** (the numbers behind each talent): legacy values are written over current values.
- **Abilities** (combat ability, blitz and aura entries): legacy values are written over the current entries. Current Darktide charges ability cooldowns through a resource system. Where the legacy cost was the cooldown, the mod sets the cost to the legacy cooldown and uses the legacy cooldown scaling.
  - Grenade items: the current game names grenade items with `inventory_item_reference`. The legacy `inventory_item_name` is dropped on those entries (Hive Scum flash grenade, its improved version, Zealot throwing knives), because equipping the item through the old key crashed on spawn.
- **Removed game functions.** Patch 1.13.0 removed the cooldown functions the legacy buffs call. The mod adds them back, each forwarding to the function Fatshark's own code switched to in that patch:

  | Legacy call | Forwards to |
  |---|---|
  | `reduce_ability_cooldown_percentage` | `restore_ability_charge_percentage` |
  | `reduce_ability_cooldown_time` | `restore_ability_resource` |
  | `increase_ability_cooldown_percentage` | `consume_ability_charge_percentage` |
  | `max_ability_cooldown` | `max_regen_time_for_ability_charge` |
  | `get_current_ability_cooldown_time` | `max_regen_time_for_ability_charge("combat_ability")` |
  | `is_cooldown_paused` | `is_ability_resource_regen_paused` |
  | `remaining_ability_cooldown` | `missing_ability_resource_until_next_charge` (inferred) |
  | `companion_unit` | `companion_units()[1]` |
  | `despawn_unit` | `despawn_companion_units` |

  They are only added where the game lacks them, so current game code is unaffected.
- **Buffs.**
  - Class buffs are replaced with the legacy versions.
  - A shared buff that is the same as in the current game uses the current buff.
  - A shared buff that differs is added as a separate copy named `<name>__legacy_<version>`, so other classes keep the current version.
- **Base stats** (toughness, dodge, stamina and others), taken from the legacy archetype files:
  - Veteran: critical chance goes from 0.1 to 0.05. Toughness and stamina change.
  - Zealot: toughness.
  - Psyker: critical chance goes from 0.1 to 0.075.
  - Ogryn: toughness and stamina.
  - Arbitrator: toughness.
  - Hive Scum: toughness and dodge.
- **Damage profiles.** Only profiles that the current game files under the class are changed, in place:

  | Class | Profiles changed |
  |---|---|
  | Zealot | 1 |
  | Psyker | 7 |
  | Arbitrator | 2 |
  | Hive Scum | 5 (2 kept at current values) |
  | Veteran | none |
  | Ogryn | none |

## Renamed in the current game

The mod maps old names to new ones when the legacy files use them. Each mapping is backed by a line in the current source, cited in `class_swap.lua` and `legacy_loader.lua`.

- **Modules:**
  - `scripts/utilities/weapon/action` became `scripts/utilities/action/action`. The `current_action` function is identical.
  - `shout_ability_implementation` became `shout_ability`. It takes the same arguments (`shout_ability.lua:31`).
- **Stats:** `<ability>_cooldown_modifier` stats became `<ability>_resource_cost_per_use_modifier` and `_resource_regen_modifier`.
- **Special rules:** some were renamed. The full list is in `class_swap.lua` (`STAT_BUFF_RENAMES`, `SPECIAL_RULE_RENAMES`).

## Dropped (not in the current game)

None of these were on a legacy tree, so no build loses a node.

- `psyker_blocking_soulblaze`
- Arbitrator's temp and stance_dance talents
- Three Psyker abilities that exist only in the legacy files

A stat, keyword, proc event or buff that the current game no longer has is removed from that talent, and the console log says so. In-game, `/legacy_talents` shows how many were dropped.

## Not restored

- **Weapon and blitz templates.** This covers grenades, the Smite action, throwing knife projectiles and the `broker_stimm_field` weapon template. They use the current versions.
- **Engine-side behavior.** Behavior coded in current action and ability code, rather than in data, stays current.
- **Shared grenade damage profiles.** These stay current.
- **Old English text.** The old text isn't in the source, only its keys, so missing text is generated:
  - Talent names show the developer name from the legacy file.
  - Descriptions show `[<version> talent, no in-game text in the source]` followed by the talent's values.
  - Current text is kept when its placeholders match the legacy values.
- **Some icons.** Tree icons come from the talent menu's package, which only holds what the current trees draw. A legacy icon the current tree of that class doesn't draw is replaced with the icon the current tree uses at the same node (or the most common icon for that node type). 90 icons are replaced this way. The 1.6.1 Zealot node color ramps (64 nodes) are removed for the same reason. Start nodes use the current start frame.

## Testing done

- **How:** in a harness that runs the real current game Lua (LuaJIT) with stubbed engine calls.
- **Checks:**
  - All six classes apply.
  - Every tree node resolves to a talent that is in the network lookup.
  - Every buff uses valid stats, keywords and procs.
  - Abilities have templates and resource costs.
  - Builds pass through the game's own CharacterSheet and select the right abilities.
  - Talent strings pack and unpack correctly.
  - Switching to official data and back restores every changed table exactly (2810 values in 269 tables).
  - A legacy save stays off the backend and is stored locally; profiles built from the official string get the local legacy build; presets swap sets with the mode; mission servers switch to official data.
  - The talents page switch: the page closes before the data flips (so the old tree's nodes are saved to the right preset set), the data, setting and presets flip, the profile is requested again, and the page reopens; the button is hidden outside the Mourning Star, when inspecting, and for classes with no legacy tree.
- **Not tested in game.** The remaining harness errors come from description damage math, which also fails for current talents in the harness.

## Risks

- **Network id limits.** The mod adds 22 talent names, 86 node names and 15 buff names. I don't know whether the network id bit-widths have headroom for these. Inferred, not checked.
- **Mods that change the same class data.** Another mod that edits these classes' buff templates or talent settings may be overwritten, depending on load order.
- **Game updates.** A Darktide patch that changes these tables may break the swap. Errors are reported with a notification and logged to the console.
