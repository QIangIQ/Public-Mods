-- Shares each player's local legacy build through QIangIQsSyncChannel, so a
-- Realms host can build every player's profile with their legacy talents.
--
-- The host builds profiles from the backend (profile_synchronizer_host.lua
-- _profile_changed), where only the official build is. Each player publishes
-- the legacy build for the character they are playing; when the host builds a
-- profile for a character it has a published build for, that build is used.
-- When a player's published build changes, the host rebuilds their profile.
local mod = get_mod("QIangIQsLegacyTalents")

local TalentLayoutParser = require("scripts/ui/views/talent_builder_view/utilities/talent_layout_parser")

local RealmsSync = {}

local CATEGORY = "c" -- Sync Channel "characters"
local KEY = "lt"
local ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"

local S = {
	channel = nil,
	builds = nil, -- LegacyBuilds
	build_archetypes = {},
	is_active = function ()
		return false
	end,
	last_seen = {},
}

-- Compact form of a build: one bit per tree node (6 per character), then
-- ".index:tier" for nodes with more than one point. A Sync Channel value is
-- capped at 250 bytes, which a full talent string can exceed.
local function _encode(layout, packed)
	local selected = {}

	TalentLayoutParser.unpack_backend_data(layout, packed, selected)

	local nodes = layout.nodes
	local chars, extra = {}, {}

	for i = 1, #nodes, 6 do
		local value = 0

		for bit = 0, 5 do
			local node = nodes[i + bit]
			local tier = node and selected[node.widget_name]

			if tier and tier > 0 then
				value = value + 2 ^ bit

				if tier > 1 then
					extra[#extra + 1] = string.format(".%d:%d", i + bit, tier)
				end
			end
		end

		chars[#chars + 1] = string.sub(ALPHABET, value + 1, value + 1)
	end

	return table.concat(chars) .. table.concat(extra)
end

local function _decode(layout, encoded)
	local nodes = layout.nodes
	local selected = {}
	local bits = string.match(encoded, "^([^%.]*)")

	for c = 1, #bits do
		local value = (string.find(ALPHABET, string.sub(bits, c, c), 1, true) or 1) - 1

		for bit = 0, 5 do
			if value % 2 == 1 then
				local node = nodes[(c - 1) * 6 + bit + 1]

				if node then
					selected[node.widget_name] = 1
				end
			end

			value = math.floor(value / 2)
		end
	end

	for index, tier in string.gmatch(encoded, "%.(%d+):(%d+)") do
		local node = nodes[tonumber(index)]

		if node and selected[node.widget_name] then
			selected[node.widget_name] = tonumber(tier)
		end
	end

	return TalentLayoutParser.pack_backend_data(layout, selected)
end

RealmsSync.encode = _encode
RealmsSync.decode = _decode

-- What I publish: the legacy build of the character I am playing.
local function _my_value()
	local player_manager = Managers.player
	local player = player_manager and player_manager:local_player_safe(1)
	local profile = player and player:profile()
	local archetype = profile and profile.archetype
	local archetype_name = type(archetype) == "table" and archetype.name
	local info = archetype_name and S.build_archetypes[archetype_name]
	local character_id = profile and profile.character_id

	if not info or not character_id then
		return nil
	end

	local packed = S.builds.stored(character_id, archetype_name)

	if not packed then
		return nil
	end

	return {
		[KEY] = {
			ch = character_id,
			a = archetype_name,
			v = info.legacy_version,
			b = _encode(info.layout, packed),
		},
	}
end

-- A build another player published for this character, as a talent string.
RealmsSync.remote = function (character_id, archetype_name)
	local channel = S.channel
	local info = S.build_archetypes[archetype_name]

	if not channel or not info or not character_id then
		return nil
	end

	for account_id in pairs(channel.roster()) do
		local data = channel.peer_by_account(account_id, CATEGORY)
		local entry = data and data[KEY]

		if type(entry) == "table" and entry.ch == character_id and entry.a == archetype_name and tonumber(entry.v) == info.legacy_version and type(entry.b) == "string" then
			local ok, packed = pcall(_decode, info.layout, entry.b)

			return ok and packed or nil
		end
	end

	return nil
end

-- Host: rebuild the profile of anyone whose published build changed.
local function _refresh_changed()
	local channel = S.channel
	local connection = Managers.connection

	if not channel or not S.is_active() or not connection or not connection:is_host() then
		return
	end

	local sync_manager = Managers.profile_synchronization
	local synchronizer = sync_manager and sync_manager:synchronizer_host()
	local players = Managers.player and Managers.player:players()

	if not synchronizer or not players then
		return
	end

	for _, player in pairs(players) do
		if player.remote and player.account_id then
			local ok, account_id = pcall(player.account_id, player)
			local data = ok and channel.peer_by_account(account_id, CATEGORY)
			local entry = data and data[KEY]
			local signature = type(entry) == "table" and string.format("%s|%s|%s", tostring(entry.ch), tostring(entry.v), tostring(entry.b)) or ""

			if ok and account_id and S.last_seen[account_id] ~= signature then
				S.last_seen[account_id] = signature

				local same_character = type(entry) == "table" and entry.ch == player:character_id()

				if same_character then
					local refreshed = pcall(synchronizer.profile_changed, synchronizer, player:peer_id(), player:local_player_id())

					if refreshed then
						mod:info("Realms: rebuilt %s's profile with their legacy build", tostring(player:name()))
					end
				end
			end
		end
	end
end

RealmsSync.publish_changed = function ()
	if S.channel then
		S.channel.mark_dirty()
	end
end

RealmsSync.start = function (config)
	S.builds = config.builds
	S.build_archetypes = config.build_archetypes
	S.is_active = config.is_active

	local sync_mod = get_mod("QIangIQsSyncChannel")
	local channel = sync_mod and sync_mod.api

	if not channel or not channel.provide then
		mod:info("QIangIQsSyncChannel not found; legacy builds are not shared in Realms.")

		return false
	end

	S.channel = channel

	channel.provide("QIangIQsLegacyTalents", CATEGORY, _my_value)
	channel.on_change(function ()
		local ok, err = pcall(_refresh_changed)

		if not ok then
			mod:error("Realms legacy build refresh failed: %s", tostring(err))
		end
	end)

	return true
end

RealmsSync.active = function ()
	return S.channel ~= nil
end

return RealmsSync
