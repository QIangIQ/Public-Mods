-- Collects what the swap did and what it could not carry over, so the result
-- can be read in the console log and with the /legacy_talents command.
local mod = get_mod("QIangIQsLegacyTalents")

local LegacyReport = {}

LegacyReport.new = function ()
	local self = setmetatable({
		lines = {},
		missing = {},
		renames = {},
		counts = {},
		errors = {},
		signature = nil,
	}, {
		__index = LegacyReport,
	})

	return self
end

LegacyReport.note_missing = function (self, kind, key)
	local id = kind .. "." .. tostring(key)

	if not self.missing[id] then
		self.missing[id] = true

		mod:info("not in the current game, dropped: %s", id)
	end
end

LegacyReport.note_rename = function (self, kind, from, to)
	local id = kind .. "." .. tostring(from)

	if not self.renames[id] then
		self.renames[id] = to

		mod:info("renamed in the current game: %s -> %s", id, tostring(to))
	end
end

LegacyReport.count = function (self, key, amount)
	self.counts[key] = (self.counts[key] or 0) + (amount or 1)
end

LegacyReport.line = function (self, fmt, ...)
	local text = string.format(fmt, ...)

	self.lines[#self.lines + 1] = text

	mod:info("%s", text)
end

LegacyReport.error = function (self, fmt, ...)
	local text = string.format(fmt, ...)

	self.errors[#self.errors + 1] = text

	mod:error("%s", text)
end

local function _sorted_keys(t)
	local keys = {}

	for key in pairs(t) do
		keys[#keys + 1] = key
	end

	table.sort(keys)

	return keys
end

LegacyReport.summary = function (self)
	local out = {}

	for _, text in ipairs(self.lines) do
		out[#out + 1] = text
	end

	local missing = _sorted_keys(self.missing)

	if #missing > 0 then
		out[#out + 1] = string.format("Dropped (not in the current game): %d. See the console log for the list.", #missing)
	end

	if #self.errors > 0 then
		out[#out + 1] = string.format("Errors: %d. See the console log.", #self.errors)
	end

	if self.signature then
		out[#out + 1] = "Network signature: " .. self.signature .. " (must match on every player)"
	end

	return out
end

return LegacyReport
