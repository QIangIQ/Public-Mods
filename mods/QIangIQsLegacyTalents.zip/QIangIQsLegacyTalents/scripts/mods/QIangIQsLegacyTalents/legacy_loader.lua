-- Loads verbatim copies of older Darktide source files (shipped in this mod's
-- legacy/<version>/ folder) inside a private environment.
--
-- A legacy file's require() resolves in this order:
--   1. an override (aggregators and settings that must come from the current game)
--   2. a module this version ships (loaded from legacy/<version>/)
--   3. a module the current game renamed (MODULE_RENAMES, each backed by the current source)
--   4. the current game's module
local mod = get_mod("QIangIQsLegacyTalents")

local LegacyLoader = {}

local MOD_ROOT = "QIangIQsLegacyTalents/scripts/mods/QIangIQsLegacyTalents/legacy/"

-- Module paths that moved between the legacy versions and the current source.
-- scripts/utilities/weapon/action: 1.6.1 Action.current_action is identical to the
--   current scripts/utilities/action/action.lua Action.current_action.
-- shout_ability_implementation: the current ShoutAbility.execute takes the same
--   arguments (scripts/extension_systems/ability/utilities/shout_ability.lua:31).
LegacyLoader.MODULE_RENAMES = {
	["scripts/utilities/weapon/action"] = "scripts/utilities/action/action",
	["scripts/extension_systems/ability/utilities/shout_ability_implementation"] = "scripts/extension_systems/ability/utilities/shout_ability",
}

LegacyLoader.MISSING_PREFIX = "__QLT_MISSING__:"

local function _strip_bom(text)
	if string.sub(text, 1, 3) == "\239\187\191" then
		return string.sub(text, 4)
	end

	return text
end

LegacyLoader.is_missing_marker = function (value)
	return type(value) == "string" and string.sub(value, 1, #LegacyLoader.MISSING_PREFIX) == LegacyLoader.MISSING_PREFIX
end

-- A read-only view of a strict table.enum that resolves renamed entries and
-- returns a marker string instead of erroring on entries the current game removed.
-- Markers are stripped from talents and buffs after loading.
LegacyLoader.lenient_enum = function (real, renames, kind, report)
	return setmetatable({}, {
		__index = function (_, key)
			local value = rawget(real, key)

			if value ~= nil then
				return value
			end

			local renamed = renames and renames[key]

			if renamed and rawget(real, renamed) ~= nil then
				report:note_rename(kind, key, renamed)

				return rawget(real, renamed)
			end

			report:note_missing(kind, key)

			return LegacyLoader.MISSING_PREFIX .. kind .. "." .. tostring(key)
		end,
		__newindex = function ()
			error("legacy enum view is read-only")
		end,
	})
end

-- A view of a settings module where only the named enum subtables are lenient.
LegacyLoader.lenient_settings = function (real, enum_specs, report)
	local views = {}

	for field, spec in pairs(enum_specs) do
		views[field] = LegacyLoader.lenient_enum(real[field], spec.renames, spec.kind, report)
	end

	return setmetatable({}, {
		__index = function (_, key)
			local view = views[key]

			if view then
				return view
			end

			return real[key]
		end,
	})
end

LegacyLoader.new = function (version, legacy_modules, overrides, report)
	local self = {
		version = version,
		legacy_modules = legacy_modules,
		overrides = overrides,
		report = report,
		cache = {},
	}

	local env

	local function legacy_require(path, ...)
		local override = overrides[path]

		if override then
			return override()
		end

		local cached = self.cache[path]

		if cached ~= nil then
			return cached
		end

		if legacy_modules[path] then
			local result = LegacyLoader._load_file(self, env, path)

			self.cache[path] = result

			return result
		end

		local renamed = LegacyLoader.MODULE_RENAMES[path]

		if renamed then
			report:note_rename("module", path, renamed)

			return require(renamed, ...)
		end

		return require(path, ...)
	end

	-- Globals a legacy file defines stay inside this environment.
	env = setmetatable({
		require = legacy_require,
	}, {
		__index = _G,
	})

	self.env = env
	self.require = legacy_require

	return self
end

LegacyLoader._load_file = function (self, env, path)
	local file_path = MOD_ROOT .. self.version .. "/" .. path
	local text = mod:io_read_content(file_path)

	if type(text) ~= "string" then
		error(string.format("[%s] could not read %s", self.version, file_path))
	end

	text = _strip_bom(text)

	local chunk, compile_error = Mods.lua.loadstring(text, "@legacy/" .. self.version .. "/" .. path .. ".lua")

	if not chunk then
		error(string.format("[%s] could not compile %s: %s", self.version, path, tostring(compile_error)))
	end

	setfenv(chunk, env)

	return chunk()
end

-- Returns the real storage of a table that table.make_unique wrapped.
LegacyLoader.raw_entries = function (t)
	return rawget(t, "__data") or t
end

return LegacyLoader
