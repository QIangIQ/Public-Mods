-- Legacy builds live on this PC; the official build stays on the backend.
--
-- * A save of a legacy tree is kept in the game's own local save file
--   (character save data, the same place profile presets live) and never sent
--   to the backend, so live games keep using the official build.
-- * When a profile is built from backend data while legacy mode is on, the
--   official talent string (a different tree version) is replaced with the
--   local legacy string for that character.
-- * Profile presets (also used by BetterLoadouts) keep two talent sets, one
--   per mode, and show the one that matches the tree in use.
local mod = get_mod("QIangIQsLegacyTalents")

local Promise = require("scripts/foundation/utilities/promise")

local LegacyBuilds = {}

local SAVE_KEY = "qlt_legacy_talents"

-- Filled by the main file: is_active(), build_archetypes[archetype_name] =
-- { legacy_version, vanilla_version, layout }.
local S = {
	is_active = function ()
		return false
	end,
	build_archetypes = {},
	build_layouts = {},
}

LegacyBuilds.setup = function (config)
	S.is_active = config.is_active
	S.build_archetypes = config.build_archetypes
	S.build_layouts = {}

	for archetype_name, info in pairs(config.build_archetypes) do
		S.build_layouts[info.layout] = archetype_name
	end
end

-- #####################################################################
-- Local store
-- #####################################################################

local function _character_entry(character_id, create)
	local save_manager = Managers.save

	if not save_manager or not character_id then
		return nil
	end

	local ok, account_data = pcall(save_manager.account_data, save_manager)
	local characters = ok and account_data and account_data.character_data
	local entry = characters and characters[character_id]

	if not entry and create then
		entry = save_manager:character_data(character_id)
	end

	return entry
end

local function _version_of(packed)
	return type(packed) == "string" and tonumber(string.match(packed, "^(%d+);")) or nil
end

LegacyBuilds.stored = function (character_id, archetype_name)
	local info = S.build_archetypes[archetype_name]
	local entry = _character_entry(character_id, false)
	local builds = entry and entry[SAVE_KEY]
	local packed = type(builds) == "table" and builds[archetype_name]

	if info and type(packed) == "string" and _version_of(packed) == info.legacy_version then
		return packed
	end

	return nil
end

LegacyBuilds.store = function (character_id, archetype_name, packed)
	local entry = _character_entry(character_id, true)

	if not entry then
		return false
	end

	local builds = entry[SAVE_KEY]

	if type(builds) ~= "table" then
		builds = {}
		entry[SAVE_KEY] = builds
	end

	builds[archetype_name] = packed

	Managers.save:queue_save()
	LegacyBuilds.on_stored()

	return true
end

-- Set by the main file: a build another player shared (Realms, through
-- QIangIQsSyncChannel), and a callback after a local save.
LegacyBuilds.remote = function ()
	return nil
end

LegacyBuilds.on_stored = function ()
	return
end

local function _is_own_character(character_id)
	return _character_entry(character_id, false) ~= nil
end

-- #####################################################################
-- Saving: keep legacy strings off the backend
-- #####################################################################

local _notified_save = false

local function _install_backend_hook()
	mod:hook_require("scripts/backend/characters", function (Characters)
		mod:hook(Characters, "set_talents_v2", function (func, self, character_id, talent_info, specialization_talent_info)
			if S.is_active() and talent_info and talent_info.packed_talents then
				local archetype_name = talent_info.layout and S.build_layouts[talent_info.layout]

				if archetype_name then
					LegacyBuilds.store(character_id, archetype_name, talent_info.packed_talents)

					talent_info = nil

					if not _notified_save then
						_notified_save = true

						mod:notify(mod:localize("legacy_build_saved"))
					end

					if not specialization_talent_info then
						return Promise.resolved(nil)
					end
				end
			end

			return func(self, character_id, talent_info, specialization_talent_info)
		end)
	end)
end

-- #####################################################################
-- Loading: swap in the local legacy string
-- #####################################################################

local _context_character_id = nil

local function _with_character(func, character, ...)
	local previous = _context_character_id

	_context_character_id = type(character) == "table" and character.id or false

	local results = {
		pcall(func, ...),
	}
	local n = table.maxn(results)

	_context_character_id = previous

	if not results[1] then
		error(results[2], 0)
	end

	return unpack(results, 2, n)
end

local TalentLayoutParser

local function _rebuild_profile_talents(profile)
	local archetype = profile.archetype

	if type(archetype) ~= "table" then
		return
	end

	local info = S.build_archetypes[archetype.name]

	if not info then
		return
	end

	local PlayerTalents = require("scripts/utilities/player_talents/player_talents")
	local old_nodes = profile.selected_nodes or {}
	local selected_nodes = {}
	local talents = {}

	-- Same steps as _fill_talents_and_selected_nodes in profile_utils.lua.
	for _, key in ipairs({ "talent_layout_file_path", "specialization_talent_layout_file_path" }) do
		local path = archetype[key]

		if path then
			local layout = require(path)

			if S.build_layouts[layout] then
				TalentLayoutParser.unpack_backend_data(layout, LegacyBuilds.stored(profile.character_id, archetype.name) or "", selected_nodes)
			else
				for _, node in ipairs(layout.nodes) do
					local tier = old_nodes[node.widget_name]

					if tier then
						selected_nodes[node.widget_name] = tier
					end
				end
			end

			TalentLayoutParser.selected_talents_from_selected_nodes(layout, selected_nodes, talents)
		end
	end

	PlayerTalents.add_archetype_base_talents(archetype, talents)

	local active_layouts = TalentLayoutParser.archetype_layouts(archetype)

	TalentLayoutParser.validate_talent_layouts(talents, active_layouts, false)

	profile.selected_nodes = selected_nodes
	profile.talents = talents
end

local function _install_load_hooks()
	TalentLayoutParser = require("scripts/ui/views/talent_builder_view/utilities/talent_layout_parser")

	mod:hook(TalentLayoutParser, "unpack_backend_data", function (func, talent_layout, backend_data, selected_nodes)
		if S.is_active() and type(backend_data) == "string" and backend_data ~= "" then
			local archetype_name = S.build_layouts[talent_layout]

			if archetype_name and _version_of(backend_data) ~= talent_layout.version then
				-- An official string does not fit the legacy tree.
				backend_data = _context_character_id and (LegacyBuilds.stored(_context_character_id, archetype_name) or LegacyBuilds.remote(_context_character_id, archetype_name)) or ""
			end
		end

		return func(talent_layout, backend_data, selected_nodes)
	end)

	local ProfileUtils = require("scripts/utilities/profile_utils")

	mod:hook(ProfileUtils, "backend_profile_data_to_profile", function (func, backend_profile_data)
		return _with_character(func, backend_profile_data and backend_profile_data.character, backend_profile_data)
	end)

	mod:hook(ProfileUtils, "pack_backend_profile_data", function (func, backend_profile_data)
		return _with_character(func, backend_profile_data and backend_profile_data.character, backend_profile_data)
	end)

	mod:hook(ProfileUtils, "character_to_profile", function (func, character, ...)
		return _with_character(func, character, character, ...)
	end)

	-- Fatshark's hub server builds profiles from the official string. Your own
	-- characters get the local legacy build back.
	mod:hook(ProfileUtils, "unpack_profile", function (func, profile_json)
		local profile = func(profile_json)

		if S.is_active() and type(profile) == "table" and LegacyBuilds.server_builds_official() and _is_own_character(profile.character_id) and not profile.tamm_custom_talents then
			local ok, err = pcall(_rebuild_profile_talents, profile)

			if not ok then
				mod:error("Could not restore the legacy build: %s", tostring(err))
			end
		end

		return profile
	end)
end

-- Set by the main file: true while connected to a Fatshark server.
LegacyBuilds.server_builds_official = function ()
	return false
end

-- #####################################################################
-- Profile presets (BetterLoadouts uses these too)
-- #####################################################################

local function _local_archetype_name()
	local player_manager = Managers.player
	local player = player_manager and player_manager:local_player_safe(1)
	local profile = player and player:profile()
	local archetype = profile and profile.archetype

	return type(archetype) == "table" and archetype.name or nil
end

local function _preset_main_version(preset)
	local version = preset.talents_version

	return version ~= nil and tonumber(string.match(tostring(version), "^(%d+)")) or nil
end

-- Returns true if the preset was changed.
local function _swap_preset(preset, target, info)
	if type(preset) ~= "table" then
		return false
	end

	local current = preset.qlt_mode

	if current == nil then
		-- Presets made before this version: the tree version tells which set it is.
		current = info and _preset_main_version(preset) == info.legacy_version and "legacy" or "official"
		preset.qlt_mode = current
	end

	if current == target then
		return false
	end

	local stash = type(preset.qlt_sets) == "table" and preset.qlt_sets or {}

	stash[current] = {
		talents = preset.talents,
		talents_version = preset.talents_version,
	}

	local other = stash[target]

	preset.talents = other and other.talents or {}
	preset.talents_version = other and other.talents_version or nil
	stash[target] = nil
	preset.qlt_sets = stash
	preset.qlt_mode = target

	return true
end

local function _preset_target()
	local archetype_name = _local_archetype_name()
	local info = archetype_name and S.build_archetypes[archetype_name]

	if not info then
		return nil
	end

	return S.is_active() and "legacy" or "official", info
end

local function _swap_presets(presets)
	local target, info = _preset_target()

	if not target or type(presets) ~= "table" then
		return
	end

	local changed = false

	for i = 1, #presets do
		changed = _swap_preset(presets[i], target, info) or changed
	end

	if changed and Managers.save then
		Managers.save:queue_save()
	end
end

local function _install_preset_hooks()
	local ProfileUtils = require("scripts/utilities/profile_utils")

	mod:hook(ProfileUtils, "get_profile_preset", function (func, profile_preset_id)
		local preset = func(profile_preset_id)
		local target, info = _preset_target()

		if target and _swap_preset(preset, target, info) and Managers.save then
			Managers.save:queue_save()
		end

		return preset
	end)

	mod:hook(ProfileUtils, "get_profile_presets", function (func)
		local presets = func()

		_swap_presets(presets)

		return presets
	end)
end

-- Brings the local character's presets in line right after a mode switch.
LegacyBuilds.refresh_presets = function ()
	local ok, ProfileUtils = pcall(require, "scripts/utilities/profile_utils")

	if ok and ProfileUtils and Managers.player and Managers.save then
		pcall(ProfileUtils.get_profile_presets)
	end
end

LegacyBuilds.install = function ()
	_install_backend_hook()
	_install_load_hooks()
	_install_preset_hooks()
end

return LegacyBuilds
