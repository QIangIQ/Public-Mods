-- Replaces a class's talent tree, talents, talent buffs, ability numbers,
-- talent settings and base archetype stats with the ones from an older source
-- version. Runs once while the mod loads; changing the settings needs a restart.
local mod = get_mod("QIangIQsLegacyTalents")
local MOD_DIR = "QIangIQsLegacyTalents/scripts/mods/QIangIQsLegacyTalents/"
local LegacyLoader = mod:io_dofile(MOD_DIR .. "legacy_loader")
local LegacyManifest = mod:io_dofile(MOD_DIR .. "legacy_manifest")

local ArchetypeTalents = require("scripts/settings/ability/archetype_talents/archetype_talents")
local Archetypes = require("scripts/settings/archetype/archetypes")
local BuffSettings = require("scripts/settings/buff/buff_settings")
local BuffTemplates = require("scripts/settings/buff/buff_templates")
local DamageProfileTemplates = require("scripts/settings/damage/damage_profile_templates")
local NodeLayout = require("scripts/ui/views/node_builder_view_base/utilities/node_layout")
local PlayerAbilities = require("scripts/settings/ability/player_abilities/player_abilities")
local SpecialRulesSettings = require("scripts/settings/ability/special_rules_settings")
local TalentSettings = require("scripts/settings/talent/talent_settings")

local ClassSwap = {}

-- Stat buffs the current game renamed. Each pair is backed by the current source:
-- * combat_ability_cooldown_modifier: veteran_combat_ability_extra_charge (0.33) and
--   veteran_combat_ability_revive_nearby_allies (0.5) now use
--   combat_ability_resource_cost_per_use_modifier with the same values.
-- * ability_cooldown_modifier: psyker_aura_ability_cooldown now uses
--   combat_ability_resource_cost_per_use_modifier with the same talent setting. In
--   1.6.1 this stat only changed combat ability cooldowns
--   (player_unit_ability_extension.lua:708-722 at c3b51ce6).
-- * grenade_ability_cooldown_modifier: same cooldown formula in 1.6.1; the current
--   game derives a charge's cost from the old cooldown (resource_cost_per_charge =
--   cooldown, resource_regen_per_second = 1), so scaling the cost per use by the
--   same value gives the same recharge time.
-- * combat_ability_cooldown_regen_modifier: 1.10.0 used it as the combat ability
--   recharge rate; the current broker buffs of the same name use
--   combat_ability_resource_regen_modifier.
ClassSwap.STAT_BUFF_RENAMES = {
	ability_cooldown_modifier = "combat_ability_resource_cost_per_use_modifier",
	combat_ability_cooldown_modifier = "combat_ability_resource_cost_per_use_modifier",
	grenade_ability_cooldown_modifier = "grenade_ability_resource_cost_per_use_modifier",
	combat_ability_cooldown_regen_modifier = "combat_ability_resource_regen_modifier",
}

-- Special rules the current game renamed:
-- * enable_quick_throw_grenades: checked in 1.6.1 base_template_settings.lua:28 and
--   player_unit_ability_extension.lua:571; the same checks now use
--   zealot_throwing_knives (base_template_settings.lua:121,
--   player_unit_ability_extension.lua:583).
-- * adamant_hack_to_allow_grenades: the same adamant talents now list
--   hack_to_allow_grenades (adamant_talents.lua:398-499).
ClassSwap.SPECIAL_RULE_RENAMES = {
	enable_quick_throw_grenades = "zealot_throwing_knives",
	adamant_hack_to_allow_grenades = "hack_to_allow_grenades",
}

-- ability_type in the legacy talents -> target slot name in the current game
-- (current base_talents use these slot names, e.g. broker_archetype.lua:72-76).
local SLOT_BY_ABILITY_TYPE = {
	combat_ability = "slot_combat_ability",
	grenade_ability = "slot_grenade_ability",
	pocketable_ability = "slot_pocketable_small",
}

-- Numeric archetype fields that are menu data, not stats.
local ARCHETYPE_SKIPPED_FIELDS = {
	ui_selection_order = true,
}

local ARCHETYPE_TEMPLATE_FIELDS = {
	"toughness",
	"dodge",
	"sprint",
	"stamina",
	"warp_charge",
}

-- #####################################################################
-- Table helpers
-- #####################################################################

local function _is_array(t)
	return type(t) == "table" and (#t > 0 or next(t) == nil)
end

local function _deep_clone(value, seen)
	if type(value) ~= "table" then
		return value
	end

	seen = seen or {}

	if seen[value] then
		return seen[value]
	end

	local copy = {}

	seen[value] = copy

	for k, v in pairs(value) do
		copy[_deep_clone(k, seen)] = _deep_clone(v, seen)
	end

	return setmetatable(copy, getmetatable(value))
end

-- Legacy values win; keys only the current game has are kept. Lists are
-- replaced whole, since a merged list would mix two versions.
local function _overlay(dst, src)
	for k, v in pairs(src) do
		local current = dst[k]

		if type(v) == "table" and type(current) == "table" and not _is_array(v) and not _is_array(current) then
			_overlay(current, v)
		else
			dst[k] = _deep_clone(v)
		end
	end

	return dst
end

-- Compares data only. Two functions count as equal, since legacy code is
-- never the same closure as the current game's.
local function _same_data(a, b, depth)
	depth = depth or 0

	if depth > 12 then
		return true
	end

	local ta, tb = type(a), type(b)

	if ta ~= tb then
		return false
	end

	if ta == "function" then
		return true
	end

	if ta ~= "table" then
		return a == b
	end

	for k, v in pairs(a) do
		if k ~= "name" and not _same_data(v, b[k], depth + 1) then
			return false
		end
	end

	for k, v in pairs(b) do
		if k ~= "name" and a[k] == nil and k ~= "predicted" and k ~= "icon" and k ~= "buff_category" then
			return false
		end
	end

	return true
end

local function _sorted_keys(t)
	local keys = {}

	for k in pairs(t) do
		keys[#keys + 1] = k
	end

	table.sort(keys, function (a, b)
		return tostring(a) < tostring(b)
	end)

	return keys
end

-- Removes marker keys and marker list entries left by the lenient enums.
local function _strip_markers(t, seen)
	if type(t) ~= "table" then
		return 0
	end

	seen = seen or {}

	if seen[t] then
		return 0
	end

	seen[t] = true

	local removed = 0

	for k, v in pairs(t) do
		if LegacyLoader.is_missing_marker(k) then
			t[k] = nil
			removed = removed + 1
		elseif type(v) == "table" then
			removed = removed + _strip_markers(v, seen)
		end
	end

	if #t > 0 then
		for i = #t, 1, -1 do
			if LegacyLoader.is_missing_marker(t[i]) then
				table.remove(t, i)
				removed = removed + 1
			end
		end
	end

	return removed
end

-- #####################################################################
-- Icons: a legacy icon is only used when the current game still uses
-- the same path somewhere, because a texture that no longer ships could
-- break the menus.
-- #####################################################################

local function _collect_icons(value, out, seen, depth)
	if depth > 8 then
		return
	end

	local tv = type(value)

	if tv == "string" then
		if string.sub(value, 1, 11) == "content/ui/" then
			out[value] = true
		end

		return
	end

	if tv ~= "table" or seen[value] then
		return
	end

	seen[value] = true

	for k, v in pairs(value) do
		_collect_icons(v, out, seen, depth + 1)
	end
end

ClassSwap.collect_known_icons = function ()
	local known = {}
	local seen = {}

	_collect_icons(ArchetypeTalents, known, seen, 0)
	_collect_icons(BuffTemplates, known, seen, 0)
	_collect_icons(PlayerAbilities, known, seen, 0)

	for _, archetype in pairs(Archetypes) do
		_collect_icons(archetype, known, seen, 0)

		for _, field in ipairs({ "talent_layout_file_path", "specialization_talent_layout_file_path" }) do
			local path = archetype[field]

			if path then
				local ok, layout = pcall(require, path)

				if ok then
					_collect_icons(layout, known, seen, 0)
				end
			end
		end
	end

	return known
end

-- Talent tree icons are drawn from the talent view's package, which only
-- holds what the current trees use. Tree icons are therefore only kept when
-- the current tree of the same class draws them; anything else takes the
-- icon the current tree uses in the same place. NodeLayout.fallback_icon()
-- is not in that package, so it is never used.
local function _add_icon(set, icon)
	if type(icon) == "string" then
		set[icon] = true
	end
end

local function _layout_profile(layout)
	local profile = {
		by_widget = {},
		by_type = {},
		start_icon = nil,
		any_icon = nil,
	}
	local type_counts = {}

	for _, node in ipairs(layout.nodes or {}) do
		local icon = node.icon

		if type(icon) == "string" then
			profile.by_widget[node.widget_name] = node

			if node.type == "start" then
				profile.start_icon = profile.start_icon or icon
			else
				profile.any_icon = profile.any_icon or icon

				local counts = type_counts[node.type] or {}

				type_counts[node.type] = counts
				counts[icon] = (counts[icon] or 0) + 1
			end
		end
	end

	for node_type, counts in pairs(type_counts) do
		local best, best_count = nil, -1

		for _, icon in ipairs(_sorted_keys(counts)) do
			if counts[icon] > best_count then
				best, best_count = icon, counts[icon]
			end
		end

		profile.by_type[node_type] = best
	end

	return profile
end

-- What the current talent view draws for this class, taken before the swap.
local function _class_view(class_entry, files)
	local archetype = Archetypes[class_entry.archetype]
	local talents = ArchetypeTalents[class_entry.archetype]
	local view = {
		icons = {},
		talents = {},
		slot_icons = {},
		profiles = {},
	}
	local used_talents = {}

	for _, path in ipairs({ files.layout, files.specialization_layout }) do
		local layout = require(path)

		view.profiles[path] = _layout_profile(layout)

		for _, node in ipairs(layout.nodes or {}) do
			_add_icon(view.icons, node.icon)
			_add_icon(view.icons, node.gradient_color)

			if node.talent then
				used_talents[node.talent] = true
			end
		end
	end

	for name in pairs(archetype.base_talents or {}) do
		used_talents[name] = true
	end

	for name in pairs(used_talents) do
		local talent = rawget(talents, name)

		if type(talent) == "table" then
			_add_icon(view.icons, talent.icon)
			_add_icon(view.icons, talent.large_icon)

			view.talents[name] = {
				icon = talent.icon,
				large_icon = talent.large_icon,
			}

			local player_ability = talent.player_ability
			local slot = type(player_ability) == "table" and SLOT_BY_ABILITY_TYPE[player_ability.ability_type]

			if slot and archetype.base_talents and archetype.base_talents[name] then
				view.slot_icons[slot] = view.slot_icons[slot] or {
					icon = talent.icon,
					large_icon = talent.large_icon,
				}
			end
		end
	end

	return view
end

local function _view_icon(ctx, view, icon, fallback)
	if icon == nil or view.icons[icon] then
		return icon, false
	end

	ctx.report:count("icons_replaced")
	mod:info("icon not drawn by the current talent tree, replaced: %s -> %s", tostring(icon), tostring(fallback))

	return fallback, true
end

local function _safe_icon(ctx, icon, fallback)
	if icon == nil or ctx.known_icons[icon] then
		return icon
	end

	ctx.report:count("icons_replaced")
	mod:info("icon not used by the current game, replaced: %s", tostring(icon))

	return fallback
end

-- #####################################################################
-- Steps
-- #####################################################################

-- Settings whose entries are replaced whole instead of merged. The 1.10.0
-- syringe buff (broker_buff_templates.lua start_func) looks up every
-- broker_stimm buff_data.buff_target in its own templates table; a merge kept
-- current-only targets (broker_syringe_slow_and_stun_immune on
-- broker_stimm_celerity_5a, and targets 1.10.0 never set on
-- broker_stimm_durability_1 to _3), which that table does not have.
local WHOLE_ENTRY_SETTINGS = {
	broker_stimm = true,
}

local function _apply_talent_settings(ctx, loader, files)
	local legacy = loader.require(files.talent_settings)
	local applied = 0

	for key, value in pairs(legacy) do
		local current = TalentSettings[key]

		if WHOLE_ENTRY_SETTINGS[key] and type(value) == "table" and type(current) == "table" then
			for entry_name, entry in pairs(value) do
				current[entry_name] = entry
			end
		elseif type(value) == "table" and type(current) == "table" then
			_overlay(current, value)
		else
			TalentSettings[key] = _deep_clone(value)
		end

		applied = applied + 1
	end

	return applied
end

local function _apply_abilities(ctx, loader, files, class_entry)
	local legacy = loader.require(files.abilities)
	local report = ctx.report
	local merged = 0

	for _, name in ipairs(_sorted_keys(legacy)) do
		local legacy_ability = legacy[name]
		local current = PlayerAbilities[name]

		if current == nil then
			-- Not referenced by any legacy talent this mod loads (checked
			-- against the source); kept out so it needs no network id.
			ctx.legacy_only_abilities[name] = legacy_ability
		else
			local old_cooldown = current.cooldown
			local old_cost = current.resource_cost_per_charge
			local old_hud_icon = current.hud_icon
			local had_item_name = current.inventory_item_name ~= nil

			_overlay(current, legacy_ability)

			-- The current game equips grenade items through inventory_item_reference
			-- (e.g. broker_abilities.lua broker_flash_grenade, zealot_abilities.lua
			-- zealot_throwing_knives). _equip_ability still equips anything named in
			-- inventory_item_name, and those items have no weapon template there, so
			-- the legacy key is dropped wherever the current entry uses the reference.
			if not had_item_name and current.inventory_item_reference ~= nil and current.inventory_item_name ~= nil then
				current.inventory_item_name = nil

				ctx.report:count("ability_item_names_dropped")
			end

			current.name = name

			local new_cooldown = legacy_ability.cooldown

			if new_cooldown ~= nil and old_cost ~= nil then
				if _same_data(old_cost, old_cooldown) then
					-- The current game sets resource_cost_per_charge from the same
					-- cooldown setting (e.g. veteran_abilities.lua base_ability), and
					-- regenerates 1 per second, so cost equals the old cooldown.
					current.resource_cost_per_charge = _deep_clone(new_cooldown)

					-- broker_ability_syringe: the current resource_cost_per_charge_lerp_func
					-- is the same code as the current cooldown_lerp_func
					-- (broker_abilities.lua), so the legacy cooldown curve drives both.
					if current.resource_cost_per_charge_lerp_func and legacy_ability.cooldown_lerp_func then
						current.resource_cost_per_charge_lerp_func = legacy_ability.cooldown_lerp_func
					end
				elseif not _same_data(new_cooldown, old_cooldown) then
					report:line("%s: legacy cooldown could not be converted, the current cost is kept", name)
				end
			end

			current.hud_icon = _safe_icon(ctx, current.hud_icon, old_hud_icon)
			merged = merged + 1
		end
	end

	return merged
end

local function _register_buff(ctx, name, template, default_category)
	ctx.report:count("markers_stripped", _strip_markers(template))

	template.name = name
	template.buff_category = template.buff_category or default_category
	template.predicted = not not template.predicted

	if template.hud_icon then
		local current = rawget(BuffTemplates, name)

		template.hud_icon = _safe_icon(ctx, template.hud_icon, current and current.hud_icon)
	end

	if not template.icon then
		template.icon = "content/ui/materials/icons/abilities/default"
	end

	if rawget(BuffTemplates, name) == nil then
		ctx.new_buff_names[name] = true
	end

	BuffTemplates[name] = template

	local predicted_lookup = rawget(BuffTemplates, "PREDICTED")
	local non_predicted_lookup = rawget(BuffTemplates, "NON_PREDICTED")

	if predicted_lookup and non_predicted_lookup then
		if template.predicted then
			predicted_lookup[name] = name
			non_predicted_lookup[name] = nil
		else
			non_predicted_lookup[name] = name
			predicted_lookup[name] = nil
		end
	end
end

local function _apply_class_buffs(ctx, loader, files)
	local templates = LegacyLoader.raw_entries(loader.require(files.class_buffs))
	local count = 0

	for _, name in ipairs(_sorted_keys(templates)) do
		_register_buff(ctx, name, templates[name], BuffSettings.buff_categories.talents)

		count = count + 1
	end

	return templates, count
end

local function _shared_pool(loader, files)
	local pool = {}
	local shared = LegacyLoader.raw_entries(loader.require(files.shared_buffs))

	for name, template in pairs(shared) do
		pool[name] = {
			template = template,
			category = BuffSettings.buff_categories.talents,
		}
	end

	local player = LegacyLoader.raw_entries(loader.require(files.player_buffs))

	for name, template in pairs(player) do
		pool[name] = pool[name] or {
			template = template,
			category = BuffSettings.buff_categories.generic,
		}
	end

	return pool
end

-- Resolves one buff name a legacy talent uses. Returns the name to use, or
-- nil when no version of the buff exists.
local function _resolve_buff(ctx, version_ctx, class_templates, name)
	if class_templates[name] then
		return name
	end

	local resolved = version_ctx.resolved_shared[name]

	if resolved ~= nil then
		return resolved or nil
	end

	local entry = version_ctx.shared_pool[name]
	local current = rawget(BuffTemplates, name)

	if entry then
		ctx.report:count("markers_stripped", _strip_markers(entry.template))

		if current == nil then
			_register_buff(ctx, name, entry.template, entry.category)

			resolved = name
		elseif _same_data(entry.template, current) then
			resolved = name
		else
			-- Shared by every class, so the legacy values get their own name.
			resolved = name .. "__legacy_" .. string.gsub(version_ctx.version, "%.", "_")

			if rawget(BuffTemplates, resolved) == nil then
				_register_buff(ctx, resolved, _deep_clone(entry.template), entry.category)
			end

			ctx.report:count("shared_buffs_versioned")
		end
	elseif current ~= nil then
		ctx.report:count("buffs_from_current_game")

		resolved = name
	else
		ctx.report:note_missing("buff", name)

		resolved = false
	end

	version_ctx.resolved_shared[name] = resolved

	return resolved or nil
end

-- Rewrites buff names in a passive or coherency entry. Identifier and buff
-- name lists are kept in step when an entry has to be dropped.
local function _resolve_buff_entry(ctx, version_ctx, class_templates, entry)
	if type(entry) ~= "table" then
		return entry
	end

	local names = entry.buff_template_name

	if type(names) == "string" then
		local resolved = _resolve_buff(ctx, version_ctx, class_templates, names)

		if not resolved then
			return nil
		end

		entry.buff_template_name = resolved
	elseif type(names) == "table" then
		local identifiers = entry.identifier

		for i = #names, 1, -1 do
			local resolved = _resolve_buff(ctx, version_ctx, class_templates, names[i])

			if resolved then
				names[i] = resolved
			else
				table.remove(names, i)

				if type(identifiers) == "table" then
					table.remove(identifiers, i)
				end
			end
		end

		if #names == 0 then
			return nil
		end
	end

	return entry
end

local function _resolve_format_values(ctx, version_ctx, class_templates, talent)
	local format_values = talent.format_values

	if type(format_values) ~= "table" then
		return
	end

	for _, config in pairs(format_values) do
		local find_value = type(config) == "table" and config.find_value

		if type(find_value) == "table" and find_value.find_value_type == "buff_template" and type(find_value.buff_template_name) == "string" then
			local resolved = _resolve_buff(ctx, version_ctx, class_templates, find_value.buff_template_name)

			if resolved then
				find_value.buff_template_name = resolved
			end
		end
	end
end

local function _sanitize_special_rule(talent)
	local special_rule = talent.special_rule

	if type(special_rule) ~= "table" then
		return
	end

	local names = special_rule.special_rule_name
	local identifiers = special_rule.identifier

	if type(names) == "table" then
		for i = #names, 1, -1 do
			if LegacyLoader.is_missing_marker(names[i]) then
				table.remove(names, i)

				if type(identifiers) == "table" then
					table.remove(identifiers, i)
				end
			end
		end

		if #names == 0 then
			talent.special_rule = nil
		end
	elseif LegacyLoader.is_missing_marker(names) then
		talent.special_rule = nil
	end
end

local function _apply_talents(ctx, version_ctx, loader, files, class_entry, class_templates)
	local base = loader.require(files.base_talents)
	local class_definition = loader.require(files.talents)
	local combined = {}

	-- Same order as that version's archetype_talents.lua: base talents first,
	-- then the class's own talents.
	-- Classes from the same version share one base_talents module, so each
	-- class gets its own copy before icons are set from its tree.
	for name, talent in pairs(base.talents) do
		-- Top-level copy: nested tables such as player_ability keep pointing
		-- at the same ability templates.
		combined[name] = table.shallow_copy(talent)
	end

	for name, talent in pairs(class_definition.talents) do
		combined[name] = talent
	end

	local target = ArchetypeTalents[class_entry.archetype]

	for _, name in ipairs(_sorted_keys(combined)) do
		local talent = combined[name]

		_sanitize_special_rule(talent)

		talent.passive = _resolve_buff_entry(ctx, version_ctx, class_templates, talent.passive)
		talent.coherency = _resolve_buff_entry(ctx, version_ctx, class_templates, talent.coherency)

		_resolve_format_values(ctx, version_ctx, class_templates, talent)

		local view = ctx.view
		local current_icons = view.talents[name]
		local player_ability = talent.player_ability
		local slot = type(player_ability) == "table" and SLOT_BY_ABILITY_TYPE[player_ability.ability_type]
		local slot_icons = slot and view.slot_icons[slot]
		local icon_fallback = current_icons and current_icons.icon or slot_icons and slot_icons.icon or view.default_icon
		local replaced

		talent.icon, replaced = _view_icon(ctx, view, talent.icon, icon_fallback)

		if replaced or talent.icon == nil then
			talent.icon = talent.icon or icon_fallback
			-- The tree node's icon takes over once the layout is in (_adapt_layout).
			ctx.icon_from_node[talent] = true
		end

		talent.large_icon = _view_icon(ctx, view, talent.large_icon, current_icons and current_icons.large_icon or slot_icons and slot_icons.large_icon or nil)
		talent.hud_icon = _safe_icon(ctx, talent.hud_icon, nil)

		local player_ability = talent.player_ability

		if type(player_ability) == "table" and player_ability.ability == nil then
			ctx.report:line("%s: talent %s has no ability in the current game, its ability was dropped", class_entry.archetype, name)

			talent.player_ability = nil
		end

		if rawget(target, name) == nil then
			ctx.new_talent_names[name] = true
		end

		target[name] = talent
		ctx.legacy_talents[class_entry.archetype][name] = talent
	end

	return combined
end

local function _adapt_layout(ctx, class_entry, layout, talents, profile)
	for _, node in ipairs(layout.nodes) do
		-- 1.6.1 counted one point per tier; later layouts store this as cost.
		if node.cost == nil then
			node.cost = node.type == "start" and 0 or 1
		end

		local talent = node.talent and talents[node.talent]

		if node.talent and not talent and node.talent ~= "not_selected" then
			ctx.report:line("%s: node %s uses talent %s, which the legacy files do not define", class_entry.archetype, node.widget_name, node.talent)
		end

		if talent and node.target_slot == nil and type(talent.player_ability) == "table" then
			node.target_slot = SLOT_BY_ABILITY_TYPE[talent.player_ability.ability_type]
		end

		local current_node = profile.by_widget[node.widget_name]
		local fallback

		if node.type == "start" then
			fallback = profile.start_icon
		elseif current_node and current_node.type == node.type then
			fallback = current_node.icon
		else
			fallback = profile.by_type[node.type] or profile.by_type.default or profile.any_icon
		end

		if node.type == "start" and profile.start_icon then
			-- The current start node is a frame material, drawn differently from talent icons.
			node.icon = profile.start_icon
		else
			node.icon = _view_icon(ctx, ctx.view, node.icon, fallback) or fallback
		end

		-- 1.6.1 Zealot nodes carry color ramps the current game never draws.
		if node.gradient_color and not ctx.view.icons[node.gradient_color] then
			ctx.report:count("node_colors_removed")

			node.gradient_color = nil
		end

		if talent and ctx.icon_from_node[talent] and node.type ~= "start" then
			talent.icon = node.icon
		end

		ctx.new_node_names[node.widget_name] = true
	end
end

local function _replace_in_place(current, legacy)
	for key in pairs(current) do
		current[key] = nil
	end

	for key, value in pairs(legacy) do
		current[key] = value
	end
end

local function _apply_layout(ctx, loader, path, class_entry, talents)
	local legacy = loader.require(path)
	local current = require(path)
	local old_version = current.version
	local current_nodes = {}

	for _, node in ipairs(current.nodes or {}) do
		current_nodes[node.widget_name] = node
	end

	-- The current stimm tree stores connector_offset on every node
	-- (broker_stimm_tree.lua), and BrokerStimmBuilderView draws connections
	-- without NodeBuilderViewBase._init_node, which is what fills in the default
	-- { 0, 0 } for the talent tree. The 1.10.0 nodes have none, so the current
	-- node's offset is used, or that same default.
	for _, node in ipairs(legacy.nodes) do
		if node.connector_offset == nil then
			local current_node = current_nodes[node.widget_name]
			local offset = current_node and current_node.connector_offset

			node.connector_offset = type(offset) == "table" and _deep_clone(offset) or {
				0,
				0,
			}
		end
	end

	_adapt_layout(ctx, class_entry, legacy, talents, ctx.view.profiles[path])
	_replace_in_place(current, legacy)

	return old_version, current.version, #current.nodes
end

local function _convert_base_talents(ctx, class_entry, base_talents, talents)
	if type(base_talents) ~= "table" then
		return nil
	end

	local out = {}

	for name, value in pairs(base_talents) do
		local talent = talents[name]

		if not talent then
			ctx.report:line("%s: base talent %s is not defined, dropped", class_entry.archetype, name)
		elseif type(value) == "table" then
			out[name] = value
		else
			local player_ability = talent.player_ability

			out[name] = {
				tier = value,
				target_slot = type(player_ability) == "table" and SLOT_BY_ABILITY_TYPE[player_ability.ability_type] or nil,
			}
		end
	end

	return out
end

local function _apply_archetype(ctx, loader, files, class_entry, talents)
	local legacy = loader.require(files.archetype)
	local current = Archetypes[class_entry.archetype]
	local changed = {}

	for _, key in ipairs(_sorted_keys(legacy)) do
		local value = legacy[key]
		local tv = type(value)

		if (tv == "number" or tv == "boolean") and not ARCHETYPE_SKIPPED_FIELDS[key] and current[key] ~= nil and type(current[key]) == tv and current[key] ~= value then
			changed[#changed + 1] = string.format("%s %s -> %s", key, tostring(current[key]), tostring(value))
			current[key] = value
		end
	end

	for _, field in ipairs(ARCHETYPE_TEMPLATE_FIELDS) do
		if type(legacy[field]) == "table" and type(current[field]) == "table" then
			if not _same_data(legacy[field], current[field]) then
				changed[#changed + 1] = field
			end

			-- A copy, because some templates (e.g. dodge "default") are shared
			-- with classes this mod does not change.
			current[field] = _overlay(_deep_clone(current[field]), legacy[field])
		end
	end

	current.base_talents = _convert_base_talents(ctx, class_entry, legacy.base_talents, talents) or {}
	current.conditional_base_talents = _convert_base_talents(ctx, class_entry, legacy.conditional_base_talents, talents)
	current.conditional_base_talent_funcs = legacy.conditional_base_talent_funcs

	return changed
end

-- #####################################################################
-- Damage profiles
-- #####################################################################

-- Same as create_new in scripts/utilities/weapon_tweaks.lua (identical in
-- 1.6.1 and the current source).
local function _create_from_overrides(base_templates, parent_template_name, template_overrides)
	local new_template = table.clone(base_templates[parent_template_name])

	for i = 1, #template_overrides do
		local overrides_table = template_overrides[i]
		local num_keys = #overrides_table - 1
		local entry = new_template

		for j = 1, num_keys do
			if j < num_keys then
				entry = entry[overrides_table[j]]
			else
				entry[overrides_table[j]] = overrides_table[j + 1]
			end
		end
	end

	return new_template
end

local function _expand_profiles(data, out)
	local base_templates = LegacyLoader.raw_entries(data.base_templates)

	for name, profile in pairs(base_templates) do
		out[name] = profile
	end

	if data.overrides then
		for name, override in pairs(LegacyLoader.raw_entries(data.overrides)) do
			out[name] = _create_from_overrides(base_templates, override.parent_template_name, override.overrides)
		end
	end

	return out
end

local function _legacy_profiles(version_ctx)
	if not version_ctx.legacy_profiles then
		local profiles = {}

		for _, path in ipairs(LegacyManifest.versions[version_ctx.version].damage_profile_files or {}) do
			_expand_profiles(version_ctx.loader.require(path), profiles)
		end

		for name, profile in pairs(profiles) do
			profile.name = name
		end

		version_ctx.legacy_profiles = profiles
	end

	return version_ctx.legacy_profiles
end

-- Only profiles the current game files under this class are changed, so
-- weapons and other classes keep theirs. The current table is updated in place
-- because ability and weapon templates hold direct references to it.
local function _apply_damage_profiles(ctx, version_ctx, files, class_entry)
	local legacy = _legacy_profiles(version_ctx)
	local current_names = _expand_profiles(require(files.current_damage_profiles), {})
	local changed, kept = 0, {}

	for _, name in ipairs(_sorted_keys(current_names)) do
		local legacy_profile = legacy[name]
		local current_profile = rawget(DamageProfileTemplates, name)

		if legacy_profile and current_profile then
			if not _same_data(legacy_profile, current_profile) then
				_overlay(current_profile, legacy_profile)

				current_profile.name = name
				changed = changed + 1
			end

			local buff_name = current_profile.buff_on_damage

			if buff_name and rawget(BuffTemplates, buff_name) == nil then
				ctx.report:note_missing("buff", buff_name)

				current_profile.buff_on_damage = nil
				current_profile.num_buffs_on_damage = nil
			end
		elseif current_profile then
			kept[#kept + 1] = name
		end
	end

	if #kept > 0 then
		mod:info("%s: damage profiles with no legacy version, kept current: %s", class_entry.archetype, table.concat(kept, ", "))
	end

	return changed, #kept
end

-- #####################################################################
-- Network ids
-- #####################################################################

local function _append_lookup(lookup_table, names)
	local added = 0

	for _, name in ipairs(names) do
		if rawget(lookup_table, name) == nil then
			local index = #lookup_table + 1

			rawset(lookup_table, index, name)
			rawset(lookup_table, name, index)

			added = added + 1
		end
	end

	return added
end

local function _hash(text, hash)
	hash = hash or 5381

	for i = 1, #text do
		hash = (hash * 33 + string.byte(text, i)) % 4294967296
	end

	return hash
end

local function _append_network_ids(ctx)
	local NetworkLookup = rawget(_G, "NetworkLookup") or require("scripts/network_lookup/network_lookup")
	local groups = {
		{ "archetype_talent_names", _sorted_keys(ctx.new_talent_names) },
		{ "talent_node_names", _sorted_keys(ctx.new_node_names) },
		{ "buff_templates", _sorted_keys(ctx.new_buff_names) },
	}
	local hash = 5381

	for _, group in ipairs(groups) do
		local lookup_name, names = group[1], group[2]
		local lookup_table = NetworkLookup[lookup_name]

		if lookup_table then
			local added = _append_lookup(lookup_table, names)

			ctx.report:count("network_" .. lookup_name, added)

			for _, name in ipairs(names) do
				hash = _hash(lookup_name .. ":" .. name .. ":" .. tostring(rawget(lookup_table, name)) .. ";", hash)
			end
		else
			ctx.report:error("NetworkLookup.%s is missing", lookup_name)
		end
	end

	ctx.report.signature = string.format("%08x", hash)
end

-- #####################################################################
-- Entry point
-- #####################################################################

local function _overrides(version, version_ctx, report)
	local version_info = LegacyManifest.versions[version]
	local lenient_buff_settings = LegacyLoader.lenient_settings(BuffSettings, {
		stat_buffs = {
			kind = "stat_buff",
			renames = ClassSwap.STAT_BUFF_RENAMES,
		},
		keywords = {
			kind = "keyword",
		},
		proc_events = {
			kind = "proc_event",
		},
	}, report)
	local lenient_special_rules = LegacyLoader.lenient_settings(SpecialRulesSettings, {
		special_rules = {
			kind = "special_rule",
			renames = ClassSwap.SPECIAL_RULE_RENAMES,
		},
	}, report)
	local talent_settings_view

	-- The current TalentSettings (with legacy class values already merged in),
	-- plus settings this version keeps private.
	local function talent_settings()
		if not talent_settings_view then
			local private = {}

			for _, path in ipairs(version_info.private_talent_settings or {}) do
				for key, value in pairs(version_ctx.loader.require(path)) do
					private[key] = value
				end
			end

			talent_settings_view = setmetatable({}, {
				__index = function (_, key)
					local value = private[key]

					if value ~= nil then
						return value
					end

					return TalentSettings[key]
				end,
			})
		end

		return talent_settings_view
	end

	return {
		["scripts/settings/buff/buff_settings"] = function ()
			return lenient_buff_settings
		end,
		["scripts/settings/ability/special_rules_settings"] = function ()
			return lenient_special_rules
		end,
		["scripts/settings/talent/talent_settings"] = talent_settings,
		["scripts/settings/ability/player_abilities/player_abilities"] = function ()
			return PlayerAbilities
		end,
		["scripts/settings/ability/archetype_talents/archetype_talents"] = function ()
			return ArchetypeTalents
		end,
		["scripts/settings/buff/buff_templates"] = function ()
			return BuffTemplates
		end,
		["scripts/settings/archetype/archetypes"] = function ()
			return Archetypes
		end,
		-- Legacy files read their own version's damage profiles (for example
		-- talent descriptions that quote a profile's values).
		["scripts/settings/damage/damage_profile_templates"] = function ()
			if not version_ctx.damage_profile_view then
				local legacy = _legacy_profiles(version_ctx)

				version_ctx.damage_profile_view = setmetatable({}, {
					__index = function (_, key)
						local value = legacy[key]

						if value ~= nil then
							return value
						end

						return DamageProfileTemplates[key]
					end,
				})
			end

			return version_ctx.damage_profile_view
		end,
	}
end

ClassSwap.apply = function (enabled_classes, report)
	local ctx = {
		report = report,
		known_icons = ClassSwap.collect_known_icons(),
		new_talent_names = {},
		new_node_names = {},
		new_buff_names = {},
		legacy_only_abilities = {},
		legacy_talents = {},
		replaced_layouts = {},
		icon_from_node = {},
	}

	local by_version, version_order = {}, {}

	for _, class_entry in ipairs(enabled_classes) do
		if not by_version[class_entry.version] then
			by_version[class_entry.version] = {}
			version_order[#version_order + 1] = class_entry.version
		end

		table.insert(by_version[class_entry.version], class_entry)
	end

	for _, version in ipairs(version_order) do
		local classes = by_version[version]
		local version_ctx = {
			version = version,
			resolved_shared = {},
		}
		local modules = LegacyManifest.legacy_modules(version, classes)

		version_ctx.loader = LegacyLoader.new(version, modules, _overrides(version, version_ctx, report), report)

		for _, class_entry in ipairs(classes) do
			local name = class_entry.archetype
			local files = LegacyManifest.class_files(class_entry)
			local ok, err = pcall(function ()
				if not Archetypes[name] or not ArchetypeTalents[name] then
					error("the current game has no archetype " .. name)
				end

				ctx.legacy_talents[name] = {}
				ctx.view = _class_view(class_entry, files)

				local main_profile = ctx.view.profiles[files.layout]

				ctx.view.default_icon = main_profile.by_type.default or main_profile.any_icon

				local settings_count = _apply_talent_settings(ctx, version_ctx.loader, files)
				local ability_count = _apply_abilities(ctx, version_ctx.loader, files, class_entry)

				version_ctx.shared_pool = version_ctx.shared_pool or _shared_pool(version_ctx.loader, files)

				local class_templates, buff_count = _apply_class_buffs(ctx, version_ctx.loader, files)
				local talents = _apply_talents(ctx, version_ctx, version_ctx.loader, files, class_entry, class_templates)
				local old_version, new_version, node_count = _apply_layout(ctx, version_ctx.loader, files.layout, class_entry, talents)

				ctx.replaced_layouts[require(files.layout)] = name

				if files.specialization_layout then
					_apply_layout(ctx, version_ctx.loader, files.specialization_layout, class_entry, talents)

					ctx.replaced_layouts[require(files.specialization_layout)] = name
				end

				local archetype_changes = _apply_archetype(ctx, version_ctx.loader, files, class_entry, talents)
				local profiles_changed, profiles_kept = _apply_damage_profiles(ctx, version_ctx, files, class_entry)

				report:line("%s: %s tree v%s (%d nodes) replaces v%s; %d talent setting groups, %d abilities, %d buffs, %d damage profiles changed (%d kept current). Base stats changed: %s", name, LegacyManifest.versions[version].label, tostring(new_version), node_count, tostring(old_version), settings_count, ability_count, buff_count, profiles_changed, profiles_kept, #archetype_changes > 0 and table.concat(archetype_changes, ", ") or "none")
			end)

			if not ok then
				report:error("%s (%s) was not applied: %s", name, version, tostring(err))
			end
		end
	end

	_append_network_ids(ctx)

	for name in pairs(ctx.legacy_only_abilities) do
		mod:info("legacy ability not loaded (no legacy talent uses it): %s", name)
	end

	return ctx
end

return ClassSwap
