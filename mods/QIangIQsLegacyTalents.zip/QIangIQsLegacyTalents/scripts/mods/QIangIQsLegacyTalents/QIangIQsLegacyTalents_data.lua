local mod = get_mod("QIangIQsLegacyTalents")

local function _toggle(setting_id)
	return {
		setting_id = setting_id,
		type = "checkbox",
		default_value = true,
	}
end

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = false,
	options = {
		widgets = {
			_toggle("legacy_veteran"),
			_toggle("legacy_zealot"),
			_toggle("legacy_psyker"),
			_toggle("legacy_ogryn"),
			_toggle("legacy_adamant"),
			_toggle("legacy_broker"),
			{
				setting_id = "legacy_in_hub",
				type = "checkbox",
				default_value = true,
				tooltip = "legacy_in_hub_description",
			},
		},
	},
}
