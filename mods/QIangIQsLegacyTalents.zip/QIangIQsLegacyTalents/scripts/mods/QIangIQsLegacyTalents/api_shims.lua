-- Methods the legacy buff templates call that the current game removed.
-- Patch 1.13.0 (Darktide-Source-Code commit 419fe18d) replaced ability
-- cooldowns with a resource system and changed every caller in the same commit.
-- Each shim below forwards to the method Fatshark's own callers switched to in
-- that commit. A shim is only added when the method is missing, so current game
-- code (which never calls these names) is unaffected.
local mod = get_mod("QIangIQsLegacyTalents")

local ApiShims = {}

local ABILITY_SHIMS = {
	-- reduce_ability_cooldown_percentage(t, p) -> restore_ability_charge_percentage(t, p)
	reduce_ability_cooldown_percentage = {
		needs = "restore_ability_charge_percentage",
		func = function (self, ability_type, percentage)
			return self:restore_ability_charge_percentage(ability_type, percentage)
		end,
	},
	-- reduce_ability_cooldown_time(t, s) -> restore_ability_resource(t, s)
	reduce_ability_cooldown_time = {
		needs = "restore_ability_resource",
		func = function (self, ability_type, time)
			return self:restore_ability_resource(ability_type, time)
		end,
	},
	-- increase_ability_cooldown_percentage(t, p) -> consume_ability_charge_percentage(t, p)
	increase_ability_cooldown_percentage = {
		needs = "consume_ability_charge_percentage",
		func = function (self, ability_type, percentage)
			return self:consume_ability_charge_percentage(ability_type, percentage)
		end,
	},
	-- max_ability_cooldown(t) -> max_regen_time_for_ability_charge(t)
	max_ability_cooldown = {
		needs = "max_regen_time_for_ability_charge",
		func = function (self, ability_type)
			return self:max_regen_time_for_ability_charge(ability_type)
		end,
	},
	-- get_current_ability_cooldown_time() returned the synced combat ability
	-- max cooldown; 1.13.0 callers use max_regen_time_for_ability_charge("combat_ability").
	get_current_ability_cooldown_time = {
		needs = "max_regen_time_for_ability_charge",
		func = function (self)
			return self:max_regen_time_for_ability_charge("combat_ability")
		end,
	},
	-- is_cooldown_paused(t) -> is_ability_resource_regen_paused(t)
	is_cooldown_paused = {
		needs = "is_ability_resource_regen_paused",
		func = function (self, ability_type)
			return self:is_ability_resource_regen_paused(ability_type)
		end,
	},
	-- remaining_ability_cooldown(t): math.huge when disabled, 0 when paused,
	-- otherwise the time to the next charge. The resource left to the next
	-- charge is used for that time (the resource regenerates 1 per second before
	-- buffs). This mapping is inferred, not taken from a Fatshark caller.
	remaining_ability_cooldown = {
		needs = "missing_ability_resource_until_next_charge",
		func = function (self, ability_type)
			if self.ability_enabled and not self:ability_enabled(ability_type) then
				return math.huge
			end

			if self.is_ability_resource_regen_paused and self:is_ability_resource_regen_paused(ability_type) then
				return 0
			end

			local missing = self:missing_ability_resource_until_next_charge(ability_type)

			return missing or 0
		end,
	},
}

local COMPANION_SHIMS = {
	-- companion_unit() -> companion_units()[1]
	companion_unit = {
		needs = "companion_units",
		func = function (self)
			local units = self:companion_units()

			return units and units[1]
		end,
	},
	-- despawn_unit() became despawn_units() in 1.11 and despawn_companion_units() now.
	despawn_unit = {
		needs = "despawn_companion_units",
		func = function (self)
			return self:despawn_companion_units()
		end,
	},
}

local added = {}

local function _install(class_table, class_name, shims)
	for name, shim in pairs(shims) do
		if class_table[name] == nil and class_table[shim.needs] ~= nil then
			class_table[name] = shim.func
			added[#added + 1] = class_name .. "." .. name
		end
	end
end

ApiShims.install = function ()
	mod:hook_require("scripts/extension_systems/ability/player_unit_ability_extension", function (Extension)
		_install(Extension, "PlayerUnitAbilityExtension", ABILITY_SHIMS)
	end)
	mod:hook_require("scripts/extension_systems/ability/player_husk_ability_extension", function (Extension)
		_install(Extension, "PlayerHuskAbilityExtension", ABILITY_SHIMS)
	end)
	mod:hook_require("scripts/extension_systems/companion_spawner/companion_spawner_extension", function (Extension)
		_install(Extension, "CompanionSpawnerExtension", COMPANION_SHIMS)
	end)
end

ApiShims.added = function ()
	return added
end

return ApiShims
