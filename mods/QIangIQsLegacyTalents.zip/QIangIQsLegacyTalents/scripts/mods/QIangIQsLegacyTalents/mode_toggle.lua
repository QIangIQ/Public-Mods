-- Switches the game data this mod changes between the legacy values and the
-- current game's own values, in place, so live missions run the official data.
--
-- Before the swap, every table reachable from the roots is copied one level
-- deep. After the swap, each of those tables is compared with its copy, and
-- every key whose value changed is recorded with both values. Switching modes
-- writes one side of that record back. Tables keep their identity, so anything
-- holding a reference (profiles, weapon templates, talents) sees the change.
local ModeToggle = {}

local function _capture(roots, stop)
	local copies = {}
	local stack = {}

	local function visit(t, deep)
		if copies[t] then
			return
		end

		local copy = {}

		for k, v in next, t do
			copy[k] = v

			if deep and type(v) == "table" and not copies[v] and not stop[v] then
				stack[#stack + 1] = v
			end
		end

		copies[t] = copy
	end

	for _, root in ipairs(roots) do
		local t = root.table

		if type(t) == "table" then
			visit(t, not root.shallow)
		end
	end

	while #stack > 0 do
		local t = stack[#stack]

		stack[#stack] = nil

		visit(t, true)
	end

	return copies
end

ModeToggle.new = function (roots, stop_tables)
	local stop = {}

	for _, t in ipairs(stop_tables or {}) do
		if type(t) == "table" then
			stop[t] = true
		end
	end

	local before = _capture(roots, stop)
	local count = 0

	for _ in pairs(before) do
		count = count + 1
	end

	return {
		before = before,
		tables_captured = count,
		active = true,
	}
end

-- Call once the swap is done. Records every key that differs from the copy.
ModeToggle.finish = function (toggle)
	local tables, keys, vanilla, legacy = {}, {}, {}, {}
	local n = 0
	local changed_tables = {}

	for t, old in pairs(toggle.before) do
		for k, v in next, old do
			local now = rawget(t, k)

			if now ~= v then
				n = n + 1
				tables[n], keys[n], vanilla[n], legacy[n] = t, k, v, now
				changed_tables[t] = true
			end
		end

		for k, now in next, t do
			if rawget(old, k) == nil then
				n = n + 1
				tables[n], keys[n], vanilla[n], legacy[n] = t, k, nil, now
				changed_tables[t] = true
			end
		end
	end

	local changed_count = 0

	for _ in pairs(changed_tables) do
		changed_count = changed_count + 1
	end

	toggle.before = nil
	toggle.tables = tables
	toggle.keys = keys
	toggle.vanilla = vanilla
	toggle.legacy = legacy
	toggle.count = n
	toggle.tables_changed = changed_count
	toggle.active = true

	return n
end

ModeToggle.set_active = function (toggle, active)
	active = not not active

	if toggle.active == active or not toggle.tables then
		return false
	end

	local values = active and toggle.legacy or toggle.vanilla
	local tables, keys = toggle.tables, toggle.keys

	for i = 1, toggle.count do
		rawset(tables[i], keys[i], values[i])
	end

	toggle.active = active

	return true
end

return ModeToggle
