-- Which source version each class comes from, and which of that version's
-- files are loaded as legacy code. Every file listed here is a verbatim copy
-- from the Aussiemon/Darktide-Source-Code history at the commit named.
local LegacyManifest = {}

local function _shared(talents_dir)
	return {
		base_talents = talents_dir .. "base_talents",
		shared_buffs = "scripts/settings/buff/archetype_buff_templates/shared_archetype_buff_templates",
		player_buffs = "scripts/settings/buff/player_buff_templates",
		archetype_templates = {
			"scripts/settings/toughness/archetype_toughness_templates",
			"scripts/settings/dodge/archetype_dodge_templates",
			"scripts/settings/stamina/archetype_stamina_templates",
			"scripts/settings/sprint/archetype_sprint_templates",
			"scripts/settings/warp_charge/archetype_warp_charge_templates",
		},
	}
end

LegacyManifest.versions = {
	["1.6.1"] = {
		commit = "c3b51ce6",
		label = "1.6.1 (12-05-24)",
		talents_dir = "scripts/settings/ability/archetype_talents/",
		abilities_dir = "scripts/settings/ability/player_abilities/",
		extra_modules = {},
		-- 1.6.1 kept class damage profiles in these files; only profiles the
		-- current game files under the class are taken from them.
		damage_profile_files = {
			"scripts/settings/damage/damage_profiles/ability_damage_profile_templates",
			"scripts/settings/damage/damage_profiles/psyker_smite_damage_profile_templates",
			"scripts/settings/damage/damage_profiles/zealot_damage_profile_templates",
		},
	},
	["1.7.1"] = {
		commit = "edcd85d1",
		label = "1.7.1 (Nightmares and Visions hotfix, 03-27-25)",
		talents_dir = "scripts/settings/ability/archetype_talents/talents/",
		abilities_dir = "scripts/settings/ability/player_abilities/abilities/",
		extra_modules = {},
		damage_profile_files = {
			"scripts/settings/damage/damage_profiles/archetypes/ogryn_damage_profile_templates",
		},
	},
	["1.8.0"] = {
		commit = "0765b12c",
		label = "1.8.0 (06-23-25)",
		talents_dir = "scripts/settings/ability/archetype_talents/talents/",
		abilities_dir = "scripts/settings/ability/player_abilities/abilities/",
		-- Required by the 1.8.0 adamant_archetype.lua; the current game removed it.
		extra_modules = {
			"scripts/settings/archetype/archetypes/adamant_archetype_dlc_settings",
		},
		damage_profile_files = {
			"scripts/settings/damage/damage_profiles/archetypes/adamant_damage_profile_templates",
		},
	},
	["1.10.0"] = {
		commit = "622281b0",
		label = "1.10.0 (12-02-25)",
		talents_dir = "scripts/settings/ability/archetype_talents/talents/",
		abilities_dir = "scripts/settings/ability/player_abilities/abilities/",
		extra_modules = {
			"scripts/settings/talent/talent_settings_shared",
		},
		damage_profile_files = {
			"scripts/settings/damage/damage_profiles/archetypes/broker_damage_profile_templates",
		},
		-- Settings from these modules only apply inside this version's files,
		-- never to the current game's shared values.
		private_talent_settings = {
			"scripts/settings/talent/talent_settings_shared",
		},
	},
}

-- Classes in the order they are applied. The order fixes the network ids
-- this mod appends, so it must be the same on every player.
LegacyManifest.classes = {
	{ archetype = "veteran", version = "1.6.1", setting_id = "legacy_veteran" },
	{ archetype = "zealot", version = "1.6.1", setting_id = "legacy_zealot" },
	{ archetype = "psyker", version = "1.6.1", setting_id = "legacy_psyker" },
	{ archetype = "ogryn", version = "1.7.1", setting_id = "legacy_ogryn" },
	{ archetype = "adamant", version = "1.8.0", setting_id = "legacy_adamant" },
	{
		archetype = "broker",
		version = "1.10.0",
		setting_id = "legacy_broker",
		specialization_layout = "scripts/ui/views/broker_stimm_builder_view/layouts/broker_stimm_tree",
	},
}

LegacyManifest.class_files = function (class_entry)
	local version = LegacyManifest.versions[class_entry.version]
	local name = class_entry.archetype
	local shared = _shared(version.talents_dir)

	return {
		talents = version.talents_dir .. name .. "_talents",
		base_talents = shared.base_talents,
		abilities = version.abilities_dir .. name .. "_abilities",
		class_buffs = "scripts/settings/buff/archetype_buff_templates/" .. name .. "_buff_templates",
		shared_buffs = shared.shared_buffs,
		player_buffs = shared.player_buffs,
		talent_settings = "scripts/settings/talent/talent_settings_" .. name,
		layout = "scripts/ui/views/talent_builder_view/layouts/" .. name .. "_tree",
		specialization_layout = class_entry.specialization_layout,
		archetype = "scripts/settings/archetype/archetypes/" .. name .. "_archetype",
		archetype_templates = shared.archetype_templates,
		current_damage_profiles = "scripts/settings/damage/damage_profiles/archetypes/" .. name .. "_damage_profile_templates",
	}
end

-- Every module path a version ships, for the loader.
LegacyManifest.legacy_modules = function (version_name, class_entries)
	local version = LegacyManifest.versions[version_name]
	local modules = {}

	for _, class_entry in ipairs(class_entries) do
		local files = LegacyManifest.class_files(class_entry)

		for key, value in pairs(files) do
			if key == "current_damage_profiles" then
				-- Read from the current game, never from the legacy folder.
			elseif type(value) == "string" then
				modules[value] = true
			elseif type(value) == "table" then
				for _, path in ipairs(value) do
					modules[path] = true
				end
			end
		end
	end

	for _, path in ipairs(version.extra_modules) do
		modules[path] = true
	end

	for _, path in ipairs(version.damage_profile_files or {}) do
		modules[path] = true
	end

	return modules
end

return LegacyManifest
