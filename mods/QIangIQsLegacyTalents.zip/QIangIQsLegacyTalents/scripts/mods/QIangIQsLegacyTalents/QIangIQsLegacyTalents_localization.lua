return {
	mod_name = {
		en = "QIangIQ's Legacy Talents",
	},
	mod_description = {
		en = "Original talent trees, talents and base stats from older game versions, for SoloPlay, the Psykhanium and Realms. Fatshark missions switch back to the official trees and build. Every player in a Realms game needs the same class settings. Class changes apply after a restart.",
	},
	legacy_veteran = {
		en = "Veteran: 1.6.1 tree",
	},
	legacy_zealot = {
		en = "Zealot: 1.6.1 tree",
	},
	legacy_psyker = {
		en = "Psyker: 1.6.1 tree",
	},
	legacy_ogryn = {
		en = "Ogryn: Nightmares and Visions tree (1.7.1)",
	},
	legacy_adamant = {
		en = "Arbites: release tree (1.8.0)",
	},
	legacy_broker = {
		en = "Hive Scum: release tree and Stimm Lab (1.10.0)",
	},
	legacy_in_hub = {
		en = "Legacy trees in the Mourning Star",
	},
	legacy_in_hub_description = {
		en = "On: the Mourning Star shows the legacy trees, and builds you save there are kept on this PC. Off: the Mourning Star shows the official trees, so you can change your official build. The talents page has a button to switch. Fatshark missions always use the official build.",
	},
	legacy_build_saved = {
		en = "Legacy build saved on this PC. Your official build is unchanged and is used in Fatshark missions.",
	},
	hub_setting_changed = {
		en = "Applies the next time you enter the Mourning Star.",
	},
	show_official_tree = {
		en = "Switch to official tree",
	},
	show_legacy_tree = {
		en = "Switch to legacy tree",
	},
	restart_required = {
		en = "Restart the game to apply legacy talent changes.",
	},
	load_errors = {
		en = "Some legacy classes did not load. Type /legacy_talents for details.",
	},
	command_description = {
		en = "Show what the legacy talent swap changed",
	},
}
