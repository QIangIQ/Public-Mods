local mod = get_mod("QIangIQsLegacyTalents")
local MOD_DIR = "QIangIQsLegacyTalents/scripts/mods/QIangIQsLegacyTalents/"
local LegacyManifest = mod:io_dofile(MOD_DIR .. "legacy_manifest")
local LegacyReport = mod:io_dofile(MOD_DIR .. "legacy_report")
local ClassSwap = mod:io_dofile(MOD_DIR .. "class_swap")
local ApiShims = mod:io_dofile(MOD_DIR .. "api_shims")
local ModeToggle = mod:io_dofile(MOD_DIR .. "mode_toggle")
local LegacyBuilds = mod:io_dofile(MOD_DIR .. "legacy_builds")
local RealmsSync = mod:io_dofile(MOD_DIR .. "realms_sync")

-- The swap changes shared game data, so it runs once per game start. A
-- persistent table keeps a mod reload (ctrl+shift+R) from running it twice.
local state = mod:persistent_table("legacy_state", {
	applied = false,
	report = nil,
	replaced_layouts = nil,
	loc_fallbacks = nil,
	enabled = nil,
	toggle = nil,
	build_archetypes = nil,
	host_type = nil,
})

ApiShims.install()

local function _enabled_classes()
	local enabled = {}

	for _, class_entry in ipairs(LegacyManifest.classes) do
		if mod:get(class_entry.setting_id) ~= false then
			enabled[#enabled + 1] = class_entry
		end
	end

	return enabled
end

-- Text for loc keys the legacy talents use but the current game no longer has.
-- Names come from the talent's own name field in the legacy source; descriptions
-- list the talent's values, since the old English text is not in the source.
local function _build_loc_fallbacks(ctx, enabled)
	local swapped = {}

	for _, class_entry in ipairs(enabled) do
		swapped[class_entry.archetype] = class_entry.version
	end

	-- Keys still used by classes this mod leaves alone are never replaced.
	local ArchetypeTalents = require("scripts/settings/ability/archetype_talents/archetype_talents")
	local protected = {}

	for archetype_name, talents in pairs(ArchetypeTalents) do
		if not swapped[archetype_name] then
			for _, talent in pairs(talents) do
				if type(talent) == "table" then
					if talent.display_name then
						protected[talent.display_name] = true
					end

					if talent.description then
						protected[talent.description] = true
					end
				end
			end
		end
	end

	local fallbacks = {}

	for archetype_name, talents in pairs(ctx.legacy_talents) do
		local version = swapped[archetype_name]

		for talent_name, talent in pairs(talents) do
			local display_name = talent.display_name

			if type(display_name) == "string" and not protected[display_name] and not fallbacks[display_name] then
				local dev_name = type(talent.name) == "string" and talent.name ~= "" and talent.name or talent_name

				fallbacks[display_name] = {
					text = dev_name,
				}
			end

			local description = talent.description

			if type(description) == "string" and not protected[description] and not fallbacks[description] then
				local keys = {}
				local parts = {}

				if type(talent.format_values) == "table" then
					for key in pairs(talent.format_values) do
						keys[#keys + 1] = key
					end

					table.sort(keys)

					for _, key in ipairs(keys) do
						parts[#parts + 1] = string.format("%s: {%s:%%s}", key, key)
					end
				end

				local known = {}

				for _, key in ipairs(keys) do
					known[key] = true
				end

				fallbacks[description] = {
					text = string.format("[%s talent, no in-game text in the source] %s", tostring(version), table.concat(parts, ", ")),
					keys = known,
				}
			end
		end
	end

	return fallbacks
end

-- Every table the swap writes to, so the swap can be undone in live games.
local function _toggle_roots(enabled)
	local roots = {
		{ table = require("scripts/settings/ability/player_abilities/player_abilities") },
		{ table = require("scripts/settings/talent/talent_settings") },
		{ table = require("scripts/settings/damage/damage_profile_templates") },
	}
	local BuffTemplates = require("scripts/settings/buff/buff_templates")
	local stop = { BuffTemplates }

	-- Buff templates are only ever replaced whole, so their top level is enough.
	roots[#roots + 1] = { table = BuffTemplates, shallow = true }

	for _, name in ipairs({ "PREDICTED", "NON_PREDICTED" }) do
		local lookup = rawget(BuffTemplates, name)

		if lookup then
			roots[#roots + 1] = { table = lookup, shallow = true }
			stop[#stop + 1] = lookup
		end
	end

	local ArchetypeTalents = require("scripts/settings/ability/archetype_talents/archetype_talents")
	local Archetypes = require("scripts/settings/archetype/archetypes")

	for _, class_entry in ipairs(enabled) do
		local files = LegacyManifest.class_files(class_entry)

		roots[#roots + 1] = { table = rawget(ArchetypeTalents, class_entry.archetype) }
		roots[#roots + 1] = { table = rawget(Archetypes, class_entry.archetype) }
		roots[#roots + 1] = { table = require(files.layout) }

		if files.specialization_layout then
			roots[#roots + 1] = { table = require(files.specialization_layout) }
		end
	end

	return roots, stop
end

local function _apply_once()
	if state.applied then
		return
	end

	state.applied = true

	local enabled = _enabled_classes()
	local report = LegacyReport.new()

	state.report = report
	state.enabled = enabled

	if #enabled == 0 then
		report:line("No legacy classes enabled.")

		return
	end

	-- Tree versions before the swap. A tree whose version changes takes a
	-- different talent string, so its builds are kept locally.
	local vanilla_versions = {}

	for _, class_entry in ipairs(enabled) do
		local layout = require(LegacyManifest.class_files(class_entry).layout)

		vanilla_versions[class_entry.archetype] = layout.version
	end

	local roots, stop = _toggle_roots(enabled)
	local toggle = ModeToggle.new(roots, stop)
	local ok, ctx = pcall(ClassSwap.apply, enabled, report)

	ModeToggle.finish(toggle)

	state.toggle = toggle

	report:line("Live-game switch: %d values in %d tables (%d tables checked)", toggle.count, toggle.tables_changed, toggle.tables_captured)

	if not ok then
		report:error("Legacy swap failed: %s", tostring(ctx))

		-- Put the current game data back rather than leave a half-applied swap.
		ModeToggle.set_active(toggle, false)

		state.toggle = nil

		return
	end

	local build_archetypes = {}

	for _, class_entry in ipairs(enabled) do
		local layout = require(LegacyManifest.class_files(class_entry).layout)
		local name = class_entry.archetype

		if ctx.replaced_layouts[layout] and layout.version ~= vanilla_versions[name] then
			build_archetypes[name] = {
				layout = layout,
				legacy_version = layout.version,
				vanilla_version = vanilla_versions[name],
			}
		end
	end

	state.replaced_layouts = ctx.replaced_layouts
	state.build_archetypes = build_archetypes
	state.loc_fallbacks = _build_loc_fallbacks(ctx, enabled)

	for _, text in ipairs(report:summary()) do
		mod:info("%s", text)
	end
end

_apply_once()

-- ####################################################################
-- Legacy data in Realms, SoloPlay and the Psykhanium; the current game's data
-- on Fatshark's mission servers, so live games use a working official build.
-- The mode is picked when a connection starts, before profiles are synced.
-- ####################################################################

local function _is_active()
	local toggle = state.toggle

	return toggle ~= nil and toggle.active
end

local function _wanted_active(host_type)
	if host_type == "mission_server" then
		return false
	elseif host_type == "hub_server" then
		return mod:get("legacy_in_hub") ~= false
	elseif host_type == "player" or host_type == "singleplay" or host_type == "singleplay_backend_session" then
		return true
	end

	return nil
end

local function _set_mode(host_type)
	state.host_type = host_type

	local toggle = state.toggle
	local wanted = _wanted_active(host_type)

	if not toggle or wanted == nil then
		return
	end

	if ModeToggle.set_active(toggle, wanted) then
		mod:info("Host type %s: %s talent data", tostring(host_type), wanted and "legacy" or "official")
		LegacyBuilds.refresh_presets()
	end

	RealmsSync.publish_changed()
end

LegacyBuilds.server_builds_official = function ()
	return state.host_type == "hub_server" or state.host_type == "mission_server"
end

LegacyBuilds.setup({
	is_active = _is_active,
	build_archetypes = state.build_archetypes or {},
})
LegacyBuilds.install()

-- Realms: other players' legacy builds arrive through QIangIQsSyncChannel.
LegacyBuilds.remote = function (character_id, archetype_name)
	return RealmsSync.remote(character_id, archetype_name)
end

LegacyBuilds.on_stored = function ()
	RealmsSync.publish_changed()
end

mod:hook_require("scripts/managers/multiplayer/connection_manager", function (ConnectionManager)
	mod:hook(ConnectionManager, "set_connection_client", function (func, self, connection_client, ...)
		local ok, host_type = pcall(function ()
			return connection_client:host_type()
		end)

		if ok then
			_set_mode(host_type)
		end

		return func(self, connection_client, ...)
	end)

	mod:hook(ConnectionManager, "set_connection_host", function (func, self, connection_host, ...)
		local ok, host_type = pcall(function ()
			return connection_host:host_type()
		end)

		if ok then
			_set_mode(host_type)
		end

		return func(self, connection_host, ...)
	end)
end)

-- ####################################################################
-- Switch on the talents page (Mourning Star only): legacy tree or official
-- tree. It flips the "legacy_in_hub" setting and applies it right away.
-- Missions always use the official tree, and the Psykhanium and Realms the
-- legacy one, because there the game data must match the host's.
-- ####################################################################

local TREE_VIEW = "talent_builder_view"
local TREE_SWITCH_TIMEOUT = 3
local TREE_SWITCH_LOC = {
	loc_qlt_show_official_tree = "show_official_tree",
	loc_qlt_show_legacy_tree = "show_legacy_tree",
}

local function _now()
	local time_manager = Managers.time

	return time_manager and time_manager:time("main") or os.clock()
end

-- Same calls as _set_backend_response_success in talents_service.lua: the
-- hub server sends the profile again, and the unpack_profile hook in
-- legacy_builds.lua builds it for the tree now in use.
local function _resync_local_profile()
	local player_manager = Managers.player
	local player = player_manager and player_manager:local_player_safe(1)
	local connection_manager = Managers.connection

	if not player or not connection_manager then
		return
	end

	local peer_id = player:peer_id()
	local local_player_id = player:local_player_id()

	if connection_manager:is_host() then
		Managers.profile_synchronization:synchronizer_host():profile_changed(peer_id, local_player_id)
	elseif connection_manager:is_client() then
		connection_manager:send_rpc_server("rpc_notify_profile_changed", local_player_id)
	end
end

-- Applies the "legacy_in_hub" setting now. Returns false outside the hub.
local function _apply_hub_mode()
	local toggle = state.toggle

	if not toggle or state.host_type ~= "hub_server" then
		return false
	end

	if ModeToggle.set_active(toggle, _wanted_active("hub_server")) then
		mod:info("Mourning Star: %s talent data", _is_active() and "legacy" or "official")
		LegacyBuilds.refresh_presets()
		RealmsSync.publish_changed()

		local ok, err = pcall(_resync_local_profile)

		if not ok then
			mod:error("Could not refresh your profile: %s", tostring(err))
		end
	end

	return true
end

local function _can_switch_tree(view)
	if view._is_readonly or view._is_own_player == false or state.host_type ~= "hub_server" or not state.toggle then
		return false
	end

	local player = view._preview_player
	local profile = player and player:profile()
	local archetype = profile and profile.archetype

	return type(archetype) == "table" and (state.build_archetypes or {})[archetype.name] ~= nil
end

local function _cb_switch_tree(view)
	if view._qlt_tree_switch or view._active_view ~= TREE_VIEW or not _can_switch_tree(view) then
		return
	end

	-- Close the talents first, while the old tree is still loaded: its on_exit
	-- saves the old tree's nodes to the active preset (talent_builder_view.lua).
	view._qlt_tree_switch = {
		stage = "closing",
	}

	if Managers.ui:view_active(TREE_VIEW) and not Managers.ui:is_view_closing(TREE_VIEW) then
		Managers.ui:close_view(TREE_VIEW)
	end
end

local function _step_tree_switch(view)
	local switch = view._qlt_tree_switch

	if not switch then
		return
	end

	if switch.stage == "closing" then
		if Managers.ui:view_active(TREE_VIEW) then
			return
		end

		local player = view._preview_player

		switch.profile = player and player:profile()
		switch.started = _now()
		switch.stage = "waiting"

		mod:set("legacy_in_hub", not _is_active())
		_apply_hub_mode()

		-- These hold the old tree's nodes; InventoryBackgroundView.on_exit
		-- would save them against the new tree.
		view._current_profile_equipped_talents = nil
		view._valid_profile_equipped_talents = nil

		return
	end

	-- Reopen once the profile for the new tree has arrived.
	local player = view._preview_player
	local profile = player and player:profile()

	if profile == switch.profile and _now() - switch.started < TREE_SWITCH_TIMEOUT then
		return
	end

	view._qlt_tree_switch = nil

	if view._active_view == TREE_VIEW and not Managers.ui:view_active(TREE_VIEW) then
		view._active_view = nil

		if view._check_toggle_companion then
			pcall(view._check_toggle_companion, view)
		end

		view:_switch_active_view(TREE_VIEW)
	end
end

local function _tree_switch_visible(view, id)
	if rawget(view, "cb_qlt_switch_tree") == nil then
		rawset(view, "cb_qlt_switch_tree", _cb_switch_tree)
	end

	local ok, err = pcall(_step_tree_switch, view)

	if not ok then
		view._qlt_tree_switch = nil

		mod:error("Tree switch failed: %s", tostring(err))
	end

	if view._qlt_tree_switch or view._active_view ~= TREE_VIEW or not _can_switch_tree(view) then
		return false
	end

	local legend = view._input_legend_element

	if legend then
		legend:set_display_name(id, _is_active() and "loc_qlt_show_official_tree" or "loc_qlt_show_legacy_tree")
	end

	return true
end

mod:hook_require("scripts/ui/views/inventory_background_view/inventory_background_view_definitions", function (definitions)
	local legend_inputs = definitions.legend_inputs

	if type(legend_inputs) ~= "table" then
		return
	end

	local entry = {
		alignment = "right_alignment",
		display_name = "loc_qlt_show_official_tree",
		input_action = "hotkey_menu_special_2",
		on_pressed_callback = "cb_qlt_switch_tree",
		visibility_function = function (parent, id)
			return _tree_switch_visible(parent, id)
		end,
	}

	for i = 1, #legend_inputs do
		if legend_inputs[i].on_pressed_callback == entry.on_pressed_callback then
			legend_inputs[i] = entry

			return
		end
	end

	legend_inputs[#legend_inputs + 1] = entry
end)

-- ####################################################################
-- Text for legacy talents whose loc keys no longer exist.
-- ####################################################################

local function _placeholders_known(raw, keys)
	for key in string.gmatch(raw, "{([%a%d_]*):*[%a%d%.%%]*}") do
		if not keys[key] then
			return false
		end
	end

	return true
end

mod:hook(CLASS.LocalizationManager, "_lookup", function (func, self, key)
	local switch_text = TREE_SWITCH_LOC[key]

	if switch_text then
		return mod:localize(switch_text)
	end

	local raw = func(self, key)
	local fallbacks = _is_active() and state.loc_fallbacks
	local fallback = fallbacks and fallbacks[key]

	if not fallback then
		return raw
	end

	if raw == nil then
		return fallback.text
	end

	-- The current text describes the current talent; if it asks for values
	-- the legacy talent does not have, show the legacy values instead.
	if fallback.keys and not _placeholders_known(raw, fallback.keys) then
		return fallback.text
	end

	return raw
end)

-- ####################################################################
-- Command
-- ####################################################################

mod:command("legacy_talents", mod:localize("command_description"), function ()
	local report = state.report

	if not report then
		mod:echo("No report.")

		return
	end

	for _, text in ipairs(report:summary()) do
		mod:echo(text)
	end

	mod:echo("Talent data now: %s (host type %s)", _is_active() and "legacy" or "official", tostring(state.host_type))
	mod:echo("Realms build sharing through QIangIQsSyncChannel: %s", RealmsSync.active() and "on" or "off (mod not found)")

	for _, name in ipairs(ApiShims.added()) do
		mod:echo("Added for legacy buffs: %s", name)
	end
end)

mod.on_all_mods_loaded = function ()
	local report = state.report

	RealmsSync.start({
		builds = LegacyBuilds,
		build_archetypes = state.build_archetypes or {},
		is_active = _is_active,
	})

	if report and report.signature then
		mod:info("Network signature %s", report.signature)
	end

	if report and #report.errors > 0 then
		mod:notify(mod:localize("load_errors"))
	end
end

mod.on_setting_changed = function (setting_id)
	if setting_id == "legacy_in_hub" then
		if not _apply_hub_mode() then
			mod:notify(mod:localize("hub_setting_changed"))
		end

		return
	end

	mod:notify(mod:localize("restart_required"))
end
