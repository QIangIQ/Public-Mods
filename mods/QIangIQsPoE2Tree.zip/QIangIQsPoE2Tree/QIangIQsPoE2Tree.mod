return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsPoE2Tree` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsPoE2Tree", {
			mod_script       = "QIangIQsPoE2Tree/scripts/mods/QIangIQsPoE2Tree/QIangIQsPoE2Tree",
			mod_data         = "QIangIQsPoE2Tree/scripts/mods/QIangIQsPoE2Tree/QIangIQsPoE2Tree_data",
			mod_localization = "QIangIQsPoE2Tree/scripts/mods/QIangIQsPoE2Tree/QIangIQsPoE2Tree_localization",
		})
	end,
	packages = {},
}
