# QIangIQsPoE2Tree

Temporarily replaces the Veteran talent tree with the Path of Exile 2 passive tree (0_5): 4,546 nodes at their PoE2 positions and connections, each stat mapped to the closest Darktide stat buff.
Data comes from PathOfBuildingCommunity/PathOfBuilding-PoE2 (src/TreeData/0_5/tree.lua); term mapping in /mnt/project-files/poe2-passive-tree/darktide/term_mapping.md.

- Hub at the tree centre: the Veteran start node plus the official tactical, aura and ability nodes, linked to the six PoE2 class starts.
- Settings: use the tree, tree in the Mourning Star, talent points (123), stat strength (100%).
- Host side only (SoloPlay, Psykhanium, Realms you host). Mission servers use the official tree. Turn off LegacyTalents' Veteran option first.
- Chat command: /poe2tree.
- Untested in game.
