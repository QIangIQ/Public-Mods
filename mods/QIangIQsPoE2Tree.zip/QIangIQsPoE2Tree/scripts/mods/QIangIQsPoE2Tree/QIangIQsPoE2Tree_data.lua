local mod = get_mod("QIangIQsPoE2Tree")

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = false,
	options = {
		widgets = {
			{
				setting_id = "tree_enabled",
				type = "checkbox",
				default_value = true,
				tooltip = "tree_enabled_description",
			},
			{
				setting_id = "tree_in_hub",
				type = "checkbox",
				default_value = true,
				tooltip = "tree_in_hub_description",
			},
			{
				setting_id = "tree_points_v2",
				type = "numeric",
				default_value = 90,
				range = { 1, 400 },
				decimals_number = 0,
				tooltip = "tree_points_v2_description",
			},
			{
				setting_id = "tree_radius_v2",
				type = "numeric",
				default_value = 14,
				range = { 10, 100 },
				decimals_number = 0,
				tooltip = "tree_radius_v2_description",
			},
			{
				setting_id = "node_spacing_v2",
				type = "numeric",
				default_value = 20,
				range = { 10, 100 },
				decimals_number = 0,
				tooltip = "node_spacing_v2_description",
			},
			{
				setting_id = "value_scale",
				type = "numeric",
				default_value = 100,
				range = { 5, 200 },
				decimals_number = 0,
				tooltip = "value_scale_description",
			},
		},
	},
}
