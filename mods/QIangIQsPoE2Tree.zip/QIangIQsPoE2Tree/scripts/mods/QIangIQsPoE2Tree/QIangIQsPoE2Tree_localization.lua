return {
	mod_name = {
		en = "QIangIQ's PoE2 Tree",
	},
	mod_description = {
		en = "Temporarily replaces the Veteran talent tree with the full Path of Exile 2 passive tree (version 0_5, 4,546 nodes at their PoE2 positions and connections). Every PoE2 stat is mapped to the closest Darktide stat buff; keystones and other effects with no Darktide equivalent are placeholders. The Veteran keeps its combat ability, tactical and aura choices in a hub at the centre of the tree, which links to the six PoE2 class start nodes. Host side only: works in SoloPlay, the Psykhanium and Realms you host; Fatshark missions use the official tree. Everyone in a Realms game needs this mod.",
	},
	tree_enabled = {
		en = "Use the PoE2 tree",
	},
	tree_enabled_description = {
		en = "Off: the Veteran has the official tree again.",
	},
	tree_in_hub = {
		en = "PoE2 tree in the Mourning Star",
	},
	tree_in_hub_description = {
		en = "Show the PoE2 tree in the Mourning Star and the main menu. Fatshark missions always use the official tree.",
	},
	tree_points_v2 = {
		en = "Talent points",
	},
	tree_points_v2_description = {
		en = "Points you can spend on the PoE2 tree. Path of Exile 2 gives about 123 passive points. The default is 90, three times the Veteran tree's 30.",
	},
	tree_radius_v2 = {
		en = "Tree radius (%%)",
	},
	tree_radius_v2_description = {
		en = "How much of the PoE2 tree, measured from its centre, is used. Lower is lighter on the game. Restart the game after changing it, and keep it the same for everyone in a party.",
	},
	node_spacing_v2 = {
		en = "Node spacing (%%)",
	},
	node_spacing_v2_description = {
		en = "Distance between nodes as a share of the PoE2 layout. 20 is tighter than the Veteran tree's spacing. Restart the game after changing it.",
	},
	value_scale = {
		en = "Stat strength (%%)",
	},
	value_scale_description = {
		en = "Scales every PoE2 stat value. 100 uses the PoE2 numbers as they are, which stack very high on a Darktide character.",
	},
	command_description = {
		en = "Shows whether the PoE2 Veteran tree is on.",
	},
}
