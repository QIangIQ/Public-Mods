local mod = get_mod("QIangIQsPoE2Tree")

-- Replaces the Veteran talent tree with the Path of Exile 2 passive tree
-- (poe2_nodes.lua, generated from PathOfBuildingCommunity/PathOfBuilding-PoE2
-- src/TreeData/0_5/tree.lua).
--
-- Layout: the official start node and the tactical, aura and ability nodes
-- stay (cloned) as a hub at the centre of the PoE2 tree, because the
-- Veteran's combat ability, blitz and aura come from those nodes
-- (character_sheet.lua class_loadout). The hub start node links to the six
-- PoE2 class start nodes; the PoE2 graph hangs below them. PoE2 positions
-- are scaled by the generator. The talent string stores nodes by index
-- (talent_layout_parser.lua pack_backend_data), so layout.version changes
-- while the PoE2 tree is on and builds of the official tree are dropped.
--
-- Talents: one talent and one buff template per node, registered like
-- QIangIQsZealotDeflect and QIangIQsMartyrdom (ArchetypeTalents,
-- BuffTemplates, NetworkLookup). Buffs are plain stat_buffs.
--
-- Gameplay runs where the game runs talents: on the host. On Fatshark's
-- mission servers nothing here runs and the tree is the official one.

local BuffSettings = require("scripts/settings/buff/buff_settings")
local BuffTemplates = require("scripts/settings/buff/buff_templates")

local stat_buffs = BuffSettings.stat_buffs
local stat_buff_types = BuffSettings.stat_buff_types

local LAYOUT_PATH = "scripts/ui/views/talent_builder_view/layouts/veteran_tree"
local MOD_DIR = "QIangIQsPoE2Tree/scripts/mods/QIangIQsPoE2Tree/"
local VERSION_OFFSET = 1000
local ICON_STAT = "content/ui/textures/frames/talents/circular_small_frame"
local HUB_TYPES = {
	ability = true,
	aura = true,
	start = true,
	tactical = true,
}
-- Node kinds in poe2_nodes.lua -> Darktide node types.
local NODE_TYPES = {
	a = "stat",
	c = "stat",
	j = "stat",
	k = "keystone",
	n = "default",
	s = "stat",
}

local DATA = mod:io_dofile(MOD_DIR .. "poe2_nodes")

local state = mod:persistent_table("poe2tree_state", {
	registered = false,
	host_type = nil,
	saved = nil,
})

-- ####################################################################
-- Data
-- ####################################################################

local function _talent_name(id)
	return "qiangiq_poe2_" .. id
end

local function _template_name(id)
	return "qiangiq_poe2_node_" .. id
end

local function _widget_name(id)
	return "node_qiangiq-poe2-" .. id
end

local function _ids(text)
	local ids = {}

	for id in string.gmatch(text, "%d+") do
		ids[#ids + 1] = tonumber(id)
	end

	return ids
end

local function _buffs(text)
	local list = {}

	for stat, value in string.gmatch(text, "([%w_]+)=([^;]+)") do
		list[#list + 1] = { stat, tonumber(value) }
	end

	return list
end

local ROWS = {}
local LOC_TEXT = {}

do
	local rows = DATA.rows

	for i = 1, #rows do
		local line = rows[i]
		local fields = {}
		local start = 1

		while true do
			local tab = string.find(line, "\t", start, true)

			if not tab then
				fields[#fields + 1] = string.sub(line, start)

				break
			end

			fields[#fields + 1] = string.sub(line, start, tab - 1)
			start = tab + 1
		end

		local id = tonumber(fields[1])

		ROWS[i] = {
			id = id,
			kind = fields[2],
			x = tonumber(fields[3]),
			y = tonumber(fields[4]),
			parents = _ids(fields[5]),
			children = _ids(fields[6]),
			name = fields[7],
			buffs = _buffs(fields[9]),
			icon = fields[10] ~= "" and fields[10] or nil,
		}

		LOC_TEXT["loc_" .. _talent_name(id) .. "_name"] = fields[7]
		LOC_TEXT["loc_" .. _talent_name(id) .. "_desc"] = string.gsub(fields[8], "|", "\n")
	end
end

-- Only the part of the tree within RADIUS_PCT of the full radius is used, to
-- keep the node count playable (the full tree is ~4.5k widgets). Changing the
-- setting needs a restart because talents are registered at load.
-- The view is 1920 wide with the Veteran start node at x 975, y 263, so the
-- kept tree is moved to put its centre where the original start was, and the
-- view is scrolled to it when it opens.
local HUB_X, HUB_Y = DATA.hub_x, DATA.hub_y
local BACKGROUND_HEIGHT = DATA.background_height
local ORIGINAL_START_X, ORIGINAL_START_Y = 975, 263
local PAN_RANGE = 0
local HUB_RING = 150

do
	local pct = math.max(5, math.min(100, mod:get("tree_radius_v2") or 14)) / 100
	local max_dist = 0

	for i = 1, #ROWS do
		local dx, dy = ROWS[i].x - DATA.hub_x, ROWS[i].y - DATA.hub_y

		max_dist = math.max(max_dist, math.sqrt(dx * dx + dy * dy))
	end

	local limit = max_dist * pct
	local inside = {}

	for i = 1, #ROWS do
		local row = ROWS[i]
		local dx, dy = row.x - DATA.hub_x, row.y - DATA.hub_y

		if math.sqrt(dx * dx + dy * dy) <= limit then
			inside[row.id] = row
		end
	end

	-- Keep only what is still connected to a class start inside the circle.
	local reachable = {}
	local queue = {}

	for i = 1, #ROWS do
		local row = ROWS[i]

		if inside[row.id] and row.kind == "c" and #row.parents == 0 then
			reachable[row.id] = true
			queue[#queue + 1] = row
		end
	end

	local head = 1

	while head <= #queue do
		local row = queue[head]

		head = head + 1

		for _, list in ipairs({ row.children, row.parents }) do
			for _, id in ipairs(list) do
				if inside[id] and not reachable[id] then
					reachable[id] = true
					queue[#queue + 1] = inside[id]
				end
			end
		end
	end

	local kept = {}

	for i = 1, #ROWS do
		local row = ROWS[i]

		if reachable[row.id] then
			local parents, children = {}, {}

			for _, id in ipairs(row.parents) do
				if reachable[id] then
					parents[#parents + 1] = id
				end
			end

			for _, id in ipairs(row.children) do
				if reachable[id] then
					children[#children + 1] = id
				end
			end

			row.parents, row.children = parents, children
			kept[#kept + 1] = row
		end
	end

	ROWS = kept

	-- PoE2 nodes sit ~420 apart (median) against ~150 in the Veteran tree, so
	-- the layout is scaled down around its centre.
	local spacing = math.max(10, math.min(100, mod:get("node_spacing_v2") or 20)) / 100

	PAN_RANGE = limit * spacing + 600

	for i = 1, #kept do
		kept[i].x = DATA.hub_x + (kept[i].x - DATA.hub_x) * spacing
		kept[i].y = DATA.hub_y + (kept[i].y - DATA.hub_y) * spacing
	end

	local min_y, max_y = math.huge, -math.huge

	for i = 1, #kept do
		min_y = math.min(min_y, kept[i].y)
		max_y = math.max(max_y, kept[i].y)
	end

	local shift_x = ORIGINAL_START_X - DATA.hub_x
	local shift_y = ORIGINAL_START_Y - min_y

	for i = 1, #kept do
		kept[i].x = kept[i].x + shift_x
		kept[i].y = kept[i].y + shift_y
	end

	HUB_X = DATA.hub_x + shift_x
	HUB_Y = DATA.hub_y + shift_y
	BACKGROUND_HEIGHT = max_y + shift_y + ORIGINAL_START_Y
end

-- ####################################################################
-- Talents and buffs
-- ####################################################################

-- Same as QIangIQsZealotDeflect _append_lookup: new names go at the end so
-- every existing id keeps its index.
local function _append_lookup(lookup_name, name)
	local NetworkLookup = rawget(_G, "NetworkLookup") or require("scripts/network_lookup/network_lookup")
	local lookup = NetworkLookup[lookup_name]

	if not lookup then
		mod:error("NetworkLookup.%s is missing", lookup_name)

		return
	end

	if rawget(lookup, name) == nil then
		local index = #lookup + 1

		rawset(lookup, index, name)
		rawset(lookup, name, index)
	end
end

local function _value_scale()
	return (mod:get("value_scale") or 100) / 100
end

local function _scaled(stat, value, scale)
	if stat_buff_types[stat] == "multiplicative_multiplier" then
		return 1 + (value - 1) * scale
	end

	return value * scale
end

local function _fill_template(template, row, scale)
	local buffs = template.stat_buffs

	for key in pairs(buffs) do
		buffs[key] = nil
	end

	for i = 1, #row.buffs do
		local stat, value = row.buffs[i][1], row.buffs[i][2]
		local key = rawget(stat_buffs, stat)

		if key then
			buffs[key] = _scaled(stat, value, scale)
		else
			mod:error("Unknown stat buff %s on PoE2 node %d", tostring(stat), row.id)
		end
	end
end

local function _register()
	if state.registered then
		return
	end

	local ArchetypeTalents = require("scripts/settings/ability/archetype_talents/archetype_talents")
	local talents = ArchetypeTalents and ArchetypeTalents.veteran

	if not talents then
		mod:error("ArchetypeTalents.veteran is missing")

		return
	end

	local non_predicted = rawget(BuffTemplates, "NON_PREDICTED")
	local scale = _value_scale()

	-- ROWS are in file (id) order: every client appends the lookup names in
	-- the same order.
	for i = 1, #ROWS do
		local row = ROWS[i]
		local talent_name = _talent_name(row.id)
		local template_name = _template_name(row.id)
		local template = {
			class_name = "buff",
			name = template_name,
			predicted = false,
			stat_buffs = {},
		}

		_fill_template(template, row, scale)

		BuffTemplates[template_name] = template

		if non_predicted then
			non_predicted[template_name] = template_name
		end

		talents[talent_name] = {
			description = "loc_" .. talent_name .. "_desc",
			display_name = "loc_" .. talent_name .. "_name",
			icon = row.icon or ICON_STAT,
			name = talent_name,
			passive = {
				buff_template_name = template_name,
				identifier = template_name,
			},
		}

		_append_lookup("buff_templates", template_name)
		_append_lookup("archetype_talent_names", talent_name)
		_append_lookup("talent_node_names", _widget_name(row.id))
	end

	state.registered = true
end

-- A changed strength applies to buffs added from then on.
local function _refresh_templates()
	if not state.registered then
		return
	end

	local scale = _value_scale()

	for i = 1, #ROWS do
		local row = ROWS[i]
		local template = rawget(BuffTemplates, _template_name(row.id))

		if template then
			_fill_template(template, row, scale)
		end
	end
end

_register()

-- ####################################################################
-- Mode: which tree is in use
-- ####################################################################

-- QIangIQsLegacyTalents replaces layout.nodes when its legacy tree is on,
-- and keeps both tables in its toggle record (mode_toggle.lua). Same lookup
-- as QIangIQsMartyrdom _legacy_record.
local function _legacy_record()
	local legacy_mod = get_mod("QIangIQsLegacyTalents")

	if not legacy_mod then
		return nil
	end

	local legacy_state = legacy_mod:persistent_table("legacy_state")
	local toggle = legacy_state and legacy_state.toggle

	if not toggle or not toggle.tables then
		return nil
	end

	local layout = require(LAYOUT_PATH)

	for i = 1, toggle.count do
		if toggle.tables[i] == layout and toggle.keys[i] == "nodes" then
			return toggle, i
		end
	end

	return nil
end

local function _legacy_veteran_active()
	local toggle = _legacy_record()

	return toggle ~= nil and toggle.active == true
end

local function _official_nodes()
	local toggle, i = _legacy_record()

	if toggle then
		return toggle.vanilla[i]
	end

	return require(LAYOUT_PATH).nodes
end

-- Same host types as QIangIQsMartyrdom _wanted.
local function _wanted(host_type)
	if mod:get("tree_enabled") == false then
		return false
	end

	if host_type == "mission_server" then
		return false
	elseif host_type == "player" or host_type == "singleplay" or host_type == "singleplay_backend_session" then
		return true
	end

	-- hub_server, or no connection yet (main menu).
	return mod:get("tree_in_hub") ~= false
end

local function _is_active()
	return _wanted(state.host_type) and not _legacy_veteran_active()
end

-- ####################################################################
-- Tree (reversible)
-- ####################################################################

local function _build_nodes(official)
	local nodes = {}
	local hub = {}
	local start_node = nil

	for i = 1, #official do
		local node = official[i]

		if HUB_TYPES[node.type] then
			local copy = table.clone(node)

			hub[#hub + 1] = copy

			if node.type == "start" then
				start_node = copy
			end
		end
	end

	if not start_node then
		return nil
	end

	-- The nine hub nodes (grenades, coherency auras, combat abilities) form a
	-- ring around the start node, which sits at the centre of the PoE2 tree.
	-- Order: grenades, then auras, then abilities, each left to right, turned
	-- so the six class-start links pass between the ring nodes where possible.
	local ring = {}

	for i = 1, #hub do
		if hub[i] ~= start_node then
			ring[#ring + 1] = hub[i]
		end
	end

	local TYPE_ORDER = { tactical = 1, aura = 2, ability = 3 }

	table.sort(ring, function (a, b)
		local ta, tb = TYPE_ORDER[a.type] or 9, TYPE_ORDER[b.type] or 9

		if ta ~= tb then
			return ta < tb
		end

		return a.x < b.x
	end)

	local start_children = {}

	start_node.x = HUB_X
	start_node.y = HUB_Y
	start_node.parents = {}
	nodes[#nodes + 1] = start_node

	for i = 1, #ring do
		local node = ring[i]
		local angle = math.rad(-90 + 10 + (i - 1) * 360 / #ring)

		node.x = HUB_X + HUB_RING * math.cos(angle)
		node.y = HUB_Y + HUB_RING * math.sin(angle)
		node.parents = { start_node.widget_name }
		node.children = {}
		start_children[#start_children + 1] = node.widget_name
		nodes[#nodes + 1] = node
	end

	local requirements = {
		all_parents_chosen = false,
		children_unlock_points = 1,
		min_points_spent = 0,
	}

	for i = 1, #ROWS do
		local row = ROWS[i]
		local parents = {}
		local children = {}

		-- Every link works both ways, so the tree can be walked in any
		-- direction (the PoE2 data lists each link once, outward from the
		-- class starts).
		local seen = {}

		for _, list in ipairs({ row.parents, row.children }) do
			for _, id in ipairs(list) do
				if not seen[id] then
					seen[id] = true
					parents[#parents + 1] = _widget_name(id)
					children[#children + 1] = _widget_name(id)
				end
			end
		end

		if #row.parents == 0 and row.kind == "c" then
			parents[#parents + 1] = start_node.widget_name
			start_children[#start_children + 1] = _widget_name(row.id)
		end

		nodes[#nodes + 1] = {
			children = children,
			cost = 1,
			icon = row.icon or ICON_STAT,
			max_points = 1,
			parents = parents,
			requirements = table.clone(requirements),
			talent = _talent_name(row.id),
			type = NODE_TYPES[row.kind] or "stat",
			widget_name = _widget_name(row.id),
			x = row.x,
			y = row.y,
		}
	end

	start_node.children = start_children

	return nodes
end

local function _apply_tree()
	if state.saved then
		return
	end

	local layout = require(LAYOUT_PATH)
	local official = _official_nodes()

	if type(layout) ~= "table" or type(official) ~= "table" then
		return
	end

	local nodes = _build_nodes(official)

	if not nodes then
		mod:error("The Veteran tree has no start node, the PoE2 tree is not applied")

		return
	end

	state.saved = {
		background_height = layout.background_height,
		node_points = layout.node_points,
		nodes = layout.nodes,
		talent_points = layout.talent_points,
		version = layout.version,
	}

	layout.nodes = nodes
	layout.version = (layout.version or 0) + VERSION_OFFSET
	layout.background_height = BACKGROUND_HEIGHT
	layout.node_points = mod:get("tree_points_v2") or 90
end

local function _revert_tree()
	local saved = state.saved

	if not saved then
		return
	end

	local layout = require(LAYOUT_PATH)

	layout.nodes = saved.nodes
	layout.version = saved.version
	layout.background_height = saved.background_height
	layout.node_points = saved.node_points
	layout.talent_points = saved.talent_points

	state.saved = nil
end

local function _reset_localization_cache()
	local localization_manager = Managers.localization

	if localization_manager and localization_manager.reset_cache then
		localization_manager:reset_cache()
	end
end

local function _refresh_mode()
	if _is_active() then
		_apply_tree()
	else
		_revert_tree()
	end

	_refresh_templates()
	_reset_localization_cache()
end

local function _set_host_type(host_type)
	state.host_type = host_type

	_refresh_mode()
end

-- Same hooks as QIangIQsMartyrdom: the host type is known when the
-- connection is set, before profiles are synced.
mod:hook_require("scripts/managers/multiplayer/connection_manager", function (ConnectionManager)
	mod:hook(ConnectionManager, "set_connection_client", function (func, self, connection_client, ...)
		local ok, host_type = pcall(function ()
			return connection_client:host_type()
		end)

		if ok then
			_set_host_type(host_type)
		end

		return func(self, connection_client, ...)
	end)

	mod:hook(ConnectionManager, "set_connection_host", function (func, self, connection_host, ...)
		local ok, host_type = pcall(function ()
			return connection_host:host_type()
		end)

		if ok then
			_set_host_type(host_type)
		end

		return func(self, connection_host, ...)
	end)
end)

-- The view counts points against profile.talent_points in the player view
-- (talent_builder_view.lua _max_layout_points) and against the layout's
-- node_points otherwise (node_builder_view_base.lua). Both give the PoE2
-- point budget while this tree is shown.
local function _tree_shown(view)
	if not state.saved then
		return false
	end

	local layout = view.get_active_layout and view:get_active_layout()

	return layout ~= nil and layout == require(LAYOUT_PATH)
end

-- name -> node lookups. The stock lookups scan the whole node list, which
-- with ~4.5k nodes runs millions of steps per frame.
local node_maps = setmetatable({}, { __mode = "k" })

local function _node_map(layout)
	local nodes = layout.nodes
	local entry = node_maps[layout]

	if not entry or entry.nodes ~= nodes or entry.count ~= #nodes then
		local map = {}

		for i = 1, #nodes do
			map[nodes[i].widget_name] = nodes[i]
		end

		entry = { nodes = nodes, count = #nodes, map = map }
		node_maps[layout] = entry
	end

	return entry.map
end

-- The stock widget creation rebuilds the whole scenegraph once per node
-- (O(n^2)), which froze the game past the 15 s watchdog. Collect the
-- definitions first and build the scenegraph once before the first refresh.
local function _finish_deferred(self)
	if not self.__poe2_deferred then
		return
	end

	self.__poe2_deferred = nil
	self._add_scenegraph_definition = nil
	self._refresh_all_nodes = nil

	local UIScenegraph = require("scripts/managers/ui/ui_scenegraph")

	self._ui_scenegraph = UIScenegraph.init_scenegraph(self._definitions.scenegraph_definition, self._nodes_render_scale)
	self:apply_active_background_size()
	self:_force_update_scenegraph()
end

local function _hook_points(view_class)
	mod:hook(view_class, "_max_layout_points", function (func, self, ...)
		if _tree_shown(self) then
			return mod:get("tree_points_v2") or 90
		end

		return func(self, ...)
	end)

	mod:hook(view_class, "_create_node_widgets", function (func, self, ...)
		if not _tree_shown(self) then
			self._qiangiq_pan_owner = nil

			return func(self, ...)
		end

		-- QIangIQsScumHook also drags the talent view sideways, but only a
		-- little; it skips its own drag while this flag is set.
		self._qiangiq_pan_owner = "poe2"
		self._poe2_pan_base_x = nil
		self.__poe2_deferred = true
		self._add_scenegraph_definition = function (view, name, definition)
			view._definitions.scenegraph_definition[name] = definition
		end
		self._refresh_all_nodes = function (view, ...)
			_finish_deferred(view)

			return view:_refresh_all_nodes(...)
		end

		local ok, err = pcall(func, self, ...)

		_finish_deferred(self)

		if not ok then
			error(err)
		end

		-- Open on the centre of the tree, not the top edge.
		if self._scroll_to_height then
			local scale = Managers.ui:view_render_scale() * (self._current_zoom or 1)

			self:_scroll_to_height(-(HUB_Y - RESOLUTION_LOOKUP.height / scale * 0.5))
		end

		-- Diagnostics for the "blank tree" report: where things ended up.
		pcall(function ()
			local layout = self:get_active_layout()
			local start_name
			local min_x, max_x = math.huge, -math.huge

			for i = 1, #layout.nodes do
				local node = layout.nodes[i]

				min_x = math.min(min_x, node.x)
				max_x = math.max(max_x, node.x)

				if node.type == "start" then
					start_name = node.widget_name
				end
			end

			local world = start_name and self:_scenegraph_world_position(start_name)
			local _, bg_y = self:_scenegraph_position("layout_background")

			mod:info("tree opened: %d nodes, %d widgets, background_height %s, hub %s,%s, node x %s..%s, scrolled y %s, start node on screen at %s,%s (screen %sx%s, scale %s, player_mode %s, preview_player %s)", #layout.nodes, #self._node_widgets, tostring(layout.background_height), tostring(HUB_X), tostring(HUB_Y), tostring(min_x), tostring(max_x), tostring(bg_y), world and tostring(world[1]) or "?", world and tostring(world[2]) or "?", tostring(RESOLUTION_LOOKUP.width), tostring(RESOLUTION_LOOKUP.height), tostring(scale), tostring(self._player_mode), tostring(self._preview_player ~= nil))
		end)
	end)

	mod:hook(view_class, "_node_by_name", function (func, self, name)
		if _tree_shown(self) then
			return _node_map(self:get_active_layout())[name]
		end

		return func(self, name)
	end)

	mod:hook(view_class, "active_layout_node_by_name", function (func, self, name)
		if _tree_shown(self) then
			return _node_map(self:get_active_layout())[name]
		end

		return func(self, name)
	end)
end

-- Classes copy their parent's methods when they are created, so both the
-- base class and the Talent view are hooked.
mod:hook_require("scripts/ui/views/node_builder_view_base/node_builder_view_base", _hook_points)
mod:hook_require("scripts/ui/views/talent_builder_view/talent_builder_view", _hook_points)

-- Dragging sideways. The talent view is 1920 wide and only drags up and down
-- (node_builder_view_base.lua _handle_scenegraph_coordinates: "if not
-- self._player_mode then scenegraph_settings.x = final_x"). While the
-- background is dragged, the cursor's x difference is added to x, within
-- PAN_RANGE of where the tree opened. Same approach as QIangIQsScumHook
-- install_pan; both classes are hooked because class() copies methods.
local function _install_pan(view_class)
	mod:hook(view_class, "_handle_scenegraph_coordinates", function (func, self, widget_name, scenegraph_id, input_service, move_input_prefix, render_settings, is_background, ...)
		if self._poe2_panning or not (is_background and self._player_mode and _tree_shown(self)) then
			return func(self, widget_name, scenegraph_id, input_service, move_input_prefix, render_settings, is_background, ...)
		end

		self._poe2_panning = true

		local last = self._dragging_scenegraph_id == scenegraph_id and self._cursor_last_coordinates
		local last_x = last and last[1]
		local ok, handled, finalized = pcall(func, self, widget_name, scenegraph_id, input_service, move_input_prefix, render_settings, is_background, ...)

		self._poe2_panning = nil

		if not ok then
			error(handled, 0)
		end

		local saved = self._saved_scenegraph_settings
		local settings = saved and saved[scenegraph_id]

		if (self._poe2_pan_logs or 0) < 3 and last_x then
			self._poe2_pan_logs = (self._poe2_pan_logs or 0) + 1

			mod:info("pan drag: last_x %s, cursor x %s, settings x %s, range %s", tostring(last_x), tostring(self._cursor_current_coordinates and self._cursor_current_coordinates[1]), tostring(settings and settings.x), tostring(PAN_RANGE))
		end

		if settings then
			self._poe2_pan_base_x = self._poe2_pan_base_x or settings.x

			local current = self._cursor_current_coordinates

			if last_x and current and current[1] ~= last_x then
				local base_x = self._poe2_pan_base_x
				local diff_x = (current[1] - last_x) / self._nodes_render_scale

				settings.x = math.clamp(settings.x + diff_x, base_x - PAN_RANGE, base_x + PAN_RANGE)
			end
		end

		return handled, finalized
	end)
end

mod:hook_require("scripts/ui/views/node_builder_view_base/node_builder_view_base", _install_pan)
mod:hook_require("scripts/ui/views/talent_builder_view/talent_builder_view", _install_pan)

mod:hook(CLASS.LocalizationManager, "_lookup", function (func, self, key)
	local text = LOC_TEXT[key]

	if text then
		return text
	end

	return func(self, key)
end)

-- ####################################################################
-- Settings, load
-- ####################################################################

mod.on_setting_changed = function (setting_id)
	if setting_id == "tree_points_v2" and state.saved then
		require(LAYOUT_PATH).node_points = mod:get("tree_points_v2") or 90
	end

	_refresh_mode()
end

mod.on_all_mods_loaded = function ()
	_refresh_mode()

	if _legacy_veteran_active() then
		mod:warning("The legacy Veteran tree from QIangIQsLegacyTalents is on, so the PoE2 tree is off. Turn off its Veteran option to use the PoE2 tree.")
	end
end

_refresh_mode()

mod:command("poe2tree", mod:localize("command_description"), function ()
	mod:echo("PoE2 Veteran tree: %s (host type %s, tree edits %s, legacy Veteran tree %s)", _is_active() and "on" or "off", tostring(state.host_type), state.saved and "applied" or "not applied", _legacy_veteran_active() and "on" or "off")
end)
