-- QIangIQs Hitbox View 0.1.3
-- Hides each enemy and draws its real hit shapes in its place, coloured by the armour the game uses for that zone.
-- Client-side drawing only: hit detection, actors and networking are not changed.
--
-- Sources (game code, Aussiemon Darktide-Source-Code master):
--   hit zones / later zone owns an actor ...... scripts/utilities/attack/hit_zone.lua (HitZone.initialize_lookup)
--   live armour per zone ...................... scripts/utilities/attack/armor.lua (Armor.armor_type)
--   weakspots ................................. breed.hit_zone_weakspot_types (scripts/utilities/attack/weakspot.lua)
--   hiding a minion with its gear ............. Unit.set_unit_visibility(unit, false, true) (cutscene_minion_dissolve.lua)
--   slot visibility ........................... MinionVisualLoadoutExtension._set_slot_visibility
-- Shape sizes: QIangIQsHitboxView_shapes.lua, parsed from the PhysX actor records of each enemy base unit
-- (export_mod_shapes.py). Capsule axis is local +X with cylinder length h (PhysX half height h/2).
-- LineObject.add_capsule / add_sphere / Actor.debug_draw signatures: Fatshark DebugDrawer (debug_drawer.lua).

local mod = get_mod("QIangIQsHitboxView")

local Armor = require("scripts/utilities/attack/armor")

local SHAPES = mod:io_dofile("QIangIQsHitboxView/scripts/mods/QIangIQsHitboxView/QIangIQsHitboxView_shapes")

-- ---------------------------------------------------------------------------
-- Palette (EnemyStats colours, as used on the Havoc guide armour cards)
-- ---------------------------------------------------------------------------

local ARMOUR_RGB = {
	unarmored = { 90, 195, 90 },
	armored = { 215, 150, 50 },
	super_armor = { 150, 155, 175 },
	berserker = { 210, 70, 70 },
	resistant = { 160, 95, 195 },
	disgustingly_resilient = { 150, 185, 70 },
	void_shield = { 80, 165, 240 },
}
local FALLBACK_RGB = { 230, 230, 230 }
local GOLD = { 255, 210, 74 }
local SHIELD_RGB = { 80, 165, 240 }
local SHADE_LEVELS = 8

-- ---------------------------------------------------------------------------
-- Shape preparation: every shape becomes a mesh in its node's space
-- ---------------------------------------------------------------------------

local function _apply(m, x, y, z)
	return m[1] * x + m[2] * y + m[3] * z + m[4], m[5] * x + m[6] * y + m[7] * z + m[8], m[9] * x + m[10] * y + m[11] * z + m[12]
end

local function _add_edges(f)
	local seen, e = {}, {}

	for i = 1, #f, 3 do
		local a, b, c = f[i], f[i + 1], f[i + 2]

		for _, p in ipairs({ { a, b }, { b, c }, { c, a } }) do
			local lo, hi = math.min(p[1], p[2]), math.max(p[1], p[2])
			local key = lo * 65536 + hi

			if not seen[key] then
				seen[key] = true
				e[#e + 1] = lo
				e[#e + 1] = hi
			end
		end
	end

	return e
end

-- Low-poly capsule (radius r, cylinder length h along +X) or sphere (h = 0), outward triangles.
local function _tessellate(m, r, h, segments, cap_rings)
	local v, f = {}, {}
	local half = h * 0.5
	local rings = {}

	-- ring list from the -X pole to the +X pole: { x offset, ring radius }
	for i = cap_rings, 1, -1 do
		local a = (i / (cap_rings + 1)) * math.pi * 0.5
		rings[#rings + 1] = { -half - r * math.sin(a), r * math.cos(a) }
	end

	rings[#rings + 1] = { -half, r }

	if h > 0 then
		rings[#rings + 1] = { half, r }
	end

	for i = 1, cap_rings do
		local a = (i / (cap_rings + 1)) * math.pi * 0.5
		rings[#rings + 1] = { half + r * math.sin(a), r * math.cos(a) }
	end

	local function add(x, y, z)
		local wx, wy, wz = _apply(m, x, y, z)

		v[#v + 1] = wx
		v[#v + 1] = wy
		v[#v + 1] = wz

		return #v / 3
	end

	local pole_a = add(-half - r, 0, 0)
	local first = #v / 3 + 1

	for _, ring in ipairs(rings) do
		for s = 0, segments - 1 do
			local a = s / segments * math.pi * 2

			add(ring[1], ring[2] * math.cos(a), ring[2] * math.sin(a))
		end
	end

	local pole_b = add(half + r, 0, 0)
	local function idx(ring, s)
		return first + (ring - 1) * segments + (s % segments)
	end

	for s = 0, segments - 1 do
		f[#f + 1] = pole_a
		f[#f + 1] = idx(1, s + 1)
		f[#f + 1] = idx(1, s)
	end

	for ring = 1, #rings - 1 do
		for s = 0, segments - 1 do
			local a, b, c, d = idx(ring, s), idx(ring, s + 1), idx(ring + 1, s + 1), idx(ring + 1, s)

			f[#f + 1] = a
			f[#f + 1] = b
			f[#f + 1] = c
			f[#f + 1] = a
			f[#f + 1] = c
			f[#f + 1] = d
		end
	end

	for s = 0, segments - 1 do
		f[#f + 1] = pole_b
		f[#f + 1] = idx(#rings, s)
		f[#f + 1] = idx(#rings, s + 1)
	end

	return v, f
end

local function _orient_outward(v, f)
	local n = #v / 3
	local cx, cy, cz = 0, 0, 0

	for i = 1, n do
		cx, cy, cz = cx + v[i * 3 - 2], cy + v[i * 3 - 1], cz + v[i * 3]
	end

	cx, cy, cz = cx / n, cy / n, cz / n

	for i = 1, #f, 3 do
		local a, b, c = f[i] * 3, f[i + 1] * 3, f[i + 2] * 3
		local ux, uy, uz = v[b - 2] - v[a - 2], v[b - 1] - v[a - 1], v[b] - v[a]
		local wx, wy, wz = v[c - 2] - v[a - 2], v[c - 1] - v[a - 1], v[c] - v[a]
		local nx, ny, nz = uy * wz - uz * wy, uz * wx - ux * wz, ux * wy - uy * wx

		if nx * (v[a - 2] - cx) + ny * (v[a - 1] - cy) + nz * (v[a] - cz) < 0 then
			f[i + 1], f[i + 2] = f[i + 2], f[i + 1]
		end
	end
end

local prepared_units = 0

for _, actors in pairs(SHAPES) do
	prepared_units = prepared_units + 1

	for _, shapes in pairs(actors) do
		for _, s in ipairs(shapes) do
			if s.k == 2 then
				s.v, s.f = _tessellate(s.m, s.r, s.h, 6, 1)
				s.ax, s.ay, s.az = _apply(s.m, -s.h * 0.5, 0, 0)
				s.bx, s.by, s.bz = _apply(s.m, s.h * 0.5, 0, 0)
			elseif s.k == 3 then
				if not s.shell then
					s.v, s.f = _tessellate(s.m, s.r, 0, 6, 2)
				end

				s.ax, s.ay, s.az = _apply(s.m, 0, 0, 0)
			else
				_orient_outward(s.v, s.f)
			end

			if s.f and not s.e then
				s.e = _add_edges(s.f)
			end

			s.n = s.v and #s.v / 3 or 0
		end
	end
end

-- ---------------------------------------------------------------------------
-- State
-- ---------------------------------------------------------------------------

local tracked = {} -- unit -> record
local view_on = true
local warned_native = false
local native_failed = false
local solid_failed = false
local perf = { frames = 0, time = 0, max = 0, tris = 0, lines = 0, drawn = 0 }
local render = { world = nil, gui = nil, lines = nil, lines_top = nil }
local scratch = {}
local deferred_recs, deferred_entries = {}, {}

local settings = {}

local function _read_settings()
	settings.draw_mode = mod:get("draw_mode") or "solid"
	settings.far_enemies = mod:get("far_enemies") or "model"
	settings.hide_enemies = mod:get("hide_enemies") ~= false
	settings.hide_corpses = mod:get("hide_corpses") ~= false
	settings.weakspot_outline = mod:get("weakspot_outline") ~= false
	settings.show_void_shield = mod:get("show_void_shield") ~= false
	settings.max_distance = mod:get("max_distance") or 40
	settings.max_enemies = mod:get("max_enemies") or 30
	settings.fill_alpha = mod:get("fill_alpha") or 220
	settings.keep_weapons = mod:get("keep_weapons") or "maulers"
	settings.weakspot_on_top = mod:get("weakspot_on_top") ~= false
end

_read_settings()

local function _level_world()
	local world_manager = Managers.world

	if world_manager and world_manager:has_world("level_world") then
		return world_manager:world("level_world")
	end

	return nil
end

local function _ensure_render()
	local world = _level_world()

	if not world then
		return false
	end

	if render.world ~= world then
		-- old resources belong to a destroyed world; abandon them
		render.world, render.gui, render.lines, render.lines_top = world, nil, nil, nil
	end

	if not render.gui then
		local ok, gui = pcall(World.create_world_gui, world, Matrix4x4.identity(), 1, 1, "immediate")

		render.gui = ok and gui or nil
	end

	if not render.lines then
		local ok, lines = pcall(World.create_line_object, world)

		render.lines = ok and lines or nil
	end

	if not render.lines_top then
		-- second argument turns the depth test off; fall back to the normal object if refused
		local ok, lines = pcall(World.create_line_object, world, true)

		render.lines_top = ok and lines or render.lines
	end

	return render.gui ~= nil and render.lines ~= nil
end

local function _camera_pose()
	local camera_manager = Managers.state and Managers.state.camera
	local player = Managers.player and Managers.player:local_player(1)

	if not camera_manager or not player or not player.viewport_name then
		return nil
	end

	local ok, pose = pcall(camera_manager.camera_pose, camera_manager, player.viewport_name)

	return ok and pose or nil
end

-- ---------------------------------------------------------------------------
-- Visibility
-- ---------------------------------------------------------------------------

-- Breeds whose wielded weapon stays visible by default: the Scab Mauler and the Crusher, so their overheads can be read.
local WEAPON_BREEDS = {
	renegade_executor = true,
	chaos_ogryn_executor = true,
}

local function _keeps_weapon(rec)
	local keep = settings.keep_weapons

	if keep == "all" then
		return true
	elseif keep == "maulers" then
		return rec.breed ~= nil and WEAPON_BREEDS[rec.breed.name] == true
	end

	return false
end

local function _hide(rec)
	local unit = rec.unit

	if Unit.alive(unit) then
		Unit.set_unit_visibility(unit, false, true)

		-- keep the wielded weapon (is_weapon slot in the breed's visual loadout template) on a living enemy
		if rec.alive ~= false and _keeps_weapon(rec) then
			local slots = rec.ext and rec.ext._slots
			local inventory_slots = rec.ext and rec.ext._inventory and rec.ext._inventory.slots

			if slots and inventory_slots then
				for slot_name, slot_data in pairs(slots) do
					local template = inventory_slots[slot_name]
					local slot_unit = slot_data.unit

					if template and template.is_weapon and slot_data.state == "wielded" and slot_data.visible ~= false and slot_unit and Unit.alive(slot_unit) then
						Unit.set_unit_visibility(slot_unit, true, true)
					end
				end
			end
		end
	end

	rec.hidden = true
end

-- Restore the way the game left it: body on, each slot as its own visible flag says.
local function _show(rec)
	local unit = rec.unit

	if Unit.alive(unit) then
		Unit.set_unit_visibility(unit, true, false)

		local slots = rec.ext and rec.ext._slots

		if slots then
			for _, slot_data in pairs(slots) do
				local slot_unit = slot_data.unit

				if slot_unit and slot_data.state ~= "unequipped" and Unit.alive(slot_unit) then
					Unit.set_unit_visibility(slot_unit, slot_data.visible ~= false, true)
				end
			end
		end
	end

	rec.hidden = false
end

local function _set_hidden(rec, want_hidden, t)
	if want_hidden then
		-- re-apply every 0.5 s so newly wielded or equipped gear is hidden too
		if not rec.hidden or t >= rec.next_hide then
			_hide(rec)

			rec.next_hide = t + 0.5
		end
	elseif rec.hidden then
		_show(rec)
	end
end

-- ---------------------------------------------------------------------------
-- Tracking
-- ---------------------------------------------------------------------------

local function _build_entries(rec)
	local unit, breed, shapes = rec.unit, rec.breed, rec.shapes
	local ude = ScriptUnit.has_extension(unit, "unit_data_system")
	local entries, seen = {}, {}
	local hit_zones = breed.hit_zones

	if not ude or not hit_zones then
		rec.entries = entries

		return
	end

	for i = 1, #hit_zones do
		local actors = hit_zones[i].actors

		for j = 1, actors and #actors or 0 do
			local actor_name = actors[j]

			if not seen[actor_name] and shapes[actor_name] then
				seen[actor_name] = true

				local actor = Unit.actor(unit, actor_name)
				local zone = actor and ude:hit_zone(actor)

				if zone then
					entries[#entries + 1] = {
						actor = actor,
						node = Actor.node(actor),
						zone = zone.name,
						weakspot = breed.hit_zone_weakspot_types and breed.hit_zone_weakspot_types[zone.name] ~= nil,
						shell = zone.name == "captain_void_shield",
						shapes = shapes[actor_name],
					}
				end
			end
		end
	end

	rec.entries = entries
end

local function _register(unit, ext)
	if tracked[unit] or not unit then
		return
	end

	local ude = ScriptUnit.has_extension(unit, "unit_data_system")
	local breed = ude and ude:breed()
	local shapes = breed and breed.base_unit and SHAPES[breed.base_unit]

	tracked[unit] = {
		unit = unit,
		ext = ext,
		breed = breed,
		shapes = shapes,
		hidden = false,
		next_hide = 0,
		next_entries = 0,
		next_armour = 0,
		colours = {},
	}
end

local function _unregister(unit)
	tracked[unit] = nil
end

mod:hook_require("scripts/extension_systems/visual_loadout/minion_visual_loadout_extension", function (MinionVisualLoadoutExtension)
	mod:hook_safe(MinionVisualLoadoutExtension, "extensions_ready", function (self, world, unit)
		_register(unit, self)
	end)

	mod:hook(MinionVisualLoadoutExtension, "destroy", function (func, self, ...)
		_unregister(self._unit)

		return func(self, ...)
	end)

	local function rehide(self)
		local rec = tracked[self._unit]

		if rec and rec.hidden then
			_hide(rec)
		end
	end

	mod:hook_safe(MinionVisualLoadoutExtension, "_wield_slot", rehide)
	mod:hook_safe(MinionVisualLoadoutExtension, "_unwield_slot", rehide)
	mod:hook_safe(MinionVisualLoadoutExtension, "_set_slot_visibility", rehide)

	-- a dropped weapon is unlinked from the body: give it back its own visibility
	mod:hook_safe(MinionVisualLoadoutExtension, "_drop_slot", function (self, slot_name)
		local slot_data = self._slots and self._slots[slot_name]
		local slot_unit = slot_data and slot_data.unit

		if slot_unit and Unit.alive(slot_unit) then
			Unit.set_unit_visibility(slot_unit, slot_data.visible ~= false, true)
		end
	end)
end)

-- ---------------------------------------------------------------------------
-- Colours
-- ---------------------------------------------------------------------------

local function _zone_rgb(rec, zone_name)
	local ok, armour = pcall(Armor.armor_type, rec.unit, rec.breed, zone_name)

	return ok and ARMOUR_RGB[armour] or FALLBACK_RGB
end

local function _refresh_colours(rec, t)
	if t < rec.next_armour then
		return
	end

	rec.next_armour = t + 0.25

	local colours = rec.colours

	for i = 1, #rec.entries do
		local zone = rec.entries[i].zone

		colours[zone] = _zone_rgb(rec, zone)
	end
end

local function _shield_up(unit)
	local toughness = ScriptUnit.has_extension(unit, "toughness_system")

	return toughness and toughness:current_toughness_percent() > 0 or false
end

-- ---------------------------------------------------------------------------
-- Drawing
-- ---------------------------------------------------------------------------

local Gui_triangle = Gui.triangle
local LineObject_add_line = LineObject.add_line
local Unit_world_pose = Unit.world_pose
local Matrix4x4_translation = Matrix4x4.translation
local Matrix4x4_right = Matrix4x4.right
local Matrix4x4_forward = Matrix4x4.forward
local Matrix4x4_up = Matrix4x4.up
local sqrt = math.sqrt
local abs = math.abs
local floor = math.floor

local frame_colours = {}

local function _colour(rgb, level, alpha)
	local key = rgb[1] * 16777216 + rgb[2] * 65536 + rgb[3] * 256 + level * 2 + (alpha == 255 and 1 or 0)
	local c = frame_colours[key]

	if not c then
		local s = 0.4 + 0.6 * level / (SHADE_LEVELS - 1)

		c = Color(alpha, floor(rgb[1] * s), floor(rgb[2] * s), floor(rgb[3] * s))
		frame_colours[key] = c
	end

	return c
end

-- node pose -> scratch world vertices; returns the vertex count
local function _transform(s, px, py, pz, rx, ry, rz, fx, fy, fz, ux, uy, uz)
	local v, n = s.v, s.n

	for i = 1, n do
		local x, y, z = v[i * 3 - 2], v[i * 3 - 1], v[i * 3]

		scratch[i * 3 - 2] = px + rx * x + fx * y + ux * z
		scratch[i * 3 - 1] = py + ry * x + fy * y + uy * z
		scratch[i * 3] = pz + rz * x + fz * y + uz * z
	end

	return n
end

local function _draw_solid(gui, s, rgb, alpha, cx, cy, cz)
	local f, w = s.f, scratch
	local tris = 0

	for i = 1, #f, 3 do
		local a, b, c = f[i] * 3, f[i + 1] * 3, f[i + 2] * 3
		local ax, ay, az = w[a - 2], w[a - 1], w[a]
		local bx, by, bz = w[b - 2], w[b - 1], w[b]
		local qx, qy, qz = w[c - 2], w[c - 1], w[c]
		local ux, uy, uz = bx - ax, by - ay, bz - az
		local vx, vy, vz = qx - ax, qy - ay, qz - az
		local nx, ny, nz = uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx
		local dx, dy, dz = ax - cx, ay - cy, az - cz
		local facing = nx * dx + ny * dy + nz * dz

		if facing < 0 then
			-- headlight shading: faces turned toward the camera are brighter
			local nl = sqrt(nx * nx + ny * ny + nz * nz) * sqrt(dx * dx + dy * dy + dz * dz)
			local lit = nl > 0 and abs(facing) / nl or 1
			local level = floor(lit * (SHADE_LEVELS - 1) + 0.5)

			Gui_triangle(gui, Vector3(ax, ay, az), Vector3(bx, by, bz), Vector3(qx, qy, qz), 1, _colour(rgb, level, alpha))

			tris = tris + 1
		end
	end

	return tris
end

local function _draw_edges(lines, s, colour)
	local e, w = s.e, scratch

	for i = 1, #e, 2 do
		local a, b = e[i] * 3, e[i + 1] * 3

		LineObject_add_line(lines, colour, Vector3(w[a - 2], w[a - 1], w[a]), Vector3(w[b - 2], w[b - 1], w[b]))
	end

	return #e / 2
end

-- capsule / sphere outline with the engine primitive (one call per shape)
local function _draw_primitive(lines, s, colour, px, py, pz, rx, ry, rz, fx, fy, fz, ux, uy, uz)
	local a = Vector3(px + rx * s.ax + fx * s.ay + ux * s.az, py + ry * s.ax + fy * s.ay + uy * s.az, pz + rz * s.ax + fz * s.ay + uz * s.az)

	if s.k == 2 then
		local b = Vector3(px + rx * s.bx + fx * s.by + ux * s.bz, py + ry * s.bx + fy * s.by + uy * s.bz, pz + rz * s.bx + fz * s.by + uz * s.bz)

		LineObject.add_capsule(lines, colour, a, b, s.r)
	else
		LineObject.add_sphere(lines, colour, a, s.r, 12, 2)
	end

	return 1
end

local function _far_first(a, b)
	return a.depth > b.depth
end

local function _draw_unit(rec, mode, cx, cy, cz, camera_pose)
	local gui, lines = render.gui, render.lines
	local unit = rec.unit
	local alpha = settings.fill_alpha
	local outline = settings.weakspot_outline
	local gold = Color(255, GOLD[1], GOLD[2], GOLD[3])
	local tris, nlines = 0, 0
	local entries = rec.entries

	-- "Weakspots only": the enemy keeps its normal model; only its weakspot shapes are queued for the
	-- gold wireframe pass (_draw_weakspot), nothing else is drawn.
	if mode == "weakspots" then
		for i = 1, #entries do
			local entry = entries[i]

			if entry.weakspot and not entry.shell then
				local n = #deferred_recs + 1

				entry.pose = nil
				deferred_recs[n] = rec
				deferred_entries[n] = entry
			end
		end

		return 0, 0
	end

	-- The world gui has no depth test: triangles land in the order they are sent, so send far shapes first
	-- (painter's order). Enemies are already sent far to near; here the actors of one enemy are sorted too.
	for i = 1, #entries do
		local entry = entries[i]

		if not entry.shell then
			local pose = Unit_world_pose(unit, entry.node)
			local p = Matrix4x4_translation(pose)
			local dx, dy, dz = p.x - cx, p.y - cy, p.z - cz

			entry.pose = pose
			entry.depth = dx * dx + dy * dy + dz * dz
		else
			entry.pose = nil
			entry.depth = -1
		end
	end

	table.sort(entries, _far_first)

	for i = 1, #entries do
		local entry = entries[i]

		if entry.shell then
			if settings.show_void_shield and _shield_up(unit) then
				local ok, centre = pcall(Actor.world_bounds, entry.actor)

				if ok and centre then
					LineObject.add_sphere(lines, Color(160, SHIELD_RGB[1], SHIELD_RGB[2], SHIELD_RGB[3]), centre, entry.shapes[1].r, 24, 3)

					nlines = nlines + 1
				end
			end
		elseif entry.weakspot and settings.weakspot_on_top then
			-- drawn after every enemy, outline without depth test: see _draw_weakspot
			local n = #deferred_recs + 1

			deferred_recs[n] = rec
			deferred_entries[n] = entry
		else
			local rgb = rec.colours[entry.zone] or FALLBACK_RGB

			if mode == "native" and not native_failed then
				local colour = entry.weakspot and outline and gold or Color(255, rgb[1], rgb[2], rgb[3])
				local ok = pcall(Actor.debug_draw, entry.actor, lines, colour, camera_pose)

				if ok then
					nlines = nlines + 1
				else
					native_failed = true

					if not warned_native then
						warned_native = true

						mod:echo("Engine outlines are not available in this build; using wireframe instead.")
					end
				end
			else
				local pose = entry.pose
				local p, r, f, u = Matrix4x4_translation(pose), Matrix4x4_right(pose), Matrix4x4_forward(pose), Matrix4x4_up(pose)
				local px, py, pz = p.x, p.y, p.z
				local rx, ry, rz = r.x, r.y, r.z
				local fx, fy, fz = f.x, f.y, f.z
				local ux, uy, uz = u.x, u.y, u.z
				local shapes = entry.shapes

				for k = 1, #shapes do
					local s = shapes[k]

					if mode == "solid" then
						_transform(s, px, py, pz, rx, ry, rz, fx, fy, fz, ux, uy, uz)

						tris = tris + _draw_solid(gui, s, rgb, alpha, cx, cy, cz)

						if entry.weakspot and outline then
							if s.k == 1 then
								nlines = nlines + _draw_edges(lines, s, gold)
							else
								nlines = nlines + _draw_primitive(lines, s, gold, px, py, pz, rx, ry, rz, fx, fy, fz, ux, uy, uz)
							end
						end
					else
						local colour = entry.weakspot and outline and gold or Color(255, rgb[1], rgb[2], rgb[3])

						if s.k == 1 then
							_transform(s, px, py, pz, rx, ry, rz, fx, fy, fz, ux, uy, uz)

							nlines = nlines + _draw_edges(lines, s, colour)
						else
							nlines = nlines + _draw_primitive(lines, s, colour, px, py, pz, rx, ry, rz, fx, fy, fz, ux, uy, uz)
						end
					end
				end
			end
		end
	end

	return tris, nlines
end

-- Weakspots on top: after all enemies are drawn, fill each weakspot again (so it covers bodies drawn
-- before it) and outline it in gold on a line object created with depth test off
-- (World.create_line_object(world, true), as BackstabHitboxDisplay does for its head markers),
-- so the outline shows through enemies, their own back and walls.
local function _draw_weakspot(rec, entry, mode, cx, cy, cz, camera_pose)
	local gui, top = render.gui, render.lines_top
	local gold = Color(255, GOLD[1], GOLD[2], GOLD[3])
	local tris, nlines = 0, 0

	if mode == "weakspots" then
		-- wireframe only; through walls only when "Weakspots on top" is on
		mode = "wire"

		if not settings.weakspot_on_top then
			top = render.lines
		end
	end

	if mode == "native" then
		if pcall(Actor.debug_draw, entry.actor, top, gold, camera_pose) then
			return 0, 1
		end

		mode = "wire"
	end

	local pose = entry.pose or Unit_world_pose(rec.unit, entry.node)
	local p, r, f, u = Matrix4x4_translation(pose), Matrix4x4_right(pose), Matrix4x4_forward(pose), Matrix4x4_up(pose)
	local px, py, pz = p.x, p.y, p.z
	local rx, ry, rz = r.x, r.y, r.z
	local fx, fy, fz = f.x, f.y, f.z
	local ux, uy, uz = u.x, u.y, u.z
	local rgb = rec.colours[entry.zone] or FALLBACK_RGB
	local shapes = entry.shapes

	for k = 1, #shapes do
		local s = shapes[k]

		if s.k == 1 or mode == "solid" then
			_transform(s, px, py, pz, rx, ry, rz, fx, fy, fz, ux, uy, uz)
		end

		if mode == "solid" then
			tris = tris + _draw_solid(gui, s, rgb, settings.fill_alpha, cx, cy, cz)
		end

		if s.k == 1 then
			nlines = nlines + _draw_edges(top, s, gold)
		else
			nlines = nlines + _draw_primitive(top, s, gold, px, py, pz, rx, ry, rz, fx, fy, fz, ux, uy, uz)
		end
	end

	return tris, nlines
end

-- ---------------------------------------------------------------------------
-- Update
-- ---------------------------------------------------------------------------

local candidates = {}
local function _by_distance(a, b)
	return a.dist < b.dist
end

local function _restore_all()
	for _, rec in pairs(tracked) do
		if rec.hidden then
			pcall(_show, rec)
		end
	end
end

local function _clear_lines()
	if render.world and render.lines then
		pcall(function ()
			LineObject.reset(render.lines)
			LineObject.dispatch(render.world, render.lines)

			if render.lines_top and render.lines_top ~= render.lines then
				LineObject.reset(render.lines_top)
				LineObject.dispatch(render.world, render.lines_top)
			end
		end)
	end
end

local function _gameplay_time()
	local time_manager = Managers.time

	if time_manager and time_manager:has_timer("gameplay") then
		return time_manager:time("gameplay")
	end

	return nil
end

mod.update = function (dt)
	if not view_on or not mod:is_enabled() then
		return
	end

	local t = _gameplay_time()

	if not t or not _ensure_render() then
		return
	end

	local camera_pose = _camera_pose()

	if not camera_pose then
		return
	end

	local clock = os.clock()
	local cam = Matrix4x4.translation(camera_pose)
	local cam_fwd = Matrix4x4.forward(camera_pose)
	local cx, cy, cz = cam.x, cam.y, cam.z
	local fwx, fwy, fwz = cam_fwd.x, cam_fwd.y, cam_fwd.z
	local max_d2 = settings.max_distance * settings.max_distance
	local health_alive = rawget(_G, "HEALTH_ALIVE")

	table.clear(candidates)
	table.clear(frame_colours)

	for unit, rec in pairs(tracked) do
		if not Unit.alive(unit) then
			tracked[unit] = nil
		elseif rec.shapes then
			local alive = not health_alive or health_alive[unit] ~= nil

			rec.drawn = false

			if alive then
				local pos = Unit.world_position(unit, 1)
				local dx, dy, dz = pos.x - cx, pos.y - cy, pos.z - cz
				local d2 = dx * dx + dy * dy + dz * dz

				-- in range and not well behind the camera (2 m slack so close enemies are kept)
				if d2 <= max_d2 and (dx * fwx + dy * fwy + dz * fwz > -2) then
					rec.dist = d2
					candidates[#candidates + 1] = rec
				end
			end

			if rec.alive ~= alive then
				rec.next_hide = 0
			end

			rec.alive = alive
		end
	end

	table.sort(candidates, _by_distance)

	local mode = settings.draw_mode

	if mode == "native" and native_failed or mode == "solid" and solid_failed then
		mode = "wire"
	end

	local lines, top = render.lines, render.lines_top

	LineObject.reset(lines)

	if top ~= lines then
		LineObject.reset(top)
	end

	table.clear(deferred_recs)
	table.clear(deferred_entries)

	local tris, nlines, drawn = 0, 0, 0

	-- candidates are sorted near to far; keep the nearest max_enemies and draw them far to near
	for i = math.min(#candidates, settings.max_enemies), 1, -1 do
		local rec = candidates[i]

		if not rec.entries or t >= rec.next_entries then
			_build_entries(rec)

			rec.next_entries = t + 1
		end

		_refresh_colours(rec, t)

		local ok, a, b = pcall(_draw_unit, rec, mode, cx, cy, cz, camera_pose)

		if ok then
			tris, nlines = tris + a, nlines + b
		elseif mode == "solid" and not solid_failed then
			-- the filled path uses the world gui; if the engine refuses it, keep going with outlines
			solid_failed = true

			mod:echo("Solid drawing failed (" .. tostring(a) .. "); using wireframe instead.")
		end

		rec.drawn = true
		drawn = drawn + 1
	end

	-- weakspots last, in the same far-to-near order they were collected
	for i = 1, #deferred_recs do
		local ok, a, b = pcall(_draw_weakspot, deferred_recs[i], deferred_entries[i], mode, cx, cy, cz, camera_pose)

		if ok then
			tris, nlines = tris + a, nlines + b
		end
	end

	LineObject.dispatch(render.world, lines)

	if top ~= lines then
		LineObject.dispatch(render.world, top)
	end

	-- visibility after drawing so the set of drawn enemies is known
	local hide_models = settings.hide_enemies and mode ~= "weakspots"
	local far_hidden = settings.far_enemies == "hidden"

	for _, rec in pairs(tracked) do
		if rec.shapes then
			local want

			if not rec.alive then
				want = hide_models and settings.hide_corpses
			elseif rec.drawn then
				want = hide_models
			else
				want = hide_models and far_hidden
			end

			_set_hidden(rec, want, t)
		end
	end

	local spent = os.clock() - clock

	perf.frames = perf.frames + 1
	perf.time = perf.time + spent
	perf.max = math.max(perf.max, spent)
	perf.tris, perf.lines, perf.drawn = tris, nlines, drawn
end

mod.toggle_view = function ()
	view_on = not view_on

	if not view_on then
		_restore_all()
		_clear_lines()
	end

	mod:echo(view_on and "Hitbox view on" or "Hitbox view off")
end

mod.on_setting_changed = function ()
	_read_settings()

	native_failed = false
	solid_failed = false
end

mod.on_disabled = function ()
	_restore_all()
	_clear_lines()
end

mod.on_unload = function ()
	_restore_all()
end

mod.on_game_state_changed = function (status, state_name)
	if state_name == "StateGameplay" then
		table.clear(tracked)

		render.world, render.gui, render.lines, render.lines_top = nil, nil, nil, nil
	end
end

mod:command("hbv_info", "QIangIQs Hitbox View: list tracked enemies and their hit zones", function ()
	local count, with_shapes, hidden = 0, 0, 0
	local per_breed = {}

	for _, rec in pairs(tracked) do
		count = count + 1

		if rec.shapes then
			with_shapes = with_shapes + 1
		end

		if rec.hidden then
			hidden = hidden + 1
		end

		local name = rec.breed and rec.breed.name or "?"

		per_breed[name] = (per_breed[name] or 0) + 1
	end

	mod:echo(string.format("tracked %d, with shape data %d, hidden %d, shape units loaded %d", count, with_shapes, hidden, prepared_units))

	for name, n in pairs(per_breed) do
		mod:echo(string.format("  %s x%d", name, n))
	end
end)

mod:command("hbv_perf", "QIangIQs Hitbox View: drawing cost since the last call", function ()
	if perf.frames == 0 then
		mod:echo("No frames drawn yet.")

		return
	end

	mod:echo(string.format("%d frames: avg %.2f ms, max %.2f ms per frame; last frame %d enemies, %d triangles, %d lines (mode %s)", perf.frames, perf.time / perf.frames * 1000, perf.max * 1000, perf.drawn, perf.tris, perf.lines, settings.draw_mode))

	perf.frames, perf.time, perf.max = 0, 0, 0
end)
