local mod = get_mod("QIangIQsHitboxView")

local function checkbox(id, default)
	return { setting_id = id, type = "checkbox", default_value = default, tooltip = id .. "_tooltip" }
end

local function numeric(id, default, low, high)
	return { setting_id = id, type = "numeric", default_value = default, range = { low, high }, tooltip = id .. "_tooltip" }
end

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			{
				setting_id = "toggle_key",
				type = "keybind",
				default_value = {},
				keybind_trigger = "pressed",
				keybind_type = "function_call",
				function_name = "toggle_view",
				tooltip = "toggle_key_tooltip",
			},
			{
				setting_id = "draw_mode",
				type = "dropdown",
				default_value = "solid",
				tooltip = "draw_mode_tooltip",
				options = {
					{ text = "mode_solid", value = "solid" },
					{ text = "mode_wire", value = "wire" },
					{ text = "mode_native", value = "native" },
					{ text = "mode_weakspots", value = "weakspots" },
				},
			},
			{
				setting_id = "far_enemies",
				type = "dropdown",
				default_value = "model",
				tooltip = "far_enemies_tooltip",
				options = {
					{ text = "far_model", value = "model" },
					{ text = "far_hidden", value = "hidden" },
				},
			},
			{
				setting_id = "keep_weapons",
				type = "dropdown",
				default_value = "maulers",
				tooltip = "keep_weapons_tooltip",
				options = {
					{ text = "keep_maulers", value = "maulers" },
					{ text = "keep_all", value = "all" },
					{ text = "keep_none", value = "none" },
				},
			},
			checkbox("hide_enemies", true),
			checkbox("hide_corpses", true),
			checkbox("weakspot_outline", true),
			checkbox("weakspot_on_top", true),
			checkbox("show_void_shield", true),
			numeric("max_distance", 40, 5, 150),
			numeric("max_enemies", 30, 1, 200),
			numeric("fill_alpha", 220, 30, 255),
		},
	},
}
