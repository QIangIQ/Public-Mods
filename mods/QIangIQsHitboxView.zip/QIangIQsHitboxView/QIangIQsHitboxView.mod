return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsHitboxView` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsHitboxView", {
			mod_script       = "QIangIQsHitboxView/scripts/mods/QIangIQsHitboxView/QIangIQsHitboxView",
			mod_data         = "QIangIQsHitboxView/scripts/mods/QIangIQsHitboxView/QIangIQsHitboxView_data",
			mod_localization = "QIangIQsHitboxView/scripts/mods/QIangIQsHitboxView/QIangIQsHitboxView_localization",
		})
	end,
	packages = {},
}
