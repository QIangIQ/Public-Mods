local loc = {
    mod_name = { en = "QIangIQ's Makima Bean" },
    mod_description = {
        en = "Shows the Makima bean plushie (Custom Assets) in place of the Zealot's holy relic (Chorus of Spiritual Fortitude / Ecclesiarch's Call) and the Veteran's Krak Grenade, in hand and when thrown. Your own character only. By QIangIQ.",
    },
    relic_group = { en = "Zealot holy relic (Chorus / Ecclesiarch's Call)" },
    krak_group = { en = "Veteran Krak Grenade (in hand)" },
    krak_thrown_group = { en = "Veteran Krak Grenade (thrown)" },
}

for _, prefix in ipairs({ "relic", "krak", "krak_thrown" }) do
    loc[prefix .. "_enabled"] = { en = "Replace with plushie" }
    loc[prefix .. "_size"] = { en = "Size (x original item size)" }
    loc[prefix .. "_yaw"] = { en = "Turn (degrees)" }
    loc[prefix .. "_pitch"] = { en = "Tilt forward/back (degrees)" }
    loc[prefix .. "_roll"] = { en = "Tilt sideways (degrees)" }
end

return loc
