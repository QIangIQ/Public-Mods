return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsMakimaBean` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsMakimaBean", {
            mod_script = "QIangIQsMakimaBean/scripts/mods/QIangIQsMakimaBean/QIangIQsMakimaBean",
            mod_data = "QIangIQsMakimaBean/scripts/mods/QIangIQsMakimaBean/QIangIQsMakimaBean_data",
            mod_localization = "QIangIQsMakimaBean/scripts/mods/QIangIQsMakimaBean/QIangIQsMakimaBean_localization",
        })
    end,
    version = "1.1.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
