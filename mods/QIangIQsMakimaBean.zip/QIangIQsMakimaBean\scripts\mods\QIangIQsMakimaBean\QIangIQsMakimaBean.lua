-- QIangIQ's Makima Bean: shows a Custom Assets plushie in place of the Zealot's holy relic
-- (weapon template zealot_relic: Chorus of Spiritual Fortitude / Ecclesiarch's Call) and the
-- Veteran's Krak Grenade (weapon template krak_grenade, projectile template krak_grenade).
-- Your own character only. Author: QIangIQ
local mod = get_mod("QIangIQsMakimaBean")

-- Cross-client sync ---------------------------------------------------------------
-- QIangIQsModelSync publishes which QIangIQ replacer mods a player has on, with their options, through
-- Vox Manifold (the transport Dio's Wardrobe shares outfits with). No asset data is sent: every client shows
-- the model from its own installed files. While another player's unit is worked on, sync_ctx holds that
-- player's options and opt() answers from them; for my own unit opt() is mod:get().
local SYNC_KEY = "mb"
local SYNC_BOOLS = { "relic_enabled", "krak_enabled" }
local SYNC_DEFAULTS = { relic_enabled = true, krak_enabled = true }
local SYNC_VALUES = { "relic_size", "relic_yaw", "relic_pitch", "relic_roll", "krak_size", "krak_yaw", "krak_pitch", "krak_roll" }
local SYNC_LAYOUT = #SYNC_BOOLS * 100 + #SYNC_VALUES -- a peer on another version of this mod is not decoded
local sync_ctx = nil
local sync_known = setmetatable({}, { __mode = "k" })   -- other players' extensions this mod has shown something on
local sync_all = setmetatable({}, { __mode = "k" })     -- every visual loadout extension seen
local sync_decoded = setmetatable({}, { __mode = "k" }) -- published array -> options table
local SYNC_FALSE = { __index = function() return false end }
local SYNC_OFF = setmetatable({}, SYNC_FALSE)           -- "everything off": removes what was shown
local sync_extra_import = nil

local function opt(key)
    if sync_ctx then
        return sync_ctx[key]
    end
    return mod:get(key)
end

local function sync_api()
    local hub = get_mod("QIangIQsModelSync")
    return hub and hub.api
end

local function sync_me()
    local players = Managers.player
    if not players then
        return nil
    end
    local ok, player = pcall(players.local_player_safe, players, 1)
    return ok and player or nil
end

-- published array { layout, checkbox bits, value, value, ... [, extra] } -> options by setting id
local function sync_decode(raw)
    local t = sync_decoded[raw]
    if t ~= nil then
        return t
    end
    t = false
    if type(raw) == "table" and raw[1] == SYNC_LAYOUT then
        t = setmetatable({}, SYNC_FALSE)
        local mask = tonumber(raw[2]) or 0
        for i = 1, #SYNC_BOOLS do
            t[SYNC_BOOLS[i]] = mask % 2 >= 1
            mask = math.floor(mask / 2)
        end
        for i = 1, #SYNC_VALUES do
            local v = raw[2 + i]
            if v ~= nil then
                t[SYNC_VALUES[i]] = v
            end
        end
        if sync_extra_import then
            sync_extra_import(t, raw[3 + #SYNC_VALUES])
        end
    end
    sync_decoded[raw] = t
    return t
end

-- whose options apply to this extension: nil = mine, a table = that player's (SYNC_OFF when they publish
-- nothing for this mod)
local function sync_owner(ext)
    sync_all[ext] = true
    local player = ext._player
    if player == nil or player == sync_me() then
        return nil
    end
    local api = sync_api()
    local raw = api and api.peer(SYNC_KEY, player)
    local state = raw and sync_decode(raw)
    if state then
        sync_known[ext] = true
        return state
    end
    return SYNC_OFF
end

-- my own unit, or another player's unit this mod is (or was) showing something on
local function sync_shown(ext)
    local player = ext._player
    return player ~= nil and (player == sync_me() or sync_known[ext] == true)
end

local function sync_pack(...)
    return { n = select("#", ...), ... }
end

-- runs a hook body with the options of the extension's owner
local function sync_wrap(fn, ext_index)
    return function(...)
        local ext = select(ext_index, ...)
        local previous = sync_ctx
        sync_ctx = sync_owner(ext)
        local results = sync_pack(pcall(fn, ...))
        sync_ctx = previous
        if not results[1] then
            error(results[2], 0)
        end
        return unpack(results, 2, results.n)
    end
end

-- The same hook on my own unit's extension and on other players' (husk) extensions. While the mods load, the
-- classes do not exist yet: CLASS.<name> is then only the name and DMF delays the hook ("needs to be delayed"
-- in the log), so the husk class cannot be inspected here. Its methods are taken from
-- player_husk_visual_loadout_extension.lua instead.
local SYNC_HUSK_METHODS = { init = true, update = true, _update_item_visibility = true, destroy = true }

local function vl_hook_safe(method, fn)
    mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, method, sync_wrap(fn, 1))
    if SYNC_HUSK_METHODS[method] then
        mod:hook_safe(CLASS.PlayerHuskVisualLoadoutExtension, method, sync_wrap(fn, 1))
    end
end

local function vl_hook(method, fn)
    mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, method, sync_wrap(fn, 2))
    if SYNC_HUSK_METHODS[method] then
        mod:hook(CLASS.PlayerHuskVisualLoadoutExtension, method, sync_wrap(fn, 2))
    elseif method == "_unequip_item_from_slot" then
        -- a husk has no _unequip_item_from_slot: its unequip arrives as rpc_player_unequip_item_from_slot
        -- (self, channel_id, go_id, slot_id), slot name = NetworkLookup.player_inventory_slot_names[slot_id]
        -- (player_husk_visual_loadout_extension.lua)
        mod:hook(CLASS.PlayerHuskVisualLoadoutExtension, "rpc_player_unequip_item_from_slot", sync_wrap(function(func, self, channel_id, go_id, slot_id, ...)
            local NetworkLookup = require("scripts/network_lookup/network_lookup")
            local slot_name = NetworkLookup.player_inventory_slot_names[slot_id]
            return fn(function()
                return func(self, channel_id, go_id, slot_id)
            end, self, slot_name)
        end, 2))
    end
end
-- ----------------------------------------------------------------------------------

mod.AUTHOR = "QIangIQ"

local BEAN_ID = "QIangIQsMakimaBean:makima_bean"
local BEAN_UNIT = "content/mods/qiangiq_makima_bean/makima_bean"
-- The compiled plushie is 1 unit tall (Z), centred on its own bounding box, face towards -Y.

-- item.weapon_template -> settings prefix (names from weapon_templates.lua)
local HELD = {
    zealot_relic = "relic",
    krak_grenade = "krak",
}
-- ProjectileTemplates name -> settings prefix (player_projectile_templates.lua)
local THROWN = {
    krak_grenade = "krak_thrown",
}
local FIT_FRAMES = 10

local custom_assets = nil
local ready = false
local tracked = setmetatable({}, { __mode = "k" })
local tracked_proj = setmetatable({}, { __mode = "k" })

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function local_player()
    local players = Managers.player
    if not players then
        return nil
    end
    local ok, player = pcall(players.local_player_safe, players, 1)
    return ok and player or nil
end

local function on(prefix)
    return ready and opt(prefix .. "_enabled") and true or false
end

local function spawn_bean(parent, is_first_person)
    local unit_spawner = Managers.state and Managers.state.unit_spawner
    if not (unit_spawner and unit_ok(parent)) then
        return nil
    end
    local unit = unit_spawner:spawn_unit(BEAN_UNIT, Unit.world_pose(parent, 1))
    if not unit then
        return nil
    end
    if is_first_person then
        Unit.set_unit_culling(unit, false)
        -- same flag the game sets on first-person items (equipment_component.lua)
        Unit.set_shader_pass_flag_for_meshes_in_unit_and_childs(unit, "custom_fov", true)
    end
    return unit
end

local function delete_unit(unit)
    if unit_ok(unit) then
        local unit_spawner = Managers.state and Managers.state.unit_spawner
        if unit_spawner then
            unit_spawner:mark_for_deletion(unit)
        end
    end
end

-- the largest bounding box among the candidate units is the visible item
local function biggest_box(units)
    local best_len, best_unit, best_pose, best_ext = 0, nil, nil, nil
    for i = 1, #units do
        local unit = units[i]
        if unit_ok(unit) then
            local pose, half_extents = Unit.box(unit)
            if pose and half_extents then
                local len = math.max(half_extents.x, half_extents.y, half_extents.z)
                if len > best_len then
                    best_len, best_unit, best_pose, best_ext = len, unit, pose, half_extents
                end
            end
        end
    end
    return best_unit, best_pose, best_len
end

-- links the bean to `parent` node 1 with its centre on the box centre, scaled to the box
local function fit(world, bean, parent, pose, max_half, prefix)
    local center = Matrix4x4.translation(pose)
    local origin = Unit.world_position(parent, 1)
    local rot = Unit.world_rotation(parent, 1)
    local bx, by, bz = Quaternion.right(rot), Quaternion.forward(rot), Quaternion.up(rot)
    local d = center - origin
    local parent_scale = Unit.local_scale(parent, 1)
    local k = parent_scale and parent_scale.x or 1
    if k <= 0 then
        k = 1
    end
    local size = 2 * max_half * (opt(prefix .. "_size") or 1)
    local s = size / k
    local yaw = math.rad(opt(prefix .. "_yaw") or 0)
    local pitch = math.rad(opt(prefix .. "_pitch") or 0)
    local roll = math.rad(opt(prefix .. "_roll") or 0)
    Unit.set_local_position(bean, 1, Vector3(Vector3.dot(d, bx), Vector3.dot(d, by), Vector3.dot(d, bz)) * (1 / k))
    Unit.set_local_rotation(bean, 1, Quaternion.from_yaw_pitch_roll(yaw, pitch, roll))
    Unit.set_local_scale(bean, 1, Vector3(s, s, s))
end

local function hide_all(units)
    for i = 1, #units do
        if unit_ok(units[i]) then
            Unit.set_unit_visibility(units[i], false, true)
        end
    end
end

-- Held items (your own player unit) --------------------------------------------

local function clear_rec(rec, restore)
    delete_unit(rec.bean)
    if restore and rec.hid and unit_ok(rec.base) then
        -- recursive visibility also covers the item's linked attachments
        Unit.set_unit_visibility(rec.base, true, true)
    end
end

local function sync_slot(ext, records, key, slot, view)
    local base = view == "1p" and slot.unit_1p or slot.unit_3p
    local att_tab = view == "1p" and slot.attachments_by_unit_1p or slot.attachments_by_unit_3p
    local attachments = base and att_tab and att_tab[base]
    local item = slot.item
    local prefix = item and item.weapon_template and HELD[item.weapon_template]
    local visible = (view == "1p" and slot.hidden_1p == false) or (view == "3p" and slot.hidden_3p == false)
    local want = prefix ~= nil and on(prefix) and unit_ok(base)

    local units = {}
    if want then
        units[1] = base
        if attachments then
            for i = 1, #attachments do
                units[#units + 1] = attachments[i]
            end
        end
    end

    local rec = records[key]
    if rec and (not want or rec.base ~= base or not unit_ok(rec.bean)) then
        clear_rec(rec, visible)
        records[key] = nil
        rec = nil
    end
    if not want then
        return
    end

    if not rec then
        local parent, pose, max_half = biggest_box(units)
        if not parent then
            return
        end
        local bean = spawn_bean(parent, view == "1p")
        if not bean then
            return
        end
        World.link_unit(ext.__qiangiq_mb_world, bean, 1, parent, 1, World.LINK_MODE_NODE_NAME)
        rec = { bean = bean, base = base, parent = parent, prefix = prefix, frames = 0 }
        records[key] = rec
    end

    if rec.frames < FIT_FRAMES or rec.refit then
        rec.frames = rec.frames + 1
        rec.refit = nil
        local parent, pose, max_half = biggest_box(units)
        if parent == rec.parent and pose then
            fit(ext.__qiangiq_mb_world, rec.bean, parent, pose, max_half, prefix)
            rec.fitted = true
        end
    end

    if rec.fitted and visible then
        hide_all(units)
        rec.hid = true
        Unit.set_unit_visibility(rec.bean, true, true)
    else
        Unit.set_unit_visibility(rec.bean, false, true)
    end
end

local function apply(ext)
    local records = ext.__qiangiq_mb_records
    if not records then
        records = {}
        ext.__qiangiq_mb_records = records
    end
    local equipment = ext._equipment
    if not (equipment and ext.__qiangiq_mb_world) then
        return
    end
    for slot_name, slot in pairs(equipment) do
        local item = slot.item
        if item and item.weapon_template and HELD[item.weapon_template] or records[slot_name .. ":3p"] or records[slot_name .. ":1p"] then
            sync_slot(ext, records, slot_name .. ":3p", slot, "3p")
            sync_slot(ext, records, slot_name .. ":1p", slot, "1p")
        end
    end
end

local function clear_all(ext, restore)
    local records = ext.__qiangiq_mb_records
    if records then
        for key, rec in pairs(records) do
            clear_rec(rec, restore)
            records[key] = nil
        end
    end
end

local function is_local_human(ext)
    return sync_shown(ext)
end

vl_hook_safe("init", function(self, extension_init_context)
    self.__qiangiq_mb_world = extension_init_context and extension_init_context.world
end)

vl_hook_safe("_update_item_visibility", function(self)
    if is_local_human(self) then
        tracked[self] = true
        apply(self)
    end
end)

vl_hook_safe("update", function(self)
    if tracked[self] then
        apply(self)
    end
end)

vl_hook("_unequip_item_from_slot", function(func, self, slot_name, ...)
    local records = self.__qiangiq_mb_records
    if records then
        for _, view in ipairs({ ":3p", ":1p" }) do
            local rec = records[slot_name .. view]
            if rec then
                delete_unit(rec.bean)
                records[slot_name .. view] = nil
            end
        end
    end
    return func(self, slot_name, ...)
end)

vl_hook("destroy", function(func, self, ...)
    clear_all(self, false)
    tracked[self] = nil
    return func(self, ...)
end)

-- Thrown grenades ---------------------------------------------------------------
-- ProjectileFxExtension.init receives extension_init_data.projectile_template_name and
-- .owner_unit (projectile_fx_extension.lua:34-39); player.player_unit is the owner's unit.

local function proj_sync(fx)
    local unit = fx.__qiangiq_mb_unit
    local prefix = fx.__qiangiq_mb_prefix
    if not (prefix and unit_ok(unit)) then
        return
    end
    if not on(prefix) then
        if fx.__qiangiq_mb_bean then
            delete_unit(fx.__qiangiq_mb_bean)
            fx.__qiangiq_mb_bean = nil
            Unit.set_unit_visibility(unit, true, true)
        end
        return
    end
    local bean = fx.__qiangiq_mb_bean
    if not unit_ok(bean) then
        local _, pose, max_half = biggest_box({ unit })
        if not pose then
            return
        end
        bean = spawn_bean(unit, false)
        if not bean then
            return
        end
        World.link_unit(fx._world, bean, 1, unit, 1, World.LINK_MODE_NODE_NAME)
        fit(fx._world, bean, unit, pose, max_half, prefix)
        fx.__qiangiq_mb_bean = bean
    end
    Unit.set_unit_visibility(unit, false, true)
    Unit.set_unit_visibility(bean, true, true)
end

mod:hook_safe(CLASS.ProjectileFxExtension, "init", function(self, extension_init_context, unit, extension_init_data)
    local name = extension_init_data and extension_init_data.projectile_template_name
    local prefix = name and THROWN[name]
    if not prefix then
        return
    end
    local player = local_player()
    if not (player and player.player_unit and extension_init_data.owner_unit == player.player_unit) then
        return
    end
    self.__qiangiq_mb_unit = unit
    self.__qiangiq_mb_prefix = prefix
    tracked_proj[self] = true
end)

mod:hook_safe(CLASS.ProjectileFxExtension, "update", function(self)
    if self.__qiangiq_mb_prefix then
        proj_sync(self)
    end
end)

mod:hook(CLASS.ProjectileFxExtension, "destroy", function(func, self, ...)
    if self.__qiangiq_mb_bean then
        delete_unit(self.__qiangiq_mb_bean)
        self.__qiangiq_mb_bean = nil
    end
    tracked_proj[self] = nil
    return func(self, ...)
end)

-- Settings / loading -------------------------------------------------------------

local function refresh_all()
    for ext in pairs(tracked) do
        if unit_ok(ext._unit) then
            local records = ext.__qiangiq_mb_records
            if records then
                for _, rec in pairs(records) do
                    rec.refit = true
                end
            end
            apply(ext)
            -- restores items whose replacement was switched off
            ext:force_update_item_visibility()
        end
    end
end

mod.on_setting_changed = function()
    refresh_all()
end

mod.on_all_mods_loaded = function()
    custom_assets = get_mod("CustomAssets")
    if not custom_assets or not custom_assets.is_api_compatible or not custom_assets.is_api_compatible(1) then
        mod:error("Custom Assets (API 1) is missing. Install it and put it above QIangIQsMakimaBean in mod_load_order.txt.")
        return
    end
    local ticket, err = custom_assets.acquire(mod, BEAN_ID, function(_, _, load_error)
        if load_error then
            mod:error("%s failed to load: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", BEAN_ID, tostring(load_error))
            return
        end
        ready = true
        refresh_all()
    end, { resident = true, reference_name = BEAN_ID })
    if not ticket then
        mod:error("%s could not be requested: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", BEAN_ID, tostring(err))
    end
end

local function remove_all()
    for ext in pairs(tracked) do
        clear_all(ext, false)
    end
    for fx in pairs(tracked_proj) do
        if fx.__qiangiq_mb_bean then
            delete_unit(fx.__qiangiq_mb_bean)
            fx.__qiangiq_mb_bean = nil
        end
        if unit_ok(fx.__qiangiq_mb_unit) then
            Unit.set_unit_visibility(fx.__qiangiq_mb_unit, true, true)
        end
    end
end

mod.on_disabled = function()
    remove_all()
    for ext in pairs(tracked) do
        if unit_ok(ext._unit) then
            ext:force_update_item_visibility()
        end
    end
end

mod.on_enabled = function()
    refresh_all()
end

mod.on_unload = function()
    remove_all()
    if custom_assets and custom_assets.release_owner then
        custom_assets.release_owner(mod)
    end
end


-- Cross-client sync: what this mod publishes about me, and the refresh when anyone's options change ---------
local function sync_applies(info)
    for template, prefix in pairs(HELD) do
        if on(prefix) and (info.templates == nil or info.templates[template]) then
            return true
        end
    end
    return false
end

local sync_enabled = true
local function sync_changed()
    local api = sync_api()
    if api then
        api.changed()
    end
end

mod.sync_key = SYNC_KEY
-- info = { breed, companion_breed, templates = { [weapon_template] = true } } of my own character (fields nil
-- while I have no unit). Returns the array to publish, or nil when this mod shows nothing on my character.
mod.sync_export = function(info)
    info = info or {}
    if not sync_enabled or not sync_applies(info) then
        return nil
    end
    local mask, bit = 0, 1
    for i = 1, #SYNC_BOOLS do
        local key = SYNC_BOOLS[i]
        local v = mod:get(key)
        if v == nil then
            v = SYNC_DEFAULTS[key]
        end
        if v then
            mask = mask + bit
        end
        bit = bit * 2
    end
    local out = { SYNC_LAYOUT, mask }
    for i = 1, #SYNC_VALUES do
        local v = mod:get(SYNC_VALUES[i])
        if type(v) == "number" then
            v = math.floor(v * 100 + 0.5) / 100
        elseif type(v) ~= "string" then
            v = false -- not set: the reader falls back to its default
        end
        out[2 + i] = v
    end
    return out
end

mod.sync_refresh = function()
    for ext in pairs(sync_all) do
        if ext._unit and Unit.alive(ext._unit) and ext.force_update_item_visibility then
            pcall(ext.force_update_item_visibility, ext)
        end
    end
end

local sync_prev_setting_changed = mod.on_setting_changed
mod.on_setting_changed = function(...)
    if sync_prev_setting_changed then
        sync_prev_setting_changed(...)
    end
    sync_changed()
end

local sync_prev_disabled = mod.on_disabled
mod.on_disabled = function(...)
    sync_enabled = false
    if sync_prev_disabled then
        sync_prev_disabled(...)
    end
    sync_changed()
end

local sync_prev_enabled = mod.on_enabled
mod.on_enabled = function(...)
    sync_enabled = true
    if sync_prev_enabled then
        sync_prev_enabled(...)
    end
    sync_changed()
end
