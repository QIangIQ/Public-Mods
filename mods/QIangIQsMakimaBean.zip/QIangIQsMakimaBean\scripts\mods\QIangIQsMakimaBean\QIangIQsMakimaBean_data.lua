local mod = get_mod("QIangIQsMakimaBean")

local function item_group(prefix)
    return {
        setting_id = prefix .. "_group",
        type = "group",
        sub_widgets = {
            { setting_id = prefix .. "_enabled", type = "checkbox", default_value = true },
            { setting_id = prefix .. "_size", type = "numeric", default_value = 1.0, range = { 0.25, 4.0 }, decimals_number = 2 },
            { setting_id = prefix .. "_yaw", type = "numeric", default_value = 0, range = { -180, 180 }, decimals_number = 0 },
            { setting_id = prefix .. "_pitch", type = "numeric", default_value = 0, range = { -180, 180 }, decimals_number = 0 },
            { setting_id = prefix .. "_roll", type = "numeric", default_value = 0, range = { -180, 180 }, decimals_number = 0 },
        },
    }
end

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = true,
    options = {
        widgets = {
            item_group("relic"),
            item_group("krak"),
            item_group("krak_thrown"),
        },
    },
}
