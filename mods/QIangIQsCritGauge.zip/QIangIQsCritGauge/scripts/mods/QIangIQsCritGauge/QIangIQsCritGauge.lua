local mod = get_mod("QIangIQsCritGauge")

--[[
    CRIT GAUGE  (QIangIQsCritGauge 0.1.0)

    Two half dials, 0 on the left end, full scale on the right end.
      left dial  (gold)    current crit chance for the attack type of the wielded weapon
      right dial (orange)  real chance that the NEXT roll crits, after the game's PRD

    Every number comes from the game's own code (Aussiemon Darktide-Source-Code master):
      scripts/utilities/attack/critical_strike.lua
        CriticalStrike.chance               base (archetype) + critical_strike_chance
                                            + melee_/ranged_critical_strike_chance
                                            + weapon_handling_template.critical_strike.chance_modifier,
                                            clamped 0..1, * (1 - critical_strike_chance_to_damage_convert)
        CriticalStrike.is_critical_strike   rounds the chance to 2 decimals, then flip_coin
      scripts/utilities/pseudo_random_distribution.lua
        flip_coin(chance, state, seed):
          c = P2C[floor(chance * 100)]
          first roll < c        -> plain roll at `chance`, state unchanged
          else n = state or floor(chance / c)
               second roll < n * c -> CRIT, state = 1
               else                -> miss, state = min(n + 1, max_prd_state)
        so P(next crit) = c * chance + (1 - c) * min(n * c, 1)
      scripts/extension_systems/weapon/actions/action_weapon_base.lua
        _check_for_critical_strike   prevent_critical_strike -> 0, guaranteed_* keywords -> 1,
                                     no roll from grenade / combat ability slots
        _check_for_lucky_strike      Leadbelcher uses the same prd_state and resets it on a proc
      scripts/extension_systems/unit_data/player_unit_data_component_config.lua
        critical_strike = { is_active, num_critical_shots, prd_state, seed }

    The critical_strike component is predicted on the owning client, so both dials are
    exact on Fatshark servers as well as solo. prd_state nil (network -1) means no roll yet
    this life: the game then starts at floor(chance / c).
--]]

local CriticalStrike = require("scripts/utilities/attack/critical_strike")

local FONT = "content/ui/fonts/proxima_nova_bold"
local LAYER = 950
local MAX_RECTS = 1500
local EMPTY_TABLE = {}

-- P2C from scripts/utilities/pseudo_random_distribution.lua (local there, so copied).
-- Index k is the PRD constant for a k-in-100 chance.
local P2C = {
	0.0001560416916765,
	0.0006200876164356,
	0.0013861777203907,
	0.0024485554716477,
	0.0038016583035531,
	0.0054401086148994,
	0.0073587052890401,
	0.009552415696806,
	0.0120163681507952,
	0.0147458447810727,
	0.0177362748045691,
	0.0209832281625322,
	0.0244824095022856,
	0.028229652481288,
	0.0322209143730877,
	0.0364522709562386,
	0.0409199116686026,
	0.045620135010803,
	0.0505493441851718,
	0.0557040429497818,
	0.0610808317144988,
	0.0666764036215081,
	0.0724875433984468,
	0.0785111206640039,
	0.084744091852317,
	0.091183460913123,
	0.097826380485467,
	0.104670227374915,
	0.1117117582421034,
	0.118949192725404,
	0.1263793161208353,
	0.1340008645349125,
	0.1418051956867528,
	0.1498100879493791,
	0.1579830981257471,
	0.166328776806438,
	0.1749092435951354,
	0.1836246523722508,
	0.1924859579708838,
	0.201547413607754,
	0.2109200313959977,
	0.2203645774003486,
	0.2298986763626535,
	0.2395401522844584,
	0.2493069984401633,
	0.2598723505886277,
	0.270452936701194,
	0.2810076352015464,
	0.2915522666427177,
	0.302103025348742,
	0.3126766393399556,
	0.3232905471447631,
	0.3341199609425926,
	0.3473699930849595,
	0.3603978509331687,
	0.3732168294719914,
	0.3858396117819544,
	0.3982783321856844,
	0.4105446351769761,
	0.4226497308103743,
	0.434604447180966,
	0.4464192805893383,
	0.4581044439647123,
	0.4696699141100894,
	0.4811254783372292,
	0.4924807810774478,
	0.5074626865671641,
	0.5294117647058825,
	0.5507246376811594,
	0.5714285714285715,
	0.591549295774648,
	0.6111111111111113,
	0.6301369863013697,
	0.6486486486486487,
	0.6666666666666666,
	0.6842105263157897,
	0.7012987012987013,
	0.717948717948718,
	0.7341772151898737,
	0.75,
	0.7654320987654323,
	0.7804878048780489,
	0.795180722891566,
	0.8095238095238093,
	0.8235294117647058,
	0.8372093023255812,
	0.850574712643678,
	0.8636363636363638,
	0.8764044943820226,
	0.8888888888888891,
	0.9010989010989011,
	0.9130434782608697,
	0.9247311827956991,
	0.9361702127659574,
	0.9473684210526315,
	0.9583333333333331,
	0.9690721649484535,
	0.979591836734694,
	0.98989898989899,
}

local function _max_prd_state()
	local constants = rawget(_G, "NetworkConstants")

	return constants and type(constants.max_prd_state) == "number" and constants.max_prd_state or math.huge
end

-- ---------------------------------------------------------------------------
-- Settings
-- ---------------------------------------------------------------------------

local settings = {}

local function _read_settings()
	settings.attack_mode = mod:get("attack_mode") or "auto"
	settings.scale = math.max((mod:get("scale_value") or 100) / 100, 0.01)
	settings.needle_speed = math.max(mod:get("needle_speed") or 12, 1)
	settings.show_fills = mod:get("show_fills") ~= false
	settings.show_text = mod:get("show_text") ~= false
	settings.show_details = mod:get("show_details") ~= false
	settings.crit_flash = mod:get("crit_flash") ~= false
	settings.pos_x = (mod:get("pos_x") or 50) / 100
	settings.pos_y = (mod:get("pos_y") or 66) / 100
	settings.size = mod:get("size") or 70
	settings.gap = mod:get("gap") or 30
end

_read_settings()

mod.on_setting_changed = function ()
	_read_settings()
end

local view_on = true

mod.toggle_view = function ()
	view_on = not view_on
end

-- ---------------------------------------------------------------------------
-- State
-- ---------------------------------------------------------------------------

local state = {}

local function _reset(unit)
	state.unit = unit
	state.kind = "melee"          -- attack type the dials currently show
	state.chance = 0              -- current crit chance (unrounded, as CriticalStrike.chance)
	state.melee = 0
	state.ranged = 0
	state.rounded = 0             -- what the roll uses
	state.forced = nil            -- "prevent" / "guaranteed" when a keyword decides the roll
	state.prd = 0                 -- P(next roll crits)
	state.prd_state = nil         -- raw component value (nil = fresh)
	state.step = 0                -- n the next roll will use
	state.c = 0
	state.ceiling = 0             -- highest P the PRD can reach at this chance
	state.to_ceiling = 0          -- misses until it gets there
	state.shown_chance = 0        -- needle positions (eased)
	state.shown_prd = 0
	state.flash_t = -math.huge
	state.t = 0
	state.rolls = 0
	state.crits = 0
	state.expected = 0            -- sum of P(crit) over the rolls seen
	state.misses_since = 0
	state.longest_drought = 0
end

_reset(nil)

local function _num(value, default)
	return type(value) == "number" and value or default
end

local function _local_player()
	local player = Managers.player and Managers.player:local_player(1)
	local unit = player and player.player_unit

	if unit and Unit.alive(unit) then
		return player, unit
	end

	return player, nil
end

local function _gameplay_time()
	local time_manager = Managers.time

	if time_manager and time_manager:has_timer("gameplay") then
		return time_manager:time("gameplay")
	end

	return nil
end

-- ---------------------------------------------------------------------------
-- The game's maths
-- ---------------------------------------------------------------------------

-- PseudoRandomDistribution.flip_coin, as a probability instead of a roll.
-- Returns P(crit), c, n (the state the roll will use).
local function _prd_probability(chance, prd_state)
	if chance >= 1 then
		return 1, 0, prd_state
	elseif chance <= 0 then
		return 0, 0, prd_state
	end

	local c = P2C[math.floor(chance * 100)]

	if not c then
		return chance, 0, prd_state
	end

	local n = prd_state or math.floor(chance / c)

	return c * chance + (1 - c) * math.min(n * c, 1), c, n
end

-- CriticalStrike.chance for one attack type, guarded (stat buffs can be missing in odd states)
local function _chance(player, handling, is_ranged, is_melee)
	local ok, value = pcall(CriticalStrike.chance, player, handling, is_ranged, is_melee, false)

	return ok and _num(value, 0) or 0
end

local function _wielded_kind(unit_data_extension)
	local inventory = unit_data_extension:read_component("inventory")
	local slot = inventory and inventory.wielded_slot

	if slot == "slot_primary" then
		return "melee"
	elseif slot == "slot_secondary" then
		return "ranged"
	end

	return nil
end

-- _check_for_critical_strike: keywords that decide the roll before the chance is used
local function _forced(buff_extension, kind)
	if not buff_extension then
		return nil
	end

	if buff_extension:has_keyword("prevent_critical_strike") then
		return "prevent"
	end

	if buff_extension:has_keyword("guaranteed_critical_strike")
		or kind == "ranged" and buff_extension:has_keyword("guaranteed_ranged_critical_strike")
		or kind == "melee" and buff_extension:has_keyword("guaranteed_melee_critical_strike") then
		return "guaranteed"
	end

	return nil
end

local function _update_model(dt, t)
	local player, unit = _local_player()

	if unit ~= state.unit then
		_reset(unit)
	end

	if not unit or not player then
		return false
	end

	local unit_data_extension = ScriptUnit.has_extension(unit, "unit_data_system")
	local weapon_extension = ScriptUnit.has_extension(unit, "weapon_system")
	local buff_extension = ScriptUnit.has_extension(unit, "buff_system")

	if not unit_data_extension or not weapon_extension or not buff_extension then
		return false
	end

	local critical_strike = unit_data_extension:read_component("critical_strike")

	if not critical_strike then
		return false
	end

	state.t = t

	local wielded = _wielded_kind(unit_data_extension)

	if settings.attack_mode == "melee" or settings.attack_mode == "ranged" then
		state.kind = settings.attack_mode
	elseif wielded then
		state.kind = wielded
	end

	-- grenades and abilities do not roll: keep the last weapon's numbers while they are out
	if wielded or settings.attack_mode ~= "auto" then
		local handling = weapon_extension.weapon_handling_template and weapon_extension:weapon_handling_template() or nil

		handling = handling or EMPTY_TABLE
		state.melee = _chance(player, handling, false, true)
		state.ranged = _chance(player, handling, true, false)
	end

	local chance = state.kind == "ranged" and state.ranged or state.melee
	local forced = _forced(buff_extension, state.kind)

	if forced == "prevent" then
		chance = 0
	elseif forced == "guaranteed" then
		chance = 1
	end

	state.forced = forced
	state.chance = chance
	state.rounded = math.round_with_precision(chance, 2)
	state.prd_state = critical_strike.prd_state

	local p, c, n = _prd_probability(state.rounded, state.prd_state)

	state.prd = p
	state.c = c
	state.step = n or 0

	if c > 0 then
		local cap_step = math.min(math.ceil(1 / c), _max_prd_state())

		state.ceiling = c * state.rounded + (1 - c) * math.min(cap_step * c, 1)
		state.to_ceiling = math.max(cap_step - (n or 0), 0)
	else
		state.ceiling = p
		state.to_ceiling = 0
	end

	-- needles ease toward their values; a drop of the PRD needle (a crit) is instant
	local k = 1 - math.exp(-dt * settings.needle_speed)

	state.shown_chance = state.shown_chance + (state.chance - state.shown_chance) * k

	if state.prd < state.shown_prd - 0.02 then
		state.shown_prd = state.prd
	else
		state.shown_prd = state.shown_prd + (state.prd - state.shown_prd) * k
	end

	return true
end

-- ---------------------------------------------------------------------------
-- Rolls (for the flash and /cgauge_info). The dials themselves read the component.
--
-- Action classes copy their base methods when they are defined (foundation class.lua),
-- so a hook on ActionWeaponBase._check_for_critical_strike would miss the subclasses.
-- CriticalStrike.is_critical_strike is called through the module table, so it is hooked
-- instead. The roll is ours when the seed passed in is the seed of our own component.
-- Leadbelcher rolls go through it too: they are told apart by their chance.
-- ---------------------------------------------------------------------------

mod:hook(CriticalStrike, "is_critical_strike", function (func, chance, prd_state, seed, ...)
	local is_crit, new_state, new_seed = func(chance, prd_state, seed, ...)

	local unit = state.unit

	if not unit or seed == nil then
		return is_crit, new_state, new_seed
	end

	local ok = pcall(function ()
		local unit_data_extension = ScriptUnit.has_extension(unit, "unit_data_system")
		local component = unit_data_extension and unit_data_extension:read_component("critical_strike")

		if not component or component.seed ~= seed then
			return
		end

		local rounded = math.round_with_precision(_num(chance, 0), 2)
		local expected

		if rounded == state.rounded then
			expected = state.prd
		elseif rounded >= 1 then
			expected = 1
		elseif rounded <= 0 then
			expected = 0
		else
			return -- a Leadbelcher roll, or a chance the dial was not showing
		end

		state.rolls = state.rolls + 1
		state.expected = state.expected + expected

		if is_crit then
			state.crits = state.crits + 1
			state.misses_since = 0
			state.flash_t = state.t
		else
			state.misses_since = state.misses_since + 1
			state.longest_drought = math.max(state.longest_drought, state.misses_since)
		end
	end)

	if not ok then
		mod:info("roll hook failed")
	end

	return is_crit, new_state, new_seed
end)

-- ---------------------------------------------------------------------------
-- Update
-- ---------------------------------------------------------------------------

local model_ok = false

mod.update = function (dt)
	if not mod:is_enabled() then
		model_ok = false

		return
	end

	local t = _gameplay_time()
	local game_mode_manager = Managers.state and Managers.state.game_mode
	local ok_mode, mode_name = pcall(function ()
		return game_mode_manager and game_mode_manager:game_mode_name()
	end)

	if not t or not game_mode_manager or (ok_mode and mode_name == "hub") then
		model_ok = false

		return
	end

	local ok, result = pcall(_update_model, dt, t)

	if not ok then
		mod:info("model: %s", tostring(result))
	end

	model_ok = ok and result or false
end

-- ---------------------------------------------------------------------------
-- Drawing (HUD gui, as QIangIQsToughnessGauge: HudElementCrosshair.update)
-- ---------------------------------------------------------------------------

local rect_count = 0

local function _rect_layer(gui, x, y, w, h, color, layer)
	if rect_count >= MAX_RECTS then
		return
	end

	rect_count = rect_count + 1

	Gui.rect(gui, Vector3(x, y, layer), Vector2(w, h), color)
end

-- angle 0 = straight up, -pi/2 = left end, +pi/2 = right end
local function _point(cx, cy, radius, angle)
	return cx + radius * math.sin(angle), cy - radius * math.cos(angle)
end

local function _arc(gui, cx, cy, radius, a1, a2, thickness, color, layer)
	if a2 < a1 then
		a1, a2 = a2, a1
	end

	local length = (a2 - a1) * radius
	local steps = math.max(1, math.ceil(length / math.max(thickness * 0.5, 1)))
	local half = thickness / 2

	for i = 0, steps do
		local x, y = _point(cx, cy, radius, a1 + (a2 - a1) * i / steps)

		_rect_layer(gui, x - half, y - half, thickness, thickness, color, layer)
	end
end

local function _line(gui, x1, y1, x2, y2, thickness, color, layer)
	local dx, dy = x2 - x1, y2 - y1
	local length = math.sqrt(dx * dx + dy * dy)
	local steps = math.max(1, math.ceil(length / math.max(thickness * 0.5, 1)))
	local half = thickness / 2

	for i = 0, steps do
		local f = i / steps

		_rect_layer(gui, x1 + dx * f - half, y1 + dy * f - half, thickness, thickness, color, layer)
	end
end

-- 0 at the left end, full scale at the right end
local function _angle(value)
	local f = math.clamp(value / settings.scale, 0, 1)

	return -math.pi / 2 + f * math.pi
end

local function _text(gui, text, x, y, size, color, align)
	local ok_extents, min, max = pcall(Gui.slug_text_extents, gui, text, FONT, size)
	local width = ok_extents and min and max and (max.x - min.x) or 0
	local left = align == "center" and x - width / 2 or align == "right" and x - width or x

	pcall(Gui.slug_text, gui, text, FONT, size, Vector3(left, y, LAYER + 5), nil, color, "shadow", Color(200, 0, 0, 0))
end

local COLOR_TRACK = Color(150, 20, 20, 20)
local COLOR_TICK = Color(200, 200, 200, 200)
local COLOR_CHANCE = Color(255, 240, 200, 70)
local COLOR_CHANCE_FILL = Color(150, 240, 200, 70)
local COLOR_PRD = Color(255, 255, 130, 40)
local COLOR_PRD_FILL = Color(150, 255, 130, 40)
local COLOR_PRD_FLASH = Color(230, 255, 245, 200)
local COLOR_MARK = Color(220, 245, 245, 245)
local COLOR_HUB = Color(255, 245, 245, 245)
local COLOR_TEXT = Color(255, 230, 230, 230)
local COLOR_DIM = Color(200, 170, 170, 170)

local function _pct(value)
	return string.format("%.1f%%", value * 100)
end

local function _dial(gui, cx, cy, radius, band, s, value, needle_color, fill_color, flash)
	local pi2 = math.pi / 2

	_arc(gui, cx, cy, radius, -pi2, pi2, band, flash and COLOR_PRD_FLASH or COLOR_TRACK, LAYER)

	for i = 0, 4 do
		local a = -pi2 + i * pi2 / 2
		local x1, y1 = _point(cx, cy, radius + band, a)
		local x2, y2 = _point(cx, cy, radius + band + (i == 2 and 8 or 5) * s, a)

		_line(gui, x1, y1, x2, y2, math.max(2 * s, 1), COLOR_TICK, LAYER + 1)
	end

	local a = _angle(value)

	if settings.show_fills and a > -pi2 + 0.005 then
		_arc(gui, cx, cy, radius, -pi2, a, band, fill_color, LAYER + 1)
	end

	local x, y = _point(cx, cy, radius * 0.92, a)

	_line(gui, cx, cy, x, y, math.max(4 * s, 2), needle_color, LAYER + 3)

	local hub = 8 * s

	_rect_layer(gui, cx - hub / 2, cy - hub / 2, hub, hub, COLOR_HUB, LAYER + 4)
end

-- short mark across the band at a value (base chance and ceiling on the PRD dial)
local function _mark(gui, cx, cy, radius, band, s, value, color)
	local a = _angle(value)
	local x1, y1 = _point(cx, cy, radius - band, a)
	local x2, y2 = _point(cx, cy, radius + band, a)

	_line(gui, x1, y1, x2, y2, math.max(2 * s, 1), color, LAYER + 2)
end

local function _draw(gui)
	local width = RESOLUTION_LOOKUP and RESOLUTION_LOOKUP.width
	local height = RESOLUTION_LOOKUP and RESOLUTION_LOOKUP.height

	if not width or not height then
		width, height = Gui.resolution()
	end

	local s = height / 1080
	local radius = settings.size * s
	local band = math.max(6 * s, 2)
	local half_gap = settings.gap * s / 2
	local cy = height * settings.pos_y
	local cx_left = width * settings.pos_x - half_gap - radius - band
	local cx_right = width * settings.pos_x + half_gap + radius + band
	local flash = settings.crit_flash and state.t - state.flash_t < 0.25

	rect_count = 0

	_dial(gui, cx_left, cy, radius, band, s, state.shown_chance, COLOR_CHANCE, COLOR_CHANCE_FILL, false)
	_dial(gui, cx_right, cy, radius, band, s, state.shown_prd, COLOR_PRD, COLOR_PRD_FILL, flash)

	if state.c > 0 then
		_mark(gui, cx_right, cy, radius, band, s, state.rounded, COLOR_CHANCE)
		_mark(gui, cx_right, cy, radius, band, s, state.ceiling, COLOR_MARK)
	end

	if not settings.show_text then
		return
	end

	local size_small = 13 * s
	local size_big = 18 * s
	local y = cy + 6 * s + size_big
	local kind_text = state.kind == "ranged" and "ranged" or "melee"
	local chance_text = _pct(state.chance)

	if state.forced == "prevent" then
		chance_text = "blocked"
	elseif state.forced == "guaranteed" then
		chance_text = "guaranteed"
	end

	_text(gui, chance_text, cx_left, y, size_big, COLOR_CHANCE, "center")
	_text(gui, "next " .. _pct(state.prd), cx_right, y, size_big, COLOR_PRD, "center")

	local y2 = y + size_small * 1.4

	_text(gui, "crit chance (" .. kind_text .. ")", cx_left, y2, size_small, COLOR_DIM, "center")
	_text(gui, "PRD", cx_right, y2, size_small, COLOR_DIM, "center")

	local lx, ly = _point(cx_left, cy, radius + band + 6 * s, -math.pi / 2)
	local rx, ry = _point(cx_right, cy, radius + band + 6 * s, math.pi / 2)

	_text(gui, "0", lx, ly + size_small, size_small, COLOR_TICK, "right")
	_text(gui, _pct(settings.scale), rx, ry + size_small, size_small, COLOR_TICK, "left")

	if not settings.show_details then
		return
	end

	local y3 = y2 + size_small * 1.3

	_text(gui, string.format("melee %s / ranged %s", _pct(state.melee), _pct(state.ranged)), cx_left, y3, size_small, COLOR_TEXT, "center")

	if state.c > 0 then
		local since = state.prd_state and string.format("step %d", state.step) or string.format("fresh, step %d", state.step)

		_text(gui, string.format("%s | cap %s in %d", since, _pct(state.ceiling), state.to_ceiling), cx_right, y3, size_small, COLOR_TEXT, "center")
	end
end

mod:hook_safe("HudElementCrosshair", "update", function (self, dt, t, ui_renderer)
	if not view_on or not model_ok or not mod:is_enabled() or not ui_renderer or not ui_renderer.gui then
		return
	end

	local ok, err = pcall(_draw, ui_renderer.gui)

	if not ok then
		mod:info("draw: %s", tostring(err))
	end
end)

-- ---------------------------------------------------------------------------
-- Lifecycle and commands
-- ---------------------------------------------------------------------------

mod.on_game_state_changed = function (status, state_name)
	_reset(nil)
end

mod:command("cgauge_info", "Crit Gauge: print the current crit chance, PRD state and the rolls seen.", function ()
	mod:echo("%s", string.format("%s chance %s (roll uses %s)%s | next roll %s | PRD state %s, c %.5f | cap %s in %d misses",
		state.kind, _pct(state.chance or 0), _pct(state.rounded or 0), state.forced and (" [" .. state.forced .. "]") or "",
		_pct(state.prd or 0), state.prd_state and tostring(state.prd_state) or "fresh (" .. tostring(state.step) .. ")",
		state.c or 0, _pct(state.ceiling or 0), state.to_ceiling or 0))
	mod:echo("%s", string.format("melee %s | ranged %s | rolls %d, crits %d (%s), expected %.1f | misses since crit %d, longest %d",
		_pct(state.melee or 0), _pct(state.ranged or 0), state.rolls or 0, state.crits or 0,
		_pct((state.rolls or 0) > 0 and state.crits / state.rolls or 0), state.expected or 0,
		state.misses_since or 0, state.longest_drought or 0))
end)
