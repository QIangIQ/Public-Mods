-- No percent signs in any string here: DMF passes localize text through string.format.
return {
	mod_name = { en = "QIangIQs Crit Gauge" },
	mod_description = { en = "Two half dials for critical strikes. Left dial (gold): your current crit chance for the weapon in your hands, from the game's own formula (class base + talents, blessings, perks and buffs + the weapon's own modifier, minus any share converted to damage). It moves live as buffs come and go. Right dial (orange): the real chance that your NEXT attack crits after the game's pseudo random distribution (PRD). It drops to its floor the moment you crit and climbs with every roll that misses. Both read the critical_strike state the game keeps on your own character, so they are exact on Fatshark servers as well as solo. Leadbelcher procs share the same PRD counter and also reset it. /cgauge_info prints the numbers and the rolls seen this mission." },

	toggle_key = { en = "Toggle key" },
	toggle_key_tooltip = { en = "Show or hide the dials without opening the mod menu." },

	attack_mode = { en = "Attack type" },
	attack_mode_tooltip = { en = "Which crit chance to show. Auto follows the wielded slot (melee weapon = melee chance, ranged weapon = ranged chance) and keeps the last one while you hold a grenade or ability." },
	attack_auto = { en = "Auto (wielded weapon)" },
	attack_melee = { en = "Always melee" },
	attack_ranged = { en = "Always ranged" },

	scale_value = { en = "Full scale (crit chance in hundredths)" },
	scale_value_tooltip = { en = "What the right end of both dials stands for. 100 = a 100 in 100 chance. Lower it (for example 40) to spread low crit builds across more of the dial; values above it pin to the end." },

	needle_speed = { en = "Needle speed" },
	needle_speed_tooltip = { en = "How fast the needles chase their value. Higher is snappier. A crit always drops the PRD needle instantly." },

	show_fills = { en = "Colour bands" },
	show_fills_tooltip = { en = "Fill each dial from 0 to its needle." },
	show_text = { en = "Numbers" },
	show_text_tooltip = { en = "The value of each dial under it." },
	show_details = { en = "Details" },
	show_details_tooltip = { en = "Under the PRD dial: misses since the last crit, the ceiling the PRD can reach, and how many more misses until it gets there. Under the crit dial: melee and ranged chance side by side." },
	crit_flash = { en = "Flash on crit" },
	crit_flash_tooltip = { en = "Briefly light up the PRD dial when a roll crits." },

	pos_x = { en = "Position across (share of screen width)" },
	pos_x_tooltip = { en = "Centre point between the two dials, 0 = left edge, 100 = right edge." },
	pos_y = { en = "Position down (share of screen height)" },
	pos_y_tooltip = { en = "Centre of the dials, 0 = top edge, 100 = bottom edge." },
	size = { en = "Radius (pixels at 1080p)" },
	size_tooltip = { en = "Radius of each half dial." },
	gap = { en = "Gap between dials (pixels at 1080p)" },
	gap_tooltip = { en = "Space between the two dials." },
}
