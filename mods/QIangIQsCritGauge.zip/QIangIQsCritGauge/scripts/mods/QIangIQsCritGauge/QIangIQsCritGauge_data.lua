local mod = get_mod("QIangIQsCritGauge")

local function checkbox(id, default)
	return { setting_id = id, type = "checkbox", default_value = default, tooltip = id .. "_tooltip" }
end

local function numeric(id, default, low, high)
	return { setting_id = id, type = "numeric", default_value = default, range = { low, high }, tooltip = id .. "_tooltip" }
end

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			{
				setting_id = "toggle_key",
				type = "keybind",
				default_value = {},
				keybind_trigger = "pressed",
				keybind_type = "function_call",
				function_name = "toggle_view",
				tooltip = "toggle_key_tooltip",
			},
			{
				setting_id = "attack_mode",
				type = "dropdown",
				default_value = "auto",
				tooltip = "attack_mode_tooltip",
				options = {
					{ text = "attack_auto", value = "auto" },
					{ text = "attack_melee", value = "melee" },
					{ text = "attack_ranged", value = "ranged" },
				},
			},
			numeric("scale_value", 100, 5, 100),
			numeric("needle_speed", 12, 1, 60),
			checkbox("show_fills", true),
			checkbox("show_text", true),
			checkbox("show_details", true),
			checkbox("crit_flash", true),
			numeric("pos_x", 50, 0, 100),
			numeric("pos_y", 66, 0, 100),
			numeric("size", 70, 30, 300),
			numeric("gap", 30, 0, 300),
		},
	},
}
