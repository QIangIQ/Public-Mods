return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsCritGauge` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsCritGauge", {
			mod_script       = "QIangIQsCritGauge/scripts/mods/QIangIQsCritGauge/QIangIQsCritGauge",
			mod_data         = "QIangIQsCritGauge/scripts/mods/QIangIQsCritGauge/QIangIQsCritGauge_data",
			mod_localization = "QIangIQsCritGauge/scripts/mods/QIangIQsCritGauge/QIangIQsCritGauge_localization",
		})
	end,
	packages = {},
}
