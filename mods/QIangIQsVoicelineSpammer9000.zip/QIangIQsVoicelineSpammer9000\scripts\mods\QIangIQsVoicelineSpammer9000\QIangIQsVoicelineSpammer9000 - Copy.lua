local mod = get_mod("QIangIQsVoicelineSpammer9000")

local VOQueryConstants = require("scripts/settings/dialogue/vo_query_constants")
local Vo = require("scripts/utilities/vo")

local HudElementSmartTagging_instance

local POS_BOTTOM = 1
local POS_BOTTOM_RIGHT = 2
local POS_RIGHT = 3
local POS_TOP_RIGHT = 4
local POS_TOP = 5
local POS_TOP_LEFT = 6
local POS_LEFT = 7
local POS_BOTTOM_LEFT = 8
 
mod:hook(LocalizationManager, "localize", function(func, self, key, no_cache, context)
	self._string_cache.loc_ammo = "Ammo"
	self._string_cache.loc_ammocrate = "Ammo Crate"
	self._string_cache.loc_cheer = "For the Emperor!"
	self._string_cache.loc_cryorod = "Cryonic Rod"
	self._string_cache.loc_diamantine = "Diamantine"
	self._string_cache.loc_enemy = "Enemy"
	self._string_cache.loc_following = "Following"
	self._string_cache.loc_go_there = "Go There"
	self._string_cache.loc_grenade = "Grenade"
	self._string_cache.loc_grim = "Grimoire"
	self._string_cache.loc_healthbooster = "Health Booster"
	self._string_cache.loc_look_there = "Look There"
	self._string_cache.loc_medicaestation = "Medicae Station"
	self._string_cache.loc_medipack = "Medipack"
	self._string_cache.loc_medipackdown = "Medipack Down"
	self._string_cache.loc_mine = "Mine"
	self._string_cache.loc_need_ammo = "Need Ammo"
	self._string_cache.loc_need_healing = "Need Healing"
	self._string_cache.loc_no = "No"
	self._string_cache.loc_plasteel = "Plasteel"
	self._string_cache.loc_power_cell = "Power Cell"
	self._string_cache.loc_relic = "Relic"
	self._string_cache.loc_scripture = "Scripture"
	self._string_cache.loc_thanks = "Thanks"
	self._string_cache.loc_unchargedmedicae = "Uncharged Medicae"
	self._string_cache.loc_vacuum_capsule = "Vacuum Capsule"
	self._string_cache.loc_yes = "Yes"
	self._string_cache.loc_comms = "Comms Device"
	return func(self, key, no_cache, context)
end)

local commands = {
    [1] = {
		icon = "content/ui/materials/icons/system/escape/achievements",
		display_name = "loc_cheer",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_com_wheel,
			voice_tag_id = VOQueryConstants.trigger_ids.com_wheel_vo_for_the_emperor,
		},
	},
	-- Vacuum Capsule
    [2] = {
		icon = "content/ui/materials/hud/interactions/icons/training_grounds",
		display_name = "loc_vacuum_capsule",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_vo_tag_item,
			voice_tag_id = VOQueryConstants.trigger_ids.smart_tag_vo_pickup_container,
		},
	},
	-- Yes
    [3] = {
		icon = "content/ui/materials/icons/pocketables/hud/scripture",
		display_name = "loc_yes",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_com_wheel,
			voice_tag_id = VOQueryConstants.trigger_ids.com_wheel_vo_yes,
		},
	},
	-- No
    [4] = {
		icon = "content/ui/materials/icons/system/settings/category_interface",
		display_name = "loc_no",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_com_wheel,
			voice_tag_id = VOQueryConstants.trigger_ids.com_wheel_vo_no,
		},
	},
	-- Cryonic Rod
    [5] = {
		icon = "content/ui/materials/hud/interactions/icons/training_grounds",
		display_name = "loc_cryorod",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_vo_tag_item,
			voice_tag_id = VOQueryConstants.trigger_ids.smart_tag_vo_pickup_control_rod,
		},
	},
	-- Power Cell
    [6] = {
		icon = "content/ui/materials/hud/interactions/icons/training_grounds",
		display_name = "loc_power_cell",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_vo_tag_item,
			voice_tag_id = VOQueryConstants.trigger_ids.smart_tag_vo_pickup_battery
		},
	},
	-- Scripture
    [7] = {
		icon = "content/ui/materials/icons/pocketables/hud/scripture",
		display_name = "loc_scripture",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_vo_tag_item,
			voice_tag_id = VOQueryConstants.trigger_ids.smart_tag_vo_pickup_side_mission_tome,
		},
	},
	-- Grimoire
    [8] = {
		icon = "content/ui/materials/icons/pocketables/hud/grimoire",
		display_name = "loc_grim",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_vo_tag_item,
			voice_tag_id = VOQueryConstants.trigger_ids.smart_tag_vo_pickup_side_mission_grimoire,
		},
	},
	-- Relic
    [9] = {
		icon = "content/ui/materials/icons/pocketables/hud/grimoire",
		display_name = "loc_relic",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_vo_tag_item,
			voice_tag_id = VOQueryConstants.trigger_ids.smart_tag_vo_pickup_side_mission_consumable,
		},
	},
	-- Health Booster
    [10] = {
		icon = "content/ui/materials/hud/interactions/icons/pocketable_medkit",
		display_name = "loc_healthbooster",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_vo_tag_item,
			voice_tag_id = VOQueryConstants.trigger_ids.smart_tag_vo_pickup_health_booster,
		},
	},
	-- Mine
    [11] = {
		icon = "content/ui/materials/hud/interactions/icons/pocketable_default",
		display_name = "loc_mine",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_com_wheel,
			voice_tag_id = VOQueryConstants.trigger_ids.com_wheel_vo_need_that,
		},
	},
	-- Ammo
    [12] = {
		icon = "content/ui/materials/hud/interactions/icons/pocketable_ammo",
		display_name = "loc_ammo",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_vo_tag_item,
			voice_tag_id = VOQueryConstants.trigger_ids.smart_tag_vo_pickup_ammo,
		},
	},
	-- Grenade
    [13] = {
		icon = "content/ui/materials/hud/interactions/icons/pocketable_default",
		display_name = "loc_grenade",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_vo_tag_item,
			voice_tag_id = VOQueryConstants.trigger_ids.smart_tag_vo_small_grenade,
		},
	},
	-- Plasteel
    [14] = {
		icon = "content/ui/materials/hud/interactions/icons/pocketable_default",
		display_name = "loc_plasteel",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_vo_tag_item,
			voice_tag_id = VOQueryConstants.trigger_ids.smart_tag_vo_pickup_forge_metal,
		},
	},
	-- Diamantine
    [15] = {
		icon = "content/ui/materials/hud/interactions/icons/pocketable_default",
		display_name = "loc_diamantine",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_vo_tag_item,
			voice_tag_id = VOQueryConstants.trigger_ids.smart_tag_vo_pickup_platinum,
		},
	},
	-- Following
    [16] = {
		icon = "content/ui/materials/icons/pocketables/hud/scripture",
		display_name = "loc_following",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_com_wheel,
			voice_tag_id = VOQueryConstants.trigger_ids.com_wheel_vo_follow_you,
		},
	},
	-- Medicae Station
    [17] = {
		icon = "content/ui/materials/hud/interactions/icons/pocketable_medkit",
		display_name = "loc_medicaestation",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_vo_tag_item,
			voice_tag_id = VOQueryConstants.trigger_ids.smart_tag_vo_station_health,
		},
	},
	-- Uncharged Medicae Station
    [18] = {
		icon = "content/ui/materials/hud/interactions/icons/pocketable_medkit",
		display_name = "loc_unchargedmedicae",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_vo_tag_item,
			voice_tag_id = VOQueryConstants.trigger_ids.smart_tag_vo_station_health_without_battery,
		},
	},
	-- Medipack
    [19] = {
		icon = "content/ui/materials/hud/interactions/icons/pocketable_medkit",
		display_name = "loc_medipack",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_vo_tag_item,
			voice_tag_id = VOQueryConstants.trigger_ids.smart_tag_vo_pickup_medical_crate,
		},
	},
	-- Medipack Down
    [20] = {
		icon = "content/ui/materials/hud/interactions/icons/pocketable_medkit",
		display_name = "loc_medipackdown",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_vo_tag_item,
			voice_tag_id = VOQueryConstants.trigger_ids.smart_tag_vo_pickup_deployed_medical_crate,
		},
	},
	-- Ammo Crate
    [21] = {
		icon = "content/ui/materials/hud/interactions/icons/pocketable_ammo",
		display_name = "loc_ammocrate",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_vo_tag_item,
			voice_tag_id = VOQueryConstants.trigger_ids.smart_tag_vo_pickup_deployed_ammo_crate,
		},
	},
	-- Need Ammo
	[22] = {
		icon = "content/ui/materials/hud/communication_wheel/icons/ammo",
		display_name = "loc_need_ammo",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_com_wheel,
			voice_tag_id = VOQueryConstants.trigger_ids.com_wheel_vo_need_ammo,
		},
	},
	-- Need Healing
	[23] = {
		icon = "content/ui/materials/hud/communication_wheel/icons/health",
		display_name = "loc_need_healing",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_com_wheel,
			voice_tag_id = VOQueryConstants.trigger_ids.com_wheel_vo_need_health,
		},
	},
	-- Look There
	[24] = {
		icon = "content/ui/materials/hud/communication_wheel/icons/attention",
		display_name = "loc_look_there",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_com_wheel,
			voice_tag_id = VOQueryConstants.trigger_ids.com_wheel_vo_over_here,
		},
	},
	-- Go There
	[25] = {
		icon = "content/ui/materials/hud/communication_wheel/icons/location",
		display_name = "loc_go_there",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_com_wheel,
			voice_tag_id = VOQueryConstants.trigger_ids.com_wheel_vo_lets_go_this_way,
		},
	},
	-- Enemy
	[26] = {
		icon = "content/ui/materials/hud/communication_wheel/icons/enemy",
		display_name = "loc_enemy",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_com_wheel,
			voice_tag_id = VOQueryConstants.trigger_ids.com_wheel_vo_enemy_over_here,
		},
	},
	-- Thanks
	[27] = {
		icon = "content/ui/materials/hud/communication_wheel/icons/thanks",
		display_name = "loc_thanks",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_com_wheel,
			voice_tag_id = VOQueryConstants.trigger_ids.com_wheel_vo_thank_you,
		},
	},
	-- Comms
	[28] = {
		icon = "content/ui/materials/hud/communication_wheel/icons/enemy",
		display_name = "loc_comms",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_com_wheel,
			voice_tag_id = VOQueryConstants.trigger_ids.smart_tag_vo_pickup_side_mission_communication_device,
		},
	},
}
 
mod:hook("HudElementSmartTagging", "_populate_wheel", function(func, self, options)
	local setting = 0

	setting = mod:get("plugin_wheel_bottom")
    if setting > 0 then
		options[POS_BOTTOM] = commands[setting]
	end

	setting = mod:get("plugin_wheel_bottom_right")
    if setting > 0 then
		options[POS_BOTTOM_RIGHT] = commands[setting]
	end

	setting = mod:get("plugin_wheel_right")
    if setting > 0 then
		options[POS_RIGHT] = commands[setting]
	end

	setting = mod:get("plugin_wheel_top_right")
    if setting > 0 then
		options[POS_TOP_RIGHT] = commands[setting]
	end

	setting = mod:get("plugin_wheel_top")
    if setting > 0 then
		options[POS_TOP] = commands[setting]
	end

	setting = mod:get("plugin_wheel_top_left")
    if setting > 0 then
		options[POS_TOP_LEFT] = commands[setting]
	end

	setting = mod:get("plugin_wheel_left")
    if setting > 0 then
		options[POS_LEFT] = commands[setting]
	end

	setting = mod:get("plugin_wheel_bottom_left")
    if setting > 0 then
		options[POS_BOTTOM_LEFT] = commands[setting]
	end
 
	func(self, options)
end)

local setup_keybind_functions = function()
	for key, option in pairs(commands) do
		mod["keybind_" .. key] = function()
			local voice_event_data = option.voice_event_data

			if voice_event_data then
				local parent = HudElementSmartTagging_instance._parent
				local player_unit = parent:player_unit()

				if player_unit then
					Vo.on_demand_vo_event(
						player_unit,
						voice_event_data.voice_tag_concept,
						voice_event_data.voice_tag_id
					)
				end
			end

			--Managers.telemetry_reporters:reporter("com_wheel"):register_event(option.voice_event_data.voice_tag_id)
		end
	end
end
 
mod:hook_safe("HudElementSmartTagging", "update", function(self)
	if not HudElementSmartTagging_instance then
		HudElementSmartTagging_instance = self

		setup_keybind_functions()
	end

	if mod.setting_dirty then
		self:_populate_wheel()
		mod.setting_dirty = false
	end
end)

--[[
mod.on_setting_changed = function(setting)
	if setting == "wheel_position" then
		wheel_position = mod:get(setting)

		if wheel_position == "left" then
			mod.wheel_options[LEFT_POSITION] = mod.wheel_options[RIGHT_POSITION]
			mod.wheel_options[RIGHT_POSITION] = nil
		elseif wheel_position == "right" then
			mod.wheel_options[RIGHT_POSITION] = mod.wheel_options[LEFT_POSITION]
			mod.wheel_options[LEFT_POSITION] = nil
		end

		mod.setting_dirty = true
	end
end
]]--

local init_keybind_functions = function()
	local fun = function()
		return
	end
	for key in pairs(commands) do
		mod["keybind_" .. key] = fun
	end
end

init_keybind_functions()