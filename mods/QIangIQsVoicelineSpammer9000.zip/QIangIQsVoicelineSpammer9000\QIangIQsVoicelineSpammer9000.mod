return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsVoicelineSpammer9000` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsVoicelineSpammer9000", {
			mod_script       = "QIangIQsVoicelineSpammer9000/scripts/mods/QIangIQsVoicelineSpammer9000/QIangIQsVoicelineSpammer9000",
			mod_data         = "QIangIQsVoicelineSpammer9000/scripts/mods/QIangIQsVoicelineSpammer9000/QIangIQsVoicelineSpammer9000_data",
			mod_localization = "QIangIQsVoicelineSpammer9000/scripts/mods/QIangIQsVoicelineSpammer9000/QIangIQsVoicelineSpammer9000_localization",
		})
	end,
	packages = {},
}
