return {
	mod_title = {
		en = "QIangIQsVoicelineSpammer9000 Sigma Skibidi Rizz Edition Elite Lite DLC++ Expansion Update V3.0 Configuration 67",
	},
	mod_description = {
		en = "I copied and pasted vacuum capsule lmao",
	},

	plugin_wheel_top = {
		en = "Top",
	},
	plugin_wheel_top_right = {
		en = "Top Right",
	},
	plugin_wheel_right = {
		en = "Right",
	},
	plugin_wheel_bottom_right = {
		en = "Bottom Right",
	},
	plugin_wheel_bottom = {
		en = "Bottom",
	},
	plugin_wheel_bottom_left = {
		en = "Bottom Left",
	},
	plugin_wheel_left = {
		en = "Left",
	},
	plugin_wheel_top_left = {
		en = "Top Left",
	},
	
	plugin_keybinds = {
		en = "Keybinds",
	},
	
	option_nil = {
		en = "None",
	},
	option_ammo = {
		en = "Ammo",
	},
	option_ammo_crate = {
		en = "Ammo Crate",
	},
	option_cryonic_rod = {
		en = "Cryonic Rod",
	},
	option_diamantine = {
		en = "Diamantine",
	},
	option_enemy = {
		en = "Enemy",
	},
	option_following = {
		en = "Following",
	},
	option_for_the_emperor = {
		en = "For The Emperor!",
	},
	option_go_there = {
		en = "Go There",
	},
	option_grenade = {
		en = "Grenade",
	},
	option_grimoire = {
		en = "Grimoire",
	},
	option_health_booster = {
		en = "Health Booster",
	},
	option_look_there = {
		en = "Look There",
	},
	option_medicae_station = {
		en = "Medicae Station",
	},
	option_medipack = {
		en = "Medipack",
	},
	option_medipack_down = {
		en = "Medipack Down",
	},
	option_mine = {
		en = "Mine",
	},
	option_need_ammo = {
		en = "Need Ammo",
	},
	option_need_healing = {
		en = "Need Healing",
	},
	option_no = {
		en = "No",
	},
	option_plasteel = {
		en = "Plasteel",
	},
	option_power_cell = {
		en = "Power Cell",
	},
	option_relic = {
		en = "Relic",
	},
	option_scripture = {
		en = "Scripture",
	},
	option_thanks = {
		en = "Thanks",
	},
	option_uncharged_medicae = {
		en = "Uncharged Medicae",
	},
	option_vacuum_capsule = {
		en = "Vacuum Capsule",
	},
	option_yes = {
		en = "Yes",
	},
	option_comms = {
		en = "Comms Device",
	},
	option_spot_rager = {
		en = "Spot: Rager",
	},
	option_spot_captain = {
		en = "Spot: Captain",
	},
	option_spot_pox_hound = {
		en = "Spot: Pox Hound",
	},
	option_spot_mutant = {
		en = "Spot: Mutant",
	},
	option_spot_crusher = {
		en = "Spot: Crusher",
	},
	option_spot_bulwark = {
		en = "Spot: Bulwark",
	},
	option_spot_reaper = {
		en = "Spot: Reaper",
	},
	option_spot_poxburster = {
		en = "Spot: Poxburster",
	},
	option_spot_chaos_spawn = {
		en = "Spot: Chaos Spawn",
	},
	option_spot_tox_flamer = {
		en = "Spot: Tox Flamer",
	},
	option_spot_tox_bomber = {
		en = "Spot: Tox Bomber",
	},
	option_spot_dreg_gunner = {
		en = "Spot: Dreg Gunner",
	},
	option_spot_dreg_shotgunner = {
		en = "Spot: Dreg Shotgunner",
	},
	option_spot_daemonhost = {
		en = "Spot: Daemonhost",
	},
	option_spot_daemonhost_awake = {
		en = "Spot: Daemonhost (Awake)",
	},
	option_spot_scab_flamer = {
		en = "Spot: Scab Flamer",
	},
	option_spot_scab_bomber = {
		en = "Spot: Scab Bomber",
	},
	option_spot_scab_gunner = {
		en = "Spot: Scab Gunner",
	},
	option_spot_scab_shotgunner = {
		en = "Spot: Scab Shotgunner",
	},
	option_spot_scab_mauler = {
		en = "Spot: Scab Mauler",
	},
	option_spot_sniper = {
		en = "Spot: Sniper",
	},
	option_spot_trapper = {
		en = "Spot: Trapper",
	},
	option_spot_trapper_flee = {
		en = "Spot: Trapper Fleeing",
	},
	option_spot_plague_ogryn = {
		en = "Spot: Plague Ogryn",
	},
	option_spot_plasma_gunner = {
		en = "Spot: Scab Plasma Gunner",
	},
	option_spot_houndmaster = {
		en = "Spot: Houndmaster",
	},
	option_spot_hunting_hound = {
		en = "Spot: Hunting Grounds Hound",
	},
	option_kill_dreg_rager = {
		en = "Kill: Dreg Rager",
	},
	option_kill_scab_rager = {
		en = "Kill: Scab Rager",
	},
	option_kill_pox_hound = {
		en = "Kill: Pox Hound",
	},
	option_kill_mutant = {
		en = "Kill: Mutant",
	},
	option_kill_poxburster = {
		en = "Kill: Poxburster",
	},
	option_kill_tox_flamer = {
		en = "Kill: Tox Flamer",
	},
	option_kill_scab_flamer = {
		en = "Kill: Scab Flamer",
	},
	option_kill_tox_bomber = {
		en = "Kill: Tox Bomber",
	},
	option_kill_scab_bomber = {
		en = "Kill: Scab Bomber",
	},
	option_kill_sniper = {
		en = "Kill: Sniper",
	},
	option_kill_trapper = {
		en = "Kill: Trapper",
	},
	option_kill_daemonhost = {
		en = "Kill: Daemonhost",
	},
	option_kill_houndmaster = {
		en = "Kill: Houndmaster",
	},
	option_kill_monster = {
		en = "Kill: Monster",
	},
	option_spot_heretic = {
		en = "Spot: Heretic (unreleased)",
	},
	option_spot_beast_of_nurgle = {
		en = "Spot: Beast of Nurgle",
	},
}
