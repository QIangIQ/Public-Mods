local mod = get_mod("QIangIQsVoicelineSpammer9000")

local VOQueryConstants = require("scripts/settings/dialogue/vo_query_constants")
local Vo = require("scripts/utilities/vo")

-- =========================================================
-- Primary patch: reduce dialogue event queue filtering time.
-- This is the more reliable approach because it targets the
-- queue-level suppression window.
--
-- Fallback patch: direct forced VO trigger path. This is less
-- reliable and is disabled by default. Enable it only if the
-- queue filter patch alone does not solve the issue.
-- =========================================================

local ENABLE_QUEUE_FILTER_PATCH = true
local QUEUE_FILTER_MAX_DURATION = 0.1

local ENABLE_FORCED_VO_FALLBACK = false

if ENABLE_QUEUE_FILTER_PATCH then
	mod:hook("DialogueEventQueue", "filter_events_under", function(func, self, category, duration)
		duration = math.min(duration or 0, QUEUE_FILTER_MAX_DURATION)
		return func(self, category, duration)
	end)
end

local original_on_demand_vo_event = Vo.on_demand_vo_event

-- =========================================================
-- Elite callouts (2026-10-30).
-- Spotted lines: rules "smart_tag_vo_enemy_*" in
-- dialogues/generated/on_demand_vo.lua, concept
-- on_demand_vo_tag_enemy, matched on query_context.enemy_tag.
-- Kill lines: rules "enemy_kill_*" in dialogues/generated/gameplay_vo.lua,
-- concept enemy_kill, matched on query_context.killed_type
-- (same payload Vo.enemy_kill_event sends).
-- Values must exist in dialogue_lookup_contexts.lua or a client
-- drops the RPC silently (trigger_networked_dialogue_event).
-- =========================================================

local ENEMY_KILL_CONCEPT = "enemy_kill"

-- { network value (nil = local only), display key, display text, responses to play locally }
-- Responses are the rule/response names in dialogues/generated/on_demand_vo_<voice>.lua and
-- gameplay_vo_<voice>.lua; the first one this voice has is played.
local ELITE_SPOTTED = {
	{ "cultist_berzerker", "loc_spot_rager", "Spot: Rager", { "smart_tag_vo_enemy_berserker" } },
	{ "renegade_captain", "loc_spot_captain", "Spot: Captain", { "smart_tag_vo_enemy_captain" } },
	{ "chaos_hound", "loc_spot_pox_hound", "Spot: Pox Hound", { "smart_tag_vo_enemy_chaos_hound" } },
	{ "cultist_mutant", "loc_spot_mutant", "Spot: Mutant", { "smart_tag_vo_enemy_chaos_mutant_charger" } },
	{ "chaos_ogryn_executor", "loc_spot_crusher", "Spot: Crusher", { "smart_tag_vo_enemy_chaos_ogryn_armored_executor" } },
	{ "chaos_ogryn_bulwark", "loc_spot_bulwark", "Spot: Bulwark", { "smart_tag_vo_enemy_chaos_ogryn_bulwark" } },
	{ "chaos_ogryn_gunner", "loc_spot_reaper", "Spot: Reaper", { "smart_tag_vo_enemy_chaos_ogryn_heavy_gunner" } },
	{ "chaos_poxwalker_bomber", "loc_spot_poxburster", "Spot: Poxburster", { "smart_tag_vo_enemy_chaos_poxwalker_bomber" } },
	{ "chaos_spawn", "loc_spot_chaos_spawn", "Spot: Chaos Spawn", { "smart_tag_vo_enemy_chaos_spawn" } },
	{ "cultist_flamer", "loc_spot_tox_flamer", "Spot: Tox Flamer", { "smart_tag_vo_enemy_cultist_flamer", "smart_tag_vo_enemy_flamer" } },
	{ "cultist_grenadier", "loc_spot_tox_bomber", "Spot: Tox Bomber", { "smart_tag_vo_enemy_cultist_grenadier", "smart_tag_vo_enemy_grenadier" } },
	{ "cultist_gunner", "loc_spot_dreg_gunner", "Spot: Dreg Gunner", { "smart_tag_vo_enemy_cultist_holy_stubber_gunner", "smart_tag_vo_enemy_gunner" } },
	{ "cultist_shocktrooper", "loc_spot_dreg_shotgunner", "Spot: Dreg Shotgunner", { "smart_tag_vo_enemy_cultist_shocktrooper", "smart_tag_vo_enemy_shocktrooper" } },
	{ "chaos_daemonhost", "loc_spot_daemonhost", "Spot: Daemonhost", { "smart_tag_vo_enemy_daemonhost_witch_not_alerted" } },
	{ "aggroed", "loc_spot_daemonhost_awake", "Spot: Daemonhost (Awake)", { "smart_tag_vo_enemy_daemonhost_witch" } },
	{ "renegade_flamer", "loc_spot_scab_flamer", "Spot: Scab Flamer", { "smart_tag_vo_enemy_scab_flamer", "smart_tag_vo_enemy_flamer" } },
	{ "renegade_grenadier", "loc_spot_scab_bomber", "Spot: Scab Bomber", { "smart_tag_vo_enemy_traitor_grenadier", "smart_tag_vo_enemy_grenadier" } },
	{ "renegade_gunner", "loc_spot_scab_gunner", "Spot: Scab Gunner", { "smart_tag_vo_enemy_traitor_gunner", "smart_tag_vo_enemy_gunner" } },
	{ "renegade_shocktrooper", "loc_spot_scab_shotgunner", "Spot: Scab Shotgunner", { "smart_tag_vo_enemy_traitor_scout_shocktrooper", "smart_tag_vo_enemy_shocktrooper" } },
	{ "renegade_executor", "loc_spot_scab_mauler", "Spot: Scab Mauler", { "smart_tag_vo_enemy_traitor_executor" } },
	{ "renegade_sniper", "loc_spot_sniper", "Spot: Sniper", { "smart_tag_vo_enemy_traitor_sniper" } },
	{ "renegade_netgunner", "loc_spot_trapper", "Spot: Trapper", { "smart_tag_vo_enemy_netgunner" } },
	{ "seen_netgunner_flee", "loc_spot_trapper_flee", "Spot: Trapper Fleeing", { "seen_netgunner_flee" } },
	{ "chaos_plague_ogryn", "loc_spot_plague_ogryn", "Spot: Plague Ogryn", { "smart_tag_vo_enemy_plague_ogryn" } },
	{ "renegade_plasma_gunner", "loc_spot_plasma_gunner", "Spot: Scab Plasma Gunner", { "smart_tag_vo_enemy_plasma" } },
	{ "chaos_ogryn_houndmaster", "loc_spot_houndmaster", "Spot: Houndmaster", { "smart_tag_vo_enemy_houndmaster" } },
	{ "chaos_hound_mutator", "loc_spot_hunting_hound", "Spot: Hunting Grounds Hound", { "smart_tag_vo_enemy_chaos_hound_mutator", "smart_tag_vo_enemy_chaos_hound" } },
}

-- { killed_type, display key, display text, responses to play locally }
local ELITE_KILLED = {
	{ "cultist_berzerker", "loc_kill_dreg_rager", "Kill: Dreg Rager", { "enemy_kill_berserker" } },
	{ "renegade_berzerker", "loc_kill_scab_rager", "Kill: Scab Rager", { "enemy_kill_renegade_berserker", "enemy_kill_berserker" } },
	{ "chaos_hound", "loc_kill_pox_hound", "Kill: Pox Hound", { "enemy_kill_chaos_hound" } },
	{ "cultist_mutant", "loc_kill_mutant", "Kill: Mutant", { "enemy_kill_mutant_charger" } },
	{ "chaos_poxwalker_bomber", "loc_kill_poxburster", "Kill: Poxburster", { "enemy_kill_poxwalker_bomber" } },
	{ "cultist_flamer", "loc_kill_tox_flamer", "Kill: Tox Flamer", { "enemy_kill_tox_flamer" } },
	{ "renegade_flamer", "loc_kill_scab_flamer", "Kill: Scab Flamer", { "enemy_kill_scab_flamer" } },
	{ "cultist_grenadier", "loc_kill_tox_bomber", "Kill: Tox Bomber", { "enemy_kill_cultist_grenadier", "enemy_kill_grenadier" } },
	{ "renegade_grenadier", "loc_kill_scab_bomber", "Kill: Scab Bomber", { "enemy_kill_grenadier" } },
	{ "renegade_sniper", "loc_kill_sniper", "Kill: Sniper", { "enemy_kill_sniper" } },
	{ "renegade_netgunner", "loc_kill_trapper", "Kill: Trapper", { "enemy_kill_netgunner" } },
	{ "chaos_daemonhost", "loc_kill_daemonhost", "Kill: Daemonhost", { "enemy_kill_daemonhost" } },
	{ "chaos_ogryn_houndmaster", "loc_kill_houndmaster", "Kill: Houndmaster", { "enemy_kill_houndmaster" } },
	{ "monster", "loc_kill_monster", "Kill: Monster", { "enemy_kill_monster" } },
}

-- Lines with audio but no rule; only you hear these.
local HERETIC_RESPONSE = "qiangiq_smart_tag_vo_enemy_heretic"
local ELITE_LOCAL_ONLY = {
	{ nil, "loc_spot_heretic", "Spot: Heretic (unreleased)", { HERETIC_RESPONSE } },
	{ nil, "loc_spot_beast_of_nurgle", "Spot: Beast of Nurgle", { "seen_enemy_beast_of_nurgle" } },
}

-- wwise/externals/loc_<voice>__smart_tag_vo_enemy_heretic_NN in the bundle index (2026-10-30);
-- only these six voices have them.
local HERETIC_LINES = {
	broker_female_c = 15,
	broker_male_c = 15,
	veteran_female_b = 15,
	veteran_male_b = 15,
	zealot_female_b = 15,
	psyker_male_b = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 18, 19, 20, 21 },
}

local ELITE_COMMAND_START = 29
-- Wheel and keybind options carry this concept and their command index;
-- the Vo.on_demand_vo_event hook below resolves them through ELITE_OPTIONS.
local ELITE_CONCEPT = "qiangiq_elite_callout"
local ELITE_OPTIONS = {}
local LOCAL_LINE_ROUTE = 0
local ECHO_WINDOW = 4

-- Adds the unreleased heretic lines to this voice's response table so
-- play_local_vo_event can use them like any other response.
local function ensure_heretic_response(dialogue_extension)
	local vo_choice = dialogue_extension._vo_choice
	local voice = dialogue_extension._vo_profile_name
	local lines = voice and HERETIC_LINES[voice]

	if not vo_choice or not lines then
		return
	end

	if vo_choice[HERETIC_RESPONSE] then
		return
	end

	local indexes = lines

	if type(lines) == "number" then
		indexes = {}

		for i = 1, lines do
			indexes[i] = i
		end
	end

	local sound_events, durations = {}, {}

	for i, index in ipairs(indexes) do
		sound_events[i] = string.format("loc_%s__smart_tag_vo_enemy_heretic_%02d", voice, index)
		durations[i] = 2
	end

	vo_choice[HERETIC_RESPONSE] = {
		randomize_indexes_n = 0,
		sound_events_n = #sound_events,
		sound_events = sound_events,
		sound_events_duration = durations,
		randomize_indexes = {},
	}
end

local last_local_play = {
	responses = nil,
	t = -math.huge,
}

local function play_elite_line_locally(dialogue_extension, responses)
	if responses[1] == HERETIC_RESPONSE then
		ensure_heretic_response(dialogue_extension)
	end

	local vo_choice = dialogue_extension._vo_choice

	if not vo_choice then
		return false
	end

	for _, response in ipairs(responses) do
		if vo_choice[response] then
			pcall(function()
				dialogue_extension:stop_currently_playing_vo()
			end)

			dialogue_extension:play_local_vo_event(response, LOCAL_LINE_ROUTE)

			last_local_play.responses = responses
			last_local_play.t = Managers.time:time("main")

			return true
		end
	end

	return false
end

-- The com wheel calls Vo.on_demand_vo_event without a target unit, so
-- enemy tags and kill callouts are sent here the same way vanilla
-- Vo.on_demand_vo_event / Vo.enemy_kill_event build their payloads.
local function send_elite_event(dialogue_extension, concept, value)
	local event_data = dialogue_extension:get_event_data_payload()

	if concept == ENEMY_KILL_CONCEPT then
		event_data.killed_type = value
	else
		event_data.enemy_tag = value
	end

	dialogue_extension:trigger_dialogue_event(concept, event_data)
end

local function trigger_elite_option(unit, option)
	local dialogue_extension = unit and ScriptUnit.has_extension(unit, "dialogue_system")

	if not dialogue_extension then
		return
	end

	-- Played on this PC every press, no rule cooldowns. The server copy
	-- (when its rules allow it) is what teammates hear.
	local played = play_elite_line_locally(dialogue_extension, option.responses)

	if not played then
		mod:notify("This voice has no line for that callout.")
	end

	if option.value then
		send_elite_event(dialogue_extension, option.concept, option.value)
	end
end

mod:hook(Vo, "on_demand_vo_event", function(func, unit, concept, trigger_id, target_unit)
	if concept == ELITE_CONCEPT then
		local option = ELITE_OPTIONS[trigger_id]

		if option then
			trigger_elite_option(unit, option)
		end

		return
	end

	if concept == ENEMY_KILL_CONCEPT or (concept == VOQueryConstants.concepts.on_demand_vo_tag_enemy and not target_unit) then
		local dialogue_extension = unit and ScriptUnit.has_extension(unit, "dialogue_system")

		if dialogue_extension then
			send_elite_event(dialogue_extension, concept, trigger_id)
		end

		return
	end

	return func(unit, concept, trigger_id, target_unit)
end)

-- Skip the server's echo of a line we just played locally, so it does not
-- cut off and replay on our own character.
mod:hook("DialogueSystem", "_play_dialogue_event_implementation", function(func, self, go_id, is_level_unit, level_name_hash, dialogue_id, ...)
	local responses = last_local_play.responses

	if responses and Managers.time:time("main") - last_local_play.t < ECHO_WINDOW then
		local dialogue_name = NetworkLookup.dialogue_names[dialogue_id]
		local unit = Managers.state.unit_spawner:unit(go_id, is_level_unit, level_name_hash)
		local player = Managers.player:local_player_safe(1)

		if unit and player and unit == player.player_unit and table.contains(responses, dialogue_name) then
			last_local_play.responses = nil

			return
		end
	end

	return func(self, go_id, is_level_unit, level_name_hash, dialogue_id, ...)
end)

local function force_on_demand_vo_event(unit, concept, trigger_id, target_unit)
	local dialogue_extension = ScriptUnit.has_extension(unit, "dialogue_system")

	if not dialogue_extension then
		return
	end

	local concepts = VOQueryConstants.concepts
	local event_data = dialogue_extension:get_event_data_payload()

	if concept == concepts.on_demand_com_wheel or concept == concepts.generic_mission_vo then
		event_data.trigger_id = trigger_id
	elseif concept == concepts.on_demand_vo_tag_enemy then
		local target_extension = target_unit and ScriptUnit.has_extension(target_unit, "dialogue_system")

		if target_extension then
			local dynamic_smart_tag = target_extension:get_dynamic_smart_tag()
			event_data.enemy_tag = dynamic_smart_tag or trigger_id
		else
			event_data.enemy_tag = trigger_id
		end
	elseif concept == concepts.on_demand_vo_tag_item then
		event_data.item_tag = trigger_id
	end

	pcall(function()
		dialogue_extension:stop_currently_playing_vo()
	end)

	event_data._anti_spam_nonce = math.random()

	dialogue_extension:trigger_dialogue_event(concept, event_data)
end

local HudElementSmartTagging_instance

local POS_BOTTOM = 1
local POS_BOTTOM_RIGHT = 2
local POS_RIGHT = 3
local POS_TOP_RIGHT = 4
local POS_TOP = 5
local POS_TOP_LEFT = 6
local POS_LEFT = 7
local POS_BOTTOM_LEFT = 8

mod:hook(LocalizationManager, "localize", function(func, self, key, no_cache, context)
	self._string_cache.loc_ammo = "Ammo"
	self._string_cache.loc_ammocrate = "Ammo Crate"
	self._string_cache.loc_cheer = "For the Emperor!"
	self._string_cache.loc_cryorod = "Cryonic Rod"
	self._string_cache.loc_diamantine = "Diamantine"
	self._string_cache.loc_enemy = "Enemy"
	self._string_cache.loc_following = "Following"
	self._string_cache.loc_go_there = "Go There"
	self._string_cache.loc_grenade = "Grenade"
	self._string_cache.loc_grim = "Grimoire"
	self._string_cache.loc_healthbooster = "Health Booster"
	self._string_cache.loc_look_there = "Look There"
	self._string_cache.loc_medicaestation = "Medicae Station"
	self._string_cache.loc_medipack = "Medipack"
	self._string_cache.loc_medipackdown = "Medipack Down"
	self._string_cache.loc_mine = "Mine"
	self._string_cache.loc_need_ammo = "Need Ammo"
	self._string_cache.loc_need_healing = "Need Healing"
	self._string_cache.loc_no = "No"
	self._string_cache.loc_plasteel = "Plasteel"
	self._string_cache.loc_power_cell = "Power Cell"
	self._string_cache.loc_relic = "Relic"
	self._string_cache.loc_scripture = "Scripture"
	self._string_cache.loc_thanks = "Thanks"
	self._string_cache.loc_unchargedmedicae = "Uncharged Medicae"
	self._string_cache.loc_vacuum_capsule = "Vacuum Capsule"
	self._string_cache.loc_yes = "Yes"
	self._string_cache.loc_comms = "Comms Device"
	for _, entry in ipairs(ELITE_SPOTTED) do
		self._string_cache[entry[2]] = entry[3]
	end
	for _, entry in ipairs(ELITE_KILLED) do
		self._string_cache[entry[2]] = entry[3]
	end
	for _, entry in ipairs(ELITE_LOCAL_ONLY) do
		self._string_cache[entry[2]] = entry[3]
	end
	return func(self, key, no_cache, context)
end)

local commands = {
    [1] = {
		icon = "content/ui/materials/icons/system/escape/achievements",
		display_name = "loc_cheer",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_com_wheel,
			voice_tag_id = VOQueryConstants.trigger_ids.com_wheel_vo_for_the_emperor,
		},
	},
	-- Vacuum Capsule
    [2] = {
		icon = "content/ui/materials/hud/interactions/icons/training_grounds",
		display_name = "loc_vacuum_capsule",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_vo_tag_item,
			voice_tag_id = VOQueryConstants.trigger_ids.smart_tag_vo_pickup_container,
		},
	},
	-- Yes
    [3] = {
		icon = "content/ui/materials/icons/pocketables/hud/scripture",
		display_name = "loc_yes",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_com_wheel,
			voice_tag_id = VOQueryConstants.trigger_ids.com_wheel_vo_yes,
		},
	},
	-- No
    [4] = {
		icon = "content/ui/materials/icons/system/settings/category_interface",
		display_name = "loc_no",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_com_wheel,
			voice_tag_id = VOQueryConstants.trigger_ids.com_wheel_vo_no,
		},
	},
	-- Cryonic Rod
    [5] = {
		icon = "content/ui/materials/hud/interactions/icons/training_grounds",
		display_name = "loc_cryorod",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_vo_tag_item,
			voice_tag_id = VOQueryConstants.trigger_ids.smart_tag_vo_pickup_control_rod,
		},
	},
	-- Power Cell
    [6] = {
		icon = "content/ui/materials/hud/interactions/icons/training_grounds",
		display_name = "loc_power_cell",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_vo_tag_item,
			voice_tag_id = VOQueryConstants.trigger_ids.smart_tag_vo_pickup_battery
		},
	},
	-- Scripture
    [7] = {
		icon = "content/ui/materials/icons/pocketables/hud/scripture",
		display_name = "loc_scripture",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_vo_tag_item,
			voice_tag_id = VOQueryConstants.trigger_ids.smart_tag_vo_pickup_side_mission_tome,
		},
	},
	-- Grimoire
    [8] = {
		icon = "content/ui/materials/icons/pocketables/hud/grimoire",
		display_name = "loc_grim",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_vo_tag_item,
			voice_tag_id = VOQueryConstants.trigger_ids.smart_tag_vo_pickup_side_mission_grimoire,
		},
	},
	-- Relic
    [9] = {
		icon = "content/ui/materials/icons/pocketables/hud/grimoire",
		display_name = "loc_relic",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_vo_tag_item,
			voice_tag_id = VOQueryConstants.trigger_ids.smart_tag_vo_pickup_side_mission_consumable,
		},
	},
	-- Health Booster
    [10] = {
		icon = "content/ui/materials/hud/interactions/icons/pocketable_medkit",
		display_name = "loc_healthbooster",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_vo_tag_item,
			voice_tag_id = VOQueryConstants.trigger_ids.smart_tag_vo_pickup_health_booster,
		},
	},
	-- Mine
    [11] = {
		icon = "content/ui/materials/hud/interactions/icons/pocketable_default",
		display_name = "loc_mine",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_com_wheel,
			voice_tag_id = VOQueryConstants.trigger_ids.com_wheel_vo_need_that,
		},
	},
	-- Ammo
    [12] = {
		icon = "content/ui/materials/hud/interactions/icons/pocketable_ammo",
		display_name = "loc_ammo",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_vo_tag_item,
			voice_tag_id = VOQueryConstants.trigger_ids.smart_tag_vo_pickup_ammo,
		},
	},
	-- Grenade
    [13] = {
		icon = "content/ui/materials/hud/interactions/icons/pocketable_default",
		display_name = "loc_grenade",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_vo_tag_item,
			voice_tag_id = VOQueryConstants.trigger_ids.smart_tag_vo_small_grenade,
		},
	},
	-- Plasteel
    [14] = {
		icon = "content/ui/materials/hud/interactions/icons/pocketable_default",
		display_name = "loc_plasteel",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_vo_tag_item,
			voice_tag_id = VOQueryConstants.trigger_ids.smart_tag_vo_pickup_forge_metal,
		},
	},
	-- Diamantine
    [15] = {
		icon = "content/ui/materials/hud/interactions/icons/pocketable_default",
		display_name = "loc_diamantine",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_vo_tag_item,
			voice_tag_id = VOQueryConstants.trigger_ids.smart_tag_vo_pickup_platinum,
		},
	},
	-- Following
    [16] = {
		icon = "content/ui/materials/icons/pocketables/hud/scripture",
		display_name = "loc_following",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_com_wheel,
			voice_tag_id = VOQueryConstants.trigger_ids.com_wheel_vo_follow_you,
		},
	},
	-- Medicae Station
    [17] = {
		icon = "content/ui/materials/hud/interactions/icons/pocketable_medkit",
		display_name = "loc_medicaestation",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_vo_tag_item,
			voice_tag_id = VOQueryConstants.trigger_ids.smart_tag_vo_station_health,
		},
	},
	-- Uncharged Medicae Station
    [18] = {
		icon = "content/ui/materials/hud/interactions/icons/pocketable_medkit",
		display_name = "loc_unchargedmedicae",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_vo_tag_item,
			voice_tag_id = VOQueryConstants.trigger_ids.smart_tag_vo_station_health_without_battery,
		},
	},
	-- Medipack
    [19] = {
		icon = "content/ui/materials/hud/interactions/icons/pocketable_medkit",
		display_name = "loc_medipack",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_vo_tag_item,
			voice_tag_id = VOQueryConstants.trigger_ids.smart_tag_vo_pickup_medical_crate,
		},
	},
	-- Medipack Down
    [20] = {
		icon = "content/ui/materials/hud/interactions/icons/pocketable_medkit",
		display_name = "loc_medipackdown",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_vo_tag_item,
			voice_tag_id = VOQueryConstants.trigger_ids.smart_tag_vo_pickup_deployed_medical_crate,
		},
	},
	-- Ammo Crate
    [21] = {
		icon = "content/ui/materials/hud/interactions/icons/pocketable_ammo",
		display_name = "loc_ammocrate",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_vo_tag_item,
			voice_tag_id = VOQueryConstants.trigger_ids.smart_tag_vo_pickup_deployed_ammo_crate,
		},
	},
	-- Need Ammo
	[22] = {
		icon = "content/ui/materials/hud/communication_wheel/icons/ammo",
		display_name = "loc_need_ammo",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_com_wheel,
			voice_tag_id = VOQueryConstants.trigger_ids.com_wheel_vo_need_ammo,
		},
	},
	-- Need Healing
	[23] = {
		icon = "content/ui/materials/hud/communication_wheel/icons/health",
		display_name = "loc_need_healing",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_com_wheel,
			voice_tag_id = VOQueryConstants.trigger_ids.com_wheel_vo_need_health,
		},
	},
	-- Look There
	[24] = {
		icon = "content/ui/materials/hud/communication_wheel/icons/attention",
		display_name = "loc_look_there",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_com_wheel,
			voice_tag_id = VOQueryConstants.trigger_ids.com_wheel_vo_over_here,
		},
	},
	-- Go There
	[25] = {
		icon = "content/ui/materials/hud/communication_wheel/icons/location",
		display_name = "loc_go_there",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_com_wheel,
			voice_tag_id = VOQueryConstants.trigger_ids.com_wheel_vo_lets_go_this_way,
		},
	},
	-- Enemy
	[26] = {
		icon = "content/ui/materials/hud/communication_wheel/icons/enemy",
		display_name = "loc_enemy",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_com_wheel,
			voice_tag_id = VOQueryConstants.trigger_ids.com_wheel_vo_enemy_over_here,
		},
	},
	-- Thanks
	[27] = {
		icon = "content/ui/materials/hud/communication_wheel/icons/thanks",
		display_name = "loc_thanks",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_com_wheel,
			voice_tag_id = VOQueryConstants.trigger_ids.com_wheel_vo_thank_you,
		},
	},
	-- Comms
	[28] = {
		icon = "content/ui/materials/hud/communication_wheel/icons/enemy",
		display_name = "loc_comms",
		voice_event_data = {
			voice_tag_concept = VOQueryConstants.concepts.on_demand_com_wheel,
			voice_tag_id = VOQueryConstants.trigger_ids.smart_tag_vo_pickup_side_mission_communication_device,
		},
	},
}

-- Elite callouts: 29.. spotted, killed, then local-only (order must match _data.lua)
do
	local index = ELITE_COMMAND_START
	local groups = {
		{ ELITE_SPOTTED, VOQueryConstants.concepts.on_demand_vo_tag_enemy },
		{ ELITE_KILLED, ENEMY_KILL_CONCEPT },
		{ ELITE_LOCAL_ONLY, nil },
	}

	for _, group in ipairs(groups) do
		for _, entry in ipairs(group[1]) do
			commands[index] = {
				icon = "content/ui/materials/hud/communication_wheel/icons/enemy",
				display_name = entry[2],
				voice_event_data = {
					voice_tag_concept = ELITE_CONCEPT,
					voice_tag_id = index,
				},
			}
			ELITE_OPTIONS[index] = {
				concept = group[2],
				value = entry[1],
				responses = entry[4],
			}
			index = index + 1
		end
	end
end

mod:hook("HudElementSmartTagging", "_populate_wheel", function(func, self, options)
	local setting = 0

	setting = mod:get("plugin_wheel_bottom")
    if setting > 0 then
		options[POS_BOTTOM] = commands[setting]
	end

	setting = mod:get("plugin_wheel_bottom_right")
    if setting > 0 then
		options[POS_BOTTOM_RIGHT] = commands[setting]
	end

	setting = mod:get("plugin_wheel_right")
    if setting > 0 then
		options[POS_RIGHT] = commands[setting]
	end

	setting = mod:get("plugin_wheel_top_right")
    if setting > 0 then
		options[POS_TOP_RIGHT] = commands[setting]
	end

	setting = mod:get("plugin_wheel_top")
    if setting > 0 then
		options[POS_TOP] = commands[setting]
	end

	setting = mod:get("plugin_wheel_top_left")
    if setting > 0 then
		options[POS_TOP_LEFT] = commands[setting]
	end

	setting = mod:get("plugin_wheel_left")
    if setting > 0 then
		options[POS_LEFT] = commands[setting]
	end

	setting = mod:get("plugin_wheel_bottom_left")
    if setting > 0 then
		options[POS_BOTTOM_LEFT] = commands[setting]
	end

	func(self, options)
end)

local setup_keybind_functions = function()
	for key, option in pairs(commands) do
		mod["keybind_" .. key] = function()
			local voice_event_data = option.voice_event_data

			if voice_event_data then
				local parent = HudElementSmartTagging_instance._parent
				local player_unit = parent:player_unit()

				if player_unit then
					if ENABLE_FORCED_VO_FALLBACK then
						force_on_demand_vo_event(
							player_unit,
							voice_event_data.voice_tag_concept,
							voice_event_data.voice_tag_id
						)
					else
						Vo.on_demand_vo_event(
							player_unit,
							voice_event_data.voice_tag_concept,
							voice_event_data.voice_tag_id
						)
					end
				end
			end

			--Managers.telemetry_reporters:reporter("com_wheel"):register_event(option.voice_event_data.voice_tag_id)
		end
	end
end

mod:hook_safe("HudElementSmartTagging", "update", function(self)
	if not HudElementSmartTagging_instance then
		HudElementSmartTagging_instance = self

		setup_keybind_functions()
	end

	if mod.setting_dirty then
		self:_populate_wheel()
		mod.setting_dirty = false
	end
end)

--[[
mod.on_setting_changed = function(setting)
	if setting == "wheel_position" then
		wheel_position = mod:get(setting)

		if wheel_position == "left" then
			mod.wheel_options[LEFT_POSITION] = mod.wheel_options[RIGHT_POSITION]
			mod.wheel_options[RIGHT_POSITION] = nil
		elseif wheel_position == "right" then
			mod.wheel_options[RIGHT_POSITION] = mod.wheel_options[LEFT_POSITION]
			mod.wheel_options[LEFT_POSITION] = nil
		end

		mod.setting_dirty = true
	end
end
]]--

local init_keybind_functions = function()
	local fun = function()
		return
	end
	for key in pairs(commands) do
		mod["keybind_" .. key] = fun
	end
end

init_keybind_functions()
