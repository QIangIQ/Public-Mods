local mod = get_mod("QIangIQsVoicelineSpammer9000")

local function get_options()
	return {
		{ text = "option_nil", value = 0 },
		{ text = "option_ammo", value = 12 },
		{ text = "option_ammo_crate", value = 21 },
		{ text = "option_cryonic_rod", value = 5 },
		{ text = "option_diamantine", value = 15 },
		{ text = "option_enemy", value = 26 },
		{ text = "option_following", value = 16 },
		{ text = "option_for_the_emperor", value = 1 },
		{ text = "option_go_there", value = 25 },
		{ text = "option_grenade", value = 13 },
		{ text = "option_grimoire", value = 8 },
		{ text = "option_health_booster", value = 10 },
		{ text = "option_look_there", value = 24 },
		{ text = "option_medicae_station", value = 17 },
		{ text = "option_medipack", value = 19 },
		{ text = "option_medipack_down", value = 20 },
		{ text = "option_mine", value = 11 },
		{ text = "option_need_ammo", value = 22 },
		{ text = "option_need_healing", value = 23 },
		{ text = "option_no", value = 4 },
		{ text = "option_plasteel", value = 14 },
		{ text = "option_power_cell", value = 6 },
		{ text = "option_relic", value = 9 },
		{ text = "option_scripture", value = 7 },
		{ text = "option_thanks", value = 27 },
		{ text = "option_uncharged_medicae", value = 18 },
		{ text = "option_vacuum_capsule", value = 2 },
		{ text = "option_yes", value = 3 },
		{ text = "option_comms", value = 28 },
		-- Elite callouts (must match ELITE_SPOTTED / ELITE_KILLED order in the main file)
		{ text = "option_spot_rager", value = 29 },
		{ text = "option_spot_captain", value = 30 },
		{ text = "option_spot_pox_hound", value = 31 },
		{ text = "option_spot_mutant", value = 32 },
		{ text = "option_spot_crusher", value = 33 },
		{ text = "option_spot_bulwark", value = 34 },
		{ text = "option_spot_reaper", value = 35 },
		{ text = "option_spot_poxburster", value = 36 },
		{ text = "option_spot_chaos_spawn", value = 37 },
		{ text = "option_spot_tox_flamer", value = 38 },
		{ text = "option_spot_tox_bomber", value = 39 },
		{ text = "option_spot_dreg_gunner", value = 40 },
		{ text = "option_spot_dreg_shotgunner", value = 41 },
		{ text = "option_spot_daemonhost", value = 42 },
		{ text = "option_spot_daemonhost_awake", value = 43 },
		{ text = "option_spot_scab_flamer", value = 44 },
		{ text = "option_spot_scab_bomber", value = 45 },
		{ text = "option_spot_scab_gunner", value = 46 },
		{ text = "option_spot_scab_shotgunner", value = 47 },
		{ text = "option_spot_scab_mauler", value = 48 },
		{ text = "option_spot_sniper", value = 49 },
		{ text = "option_spot_trapper", value = 50 },
		{ text = "option_spot_trapper_flee", value = 51 },
		{ text = "option_spot_plague_ogryn", value = 52 },
		{ text = "option_spot_plasma_gunner", value = 53 },
		{ text = "option_spot_houndmaster", value = 54 },
		{ text = "option_spot_hunting_hound", value = 55 },
		{ text = "option_kill_dreg_rager", value = 56 },
		{ text = "option_kill_scab_rager", value = 57 },
		{ text = "option_kill_pox_hound", value = 58 },
		{ text = "option_kill_mutant", value = 59 },
		{ text = "option_kill_poxburster", value = 60 },
		{ text = "option_kill_tox_flamer", value = 61 },
		{ text = "option_kill_scab_flamer", value = 62 },
		{ text = "option_kill_tox_bomber", value = 63 },
		{ text = "option_kill_scab_bomber", value = 64 },
		{ text = "option_kill_sniper", value = 65 },
		{ text = "option_kill_trapper", value = 66 },
		{ text = "option_kill_daemonhost", value = 67 },
		{ text = "option_kill_houndmaster", value = 68 },
		{ text = "option_kill_monster", value = 69 },
		{ text = "option_spot_heretic", value = 70 },
		{ text = "option_spot_beast_of_nurgle", value = 71 },
	}
end

local function get_keybind_widgets()
    local widgets = {}

	for i, option in ipairs(get_options()) do
		if option.value > 0 then
			widgets[i - 1] = {
				setting_id = option.text,
				type = "keybind",
				keybind_trigger = "pressed",
				keybind_type = "function_call",
				function_name = "keybind_" .. option.value,
				default_value = {},
			}
		end
	end

	return widgets
end

return {
	name = mod:localize("mod_title"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			{
				setting_id = "plugin_wheel_top_left",
				type = "dropdown",
				default_value = 0,
				options = get_options(),
			},
			{
				setting_id = "plugin_wheel_top",
				type = "dropdown",
				default_value = 0,
				options = get_options(),
			},
			{
				setting_id = "plugin_wheel_top_right",
				type = "dropdown",
				default_value = 0,
				options = get_options(),
			},
			{
				setting_id = "plugin_wheel_left",
				type = "dropdown",
				default_value = 0,
				options = get_options(),
			},
			{
				setting_id = "plugin_wheel_right",
				type = "dropdown",
				default_value = 0,
				options = get_options(),
			},
			{
				setting_id = "plugin_wheel_bottom_left",
				type = "dropdown",
				default_value = 0,
				options = get_options(),
			},
			{
				setting_id = "plugin_wheel_bottom",
				type = "dropdown",
				default_value = 0,
				options = get_options(),
			},
			{
				setting_id = "plugin_wheel_bottom_right",
				type = "dropdown",
				default_value = 0,
				options = get_options(),
			},
			{
				setting_id = "plugin_keybinds",
				type = "group",
				sub_widgets = get_keybind_widgets(),
			},
		},
	},
}
