local mod = get_mod("QIangIQsTorid")

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = false,
    options = {
        widgets = {
            { setting_id = "add_to_unlock_list", type = "checkbox", default_value = true },
            { setting_id = "unlock_level", type = "numeric", default_value = 1, range = { 1, 30 }, decimals_number = 0 },
            { setting_id = "model_scale", type = "numeric", default_value = 1, range = { 0.5, 1.5 }, decimals_number = 2 },
            { setting_id = "model_forward", type = "numeric", default_value = 0, range = { -0.3, 0.3 }, decimals_number = 2 },
            { setting_id = "model_up", type = "numeric", default_value = 0, range = { -0.2, 0.2 }, decimals_number = 2 },
            { setting_id = "model_side", type = "numeric", default_value = 0, range = { -0.2, 0.2 }, decimals_number = 2 },
            { setting_id = "incarnon_beam", type = "checkbox", default_value = true },
            { setting_id = "grenade_power", type = "numeric", default_value = 100, range = { 25, 300 }, decimals_number = 0 },
        },
    },
}
