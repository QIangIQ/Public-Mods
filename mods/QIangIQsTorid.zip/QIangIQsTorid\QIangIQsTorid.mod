return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsTorid` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsTorid", {
            mod_script = "QIangIQsTorid/scripts/mods/QIangIQsTorid/QIangIQsTorid",
            mod_data = "QIangIQsTorid/scripts/mods/QIangIQsTorid/QIangIQsTorid_data",
            mod_localization = "QIangIQsTorid/scripts/mods/QIangIQsTorid/QIangIQsTorid_localization",
        })
    end,
    version = "0.1.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
