return {
    mod_name = { en = "QIangIQ's Torid" },
    mod_description = { en = "Warframe's Torid launcher and its Incarnon form for every human class. The blast poisons enemies in the radius. Direct grenade hits charge the Incarnon gauge; the weapon special key switches to the Incarnon full-auto toxin rifle and back. Wiki numbers scaled to Darktide. By QIangIQ." },
    add_to_unlock_list = { en = "Add the Torid to every human class's weapon list" },
    unlock_level = { en = "Unlock level" },
    model_scale = { en = "Model scale" },
    model_forward = { en = "Model forward / back (x length)" },
    model_up = { en = "Model up / down (x length)" },
    model_side = { en = "Model left / right (x length)" },
    incarnon_beam = { en = "Incarnon shows the Riftlance staff beam (needs the Riftlance mod)" },
    grenade_power = { en = "Grenade damage (%%)" },
}
