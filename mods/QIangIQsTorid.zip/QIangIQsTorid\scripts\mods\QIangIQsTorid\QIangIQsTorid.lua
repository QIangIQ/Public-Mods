-- QIangIQ's Torid 0.1.0: Warframe's Torid launcher and its Incarnon form as a weapon for every human class.
--
-- Pattern = QIangIQsDauntlessArmory (clone template + clone item + NetworkLookup appends + alias copy) and
-- QIangIQsShardStaff (custom model unit linked to the weapon's base unit, retail pieces hidden). Every call comes from
-- the Darktide source (Aussiemon master) or those two mods:
--   * Base weapon = autogun_p1_m1 (human, hold-to-fire "shoot" input, hit-scan action, ranged weapon_special that only
--     toggles the flashlight). Its hit-scan actions stay as the Incarnon form.
--   * Torid form: action_shoot_hip / action_shoot_zoomed become kind "shoot_projectile" with the fire_configuration shape
--     of ogryn_thumper_p1_m2.lua:218-262 (projectile_locomotion_template, throw_type "shoot", skip_aiming, shotshell).
--     The grenade explodes on impact (projectile_damage_extension.lua on_impact: impact explosion_template +
--     first_impact_activated left off) with the Hive Scum tox grenade explosion; no puddle: the blast poisons enemies in the radius
--     directly (flash-grenade style, see apply_toxin).
--   * Incarnon gauge: a direct hit (ProjectileDamageExtension.on_impact, is_target_unit) adds one charge, five fill it.
--     The weapon special action (the template's flashlight toggle, started through PlayerUnitWeaponExtension._start_action)
--     switches to the Incarnon hit-scan actions with 34 rounds per charge; the weapon's own clip is resized to the rounds
--     (reserve 0, launcher clip / reserve restored on the way back).
-- Numbers are from wiki.warframe.com/w/Torid scaled to Darktide: magazine 5, reserve 60, reload 1.7 s, 1.5 grenades/s,
-- cloud 3 m for 10 s, Incarnon ~8 shots/s, 35 rounds per charge, up to 175. Crit / status are Darktide's own systems.
-- Author: QIangIQ
local mod = get_mod("QIangIQsTorid")

local WeaponTemplates = require("scripts/settings/equipment/weapon_templates/weapon_templates")
local MasterItems = require("scripts/backend/master_items")
local NetworkLookup = require("scripts/network_lookup/network_lookup")

local TEMPLATE = "qiangiq_torid_p1_m1"
local SOURCE_TEMPLATE = "autogun_p1_m1"
local ITEM_ROOT = "content/items/weapons/player/ranged/"
local ITEM = ITEM_ROOT .. "qiangiq_torid_p1_m1"
local SOURCE_ITEM = ITEM_ROOT .. "autogun_p1_m1"
local GRENADE_ITEM = ITEM_ROOT .. "bullets/grenade_thumper_frag"       -- ogryn_thumper_p1_m2.lua:226
local DISPLAY = "loc_qiangiq_torid"
local ARCHETYPES = { "veteran", "zealot", "psyker", "adamant", "broker" }

local PROJECTILE = "qiangiq_torid_grenade"
local LOCOMOTION = "qiangiq_torid_grenade"
local EXPLOSION = "qiangiq_torid_explosion"
local LIQUID = "qiangiq_torid_toxin"
local AMMO = "qiangiq_torid_p1_m1"

local CHARGES_MAX = 5
local ROUNDS_PER_CHARGE = 35
local GRENADE_CHAIN = 0.667                                              -- 1.5 attacks/s

local MODEL = {
    grenade = { asset = "QIangIQsTorid:torid", unit = "content/mods/qiangiq_torid/torid", ready = false },
    incarnon = { asset = "QIangIQsTorid:torid_incarnon", unit = "content/mods/qiangiq_torid/torid_incarnon", ready = false },
}
-- Incarnon beam look: the staff beam of the Riftlance mod (fviuff), its Custom Assets are used as installed (Riftlance:riftlance
-- particles beam / impact, Riftlance:riftlance_sounds beam loop). Variables length / start / end as in Riftlance.lua.
local RIFT = {
    beam = "content/mods/riftlance/riftlance_beam",
    impact = "content/mods/riftlance/riftlance_impact",
    loop = "wwise/events/riftlance/play_riftlance_beam_loop",
    ready = false, sounds = false,
}
local BEAM_RANGE = 60
local FUEL_SECONDS = 5                                                  -- a full 175 rounds burn in 5 s of held fire
local BEAM_HOLD = 0.4                                                   -- shots are 0.09-0.125 s apart: the beam stays on while firing
local BEAM_SPREAD = 0.025                                                 -- extra beam copies sit this far (m) to each side
local GUN_BORE_UP = 0.162                                               -- the muzzle sits this far above the grip origin (body mesh: tip y 0.127 vs origin -0.038, / length 1.019)
local GUN_FRONT = 0.93                                                   -- build_gun.py GRIP 0.07: 93 % of the length is ahead of the hand

mod:add_global_localize_strings({
    [DISPLAY] = { en = "Torid (Warframe)" },
})

local function say(fmt, ...)
    local text = string.format(fmt, ...)

    mod:echo(text)
    mod:info(text)
end

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

-- Network lookups (QIangIQsDauntlessArmory append_lookup) ----------------------------------------------------------
local function append_lookup(lookup_name, key)
    local lookup = NetworkLookup[lookup_name]

    if not lookup then
        return false, "no lookup " .. lookup_name
    end

    local existing = rawget(lookup, key)

    if existing then
        return true, existing
    end

    local index = #lookup + 1

    rawset(lookup, index, key)
    rawset(lookup, key, index)

    return true, index
end

-- Particle / sound aliases keyed by wielded_weapon_template (QIangIQsDauntlessArmory copy_aliases)
local ALIAS_MODULES = {
    "scripts/settings/particles/player_character_particle_aliases",
    "scripts/settings/sound/player_character_sound_event_aliases",
}

local function alias_keys(root, source, target, seen, counter)
    if type(root) ~= "table" or seen[root] then
        return
    end

    seen[root] = true

    local value = rawget(root, source)

    if value ~= nil and rawget(root, target) == nil then
        root[target] = value
        counter.n = counter.n + 1
    end

    for _, child in pairs(root) do
        if type(child) == "table" then
            alias_keys(child, source, target, seen, counter)
        end
    end
end

local function copy_aliases(source, target)
    local counter = { n = 0 }

    for _, path in ipairs(ALIAS_MODULES) do
        local ok, module = pcall(require, path)

        if ok then
            alias_keys(module, source, target, {}, counter)
        else
            mod:error("alias module %s: %s", path, tostring(module))
        end
    end

    return counter.n
end

-- Per-player state: charges, Incarnon rounds ----------------------------------------------------------------------
local players = setmetatable({}, { __mode = "k" })
local function state_of(unit)
    local st = players[unit]

    if not st then
        st = { charges = 0, rounds = 0, incarnon = false }
        players[unit] = st
    end

    return st
end

-- Projectile, explosion, toxin puddle ---------------------------------------------------------------------------------
local projectile_template

local function ensure_projectile()
    if projectile_template then
        return projectile_template
    end

    local ProjectileTemplates = require("scripts/settings/projectile/projectile_templates")
    local ProjectileLocomotionTemplates = require("scripts/settings/projectile_locomotion/projectile_locomotion_templates")
    local ExplosionTemplates = require("scripts/settings/damage/explosion_templates")
    local LiquidAreaTemplates = require("scripts/settings/liquid_area/liquid_area_templates")
    local thumper = rawget(ProjectileTemplates, "ogryn_thumper_grenade_hip_fire")
    local thumper_locomotion = rawget(ProjectileLocomotionTemplates, "ogryn_thumper_grenade")
    local tox_explosion = rawget(ExplosionTemplates, "broker_tox_grenade")
    local tox_liquid = rawget(LiquidAreaTemplates, "broker_tox_grenade")

    if not (thumper and thumper_locomotion and tox_explosion and tox_liquid) then
        return nil, "thumper grenade / tox grenade templates not found"
    end

    -- flatter, slower than the thumper's 95 m/s lob: wiki projectile speed 40 m/s scaled for Darktide's units
    local locomotion = table.clone(thumper_locomotion)
    local shoot = locomotion.trajectory_parameters.shoot

    shoot.speed_initial = 60
    shoot.speed_maximal = 60
    locomotion.integrator_parameters.gravity = 8
    locomotion.name = LOCOMOTION
    ProjectileLocomotionTemplates[LOCOMOTION] = locomotion

    local explosion = table.clone(tox_explosion)

    explosion.name = EXPLOSION
    explosion.radius = 3                                                  -- wiki cloud radius 3 m
    explosion.static_power_level = tox_explosion.static_power_level * (mod:get("grenade_power") or 100) / 100
    ExplosionTemplates[EXPLOSION] = explosion

    local liquid = table.clone(tox_liquid)

    liquid.name = LIQUID
    liquid.life_time = 10                                                 -- wiki cloud lasts 10 s
    LiquidAreaTemplates[LIQUID] = liquid

    local template = table.clone(thumper)

    template.name = PROJECTILE
    template.locomotion_template = locomotion
    template.damage = {
        impact = {
            damage_profile = thumper.damage.impact.damage_profile,
            damage_type = thumper.damage.impact.damage_type,
            explosion_template = explosion,
        },
    }
    template.effects = {
        spawn = {
            vfx = {
                link = true,
                orphaned_policy = "destroy",
                particle_name = "content/fx/particles/weapons/grenades/chem_grenade/chem_grenade_gas_trail",
            },
        },
    }
    ProjectileTemplates[PROJECTILE] = template

    for _, entry in ipairs({
        { "projectile_template_names", PROJECTILE },
        { "explosion_templates", EXPLOSION },
        { "liquid_area_template_names", LIQUID },
    }) do
        local ok, err = append_lookup(entry[1], entry[2])

        if not ok then
            return nil, err
        end
    end

    projectile_template = template

    return template
end

-- Template -------------------------------------------------------------------------------------------------------------
local modes = {}                                                          -- { grenade = {hip, zoomed}, incarnon = {hip, zoomed} }
local state = { template_ok = false, item_ok = false }
local template_clone

local function build_modes(clone, projectile)
    local ShotshellTemplates = require("scripts/settings/projectile/shotshell_templates")
    local DamageSettings = require("scripts/settings/damage/damage_settings")
    local incarnon_hip = table.clone(clone.actions.action_shoot_hip)
    local incarnon_zoomed = table.clone(clone.actions.action_shoot_zoomed)

    -- Incarnon: autogun hit-scan, hold to fire, ~8 shots/s (autogun_full_auto 0.11-0.09 s between shots)
    for _, action in ipairs({ incarnon_hip, incarnon_zoomed }) do
        -- the autogun's own "autogun_full_auto_slow" stays: a handling template name is only resolved for a weapon when its
        -- template referenced it at load (weapon_tweak_templates preparse), an unknown name gives no auto_fire_time, which
        -- ActionShoot treats as semi-auto (action_shoot.lua _is_auto_fire_weapon)
        action.ammunition_usage = 0        -- the fuel is burned by time (FUEL_SECONDS), not per shot

        if action.fx then
            action.fx.line_effect = nil        -- no vigilant tracer: the Riftlance beam is the projectile look
        end
    end

    -- the bullets deal nothing: the beam damage is applied per shot (incarnon_shot), like the Riftlance beam
    for _, action in ipairs({ incarnon_hip, incarnon_zoomed }) do
        local fire = action.fire_configuration
        local scan = fire and fire.hit_scan_template
        local profile = scan and scan.damage and scan.damage.impact and scan.damage.impact.damage_profile

        if profile then
            scan = table.clone(scan)
            profile = table.clone(profile)
            profile.power_distribution = { attack = 0, impact = 0 }
            scan.damage.impact.damage_profile = profile
            fire.hit_scan_template = scan
        else
            mod:info("incarnon: no hit scan damage profile to silence (%s)", tostring(scan))
        end
    end

    -- Incarnon: no firing noise, muzzle flash, casings or recoil (the beam brings its own loop sound)
    for _, action in ipairs({ incarnon_hip, incarnon_zoomed }) do
        action.recoil_template = "none"
        action.spread_template = "none"
        action.anim_event = nil
        action.anim_event_3p = nil

        -- no shot animation either: ActionShoot.trigger_anim_event ignores a nil event (action_shoot.lua:1099)
        if action.fire_configuration then
            action.fire_configuration.anim_event = nil
            action.fire_configuration.anim_event_3p = nil
            action.fire_configuration.anim_event_func = nil
        end

        if action.fx then
            local drop = {}

            for key in pairs(action.fx) do
                if type(key) == "string" and (string.find(key, "sfx", 1, true) or string.find(key, "muzzle_flash", 1, true)
                    or key == "shell_casing_effect" or key == "auto_fire_time_parameter_name" or key == "num_pre_loop_events") then
                    drop[#drop + 1] = key
                end
            end

            for _, key in ipairs(drop) do
                action.fx[key] = nil
            end
        end
    end

    local function grenade_action(source)
        local action = table.clone(source)

        action.kind = "shoot_projectile"
        action.throw_type = "shoot"
        action.projectile_locomotion_template = LOCOMOTION
        action.ammunition_usage = 1
        action.total_time = GRENADE_CHAIN
        -- stop_input stays: the hold hierarchy only leaves the "shoot" node when shoot_release is consumed by a stop
        action.weapon_handling_template = "immediate_single_shot"
        action.fire_configuration = {
            anim_event = "attack_shoot",
            inventory_item_name = GRENADE_ITEM,
            same_side_suppression_enabled = false,
            skip_aiming = true,
            projectile = projectile,
            shotshell = ShotshellTemplates.default_thumper_assault,
        }

        if action.fx then
            action.fx.line_effect = nil
            action.fx.shell_casing_effect = nil
            action.fx.looping_shoot_sfx_alias = nil
            action.fx.pre_loop_shoot_sfx_alias = nil
            action.fx.post_loop_shoot_tail_sfx_alias = nil
            action.fx.pre_loop_shoot_tail_sfx_alias = nil
            action.fx.auto_fire_time_parameter_name = nil
            action.fx.num_pre_loop_events = nil
            action.fx.shoot_sfx_alias = "ranged_single_shot"
            action.fx.shoot_tail_sfx_alias = "ranged_shot_tail"
            action.fx.muzzle_flash_effect = "content/fx/particles/weapons/rifles/ogryn_thumper/ogryn_thumper_muzzle_flash"
            action.fx.muzzle_flash_crit_effect = nil
        end

        projectile.damage.impact.damage_type = projectile.damage.impact.damage_type or DamageSettings.damage_types.ogryn_bullet_bounce

        return action
    end

    modes.grenade = {
        action_shoot_hip = grenade_action(clone.actions.action_shoot_hip),
        action_shoot_zoomed = grenade_action(clone.actions.action_shoot_zoomed),
    }
    modes.incarnon = { action_shoot_hip = incarnon_hip, action_shoot_zoomed = incarnon_zoomed }

    for _, m in pairs(modes) do
        for name, action in pairs(m) do
            action.name = name
        end
    end
end

local function tune(clone)
    local WeaponAmmoTemplates = require("scripts/settings/equipment/weapon_handling_templates/weapon_ammo_templates")
    local WeaponTweakTemplateSettings = require("scripts/settings/equipment/weapon_templates/weapon_tweak_template_settings")
    local ammo_type = WeaponTweakTemplateSettings.template_types.ammo

    WeaponAmmoTemplates[AMMO] = {
        ammunition_clips = { { lerp_basic = 5, lerp_perfect = 5 } },
        ammunition_reserve = { lerp_basic = 60, lerp_perfect = 60 },
    }

    -- weapon_tweak_templates.lua _preparse_templates / _build_templates (same route as QIangIQsDauntlessArmory tune_crossbow)
    local lookup = rawget(clone, "__base_template_lookup")
    local ammo_lookup = lookup and lookup[ammo_type]

    if ammo_lookup and ammo_lookup.base then
        ammo_lookup.base = { new_identifier = ammo_lookup.base.new_identifier, base_identifier = AMMO }
    else
        clone.ammo_template = AMMO
    end

    -- reload 3.3 s at time_scale_1_2 (2.75 s) -> time_scale_2_0 (1.65 s, wiki 1.70 s)
    clone.actions.action_reload.weapon_handling_template = "time_scale_2_0"
end

local function apply_mode(mode)
    local clone = template_clone
    local set = modes[mode]

    if clone and set then
        clone.actions.action_shoot_hip = set.action_shoot_hip
        clone.actions.action_shoot_zoomed = set.action_shoot_zoomed
        state.mode = mode
    end
end

local function ensure_template()
    local existing = rawget(WeaponTemplates, TEMPLATE)

    if existing then
        state.template_ok = true
        template_clone = template_clone or existing

        return true
    end

    local source = WeaponTemplates[SOURCE_TEMPLATE]

    if not source then
        return false
    end

    local projectile, err = ensure_projectile()

    if not projectile then
        error(err)
    end

    local clone = table.clone(source)

    clone.name = TEMPLATE

    for action_name, action_settings in pairs(clone.actions) do
        action_settings.name = action_name
    end

    build_modes(clone, projectile)
    tune(clone)
    template_clone = clone
    WeaponTemplates[TEMPLATE] = clone
    apply_mode("grenade")

    local ok, index = append_lookup("weapon_templates", TEMPLATE)

    state.template_id = ok and index or nil
    state.aliases = copy_aliases(SOURCE_TEMPLATE, TEMPLATE)
    state.template_ok = ok

    return ok
end

-- Item ------------------------------------------------------------------------------------------------------------------
local function build_item(cache)
    local source = rawget(cache, SOURCE_ITEM)

    if not (source and source.weapon_template == SOURCE_TEMPLATE) then
        return false
    end

    local grenade = rawget(cache, GRENADE_ITEM)

    if not grenade then
        return false, GRENADE_ITEM .. " not in the master items"
    end

    local item = table.clone(source)

    item.name = ITEM
    item.weapon_template = TEMPLATE
    item.archetypes = ARCHETYPES
    item.display_name = DISPLAY

    for _, field in ipairs({ "weapon_family_display_name", "weapon_pattern_display_name", "weapon_mark_display_name" }) do
        if type(item[field]) == "table" then
            item[field].loc_id = DISPLAY
        end
    end

    local deps = item.resource_dependencies or {}
    local WeaponTemplateResourceDependencies = require("scripts/utilities/weapon_template_resource_dependencies")

    for _, resource in ipairs(WeaponTemplateResourceDependencies.generate(TEMPLATE)) do
        deps[resource] = true
    end

    item.resource_dependencies = deps
    item.projectile_items = { GRENADE_ITEM }

    local ok, index = append_lookup("player_item_names", ITEM)

    if not ok then
        return false
    end

    cache[ITEM] = item
    state.item_id = index
    state.slot = item.slots and item.slots[1]

    return true
end

local function ensure_item()
    local ok, has_data = pcall(MasterItems.has_data)

    if not ok or not has_data then
        return false
    end

    local cache = MasterItems.get_cached()

    if rawget(cache, ITEM) then
        state.item_ok = true

        return true
    end

    local built, err = build_item(cache)

    if err and err ~= state.last_error then
        state.last_error = err
        mod:error("%s", err)
    end

    state.item_ok = built and rawget(cache, ITEM) ~= nil

    return state.item_ok
end

-- Every human class's weapon list (QIangIQsDauntlessArmory add_to_unlock_list)
local function add_to_unlock_list()
    if not mod:get("add_to_unlock_list") then
        return
    end

    local ok, unlocks = pcall(require, "scripts/settings/weapon_unlock/weapon_unlock_settings")

    if not ok or not unlocks then
        mod:error("WeaponUnlockSettings not found")

        return
    end

    local level = math.floor(mod:get("unlock_level") or 1)

    for _, archetype in ipairs(ARCHETYPES) do
        local list = unlocks[archetype]

        if list then
            list[level] = list[level] or {}

            if not table.find(list[level], ITEM) then
                table.insert(list[level], ITEM)
            end
        end
    end
end

local next_poll = 0

local function poll()
    if next_poll > os.clock() then
        return
    end

    next_poll = os.clock() + 1

    local before_t, before_i = state.template_ok, state.item_ok
    local ok_t, err_t = pcall(ensure_template)
    local ok_i, err_i = true, nil

    if state.template_ok then
        ok_i, err_i = pcall(ensure_item)
    end

    if not ok_t then
        mod:error("template: %s", tostring(err_t))
    end

    if not ok_i then
        mod:error("item: %s", tostring(err_i))
    end

    if state.template_ok and not before_t then
        mod:info("template %s registered (clone of %s), %s alias entries", TEMPLATE, SOURCE_TEMPLATE, tostring(state.aliases))
    end

    if state.item_ok and not before_i then
        mod:info("item %s injected (clone of %s, slot %s)", ITEM, SOURCE_ITEM, tostring(state.slot))
    end
end

-- Toxin application, flash-grenade style: no puddle, the blast itself poisons every enemy in the radius. Same call the game's
-- broker_passive_blitz_inflicts_toxin makes (broker_buff_templates.lua: add_internally_controlled_buff("neurotoxin_interval_buff3",
-- t, "owner_unit", owner), 10 stacks for the tox grenade) with the broadphase query of broker_passive_toxin_spread_on_kills.
local TOXIN_BUFF = "neurotoxin_interval_buff3"
local TOXIN_STACKS = 10
local TOXIN_RADIUS = 3
local toxin_results = {}

local function apply_toxin(owner, position)
    local ok, err = pcall(function()
        if not (unit_ok(owner) and position and Managers.state.game_session and Managers.state.game_session:is_server()) then
            return
        end

        local extension_manager = Managers.state.extension
        local side = extension_manager:system("side_system").side_by_unit[owner]
        local broadphase = extension_manager:system("broadphase_system").broadphase
        local now = Managers.time:time("gameplay")
        local num = broadphase.query(broadphase, position, TOXIN_RADIUS, toxin_results, side:relation_side_names("enemy"))

        for i = 1, num do
            local enemy = toxin_results[i]
            local buffs = HEALTH_ALIVE[enemy] and ScriptUnit.has_extension(enemy, "buff_system")

            if buffs then
                for _ = 1, TOXIN_STACKS do
                    buffs:add_internally_controlled_buff(TOXIN_BUFF, now, "owner_unit", owner)
                end
            end
        end
    end)

    if not ok then
        mod:info("toxin: %s", tostring(err))
    end
end

-- Incarnon gauge ------------------------------------------------------------------------------------------------------
-- A direct hit = the projectile's impact on a target unit (projectile_damage_extension.lua on_impact(..., is_target_unit))
mod:hook_safe(CLASS.ProjectileDamageExtension, "on_impact", function(self, hit_position, hit_unit, hit_actor, hit_direction, hit_normal, current_speed, force_delete, is_target_unit)
    local template = self._projectile_template

    if not (template and template.name == PROJECTILE) or self._qiangiq_torid_counted then
        return
    end

    self._qiangiq_torid_counted = true

    local owner = self._owner_unit

    apply_toxin(owner, hit_position)

    if is_target_unit and unit_ok(owner) and hit_unit ~= owner then
        local st = state_of(owner)

        if st.charges < CHARGES_MAX then
            st.charges = st.charges + 1

            if st.charges == CHARGES_MAX and Managers.player:local_player_safe(1) and Managers.player:local_player_safe(1).player_unit == owner then
                say("Torid: Incarnon charged. Weapon special key to switch.")
            end
        end
    end
end)

-- Action objects are created once from the settings table and their class comes from "kind" (action_handler.lua start_action:
-- `if not action_objects[action_name] then _create_action`), so swapping the tables in the template is not enough. The shoot
-- objects are dropped here and rebuilt from the active mode on the next press.
local function reset_shoot_actions(unit)
    local extension = ScriptUnit.has_extension(unit, "weapon_system")
    local weapons = extension and extension._weapons

    for _, weapon in pairs(weapons or {}) do
        if weapon.weapon_template and weapon.weapon_template.name == TEMPLATE and weapon.actions then
            weapon.actions.action_shoot_hip = nil
            weapon.actions.action_shoot_zoomed = nil
        end
    end
end

-- Incarnon rounds live in the weapon's own clip (HUD, shots and empty check are the game's): the clip is resized to the rounds
-- on the switch, reserve is zero (no reload) and the launcher's clip / reserve are restored on the way back.
local function ammo_component(unit, slot)
    local ok, component, slot_name = pcall(function()
        local data = ScriptUnit.extension(unit, "unit_data_system")
        local name = slot or data:read_component("inventory").wielded_slot

        return data:write_component(name), name
    end)

    if ok and component and component.current_ammunition_clip then
        return component, slot_name
    end
end

-- Ammo is written in the weapon extension's fixed_update (the game's own place for it; a write from the frame update is
-- overwritten by the next fixed step), the Lua-side form switch happens at once.
local function activate_incarnon(unit)
    local st = state_of(unit)

    if st.incarnon or (st.charges <= 0 and (st.stored or 0) <= 0) then
        return
    end

    st.rounds = math.min(CHARGES_MAX * ROUNDS_PER_CHARGE, (st.stored or 0) + st.charges * ROUNDS_PER_CHARGE)
    st.stored = nil
    st.charges = 0
    st.incarnon = true
    st.fire_t = nil
    st.fuel_carry = 0
    st.ammo_ready = false
    st.job = "start"
    apply_mode("incarnon")
    reset_shoot_actions(unit)
    say("Torid Incarnon: %d rounds", st.rounds)
end

local stop_beam_ref

local function end_incarnon(unit, keep_rounds)
    local st = state_of(unit)

    st.incarnon = false
    st.ammo_ready = false
    st.job = "end"
    st.keep = keep_rounds
    stop_beam_ref(st)
    apply_mode("grenade")
    reset_shoot_actions(unit)
end

mod:hook_safe(CLASS.PlayerUnitWeaponExtension, "fixed_update", function(self, unit, dt, t, fixed_frame)
    local st = players[unit]
    local job = st and st.job

    if not job then
        return
    end

    st.job = nil

    local component, slot = ammo_component(unit, job == "end" and st.saved and st.saved.slot or nil)

    if not component then
        mod:info("ammo: no component for %s", job)
        st.saved = nil

        return
    end

    if job == "start" then
        st.saved = {
            slot = slot,
            clip = component.current_ammunition_clip[1],
            max = component.max_ammunition_clip[1],
            reserve = component.current_ammunition_reserve,
        }
        -- PlayerUnitWeaponExtension._update_ammo rescales the clip to _base_clip_by_slot[slot][i] * clip_size_modifier on every
        -- fixed step (that was the "only 5 rounds" and the broken readout), so the base clip is resized as well
        local base = self._base_clip_by_slot and self._base_clip_by_slot[slot]

        if base and base[1] then
            local modifier = 1
            local buffs = self._buff_extension and self._buff_extension:stat_buffs()

            if buffs and buffs.clip_size_modifier and buffs.clip_size_modifier > 0 then
                modifier = buffs.clip_size_modifier
            end

            local wanted = math.floor(st.rounds / modifier)

            for _ = 1, 8 do
                if math.ceil(wanted * modifier) < st.rounds then
                    wanted = wanted + 1
                elseif math.ceil(wanted * modifier) > st.rounds then
                    wanted = wanted - 1
                end
            end

            st.saved.base = base[1]
            base[1] = wanted
        end

        component.max_ammunition_clip[1] = st.rounds
        component.current_ammunition_clip[1] = st.rounds
        component.current_ammunition_reserve = 0
        st.ammo_ready = true
        mod:info("ammo: %s clip %s/%s reserve %s -> %s/%s", slot, tostring(st.saved.clip), tostring(st.saved.max),
            tostring(st.saved.reserve), tostring(component.current_ammunition_clip[1]), tostring(component.max_ammunition_clip[1]))
    else
        local saved = st.saved
        local left = component.current_ammunition_clip[1]

        st.stored = st.keep and left > 0 and left or nil
        st.keep = nil
        st.rounds = 0

        if saved then
            local base = self._base_clip_by_slot and self._base_clip_by_slot[slot]

            if base and saved.base then
                base[1] = saved.base
            end

            component.max_ammunition_clip[1] = saved.max
            component.current_ammunition_clip[1] = math.min(saved.clip, saved.max)
            component.current_ammunition_reserve = saved.reserve
        end

        st.saved = nil
        mod:info("ammo: restored, %s rounds kept", tostring(st.stored))

        -- the running Incarnon shoot action would keep firing (dry, damage-less bullets) while fire is held
        if slot and self._inventory_component and self._inventory_component.wielded_slot == slot then
            local stopped, err = pcall(self.stop_action, self, "new_interrupting_action", nil, t)

            if not stopped then
                mod:info("stop action: %s", tostring(err))
            end
        end

        for _, name in ipairs({ "slot_primary", "slot_secondary" }) do
            local ok, text = pcall(function()
                local c = ScriptUnit.extension(unit, "unit_data_system"):read_component(name)

                return string.format("%s clip %s/%s reserve %s", name, tostring(c.current_ammunition_clip[1]), tostring(c.max_ammunition_clip[1]), tostring(c.current_ammunition_reserve))
            end)

            mod:info("ammo: after restore %s", ok and text or name .. " unreadable")
        end
    end
end)

-- The weapon special (kind "toggle_special" = ActionToggleWeaponSpecial, weapon_action_handler_data.lua:79) switches forms.
-- Input-started actions never pass through PlayerUnitWeaponExtension._start_action, so the action class is hooked.
mod:hook_safe(CLASS.ActionToggleWeaponSpecial, "start", function(self, action_settings, t)
    local template = self._weapon_template

    if template and template.name == TEMPLATE and state.mode and unit_ok(self._player_unit) then
        local st = state_of(self._player_unit)

        -- Warframe alt-fire: the same key goes back to the launcher, unspent rounds stay for the next switch
        if st.incarnon then
            end_incarnon(self._player_unit, true)
            say("Torid: launcher form")
        else
            activate_incarnon(self._player_unit)
        end
    end
end)

-- Beam: the running shoot action is kept (it holds the world / first person / fx handles), a shot is a drop of the clip
mod:hook_safe(CLASS.ActionShoot, "fixed_update", function(self, dt, t)
    local st = players[self._player_unit]

    if st and st.incarnon and self._is_local_unit and self._weapon_template and self._weapon_template.name == TEMPLATE then
        st.beam_action = self
    end
end)



-- Model overlay (QIangIQsShardStaff sync_record, wf_guns.lua fit_gun) ------------------------------------------------
local FIT_FRAMES = 10
local fit_generation = 0
local tracked = setmetatable({}, { __mode = "k" })

local function spawn_model(ext, kind, parent, first_person)
    local world = ext.__qiangiq_torid_world
    local unit_spawner = Managers.state and Managers.state.unit_spawner

    if not (world and unit_spawner) then
        return nil
    end

    local unit = unit_spawner:spawn_unit(MODEL[kind].unit, Unit.world_pose(parent, 1))

    if not unit then
        return nil
    end

    if first_person then
        Unit.set_unit_culling(unit, false)
        Unit.set_shader_pass_flag_for_meshes_in_unit_and_childs(unit, "custom_fov", true)
    end

    World.link_unit(world, unit, 1, parent, 1, World.LINK_MODE_NODE_NAME)

    return unit
end

local function destroy_model(unit)
    if unit_ok(unit) then
        local unit_spawner = Managers.state and Managers.state.unit_spawner

        if unit_spawner then
            unit_spawner:mark_for_deletion(unit)
        end
    end
end

-- Gun unit: origin = grip, barrel +Y, top +Z, length 1 (build_gun.py). Forward = the base axis closest to the farthest
-- piece (the muzzle end), up = the axis the pieces' centre lies along once forward is removed; scale = the retail weapon's
-- reach ahead of the hand / the fraction of the gun ahead of its grip.
local function fit_gun(model, base, attachments, parent_scale)
    local rot = Unit.world_rotation(base, 1)
    local origin = Unit.world_position(base, 1)
    local ax = { Quaternion.right(rot), Quaternion.forward(rot), Quaternion.up(rot) }
    local pieces, far_d, far_v, sum, n = {}, -1, nil, Vector3(0, 0, 0), 0

    for i = 1, #(attachments or {}) do
        local u = attachments[i]

        if unit_ok(u) then
            local pose, e = Unit.box(u)

            if pose and e then
                local c = Matrix4x4.translation(pose) - origin
                local h = math.max(e.x, e.y, e.z)

                pieces[#pieces + 1] = { c = c, h = h }
                sum = sum + c
                n = n + 1

                local d = Vector3.length(c) + h

                if d > far_d then
                    far_d, far_v = d, c
                end
            end
        end
    end

    if not far_v or n == 0 then
        return false
    end

    local dir, fi, best = nil, 1, -1

    for i = 1, 3 do
        local d = Vector3.dot(ax[i], far_v)

        if math.abs(d) > best then
            best, fi = math.abs(d), i
            dir = d < 0 and -ax[i] or ax[i]
        end
    end

    local mean = sum * (1 / n)
    local resid = mean - dir * Vector3.dot(mean, dir)
    local up, bu = nil, -1

    for i = 1, 3 do
        if i ~= fi then
            local d = Vector3.dot(ax[i], resid)

            if math.abs(d) > bu then
                bu = math.abs(d)
                up = d < 0 and -ax[i] or ax[i]
            end
        end
    end

    local reach = 0

    for _, q in ipairs(pieces) do
        reach = math.max(reach, Vector3.dot(q.c, dir) + q.h)
    end

    if reach <= 0 or not up then
        return false
    end

    local s_world = reach / GUN_FRONT * (mod:get("model_scale") or 1)
    local side = Vector3.normalize(Vector3.cross(dir, up))
    local pos = dir * ((mod:get("model_forward") or 0) * s_world) + side * ((mod:get("model_side") or 0) * s_world) + up * ((mod:get("model_up") or 0) * s_world)
    local bx, by, bz = ax[1], ax[2], ax[3]
    local function to_local(v)
        return Vector3(Vector3.dot(v, bx), Vector3.dot(v, by), Vector3.dot(v, bz))
    end

    local k = parent_scale and parent_scale > 0 and parent_scale or 1
    local s = s_world / k

    Unit.set_local_position(model, 1, to_local(pos) * (1 / k))
    Unit.set_local_rotation(model, 1, Quaternion.look(to_local(dir), to_local(up)))
    Unit.set_local_scale(model, 1, Vector3(s, s, s))

    return true
end

local function hide_originals(base, attachments)
    Unit.set_unit_visibility(base, false, true)

    for i = 1, #(attachments or {}) do
        if unit_ok(attachments[i]) then
            Unit.set_unit_visibility(attachments[i], false, true)
        end
    end
end

local function drop_record(rec)
    destroy_model(rec.grenade)
    destroy_model(rec.incarnon)
end

local function sync_record(ext, records, key, base, attachments, visible, first_person, unit)
    local rec = records[key]
    local want = MODEL.grenade.ready and unit_ok(base) and attachments ~= nil

    if rec and (not want or rec.base ~= base or not unit_ok(rec.grenade)) then
        drop_record(rec)
        records[key] = nil

        if rec.hid and rec.base == base and unit_ok(base) and visible then
            Unit.set_unit_visibility(base, true, true)
        end

        rec = nil
    end

    if not want then
        return
    end

    if not rec then
        local grenade = spawn_model(ext, "grenade", base, first_person)

        if not grenade then
            return
        end

        rec = { grenade = grenade, base = base, frames = 0, count = -1, fitted = false }
        records[key] = rec
    end

    if MODEL.incarnon.ready and not unit_ok(rec.incarnon) then
        rec.incarnon = spawn_model(ext, "incarnon", base, first_person)
        rec.frames = 0
    end

    if rec.count ~= #attachments or rec.gen ~= fit_generation then
        rec.gen = fit_generation
        rec.count = #attachments
        rec.frames = 0
    end

    if rec.frames < FIT_FRAMES then
        rec.frames = rec.frames + 1

        local base_scale = Unit.local_scale(base, 1)
        local k = base_scale and base_scale.x or 1
        local fitted = fit_gun(rec.grenade, base, attachments, k)

        if fitted and unit_ok(rec.incarnon) then
            fit_gun(rec.incarnon, base, attachments, k)
        end

        rec.fitted = fitted or rec.fitted
    end

    local incarnon = players[unit] and players[unit].incarnon and unit_ok(rec.incarnon)

    if rec.fitted and visible then
        hide_originals(base, attachments)
        rec.hid = true
        Unit.set_unit_visibility(rec.grenade, not incarnon, true)

        if unit_ok(rec.incarnon) then
            Unit.set_unit_visibility(rec.incarnon, incarnon and true or false, true)
        end
    else
        Unit.set_unit_visibility(rec.grenade, false, true)

        if unit_ok(rec.incarnon) then
            Unit.set_unit_visibility(rec.incarnon, false, true)
        end
    end
end

local function apply_models(ext)
    if not ext._is_local_unit or not ext._equipment then
        return
    end

    local records = ext.__qiangiq_torid_records

    if not records then
        records = {}
        ext.__qiangiq_torid_records = records
    end

    for slot_name, slot in pairs(ext._equipment) do
        local item = slot.item
        local active = item and item.weapon_template == TEMPLATE

        if active or records[slot_name .. ":3p"] or records[slot_name .. ":1p"] then
            if active then
                local base_3p, base_1p = slot.unit_3p, slot.unit_1p
                local att_3p = base_3p and slot.attachments_by_unit_3p and slot.attachments_by_unit_3p[base_3p]
                local att_1p = base_1p and slot.attachments_by_unit_1p and slot.attachments_by_unit_1p[base_1p]

                sync_record(ext, records, slot_name .. ":3p", base_3p, att_3p, slot.hidden_3p == false, false, ext._unit)
                sync_record(ext, records, slot_name .. ":1p", base_1p, att_1p, slot.hidden_1p == false, true, ext._unit)
            else
                for _, view in ipairs({ ":3p", ":1p" }) do
                    local rec = records[slot_name .. view]

                    if rec then
                        drop_record(rec)
                        records[slot_name .. view] = nil
                    end
                end
            end
        end
    end
end

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "init", function(self, extension_init_context)
    self.__qiangiq_torid_world = extension_init_context and extension_init_context.world
end)

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "_update_item_visibility", function(self)
    if self._is_local_unit then
        tracked[self] = true
        apply_models(self)
    end
end)

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "update", function(self)
    if tracked[self] then
        apply_models(self)
    end
end)

mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, "_unequip_item_from_slot", function(func, self, slot_name, ...)
    local records = self.__qiangiq_torid_records

    if records then
        for _, view in ipairs({ ":3p", ":1p" }) do
            local rec = records[slot_name .. view]

            if rec then
                drop_record(rec)
                records[slot_name .. view] = nil
            end
        end
    end

    return func(self, slot_name, ...)
end)

mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, "destroy", function(func, self, ...)
    for key, rec in pairs(self.__qiangiq_torid_records or {}) do
        drop_record(rec)
        self.__qiangiq_torid_records[key] = nil
    end

    tracked[self] = nil

    return func(self, ...)
end)

mod.on_setting_changed = function()
    fit_generation = fit_generation + 1
end

local function beam_hit(action)
    local first_person = action._first_person_component
    local from, direction = first_person.position, Quaternion.forward(first_person.rotation)
    local hits = PhysicsWorld.raycast(action._physics_world, from, direction, BEAM_RANGE, "all", "types", "both", "max_hits", 8,
        "collision_filter", "filter_player_character_shooting_raycast")

    if hits then
        for i = 1, #hits do
            local found = hits[i]
            local actor = found.actor or found[4]
            local hit_unit = actor and Actor.unit(actor)

            if hit_unit ~= action._player_unit then
                return found.position or found[1], found.normal or found[3], direction, hit_unit, actor
            end
        end
    end

    return from + direction * BEAM_RANGE, nil, direction, nil, nil
end

local function stop_chain(st)
    local fx = st.chain_fx

    st.chain_fx = nil

    if fx then
        for _, effect in ipairs(fx.list) do
            World.destroy_particles(fx.world, effect.id)
        end
    end
end

local function stop_beam(st)
    local beam = st.beam

    stop_chain(st)

    st.beam = nil

    if beam then
        World.destroy_particles(beam.world, beam.effect)
        World.destroy_particles(beam.world, beam.impact)

        for _, e in ipairs(beam.extra or {}) do
            World.destroy_particles(beam.world, e.id)
        end

        if beam.sound then
            WwiseWorld.stop_event(Wwise.wwise_world(beam.world), beam.sound)
        end
    end
end

stop_beam_ref = stop_beam

local function update_beam(st, now)
    local action = st.beam_action

    if not st.incarnon or not action or not st.beam_t or now - st.beam_t > BEAM_HOLD or not unit_ok(action._player_unit) then
        stop_beam(st)

        return
    end

    local world = action._world
    local beam = st.beam

    if not beam then
        beam = { world = world, effect = World.create_particles(world, RIFT.beam, Vector3.zero()),
            impact = World.create_particles(world, RIFT.impact, Vector3.zero()) }
        -- first-person effects are drawn with the weapon's own field of view (PlayerUnitFxExtension: set_particles_use_custom_fov),
        -- else a world-space beam sits off the barrel on screen
        World.set_particles_use_custom_fov(world, beam.effect, true)
        beam.length = World.find_particles_variable(world, RIFT.beam, "length")
        beam.start = World.find_particles_variable(world, RIFT.beam, "start")
        mod:info("beam started (sounds %s)", tostring(RIFT.sounds))
        beam.finish = World.find_particles_variable(world, RIFT.beam, "end")
        st.beam = beam
    end

    local source_unit, source_node = action._fx_extension:vfx_spawner_unit_and_node(action:_muzzle_fx_source())
    local origin = unit_ok(source_unit) and Unit.world_position(source_unit, source_node or 1) or action._first_person_component.position

    -- the barrel of the Incarnon model (unit origin = grip, barrel along +Y, GUN_FRONT of the length ahead of the grip)
    local visual_loadout = ScriptUnit.has_extension(action._player_unit, "visual_loadout_system")
    local records = visual_loadout and visual_loadout.__qiangiq_torid_records
    local wielded = action._wielded_slot or ScriptUnit.extension(action._player_unit, "unit_data_system"):read_component("inventory").wielded_slot
    local rec = records and (records[tostring(wielded) .. ":1p"] or records["slot_primary:1p"] or records["slot_secondary:1p"])

    if not beam.origin_logged then
        beam.origin_logged = true
        mod:info("beam origin: wielded=%s record=%s incarnon=%s", tostring(wielded), tostring(rec ~= nil), tostring(rec ~= nil and unit_ok(rec.incarnon)))
    end

    if rec and unit_ok(rec.incarnon) then
        -- build_gun.py puts a "torid_muzzle" node at the barrel tip: the unit gives the position, no axis guessing
        if Unit.has_node(rec.incarnon, "torid_muzzle") then
            origin = Unit.world_position(rec.incarnon, Unit.node(rec.incarnon, "torid_muzzle"))
        else
            origin = Matrix4x4.transform(Unit.world_pose(rec.incarnon, 1), Vector3(0, GUN_FRONT, GUN_BORE_UP))
        end

        if not beam.node_logged then
            beam.node_logged = true
            mod:info("beam origin node: %s", tostring(Unit.has_node(rec.incarnon, "torid_muzzle")))
        end
    end
    local target, normal, aim_direction = beam_hit(action)
    local direction, length = Vector3.direction_length(target - origin)

    if length < 0.01 then
        return
    end

    World.move_particles(world, beam.effect, origin, Quaternion.look(direction))
    World.set_particles_variable(world, beam.effect, beam.length, Vector3(length, 1, 1))
    World.set_particles_variable(world, beam.effect, beam.start, origin)
    World.set_particles_variable(world, beam.effect, beam.finish, target)
    World.move_particles(world, beam.impact, target, Quaternion.look(-direction))

    -- thicker beam: two more copies, shifted sideways and up by BEAM_SPREAD at both ends
    beam.extra = beam.extra or {}

    if #beam.extra == 0 then
        for i = 1, 2 do
            local id = World.create_particles(world, RIFT.beam, Vector3.zero())

            World.set_particles_use_custom_fov(world, id, true)
            beam.extra[i] = { id = id, length = World.find_particles_variable(world, RIFT.beam, "length"),
                start = World.find_particles_variable(world, RIFT.beam, "start"), finish = World.find_particles_variable(world, RIFT.beam, "end") }
        end
    end

    local side = Vector3.normalize(Vector3.cross(direction, Vector3(0, 0, 1)))
    local lift = Vector3.normalize(Vector3.cross(side, direction))

    for i, e in ipairs(beam.extra) do
        local shift = (i == 1 and (side * BEAM_SPREAD + lift * BEAM_SPREAD * 0.5)) or (side * -BEAM_SPREAD + lift * BEAM_SPREAD * 0.5)

        World.move_particles(world, e.id, origin + shift, Quaternion.look(direction))
        World.set_particles_variable(world, e.id, e.length, Vector3(length, 1, 1))
        World.set_particles_variable(world, e.id, e.start, origin + shift)
        World.set_particles_variable(world, e.id, e.finish, target + shift)
    end

    if RIFT.sounds and not beam.sound then
        local wwise_world = Wwise.wwise_world(world)
        local source = WwiseWorld.make_auto_source(wwise_world, source_unit, source_node or 1)

        beam.sound = WwiseWorld.trigger_resource_event(wwise_world, RIFT.loop, source)
    end
end

-- Evo 1 chain: every shot poisons the target and chains to the nearest enemies in range, each link 75% of the previous
-- (psyker_chain_lightning.lua pattern; toxin application as in apply_toxin). Server only, the local unit draws the links.
local INCARNON_STACKS = 4
local CHAIN_COUNT = 5
local CHAIN_RANGE = 7
local CHAIN_FALLOFF = 0.75
local chain_results = {}

local Attack = require("scripts/utilities/attack/attack")
local AttackSettings = require("scripts/settings/damage/attack_settings")
local DamageSettings = require("scripts/settings/damage/damage_settings")
local HitZone = require("scripts/utilities/attack/hit_zone")
local BEAM_POWER = 500                       -- at power 500 the attack value is the damage (Riftlance.lua POWER_LEVEL)
local BEAM_SHOT_DAMAGE = 30                  -- Riftlance: 30 per 0.1 s tick; a shot carries the ticks since the previous shot
local BEAM_SHOT_STAGGER = 2
local beam_profile_cache

local function beam_profile()
    if not beam_profile_cache then
        local ArmorSettings = require("scripts/settings/damage/armor_settings")
        local GibbingSettings = require("scripts/settings/gibbing/gibbing_settings")
        local PowerLevelSettings = require("scripts/settings/damage/power_level_settings")
        local full = {}

        for _, armor_type in pairs(ArmorSettings.types) do
            full[armor_type] = 1
        end

        -- Riftlance.lua damage_profile(): the network sends profiles by name, so the voidstrike name is kept
        beam_profile_cache = {
            name = "default_bfg",
            ignore_hitzone_multiplier = true,
            ragdoll_push_force = 600,
            stagger_category = "ranged",
            cleave_distribution = { attack = 0.15, impact = 0.15 },
            armor_damage_modifier = { attack = full, impact = full },
            power_distribution = { attack = BEAM_SHOT_DAMAGE, impact = BEAM_SHOT_STAGGER },
            gibbing_power = GibbingSettings.gibbing_power.heavy,
            gibbing_type = GibbingSettings.gibbing_types.warp,
            targets = { default_target = { boost_curve = PowerLevelSettings.boost_curves.default } },
        }
    end

    return beam_profile_cache
end

local function incarnon_shot(action, st, now)
    local owner = action._player_unit
    local game_session = Managers.state.game_session

    if not (game_session and game_session:is_server() and unit_ok(owner)) then
        return
    end

    local hit_position, _, hit_direction, hit_unit, hit_actor = beam_hit(action)

    if not (hit_unit and HEALTH_ALIVE[hit_unit]) then
        return
    end

    local extension_manager = Managers.state.extension

    if not extension_manager:system("side_system"):is_enemy(owner, hit_unit) then
        return
    end

    -- beam damage: the Riftlance beam call (Riftlance.lua hit()), 30 per 0.1 s tick = 300/s, spread over ~8 shots/s
    local hit_zone = HitZone.get_name(hit_unit, hit_actor)

    if hit_zone and hit_zone ~= HitZone.hit_zone_names.afro then
        local gap = now - (st.last_shot_t or now - 0.1)
        local ticks = gap > 0.4 and 1 or math.clamp(gap / 0.1, 0.5, 3)

        st.last_shot_t = now

        Attack.execute(hit_unit, beam_profile(), "power_level", BEAM_POWER * ticks, "charge_level", 1, "hit_world_position", hit_position,
            "hit_zone_name", hit_zone, "hit_actor", hit_actor, "attacking_unit", owner, "attack_direction", hit_direction,
            "attack_type", AttackSettings.attack_types.ranged, "damage_type", DamageSettings.damage_types.force_staff_single_target)
    end

    local side = extension_manager:system("side_system").side_by_unit[owner]
    local enemy_sides = side:relation_side_names("enemy")
    local broadphase = extension_manager:system("broadphase_system").broadphase
    local used = { [hit_unit] = true }
    local current = hit_unit
    local stacks = INCARNON_STACKS
    local links = {}

    for link = 0, CHAIN_COUNT do
        local buffs = ScriptUnit.has_extension(current, "buff_system")

        if buffs then
            for _ = 1, math.max(1, math.floor(stacks + 0.5)) do
                buffs:add_internally_controlled_buff(TOXIN_BUFF, now, "owner_unit", owner)
            end
        end

        if link == CHAIN_COUNT then
            break
        end

        local from = Unit.world_position(current, 1) + Vector3(0, 0, 1)
        local num = broadphase.query(broadphase, from, CHAIN_RANGE, chain_results, enemy_sides)
        local best, best_distance

        for i = 1, num do
            local enemy = chain_results[i]

            if not used[enemy] and HEALTH_ALIVE[enemy] then
                local distance = Vector3.distance(from, Unit.world_position(enemy, 1) + Vector3(0, 0, 1))

                if not best_distance or distance < best_distance then
                    best, best_distance = enemy, distance
                end
            end
        end

        if not best then
            break
        end

        links[#links + 1] = { from = Vector3Box(from), to = Vector3Box(Unit.world_position(best, 1) + Vector3(0, 0, 1)) }
        used[best] = true
        current = best
        stacks = stacks * CHAIN_FALLOFF
    end

    st.chain_links = links
    st.chain_t = now
end

local function update_chain(st, now)
    local action = st.beam_action
    local links = st.chain_links

    if not (links and #links > 0 and action and st.chain_t and now - st.chain_t <= BEAM_HOLD and st.incarnon and unit_ok(action._player_unit)) then
        stop_chain(st)

        return
    end

    local world = action._world
    local fx = st.chain_fx

    if fx and #fx.list ~= #links then
        stop_chain(st)
        fx = nil
    end

    if not fx then
        fx = { world = world, list = {} }

        for i = 1, #links do
            local id = World.create_particles(world, RIFT.beam, Vector3.zero())

            fx.list[i] = { id = id, length = World.find_particles_variable(world, RIFT.beam, "length"),
                start = World.find_particles_variable(world, RIFT.beam, "start"),
                finish = World.find_particles_variable(world, RIFT.beam, "end") }
        end

        st.chain_fx = fx
    end

    for i, link in ipairs(links) do
        local effect = fx.list[i]
        local link_from, link_to = link.from:unbox(), link.to:unbox()
        local direction, length = Vector3.direction_length(link_to - link_from)

        if length > 0.01 then
            World.move_particles(world, effect.id, link_from, Quaternion.look(direction))
            World.set_particles_variable(world, effect.id, effect.length, Vector3(length, 1, 1))
            World.set_particles_variable(world, effect.id, effect.start, link_from)
            World.set_particles_variable(world, effect.id, effect.finish, link_to)
        end
    end
end

-- A shot of the Incarnon form (ActionShoot._shoot): beam look on the local unit, poison + chain on the host
-- the autogun action is kind "shoot_hit_scan" = ActionShootHitScan, which overrides _shoot (action_shoot_hit_scan.lua:145)
mod:hook_safe(CLASS.ActionShootHitScan, "_shoot", function(self, position, rotation, power_level, charge_level, t, fire_config)
    local template = self._weapon_template
    local st = template and template.name == TEMPLATE and players[self._player_unit]

    if not (st and st.incarnon) then
        return
    end

    local time_manager = Managers.time

    if not (time_manager and time_manager:has_timer("gameplay")) then
        return
    end

    local now = time_manager:time("gameplay")

    st.beam_action = self

    -- fuel: 175 rounds over FUEL_SECONDS of held fire = 35 rounds per second, burned for the time since the previous shot
    if st.ammo_ready then
        local gap = st.fire_t and now - st.fire_t or 0

        st.fire_t = now

        if gap > 0.4 then
            gap = 0
        end

        st.fuel_carry = (st.fuel_carry or 0) + gap * CHARGES_MAX * ROUNDS_PER_CHARGE / FUEL_SECONDS

        local burn = math.floor(st.fuel_carry)

        if burn > 0 then
            st.fuel_carry = st.fuel_carry - burn

            local component = ammo_component(self._player_unit, st.saved and st.saved.slot)

            if component then
                component.current_ammunition_clip[1] = math.max(0, component.current_ammunition_clip[1] - burn)
            end
        end
    end

    if not st.shot_logged then
        st.shot_logged = true
        mod:info("incarnon shot (beam assets %s, setting %s)", tostring(RIFT.ready), tostring(mod:get("incarnon_beam")))
    end

    local ok, err = pcall(incarnon_shot, self, st, now)

    if not ok then
        mod:info("chain: %s", tostring(err))
    end

    if self._is_local_unit and RIFT.ready and mod:get("incarnon_beam") ~= false then
        st.beam_t = now
    end
end)

-- Impact sounds (the armour clink) are muted while the Torid is wielded, in both forms: the same route Riftlance.lua uses
-- (FxSystem.play_impact_fx / ImpactEffect.surface_impact_fx get a copy of the impact fx without its sfx entries).
local ImpactEffect = require("scripts/utilities/attack/impact_effect")
local silence_impacts = false
local silent_copies = setmetatable({}, { __mode = "k" })

local function silent(impact_fx)
    if not silence_impacts or type(impact_fx) ~= "table" then
        return impact_fx
    end

    local copy = silent_copies[impact_fx]

    if not copy then
        copy = table.shallow_copy(impact_fx)

        for key in pairs(impact_fx) do
            if type(key) == "string" and string.find(key, "sfx", 1, true) then
                copy[key] = nil
            end
        end

        silent_copies[impact_fx] = copy
    end

    return copy
end

local function torid_wielded(unit)
    if not unit_ok(unit) then
        return false
    end

    local ok, result = pcall(function()
        local weapons = ScriptUnit.extension(unit, "weapon_system")._weapons
        local slot = ScriptUnit.extension(unit, "unit_data_system"):read_component("inventory").wielded_slot
        local weapon = weapons and weapons[slot]

        return weapon and weapon.weapon_template and weapon.weapon_template.name == TEMPLATE
    end)

    return ok and result and true or false
end

-- ImpactEffect.play(hit_unit, hit_actor, damage, damage_type, hit_zone, result, position, normal, direction, attacker_unit, ...)
mod:hook(ImpactEffect, "play", function(func, ...)
    local previous = silence_impacts

    silence_impacts = torid_wielded((select(10, ...)))

    local ok, a, b, c = pcall(func, ...)

    silence_impacts = previous

    if not ok then
        error(a, 0)
    end

    return a, b, c
end)

mod:hook("FxSystem", "play_impact_fx", function(func, self, impact_fx, ...)
    return func(self, silent(impact_fx), ...)
end)

mod:hook(ImpactEffect, "surface_impact_fx", function(func, ...)
    local impact_fx, hit_unit, hit_actor = func(...)

    return silent(impact_fx), hit_unit, hit_actor
end)

-- Weapon HUD: after the clip is resized the element can keep showing the old clip (the Incarnon number next to the launcher
-- reserve). When its cached clip stays different from the component for half a second the cache is dropped so it repaints.
local hud_logged = 0

mod:hook_safe(CLASS.HudElementPlayerWeapon, "update", function(self, dt, t)
    local component = self._slot_component
    local cache = self._current_ammunition_clips

    if not (component and cache and self._uses_ammo) then
        return
    end

    local ok, clip = pcall(function()
        return component.current_ammunition_clip[1]
    end)

    if not (ok and clip and cache[1]) or cache[1] == clip then
        self._qiangiq_torid_mismatch = nil

        return
    end

    self._qiangiq_torid_mismatch = self._qiangiq_torid_mismatch or t

    if t - self._qiangiq_torid_mismatch > 0.5 then
        if hud_logged < 12 then
            hud_logged = hud_logged + 1
            mod:info("hud: cached clip %s, component clip %s, total %s: refreshed", tostring(cache[1]), tostring(clip), tostring(self._total_ammo))
        end

        self._qiangiq_torid_mismatch = nil
        self._current_ammunition_clips = {}
        self._max_ammunition_clips = {}
        self._total_ammo = nil
    end
end)

mod.update = function()
    poll()

    -- no gameplay timer in the hub / menus (TimeManager:has_timer)
    local time_manager = Managers.time

    if not time_manager or not time_manager:has_timer("gameplay") then
        return
    end

    local now = time_manager:time("gameplay")

    for unit, st in pairs(players) do
        if not st.incarnon then
            st.shot_logged = nil
        end

        if st.beam or st.beam_t then
            local ok, err = pcall(update_beam, st, now)

            if ok then
                ok, err = pcall(update_chain, st, now)
            end

            if not ok and not st.beam_error then
                st.beam_error = true
                mod:error("beam: %s", tostring(err))
            end
        end
    end

    for unit, st in pairs(players) do
        if st.incarnon and st.ammo_ready and unit_ok(unit) then
            local component = ammo_component(unit, st.saved and st.saved.slot)

            -- spent clip (or the weapon is gone): back to the launcher
            if not component or component.current_ammunition_clip[1] <= 0 then
                end_incarnon(unit)
                say("Torid Incarnon: spent")
            end
        end
    end
end

mod.on_all_mods_loaded = function()
    add_to_unlock_list()

    local custom_assets = get_mod("CustomAssets")

    if not custom_assets or not custom_assets.is_api_compatible or not custom_assets.is_api_compatible(1) then
        mod:error("Custom Assets (API 1) is missing: the Torid keeps the autogun model")

        return
    end

    for key, asset in pairs({ ready = "Riftlance:riftlance", sounds = "Riftlance:riftlance_sounds" }) do
        local ticket = custom_assets.acquire(mod, asset, function(_, _, load_error)
            if load_error then
                mod:error("%s failed to load: %s", asset, tostring(load_error))
            else
                RIFT[key] = true
                mod:info("%s loaded", asset)
            end
        end, { resident = true, reference_name = asset })

        if not ticket then
            mod:info("%s is not installed: the Incarnon keeps the autogun tracer", asset)
        end
    end

    for kind, def in pairs(MODEL) do
        local ticket, err = custom_assets.acquire(mod, def.asset, function(_, _, load_error)
            if load_error then
                mod:error("%s failed to load: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", def.asset, tostring(load_error))

                return
            end

            def.ready = true
            mod:info("model %s loaded", def.asset)
        end, { resident = true, reference_name = def.asset })

        if not ticket then
            mod:error("%s could not be requested: %s", def.asset, tostring(err))
        end
    end
end

mod.on_unload = function()
    local ok, cache = pcall(MasterItems.get_cached)

    if ok and cache then
        cache[ITEM] = nil
    end

    WeaponTemplates[TEMPLATE] = nil
end

-- Equip without the backend (QIangIQsDauntlessArmory override): only where this client hosts ---------------------------
mod:command("torid", "Equip the Torid: /torid (secondary slot), /torid state", function(which)
    local player = Managers.player and Managers.player:local_player_safe(1)

    if which == "state" then
        local st = player and player.player_unit and players[player.player_unit]

        say("template %s, item %s, mode %s, charges %s, rounds %s, models grenade %s incarnon %s",
            tostring(state.template_ok), tostring(state.item_ok), tostring(state.mode), tostring(st and st.charges),
            tostring(st and st.rounds), tostring(MODEL.grenade.ready), tostring(MODEL.incarnon.ready))

        return
    end

    local sync = Managers.profile_synchronization
    local host = sync and sync:synchronizer_host()

    if not player then
        say("no local player")

        return
    end

    if not host then
        say("not the host here. Use the Psykhanium, a SoloPlay game or a game you host")

        return
    end

    local slot = state.slot or "slot_secondary"

    host:override_slot(player:peer_id(), player:local_player_id(), slot, ITEM)
    say("override_slot(%s, %s) sent", slot, ITEM)
end)
