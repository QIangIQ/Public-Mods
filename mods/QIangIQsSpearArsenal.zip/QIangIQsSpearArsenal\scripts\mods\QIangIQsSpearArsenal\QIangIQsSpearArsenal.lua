-- QIangIQ's Spear Arsenal (was QIangIQ's Staff of Homa): shows one of 23 Genshin Impact polearms
-- (Custom Assets) in place of the force staffs. Each staff has its own profile (on/off, spear or random,
-- length, grip, spin, tilt, flip), chosen in a CookedMacroManager / Skull Runeblade style selector.
-- A random spear is picked once per game session per staff; /spear reroll picks another.
-- Author: QIangIQ
local mod = get_mod("QIangIQsSpearArsenal")

-- Cross-client sync ---------------------------------------------------------------
-- QIangIQsModelSync publishes which QIangIQ replacer mods a player has on, with their options, through
-- Vox Manifold (the transport Dio's Wardrobe shares outfits with). No asset data is sent: every client shows
-- the model from its own installed files. While another player's unit is worked on, sync_ctx holds that
-- player's options and opt() answers from them; for my own unit opt() is mod:get().
local SYNC_KEY = "spear"
-- 2.2: the per-staff profiles travel in the extra element, so no checkbox bits are published
local SYNC_BOOLS = {}
local SYNC_DEFAULTS = {}
local SYNC_VALUES = { "glow_brightness" }
local SYNC_LAYOUT = 300 + #SYNC_VALUES -- a peer on another version of this mod is not decoded (2.1 = 204)
local sync_ctx = nil
local sync_known = setmetatable({}, { __mode = "k" })   -- other players' extensions this mod has shown something on
local sync_all = setmetatable({}, { __mode = "k" })     -- every visual loadout extension seen
local sync_decoded = setmetatable({}, { __mode = "k" }) -- published array -> options table
local SYNC_FALSE = { __index = function() return false end }
local SYNC_OFF = setmetatable({}, SYNC_FALSE)           -- "everything off": removes what was shown
local sync_extra_import = nil

local function opt(key)
    if sync_ctx then
        return sync_ctx[key]
    end
    return mod:get(key)
end

local function sync_api()
    local hub = get_mod("QIangIQsModelSync")
    return hub and hub.api
end

local function sync_me()
    local players = Managers.player
    if not players then
        return nil
    end
    local ok, player = pcall(players.local_player_safe, players, 1)
    return ok and player or nil
end

-- published array { layout, checkbox bits, value, value, ... [, extra] } -> options by setting id
local function sync_decode(raw)
    local t = sync_decoded[raw]
    if t ~= nil then
        return t
    end
    t = false
    if type(raw) == "table" and raw[1] == SYNC_LAYOUT then
        t = setmetatable({}, SYNC_FALSE)
        local mask = tonumber(raw[2]) or 0
        for i = 1, #SYNC_BOOLS do
            t[SYNC_BOOLS[i]] = mask % 2 >= 1
            mask = math.floor(mask / 2)
        end
        for i = 1, #SYNC_VALUES do
            local v = raw[2 + i]
            if v ~= nil then
                t[SYNC_VALUES[i]] = v
            end
        end
        if sync_extra_import then
            sync_extra_import(t, raw[3 + #SYNC_VALUES])
        end
    end
    sync_decoded[raw] = t
    return t
end

-- whose options apply to this extension: nil = mine, a table = that player's (SYNC_OFF when they publish
-- nothing for this mod)
local function sync_owner(ext)
    sync_all[ext] = true
    local player = ext._player
    if player == nil or player == sync_me() then
        return nil
    end
    local api = sync_api()
    local raw = api and api.peer(SYNC_KEY, player)
    local state = raw and sync_decode(raw)
    if state then
        sync_known[ext] = true
        return state
    end
    return SYNC_OFF
end

-- my own unit, or another player's unit this mod is (or was) showing something on
local function sync_shown(ext)
    local player = ext._player
    return player ~= nil and (player == sync_me() or sync_known[ext] == true)
end

local function sync_pack(...)
    return { n = select("#", ...), ... }
end

-- runs a hook body with the options of the extension's owner
local function sync_wrap(fn, ext_index)
    return function(...)
        local ext = select(ext_index, ...)
        local previous = sync_ctx
        sync_ctx = sync_owner(ext)
        local results = sync_pack(pcall(fn, ...))
        sync_ctx = previous
        if not results[1] then
            error(results[2], 0)
        end
        return unpack(results, 2, results.n)
    end
end

-- The same hook on my own unit's extension and on other players' (husk) extensions. While the mods load, the
-- classes do not exist yet: CLASS.<name> is then only the name and DMF delays the hook ("needs to be delayed"
-- in the log), so the husk class cannot be inspected here. Its methods are taken from
-- player_husk_visual_loadout_extension.lua instead.
local SYNC_HUSK_METHODS = { init = true, update = true, _update_item_visibility = true, destroy = true }

local function vl_hook_safe(method, fn)
    mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, method, sync_wrap(fn, 1))
    if SYNC_HUSK_METHODS[method] then
        mod:hook_safe(CLASS.PlayerHuskVisualLoadoutExtension, method, sync_wrap(fn, 1))
    end
end

local function vl_hook(method, fn)
    mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, method, sync_wrap(fn, 2))
    if SYNC_HUSK_METHODS[method] then
        mod:hook(CLASS.PlayerHuskVisualLoadoutExtension, method, sync_wrap(fn, 2))
    elseif method == "_unequip_item_from_slot" then
        -- a husk has no _unequip_item_from_slot: its unequip arrives as rpc_player_unequip_item_from_slot
        -- (self, channel_id, go_id, slot_id), slot name = NetworkLookup.player_inventory_slot_names[slot_id]
        -- (player_husk_visual_loadout_extension.lua)
        mod:hook(CLASS.PlayerHuskVisualLoadoutExtension, "rpc_player_unequip_item_from_slot", sync_wrap(function(func, self, channel_id, go_id, slot_id, ...)
            local NetworkLookup = require("scripts/network_lookup/network_lookup")
            local slot_name = NetworkLookup.player_inventory_slot_names[slot_id]
            return fn(function()
                return func(self, channel_id, go_id, slot_id)
            end, self, slot_name)
        end, 2))
    end
end
-- ----------------------------------------------------------------------------------

mod.AUTHOR = "QIangIQ"

-- Custom folder name (= unit file name) and display name. Asset id = "<Mod>:<folder>", unit path = the
-- --asset-path used at compile time (DMS\work\arsenal\split.py, genshin-impact-arsenal.zip "Polearms").
local SPEARS = {
    { "beginners_protector", "Beginner's Protector" },
    { "black_tassel", "Black Tassel" },
    { "blackcliff_pole", "Blackcliff Pole" },
    { "crescent_pike", "Crescent Pike" },
    { "deathmatch", "Deathmatch" },
    { "dragons_bane", "Dragon's Bane" },
    { "dragonspine_spear", "Dragonspine Spear" },
    { "engulfing_lightning", "Engulfing Lightning" },
    { "favonius_lance", "Favonius Lance" },
    { "halberd", "Halberd" },
    { "iron_point", "Iron Point" },
    { "kitain_cross_spear", "Kitain Cross Spear" },
    { "lithic_spear", "Lithic Spear" },
    { "primordial_jade_winged_spear", "Primordial Jade Winged-Spear" },
    { "prototype_grudge", "Prototype Grudge" },
    { "regicide", "Regicide" },
    { "royal_spear", "Royal Spear" },
    { "skyward_spine", "Skyward Spine" },
    { "staff_of_homa", "Staff of Homa" },
    { "the_catch", "The Catch" },
    { "vortex_vanquisher", "Vortex Vanquisher" },
    { "wavebreakers_fin", "Wavebreaker's Fin" },
    { "white_tassel", "White Tassel" },
}
local SPEAR_BY_STEM = {}
for i = 1, #SPEARS do
    SPEAR_BY_STEM[SPEARS[i][1]] = i
end

-- Force staffs: weapon template (item.weapon_template, equipment_component.lua) and name
-- (Enhanced_descriptions/NAMES_Enemies_Weapons.lua:1285, 1313, 1343, 1373; templates from
-- scripts/settings/equipment/weapon_templates/force_staffs/)
local STAFFS = {
    { "forcestaff_p1_m1", "Voidblast Force Staff" },
    { "forcestaff_p2_m1", "Inferno Force Staff" },
    { "forcestaff_p3_m1", "Electrokinetic Force Staff" },
    { "forcestaff_p4_m1", "Voidstrike Force Staff" },
}
local STAFF_SET = {}
for i = 1, #STAFFS do
    STAFF_SET[STAFFS[i][1]] = STAFFS[i][2]
end
local DEFAULT_STAFF = "forcestaff_p2_m1"

-- One profile per staff, kept in the saved table "profiles" (as CookedMacroManager keeps "bind_data" and
-- the Skull Runeblade "profiles"); the widgets with these ids show the profile of the selected staff.
--   profile_enabled: replace this staff
--   profile_spear:   folder name of the spear, or "random" (a new pick each session)
--   profile_scale:   length, x the original staff's butt-to-head length
--   profile_grip:    where the hand holds it, in spear lengths (positive = nearer the spearhead)
--   profile_roll:    degrees about the shaft
--   profile_tilt:    degrees, leans the spear about the hand (in the plane of the spearhead's flat)
--   profile_flip:    end to end
local PROFILE_TEMPLATE = {
    profile_enabled = false,
    profile_spear = "random",
    profile_scale = 1,
    profile_grip = 0,
    profile_roll = 0,
    profile_tilt = 0,
    profile_flip = false,
}
local profiles = nil

-- another player's profiles travel as the extra element of their published array:
-- { [template] = { spear folder name, scale, grip, roll, tilt, flip 0/1 } } for the staffs they carry.
-- Unknown spear names (a newer list) show nothing.
sync_extra_import = function(t, extra)
    local list = {}
    if type(extra) == "table" then
        for template, v in pairs(extra) do
            if type(v) == "string" then
                v = { v } -- short form: only the model, every slider at its default
            end
            if STAFF_SET[template] and type(v) == "table" and type(v[1]) == "string" and SPEAR_BY_STEM[v[1]] then
                list[template] = {
                    profile_enabled = true,
                    spear = SPEAR_BY_STEM[v[1]],
                    profile_scale = tonumber(v[2]) or 1,
                    profile_grip = tonumber(v[3]) or 0,
                    profile_roll = tonumber(v[4]) or 0,
                    profile_tilt = tonumber(v[5]) or 0,
                    profile_flip = v[6] == 1,
                }
            end
        end
    end
    rawset(t, "__profiles", list)
end

local function spear_id(i)
    return "QIangIQsSpearArsenal:" .. SPEARS[i][1]
end

local function spear_unit(i)
    return "content/mods/qiangiq_spear_arsenal/" .. SPEARS[i][1]
end

-- Picked once when the mod loads (= once per game session). os.time is one of the os functions the game
-- keeps (scrub_dangerous_functions.lua); math.randomseed is not called, so the game's own random
-- sequence is left alone.
local function roll(previous)
    local i = (os.time() + math.random(0, 9999)) % #SPEARS + 1
    if previous and i == previous then
        i = i % #SPEARS + 1
    end
    return i
end
local session_pick = {} -- [staff template] = spear index, rolled the first time it is needed
local loaded = {} -- [spear index] = true once its package is in

local function profile_for(template, create)
    if sync_ctx then
        -- another player's staff: the profile they published for it
        local list = rawget(sync_ctx, "__profiles")
        return list and list[template] or PROFILE_TEMPLATE
    end
    if not profiles then
        return PROFILE_TEMPLATE
    end
    local p = profiles[template]
    if not p and create then
        p = table.clone(PROFILE_TEMPLATE)
        profiles[template] = p
    end
    return p or PROFILE_TEMPLATE
end

-- my spear for a staff: the one in its profile, or this session's random pick for it
local function my_spear(template)
    local p = profile_for(template)
    local fixed = p.profile_spear and SPEAR_BY_STEM[p.profile_spear]
    if fixed then
        return fixed
    end
    if not session_pick[template] then
        session_pick[template] = roll(nil)
    end
    return session_pick[template]
end

-- the spear for a staff: mine, or the one another player published
local function spear_for(template)
    if not STAFF_SET[template] then
        return nil
    end
    if sync_ctx then
        return profile_for(template).spear
    end
    return my_spear(template)
end

-- Glow layer: up to three textureless emissive slots per spear (DMS/work/arsenal/split.py glow_layer),
-- named after their glTF materials. Spears without a glow layer have none of them (pcall).
local GLOW_SLOTS = { "glow_0", "glow_1", "glow_2" }
local GLOW_BAKED = 2 -- KHR_materials_emissive_strength compiled into the glow materials

local function apply_glow(unit)
    local v = opt("glow_brightness") or GLOW_BAKED
    for i = 1, #GLOW_SLOTS do
        -- one material slot at a time, as in ammo_display.lua:85 (per-slot call works on the Skull Runeblade)
        pcall(Unit.set_scalar_for_material, unit, GLOW_SLOTS[i], "intensity", v)
    end
end

-- The compiled staff is authored along local +Y (Stingray forward): butt end at y = 0, spearhead
-- tip at y = 1, shaft centred on the Y axis, the flat of the spearhead facing local Z
-- (homa/prep_homa.py; the arsenal spears use the same layout, DMS/work/arsenal/split.py).
local FIT_FRAMES = 10
local fit_generation = 0 -- bumped when a setting changes, so every staff refits

local custom_assets = nil
local mod_on = true
local session_off = false -- the toggle keybind / /spear: every staff back to the original for this session

local tracked = setmetatable({}, { __mode = "k" })    -- PlayerUnitVisualLoadoutExtension
local tracked_ui = setmetatable({}, { __mode = "k" }) -- UIProfileSpawner
local tracked_wpn = setmetatable({}, { __mode = "k" }) -- UIWeaponSpawner

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function staff_on(template)
    if not STAFF_SET[template] or (session_off and not sync_ctx) then
        return false
    end
    return profile_for(template).profile_enabled and true or false
end

local function wants_item(item)
    local template = item and item.weapon_template
    local spear = spear_for(template)
    return mod_on and spear ~= nil and loaded[spear] == true and staff_on(template)
end

local function local_player()
    local players = Managers.player
    if not players then
        return nil
    end
    local ok, player = pcall(players.local_player_safe, players, 1)
    return ok and player or nil
end

-- Fitting ---------------------------------------------------------------------
-- Only what proved reliable in game for the Diamond Sword is used: Unit.box centres
-- (Matrix4x4.translation), the largest box half-extent, unit origins and units' own world axes.
-- Box pose rotations are never used.

local function fmt(v)
    return string.format("(%.3f, %.3f, %.3f)", v.x, v.y, v.z)
end

local last_fit = {} -- per view, for /spear debug

-- pieces of the original staff: every attachment (and the base) with a measurable box
local function staff_parts(base, attachments)
    local parts = {}
    local function add(unit)
        if unit_ok(unit) then
            local pose, ext = Unit.box(unit)
            if pose and ext then
                local half = math.max(ext.x, ext.y, ext.z)
                if half > 0.005 then
                    parts[#parts + 1] = { center = Matrix4x4.translation(pose), half = half }
                end
            end
        end
    end
    add(base)
    if attachments then
        for i = 1, #attachments do
            add(attachments[i])
        end
    end
    return parts
end

-- Staff direction: from the hand (base unit origin, where the weapon is linked to the hand) to
-- the piece farthest from it (the head), snapped to one of the weapon base unit's own axes when
-- within ~14 degrees. Extent: every piece's centre projected on that line +- its largest
-- half-extent. The spear is laid over the whole original staff (butt to head), so the
-- hand keeps the same point on the shaft.
local function fit(staff, base, attachments, parent_scale, view, profile)
    profile = profile or PROFILE_TEMPLATE
    local parts = staff_parts(base, attachments)
    if #parts == 0 then
        return false
    end
    local origin = Unit.world_position(base, 1)
    local far_d, far_c = 0, nil
    for i = 1, #parts do
        local d = Vector3.length_squared(parts[i].center - origin)
        if d > far_d then
            far_d, far_c = d, parts[i].center
        end
    end
    if not far_c or far_d < 0.0001 then
        return false
    end
    local dir = Vector3.normalize(far_c - origin)
    local source = "hand->farthest piece"
    local base_rot = Unit.world_rotation(base, 1)
    local base_axes = { Quaternion.right(base_rot), Quaternion.forward(base_rot), Quaternion.up(base_rot) }
    local best, best_axis, best_i = 0, nil, nil
    for i = 1, 3 do
        local d = Vector3.dot(base_axes[i], dir)
        if math.abs(d) > best then
            best, best_i = math.abs(d), i
            best_axis = d < 0 and -base_axes[i] or base_axes[i]
        end
    end
    if best_axis and best > 0.97 then
        dir = best_axis
        source = string.format("base unit axis (%.2f to hand->farthest)", best)
    end
    if profile.profile_flip then
        dir = -dir
    end

    local t_min, t_max = 0, 0
    for i = 1, #parts do
        local t = Vector3.dot(parts[i].center - origin, dir)
        t_min = math.min(t_min, t - parts[i].half)
        t_max = math.max(t_max, t + parts[i].half)
    end
    local length = t_max - t_min
    if length <= 0 then
        return false
    end
    local ls = profile.profile_scale or 1
    local s_world = length * ls
    -- grip slider: slides the staff along its own line, in staff lengths. Positive = the hand holds it
    -- nearer the spearhead (the staff moves butt-wards), negative = nearer the butt end.
    local shift = profile.profile_grip or 0

    -- reference "up" across the shaft: the base unit axis least parallel to the staff
    local ref, ref_dot = nil, nil
    for i = 1, 3 do
        local d = math.abs(Vector3.dot(base_axes[i], dir))
        if ref_dot == nil or d < ref_dot then
            ref, ref_dot = base_axes[i], d
        end
    end
    local up = Vector3.normalize(ref - dir * Vector3.dot(ref, dir))
    local roll = math.rad(profile.profile_roll or 0)
    if roll ~= 0 then
        local side = Vector3.cross(dir, up)
        up = up * math.cos(roll) + side * math.sin(roll)
    end
    -- tilt: turns the spear about the hand, in the plane of the spearhead's flat (about "up", which is the
    -- flat's normal: the spear's local Z after Quaternion.look). The hand keeps its point on the shaft.
    local tilt = math.rad(profile.profile_tilt or 0)
    if tilt ~= 0 then
        local side = Vector3.cross(dir, up)
        dir = Vector3.normalize(dir * math.cos(tilt) + side * math.sin(tilt))
    end
    local butt = origin + dir * (t_min * ls - shift * s_world)

    local bx, by, bz = base_axes[1], base_axes[2], base_axes[3]
    local function to_local(v)
        return Vector3(Vector3.dot(v, bx), Vector3.dot(v, by), Vector3.dot(v, bz))
    end
    local k = parent_scale and parent_scale > 0 and parent_scale or 1
    local s = s_world / k
    local local_pos = to_local(butt - origin) * (1 / k)
    local local_dir = to_local(dir)
    Unit.set_local_position(staff, 1, local_pos)
    Unit.set_local_rotation(staff, 1, Quaternion.look(local_dir, to_local(up)))
    Unit.set_local_scale(staff, 1, Vector3(s, s, s))

    if view then
        last_fit[view] = string.format("%s: %d pieces, dir by %s, length %.3f (hand at %.2f of it), local start %s, local dir %s",
            view, #parts, source, length, -t_min / length, fmt(local_pos), fmt(local_dir))
    end
    return true
end

local function hide_originals(base, attachments)
    Unit.set_unit_visibility(base, false, true)
    if attachments then
        for i = 1, #attachments do
            if unit_ok(attachments[i]) then
                Unit.set_unit_visibility(attachments[i], false, true)
            end
        end
    end
end

-- One record per (holder, slot, view): { sword = staff unit, base, frames, count }
-- spawn_fn(parent, unit path) -> unit linked to parent node 1, destroy_fn(unit)
local function sync_record(records, key, base, attachments, item, visible, spawn_fn, destroy_fn, parent_scale, first_person)
    local rec = records[key]
    local want = unit_ok(base) and wants_item(item) and attachments ~= nil
    local template = item and item.weapon_template
    local spear = spear_for(template)

    -- a different spear (reroll, or another player's pick arriving) is a new unit
    if rec and (not want or rec.base ~= base or rec.spear ~= spear or not unit_ok(rec.sword)) then
        destroy_fn(rec.sword)
        records[key] = nil
        if rec.hid and rec.base == base and unit_ok(base) and visible then
            -- give the original weapon back (recursive visibility also covers its linked attachments)
            Unit.set_unit_visibility(base, true, true)
        end
        rec = nil
    end
    if not want then
        return false
    end

    if not rec then
        local staff = spawn_fn(base, spear_unit(spear))
        if not staff then
            return false
        end
        if first_person then
            -- same flag the game sets on first-person weapons (equipment_component.lua)
            Unit.set_shader_pass_flag_for_meshes_in_unit_and_childs(staff, "custom_fov", true)
        end
        rec = { sword = staff, base = base, spear = spear, frames = 0, count = -1, fitted = false }
        records[key] = rec
    end

    if rec.count ~= #attachments or rec.gen ~= fit_generation then
        rec.gen = fit_generation
        rec.count = #attachments
        rec.frames = 0
    end
    if rec.frames < FIT_FRAMES then
        rec.frames = rec.frames + 1
        local base_scale = Unit.local_scale(base, 1)
        local k = (parent_scale or 1) * (base_scale and base_scale.x or 1)
        apply_glow(rec.sword)
        rec.fitted = fit(rec.sword, base, attachments, k, key, profile_for(template)) or rec.fitted
    end

    if rec.fitted and visible then
        hide_originals(base, attachments)
        rec.hid = true
        Unit.set_unit_visibility(rec.sword, true, true)
    else
        Unit.set_unit_visibility(rec.sword, false, true)
    end
    return true
end

local function clear_records(records, destroy_fn)
    if not records then
        return
    end
    for key, rec in pairs(records) do
        destroy_fn(rec.sword)
        records[key] = nil
    end
end

-- In-game (your own player unit) ------------------------------------------------

local function ingame_spawn(ext, is_first_person)
    return function(parent, unit_path)
        local world = ext.__qiangiq_spear_world
        local unit_spawner = Managers.state and Managers.state.unit_spawner
        if not (world and unit_spawner) then
            return nil
        end
        local unit = unit_spawner:spawn_unit(unit_path, Unit.world_pose(parent, 1))
        if not unit then
            return nil
        end
        if is_first_person then
            Unit.set_unit_culling(unit, false)
        end
        World.link_unit(world, unit, 1, parent, 1, World.LINK_MODE_NODE_NAME)
        return unit
    end
end

local function ingame_destroy(unit)
    if unit_ok(unit) then
        local unit_spawner = Managers.state and Managers.state.unit_spawner
        if unit_spawner then
            unit_spawner:mark_for_deletion(unit)
        end
    end
end

local function ingame_apply(ext)
    local records = ext.__qiangiq_spear_records
    if not records then
        records = {}
        ext.__qiangiq_spear_records = records
    end
    local equipment = ext._equipment
    if not equipment then
        return
    end
    for slot_name, slot in pairs(equipment) do
        local item = slot.item
        if item and STAFF_SET[item.weapon_template] or records[slot_name .. ":3p"] or records[slot_name .. ":1p"] then
            local base_3p, base_1p = slot.unit_3p, slot.unit_1p
            local att_3p = base_3p and slot.attachments_by_unit_3p and slot.attachments_by_unit_3p[base_3p]
            local att_1p = base_1p and slot.attachments_by_unit_1p and slot.attachments_by_unit_1p[base_1p]
            -- "body" reference for the tilt direction: the character's vertical axis in third
            -- person, the view direction through the first-person unit in first person
            sync_record(records, slot_name .. ":3p", base_3p, att_3p, item, slot.hidden_3p == false,
                ingame_spawn(ext, false), ingame_destroy, 1, false)
            sync_record(records, slot_name .. ":1p", base_1p, att_1p, item, slot.hidden_1p == false,
                ingame_spawn(ext, true), ingame_destroy, 1, true)
        end
    end
end

local function is_local_human(ext)
    return sync_shown(ext)
end

vl_hook_safe("init", function(self, extension_init_context)
    self.__qiangiq_spear_world = extension_init_context and extension_init_context.world
end)

vl_hook_safe("_update_item_visibility", function(self)
    if not is_local_human(self) then
        return
    end
    tracked[self] = true
    ingame_apply(self)
end)

vl_hook_safe("update", function(self)
    if tracked[self] then
        ingame_apply(self)
    end
end)

vl_hook("_unequip_item_from_slot", function(func, self, slot_name, ...)
    local records = self.__qiangiq_spear_records
    if records then
        for _, view in ipairs({ ":3p", ":1p" }) do
            local rec = records[slot_name .. view]
            if rec then
                ingame_destroy(rec.sword)
                records[slot_name .. view] = nil
            end
        end
    end
    return func(self, slot_name, ...)
end)

vl_hook("destroy", function(func, self, ...)
    clear_records(self.__qiangiq_spear_records, ingame_destroy)
    tracked[self] = nil
    return func(self, ...)
end)

-- Menu previews ---------------------------------------------------------------

local function ui_profile_is_mine(profile)
    -- __qiangiq_npc: the companion NPC spawned by QIangIQsCompanionSwap is nobody's character
    if not profile or profile.__qiangiq_npc then
        return false
    end
    local players = Managers.player and Managers.player:players()
    local me = local_player()
    if players and profile.character_id then
        for _, player in pairs(players) do
            if player ~= me and player.character_id and player:character_id() == profile.character_id then
                return false
            end
        end
    end
    return true
end

local function ui_spawn(world)
    return function(parent, unit_path)
        -- same calls ui_profile_spawner.lua uses for its own units
        local unit = World.spawn_unit_ex(world, unit_path, nil, Unit.world_pose(parent, 1))
        World.link_unit(world, unit, 1, parent, 1, World.LINK_MODE_NODE_NAME)
        return unit
    end
end

local function ui_destroy_fn(world)
    return function(unit)
        if unit_ok(unit) and world then
            World.destroy_unit(world, unit)
        end
    end
end

local function scale_x(unit)
    if unit_ok(unit) then
        local s = Unit.local_scale(unit, 1)
        return s and s.x or 1
    end
    return 1
end

-- operative select / inventory character preview
local function profile_apply(spawner)
    local world = spawner._world
    local records = spawner.__qiangiq_spear_records
    if not records then
        records = {}
        spawner.__qiangiq_spear_records = records
    end
    local data = spawner._character_spawn_data
    local allowed = data and data.slots and opt("menu_previews") and ui_profile_is_mine(data.profile)
    if not allowed then
        clear_records(records, ui_destroy_fn(world))
        return
    end
    tracked_ui[spawner] = true
    local k = scale_x(data.unit_3p)
    for slot_name, slot in pairs(data.slots) do
        local item = slot.item
        if item and STAFF_SET[item.weapon_template] or records[slot_name] then
            local base = slot.unit_3p
            local att = base and slot.attachments_by_unit_3p and slot.attachments_by_unit_3p[base]
            sync_record(records, slot_name, base, att, item, spawner._visible and slot.hidden_3p == false,
                ui_spawn(world), ui_destroy_fn(world), k, false)
        end
    end
end

mod:hook_safe(CLASS.UIProfileSpawner, "_update_items_visibility", function(self)
    profile_apply(self)
end)

mod:hook_safe(CLASS.UIProfileSpawner, "update", function(self)
    local data = self._character_spawn_data
    if data and data.is_ready then
        profile_apply(self)
    elseif self.__qiangiq_spear_records then
        clear_records(self.__qiangiq_spear_records, ui_destroy_fn(self._world))
    end
end)

mod:hook(CLASS.UIProfileSpawner, "_despawn_current_character_profile", function(func, self, ...)
    clear_records(self.__qiangiq_spear_records, ui_destroy_fn(self._world))
    return func(self, ...)
end)

-- weapon inspect / inventory weapon preview
local function weapon_apply(spawner)
    local world = spawner._world
    local records = spawner.__qiangiq_spear_records
    if not records then
        records = {}
        spawner.__qiangiq_spear_records = records
    end
    local data = spawner._weapon_spawn_data
    if not (data and opt("menu_previews")) then
        if next(records) ~= nil then
            clear_records(records, ui_destroy_fn(world))
            if data and data.visible and unit_ok(data.item_unit_3p) then
                -- shown the same way ui_weapon_spawner.lua shows it
                Unit.set_unit_visibility(data.item_unit_3p, true, true)
            end
        end
        return
    end
    tracked_wpn[spawner] = true
    local base = data.item_unit_3p
    local att = base and data.attachment_units_3p and data.attachment_units_3p[base]
    local k = scale_x(data.link_unit)
    sync_record(records, "weapon", base, att, data.item, data.visible and true or false,
        ui_spawn(world), ui_destroy_fn(world), k, false)
end

mod:hook_safe(CLASS.UIWeaponSpawner, "update", function(self)
    weapon_apply(self)
end)

mod:hook(CLASS.UIWeaponSpawner, "_despawn_current_weapon", function(func, self, ...)
    clear_records(self.__qiangiq_spear_records, ui_destroy_fn(self._world))
    return func(self, ...)
end)

-- Refresh / toggles ------------------------------------------------------------

local function refresh_all()
    for ext in pairs(tracked) do
        if unit_ok(ext._unit) then
            ingame_apply(ext)
            -- restores the original weapon's visibility when a replacement was switched off
            ext:force_update_item_visibility()
        end
    end
    for spawner in pairs(tracked_ui) do
        profile_apply(spawner)
        if spawner._character_spawn_data and spawner._visible then
            spawner:_update_items_visibility()
        end
    end
    for spawner in pairs(tracked_wpn) do
        weapon_apply(spawner)
    end
end

mod.toggle_staff = function()
    session_off = not session_off
    refresh_all()
    mod:echo("Spear Arsenal replacement %s for this session", session_off and "off" or "on")
end

-- Per-staff profiles (the selection logic follows QIangIQsCookedMacroManager.lua and
-- QIangIQsSkullRuneblade.lua, mod.on_setting_changed) -------------------------------------------------

-- template of the equipped ranged weapon, read as CookedMacroManager's mod.get_equipped("RANGED") does
local function equipped_staff()
    local player = local_player()
    local player_unit = player and player.player_unit
    local weapon_extension = player_unit and ScriptUnit.has_extension(player_unit, "weapon_system")
    local weapons = weapon_extension and weapon_extension._weapons
    local weapon = weapons and weapons.slot_secondary
    local weapon_template = weapon and weapon.weapon_template
    local name = weapon_template and weapon_template.name
    return name and STAFF_SET[name] and name or nil
end

local function selected_staff()
    local sel = mod:get("staff_selection")
    return sel and STAFF_SET[sel] and sel or DEFAULT_STAFF
end

-- puts the selected staff's profile into the widgets
local function show_profile(template)
    local p = profile_for(template)
    for key, default in pairs(PROFILE_TEMPLATE) do
        local value = p[key]
        if value == nil then
            value = default
        end
        mod:set(key, value, false)
    end
end

local function save_profiles()
    mod:set("profiles", profiles, false)
end

local function load_profiles()
    profiles = mod:get("profiles")
    if type(profiles) ~= "table" then
        -- first run: the Inferno staff is replaced (as in 2.0 / 2.1), the others are not
        profiles = {}
        local inferno = table.clone(PROFILE_TEMPLATE)
        inferno.profile_enabled = true
        profiles[DEFAULT_STAFF] = inferno
        save_profiles()
    end
    show_profile(selected_staff())
end

local function after_change()
    fit_generation = fit_generation + 1
    refresh_all()
    local api = sync_api()
    if api then
        api.changed()
    end
end

-- /spear reroll and the reroll keybind: a new random spear for the equipped staff (every staff when no staff
-- is equipped). A staff set to a fixed spear goes back to "random".
mod.reroll_spear = function()
    local targets = {}
    local equipped = equipped_staff()
    if equipped then
        targets[1] = equipped
    else
        for i = 1, #STAFFS do
            targets[i] = STAFFS[i][1]
        end
    end
    for _, template in ipairs(targets) do
        local p = profile_for(template, true)
        session_pick[template] = roll(my_spear(template))
        if p.profile_spear ~= "random" then
            p.profile_spear = "random"
            save_profiles()
        end
    end
    if targets[1] then
        show_profile(selected_staff())
    end
    after_change()
    for _, template in ipairs(targets) do
        mod:echo("%s: %s", STAFF_SET[template], SPEARS[my_spear(template)][2])
    end
end

mod:command("spear", "Spear Arsenal: /spear (toggle), /spear reroll, /spear which, /spear debug", function(which)
    if which == "debug" then
        local any = false
        for _, line in pairs(last_fit) do
            mod:echo(line)
            any = true
        end
        if not any then
            mod:echo("No spear fitted yet: wield a force staff that is switched on in its profile.")
        end
        return
    end
    if which == "which" then
        for i = 1, #STAFFS do
            local template, name = STAFFS[i][1], STAFFS[i][2]
            local p = profile_for(template)
            if p.profile_enabled then
                local spear = my_spear(template)
                mod:echo("%s: %s (%s)", name, SPEARS[spear][2], SPEAR_BY_STEM[p.profile_spear or ""] and "chosen" or "random this session")
            else
                mod:echo("%s: not replaced", name)
            end
        end
        return
    end
    if which == "reroll" then
        mod.reroll_spear()
        return
    end
    mod.toggle_staff()
end)

-- QIangIQsWarframeArsenal and QIangIQsHorizonStaffs also replace force staffs: only one mod shows a staff at a time.
-- Called by it when it switches a staff on: the profile here goes off.
mod.release_template = function(template)
    local p = profiles and profiles[template]
    if p and p.profile_enabled then
        p.profile_enabled = false
        save_profiles()
        if selected_staff() == template then
            mod:set("profile_enabled", false, false)
        end
        after_change()
        mod:echo("%s is now shown by QIangIQ's Warframe Arsenal: switched off in Spear Arsenal.", template)
    end
end

mod.on_setting_changed = function(setting_id)
    local sel = selected_staff()
    if setting_id == "staff_selection" then
        show_profile(sel)
    elseif setting_id == "current_weapon" then
        if mod:get("current_weapon") then
            local equipped = equipped_staff()
            if equipped then
                mod:set("staff_selection", equipped, false)
                show_profile(equipped)
            else
                mod:echo("No force staff is equipped right now.")
            end
            mod:set("current_weapon", false, false)
        end
    elseif setting_id == "reset_weapon" then
        if mod:get("reset_weapon") then
            if profiles then
                profiles[sel] = table.clone(PROFILE_TEMPLATE)
                save_profiles()
            end
            session_pick[sel] = nil
            show_profile(sel)
            mod:set("reset_weapon", false, false)
        end
    elseif setting_id == "reset_all" then
        if mod:get("reset_all") then
            profiles = {}
            save_profiles()
            session_pick = {}
            show_profile(sel)
            mod:set("reset_all", false, false)
        end
    elseif setting_id and PROFILE_TEMPLATE[setting_id] ~= nil then
        if profiles then
            local p = profile_for(sel, true)
            p[setting_id] = mod:get(setting_id)
            save_profiles()
        end
        if setting_id == "profile_enabled" and mod:get("profile_enabled") then
            for _, other_name in ipairs({ "QIangIQsWarframeArsenal", "QIangIQsHorizonStaffs" }) do
                local other = get_mod(other_name)
                if other and other.release_template then
                    other.release_template(sel)
                end
            end
        end
    end
    after_change()
end

-- Package loading through Custom Assets --------------------------------------

mod.on_all_mods_loaded = function()
    load_profiles()
    custom_assets = get_mod("CustomAssets")
    if not custom_assets or not custom_assets.is_api_compatible or not custom_assets.is_api_compatible(1) then
        mod:error("Custom Assets (API 1) is missing. Install it and put it above QIangIQsSpearArsenal in mod_load_order.txt.")
        return
    end
    -- every spear is requested: other players' picks can be any of them (23 small units, 512 px textures)
    for i = 1, #SPEARS do
        local id = spear_id(i)
        local ticket, err = custom_assets.acquire(mod, id, function(_, _, load_error)
            if load_error then
                mod:error("%s failed to load: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", id, tostring(load_error))
                return
            end
            loaded[i] = true
            refresh_all()
        end, { resident = true, reference_name = id })
        if not ticket then
            mod:error("%s could not be requested: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", id, tostring(err))
        end
    end
end

local function remove_all()
    for ext in pairs(tracked) do
        clear_records(ext.__qiangiq_spear_records, ingame_destroy)
    end
    for spawner in pairs(tracked_ui) do
        clear_records(spawner.__qiangiq_spear_records, ui_destroy_fn(spawner._world))
    end
    for spawner in pairs(tracked_wpn) do
        clear_records(spawner.__qiangiq_spear_records, ui_destroy_fn(spawner._world))
    end
end

mod.on_disabled = function()
    remove_all()
    -- hooks are off now, so these restore the original weapon visibility
    for ext in pairs(tracked) do
        if unit_ok(ext._unit) then
            ext:force_update_item_visibility()
        end
    end
    for spawner in pairs(tracked_ui) do
        if spawner._character_spawn_data and spawner._visible then
            spawner:_update_items_visibility()
        end
    end
    for spawner in pairs(tracked_wpn) do
        local data = spawner._weapon_spawn_data
        if data and data.visible and unit_ok(data.item_unit_3p) then
            Unit.set_unit_visibility(data.item_unit_3p, true, true)
        end
    end
end

mod.on_enabled = function()
    refresh_all()
end

mod.on_unload = function()
    remove_all()
    if custom_assets and custom_assets.release_owner then
        custom_assets.release_owner(mod)
    end
end


-- Cross-client sync: what this mod publishes about me, and the refresh when anyone's options change ---------
-- switched-on staffs I carry (every switched-on staff while I have no unit)
local function sync_carried(info)
    local list = {}
    for i = 1, #STAFFS do
        local template = STAFFS[i][1]
        if staff_on(template) and (info.templates == nil or info.templates[template]) then
            list[#list + 1] = template
        end
    end
    return list
end

local function sync_applies(info)
    return #sync_carried(info) > 0
end

local sync_enabled = true
local function sync_changed()
    local api = sync_api()
    if api then
        api.changed()
    end
end

mod.sync_key = SYNC_KEY
-- info = { breed, companion_breed, templates = { [weapon_template] = true } } of my own character (fields nil
-- while I have no unit). Returns the array to publish, or nil when this mod shows nothing on my character.
mod.sync_export = function(info)
    info = info or {}
    if not sync_enabled or not sync_applies(info) then
        return nil
    end
    local mask, bit = 0, 1
    for i = 1, #SYNC_BOOLS do
        local key = SYNC_BOOLS[i]
        local v = mod:get(key)
        if v == nil then
            v = SYNC_DEFAULTS[key]
        end
        if v then
            mask = mask + bit
        end
        bit = bit * 2
    end
    local out = { SYNC_LAYOUT, mask }
    for i = 1, #SYNC_VALUES do
        local v = mod:get(SYNC_VALUES[i])
        if type(v) == "number" then
            v = math.floor(v * 100 + 0.5) / 100
        elseif type(v) ~= "string" then
            v = false -- not set: the reader falls back to its default
        end
        out[2 + i] = v
    end
    -- profiles of the carried staffs: { [template] = { spear, scale, grip, roll, tilt, flip } }
    local extra, carried = {}, sync_carried(info)
    local function r(v, default)
        return math.floor((tonumber(v) or default) * 100 + 0.5) / 100
    end
    for i = 1, #carried do
        local template = carried[i]
        local p = profile_for(template)
        local v = { SPEARS[my_spear(template)][1], r(p.profile_scale, 1), r(p.profile_grip, 0),
            r(p.profile_roll, 0), r(p.profile_tilt, 0), p.profile_flip and 1 or 0 }
        if v[2] == 1 and v[3] == 0 and v[4] == 0 and v[5] == 0 and v[6] == 0 then
            v = v[1] -- every slider at its default: only the model name (the Vox Manifold payload is small)
        end
        extra[template] = v
    end
    out[3 + #SYNC_VALUES] = extra
    return out
end

mod.sync_refresh = function()
    for ext in pairs(sync_all) do
        if ext._unit and Unit.alive(ext._unit) and ext.force_update_item_visibility then
            pcall(ext.force_update_item_visibility, ext)
        end
    end
end

local sync_prev_setting_changed = mod.on_setting_changed
mod.on_setting_changed = function(...)
    if sync_prev_setting_changed then
        sync_prev_setting_changed(...)
    end
    sync_changed()
end

local sync_prev_disabled = mod.on_disabled
mod.on_disabled = function(...)
    sync_enabled = false
    if sync_prev_disabled then
        sync_prev_disabled(...)
    end
    sync_changed()
end

local sync_prev_enabled = mod.on_enabled
mod.on_enabled = function(...)
    sync_enabled = true
    if sync_prev_enabled then
        sync_prev_enabled(...)
    end
    sync_changed()
end

-- QIangIQsArmoryVis: stowed-weapon copies (see QIangIQsArmoryVis/README.md). Armory Vis calls apply every frame
-- and clear once per copy with `holder` (one table per character and stowed slot: _unit, _player, _ext,
-- _slot_name) and `equipment` ({ [slot_name] = slot-like table of the copy, hidden_3p false while shown }).
-- The in-game apply above runs on the holder as it runs on a loadout extension.
mod.armory_vis = {
    apply = function(holder, world, equipment)
        holder.__qiangiq_spear_world = world
        holder._equipment = equipment
        ingame_apply(holder)
    end,
    clear = function(holder)
        clear_records(holder.__qiangiq_spear_records, ingame_destroy)
        holder.__qiangiq_spear_records = nil
    end,
}
