return {
    mod_name = {
        en = "QIangIQ's Spear Arsenal",
    },
    mod_description = {
        en = "Shows Genshin Impact polearms (23, Custom Assets) in place of the force staffs. Each staff has its own profile: on/off, which spear (or a random one each session), length, grip, spin, tilt and flip. /spear which lists them, /spear reroll rolls the equipped staff again. By QIangIQ.",
    },
    staff_selection = {
        en = "Staff",
    },
    staff_selection_description = {
        en = "The force staff whose profile the settings below show and change.",
    },
    forcestaff_p1_m1 = {
        en = "Voidblast Force Staff",
    },
    forcestaff_p2_m1 = {
        en = "Inferno Force Staff",
    },
    forcestaff_p3_m1 = {
        en = "Electrokinetic Force Staff",
    },
    forcestaff_p4_m1 = {
        en = "Voidstrike Force Staff",
    },
    current_weapon = {
        en = "Select equipped staff",
    },
    current_weapon_description = {
        en = "Tick to pick the force staff you are holding in the Staff list.",
    },
    profile_enabled = {
        en = "Replace this staff",
    },
    profile_enabled_description = {
        en = "Show a spear in place of the selected staff.",
    },
    profile_spear = {
        en = "Spear",
    },
    profile_spear_description = {
        en = "Random = a new random spear each game session (the reroll keybind or /spear reroll picks another). Or pick one spear for this staff.",
    },
    spear_random = {
        en = "Random each session",
    },
    spear_beginners_protector = {
        en = "Beginner's Protector",
    },
    spear_black_tassel = {
        en = "Black Tassel",
    },
    spear_blackcliff_pole = {
        en = "Blackcliff Pole",
    },
    spear_crescent_pike = {
        en = "Crescent Pike",
    },
    spear_deathmatch = {
        en = "Deathmatch",
    },
    spear_dragons_bane = {
        en = "Dragon's Bane",
    },
    spear_dragonspine_spear = {
        en = "Dragonspine Spear",
    },
    spear_engulfing_lightning = {
        en = "Engulfing Lightning",
    },
    spear_favonius_lance = {
        en = "Favonius Lance",
    },
    spear_halberd = {
        en = "Halberd",
    },
    spear_iron_point = {
        en = "Iron Point",
    },
    spear_kitain_cross_spear = {
        en = "Kitain Cross Spear",
    },
    spear_lithic_spear = {
        en = "Lithic Spear",
    },
    spear_primordial_jade_winged_spear = {
        en = "Primordial Jade Winged-Spear",
    },
    spear_prototype_grudge = {
        en = "Prototype Grudge",
    },
    spear_regicide = {
        en = "Regicide",
    },
    spear_royal_spear = {
        en = "Royal Spear",
    },
    spear_skyward_spine = {
        en = "Skyward Spine",
    },
    spear_staff_of_homa = {
        en = "Staff of Homa",
    },
    spear_the_catch = {
        en = "The Catch",
    },
    spear_vortex_vanquisher = {
        en = "Vortex Vanquisher",
    },
    spear_wavebreakers_fin = {
        en = "Wavebreaker's Fin",
    },
    spear_white_tassel = {
        en = "White Tassel",
    },
    profile_scale = {
        en = "Length (x original staff)",
    },
    profile_scale_description = {
        en = "1 = same length as the staff it replaces. The hand stays on the same point of the shaft.",
    },
    profile_grip = {
        en = "Grip location",
    },
    profile_grip_description = {
        en = "Where the hand holds the spear, in spear lengths. 0 = where the staff is held. Positive = nearer the spearhead, negative = nearer the butt end.",
    },
    profile_roll = {
        en = "Spin around the shaft (degrees)",
    },
    profile_roll_description = {
        en = "Turns the spear around its own shaft, e.g. to face the spearhead's flat side forward.",
    },
    profile_tilt = {
        en = "Tilt (degrees)",
    },
    profile_tilt_description = {
        en = "Leans the spear about the hand, in the plane of the spearhead's flat side.",
    },
    profile_flip = {
        en = "Flip end to end",
    },
    profile_flip_description = {
        en = "Use this if the spearhead points the wrong way (towards the butt of the original staff).",
    },
    reset_weapon = {
        en = "Reset selected staff",
    },
    reset_weapon_description = {
        en = "Tick to put the selected staff's profile back to the defaults (not replaced).",
    },
    reset_all = {
        en = "Reset all staffs",
    },
    reset_all_description = {
        en = "Tick to put every staff's profile back to the defaults (none replaced).",
    },
    glow_brightness = {
        en = "Glow brightness",
    },
    glow_brightness_description = {
        en = "Brightness of the glowing parts (Staff of Homa spokes and eye, Engulfing Lightning blade, Skyward Spine and The Catch blades, Primordial Jade shards, the gems of Lithic Spear, Royal Spear and Regicide, Blackcliff Pole core). 2 = as built, 0 = off.",
    },
    menu_previews = {
        en = "Show in menus (inventory, operative previews)",
    },
    menu_previews_description = {
        en = "Also swaps the staffs in menu previews of your own operatives and in the weapon inspect view.",
    },
    toggle_staff_keybind = {
        en = "Toggle Spear Arsenal replacement",
    },
    reroll_spear_keybind = {
        en = "Reroll spear",
    },
    reroll_spear_keybind_description = {
        en = "A new random spear for the staff you are holding (every staff when none is held), for the rest of the session. A staff set to a fixed spear goes back to random.",
    },
}
