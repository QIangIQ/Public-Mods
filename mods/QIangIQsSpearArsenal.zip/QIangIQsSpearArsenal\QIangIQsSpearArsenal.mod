return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsSpearArsenal` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsSpearArsenal", {
            mod_script = "QIangIQsSpearArsenal/scripts/mods/QIangIQsSpearArsenal/QIangIQsSpearArsenal",
            mod_data = "QIangIQsSpearArsenal/scripts/mods/QIangIQsSpearArsenal/QIangIQsSpearArsenal_data",
            mod_localization = "QIangIQsSpearArsenal/scripts/mods/QIangIQsSpearArsenal/QIangIQsSpearArsenal_localization",
        })
    end,
    version = "2.2.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
