return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsMMJMagicGlove` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsMMJMagicGlove", {
            mod_script = "QIangIQsMMJMagicGlove/scripts/mods/QIangIQsMMJMagicGlove/QIangIQsMMJMagicGlove",
            mod_data = "QIangIQsMMJMagicGlove/scripts/mods/QIangIQsMMJMagicGlove/QIangIQsMMJMagicGlove_data",
            mod_localization = "QIangIQsMMJMagicGlove/scripts/mods/QIangIQsMMJMagicGlove/QIangIQsMMJMagicGlove_localization",
        })
    end,
    version = "0.1.0",
    author = "QIangIQ",
    packages = {},
}
