-- QIangIQsMMJMagicGlove per-weapon data (gen.py spec magic_glove). Clips are MMJ clip names from magic_glove\OBJ-Weapond-Magic-Glove lv1__16533.
-- Action map sources: Darktide weapon templates (Aussiemon master) via tools\dump_actions.py.
return {
    ranged = true,
    idle = "magic glove-idle",
    fx_node = "j_leftweaponattach",
    templates = { forcestaff_p2_m1 = true },
    actions = {
        action_wield = { clips = { "magic glove-equip" } },
        action_shoot_flame = { clips = { "magic glove-shoot" }, sounds = { "sfx_wp_railgun_shot_01.ogg", "sfx_wp_railgun_shot_02.ogg", "sfx_wp_railgun_shot_03.ogg" } },
        action_charge_flame = { clips = { "magic glove-shoot" }, segment = { 0.25, 0.35 }, sounds = { "camera canon eos 3000n flash charging mono.ogg" } },
        action_shoot_charged_flame = { clips = { "magic glove-shoot" }, segment = { 0.0, 0.233 }, sounds = { "LASRBeam_Calibrated Heavy Repulsor Ray_PSE_ANI_NzwaX.ogg" } },
        action_vent = { clips = { "magic glove-reload and slow intro" }, loop = true },
    },
}
