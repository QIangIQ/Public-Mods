Using your own images instead
-----------------------------

The mod loads every image in this folder and plays them sorted by filename.
Delete what's here, drop yours in, done.

Names sort as text, so 10 comes before 2. Zero-pad them:

    01.png  02.png  03.png       yes
    1.png   2.png   10.png       no

Any count works, including a single image (it gets held on screen instead of
animating). PNG and JPG both load. 16:9 fills the area without bars.

Sound is one file named scare.ogg.
