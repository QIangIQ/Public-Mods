return {
	-- Needs SimpleAssets for the images and SimpleAudio for the sound.
	-- Neither is a hard requirement to load: without them the scare is a
	-- screen flash and nothing else.
	run = function()
		fassert(rawget(_G, "new_mod"), "`1 in x chance foxy jumpscare mod` encountered an error loading the Darktide Mod Framework.")

		new_mod("FoxyJumpscare", {
			mod_script       = "1 in x chance foxy jumpscare mod/scripts/mods/FoxyJumpscare/FoxyJumpscare",
			mod_data         = "1 in x chance foxy jumpscare mod/scripts/mods/FoxyJumpscare/FoxyJumpscare_data",
			mod_localization = "1 in x chance foxy jumpscare mod/scripts/mods/FoxyJumpscare/FoxyJumpscare_localization",
		})
	end,
	version = "1.0.0",
	packages = {},
}
