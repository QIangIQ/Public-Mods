--[[
    Every setting_id in DiosJumpscare_data.lua needs an entry here, and every
    non-group widget needs a matching _tooltip. DMF renders the raw id when a
    key is missing, which looks like a bug and reads like one.

    The tooltips carry the requirements on purpose. The mod ships working
    assets, so the common question is not "what do I put in it" but "why do I
    see a black flash and no picture" - and the answer, which is always a
    missing SimpleAssets or SimpleAudio, belongs where someone is already
    looking rather than only in a README they have not opened.
--]]
return {
    mod_name = {
        en = "1 in 1000x chance for foxy jumpscare",
    },

    dio_scare_mod_description = {
        en = "Author: Dioscurio\n\n"
            .. "A small chance, every second, of a full-screen jumpscare.\n\n"
            .. "OFF BY DEFAULT - tick the box below to arm it.\n\n"
            .. "BOTH THE ODDS AND THE SCARE ARE YOURS TO CHANGE:\n\n"
            .. "Odds - the chance and the roll interval are sliders below. Anything from "
            .. "1 in 1 (every roll fires) to 1 in 100000. The two multiply, so 1 in 1000 every "
            .. "10 seconds is the same rate as 1 in 10000 every second.\n\n"
            .. "Assets - the mod plays every image in  mods/1 in x chance foxy jumpscare mod/assets/  sorted by "
            .. "filename, so delete the included frames and drop your own in to replace the scare "
            .. "entirely. Any number of frames, including one. Sound is  scare.ogg.\n"
            .. "Zero-pad the names: text sorting puts 10 before 2.\n\n"
            .. "REQUIRES SimpleAssets (animation) and SimpleAudio (sound). Each missing one costs "
            .. "its own half - with neither you get a dark flash and nothing else.\n\n"
            .. "Type /jumpscare in chat to fire one and see what loaded.\n\n"
            .. "Frames and sound from PredatedElk6's Balatro mod \"1 in 10000 chance for Withered Foxy "
            .. "jumpscare every second\". Withered Foxy is from Five Nights at Freddy's, by Scott Cawthon. "
            .. "Texture and audio loading by SimpleAssets and SimpleAudio, by Zombine.",
    },

    dio_scare = {
        en = "Enable jumpscare",
    },
    dio_scare_tooltip = {
        en = "Off by default, and it never arms itself.\n\n"
            .. "The scare ships ready to go, but it needs two libraries to show up:\n"
            .. "SimpleAssets for the animation, SimpleAudio for the sound. Each missing one "
            .. "costs exactly its own half - with neither you get a dark flash and nothing else.\n\n"
            .. "SWAPPING IT: the mod plays every image in  mods/1 in x chance foxy jumpscare mod/assets/  "
            .. "sorted by filename, so you can delete the included frames and drop your own in. "
            .. "Zero-pad the names - text sorting puts 10 before 2. Sound is  scare.ogg.\n\n"
            .. "/jumpscare fires one on demand and reports what loaded, whether or not this box is ticked.\n\n"
            .. "Only rolls while you are alive in a mission - never in the Mourningstar, never while downed.",
    },

    dio_scare_chance = {
        en = "Chance: 1 in N",
    },
    dio_scare_chance_tooltip = {
        en = "One in this many, per roll.\n\n"
            .. "10000 at a one second interval is roughly once every 2 hours 45 minutes of being alive in a mission. "
            .. "1000 is about once every 17 minutes.\n\n"
            .. "Set it to 1 to make every roll fire, which is how you check your files work without waiting.",
    },

    dio_scare_interval = {
        en = "Seconds between rolls",
    },
    dio_scare_interval_tooltip = {
        en = "How often the dice are rolled. One second matches the Balatro mod this idea comes from.\n\n"
            .. "Raising this is a second way to make the scare rarer - the two multiply, so 1 in 1000 "
            .. "rolled every 10 seconds is the same rate as 1 in 10000 rolled every second.",
    },

    dio_scare_look_group = {
        en = "Appearance",
    },

    dio_scare_size = {
        en = "Size (% of screen)",
    },
    dio_scare_size_tooltip = {
        en = "How much of the screen the image covers, as a percentage of a 16:9 reference. "
            .. "One number drives both axes, so no aspect ratio can stretch the picture.\n\n"
            .. "100 is genuinely full-screen. The dark flash behind the image is sized to match, "
            .. "so at smaller values it is a card behind the picture rather than a screen-wide impact.",
    },

    dio_scare_frame_delay = {
        en = "Frame time (1/100 sec)",
    },
    dio_scare_frame_delay_tooltip = {
        en = "How long each frame is held, in hundredths of a second.\n\n"
            .. "7 is about 14 frames per second, which is the original's timing. Lower is faster. "
            .. "The whole animation lasts frames x this, so it also sets how long the scare is on screen.\n\n"
            .. "Ignored when there is only one image - a single frame is held for a readable beat instead.",
    },

    dio_scare_sound = {
        en = "Play sound",
    },
    dio_scare_sound_tooltip = {
        en = "Plays  assets/scare.ogg  when the scare fires. Needs SimpleAudio installed.\n\n"
            .. "The filename is fixed rather than a setting, because a text box that has to match a filename "
            .. "exactly causes more problems than it solves. If you swap the sound, name yours scare.ogg.\n\n"
            .. "It follows your SFX and master volume sliders.",
    },
}
