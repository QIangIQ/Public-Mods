local mod = get_mod("DiosJumpscare")

--[[
    ========================================================================
    1 in x chance foxy jumpscare mod
    ========================================================================

    A chance, every so often, of a short full-screen animation and a sound.
    Bring your own images.

    This file is only wiring: the HUD element registration, the per-frame
    hook, and the one predicate the roll depends on. The scare itself lives in
    DiosJumpscare_jumpscare.lua and the drawing in HudElementDiosJumpscare.lua.
--]]

--[[
    REGISTERED AS "HudElementDiosJumpscare", WHICH MUST MATCH THE STRING THAT
    FILE PASSES TO class().

    UIHud uses the name from two different places:

        _add_element               elements[definition.class_name] = element
        _update_element_visibility  local n = element.__class_name
                                    status = visible_elements[n] or false

    visible_elements is built from the REGISTRATION's class_name, but the
    visibility lookup asks the ELEMENT for its own name, and that comes from
    class(). If the two disagree the element is constructed, updated every
    frame, and permanently invisible - with no error and no log line. There is
    a check for this in _tools/check_hud_names.py; it exists because this
    failure is completely silent.

    "alive" only. The whole joke is that it happens to YOU, mid-fight. Firing
    one over a spectator camera is a confusing black flash on somebody else's
    gameplay.
--]]
mod:register_hud_element({
    class_name = "HudElementDiosJumpscare",
    filename = "1 in x chance foxy jumpscare mod/scripts/mods/DiosJumpscare/HudElementDiosJumpscare",
    use_hud_scale = false,

    visibility_groups = {
        "alive",
    },
})

--[[
    Alive AND in a mission, which are not the same question.

    Managers.state.* only exists in a mission, so its absence is the hub test
    and no separate one is needed. The unit check is what stops a scare firing
    over a corpse or during the drop.
--]]
function mod.player_is_alive()
    local pm = Managers and Managers.player

    if not pm then
        return false
    end

    local ok, player = pcall(pm.local_player, pm, 1)

    if not ok or not player then
        return false
    end

    local unit = player.player_unit and player:player_unit()

    if not unit then
        return false
    end

    local Unit_alive = rawget(_G, "Unit")

    if not Unit_alive or not Unit_alive.alive(unit) then
        return false
    end

    --[[
        Alive in the engine sense is not alive in the gameplay sense - a
        knocked-down or hogtied player still has a live unit. The health
        extension is the honest answer and its absence is treated as dead,
        because a player whose extensions have not been created yet is
        mid-spawn.
    --]]
    local ext = Managers.state and Managers.state.extension

    if not ext then
        return false
    end

    local ok_h, health = pcall(ext.system, ext, "health_system")

    if not ok_h or not health then
        return false
    end

    local ok_a, alive = pcall(health.is_alive, health, unit)

    return ok_a and alive == true
end

mod:io_dofile("1 in x chance foxy jumpscare mod/scripts/mods/DiosJumpscare/DiosJumpscare_jumpscare")

--[[
    DMF calls mod.update(dt) once per frame when the field exists. Everything
    is driven from here so there is one place that decides how often anything
    in this mod runs, and pcall'd so a fault in the scare cannot take a frame
    down with it.
--]]
function mod.update(dt)
    local jump = mod.__dio_jump

    if jump and jump.update then
        pcall(jump.update, dt)
    end
end
