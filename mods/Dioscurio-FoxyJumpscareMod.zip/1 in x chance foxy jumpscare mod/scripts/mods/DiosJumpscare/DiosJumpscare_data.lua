local mod = get_mod("DiosJumpscare")

--[[
    ========================================================================
    SETTINGS
    ========================================================================

    OFF BY DEFAULT, and that is not a formality.

    This mod's entire function is to surprise you with a loud full-screen
    image. Anything that ships armed will eventually fire at someone who
    installed it, forgot, and is three hours into a run - or at someone who
    installed it for a friend and never read the description. It arms when a
    person deliberately ticks a box, and not before.

    The rest of the tree nests under that box, so a player who leaves it off
    sees exactly one line and never scrolls past odds they will not use.

    THE CHANCE IS 1-IN-N, NOT A PERCENTAGE, because that is how the number is
    actually reasoned about. "One in ten thousand a second" is legible;
    "0.01%" is the same fact in a form nobody can picture.

    At the default 1 in 10000 rolled once a second, the expected wait is about
    2 hours 45 minutes of being alive in a mission - which is the original
    Balatro mod's rate, and about right for something that should feel like an
    accident rather than a feature.
--]]

--[[
    `name` is what the mod settings list shows. The FOLDER is
    "1 in x chance foxy jumpscare mod", which is a separate string and has to
    stay in step with three other things by hand:

        the .mod file's own filename
        the mod_* paths inside it
        every "mods/<folder>/assets" path in DiosJumpscare_jumpscare.lua

    _tools/preflight.py checks the first two. The asset paths are only proved
    by the frames actually loading, so if a rename ever leaves the animation
    dead with the sound working, that is the first place to look.
--]]
return {
    name = "1 in 1000x chance for foxy jumpscare",
    description = "dio_scare_mod_description",
    is_togglable = true,

    options = {
        widgets = {
            {
                setting_id = "dio_scare",
                type = "checkbox",
                default_value = false,
                tooltip = "dio_scare_tooltip",

                sub_widgets = {
                    {
                        setting_id = "dio_scare_chance",
                        type = "numeric",
                        default_value = 10000,
                        range = { 1, 100000 },
                        tooltip = "dio_scare_chance_tooltip",
                    },
                    {
                        setting_id = "dio_scare_interval",
                        type = "numeric",
                        default_value = 1,
                        range = { 1, 60 },
                        tooltip = "dio_scare_interval_tooltip",
                    },

                    --[[
                        Presentation, one level down: these describe how the
                        scare LOOKS, as opposed to whether and how often it
                        happens, and nobody tuning the odds is also tuning the
                        frame rate in the same sitting.
                    --]]
                    {
                        setting_id = "dio_scare_look_group",
                        type = "group",

                        sub_widgets = {
                            --[[
                                Percentage of the screen's 16:9 reference, so
                                one number covers both axes and no aspect
                                ratio can distort the image.
                            --]]
                            {
                                setting_id = "dio_scare_size",
                                type = "numeric",
                                default_value = 40,
                                range = { 10, 100 },
                                tooltip = "dio_scare_size_tooltip",
                            },

                            --[[
                                Hundredths of a second per frame. Exposed as
                                an integer because DMF's numeric widget with
                                decimals is fiddlier to drag than it is worth
                                for a value nobody sets twice.

                                7 is ~14fps, which is the original's timing.
                            --]]
                            {
                                setting_id = "dio_scare_frame_delay",
                                type = "numeric",
                                default_value = 7,
                                range = { 1, 50 },
                                tooltip = "dio_scare_frame_delay_tooltip",
                            },
                            {
                                setting_id = "dio_scare_sound",
                                type = "checkbox",
                                default_value = true,
                                tooltip = "dio_scare_sound_tooltip",
                            },
                        },
                    },
                },
            },
        },
    },
}
