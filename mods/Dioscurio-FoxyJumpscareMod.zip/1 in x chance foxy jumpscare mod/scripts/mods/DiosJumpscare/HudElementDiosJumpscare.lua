local mod = get_mod("DiosJumpscare")

local UIWidget = require("scripts/managers/ui/ui_widget")
local UIWorkspaceSettings = require("scripts/settings/ui/ui_workspace_settings")

--[[
    ========================================================================
    THE OVERLAY
    ========================================================================

    Two passes:

        flash   a plain rect. Needs nothing loaded and is the whole effect
                when SimpleAssets is absent or the frames have not arrived.
        image   the current frame, bound through material_values.

    THE MATERIAL IS ui_default_base AND THAT CHOICE MATTERS.

    content/ui/materials/base/ui_default_base is the engine's stock texture
    material; its settable slot is texture_map, and ui_passes routes a
    userdata material value through Material.set_resource - so a texture
    object with no resource name binds there exactly like the resource-name
    strings the game's own views assign.

    The obvious alternative, the news view's article_image_blank, is a banner
    material with a horizontal edge fade baked into its material values. An
    image drawn through it comes out smeared with the alpha channel gone.
    That finding is CustomCrosshairs' (crosshair_template.lua:16-26) and it
    saves an afternoon.

    material_values MUST EXIST AT DEFINITION TIME. ui_passes only builds a
    per-pass gui material - and so only honours material_values at all - when
    the style already carries that table. An empty table is fine; a nil one
    means the texture silently never binds.

    ------------------------------------------------------------------------
    THE ELEMENT IS SIZED BY A SETTING, AND THE NODE IS WHAT COUNTS

    The scenegraph node is the element as far as anything outside this file is
    concerned - it is what a HUD editor draws a box around and what "how big
    is it" means. Sizing only the image pass and leaving the node full-screen
    produces an element that is still full-screen with a small picture in it.

    So the node is resized too, every frame, from the size setting.

    The trade is that the flash cannot exceed the node: at small sizes it is a
    card behind the image rather than a screen-wide impact. That is the right
    way round - a full-screen flash is exactly what someone asking for a
    smaller element does not want.

    ------------------------------------------------------------------------
    IT IS ALWAYS CENTRED, AND THAT IS NOT NEGOTIABLE

    Position is re-asserted every frame so no HUD editor can move it. A
    jumpscare parked in the corner of the screen is not a jumpscare, and there
    is no reason anyone would want one there except to defeat it.

    Note the class name below is the one this element is REGISTERED under in
    DiosJumpscare.lua. UIHud builds its visibility set from the registration's
    class_name but looks visibility up via element.__class_name, which comes
    from the string passed to class() - so if those two ever disagree, the
    element is constructed, ticked, and permanently invisible with no error
    anywhere. Keep them identical.
--]]

local IMAGE_MATERIAL = "content/ui/materials/base/ui_default_base"
local IMAGE_SLOT = "texture_map"

-- The 16:9 reference the node is scaled from. Not the monitor.
local BASE_W, BASE_H = 1920, 1080

local HudElementDiosJumpscare = class("HudElementDiosJumpscare", "HudElementBase")

local scenegraph_definition = {
    screen = UIWorkspaceSettings.screen,
    scare = {
        parent = "screen",
        scale = "fit",
        vertical_alignment = "center",
        horizontal_alignment = "center",
        size = { BASE_W, BASE_H },
        --[[
            z of 900: over the rest of the HUD, which is the point, and under
            nothing that matters because it is up for under a second.
        --]]
        position = { 0, 0, 900 },
    },
}

local widget_definitions = {
    scare = UIWidget.create_definition({
        {
            pass_type = "rect",
            style_id = "flash",
            style = {
                color = { 0, 0, 0, 0 },
                size = { BASE_W, BASE_H },
                offset = { 0, 0, 0 },
                horizontal_alignment = "center",
                vertical_alignment = "center",
            },
        },
        {
            pass_type = "texture",
            style_id = "image",
            value = IMAGE_MATERIAL,
            style = {
                color = { 0, 255, 255, 255 },
                size = { BASE_W, BASE_H },
                offset = { 0, 0, 1 },
                horizontal_alignment = "center",
                vertical_alignment = "center",
                material_values = {},
            },
        },
    }, "scare"),
}

HudElementDiosJumpscare.init = function(self, parent, draw_layer, start_scale)
    HudElementDiosJumpscare.super.init(self, parent, draw_layer, start_scale, {
        scenegraph_definition = scenegraph_definition,
        widget_definitions = widget_definitions,
    })

    self._was_active = false
    self._last_size = nil
end

--[[
    Size is applied to the node AND to both passes, and only when it changes -
    it is four table writes, but they are four table writes that would
    otherwise happen sixty times a second for a value that changes when
    somebody drags a slider.
--]]
HudElementDiosJumpscare._apply_size = function(self, widget)
    local pct = tonumber(mod:get("dio_scare_size")) or 40

    if self._last_size == pct then
        return
    end

    self._last_size = pct

    local w = math.floor(BASE_W * (pct / 100))
    local h = math.floor(BASE_H * (pct / 100))

    local node = self._ui_scenegraph and self._ui_scenegraph.scare

    if node and node.size then
        node.size[1], node.size[2] = w, h
    end

    local style = widget.style

    if style.flash and style.flash.size then
        style.flash.size[1], style.flash.size[2] = w, h
    end

    if style.image and style.image.size then
        style.image.size[1], style.image.size[2] = w, h
    end

    widget.dirty = true
end

HudElementDiosJumpscare.update = function(self, dt, t, ui_renderer, render_settings, input_service)
    HudElementDiosJumpscare.super.update(self, dt, t, ui_renderer, render_settings, input_service)

    -- Always centred. See the note above.
    self:set_scenegraph_position("scare", 0, 0)

    local widget = self._widgets_by_name and self._widgets_by_name.scare

    if not widget then
        return
    end

    local Jump = mod.__dio_jump
    local on = Jump and Jump.active()

    --[[
        widget.visible rather than zeroing the alphas: it is the flag the
        renderer itself checks, so one assignment covers both passes, and a
        rect left at alpha 0 is still a full-screen draw every frame for
        something nobody can see.
    --]]
    if not on then
        if self._was_active then
            self._was_active = false
            widget.visible = false
        end

        return
    end

    if not self._was_active then
        self._was_active = true
        widget.visible = true
    end

    self:_apply_size(widget)

    local style = widget.style

    --[[
        Rebound EVERY FRAME, not once. The textures arrive asynchronously, so
        the widget reliably exists before its image does, and a mod reload
        replaces the frame table underneath a live widget.

        A nil here is the normal state while frames are still loading, or
        permanently when SimpleAssets is absent. Handled by leaving the image
        transparent rather than by skipping the draw, so the flash still fires
        and the scare still lands without the animation.
    --]]
    local tex = Jump.frame(Jump.current_frame())

    if style.image and style.image.material_values then
        style.image.material_values[IMAGE_SLOT] = tex
        style.image.color[1] = tex and 255 or 0
    end

    --[[
        The flash fades across the animation so it reads as an impact rather
        than a black box sitting on screen. Full opacity when there is no
        texture, so the feature still does something with no SimpleAssets.
    --]]
    if style.flash then
        local count = Jump.frame_count()
        local peak = tex and 120 or 255
        local frac = count > 1
            and (1 - ((Jump.current_frame() - 1) / count))
            or 1

        style.flash.color[1] = math.floor(peak * frac)
    end
end

return HudElementDiosJumpscare
