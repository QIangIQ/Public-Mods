local mod = get_mod("DiosJumpscare")

--[[
    ========================================================================
    THE SCARE: LOADING, ROLLING, FIRING
    ========================================================================

    A chance, every so often, of a short animation and a sound.

    ------------------------------------------------------------------------
    FRAMES ARE DISCOVERED, NOT HARDCODED

    This mod ships no images. Whatever PNG or JPEG files are in its assets
    folder become the animation, sorted by filename, and the count is however
    many there are. So

        assets/01.png  02.png  03.png

    is a three frame animation and

        assets/a.png

    is a single held image. Both are valid; neither needs a setting.

    SimpleAssets.load_textures_from_dir does the listing and the loading in
    one call and hands back a table keyed by relative path. Sorting those keys
    is what makes the order predictable - the table itself has no order, and
    an animation whose frames arrive in hash order is not an animation.

    NUMBERS SORT AS TEXT, which is worth knowing before naming files:

        frame_1, frame_10, frame_2      wrong, and it is not a bug
        frame_01, frame_02, frame_10    right

    Zero-pad, and the README says so.

    ------------------------------------------------------------------------
    THE SOUND IS ONE FIXED FILENAME

    assets/scare.ogg, played through SimpleAudio. Fixed rather than a setting
    because a text box that has to match a filename exactly is a support
    burden, and "rename your file to scare.ogg" is one instruction.

    Wwise is not involved and cannot be: it only plays events compiled into a
    soundbank that is currently resident, so a loose file has no route through
    it. SimpleAudio decodes the file itself and plays it outside Wwise.

    ------------------------------------------------------------------------
    NOTHING HERE RUNS AT MOD LOAD

    Both libraries are resolved on the first frame that wants them, never
    during new_mod. Loading a native DLL in early boot is how a mod breaks
    somebody else's unrelated mod, and it is not worth the milliseconds.
--]]

local Jump = {}

local SOUND_FILE = "scare.ogg"
local MAX_ATTEMPTS = 3

--[[
    Prefixed with "mods/" rather than relative.

    A bare relative path makes SimpleAssets infer the calling mod by walking
    the Lua stack for "/mods/<name>/scripts/", and that walk stops at the
    first frame that does not match - so any C frame in between, a pcall being
    the easiest one to introduce, resolves the path against SimpleAssets' own
    folder instead. The prefixed form is resolved from the mods directory and
    never consults the caller.
--]]
local ASSET_DIR = "mods/1 in x chance foxy jumpscare mod/assets"
local SOUND_PATH = "mods/1 in x chance foxy jumpscare mod/assets/" .. SOUND_FILE

-- index -> texture, dense, in sorted-filename order
local frames = {}
local frame_count = 0

local load_state = "not started"
local attempts = 0

local active = false
local scare_timer = 0
local frame_index = 1
local frame_timer = 0
local roll_timer = 0

local function num(id, fallback)
    local v = tonumber(mod:get(id))

    return v and v > 0 and v or fallback
end

-- ---------------------------------------------------------------- loading --

local function assets_lib()
    local sa = get_mod("SimpleAssets")

    if sa and type(sa.load_textures_from_dir) == "function" then
        return sa
    end

    return nil
end

local function audio_lib()
    local sa = get_mod("SimpleAudio")

    if sa and type(sa.play_file) == "function" then
        return sa
    end

    return nil
end

local function begin_load()
    if load_state ~= "not started" and load_state ~= "retrying" then
        return
    end

    local sa = assets_lib()

    if not sa then
        load_state = "SimpleAssets not installed - no animation"
        return
    end

    attempts = attempts + 1
    load_state = "loading"

    local ok, promise = pcall(sa.load_textures_from_dir, ASSET_DIR, false)

    if not ok or not promise then
        load_state = "assets folder could not be read"

        mod:error("[jumpscare] could not read %s: %s", ASSET_DIR, tostring(promise))
        return
    end

    promise:next(function(results)
        --[[
            results is keyed by relative path and therefore unordered. Collect
            the keys, sort them, and index the textures by position - that
            sort IS the frame order.
        --]]
        local names = {}

        for name in pairs(results) do
            names[#names + 1] = name
        end

        table.sort(names)

        frames = {}
        frame_count = 0

        for i = 1, #names do
            local entry = results[names[i]]

            --[[
                A per-file failure resolves to the rejection value rather than
                throwing, so a folder with one unreadable file still yields
                every other frame. Skipped rather than fatal.
            --]]
            if type(entry) == "table" and entry.is_ok and entry.texture then
                frame_count = frame_count + 1
                frames[frame_count] = entry.texture
            end
        end

        if frame_count == 0 then
            load_state = "no usable images in the assets folder"
            return
        end

        load_state = string.format("%d frame%s loaded",
            frame_count, frame_count == 1 and "" or "s")
    end, function(err)
        --[[
            Retried, because the SimpleAssets runtime starts asynchronously
            and an early request can be refused simply for being early.
        --]]
        if attempts < MAX_ATTEMPTS then
            load_state = "retrying"
            return
        end

        load_state = "load failed - see the log"

        mod:error("[jumpscare] gave up loading frames after %d attempts: %s",
            attempts, tostring(type(err) == "table" and err.error or err))
    end)
end

-- ------------------------------------------------------------------ sound --

local function play_sound()
    if mod:get("dio_scare_sound") == false then
        return
    end

    local sa = audio_lib()

    if not sa then
        return
    end

    --[[
        audio_type "sfx" so the file rides the player's SFX slider and their
        master volume. A jumpscare that ignores the volume settings of
        someone who deliberately turned the game down is not a joke.
    --]]
    pcall(sa.play_file, SOUND_PATH, { audio_type = "sfx" })
end

-- ------------------------------------------------------------------ state --

function Jump.state()
    return load_state
end

function Jump.frame_count()
    return frame_count
end

function Jump.frame(i)
    return frames[i]
end

function Jump.active()
    return active
end

function Jump.current_frame()
    return frame_index
end

function Jump.sound_available()
    return audio_lib() ~= nil
end

function Jump.trigger()
    local delay = num("dio_scare_frame_delay", 7) / 100

    active = true
    frame_index = 1
    frame_timer = 0

    --[[
        A single frame has no animation to play, so it is held for a readable
        beat instead of vanishing in one frame delay.
    --]]
    scare_timer = frame_count > 1 and (frame_count * delay) or 0.8

    play_sound()
end

function Jump.update(dt)
    if mod:get("dio_scare") ~= true then
        active = false
        return
    end

    begin_load()

    if active then
        scare_timer = scare_timer - dt

        if scare_timer <= 0 then
            active = false
            return
        end

        if frame_count > 1 then
            local delay = num("dio_scare_frame_delay", 7) / 100

            frame_timer = frame_timer + dt

            if frame_timer >= delay then
                frame_timer = frame_timer - delay
                frame_index = frame_index + 1

                --[[
                    Clamped, not looped. scare_timer is already sized to the
                    animation so a second pass cannot start; clamping just
                    holds the last frame cleanly instead of snapping back to
                    the first on the final tick.
                --]]
                if frame_index > frame_count then
                    frame_index = frame_count
                end
            end
        end

        return
    end

    --[[
        THE ROLL. Only while alive and in a mission: a jumpscare in the
        Mourningstar is confusing rather than frightening, and one fired over
        a corpse is neither.
    --]]
    if not mod.player_is_alive or not mod.player_is_alive() then
        return
    end

    local interval = num("dio_scare_interval", 1)

    roll_timer = roll_timer + dt

    if roll_timer < interval then
        return
    end

    --[[
        Subtracted rather than zeroed, so a frame that overshoots the interval
        does not silently shorten the next one. Zeroing drifts the real rate
        above the configured one across a long session.
    --]]
    roll_timer = roll_timer - interval

    local chance = num("dio_scare_chance", 10000)

    if math.random() < (1 / chance) then
        Jump.trigger()
    end
end

--[[
    Fires one on demand and reports both halves separately, because from the
    couch a missing animation and a missing sound look identical - each has
    its own library and its own failure.
--]]
mod:command("jumpscare", "fire the jumpscare once, and report what is loaded", function()
    mod:echo(string.format("[Jumpscare] frames: %s", Jump.state()))
    mod:echo(string.format("[Jumpscare] sound: %s",
        audio_lib() and ("SimpleAudio ready - playing assets/" .. SOUND_FILE)
                     or "SimpleAudio not installed - no sound"))

    if mod:get("dio_scare") ~= true then
        mod:echo("[Jumpscare] the mod is switched off - enable it in the settings to arm the random roll")
    end

    --[[
        Fires regardless of the on/off setting. This command is how you check
        your own files are working, and refusing to run until the random roll
        is armed would make testing require arming it.
    --]]
    Jump.trigger()
end)

mod.__dio_jump = Jump

return Jump
