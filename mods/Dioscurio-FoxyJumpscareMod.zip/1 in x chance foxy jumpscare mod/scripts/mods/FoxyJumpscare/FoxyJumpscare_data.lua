local mod = get_mod("FoxyJumpscare")

-- description is LOCALIZED HERE, not passed as a key. DMF hands this table's
-- description straight to the menu, so a key would render as the key.
return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,

	options = {
		widgets = {
			-- Defaults to off. Everything else nests under it, so leaving it
			-- off means one line in the menu.
			{
				setting_id = "scare_enabled",
				type = "checkbox",
				default_value = false,
				tooltip = "scare_enabled_tooltip",

				sub_widgets = {
					-- 1-in-N rather than a percentage. 10000 a second is the
					-- rate the original Balatro mod used.
					{
						setting_id = "scare_chance",
						type = "numeric",
						default_value = 10000,
						range = { 1, 100000 },
						tooltip = "scare_chance_tooltip",
					},
					{
						setting_id = "scare_interval",
						type = "numeric",
						default_value = 1,
						range = { 1, 60 },
						tooltip = "scare_interval_tooltip",
					},

					{
						setting_id = "scare_look_group",
						type = "group",

						sub_widgets = {
							-- Hundredths of a second. An integer because
							-- DMF's decimal sliders are awkward to drag.
							{
								setting_id = "scare_frame_time",
								type = "numeric",
								default_value = 7,
								range = { 1, 50 },
								tooltip = "scare_frame_time_tooltip",
							},
							{
								setting_id = "scare_sound",
								type = "checkbox",
								default_value = true,
								tooltip = "scare_sound_tooltip",
							},
						},
					},
				},
			},
		},
	},
}
