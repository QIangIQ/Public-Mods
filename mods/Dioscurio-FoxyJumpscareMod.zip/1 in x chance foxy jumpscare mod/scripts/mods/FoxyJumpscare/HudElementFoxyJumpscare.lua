local mod = get_mod("FoxyJumpscare")

local UIWidget = require("scripts/managers/ui/ui_widget")
local UIWorkspaceSettings = require("scripts/settings/ui/ui_workspace_settings")

--[[
	Two passes: a flash rect that always works, and the current frame.

	THE MATERIAL IS ui_default_base AND THAT MATTERS. Its settable slot is
	texture_map, and ui_passes routes a userdata material value through
	Material.set_resource - so a loaded texture binds there like the resource
	names the game's own views use.

	The obvious alternative, the news view's article_image_blank, has a
	horizontal edge fade baked in that smears the image and eats the alpha.
	That is CustomCrosshairs' finding and it saves an afternoon.

	material_values must exist at definition time. ui_passes only builds a
	per-pass material when the style already carries the table, so a nil one
	means the texture silently never binds.

	THE CLASS NAME HERE MUST MATCH THE class_name IT IS REGISTERED UNDER in
	FoxyJumpscare.lua. UIHud builds its visibility set from the registration
	but looks visibility up via element.__class_name, which comes from the
	string below. If they disagree the element is built, updated every frame,
	and permanently invisible, with no error anywhere.
--]]

local IMAGE_MATERIAL = "content/ui/materials/base/ui_default_base"
local IMAGE_SLOT = "texture_map"

--[[
	FULLSCREEN, AND NOT RESIZABLE. This is deliberate and it took three
	attempts to get right, so the reason is written down.

	The node uses scale = "fit". In UIScenegraph.update_scenegraph, the "fit"
	branch does two things worth knowing:

		size_x = w_inverse_scale        -- the node is FORCED to full screen
		size_y = h_inverse_scale
		...and _handle_alignment is NEVER CALLED

	Only the aspect_ratio, fit_width and fit_height branches align. So
	horizontal_alignment and vertical_alignment on a "fit" node do nothing at
	all - the node sits at the safe-rect origin, which is the top-left.

	That means this element was never centred by alignment. A 1920x1080 image
	drawn from the top-left simply fills the screen, which is indistinguishable
	from centred. Shrinking it to 40% did not move a centred thing off-centre;
	it revealed that the anchor had been the corner the whole time.

	Which is why adding _set_scenegraph_size and re-asserting position both
	failed to fix it: there was no alignment step for either to influence.

	Centring a smaller node would mean scale = "aspect_ratio" (which does call
	_handle_alignment) or computing the offset by hand against the live
	resolution. Both are doable. Neither is worth it for a full-screen
	jumpscare, which is what this is.
--]]
local BASE_W, BASE_H = 1920, 1080

local HudElementFoxyJumpscare = class("HudElementFoxyJumpscare", "HudElementBase")

local scenegraph_definition = {
	screen = UIWorkspaceSettings.screen,
	scare = {
		parent = "screen",
		scale = "fit",
		vertical_alignment = "center",
		horizontal_alignment = "center",
		size = { BASE_W, BASE_H },
		-- z 900: over the rest of the HUD, which is the point.
		position = { 0, 0, 900 },
	},
}

local widget_definitions = {
	scare = UIWidget.create_definition({
		{
			pass_type = "rect",
			style_id = "flash",
			style = {
				color = { 0, 0, 0, 0 },
				size = { BASE_W, BASE_H },
				offset = { 0, 0, 0 },
				horizontal_alignment = "center",
				vertical_alignment = "center",
			},
		},
		{
			pass_type = "texture",
			style_id = "image",
			value = IMAGE_MATERIAL,
			style = {
				color = { 0, 255, 255, 255 },
				size = { BASE_W, BASE_H },
				offset = { 0, 0, 1 },
				horizontal_alignment = "center",
				vertical_alignment = "center",
				material_values = {},
			},
		},
	}, "scare"),
}

HudElementFoxyJumpscare.init = function(self, parent, draw_layer, start_scale)
	HudElementFoxyJumpscare.super.init(self, parent, draw_layer, start_scale, {
		scenegraph_definition = scenegraph_definition,
		widget_definitions = widget_definitions,
	})

	self._was_active = false
end

HudElementFoxyJumpscare.update = function(self, dt, t, ui_renderer, render_settings, input_service)
	HudElementFoxyJumpscare.super.update(self, dt, t, ui_renderer, render_settings, input_service)

	local widget = self._widgets_by_name and self._widgets_by_name.scare

	if not widget then
		return
	end

	local Scare = mod.__foxy_scare
	local on = Scare and Scare.active()

	--[[
		widget.visible rather than zeroing alphas: it is the flag the renderer
		checks, so one assignment covers both passes, and a rect left at alpha
		0 is still a draw every frame for something nobody can see.
	--]]
	if not on then
		if self._was_active then
			self._was_active = false
			widget.visible = false
		end

		return
	end

	if not self._was_active then
		self._was_active = true
		widget.visible = true
	end

	local style = widget.style

	--[[
		Rebound every frame. The textures arrive asynchronously so the widget
		reliably exists before its image does, and a mod reload replaces the
		frame table under a live widget.

		nil is normal while loading, or permanent with no SimpleAssets.
		Handled by leaving the image transparent rather than skipping the draw
		so the flash still fires.
	--]]
	local tex = Scare.frame(Scare.current_frame())

	if style.image and style.image.material_values then
		style.image.material_values[IMAGE_SLOT] = tex
		style.image.color[1] = tex and 255 or 0
	end

	-- Fades across the animation so it reads as an impact rather than a black
	-- box. Full opacity with no texture, so the scare still lands.
	if style.flash then
		local count = Scare.frame_count()
		local peak = tex and 120 or 255
		local frac = count > 1 and (1 - ((Scare.current_frame() - 1) / count)) or 1

		style.flash.color[1] = math.floor(peak * frac)
	end
end

return HudElementFoxyJumpscare
