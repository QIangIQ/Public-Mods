local mod = get_mod("FoxyJumpscare")

-- Wiring only. The scare is in FoxyJumpscare_scare.lua, the drawing in
-- HudElementFoxyJumpscare.lua.

--[[
	class_name here must match the string HudElementFoxyJumpscare.lua passes
	to class(). UIHud builds its visibility set from this class_name but looks
	visibility up via element.__class_name - so a mismatch leaves the element
	constructed, updated, and permanently invisible with nothing in the log.

	"alive" only. The joke is that it happens to you mid-fight; firing one
	over a spectator camera is a confusing black flash on someone else's game.
--]]
mod:register_hud_element({
	class_name = "HudElementFoxyJumpscare",
	filename = "1 in x chance foxy jumpscare mod/scripts/mods/FoxyJumpscare/HudElementFoxyJumpscare",
	use_hud_scale = false,

	visibility_groups = {
		"alive",
	},
})

--[[
	Alive and not disabled. Runs anywhere you have a character: missions, the
	Mourningstar and the Psykhanium. A downed player's unit is still alive to
	the health extension, so knocked down / netted / grabbed etc. are checked
	separately from the character state - a scare fired over someone in
	bleedout is not funny.
--]]
--[[
	CRASH FIX (console-2026-10-05-01.02.22): this used to call
	Managers.player:local_player(1) every frame from the title screen on.
	local_player calls Network.peer_id(), which is a NATIVE crash before the
	network is up - pcall cannot catch it, the game just dies at the title
	screen. Two guards now, in this order:

	  1. Managers.state.extension exists whenever you are in a world with a
	     character - missions, the Mourningstar and the Psykhanium alike - and
	     is absent on the title screen, character select and loading screens,
	     which are exactly where the crash happened. So the scare still rolls
	     everywhere it used to.
	  2. local_player_safe returns nil unless the connection manager is
	     initialized, instead of calling Network.peer_id() blind.

	Also: player_unit is a FIELD on the player, not a method, so the old
	player:player_unit() threw every frame once in a mission.
--]]
local DISABLED_STATES = {
	dead = true,
	knocked_down = true,
	hogtied = true,
	netted = true,
	pounced = true,
	grabbed = true,
	consumed = true,
	mutant_charged = true,
	catapulted = true,
	warp_grabbed = true,
	ledge_hanging = true,
}

function mod.player_is_alive()
	local ext = Managers and Managers.state and Managers.state.extension

	if not ext then
		return false
	end

	local pm = Managers.player

	if not pm or not pm.local_player_safe then
		return false
	end

	local ok, player = pcall(pm.local_player_safe, pm, 1)

	if not ok or not player then
		return false
	end

	local unit = player.player_unit

	if not unit then
		return false
	end

	local Unit_g = rawget(_G, "Unit")

	if not Unit_g or not Unit_g.alive(unit) then
		return false
	end

	--[[
		The old check asked the health SYSTEM for is_alive(unit). The system has
		no such method, so pcall always failed and the scare could never roll in
		a mission. Alive is asked of the unit's own health EXTENSION, and
		"downed" comes from the character state, which is where the engine keeps
		it (a knocked-down player is still alive to the health extension).
	--]]
	local SU = rawget(_G, "ScriptUnit")

	if not SU then
		return false
	end

	local health = SU.has_extension(unit, "health_system")

	if not health then
		return false
	end

	local ok_a, alive = pcall(health.is_alive, health)

	if not ok_a or alive ~= true then
		return false
	end

	local unit_data = SU.has_extension(unit, "unit_data_system")
	local ok_c, state = pcall(function()
		return unit_data and unit_data:read_component("character_state").state_name
	end)

	if ok_c and DISABLED_STATES[state] then
		return false
	end

	return true
end

mod:io_dofile("1 in x chance foxy jumpscare mod/scripts/mods/FoxyJumpscare/FoxyJumpscare_scare")

-- DMF calls this once per frame when the field exists. pcall'd so a fault in
-- the scare cannot take a frame down with it.
function mod.update(dt)
	local scare = mod.__foxy_scare

	if scare and scare.update then
		pcall(scare.update, dt)
	end
end
