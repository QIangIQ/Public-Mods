local function color(text, r, g, b)
	return string.format("{#color(%d,%d,%d)}%s{#reset()}", r, g, b, text)
end

return {
	mod_name = {
		en = "1 in 1000x chance for foxy jumpscare",
	},

	mod_description = {
		en = color("Author: Dioscurio", 255, 215, 95)
			.. "\n"
			.. color("A small chance, every second, of a fullscreen Foxy jumpscare. Off until you turn it on.", 185, 210, 170)
			.. "\n"
			.. color("Needs SimpleAssets and SimpleAudio. Type /jumpscare to test it.", 185, 210, 170)
			.. "\n ",
	},

	scare_enabled = {
		en = "Enable jumpscare",
	},
	scare_enabled_tooltip = {
		en = "Rolls once a second while you are alive in a mission. Never in the Mourningstar, never while downed.\n\n"
			.. "/jumpscare fires one right now, on or off.",
	},

	scare_chance = {
		en = "Chance: 1 in N",
	},
	scare_chance_tooltip = {
		en = "One in this many, per roll.\n\n"
			.. "10000 is about once every 2h45m of mission time. 1000 is about every 17 minutes. "
			.. "Set it to 1 and every roll fires.",
	},

	scare_interval = {
		en = "Seconds between rolls",
	},
	scare_interval_tooltip = {
		en = "How often the dice are rolled.\n\n"
			.. "This and the chance multiply. 1 in 1000 every 10 seconds is the same rate as 1 in 10000 every second.",
	},

	scare_look_group = {
		en = "Appearance",
	},


	scare_frame_time = {
		en = "Frame time (1/100 sec)",
	},
	scare_frame_time_tooltip = {
		en = "How long each frame is held. 7 is about 14fps, which matches the original.\n\n"
			.. "Frames x this is how long the scare lasts. Ignored if you only have one image.",
	},

	scare_sound = {
		en = "Play sound",
	},
	scare_sound_tooltip = {
		en = "Plays assets/scare.ogg. Needs SimpleAudio.\n\n"
			.. "Follows your SFX and master volume.",
	},
}
