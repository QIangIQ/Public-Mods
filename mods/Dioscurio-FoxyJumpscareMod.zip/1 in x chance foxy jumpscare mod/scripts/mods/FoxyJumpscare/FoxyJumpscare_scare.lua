local mod = get_mod("FoxyJumpscare")

--[[
	Loading, rolling, firing.

	FRAMES ARE WHATEVER IS IN assets/. They are sorted by filename and that
	sort is the frame order, so names have to be zero-padded - text sorting
	puts 10 before 2. Any count works, including one.

	The sound is one fixed filename, scare.ogg. Fixed rather than a setting
	because a text box that has to match a filename exactly causes more
	support than it saves.

	Neither library is touched during mod load. Both resolve on the first
	frame that wants them.
--]]

local Scare = {}

local SOUND_FILE = "scare.ogg"
local MAX_ATTEMPTS = 3

--[[
	The "mods/" prefixed form, not a relative path.

	A relative path makes SimpleAssets work out the calling mod by walking the
	Lua stack for "/mods/<name>/scripts/", and that walk stops at the first
	frame that does not match - so any C frame in between, a pcall being the
	easiest one to introduce, resolves against SimpleAssets' own folder
	instead. The prefixed form skips the walk.
--]]
local ASSET_DIR = "mods/1 in x chance foxy jumpscare mod/assets"
local SOUND_PATH = ASSET_DIR .. "/" .. SOUND_FILE

local frames = {}
local frame_count = 0

local load_state = "not started"
local attempts = 0

local active = false
local scare_timer = 0
local frame_index = 1
local frame_timer = 0
local roll_timer = 0

local function num(id, fallback)
	local v = tonumber(mod:get(id))

	return v and v > 0 and v or fallback
end

local function assets_lib()
	local sa = get_mod("SimpleAssets")

	return sa and type(sa.load_textures_from_dir) == "function" and sa or nil
end

local function audio_lib()
	local sa = get_mod("SimpleAudio")

	return sa and type(sa.play_file) == "function" and sa or nil
end

local function begin_load()
	if load_state ~= "not started" and load_state ~= "retrying" then
		return
	end

	local sa = assets_lib()

	if not sa then
		load_state = "SimpleAssets not installed - no animation"
		return
	end

	attempts = attempts + 1
	load_state = "loading"

	local ok, promise = pcall(sa.load_textures_from_dir, ASSET_DIR, false)

	if not ok or not promise then
		load_state = "assets folder could not be read"
		mod:error("[foxy] could not read %s: %s", ASSET_DIR, tostring(promise))
		return
	end

	promise:next(function(results)
		-- results is keyed by relative path and unordered. Sorting the keys
		-- is what makes the frame order predictable.
		local names = {}

		for name in pairs(results) do
			names[#names + 1] = name
		end

		table.sort(names)

		frames = {}
		frame_count = 0

		for i = 1, #names do
			local entry = results[names[i]]

			-- A per-file failure resolves to the rejection rather than
			-- throwing, so one unreadable file does not cost the rest.
			if type(entry) == "table" and entry.is_ok and entry.texture then
				frame_count = frame_count + 1
				frames[frame_count] = entry.texture
			end
		end

		if frame_count == 0 then
			load_state = "no usable images in assets"
			return
		end

		load_state = string.format("%d frame%s loaded",
			frame_count, frame_count == 1 and "" or "s")
	end, function(err)
		-- Retried because the SimpleAssets runtime starts asynchronously and
		-- an early request can be refused just for being early.
		if attempts < MAX_ATTEMPTS then
			load_state = "retrying"
			return
		end

		load_state = "load failed - see the log"
		mod:error("[foxy] gave up loading frames after %d attempts: %s",
			attempts, tostring(type(err) == "table" and err.error or err))
	end)
end

local function play_sound()
	if mod:get("scare_sound") == false then
		return
	end

	local sa = audio_lib()

	if not sa then
		return
	end

	-- sfx so it follows the player's SFX and master sliders. A jumpscare that
	-- ignores someone's volume settings is not a joke.
	pcall(sa.play_file, SOUND_PATH, { audio_type = "sfx" })
end

function Scare.state()
	return load_state
end

function Scare.frame_count()
	return frame_count
end

function Scare.frame(i)
	return frames[i]
end

function Scare.active()
	return active
end

function Scare.current_frame()
	return frame_index
end

function Scare.trigger()
	local delay = num("scare_frame_time", 7) / 100

	active = true
	frame_index = 1
	frame_timer = 0

	-- One frame has nothing to animate, so it is held for a readable beat
	-- rather than vanishing after a single frame time.
	scare_timer = frame_count > 1 and (frame_count * delay) or 0.8

	play_sound()
end

function Scare.update(dt)
	if mod:get("scare_enabled") ~= true then
		active = false
		return
	end

	begin_load()

	if active then
		scare_timer = scare_timer - dt

		if scare_timer <= 0 then
			active = false
			return
		end

		if frame_count > 1 then
			local delay = num("scare_frame_time", 7) / 100

			frame_timer = frame_timer + dt

			if frame_timer >= delay then
				frame_timer = frame_timer - delay
				frame_index = frame_index + 1

				-- Clamped, not looped. scare_timer is already sized to the
				-- animation, so this just holds the last frame cleanly.
				if frame_index > frame_count then
					frame_index = frame_count
				end
			end
		end

		return
	end

	if not mod.player_is_alive or not mod.player_is_alive() then
		return
	end

	local interval = num("scare_interval", 1)

	roll_timer = roll_timer + dt

	if roll_timer < interval then
		return
	end

	-- Subtracted rather than zeroed, so an overshooting frame does not
	-- shorten the next interval and drift the rate up over a long session.
	roll_timer = roll_timer - interval

	if math.random() < (1 / num("scare_chance", 10000)) then
		Scare.trigger()
	end
end

-- Reports both halves separately: a missing animation and a missing sound
-- look the same from the couch but have different causes.
mod:command("jumpscare", "fire the jumpscare once and report what loaded", function()
	mod:echo(string.format("[foxy] frames: %s", Scare.state()))
	mod:echo(string.format("[foxy] sound: %s",
		audio_lib() and ("ready - " .. SOUND_FILE) or "SimpleAudio not installed"))

	if mod:get("scare_enabled") ~= true then
		mod:echo("[foxy] the mod is off - tick it in the settings to arm the random roll")
	end

	-- Fires regardless of the setting. This is how you test your own files
	-- without having to arm the random roll first.
	Scare.trigger()
end)

mod.__foxy_scare = Scare

return Scare
