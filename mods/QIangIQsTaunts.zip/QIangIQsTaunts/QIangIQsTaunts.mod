return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsTaunts` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsTaunts", {
            mod_script = "QIangIQsTaunts/scripts/mods/QIangIQsTaunts/QIangIQsTaunts",
            mod_data = "QIangIQsTaunts/scripts/mods/QIangIQsTaunts/QIangIQsTaunts_data",
            mod_localization = "QIangIQsTaunts/scripts/mods/QIangIQsTaunts/QIangIQsTaunts_localization",
        })
    end,
    version = "0.1.0",
    author = "QIangIQ",
    packages = {},
}
