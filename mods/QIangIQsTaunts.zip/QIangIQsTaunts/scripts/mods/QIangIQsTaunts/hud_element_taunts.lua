-- The taunt frame (one texture pass) and the voice line text, drawn as one HUD element (DMF register_hud_element;
-- pass pattern from QIangIQsFingerGun's hud_element_finger_gun.lua). Layout space is the 1920x1080 UI screen.
-- Frames are 2:1 in Boltgun 1 (512x256) and 1440x405 in Boltgun 2 (aspect per set); by default the frame spans the
-- screen width and sits on the bottom edge.
local mod = get_mod("QIangIQsTaunts")
local UIWorkspaceSettings = require("scripts/settings/ui/ui_workspace_settings")
local UIWidget = require("scripts/managers/ui/ui_widget")
local UIFontSettings = require("scripts/managers/ui/ui_font_settings")

local MATERIAL = "content/ui/materials/base/ui_default_base"
local W, H = 1920, 1080

local subtitle_style = table.clone(UIFontSettings.hud_body)

subtitle_style.text_horizontal_alignment = "center"
subtitle_style.text_vertical_alignment = "bottom"
subtitle_style.horizontal_alignment = "center"
subtitle_style.vertical_alignment = "bottom"
subtitle_style.font_size = 26
subtitle_style.offset = { 0, -170, 10 }
subtitle_style.size = { W, 60 }
subtitle_style.text_color = { 255, 255, 255, 255 }
subtitle_style.drop_shadow = true

local definitions = {
    scenegraph_definition = {
        screen = UIWorkspaceSettings.screen,
    },
    widget_definitions = {
        taunt = UIWidget.create_definition({
            {
                pass_type = "texture",
                value_id = "frame",
                style_id = "frame",
                value = MATERIAL,
                style = {
                    color = { 255, 255, 255, 255 },
                    offset = { 0, 0, 1 },
                    size = { W, W / 2 },
                    material_values = {},
                    visible = false,
                },
            },
            {
                pass_type = "text",
                value_id = "subtitle",
                style_id = "subtitle",
                value = "",
                style = subtitle_style,
            },
        }, "screen"),
    },
}

HudElementQIangIQsTaunts = class("HudElementQIangIQsTaunts", "HudElementBase")

function HudElementQIangIQsTaunts:init(parent, draw_layer, start_scale)
    HudElementQIangIQsTaunts.super.init(self, parent, draw_layer, start_scale, definitions)

    self._widget = self._widgets_by_name.taunt
end

function HudElementQIangIQsTaunts:update(dt, t, ui_renderer, render_settings, input_service)
    HudElementQIangIQsTaunts.super.update(self, dt, t, ui_renderer, render_settings, input_service)

    local api = mod.taunts
    local widget = self._widget
    local st = widget.style.frame
    local tex = api and api.frame()

    if tex and tex.texture then
        local scale, ox, oy, aspect = api.layout()
        local w = W * scale
        local h = w / aspect

        st.visible = true
        st.size[1], st.size[2] = w, h
        st.offset[1] = (W - w) / 2 + ox * W
        st.offset[2] = H - h - oy * H
        st.material_values.texture_map = tex.texture
    else
        st.visible = false
        st.material_values.texture_map = nil
    end

    local text = api and api.subtitle()

    widget.content.subtitle = text or ""
    widget.dirty = true
end

return HudElementQIangIQsTaunts
