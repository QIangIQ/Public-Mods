local loc = {
    mod_name = { en = "QIangIQ's Taunts" },
    mod_description = { en = "Boltgun taunts on every class: the taunting arm on screen and a random voice line, picked the way Boltgun picks them. Local only (contains ripped Boltgun art and audio)." },
    taunt_key = { en = "Taunt key" },
    taunt_key_2 = { en = "Taunt key 2" },
    taunt_key_3 = { en = "Taunt key 3" },
    classes = { en = "Sprite and voice per class" },
    character_malum = { en = "Malum Caedo (Boltgun 1 + 2)" },
    character_canoness = { en = "Sister of Battle (Boltgun 2)" },
    character_none = { en = "None" },
    mode = { en = "Taunt type" },
    mode_auto = { en = "Auto (directed when an enemy is in the crosshair within taunt range)" },
    mode_directed = { en = "Always directed (at enemy)" },
    mode_undirected = { en = "Always undirected" },
    one_arm_melee = { en = "Melee and one-handed sprite weapons (MMJ pistols, Magic Glove, etc): keep the weapon, hide the left arm and taunt with the free arm only" },
    hide_weapon = { en = "Ranged weapons: hide the first-person weapon and arms during the taunt (as Boltgun draws the taunt in place of the weapon)" },
    subtitles = { en = "Show voice line text" },
    volume = { en = "Volume (percent)" },
    layout = { en = "Sprite layout" },
    size = { en = "Size (percent of screen width)" },
    offset_x = { en = "Offset X (percent of screen)" },
    offset_y = { en = "Offset Y (percent of screen)" },
    command_desc = { en = "Taunt status; /taunts play [directed|undirected]" },
}

local CLASS_NAMES = {
    veteran = "Veteran", zealot = "Zealot", psyker = "Psyker", ogryn = "Ogryn", adamant = "Arbites", broker = "Hive Scum",
    cryptic = "Skitarius",
}

for class, name in pairs(CLASS_NAMES) do
    loc["sprite_" .. class] = { en = name .. ": taunt sprite" }
    loc["voice_" .. class] = { en = name .. ": taunt voice" }
end

return loc