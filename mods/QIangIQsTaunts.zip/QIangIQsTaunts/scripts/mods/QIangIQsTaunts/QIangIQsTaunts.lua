local mod = get_mod("QIangIQsTaunts")

-- QIangIQsTaunts 0.1.0: Warhammer 40,000: Boltgun taunts on every Darktide class.
--
-- Boltgun's player taunt is a 2D sprite flipbook drawn on the weapon render plane (BGPlayerAnimation: one material per
-- frame, TimeToDisplay per frame) plus a voice line from a SoundCue and a foley cue. All of it comes from the Boltgun 1
-- rip (D:\boltgun_rip\bg1) through bake_taunts.py into sets/<set>.lua:
--   BP_CharacterData: TauntRange 5000 (50 m), DirectedTauntAnimations = BP_PlayerAnimation_Taunt1 (12 frames, 1.70 s,
--   foley PlayerTauntPoint), UndirectedTauntAnimations = BP_PlayerAnimation_Taunt2 (13 frames, 1.73 s, foley
--   PlayerTauntKnuckles), DirectedTauntSound / UndirectedTauntSound -> BP_AudioAssetManager_2 SFX_PlayerTaunts_ ->
--   Placeholder_Tuant_Directed / _Undirected cues (VolumeMultiplier 0.65, SoundClass VOTaunts volume 1.25).
-- The cues are a tree of SoundNodeRandom nodes (3 equal groups, then equal lines). bRandomizeWithoutReplacement is never
-- serialized anywhere in the pak (all 335 SoundNodeRandom exports leave it out), so every node keeps the engine default.
-- That default is true in UE4 SoundNodeRandom's constructor (engine source, not provable from the pak): each node deals
-- its children like a shuffled deck and starts over once all have played. That is reproduced in pick() below.
-- PlayerTauntConcurrency is MaxCount 1 / PreventNew and the exe names EndTaunt / TauntSoundEnded, so a new taunt is refused
-- while the voice line still plays.
--
-- Boltgun 2 sets (canoness_bg2, malum_bg2; bake_taunts_bg2.py, rip read with a Dumper-7 usmap): frames rebuilt from the
-- sprite atlases (SpriteUVControlTex / SpriteBoundsControlTex), lines = the <Who>TauntDataTable GenericDirect /
-- GenericIndirect rows with their MetaSound waves and subtitles. Boltgun 2 picks rows in native code, so there each press
-- is one equal-chance pick, no repeats until all lines have played.
--
-- NOT from the game data (native C++ we cannot read): which taunt is "directed". Here it is directed when an enemy is
-- under the crosshair within TauntRange. Also the sprite's screen size: the taunt animations use the native default
-- TextureSize on the render plane, so the default layout (full screen width, bottom edge) is a guess with settings.
--
-- Local only: other players see and hear nothing. Contains ripped Boltgun art and audio: never share
-- (Datavault decision-ripped-assets-stay-local).

local SCRIPTS = "QIangIQsTaunts/scripts/mods/QIangIQsTaunts/"
local Assets = mod:io_dofile(SCRIPTS .. "QIangIQsTaunts_assets")
local Audio = mod:io_dofile(SCRIPTS .. "QIangIQsTaunts_audio")

local persist = mod:persistent_table("runtime")

Assets.setup(persist, function(line)
    mod:info("%s", line)
end)
Audio.setup(persist, function(line)
    mod:info("%s", line)
end)

-- voice gain per set = the cue's VolumeMultiplier (voice.volume) x the sound class volume (voice_class_volume):
-- Boltgun 1 0.65 x VOTaunts 1.25; Boltgun 2 sets carry SCL_VO_Taunts_Nyra 0.8 / SCL_VO_Taunts_Malum 1.5 in voice.volume

-- Taunt sets ----------------------------------------------------------------------------------------------------------
local sets = {}

local function get_set(id)
    if sets[id] == nil then
        local ok, data = pcall(mod.io_dofile, mod, SCRIPTS .. "sets/" .. id)

        sets[id] = ok and type(data) == "table" and data or false
    end

    return sets[id] or nil
end

-- Shuffle-bag random, as UE4 SoundNodeRandom with bRandomizeWithoutReplacement: pick by weight among the children not
-- used yet; once every child has been used, all are available again.
local bags = {}

local function pick(node, key)
    if node.line then
        return node.line
    end

    -- the node that joins the two games' Malum trees picks by weight (line counts) every time, without a bag
    if node.with_replacement then
        local total = 0

        for i = 1, #node.random do
            total = total + node.weights[i]
        end

        local r = math.random() * total

        for i = 1, #node.random do
            r = r - node.weights[i]

            if r <= 0 or i == #node.random then
                return pick(node.random[i], key .. "." .. i)
            end
        end
    end

    local used = bags[key]

    if not used then
        used = {}
        bags[key] = used
    end

    local n = #node.random
    local count = 0

    for i = 1, n do
        if used[i] then
            count = count + 1
        end
    end

    if count >= n then
        table.clear(used)
    end

    local total = 0

    for i = 1, n do
        if not used[i] then
            total = total + (node.weights[i] or 1)
        end
    end

    local r = math.random() * total
    local chosen = n

    for i = 1, n do
        if not used[i] then
            r = r - (node.weights[i] or 1)

            if r <= 0 then
                chosen = i
                break
            end
        end
    end

    used[chosen] = true

    return pick(node.random[chosen], key .. "." .. chosen)
end

-- Directed or not -----------------------------------------------------------------------------------------------------
local function camera_pose()
    local ok, rotation, position = pcall(function()
        local camera = Managers.state and Managers.state.camera
        local player = Managers.player and Managers.player:local_player_safe(1)
        local viewport = player and player.viewport_name

        if not camera or not viewport then
            return nil
        end

        return camera:camera_rotation(viewport), camera:camera_position(viewport)
    end)

    if ok and rotation and position then
        return rotation, position
    end
end

-- an enemy under the crosshair within range_m (closest hit on the shooting filter, as the player's own shots see it)
local function enemy_in_sight(range_m)
    local ok, result = pcall(function()
        local player = Managers.player:local_player_safe(1)
        local player_unit = player and player.player_unit
        local rotation, position = camera_pose()

        if not player_unit or not rotation then
            return false
        end

        local world = Managers.world:world("level_world")
        local physics_world = World.physics_world(world)
        -- result rows: [1] position, [4] actor (sound_reflection.lua INDEX_POSITION / INDEX_ACTOR)
        local results, num_hits = PhysicsWorld.raycast(physics_world, position, Quaternion.forward(rotation), range_m, "all", "types",
            "both", "collision_filter", "filter_player_character_shooting_raycast")

        if not results or not num_hits or num_hits == 0 then
            return false
        end

        local hits = {}

        for i = 1, num_hits do
            hits[i] = { d = Vector3.distance(results[i][1], position), actor = results[i][4] }
        end

        table.sort(hits, function(a, b)
            return a.d < b.d
        end)

        local side_system = Managers.state.extension:system("side_system")

        for i = 1, #hits do
            local actor = hits[i].actor
            local unit = actor and Actor.unit(actor)

            if unit and unit ~= player_unit then
                if side_system:is_enemy(player_unit, unit) then
                    return true
                end

                -- the first thing that is not the player or an enemy blocks the view
                if not ScriptUnit.has_extension(unit, "health_system") then
                    return false
                end
            end
        end

        return false
    end)

    return ok and result or false
end

-- Playback ------------------------------------------------------------------------------------------------------------
local S = {
    playing = nil, -- { set, kind, t0, frames, total }
    voice_id = nil,
    text = nil,
}

local function now()
    return Managers.time and Managers.time:time("main") or os.clock()
end

-- Characters: "malum" joins Malum Caedo from both games (Boltgun 1 tree and Boltgun 2 lines side by side, chosen by line
-- count, so every line is about as likely); "canoness" is the Boltgun 2 Sister of Battle (Nyra). Each line keeps the game
-- it came from (src), its own gain and, for Boltgun 2 rows, the animation the row names.
local KINDS = { "directed", "undirected" }
local CHARACTER_SETS = { malum = { "malum_bg1", "malum_bg2" }, canoness = { "canoness_bg2" } }
local characters = {}

local function offset_tree(node, add)
    if node.line then
        return { line = node.line + add }
    end

    local out = { random = {}, weights = node.weights, with_replacement = node.with_replacement }

    for i, child in ipairs(node.random) do
        out.random[i] = offset_tree(child, add)
    end

    return out
end

local function get_character(id)
    if characters[id] ~= nil then
        return characters[id] or nil
    end

    local parts = {}

    for _, set_id in ipairs(CHARACTER_SETS[id] or {}) do
        local set = get_set(set_id)

        if set then
            parts[#parts + 1] = { id = set_id, set = set }
        end
    end

    if #parts == 0 then
        characters[id] = false

        return nil
    end

    local c = { id = id, parts = parts, taunt_range_m = parts[1].set.taunt_range_m }

    for _, kind in ipairs(KINDS) do
        local lines, trees, weights = {}, {}, {}

        for _, part in ipairs(parts) do
            local voice = part.set[kind].voice
            local gain = (voice.volume or 1) * (part.set.voice_class_volume or 1)

            trees[#trees + 1] = offset_tree(voice.tree, #lines)
            weights[#weights + 1] = #voice.lines

            for _, line in ipairs(voice.lines) do
                lines[#lines + 1] = { file = line.file, text = line.text, anim = line.anim, src = part.id, gain = gain }
            end
        end

        c[kind] = { lines = lines, tree = #trees == 1 and trees[1] or { random = trees, weights = weights, with_replacement = true } }
    end

    characters[id] = c

    return c
end

local function class_name()
    local player = Managers.player and Managers.player:local_player_safe(1)
    local ok, name = pcall(function()
        return player:profile().archetype.name
    end)

    return ok and name or "veteran"
end

-- the sprite (frames + foley) for a line: the line's own game when the sprite and voice are the same character
local function sprite_for(sprite_char, kind, line, voice_id, one_arm)
    if not sprite_char then
        return nil
    end

    local part = sprite_char.parts[1]

    if line and sprite_char.id == voice_id then
        for _, p in ipairs(sprite_char.parts) do
            if p.id == line.src then
                part = p
            end
        end
    end

    -- a melee weapon stays in the right hand: only an animation with the left arm alone can play. Malum's directed taunt
    -- is one arm in both games; the Sister's two-arm taunt has a baked left-arm cut (one_arm)
    if one_arm then
        return part.set.one_arm or part.set.directed, part.set
    end

    local anim_kind = line and sprite_char.id == voice_id and line.anim or kind

    return part.set[anim_kind], part.set
end

-- Ranged sprite weapons drawn with one hand (user, 2026-11-04: do not remove them; idle poses checked on a sheet of every
-- rig, boltgun_rip\scripts\mmj_idle_sheet.py). Template -> the mod that draws it; only counts while that mod shows it.
-- The two-handed or handless rigs (MMJ Rifle, Minigun, Plasma Gun, Rail Gun, Sniper; Boltgun Bolter, Flamer) are not listed.
local ONE_HANDED_SPRITES = {
    needlepistol_p1_m1 = "QIangIQsMMJArcadePistol", needlepistol_p1_m2 = "QIangIQsMMJArcadePistol", needlepistol_p1_m3 = "QIangIQsMMJArcadePistol",
    boltpistol_p1_m1 = "QIangIQsMMJChainPistol", boltpistol_p1_m2 = "QIangIQsMMJChainPistol",
    shotgun_p2_m1 = "QIangIQsMMJDoubleBarrel", shotgun_p2_m3 = "QIangIQsMMJDoubleBarrel",
    forcestaff_p2_m1 = "QIangIQsMMJMagicGlove",
    stubrevolver_p1_m1 = "QIangIQsMMJPistol", stubrevolver_p1_m2 = "QIangIQsMMJPistol",
    shotgun_p1_m1 = "QIangIQsMMJShotgun", shotgun_p1_m2 = "QIangIQsMMJShotgun", shotgun_p1_m3 = "QIangIQsMMJShotgun",
    lasgun_p3_m1 = "QIangIQsMMJSilencedUzi", lasgun_p3_m2 = "QIangIQsMMJSilencedUzi", lasgun_p3_m3 = "QIangIQsMMJSilencedUzi",
    autopistol_p1_m1 = "QIangIQsMMJUzi",
    laspistol_p1_m1 = "QIangIQsFingerGun", laspistol_p1_m3 = "QIangIQsFingerGun",
    plasmagun_p1_m1 = "QIangIQsBoltgunPlasmaPistol", plasmagun_p1_m2 = "QIangIQsBoltgunPlasmaPistol",
}

local function one_handed_sprite(item)
    local template = item and item.weapon_template
    local owner = template and ONE_HANDED_SPRITES[template]
    local other = owner and get_mod(owner)

    return other and other:is_enabled() and other:get("replace_" .. template) ~= false or false
end

-- a free left arm: melee keyword of the wielded weapon's template (weapon_templates/*: every melee template lists "melee";
-- the game has no one-handed / two-handed flag, and both are treated the same), or a one-handed sprite weapon
local function melee_wielded()
    local ok, result = pcall(function()
        local player = Managers.player:local_player_safe(1)
        local unit = player.player_unit
        local inventory = ScriptUnit.extension(unit, "unit_data_system"):read_component("inventory")
        local template, slot = ScriptUnit.extension(unit, "visual_loadout_system"):weapon_template_from_slot(inventory.wielded_slot)

        if one_handed_sprite(slot and slot.item) then
            return true
        end

        for _, keyword in ipairs(template and template.keywords or {}) do
            if keyword == "melee" then
                return true
            end
        end

        return false
    end)

    return ok and result or false
end

local function play(kind_override)
    if S.voice_id and Audio.is_playing(S.voice_id) then
        return false, "voice line still playing"
    end

    local class = class_name()
    local sprite_id, voice_id = mod:get("sprite_" .. class), mod:get("voice_" .. class)
    local sprite_char = sprite_id ~= "none" and get_character(sprite_id) or nil
    local voice_char = voice_id ~= "none" and get_character(voice_id) or nil

    if not sprite_char and not voice_char then
        return false, "nothing chosen for " .. tostring(class)
    end

    local kind = kind_override

    if not kind then
        local mode = mod:get("mode")

        if mode == "auto" then
            kind = enemy_in_sight((voice_char or sprite_char).taunt_range_m) and "directed" or "undirected"
        else
            kind = mode
        end
    end

    local line = voice_char and voice_char[kind].lines[pick(voice_char[kind].tree, voice_id .. "." .. kind)]
    local one_arm = mod:get("one_arm_melee") and melee_wielded() or false
    local anim, sprite_set = sprite_for(sprite_char, kind, line, voice_id, one_arm)
    local volume = mod:get("volume")

    if anim then
        local total = 0

        for _, f in ipairs(anim.frames) do
            total = total + f.t
            Assets.texture(f.tex)
        end

        S.playing = { kind = kind, t0 = now(), frames = anim.frames, total = total, aspect = sprite_set.aspect or 2, one_arm = one_arm }
        -- read by QIangIQsMMJHud (phone, always off during a taunt) and the MMJ weapon sprite mods (off unless one-armed)
        rawset(_G, "__qiangiq_taunt_active", true)
        rawset(_G, "__qiangiq_taunt_hide_weapon", not one_arm)
        Audio.play(anim.foley, volume * (sprite_set.foley_gain or 1))
    end

    if line then
        S.voice_id = Audio.play(line.file, volume * line.gain)
        S.text = line.text
    end

    return true, kind .. " (" .. tostring(class) .. ")"
end

mod.taunt = function()
    local player = Managers.player and Managers.player:local_player_safe(1)

    if not (player and player.player_unit and ALIVE[player.player_unit]) then
        return
    end

    play()
end

-- warm the textures of the current class's sprite character so the first taunt does not blink
local function warm()
    local sprite_id = mod:get("sprite_" .. class_name())
    local c = sprite_id ~= "none" and get_character(sprite_id)

    if c then
        for _, part in ipairs(c.parts) do
            for _, kind in ipairs(KINDS) do
                for _, f in ipairs(part.set[kind].frames) do
                    Assets.texture(f.tex)
                end
            end

            for _, f in ipairs(part.set.one_arm and part.set.one_arm.frames or {}) do
                Assets.texture(f.tex)
            end
        end
    end

    Audio.warm()
end

-- Hiding the first-person weapon and arms ------------------------------------------------------------------------------
-- The taunt animations leave bUsePrimaryRenderPlane at the BGPlayerAnimation default; the grenade throws (same parent
-- class, SuperStruct BGPlayerAnimation) serialize it as false, so the default is true: the taunt is drawn on the weapon's
-- own plane, in place of the weapon. Here every first-person unit of the local player's equipment (weapons, slot_body*
-- / slot_gear* arms, QIangIQs model arms) is hidden while the frames play, then the game restores visibility
-- (QIangIQsFingerGun hide / show_hidden pattern, force_update_item_visibility as in QIangIQsEmotes end_dance).
local hidden = setmetatable({}, { __mode = "k" })
local local_ext = setmetatable({}, { __mode = "k" })
local busy = false

local function unit_ok(unit)
    return unit and type(unit) == "userdata" and Unit.alive(unit)
end

local function hide(ext, unit)
    if unit_ok(unit) then
        local mine = hidden[ext] or {}

        hidden[ext] = mine
        mine[unit] = true
        Unit.set_unit_visibility(unit, false, true)
    end
end

local function hide_first_person(ext)
    for _, slot in pairs(ext._equipment or {}) do
        if type(slot) == "table" then
            hide(ext, slot.unit_1p)

            for unit in pairs(slot.item_name_by_unit_1p or {}) do
                hide(ext, unit)
            end
        end
    end

    for key, value in pairs(ext) do
        if type(key) == "string" then
            if key:find("^__qiangiq_.+_arms$") and not key:find("_part_arms$") then
                hide(ext, value)
            elseif key:find("^__qiangiq_.+_part_arms$") and type(value) == "table" then
                for _, part in pairs(value) do
                    hide(ext, part)
                end
            end
        end
    end
end

local function show_hidden(ext)
    if not hidden[ext] then
        return
    end

    hidden[ext] = nil

    if ext.force_update_item_visibility then
        pcall(ext.force_update_item_visibility, ext)
    end
end

local function sync_visibility(ext)
    if busy then
        return
    end

    busy = true

    local ok, err = pcall(function()
        -- ends a finished taunt even when the HUD element is not drawing (frame() clears S.playing and the flag)
        if S.playing then
            mod.taunts.frame()
        end

        if S.playing and not S.playing.one_arm and mod:get("hide_weapon") then
            hide_first_person(ext)
        else
            show_hidden(ext)
        end
    end)

    busy = false

    if not ok then
        mod:info("visibility: %s", tostring(err))
    end
end

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "init", function(self)
    if self._is_local_unit then
        local_ext[self] = true
        -- warm here, once the backend is up: loads asked for at mod load fail with "Backend not initialized"
        pcall(warm)
    end
end)

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "update", function(self)
    if self._is_local_unit then
        local_ext[self] = true
        sync_visibility(self)
    end
end)

-- the game sets item visibility again here (wield, swap): hide again at once
mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "_update_item_visibility", function(self)
    if self._is_local_unit then
        sync_visibility(self)
    end
end)

mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, "destroy", function(func, self, ...)
    local_ext[self] = nil
    hidden[self] = nil

    return func(self, ...)
end)

-- Darktide's left arm while a one-armed taunt plays. The 1P arms are one mesh, so the arm is shrunk from its bone right
-- after the animations are evaluated and before the scene graph runs (QIangIQsMMJHud mmjhud_phone.lua apply_arm); the hand
-- and anything held in it go too (a shield, the second hand on a two-handed weapon).
local LEFT_ARM_NODES = { "j_leftarm", "j_leftforearm", "j_lefthand" }
local TINY = 0.0001
local arm = {}

local function restore_left_arm()
    if arm.unit and arm.scale and Unit.alive(arm.unit) then
        Unit.set_local_scale(arm.unit, arm.node, arm.scale:unbox())
    end

    arm.unit, arm.node, arm.scale = nil, nil, nil
end

local function update_left_arm(world)
    if not (S.playing and S.playing.one_arm) then
        if arm.unit then
            restore_left_arm()
        end

        return
    end

    if not arm.unit then
        local player = Managers.player:local_player_safe(1)
        local extension = player and player.player_unit and ScriptUnit.has_extension(player.player_unit, "first_person_system")
        local unit = extension and extension:first_person_unit()

        if not (unit and Unit.alive(unit) and Unit.world(unit) == world) then
            return
        end

        for _, name in ipairs(LEFT_ARM_NODES) do
            if Unit.has_node(unit, name) then
                arm.unit, arm.node = unit, Unit.node(unit, name)
                arm.scale = Vector3Box(Unit.local_scale(unit, arm.node))

                break
            end
        end

        if not arm.unit then
            return
        end
    end

    if Unit.alive(arm.unit) and Unit.world(arm.unit) == world then
        Unit.set_local_scale(arm.unit, arm.node, Vector3(TINY, TINY, TINY))
    end
end

local arm_errors = 0

mod:hook_safe(World, "update_animations", function(world)
    if arm_errors > 5 then
        return
    end

    local ok, err = pcall(update_left_arm, world)

    if not ok then
        arm_errors = arm_errors + 1
        mod:info("left arm: %s", tostring(err))
    end
end)

local function reset_all()
    S.playing = nil
    rawset(_G, "__qiangiq_taunt_active", nil)
    rawset(_G, "__qiangiq_taunt_hide_weapon", nil)

    for ext in pairs(local_ext) do
        pcall(show_hidden, ext)
    end

    pcall(restore_left_arm)
end

mod.on_disabled = reset_all

-- HUD API: the frame to draw now and the subtitle -----------------------------------------------------------------------
mod.taunts = {
    frame = function()
        local p = S.playing

        if not p then
            return nil
        end

        local t = now() - p.t0

        if t >= p.total then
            S.playing = nil
            rawset(_G, "__qiangiq_taunt_active", nil)
            rawset(_G, "__qiangiq_taunt_hide_weapon", nil)

            return nil
        end

        local acc = 0

        for _, f in ipairs(p.frames) do
            acc = acc + f.t

            if t < acc then
                return Assets.texture(f.tex)
            end
        end
    end,
    subtitle = function()
        if not mod:get("subtitles") or not S.text then
            return nil
        end

        if S.voice_id and Audio.is_playing(S.voice_id) or S.playing then
            return S.text
        end

        S.text = nil
    end,
    layout = function()
        local p = S.playing

        return mod:get("size") / 100, mod:get("offset_x") / 100, mod:get("offset_y") / 100, p and p.aspect or 2
    end,
}

mod:register_hud_element({
    class_name = "HudElementQIangIQsTaunts",
    filename = SCRIPTS .. "hud_element_taunts",
    use_hud_scale = false,
    visibility_groups = { "alive" },
})

mod.on_setting_changed = function(setting_id)
    if setting_id:find("^sprite_") then
        warm()
    end
end



mod:command("taunts", mod:localize("command_desc"), function(arg, kind)
    if arg == "play" then
        local ok, info = play(kind == "directed" and "directed" or kind == "undirected" and "undirected" or nil)

        mod:echo("Taunts: %s (%s)", ok and "playing" or "not played", tostring(info))

        return
    end

    local class = class_name()
    local sprite_id, voice_id = mod:get("sprite_" .. class), mod:get("voice_" .. class)
    local c = sprite_id ~= "none" and get_character(sprite_id)
    local loaded, total = 0, 0

    if c then
        for _, part in ipairs(c.parts) do
            for _, k in ipairs(KINDS) do
                for _, f in ipairs(part.set[k].frames) do
                    total = total + 1

                    local tex = Assets.texture(f.tex)

                    if tex and tex.texture then
                        loaded = loaded + 1
                    end
                end
            end
        end
    end

    mod:echo("Taunts: class %s, sprite %s, voice %s, frames loaded %d/%d, enemy in sight %s, assets runtime %s, audio runtime %s",
        tostring(class), tostring(sprite_id), tostring(voice_id), loaded, total, tostring(enemy_in_sight(50)),
        persist.assets_rt and "ok" or tostring(persist.assets_failed), persist.audio_rt and "ok" or tostring(persist.audio_failed))
end)
