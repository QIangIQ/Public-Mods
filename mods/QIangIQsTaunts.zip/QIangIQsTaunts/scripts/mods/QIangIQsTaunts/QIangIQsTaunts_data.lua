local mod = get_mod("QIangIQsTaunts")

-- one sprite and one voice choice per Darktide class (archetype names from scripts/settings/archetype/archetypes)
local CLASSES = { "veteran", "zealot", "psyker", "ogryn", "adamant", "broker", "cryptic" }
local CHOICES = {
    { text = "character_malum", value = "malum" },
    { text = "character_canoness", value = "canoness" },
    { text = "character_none", value = "none" },
}
local class_widgets = {}

for _, class in ipairs(CLASSES) do
    class_widgets[#class_widgets + 1] = { setting_id = "sprite_" .. class, type = "dropdown", default_value = "malum", options = table.clone(CHOICES) }
    class_widgets[#class_widgets + 1] = { setting_id = "voice_" .. class, type = "dropdown", default_value = "malum", options = table.clone(CHOICES) }
end

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = true,
    options = {
        widgets = {
            {
                setting_id = "taunt_key",
                type = "keybind",
                default_value = { "t" },
                keybind_trigger = "pressed",
                keybind_type = "function_call",
                function_name = "taunt",
            },            {
                setting_id = "taunt_key_2",
                type = "keybind",
                default_value = {},
                keybind_trigger = "pressed",
                keybind_type = "function_call",
                function_name = "taunt",
            },
            {
                setting_id = "taunt_key_3",
                type = "keybind",
                default_value = {},
                keybind_trigger = "pressed",
                keybind_type = "function_call",
                function_name = "taunt",
            },

            {
                setting_id = "classes",
                type = "group",
                sub_widgets = class_widgets,
            },
            {
                setting_id = "mode",
                type = "dropdown",
                default_value = "auto",
                options = {
                    { text = "mode_auto", value = "auto" },
                    { text = "mode_directed", value = "directed" },
                    { text = "mode_undirected", value = "undirected" },
                },
            },
            { setting_id = "one_arm_melee", type = "checkbox", default_value = true },
            { setting_id = "hide_weapon", type = "checkbox", default_value = true },
            { setting_id = "subtitles", type = "checkbox", default_value = true },
            { setting_id = "volume", type = "numeric", default_value = 150, range = { 0, 500 }, decimals_number = 0 },
            {
                setting_id = "layout",
                type = "group",
                sub_widgets = {
                    { setting_id = "size", type = "numeric", default_value = 150, range = { 30, 400 }, decimals_number = 0 },
                    { setting_id = "offset_x", type = "numeric", default_value = 0, range = { -100, 100 }, decimals_number = 1 },
                    { setting_id = "offset_y", type = "numeric", default_value = 0, range = { -100, 100 }, decimals_number = 1 },
                },
            },
        },
    },
}
