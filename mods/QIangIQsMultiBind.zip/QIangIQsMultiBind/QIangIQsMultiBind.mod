return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsMultiBind` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsMultiBind", {
			mod_script       = "QIangIQsMultiBind/scripts/mods/QIangIQsMultiBind/QIangIQsMultiBind",
			mod_data         = "QIangIQsMultiBind/scripts/mods/QIangIQsMultiBind/QIangIQsMultiBind_data",
			mod_localization = "QIangIQsMultiBind/scripts/mods/QIangIQsMultiBind/QIangIQsMultiBind_localization",
		})
	end,
	version = "1.0.0",
	author = "QIangIQ (original MultiBind by Seph)",
	packages = {},
}
