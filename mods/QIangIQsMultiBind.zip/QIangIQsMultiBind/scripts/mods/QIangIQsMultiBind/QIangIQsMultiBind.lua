--[[
┌───────────────────────────────────────────────────────────────────────────────────────────┐
│ Mod Name: QIangIQ's Multi Bind                                                            │
│ Mod Description: Allows up to 4 additional bindings for all actions.                      │
│ Mod Author: Seph (Steam: Concoction of Constitution)                                      │
│ Modified by: QIangIQ (renamed, 4 additional binds per action instead of 1)                │
└───────────────────────────────────────────────────────────────────────────────────────────┘
--]]

local mod = get_mod("QIangIQsMultiBind")

mod.AUTHOR = "QIangIQ"

local aliases = {
    action_one = {false, false},
    action_two = {false, false},
    weapon_extra = {false, false},
    interact = {false, false},
    interact_inspect = {false, false},
    wield_1 = {false, false},
    wield_2 = {false, false},
    wield_3 = {false, false},
    wield_4 = {false, false},
    wield_5 = {false, false},
    quick_wield = {false, false},
    wield_scroll_down = {false, false},
    wield_scroll_up = {false, false},
    weapon_reload = {false, false},
    grenade_ability = {false, false},
    combat_ability = {false, false},
    smart_tag = {false, false},
    com_wheel = {false, false},
    tactical_overlay = {false, false},
    weapon_inspect = {false, false},
    spectate_next = {false, false},
    voip_push_to_talk = {false, false},
    hotkey_inventory = {false, false},
    show_chat = {false, false},
    keyboard_move_forward = {false, false},
    keyboard_move_backward = {false, false},
    keyboard_move_left = {false, false},
    keyboard_move_right = {false, false},
    dodge = {false, false},
    jump = {false, false},
    crouch = {false, false},
    sprint = {false, false}
}


local enabled = true
local z
mod:hook("InputService", "_get", function(f, s, action_name)
    local a = s._actions[action_name]
    if a.key_alias == "keyboard_move_forward" and a.filter == true then mod:echo(a.filter) end
    if enabled and aliases[a.key_alias] then
        if a.filter == true then
            if aliases[a.eval_obj.input_mappings.button_2][1] == true then return 1 end
        elseif a.key_alias ~= "keyboard_move_forward" and a.key_alias ~= "keyboard_move_backward" and a.key_alias ~= "keyboard_move_left" and a.key_alias ~= "keyboard_move_right" then
            if aliases[a.key_alias][1] == true and a.type ~= "released" and a.type ~= "pressed" then 
                return true
            elseif a.type == "pressed" and aliases[a.key_alias][2] == true then
                aliases[a.key_alias][2] = false
                return true
            end
        elseif aliases[a.key_alias][1] == true then
            return 1
        end
    end

    return f(s, action_name)
end)





-- Up to MAX_BINDS additional binds per action. Bind 1 keeps the original setting / function name
-- (e.g. "action_one"), binds 2-4 are "<action>_2" .. "<action>_4". Each keybind is a DMF "held"
-- function_call, so its function receives true on press and false on release (as in the original).
-- An action counts as held while any of its binds is held; a press of any bind queues one "pressed".
local MAX_BINDS = 4
local held = {}

for name, state in pairs(aliases) do
    held[name] = {}
    for n = 1, MAX_BINDS do
        local function_name = n == 1 and name or name .. "_" .. n
        mod[function_name] = function(e)
            local binds = held[name]
            binds[n] = e and true or false
            local any = false
            for i = 1, MAX_BINDS do
                any = any or binds[i] == true
            end
            state[1] = any
            if e then
                state[2] = true
            elseif not any then
                state[2] = false
            end
        end
    end
end



-- Unassign bindings
mod:hook("InputAliases", "set_keys_for_alias", function(f, s, name, device_types, new_key_info, device_index)
    if (new_key_info and new_key_info.main == "keyboard_delete") then new_key_info.main = "keybind_unassigned" end
    return f(s, name, device_types, new_key_info, device_index)
end)
