return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsCrossbow` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsCrossbow", {
            mod_script = "QIangIQsCrossbow/scripts/mods/QIangIQsCrossbow/QIangIQsCrossbow",
            mod_data = "QIangIQsCrossbow/scripts/mods/QIangIQsCrossbow/QIangIQsCrossbow_data",
            mod_localization = "QIangIQsCrossbow/scripts/mods/QIangIQsCrossbow/QIangIQsCrossbow_localization",
        })
    end,
    version = "0.5.0",
    author = "QIangIQ",
    packages = {},
}
