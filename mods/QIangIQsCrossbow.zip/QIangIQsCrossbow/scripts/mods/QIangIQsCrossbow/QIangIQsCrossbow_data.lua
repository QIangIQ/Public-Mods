local mod = get_mod("QIangIQsCrossbow")

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = false,
    options = {
        widgets = {
            { setting_id = "drawn_hud_icon", type = "checkbox", default_value = true },
            { setting_id = "add_to_unlock_list", type = "checkbox", default_value = true },
            { setting_id = "unlock_level", type = "numeric", default_value = 1, range = { 1, 30 }, decimals_number = 0 },
            { setting_id = "stagger_resistance_modifier", type = "numeric", default_value = 0.01, range = { 0.001, 1 }, decimals_number = 3 },
            { setting_id = "native_animations", type = "checkbox", default_value = true },
            { setting_id = "reload_time", type = "numeric", default_value = 6.5, range = { 3, 12 }, decimals_number = 1 },
            { setting_id = "ragdoll_push_force", type = "numeric", default_value = 2500, range = { 600, 8000 }, decimals_number = 0 },
        },
    },
}

