-- QIangIQ's Crossbow 0.5.0: the datamined Crossbow as a Zealot weapon (split off QIangIQsDauntlessArmory 0.4.2).
--
-- What is datamined (A:\Dowloads\Darktide_NonMod\dauntless_datamine, INDEX.md, Oct 11 2026 build):
--   * Retail units with their own packages (all_resources.json exts = package + unit):
--       content/weapons/player/ranged/crossbow/wpn_crossbow_chained_rig (its strings name the item
--       "content/items/weapons/player/ranged/crossbow_p1_m1"), crossbow attachments receiver/barrel/magazine/grip_01
--       and underbarrel_01 (name recovered by hash), flamer_pistol attachments receiver/barrel/magazine/grip_01.
--   * Node names (recovered by id32 match, _scratch_xbow\nodes.txt): crossbow receiver has ap_barrel_01, ap_magazine_01,
--     ap_grip_01, ap_underbarrel_01; flamer pistol receiver has ap_barrel_01, ap_magazine_01, ap_grip_01; the flamer
--     pistol barrel has fx_muzzle_02 + fx_pilot.
--   * NOT datamined: weapon templates, stats, actions, animations, item master data. None exist in the build.
--
-- So behaviour is borrowed from a released weapon, chosen by the fx nodes the models carry:
--   * Crossbow rig fx nodes = fx_eject, fx_muzzle_01, fx_muzzle_02 = exactly bolter_p1_m1's fx_sources
--     (bolter_p1_m1.lua). Rig node overlap with the bolt_gun rig is 0.54 (_scratch_xbow\rigs.txt).
--   * Flamer pistol barrel fx nodes = fx_muzzle_02, fx_pilot = exactly flamer_p1_m1's fx_sources (flamer_p1_m1.lua:643).
--     There is no flamer pistol rig in the bundles, so the flamer's own rig stays as the base unit.
--
-- New weapon pattern = QIangIQsShardStaff (note weapons/78, seen working in game):
--   template clone into WeaponTemplates + NetworkLookup append + particle/sound alias copy; item clone into
--   MasterItems.get_cached() (extended_weapon_customization kitbash.lua); equip by override_slot
--   (training_grounds_steps.lua:341-347). Attachment items follow the full-item kitbash shape
--   (extended_weapon_customization_more_dakka kitbashs: base_unit, attach_node, resource_dependencies).
--   Attachment spawning: visual_loadout_customization.lua _attach_hierarchy / _spawn_attachment (item "" = nothing,
--   attach_node looked up on the parent unit). Packages: item_package.lua _resolve_item_packages_recursive.
--
-- 0.2.0 (after the first in-game test):
--   * Static receiver. _spawn_attachment links every attachment with World.LINK_MODE_NODE_NAME unless the slot sets
--     link_map_mode_override (World[...]), so the crossbow receiver's ap_magazine_01 followed the rig's ap_magazine_01,
--     which the borrowed bolter animation moves to the boltgun's magazine spot: the clip hung below the stock.
--     The receiver slot now uses link_map_mode_override = "LINK_MODE_NONE" (World.LINK_MODE_NONE is used in the same
--     function) and every part sits under the receiver, so the clip stays where the models place it (its ap_bullet_01
--     lands exactly on the receiver's ap_bullet_01). Same for the flamer pistol.
--   * Flamer pistol overlay: laspistol_p1_m1's state machines, reload template and rig (laspistol_p1_m1.lua:879-881,
--     the laspistol master item's base_unit). Flamer anim events with a laspistol counterpart in the same role are
--     swapped to it; any event the lasgun_pistol state machine still lacks is skipped (Unit.has_animation_event, as
--     player_character_state_ledge_vaulting.lua:109 does) instead of reaching Unit.animation_event
--     (player_unit_animation_extension.lua anim_event*, unguarded).
--
-- 0.3.0 (after the second in-game test):
--   * Laspistol crash fix: "AnimationStateMachine ... lasgun_pistol does not exist" (player_unit_animation_state.lua:154).
--     Items only load what resource_dependencies lists (item_package.lua compile_item_instance_dependencies), and the
--     offline compile puts the template's resources there via WeaponTemplateResourceDependencies.generate
--     (item_package.lua:239-249). Both items now get that list for their own template.
--   * Crossbow = boltpistol_p1_m1 (one-handed; its fx_sources fx_eject/fx_muzzle_01/fx_muzzle_02 are crossbow rig nodes).
--   * Bolts are real projectiles at voidstrike speed: both shoot actions become kind "shoot_projectile" with the
--     fire_configuration shape of ogryn_thumper_p1_m2 / missile_launcher (inventory_item_name, skip_aiming, projectile,
--     shotshell). Projectile template = force_staff_ball (forcestaff_p1_m1 rapid_left), whose locomotion
--     (initial_speed 60, gravity 0) gets the thumper's "shoot" trajectory block at speed 60 and rotate_towards_direction;
--     damage = the bolt pistol hitscan's impact profile and damage_type. The flying bolt is the clip's top bolt
--     (Custom/crossbow_bolt, from magazine_01 mesh11); until that asset is loaded the projectile keeps the voidstrike look.
--   * Clip shows the bolts left: Custom/crossbow_clip (magazine_01 frame meshes) + 18 crossbow_bolt units at the clip's
--     own bolt spacing (centres z 0.2164 down to -0.0563, 0.016035 apart), linked to the magazine attachment the way
--     QIangIQsShardStaff links its model; Ammo.current_slot_clip_amount / max_slot_clip_amount (ammo.lua:139/160).
--
-- 0.4.0 (user asks after 0.3.2):
--   * Grip: the hand holds the rig root where the donor's trigger sits (bolt_pistol rig ap_trigger_01 = 0,0,0; lasgun_pistol
--     rig ap_trigger_01 = 0,-0.0073,0.0168; every pistol rig's ap_trigger_01 equals its receiver's, _scratch_xbow\grips.txt).
--     Crossbow receiver ap_trigger_01 = 0,-0.1258,-0.0075 (hand ended up in the magwell), flamer pistol receiver
--     ap_trigger_01 = 0,0.063,0.0636. The static receiver's root is shifted by the difference
--     (Unit.set_local_position(unit, 1, ...) on a linked unit, as QIangIQsAWP.lua:282 does).
--   * Clip feeds upward: the bolts left sit at the top positions.
--   * Recoil: SteadyHands' PlayerUnitWeaponRecoilExtension _update_offset hook (mods/SteadyHands), "minimal" preset,
--     applied only while the crossbow is wielded.
--   * Audio (2026-10-30): the game's own play_crossbow_p1_* events by default (CROSSBOW_SOUNDS below). Optional legacy:
--     synthesised crossbow_shot.wav / crossbow_cock.wav (_build/make_audio.py) played through SimpleAudio the way
--     QIangIQsAWP_cs2audio.lua does, replacing the bolt pistol shot in ActionShoot._play_shoot_sound (QIangIQsAWP.lua:715).
--   * Mechanism: the underbarrel's string is skinned to ap_recharge_01 (nock) + ap_anim_05/07 (limb tips, children of the
--     limbs ap_recharge_03/02); those and the latch parts (ap_release_01, ap_anim_01/02/03) and the grip's ap_trigger_01
--     follow the receiver's same-named nodes (LINK_MODE_NODE_NAME), so the receiver nodes are posed per shot
--     (_scratch_xbow\mech.txt). Stroke = nock to limb-tip line, 0.1612. Timings fit the 0.6 s refire chain time.
--
-- 0.4.1 (user asks after 0.4.0):
--   * No jump: the bolt pistol's shoot animation (fire_configuration.anim_event "attack_shoot") is dropped (ActionShoot
--     trigger_anim_event skips nil, action_shoot.lua:1097), and the recoil pitch/yaw offsets are zeroed at the SteadyHands
--     hook point. The only kick left is the receiver sliding straight back into the shoulder for a moment.
--   * Bolt: the riding bolt is scaled 3x (Unit.set_local_scale on node 1, as QIangIQsAWP.lua does) and the projectile gets
--     the frag grenade's trail (player_projectile_templates.lua:40-47 effects.spawn.vfx). Being in the weapon template, the
--     particle goes into the item's resource_dependencies through WeaponTemplateResourceDependencies.generate.
--   * Deeper shot sound (_build/make_audio.py).
--
-- 0.4.2 (user asks after 0.4.1, hipfire still kicked up hard):
--   * No recoil at all: weapon_template.recoil_template / sway_template (and the alternate fire and per-action ones) are
--     cleared, so every action sets recoil_template_name / sway_template_name "none" (action_shoot.lua:208-209,
--     alternate_fire.lua:15-16, player_unit_weapon_extension.lua:720/726) and Recoil.add_recoil returns early (recoil.lua).
--   * 18-round clip: own WeaponAmmoTemplates entry (shape of boltpistol_p1_m1, weapon_ammo_templates.lua:667), wired in
--     through the clone's __base_template_lookup (weapon_tweak_templates.lua _preparse_templates/_build_templates).
--     Reserve keeps the bolt pistol's 8 clips (80/10 -> 144/18).
--   * Reload: the left hand's rig node ap_magazine_01 (bolt pistol reload anim) carries the clip: during action_reload the
--     receiver's ap_magazine_01 follows that node's motion from its idle pose. A fresh, full clip shows once the old
--     rounds are removed (boltpistol reload template remove_ammunition 0.4 s), where crossbow_eject.wav also plays.
--   * Viewmodel lowered 3 cm while the crossbow is wielded: the crossbow's rear top (latch housing z 0.1617 after the grip
--     shift) stood 2.85 cm above the bolt pistol's sight line (ap_sight_01 0.1231 + sight_01 top 0.0101), _scratch_xbow
--     tops.py / zoom2.py. Done the way ViewModelTweaker moves the first person unit (update_unit_position hook).
-- 0.5.0 (split from QIangIQsDauntlessArmory, user: separate mods and the HUD icon):
--   * This mod is the Crossbow only; the Flamer Pistol is QIangIQsFlamerPistol. Item and attachment names are unchanged, so
--     presets that name crossbow_p1_m1 keep working. Custom assets now belong to this mod (ids QIangIQsCrossbow:...).
--   * Bottom-right weapon icon shows the Crossbow, not the Bolt Pistol (see "Bottom-right weapon icon" below).
-- Author: QIangIQ
local mod = get_mod("QIangIQsCrossbow")

local WeaponTemplates = require("scripts/settings/equipment/weapon_templates/weapon_templates")
local MasterItems = require("scripts/backend/master_items")
local NetworkLookup = require("scripts/network_lookup/network_lookup")

local W = "content/weapons/player/ranged/"
local ITEM_ROOT = "content/items/weapons/player/ranged/"

-- Custom assets (compiled from the datamined magazine_01 with DarktideGLBCompiler, loaded through Custom Assets)
local CLIP_ASSET, CLIP_UNIT = "QIangIQsCrossbow:crossbow_clip", "content/mods/qiangiq_dauntless/crossbow_clip"
local BOLT_ASSET, BOLT_UNIT = "QIangIQsCrossbow:crossbow_bolt", "content/mods/qiangiq_dauntless/crossbow_bolt"
local CLIP_BOLTS = 18
local TOP_BOLT_Z = 0.2164
local BOLT_PITCH = 0.016035
local assets_ready = { clip = false, bolt = false }

-- Projectile: voidstrike's projectile item stands in until the bolt model is loaded
local BOLT_ITEM = ITEM_ROOT .. "qiangiq_dauntless/crossbow_bolt_projectile"
local BOLT_ITEM_SOURCE = ITEM_ROOT .. "bullets/force_staff_projectile_01"   -- forcestaff_p1_m1 rapid_left projectile_item
local BOLT_PROJECTILE = "qiangiq_crossbow_bolt"
local BOLT_LOCOMOTION = "qiangiq_crossbow_bolt"

local WEAPONS = {
    {
        key = "crossbow",
        -- Hub crash fix: the template name must sort after every retail template. weapon_action.template_name is sent
        -- as an index into the sorted table.keys(WeaponTemplates) (player_unit_data_component_config.lua:131-140), and the
        -- action and tweak lists are built in that order. A name sorting before unarmed_hub_human made a Fatshark hub server
        -- correction decode the hub template as 'unarmed' (hub_aim_constraints crash #ID[f8cbbdda]). Same fix as QIangIQsMeltagun 0.10.3.
        template = "zz_qiangiq_crossbow_p1_m1",
        source_template = "boltpistol_p1_m1",
        item = ITEM_ROOT .. "crossbow_p1_m1",                  -- named by the rig's own string
        source_item = ITEM_ROOT .. "boltpistol_p1_m1",
        fires_bolts = true,
        animate_mechanism = true,
        grip_offset = { 0, 0.1258, 0.0075 },                   -- bolt pistol trigger (0,0,0) - crossbow trigger
        viewmodel_drop = 0.03,                                 -- rear top 2.85 cm over the bolt pistol sight line
        base_unit = W .. "crossbow/wpn_crossbow_chained_rig",
        display = "loc_qiangiq_dauntless_crossbow",
        parts = {
            receiver = { unit = W .. "crossbow/attachments/receiver_01/receiver_01" },
            barrel = { unit = W .. "crossbow/attachments/barrel_01/barrel_01", attach_node = "ap_barrel_01" },
            magazine = { unit = W .. "crossbow/attachments/magazine_01/magazine_01", attach_node = "ap_magazine_01" },
            grip = { unit = W .. "crossbow/attachments/grip_01/grip_01", attach_node = "ap_grip_01" },
            underbarrel = { unit = W .. "crossbow/attachments/underbarrel_01/underbarrel_01", attach_node = "ap_underbarrel_01" },
        },
    },
}

local PART_ORDER = { "receiver", "barrel", "magazine", "grip", "underbarrel" }

mod:add_global_localize_strings({
    loc_qiangiq_dauntless_crossbow = { en = "Crossbow (datamined)" },
})

local function say(fmt, ...)
    local text = string.format(fmt, ...)

    mod:echo(text)
    mod:info(text)
end

-- Network lookups (QIangIQsShardStaff append_lookup): new names go at the end so no existing id moves -------------
local function append_lookup(lookup_name, key)
    local lookup = NetworkLookup[lookup_name]

    if not lookup then
        return false, "no lookup"
    end

    local existing = rawget(lookup, key)

    if existing then
        return true, existing
    end

    local index = #lookup + 1

    rawset(lookup, index, key)
    rawset(lookup, key, index)

    return true, index
end

-- Particle / sound aliases keyed by wielded_weapon_template (QIangIQsShardStaff alias_template_keys) --------------
local ALIAS_MODULES = {
    "scripts/settings/particles/player_character_particle_aliases",
    "scripts/settings/sound/player_character_sound_event_aliases",
}

local function alias_keys(root, source, target, seen, counter)
    if type(root) ~= "table" or seen[root] then
        return
    end

    seen[root] = true

    local value = rawget(root, source)

    if value ~= nil and rawget(root, target) == nil then
        root[target] = value
        counter.n = counter.n + 1
    end

    for _, child in pairs(root) do
        if type(child) == "table" then
            alias_keys(child, source, target, seen, counter)
        end
    end
end

local function copy_aliases(source, target)
    local counter = { n = 0 }

    for _, path in ipairs(ALIAS_MODULES) do
        local ok, module = pcall(require, path)

        if ok then
            alias_keys(module, source, target, {}, counter)
        else
            mod:error("alias module %s: %s", path, tostring(module))
        end
    end

    return counter.n
end

-- Crossbow bolts: projectile template and locomotion (see the 0.3.0 header) -----------------------------------------
local bolt_projectile

local function ensure_bolt_projectile()
    if bolt_projectile then
        return bolt_projectile
    end

    local ProjectileTemplates = require("scripts/settings/projectile/projectile_templates")
    local ProjectileLocomotionTemplates = require("scripts/settings/projectile_locomotion/projectile_locomotion_templates")
    local HitScanTemplates = require("scripts/settings/projectile/hit_scan_templates")
    local voidstrike = rawget(ProjectileTemplates, "force_staff_ball")
    local thumper_locomotion = rawget(ProjectileLocomotionTemplates, "ogryn_thumper_grenade")

    if not voidstrike or not thumper_locomotion then
        return nil, "force_staff_ball / ogryn_thumper_grenade templates not found"
    end

    local locomotion = table.clone(voidstrike.locomotion_template)
    local shoot = table.clone(thumper_locomotion.trajectory_parameters.shoot)
    local speed = locomotion.spawn_projectile_parameters.initial_speed     -- 60, weapon_projectile_locomotion_templates.lua:13

    shoot.speed_initial = speed
    shoot.speed_maximal = speed
    shoot.offset_forward = 0                                                -- voidstrike spawn_offset is zero
    shoot.randomized_angular_velocity = nil
    shoot.initial_angular_velocity = nil
    locomotion.trajectory_parameters.shoot = shoot
    locomotion.integrator_parameters.rotate_towards_direction = true        -- thumper: the bolt points where it flies
    locomotion.name = BOLT_LOCOMOTION
    ProjectileLocomotionTemplates[BOLT_LOCOMOTION] = locomotion

    local template = table.clone(voidstrike)
    local hitscan = HitScanTemplates.default_boltpistol_hitscan
    local profile = hitscan and hitscan.damage and hitscan.damage.impact and hitscan.damage.impact.damage_profile

    template.name = BOLT_PROJECTILE
    template.item_name = BOLT_ITEM
    template.locomotion_template = locomotion
    template.effects = {                                                    -- frag grenade trail, player_projectile_templates.lua:40-47
        spawn = {
            vfx = {
                link = true,
                orphaned_policy = "destroy",
                particle_name = "content/fx/particles/weapons/grenades/grenade_trail",
            },
        },
    }

    if profile then
        -- Heavy hit (user: stagger a Crusher out of its overhead). stagger_calculation.lua: the stagger type is the highest
        -- one in the category whose threshold (x damage_profile.stagger_resistance_modifier) is under the stagger strength, and
        -- ignore_stagger_reduction skips the breed's stagger_reduction (Crusher 15). "explosion" is the category that reaches
        -- the explosion type (Crusher threshold 200, 3 s), the heaviest stagger; a tiny resistance modifier makes every hit reach it.
        local heavy = table.clone(profile)

        heavy.stagger_category = "explosion"
        heavy.ignore_stagger_reduction = true
        heavy.stagger_resistance_modifier = mod:get("stagger_resistance_modifier") or 0.01
        heavy.ragdoll_push_force = math.max(heavy.ragdoll_push_force or 0, mod:get("ragdoll_push_force") or 2500)
        template.damage.impact.damage_profile = heavy
    end
    ProjectileTemplates[BOLT_PROJECTILE] = template

    local ok = append_lookup("projectile_template_names", BOLT_PROJECTILE)

    if not ok then
        return nil, "NetworkLookup.projectile_template_names missing"
    end

    bolt_projectile = template

    return template
end

-- The projectile unit stays voidstrike's (always hidden): manual_physics needs its "dynamic" actor
-- (projectile_unit_locomotion_extension.lua:51-56 and :360, unguarded; 0.3.0 crashed with our actor-less bolt unit).
-- Once the bolt model is loaded a bolt unit rides on the projectile (hooks further down). The trail is set in
-- ensure_bolt_projectile; effects must stay a table (projectile_fx_extension.lua:84 pairs() it in destroy).
local function show_bolt_model()
end

-- Crossbow handling: no recoil or sway, 18-round clip
local CROSSBOW_AMMO = "qiangiq_crossbow_p1_m1"

local function tune_crossbow(clone)
    local WeaponAmmoTemplates = require("scripts/settings/equipment/weapon_handling_templates/weapon_ammo_templates")
    local WeaponTweakTemplateSettings = require("scripts/settings/equipment/weapon_templates/weapon_tweak_template_settings")
    local ammo_type = WeaponTweakTemplateSettings.template_types.ammo

    WeaponAmmoTemplates[CROSSBOW_AMMO] = {
        ammunition_clips = {
            {
                lerp_basic = 18,
                lerp_perfect = 18,
            },
        },
        ammunition_reserve = {
            lerp_basic = 144,
            lerp_perfect = 144,
        },
    }

    local lookup = rawget(clone, "__base_template_lookup")
    local ammo_lookup = lookup and lookup[ammo_type]

    if ammo_lookup and ammo_lookup.base then
        ammo_lookup.base = { new_identifier = ammo_lookup.base.new_identifier, base_identifier = CROSSBOW_AMMO }
    else
        clone.ammo_template = CROSSBOW_AMMO
    end

    clone.recoil_template = nil
    clone.sway_template = nil

    if clone.alternate_fire_settings then
        clone.alternate_fire_settings.recoil_template = nil
        clone.alternate_fire_settings.sway_template = nil
    end

    for _, action in pairs(clone.actions) do
        action.recoil_template = nil
        action.sway_template = nil
    end
end

-- boltpistol action_shoot_hip / action_shoot_zoomed -> shoot_projectile (ogryn_thumper_p1_m2.lua:218-262 shape)
local function fire_bolts(clone, projectile)
    local ShotshellTemplates = require("scripts/settings/projectile/shotshell_templates")
    local DamageSettings = require("scripts/settings/damage/damage_settings")

    for _, action_name in ipairs({ "action_shoot_hip", "action_shoot_zoomed" }) do
        local action = clone.actions[action_name]

        if action and action.kind == "shoot_hit_scan" then
            local old = action.fire_configuration or {}

            action.kind = "shoot_projectile"
            action.throw_type = "shoot"
            action.projectile_locomotion_template = BOLT_LOCOMOTION
            action.fire_configuration = {
                anim_event = nil,                              -- no bolt pistol kick-up animation (user: no jump)
                inventory_item_name = BOLT_ITEM,
                same_side_suppression_enabled = false,
                skip_aiming = true,
                projectile = projectile,
                shotshell = ShotshellTemplates.default_thumper_assault,
            }

            if action.fx then
                action.fx.line_effect = nil
                action.fx.shell_casing_effect = nil
                action.fx.muzzle_flash_effect = nil            -- no powder: and the rig's fx_muzzle_01 no longer sits at the tip
                action.fx.muzzle_flash_effect_secondary = nil
            end

            projectile.damage.impact.damage_type = old.damage_type or DamageSettings.damage_types.boltshell_non_armed
        end
    end
end

-- Crossbow animations (native_animations setting, on by default) -----------------------------------------------------
-- The 2026-10-25 sweep found the crossbow's own first-person set (63 clips) and its state machine in the bundles. Its
-- event names were recovered by hashing candidate names against the state machine file: aim_braced, unaim_braced, shoot,
-- push, equip, equip_reload, reload, reload_partial (plus movement/stun events the engine sends itself). There is no
-- crossbow third-person set, so 3p keeps the bolt pistol's state machine and events (alternate_fire.lua:30 reads the
-- 3p start key as "start_anime_event_3p", so that spelling is deliberate).
local CROSSBOW_SM = "content/characters/player/human/first_person/animations/crossbow"

local function native_anims()
    return mod:get("native_animations") ~= false
end

local function use_native_animations(clone)
    local Ammo = require("scripts/utilities/ammo")
    local reload_time = math.max(3, math.min(12, mod:get("reload_time") or 6.5))

    -- player_unit_animation_state.lua:112 indexes the settings by state machine path (CTD "state_machine_settings (a nil
    -- value)" otherwise); the crossbow set is not listed in state_machine_ranged_first_person.lua, so it gets the bolt
    -- pistol entry (blend_time = 0). Same fix as QIangIQsMeltagun 0.2.2.
    local SMSettings = require("scripts/settings/animation/player_unit_animation_state_machine_settings")

    if not SMSettings[CROSSBOW_SM] then
        SMSettings[CROSSBOW_SM] = table.clone(SMSettings["content/characters/player/human/first_person/animations/bolt_pistol"] or { blend_time = 0 })
    end

    clone.anim_state_machine_1p = CROSSBOW_SM

    local alt = clone.alternate_fire_settings

    if alt then
        alt.start_anime_event_3p = alt.start_anim_event
        alt.stop_anim_event_3p = alt.stop_anim_event
        alt.start_anim_event = "to_braced"            -- the set's aim clips are to_braced / from_braced
        alt.stop_anim_event = "to_unaim_braced"
    end

    for _, action_name in ipairs({ "action_shoot_hip", "action_shoot_zoomed" }) do
        local action = clone.actions[action_name]
        local fire = action and action.fire_configuration

        if fire then
            fire.anim_event = "attack_shoot"
            fire.anim_event_3p = "attack_shoot"
        end
    end

    local push = clone.actions.action_push

    if push then
        push.matrices_data_location = "content/characters/player/human/first_person/animations/crossbow/push"
    end

    -- basic_reload_template.lua shape: one state, one clip. Clip lengths are not stored in a readable header, so the
    -- time is an estimate from file sizes (reload_time setting).
    local function reload_anim(partial, full)
        return function(params)
            if Ammo.current_ammo_in_clips(params.inventory_slot_component) > 0 then
                return partial
            end

            return full
        end
    end

    clone.reload_template = {
        name = "qiangiq_crossbow",
        states = { "reload" },
        reload = {
            state_index = 1,
            anim_1p = reload_anim("reload_partial", "reload_start"),
            anim_3p = reload_anim("reload_partial", "reload_start"),
            show_magazine_ammo_time = reload_time * 0.4,
            time = reload_time,
            state_transitions = { reload = reload_time - 0.1 },
            functionality = {
                remove_ammunition = reload_time * 0.12,
                refill_ammunition = reload_time * 0.8,
            },
        },
    }

    local reload = clone.actions.action_reload

    if reload then
        reload.total_time = reload_time

        local chains = reload.allowed_chain_actions or {}

        for _, input in ipairs({ "shoot_pressed", "special_action" }) do
            if type(chains[input]) == "table" then
                chains[input].chain_time = reload_time - 0.2
            end
        end
    end
end

-- First-person event guard. The first attempt sent names that were only state-machine state names (aim_braced), and
-- Unit.animation_event raised a script error ("state machine ... does not have an event"). Event ids are 32 bit (high half
-- of the murmur64); the real events found in the file are the bolt pistol's set (attack_shoot, attack_push, attack_hit, equip,
-- equip_reload, reload_start/middle/end(+_partial), to_braced, to_unaim_braced, to_ironsight, to_unaim_ironsight, inspect_*).
-- An event the crossbow state machine lacks is replaced by its fallback, or skipped. The wielded template name is stored
-- from inventory_slot_wielded because AuthoritativePlayerUnitAnimationExtension has no _local_wielded_weapon_template.
local EVENT_FALLBACKS = {
    to_braced = { "to_ironsight" },
    to_unaim_braced = { "to_unaim_ironsight" },
    attack_shoot = { "shoot" },
    attack_push = { "push" },
    reload_start = { "reload" },
}
local skipped_events = {}

local function guard_1p(func, self, event_name, ...)
    if native_anims() and (self.__qiangiq_crossbow_wielded or self._local_wielded_weapon_template) == WEAPONS[1].template then
        local unit = self._first_person_unit

        if unit and not Unit.alive(unit) then
            return                                     -- a destroyed unit would crash inside has_animation_event (native AV 2026-10-27)
        end

        if unit and not Unit.has_animation_event(unit, event_name) then
            for _, alternative in ipairs(EVENT_FALLBACKS[event_name] or {}) do
                if Unit.has_animation_event(unit, alternative) then
                    return func(self, alternative, ...)
                end
            end

            if not skipped_events[event_name] then
                skipped_events[event_name] = true
                mod:info("skipped anim event %s: not in the crossbow state machine", tostring(event_name))
            end

            return
        end
    end

    return func(self, event_name, ...)
end

for _, class_name in ipairs({ "PlayerUnitAnimationExtension", "AuthoritativePlayerUnitAnimationExtension" }) do
    local class = CLASS[class_name]

    if class then
        mod:hook_safe(class, "inventory_slot_wielded", function(self, weapon_template)
            self.__qiangiq_crossbow_wielded = weapon_template and weapon_template.name or false
        end)

        for _, method in ipairs({ "anim_event_1p", "anim_event_with_variable_float_1p", "anim_event_with_variable_floats_1p" }) do
            if class[method] then
                mod:hook(class, method, guard_1p)
            end
        end
    end
end

-- State -------------------------------------------------------------------------------------------------------------
local state = {}

for _, spec in ipairs(WEAPONS) do
    state[spec.key] = { template_ok = false, item_ok = false, notes = {} }
end

local next_poll = 0

-- Template ----------------------------------------------------------------------------------------------------------
local function ensure_template(spec, st)
    local existing = rawget(WeaponTemplates, spec.template)

    if existing then
        st.template_ok = true
        st.official_template = not st.template_ours

        return true
    end

    local source = WeaponTemplates[spec.source_template]

    if not source then
        return false
    end

    local projectile

    if spec.fires_bolts then
        local err

        projectile, err = ensure_bolt_projectile()

        if not projectile then
            error(err)
        end
    end

    local clone = table.clone(source)

    clone.name = spec.template

    -- weapon_templates.lua _require_template: action_settings.name = action_name
    for action_name, action_settings in pairs(clone.actions) do
        action_settings.name = action_name
    end

    if projectile then
        fire_bolts(clone, projectile)
        tune_crossbow(clone)

        if native_anims() then
            use_native_animations(clone)
        end
    end

    WeaponTemplates[spec.template] = clone
    st.template_ours = true

    local ok, index = append_lookup("weapon_templates", spec.template)

    st.template_id = ok and index or nil
    st.aliases = copy_aliases(spec.source_template, spec.template)
    st.template_ok = ok

    return ok
end

-- Items -------------------------------------------------------------------------------------------------------------
local function part_of(item)
    local base_unit = type(item) == "table" and item.base_unit

    if type(base_unit) ~= "string" then
        return nil
    end

    return base_unit:match("/attachments/([%a_]+)_%a*%d+/")
end

local function find_item(cache, preferred, template)
    local direct = rawget(cache, preferred)

    if direct and direct.weapon_template == template then
        return preferred, direct
    end

    for name, item in pairs(cache) do
        if type(item) == "table" and item.weapon_template == template then
            return name, item
        end
    end
end

-- Only base_unit is kept: Items.base_unit can also read per-breed / first-person variants of the source part
local function only_base_unit(item, unit)
    for key in pairs(item) do
        if type(key) == "string" and key ~= "base_unit" and key:find("^base_unit") then
            item[key] = nil
        end
    end

    item.base_unit = unit
end

local function attachment_name(spec, part)
    return ITEM_ROOT .. "qiangiq_dauntless/" .. spec.key .. "_" .. part .. "_01"
end

local function make_attachment(cache, spec, part, template_item)
    local name = attachment_name(spec, part)
    local def = spec.parts[part]
    local item = table.clone(template_item)

    only_base_unit(item, def.unit)
    item.name = name
    item.resource_dependencies = { [def.unit] = true }
    item.attachments = nil
    item.material_overrides = nil
    item.material_override_items = nil

    if def.attach_node then
        item.attach_node = def.attach_node
    end

    cache[name] = item

    return name
end

-- Walk the source weapon's attachment tree. Each slot whose item is a weapon part we have is pointed at our part;
-- every other item becomes "" (spawns nothing). Parts we have but the source lacks go under the receiver.
local function rebuild_tree(cache, spec, tree, placed, reachable, notes)
    for slot_name, node in pairs(tree) do
        if type(node) == "table" then
            local item_name = node.item
            local keep_children_reachable = reachable

            if type(item_name) == "string" and item_name ~= "" then
                local source_part_item = rawget(cache, item_name)
                local part = part_of(source_part_item)

                if part and spec.parts[part] and reachable and not placed[part] then
                    node.item = make_attachment(cache, spec, part, source_part_item)
                    placed[part] = { node = node, template_item = source_part_item, parent = tree, slot = slot_name }
                    notes[#notes + 1] = string.format("%s <- %s", part, item_name)
                else
                    node.item = ""
                    keep_children_reachable = false
                end
            end

            if type(node.children) == "table" then
                rebuild_tree(cache, spec, node.children, placed, keep_children_reachable, notes)
            end
        end
    end
end

-- Source tree as "slot_path=item [leaf override, map mode]" for the log, to check placement against the game's data
local function dump_tree(tree, prefix, out)
    for slot_name, node in pairs(tree) do
        if type(node) == "table" then
            local path = prefix .. slot_name

            out[#out + 1] = string.format("%s=%s%s%s", path, tostring(node.item),
                node.leaf_attach_node_override and (" leaf:" .. tostring(node.leaf_attach_node_override)) or "",
                node.link_map_mode_override and (" map:" .. tostring(node.link_map_mode_override)) or "")

            if type(node.children) == "table" then
                dump_tree(node.children, path .. "/", out)
            end
        end
    end

    return out
end

-- Retail HUD icon (unreleased-asset sweep build 139617: material+package content/ui/materials/icons/weapons/hud/crossbow_p1_m1).
-- Used when the package exists, so the bottom-right icon needs no other mod; the drawn PNG (SimpleAssets) is the opt-in fallback.
local RETAIL_HUD_ICON = "content/ui/materials/icons/weapons/hud/crossbow_p1_m1"
local retail_icon = { used = false }

local function build_item(cache, spec, st)
    local source_name, source_item = find_item(cache, spec.source_item, spec.source_template)

    if not source_item then
        return false
    end

    local rig = spec.base_unit

    local item = table.clone(source_item)
    local notes = {}
    local placed = {}

    item.name = spec.item
    item.weapon_template = spec.template
    item.archetypes = { "zealot" }

    if rig then
        local deps = item.resource_dependencies or {}

        if item.base_unit then
            deps[item.base_unit] = nil
        end

        only_base_unit(item, rig)
        deps[rig] = true
        item.resource_dependencies = deps
    end

    item.display_name = spec.display

    local ok_icon, icon_package = pcall(Application.can_get_resource, "package", RETAIL_HUD_ICON)

    if ok_icon and icon_package and mod:get("drawn_hud_icon") ~= true then
        local icon_deps = item.resource_dependencies or {}

        if type(item.hud_icon) == "string" then
            icon_deps[item.hud_icon] = nil
        end

        item.hud_icon = RETAIL_HUD_ICON
        icon_deps[RETAIL_HUD_ICON] = true
        item.resource_dependencies = icon_deps
        retail_icon.used = true
    end

    for _, field in ipairs({ "weapon_family_display_name", "weapon_pattern_display_name", "weapon_mark_display_name" }) do
        if type(item[field]) == "table" then
            item[field].loc_id = spec.display
        end
    end

    if type(item.attachments) ~= "table" then
        return false, "source item has no attachments"
    end

    mod:info("%s: source tree of %s: %s", spec.key, tostring(source_name),
        table.concat(dump_tree(item.attachments, "", {}), "; "))
    rebuild_tree(cache, spec, item.attachments, placed, true, notes)

    local receiver = placed.receiver

    if not receiver then
        return false, "no receiver slot in " .. tostring(source_name)
    end

    -- Static receiver: its nodes no longer follow same-named rig nodes, and every part hangs off those nodes
    if not (spec.fires_bolts and native_anims()) then
        receiver.node.link_map_mode_override = "LINK_MODE_NONE"   -- native crossbow animation moves the rig nodes, so the parts follow them
    end
    receiver.node.children = receiver.node.children or {}

    local receiver_children = receiver.node.children

    for _, part in ipairs(PART_ORDER) do
        local p = placed[part]

        if p and part ~= "receiver" then
            p.node.leaf_attach_node_override = nil
            p.node.link_map_mode_override = nil

            if p.parent ~= receiver_children then
                local slot = rawget(receiver_children, p.slot) == nil and p.slot or ("qiangiq_" .. part)

                p.parent[p.slot] = { item = "", children = {} }
                receiver_children[slot] = p.node
                notes[#notes + 1] = string.format("%s moved under the receiver", part)
            end
        end
    end

    for _, part in ipairs(PART_ORDER) do
        if spec.parts[part] and not placed[part] then
            receiver.node.children = receiver.node.children or {}
            receiver.node.children["qiangiq_" .. part] = {
                item = make_attachment(cache, spec, part, receiver.template_item),
                children = {},
            }
            notes[#notes + 1] = string.format("%s added under the receiver (%s)", part, spec.parts[part].attach_node)
        end
    end

    -- What the offline item compile adds for the weapon template (item_package.lua:239-249): state machines, sounds,
    -- effects. Without it the laspistol state machine was never loaded (crash on equipping the flamer pistol).
    local deps = item.resource_dependencies or {}
    local WeaponTemplateResourceDependencies = require("scripts/utilities/weapon_template_resource_dependencies")

    for _, resource in ipairs(WeaponTemplateResourceDependencies.generate(spec.template)) do
        deps[resource] = true
    end

    item.resource_dependencies = deps

    if spec.fires_bolts then
        local bolt_source = rawget(cache, BOLT_ITEM_SOURCE)

        if not bolt_source then
            return false, "no " .. BOLT_ITEM_SOURCE .. " item to clone the bolt projectile from"
        end

        if not rawget(cache, BOLT_ITEM) then
            local bolt = table.clone(bolt_source)

            bolt.name = BOLT_ITEM

            if not append_lookup("player_item_names", BOLT_ITEM) then
                return false
            end

            cache[BOLT_ITEM] = bolt
        end

        -- projectile items' dependencies load with the weapon (item_package.lua compile_item_instance_dependencies)
        item.projectile_items = { BOLT_ITEM }
        show_bolt_model()
    end

    local ok, index = append_lookup("player_item_names", spec.item)

    if not ok then
        return false
    end

    cache[spec.item] = item
    st.item_id = index
    st.source_item_name = source_name
    st.slot = item.slots and item.slots[1]
    st.notes = notes

    return true
end

local function ensure_item(spec, st)
    local ok, has_data = pcall(MasterItems.has_data)

    if not ok or not has_data then
        return false
    end

    local cache = MasterItems.get_cached()
    local existing = rawget(cache, spec.item)

    if existing then
        st.item_ok = true

        return true
    end

    local built, err = build_item(cache, spec, st)

    if err and err ~= st.last_error then
        st.last_error = err
        mod:error("%s: %s", spec.key, err)
    end

    st.item_ok = built and rawget(cache, spec.item) ~= nil

    return st.item_ok
end

-- Zealot unlock list (weapon_unlock_settings.lua builds WeaponUnlockSettings[archetype][level] = { item names });
-- realms_loadout weapon_catalog.lua human_weapon_levels_by_name builds its human weapon list from it.
local function add_to_unlock_list()
    if not mod:get("add_to_unlock_list") then
        return
    end

    local ok, unlocks = pcall(require, "scripts/settings/weapon_unlock/weapon_unlock_settings")
    local zealot = ok and unlocks and unlocks.zealot

    if not zealot then
        mod:error("WeaponUnlockSettings.zealot not found")

        return
    end

    local level = math.floor(mod:get("unlock_level") or 1)

    zealot[level] = zealot[level] or {}

    for _, spec in ipairs(WEAPONS) do
        if not table.find(zealot[level], spec.item) then
            table.insert(zealot[level], spec.item)
        end
    end
end

local function poll()
    if next_poll > os.clock() then
        return
    end

    next_poll = os.clock() + 1

    for _, spec in ipairs(WEAPONS) do
        local st = state[spec.key]
        local before_t, before_i = st.template_ok, st.item_ok
        local ok_t, err_t = pcall(ensure_template, spec, st)
        local ok_i, err_i = true, nil

        if st.template_ok then
            ok_i, err_i = pcall(ensure_item, spec, st)
        end

        if not ok_t then
            mod:error("%s template: %s", spec.key, tostring(err_t))
        end

        if not ok_i then
            mod:error("%s item: %s", spec.key, tostring(err_i))
        end

        if st.template_ok and not before_t then
            if st.official_template then
                mod:info("%s: the game now has its own %s template; using it", spec.key, spec.template)
            else
                mod:info("%s: template %s registered (clone of %s), %s alias entries", spec.key, spec.template,
                    spec.source_template, tostring(st.aliases))
            end
        end

        if st.item_ok and not before_i then
            mod:info("%s: item %s injected (clone of %s, slot %s): %s", spec.key, spec.item,
                tostring(st.source_item_name), tostring(st.slot), table.concat(st.notes or {}, "; "))
        end
    end
end

-- Clip display: our clip frame + one bolt unit per remaining round on the crossbow's magazine attachment -------------
-- Spawning, linking, 1p flags, hiding the original and cleanup follow QIangIQsShardStaff (seen working in game):
-- PlayerUnitVisualLoadoutExtension init/_update_item_visibility/update/_unequip_item_from_slot/destroy hooks,
-- ext._equipment[slot] unit_1p/unit_3p, item_name_by_unit_1p/3p (equipment_component.lua:299/345).
local CROSSBOW_ITEM = WEAPONS[1].item
local CROSSBOW_MAGAZINE = ITEM_ROOT .. "qiangiq_dauntless/crossbow_magazine_01"
local tracked = {}

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function delete_unit(unit)
    local unit_spawner = Managers.state and Managers.state.unit_spawner

    if unit_ok(unit) and unit_spawner then
        unit_spawner:mark_for_deletion(unit)
    end
end

local function clear_clip(rec)
    if rec then
        delete_unit(rec.clip)

        for i = 1, #rec.bolts do
            delete_unit(rec.bolts[i])
        end
    end
end

local function spawn_linked(ext, unit_name, parent, first_person, z)
    local world = ext.__qiangiq_dauntless_world
    local unit_spawner = Managers.state and Managers.state.unit_spawner
    local unit = world and unit_spawner and unit_spawner:spawn_unit(unit_name, Unit.world_pose(parent, 1))

    if not unit then
        return nil
    end

    if first_person then
        Unit.set_unit_culling(unit, false)
        Unit.set_shader_pass_flag_for_meshes_in_unit_and_childs(unit, "custom_fov", true)
    end

    World.link_unit(world, unit, 1, parent, 1, World.LINK_MODE_NODE_NAME)

    if z then
        Unit.set_local_position(unit, 1, Vector3(0, 0, z))
    end

    return unit
end

local function magazine_unit(names)
    if names then
        for unit, item_name in pairs(names) do
            if item_name == CROSSBOW_MAGAZINE and unit_ok(unit) then
                return unit
            end
        end
    end
end

local function bolts_to_show(ext, slot_name)
    local Ammo = require("scripts/utilities/ammo")
    local ok, current = pcall(Ammo.current_slot_clip_amount, ext._unit, slot_name)
    local ok_max, max = pcall(Ammo.max_slot_clip_amount, ext._unit, slot_name)

    if not (ok and ok_max and current and max and max > 0) then
        return CLIP_BOLTS
    end

    if current <= 0 then
        return 0
    end

    return math.max(1, math.min(CLIP_BOLTS, math.floor(CLIP_BOLTS * current / max + 0.5)))
end

local function sync_clip(ext, records, key, names, visible, first_person, shown)
    local rec = records[key]
    local mag = assets_ready.clip and assets_ready.bolt and magazine_unit(names)

    if rec and (rec.mag ~= mag or not unit_ok(rec.clip)) then
        clear_clip(rec)
        records[key] = nil
        rec = nil
    end

    if not mag then
        return
    end

    if not rec then
        rec = { mag = mag, bolts = {} }
        rec.clip = spawn_linked(ext, CLIP_UNIT, mag, first_person, nil)

        for i = 1, CLIP_BOLTS do
            rec.bolts[i] = spawn_linked(ext, BOLT_UNIT, mag, first_person, TOP_BOLT_Z - (i - 1) * BOLT_PITCH)
        end

        records[key] = rec

        if not rec.clip then
            return
        end
    end

    Unit.set_unit_visibility(mag, false, true)
    Unit.set_unit_visibility(rec.clip, visible, true)

    -- the stack feeds up: the bolts left fill the top positions
    for i = 1, CLIP_BOLTS do
        if unit_ok(rec.bolts[i]) then
            Unit.set_unit_visibility(rec.bolts[i], visible and i <= shown, true)
        end
    end
end

local function drop_slot_clips(records, slot_name)
    for _, view in ipairs({ ":3p", ":1p" }) do
        local rec = records[slot_name .. view]

        if rec then
            clear_clip(rec)
            records[slot_name .. view] = nil
        end
    end
end

-- Grip offset and crossbow mechanism on the static receiver -----------------------------------------------------------
local SPEC_BY_ITEM = {}

for _, spec in ipairs(WEAPONS) do
    SPEC_BY_ITEM[spec.item] = spec
end

local MECH_NODES = { "ap_magazine_01", "ap_recharge_01", "ap_recharge_02", "ap_recharge_03", "ap_trigger_01", "ap_release_01", "ap_anim_01", "ap_anim_02", "ap_anim_03" }
local STROKE = 0.1612              -- underbarrel nock ap_recharge_01 (y -0.2228) to the limb-tip line ap_anim_05/07 (y -0.0616)
local LIMB_ANGLE = math.rad(8)     -- limbs swing forward as the string runs out
local KICK_BACK = 0.015           -- straight back into the shoulder, no climb
local BOLT_SCALE = 3
local LATCH_SHUT_T = 0.47          -- string back on the latch; the refire chain time is 0.6 (boltpistol action_shoot_hip)
local shot_time = {}               -- player unit -> gameplay time of the last crossbow shot
local AUDIO_DIR = "mods/QIangIQsCrossbow/audio/"
local EJECT_T = 0.4                -- boltpistol reload template eject_mag functionality.remove_ammunition

local function gameplay_time()
    local ok, t = pcall(function()
        return Managers.time:time("gameplay")
    end)

    return ok and t or nil
end

-- SimpleAudio, called the way QIangIQsAWP_cs2audio.lua does
local function play_sound(file)
    if not mod:get("synth_audio") then
        return
    end

    local sa = get_mod and get_mod("SimpleAudio")

    if sa and sa.play_file then
        pcall(sa.play_file, AUDIO_DIR .. file, { audio_type = "sfx", volume = 100 })
    end
end

local function ramp(s, a, b)
    if s <= a then
        return 0
    elseif s >= b then
        return 1
    end

    local u = (s - a) / (b - a)

    return u * u * (3 - 2 * u)
end

-- seconds since the shot -> string travel (0 cocked .. 1 out, with a small overshoot), trigger pull, latch opening
local function mech_pose(s)
    if not s or s < 0 or s > LATCH_SHUT_T + 0.08 then
        return 0, 0, 0
    end

    local trigger = ramp(s, 0, 0.03) * (1 - ramp(s, 0.09, 0.2))
    local latch = ramp(s, 0.015, 0.03) * (1 - ramp(s, LATCH_SHUT_T, LATCH_SHUT_T + 0.05))
    local string_out

    if s < 0.025 then
        string_out = 0
    elseif s < 0.045 then
        local u = (s - 0.025) / 0.02

        string_out = u * u                                     -- limbs accelerate the string
    elseif s < 0.2 then
        local d = s - 0.045

        string_out = 1 + 0.05 * math.sin(2 * math.pi * d / 0.05) * math.exp(-d / 0.02)   -- slaps the stops and settles
    else
        string_out = 1 - ramp(s, 0.2, LATCH_SHUT_T)            -- drawn back onto the latch
    end

    return string_out, trigger, latch
end

local function receiver_unit(names, spec)
    local want = attachment_name(spec, "receiver")

    if names then
        for unit, item_name in pairs(names) do
            if item_name == want and unit_ok(unit) then
                return unit
            end
        end
    end
end

-- bind-pose locals of the receiver root and the mechanism nodes, read once per spawned receiver
local function rig_record(rigs, unit)
    local rec = rigs[unit]

    if rec then
        return rec
    end

    local p = Unit.local_position(unit, 1)

    rec = { root = { p[1], p[2], p[3] }, nodes = {} }

    for _, name in ipairs(MECH_NODES) do
        if Unit.has_node(unit, name) then
            local index = Unit.node(unit, name)
            local q = Unit.local_position(unit, index)

            rec.nodes[name] = { index = index, pos = { q[1], q[2], q[3] }, rot = QuaternionBox(Unit.local_rotation(unit, index)) }
        end
    end

    rigs[unit] = rec

    return rec
end

local function move(unit, node, dx, dy, dz)
    if node then
        local p = node.pos

        Unit.set_local_position(unit, node.index, Vector3(p[1] + dx, p[2] + dy, p[3] + dz))
    end
end

local function swing(unit, node, angle)
    if node then
        Unit.set_local_rotation(unit, node.index, Quaternion.multiply(Quaternion.axis_angle(Vector3(0, 0, 1), angle), node.rot:unbox()))
    end
end

-- The bolt pistol reload anim moves the rig's ap_magazine_01 with the left hand. While reloading, the clip (child of the
-- receiver's ap_magazine_01) gets that node's motion relative to its idle pose; otherwise the idle pose is recorded.
local function follow_hand(rec, unit, rig, reloading, o)
    local node = rec.nodes.ap_magazine_01

    if not (node and unit_ok(rig) and Unit.has_node(rig, "ap_magazine_01")) then
        return
    end

    local index = Unit.node(rig, "ap_magazine_01")
    local p = Unit.local_position(rig, index)
    local q = Unit.local_rotation(rig, index)

    if not reloading or not rec.hand_rest then
        rec.hand_rest = { pos = { p[1], p[2], p[3] }, rot = QuaternionBox(q) }
        Unit.set_local_position(unit, node.index, Vector3(node.pos[1], node.pos[2], node.pos[3]))
        Unit.set_local_rotation(unit, node.index, node.rot:unbox())

        return
    end

    local rest = rec.hand_rest
    local delta_rot = Quaternion.multiply(q, Quaternion.inverse(rest.rot:unbox()))
    -- clip position in the rig frame at idle = grip offset + its bind position on the receiver
    local idle = Vector3(o[1] + node.pos[1] - rest.pos[1], o[2] + node.pos[2] - rest.pos[2], o[3] + node.pos[3] - rest.pos[3])
    local moved = p + Quaternion.rotate(delta_rot, idle)

    Unit.set_local_position(unit, node.index, Vector3(moved[1] - o[1], moved[2] - o[2], moved[3] - o[3]))
    Unit.set_local_rotation(unit, node.index, Quaternion.multiply(delta_rot, node.rot:unbox()))
end

local function pose_receiver(ext, names, spec, first_person, rig, reloading)
    if native_anims() then
        return                                         -- the crossbow's own animation moves the string, latch and magazine
    end

    local unit = receiver_unit(names, spec)

    if not unit then
        return
    end

    local rigs = ext.__qiangiq_dauntless_rigs

    if not rigs then
        rigs = {}
        ext.__qiangiq_dauntless_rigs = rigs
    end

    local rec = rig_record(rigs, unit)
    local o = spec.grip_offset or { 0, 0, 0 }
    local r = rec.root
    local fired_at = spec.animate_mechanism and shot_time[ext._unit]
    local now = fired_at and gameplay_time()
    local s = now and now - fired_at
    local kick = 0

    if s and s >= 0 and s < 0.3 then
        kick = KICK_BACK * ramp(s, 0, 0.02) * math.exp(-math.max(s - 0.02, 0) / 0.05)
    end

    Unit.set_local_position(unit, 1, Vector3(r[1] + o[1], r[2] + o[2] - kick, r[3] + o[3]))

    if not spec.animate_mechanism then
        return
    end
    local string_out, trigger, latch = mech_pose(s)
    local n = rec.nodes

    move(unit, n.ap_recharge_01, 0, STROKE * string_out, 0)
    swing(unit, n.ap_recharge_02, LIMB_ANGLE * math.min(string_out, 1))
    swing(unit, n.ap_recharge_03, -LIMB_ANGLE * math.min(string_out, 1))
    move(unit, n.ap_trigger_01, 0, -0.006 * trigger, 0)
    move(unit, n.ap_release_01, 0, 0, -0.004 * latch)
    move(unit, n.ap_anim_01, 0, 0, -0.006 * latch)
    move(unit, n.ap_anim_02, -0.008 * latch, 0, 0)
    move(unit, n.ap_anim_03, 0.008 * latch, 0, 0)

    follow_hand(rec, unit, rig, reloading, o)

    if first_person and s and s >= LATCH_SHUT_T and rec.cocked_for ~= fired_at then
        rec.cocked_for = fired_at
        play_sound("crossbow_cock.wav")
    end
end

local function prune_rigs(ext)
    local rigs = ext.__qiangiq_dauntless_rigs

    if rigs then
        for unit in pairs(rigs) do
            if not unit_ok(unit) then
                rigs[unit] = nil
            end
        end
    end
end

-- action_reload on the wielded crossbow; plays the eject thud once the old rounds are removed
local function crossbow_reloading(ext)
    local ok, weapon_action = pcall(function()
        local ude = ScriptUnit.has_extension(ext._unit, "unit_data_system")

        return ude and ude:read_component("weapon_action")
    end)
    local reloading = ok and weapon_action and weapon_action.template_name == WEAPONS[1].template and weapon_action.current_action_name == "action_reload"
    local now = gameplay_time()

    if not reloading then
        ext.__qiangiq_dauntless_reload = nil

        return false
    end

    local r = ext.__qiangiq_dauntless_reload

    if not r then
        r = { since = now }
        ext.__qiangiq_dauntless_reload = r
    end

    if not r.ejected and now and r.since and now - r.since >= EJECT_T then
        r.ejected = true
        play_sound("crossbow_eject.wav")
    end

    return true
end

local function apply_clips(ext)
    if not ext._is_local_unit or not ext._equipment then
        return
    end

    local records = ext.__qiangiq_dauntless_clips

    if not records then
        records = {}
        ext.__qiangiq_dauntless_clips = records
    end

    prune_rigs(ext)

    for slot_name, slot in pairs(ext._equipment) do
        local item = slot.item
        local spec = item and SPEC_BY_ITEM[item.name]

        local reloading = spec and (spec.animate_mechanism or native_anims()) and crossbow_reloading(ext)

        if spec then
            pose_receiver(ext, slot.item_name_by_unit_3p, spec, false, slot.unit_3p, reloading)
            pose_receiver(ext, slot.item_name_by_unit_1p, spec, true, slot.unit_1p, reloading)
        end

        if item and item.name == CROSSBOW_ITEM then
            local shown = bolts_to_show(ext, slot_name)

            if reloading and shown == 0 then
                shown = CLIP_BOLTS                         -- the fresh clip in the left hand
            end

            sync_clip(ext, records, slot_name .. ":3p", slot.item_name_by_unit_3p, slot.hidden_3p == false, false, shown)
            sync_clip(ext, records, slot_name .. ":1p", slot.item_name_by_unit_1p, slot.hidden_1p == false, true, shown)
        elseif records[slot_name .. ":3p"] or records[slot_name .. ":1p"] then
            drop_slot_clips(records, slot_name)
        end
    end
end

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "init", function(self, extension_init_context)
    self.__qiangiq_dauntless_world = extension_init_context and extension_init_context.world
end)

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "_update_item_visibility", function(self)
    if self._is_local_unit then
        tracked[self] = true
        apply_clips(self)
    end
end)

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "update", function(self)
    if tracked[self] then
        apply_clips(self)
    end
end)

mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, "_unequip_item_from_slot", function(func, self, slot_name, ...)
    local records = self.__qiangiq_dauntless_clips

    if records then
        drop_slot_clips(records, slot_name)
    end

    return func(self, slot_name, ...)
end)

mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, "destroy", function(func, self, ...)
    local records = self.__qiangiq_dauntless_clips

    if records then
        for key, rec in pairs(records) do
            clear_clip(rec)
            records[key] = nil
        end
    end

    tracked[self] = nil

    return func(self, ...)
end)

-- Bolt model on each crossbow projectile: spawned in the projectile's world, linked to its root node
local riding_bolts = {}

mod:hook_safe(CLASS.ProjectileUnitLocomotionExtension, "init", function(self, extension_init_context, unit, extension_init_data)
    if not (assets_ready.bolt and extension_init_data and extension_init_data.projectile_template_name == BOLT_PROJECTILE) then
        return
    end

    local world = extension_init_context and extension_init_context.world

    if world and unit_ok(unit) then
        local bolt = World.spawn_unit_ex(world, BOLT_UNIT, nil, Unit.world_pose(unit, 1))

        if bolt then
            World.link_unit(world, bolt, 1, unit, 1, World.LINK_MODE_NODE_NAME)
            Unit.set_local_scale(bolt, 1, Vector3(BOLT_SCALE, BOLT_SCALE, BOLT_SCALE))
            Unit.set_unit_visibility(bolt, true, true)
            riding_bolts[unit] = { bolt = bolt, world = world }
        end
    end
end)

local function drop_riding_bolt(unit)
    local rec = riding_bolts[unit]

    if rec then
        riding_bolts[unit] = nil

        if unit_ok(rec.bolt) then
            World.destroy_unit(rec.world, rec.bolt)
        end
    end
end

mod:hook(CLASS.ProjectileUnitLocomotionExtension, "destroy", function(func, self, ...)
    drop_riding_bolt(self._projectile_unit)

    return func(self, ...)
end)

-- Crossbow shot: our thunk instead of the bolt pistol shot, and the mechanism cycle (QIangIQsAWP.lua:715 hook shape)
local CROSSBOW_TEMPLATE = WEAPONS[1].template

mod:hook("ActionShootProjectile", "_play_shoot_sound", function(func, self, fire_config)
    local unit = self._player_unit
    local action_component = self._action_component

    if self._is_local_unit and self._is_human_controlled and unit and action_component and action_component.fire_state == "start_shooting" then
        local ok, weapon_action = pcall(function()
            return self._unit_data_extension:read_component("weapon_action")
        end)

        if ok and weapon_action and weapon_action.template_name == CROSSBOW_TEMPLATE and self:_has_ammo(fire_config) and mod:get("synth_audio") and get_mod("SimpleAudio") then
            shot_time[unit] = gameplay_time()
            play_sound("crossbow_shot.wav")

            return
        end
    end

    return func(self, fire_config)
end)

-- Retail crossbow sounds (wwise/events/weapon/play_crossbow_p1_*, referenced by packages/boot_assets so always loaded;
-- names from the 2026-10-30 datafile list). Swapped at local playback only: the alias table and
-- NetworkLookup.player_character_sounds keep the bolt pistol names, so synced RPCs only carry ids every peer knows
-- (player_unit_fx_extension.lua:1581 sends NetworkLookup.player_character_sounds[event_name]). The _husk suffix is
-- appended afterwards by trigger_wwise_event and every swapped event that is played as a husk has a _husk twin.
local CROSSBOW_SOUNDS = {
    ["wwise/events/weapon/play_bolt_pistol_p1_m1_single"] = "wwise/events/weapon/play_crossbow_p1_fire",
    ["wwise/events/weapon/play_boltpistol_ads_up"] = "wwise/events/weapon/play_crossbow_p1_foley_ads_in",
    ["wwise/events/weapon/play_boltpistol_ads_down"] = "wwise/events/weapon/play_crossbow_p1_foley_ads_out",
    ["wwise/events/weapon/play_boltpistol_reload_equip"] = "wwise/events/weapon/play_crossbow_p1_foley_equip",
    ["wwise/events/weapon/play_boltpistol_reload_hit"] = "wwise/events/weapon/play_crossbow_p1_foley_reload_punch",
    ["wwise/events/weapon/play_boltpistol_reload_mag_out"] = "wwise/events/weapon/play_crossbow_p1_foley_reload_mag_out",
    ["wwise/events/weapon/play_boltpistol_reload_mag_in"] = "wwise/events/weapon/play_crossbow_p1_foley_reload_mag_in",
    ["wwise/events/weapon/play_boltpistol_reload_lever_pull"] = "wwise/events/weapon/play_crossbow_p1_foley_reload_lever_pull",
    -- the bolter reflection tail does not fit a crossbow
    ["wwise/events/weapon/play_player_wpn_refl_bolter"] = "wwise/events/weapon/play_weapon_silence",
}
local CROSSBOW_INSPECT_SOUND = "wwise/events/weapon/play_crossbow_p1_foley_inspect"

local function fx_wields_crossbow(fx_self)
    local ok, wields = pcall(function()
        local inventory = fx_self._unit_data_extension:read_component("inventory")
        local template = fx_self._visual_loadout_extension:weapon_template_from_slot(inventory.wielded_slot)

        return template and template.name == CROSSBOW_TEMPLATE
    end)

    return ok and wields
end

local function retail_sounds()
    return mod:get("retail_sounds") ~= false and not (mod:get("synth_audio") and get_mod("SimpleAudio"))
end

mod:hook("PlayerUnitFxExtension", "trigger_wwise_event", function(func, self, event_name, ...)
    local swap = CROSSBOW_SOUNDS[event_name]

    if swap and retail_sounds() and fx_wields_crossbow(self) then
        return func(self, swap, ...)
    end

    return func(self, event_name, ...)
end)

-- Inspect resolves to the shared play_player_foley_subtle, so it is matched by alias on the local-only path.
-- The crossbow inspect event has no _husk twin, so it is played without the suffix.
mod:hook("PlayerUnitFxExtension", "trigger_gear_wwise_event", function(func, self, sound_alias, external_properties, ...)
    if sound_alias == "sfx_inspect" and retail_sounds() and fx_wields_crossbow(self) then
        return self:trigger_wwise_event(CROSSBOW_INSPECT_SOUND, false, ...)
    end

    return func(self, sound_alias, external_properties, ...)
end)

local function crossbow_wielded(c_self)
    local weapon_extension = rawget(c_self, "_weapon_extension")
    local ok, template = pcall(function()
        return weapon_extension and weapon_extension:weapon_template()
    end)

    return ok and template and template.name == CROSSBOW_TEMPLATE
end

-- Viewmodel drop for the crossbow: ViewModelTweaker's PlayerUnitFirstPersonExtension update_unit_position hook
local VIEWMODEL_DROP = WEAPONS[1].viewmodel_drop

mod:hook("PlayerUnitFirstPersonExtension", "update_unit_position", function(func, self, unit, dt, t)
    func(self, unit, dt, t)

    local player = self._player

    if native_anims() or not (player and self._is_local_unit and player:is_human_controlled() and crossbow_wielded(self)) then
        return                                         -- the real aim animation already lines the sights up
    end

    local first_person_unit = self._first_person_unit
    local input_extension = ScriptUnit.extension(unit, "input_system")
    local yaw, pitch, roll = input_extension:get_orientation()
    local look_rotation = Quaternion.from_yaw_pitch_roll(yaw, pitch, roll)
    local position = Unit.local_position(first_person_unit, 1)

    Unit.set_local_position(first_person_unit, 1, position + Quaternion.rotate(look_rotation, Vector3(0, 0, -VIEWMODEL_DROP)))
    World.update_unit_and_children(self._world, first_person_unit)
end)

-- Bottom-right weapon icon -------------------------------------------------------------------------------------------
-- hud_element_player_weapon.lua:76-80 reads item.hud_icon into widget.content.icon, and the game's own icon for this weapon
-- is a blank placeholder. The drawn icon (assets/*.png, make_icons.py) is compiled into this mod's own Custom Assets build
-- as a texture (build_icon_units.py wraps it in a one-quad unit, Custom/hud_icon) and shown through ui_default_base, the
-- way QIangIQsSwordShield does. No SimpleAssets (user rule 2026-10-25: mods stand alone).
local ICON_ITEM = WEAPONS[1].item
local HUD_ICON_ASSET = "QIangIQsCrossbow:hud_icon"
local HUD_ICON_MATERIAL = "content/ui/materials/base/ui_default_base"
local HUD_ICON_TEXTURE = "content/mods/qiangiq_crossbow/hud_icon_material_1_bca"
local icon_ready = false

-- The handler destroys and recreates the element when the slot's weapon changes (hud_element_player_weapon_handler.lua:82)
mod:hook_safe(CLASS.HudElementPlayerWeapon, "init", function(self, parent, draw_layer, start_scale, data)
    self.__qiangiq_hud_icon = data and data.weapon_name == ICON_ITEM and not retail_icon.used
end)

-- The icon widget is a texture pass whose value is a material; ui_default_base takes the PNG as texture_map, the emote
-- wheel's way (hud_element_emote_wheel_definitions.lua:76-83). Without Custom Assets the donor's icon stays.
mod:hook_safe(CLASS.HudElementPlayerWeapon, "update", function(self)
    local widget = self.__qiangiq_hud_icon and icon_ready and self._widgets_by_name and self._widgets_by_name.icon

    if not widget then
        return
    end

    local style = widget.style.icon

    style.material_values = style.material_values or {}

    if widget.content.icon ~= HUD_ICON_MATERIAL or style.material_values.texture_map ~= HUD_ICON_TEXTURE then
        widget.content.icon = HUD_ICON_MATERIAL
        style.material_values.texture_map = HUD_ICON_TEXTURE
        widget.dirty = true
    end
end)

mod.update = function()
    poll()


    for unit in pairs(riding_bolts) do
        if not unit_ok(unit) then
            drop_riding_bolt(unit)
        end
    end
end

-- Custom Assets API 1, the QIangIQsShardStaff / QIangIQsScumHook acquire call
local function acquire_assets()
    local custom_assets = get_mod("CustomAssets")

    if not custom_assets or not custom_assets.is_api_compatible or not custom_assets.is_api_compatible(1) then
        mod:error("Custom Assets (API 1) is missing: the crossbow keeps a static clip and voidstrike-looking bolts")

        return
    end

    local function acquire(id, key)
        local ticket, err = custom_assets.acquire(mod, id, function(_, _, load_error)
            if load_error then
                mod:error("%s failed to load: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", id, tostring(load_error))

                return
            end

            assets_ready[key] = true

            if key == "icon" then
                icon_ready = true
            end
            mod:info("model %s loaded", id)

            if key == "bolt" then
                show_bolt_model()
            end
        end, { resident = true, reference_name = id })

        if not ticket then
            mod:error("%s could not be requested: %s", id, tostring(err))
        end
    end

    acquire(CLIP_ASSET, "clip")
    acquire(BOLT_ASSET, "bolt")
    acquire(HUD_ICON_ASSET, "icon")
end

mod.on_all_mods_loaded = function()
    add_to_unlock_list()
    acquire_assets()
end

mod.on_unload = function()
    local ok, cache = pcall(MasterItems.get_cached)

    for _, spec in ipairs(WEAPONS) do
        if ok and cache then
            cache[spec.item] = nil
            cache[BOLT_ITEM] = nil

            for part in pairs(spec.parts) do
                cache[attachment_name(spec, part)] = nil
            end
        end

        if state[spec.key].template_ours then
            WeaponTemplates[spec.template] = nil
        end
    end
end

-- Equip without the backend (QIangIQsShardStaff override): only where this client hosts ----------------------------
local function local_player()
    local players = Managers.player

    return players and players:local_player_safe(1)
end

local function equipped_item_name(player, slot)
    local unit = player and player.player_unit

    if not unit or not Unit.alive(unit) then
        return nil
    end

    local extension = ScriptUnit.has_extension(unit, "visual_loadout_system")
    local item = extension and extension:item_from_slot(slot)

    return item and item.name
end

local previous = {}

local function override(slot, item_name)
    local player = local_player()
    local sync = Managers.profile_synchronization
    local host = sync and sync:synchronizer_host()

    if not player then
        say("no local player")

        return false
    end

    if not host then
        say("not the host here. Use the Psykhanium, a SoloPlay game or a game you host")

        return false
    end

    host:override_slot(player:peer_id(), player:local_player_id(), slot, item_name)
    say("override_slot(%s, %s) sent", slot, tostring(item_name))

    return true
end

local function package_state(path)
    local ok, exists = pcall(Application.can_get_resource, "package", path)

    return ok and tostring(exists) or "?"
end

local function status()
    for _, spec in ipairs(WEAPONS) do
        local st = state[spec.key]

        say("%s: template %s (id %s, from %s), item %s (id %s, slot %s)", spec.key, tostring(st.template_ok),
            tostring(st.template_id), spec.source_template, tostring(st.item_ok), tostring(st.item_id), tostring(st.slot))

        for _, part in ipairs(PART_ORDER) do
            local def = spec.parts[part]

            if def then
                say("  %s package found: %s", part, package_state(def.unit))
            end
        end

        local rig = spec.base_unit or st.rig

        if rig then
            say("  rig %s package found: %s", rig, package_state(rig))
        end

        if spec.fires_bolts then
            say("  clip model %s, bolt model %s, projectile %s", tostring(assets_ready.clip), tostring(assets_ready.bolt),
                tostring(bolt_projectile and bolt_projectile.name))
        end

        if st.notes and #st.notes > 0 then
            say("  %s", table.concat(st.notes, "; "))
        end
    end
end

mod:command("crossbow", mod:localize("command_crossbow"), function(action)
    action = action or "status"

    if action == "status" then
        status()
    elseif action == "equip" then
        local spec = WEAPONS[1]
        local st = state[spec.key]

        if not (st.template_ok and st.item_ok and st.slot) then
            say("%s not ready yet (template %s, item %s)", spec.key, tostring(st.template_ok), tostring(st.item_ok))

            return
        end

        local player = local_player()

        previous[st.slot] = previous[st.slot] or (player and equipped_item_name(player, st.slot))
        override(st.slot, spec.item)
    elseif action == "restore" then
        local any = false

        for slot, item_name in pairs(previous) do
            if item_name and override(slot, item_name) then
                previous[slot] = nil
                any = true
            end
        end

        if not any then
            say("nothing to restore (equip first)")
        end
    else
        say("usage: /crossbow [status|equip|restore]")
    end
end)
