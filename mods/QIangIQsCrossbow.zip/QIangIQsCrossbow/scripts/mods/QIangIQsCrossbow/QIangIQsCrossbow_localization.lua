return {
    mod_name = {
        en = "QIangIQ's Crossbow",
    },
    mod_description = {
        en = "Adds the datamined Crossbow as a Zealot weapon, built from the unreleased retail models in the game files. The game has no weapon template for it yet, so it handles like the Bolt Pistol (boltpistol_p1_m1) but fires visible bolts at voidstrike projectile speed, its clip shows the bolts left, feeding upward (needs Custom Assets and CUSTOM_ASSETS_PATCH.bat), the string and latch cycle on every shot, it plays its own deep thunk (needs SimpleAudio), fires large trailed bolts from an 18-round clip, has no recoil climb, and its clip rides in the left hand on reloads. The bottom-right weapon icon shows the Crossbow (needs Custom Assets and CUSTOM_ASSETS_PATCH.bat). Pick it in Realms Loadout (/rl) or equip with /crossbow equip in the Psykhanium or a game you host. Everyone in the game needs this mod.",
    },
    command_crossbow = {
        en = "/crossbow [status|equip|restore]",
    },
    drawn_hud_icon = { en = "Use the drawn bottom-right icon (needs Custom Assets and a restart). Off = the game's own icon for this weapon, which is a blank placeholder" },
    add_to_unlock_list = { en = "List the Crossbow in the Zealot weapon unlock list (Realms Loadout reads it)" },
    unlock_level = { en = "Unlock level in that list (needs a restart)" },
    stagger_resistance_modifier = { en = "Bolt stagger: breed threshold multiplier (lower = heavier, needs a restart)" },
    native_animations = { en = "Use the crossbow's own animations (needs a restart; off = bolt pistol animations)" },
    reload_time = { en = "Crossbow reload time in seconds (needs a restart; match it to the reload animation)" },
    ragdoll_push_force = { en = "Bolt kill push force (needs a restart)" },
    retail_sounds = { en = "Use the game's own crossbow sounds (shot, aim, equip, reload, inspect)" },
    synth_audio = { en = "Use the old synthesised wav sounds instead (needs the SimpleAudio mod)" },
}

