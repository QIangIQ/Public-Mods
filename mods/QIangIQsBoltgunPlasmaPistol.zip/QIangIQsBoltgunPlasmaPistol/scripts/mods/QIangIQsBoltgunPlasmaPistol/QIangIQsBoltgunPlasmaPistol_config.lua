-- QIangIQsBoltgunPlasmaPistol per-weapon data (weapons\gen.py spec plasma). Clips are the Animations keys of BP_WeaponAnimations_PlasmaPistol.
-- Action names and kinds: Darktide weapon templates (Aussiemon master), read by gen.py actions_of.
return {
    ranged = true,
    idle = "Idle",
    templates = { plasmagun_p1_m1 = true, plasmagun_p1_m2 = true },
    actions = {
        action_charge = { clips = { "IdleHigh" }, loop = true },
        action_charge_direct = { clips = { "IdleHigh" }, loop = true },
        action_overheat_explode = { clips = { "FireOverheat" } },
        action_reload = { clips = { "Pickup" }, stretch = true, reload_template = true, tempo = true, sounds = { "WPN_SOB_PlasmaPistol_PickupAnim.ogg" } },
        action_shoot = { clips = { "Fire" }, over_shot = true, speed_to = 0.5, sounds = { "WPN_SOB_PlasmaPistol_Fire_Mid-001.ogg", "WPN_SOB_PlasmaPistol_Fire_Mid-002.ogg", "WPN_SOB_PlasmaPistol_Fire_Mid-003.ogg", "WPN_SOB_PlasmaPistol_Fire_Mid-004.ogg", "WPN_SOB_PlasmaPistol_Fire_Mid-005.ogg" } },
        action_shoot_charged = { clips = { "FireOverheat" }, over_shot = true, speed_to = 0.75, sounds = { "WPN_SOB_PlasmaPistol_Fire_High-001.ogg", "WPN_SOB_PlasmaPistol_Fire_High-002.ogg", "WPN_SOB_PlasmaPistol_Fire_High-003.ogg", "WPN_SOB_PlasmaPistol_Fire_High-004.ogg", "WPN_SOB_PlasmaPistol_Fire_High-005.ogg" } },
        action_vent = { clips = { "Vent" }, loop = true, sounds = { "WPN_SOB_PlasmaPistol_CoolDown.ogg" } },
        action_vent_override = { clips = { "Vent" }, loop = true, sounds = { "WPN_SOB_PlasmaPistol_CoolDown.ogg" } },
        action_wield = { clips = { "Pickup" }, tempo = true, speed_to = 1.0, sounds = { "WPN_SOB_PlasmaPistol_PickupAnim.ogg" } },
    },
}
