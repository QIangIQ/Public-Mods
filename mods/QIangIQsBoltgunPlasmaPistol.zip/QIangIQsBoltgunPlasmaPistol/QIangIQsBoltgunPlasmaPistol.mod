return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsBoltgunPlasmaPistol` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsBoltgunPlasmaPistol", {
            mod_script = "QIangIQsBoltgunPlasmaPistol/scripts/mods/QIangIQsBoltgunPlasmaPistol/QIangIQsBoltgunPlasmaPistol",
            mod_data = "QIangIQsBoltgunPlasmaPistol/scripts/mods/QIangIQsBoltgunPlasmaPistol/QIangIQsBoltgunPlasmaPistol_data",
            mod_localization = "QIangIQsBoltgunPlasmaPistol/scripts/mods/QIangIQsBoltgunPlasmaPistol/QIangIQsBoltgunPlasmaPistol_localization",
        })
    end,
    version = "0.1.0",
    author = "QIangIQ",
    packages = {},
}
