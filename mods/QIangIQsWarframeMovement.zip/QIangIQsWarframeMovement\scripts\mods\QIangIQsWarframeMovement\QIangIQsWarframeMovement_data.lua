local mod = get_mod("QIangIQsWarframeMovement")

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = false,
    options = {
        widgets = {
            { setting_id = "enabled", type = "checkbox", default_value = true,
                keybind_trigger = "pressed", keybind_type = "function_call", keybind_global = false, keybind_function_name = "toggle_enabled" },
            { setting_id = "bullet_jump", type = "checkbox", default_value = true },
            { setting_id = "bullet_jump_look_speed", type = "numeric", default_value = 14, range = { 6, 25 }, decimals_number = 1 },
            { setting_id = "bullet_jump_lift", type = "numeric", default_value = 0, range = { 0, 8 }, decimals_number = 1 },
            { setting_id = "double_jump", type = "checkbox", default_value = true },
            { setting_id = "air_jumps", type = "numeric", default_value = 1, range = { 1, 5 }, decimals_number = 0 },
            { setting_id = "double_jump_up", type = "numeric", default_value = 5, range = { 3, 10 }, decimals_number = 1 },
            { setting_id = "aim_glide", type = "checkbox", default_value = true },
            { setting_id = "glide_fall_speed", type = "numeric", default_value = 1.5, range = { 0.5, 6 }, decimals_number = 1 },
            { setting_id = "wall_run", type = "checkbox", default_value = true },
            { setting_id = "wall_run_speed", type = "numeric", default_value = 9, range = { 4, 16 }, decimals_number = 1 },
            { setting_id = "wall_run_time", type = "numeric", default_value = 2.5, range = { 0.5, 8 }, decimals_number = 1 },
            { setting_id = "wall_jump_out", type = "numeric", default_value = 6, range = { 2, 12 }, decimals_number = 1 },
            { setting_id = "wall_jump_up", type = "numeric", default_value = 6, range = { 3, 12 }, decimals_number = 1 },
            { setting_id = "slide_friction", type = "numeric", default_value = 40, range = { 0, 100 }, decimals_number = 0 },
            { setting_id = "no_fall_damage", type = "checkbox", default_value = true },
        },
    },
}
