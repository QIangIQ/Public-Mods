-- QIangIQ's Warframe Movement 0.1.0: bullet jump, double jump, aim glide, wall run / wall jump and a longer slide.
--
-- Built on the character-state hooks QIangIQsSourceMovement and QIangIQsRocketJump already use. Source lines (Aussiemon master):
--   * Jump launch = locomotion_steering.velocity_wanted set in PlayerCharacterStateJumping.on_enter (player_character_state_jumping.lua:88).
--   * Gravity is applied in script: Jumping.fixed_update subtracts gravity after _air_movement (:140); Falling lets the engine do it
--     while locomotion_steering.calculate_fall_velocity is true (falling.lua on_enter sets it, SourceMovement turns it off on ramps).
--   * Walking/sliding go to "jumping" on the jump press and leave crouch first (walking.lua:234-239, sliding.lua:246-251), so crouch
--     is read from the crouching input (default_ingame_input_settings.lua "crouching", key_alias crouch).
--   * Slide friction = PlayerCharacterConstants.slide_friction_function / sprint_slide_friction_function (player_character_constants.lua:273-293),
--     called from player_character_state_sliding.lua:190-203.
--   * No wall state exists in the state machine: wall run is a sideways raycast (PhysicsWorld.raycast, as QIangIQsSourceMovement ramp_normal)
--     while falling or jumping, with the wall-tangent velocity written back from _air_movement. Third person plays the falling animation.
-- Works where this client runs the unit's states: solo, Psykhanium, a game you host (the host also runs the states of Realms clients, who
-- would be corrected; clients are not covered in 0.1.0). Load after QIangIQsSourceMovement and QIangIQsRocketJump.
-- Author: QIangIQ
local mod = get_mod("QIangIQsWarframeMovement")

local Fall = require("scripts/extension_systems/character_state_machine/character_states/utilities/fall")
local PlayerCharacterConstants = require("scripts/settings/player_character/player_character_constants")

local session_on = true
local cache = {}

local function own(id)
    local v = cache[id]

    if v == nil then
        v = mod:get(id)
        cache[id] = v
    end

    return v
end

local function is_server()
    local game_session = Managers.state and Managers.state.game_session

    return game_session and game_session:is_server() or false
end

local function active(self)
    return session_on and own("enabled") ~= false and self._is_local_unit and self._is_server
end

local function flat_forward(rotation)
    return Vector3.normalize(Vector3.flat(Quaternion.forward(rotation)))
end

-- per unit
local air_jumps_used = {}
local wall = {}                    -- unit -> { normal, tangent, t0 }
local pending = {}                 -- unit -> { kind = "air" | "wall", normal = Vector3 }
local entered = {}                 -- unit -> gameplay time the jumping state was entered

local function wall_probe(self, unit, rotation)
    local physics_world = self._physics_world
    local position = self._locomotion_component.position + Vector3(0, 0, 0.9)
    local right = Quaternion.right(Quaternion.look(Vector3.flat(Quaternion.forward(rotation)), Vector3.up()))
    local best, best_d

    for _, sign in ipairs({ 1, -1 }) do
        local ok, hit, _, distance, normal = pcall(PhysicsWorld.raycast, physics_world, position, right * sign, 0.75, "closest",
            "collision_filter", "filter_player_mover")

        if ok and hit and normal and math.abs(normal.z) < 0.3 and (not best_d or distance < best_d) then
            best, best_d = normal, distance
        end
    end

    return best
end

local function ground_reset(unit)
    air_jumps_used[unit] = nil
    wall[unit] = nil
    pending[unit] = nil
end

for _, state_name in ipairs({ "PlayerCharacterStateWalking", "PlayerCharacterStateSprinting", "PlayerCharacterStateSliding", "PlayerCharacterStateLedgeVaulting" }) do
    mod:hook_safe(state_name, "on_enter", function(self, unit)
        ground_reset(unit)
    end)
end

-- Air movement: wall run, aim glide ------------------------------------------------------------------------------------
local function air_hook(func, self, velocity_current, x, y, rotation, move_speed, player_speed_scale, dt)
    local velocity = func(self, velocity_current, x, y, rotation, move_speed, player_speed_scale, dt)

    if not active(self) then
        return velocity
    end

    local unit = self._unit
    local steering = self._locomotion_steering_component
    local gravity = self._constants.gravity
    local t = Managers.time:time("gameplay")
    local input = self._input_extension

    -- wall run: hold jump and forward beside a wall
    if own("wall_run") ~= false then
        local run = wall[unit]
        local wants = input:get("jump_held") and y > 0.3 and velocity_current.z < 8

        if run and (not wants or t - run.t0 > (own("wall_run_time") or 2.5)) then
            wall[unit] = nil
            run = nil
        end

        if wants and (not run or t - run.t0 <= (own("wall_run_time") or 2.5)) then
            local normal = wall_probe(self, unit, rotation)

            if normal then
                if not run then
                    run = { t0 = t }
                    wall[unit] = run
                    air_jumps_used[unit] = nil                              -- a wall run gives the air jump back (Warframe)
                end

                run.normal = normal
            elseif run then
                wall[unit] = nil
                run = nil
            end
        end

        if run and run.normal then
            local forward = flat_forward(rotation)
            local tangent = forward - run.normal * Vector3.dot(forward, run.normal)
            local len = Vector3.length(tangent)

            if len > 0.01 then
                tangent = tangent * (1 / len)

                local speed = own("wall_run_speed") or 9
                local into = -run.normal * 1.0                                -- stay against the wall

                velocity = Vector3(tangent.x * speed + into.x, tangent.y * speed + into.y, self.name == "falling" and 0 or gravity * dt)   -- Jumping subtracts gravity after
                steering.calculate_fall_velocity = false
                run.tangent = tangent

                return velocity
            end
        end
    end

    -- aim glide: aiming while falling caps the fall speed
    if own("aim_glide") ~= false and self._alternate_fire_component and self._alternate_fire_component.is_active and velocity.z < 0 then
        local fall = -(own("glide_fall_speed") or 1.5)
        local z = math.max(velocity.z - gravity * dt, fall)

        if self.name == "falling" then
            steering.calculate_fall_velocity = false
            velocity = Vector3(velocity.x, velocity.y, z)
        else
            velocity = Vector3(velocity.x, velocity.y, math.max(velocity.z, fall + gravity * dt))   -- Jumping subtracts gravity after
        end
    elseif self.name == "falling" and not wall[unit] then
        steering.calculate_fall_velocity = true
    end

    return velocity
end

mod:hook("PlayerCharacterStateFalling", "_air_movement", air_hook)
mod:hook("PlayerCharacterStateJumping", "_air_movement", air_hook)

-- Air jump and wall jump: a jump press in the air -----------------------------------------------------------------------
local function air_transition(func, self, unit, t, next_state_params, input_source, ...)
    local next_state = func(self, unit, t, next_state_params, input_source, ...)

    if next_state ~= nil or not active(self) then
        return next_state
    end

    if not input_source:get("jump") or t - (entered[unit] or -1) < 0.15 then
        return next_state
    end

    local run = wall[unit]

    if run and run.normal and own("wall_run") ~= false then
        pending[unit] = { kind = "wall", normal = run.normal, tangent = run.tangent }
        wall[unit] = nil

        return "jumping"
    end

    if own("double_jump") ~= false and (air_jumps_used[unit] or 0) < (own("air_jumps") or 1) then
        air_jumps_used[unit] = (air_jumps_used[unit] or 0) + 1
        pending[unit] = { kind = "air" }

        return "jumping"
    end

    return next_state
end

mod:hook("PlayerCharacterStateFalling", "_check_transition", air_transition)
mod:hook("PlayerCharacterStateJumping", "_check_transition", air_transition)

-- Jump launch: bullet jump, air jump, wall jump --------------------------------------------------------------------------
mod:hook_safe("PlayerCharacterStateJumping", "on_enter", function(self, unit, dt, t, previous_state, params)
    if not active(self) then
        return
    end

    local steering = self._locomotion_steering_component
    local velocity = self._locomotion_component.velocity_current
    local rotation = self._first_person_component.rotation
    local jump = pending[unit]

    entered[unit] = t

    pending[unit] = nil

    if jump and jump.kind == "air" then
        steering.velocity_wanted = Vector3(velocity.x, velocity.y, own("double_jump_up") or 5)

        return
    end

    if jump and jump.kind == "wall" then
        local out = jump.normal * (own("wall_jump_out") or 6)
        local along = jump.tangent and jump.tangent * 4 or Vector3(0, 0, 0)

        steering.velocity_wanted = Vector3(out.x + along.x, out.y + along.y, own("wall_jump_up") or 6)
        air_jumps_used[unit] = nil

        return
    end

    if own("bullet_jump") ~= false and (previous_state == "sliding" or self._input_extension:get("crouching")) and previous_state ~= "ladder_climbing" then
        -- Warframe: the leap follows the camera exactly, straight up when looking up, down when looking down
        local direction = Quaternion.forward(rotation)
        local speed = own("bullet_jump_look_speed") or 14

        steering.velocity_wanted = direction * speed + Vector3(0, 0, own("bullet_jump_lift") or 0)
    end
end)

-- Slide: longer (friction scaled) -----------------------------------------------------------------------------------------
local original_slide = PlayerCharacterConstants.slide_friction_function
local original_sprint_slide = PlayerCharacterConstants.sprint_slide_friction_function

local function scaled(original)
    return function(...)
        local value = original(...)

        if session_on and own("enabled") ~= false then
            return value * (own("slide_friction") or 40) / 100
        end

        return value
    end
end

PlayerCharacterConstants.slide_friction_function = scaled(original_slide)
PlayerCharacterConstants.sprint_slide_friction_function = scaled(original_sprint_slide)

mod.on_unload = function()
    PlayerCharacterConstants.slide_friction_function = original_slide
    PlayerCharacterConstants.sprint_slide_friction_function = original_sprint_slide
end

mod:hook(Fall, "check_damage", function(func, unit, ...)
    if own("no_fall_damage") ~= false and session_on and own("enabled") ~= false and is_server() then
        local player = Managers.player and Managers.player:local_player_safe(1)

        if player and player.player_unit == unit then
            return
        end
    end

    return func(unit, ...)
end)

mod.on_setting_changed = function()
    cache = {}
end

mod.toggle_enabled = function()
    session_on = not session_on
    mod:echo("Warframe movement %s for this session", session_on and "on" or "off")
end

mod:command("wfmove", "Warframe movement: /wfmove toggles it for this session", function()
    mod.toggle_enabled()
end)
