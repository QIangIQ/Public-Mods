return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsWarframeMovement` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsWarframeMovement", {
            mod_script = "QIangIQsWarframeMovement/scripts/mods/QIangIQsWarframeMovement/QIangIQsWarframeMovement",
            mod_data = "QIangIQsWarframeMovement/scripts/mods/QIangIQsWarframeMovement/QIangIQsWarframeMovement_data",
            mod_localization = "QIangIQsWarframeMovement/scripts/mods/QIangIQsWarframeMovement/QIangIQsWarframeMovement_localization",
        })
    end,
    version = "0.1.0",
    author = "QIangIQ",
    packages = {},
}
