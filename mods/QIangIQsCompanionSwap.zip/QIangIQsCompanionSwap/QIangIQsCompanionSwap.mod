return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsCompanionSwap` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsCompanionSwap", {
            mod_script = "QIangIQsCompanionSwap/scripts/mods/QIangIQsCompanionSwap/QIangIQsCompanionSwap",
            mod_data = "QIangIQsCompanionSwap/scripts/mods/QIangIQsCompanionSwap/QIangIQsCompanionSwap_data",
            mod_localization = "QIangIQsCompanionSwap/scripts/mods/QIangIQsCompanionSwap/QIangIQsCompanionSwap_localization",
        })
    end,
    version = "1.1.4",
    author = "QIangIQ",
    packages = {},
}
