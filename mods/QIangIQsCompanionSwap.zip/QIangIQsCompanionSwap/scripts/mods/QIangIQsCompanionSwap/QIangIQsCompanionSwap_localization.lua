return {
    mod_name = {
        en = "QIangIQ's Companion Swap",
    },
    mod_description = {
        en = "Shows one of the game's own cutscene characters (the zealots and others from the cinematics and the prologue) in place of your Arbites dog. The dog still does everything; only its look changes. The character walks, jogs and sprints with the hub's animations. Only on your own screen. Chat command: /companionswap. By QIangIQ.",
    },
    swap_dog = {
        en = "Replace my dog",
    },
    swap_dog_description = {
        en = "Hides your Arbites dog and shows the chosen character where it is.",
    },
    npc_profile = {
        en = "Character",
    },
    npc_profile_description = {
        en = "The game's own characters from its cinematics (\"Darktide Seven\") and the prologue tutorial.",
    },
    npc_darktide_seven_06 = { en = "Zealot (male, cinematic)" },
    npc_darktide_seven_03 = { en = "Zealot (female, cinematic)" },
    npc_tutorial_guide_zealot = { en = "Jilande (zealot, prologue)" },
    npc_tutorial_guide = { en = "Zola (prologue)" },
    npc_tutorial_guide_ogryn = { en = "Kreft (ogryn, prologue)" },
    npc_darktide_seven_01 = { en = "Veteran (male, cinematic)" },
    npc_darktide_seven_05 = { en = "Veteran (female, cinematic)" },
    npc_darktide_seven_04 = { en = "Psyker (male, cinematic)" },
    npc_darktide_seven_07 = { en = "Psyker (female, cinematic)" },
    npc_darktide_seven_02 = { en = "Ogryn (cinematic)" },
    npc_attacks = {
        en = "Attack while the dog pins an enemy",
    },
    npc_attacks_description = {
        en = "While your dog holds an enemy down, the character draws their melee weapon and swings at it (looks only; the dog still does the damage).",
    },
    npc_crouch = {
        en = "Crouch while attacking",
    },
    npc_crouch_description = {
        en = "The character crouches over the enemy the dog holds down while swinging at it.",
    },
    npc_scale = {
        en = "Size",
    },
    npc_scale_description = {
        en = "1 = normal size.",
    },
    toggle_keybind = {
        en = "Toggle the swap",
    },
}
