-- QIangIQ's Companion Swap: shows one of the game's own cutscene / tutorial characters (the "Darktide Seven",
-- Zola, Jilande, Kreft) in place of your Arbites dog. The dog keeps doing everything (following, pouncing,
-- pinning); only what you see changes. Local player only, in missions and the hub.
-- Author: QIangIQ
local mod = get_mod("QIangIQsCompanionSwap")

local MasterItems = require("scripts/backend/master_items")
local ProfileUtils = require("scripts/utilities/profile_utils")
local UIProfileSpawner = require("scripts/managers/ui/ui_profile_spawner")
local UiUnitSpawner = require("scripts/managers/ui/ui_unit_spawner")
local WeaponTemplate = require("scripts/utilities/weapon/weapon_template")
local WeaponTemplates = require("scripts/settings/equipment/weapon_templates/weapon_templates")
local HubMovementSettingsTemplates = require("scripts/settings/player_character/hub_movement_settings_templates")

mod.AUTHOR = "QIangIQ"

local DOG_BREED = "companion_dog"                 -- archetype.companion_breed (player_unit_visual_loadout_extension.lua:207)
local COMPANION_SLOT = "slot_companion_gear_full" -- ui_profile_spawner.lua:24, equipment_component.lua:262-264
local PACKAGE_REFERENCE = "QIangIQsCompanionSwap"
-- the ranged weapon of the bot profiles is not spawned (cutscene_character_extension.lua: ignore_slot); the melee
-- weapon is spawned but only shown while the dog pins an enemy
local IGNORED_SLOTS = { "slot_secondary" }
local MELEE_SLOT = "slot_primary"

-- Bot profiles (scripts/settings/bot_profiles/*.lua) used by the game's cinematics and tutorial
local PROFILES = {
    darktide_seven_06 = true, -- zealot, male (Darktide Seven)
    darktide_seven_03 = true, -- zealot, female (Darktide Seven)
    tutorial_guide_zealot = true, -- Jilande, zealot (prologue)
    tutorial_guide = true, -- Zola, veteran (prologue)
    tutorial_guide_ogryn = true, -- Kreft, ogryn (prologue)
    darktide_seven_01 = true, -- veteran, male
    darktide_seven_05 = true, -- veteran, female
    darktide_seven_04 = true, -- psyker, male
    darktide_seven_07 = true, -- psyker, female
    darktide_seven_02 = true, -- ogryn
}

-- the hub's unarmed locomotion (player_character_constants.lua hub_movement.move_method_anims,
-- player_character_state_hub_jog.lua move_state_anim_events)
local START_EVENT = "start_0"
local MOVE_EVENTS = { walk = "to_walk", jog = "to_jog", sprint = "to_sprint" }
local STOP_EVENTS = { walk = "idle_walk", jog = "idle_jog", sprint = "idle_sprint" }

local mod_on = true
local tracked = setmetatable({}, { __mode = "k" }) -- PlayerUnitVisualLoadoutExtension -> record
local packages = {}
local npc_units = setmetatable({}, { __mode = "k" }) -- the NPC character units (flow callback guard below)
local pinning = setmetatable({}, { __mode = "k" })  -- dog unit -> true while it pins / pounces an enemy

local function unit_ok(unit)
    -- only units: "rec.pinned and rec.pin_target" can be false (1.1.3 error in the Psykhanium)
    return type(unit) == "userdata" and Unit.alive(unit)
end

local function local_player()
    local players = Managers.player
    if not players then
        return nil
    end
    local ok, player = pcall(players.local_player_safe, players, 1)
    return ok and player or nil
end

local function enabled()
    return mod_on and mod:get("swap_dog") ~= false
end

local function chosen_profile()
    local id = mod:get("npc_profile") or "darktide_seven_06"
    return PROFILES[id] and id or "darktide_seven_06"
end

-- Packages ----------------------------------------------------------------------------
-- A state machine's resource name is the name of its package (as QIangIQsEmotes: weapon_template_resource_dependencies.lua,
-- package_synchronizer_client.lua:560).
local function with_package(name, fn)
    local entry = packages[name]
    if entry and entry.loaded then
        fn()
        return
    end
    if not entry then
        if not Application.can_get_resource("package", name) then
            mod:error("Companion Swap: the package %s does not exist in this game version.", name)
            return
        end
        entry = { loaded = false, waiting = { fn } }
        packages[name] = entry
        entry.id = Managers.package:load(name, PACKAGE_REFERENCE, function()
            entry.loaded = true
            local waiting = entry.waiting
            entry.waiting = {}
            for i = 1, #waiting do
                waiting[i]()
            end
        end)
        return
    end
    entry.waiting[#entry.waiting + 1] = fn
end

local function release_packages()
    for name, entry in pairs(packages) do
        if entry.id and Managers.package then
            Managers.package:release(entry.id)
        end
        packages[name] = nil
    end
end

-- the hub's unarmed state machine of the breed (game_mode_settings_hub.lua, QIangIQsEmotes hub_template)
local function hub_state_machine(breed_name)
    local template = WeaponTemplates[breed_name == "ogryn" and "unarmed_hub_ogryn" or "unarmed_hub_human"]
    local state_machine_3p = template and WeaponTemplate.state_machines(template, breed_name)
    return state_machine_3p
end

-- Spawn / despawn -------------------------------------------------------------------------

local function destroy_record(rec, restore_dog)
    if not rec then
        return
    end
    if rec.spawner then
        pcall(rec.spawner.destroy, rec.spawner)
        rec.spawner = nil
    end
    if restore_dog and rec.hid and unit_ok(rec.dog) then
        Unit.set_unit_visibility(rec.dog, true, true)
        if rec.attachments then
            for i = 1, #rec.attachments do
                if unit_ok(rec.attachments[i]) then
                    Unit.set_unit_visibility(rec.attachments[i], true, true)
                end
            end
        end
    end
end

local function start_spawn(ext, rec, dog)
    local profile_id = chosen_profile()
    local profile = ProfileUtils.get_bot_profile(profile_id)
    if not profile then
        mod:error("Companion Swap: bot profile %s not found.", profile_id)
        return
    end
    -- the character mods (ui_profile_is_mine) leave this profile alone
    profile.__qiangiq_npc = true
    local breed_name = profile.archetype and profile.archetype.breed or "human"
    local state_machine = hub_state_machine(breed_name)
    -- the melee weapon's third-person state machine (weapon_template.anim_state_machine_3p, via WeaponTemplate.state_machines)
    local melee_item = profile.loadout and profile.loadout[MELEE_SLOT]
    local melee_template = melee_item and melee_item.weapon_template and WeaponTemplates[melee_item.weapon_template]
    if melee_template then
        local sm_3p, _, init_vars = WeaponTemplate.state_machines(melee_template, breed_name)
        rec.weapon_sm, rec.weapon_init_vars = sm_3p, init_vars
        if sm_3p then
            with_package(sm_3p, function()
                rec.weapon_sm_ready = true
            end)
        end
    end
    rec.hub_sm = state_machine
    rec.profile_id = profile_id
    rec.breed_name = breed_name
    rec.loading = true
    local function spawn()
        if tracked[ext] ~= rec or not unit_ok(dog) then
            return
        end
        local world = ext.__qiangiq_cswap_world
        if not world then
            return
        end
        local mission_manager = Managers.state and Managers.state.mission
        local mission_template = mission_manager and mission_manager:mission()
        -- same construction as cutscene_character_extension.lua:40-45
        local unit_spawner = UiUnitSpawner:new(world)
        local spawner = UIProfileSpawner:new("QIangIQsCompanionSwap", world, nil, unit_spawner, false, mission_template)
        for i = 1, #IGNORED_SLOTS do
            spawner:ignore_slot(IGNORED_SLOTS[i])
        end
        local position = Unit.world_position(dog, 1)
        local rotation = Unit.world_rotation(dog, 1)
        local face_state_machine_key = mission_template and mission_template.face_state_machine_key
        local companion_data = { ignore = true }
        spawner:spawn_profile(profile, position, rotation, nil, state_machine, nil, face_state_machine_key, nil, false, false, nil, nil, companion_data)
        rec.spawner = spawner
        rec.loading = false
    end
    if state_machine then
        with_package(state_machine, spawn)
    else
        spawn()
    end
end

local function hide_dog(rec)
    Unit.set_unit_visibility(rec.dog, false, true)
    if rec.attachments then
        for i = 1, #rec.attachments do
            if unit_ok(rec.attachments[i]) then
                Unit.set_unit_visibility(rec.attachments[i], false, true)
            end
        end
    end
    rec.hid = true
end

local function play(unit, event)
    if event and Unit.has_animation_event(unit, event) then
        Unit.animation_event(unit, event)
        return true
    end
    return false
end

-- walk / jog / sprint from the dog's ground speed, with the hub's speeds (hub_movement_settings_templates.lua)
local function move_state_for(speed, breed_name)
    local t = HubMovementSettingsTemplates[breed_name == "ogryn" and "ogryn" or "human"]
    local walk = t and t.walk and t.walk.move_speed or 1.6
    local jog = t and t.jog and t.jog.move_speed or 3.5
    local sprint = t and t.sprint and t.sprint.move_speed or 5.6
    if speed > (jog + sprint) * 0.5 then
        return "sprint"
    elseif speed > (walk + jog) * 0.5 then
        return "jog"
    end
    return "walk"
end

local IDLE_SPEED = 0.35
local MOVE_SPEED = 0.6

local function animate(rec, unit, dt)
    local pos = Unit.world_position(rec.dog, 1)
    local speed = 0
    if rec.last_x and dt and dt > 0 then
        local dx, dy = pos.x - rec.last_x, pos.y - rec.last_y
        speed = math.sqrt(dx * dx + dy * dy) / dt
        if speed > 30 then
            speed = 0 -- teleported
        end
    end
    rec.last_x, rec.last_y = pos.x, pos.y
    -- smoothed so single-frame jitters do not start and stop the walk
    rec.speed = (rec.speed or 0) + (speed - (rec.speed or 0)) * math.min(1, (dt or 0.016) * 6)
    local s = rec.speed
    -- The hub's walk / jog / sprint loops are driven by the "anim_move_speed" variable, which the game sets every
    -- frame from the body's velocity (player_unit_locomotion_extension.lua:905-911: lerp(old, speed, dt * 10), clamped
    -- 0..19.9). Without it the loop played at speed 0: legs still while the body slid along (1.0.1 report).
    if rec.speed_var == nil then
        rec.speed_var = Unit.animation_find_variable(unit, "anim_move_speed") or false
        rec.direction_var = Unit.animation_find_variable(unit, "movement_direction") or false
    end
    if rec.speed_var then
        local old = Unit.animation_get_variable(unit, rec.speed_var) or 0
        local new = old + (speed - old) * math.min(1, (dt or 0.016) * 10)
        Unit.animation_set_variable(unit, rec.speed_var, math.max(0, math.min(new, 19.9)))
    end
    if rec.direction_var then
        -- third_person_hub_movement_direction_animation_control.lua: lean into turns (-1..1); 0 = straight
        Unit.animation_set_variable(unit, rec.direction_var, 0)
    end
    if not rec.moving and s > MOVE_SPEED then
        rec.moving = true
        rec.move_state = move_state_for(s, rec.breed_name)
        play(unit, START_EVENT)
        play(unit, MOVE_EVENTS[rec.move_state])
    elseif rec.moving and s < IDLE_SPEED then
        rec.moving = false
        play(unit, STOP_EVENTS[rec.move_state or "walk"])
    elseif rec.moving then
        local state = move_state_for(s, rec.breed_name)
        if state ~= rec.move_state then
            rec.move_state = state
            play(unit, MOVE_EVENTS[state])
        end
    end
end

-- The hub state machine has head / chest aim constraints that the game points along the camera every frame
-- (hub_aim_constraints.lua; names from player_character_social_hub_unit_template.lua:216-219). Nothing aims them for
-- the NPC, so their targets stayed wherever they were and twisted the torso (1.0.2 report). Weights to 0 and both
-- targets straight ahead of the character, at head / chest height.
local AIM_TARGETS = { { "aim_constraint_target", 1.6 }, { "aim_constraint_target_torso", 1.2 } }
local AIM_WEIGHTS = { "head_aim_weight", "chest_aim_weight" }

local function straighten_aim(rec, unit, s)
    if rec.aim_ids == nil then
        rec.aim_ids, rec.weight_ids = {}, {}
        for i = 1, #AIM_TARGETS do
            local ok, index = pcall(Unit.animation_find_constraint_target, unit, AIM_TARGETS[i][1])
            rec.aim_ids[i] = ok and index or false
        end
        for i = 1, #AIM_WEIGHTS do
            rec.weight_ids[i] = Unit.animation_find_variable(unit, AIM_WEIGHTS[i]) or false
        end
    end
    for i = 1, #rec.weight_ids do
        if rec.weight_ids[i] and not rec.pinned then
            Unit.animation_set_variable(unit, rec.weight_ids[i], 0)
        end
    end
    local pos = Unit.world_position(rec.dog, 1)
    local forward = Quaternion.forward(Unit.world_rotation(rec.dog, 1))
    local enemy = rec.pinned and rec.pin_target
    for i = 1, #rec.aim_ids do
        if rec.aim_ids[i] then
            local target
            if unit_ok(enemy) then
                -- while pinning: look down at the pinned enemy. The weapon state machines aim with this one target,
                -- placed 5 m (PLAYER_AIM_CONSTRAINT_DISTANCE) from head height along the aim direction
                -- (player_husk_aim_extension.lua:45-54, player_character_unit_template.lua:12, 217)
                local height = AIM_TARGETS[i][2] * (rec.crouched and 0.65 or 1)
                local head = Unit.world_position(unit, 1) + Vector3(0, 0, height * s)
                local goal = Unit.world_position(enemy, 1) + Vector3(0, 0, 0.3)
                target = head + Vector3.normalize(goal - head) * 5
            else
                target = pos + Vector3(0, 0, AIM_TARGETS[i][2] * s) + forward * 5
            end
            Unit.animation_set_constraint_target(unit, rec.aim_ids[i], target)
        end
    end
end

-- Attacks while the dog pins an enemy: the weapon's own third-person state machine (swing events from the weapon
-- template actions, thunderhammer_2h_p1_m1.lua anim_event / anim_event_3p), charge pose then swing, left and right.
local ATTACKS = {
    { "attack_swing_charge_left_pose", "attack_swing_left_diagonal" },
    { "attack_swing_charge_right_pose", "attack_swing_right_diagonal" },
    { "attack_swing_charge_left_pose", "attack_swing_heavy_left" },
    { "attack_swing_charge_right_pose", "attack_swing_heavy_right" },
}
local CHARGE_TIME = 0.35
local SWING_TIME = 1.0
local PIN_BACK_OFFSET = 0.8 -- the character stands this far behind the dog's spot, facing the pinned enemy

-- Weapon actions play their third-person event with the variables "attack_speed" (the action's time scale, 1 = normal)
-- and "action_time_offset" (action_base.lua:75-78: anim_event_with_variable_floats). Left at 0 the attack played at
-- speed 0 and only jumped a frame on the next event (1.1.0 report).
local function play_attack(rec, unit, event)
    if not (event and Unit.has_animation_event(unit, event)) then
        return false
    end
    if rec.attack_speed_var == nil then
        rec.attack_speed_var = Unit.animation_find_variable(unit, "attack_speed") or false
        rec.attack_offset_var = Unit.animation_find_variable(unit, "action_time_offset") or false
    end
    if rec.attack_speed_var then
        Unit.animation_set_variable(unit, rec.attack_speed_var, 1)
    end
    if rec.attack_offset_var then
        Unit.animation_set_variable(unit, rec.attack_offset_var, 0)
    end
    Unit.animation_event(unit, event)
    return true
end

local function reset_anim_cache(rec)
    rec.speed_var, rec.direction_var, rec.aim_ids, rec.weight_ids = nil, nil, nil, nil
    rec.attack_speed_var, rec.attack_offset_var = nil, nil
end

-- third-person half of PlayerUnitAnimationState.set_anim_state_machine (player_unit_animation_state.lua:41-55,
-- 111-128), as QIangIQsEmotes set_state_machine_3p
local function switch_state_machine(rec, unit, state_machine, init_vars)
    Unit.set_animation_state_machine_blend_base_layer(unit, state_machine, 0.2)
    if init_vars then
        for variable_name, value in pairs(init_vars) do
            local variable_id = Unit.animation_find_variable(unit, variable_name)
            if variable_id then
                Unit.animation_set_variable(unit, variable_id, type(value) == "function" and value(unit) or value)
            end
        end
    end
    reset_anim_cache(rec)
end

local function show_weapon(rec, visible)
    local weapon = rec.spawner and rec.spawner:unit_3p_from_slot(MELEE_SLOT)
    if unit_ok(weapon) then
        Unit.set_unit_visibility(weapon, visible, true)
    end
end

-- Nearest live enemy to the dog (Managers.state.minion_spawn:spawned_minions(), as TF2ExampleMod backfill_live_minions)
local function nearest_enemy(dog, max_distance)
    local spawn_manager = Managers.state and Managers.state.minion_spawn
    if not (spawn_manager and spawn_manager.spawned_minions) then
        return nil
    end
    local ok, minions = pcall(spawn_manager.spawned_minions, spawn_manager)
    if not ok or type(minions) ~= "table" then
        return nil
    end
    local p = Unit.world_position(dog, 1)
    local best, best_d = nil, max_distance * max_distance
    for i = 1, #minions do
        local m = minions[i]
        if m ~= dog and unit_ok(m) then
            local q = Unit.world_position(m, 1)
            local dx, dy, dz = q.x - p.x, q.y - p.y, q.z - p.z
            local d = dx * dx + dy * dy
            if d < best_d and math.abs(dz) < 1.5 then
                best, best_d = m, d
            end
        end
    end
    return best
end

-- Pinned = the dog's pounce actions are running (only seen where its behaviour tree runs: solo / host), or, for a
-- client of a Fatshark server, the dog has stopped right at a live enemy for PIN_HOLD seconds.
local PIN_RANGE = 1.3
local PIN_RELEASE_RANGE = 1.9
local PIN_HOLD = 0.35

local function detect_pin(rec, t)
    if pinning[rec.dog] then
        rec.pin_target = nearest_enemy(rec.dog, PIN_RELEASE_RANGE)
        return true
    end
    if rec.pinned then
        local target = rec.pin_target
        if unit_ok(target) then
            local a, b = Unit.world_position(rec.dog, 1), Unit.world_position(target, 1)
            local dx, dy = a.x - b.x, a.y - b.y
            if dx * dx + dy * dy < PIN_RELEASE_RANGE * PIN_RELEASE_RANGE then
                return true
            end
        end
        rec.pin_since = nil
        return false
    end
    local target = (rec.speed or 0) < 0.8 and nearest_enemy(rec.dog, PIN_RANGE) or nil
    if not target then
        rec.pin_since = nil
        return false
    end
    rec.pin_since = rec.pin_since or t
    rec.pin_target = target
    return t - rec.pin_since >= PIN_HOLD
end

local function update_pin(rec, unit, t)
    local want = detect_pin(rec, t) and rec.weapon_sm_ready and mod:get("npc_attacks") ~= false
    if want and not rec.pinned then
        rec.pinned = true
        rec.moving = false
        pcall(rec.spawner.wield_slot, rec.spawner, MELEE_SLOT)
        switch_state_machine(rec, unit, rec.weapon_sm, rec.weapon_init_vars)
        -- crouched over the pinned enemy: the weapon state machines' crouch layer (crouch.lua:53, "to_crouch")
        rec.crouched = mod:get("npc_crouch") ~= false and play(unit, "to_crouch")
        rec.attack_index, rec.attack_phase, rec.attack_t = 0, "charge", t + 0.15
    elseif not want and rec.pinned then
        rec.pinned = false
        if rec.crouched then
            play(unit, "to_uncrouch") -- crouch.lua:69
            rec.crouched = false
        end
        switch_state_machine(rec, unit, rec.hub_sm, nil)
    end
    show_weapon(rec, rec.pinned and true or false)
    if not rec.pinned or t < rec.attack_t then
        return
    end
    if rec.attack_phase == "charge" then
        rec.attack_index = rec.attack_index % #ATTACKS + 1
        play_attack(rec, unit, ATTACKS[rec.attack_index][1])
        rec.attack_phase, rec.attack_t = "swing", t + CHARGE_TIME
    else
        play_attack(rec, unit, ATTACKS[rec.attack_index][2])
        rec.attack_phase, rec.attack_t = "charge", t + SWING_TIME
    end
end

-- the character stands where the dog is and faces where it faces; while pinning, it stands just off the pinned
-- enemy (on the dog's side) and faces it. Scale from the option.
local function place(rec, unit)
    local position = Unit.world_position(rec.dog, 1)
    local rotation = Unit.world_rotation(rec.dog, 1)
    if rec.pinned then
        local target = rec.pin_target
        if unit_ok(target) then
            local tp = Unit.world_position(target, 1)
            local away = Vector3(position.x - tp.x, position.y - tp.y, 0)
            if Vector3.length(away) < 0.05 then
                away = -Quaternion.forward(rotation)
                away = Vector3(away.x, away.y, 0)
            end
            away = Vector3.normalize(away)
            position = Vector3(tp.x, tp.y, position.z) + away * PIN_BACK_OFFSET
            rotation = Quaternion.look(-away, Vector3(0, 0, 1))
        else
            position = position - Quaternion.forward(rotation) * PIN_BACK_OFFSET
        end
    end
    Unit.set_local_position(unit, 1, position)
    Unit.set_local_rotation(unit, 1, rotation)
    local s = mod:get("npc_scale") or 1
    if rec.scale ~= s then
        rec.scale = s
        Unit.set_local_scale(unit, 1, Vector3(s, s, s))
    end
    straighten_aim(rec, unit, s)
end

local function apply(ext, dt, t)
    local owner = ext._unit
    -- same lookup as equipment_component.lua:228-230
    local spawner_ext = unit_ok(owner) and ScriptUnit.has_extension(owner, "companion_spawner_system")
    local companion_units = spawner_ext and spawner_ext:companion_units()
    local dog = companion_units and #companion_units > 0 and companion_units[1] or nil
    local rec = tracked[ext]
    local want = enabled() and unit_ok(dog)
    if rec and (not want or rec.dog ~= dog or rec.profile_id ~= chosen_profile() and not rec.loading) then
        destroy_record(rec, true)
        tracked[ext] = nil
        rec = nil
    end
    if not want then
        return
    end
    if not rec then
        rec = { dog = dog }
        tracked[ext] = rec
        start_spawn(ext, rec, dog)
    end
    local slot = ext._equipment and ext._equipment[COMPANION_SLOT]
    rec.attachments = slot and slot.attachments_by_unit_3p and slot.attachments_by_unit_3p[dog]
    local spawner = rec.spawner
    if not spawner then
        return
    end
    spawner:update(dt, t, nil)
    local unit = spawner:spawned_character_unit()
    if unit_ok(unit) then
        npc_units[unit] = true
    end
    if unit_ok(unit) and spawner:spawned() then
        update_pin(rec, unit, t)
        place(rec, unit)
        if not rec.pinned then
            animate(rec, unit, dt)
        end
        hide_dog(rec)
    end
end

-- Hooks ---------------------------------------------------------------------------------

-- The hub animations trigger the player's own flow events (footsteps, foley, voice). Their callbacks read the
-- unit's player extensions (flow_callbacks.lua:703-705 _should_play_player_fx: ScriptUnit.extension(unit,
-- "first_person_system")), which the NPC does not have: that was a crash to desktop in 1.0.0. They are skipped
-- for the NPC (and for any unit without a first-person extension, which would fail the same way).
-- Hooked like Realms/workarounds/gameplay_time_scale.lua does (require + mod:hook).
local FlowCallbacks = require("scripts/script_flow_nodes/flow_callbacks")
local EMPTY_RETURN = {}

-- same lookup as flow_callbacks.lua _player_fx_source_and_extension_unit
local function flow_extension_unit(params)
    local first_person_unit = params and params.first_person_unit
    if first_person_unit then
        return Unit.get_data(first_person_unit, "owner_unit")
    end
    return params and params.unit
end

local function skip_player_flow(params)
    local unit = flow_extension_unit(params)
    if unit == nil then
        return false
    end
    if npc_units[unit] then
        return true
    end
    return not ScriptUnit.has_extension(unit, "first_person_system")
end

for _, name in ipairs({ "player_footstep", "player_fx", "player_inventory_event", "player_inventory_fx", "player_voice" }) do
    if type(FlowCallbacks[name]) == "function" then
        mod:hook(FlowCallbacks, name, function(func, params, ...)
            if skip_player_flow(params) then
                table.clear(EMPTY_RETURN)
                return EMPTY_RETURN
            end
            return func(params, ...)
        end)
    end
end

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "init", function(self, extension_init_context, unit, extension_init_data)
    self.__qiangiq_cswap_world = extension_init_context and extension_init_context.world
    local archetype = extension_init_data and extension_init_data.archetype
    self.__qiangiq_cswap_breed = archetype and archetype.companion_breed
end)

-- PlayerUnitVisualLoadoutExtension.update = function (self, unit, dt, t)
mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "update", function(self, unit, dt, t)
    if self.__qiangiq_cswap_breed ~= DOG_BREED or self._player ~= local_player() then
        return
    end
    local ok, err = pcall(apply, self, dt, t)
    if not ok then
        mod:error("Companion Swap: %s", tostring(err))
        destroy_record(tracked[self], true)
        tracked[self] = nil
        mod_on = false
    end
end)

-- The dog's pounce / pin actions (bt_companion_target_pounced_action.lua, bt_companion_target_pounce_and_escape_action.lua;
-- hooked the same way as SimplySimpleDogReplacer/Modules/Animation.lua:1011-1083). unit = the dog.
for _, class_name in ipairs({ "BtCompanionTargetPouncedAction", "BtCompanionTargetPounceAndEscapeAction" }) do
    mod:hook_safe(class_name, "enter", function(self, unit)
        pinning[unit] = true
    end)
    mod:hook_safe(class_name, "leave", function(self, unit)
        pinning[unit] = nil
    end)
end

mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, "destroy", function(func, self, ...)
    destroy_record(tracked[self], false)
    tracked[self] = nil
    return func(self, ...)
end)

-- Options -------------------------------------------------------------------------------

local function remove_all(restore)
    for ext, rec in pairs(tracked) do
        destroy_record(rec, restore)
        tracked[ext] = nil
    end
end

mod.toggle_swap = function()
    local on = not (mod:get("swap_dog") ~= false)
    mod:set("swap_dog", on, true)
    mod:echo("Companion Swap %s", on and "on" or "off")
end

mod:command("companionswap", "Toggle the cutscene character in place of your Arbites dog", function()
    mod.toggle_swap()
end)

mod.on_setting_changed = function(setting_id)
    if setting_id == "swap_dog" and mod:get("swap_dog") == false then
        remove_all(true)
    end
end

mod.on_disabled = function()
    mod_on = false
    remove_all(true)
end

mod.on_enabled = function()
    mod_on = true
end

mod.on_unload = function()
    remove_all(false)
    release_packages()
end
