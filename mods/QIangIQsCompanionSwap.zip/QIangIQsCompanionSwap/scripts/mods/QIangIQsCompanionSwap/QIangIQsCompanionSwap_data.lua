local mod = get_mod("QIangIQsCompanionSwap")

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = true,
    options = {
        widgets = {
            {
                setting_id = "swap_dog",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "npc_profile",
                type = "dropdown",
                default_value = "darktide_seven_06",
                options = {
                    { text = "npc_darktide_seven_06", value = "darktide_seven_06" },
                    { text = "npc_darktide_seven_03", value = "darktide_seven_03" },
                    { text = "npc_tutorial_guide_zealot", value = "tutorial_guide_zealot" },
                    { text = "npc_tutorial_guide", value = "tutorial_guide" },
                    { text = "npc_tutorial_guide_ogryn", value = "tutorial_guide_ogryn" },
                    { text = "npc_darktide_seven_01", value = "darktide_seven_01" },
                    { text = "npc_darktide_seven_05", value = "darktide_seven_05" },
                    { text = "npc_darktide_seven_04", value = "darktide_seven_04" },
                    { text = "npc_darktide_seven_07", value = "darktide_seven_07" },
                    { text = "npc_darktide_seven_02", value = "darktide_seven_02" },
                },
            },
            {
                setting_id = "npc_attacks",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "npc_crouch",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "npc_scale",
                type = "numeric",
                default_value = 1,
                range = { 0.5, 1.5 },
                decimals_number = 2,
            },
            {
                setting_id = "toggle_keybind",
                type = "keybind",
                default_value = {},
                keybind_trigger = "pressed",
                keybind_type = "function_call",
                function_name = "toggle_swap",
            },
        },
    },
}
