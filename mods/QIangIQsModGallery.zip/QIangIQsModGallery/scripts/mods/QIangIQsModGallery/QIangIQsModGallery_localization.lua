return {
	mod_name = {
		en = "QIangIQ's Mod Gallery",
	},
	mod_description = {
		en = "A tiled gallery of every mod: open its options, switch it on or off, pin it. Replaces Mod Options: F4, the Esc menu button and /modgallery open it; Back on a mod's page returns here. Disable this mod to get the plain Mod Options back.",
	},
	open_gallery_keybind = {
		en = "Open Mod Gallery",
	},
	gallery_title = {
		en = "Mod Gallery",
	},
	gallery_hint = {
		en = "Click a tile to open its options. Top right: on / off. Top left: pin.",
	},
	no_options = {
		en = "No options",
	},
	toggle_on = {
		en = "ON",
	},
	toggle_off = {
		en = "OFF",
	},
}
