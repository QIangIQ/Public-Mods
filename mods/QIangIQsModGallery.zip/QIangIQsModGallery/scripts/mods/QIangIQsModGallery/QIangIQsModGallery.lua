-- QIangIQs Mod Gallery
--
-- A tiled view of every mod that has a page in DMF's Mod Options. Clicking a
-- tile opens Mod Options on that mod.
--
-- Built only from things that already exist:
--   * the mod list:        dmf.options_widgets_data and the category rule in
--                          dmf/.../ui/options/mod_options.lua (create_mod_category,
--                          dmf.create_mod_options_settings: a mod gets a page when #mod_data > 1)
--   * open on one mod:     DMFOptionsView._setup_category_config reads
--                          dmf:get("options_menu_last_selected") as the category display name
--   * view registration:   SimpleAssets demo view / AnotherScoreboard history view
--   * picture loading:     SimpleAssets.load_texture (docs/api/textures.md), drawn with
--                          ui_default_base + material_values.texture_map, as the game's
--                          store_item_detail_view does with url-loaded textures

local mod = get_mod("QIangIQsModGallery")

local VIEW_NAME = "qiangiq_mod_gallery_view"
local VIEW_PATH = "QIangIQsModGallery/scripts/mods/QIangIQsModGallery/views/mod_gallery_view"
local HEADS = "mods/QIangIQsModGallery/assets/heads/"

-- Test set: the Warframe mods get a headshot. Every other mod is a plain name tile.
mod.tile_images = {
	QIangIQsCitrinePrime = HEADS .. "citrine_prime.png",
	QIangIQsEleanorGemini = HEADS .. "eleanor_gemini.png",
	QIangIQsGrendelPrime = HEADS .. "grendel_prime.png",
	QIangIQsJade = HEADS .. "jade.png",
	QIangIQsMarieGemini = HEADS .. "marie_gemini.png",
	QIangIQsMesaHeirloom = HEADS .. "mesa_heirloom.png",
	QIangIQsOctaviaPrime = HEADS .. "octavia_prime.png",
	QIangIQsOraxia = HEADS .. "oraxia.png",
	QIangIQsSevagothPrime = HEADS .. "sevagoth_prime.png",
	QIangIQsValkyrHeirloom = HEADS .. "valkyr_heirloom.png",
	QIangIQsVorunaPrime = HEADS .. "voruna_prime.png",
	QIangIQsWispPrime = HEADS .. "wisp_prime.png",
	QIangIQsYareliPrime = HEADS .. "yareli_prime.png",
}

-- path -> { status = "loading" | "ready" | "failed", texture = userdata }
-- Kept for the session; the pictures are small.
mod.textures = mod.textures or {}

mod.request_texture = function(path)
	local entry = mod.textures[path]

	if entry then
		return entry
	end

	entry = { status = "loading" }
	mod.textures[path] = entry

	local SimpleAssets = get_mod("SimpleAssets")

	if not SimpleAssets or not SimpleAssets.load_texture then
		entry.status = "failed"
		mod:error("SimpleAssets is required for pictures and must be in the load order.")

		return entry
	end

	local ok, promise = pcall(SimpleAssets.load_texture, path)

	if not ok then
		entry.status = "failed"
		mod:error("load_texture failed for %s: %s", path, tostring(promise))

		return entry
	end

	promise:next(function(data)
		if not data or not data.is_ok or not data.texture then
			entry.status = "failed"
			mod:error("picture failed: %s", path)

			return
		end

		entry.texture = data.texture
		entry.status = "ready"
	end):catch(function(reason)
		entry.status = "failed"
		mod:error("picture failed: %s (%s)", path, tostring(type(reason) == "table" and (reason.error or reason.url) or reason))
	end)

	return entry
end

local FAVORITE_MODS_SETTING = "options_menu_favorite_mods" -- dmf_options_view.lua:15

local function favorites()
	local dmf = get_mod("DMF")
	local list = dmf and dmf:get(FAVORITE_MODS_SETTING) or {}
	local set = {}

	for i = 1, #list do
		set[list[i]] = true
	end

	return set, list
end

-- Every mod DMF lists (the "toggle mods" category lists all of them).
-- has_page: the mod has its own Mod Options page (#mod_data > 1).
-- Order as DMF's category list: pinned first, then load order (sort_pinned_categories).
mod.collect_mods = function(filter_text)
	local dmf = get_mod("DMF")
	local data = dmf and dmf.options_widgets_data
	local pinned, regular = {}, {}

	if not data then
		return pinned
	end

	local favorite_set = favorites()
	local needle = filter_text and filter_text ~= "" and string.lower(filter_text) or nil

	for _, mod_data in ipairs(data) do
		local head = mod_data[1]

		if head then
			local display_name = head.readable_mod_name or head.title or head.mod_name or ""
			local matches = not needle
				or string.find(string.lower(display_name), needle, 1, true)
				or string.find(string.lower(head.mod_name or ""), needle, 1, true)

			if matches then
				local entry = {
					mod_name = head.mod_name,
					display_name = display_name,
					author = head.author,
					has_page = #mod_data > 1,
					is_togglable = head.is_togglable and true or false,
					is_favorited = favorite_set[head.mod_name] or false,
					image = mod.tile_images[head.mod_name],
				}
				local target = entry.is_favorited and pinned or regular

				target[#target + 1] = entry
			end
		end
	end

	for i = 1, #regular do
		pinned[#pinned + 1] = regular[i]
	end

	return pinned
end

mod.is_mod_enabled = function(mod_name)
	local other = get_mod(mod_name)

	return other and other:is_enabled() or false
end

-- The same call DMF's header toggle makes (DMFOptionsView._on_header_toggle_changed).
mod.set_mod_enabled = function(mod_name, value)
	local dmf = get_mod("DMF")

	if dmf and dmf.mod_state_changed then
		dmf.mod_state_changed(mod_name, value)
	end
end

-- Same as DMFOptionsView._on_header_pin_changed.
mod.set_mod_pinned = function(mod_name, value)
	local dmf = get_mod("DMF")

	if not dmf then
		return
	end

	local _, list = favorites()
	local updated = {}

	for i = 1, #list do
		if list[i] ~= mod_name then
			updated[#updated + 1] = list[i]
		end
	end

	if value then
		updated[#updated + 1] = mod_name
	end

	dmf:set(FAVORITE_MODS_SETTING, updated)
end

mod:add_require_path(VIEW_PATH)
mod:register_view({
	view_name = VIEW_NAME,
	view_settings = {
		init_view_function = function()
			return true
		end,
		class = "QIangIQsModGalleryView",
		disable_game_world = false,
		game_world_blur = 1.1,
		load_always = true,
		load_in_hub = true,
		package = "packages/ui/views/options_view/options_view",
		path = VIEW_PATH,
		state_bound = true,
		enter_sound_events = { "wwise/events/ui/play_ui_enter_short" },
		exit_sound_events = { "wwise/events/ui/play_ui_back_short" },
		wwise_states = { options = "ingame_menu" },
	},
	view_transitions = {},
	view_options = {
		close_all = false,
		close_previous = false,
	},
})
mod:io_dofile(VIEW_PATH)

mod.open_gallery = function()
	local ui = Managers.ui

	if not ui then
		return
	end

	if ui:view_instance(VIEW_NAME) then
		ui:close_view(VIEW_NAME)

		return
	end

	ui:open_view(VIEW_NAME, nil, nil, nil, nil, {})
end

mod:command("modgallery", mod:localize("mod_description"), function()
	mod.open_gallery()
end)

-- Taking over Mod Options:
-- * every open of "dmf_options_view" (F4 keybind, Esc-menu "Mod Options" button,
--   other mods) opens the gallery instead, unless it came from a gallery tile;
-- * F4 while the gallery is open closes it (DMF's keybind_toggle_view calls
--   open_view again because the options view is not active);
-- * leaving a page opened from the gallery with Back returns to the gallery.
--   F4 closes with force_close (custom_views.lua keybind_toggle_view) and does not.
local OPTIONS_VIEW = "dmf_options_view"

mod:hook("UIManager", "open_view", function(func, self, view_name, transition_time, close_previous, close_all, close_transition_time, context, settings_override)
	if view_name == OPTIONS_VIEW and mod:is_enabled() and not (context and context.qmg_from_gallery) then
		if self:view_instance(VIEW_NAME) then
			if not self:is_view_closing(VIEW_NAME) then
				self:close_view(VIEW_NAME)
			end

			return
		end

		return func(self, VIEW_NAME, transition_time, close_previous, close_all, close_transition_time, {}, settings_override)
	end

	return func(self, view_name, transition_time, close_previous, close_all, close_transition_time, context, settings_override)
end)

mod:hook_safe("UIManager", "close_view", function(self, view_name, force_close)
	if view_name == OPTIONS_VIEW and mod._options_from_gallery then
		mod._options_from_gallery = nil
		mod._reopen_gallery = not force_close
	end
end)

-- Tile pressed: close the gallery, then open Mod Options on that mod once the
-- gallery has gone (mod.update), the same open call as DMF's Esc-menu button.
mod.open_options_for = function(display_name)
	mod._pending_category = display_name
	mod._reopen_gallery = nil

	if Managers.ui:view_instance(VIEW_NAME) then
		Managers.ui:close_view(VIEW_NAME)
	end
end

mod.update = function(dt)
	local ui = Managers.ui

	if not ui then
		return
	end

	if mod._reopen_gallery then
		if not ui:view_instance(OPTIONS_VIEW) and not ui:is_view_closing(OPTIONS_VIEW) then
			mod._reopen_gallery = nil

			if not ui:view_instance(VIEW_NAME) then
				ui:open_view(VIEW_NAME, nil, nil, nil, nil, {})
			end
		end

		return
	end

	local category = mod._pending_category

	if not category then
		return
	end

	if ui:view_instance(VIEW_NAME) or ui:is_view_closing(VIEW_NAME) then
		return
	end

	mod._pending_category = nil

	local dmf = get_mod("DMF")

	if dmf then
		dmf:set("options_menu_last_selected", category)
	end

	if not ui:view_instance(OPTIONS_VIEW) then
		mod._options_from_gallery = true
		ui:open_view(OPTIONS_VIEW, nil, nil, nil, nil, { can_exit = true, qmg_from_gallery = true })
	end
end

-- Pages opened from the gallery: no mod list on the left, and Back goes
-- straight back to the gallery.
-- DMF re-runs dmf_options_view.lua on every open (dmf core/require.lua: a
-- require path is io_dofile'd again), which reassigns every DMFOptionsView
-- method and drops hooks made on that class. So, as Alf's DMF Extensions does,
-- hook BaseView and act only when self.view_name == "dmf_options_view".
-- The left list is every scenegraph node under "background" plus
-- "category_filter" (dmf_options_view_definitions.lua); it is moved off screen.
local OFF_SCREEN_X = -4000

-- Same order of checks as DMFOptionsView.cb_on_back_pressed; only the steps that
-- move focus to the (hidden) mod list are replaced by closing the page.
-- Set on the instance: the legend calls it through callback(self, "cb_on_back_pressed"),
-- which looks the name up on the object at call time (foundation/utilities/callback.lua).
local function gallery_back(view, ...)
	local header = view._options_header
	local busy = view:_is_category_filter_writing()
		or (header and header:is_filter_writing())
		or view._selected_settings_widget
		or view._require_restart

	if busy then
		return CLASS.DMFOptionsView.cb_on_back_pressed(view, ...)
	end

	Managers.ui:close_view(OPTIONS_VIEW)
end

mod:hook_safe(CLASS.BaseView, "on_enter", function(self)
	if self.view_name ~= OPTIONS_VIEW or not mod._options_from_gallery then
		return
	end

	self._qmg_from_gallery = true
	self.cb_on_back_pressed = gallery_back
end)

mod:hook_safe(CLASS.BaseView, "update", function(self)
	if self.view_name ~= OPTIONS_VIEW or not self._qmg_from_gallery then
		return
	end

	local scenegraph = self._ui_scenegraph

	if scenegraph and scenegraph.background and scenegraph.background.position[1] ~= OFF_SCREEN_X then
		self:_set_scenegraph_position("background", OFF_SCREEN_X)
		self:_set_scenegraph_position("category_filter", OFF_SCREEN_X)
	end
end)
