local mod = get_mod("QIangIQsModGallery")

-- keybind widget with keybind_type "function_call": same fields as the reload
-- keybind in Alf's DMF Extensions (Alfs_DMF_Extensions_data.lua).
return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			{
				setting_id = "open_gallery_keybind",
				type = "keybind",
				default_value = {},
				keybind_trigger = "pressed",
				keybind_type = "function_call",
				function_name = "open_gallery",
				keybind_global = true,
			},
		},
	},
}
