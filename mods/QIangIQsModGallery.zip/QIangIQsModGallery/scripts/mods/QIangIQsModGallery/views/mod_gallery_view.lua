-- Gallery view. Structure follows the SimpleAssets demo view (init, legend,
-- _on_back_pressed) and the AnotherScoreboard history view (tiles created with
-- _create_widget, drawn in an own _draw_widgets, mouse wheel from "scroll_axis").
-- Search box handling as DMFOptionsView (FilterInput.reset / update / finish_editing).

local mod = get_mod("QIangIQsModGallery")
local UIWidget = require("scripts/managers/ui/ui_widget")
local ViewElementInputLegend = require("scripts/ui/view_elements/view_element_input_legend/view_element_input_legend")
local definitions = mod:io_dofile("QIangIQsModGallery/scripts/mods/QIangIQsModGallery/views/mod_gallery_view_definitions")

local settings = definitions.settings
local FilterInput = definitions.FilterInput

-- Kept while the game runs, so the gallery reopens on the same search and row.
local _saved = {
	filter = "",
	first_row = 0,
}

QIangIQsModGalleryView = class("QIangIQsModGalleryView", "BaseView")

QIangIQsModGalleryView.init = function(self, view_settings, context)
	self._tiles = {}
	self._first_row = 0
	self._tile_generation = 0

	QIangIQsModGalleryView.super.init(self, definitions, view_settings, context)
end

QIangIQsModGalleryView.on_enter = function(self)
	QIangIQsModGalleryView.super.on_enter(self)

	self._input_legend_element = self:_add_element(ViewElementInputLegend, "input_legend", 100)

	local legend_inputs = self._definitions.legend_inputs

	for i = 1, #legend_inputs do
		local entry = legend_inputs[i]

		self._input_legend_element:add_entry(
			entry.display_name,
			entry.input_action,
			entry.visibility_function,
			entry.on_pressed_callback and callback(self, entry.on_pressed_callback),
			entry.alignment
		)
	end

	local search = self._widgets_by_name.search.content

	FilterInput.reset(search)
	search.input_text = _saved.filter
	search.display_text = _saved.filter
	self._search_content = search
	self._applied_filter = _saved.filter

	self:_build_tiles(_saved.first_row)
end

QIangIQsModGalleryView._clear_tiles = function(self)
	for i = 1, #self._tiles do
		self:_unregister_widget_name(self._tiles[i].widget.name)
	end

	self._tiles = {}
end

QIangIQsModGalleryView._build_tiles = function(self, first_row)
	self:_clear_tiles()

	local entries = mod.collect_mods(self._applied_filter)
	local definition_with_image = definitions.tile_definition(true)
	local definition_plain = definitions.tile_definition(false)

	-- Fresh names each rebuild: a widget name is only unregistered, never reused.
	self._tile_generation = self._tile_generation + 1

	local prefix = "qmg_tile_" .. self._tile_generation .. "_"

	for i = 1, #entries do
		local entry = entries[i]
		local definition = entry.image and definition_with_image or definition_plain
		local widget = self:_create_widget(prefix .. i, definition)
		local content = widget.content
		local index = i - 1

		content.name = entry.display_name
		content.entry = entry
		content.has_page = entry.has_page
		content.is_togglable = entry.is_togglable
		content.is_favorited = entry.is_favorited
		self:_refresh_enabled(content)

		content.hotspot.pressed_callback = function()
			if content.toggle_hotspot.is_hover or content.pin_hotspot.is_hover then
				return
			end

			if entry.has_page then
				mod.open_options_for(entry.display_name)
			end
		end
		content.toggle_hotspot.pressed_callback = function()
			mod.set_mod_enabled(entry.mod_name, not mod.is_mod_enabled(entry.mod_name))
			self:_refresh_enabled(content)
		end
		content.pin_hotspot.pressed_callback = function()
			mod.set_mod_pinned(entry.mod_name, not entry.is_favorited)
			-- Pinned tiles move to the front; rebuild after this draw.
			self._rebuild_requested = true
		end

		self._tiles[i] = {
			widget = widget,
			column = index % settings.columns,
			row = math.floor(index / settings.columns),
			texture = entry.image and mod.request_texture(entry.image) or nil,
		}
	end

	local rows = math.ceil(#entries / settings.columns)

	self._max_first_row = math.max(0, rows - settings.visible_rows)
	self._first_row = math.clamp(first_row or 0, 0, self._max_first_row)
	self:_layout_tiles()
end

QIangIQsModGalleryView._refresh_enabled = function(self, content)
	local enabled = mod.is_mod_enabled(content.entry.mod_name)

	content.is_enabled = enabled
	content.pill_text = mod:localize(enabled and "toggle_on" or "toggle_off")
end

QIangIQsModGalleryView._layout_tiles = function(self)
	local step = settings.tile_step
	local first_row = self._first_row
	local last_row = first_row + settings.visible_rows - 1

	for i = 1, #self._tiles do
		local tile = self._tiles[i]
		local widget = tile.widget

		tile.visible = tile.row >= first_row and tile.row <= last_row
		widget.offset = { tile.column * step, (tile.row - first_row) * step, 0 }
	end

	local hint = self._widgets_by_name.hint

	if hint then
		local text = mod:localize("gallery_hint")

		if self._max_first_row > 0 then
			text = string.format("%s   (%d / %d)", text, first_row + 1, self._max_first_row + 1)
		end

		hint.content.text = text
	end
end

QIangIQsModGalleryView._update_textures = function(self)
	for i = 1, #self._tiles do
		local tile = self._tiles[i]
		local texture = tile.texture
		local content = tile.widget.content

		if texture and not content.image_ready and texture.status == "ready" then
			tile.widget.style.image.material_values.texture_map = texture.texture
			content.image_ready = true
		end
	end
end

QIangIQsModGalleryView.update = function(self, dt, t, input_service)
	local search = self._search_content

	if search and input_service then
		FilterInput.update(search, input_service, false)

		local text = search.input_text or ""

		if text ~= self._applied_filter then
			self._applied_filter = text
			self._rebuild_requested = true
			self._rebuild_row = 0
		end
	end

	if self._rebuild_requested then
		self._rebuild_requested = nil
		self:_build_tiles(self._rebuild_row or self._first_row)
		self._rebuild_row = nil
	end

	self:_update_textures()

	if input_service then
		local scroll_axis = input_service:get("scroll_axis")
		local scroll = scroll_axis and scroll_axis[2] or 0

		if scroll ~= 0 then
			local first_row = math.clamp(self._first_row + (scroll > 0 and -1 or 1), 0, self._max_first_row or 0)

			if first_row ~= self._first_row then
				self._first_row = first_row
				self:_layout_tiles()
			end
		end
	end

	return QIangIQsModGalleryView.super.update(self, dt, t, input_service)
end

QIangIQsModGalleryView._draw_widgets = function(self, dt, t, input_service, ui_renderer, render_settings)
	QIangIQsModGalleryView.super._draw_widgets(self, dt, t, input_service, ui_renderer, render_settings)

	local alpha = render_settings and render_settings.alpha_multiplier or 1

	for i = 1, #self._tiles do
		local tile = self._tiles[i]

		if tile.visible then
			local widget = tile.widget

			-- Disabled mods are dimmed, as switched-off entries elsewhere in the menus.
			widget.alpha_multiplier = widget.content.is_enabled and alpha or alpha * 0.5
			UIWidget.draw(widget, ui_renderer)
		end
	end
end

QIangIQsModGalleryView._on_back_pressed = function(self)
	local search = self._search_content

	-- First Back only stops typing in the search box (as DMFOptionsView.cb_on_back_pressed).
	if search and search.is_writing then
		FilterInput.finish_editing(search)

		return
	end

	local ui = Managers.ui

	ui:close_view(self.view_name)

	-- Opened from the Esc menu: go straight back to the game, not to the Esc menu.
	-- ("system_view" is the hotkey_system view in game_mode_settings_*.lua.)
	if ui:view_active("system_view") and not ui:is_view_closing("system_view") then
		ui:close_view("system_view")
	end
end

QIangIQsModGalleryView.on_exit = function(self)
	_saved.filter = self._applied_filter or ""
	_saved.first_row = self._first_row or 0

	self:_clear_tiles()

	QIangIQsModGalleryView.super.on_exit(self)
end

return QIangIQsModGalleryView
