-- Layout and widget definitions. Pass shapes follow the SimpleAssets demo view
-- (screen node, terminal_basic background, frame_tile_2px card frame), the
-- AnotherScoreboard history view (hotspot + rect + text passes), the game's
-- store_item_detail_view (ui_default_base texture with material_values.texture_map)
-- and DMF's own options view (FilterInput search box, pin glyph and colour).

local mod = get_mod("QIangIQsModGallery")
local dmf = get_mod("DMF")
local UIFontSettings = require("scripts/managers/ui/ui_font_settings")
local UIWidget = require("scripts/managers/ui/ui_widget")
local UIWorkspaceSettings = require("scripts/settings/ui/ui_workspace_settings")
local FilterInput = dmf:io_dofile("dmf/scripts/mods/dmf/modules/ui/options/filter/filter_input")
local OptionsDisplayUtils = dmf:io_dofile("dmf/scripts/mods/dmf/modules/ui/options/options_display_utils")

local VIEW_ROOT_LAYER = 13

local settings = {
	gallery_x = 120,
	gallery_y = 170,
	gallery_width = 1680,
	gallery_height = 820,
	tile_size = 190,
	tile_gap = 14,
	name_band_height = 56,
	pill_width = 54,
	pill_height = 24,
	pin_size = 32,
	search_width = 480,
	search_height = 44,
}

settings.tile_step = settings.tile_size + settings.tile_gap
settings.columns = math.floor((settings.gallery_width + settings.tile_gap) / settings.tile_step)
settings.visible_rows = math.floor((settings.gallery_height + settings.tile_gap) / settings.tile_step)

local screen = table.clone(UIWorkspaceSettings.screen)

screen.position[3] = VIEW_ROOT_LAYER

local scenegraph_definition = {
	screen = screen,
	title = {
		parent = "screen",
		horizontal_alignment = "left",
		vertical_alignment = "top",
		size = { 900, 70 },
		position = { settings.gallery_x, 40, 2 },
	},
	hint = {
		parent = "screen",
		horizontal_alignment = "left",
		vertical_alignment = "top",
		size = { 1100, 30 },
		position = { settings.gallery_x, 122, 2 },
	},
	search = {
		parent = "screen",
		horizontal_alignment = "left",
		vertical_alignment = "top",
		size = { settings.search_width, settings.search_height },
		position = { settings.gallery_x + settings.columns * settings.tile_step - settings.tile_gap - settings.search_width, 110, 3 },
	},
	gallery = {
		parent = "screen",
		horizontal_alignment = "left",
		vertical_alignment = "top",
		size = { settings.gallery_width, settings.gallery_height },
		position = { settings.gallery_x, settings.gallery_y, 1 },
	},
}

local hint_style = table.clone(UIFontSettings.body)

hint_style.font_size = 18
hint_style.text_color = { 255, 170, 170, 170 }

local widget_definitions = {
	background = UIWidget.create_definition({
		{
			pass_type = "rect",
			style = {
				color = { 160, 0, 0, 0 },
			},
		},
		{
			pass_type = "texture",
			value = "content/ui/materials/backgrounds/terminal_basic",
			style = {
				horizontal_alignment = "center",
				vertical_alignment = "center",
				scale_to_material = true,
				size_addition = { 40, 40 },
				color = Color.terminal_grid_background_gradient(204, true),
			},
		},
	}, "screen"),
	title = UIWidget.create_definition({
		{
			pass_type = "text",
			value = mod:localize("gallery_title"),
			style = table.clone(UIFontSettings.header_1),
		},
	}, "title"),
	hint = UIWidget.create_definition({
		{
			pass_type = "text",
			value_id = "text",
			value = mod:localize("gallery_hint"),
			style = hint_style,
		},
	}, "hint"),
	-- dmf_options_view_definitions.lua: category_filter
	search = UIWidget.create_definition(FilterInput.create_passes(), "search", {
		input_text = "",
		placeholder_text = " \u{e04a}",
	}),
}

local PIN_ON = { 255, 226, 199, 126 } -- OptionsDisplayUtils METADATA_LABEL_COLOR
local PIN_OFF = { 150, 200, 200, 200 }
local PILL_ON = { 230, 46, 110, 58 }
local PILL_OFF = { 230, 105, 34, 34 }

local function tile_definition(has_image)
	local size = settings.tile_size
	local band = settings.name_band_height
	local pill_w, pill_h = settings.pill_width, settings.pill_height
	local pin = settings.pin_size
	local name_offset = has_image and { 8, size - band, 5 } or { 10, 34, 5 }
	local name_size = has_image and { size - 16, band } or { size - 20, size - 68 }

	return UIWidget.create_definition({
		-- Small hotspots first, so their is_hover is current when the tile hotspot is pressed.
		{
			pass_type = "hotspot",
			content_id = "toggle_hotspot",
			style = {
				offset = { size - pill_w - 6, 6, 8 },
				size = { pill_w, pill_h },
			},
			visibility_function = function(content)
				return content.parent.is_togglable
			end,
		},
		{
			pass_type = "hotspot",
			content_id = "pin_hotspot",
			style = {
				offset = { 2, 2, 8 },
				size = { pin, pin },
			},
			visibility_function = function(content)
				return content.parent.has_page
			end,
		},
		{
			pass_type = "hotspot",
			content_id = "hotspot",
			style = {
				offset = { 0, 0, 6 },
				size = { size, size },
			},
		},
		{
			pass_type = "rect",
			style = {
				offset = { 0, 0, 0 },
				size = { size, size },
				color = { 230, 22, 24, 26 },
			},
		},
		{
			pass_type = "texture",
			style_id = "image",
			value = "content/ui/materials/base/ui_default_base",
			style = {
				offset = { 0, 0, 1 },
				size = { size, size },
				color = { 255, 255, 255, 255 },
				material_values = {
					texture_map = nil,
				},
			},
			visibility_function = function(content)
				return content.image_ready
			end,
		},
		{
			pass_type = "rect",
			style = {
				offset = { 0, size - band, 3 },
				size = { size, band },
				color = { 185, 0, 0, 0 },
			},
			visibility_function = function(content)
				return content.has_image
			end,
		},
		{
			pass_type = "rect",
			style = {
				offset = { 0, 0, 4 },
				size = { size, size },
				color = { 36, 255, 255, 255 },
			},
			visibility_function = function(content)
				return content.has_page and content.hotspot.is_hover
					and not content.toggle_hotspot.is_hover and not content.pin_hotspot.is_hover
			end,
		},
		{
			pass_type = "text",
			value_id = "name",
			value = "",
			style = {
				offset = name_offset,
				size = name_size,
				font_size = has_image and 18 or 20,
				font_type = "proxima_nova_bold",
				text_horizontal_alignment = "center",
				text_vertical_alignment = "center",
				text_color = { 255, 235, 235, 235 },
				drop_shadow = true,
			},
		},
		{
			pass_type = "text",
			value = mod:localize("no_options"),
			style = {
				offset = { 10, size - 34, 5 },
				size = { size - 20, 26 },
				font_size = 15,
				font_type = "proxima_nova_bold",
				text_horizontal_alignment = "center",
				text_vertical_alignment = "center",
				text_color = { 255, 130, 130, 130 },
			},
			visibility_function = function(content)
				return not content.has_page
			end,
		},
		-- Enabled / disabled pill (the "Toggle mods" category's job).
		{
			pass_type = "rect",
			style_id = "pill",
			style = {
				offset = { size - pill_w - 6, 6, 7 },
				size = { pill_w, pill_h },
				color = table.clone(PILL_ON),
			},
			visibility_function = function(content)
				return content.is_togglable
			end,
			change_function = function(content, style)
				local color = content.is_enabled and PILL_ON or PILL_OFF
				local hover = content.toggle_hotspot.is_hover and 25 or 0

				style.color[1] = color[1]
				style.color[2] = math.min(255, color[2] + hover)
				style.color[3] = math.min(255, color[3] + hover)
				style.color[4] = math.min(255, color[4] + hover)
			end,
		},
		{
			pass_type = "text",
			value_id = "pill_text",
			value = "",
			style = {
				offset = { size - pill_w - 6, 6, 8 },
				size = { pill_w, pill_h },
				font_size = 15,
				font_type = "proxima_nova_bold",
				text_horizontal_alignment = "center",
				text_vertical_alignment = "center",
				text_color = { 255, 240, 240, 240 },
			},
			visibility_function = function(content)
				return content.is_togglable
			end,
		},
		-- Pin glyph (dmf options header pin: OptionsDisplayUtils.pin_symbol on header_3).
		{
			pass_type = "text",
			style_id = "pin",
			value = OptionsDisplayUtils.pin_symbol,
			style = {
				offset = { 2, 2, 8 },
				size = { pin, pin },
				font_size = 22,
				font_type = UIFontSettings.header_3.font_type,
				text_horizontal_alignment = "center",
				text_vertical_alignment = "center",
				text_color = table.clone(PIN_OFF),
				drop_shadow = true,
			},
			visibility_function = function(content)
				return content.has_page and (content.is_favorited or content.hotspot.is_hover)
			end,
			change_function = function(content, style)
				local color = content.is_favorited and PIN_ON or PIN_OFF
				local alpha = content.pin_hotspot.is_hover and 255 or color[1]

				style.text_color[1] = alpha
				style.text_color[2] = color[2]
				style.text_color[3] = color[3]
				style.text_color[4] = color[4]
			end,
		},
		{
			pass_type = "texture",
			value = "content/ui/materials/frames/frame_tile_2px",
			style = {
				offset = { 0, 0, 9 },
				size = { size, size },
				color = Color.terminal_frame(nil, true),
			},
		},
	}, "gallery", {
		has_image = has_image,
		image_ready = false,
		has_page = true,
		is_togglable = false,
		is_enabled = true,
		is_favorited = false,
	})
end

local legend_inputs = {
	{
		input_action = "back",
		on_pressed_callback = "_on_back_pressed",
		display_name = "loc_class_selection_button_back",
		alignment = "left_alignment",
	},
}

return {
	settings = settings,
	tile_definition = tile_definition,
	legend_inputs = legend_inputs,
	scenegraph_definition = scenegraph_definition,
	widget_definitions = widget_definitions,
	FilterInput = FilterInput,
}
