return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsModGallery` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsModGallery", {
			mod_script       = "QIangIQsModGallery/scripts/mods/QIangIQsModGallery/QIangIQsModGallery",
			mod_data         = "QIangIQsModGallery/scripts/mods/QIangIQsModGallery/QIangIQsModGallery_data",
			mod_localization = "QIangIQsModGallery/scripts/mods/QIangIQsModGallery/QIangIQsModGallery_localization",
		})
	end,
	load_after = {
		"SimpleAssets",
	},
	packages = {},
}
