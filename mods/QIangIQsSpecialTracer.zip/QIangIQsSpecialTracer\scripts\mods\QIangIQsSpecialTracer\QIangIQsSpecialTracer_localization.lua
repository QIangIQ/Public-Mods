return {
	mod_name = {
		en = "QIangIQ's Specials Tracer",
	},
	mod_description = {
		en = "Tracers from your crosshair to the centre of mass of trappers and hounds (optionally other specials), with toggleable boxes. Built from Dio's Handholder disabler tracers and CombatFlow's Headhunter brackets.",
	},
}
