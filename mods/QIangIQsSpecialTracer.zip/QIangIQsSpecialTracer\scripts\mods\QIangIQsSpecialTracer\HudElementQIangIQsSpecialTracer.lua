local mod = get_mod("QIangIQsSpecialTracer")

--[[
    Screen-space drawing: thick tracers, boxes and labels.

    The line rasteriser (clip_edge / tri / seg_quad) is CombatFlow's
    (HudElementCombatFlow.lua): each segment becomes a quad of two
    Gui.triangle calls, clipped to the screen, with a per-frame triangle
    budget. Here every coordinate is already in renderer pixels, so the
    scale step CombatFlow does (virtual units * scale) is 1.

    Projection is Camera.world_to_screen on the local viewport camera, as in
    CombatFlow's visor.lua; its y runs top-down, the same space the HUD world
    markers put straight into widget offsets.

    Text uses Gui2.slug_text (as the ESP reference mod does) with the font path
    from UIFonts.data_by_type, falling back to Gui.slug_text.

    Drawing route: this file is NOT a registered HUD element any more. The
    main file hooks HudElementCrosshair.update (the route the ESP reference
    mod uses, known to draw on screen) and calls mod.draw_overlay(ui_renderer)
    from there. The file name is kept so the install layout does not change.
--]]

local MAX_TRIS_PER_FRAME = 7000
local DRAW_LAYER = 999        -- same z the ESP reference mod draws at
local MIN_DEPTH = 0.2          -- CombatFlow draw_brackets depth gate
local LABEL_MARGIN = 6         -- CombatFlow aim distance MARGIN
local LABEL_FONT = "proxima_nova_bold"

-- CombatFlow text palette (alpha first).
local LABEL_COLOURS = {
	white = { 255, 225, 227, 231 },
	yellow = { 255, 255, 205, 90 },
	cyan = { 255, 122, 255, 255 },
	green = { 255, 100, 255, 60 },
}

local _tri_budget = 0
local _in_x, _in_y = {}, {}
local _out_x, _out_y = {}, {}

-- ---------------------------------------------- CombatFlow rasteriser --

local function clip_edge(in_x, in_y, cnt, out_x, out_y, edge, bound)
	local m = 0
	for i = 1, cnt do
		local j = i % cnt + 1
		local xi, yi = in_x[i], in_y[i]
		local xj, yj = in_x[j], in_y[j]
		local inside_i, inside_j
		if edge == 1 then
			inside_i, inside_j = xi >= bound, xj >= bound
		elseif edge == 2 then
			inside_i, inside_j = xi <= bound, xj <= bound
		elseif edge == 3 then
			inside_i, inside_j = yi >= bound, yj >= bound
		else
			inside_i, inside_j = yi <= bound, yj <= bound
		end
		if inside_i then
			m = m + 1
			out_x[m], out_y[m] = xi, yi
		end
		if inside_i ~= inside_j then
			local t
			if edge <= 2 then
				t = (bound - xi) / (xj - xi)
			else
				t = (bound - yi) / (yj - yi)
			end
			m = m + 1
			out_x[m] = xi + (xj - xi) * t
			out_y[m] = yi + (yj - yi) * t
		end
	end
	return m
end

local function tri(gui, x1, y1, x2, y2, x3, y3, layer, color)
	if _tri_budget >= MAX_TRIS_PER_FRAME then
		return
	end
	_tri_budget = _tri_budget + 1
	Gui.triangle(gui, Vector3(x1, 0, y1), Vector3(x2, 0, y2), Vector3(x3, 0, y3), layer, color)
end

-- Lines are drawn with Gui.rect only (the primitive the ESP reference mod
-- draws with on this route): axis-aligned segments are one rect, diagonals
-- are a run of small squares.
local function clamp(v, a, b)
	return v < a and a or (v > b and b or v)
end

local function rect(gui, x, y, w, h, layer, color)
	if _tri_budget >= MAX_TRIS_PER_FRAME then
		return
	end
	_tri_budget = _tri_budget + 1
	Gui.rect(gui, Vector3(x, y, layer), Vector2(w, h), color)
end

local function seg_quad(gui, x1, y1, x2, y2, thickness, right, bottom, layer, color)
	local dx = x2 - x1
	local dy = y2 - y1
	local len = math.sqrt(dx * dx + dy * dy)
	if len < 1e-3 then
		return
	end
	local th = math.max(thickness, 1.5)
	if math.abs(dy) < 0.5 or math.abs(dx) < 0.5 then
		local minx, maxx = math.min(x1, x2), math.max(x1, x2)
		local miny, maxy = math.min(y1, y2), math.max(y1, y2)
		if math.abs(dy) < 0.5 then
			miny, maxy = miny - th * 0.5, miny + th * 0.5
		else
			minx, maxx = minx - th * 0.5, minx + th * 0.5
		end
		minx, maxx = clamp(minx, 0, right), clamp(maxx, 0, right)
		miny, maxy = clamp(miny, 0, bottom), clamp(maxy, 0, bottom)
		if maxx > minx and maxy > miny then
			rect(gui, minx, miny, maxx - minx, maxy - miny, layer, color)
		end
		return
	end
	local step = th * 0.7
	local n = math.min(math.floor(len / step) + 1, 220)
	for i = 0, n do
		local f = i / n
		local x, y = x1 + dx * f, y1 + dy * f
		if x >= 0 and x <= right and y >= 0 and y <= bottom then
			rect(gui, x - th * 0.5, y - th * 0.5, th, th, layer, color)
		end
	end
end

-- ------------------------------------------------------------ projection --

-- CombatFlow visor.lua get_cam.
local function get_cam()
	local lp = Managers.player and Managers.player:local_player_safe(1)
	local vp = lp and lp.viewport_name
	local cm = vp and Managers.state and Managers.state.camera
	if not cm or not cm:has_viewport(vp) then
		return nil
	end
	local ok, c = pcall(cm.camera, cm, vp)
	return ok and c or nil
end

local function w2s(cam, x, y, z)
	local ok, sp = pcall(Camera.world_to_screen, cam, Vector3(x, y, z))
	if ok and sp then
		return sp.x, sp.y
	end
	return nil
end

local function depth(F, x, y, z)
	local o, f = F.o, F.f
	return (x - o.x) * f.x + (y - o.y) * f.y + (z - o.z) * f.z
end

local function smoothstep(s)
	return s * s * (3 - 2 * s)
end

-- ------------------------------------------------------------------ font --

local font_path_cache = nil

local function font_path()
	if font_path_cache then
		return font_path_cache
	end
	local ok_f, UIFonts = pcall(require, "scripts/managers/ui/ui_fonts")
	if ok_f and UIFonts and UIFonts.data_by_type then
		local ok, data = pcall(UIFonts.data_by_type, LABEL_FONT)
		if ok and data and data.path then
			font_path_cache = data.path
			return font_path_cache
		end
	end
	local fm = Managers.font
	if fm and fm.data_by_type then
		local ok, data = pcall(fm.data_by_type, fm, LABEL_FONT)
		if ok and data and data.path then
			font_path_cache = data.path
		end
	end
	return font_path_cache
end

local function draw_text(gui, text, font, size, x, y, layer, colour)
	local g2 = rawget(_G, "Gui2")
	if g2 and g2.slug_text then
		local ok = pcall(g2.slug_text, gui, text, font, size, Vector3(x, y, layer), Vector2(math.huge, math.huge), { shadow = false, color = colour })
		if ok then
			return
		end
	end
	pcall(Gui.slug_text, gui, text, font, size, Vector3(x, y, layer + 1), nil, colour)
end

-- ----------------------------------------------------------------- boxes --

-- Box corner order: bit 1 = right sign, bit 2 = forward sign, bit 3 = up sign.
local SIGNS = {
	{ -1, -1, -1 }, { 1, -1, -1 }, { -1, 1, -1 }, { 1, 1, -1 },
	{ -1, -1, 1 }, { 1, -1, 1 }, { -1, 1, 1 }, { 1, 1, 1 },
}
local EDGES = {
	{ 1, 2 }, { 3, 4 }, { 5, 6 }, { 7, 8 },  -- along right
	{ 1, 3 }, { 2, 4 }, { 5, 7 }, { 6, 8 },  -- along forward
	{ 1, 5 }, { 2, 6 }, { 3, 7 }, { 4, 8 },  -- along up
}
local _cx, _cy = {}, {}

-- Projects the (possibly gate-scaled) box. Returns the screen AABB, or nil
-- when any corner is not safely in front of the camera.
local function project_box(cam, F, b, k)
	local minx, miny, maxx, maxy = math.huge, math.huge, -math.huge, -math.huge
	local c, r, f, u = b.c, b.r, b.f, b.u
	local hx, hy, hz = b.hx * k, b.hy * k, b.hz * k
	for i = 1, 8 do
		local s = SIGNS[i]
		local ax, ay, az = s[1] * hx, s[2] * hy, s[3] * hz
		local x = c.x + r.x * ax + f.x * ay + u.x * az
		local y = c.y + r.y * ax + f.y * ay + u.y * az
		local z = c.z + r.z * ax + f.z * ay + u.z * az
		if depth(F, x, y, z) <= MIN_DEPTH then
			return nil
		end
		local sx, sy = w2s(cam, x, y, z)
		if not sx then
			return nil
		end
		_cx[i], _cy[i] = sx, sy
		if sx < minx then minx = sx end
		if sx > maxx then maxx = sx end
		if sy < miny then miny = sy end
		if sy > maxy then maxy = sy end
	end
	return minx, miny, maxx, maxy
end

-- CombatFlow bracket thickness: pixels per metre at the target, * 0.022,
-- clamped to 1.6 - 3.2 px.
local function box_thickness(cam, F, com)
	local hx, hy = w2s(cam, com.x, com.y, com.z)
	if not hx then
		return 1.6
	end
	local r = F.r
	local ox, oy = w2s(cam, com.x + r.x, com.y + r.y, com.z + r.z)
	if not ox then
		return 1.6
	end
	local l = math.sqrt((ox - hx) ^ 2 + (oy - hy) ^ 2)
	return clamp(l * 0.022, 1.6, 3.2)
end

local function draw_all(gui, layer, W, H)
	local F = mod.frame
	local S = mod.settings
	local cam = get_cam()
	if not cam then
		mod.dstate("draw", "no camera for projection")
		return
	end
	mod.dstate("draw", string.format("drawing %d target(s), %dx%d", F.count, W, H))

	local cx, cy = W * 0.5, H * 0.5
	local screen_tracers = S.tracers_enabled and S.tracer_style == "screen"
	local thick = S.tracer_thickness
	local labels = S.label_mode ~= "off" or S.show_names
	local font = labels and font_path()
	local label_size = S.label_size * ((RESOLUTION_LOOKUP and RESOLUTION_LOOKUP.scale) or 1)

	for i = 1, F.count do
		local t = F.targets[i]
		local com = t.com
		local rgb = t.rgb
		local d = depth(F, com.x, com.y, com.z)
		local tx, ty = nil, nil

		if d > MIN_DEPTH then
			tx, ty = w2s(cam, com.x, com.y, com.z)
		end

		-- Tracer ------------------------------------------------------------
		if screen_tracers and t.live then
			local colour = Color(255 * t.factor, rgb[1], rgb[2], rgb[3])
			if tx then
				seg_quad(gui, cx, cy, tx, ty, thick, W, H, layer, colour)
			elseif S.show_offscreen then
				-- Behind the camera: aim at a helper point in front of the
				-- camera on the same side, then run to the screen edge.
				local o, r, u, f = F.o, F.r, F.u, F.f
				local vx, vy, vz = com.x - o.x, com.y - o.y, com.z - o.z
				local sr = vx * r.x + vy * r.y + vz * r.z
				local su = vx * u.x + vy * u.y + vz * u.z
				local l = math.sqrt(sr * sr + su * su)
				if l > 1e-4 then
					sr, su = sr / l * 0.5, su / l * 0.5
					local hx, hy = w2s(cam,
						o.x + f.x + r.x * sr + u.x * su,
						o.y + f.y + r.y * sr + u.y * su,
						o.z + f.z + r.z * sr + u.z * su)
					if hx then
						local dx, dy = hx - cx, hy - cy
						local dl = math.sqrt(dx * dx + dy * dy)
						if dl > 1e-4 then
							local reach = W + H
							seg_quad(gui, cx, cy, cx + dx / dl * reach, cy + dy / dl * reach, thick, W, H, layer, colour)
						end
					end
				end
			end
		end

		-- Box ---------------------------------------------------------------
		local minx, miny, maxx, maxy = nil, nil, nil, nil
		local simple = S.box_style ~= "box3d"
		-- Only the 3D box uses the gate-open animation; the feet/head box stays steady.
		local s = simple and 1 or clamp(t.anim or 1, 0, 1)

		-- (simple: ESP-style box from feet to head)
		if S.boxes_enabled and (simple and t.pos or t.has_box) and s > 0.02 and d > MIN_DEPTH then
			if simple then
				-- ESP reference: project the feet and a point head_height above,
				-- box width is half the height, clamped to the screen.
				local p = t.pos
				local fx, fy = w2s(cam, p.x, p.y, p.z)
				local hx2, hy2 = w2s(cam, p.x, p.y, p.z + (t.height or 2.0))
				if fx and hx2 and math.abs(fy - hy2) >= 5 then
					local hh = math.abs(fy - hy2)
					local cxm = (fx + hx2) * 0.5
					minx, maxx = clamp(cxm - hh * 0.25, 0, W), clamp(cxm + hh * 0.25, 0, W)
					miny, maxy = clamp(math.min(fy, hy2), 0, H), clamp(math.max(fy, hy2), 0, H)
				end
			else
				-- CombatFlow gate-open: from ~11.5% (0.03 of 0.26) to full size.
				local e = smoothstep(s)
				local k = 0.115 + (1 - 0.115) * e
				minx, miny, maxx, maxy = project_box(cam, F, t.box, k)
			end

			if minx then
				local a = (215 + 40 * s) * clamp(s * 1.1, 0, 1) * t.factor
				local colour = Color(a, rgb[1], rgb[2], rgb[3])
				local bt = box_thickness(cam, F, com)
				local style = S.box_style

				if style == "box3d" then
					for j = 1, #EDGES do
						local e1, e2 = EDGES[j][1], EDGES[j][2]
						seg_quad(gui, _cx[e1], _cy[e1], _cx[e2], _cy[e2], bt, W, H, layer, colour)
					end
				elseif style == "box2d" or style == "simple" then
					seg_quad(gui, minx, miny, maxx, miny, bt, W, H, layer, colour)
					seg_quad(gui, maxx, miny, maxx, maxy, bt, W, H, layer, colour)
					seg_quad(gui, maxx, maxy, minx, maxy, bt, W, H, layer, colour)
					seg_quad(gui, minx, maxy, minx, miny, bt, W, H, layer, colour)
				else
					-- CombatFlow draw_bracket: vertical edge plus two tips that
					-- reach inward by 0.32 of the half height.
					local tip = (maxy - miny) * 0.5 * 0.32
					seg_quad(gui, minx, miny, minx + tip, miny, bt, W, H, layer, colour)
					seg_quad(gui, minx, miny, minx, maxy, bt, W, H, layer, colour)
					seg_quad(gui, minx, maxy, minx + tip, maxy, bt, W, H, layer, colour)
					seg_quad(gui, maxx, miny, maxx - tip, miny, bt, W, H, layer, colour)
					seg_quad(gui, maxx, miny, maxx, maxy, bt, W, H, layer, colour)
					seg_quad(gui, maxx, maxy, maxx - tip, maxy, bt, W, H, layer, colour)
				end
			end
		end

		-- Skeleton ----------------------------------------------------------
		if S.skeleton_enabled and t.live and t.skel_n and t.skel_n >= 12 then
			local sk = t.skel
			local sc = Color(255 * t.factor, rgb[1], rgb[2], rgb[3])
			local sth = math.max(thick * 0.8, 1.5)
			for k = 1, t.skel_n, 6 do
				if depth(F, sk[k], sk[k + 1], sk[k + 2]) > MIN_DEPTH and depth(F, sk[k + 3], sk[k + 4], sk[k + 5]) > MIN_DEPTH then
					local x1, y1 = w2s(cam, sk[k], sk[k + 1], sk[k + 2])
					local x2, y2 = w2s(cam, sk[k + 3], sk[k + 4], sk[k + 5])
					if x1 and x2 then
						seg_quad(gui, x1, y1, x2, y2, sth, W, H, layer, sc)
					end
				end
			end
		end

		-- Label -------------------------------------------------------------
		if font and t.live and tx then
			local parts = {}
			local metres = math.floor((t.dist or 0) + 0.5)
			if S.show_names then
				parts[#parts + 1] = t.name or mod.KIND_NAME[t.kind] or ""
			end
			if S.label_mode ~= "off" then
				parts[#parts + 1] = string.format("%dm", metres)
			end
			local text = table.concat(parts, " ")
			if text ~= "" then
			local lx = (maxx or tx) + LABEL_MARGIN
			local ly = (miny or ty) - LABEL_MARGIN
			local lc = LABEL_COLOURS[S.label_colour]
			local colour
			if lc then
				colour = Color(lc[1] * t.factor, lc[2], lc[3], lc[4])
			else
				colour = Color(255 * t.factor, rgb[1], rgb[2], rgb[3])
			end
			draw_text(gui, text, font, label_size, lx, ly, layer + 1, colour)
			end
		end
	end
end

-- Called every frame from the HudElementCrosshair.update hook in the main file.
mod.draw_overlay = function(ui_renderer)
	if mod._draw_failed or not mod:is_enabled() then
		mod.dstate("draw", "skipped (draw_failed=" .. tostring(mod._draw_failed) .. ")")
		return
	end
	local F = mod.frame
	if not F or not F.valid or F.count < 1 then
		mod.dstate("draw", "idle (no valid frame or 0 targets)")
		return
	end
	local gui = ui_renderer and ui_renderer.gui
	if not gui then
		mod.dstate("draw", "no gui in ui_renderer")
		return
	end
	local res = RESOLUTION_LOOKUP or {}
	local W = res.width or 1920
	local H = res.height or 1080

	_tri_budget = 0
	local ok, err = pcall(draw_all, gui, DRAW_LAYER, W, H)
	if not ok then
		mod._draw_failed = true
		mod.dlog("draw ERROR (drawing switched off until /specialtracer_log_clear or reload): " .. tostring(err))
		mod:error("Specials Tracer drawing was switched off after an error: %s", tostring(err))
	end
end

return true
