local mod = get_mod("QIangIQsSpecialTracer")

-- Titles and tooltips are plain strings (localize = false), the way
-- CombatFlow_Data.lua writes its options, so no text goes through DMF's
-- string.format and a stray "%" can never break a label.

local function checkbox(id, default, title, tooltip)
	return { setting_id = id, type = "checkbox", default_value = default, localize = false, title = title, tooltip = tooltip }
end

local function numeric(id, default, low, high, title, tooltip)
	return {
		setting_id = id, type = "numeric", default_value = default, range = { low, high },
		decimals_number = 0, localize = false, title = title, tooltip = tooltip,
	}
end

local function dropdown(id, default, title, tooltip, options)
	return { setting_id = id, type = "dropdown", default_value = default, localize = false, title = title, tooltip = tooltip, options = options }
end

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			checkbox("rave_mode", false, "Rave trappers (rainbow colours)",
				"Only trappers: their tracer, box, skeleton and label constantly cycle through the rainbow, overriding the Colour setting, so they stand out from every other target."),
			numeric("rave_speed", 160, 10, 500, "Rave speed", "How fast the colours cycle (cycles per 100 seconds)."),
			{
				setting_id = "toggle_key",
				type = "keybind",
				default_value = {},
				keybind_trigger = "pressed",
				keybind_type = "function_call",
				function_name = "toggle_tracers",
				localize = false,
				title = "Toggle tracers + boxes (key)",
				tooltip = "Turns every tracer and box on or off without opening the menu.",
			},
			{
				setting_id = "group_targets",
				type = "group",
				localize = false,
				title = "Targets",
				sub_widgets = {
					checkbox("show_trappers", true, "Trappers",
						"Renegade netgunners, at any range up to Max range. From Dio's Handholder: a trapper is dangerous at whatever range it can see you from."),
					checkbox("show_hounds", true, "Hounds",
						"All three hounds: chaos_hound, chaos_armored_hound and chaos_hound_mutator."),
					dropdown("hound_mode", "always", "Hound range rule",
						"Always: every hound up to Max range; hounds outside the pounce range are drawn dimmer.\nPounce range (Dio's): only hounds inside the pounce range, plus a dimmer 6 m warning band just outside it.",
						{
							{ text = "Always (dim outside pounce range)", value = "always" },
							{ text = "Pounce range + warning band (Dio's)", value = "pounce" },
						}),
					numeric("hound_range", 16, 8, 40, "Hound pounce range (m)",
						"16 m is where a hound commits to the leap (leave_distance in the chaos_hound approach action, same for all three hounds). Taken from Dio's Handholder."),
					numeric("max_range", 120, 10, 200, "Max range (m)",
						"Nothing beyond this distance gets a tracer or a box. 120 m is Dio's Handholder trapper cap."),
					checkbox("show_elites", true, "Elites",
						"Every elite breed (breed.tags.elite): ragers, maulers, gunners, bulwarks, crushers, reapers and so on. Taken from the ESP reference mod's breed rules."),
					checkbox("show_bosses", true, "Bosses",
						"Every boss breed (breed.is_boss), same rule as the ESP reference mod."),
					{
						setting_id = "group_other_specials",
						type = "group",
						localize = false,
						title = "Other specials",
						sub_widgets = {
							checkbox("show_bombers", false, "Poxbursters", "chaos_poxwalker_bomber"),
							checkbox("show_flamers", false, "Flamers", "cultist_flamer, renegade_flamer, renegade_flamer_mutator"),
							checkbox("show_grenadiers", false, "Bombers (grenadiers)", "cultist_grenadier, renegade_grenadier"),
							checkbox("show_mutants", false, "Mutants", "cultist_mutant, cultist_mutant_mutator"),
							checkbox("show_snipers", false, "Snipers", "renegade_sniper"),
						},
					},
				},
			},
			{
				setting_id = "group_tracers",
				type = "group",
				localize = false,
				title = "Tracers",
				sub_widgets = {
					checkbox("tracers_enabled", true, "Tracers On/Off",
						"A line from the centre of your screen (crosshair) to each target's centre of mass."),
					dropdown("tracer_style", "screen", "Tracer style",
						"Screen: thick anti-aliased lines drawn on the HUD (CombatFlow's quad rasteriser), width set below.\nWorld (Dio's): thin 1-pixel world lines through LineObject, exactly as Dio's Handholder draws them.",
						{
							{ text = "Screen - thick (CombatFlow)", value = "screen" },
							{ text = "World - thin (Dio's)", value = "world" },
						}),
					numeric("tracer_thickness", 2, 1, 8, "Tracer thickness (px)", "Line width for the Screen style."),
					checkbox("show_offscreen", true, "Targets behind you",
						"Screen style: a target behind the camera still gets a line, running from the crosshair to the screen edge on its side."),
					dropdown("colour_mode", "health", "Colour",
						"Health (ESP reference): the type colour (special cyan/red/amber, elite green, boss purple) fades to red as the target loses health.\nThreat (Dio's): trapper red, hound amber, other specials cyan.\nDistance (CombatFlow): red when close, yellow when far, smoothly from 3 m to 22 m.\nRave (Dio's): colours cycle through the spectrum - harder to read, cosmetic only.",
						{
							{ text = "By health (type colour to red)", value = "health" },
							{ text = "By threat (Dio's)", value = "threat" },
							{ text = "By distance (CombatFlow)", value = "distance" },
							{ text = "Rave (Dio's)", value = "rave" },
						}),
				},
			},
			{
				setting_id = "group_boxes",
				type = "group",
				localize = false,
				title = "Boxes",
				sub_widgets = {
					checkbox("boxes_enabled", true, "Boxes On/Off",
						"Draw a box around every tracked target. Sized from the unit's own bounding box (Unit.box), so hounds and trappers are boxed to their real shape."),
					dropdown("box_style", "simple", "Box style",
						"Simple (ESP reference): feet and head projected to the screen, width half the height. Works for every unit.\n3D box: the unit's bounding box as a wireframe cube.\n2D box: a flat rectangle around it on screen.\nBrackets (CombatFlow): the Headhunter [ ] brackets, sized to the whole body.",
						{
							{ text = "Simple (ESP reference)", value = "simple" },
							{ text = "3D box", value = "box3d" },
							{ text = "2D box", value = "box2d" },
							{ text = "Brackets (CombatFlow)", value = "brackets" },
						}),
					checkbox("box_animation", true, "Gate-open animation (CombatFlow)",
						"Boxes ease open from the target's centre when it appears and close when it goes, one after another like CombatFlow's Headhunter brackets."),
				},
			},
			{
				setting_id = "group_skeleton",
				type = "group",
				localize = false,
				title = "Skeleton",
				sub_widgets = {
					checkbox("skeleton_enabled", true, "Draw skeletons",
						"A stick figure through each target's joints (spine, arms, legs, head), like ESP skeletons. Only the 14 nearest targets in range are drawn."),
					numeric("skeleton_range", 60, 10, 200, "Skeleton range", "Targets further away than this get no skeleton (metres)."),
				},
			},
			{
				setting_id = "group_combatflow",
				type = "group",
				localize = false,
				title = "CombatFlow options",
				sub_widgets = {
					dropdown("line_of_sight", "off", "Line of Sight",
						"From CombatFlow's Headhunter. Checks for a clear line from your camera to the target, using the game's own collision filters.\nOff: draw everything, walls or not.\nDim when hidden: targets behind cover are drawn faint.\nHide when hidden: only targets you can actually see (CombatFlow's behaviour).",
						{
							{ text = "Off (see through walls)", value = "off" },
							{ text = "Dim when hidden", value = "dim" },
							{ text = "Hide when hidden (CombatFlow)", value = "hide" },
						}),
					checkbox("show_names", true, "Show names",
						"Write the enemy's name (Trapper, Hound, Sniper...) next to each target. Switch off to keep only the distance."),
					dropdown("label_mode", "name", "Distance label",
						"Text next to each box. Distance uses CombatFlow's readout format (\"12m\").",
						{
							{ text = "Off", value = "off" },
							{ text = "Distance", value = "distance" },
							{ text = "Name + distance", value = "name" },
						}),
					dropdown("label_colour", "white", "Label colour", "CombatFlow's text palette.",
						{
							{ text = "White", value = "white" },
							{ text = "Yellow", value = "yellow" },
							{ text = "Cyan", value = "cyan" },
							{ text = "Green", value = "green" },
							{ text = "Same as tracer", value = "tracer" },
						}),
					numeric("label_size", 18, 10, 40, "Label size", "Font size of the label, before HUD scale."),
				},
			},
		},
	},
}
