local mod = get_mod("QIangIQsSpecialTracer")

--[[
    SPECIALS TRACER

    Lines from the crosshair to the centre of mass of trappers and hounds
    (other specials optional), plus toggleable boxes around them.

    Where each part comes from:

    Dio's Handholder (DiosHandholder_tracers.lua)
        - the target scan: side_system alive_units_by_tag("enemy", "special")
          every 0.25 s, filtered by exact breed name
        - trapper/hound breed names, the 16 m pounce range and the 6 m warning
          band, the 120 m cap, the dimmed band alpha (110)
        - trapper red / hound amber, rave mode
        - "World" tracer style: LineObject reset / add_line / dispatch from a
          point 0.35 m in front of the camera

    CombatFlow (modules/visor.lua, headhunter.lua, HudElementCombatFlow.lua,
    CombatFlow_utils.lua)
        - camera basis from camera_pose, Camera.world_to_screen projection
        - the thick anti-aliased screen line rasteriser ("Screen" style)
        - Headhunter bracket shape, gate-open animation (open 4/s, close 5/s,
          0.13 s stagger, smoothstep), bracket alpha and thickness formulas
        - distance colour red (3 m) -> yellow (22 m)
        - Line of Sight raycast and its two collision filters
        - "%dm" distance readout, text colour palette

    Game source
        - centre of mass: HitZone.hit_zone_center_of_mass(unit, "center_mass",
          true), the average of the breed's center_mass hit-zone actors
          (scripts/utilities/attack/hit_zone.lua)
        - box: Unit.box(unit, true) pose + half extents, read the way
          target_selection.lua reads them (x = right, y = forward, z = up)

    Every engine global is looked up at call time (Dio's rule): Vector3,
    Unit, Color, LineObject and friends are nil when a mod file loads.
--]]

local function g(name)
	return rawget(_G, name)
end

local ok_hz, HitZone = pcall(require, "scripts/utilities/attack/hit_zone")
if not ok_hz then
	HitZone = nil
end

-- ------------------------------------------------------------ debug log --

-- Writes ./../mods/QIangIQsSpecialTracer/debug.log (the game's cwd is
-- <install>/binaries/; DMF sandboxes io, the pre-sandbox copy is Mods.lua.io,
-- the same way QIangIQsTarkAccount logs). dlog(text) always writes;
-- dstate(key, text) writes only when the text for that key changes, so
-- per-frame checks do not flood the file. Commands: /specialtracer_log and
-- /specialtracer_log_clear.
local LOG_PATH = "./../mods/QIangIQsSpecialTracer/debug.log"
local LOG_MAX_BYTES = 512 * 1024
local _dstate = {}

local function log_io()
	local mods = rawget(_G, "Mods")
	return mods and mods.lua and mods.lua.io or nil
end

local function dlog(text)
	local io_lib = log_io()
	if not io_lib then
		return
	end
	pcall(function()
		local f = io_lib.open(LOG_PATH, "a")
		if not f then
			return
		end
		f:write(string.format("[%s] %s\n", tostring(os.date("%H:%M:%S")), text))
		f:close()
	end)
end

local function dstate(key, text)
	if _dstate[key] == text then
		return
	end
	_dstate[key] = text
	dlog(key .. ": " .. text)
end

-- Keep the file bounded: start fresh when it passed the cap at load time.
pcall(function()
	local io_lib = log_io()
	local f = io_lib and io_lib.open(LOG_PATH, "r")
	if f then
		local size = f:seek("end")
		f:close()
		if size and size > LOG_MAX_BYTES then
			local w = io_lib.open(LOG_PATH, "w")
			if w then
				w:close()
			end
		end
	end
end)

mod.dlog = dlog
mod.dstate = dstate

-- ------------------------------------------------------------ constants --

local KIND_BY_BREED = {
	renegade_netgunner = "trapper",
	chaos_hound = "hound",
	chaos_armored_hound = "hound",
	chaos_hound_mutator = "hound",
	chaos_poxwalker_bomber = "bomber",
	cultist_flamer = "flamer",
	renegade_flamer = "flamer",
	renegade_flamer_mutator = "flamer",
	cultist_grenadier = "grenadier",
	renegade_grenadier = "grenadier",
	cultist_mutant = "mutant",
	cultist_mutant_mutator = "mutant",
	renegade_sniper = "sniper",
}

-- Breed hazards are never tracked (ESP reference mod filter).
local function is_hazard(breed)
	local n = breed.name
	return n and n:find("hazard") and true or false
end

local KIND_SETTING = {
	trapper = "show_trappers",
	hound = "show_hounds",
	bomber = "show_bombers",
	flamer = "show_flamers",
	grenadier = "show_grenadiers",
	mutant = "show_mutants",
	sniper = "show_snipers",
	elite = "show_elites",
	boss = "show_bosses",
}

mod.KIND_NAME = {
	trapper = "Trapper",
	hound = "Hound",
	bomber = "Poxburster",
	flamer = "Flamer",
	grenadier = "Bomber",
	mutant = "Mutant",
	sniper = "Sniper",
	elite = "Elite",
	boss = "Boss",
}

local SCAN_INTERVAL = 0.25     -- Dio's scan throttle
local WARNING_BAND = 6         -- Dio's band above the pounce radius
local DIM_ALPHA = 110 / 255    -- Dio's band alpha, reused for every "dim"
local WORLD_ORIGIN_AHEAD = 0.35 -- Dio's tracer origin in front of the camera

-- Dio's threat colours; other specials use CombatFlow's cyan scheme.
local THREAT_RGB = {
	trapper = { 255, 60, 50 },
	hound = { 255, 175, 40 },
	elite = { 100, 255, 60 },
	boss = { 170, 60, 255 },
	other = { 0.20 * 255, 1.00 * 255, 1.00 * 255 },
}

local HEALTH_LOW_RGB = { 255, 0, 0 } -- ESP reference: colour runs from red (dead) to the type colour (full)

-- CombatFlow distance colour.
local BR_NEAR = { 1.00, 0.25, 0.20 }
local BR_FAR = { 1.00, 0.90, 0.30 }
local BR_DIST_NEAR = 3
local BR_DIST_FAR = 22

-- CombatFlow Headhunter gate animation.
local OPEN_RATE = 4.0
local CLOSE_RATE = 5.0
local STAGGER = 0.13

local RAVE_SPEED = 1.6

-- ------------------------------------------------------------- settings --

local S = {}

local SETTING_DEFAULTS = {
	show_trappers = true, show_hounds = true, hound_mode = "always", hound_range = 16, max_range = 120,
	show_bombers = false, show_flamers = false, show_grenadiers = false, show_mutants = false, show_snipers = false, show_elites = true, show_bosses = true,
	tracers_enabled = true, tracer_style = "screen", tracer_thickness = 2, show_offscreen = true, colour_mode = "health",
	boxes_enabled = true, box_style = "simple", box_animation = true,
	line_of_sight = "off", label_mode = "name", label_colour = "white", label_size = 18,
	show_names = true, skeleton_enabled = true, skeleton_range = 60,
	rave_mode = false, rave_speed = 160,
}

local function read_settings()
	for id, default in pairs(SETTING_DEFAULTS) do
		local ok, v = pcall(mod.get, mod, id)
		if not ok or v == nil or type(v) ~= type(default) then
			v = default
		end
		S[id] = v
	end
end

read_settings()
mod.settings = S

local function settings_line()
	local keys = {}
	for id in pairs(SETTING_DEFAULTS) do
		keys[#keys + 1] = id
	end
	table.sort(keys)
	local parts = {}
	for i = 1, #keys do
		parts[i] = keys[i] .. "=" .. tostring(S[keys[i]])
	end
	return table.concat(parts, " ")
end

dlog("BOOT QIangIQsSpecialTracer loaded; hit_zone=" .. tostring(HitZone ~= nil) .. "; " .. settings_line())

mod.on_setting_changed = function()
	read_settings()
	dlog("settings changed: " .. settings_line())
end

-- ---------------------------------------------------------------- state --

local clock = 0
local scanned = { units = {}, at = -math.huge }
local los_cache = setmetatable({}, { __mode = "k" })
local track = setmetatable({}, { __mode = "k" })

-- What the HUD element draws this frame. Everything in here is a plain Lua
-- table - an engine Vector3 is a per-frame temporary (CombatFlow's rule).
local frame = {
	valid = false,
	o = { x = 0, y = 0, z = 0 }, f = { x = 0, y = 1, z = 0 },
	r = { x = 1, y = 0, z = 0 }, u = { x = 0, y = 0, z = 1 },
	targets = {}, count = 0,
	clock = 0,
}
mod.frame = frame
mod._hidden = false

-- ---------------------------------------------------------- vector math --

local function to_plain(v, out, tag)
	out = out or {}
	-- Plain Vector3 first; some values (Vector3Box etc.) need unboxing or the
	-- Vector3.x/y/z accessors. The tag names the caller in the error message.
	local ok, x, y, z = pcall(function() return v.x, v.y, v.z end)
	if not ok then
		ok, x, y, z = pcall(function()
			local u = v:unbox()
			return u.x, u.y, u.z
		end)
	end
	if not ok then
		ok, x, y, z = pcall(function() return Vector3.x(v), Vector3.y(v), Vector3.z(v) end)
	end
	if not ok then
		error("to_plain(" .. tostring(tag) .. ") cannot read " .. tostring(v) .. " type=" .. type(v), 0)
	end
	out.x, out.y, out.z = x, y, z
	return out
end

local function dist3(a, b)
	local dx, dy, dz = a.x - b.x, a.y - b.y, a.z - b.z
	return math.sqrt(dx * dx + dy * dy + dz * dz)
end

local function clamp(v, a, b)
	return v < a and a or (v > b and b or v)
end

-- ------------------------------------------------------------- helpers --

local function alive(unit)
	local ALIVE = g("ALIVE")
	if not ALIVE or not ALIVE[unit] then
		return false
	end
	-- HEALTH_ALIVE drops a unit as soon as it dies, while ALIVE keeps the
	-- ragdoll until it despawns (CombatFlow enumerates HEALTH_ALIVE).
	local HEALTH_ALIVE = g("HEALTH_ALIVE")
	if HEALTH_ALIVE and not HEALTH_ALIVE[unit] then
		return false
	end
	return true
end

local function local_player()
	local pm = Managers and Managers.player
	if not pm or not pm.local_player_safe then
		return nil
	end
	-- local_player_safe, not local_player (Dio's note: the latter faults
	-- outside a session).
	local ok, p = pcall(pm.local_player_safe, pm, 1)
	return ok and p or nil
end

local function unit_breed(unit)
	local ScriptUnit = g("ScriptUnit")
	if not ScriptUnit or not ScriptUnit.has_extension then
		return nil
	end
	local ok, ext = pcall(ScriptUnit.has_extension, unit, "unit_data_system")
	if not ok or not ext or not ext.breed then
		return nil
	end
	local ok2, breed = pcall(ext.breed, ext)
	if not ok2 or type(breed) ~= "table" then
		return nil
	end
	return breed
end

local function read_player_side(side_system)
	local name = side_system:get_default_player_side_name()
	return side_system:get_side_from_name(name)
end

-- Which kind a breed is tracked as, or nil. The dedicated specials come from
-- KIND_BY_BREED; every other elite / boss follows the ESP reference mod's
-- breed rules (breed.is_boss, tags.elite).
local function kind_of(breed)
	local kind = KIND_BY_BREED[breed.name]
	if kind then
		return kind
	end
	if is_hazard(breed) then
		return nil
	end
	if breed.is_boss then
		return "boss"
	end
	local tags = breed.tags
	if tags and tags.elite then
		return "elite"
	end
	return nil
end

-- Primary scan (ESP reference mod): every minion with a locomotion extension.
local function scan_entities()
	local units = {}
	local ext = Managers.state and Managers.state.extension
	if not ext then
		return units, false
	end
	local entities = ext:get_entities("MinionHuskLocomotionExtension")
	if next(entities) == nil then
		entities = ext:get_entities("MinionLocomotionExtension")
	end
	if next(entities) == nil then
		return units, false
	end
	for unit in pairs(entities) do
		local breed = unit_breed(unit)
		local kind = breed and kind_of(breed)
		if kind then
			units[#units + 1] = { unit = unit, kind = kind, name_key = breed.display_name }
		end
	end
	return units, true
end

-- Fallback scan (Dio's): the game's own per-tag list, specials only.
local function scan_side()
	local units = {}
	local ext = Managers.state and Managers.state.extension
	local side_system = ext and ext:system("side_system")
	if not side_system then
		return units
	end
	local ok, side = pcall(read_player_side, side_system)
	if not ok or not side or not side.alive_units_by_tag then
		return units
	end
	local ok2, list = pcall(side.alive_units_by_tag, side, "enemy", "special")
	if not ok2 or type(list) ~= "table" then
		return units
	end
	for i = 1, list.size or 0 do
		local unit = list[i]
		local breed = unit and unit_breed(unit)
		local kind = breed and KIND_BY_BREED[breed.name]
		if kind then
			units[#units + 1] = { unit = unit, kind = kind, name_key = breed.display_name }
		end
	end
	return units
end

local function scan()
	local ok, units, found = pcall(scan_entities)
	if ok and found then
		return units
	end
	if not ok then
		dstate("scan_entities ERROR", tostring(units))
	end
	return scan_side()
end

-- CombatFlow Utils.get_camera_data: camera_pose of the local viewport.
local function read_pose(cam_mgr, vp)
	local pose = cam_mgr:camera_pose(vp)
	local rot = Matrix4x4.rotation(pose)
	local pos = Matrix4x4.translation(pose)
	return pos, Quaternion.forward(rot), Quaternion.right(rot), Quaternion.up(rot)
end

local function camera_basis(player)
	local vp = player and player.viewport_name
	local cam_mgr = Managers.state and Managers.state.camera
	if not vp or not cam_mgr or not cam_mgr:has_viewport(vp) then
		return false
	end
	local ok, pos, fwd, right, up = pcall(read_pose, cam_mgr, vp)
	if not ok or not pos or not fwd then
		return false
	end
	to_plain(pos, frame.o, "pos")
	to_plain(fwd, frame.f, "fwd")
	to_plain(right, frame.r, "right")
	to_plain(up, frame.u, "up")
	return true
end

-- Centre of mass: the game's own average of the center_mass hit-zone actors.
local function com_read(unit)
	return HitZone.hit_zone_center_of_mass(unit, "center_mass", true)
end

local function box_read(unit)
	local pose, half = Unit.box(unit, true)
	return Matrix4x4.translation(pose), Matrix4x4.right(pose), Matrix4x4.forward(pose), Matrix4x4.up(pose), half
end

local function read_box(unit, out)
	local ok, c, r, f, u, half = pcall(box_read, unit)
	if not ok or not c or not half then
		return nil
	end
	out.c = to_plain(c, out.c, "box.c")
	out.r = to_plain(r, out.r, "box.r")
	out.f = to_plain(f, out.f, "box.f")
	out.u = to_plain(u, out.u, "box.u")
	out.hx, out.hy, out.hz = half.x, half.y, half.z
	return out
end

local function read_com(unit, box, out)
	if HitZone then
		local ok, p = pcall(com_read, unit)
		if ok and p then
			return to_plain(p, out, "com")
		end
	end
	if box and box.c then
		out.x, out.y, out.z = box.c.x, box.c.y, box.c.z
		return out
	end
	local lookup = g("POSITION_LOOKUP")
	local p = lookup and lookup[unit]
	if p then
		local pok2, res = pcall(to_plain, p, out, "com_lookup")
		if pok2 then
			return res
		end
	end
	return nil
end

-- CombatFlow Utils.head_los, pointed at the centre of mass.
local LOS_FILTERS = { "filter_player_character_shooting_raycast_statics", "filter_minion_line_of_sight_check" }

local function physics_world()
	local wm = Managers.world
	if not wm or not wm.has_world or not wm:has_world("level_world") then
		return nil
	end
	local ok, world = pcall(wm.world, wm, "level_world")
	if not ok or not world then
		return nil
	end
	local ok2, pw = pcall(World.physics_world, world)
	return ok2 and pw or nil
end

local function los_clear(from, to, target_unit)
	local pw = physics_world()
	if not pw then
		return true
	end
	local dx, dy, dz = to.x - from.x, to.y - from.y, to.z - from.z
	local d = math.sqrt(dx * dx + dy * dy + dz * dz)
	if d < 0.1 then
		return true
	end
	for i = 1, #LOS_FILTERS do
		local ok, hit, _, _, _, hit_actor = pcall(PhysicsWorld.raycast, pw,
			Vector3(from.x, from.y, from.z), Vector3(dx / d, dy / d, dz / d), d,
			"closest", "collision_filter", LOS_FILTERS[i])
		if ok and not hit then
			return true
		end
		if ok then
			local ok_u, hu = pcall(Actor.unit, hit_actor)
			return ok_u and hu == target_unit
		end
	end
	return true
end

local function visible(unit, com)
	local c = los_cache[unit]
	if c and clock - c.at < SCAN_INTERVAL then
		return c.clear
	end
	c = c or {}
	c.at = clock
	c.clear = los_clear(frame.o, com, unit)
	los_cache[unit] = c
	return c.clear
end

-- Dio's rave hue.
local function rave_rgb(t, offset)
	local h = ((t * ((S.rave_speed or 160) / 100) + (offset or 0)) % 1) * 6
	local i = math.floor(h)
	local f = h - i
	local q = 1 - f
	if i == 0 then return 255, math.floor(f * 255), 0 end
	if i == 1 then return math.floor(q * 255), 255, 0 end
	if i == 2 then return 0, 255, math.floor(f * 255) end
	if i == 3 then return 0, math.floor(q * 255), 255 end
	if i == 4 then return math.floor(f * 255), 0, 255 end
	return 255, 0, math.floor(q * 255)
end

local name_cache = {}

local function localized_name(entry)
	local key = entry.name_key
	if not key then
		return nil
	end
	local c = name_cache[key]
	if c == nil then
		local L = rawget(_G, "Localize")
		local ok, txt = pcall(L, key)
		c = ok and type(txt) == "string" and txt or false
		name_cache[key] = c
	end
	return c or nil
end

local function health_pct(unit)
	local ScriptUnit = g("ScriptUnit")
	local ok, v = pcall(function()
		local h = ScriptUnit.has_extension(unit, "health_system")
		if not h then
			return nil
		end
		local max = h:max_health()
		return max > 0 and h:current_health() / max or 1
	end)
	if ok and v then
		return clamp(v, 0, 1)
	end
	return 1
end

local function colour_for(kind, dist, index, out, health)
	local mode = (S.rave_mode and kind == "trapper") and "rave" or S.colour_mode
	if mode == "health" then
		local base = THREAT_RGB[kind] or THREAT_RGB.other
		local h = health or 1
		for c = 1, 3 do
			out[c] = clamp(HEALTH_LOW_RGB[c] + (base[c] - HEALTH_LOW_RGB[c]) * h, 0, 255)
		end
	elseif mode == "rave" then
		out[1], out[2], out[3] = rave_rgb(clock, (kind == "hound" and 0.5 or 0) + index * 0.11)
	elseif mode == "distance" then
		local dn = clamp((dist - BR_DIST_NEAR) / (BR_DIST_FAR - BR_DIST_NEAR), 0, 1)
		out[1] = (BR_NEAR[1] + (BR_FAR[1] - BR_NEAR[1]) * dn) * 255
		out[2] = (BR_NEAR[2] + (BR_FAR[2] - BR_NEAR[2]) * dn) * 255
		out[3] = (BR_NEAR[3] + (BR_FAR[3] - BR_NEAR[3]) * dn) * 255
	else
		local rgb = THREAT_RGB[kind] or THREAT_RGB.other
		out[1], out[2], out[3] = rgb[1], rgb[2], rgb[3]
	end
	return out
end

-- Returns the alpha factor (1 or DIM_ALPHA) or nil when not drawn at all.
local function range_rule(kind, dist)
	if dist > S.max_range then
		return nil
	end
	if kind ~= "hound" then
		return 1
	end
	local radius = S.hound_range
	if dist <= radius then
		return 1
	end
	if S.hound_mode == "pounce" then
		return dist <= radius + WARNING_BAND and DIM_ALPHA or nil
	end
	return DIM_ALPHA
end

-- --------------------------------------------------------- frame build --

local seen = {}

local BOX_KEYS = { "c", "r", "f", "u" }

local function copy_target(src, dst)
	dst.com.x, dst.com.y, dst.com.z = src.com.x, src.com.y, src.com.z
	for i = 1, #BOX_KEYS do
		local key = BOX_KEYS[i]
		local a = src.box[key]
		if a then
			local b = dst.box[key] or {}
			dst.box[key] = b
			b.x, b.y, b.z = a.x, a.y, a.z
		end
	end
	dst.box.hx, dst.box.hy, dst.box.hz = src.box.hx, src.box.hy, src.box.hz
	dst.rgb[1], dst.rgb[2], dst.rgb[3] = src.rgb[1], src.rgb[2], src.rgb[3]
	dst.kind, dst.dist, dst.factor = src.kind, src.dist, src.factor
	dst.name, dst.height = src.name, src.height
	if src.pos then
		dst.pos = dst.pos or {}
		dst.pos.x, dst.pos.y, dst.pos.z = src.pos.x, src.pos.y, src.pos.z
	end
end

-- ------------------------------------------------------------ skeleton --

-- Humanoid joint chains (names seen across the minion breeds). Consecutive
-- joints that exist on the unit are joined into stick-figure segments.
local SKEL_CHAINS = {
	{ "j_hips", "j_spine", "j_spine1", "j_spine2", "j_neck", "j_head" },
	{ "j_neck", "j_leftshoulder", "j_leftarm", "j_leftforearm", "j_lefthand" },
	{ "j_neck", "j_rightshoulder", "j_rightarm", "j_rightforearm", "j_righthand" },
	{ "j_hips", "j_leftupleg", "j_leftleg", "j_leftfoot", "j_lefttoebase" },
	{ "j_hips", "j_rightupleg", "j_rightleg", "j_rightfoot", "j_righttoebase" },
}
local skel_nodes = setmetatable({}, { __mode = "k" })

local function skel_index(unit)
	local c = skel_nodes[unit]
	if c then
		return c
	end
	c = {}
	for ci = 1, #SKEL_CHAINS do
		local list = {}
		local chain = SKEL_CHAINS[ci]
		for k = 1, #chain do
			local ok, has = pcall(Unit.has_node, unit, chain[k])
			if ok and has then
				list[#list + 1] = Unit.node(unit, chain[k])
			end
		end
		c[ci] = list
	end
	skel_nodes[unit] = c
	return c
end

-- Fills t.skel with flat world-space segment endpoints (x1,y1,z1,x2,y2,z2,...).
local function gather_skeleton(unit, t)
	local idx = skel_index(unit)
	local a = t.skel or {}
	t.skel = a
	local n = 0
	for ci = 1, #idx do
		local list = idx[ci]
		local have, px, py, pz = false, 0, 0, 0
		for k = 1, #list do
			local v = Unit.world_position(unit, list[k])
			local x, y, z = v.x, v.y, v.z
			if have then
				a[n + 1], a[n + 2], a[n + 3], a[n + 4], a[n + 5], a[n + 6] = px, py, pz, x, y, z
				n = n + 6
			end
			have, px, py, pz = true, x, y, z
		end
	end
	t.skel_n = n
end

local function build_frame(dt)
	frame.valid = false
	frame.count = 0
	frame.clock = clock

	if mod._hidden or (not S.tracers_enabled and not S.boxes_enabled) then
		dstate("frame", "idle (hidden=" .. tostring(mod._hidden) .. " tracers=" .. tostring(S.tracers_enabled) .. " boxes=" .. tostring(S.boxes_enabled) .. ")")
		return
	end

	local player = local_player()
	local me = player and player.player_unit
	if not me or not alive(me) then
		dstate("frame", "no live local player unit")
		return
	end

	local lookup = g("POSITION_LOOKUP")
	local pok, my_pos = pcall(Unit.world_position, me, 1)
	if not pok then
		my_pos = lookup and lookup[me]
	end
	if not my_pos then
		dstate("frame", "no player position")
		return
	end
	local mp = to_plain(my_pos, {}, "my_pos")

	if not camera_basis(player) then
		dstate("frame", "no camera basis (viewport/camera_pose failed)")
		return
	end

	if clock - scanned.at >= SCAN_INTERVAL then
		scanned.at = clock
		scanned.units = scan()
		local names = {}
		for i = 1, #scanned.units do
			names[i] = scanned.units[i].kind
		end
		table.sort(names)
		dstate("scan", string.format("%d tracked special(s): %s", #scanned.units, table.concat(names, ",")))
	end

	for k in pairs(seen) do
		seen[k] = nil
	end

	local targets = frame.targets
	local n = 0
	local list = scanned.units
	local queue = 0
	local skel_count = 0

	for i = 1, #list do
		local entry = list[i]
		local unit = entry.unit
		if S[KIND_SETTING[entry.kind]] and alive(unit) then
			n = n + 1
			local t = targets[n] or { com = {}, box = {}, rgb = {} }
			targets[n] = t

			local box = read_box(unit, t.box)
			local com = read_com(unit, box, t.com)
			local dist = com and dist3(mp, com)
			local factor = dist and range_rule(entry.kind, dist)

			if factor and S.line_of_sight ~= "off" and not visible(unit, com) then
				if S.line_of_sight == "hide" then
					factor = nil
				else
					factor = factor * DIM_ALPHA
				end
			end

			if not factor then
				dstate("target " .. tostring(entry.kind), string.format("com=%s dist=%s box=%s", tostring(com ~= nil), tostring(dist and math.floor(dist)), tostring(box ~= nil)))
				n = n - 1
			else
				dstate("target " .. tostring(entry.kind), "drawn")
				t.unit = unit
				t.kind = entry.kind
				t.dist = dist
				t.factor = factor
				t.has_box = box ~= nil
				t.live = true
				t.name = localized_name(entry)
				t.pos = t.pos or {}
				local up = lookup and lookup[unit]
				local up_ok = false
				if up then
					-- POSITION_LOOKUP entries can be stale Vector3s; fall back to the box/COM
					up_ok = pcall(to_plain, up, t.pos, "lookup")
				end
				if not up_ok then
					t.pos.x, t.pos.y, t.pos.z = t.com.x, t.com.y, t.com.z - 1.0
				end
				-- Height from the head bone (the unit bounds include weapons and
				-- animation sweeps and ran about half a metre too tall); a per-kind
				-- default when there is no j_head node.
				local default_h = (entry.kind == "hound" and 1.0) or (entry.kind == "boss" and 3.2) or 1.9
				t.height = default_h
				local hok, head_z = pcall(function()
					if Unit.has_node(unit, "j_head") then
						return Unit.world_position(unit, Unit.node(unit, "j_head")).z
					end
				end)
				if hok and head_z then
					local hh = head_z - t.pos.z + 0.2
					if hh > 0.5 and hh < 5 then
						t.height = hh
					end
				end
				if S.skeleton_enabled and dist <= S.skeleton_range and skel_count < 14 then
					skel_count = skel_count + 1
					local okk, errk = pcall(gather_skeleton, unit, t)
					if not okk then
						t.skel_n = 0
						dstate("skeleton", tostring(errk))
					end
				else
					t.skel_n = 0
				end
				colour_for(entry.kind, dist, i, t.rgb, health_pct(unit))

				-- CombatFlow gate: a fresh target re-queues with a stagger.
				local tr = track[unit]
				if not tr or tr.state == "out" then
					tr = tr or {}
					tr.anim = tr.anim or 0
					tr.state = "in"
					tr.delay = queue * STAGGER
					queue = queue + 1
					track[unit] = tr
				end
				-- Own snapshot, so a closing box never reads a target slot
				-- that another unit reuses next frame.
				if box then
					tr.snap = tr.snap or { com = {}, box = {}, rgb = {} }
					copy_target(t, tr.snap)
				else
					tr.snap = nil
				end
				seen[unit] = true
			end
		end
	end

	-- Targets that just left (died, out of range, hidden) close in place.
	for unit, tr in pairs(track) do
		if not seen[unit] then
			tr.state = "out"
		end
	end

	for unit, tr in pairs(track) do
		if tr.state == "in" then
			if tr.delay and tr.delay > 0 then
				tr.delay = tr.delay - dt
			else
				tr.anim = math.min(1, tr.anim + dt * OPEN_RATE)
			end
		else
			tr.anim = tr.anim - dt * CLOSE_RATE
			if tr.anim <= 0 then
				track[unit] = nil
			elseif tr.snap then
				-- Keep drawing the closing box at its last position.
				n = n + 1
				local t = targets[n] or { com = {}, box = {}, rgb = {} }
				targets[n] = t
				copy_target(tr.snap, t)
				t.unit = unit
				t.has_box = true
				t.live = false
			end
		end
	end

	for i = 1, n do
		local t = targets[i]
		local tr = track[t.unit]
		t.anim = S.box_animation and (tr and tr.anim or 0) or 1
	end

	for i = n + 1, #targets do
		targets[i].unit = nil
	end

	frame.count = n
	frame.valid = true
	dstate("frame", string.format("ok, %d target(s) this frame", n))
end

-- ---------------------------------------------- Dio's world-line style --

local line_object, line_world = nil, nil

local function drop_line_object()
	line_object, line_world = nil, nil
end

local function ensure_line_object()
	local wm = Managers.world
	local World = g("World")
	local LineObject = g("LineObject")
	if not wm or not World or not LineObject or not wm.has_world or not wm:has_world("level_world") then
		return nil
	end
	local ok_world, world = pcall(wm.world, wm, "level_world")
	if not ok_world or not world then
		return nil
	end
	if line_world ~= world or not line_object then
		drop_line_object()
		local ok, obj = pcall(World.create_line_object, world)
		if not ok or not obj then
			return nil
		end
		line_object, line_world = obj, world
	end
	return line_object, world, LineObject
end

-- Reset + dispatch an empty object so the last frame's lines disappear
-- (Dio: returning early instead would freeze them on screen).
local function clear_world_lines()
	if not line_object or not line_world then
		return
	end
	local LineObject = g("LineObject")
	if LineObject then
		pcall(LineObject.reset, line_object)
		pcall(LineObject.dispatch, line_world, line_object)
	end
	drop_line_object()
end

local function draw_world_lines()
	local obj, world, LineObject = ensure_line_object()
	if not obj then
		return
	end
	if not pcall(LineObject.reset, obj) then
		drop_line_object()
		return
	end
	local o, f = frame.o, frame.f
	local from = Vector3(o.x + f.x * WORLD_ORIGIN_AHEAD, o.y + f.y * WORLD_ORIGIN_AHEAD, o.z + f.z * WORLD_ORIGIN_AHEAD)
	for i = 1, frame.count do
		local t = frame.targets[i]
		if t.live then
			local c = t.rgb
			pcall(LineObject.add_line, obj, Color(255 * t.factor, c[1], c[2], c[3]), from, Vector3(t.com.x, t.com.y, t.com.z))
		end
	end
	if not pcall(LineObject.dispatch, world, obj) then
		drop_line_object()
	end
end

-- ----------------------------------------------------------------- hooks --

mod:command("specialtracer_log", "Print the Specials Tracer debug log path and the last frame state.", function()
	mod:echo("[SpecialsTracer] log: " .. LOG_PATH)
	mod:echo(string.format("[SpecialsTracer] frame valid=%s count=%d, state=%s", tostring(frame.valid), frame.count, tostring(_dstate.frame)))
end)

mod:command("specialtracer_log_clear", "Truncate the Specials Tracer debug log.", function()
	local io_lib = log_io()
	local f = io_lib and io_lib.open(LOG_PATH, "w")
	if f then
		f:close()
		for k in pairs(_dstate) do
			_dstate[k] = nil
		end
		mod._draw_failed = false
		mod:echo("[SpecialsTracer] log cleared")
	else
		mod:echo("[SpecialsTracer] log clear failed (no io)")
	end
end)


mod.update = function(dt)
	dt = dt or 0
	clock = clock + dt

	local ok, err = pcall(build_frame, dt)
	if not ok then
		frame.valid = false
		frame.count = 0
		dstate("build_frame ERROR", tostring(err))
	end

	local world_style = frame.valid and S.tracers_enabled and S.tracer_style == "world"
	if world_style then
		local wok, werr = pcall(draw_world_lines)
		if not wok then
			dstate("world_lines ERROR", tostring(werr))
		end
	elseif line_object then
		clear_world_lines()
	end
end

mod.toggle_tracers = function()
	mod._hidden = not mod._hidden
	mod:notify("Specials Tracer %s", mod._hidden and "off" or "on")
end

local function reset_all()
	scanned.units, scanned.at = {}, -math.huge
	frame.valid, frame.count = false, 0
	for k in pairs(track) do
		track[k] = nil
	end
	clear_world_lines()
	drop_line_object()
end

mod.on_game_state_changed = function(status, state_name)
	if status == "exit" then
		reset_all()
	end
end

mod.on_disabled = function()
	reset_all()
end

mod.on_unload = function()
	reset_all()
end

-- Drawing (the ESP reference mod's route): the overlay module is loaded as a
-- plain file and called from HudElementCrosshair.update with that frame's
-- ui_renderer, instead of through a separately registered HUD element.
local ok_draw, err_draw = pcall(mod.io_dofile, mod, "QIangIQsSpecialTracer/scripts/mods/QIangIQsSpecialTracer/HudElementQIangIQsSpecialTracer")
if not ok_draw then
	dlog("draw module load ERROR: " .. tostring(err_draw))
end

mod:hook_safe("HudElementCrosshair", "update", function(self, dt, t, ui_renderer, render_settings, input_service)
	if not mod.draw_overlay then
		dstate("draw", "draw module not loaded")
		return
	end
	local ok, err = pcall(mod.draw_overlay, ui_renderer)
	if not ok then
		dstate("draw_overlay ERROR", tostring(err))
	end
end)

dlog("hook installed on HudElementCrosshair.update; draw module " .. tostring(ok_draw and mod.draw_overlay ~= nil))
