return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsSpecialTracer` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsSpecialTracer", {
			mod_script       = "QIangIQsSpecialTracer/scripts/mods/QIangIQsSpecialTracer/QIangIQsSpecialTracer",
			mod_data         = "QIangIQsSpecialTracer/scripts/mods/QIangIQsSpecialTracer/QIangIQsSpecialTracer_data",
			mod_localization = "QIangIQsSpecialTracer/scripts/mods/QIangIQsSpecialTracer/QIangIQsSpecialTracer_localization",
		})
	end,
	packages = {},
}
