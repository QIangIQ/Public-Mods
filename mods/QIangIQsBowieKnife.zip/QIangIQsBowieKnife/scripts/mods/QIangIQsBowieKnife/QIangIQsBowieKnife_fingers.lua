local Fingers = {}

local FP_NODES = nil

function Fingers.setup(node_names)
    FP_NODES = node_names
end

local function parent_chain(unit, node)
    local list = {}
    local current = node
    local guard = 0
    while current and guard < 64 do
        list[#list + 1] = current
        if current == 1 then
            break
        end
        current = Unit.scene_graph_parent(unit, current)
        guard = guard + 1
    end
    return list
end

local function root_relative(unit, chain)
    local rotation = Quaternion.identity()
    local position = Vector3(0, 0, 0)
    local first = chain[#chain] == 1 and #chain - 1 or #chain
    for i = first, 1, -1 do
        position = position + Quaternion.rotate(rotation, Unit.local_position(unit, chain[i]))
        rotation = Quaternion.multiply(rotation, Unit.local_rotation(unit, chain[i]))
    end
    return rotation, position
end

function Fingers.driver(driver, fp_unit, finger_nodes)
    local fpd = { driver = driver, fp_unit = fp_unit, nodes = {}, by_node = {}, fp_chains = {}, fingers = {} }
    for i = 1, #FP_NODES do
        local name = FP_NODES[i]
        if Unit.has_node(driver, name) then
            local node = Unit.node(driver, name)
            if node ~= 1 and not fpd.by_node[node] then
                local entry = { node = node, parent = Unit.scene_graph_parent(driver, node) }
                if Unit.has_node(fp_unit, name) then
                    entry.fp = Unit.node(fp_unit, name)
                    fpd.fp_chains[entry.fp] = parent_chain(fp_unit, entry.fp)
                end
                fpd.by_node[node] = entry
                fpd.nodes[#fpd.nodes + 1] = entry
            end
        end
    end
    for _, name in ipairs({ "j_righthand", "j_righthandmiddle1", "j_righthandindex1", "j_righthandpinky1" }) do
        if not Unit.has_node(driver, name) then
            return nil
        end
    end
    local function bind_pose(name)
        return root_relative(driver, parent_chain(driver, Unit.node(driver, name)))
    end
    local hand_r, hand_p = bind_pose("j_righthand")
    local hand_inv = Quaternion.inverse(hand_r)
    local function hand_local(name)
        local _, p = bind_pose(name)
        return Quaternion.rotate(hand_inv, p - hand_p)
    end
    local f = Vector3.normalize(hand_local("j_righthandmiddle1"))
    local u = hand_local("j_righthandindex1") - hand_local("j_righthandpinky1")
    u = Vector3.normalize(u - f * Vector3.dot(u, f))
    fpd.lm = { Vector3Box(f), Vector3Box(u), Vector3Box(Vector3.cross(f, u)) }
    for i = 1, #finger_nodes do
        local name = finger_nodes[i]
        if Unit.has_node(driver, name) then
            local node = Unit.node(driver, name)
            local parent_r = root_relative(driver, parent_chain(driver, Unit.scene_graph_parent(driver, node)))
            fpd.fingers[i] = {
                node = node,
                bind = QuaternionBox(Unit.local_rotation(driver, node)),
                parent_inv = QuaternionBox(Quaternion.inverse(Quaternion.multiply(hand_inv, parent_r))),
            }
        end
    end
    return fpd
end

local CS2_TO_STINGRAY = QuaternionBox(Quaternion.axis_angle(Vector3(0, 0, 1), math.pi / 2))

local function apply_hand_cam(fpd, arm)
    local driver = fpd.driver
    for _, name in ipairs({ "j_righthand", "j_righthandmiddle1", "j_righthandindex1", "j_righthandpinky1", "ap_camera_node" }) do
        if not Unit.has_node(driver, name) then
            return
        end
    end
    local hand = Unit.node(driver, "j_righthand")
    local parent = Unit.scene_graph_parent(driver, hand)
    local function world(node)
        return root_relative(driver, parent_chain(driver, node))
    end
    local function wpos(name)
        local _, p = world(Unit.node(driver, name))
        return p
    end
    local cam_r, cam_p = world(Unit.node(driver, "ap_camera_node"))
    local hand_r, hand_p = world(hand)
    local f = Vector3.normalize(wpos("j_righthandmiddle1") - hand_p)
    local u = wpos("j_righthandindex1") - wpos("j_righthandpinky1")
    u = Vector3.normalize(u - f * Vector3.dot(u, f))
    local lm_in_hand = Quaternion.multiply(Quaternion.inverse(hand_r), Quaternion.look(f, u))
    local q = arm.frame
    local target_lm = Quaternion.multiply(Quaternion.multiply(cam_r, CS2_TO_STINGRAY:unbox()), Quaternion.from_elements(q[1], q[2], q[3], q[4]))
    local target_hand = Quaternion.multiply(target_lm, Quaternion.inverse(lm_in_hand))
    local new_hand = Quaternion.lerp(hand_r, target_hand, arm.weight)
    local pr, pp = world(parent)
    local pr_inv = Quaternion.inverse(pr)
    Unit.set_local_rotation(driver, hand, Quaternion.multiply(pr_inv, new_hand))
    local axis = Vector3.normalize(hand_p - pp)
    local d_root = Quaternion.multiply(new_hand, Quaternion.inverse(hand_r))
    local x, y, z, w = Quaternion.to_elements(d_root)
    local proj = Vector3.dot(Vector3(x, y, z), axis)
    if math.sqrt(proj * proj + w * w) > 1e-6 then
        local twist_angle = 2 * math.atan2(proj, w)
        if twist_angle > math.pi then
            twist_angle = twist_angle - 2 * math.pi
        elseif twist_angle < -math.pi then
            twist_angle = twist_angle + 2 * math.pi
        end
        for k, name in ipairs({ "j_rightforearmroll1", "j_rightforearmroll2" }) do
            if Unit.has_node(driver, name) then
                local node = Unit.node(driver, name)
                local rr = world(Unit.scene_graph_parent(driver, node))
                local share = Quaternion.axis_angle(Quaternion.rotate(Quaternion.inverse(rr), axis), twist_angle * k / 3)
                Unit.set_local_rotation(driver, node, Quaternion.multiply(share, Unit.local_rotation(driver, node)))
            end
        end
    end
end

function Fingers.update(world, fpd, quats, weight, arm)
    local driver, fp_unit = fpd.driver, fpd.fp_unit
    local poses = {}
    local function pose_of(node)
        if node == nil or node == 1 then
            return Quaternion.identity(), Vector3(0, 0, 0)
        end
        local pose = poses[node]
        if pose then
            return pose[1], pose[2]
        end
        local entry = fpd.by_node[node]
        local rotation, position
        if entry and entry.fp then
            rotation, position = root_relative(fp_unit, fpd.fp_chains[entry.fp])
        else
            local parent_rotation, parent_position = pose_of(Unit.scene_graph_parent(driver, node))
            rotation = Quaternion.multiply(parent_rotation, Unit.local_rotation(driver, node))
            position = parent_position + Quaternion.rotate(parent_rotation, Unit.local_position(driver, node))
        end
        poses[node] = { rotation, position }
        return rotation, position
    end
    for i = 1, #fpd.nodes do
        local entry = fpd.nodes[i]
        if entry.fp then
            local rotation, position = pose_of(entry.node)
            local parent_rotation, parent_position = pose_of(entry.parent)
            local inverse_parent = Quaternion.inverse(parent_rotation)
            Unit.set_local_rotation(driver, entry.node, Quaternion.multiply(inverse_parent, rotation))
            Unit.set_local_position(driver, entry.node, Quaternion.rotate(inverse_parent, position - parent_position))
        end
    end
    if arm and arm.weight > 0 and arm.frame then
        apply_hand_cam(fpd, arm)
    end
    if quats and weight > 0 then
        local f, u, s = fpd.lm[1]:unbox(), fpd.lm[2]:unbox(), fpd.lm[3]:unbox()
        for i, finger in pairs(fpd.fingers) do
            local k = (i - 1) * 4
            local x, y, z, w = quats[k + 1], quats[k + 2], quats[k + 3], quats[k + 4]
            local target = finger.bind:unbox()
            if x then
                w = math.max(-1, math.min(1, w))
                local sn = math.sqrt(math.max(0, 1 - w * w))
                if sn > 1e-6 then
                    local axis_hand = f * (x / sn) + u * (y / sn) + s * (z / sn)
                    local axis = Vector3.normalize(Quaternion.rotate(finger.parent_inv:unbox(), axis_hand))
                    target = Quaternion.multiply(Quaternion.axis_angle(axis, 2 * math.acos(w)), target)
                end
            end
            Unit.set_local_rotation(driver, finger.node, Quaternion.lerp(Unit.local_rotation(driver, finger.node), target, weight))
        end
    end
    World.update_unit_and_children(world, driver)
end

function Fingers.arm_units(ext)
    local found = {}
    if not ext then
        return found
    end
    local function ok(u)
        return u ~= nil and Unit.alive(u)
    end
    for key, value in pairs(ext) do
        if type(key) == "string" then
            if string.find(key, "^__qiangiq_.+_arms$") and not string.find(key, "_part_arms$") then
                if ok(value) then
                    found[#found + 1] = value
                end
            elseif string.find(key, "^__qiangiq_.+_part_arms$") and type(value) == "table" then
                for _, part in pairs(value) do
                    if ok(part) then
                        found[#found + 1] = part
                    end
                end
            end
        end
    end
    if ext._equipment then
        for slot_name, slot in pairs(ext._equipment) do
            if type(slot_name) == "string" and (string.find(slot_name, "^slot_body") or string.find(slot_name, "^slot_gear")) and ok(slot.unit_1p) then
                found[#found + 1] = slot.unit_1p
            end
        end
    end
    return found
end

return Fingers
