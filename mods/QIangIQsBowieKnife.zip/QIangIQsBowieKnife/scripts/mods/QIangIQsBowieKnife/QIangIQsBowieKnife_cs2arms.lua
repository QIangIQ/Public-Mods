-- CS2 first-person arms (agent default gloves + sleeves, CT or T) while the knife is wielded, local player only.
-- "viewmodel": CS2's own viewmodel. Arms unit linked to the first-person unit's ap_camera_node (x right, y forward,
--   z up), placed at CS2's viewmodel offset, every bone set from the baked CS2 clips (idle, draw, light / heavy
--   swings, backstabs, hits, inspects) chosen from the weapon action and what is in reach; a second knife unit is
--   posed in it from the same clips.
--   The game's first-person arms and its knife are hidden.
-- "follow": the arms unit is linked to the first-person unit and its bones follow the game's first-person arm bones
--   (directions of the joints, CS2 bone lengths, hands anchored on the game's hands). The game's arms are hidden,
--   its knife stays.
-- Bones are set as root-relative poses: viewmodel = (Dq R0, Dq P0 + Dt) with D baked per bone and frame (cs2arms
-- bake.py), so nothing depends on the compiled bone axes.
local Arms = {}
local CFG = nil

function Arms.setup(cfg)
    CFG = cfg
end

Arms.ASSETS = { "cs2_arms_ct", "cs2_arms_t" }

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function opt(key, default)
    local v = CFG.opt(key)
    if v == nil then
        return default
    end
    return v
end

local decoded = {}

local function clip_data(name)
    local clip = CFG.data.clips[name]
    if not clip then
        return nil
    end
    local arr = decoded[name]
    if not arr then
        arr = {}
        local n, inv = 0, 1 / CFG.data.scale
        for v in string.gmatch(clip.data, "-?%d+") do
            n = n + 1
            arr[n] = tonumber(v) * inv
        end
        decoded[name] = arr
    end
    return arr, clip.frames
end

local function clip_duration(name)
    local clip = CFG.data.clips[name]
    return clip and (clip.frames - 1) / CFG.data.fps or 0
end

local function sample(name, t, out)
    local arr, frames = clip_data(name)
    if not arr then
        return nil
    end
    local stride = CFG.data.stride
    local f = math.max(0, math.min(frames - 1, t * CFG.data.fps))
    local i = math.floor(f)
    local u = f - i
    local j = math.min(frames - 1, i + 1)
    local a, b = i * stride, j * stride
    for k = 1, stride do
        local va = arr[a + k]
        out[k] = va + (arr[b + k] - va) * u
    end
    return out
end

local quat_slots = nil

local function quat_slot_list()
    if not quat_slots then
        quat_slots = {}
        local nb = #CFG.data.bones
        for i = 0, nb do
            quat_slots[#quat_slots + 1] = 7 * i + 1
        end
        for k = 0, CFG.data.parts - 1 do
            quat_slots[#quat_slots + 1] = 7 * nb + 8 + 4 * k
        end
    end
    return quat_slots
end

local function blend(a, b, u, out)
    for k = 1, CFG.data.stride do
        out[k] = a[k] + (b[k] - a[k]) * u
    end
    for _, s in ipairs(quat_slot_list()) do
        local d = a[s] * b[s] + a[s + 1] * b[s + 1] + a[s + 2] * b[s + 2] + a[s + 3] * b[s + 3]
        if d < 0 then
            for k = 0, 3 do
                out[s + k] = a[s + k] + (-b[s + k] - a[s + k]) * u
            end
        end
    end
    return out
end

local function quat_at(p, o)
    local x, y, z, w = p[o], p[o + 1], p[o + 2], p[o + 3]
    local n = math.sqrt(x * x + y * y + z * z + w * w)
    if n < 1e-9 then
        return Quaternion.identity()
    end
    return Quaternion.from_elements(x / n, y / n, z / n, w / n)
end

local function parent_chain(unit, node)
    local list, current, guard = {}, node, 0
    while current and guard < 64 do
        list[#list + 1] = current
        if current == 1 then
            break
        end
        current = Unit.scene_graph_parent(unit, current)
        guard = guard + 1
    end
    return list
end

local function root_relative(unit, node)
    local chain = parent_chain(unit, node)
    local rotation, position = Quaternion.identity(), Vector3(0, 0, 0)
    local first = chain[#chain] == 1 and #chain - 1 or #chain
    for i = first, 1, -1 do
        position = position + Quaternion.rotate(rotation, Unit.local_position(unit, chain[i]))
        rotation = Quaternion.multiply(rotation, Unit.local_rotation(unit, chain[i]))
    end
    return rotation, position
end

-- rest pose of every baked bone the unit has: root-relative rotation / position, and its parent's (never animated)
local function capture_rest(unit)
    local bones, by_name = {}, {}
    for i, name in ipairs(CFG.data.bones) do
        if Unit.has_node(unit, name) then
            local node = Unit.node(unit, name)
            local r0, p0 = root_relative(unit, node)
            local parent = Unit.scene_graph_parent(unit, node)
            local pr, pp = Quaternion.identity(), Vector3(0, 0, 0)
            if parent and parent ~= 1 then
                pr, pp = root_relative(unit, parent)
            end
            local b = { index = i, name = name, node = node, r0 = QuaternionBox(r0), p0 = Vector3Box(p0),
                pinv = QuaternionBox(Quaternion.inverse(pr)), pp = Vector3Box(pp) }
            bones[#bones + 1] = b
            by_name[name] = b
        end
    end
    return bones, by_name
end

local function set_rr(unit, b, r, p)
    local pinv = b.pinv:unbox()
    Unit.set_local_rotation(unit, b.node, Quaternion.multiply(pinv, r))
    Unit.set_local_position(unit, b.node, Quaternion.rotate(pinv, p - b.pp:unbox()))
end

-- knife parts (butterfly bf_blade / bf_handle / bf_latch), body axes from the bf_axis_x / bf_tip markers
local KNIFE_PARTS = { "bf_blade", "bf_handle", "bf_latch" }

local function knife_init(knife)
    local k = { unit = knife, parts = {} }
    if Unit.has_node(knife, "bf_tip") and Unit.has_node(knife, "bf_axis_x") then
        local ex = Vector3.normalize(Unit.local_position(knife, Unit.node(knife, "bf_axis_x")))
        local ey = Vector3.normalize(Unit.local_position(knife, Unit.node(knife, "bf_tip")))
        k.ax = { Vector3Box(ex), Vector3Box(ey), Vector3Box(Vector3.cross(ex, ey)) }
        for i, name in ipairs(KNIFE_PARTS) do
            if Unit.has_node(knife, name) then
                local n = Unit.node(knife, name)
                k.parts[i] = { node = n, rot = QuaternionBox(Unit.local_rotation(knife, n)) }
            end
        end
    end
    return k
end

local function knife_part_turn(k, x, y, z, w)
    w = math.max(-1, math.min(1, w))
    local sn = math.sqrt(math.max(0, 1 - w * w))
    if sn < 1e-6 or not k.ax then
        return nil
    end
    local axis = Vector3.normalize(k.ax[1]:unbox() * (x / sn) + k.ax[2]:unbox() * (y / sn) + k.ax[3]:unbox() * (z / sn))
    return Quaternion.axis_angle(axis, 2 * math.acos(w))
end

local function spawn(world, path, parent, node, custom_fov)
    local spawner = Managers.state and Managers.state.unit_spawner
    if not (spawner and unit_ok(parent)) then
        return nil
    end
    local unit = spawner:spawn_unit(path, Unit.world_pose(parent, node))
    if not unit then
        return nil
    end
    Unit.set_unit_culling(unit, false)
    if custom_fov then
        Unit.set_shader_pass_flag_for_meshes_in_unit_and_childs(unit, "custom_fov", true)
    end
    World.link_unit(world, unit, 1, parent, node)
    return unit
end

local function destroy(world, unit)
    if unit_ok(unit) then
        if world then
            World.unlink_unit(world, unit)
        end
        local spawner = Managers.state and Managers.state.unit_spawner
        if spawner then
            spawner:mark_for_deletion(unit)
        end
    end
end

-- viewmodel clip choice from the Combat Knife's weapon actions (combatknife_p1_m1/m2.lua action names)
local function classify(name)
    if not name then
        return nil
    end
    if name == "action_wield" then
        return "draw"
    elseif name == "action_inspect" or name == "action_inspect_3p" then
        return "inspect"
    elseif string.find(name, "riposte") then
        return "riposte"
    elseif string.find(name, "heavy") then
        return "heavy"
    elseif string.find(name, "light") or string.find(name, "jab") or name == "action_push" then
        return "light"
    end
    return nil
end

local INSPECTS = { "lookat01", "lookat02", "lookat03" }
local DRAWS = { "draw", "draw2" }

-- random pick among the clips this knife has (user request 2026-11-08: inspects and draws are random, not in turn);
-- avoids repeating the last pick when there is another choice
local function random_clip(list, last)
    local have = {}
    for i = 1, #list do
        if CFG.data.clips[list[i]] then
            have[#have + 1] = list[i]
        end
    end
    if #have > 1 and last then
        for i = #have, 1, -1 do
            if have[i] == last then
                table.remove(have, i)
            end
        end
    end
    return have[math.random(1, math.max(1, #have))] or list[1]
end

-- CS2 picks a backstab / hit clip from what is in reach when a swing starts. Behind = Darktide's own backstab rule
-- (scripts/utilities/attack/attack_positioning.lua): flat direction attacker -> target dotted with the target's flat
-- forward > 0.5 (BACKSTAB_DOT_THRESHOLD). Target = first live minion (Breed.is_minion, health_system:is_alive as in
-- target_selection.lua) found with the broadphase (bot_perception_extension.lua query shape), nearest along the view.
-- No PhysicsWorld query: a sweep here crashed the game in PhysicsWorld.fetch_queries (2026-11-08).
local Breed = require("scripts/utilities/breed")
local REACH, SWEEP_RADIUS, BACKSTAB_DOT = 2.5, 0.3, 0.5
local BODY_RADIUS = 0.8
local BROADPHASE_RESULTS = {}
local MINION_BREED_TYPE = require("scripts/settings/breed/breed_settings").types.minion

local function swing_target(st)
    local player = st.player
    if not unit_ok(player) then
        return nil
    end
    local ok, result = pcall(function()
        local fpe = ScriptUnit.has_extension(player, "first_person_system")
        local fp = fpe and fpe:first_person_unit()
        local side_system = Managers.state.extension:system("side_system")
        local broadphase_system = Managers.state.extension:system("broadphase_system")
        local side = side_system and side_system.side_by_unit[player]
        if not (unit_ok(fp) and side and broadphase_system and broadphase_system.broadphase) then
            return nil
        end
        local pos = Unit.world_position(fp, 1)
        local fwd = Quaternion.forward(Unit.world_rotation(fp, 1))
        local n = broadphase_system.broadphase:query(pos, REACH + 1, BROADPHASE_RESULTS, side:relation_side_names("enemy"),
            MINION_BREED_TYPE)
        local best, best_along = nil, math.huge
        for i = 1, n or 0 do
            local unit = BROADPHASE_RESULTS[i]
            local it = unit_ok(unit) and POSITION_LOOKUP[unit]
            local health = it and ScriptUnit.has_extension(unit, "health_system")
            if health and health:is_alive() then
                -- nearest minion whose body (feet to ~1.8 m) is within reach along the view and close to the view line
                local to = it + Vector3(0, 0, math.min(math.max(pos.z - it.z, 0.3), 1.8)) - pos
                local along = Vector3.dot(to, fwd)
                local off = Vector3.length(to - fwd * along)
                if along > 0 and along < REACH + SWEEP_RADIUS and off < BODY_RADIUS and along < best_along then
                    best, best_along = unit, along
                end
            end
        end
        if not best then
            return nil
        end
        local me = POSITION_LOOKUP[player]
        if not me then
            return "front"
        end
        local dir = Vector3.normalize(Vector3.flat(POSITION_LOOKUP[best] - me))
        local forward = Vector3.normalize(Vector3.flat(Quaternion.forward(Unit.world_rotation(best, 1))))
        return Vector3.dot(dir, forward) > BACKSTAB_DOT and "back" or "front"
    end)
    for i = 1, #BROADPHASE_RESULTS do
        BROADPHASE_RESULTS[i] = nil
    end
    return ok and result or nil
end

-- light swing clip: a light swing that backstabs plays CS2's light backstab, both versions in turn (user request
-- 2026-11-08 22:07, was the heavy backstab), else hit, else CS2's misses as before
-- CS2 light swing (hit or miss version, the two swings in turn)
local function light_swing(st, target)
    local clips = CFG.data.clips
    st.light_flip = not st.light_flip
    if target and opt("cs2_hit_anims", false) and clips.light_hit1 then
        return (st.light_flip or not clips.light_hit2) and "light_hit1" or "light_hit2"
    end
    return st.light_flip and "light_miss1" or "light_miss2"
end

local function light_clip(st)
    local clips = CFG.data.clips
    local target = (opt("cs2_backstab_anims", true) or opt("cs2_hit_anims", false)) and swing_target(st) or nil
    if target == "back" and opt("cs2_backstab_anims", true) then
        if clips.light_backstab then
            st.light_backstab_flip = not st.light_backstab_flip
            return (st.light_backstab_flip or not clips.light_backstab2) and "light_backstab" or "light_backstab2"
        elseif clips.heavy_backstab then
            return "heavy_backstab"
        end
    end
    return light_swing(st, target)
end

-- Duelling Sword (combatsword_p3_m1..m3, ButterflyKnife's replace_duelling_sword), by user request 2026-11-08: its
-- light attacks play CS2's light swings, heavy attacks play CS2's light backstab (both versions, alternating), and any
-- backstab and its special riposte slash (action_attack_special_riposte / _psyker) play CS2's heavy backstab.
local DUELLING = { combatsword_p3_m1 = true, combatsword_p3_m2 = true, combatsword_p3_m3 = true }

local function duelling_heavy_clip(st)
    local clips = CFG.data.clips
    -- a heavy that backstabs plays CS2's heavy backstab (user request 2026-11-08)
    if opt("cs2_backstab_anims", true) and clips.heavy_backstab and swing_target(st) == "back" then
        return "heavy_backstab"
    end
    st.backstab_flip = not st.backstab_flip
    return (st.backstab_flip or not clips.light_backstab2) and "light_backstab" or "light_backstab2"
end

local function heavy_clip(st)
    local clips = CFG.data.clips
    local target = (opt("cs2_backstab_anims", true) or opt("cs2_hit_anims", false)) and swing_target(st) or nil
    if target == "back" and opt("cs2_backstab_anims", true) and clips.heavy_backstab then
        return "heavy_backstab"
    end
    -- a heavy that is not a backstab plays CS2's light swing (user request 2026-11-08), unless turned off
    if opt("cs2_heavy_light_swings", true) then
        return light_swing(st, target)
    end
    if target and opt("cs2_hit_anims", false) and clips.heavy_hit1 then
        return "heavy_hit1"
    end
    return "heavy_miss1"
end
local FADE = 0.12

local function play(st, name, speed, loop)
    if not CFG.data.clips[name] then
        return
    end
    if st.pose then
        st.from = {}
        for k = 1, CFG.data.stride do
            st.from[k] = st.pose[k]
        end
        st.fade = 0
    end
    st.clip, st.t, st.speed, st.loop = name, 0, speed, loop
end

-- Inspect = a tap toggle on the inspect key (user requests 2026-11-08 22:19 and 22:22): the press starts one CS2 inspect at
-- once, every further press starts a new one, releasing the key does nothing, and any other action (attack, reload, draw) takes over.
-- Darktide's own action_inspect (it needs the key held 0.2 s) no longer drives the viewmodel.
local function inspect_held()
    local ok, held = pcall(function()
        local svc = Managers.input and Managers.input:get_input_service("Ingame")
        return svc and svc:get("weapon_inspect_hold")
    end)
    return ok and held and true or false
end

local function viewmodel_step(st, action, dt)
    local name, start_t, time_scale = action.name, action.start_t, action.time_scale or 1
    local key = tostring(name) .. ":" .. tostring(start_t)
    local kind = classify(name)
    local inspect_down = inspect_held()
    if inspect_down and not st.inspect_was_down then
        -- every press starts a fresh inspect, also during one (user request 2026-11-08 22:31: spam inspect, no cancel tap)
        if st.loop or (st.clip and string.find(st.clip, "^lookat")) then
            st.last_inspect = random_clip(INSPECTS, st.last_inspect)
            play(st, st.last_inspect, opt("flip_speed", 1), false)
        end
    end
    st.inspect_was_down = inspect_down
    local attack_speed = opt("cs2_attack_speed", 1) * math.max(0.25, time_scale)
    if key ~= st.action_key then
        st.action_key = key
        if kind == "draw" then
            st.last_draw = random_clip(DRAWS, st.last_draw)
            play(st, st.last_draw, 1, false)
        elseif kind == "light" then
            play(st, light_clip(st), attack_speed, false)
        elseif kind == "heavy" and DUELLING[action.template] and CFG.data.clips.light_backstab then
            play(st, duelling_heavy_clip(st), attack_speed, false)
        elseif kind == "heavy" then
            play(st, heavy_clip(st), attack_speed, false)
        elseif kind == "riposte" and CFG.data.clips.heavy_backstab then
            play(st, "heavy_backstab", attack_speed, false)
        end
        st.kind = kind
    end
    -- the "Play an inspect animation" keybind / "/bfknife flip": one CS2 inspect, then back to idle
    if st.manual_inspect then
        st.manual_inspect = nil
        st.last_inspect = random_clip(INSPECTS, st.last_inspect)
        play(st, st.last_inspect, opt("flip_speed", 1), false)
    end
    if not st.clip then
        play(st, "idle1", 1, true)
    end
    st.t = st.t + dt * (st.speed or 1)
    local dur = clip_duration(st.clip)
    if st.t >= dur then
        if st.loop then
            st.t = st.t % math.max(dur, 1e-3)
        else
            play(st, "idle1", 1, true)
        end
    end
    st.cur = st.cur or {}
    local pose = sample(st.clip, st.t, st.cur)
    if st.from and st.fade then
        st.fade = st.fade + dt
        local u = math.min(1, st.fade / FADE)
        u = u * u * (3 - 2 * u)
        st.blend_out = st.blend_out or {}
        pose = blend(st.from, pose, u, st.blend_out)
        if u >= 1 then
            st.from, st.fade = nil, nil
        end
    end
    st.pose = st.pose or {}
    for k = 1, CFG.data.stride do
        st.pose[k] = pose[k]
    end
    return st.pose
end

local function apply_viewmodel(data, pose)
    local unit = data.unit
    local inch = 0.0254
    local offset = Vector3(opt("cs2_vm_x", 1) * inch, opt("cs2_vm_y", 1) * inch, opt("cs2_vm_z", -1) * inch)
    Unit.set_local_position(unit, 1, offset)
    data.cs2_off = Vector3Box(offset)
    data.cs2_rr = data.cs2_rr or {}
    for _, b in ipairs(data.bones) do
        local o = 7 * (b.index - 1) + 1
        local dq = quat_at(pose, o)
        local dt = Vector3(pose[o + 4], pose[o + 5], pose[o + 6])
        local r, p = Quaternion.multiply(dq, b.r0:unbox()), Quaternion.rotate(dq, b.p0:unbox()) + dt
        set_rr(unit, b, r, p)
        data.cs2_rr[b.node] = { QuaternionBox(r), Vector3Box(p), QuaternionBox(dq) }
    end
    local k = data.knife
    if k and unit_ok(k.unit) then
        local o = 7 * #CFG.data.bones + 1
        local L = CFG.data.knife_length
        Unit.set_local_rotation(k.unit, 1, quat_at(pose, o))
        Unit.set_local_position(k.unit, 1, Vector3(pose[o + 4], pose[o + 5], pose[o + 6]))
        Unit.set_local_scale(k.unit, 1, Vector3(L, L, L))
        for i = 1, CFG.data.parts do
            local part = k.parts[i]
            if part then
                local s = 7 * #CFG.data.bones + 8 + 4 * (i - 1)
                local q = quat_at(pose, s)
                local x, y, z, w = Quaternion.to_elements(q)
                local d = knife_part_turn(k, x, y, z, w)
                local rest = part.rot:unbox()
                Unit.set_local_rotation(k.unit, part.node, d and Quaternion.multiply(d, rest) or rest)
            end
        end
    end
end

-- follow mode --------------------------------------------------------------------------------------------------
local FINGERS = { "index", "middle", "ring", "pinky" }

local function perp(v, axis)
    local p = v - axis * Vector3.dot(v, axis)
    local l = Vector3.length(p)
    if l < 1e-6 then
        return nil
    end
    return p * (1 / l)
end

local function frame(dir, ref)
    local d = Vector3.normalize(dir)
    local r = ref and perp(ref, d)
    if not r then
        return nil
    end
    return Quaternion.look(d, r)
end

local function rest_pos(data, name)
    local b = data.by_name[name]
    return b and b.p0:unbox()
end

local function follow_side(data, src, to_local, side, cs)
    local dt = "j_" .. side
    local function has(n)
        return Unit.has_node(src, n)
    end
    for _, n in ipairs({ dt .. "arm", dt .. "forearm", dt .. "hand", dt .. "handmiddle1", dt .. "handindex1", dt .. "handpinky1" }) do
        if not has(n) then
            return
        end
    end
    local function P(n)
        return to_local.pos(Unit.world_position(src, Unit.node(src, n)))
    end
    local function R(n)
        return to_local.rot(Unit.world_rotation(src, Unit.node(src, n)))
    end
    local B = data.by_name
    local hand, lower, upper = B["hand_" .. cs], B["arm_lower_" .. cs], B["arm_upper_" .. cs]
    if not (hand and lower and upper and B["finger_middle_0_" .. cs] and B["finger_index_0_" .. cs] and B["finger_pinky_0_" .. cs]) then
        return
    end
    local unit = data.unit
    local out = {}
    local function put(b, delta, pos)
        out[b.name] = { delta, pos }
        set_rr(unit, b, Quaternion.multiply(delta, b.r0:unbox()), pos)
    end
    -- live landmarks
    local p_sh, p_el, p_wr = P(dt .. "arm"), P(dt .. "forearm"), P(dt .. "hand")
    local f = P(dt .. "handmiddle1") - p_wr
    local u = P(dt .. "handindex1") - P(dt .. "handpinky1")
    -- rest landmarks (CS2)
    local r_wr = hand.p0:unbox()
    local f0 = rest_pos(data, "finger_middle_0_" .. cs) - r_wr
    local u0 = rest_pos(data, "finger_index_0_" .. cs) - rest_pos(data, "finger_pinky_0_" .. cs)
    local r_lo, r_up = lower.p0:unbox(), upper.p0:unbox()
    local hf, hf0 = frame(f, u), frame(f0, u0)
    if not (hf and hf0) then
        return
    end
    local d_hand = Quaternion.multiply(hf, Quaternion.inverse(hf0))
    local du, dl = p_el - p_sh, p_wr - p_el
    local du0, dl0 = r_lo - r_up, r_wr - r_lo
    local n = Vector3.cross(du, dl)
    local n0 = Vector3.cross(du0, dl0)
    if Vector3.length(n) < 1e-5 or Vector3.length(n0) < 1e-5 then
        n, n0 = u, u0
    end
    local fu, fu0 = frame(du, n), frame(du0, n0)
    local fl, fl0 = frame(dl, n), frame(dl0, n0)
    if not (fu and fu0 and fl and fl0) then
        return
    end
    local d_up = Quaternion.multiply(fu, Quaternion.inverse(fu0))
    local d_lo = Quaternion.multiply(fl, Quaternion.inverse(fl0))
    -- hands anchored on the game's hands; arm joints placed back along CS2's own bone lengths
    local pos_hand = p_wr
    local pos_lo = pos_hand - Quaternion.rotate(d_lo, r_wr - r_lo)
    local pos_up = pos_lo - Quaternion.rotate(d_up, r_lo - r_up)
    put(upper, d_up, pos_up)
    put(lower, d_lo, pos_lo)
    put(hand, d_hand, pos_hand)
    -- twist bones: forearm ones take 0.5 / 1 of the hand's twist about the forearm (CS2 twist_constraints weights)
    local axis = Vector3.normalize(dl)
    local q = Quaternion.multiply(d_hand, Quaternion.inverse(d_lo))
    local x, y, z, w = Quaternion.to_elements(q)
    local proj = x * axis.x + y * axis.y + z * axis.z
    local tw = 2 * math.atan2(proj, w)
    if tw > math.pi then
        tw = tw - 2 * math.pi
    elseif tw < -math.pi then
        tw = tw + 2 * math.pi
    end
    for name, share in pairs({ ["arm_lower_" .. cs .. "_TWIST"] = 0.5, ["arm_lower_" .. cs .. "_TWIST1"] = 1 }) do
        local b = B[name]
        if b then
            put(b, Quaternion.multiply(Quaternion.axis_angle(axis, tw * share), d_lo), pos_lo + Quaternion.rotate(d_lo, b.p0:unbox() - r_lo))
        end
    end
    for _, name in ipairs({ "arm_upper_" .. cs .. "_TWIST", "arm_upper_" .. cs .. "_TWIST1" }) do
        local b = B[name]
        if b then
            put(b, d_up, pos_up + Quaternion.rotate(d_up, b.p0:unbox() - r_up))
        end
    end
    -- fingers: CS2 lengths, each segment turned onto the game's segment (twist from the hand's knuckle line)
    local function tip(a, b)
        local pa, pb = P(a), P(b)
        local turn = Quaternion.multiply(R(b), Quaternion.inverse(R(a)))
        return pb + Quaternion.rotate(turn, pb - pa)
    end
    local function chain(cs_names, dt_names, start_parent)
        local parent_b, parent_pos, parent_d = start_parent[1], start_parent[2], start_parent[3]
        for i, cn in ipairs(cs_names) do
            local b = B[cn]
            if not b then
                return
            end
            local pos = parent_pos + Quaternion.rotate(parent_d, b.p0:unbox() - parent_b.p0:unbox())
            local a_name, b_name = dt_names[i], dt_names[i + 1]
            local live_dir
            if b_name and has(b_name) then
                live_dir = P(b_name) - P(a_name)
            elseif has(a_name) and i > 1 and has(dt_names[i - 1]) then
                live_dir = tip(dt_names[i - 1], a_name) - P(a_name)
            end
            local nxt = B[cs_names[i + 1]]
            local rest_dir = nxt and (nxt.p0:unbox() - b.p0:unbox()) or (b.p0:unbox() - parent_b.p0:unbox())
            local fr, fr0 = live_dir and frame(live_dir, u), frame(rest_dir, u0)
            local d = (fr and fr0) and Quaternion.multiply(fr, Quaternion.inverse(fr0)) or parent_d
            put(b, d, pos)
            parent_b, parent_pos, parent_d = b, pos, d
        end
    end
    for _, fg in ipairs(FINGERS) do
        local meta = B["finger_" .. fg .. "_meta_" .. cs]
        local start = { hand, pos_hand, d_hand }
        if meta then
            local mpos = pos_hand + Quaternion.rotate(d_hand, meta.p0:unbox() - r_wr)
            put(meta, d_hand, mpos)
            start = { meta, mpos, d_hand }
        end
        local dtn = { dt .. "hand" .. fg .. "1", dt .. "hand" .. fg .. "2", dt .. "hand" .. fg .. "3" }
        if has(dtn[1]) then
            chain({ "finger_" .. fg .. "_0_" .. cs, "finger_" .. fg .. "_1_" .. cs, "finger_" .. fg .. "_2_" .. cs }, dtn, start)
        end
    end
    local tdt = { dt .. "handthumb1", dt .. "handthumb2", dt .. "handthumb3" }
    if has(tdt[1]) then
        chain({ "finger_thumb_0_" .. cs, "finger_thumb_1_" .. cs, "finger_thumb_2_" .. cs }, tdt, { hand, pos_hand, d_hand })
    end
end

local function apply_follow(data, src)
    local unit = data.unit
    Unit.set_local_position(unit, 1, Vector3(0, 0, 0))
    Unit.set_local_rotation(unit, 1, Quaternion.identity())
    local root_p, root_r = Unit.world_position(data.parent, 1), Unit.world_rotation(data.parent, 1)
    local inv = Quaternion.inverse(root_r)
    local to_local = {
        pos = function(p)
            return Quaternion.rotate(inv, p - root_p)
        end,
        rot = function(r)
            return Quaternion.multiply(inv, r)
        end,
    }
    follow_side(data, src, to_local, "right", "R")
    follow_side(data, src, to_local, "left", "L")
end

-- character arms: the game's / a character mod's first-person arm units, relinked to a first-person driver
-- (QIangIQsEmotes / fingers module pattern); each frame the driver takes the game's pose (Fingers.update) and its
-- arm bones are turned onto the hidden CS2 viewmodel skeleton (same segment / landmark alignment as "follow", in the
-- other direction; the game's own bone lengths, hands anchored on CS2's hands).
local DT_FINGERS = { "index", "middle", "ring", "pinky", "thumb" }

local function driver_rest(driver)
    local rest = {}
    for _, name in ipairs(CFG.fp_nodes) do
        if Unit.has_node(driver, name) and not rest[name] then
            local node = Unit.node(driver, name)
            if node ~= 1 then
                local r, p = root_relative(driver, node)
                rest[name] = { node = node, r0 = QuaternionBox(r), p0 = Vector3Box(p), parent = Unit.scene_graph_parent(driver, node) }
            end
        end
    end
    return rest
end

-- every driver bone below j_<s>arm (inclusive), parents first
local function side_bones(rest, name_of, s)
    local root = rest["j_" .. s .. "arm"]
    if not root then
        return nil
    end
    local list = {}
    for name, b in pairs(rest) do
        local d, n = 0, b.node
        while n and n ~= root.node and n ~= 1 and d < 64 do
            local nm = name_of[n]
            n = nm and rest[nm].parent or nil
            d = d + 1
        end
        if n == root.node then
            list[#list + 1] = { name = name, depth = d }
        end
    end
    table.sort(list, function(a, b)
        return a.depth < b.depth
    end)
    local names = {}
    for i, e in ipairs(list) do
        names[i] = e.name
    end
    return names
end

local function character_side(data, s, cs)
    local cu, rest, driver = data.unit, data.rest, data.driver
    local function C(name)
        local full = name .. "_" .. cs
        return Unit.has_node(cu, full) and Unit.node(cu, full) or nil
    end
    local need = { C("arm_upper"), C("arm_lower"), C("hand"), C("finger_middle_0"), C("finger_index_0"), C("finger_pinky_0") }
    for i = 1, 6 do
        if not need[i] then
            return
        end
    end
    local cam_r, cam_p = data.cam_r, data.cam_p
    local off = data.cs2_off and data.cs2_off:unbox() or Vector3(0, 0, 0)
    local function CP(n)
        local e = data.cs2_rr and data.cs2_rr[n]
        return cam_p + Quaternion.rotate(cam_r, off + (e and e[2]:unbox() or Vector3(0, 0, 0)))
    end
    local function CR(n)
        local e = data.cs2_rr and data.cs2_rr[n]
        return Quaternion.multiply(cam_r, e and e[1]:unbox() or Quaternion.identity())
    end
    local dt = "j_" .. s
    local function P0(n)
        local b = rest[n]
        return b and b.p0:unbox()
    end
    for _, n in ipairs({ dt .. "arm", dt .. "forearm", dt .. "hand", dt .. "handmiddle1", dt .. "handindex1", dt .. "handpinky1" }) do
        if not rest[n] then
            return
        end
    end
    local names = data.side_names[s]
    if not names then
        return
    end
    -- live CS2 landmarks / the game's bind landmarks
    local c_up, c_lo, c_wr = CP(need[1]), CP(need[2]), CP(need[3])
    local f = CP(need[4]) - c_wr
    local u = CP(need[5]) - CP(need[6])
    local b_up, b_lo, b_wr = P0(dt .. "arm"), P0(dt .. "forearm"), P0(dt .. "hand")
    local f0 = P0(dt .. "handmiddle1") - b_wr
    local u0 = P0(dt .. "handindex1") - P0(dt .. "handpinky1")
    local hf, hf0 = frame(f, u), frame(f0, u0)
    if not (hf and hf0) then
        return
    end
    local delta = {}
    delta[dt .. "hand"] = Quaternion.multiply(hf, Quaternion.inverse(hf0))
    local du, dl, du0, dl0 = c_lo - c_up, c_wr - c_lo, b_lo - b_up, b_wr - b_lo
    -- arm roll: CS2's rest knuckle line carried by each arm bone's own baked turn (the CS2 upper arm is a straightened
    -- helper on the forearm line, so an elbow-plane normal is degenerate and flips), matched to the game's bind knuckle line
    local B = data.by_name
    local function rest_of(nm)
        local b = B[nm .. "_" .. cs]
        return b and b.p0:unbox()
    end
    local function turn_of(nm)
        local b = B[nm .. "_" .. cs]
        local e = b and data.cs2_rr and data.cs2_rr[b.node]
        return e and e[3] and e[3]:unbox()
    end
    local q_up, q_lo = turn_of("arm_upper"), turn_of("arm_lower")
    local ri, rp = rest_of("finger_index_0"), rest_of("finger_pinky_0")
    if not (q_up and q_lo and ri and rp) then
        return
    end
    local r_u = ri - rp
    local ref_up = Quaternion.rotate(cam_r, Quaternion.rotate(q_up, r_u))
    local ref_lo = Quaternion.rotate(cam_r, Quaternion.rotate(q_lo, r_u))
    local fu, fu0, fl, fl0 = frame(du, ref_up), frame(du0, u0), frame(dl, ref_lo), frame(dl0, u0)
    if not (fu and fu0 and fl and fl0) then
        return
    end
    delta[dt .. "arm"] = Quaternion.multiply(fu, Quaternion.inverse(fu0))
    delta[dt .. "forearm"] = Quaternion.multiply(fl, Quaternion.inverse(fl0))
    -- forearm roll bones: 1/3, 2/3 of the hand's twist about the forearm (fingers module apply_hand_cam)
    local axis = Vector3.normalize(dl)
    local x, y, z, w = Quaternion.to_elements(Quaternion.multiply(delta[dt .. "hand"], Quaternion.inverse(delta[dt .. "forearm"])))
    local tw = 2 * math.atan2(x * axis.x + y * axis.y + z * axis.z, w)
    if tw > math.pi then
        tw = tw - 2 * math.pi
    elseif tw < -math.pi then
        tw = tw + 2 * math.pi
    end
    delta[dt .. "forearmroll1"] = Quaternion.multiply(Quaternion.axis_angle(axis, tw / 3), delta[dt .. "forearm"])
    delta[dt .. "forearmroll2"] = Quaternion.multiply(Quaternion.axis_angle(axis, tw * 2 / 3), delta[dt .. "forearm"])
    -- fingers: game joint k <- CS2 finger_<k-1> segment (twist from the knuckle line)
    local function ctip(a, b)
        local pa, pb = CP(a), CP(b)
        return pb + Quaternion.rotate(Quaternion.multiply(CR(b), Quaternion.inverse(CR(a))), pb - pa)
    end
    for _, fg in ipairs(DT_FINGERS) do
        local cn = { C("finger_" .. fg .. "_0"), C("finger_" .. fg .. "_1"), C("finger_" .. fg .. "_2") }
        for k = 1, 3 do
            local dn = dt .. "hand" .. fg .. k
            if rest[dn] and cn[k] then
                local live
                if k < 3 and cn[k + 1] then
                    live = CP(cn[k + 1]) - CP(cn[k])
                elseif k == 3 and cn[2] then
                    live = ctip(cn[2], cn[3]) - CP(cn[3])
                end
                local nxt = rest[dt .. "hand" .. fg .. (k + 1)]
                local prv = rest[dt .. "hand" .. fg .. (k - 1)]
                local bind = nxt and (nxt.p0:unbox() - P0(dn)) or (prv and (P0(dn) - prv.p0:unbox()))
                local ref, ref0 = u, u0
                if fg == "thumb" then
                    ref, ref0 = Vector3.cross(f, u), Vector3.cross(f0, u0)
                end
                local fr, fr0 = live and frame(live, ref), bind and frame(bind, ref0)
                if fr and fr0 then
                    delta[dn] = Quaternion.multiply(fr, Quaternion.inverse(fr0))
                end
            end
        end
    end
    -- targets, parents first; unmapped bones keep their parent's turn
    -- The Darktide fingers are shorter and thicker than CS2's: curled the CS2 way, ring/pinky (and on the Stiletto the
    -- middle finger too) sank up to about 9 mm into the knife handle (user report 2026-11-08; measured with
    -- tp\knife_finger_pen.py, rendered with tp\render_knife_fingers_open.py). Opening index..pinky 12 degrees about
    -- the knuckle axis keeps the grip around the handle with almost no clipping. Setting finger_open, degrees.
    local fopen = s == "right" and tonumber(opt("finger_open", 12)) or 0
    if fopen ~= 0 then
        local turn = Quaternion.axis_angle(Vector3.normalize(u), -math.rad(fopen))
        for _, fq in ipairs({ "index", "middle", "ring", "pinky" }) do
            for k = 1, 3 do
                local dn = dt .. "hand" .. fq .. k
                if delta[dn] then
                    delta[dn] = Quaternion.multiply(turn, delta[dn])
                end
            end
        end
    end
    local target = {}
    local lo_d, up_d = delta[dt .. "forearm"], delta[dt .. "arm"]
    local pos_hand = c_wr
    local pos_lo = pos_hand - Quaternion.rotate(lo_d, b_wr - b_lo)
    local pos_up = pos_lo - Quaternion.rotate(up_d, b_lo - b_up)
    local anchor = { [dt .. "arm"] = pos_up, [dt .. "forearm"] = pos_lo, [dt .. "hand"] = pos_hand }
    local name_of = data.name_of
    for _, name in ipairs(names) do
        local b = rest[name]
        local pname = name_of[b.parent]
        local pt = pname and target[pname]
        local d = delta[name] or (pt and pt.d) or up_d
        local p = anchor[name]
        if not p then
            if pt then
                p = pt.p + Quaternion.rotate(pt.d, b.p0:unbox() - rest[pname].p0:unbox())
            else
                p = b.p0:unbox()
            end
        end
        target[name] = { d = d, p = p, r = Quaternion.multiply(d, b.r0:unbox()) }
    end
    -- write locals (the parent of j_<s>arm keeps the driver's current pose)
    for _, name in ipairs(names) do
        local b, tg = rest[name], target[name]
        local pname = name_of[b.parent]
        local pr, pp
        if pname and target[pname] then
            pr, pp = target[pname].r, target[pname].p
        elseif b.parent and b.parent ~= 1 then
            pr, pp = root_relative(driver, b.parent)
        else
            pr, pp = Quaternion.identity(), Vector3(0, 0, 0)
        end
        local inv = Quaternion.inverse(pr)
        Unit.set_local_rotation(driver, b.node, Quaternion.multiply(inv, tg.r))
        Unit.set_local_position(driver, b.node, Quaternion.rotate(inv, tg.p - pp))
    end
end

local function relink(world, unit, parent)
    World.unlink_unit(world, unit)
    World.link_unit(world, unit, 1, parent, 1, World.LINK_MODE_NODE_NAME)
end

local function character_start(data, world, fp_unit)
    local spawner = Managers.state and Managers.state.unit_spawner
    if not spawner then
        return false
    end
    local driver = spawner:spawn_unit(CFG.unit_path(CFG.driver_key), Unit.world_pose(fp_unit, 1))
    if not driver then
        return false
    end
    local ok, fpd = pcall(CFG.fingers.driver, driver, fp_unit, CFG.finger_nodes)
    if not ok or not fpd then
        spawner:mark_for_deletion(driver)
        return false
    end
    World.link_unit(world, driver, 1, fp_unit, 1)
    data.driver, data.fpd, data.rest = driver, fpd, driver_rest(driver)
    data.name_of = {}
    for name, b in pairs(data.rest) do
        data.name_of[b.node] = name
    end
    data.side_names = { right = side_bones(data.rest, data.name_of, "right"), left = side_bones(data.rest, data.name_of, "left") }
    data.linked = {}
    return true
end

-- The Darktide 1p arm units are shared by every QIangIQ mod that runs CS2 arms. Whoever linked a unit last owns it:
-- a mod that stops (e.g. the pistol you just put away) only hands back units it still owns, and the active mod
-- takes a unit back if anyone else moved it.
local ARM_OWNER = rawget(_G, "__qiangiq_cs2_arm_owner")
if type(ARM_OWNER) ~= "table" then
    ARM_OWNER = {}
    rawset(_G, "__qiangiq_cs2_arm_owner", ARM_OWNER)
end

local function character_relink(data, ext, world)
    local now = {}
    for _, u in ipairs(CFG.arm_units(ext)) do
        now[u] = true
        if not data.linked[u] or ARM_OWNER[u] ~= data.driver then
            relink(world, u, data.driver)
            data.linked[u] = true
            ARM_OWNER[u] = data.driver
        end
    end
    for u in pairs(data.linked) do
        if not now[u] or not unit_ok(u) then
            data.linked[u] = nil
            if ARM_OWNER[u] == data.driver then
                ARM_OWNER[u] = nil
            end
        end
    end
end

local function character_stop(data, world)
    if data.linked and unit_ok(data.parent) then
        for u in pairs(data.linked) do
            if unit_ok(u) and ARM_OWNER[u] == data.driver then
                relink(world, u, data.parent)
                ARM_OWNER[u] = nil
            end
        end
    end
    data.linked = nil
    destroy(world, data.driver)
end

local function apply_character(data, ext, world)
    character_relink(data, ext, world)
    CFG.fingers.update(world, data.fpd, nil, 0)
    local fp_unit = data.parent
    if not (data.cs2_rr and Unit.has_node(fp_unit, "ap_camera_node")) then
        return
    end
    data.cam_r, data.cam_p = root_relative(fp_unit, Unit.node(fp_unit, "ap_camera_node"))
    character_side(data, "right", "R")
    character_side(data, "left", "L")
    World.update_unit_and_children(world, data.driver)
end

-- public -------------------------------------------------------------------------------------------------------
local function sleeves()
    local s = CFG.opt("cs2_sleeves")
    if s == "t" or s == "character" then
        return s
    end
    return "ct"
end

function Arms.mode(rec)
    local m = CFG.opt("cs2_arms")
    if m ~= "viewmodel" and m ~= "follow" then
        return nil
    end
    if not (rec and rec.shown and rec.first_person) then
        return nil
    end
    local s = sleeves()
    if s == "character" then
        if m == "follow" or not (CFG.loaded("cs2_arms_ct") and CFG.loaded(CFG.driver_key)) then
            return nil
        end
        return m
    end
    if not CFG.loaded("cs2_arms_" .. s) then
        return nil
    end
    return m
end

local function set_arms_visible(ext, visible)
    for _, u in ipairs(CFG.arm_units(ext)) do
        Unit.set_unit_visibility(u, visible, true)
    end
end

function Arms.stop(ext, world)
    local data = ext[CFG.field]
    if not data then
        return
    end
    ext[CFG.field] = nil
    if data.driver then
        character_stop(data, world)
    end
    destroy(world, data.knife and data.knife.unit)
    destroy(world, data.unit)
    if unit_ok(ext._unit) and ext.force_update_item_visibility then
        pcall(ext.force_update_item_visibility, ext)
    end
end

-- asks the viewmodel for one inspect clip (the game's 1p knife is hidden in this mode, so the knife flip cannot show)
function Arms.flip(ext)
    local data = ext[CFG.field]
    if not data or data.mode ~= "viewmodel" or not data.st then
        return false
    end
    data.st.manual_inspect = true
    return true
end

function Arms.debug(ext)
    local data = ext[CFG.field]
    if not data then
        return "CS2 arms: not active"
    end
    local st = data.st or {}
    return string.format("CS2 arms: %s, sleeves %s, clip %s at %.2f s, action %s", data.mode, data.side,
        tostring(st.clip), st.t or 0, tostring(st.action_key))
end

function Arms.update(ext, rec, mode, world, dt, src_override)
    local data = ext[CFG.field]
    local side = sleeves()
    local fpe = mode and unit_ok(ext._unit) and ScriptUnit.has_extension(ext._unit, "first_person_system")
    local fp_unit = fpe and fpe:first_person_unit()
    if mode and not (fpe and fpe:is_in_first_person_mode() and unit_ok(fp_unit) and Unit.has_node(fp_unit, "ap_camera_node")) then
        mode = nil
    end
    if data and (data.mode ~= mode or data.side ~= side or not unit_ok(data.unit) or data.parent ~= fp_unit
        or (data.driver and not unit_ok(data.driver))) then
        Arms.stop(ext, world)
        data = nil
    end
    if not mode then
        return
    end
    local character = side == "character"
    if not data then
        local parent_node = mode == "viewmodel" and Unit.node(fp_unit, "ap_camera_node") or 1
        local key = character and "cs2_arms_ct" or "cs2_arms_" .. side
        local unit = spawn(world, CFG.unit_path(key), fp_unit, parent_node, mode == "viewmodel")
        if not unit then
            return
        end
        local bones, by_name = capture_rest(unit)
        data = { unit = unit, mode = mode, side = side, parent = fp_unit, bones = bones, by_name = by_name, st = {} }
        ext[CFG.field] = data
        if mode == "viewmodel" and CFG.loaded(CFG.knife_key) then
            local knife = spawn(world, CFG.unit_path(CFG.knife_key), unit, 1, true)
            data.knife = knife and knife_init(knife)
        end
        if character and not character_start(data, world, fp_unit) then
            Arms.stop(ext, world)
            return
        end
    end
    if character then
        Unit.set_unit_visibility(data.unit, false, true)
        if data.knife and unit_ok(data.knife.unit) then
            Unit.set_unit_visibility(data.knife.unit, true, true)
        end
    else
        set_arms_visible(ext, false)
        Unit.set_unit_visibility(data.unit, true, true)
    end
    if mode == "viewmodel" then
        if unit_ok(rec.sword) then
            Unit.set_unit_visibility(rec.sword, false, true)
        end
        data.st.player, data.st.world = ext._unit, world
        local pose = viewmodel_step(data.st, CFG.action(ext._unit), dt)
        if CFG.on_clip then
            CFG.on_clip(data.st.clip, data.st.t)
        end
        if pose then
            apply_viewmodel(data, pose)
        end
    else
        local src = unit_ok(src_override) and src_override or fp_unit
        apply_follow(data, src)
    end
    World.update_unit_and_children(world, data.unit)
    if character then
        apply_character(data, ext, world)
    end
end

return Arms
