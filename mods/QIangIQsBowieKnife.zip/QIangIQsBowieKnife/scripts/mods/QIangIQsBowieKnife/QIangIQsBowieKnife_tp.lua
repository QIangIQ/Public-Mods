-- CS2 third person (user rule 2026-10-27: borrowed animations are retargeted in third person too).
-- The CS2 viewmodel clips, as the "your character" sleeves mode puts them on the Darktide first-person arms, baked onto the

-- with verify_cs2_tp.py). Datavault: Techniques/technique-cs2-clips-to-3p.
--
-- How (QIangIQsChainaxe2h_tp.lua method):
--   * Custom/<driver> is a skeleton-only unit on the 3p skeleton whose simple animation holds the clips one after the other.
--   * When the weapon plays a draw, shot, reload or inspect event, the driver is spawned, its root linked to the player's
--     j_hips, and the body and gear units except the legs, plus the weapon, are moved onto it by node name. The legs stay
--     the game's, so walking is unchanged. The weapon follows the driver's j_rightweaponattach, which the bake moves the
--     way CS2 moves the gun in the hand.
--   * Reloads are stretched to the Darktide reload length (local player: the live action time; others: the template's).
--   * Other players: anim events arrive as an index (AnimationSystem.rpc_player_anim_event); the index of each event is
--     learnt when this client's own weapon plays it, so another player's CS2 moves show once you have done the same move.
--   * Ends LINGER seconds after the clip, or when the weapon plays any other event of its template (block, push, special,
--     unwield), and snaps back to the game's animation.
local Tp = {}
local CFG

local LINGER = 0.35
local KEEP_ON_BODY = { slot_body_legs = true, slot_gear_lowerbody = true }

local active = {}      -- 3p unit -> state
local wielded = setmetatable({}, { __mode = "k" }) -- 3p unit -> weapon template name
local event_names = {} -- state machine event index -> name (learnt from this client's own moves)
local kinds = {}       -- template name -> { [event] = kind }

function Tp.setup(cfg)
    CFG = cfg
end

-- 2026-11-08 fix (user: 3p weapons too small and pointing at the floor): the game's 3p weapon rides the driver's
-- j_rightweaponattach, whose bind IS the hand, so the replacement fitted to it sat on the hand bone axes at the Darktide
-- weapon's size. While a CS2 move plays, the CS2 weapon unit is put under the attach node at G_idle (<Mod>_tp_grip.lua,
-- make_grip.py): the attach node moves by G(t) G_idle^-1, so the weapon sits where CS2 holds it, at CS2 size.
local GRIP, GUN_OF

-- apply_grip sits above the file's own unit_ok, so it needs this one (else: a call to the nil global unit_ok)
local function grip_unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

function Tp.set_grip(grip, gun_of)
    GRIP, GUN_OF = grip, gun_of
end

local function apply_grip(unit, data)
    if not (GRIP and GUN_OF and data and grip_unit_ok(data.driver) and Unit.has_node(data.driver, "j_rightweaponattach")) then
        return
    end
    local gun, base, rec = GUN_OF(unit)
    if not (grip_unit_ok(gun) and grip_unit_ok(base)) then
        return
    end
    local q, p = GRIP.q, GRIP.p
    local g = Matrix4x4.from_quaternion_position(Quaternion.from_elements(q[1], q[2], q[3], q[4]), Vector3(p[1], p[2], p[3]))
    local rwa = Unit.world_pose(data.driver, Unit.node(data.driver, "j_rightweaponattach"))
    local loc = Matrix4x4.multiply(Matrix4x4.multiply(g, rwa), Matrix4x4.inverse(Unit.world_pose(base, 1)))
    Unit.set_local_pose(gun, 1, loc)
    local gs = GRIP.s or 1 -- the knife units are modelled 1 long (data knife_length), guns at gun_scale
    if gs ~= 1 then
        Unit.set_local_scale(gun, 1, Unit.local_scale(gun, 1) * gs)
    end
    if rec then
        rec.frames = 1e9 -- no refit to the game weapon while the CS2 move plays
        data.grip_rec = rec
    end
end

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function now()
    local time = Managers.time
    return time and time:has_timer("gameplay") and time:time("gameplay") or os.clock()
end

-- what each anim event of the template does: draw / shot / reload / reload_loop / inspect / other
local function action_kind(name, action)
    local kind = action.kind or ""
    if name == "action_wield" or kind == "wield" then
        return "draw"
    elseif name == "action_reload_loop" then
        return "reload_loop"
    elseif name == "action_reload" or name == "action_start_reload" or kind:find("reload") then
        return "reload"
    elseif name == "action_inspect" or kind == "inspect" then
        return "inspect"
    elseif kind:find("shoot") or kind:find("spawn_projectile") then
        return "shot"
    elseif kind == "sweep" then
        return name:find("heavy") and "heavy" or "light"
    end
    return "other"
end

local function template_kinds(template_name)
    local map = kinds[template_name]
    if map then
        return map
    end
    map = {}
    local template = WeaponTemplates[template_name]
    for name, action in pairs(template and template.actions or {}) do
        if type(action) == "table" then
            local k = action_kind(name, action)
            for key, v in pairs(action) do
                if type(key) == "string" and key:find("anim_event") and type(v) == "string" then
                    if map[v] == nil or map[v] == "other" then
                        map[v] = k
                    end
                end
            end
        end
    end
    kinds[template_name] = map
    return map
end

-- the template's own length of an action kind (others: no live action), scaled by nothing
local function template_total(template_name, kind)
    local template = WeaponTemplates[template_name]
    local actions = template and template.actions or {}
    if kind == "reload" then
        local start, loop = actions.action_start_reload, actions.action_reload_loop
        if start and loop and start.total_time and loop.total_time then
            return start.total_time + 5 * loop.total_time
        end
        local rt = template and template.reload_template
        local st = rt and rt.states and rt[rt.states[1]]
        if st and type(st.time) == "number" then
            return st.time
        end
        local a = actions.action_reload
        return a and a.total_time and a.total_time < 10 and a.total_time or nil
    end
    return nil
end

local function attach_index(parent, item, breed_name)
    local node = item and ((item.breed_attach_node and breed_name and item.breed_attach_node[breed_name]) or item.attach_node)
    if node == nil or node == "" then
        return 1
    end
    if tonumber(node) ~= nil then
        return tonumber(node)
    end
    if Unit.has_node(parent, node) then
        return Unit.node(parent, node)
    end
end

local function movable_units(unit, template_name)
    local ext = ScriptUnit.has_extension(unit, "visual_loadout_system")
    local found = {}
    for name, slot in pairs(ext and ext._equipment or {}) do
        local item = slot.item
        local body = type(name) == "string" and (name:find("^slot_body_") or name:find("^slot_gear_")) and not KEEP_ON_BODY[name]
        local weapon = item and item.weapon_template == template_name
        if (body or weapon) and unit_ok(slot.unit_3p) then
            local map_mode = item and item.link_map_mode and World[item.link_map_mode]
            if map_mode == nil or map_mode == World.LINK_MODE_NODE_NAME then
                found[#found + 1] = { unit = slot.unit_3p, item = item }
            end
        end
    end
    return found
end

local function relink(world, child, parent, node)
    World.unlink_unit(world, child)
    World.link_unit(world, child, 1, parent, node, World.LINK_MODE_NODE_NAME)
end

function Tp.stop(unit)
    local data = active[unit]
    if not data then
        return
    end
    active[unit] = nil
    if data.grip_rec then
        data.grip_rec.frames = 0 -- refit to the game weapon
    end
    if unit_ok(unit) then
        for _, moved in ipairs(data.moved) do
            if unit_ok(moved.unit) then
                relink(data.world, moved.unit, unit, moved.node)
            end
        end
    end
    if unit_ok(data.driver) then
        local unit_spawner = Managers.state and Managers.state.unit_spawner
        if unit_spawner then
            unit_spawner:mark_for_deletion(data.driver)
        end
    end
end

local function start(unit, template_name)
    local path = CFG.tp_driver_path()
    local unit_spawner = Managers.state and Managers.state.unit_spawner
    local world = unit_ok(unit) and Unit.world(unit)
    if not (path and unit_spawner and world and Unit.has_node(unit, "j_hips")) then
        return nil
    end
    local driver = unit_spawner:spawn_unit(path, Unit.world_pose(unit, 1))
    if not driver then
        return nil
    end
    World.link_unit(world, driver, 1, unit, Unit.node(unit, "j_hips"))
    local unit_data = ScriptUnit.has_extension(unit, "unit_data_system")
    local breed_name = unit_data and unit_data.breed_name and unit_data:breed_name()
    local data = { driver = driver, world = world, moved = {} }
    for _, entry in ipairs(movable_units(unit, template_name)) do
        local own = attach_index(unit, entry.item, breed_name)
        local on_driver = own and attach_index(driver, entry.item, breed_name)
        if own and on_driver then
            relink(world, entry.unit, driver, on_driver)
            data.moved[#data.moved + 1] = { unit = entry.unit, node = own }
        end
    end
    active[unit] = data
    return data
end

local function pick_inspect()
    local list = {}
    for _, k in ipairs({ "lookat01", "lookat02", "lookat03" }) do
        if CFG.spans[k] then
            list[#list + 1] = k
        end
    end
    return list[math.random(math.max(1, #list))]
end

local light_turn = setmetatable({}, { __mode = "k" })

local function clip_for(kind, empty, unit, template_name)
    local S = CFG.spans
    if kind == "light" then
        light_turn[unit] = not light_turn[unit]
        return (light_turn[unit] or not S.light_miss2) and "light_miss1" or "light_miss2"
    elseif kind == "heavy" then
        return CFG.heavy_clip and CFG.heavy_clip(template_name) or "heavy_miss1"
    elseif kind == "draw" then
        return "draw"
    elseif kind == "shot" then
        return (empty and S.shoot_empty) and "shoot_empty" or "shoot1"
    elseif kind == "reload" then
        return (empty and S.reload_empty) and "reload_empty" or "reload"
    elseif kind == "inspect" then
        return pick_inspect()
    end
end

function Tp.on_event(unit, event)
    local template_name = wielded[unit]
    if not (template_name and CFG.templates[template_name] and CFG.enabled() and CFG.shown(unit)) then
        return
    end
    local kind = template_kinds(template_name)[event]
    local data = active[unit]
    if kind == nil or kind == "reload_loop" then
        return
    end
    if kind == "other" then
        if data then
            Tp.stop(unit)
        end
        return
    end
    if kind == "inspect" and data and data.kind == "inspect" then
        return
    end
    local info = CFG.local_action(unit)
    local empty = info and info.empty or false
    local clip = clip_for(kind, empty, unit, template_name)
    local span = clip and CFG.spans[clip]
    if not span then
        return
    end
    local total = span.length
    if kind == "reload" then
        total = (info and info.total_time) or template_total(template_name, kind) or total
        total = math.max(span.length / 4, math.min(span.length * 4, total))
    elseif kind == "shot" then
        total = span.length / math.max(0.5, CFG.opt("cs2_shot_speed", 1))
    end
    data = data or start(unit, template_name)
    if not data then
        return
    end
    local t = now()
    local speed = span.length / math.max(total, 0.01)
    Unit.play_simple_animation(data.driver, span.start, span.start + span.length, false, speed)
    data.kind, data.clip = kind, clip
    apply_grip(unit, data)
    data.end_t = t + total + LINGER
end

function Tp.update()
    if next(active) == nil then
        return
    end
    local t = now()
    for unit, data in pairs(active) do
        if not unit_ok(unit) or not unit_ok(data.driver) or not CFG.templates[wielded[unit] or ""] or t >= data.end_t then
            Tp.stop(unit)
        else
            apply_grip(unit, data)
        end
    end
end

function Tp.wielded(unit, template_name)
    wielded[unit] = template_name
    if active[unit] and not CFG.templates[template_name or ""] then
        Tp.stop(unit)
    end
end

function Tp.learn(func, unit, event_name, ...)
    local template_name = wielded[unit]
    if not (template_name and CFG.templates[template_name] and template_kinds(template_name)[event_name]) then
        return func(...)
    end
    local original = Unit.animation_event
    Unit.animation_event = function(u, name, ...)
        local index = original(u, name, ...)
        if u == unit and name == event_name and index then
            event_names[index] = name
        end
        return index
    end
    local ok, a, b = pcall(func, ...)
    Unit.animation_event = original
    if not ok then
        error(a, 0)
    end
    return a, b
end

function Tp.on_husk_event(unit, event_index)
    local name = event_names[event_index]
    if name then
        Tp.on_event(unit, name)
    end
end

function Tp.forget(unit)
    Tp.stop(unit)
    wielded[unit] = nil
end

function Tp.stop_all()
    for unit in pairs(active) do
        Tp.stop(unit)
    end
end

function Tp.debug()
    local n, learnt = 0, 0
    local last = ""
    for _, d in pairs(active) do
        n = n + 1
        last = tostring(d.clip)
    end
    for _ in pairs(event_names) do
        learnt = learnt + 1
    end
    return string.format("third person: %d playing %s, %d events learnt for other players, driver %s", n, last, learnt,
        tostring(CFG.tp_driver_path()))
end

return Tp
