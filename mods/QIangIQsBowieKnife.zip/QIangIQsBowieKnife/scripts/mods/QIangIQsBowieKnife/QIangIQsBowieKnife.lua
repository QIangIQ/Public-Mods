local mod = get_mod("QIangIQsBowieKnife")

local SYNC_KEY = "bowie"
local SYNC_BOOLS = { "replace_combat_knife", "knife_flip", "flip_on_inspect", "cs2_wrist_turns", "replace_duelling_sword" }
local SYNC_DEFAULTS = { replace_combat_knife = true, knife_flip = false, flip_on_inspect = true, cs2_wrist_turns = false, replace_duelling_sword = false }
local SYNC_VALUES = { "knife_scale", "fp_scale", "knife_grip", "knife_roll", "knife_tilt", "knife_pitch", "knife_edge", "flip_speed", "hold_fingers", "hold_palm", "hold_thumb" }
local SYNC_LAYOUT = 260 + #SYNC_VALUES
local sync_ctx = nil
local sync_known = setmetatable({}, { __mode = "k" })
local sync_all = setmetatable({}, { __mode = "k" })
local sync_decoded = setmetatable({}, { __mode = "k" })
local SYNC_FALSE = { __index = function() return false end }
local SYNC_OFF = setmetatable({}, SYNC_FALSE)

local function opt(key)
    if sync_ctx then
        return sync_ctx[key]
    end
    return mod:get(key)
end

local function sync_api()
    local hub = get_mod("QIangIQsModelSync")
    return hub and hub.api
end

local function sync_me()
    local players = Managers.player
    if not players then
        return nil
    end
    local ok, player = pcall(players.local_player_safe, players, 1)
    return ok and player or nil
end

local function sync_decode(raw)
    local t = sync_decoded[raw]
    if t ~= nil then
        return t
    end
    t = false
    if type(raw) == "table" and raw[1] == SYNC_LAYOUT then
        t = setmetatable({}, SYNC_FALSE)
        local mask = tonumber(raw[2]) or 0
        for i = 1, #SYNC_BOOLS do
            t[SYNC_BOOLS[i]] = mask % 2 >= 1
            mask = math.floor(mask / 2)
        end
        for i = 1, #SYNC_VALUES do
            local v = raw[2 + i]
            if v ~= nil then
                t[SYNC_VALUES[i]] = v
            end
        end
    end
    sync_decoded[raw] = t
    return t
end

local function sync_owner(ext)
    sync_all[ext] = true
    local player = ext._player
    if player == nil or player == sync_me() then
        return nil
    end
    local api = sync_api()
    local raw = api and api.peer(SYNC_KEY, player)
    local state = raw and sync_decode(raw)
    if state then
        sync_known[ext] = true
        return state
    end
    return SYNC_OFF
end

local function sync_shown(ext)
    local player = ext._player
    return player ~= nil and (player == sync_me() or sync_known[ext] == true)
end

local function sync_pack(...)
    return { n = select("#", ...), ... }
end

local function sync_wrap(fn, ext_index)
    return function(...)
        local ext = select(ext_index, ...)
        local previous = sync_ctx
        sync_ctx = sync_owner(ext)
        local results = sync_pack(pcall(fn, ...))
        sync_ctx = previous
        if not results[1] then
            error(results[2], 0)
        end
        return unpack(results, 2, results.n)
    end
end

local SYNC_HUSK_METHODS = { init = true, update = true, _update_item_visibility = true, destroy = true }

local function vl_hook_safe(method, fn)
    mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, method, sync_wrap(fn, 1))
    if SYNC_HUSK_METHODS[method] then
        mod:hook_safe(CLASS.PlayerHuskVisualLoadoutExtension, method, sync_wrap(fn, 1))
    end
end

local function vl_hook(method, fn)
    mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, method, sync_wrap(fn, 2))
    if SYNC_HUSK_METHODS[method] then
        mod:hook(CLASS.PlayerHuskVisualLoadoutExtension, method, sync_wrap(fn, 2))
    elseif method == "_unequip_item_from_slot" then
        mod:hook(CLASS.PlayerHuskVisualLoadoutExtension, "rpc_player_unequip_item_from_slot", sync_wrap(function(func, self, channel_id, go_id, slot_id, ...)
            local NetworkLookup = require("scripts/network_lookup/network_lookup")
            local slot_name = NetworkLookup.player_inventory_slot_names[slot_id]
            return fn(function()
                return func(self, channel_id, go_id, slot_id)
            end, self, slot_name)
        end, 2))
    end
end

mod.AUTHOR = "QIangIQ"

local TEMPLATES = {
    combatknife_p1_m1 = "replace_combat_knife",
    combatknife_p1_m2 = "replace_combat_knife",
    combatsword_p3_m1 = "replace_duelling_sword",
    combatsword_p3_m2 = "replace_duelling_sword",
    combatsword_p3_m3 = "replace_duelling_sword",
}
local KNIFE_REF_LENGTH = 0.93
local fit_template = nil

local KNIFE_KEY = "bowie_ddpat"

local function asset_id(key)
    return "QIangIQsBowieKnife:" .. key
end

local function unit_path(key)
    return "content/mods/qiangiq_bowie/" .. key
end

local loaded = {}

local FIT_FRAMES = 10
local fit_generation = 0

local custom_assets = nil
local mod_on = true
local session_off = false

local tracked = setmetatable({}, { __mode = "k" })
local tracked_ui = setmetatable({}, { __mode = "k" })
local tracked_wpn = setmetatable({}, { __mode = "k" })

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function wants_item(item)
    if not (mod_on and item and TEMPLATES[item.weapon_template]) then
        return false
    end
    if session_off and not sync_ctx then
        return false
    end
    if not opt(TEMPLATES[item.weapon_template]) then
        return false
    end
    return loaded[KNIFE_KEY] == true
end

local function fmt(v)
    return string.format("(%.3f, %.3f, %.3f)", v.x, v.y, v.z)
end

local last_fit = {}
local fit_pose = nil

local function weapon_parts(base, attachments)
    local parts = {}
    local function add(unit)
        if unit_ok(unit) then
            local pose, ext = Unit.box(unit)
            if pose and ext then
                local half = math.max(ext.x, ext.y, ext.z)
                if half > 0.005 then
                    parts[#parts + 1] = { center = Matrix4x4.translation(pose), half = half }
                end
            end
        end
    end
    add(base)
    if attachments then
        for i = 1, #attachments do
            add(attachments[i])
        end
    end
    return parts
end

local function fit(knife, base, attachments, parent_scale, view, first_person)
    local parts = weapon_parts(base, attachments)
    if #parts == 0 then
        return false
    end
    local origin = Unit.world_position(base, 1)
    local far_d, far_c = 0, nil
    for i = 1, #parts do
        local d = Vector3.length_squared(parts[i].center - origin)
        if d > far_d then
            far_d, far_c = d, parts[i].center
        end
    end
    if not far_c or far_d < 0.0001 then
        return false
    end
    local dir = Vector3.normalize(far_c - origin)
    local source = "hand->farthest piece"
    local base_rot = Unit.world_rotation(base, 1)
    local base_axes = { Quaternion.right(base_rot), Quaternion.forward(base_rot), Quaternion.up(base_rot) }
    local best, best_axis = 0, nil
    for i = 1, 3 do
        local d = Vector3.dot(base_axes[i], dir)
        if math.abs(d) > best then
            best = math.abs(d)
            best_axis = d < 0 and -base_axes[i] or base_axes[i]
        end
    end
    if best_axis and best > 0.97 then
        dir = best_axis
        source = string.format("base unit axis (%.2f to hand->farthest)", best)
    end
    if opt("knife_flip") then
        dir = -dir
    end
    local t_min, t_max = 0, 0
    for i = 1, #parts do
        local t = Vector3.dot(parts[i].center - origin, dir)
        t_min = math.min(t_min, t - parts[i].half)
        t_max = math.max(t_max, t + parts[i].half)
    end
    local length = t_max - t_min
    if length <= 0 then
        return false
    end
    local ls = (opt("knife_scale") or 0.86) * (first_person and (opt("fp_scale") or 0.51) or 1)
    if fit_template and TEMPLATES[fit_template] == "replace_duelling_sword" then
        ls = ls * KNIFE_REF_LENGTH * (opt("duelling_size") or 1) / length
    end
    local s_world = length * ls
    local shift = opt("knife_grip") or 0.18
    local ref, ref_dot = nil, nil
    for i = 1, 3 do
        local d = math.abs(Vector3.dot(base_axes[i], dir))
        if ref_dot == nil or d < ref_dot then
            ref, ref_dot = base_axes[i], d
        end
    end
    local up = Vector3.normalize(ref - dir * Vector3.dot(ref, dir))
    local roll = math.rad(opt("knife_roll") or -180)
    if roll ~= 0 then
        local side = Vector3.cross(dir, up)
        up = up * math.cos(roll) + side * math.sin(roll)
    end
    local tilt = math.rad(opt("knife_tilt") or -20)
    if tilt ~= 0 then
        local side = Vector3.cross(dir, up)
        dir = Vector3.normalize(dir * math.cos(tilt) + side * math.sin(tilt))
    end
    local pitch = math.rad(opt("knife_pitch") or 0)
    if pitch ~= 0 then
        local d2 = dir * math.cos(pitch) + up * math.sin(pitch)
        up = Vector3.normalize(up * math.cos(pitch) - dir * math.sin(pitch))
        dir = Vector3.normalize(d2)
    end
    local edge = math.rad(opt("knife_edge") or 180)
    if edge ~= 0 then
        up = Vector3.normalize(up - dir * Vector3.dot(up, dir))
        local side = Vector3.cross(dir, up)
        up = up * math.cos(edge) + side * math.sin(edge)
    end
    local butt = origin + dir * (t_min * ls - shift * s_world)
    local bx, by, bz = base_axes[1], base_axes[2], base_axes[3]
    local function to_local(v)
        return Vector3(Vector3.dot(v, bx), Vector3.dot(v, by), Vector3.dot(v, bz))
    end
    local k = parent_scale and parent_scale > 0 and parent_scale or 1
    local s = s_world / k
    local local_pos = to_local(butt - origin) * (1 / k)
    local local_dir = to_local(dir)
    Unit.set_local_position(knife, 1, local_pos)
    Unit.set_local_rotation(knife, 1, Quaternion.look(local_dir, to_local(up)))
    Unit.set_local_scale(knife, 1, Vector3(s, s, s))
    fit_pose = { Vector3Box(local_pos), QuaternionBox(Quaternion.look(local_dir, to_local(up))), s, s_world, k }
    if view then
        last_fit[view] = string.format("%s: %d pieces, dir by %s, length %.3f (hand at %.2f of it), local start %s, local dir %s, parent scale %.3f",
            view, #parts, source, length, -t_min / length, fmt(local_pos), fmt(local_dir), k)
    end
    return true
end

local function hide_originals(base, attachments)
    Unit.set_unit_visibility(base, false, true)
    if attachments then
        for i = 1, #attachments do
            if unit_ok(attachments[i]) then
                Unit.set_unit_visibility(attachments[i], false, true)
            end
        end
    end
end

local function now()
    local time = Managers.time
    local ok, t = pcall(time.time, time, "main")
    return ok and t or 0
end

local function read_comp(ude, name)
    local ok, comp = pcall(ude.read_component, ude, name)
    return ok and comp or nil
end

local function holder_action(holder_unit)
    local ude = unit_ok(holder_unit) and ScriptUnit.has_extension(holder_unit, "unit_data_system")
    if not ude then
        return nil
    end
    local wa = read_comp(ude, "weapon_action")
    local name = wa and wa.current_action_name
    return type(name) == "string" and name or nil
end

local function smooth(x)
    x = math.min(1, math.max(0, x))
    return x * x * (3 - 2 * x)
end

local function lerp(a, b, t)
    return a + (b - a) * t
end

local ANIMS = mod:io_dofile("QIangIQsBowieKnife/scripts/mods/QIangIQsBowieKnife/QIangIQsBowieKnife_anims")
local Fingers = mod:io_dofile("QIangIQsBowieKnife/scripts/mods/QIangIQsBowieKnife/QIangIQsBowieKnife_fingers")
Fingers.setup(mod:io_dofile("QIangIQsBowieKnife/scripts/mods/QIangIQsBowieKnife/QIangIQsBowieKnife_fp_nodes"))
local CS2Arms = mod:io_dofile("QIangIQsBowieKnife/scripts/mods/QIangIQsBowieKnife/QIangIQsBowieKnife_cs2arms")
local FINGER_FADE = 0.15
local DRIVER_KEY = "bw_fp_driver"
local TP_KEY = "bw_tp_driver"
local ABS_FADE = 0.25
local IDENTITY = { 0, 0, 0, 1 }
local EASE_OUT = 0.15

local function qlerp(a, b, u)
    local d = a[1] * b[1] + a[2] * b[2] + a[3] * b[3] + a[4] * b[4]
    local sgn = d < 0 and -1 or 1
    local x, y, z, w = lerp(a[1], sgn * b[1], u), lerp(a[2], sgn * b[2], u), lerp(a[3], sgn * b[3], u), lerp(a[4], sgn * b[4], u)
    local n = math.sqrt(x * x + y * y + z * z + w * w)
    if n < 1e-9 then
        return { 0, 0, 0, 1 }
    end
    return { x / n, y / n, z / n, w / n }
end

local function clip_frame(clip, channel, t)
    local f = t * ANIMS.fps
    local i = math.floor(f)
    local rows = clip[channel]
    local n = #rows
    return rows[math.min(n, math.max(1, i + 1))], rows[math.min(n, math.max(1, i + 2))], f - i
end

local function clip_pose(clip, t)
    local pose = {}
    for _, ch in ipairs({ "blade", "handle", "latch" }) do
        local r0, r1, u = clip_frame(clip, ch, t)
        pose[ch] = qlerp(r0, r1, u)
    end
    local r0, r1, u = clip_frame(clip, opt("cs2_wrist_turns") and "wrist" or "root", t)
    pose.root_q = qlerp({ r0[1], r0[2], r0[3], r0[4] }, { r1[1], r1[2], r1[3], r1[4] }, u)
    pose.root_t = { lerp(r0[5], r1[5], u), lerp(r0[6], r1[6], u), lerp(r0[7], r1[7], u) }
    local a0, a1, au = clip_frame(clip, "abs", t)
    pose.abs_q = qlerp({ a0[1], a0[2], a0[3], a0[4] }, { a1[1], a1[2], a1[3], a1[4] }, au)
    pose.abs_t = { lerp(a0[5], a1[5], au), lerp(a0[6], a1[6], au), lerp(a0[7], a1[7], au) }
    pose.abs_c = { lerp(a0[8], a1[8], au), lerp(a0[9], a1[9], au), lerp(a0[10], a1[10], au) }
    local f0, f1, fu = clip_frame(clip, "fingers", t)
    local fingers = {}
    for k = 1, #f0, 4 do
        local q = qlerp({ f0[k], f0[k + 1], f0[k + 2], f0[k + 3] }, { f1[k], f1[k + 1], f1[k + 2], f1[k + 3] }, fu)
        fingers[k], fingers[k + 1], fingers[k + 2], fingers[k + 3] = q[1], q[2], q[3], q[4]
    end
    pose.fingers = fingers
    local w0, w1, wu = clip_frame(clip, "handcam", t)
    local arm = qlerp(w0, w1, wu)
    pose.arm = arm
    pose.clip = clip
    return pose
end

local function rest_pose()
    return { blade = IDENTITY, handle = IDENTITY, latch = ANIMS.latch_rest, root_q = IDENTITY, root_t = { 0, 0, 0 } }
end

local function blend_pose(a, b, u)
    local p = {}
    for _, ch in ipairs({ "blade", "handle", "latch", "root_q" }) do
        p[ch] = qlerp(a[ch], b[ch], u)
    end
    p.root_t = { lerp(a.root_t[1], b.root_t[1], u), lerp(a.root_t[2], b.root_t[2], u), lerp(a.root_t[3], b.root_t[3], u) }
    return p
end

local FLIP_BONES = { bf_blade = "blade", bf_handle = "handle", bf_latch = "latch" }

local function bones_init(rec)
    rec.bones = {}
    local unit = rec.sword
    if not (Unit.has_node(unit, "bf_tip") and Unit.has_node(unit, "bf_axis_x")) then
        return
    end
    local ex = Unit.local_position(unit, Unit.node(unit, "bf_axis_x"))
    local ey = Unit.local_position(unit, Unit.node(unit, "bf_tip"))
    if Vector3.length(ex) < 1e-6 or Vector3.length(ey) < 1e-6 then
        return
    end
    ex, ey = Vector3.normalize(ex), Vector3.normalize(ey)
    rec.ax = { Vector3Box(ex), Vector3Box(ey), Vector3Box(Vector3.cross(ex, ey)) }
    for name, ch in pairs(FLIP_BONES) do
        if Unit.has_node(unit, name) then
            local n = Unit.node(unit, name)
            rec.bones[ch] = { node = n, rot = QuaternionBox(Unit.local_rotation(unit, n)) }
        end
    end
end

local function to_root_space(rec, q)
    local w = math.max(-1, math.min(1, q[4]))
    local sn = math.sqrt(math.max(0, 1 - w * w))
    if sn < 1e-6 then
        return nil
    end
    local ex, ey, ez = rec.ax[1]:unbox(), rec.ax[2]:unbox(), rec.ax[3]:unbox()
    local axis = Vector3.normalize(ex * (q[1] / sn) + ey * (q[2] / sn) + ez * (q[3] / sn))
    return Quaternion.axis_angle(axis, 2 * math.acos(w))
end

local function hand_landmark(rec, holder_unit)
    if not unit_ok(holder_unit) then
        return nil
    end
    local unit = holder_unit
    if rec.first_person then
        if rec.fp_driver and unit_ok(rec.fp_driver) then
            unit = rec.fp_driver
        else
            local fpe = ScriptUnit.has_extension(holder_unit, "first_person_system")
            unit = fpe and fpe:first_person_unit()
        end
    end
    if not unit_ok(unit) then
        return nil
    end
    local names = { "j_righthand", "j_righthandmiddle1", "j_righthandindex1", "j_righthandpinky1" }
    local p = {}
    for i = 1, 4 do
        if not Unit.has_node(unit, names[i]) then
            return nil
        end
        p[i] = Unit.world_position(unit, Unit.node(unit, names[i]))
    end
    local f = Vector3.normalize(p[2] - p[1])
    local u = p[3] - p[4]
    u = u - f * Vector3.dot(u, f)
    if Vector3.length(u) < 1e-6 then
        return nil
    end
    return p[1], Quaternion.look(f, Vector3.normalize(u)), Vector3.length(p[2] - p[1])
end

local function abs_local(rec, pose)
    local fp = rec.fit_pose
    local lm_p, lm_r = rec.lm_p, rec.lm_r
    if not (fp and fp[4] and fp[5] and lm_p and unit_ok(rec.base)) then
        return nil
    end
    local q, t = pose.abs_q, pose.abs_t
    local ra = Quaternion.from_elements(q[1], q[2], q[3], q[4])
    local world_r = Quaternion.multiply(lm_r:unbox(), ra)
    local L = ANIMS.cs2_length
    local h = (rec.lm_h or ANIMS.hand_size) / ANIMS.hand_size
    local pin = Vector3(ANIMS.pins.blade[1], ANIMS.pins.blade[2], ANIMS.pins.blade[3])
    local pin_cs2 = Quaternion.rotate(ra, pin * L) + Vector3(t[1], t[2], t[3]) * L
    local origin_lm = pin_cs2 * h - Quaternion.rotate(ra, pin * fp[4])
    local drv = rec.fp_driver
    if pose.abs_c and opt("hold_on_fingertips") ~= false and drv and unit_ok(drv) and Unit.has_node(drv, "j_righthandindex3") and Unit.has_node(drv, "j_righthandthumb3") then
        local mid = (Unit.world_position(drv, Unit.node(drv, "j_righthandindex3")) + Unit.world_position(drv, Unit.node(drv, "j_righthandthumb3"))) * 0.5
        local mid_lm = Quaternion.rotate(Quaternion.inverse(lm_r:unbox()), mid - lm_p:unbox())
        local c = pose.abs_c
        origin_lm = mid_lm - Quaternion.rotate(ra, Vector3(c[1], c[2], c[3]) * fp[4])
    end
    origin_lm = origin_lm + Vector3(opt("hold_palm") or 0, opt("hold_fingers") or 0, opt("hold_thumb") or 0) * 0.01
    local world_p = lm_p:unbox() + Quaternion.rotate(lm_r:unbox(), origin_lm)
    local base_r_inv = Quaternion.inverse(Unit.world_rotation(rec.base, 1))
    local local_p = Quaternion.rotate(base_r_inv, world_p - Unit.world_position(rec.base, 1)) * (1 / fp[5])
    return Quaternion.multiply(base_r_inv, world_r), local_p
end

local function hold_capture(rec, holder_unit)
    rec.hold_from = nil
    local lp, lr = hand_landmark(rec, holder_unit)
    if lp and unit_ok(rec.sword) then
        local inv = Quaternion.inverse(lr)
        rec.hold_from = { QuaternionBox(Quaternion.multiply(inv, Unit.world_rotation(rec.sword, 1))),
            Vector3Box(Quaternion.rotate(inv, Unit.world_position(rec.sword, 1) - lp)) }
    end
end

local function hold_local(rec)
    local h, fp = rec.hold_from, rec.fit_pose
    if not (h and fp and fp[5] and rec.lm_p and rec.lm_r and unit_ok(rec.base)) then
        return nil
    end
    local lr = rec.lm_r:unbox()
    local world_r = Quaternion.multiply(lr, h[1]:unbox())
    local world_p = rec.lm_p:unbox() + Quaternion.rotate(lr, h[2]:unbox())
    local base_r_inv = Quaternion.inverse(Unit.world_rotation(rec.base, 1))
    return Quaternion.multiply(base_r_inv, world_r), Quaternion.rotate(base_r_inv, world_p - Unit.world_position(rec.base, 1)) * (1 / fp[5])
end

local function apply_pose(rec, pose)
    for ch, b in pairs(rec.bones) do
        local d = to_root_space(rec, pose[ch])
        local rest = b.rot:unbox()
        Unit.set_local_rotation(rec.sword, b.node, d and Quaternion.multiply(d, rest) or rest)
    end
    local fp = rec.fit_pose
    if fp then
        local q = pose.root_q
        local rq = Quaternion.from_elements(q[1], q[2], q[3], q[4])
        local fr = fp[2]:unbox()
        local t = pose.root_t
        local tv = Vector3(t[1], t[2], t[3])
        local d = rec.pivot_shift and rec.pivot_shift:unbox()
        if d then
            tv = tv + d - Quaternion.rotate(rq, d)
        end
        local rel_r, rel_p = Quaternion.multiply(fr, rq), fp[1]:unbox() + Quaternion.rotate(fr, tv * fp[3])
        local w = rec.abs_weight or 0
        if w > 0 and pose.abs_q then
            local ar, ap = abs_local(rec, pose)
            if ar then
                if rec.clip and w < 1 then
                    local hr, hp = hold_local(rec)
                    if hr then
                        rel_r, rel_p = hr, hp
                    end
                end
                rel_r = Quaternion.lerp(rel_r, ar, w)
                rel_p = rel_p + (ap - rel_p) * w
            end
        end
        Unit.set_local_rotation(rec.sword, 1, rel_r)
        Unit.set_local_position(rec.sword, 1, rel_p)
    end
end

local function pivot_shift(rec, holder_unit, clip)
    local fp = rec.fit_pose
    if not (fp and fp[4] and fp[4] > 0 and unit_ok(holder_unit)) then
        return nil
    end
    local unit = holder_unit
    if rec.first_person then
        local fpe = ScriptUnit.has_extension(holder_unit, "first_person_system")
        unit = fpe and fpe:first_person_unit()
    end
    if not (unit_ok(unit) and Unit.has_node(unit, "j_righthand")) then
        return nil
    end
    local hand = Unit.world_position(unit, Unit.node(unit, "j_righthand"))
    local k_pos, k_rot = Unit.world_position(rec.sword, 1), Unit.world_rotation(rec.sword, 1)
    local here = Quaternion.rotate(Quaternion.inverse(k_rot), hand - k_pos) * (1 / fp[4])
    local c = opt("cs2_wrist_turns") and clip.forearm or clip.hand
    local d = here - Vector3(c[1], c[2], c[3])
    if Vector3.length(d) > 2 then
        return nil
    end
    return Vector3Box(d)
end

local CS2Audio = mod:io_dofile("QIangIQsBowieKnife/scripts/mods/QIangIQsBowieKnife/QIangIQsBowieKnife_cs2audio")
CS2Audio.setup({
    data = mod:io_dofile("QIangIQsBowieKnife/scripts/mods/QIangIQsBowieKnife/QIangIQsBowieKnife_cs2sounds"),
    mod_name = "QIangIQsBowieKnife",
    now = now,
    opt = function(key)
        return mod:get(key)
    end,
})
local hide_1p_knife = false

local function animate(rec, holder_unit)
    if not rec.bones then
        bones_init(rec)
    end
    if not rec.ax then
        return
    end
    local t = now()
    local dt = rec.last_t and math.min(0.1, math.max(0, t - rec.last_t)) or 0
    rec.last_t = t
    local speed = math.max(0.1, opt("flip_speed") or 1)

    local action = holder_action(holder_unit)
    local inspecting = action == "action_inspect" or action == "action_inspect_3p"
    local want = (inspecting and opt("flip_on_inspect") ~= false) or rec.manual
    local pose
    rec.inspect_age = want and (rec.inspect_age or 0) + dt or 0
    if want then
        if not rec.clip then
            hold_capture(rec, holder_unit)
            rec.clip_index = (rec.clip_index or 0) % #ANIMS.clips + 1
            rec.clip, rec.clip_t = ANIMS.clips[rec.clip_index], 0
            rec.pivot_shift = pivot_shift(rec, holder_unit, rec.clip)
        end
        rec.clip_t = rec.clip_t + dt * speed
        local held = inspecting and opt("flip_on_inspect") ~= false
        local dur = (rec.clip.frames - 1) / ANIMS.fps
        if rec.clip_t >= dur and held then
            rec.clip_t = rec.clip_t - dur
            rec.clip_index = rec.clip_index % #ANIMS.clips + 1
            rec.clip = ANIMS.clips[rec.clip_index]
            rec.manual = nil
            dur = (rec.clip.frames - 1) / ANIMS.fps
        end
        if rec.clip_t >= dur then
            rec.clip = nil
            rec.manual = nil
            pose = rest_pose()
        else
            pose = clip_pose(rec.clip, rec.clip_t)
            local tail = held and math.huge or dur - rec.clip_t
            rec.abs_weight = opt("hand_lock") ~= false and smooth(math.min(rec.inspect_age, tail) / ABS_FADE) or 0
        end
        rec.ease = nil
        rec.finger_quats = pose.fingers
        rec.finger_weight = pose.fingers and smooth(rec.inspect_age / FINGER_FADE) or 0
    else
        if rec.clip then
            rec.ease = { from = clip_pose(rec.clip, rec.clip_t), t = 0 }
            rec.ease_clip, rec.ease_clip_name = rec.clip, rec.clip.name
            rec.abs_weight_at_end = rec.abs_weight or 0
            rec.finger_weight_at_end = rec.finger_weight or 1
            rec.clip = nil
        end
        if rec.ease then
            rec.ease.t = rec.ease.t + dt
            local u = smooth(rec.ease.t / EASE_OUT)
            pose = blend_pose(rec.ease.from, rest_pose(), u)
            pose.abs_q, pose.abs_t, pose.abs_c = rec.ease.from.abs_q, rec.ease.from.abs_t, rec.ease.from.abs_c
            pose.arm, pose.clip = rec.ease.from.arm, rec.ease.from.clip
            rec.abs_weight = (1 - u) * (rec.abs_weight_at_end or 0)
            rec.finger_quats = rec.ease.from.fingers
            rec.finger_weight = (1 - u) * (rec.finger_weight_at_end or 1)
            if u >= 1 then
                rec.ease = nil
                rec.finger_weight = 0
            end
        elseif rec.at_rest then
            rec.finger_weight = 0
            if rec.first_person and not sync_ctx then
                CS2Audio.tick("knife", nil, 0)
            end
            return
        else
            pose = rest_pose()
        end
    end
    if (rec.abs_weight or 0) > 0 then
        local lp, lr, lh = hand_landmark(rec, holder_unit)
        rec.lm_p, rec.lm_r, rec.lm_h = lp and Vector3Box(lp), lr and QuaternionBox(lr), lh
    end
    if not (rec.clip or rec.ease) then
        rec.abs_weight = 0
    end
    rec.last_pose = pose
    rec.last_holder = holder_unit
    apply_pose(rec, pose)
    rec.at_rest = not (rec.clip or rec.ease)
    if rec.first_person and not sync_ctx and not hide_1p_knife then
        CS2Audio.tick("knife", rec.clip and rec.clip.name or nil, rec.clip_t or 0)
    end
end

mod.flip = function()
    for ext in pairs(tracked) do
        if ext._player == sync_me() then
            CS2Arms.flip(ext)
            for _, rec in pairs(ext.__qiangiq_bowie_records or {}) do
                rec.manual = true
            end
        end
    end
end

local CS2_CFG = {
    data = mod:io_dofile("QIangIQsBowieKnife/scripts/mods/QIangIQsBowieKnife/QIangIQsBowieKnife_cs2arms_data"),
    field = "__qiangiq_bowie_cs2arms",
    knife_key = KNIFE_KEY,
    unit_path = unit_path,
    opt = function(key)
        return mod:get(key)
    end,
    loaded = function(key)
        return loaded[key] == true
    end,
    arm_units = Fingers.arm_units,
    fingers = Fingers,
    driver_key = DRIVER_KEY,
    finger_nodes = ANIMS.finger_nodes,
    on_clip = function(clip, t)
        CS2Audio.tick("viewmodel", clip, t)
    end,
    fp_nodes = mod:io_dofile("QIangIQsBowieKnife/scripts/mods/QIangIQsBowieKnife/QIangIQsBowieKnife_fp_nodes"),
    action = function(holder_unit)
        local ude = unit_ok(holder_unit) and ScriptUnit.has_extension(holder_unit, "unit_data_system")
        local wa = ude and read_comp(ude, "weapon_action")
        if not wa then
            return {}
        end
        return { name = wa.current_action_name, start_t = wa.start_t, time_scale = wa.time_scale, template = wa.template_name }
    end,
}
CS2Arms.setup(CS2_CFG)

local function fp_stop(ext)
    local data = ext.__qiangiq_bowie_fp
    if not data then
        return
    end
    ext.__qiangiq_bowie_fp = nil
    local world = ext.__qiangiq_bowie_world
    if world and unit_ok(data.fp_unit) then
        for i = 1, #data.arms do
            local arm_unit = data.arms[i]
            if unit_ok(arm_unit) then
                World.unlink_unit(world, arm_unit)
                World.link_unit(world, arm_unit, 1, data.fp_unit, 1, World.LINK_MODE_NODE_NAME)
            end
        end
    end
    if unit_ok(data.driver) then
        local unit_spawner = Managers.state and Managers.state.unit_spawner
        if unit_spawner then
            unit_spawner:mark_for_deletion(data.driver)
        end
    end
end

local function fp_start(ext)
    local unit = ext._unit
    local world = ext.__qiangiq_bowie_world
    local unit_spawner = Managers.state and Managers.state.unit_spawner
    local fpe = unit_ok(unit) and ScriptUnit.has_extension(unit, "first_person_system")
    if not (fpe and world and unit_spawner and fpe.is_in_first_person_mode and fpe:is_in_first_person_mode()) then
        return
    end
    local fp_unit = fpe:first_person_unit()
    if not unit_ok(fp_unit) then
        return
    end
    local arms = Fingers.arm_units(ext)
    if #arms == 0 then
        return
    end
    local driver = unit_spawner:spawn_unit(unit_path(DRIVER_KEY), Unit.world_pose(fp_unit, 1))
    if not driver then
        return
    end
    local ok, fpd = pcall(Fingers.driver, driver, fp_unit, ANIMS.finger_nodes)
    if not ok or not fpd then
        unit_spawner:mark_for_deletion(driver)
        return
    end
    World.link_unit(world, driver, 1, fp_unit, 1)
    local posed = pcall(Fingers.update, world, fpd, nil, 0)
    if not posed then
        unit_spawner:mark_for_deletion(driver)
        return
    end
    for i = 1, #arms do
        World.unlink_unit(world, arms[i])
        World.link_unit(world, arms[i], 1, driver, 1, World.LINK_MODE_NODE_NAME)
    end
    ext.__qiangiq_bowie_fp = { driver = driver, fpd = fpd, arms = arms, fp_unit = fp_unit, fpe = fpe }
end

local function fp_fingers(ext, rec)
    local data = ext.__qiangiq_bowie_fp
    local want = rec ~= nil and (rec.finger_weight or 0) > 0 and not sync_ctx and opt("fp_fingers") ~= false
        and loaded[DRIVER_KEY] == true
    if data and (not want or not unit_ok(data.driver) or not unit_ok(data.fp_unit) or not data.fpe:is_in_first_person_mode()) then
        fp_stop(ext)
        data = nil
    end
    if want and not data then
        fp_start(ext)
        data = ext.__qiangiq_bowie_fp
    end
    if rec then
        rec.fp_driver = data and data.driver or nil
    end
    if data then
        local lp = rec.last_pose
        local arm = nil
        if lp and lp.arm and opt("arm_motion") ~= 0 then
            arm = { frame = lp.arm, clip = rec.clip and rec.clip.name or rec.ease_clip_name or "ease",
                weight = (rec.finger_weight or 0) * (opt("arm_motion") or 1) }
        end
        local ok, err = pcall(Fingers.update, ext.__qiangiq_bowie_world, data.fpd, rec.finger_quats, rec.finger_weight, arm)
        if ok and lp and (rec.abs_weight or 0) > 0 then
            local hp, hr, hh = hand_landmark(rec, rec.last_holder)
            if hp then
                rec.lm_p, rec.lm_r, rec.lm_h = Vector3Box(hp), QuaternionBox(hr), hh
                apply_pose(rec, lp)
            end
        end
        if not ok then
            mod:error("Bowie Knife: first-person fingers stopped: %s", tostring(err))
            fp_stop(ext)
        end
    end
end

local function sync_record(records, key, base, attachments, item, visible, spawn_fn, destroy_fn, parent_scale, first_person, holder_unit)
    local rec = records[key]
    local want = unit_ok(base) and wants_item(item) and attachments ~= nil
    if rec and (not want or rec.base ~= base or not unit_ok(rec.sword)) then
        destroy_fn(rec.sword)
        records[key] = nil
        if rec.hid and rec.base == base and unit_ok(base) and visible then
            Unit.set_unit_visibility(base, true, true)
        end
        rec = nil
    end
    if not want then
        return false
    end
    if not rec then
        local knife = spawn_fn(base, unit_path(KNIFE_KEY))
        if not knife then
            return false
        end
        if first_person then
            Unit.set_shader_pass_flag_for_meshes_in_unit_and_childs(knife, "custom_fov", true)
        end
        rec = { sword = knife, base = base, frames = 0, count = -1, fitted = false, first_person = first_person }
        records[key] = rec
    end
    if rec.count ~= #attachments or rec.gen ~= fit_generation then
        rec.gen = fit_generation
        rec.count = #attachments
        rec.frames = 0
    end
    if rec.frames < FIT_FRAMES then
        rec.frames = rec.frames + 1
        local base_scale = Unit.local_scale(base, 1)
        local k = (parent_scale or 1) * (base_scale and base_scale.x or 1)
        fit_template = item and item.weapon_template
        local fitted = fit(rec.sword, base, attachments, k, key, first_person)
        fit_template = nil
        if fitted then
            rec.fitted = true
            rec.fit_pose = fit_pose
            rec.at_rest = false
        end
    end
    rec.shown = (rec.fitted and visible) and true or false
    if rec.fitted and visible then
        hide_originals(base, attachments)
        rec.hid = true
        Unit.set_unit_visibility(rec.sword, not (first_person and hide_1p_knife), true)
        animate(rec, holder_unit)
    else
        Unit.set_unit_visibility(rec.sword, false, true)
    end
    return true
end

local function clear_records(records, destroy_fn)
    if not records then
        return
    end
    for key, rec in pairs(records) do
        destroy_fn(rec.sword)
        records[key] = nil
    end
end

local function ingame_spawn(ext, is_first_person)
    return function(parent, path)
        local world = ext.__qiangiq_bowie_world
        local unit_spawner = Managers.state and Managers.state.unit_spawner
        if not (world and unit_spawner) then
            return nil
        end
        local unit = unit_spawner:spawn_unit(path, Unit.world_pose(parent, 1))
        if not unit then
            return nil
        end
        if is_first_person then
            Unit.set_unit_culling(unit, false)
        end
        World.link_unit(world, unit, 1, parent, 1, World.LINK_MODE_NODE_NAME)
        return unit
    end
end

local function ingame_destroy(unit)
    if unit_ok(unit) then
        local unit_spawner = Managers.state and Managers.state.unit_spawner
        if unit_spawner then
            unit_spawner:mark_for_deletion(unit)
        end
    end
end

local function ingame_apply(ext)
    local records = ext.__qiangiq_bowie_records
    if not records then
        records = {}
        ext.__qiangiq_bowie_records = records
    end
    local equipment = ext._equipment
    if not equipment then
        return
    end
    local fp_rec = nil
    hide_1p_knife = not sync_ctx and ext.__qiangiq_bowie_arms_vm == true
    for slot_name, slot in pairs(equipment) do
        local item = slot.item
        if item and TEMPLATES[item.weapon_template] or records[slot_name .. ":3p"] or records[slot_name .. ":1p"] then
            local base_3p, base_1p = slot.unit_3p, slot.unit_1p
            local att_3p = base_3p and slot.attachments_by_unit_3p and slot.attachments_by_unit_3p[base_3p]
            local att_1p = base_1p and slot.attachments_by_unit_1p and slot.attachments_by_unit_1p[base_1p]
            sync_record(records, slot_name .. ":3p", base_3p, att_3p, item, slot.hidden_3p == false,
                ingame_spawn(ext, false), ingame_destroy, 1, false, ext._unit)
            sync_record(records, slot_name .. ":1p", base_1p, att_1p, item, slot.hidden_1p == false,
                ingame_spawn(ext, true), ingame_destroy, 1, true, ext._unit)
            fp_rec = fp_rec or records[slot_name .. ":1p"]
        end
    end
    hide_1p_knife = false
    local arms_mode = not sync_ctx and CS2Arms.mode(fp_rec) or nil
    if not sync_ctx then
        ext.__qiangiq_bowie_arms_vm = arms_mode == "viewmodel"
    end
    fp_fingers(ext, arms_mode ~= "viewmodel" and fp_rec or nil)
    if not sync_ctx then
        local t = now()
        local dt = ext.__qiangiq_bowie_arms_t and math.min(0.1, math.max(0, t - ext.__qiangiq_bowie_arms_t)) or 0
        ext.__qiangiq_bowie_arms_t = t
        local fpd = ext.__qiangiq_bowie_fp
        local ok, err = pcall(CS2Arms.update, ext, fp_rec, arms_mode, ext.__qiangiq_bowie_world, dt, fpd and fpd.driver)
        if not ok then
            mod:error("Bowie Knife: CS2 arms stopped: %s", tostring(err))
            pcall(CS2Arms.stop, ext, ext.__qiangiq_bowie_world)
            mod:set("cs2_arms", "off", false)
        end
    end
end

-- ArmoryVis (optional): the stowed copy of the knife gets the same 3p replacement as the knife in hand
mod.armory_vis = {
    apply = function(holder, world, equipment)
        holder.__qiangiq_bowie_world = world
        local records = holder.__qiangiq_bowie_records
        if not records then
            records = {}
            holder.__qiangiq_bowie_records = records
        end
        for slot_name, slot in pairs(equipment) do
            local item = slot.item
            if item and TEMPLATES[item.weapon_template] or records[slot_name .. ":3p"] then
                local base = slot.unit_3p
                local att = base and slot.attachments_by_unit_3p and slot.attachments_by_unit_3p[base]
                sync_record(records, slot_name .. ":3p", base, att, item, slot.hidden_3p == false,
                    ingame_spawn(holder, false), ingame_destroy, 1, false, holder._unit)
            end
        end
    end,
    clear = function(holder)
        clear_records(holder.__qiangiq_bowie_records, ingame_destroy)
        holder.__qiangiq_bowie_records = nil
    end,
}

local function register_armory_vis()
    local av = get_mod("QIangIQsArmoryVis")
    if av and type(av.register) == "function" then
        pcall(av.register, mod:get_name(), mod.armory_vis)
    end
end

vl_hook_safe("init", function(self, extension_init_context)
    self.__qiangiq_bowie_world = extension_init_context and extension_init_context.world
end)

vl_hook_safe("_update_item_visibility", function(self)
    if not sync_shown(self) then
        return
    end
    tracked[self] = true
    ingame_apply(self)
end)

vl_hook_safe("update", function(self)
    if tracked[self] then
        ingame_apply(self)
    end
end)

vl_hook("_unequip_item_from_slot", function(func, self, slot_name, ...)
    local records = self.__qiangiq_bowie_records
    if records then
        for _, view in ipairs({ ":3p", ":1p" }) do
            local rec = records[slot_name .. view]
            if rec then
                ingame_destroy(rec.sword)
                records[slot_name .. view] = nil
            end
        end
    end
    return func(self, slot_name, ...)
end)

vl_hook("destroy", function(func, self, ...)
    fp_stop(self)
    pcall(CS2Arms.stop, self, self.__qiangiq_bowie_world)
    clear_records(self.__qiangiq_bowie_records, ingame_destroy)
    tracked[self] = nil
    return func(self, ...)
end)

local function local_player()
    local players = Managers.player
    if not players then
        return nil
    end
    local ok, player = pcall(players.local_player_safe, players, 1)
    return ok and player or nil
end

local function ui_profile_is_mine(profile)
    if not profile then
        return false
    end
    local players = Managers.player and Managers.player:players()
    local me = local_player()
    if players and profile.character_id then
        for _, player in pairs(players) do
            if player ~= me and player.character_id and player:character_id() == profile.character_id then
                return false
            end
        end
    end
    return true
end

local function ui_spawn(world)
    return function(parent, path)
        local unit = World.spawn_unit_ex(world, path, nil, Unit.world_pose(parent, 1))
        World.link_unit(world, unit, 1, parent, 1, World.LINK_MODE_NODE_NAME)
        return unit
    end
end

local function ui_destroy_fn(world)
    return function(unit)
        if unit_ok(unit) and world then
            World.destroy_unit(world, unit)
        end
    end
end

local function scale_x(unit)
    if unit_ok(unit) then
        local s = Unit.local_scale(unit, 1)
        return s and s.x or 1
    end
    return 1
end

local function profile_apply(spawner)
    local world = spawner._world
    local records = spawner.__qiangiq_bowie_records
    if not records then
        records = {}
        spawner.__qiangiq_bowie_records = records
    end
    local data = spawner._character_spawn_data
    local allowed = data and data.slots and opt("menu_previews") and ui_profile_is_mine(data.profile)
    if not allowed then
        clear_records(records, ui_destroy_fn(world))
        return
    end
    tracked_ui[spawner] = true
    local k = scale_x(data.unit_3p)
    for slot_name, slot in pairs(data.slots) do
        local item = slot.item
        if item and TEMPLATES[item.weapon_template] or records[slot_name] then
            local base = slot.unit_3p
            local att = base and slot.attachments_by_unit_3p and slot.attachments_by_unit_3p[base]
            sync_record(records, slot_name, base, att, item, spawner._visible and slot.hidden_3p ~= true, -- menu preview: the wielded slot has hidden_3p nil (log 2026-11-09)
                ui_spawn(world), ui_destroy_fn(world), k, false, nil)
        end
    end
end

mod:hook_safe(CLASS.UIProfileSpawner, "_update_items_visibility", function(self)
    profile_apply(self)
end)

mod:hook_safe(CLASS.UIProfileSpawner, "update", function(self)
    local data = self._character_spawn_data
    if data and data.is_ready then
        profile_apply(self)
    elseif self.__qiangiq_bowie_records then
        clear_records(self.__qiangiq_bowie_records, ui_destroy_fn(self._world))
    end
end)

mod:hook(CLASS.UIProfileSpawner, "_despawn_current_character_profile", function(func, self, ...)
    clear_records(self.__qiangiq_bowie_records, ui_destroy_fn(self._world))
    return func(self, ...)
end)

local function weapon_apply(spawner)
    local world = spawner._world
    local records = spawner.__qiangiq_bowie_records
    if not records then
        records = {}
        spawner.__qiangiq_bowie_records = records
    end
    local data = spawner._weapon_spawn_data
    if not (data and opt("menu_previews")) then
        if next(records) ~= nil then
            clear_records(records, ui_destroy_fn(world))
            if data and data.visible and unit_ok(data.item_unit_3p) then
                Unit.set_unit_visibility(data.item_unit_3p, true, true)
            end
        end
        return
    end
    tracked_wpn[spawner] = true
    local base = data.item_unit_3p
    local att = base and data.attachment_units_3p and data.attachment_units_3p[base]
    local k = scale_x(data.link_unit)
    sync_record(records, "weapon", base, att, data.item, data.visible and true or false,
        ui_spawn(world), ui_destroy_fn(world), k, false, nil)
end

mod:hook_safe(CLASS.UIWeaponSpawner, "update", function(self)
    weapon_apply(self)
end)

mod:hook(CLASS.UIWeaponSpawner, "_despawn_current_weapon", function(func, self, ...)
    clear_records(self.__qiangiq_bowie_records, ui_destroy_fn(self._world))
    return func(self, ...)
end)

mod:hook("HumanGameplay", "_player_orientation_class", function(func, self, ...)
    local orientation = func(self, ...)
    if orientation ~= nil and self._default_player_orientation
        and (orientation == self._weapon_lock_view_player_orientation or orientation == self._weapon_force_view_player_orientation)
        and mod:is_enabled() and mod:get("free_look_inspect") and not session_off then
        local unit = self._player_unit
        local ude = unit and Unit.alive(unit) and ScriptUnit.has_extension(unit, "unit_data_system")
        local wa = ude and read_comp(ude, "weapon_action")
        local name = wa and wa.current_action_name
        if (name == "action_inspect" or name == "action_inspect_3p") and TEMPLATES[wa.template_name] and mod:get(TEMPLATES[wa.template_name]) then
            return self._default_player_orientation
        end
    end
    return orientation
end)

local function refresh_all()
    for ext in pairs(tracked) do
        if unit_ok(ext._unit) then
            ingame_apply(ext)
            ext:force_update_item_visibility()
        end
    end
    for spawner in pairs(tracked_ui) do
        profile_apply(spawner)
        if spawner._character_spawn_data and spawner._visible then
            spawner:_update_items_visibility()
        end
    end
    for spawner in pairs(tracked_wpn) do
        weapon_apply(spawner)
    end
end

local function after_change()
    fit_generation = fit_generation + 1
    refresh_all()
end

mod.toggle_knife = function()
    session_off = not session_off
    refresh_all()
    mod:echo("Bowie Knife %s for this session", session_off and "off" or "on")
end

local OTHER_KNIFE_MODS = { "QIangIQsSkullRuneblade", "QIangIQsMeleeArsenal", "QIangIQsWarframeArsenal" }
local SWORD_MODS = { "QIangIQsDiamondSword", "QIangIQsGoldenBloodSword", "QIangIQsBismuthRelicBlade", "QIangIQsSkullRuneblade", "QIangIQsBismuthSword" }

local function swords_off()
    for _, name in ipairs(SWORD_MODS) do
        local other = get_mod(name)
        if other and other:get("replace_duelling_sword") then
            other:set("replace_duelling_sword", false, true)
        end
    end
end
local KNIFE_MODS = { "QIangIQsButterflyKnife", "QIangIQsKarambit", "QIangIQsBayonet", "QIangIQsStiletto", "QIangIQsBowieKnife" }

local function switch_others_off(setting)
    setting = setting or "replace_combat_knife"
    for _, name in ipairs(KNIFE_MODS) do
        if name ~= "QIangIQsBowieKnife" then
            local other = get_mod(name)
            local v = other and other:get(setting)
            if other and (setting == "replace_combat_knife" and v ~= false or v == true) then
                other:set(setting, false, true)
            end
        end
    end
end

local function resolve_at_load()
    for _, setting in ipairs({ "replace_combat_knife", "replace_duelling_sword" }) do
        local mine = false
        for _, name in ipairs(KNIFE_MODS) do
            if name == "QIangIQsBowieKnife" then
                mine = true
            elseif mine then
                local other = get_mod(name)
                local v, me = other and other:get(setting), mod:get(setting)
                local on = setting == "replace_combat_knife" and v ~= false or v == true
                local my_on = setting == "replace_combat_knife" and me ~= false or me == true
                if other and on and my_on then
                    mod:set(setting, false, false)
                end
            end
        end
    end
end

local function claim_knives(setting)
    for _, name in ipairs(OTHER_KNIFE_MODS) do
        local other = get_mod(name)
        if other and other.release_template then
            for template, key in pairs(TEMPLATES) do
                if setting == nil or key == setting then
                    pcall(other.release_template, template)
                end
            end
        end
    end
end

local claim_pending = true

mod.update = function()
    if claim_pending then
        claim_pending = false
        register_armory_vis()
        if mod:get("replace_combat_knife") ~= false then
            claim_knives("replace_combat_knife")
        end
        if mod:get("replace_duelling_sword") then
            claim_knives("replace_duelling_sword")
            swords_off()
        end
    end
end

mod.release_template = function(template)
    if claim_pending then
        return
    end
    local setting = TEMPLATES[template]
    if setting and mod:get(setting) then
        mod:set(setting, false, false)
        after_change()
        mod:echo("%s is now shown by another QIangIQ mod: switched off in Bowie Knife.", setting == "replace_duelling_sword" and "The Duelling Sword" or "The Combat Knife")
    end
end

mod:command("bowie", "Bowie Knife: /bowie (toggle), /bowie flip, /bowie debug", function(which)
    if which == "debug" then
        for ext in pairs(tracked) do
            if ext._player == sync_me() then
                mod:echo(CS2Arms.debug(ext))
            end
        end
        local any = false
        for _, line in pairs(last_fit) do
            mod:echo(line)
            any = true
        end
        for ext in pairs(tracked) do
            for key, rec in pairs(ext.__qiangiq_bowie_records or {}) do
                local n = 0
                for _ in pairs(rec.bones or {}) do
                    n = n + 1
                end
                mod:echo("%s: %d flip bones, action %s, clip %s at %.2f s", key, n, tostring(holder_action(ext._unit)), rec.clip and rec.clip.name or "none", rec.clip_t or 0)
                any = true
            end
        end
        if not any then
            mod:echo("Nothing fitted yet: wield a Combat Knife with the replacement switched on.")
        end
        return
    end
    if which == "flip" then
        mod.flip()
        return
    end
    mod.toggle_knife()
end)

mod.on_setting_changed = function(setting_id)
    if setting_id == "replace_combat_knife" and mod:get("replace_combat_knife") then
        claim_knives("replace_combat_knife")
        switch_others_off()
    end
    if setting_id == "replace_duelling_sword" and mod:get("replace_duelling_sword") then
        claim_knives("replace_duelling_sword")
        swords_off()
        switch_others_off("replace_duelling_sword")
    end
    after_change()
end

mod.on_all_mods_loaded = function()
    resolve_at_load()
    custom_assets = get_mod("CustomAssets")
    if not custom_assets or not custom_assets.is_api_compatible or not custom_assets.is_api_compatible(1) then
        mod:error("Custom Assets (API 1) is missing. Install it and put it above QIangIQsBowieKnife in mod_load_order.txt.")
        return
    end
    for _, key in ipairs({ KNIFE_KEY, TP_KEY, DRIVER_KEY, CS2Arms.ASSETS[1], CS2Arms.ASSETS[2] }) do
        local id = asset_id(key)
        local ticket, err = custom_assets.acquire(mod, id, function(_, _, load_error)
            if load_error then
                mod:error("%s failed to load: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", id, tostring(load_error))
                return
            end
            loaded[key] = true
            refresh_all()
        end, { resident = true, reference_name = id })
        if not ticket then
            mod:error("%s could not be requested: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", id, tostring(err))
        end
    end
end

local function remove_all()
    for ext in pairs(tracked) do
        fp_stop(ext)
        pcall(CS2Arms.stop, ext, ext.__qiangiq_bowie_world)
        clear_records(ext.__qiangiq_bowie_records, ingame_destroy)
    end
    for spawner in pairs(tracked_ui) do
        clear_records(spawner.__qiangiq_bowie_records, ui_destroy_fn(spawner._world))
    end
    for spawner in pairs(tracked_wpn) do
        clear_records(spawner.__qiangiq_bowie_records, ui_destroy_fn(spawner._world))
    end
end

mod.on_disabled = function()
    remove_all()
    for ext in pairs(tracked) do
        if unit_ok(ext._unit) then
            ext:force_update_item_visibility()
        end
    end
    for spawner in pairs(tracked_ui) do
        if spawner._character_spawn_data and spawner._visible then
            spawner:_update_items_visibility()
        end
    end
    for spawner in pairs(tracked_wpn) do
        local data = spawner._weapon_spawn_data
        if data and data.visible and unit_ok(data.item_unit_3p) then
            Unit.set_unit_visibility(data.item_unit_3p, true, true)
        end
    end
end

mod.on_enabled = function()
    refresh_all()
end

mod.on_unload = function()
    remove_all()
    if custom_assets and custom_assets.release_owner then
        custom_assets.release_owner(mod)
    end
end

local sync_enabled = true
local function sync_changed()
    local api = sync_api()
    if api then
        api.changed()
    end
end

mod.sync_key = SYNC_KEY
mod.sync_export = function(info)
    info = info or {}
    if not sync_enabled or session_off or not (mod:get("replace_combat_knife") or mod:get("replace_duelling_sword")) then
        return nil
    end
    if info.templates ~= nil then
        local any = false
        for template in pairs(TEMPLATES) do
            any = any or (info.templates[template] and true or false)
        end
        if not any then
            return nil
        end
    end
    local mask, bit = 0, 1
    for i = 1, #SYNC_BOOLS do
        local key = SYNC_BOOLS[i]
        local v = mod:get(key)
        if v == nil then
            v = SYNC_DEFAULTS[key]
        end
        if v then
            mask = mask + bit
        end
        bit = bit * 2
    end
    local out = { SYNC_LAYOUT, mask }
    for i = 1, #SYNC_VALUES do
        local v = mod:get(SYNC_VALUES[i])
        if type(v) == "number" then
            v = math.floor(v * 100 + 0.5) / 100
        elseif type(v) ~= "string" then
            v = false
        end
        out[2 + i] = v
    end
    return out
end

mod.sync_refresh = function()
    for ext in pairs(sync_all) do
        if ext._unit and Unit.alive(ext._unit) and ext.force_update_item_visibility then
            pcall(ext.force_update_item_visibility, ext)
        end
    end
end

local sync_prev_setting_changed = mod.on_setting_changed
mod.on_setting_changed = function(...)
    if sync_prev_setting_changed then
        sync_prev_setting_changed(...)
    end
    sync_changed()
end

local sync_prev_disabled = mod.on_disabled
mod.on_disabled = function(...)
    sync_enabled = false
    if sync_prev_disabled then
        sync_prev_disabled(...)
    end
    sync_changed()
end

local sync_prev_enabled = mod.on_enabled
mod.on_enabled = function(...)
    sync_enabled = true
    if sync_prev_enabled then
        sync_prev_enabled(...)
    end
    sync_changed()
end

-- CS2 moves in third person (QIangIQsBowieKnife_tp.lua): Custom/bw_tp_driver, the CS2 clips baked on the player 3p skeleton
local Tp = mod:io_dofile("QIangIQsBowieKnife/scripts/mods/QIangIQsBowieKnife/QIangIQsBowieKnife_tp")
local tp_templates = {}
for template in pairs(TEMPLATES) do
    tp_templates[template] = true
end
Tp.setup({
    spans = mod:io_dofile("QIangIQsBowieKnife/scripts/mods/QIangIQsBowieKnife/QIangIQsBowieKnife_tp_spans"),
    templates = tp_templates,
    tp_driver_path = function()
        return loaded[TP_KEY] and unit_path(TP_KEY) or nil
    end,
    enabled = function()
        return mod_on and not session_off and mod:get("cs2_3p") ~= false
    end,
    opt = function(key, default)
        local v = mod:get(key)
        if v == nil then
            return default
        end
        return tonumber(v) or v
    end,
    -- the CS2 weapon is shown on this unit (this mod's own 3p record; other players need the mod and model sync)
    shown = function(unit)
        local ext = unit_ok(unit) and ScriptUnit.has_extension(unit, "visual_loadout_system")
        local records = ext and ext.__qiangiq_bowie_records
        for key, rec in pairs(records or {}) do
            if type(key) == "string" and key:find(":3p$") and rec.shown then
                return true
            end
        end
        return false
    end,
    local_action = function(unit)
        local player = local_player()
        if player and player.player_unit == unit then
            local ok, info = pcall(CS2_CFG.action, unit)
            return ok and info or nil
        end
        return nil
    end,
    -- Duelling Sword heavies = CS2 light_backstab (user rule 2026-11-08); knife heavies follow cs2_heavy_light_swings
    heavy_clip = function(template_name)
        if template_name and template_name:find("^combatsword_p3") then
            return "light_backstab"
        end
        if mod:get("cs2_heavy_light_swings") ~= false then
            return "light_miss1"
        end
        return "heavy_miss1"
    end,
})

for _, class_name in ipairs({ "PlayerUnitAnimationExtension", "AuthoritativePlayerUnitAnimationExtension", "PlayerHuskAnimationExtension" }) do
    local class = CLASS[class_name]
    if class then
        mod:hook_safe(class, "inventory_slot_wielded", function(self, weapon_template)
            pcall(Tp.wielded, self._unit, weapon_template and weapon_template.name or nil)
        end)
        if class_name ~= "PlayerHuskAnimationExtension" then
            for _, method in ipairs({ "anim_event", "anim_event_with_variable_float", "anim_event_with_variable_floats",
                "anim_event_with_variable_int" }) do
                if class[method] then
                    mod:hook(class, method, function(func, self, event_name, ...)
                        local a, b = Tp.learn(func, self._unit, event_name, self, event_name, ...)
                        local ok, err = pcall(Tp.on_event, self._unit, event_name)
                        if not ok then
                            mod:error("third person: %s", tostring(err))
                        end
                        return a, b
                    end)
                end
            end
        end
    end
end

if CLASS.AnimationSystem then
    for _, rpc in ipairs({ "rpc_player_anim_event", "rpc_player_anim_event_variable_float", "rpc_player_anim_event_variable_floats",
        "rpc_player_anim_event_variable_int" }) do
        if CLASS.AnimationSystem[rpc] then
            mod:hook_safe(CLASS.AnimationSystem, rpc, function(self, channel_id, unit_id, event_index, ...)
                local is_first_person = select(select("#", ...), ...)
                if is_first_person then
                    return
                end
                local ok, err = pcall(function()
                    local unit = Managers.state.unit_spawner:unit(unit_id)
                    if unit then
                        Tp.on_husk_event(unit, event_index)
                    end
                end)
                if not ok then
                    mod:error("third person (other player): %s", tostring(err))
                end
            end)
        end
    end
end

local tp_prev_update = mod.update
mod.update = function(...)
    local ok, err = pcall(Tp.update)
    if not ok then
        mod:error("third person update: %s", tostring(err))
        pcall(Tp.stop_all)
    end
    if tp_prev_update then
        return tp_prev_update(...)
    end
end

local tp_prev_disabled = mod.on_disabled
mod.on_disabled = function(...)
    pcall(Tp.stop_all)
    if tp_prev_disabled then
        return tp_prev_disabled(...)
    end
end

local tp_prev_unload = mod.on_unload
mod.on_unload = function(...)
    pcall(Tp.stop_all)
    if tp_prev_unload then
        return tp_prev_unload(...)
    end
end

mod:command("bowie3p", "CS2 moves in third person: state", function()
    mod:echo(Tp.debug())
end)

-- Inspects never lock the camera (user request 2026-11-08 22:11): the free-look setting is switched on once for everyone.
if not mod:get("free_look_v2") then
    mod:set("free_look_inspect", true, false)
    mod:set("free_look_v2", true, false)
end

-- Heavies play this knife's own CS2 heavy attack (user request 2026-11-08 22:15, e.g. the Bowie's underhand stab);
-- the "heavies as light swings" option (a Butterfly request) is switched off once here.
if not mod:get("own_heavy_v1") then
    mod:set("cs2_heavy_light_swings", false, false)
    mod:set("own_heavy_v1", true, false)
end

-- 3p: the CS2 weapon held the CS2 way during third-person CS2 moves (see QIangIQsBowieKnife_tp.lua apply_grip)
Tp.set_grip(mod:io_dofile("QIangIQsBowieKnife/scripts/mods/QIangIQsBowieKnife/QIangIQsBowieKnife_tp_grip"), function(unit)
    local ext = unit_ok(unit) and ScriptUnit.has_extension(unit, "visual_loadout_system")
    for key, rec in pairs(ext and ext.__qiangiq_bowie_records or {}) do
        if type(key) == "string" and key:find(":3p$") and rec.shown and unit_ok(rec.sword) then
            return rec.sword, rec.base, rec
        end
    end
    return nil
end)

-- Darktide-style bottom-right HUD icon (user 2026-11-09: "schematic/blueprint/lineart style of Darktide for CS2 weapons").
-- cs2_weapons\icons\render_icons.py draws the CS2 model as white line art + grey fill + glow (512x192, like the retail
-- hud icons); build_and_patch.py compiles it into Custom/hud_icon (one quad; loading it makes the texture resident).
-- hud_element_player_weapon.lua:73-80 puts item.hud_icon in widget.content.icon; here ui_default_base with
-- material_values.texture_map = the icon (Datavault technique-weapon-hud-icon-custom-texture, QIangIQsDauntlessMaul).
-- Without Custom Assets or before the patcher has run, the game's icon stays.
local HUD_ICON_ID = asset_id("hud_icon")
local HUD_ICON_MATERIAL = "content/ui/materials/base/ui_default_base"
local HUD_ICON_TEXTURE = "content/mods/qiangiq_bowie/hud_icon_material_0_bca"
local hud_icon_ready = false
local hud_icon_prev_all_loaded = mod.on_all_mods_loaded
mod.on_all_mods_loaded = function(...)
    if hud_icon_prev_all_loaded then
        hud_icon_prev_all_loaded(...)
    end
    local ca = get_mod("CustomAssets")
    if not (ca and ca.acquire) then
        return
    end
    local ok, ticket = pcall(ca.acquire, mod, HUD_ICON_ID, function(_, _, load_error)
        if load_error then
            mod:info("HUD icon %s not loaded: %s", HUD_ICON_ID, tostring(load_error))
            return
        end
        hud_icon_ready = true
        mod:info("HUD icon %s loaded", HUD_ICON_ID)
    end, { resident = true, reference_name = HUD_ICON_ID })
    if not (ok and ticket) then
        mod:info("HUD icon %s could not be requested (Custom Assets patcher not run yet?)", HUD_ICON_ID)
    end
end

-- the handler recreates the element when the slot's weapon changes (hud_element_player_weapon_handler.lua:83-120)
mod:hook_safe(CLASS.HudElementPlayerWeapon, "init", function(self, parent, draw_layer, start_scale, data)
    self.__qiangiq_qiangiq_bowie_hud_item = data and data.item
end)

mod:hook_safe(CLASS.HudElementPlayerWeapon, "update", function(self)
    local item = self.__qiangiq_qiangiq_bowie_hud_item
    local widget = item and hud_icon_ready and self._widgets_by_name and self._widgets_by_name.icon
    if not widget then
        return
    end
    local ok, want = pcall(wants_item, item)
    if not (ok and want) then
        return
    end
    local style = widget.style.icon
    style.material_values = style.material_values or {}
    if widget.content.icon ~= HUD_ICON_MATERIAL or style.material_values.texture_map ~= HUD_ICON_TEXTURE then
        widget.content.icon = HUD_ICON_MATERIAL
        style.material_values.texture_map = HUD_ICON_TEXTURE
        widget.dirty = true
    end
end)
