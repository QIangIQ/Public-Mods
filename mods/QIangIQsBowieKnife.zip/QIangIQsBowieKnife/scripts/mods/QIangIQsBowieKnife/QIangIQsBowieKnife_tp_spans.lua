-- seconds of each CS2 clip in Custom/bw_tp_driver (tp_bake_cs2.py, 372 frames at 30 fps)
return {
    draw = { start = 0.0000, length = 1.1000 },
    light_miss1 = { start = 1.2000, length = 1.1333 },
    light_miss2 = { start = 2.4333, length = 1.1333 },
    heavy_miss1 = { start = 3.6667, length = 1.1333 },
    light_backstab = { start = 4.9000, length = 1.1333 },
    lookat01 = { start = 6.1333, length = 6.1667 },
}
