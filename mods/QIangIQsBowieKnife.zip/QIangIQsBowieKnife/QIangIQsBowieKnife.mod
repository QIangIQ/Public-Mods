return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsBowieKnife` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsBowieKnife", {
            mod_script = "QIangIQsBowieKnife/scripts/mods/QIangIQsBowieKnife/QIangIQsBowieKnife",
            mod_data = "QIangIQsBowieKnife/scripts/mods/QIangIQsBowieKnife/QIangIQsBowieKnife_data",
            mod_localization = "QIangIQsBowieKnife/scripts/mods/QIangIQsBowieKnife/QIangIQsBowieKnife_localization",
        })
    end,
    version = "1.1.11",
    author = "QIangIQ",
    load_after = { "CustomAssets" },
    packages = {},
}
