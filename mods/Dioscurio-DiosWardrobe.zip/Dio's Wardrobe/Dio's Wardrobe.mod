return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`DiosWardrobe` encountered an error loading the Darktide Mod Framework.")

		new_mod("DiosWardrobe", {
			mod_script       = "Dio's Wardrobe/scripts/mods/DiosWardrobe/DiosWardrobe",
			mod_data         = "Dio's Wardrobe/scripts/mods/DiosWardrobe/DiosWardrobe_data",
			mod_localization = "Dio's Wardrobe/scripts/mods/DiosWardrobe/DiosWardrobe_localization",
		})
	end,
	version = "1.0.1",
	packages = {},
}
