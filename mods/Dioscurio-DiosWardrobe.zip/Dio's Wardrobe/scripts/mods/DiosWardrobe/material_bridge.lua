local mod = get_mod("DiosWardrobe")

--[[
  MATERIAL BRIDGE

  Up to Darktide 1.10 the game applied every name listed in an item's
  `material_overrides` (looked up in ItemMaterialOverrides) when it spawned the item and
  each attachment. Patch 1.11.0 removed that: the game now only applies
  `material_override_items`, which are master item names. Dio's Wardrobe still writes its
  colours, patterns, materials and decals as `material_overrides`, so since 1.11.0 none of
  them reach the character.

  This bridges the two:

    1. After make_custom_item builds an item, every `material_overrides` list in it (the
       item and each attachment) is mirrored into `material_override_items` as
       "wd_mo:<name>" entries, appended after the item's own entries so they win.
    2. VisualLoadoutCustomization.apply_material_override_item is hooked. An "wd_mo:"
       entry is applied the way 1.10 applied a material override; anything else goes to
       the game untouched.
    3. ItemPackage._add_item_dependencies is hooked so an "wd_mo:" entry contributes its
       textures to package loading instead of logging "Unable to find item".

  Runtime materials (the per-slot ones make_custom_item generates, e.g.
  "slot_gear_upperbody_material") share one global name for everyone. Items for other
  players can finish spawning later, when their attachments stream in, so each such
  material is copied under a per-owner name at bridge time. The value applied is then the
  one that existed when that owner's item was built.
--]]

local VisualLoadoutCustomization = require("scripts/extension_systems/visual_loadout/utilities/visual_loadout_customization")
local ItemPackage = require("scripts/foundation/managers/package/utilities/item_package")

local ItemMaterialOverrides = mod.ItemMaterialOverrides
local PREFIX = "wd_mo:"
local PREFIX_LEN = #PREFIX

-- names that came from the vendored library; everything else is generated at runtime
local library_names = {}
for name in pairs(ItemMaterialOverrides) do
  library_names[name] = true
end
mod.material_library_names = library_names

---------------------------------------------------------------------------
-- RESOURCE PINS
--
-- Every package (texture or item dependency) that Dio's Wardrobe puts on a character is
-- loaded under Dio's Wardrobe's own reference and never released. Without this a texture
-- that happened to be loaded by someone else (a mission package, another player's item)
-- was applied on a borrowed reference; when that owner released it on leaving a mission
-- the engine was asked to unload a texture still on a character, and asserted
-- "Trying to unload resource ... that's used elsewhere by the engine".
-- The textures involved are small colour and pattern maps, so holding them is cheap.
---------------------------------------------------------------------------

local Pin = { state = {}, waiters = {} }

local function is_known_package(name)
  return type(name) == "string" and name ~= "" and Application.can_get_resource("package", name)
end
mod.wd_is_known_package = function(self, name)
  return is_known_package(name)
end

mod.wd_is_pinned = function(self, name)
  return Pin.state[name] == "loaded"
end

-- Takes a permanent reference on a package. cb runs once it is loaded (at once if it
-- already is). Unknown names are refused rather than handed to the engine.
mod.wd_pin = function(self, name, cb)
  if not is_known_package(name) then
    return false
  end

  local state = Pin.state[name]

  if state == "loaded" then
    if cb then cb() end
    return true
  end

  if cb then
    Pin.waiters[name] = Pin.waiters[name] or {}
    table.insert(Pin.waiters[name], cb)
  end

  if state == "loading" then
    return true
  end

  Pin.state[name] = "loading"
  Managers.package:load(name, "dios_wardrobe_pin", function()
    Pin.state[name] = "loaded"
    local waiting = Pin.waiters[name]
    Pin.waiters[name] = nil
    for _, w in ipairs(waiting or {}) do
      local ok, err = pcall(w)
      if not ok then
        mod:error("Pin callback failed: %s", tostring(err))
      end
    end
  end, true)

  return true
end

-- cb runs once every name in the set is pinned and loaded.
mod.wd_pin_all = function(self, names, cb)
  local pending = 0
  local fired = false

  local function done()
    pending = pending - 1
    if pending <= 0 and not fired then
      fired = true
      if cb then cb() end
    end
  end

  for name in pairs(names) do
    if is_known_package(name) and not mod:wd_is_pinned(name) then
      pending = pending + 1
    end
  end

  if pending == 0 then
    fired = true
    if cb then cb() end
    return
  end

  for name in pairs(names) do
    if is_known_package(name) and not mod:wd_is_pinned(name) then
      mod:wd_pin(name, done)
    end
  end
end

local function is_bridged(entry)
  return type(entry) == "string" and entry:sub(1, PREFIX_LEN) == PREFIX
end

-- Apply one old-style material override, exactly as 1.10's _apply_material_override did
-- for the non-editor case.
local function apply_old_override(unit, data)
  if not unit or not Unit.alive(unit) or not data then
    return
  end

  if data.property_overrides then
    for property_name, value in pairs(data.property_overrides) do
      if type(value) == "number" then
        Unit.set_scalar_for_materials(unit, property_name, value, true)
      elseif type(value) == "table" then
        local n = #value
        if n == 1 then
          Unit.set_scalar_for_materials(unit, property_name, value[1], true)
        elseif n == 2 then
          Unit.set_vector2_for_materials(unit, property_name, Vector2(value[1], value[2]), true)
        elseif n == 3 then
          Unit.set_vector3_for_materials(unit, property_name, Vector3(value[1], value[2], value[3]), true)
        elseif n == 4 then
          Unit.set_vector4_for_materials(unit, property_name, Color(value[1], value[2], value[3], value[4]), true)
        end
      end
    end
  end

  if data.texture_overrides then
    for texture_slot, texture_data in pairs(data.texture_overrides) do
      local resource = type(texture_data) == "table" and texture_data.resource

      -- Only textures that are loaded right now; the pin keeps them loaded from here on.
      -- A texture name from another player's outfit is untrusted input, so an unknown or
      -- unloaded one is skipped instead of handed to the engine.
      if type(resource) == "string" and resource ~= "" and Application.can_get_resource("texture", resource) then
        mod:wd_pin(resource)

        if texture_data.material_slot then
          Unit.set_texture_for_material(unit, texture_data.material_slot, texture_slot, resource)
        else
          Unit.set_texture_for_materials(unit, texture_slot, resource, true)
        end
      end
    end
  end
end

mod:hook(VisualLoadoutCustomization, "apply_material_override_item", function(func, unit, parent_unit, apply_to_parent, material_override_item, ...)
  if is_bridged(material_override_item) then
    local data = ItemMaterialOverrides[material_override_item:sub(PREFIX_LEN + 1)]

    if data then
      local ok, err = pcall(apply_old_override, apply_to_parent and parent_unit or unit, data)

      if not ok then
        mod:error("Could not apply material %s: %s", material_override_item, tostring(err))
      end
    end

    return
  end

  return func(unit, parent_unit, apply_to_parent, material_override_item, ...)
end)

mod:hook(ItemPackage, "_add_item_dependencies", function(func, item_name, items_dictionary, result)
  if is_bridged(item_name) then
    local data = ItemMaterialOverrides[item_name:sub(PREFIX_LEN + 1)]

    if data then
      if not data.resource_dependencies then
        data.resource_dependencies = {}
        ItemPackage.compile_resource_dependencies(data, data.resource_dependencies)
      end

      for resource_name in pairs(data.resource_dependencies) do
        -- never hand a loader a name that is not a real package
        if is_known_package(resource_name) then
          result[resource_name] = true
        end
      end
    end

    return
  end

  return func(item_name, items_dictionary, result)
end)

-- Rebuilds `material_override_items` on one table (an item, or an attachment slot entry):
-- the game's own entries first, then one bridged entry per `material_overrides` name.
local function bridge_table(t, owner_tag)
  if type(t) ~= "table" then
    return
  end

  local names = rawget(t, "material_overrides") or t.material_overrides
  local existing = rawget(t, "material_override_items") or t.material_override_items

  local items = {}

  if type(existing) == "table" then
    for _, entry in pairs(existing) do
      if not is_bridged(entry) then
        items[#items + 1] = entry
      end
    end
  end

  if type(names) == "table" then
    for _, name in ipairs(names) do
      if type(name) == "string" and name ~= "" and ItemMaterialOverrides[name] then
        local use_name = name

        if not library_names[name] then
          use_name = name .. "@" .. owner_tag
          ItemMaterialOverrides[use_name] = table.clone(ItemMaterialOverrides[name])
          ItemMaterialOverrides[use_name].resource_dependencies = nil
        end

        items[#items + 1] = PREFIX .. use_name
      end
    end
  end

  rawset(t, "material_override_items", items)
end

local function bridge_attachments(attachments, owner_tag, depth)
  if type(attachments) ~= "table" or depth > 8 then
    return
  end

  for _, attach_data in pairs(attachments) do
    if type(attach_data) == "table" then
      bridge_table(attach_data, owner_tag)

      if type(attach_data.item) == "table" then
        bridge_table(attach_data.item, owner_tag)
        bridge_attachments(attach_data.item.attachments, owner_tag, depth + 1)
      end

      bridge_attachments(attach_data.children, owner_tag, depth + 1)
    end
  end
end

-- owner_tag: "me" for the local player, a short account id for other players
mod.bridge_item_materials = function(self, item, owner_tag)
  if type(item) ~= "table" then
    return item
  end

  owner_tag = owner_tag or "me"

  bridge_table(item, owner_tag)
  bridge_attachments(rawget(item, "attachments") or item.attachments, owner_tag, 0)

  return item
end

-- Every item make_custom_item produces goes through the bridge. make_custom_item calls
-- itself for the head gear and hair, which is fine: bridging is idempotent.
local original_make_custom_item = mod.make_custom_item

mod.make_custom_item = function(self, slot_name, source_item, source)
  local item = original_make_custom_item(self, slot_name, source_item, source)

  if item then
    local ok, err = pcall(mod.bridge_item_materials, mod, item, mod:ctx_owner_tag())

    if not ok then
      mod:error("Material bridge failed for %s: %s", tostring(slot_name), tostring(err))
    end
  end

  return item
end
