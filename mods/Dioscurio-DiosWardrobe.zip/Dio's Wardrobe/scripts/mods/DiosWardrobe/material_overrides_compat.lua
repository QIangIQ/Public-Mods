local mod = get_mod("DiosWardrobe")

--[[
  Darktide 1.12.0 deleted scripts/settings/equipment/item_material_overrides/.
  The game now reads material overrides from master items instead, but this mod
  uses those tables as its colour / pattern / material / decal library, and the
  require() of the missing file threw on load, so DMF never registered the mod.

  The last shipped copies (1.11.x) are vendored in ./material_overrides and merged
  here exactly the way the game's item_material_overrides.lua used to, into ONE
  shared table that every file of the mod uses.
--]]

local ItemPackage = require("scripts/foundation/managers/package/utilities/item_package")

local GAME_DIR = "scripts/settings/equipment/item_material_overrides/"
local MOD_DIR = "Dio's Wardrobe/scripts/mods/DiosWardrobe/material_overrides/"

local FILES = {
  "item_material_overrides_ammo",
  "item_material_overrides_gear_colors",
  "item_material_overrides_gear_materials",
  "item_material_overrides_gear_patterns",
  "minion_material_overrides_decals",
  "minion_material_overrides_faces",
  "minion_material_overrides_gear",
  "player_material_overrides_base_body_mask",
  "player_material_overrides_emissive",
  "player_material_overrides_eye_colors",
  "player_material_overrides_face_mask",
  "player_material_overrides_gear_decals",
  "player_material_overrides_hair_colors",
  "player_material_overrides_hair_headgear_mask",
  "player_material_overrides_makeup",
  "player_material_overrides_pattern_properties",
  "player_material_overrides_skin_colors",
  "player_material_overrides_tattoos",
  "player_material_overrides_wrap_deform",
  "player_material_overrides_dog_coat_masks",
  "player_material_overrides_dog_fur_color",
  "player_material_overrides_dog_gear_patterns",
  "player_material_overrides_dog_skin_colors",
}

local merged = {}
local by_game_path = {}

for _, name in ipairs(FILES) do
  local definition = mod:io_dofile(MOD_DIR .. name)

  if type(definition) == "table" then
    by_game_path[GAME_DIR .. name] = definition

    for override_name, entry_data in pairs(definition) do
      entry_data.name = override_name
      entry_data.resource_dependencies = {}
      ItemPackage.compile_resource_dependencies(entry_data, entry_data.resource_dependencies)
      merged[override_name] = entry_data
    end
  else
    mod:error("Missing material data file: %s", name)
  end
end

mod.ItemMaterialOverrides = merged
mod.material_override_files = by_game_path

-- Stand-in for mod:hook_require() on the deleted files. The callbacks only ever read
-- the instance, so running them once against the vendored table is equivalent.
mod.hook_material_override_file = function(self, path, callback)
  local instance = by_game_path[path]

  if instance then
    callback(instance)
  else
    mod:error("No vendored material data for %s", path)
  end
end
