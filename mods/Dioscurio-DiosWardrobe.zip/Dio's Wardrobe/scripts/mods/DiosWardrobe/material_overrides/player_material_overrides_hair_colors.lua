-- chunkname: @scripts/settings/equipment/item_material_overrides/player_material_overrides_hair_colors.lua

local material_overrides = {
	use_uv2_gradient_mask = {
		property_overrides = {
			use_uv2_gradient = {
				1,
			},
		},
	},
	hair_color_bardin = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_color_bardin",
			},
		},
		property_overrides = {
			hair_scatter = {
				0.04,
			},
			hair_rgb = {
				0.6,
				0.34,
				0.02,
			},
		},
	},
	hair_color_sienna = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_color_sienna",
			},
		},
		property_overrides = {
			hair_scatter = {
				0.04,
			},
			hair_rgb = {
				0.6,
				0.24,
				0.02,
			},
		},
	},
	hair_color_kerilian = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_color_kerilian",
			},
		},
		property_overrides = {
			hair_scatter = {
				0.04,
			},
			hair_rgb = {
				0.8,
				0.8,
				0.75,
			},
		},
	},
	hair_black_01 = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_color_black_01",
			},
		},
		property_overrides = {
			hair_scatter = {
				0,
			},
			hair_rgb = {
				0.08,
				0.08,
				0.08,
			},
		},
	},
	hair_black_02 = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_color_black_02",
			},
		},
		property_overrides = {
			hair_scatter = {
				0,
			},
			hair_rgb = {
				0.03,
				0.03,
				0.03,
			},
		},
	},
	hair_blonde_01 = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_color_blonde_01",
			},
		},
		property_overrides = {
			hair_scatter = {
				0.13,
			},
			hair_rgb = {
				0.65,
				0.53,
				0.28,
			},
		},
	},
	hair_blonde_02 = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_color_blonde_02",
			},
		},
		property_overrides = {
			hair_scatter = {
				0.11,
			},
			hair_rgb = {
				0.65,
				0.5,
				0.35,
			},
		},
	},
	hair_blonde_03 = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_color_blonde_03",
			},
		},
		property_overrides = {
			hair_scatter = {
				0.11,
			},
			hair_rgb = {
				0.6,
				0.52,
				0.4,
			},
		},
	},
	hair_blonde_04 = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_color_blonde_03",
			},
		},
		property_overrides = {
			hair_scatter = {
				0.11,
			},
			hair_rgb = {
				0.6,
				0.52,
				0.4,
			},
		},
	},
	hair_brown_01 = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_color_brown_01",
			},
		},
		property_overrides = {
			hair_scatter = {
				0.02,
			},
			hair_rgb = {
				0.16,
				0.12,
				0.1,
			},
		},
	},
	hair_brown_02 = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_color_brown_02",
			},
		},
		property_overrides = {
			hair_scatter = {
				0.02,
			},
			hair_rgb = {
				0.18,
				0.14,
				0.1,
			},
		},
	},
	hair_brown_03 = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_color_brown_03",
			},
		},
		property_overrides = {
			hair_scatter = {
				0.02,
			},
			hair_rgb = {
				0.16,
				0.13,
				0.08,
			},
		},
	},
	hair_brown_04 = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_color_brown_04",
			},
		},
		property_overrides = {
			hair_scatter = {
				0.02,
			},
			hair_rgb = {
				0.16,
				0.12,
				0.1,
			},
		},
	},
	hair_red_01 = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_color_red_01",
			},
		},
		property_overrides = {
			hair_scatter = {
				0.04,
			},
			hair_rgb = {
				0.4,
				0.25,
				0.05,
			},
		},
	},
	hair_red_02 = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_color_red_02",
			},
		},
		property_overrides = {
			hair_scatter = {
				0.04,
			},
			hair_rgb = {
				0.36,
				0.14,
				0.08,
			},
		},
	},
	hair_red_03 = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_color_red_03",
			},
		},
		property_overrides = {
			hair_scatter = {
				0.04,
			},
			hair_rgb = {
				0.4,
				0.14,
				0.08,
			},
		},
	},
	hair_red_04 = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_color_red_04",
			},
		},
		property_overrides = {
			hair_scatter = {
				0.04,
			},
			hair_rgb = {
				0.4,
				0.14,
				0.08,
			},
		},
	},
	hair_gray_01 = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_color_gray_01",
			},
		},
		property_overrides = {
			hair_scatter = {
				0.14,
			},
			hair_rgb = {
				0.55,
				0.55,
				0.55,
			},
		},
	},
	hair_gray_02 = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_color_gray_02",
			},
		},
		property_overrides = {
			hair_scatter = {
				0.12,
			},
			hair_rgb = {
				0.47,
				0.45,
				0.44,
			},
		},
	},
	hair_gray_03 = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_color_gray_03",
			},
		},
		property_overrides = {
			hair_scatter = {
				0.12,
			},
			hair_rgb = {
				0.45,
				0.43,
				0.42,
			},
		},
	},
	hair_white_01 = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_color_white_01",
			},
		},
		property_overrides = {
			hair_scatter = {
				0.1,
			},
			hair_rgb = {
				0.65,
				0.62,
				0.6,
			},
		},
	},
	hair_color_hive_scum_red_01 = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_color_hive_scum_red_01",
			},
		},
		property_overrides = {
			hair_scatter = {
				0.04,
			},
			hair_rgb = {
				0.7,
				0.14,
				0.08,
			},
		},
	},
	hair_color_hive_scum_purple_01 = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_color_hive_scum_purple_01",
			},
		},
		property_overrides = {
			hair_scatter = {
				0.04,
			},
			hair_rgb = {
				0.7,
				0.04,
				0.2,
			},
		},
	},
	hair_color_hive_scum_blue_01 = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_color_hive_scum_blue_01",
			},
		},
		property_overrides = {
			hair_scatter = {
				0.04,
			},
			hair_rgb = {
				0.1,
				0.4,
				0.8,
			},
		},
	},
	hair_color_hive_scum_green_01 = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_color_hive_scum_green_01",
			},
		},
		property_overrides = {
			hair_scatter = {
				0.04,
			},
			hair_rgb = {
				0.05,
				0.75,
				0.3,
			},
		},
	},
	hair_headgear_blonde_01 = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_color_blonde_01",
			},
		},
		property_overrides = {
			hair_scatter = {
				0.13,
			},
			hair_rgb = {
				0.65,
				0.53,
				0.28,
			},
		},
	},
	hair_color_2_red_black_01 = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_color_gray_01",
			},
			two_color_blend_mask = {
				resource = "content/characters/player/human/attachments_base/hair/shared/textures/hair_material_mask/hair_material_mask_01",
			},
		},
		property_overrides = {
			two_color_blend_bool = {
				1,
			},
			two_color_blend_color_a = {
				0.1,
				0,
				0,
			},
			two_color_blend_color_b = {
				0.6,
				0.01,
				0,
			},
		},
	},
	hair_broker_blonde_01 = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_color_broker_blonde_01",
			},
		},
		property_overrides = {
			hair_scatter = {
				0.02,
			},
			hair_rgb = {
				0.78,
				0.706,
				0.565,
			},
		},
	},
	hair_broker_green_01 = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_color_broker_green_01",
			},
		},
		property_overrides = {
			hair_scatter = {
				0.04,
			},
			hair_rgb = {
				0.23,
				0.396,
				0.275,
			},
		},
	},
	hair_broker_yellow_01 = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_color_broker_yellow_01",
			},
		},
		property_overrides = {
			hair_scatter = {
				0.04,
			},
			hair_rgb = {
				0.58,
				0.671,
				0.31,
			},
		},
	},
	hair_broker_blue_01 = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_color_broker_blue_01",
			},
		},
		property_overrides = {
			hair_scatter = {
				0.04,
			},
			hair_rgb = {
				0.176,
				0.4,
				0.365,
			},
		},
	},
	hair_broker_blue_02 = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_color_broker_blue_02",
			},
		},
		property_overrides = {
			hair_scatter = {
				0.04,
			},
			hair_rgb = {
				0.11,
				0.2,
				0.46,
			},
		},
	},
	hair_broker_red_01 = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_color_broker_red_01",
			},
		},
		property_overrides = {
			hair_scatter = {
				0.04,
			},
			hair_rgb = {
				0.61,
				0.23,
				0.196,
			},
		},
	},
	hair_broker_red_02 = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_color_broker_red_02",
			},
		},
		property_overrides = {
			hair_scatter = {
				0.04,
			},
			hair_rgb = {
				0.416,
				0.09,
				0.09,
			},
		},
	},
	hair_broker_purple_01 = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_color_broker_purple_01",
			},
		},
		property_overrides = {
			hair_scatter = {
				0.04,
			},
			hair_rgb = {
				0.463,
				0.22,
				0.424,
			},
		},
	},
	hair_broker_purple_02 = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_color_broker_purple_02",
			},
		},
		property_overrides = {
			hair_scatter = {
				0.04,
			},
			hair_rgb = {
				0.29,
				0.19,
				0.427,
			},
		},
	},
	hair_color_2_red_black_01 = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_color_gray_01",
			},
			two_color_blend_mask = {
				resource = "content/characters/player/human/attachments_base/hair/shared/textures/hair_material_mask/hair_material_mask_01",
			},
		},
		property_overrides = {
			two_color_blend_bool = {
				1,
			},
			two_color_blend_color_a = {
				0.1,
				0,
				0,
			},
			two_color_blend_color_b = {
				0.6,
				0.01,
				0,
			},
		},
	},
	hair_cosmetic_blonde_01 = {
		texture_overrides = {
			hair_color_gradient = {
				resource = "content/textures/colors/hair_cosmetic_color_blonde_01",
			},
		},
		property_overrides = {
			hair_scatter = {
				0.13,
			},
			hair_rgb = {
				0.65,
				0.53,
				0.28,
			},
		},
	},
}

return material_overrides
