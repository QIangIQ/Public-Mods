-- chunkname: @scripts/settings/equipment/item_material_overrides/player_material_overrides_hair_headgear_mask.lua

local material_overrides = {
	hair_no_mask = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_remove_all = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-5,
			},
			hair_mask_y = {
				-1,
				-0.01,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_underside_back_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-0.548,
			},
			hair_mask_z = {
				-1,
				-0.8,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_underside_back_02 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.06,
				-0.06,
			},
			hair_mask_y = {
				-1,
				-0.548,
			},
			hair_mask_z = {
				-1,
				-0.9,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_underside_back_03 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-0.82,
			},
			hair_mask_z = {
				-1,
				-0.82,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_underside_back_04 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-1,
				-0.862,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_underside_back_05 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-0.82,
			},
			hair_mask_z = {
				-1,
				-0.747,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_underside_back_06 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-0.617,
			},
			hair_mask_z = {
				-1,
				-0.84,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_half_left_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				1,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				-0.09,
				0,
				0,
			},
		},
	},
	hair_mask_half_left_02 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				1,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.006,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				-0.08,
				0,
				0,
			},
		},
	},
	hair_mask_half_left_03 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				1,
				0,
			},
			hair_mask_x = {
				-0.5,
				0.011,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0.03,
			},
		},
	},
	hair_mask_half_left_04 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.07,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_half_left_05 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.025,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_half_left_06 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.019,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_half_left_07 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.033,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				-0.0489,
				0.231,
				0,
			},
		},
	},
	hair_mask_half_left_08 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.078,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_half_shrink_left_side = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0.072,
				0.654,
			},
			hair_mask_x = {
				-0.5,
				0.002,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				-0.06,
				0,
				0,
			},
		},
	},
	hair_mask_half_shrink_left_side_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.06,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				-0.383,
				0.283,
				-1.084,
			},
		},
	},
	hair_mask_half_right_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				1,
				1,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0.09,
				0,
				0,
			},
		},
	},
	hair_mask_half_right_02 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0.64,
				1,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_half_right_03 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0.64,
				1,
			},
			hair_mask_x = {
				-0.5,
				-0.06,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_half_right_back_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0.37,
				1,
			},
			hair_mask_x = {
				-0.075,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-1,
				-0.954,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_half_right_back_02 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0.185,
				1,
			},
			hair_mask_x = {
				-0.078,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-1,
				-0.954,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_half_right_small = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.032,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_half_right_small_offset = {
		property_overrides = {
			hair_mask_types_invert = {
				-0.06,
				-0.06,
				0.21,
			},
			hair_mask_x = {
				-0.022,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_back = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-0.245,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_back_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-0.41,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_back_02 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-0.388,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_back_03 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-0.388,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0.003,
				0,
				-0.088,
			},
		},
	},
	hair_mask_back_big = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-0.532,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_back_big_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-0.523,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_back_top = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-0.531,
			},
			hair_mask_z = {
				-0.377,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_back_top_front_small = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-0.562,
				-0.502,
			},
			hair_mask_z = {
				-0.375,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_backside_sides_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.36,
				-0.36,
			},
			hair_mask_y = {
				-1,
				-0.622,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_backside_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-0.559,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_backside_02 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-0.325,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_fringe_big = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-0.21,
			},
			hair_mask_z = {
				-0.361,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_fringe_big_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-0.21,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_fringe = {
		property_overrides = {
			hair_mask_types_invert = {
				1,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_fringe_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				1,
				0,
				0,
			},
			hair_mask_x = {
				-0.05,
				-0.05,
			},
			hair_mask_y = {
				-0.788,
				-0.169,
			},
			hair_mask_z = {
				-0.198,
				-0.83,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_fringe_02 = {
		property_overrides = {
			hair_mask_types_invert = {
				1,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-0.1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_fringe_03 = {
		property_overrides = {
			hair_mask_types_invert = {
				1,
				0,
				0,
			},
			hair_mask_x = {
				-0.04,
				-0.04,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-0.3,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_fringe_04 = {
		property_overrides = {
			hair_mask_types_invert = {
				1,
				0,
				0,
			},
			hair_mask_x = {
				0.03,
				-0.1,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-1,
				-0.786,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_fringe_tight = {
		property_overrides = {
			hair_mask_types_invert = {
				1,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-0.537,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_fringe_inverted = {
		property_overrides = {
			hair_mask_types_invert = {
				1,
				0,
				1,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_fringe_inverted_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				1,
				0,
				1,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-0.54,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_top = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-0.542,
				-0.52,
			},
			hair_mask_z = {
				-0.156,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_top_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.005,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-0.52,
			},
			hair_mask_z = {
				-0.12,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_top_02 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-0.16,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_top_03 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-0.13,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_top_04 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-0.196,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_top_05 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-0.08,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_top_06 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-0.453,
				-0.474,
			},
			hair_mask_z = {
				-0.336,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0.282,
			},
		},
	},
	hair_mask_top_07 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-0.524,
			},
			hair_mask_z = {
				-0.272,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				-0.152,
			},
		},
	},
	hair_mask_top_08 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-0.274,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				-0.083,
			},
		},
	},
	hair_mask_top_09 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-0.5,
				-0.474,
			},
			hair_mask_z = {
				-0.3,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_remove_fringe_small = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-0.538,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_remove_fringe_big = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-0.484,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_fringe_small_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-0.17,
			},
			hair_mask_z = {
				-1,
				-0.9,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_fringe_small_02 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-0.12,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_shrink_sides = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.057,
				-0.069,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_shrink_sides_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0.266,
				0.266,
			},
			hair_mask_x = {
				-0.075,
				-0.075,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_shrink_sides_02 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.058,
				-0.058,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_shrink_sides_03 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.097,
				-0.097,
			},
			hair_mask_y = {
				-1,
				-0.615,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_shrink_sides_04 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.058,
				-0.09,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_shrink_right_side = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0.072,
				0.654,
			},
			hair_mask_x = {
				-0.096,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_shrink_right_side_02 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0.072,
				0.654,
			},
			hair_mask_x = {
				-0.059,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_top_bigger = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-0.542,
				-0.52,
			},
			hair_mask_z = {
				-0.142,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_top_big = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-0.542,
				-0.52,
			},
			hair_mask_z = {
				-0.12,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_top_big_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-0.047,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_top_big_02 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-0.083,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_shrink_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.064,
				-0.064,
			},
			hair_mask_y = {
				-1,
				-0.53,
			},
			hair_mask_z = {
				-0.309,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_shrink_02 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.06,
				-0.06,
			},
			hair_mask_y = {
				-1,
				-0.5,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_shrink_03 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.05,
				-0.05,
			},
			hair_mask_y = {
				-1,
				-0.381,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_shrink_04 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.086,
				-0.092,
			},
			hair_mask_y = {
				-1,
				-0.532,
			},
			hair_mask_z = {
				-1,
				-0.916,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_shrink_05 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.079,
				-0.068,
			},
			hair_mask_y = {
				-1,
				-0.548,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_belladonna_shrink_back_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-0.405,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_belladonna_cap_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-0.06,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0.104,
			},
		},
	},
	hair_mask_short_reverse_mohawk_a_shrink_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.05,
				-0.05,
			},
			hair_mask_y = {
				-1,
				-0.5,
			},
			hair_mask_z = {
				-0.075,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_short_reverse_mohawk_a_shrink_02 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.05,
				-0.05,
			},
			hair_mask_y = {
				-1,
				-0.5,
			},
			hair_mask_z = {
				-1,
				-0.952,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_short_reverse_mohawk_a_shrink_03 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.092,
				-0.092,
			},
			hair_mask_y = {
				-1,
				-0.5,
			},
			hair_mask_z = {
				-1,
				-0.952,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_ponytail_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-5,
			},
			hair_mask_y = {
				-1,
				-0.01,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_ponytail_short_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-1,
				-0.946,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_short_dreads_reduce_top = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-0.562,
				-0.436,
			},
			hair_mask_z = {
				-0.322,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_medium_side_swept_afro_a_short_back_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.049,
			},
			hair_mask_y = {
				-1,
				-0.532,
			},
			hair_mask_z = {
				-1,
				-0.946,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_medium_side_swept_afro_a_top_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-0.118,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_medium_side_swept_afro_a_top_02 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.038,
			},
			hair_mask_y = {
				-0.27,
				-1,
			},
			hair_mask_z = {
				-0.335,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_medium_side_swept_afro_a_top_03 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.038,
			},
			hair_mask_y = {
				-0.27,
				-1,
			},
			hair_mask_z = {
				-0.1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0.07,
			},
		},
	},
	hair_medium_afro_reduce_top_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-0.9,
				-0.99,
			},
			hair_mask_z = {
				-0.619,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_medium_afro_reduce_top_02 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-0.02,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_medium_afro_reduce_top_03 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				0.02,
				-1,
			},
			hair_mask_offset = {
				0,
				-0.02,
				0.1,
			},
		},
	},
	hair_mask_bantu_remove_top = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-0.952,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_bantu_remove_top_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-0.131,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_bantu_keep_back = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-0.136,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_medium_afro_a_keep_backside = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-0.528,
			},
			hair_mask_z = {
				-0.003,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_cap_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_cap_02 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-0.031,
				-1,
			},
			hair_mask_offset = {
				0,
				-0.133,
				-0.202,
			},
		},
	},
	hair_mask_cap_03 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-0.44,
				-1,
			},
			hair_mask_z = {
				-0.1,
				-1,
			},
			hair_mask_offset = {
				0,
				-0.03,
				0.109,
			},
		},
	},
	hair_mask_cap_04 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-0.262,
				-1,
			},
			hair_mask_z = {
				0.036,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
			},
		},
	},
	hair_mask_short_modular_shorter_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-1,
				-0.975,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_mullet_top_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-0.8,
				-1,
			},
			hair_mask_z = {
				-0.219,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				-1,
			},
		},
	},
	hair_mask_mullet_top_02 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-0.29,
				-1,
			},
			hair_mask_z = {
				-0.147,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_powdered_wig_bottom_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.117,
				-0.107,
			},
			hair_mask_y = {
				-0.523,
				-1,
			},
			hair_mask_z = {
				-1,
				-0.821,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_powdered_wig_top_back_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-0.485,
			},
			hair_mask_z = {
				-0.224,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				-0.059,
			},
		},
	},
	hair_mask_powdered_wig_top_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-0.62,
				-1,
			},
			hair_mask_z = {
				0.01,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_powdered_wig_top_02 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-0.7,
				-1,
			},
			hair_mask_z = {
				0.09,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0.05,
			},
		},
	},
	hair_mask_front_top_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-0.4,
				-1,
			},
			hair_mask_z = {
				-0.18,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_front_top_02 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-0.319,
				-1,
			},
			hair_mask_z = {
				-0.169,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_front_top_03 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				0.038,
				-1,
			},
			hair_mask_offset = {
				0,
				0.083,
				0,
			},
		},
	},
	hair_mask_front_top_04 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-0.378,
				-1,
			},
			hair_mask_z = {
				-0.031,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0.012,
			},
		},
	},
	hair_mask_front_top_05 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.12,
				-0.135,
			},
			hair_mask_y = {
				-0.566,
				-1,
			},
			hair_mask_z = {
				-0.082,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_underside_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-1,
				-0.674,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	hair_mask_short_horn_braids_a_back_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-0.515,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0.002,
				0,
			},
		},
	},
	hair_mask_mohawk_fringe_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-0.515,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	ogryn_hair_mask_fringe = {
		property_overrides = {
			hair_mask_types_invert = {
				1,
				0,
				0,
			},
			hair_mask_x = {
				-0.1,
				-0.1,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-0.3,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	ogryn_hair_mask_fringe_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				1,
				0,
				0,
			},
			hair_mask_x = {
				-0.1,
				-0.1,
			},
			hair_mask_y = {
				-0.591,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	ogryn_hair_mask_fringe_02 = {
		property_overrides = {
			hair_mask_types_invert = {
				1,
				0,
				0,
			},
			hair_mask_x = {
				-0.1,
				-0.1,
			},
			hair_mask_y = {
				-0.343,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	ogryn_hair_mask_back_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-0.296,
				-1,
			},
			hair_mask_z = {
				-0.309,
				-1,
			},
			hair_mask_offset = {
				-0,
				0,
				-0,
			},
		},
	},
	ogryn_hair_mask_underside_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-1,
				-0.778,
			},
			hair_mask_offset = {
				-0,
				0,
				-0,
			},
		},
	},
	ogryn_hair_mask_underside_small_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-1,
				-0.91,
			},
			hair_mask_offset = {
				-0,
				0,
				-0,
			},
		},
	},
	ogryn_hair_mask_underside_back_small_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-0.46,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				-0,
				0,
				-0,
			},
		},
	},
	ogryn_hair_mask_beret = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.165,
				-0.5,
			},
			hair_mask_y = {
				-0.478,
				-1,
			},
			hair_mask_z = {
				-0.26,
				-1,
			},
			hair_mask_offset = {
				-0,
				0.1,
				-0.03,
			},
		},
	},
	ogryn_hair_mask_beret_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.165,
				-0.5,
			},
			hair_mask_y = {
				-0.478,
				-1,
			},
			hair_mask_z = {
				-0.23,
				-1,
			},
			hair_mask_offset = {
				-0,
				0.1,
				-0.03,
			},
		},
	},
	ogryn_hair_mask_cap_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-0.548,
			},
			hair_mask_z = {
				-0.147,
				-1,
			},
			hair_mask_offset = {
				-0,
				0.162,
				0.108,
			},
		},
	},
	ogryn_hair_mask_cap_02 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-0.151,
				-1,
			},
			hair_mask_offset = {
				-0,
				-0.054,
				0.108,
			},
		},
	},
	ogryn_hair_mask_top_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.19,
				-0.19,
			},
			hair_mask_y = {
				-0.554,
				-0.548,
			},
			hair_mask_z = {
				-0.265,
				-1,
			},
			hair_mask_offset = {
				-0,
				0.112,
				-0,
			},
		},
	},
	ogryn_hair_mask_top_02 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.19,
				-0.19,
			},
			hair_mask_y = {
				-0.554,
				-1,
			},
			hair_mask_z = {
				-0.265,
				-1,
			},
			hair_mask_offset = {
				-0,
				0.112,
				-0,
			},
		},
	},
	ogryn_hair_mask_top_03 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.19,
				-0.19,
			},
			hair_mask_y = {
				-0.05,
				-1,
			},
			hair_mask_z = {
				-0.265,
				-1,
			},
			hair_mask_offset = {
				-0,
				0.112,
				-0,
			},
		},
	},
	ogryn_hair_mask_top_04 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.19,
				-0.19,
			},
			hair_mask_y = {
				0.1,
				-1,
			},
			hair_mask_z = {
				-0.265,
				-1,
			},
			hair_mask_offset = {
				-0,
				0.112,
				-0,
			},
		},
	},
	ogryn_hair_mask_top_05 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.19,
				-0.19,
			},
			hair_mask_y = {
				-0.526,
				-0.435,
			},
			hair_mask_z = {
				-0.313,
				-1,
			},
			hair_mask_offset = {
				-0,
				-0.08,
				0.106,
			},
		},
	},
	ogryn_hair_mask_top_06 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.19,
				-0.19,
			},
			hair_mask_y = {
				-0.4,
				-0.435,
			},
			hair_mask_z = {
				-0.313,
				-1,
			},
			hair_mask_offset = {
				-0,
				-0.08,
				0.106,
			},
		},
	},
	ogryn_hair_mask_half_left = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				1.777,
				0,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				-0.2,
				0,
				0,
			},
		},
	},
	ogryn_hair_mask_half_right = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				1.777,
				1,
			},
			hair_mask_x = {
				-0.5,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0.2,
				0,
				0,
			},
		},
	},
	ogryn_hair_mask_half_right_02 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				0.052,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-1,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	ogryn_hair_mask_half_right_03 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				0.09,
				-0.5,
			},
			hair_mask_y = {
				-0.6,
				-1,
			},
			hair_mask_z = {
				-0.306,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	ogryn_hair_mask_half_right_04 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				0.011,
				-0.5,
			},
			hair_mask_y = {
				-1,
				-1,
			},
			hair_mask_z = {
				-0.234,
				-1,
			},
			hair_mask_offset = {
				0.0136,
				0,
				0,
			},
		},
	},
	ogryn_hair_mask_half_right_top_01 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.161,
				-0.5,
			},
			hair_mask_y = {
				-0.777,
				-1,
			},
			hair_mask_z = {
				-0.236,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	ogryn_hair_mask_half_right_top_02 = {
		property_overrides = {
			hair_mask_types_invert = {
				0,
				0,
				0,
			},
			hair_mask_x = {
				-0.148,
				-0.5,
			},
			hair_mask_y = {
				-0.441,
				-1,
			},
			hair_mask_z = {
				-0.249,
				-1,
			},
			hair_mask_offset = {
				0,
				0,
				0,
			},
		},
	},
	facial_hair_no_mask = {
		property_overrides = {
			facial_hair_mask_x = {
				-1,
				-1,
			},
			facial_hair_mask_y = {
				-1,
				-1,
			},
			facial_hair_mask_z = {
				-1,
				-1,
			},
			use_alpha_masking = {
				1,
			},
		},
	},
	facial_hair_mask_neck_01 = {
		property_overrides = {
			facial_hair_mask_x = {
				-1,
				-1,
			},
			facial_hair_mask_y = {
				0.188,
				-0.916,
			},
			facial_hair_mask_z = {
				-1,
				-0.904,
			},
			use_alpha_masking = {
				1,
			},
		},
	},
	facial_hair_mask_chin_strap_01 = {
		property_overrides = {
			facial_hair_mask_x = {
				-1,
				-1,
			},
			facial_hair_mask_y = {
				-0.21,
				-1,
			},
			facial_hair_mask_z = {
				-1,
				-0.746,
			},
			use_alpha_masking = {
				1,
			},
		},
	},
	facial_hair_mask_chin_strap_02 = {
		property_overrides = {
			facial_hair_mask_x = {
				-1,
				-1,
			},
			facial_hair_mask_y = {
				-0.21,
				-1,
			},
			facial_hair_mask_z = {
				-1,
				-0.746,
			},
			use_alpha_masking = {
				1,
			},
		},
	},
	facial_hair_mask_chin_strap_03 = {
		property_overrides = {
			facial_hair_mask_x = {
				-1,
				-1,
			},
			facial_hair_mask_y = {
				-0.266,
				-0.862,
			},
			facial_hair_mask_z = {
				-1,
				-0.645,
			},
			use_alpha_masking = {
				1,
			},
		},
	},
	facial_hair_mask_chin_strap_04 = {
		property_overrides = {
			facial_hair_mask_x = {
				-1,
				-1,
			},
			facial_hair_mask_y = {
				-0.289,
				-0.86,
			},
			facial_hair_mask_z = {
				-1,
				-0.835,
			},
			use_alpha_masking = {
				1,
			},
		},
	},
	facial_hair_mask_chin_strap_05 = {
		property_overrides = {
			facial_hair_mask_x = {
				-0.832,
				-1,
			},
			facial_hair_mask_y = {
				-0.06,
				-1,
			},
			facial_hair_mask_z = {
				-1,
				-0.763,
			},
			use_alpha_masking = {
				1,
			},
		},
	},
	facial_hair_mask_chin_01 = {
		property_overrides = {
			facial_hair_mask_x = {
				-0.888,
				-0.888,
			},
			facial_hair_mask_y = {
				-0.203,
				-1,
			},
			facial_hair_mask_z = {
				-1,
				-1,
			},
			use_alpha_masking = {
				1,
			},
		},
	},
	facial_hair_mask_chin_02 = {
		property_overrides = {
			facial_hair_mask_x = {
				-0.888,
				-0.888,
			},
			facial_hair_mask_y = {
				-0.261,
				-0.715,
			},
			facial_hair_mask_z = {
				-1,
				-0.677,
			},
			use_alpha_masking = {
				1,
			},
		},
	},
	facial_hair_mask_chin_03 = {
		property_overrides = {
			facial_hair_mask_x = {
				-0.888,
				-0.888,
			},
			facial_hair_mask_y = {
				-0.35,
				-1,
			},
			facial_hair_mask_z = {
				-1,
				-0.93,
			},
			use_alpha_masking = {
				1,
			},
		},
	},
	facial_hair_mask_chin_04 = {
		property_overrides = {
			facial_hair_mask_x = {
				-0.888,
				-0.888,
			},
			facial_hair_mask_y = {
				-0.35,
				-1,
			},
			facial_hair_mask_z = {
				-1,
				-0.769,
			},
			use_alpha_masking = {
				1,
			},
		},
	},
	facial_hair_mask_chin_sides_01 = {
		property_overrides = {
			facial_hair_mask_x = {
				-1,
				-1,
			},
			facial_hair_mask_y = {
				-0.179,
				-0.845,
			},
			facial_hair_mask_z = {
				-1,
				-0.636,
			},
			use_alpha_masking = {
				1,
			},
		},
	},
	facial_hair_mask_chin_sides_02 = {
		property_overrides = {
			facial_hair_mask_x = {
				-0.976,
				-0.976,
			},
			facial_hair_mask_y = {
				-1,
				-0.436,
			},
			facial_hair_mask_z = {
				-1,
				-0.496,
			},
			use_alpha_masking = {
				1,
			},
		},
	},
	facial_hair_mask_chin_sides_03 = {
		property_overrides = {
			facial_hair_mask_x = {
				-0.888,
				-0.888,
			},
			facial_hair_mask_y = {
				-0.278,
				-1,
			},
			facial_hair_mask_z = {
				-1,
				-0.477,
			},
			use_alpha_masking = {
				1,
			},
		},
	},
	facial_hair_mask_chin_sides_04 = {
		property_overrides = {
			facial_hair_mask_x = {
				-0.98,
				-0.98,
			},
			facial_hair_mask_y = {
				-0.583,
				-0.848,
			},
			facial_hair_mask_z = {
				-1,
				-0.93,
			},
			use_alpha_masking = {
				1,
			},
		},
	},
	facial_hair_mask_chin_sides_05 = {
		property_overrides = {
			facial_hair_mask_x = {
				-0.288,
				-0.544,
			},
			facial_hair_mask_y = {
				-1,
				-1,
			},
			facial_hair_mask_z = {
				-1,
				-0.68,
			},
			use_alpha_masking = {
				1,
			},
		},
	},
	facial_hair_mask_chin_sides_06 = {
		property_overrides = {
			facial_hair_mask_x = {
				0.246,
				-0.956,
			},
			facial_hair_mask_y = {
				-0.06,
				-1,
			},
			facial_hair_mask_z = {
				-0.782,
				-0.556,
			},
			use_alpha_masking = {
				1,
			},
		},
	},
	facial_hair_mask_sides_01 = {
		property_overrides = {
			facial_hair_mask_x = {
				-1,
				-1,
			},
			facial_hair_mask_y = {
				-1,
				-0.844,
			},
			facial_hair_mask_z = {
				-1,
				-1,
			},
			use_alpha_masking = {
				1,
			},
		},
	},
	facial_hair_mask_sides_02 = {
		property_overrides = {
			facial_hair_mask_x = {
				-1,
				-1,
			},
			facial_hair_mask_y = {
				-1,
				-0.702,
			},
			facial_hair_mask_z = {
				-1,
				-1,
			},
			use_alpha_masking = {
				1,
			},
		},
	},
	facial_hair_mask_sides_03 = {
		property_overrides = {
			facial_hair_mask_x = {
				-1,
				-1,
			},
			facial_hair_mask_y = {
				-1,
				-0.874,
			},
			facial_hair_mask_z = {
				-1,
				-1,
			},
			use_alpha_masking = {
				1,
			},
		},
	},
	facial_hair_mask_sides_04 = {
		property_overrides = {
			facial_hair_mask_x = {
				-1,
				-1,
			},
			facial_hair_mask_y = {
				-1,
				-0.95,
			},
			facial_hair_mask_z = {
				-1,
				-1,
			},
			use_alpha_masking = {
				1,
			},
		},
	},
	facial_hair_mask_sides_05 = {
		property_overrides = {
			facial_hair_mask_x = {
				-1,
				-1,
			},
			facial_hair_mask_y = {
				-1,
				-0.801,
			},
			facial_hair_mask_z = {
				-1,
				-1,
			},
			use_alpha_masking = {
				1,
			},
		},
	},
	facial_hair_mask_sides_06 = {
		property_overrides = {
			facial_hair_mask_x = {
				-0.8,
				-0.8,
			},
			facial_hair_mask_y = {
				-1,
				-1,
			},
			facial_hair_mask_z = {
				-1,
				-1,
			},
			use_alpha_masking = {
				1,
			},
		},
	},
	facial_hair_mask_upper_cheeks_01 = {
		property_overrides = {
			facial_hair_mask_x = {
				-1,
				-1,
			},
			facial_hair_mask_y = {
				-1,
				-1,
			},
			facial_hair_mask_z = {
				-0.085,
				-1,
			},
			use_alpha_masking = {
				0,
			},
		},
	},
	facial_hair_keep_sides_01 = {
		property_overrides = {
			facial_hair_mask_x = {
				-1,
				-1,
			},
			facial_hair_mask_y = {
				-0.161,
				-1,
			},
			facial_hair_mask_z = {
				-1,
				-0.999,
			},
			use_alpha_masking = {
				0,
			},
		},
	},
	facial_hair_keep_sides_02 = {
		property_overrides = {
			facial_hair_mask_x = {
				-0.476,
				-0.476,
			},
			facial_hair_mask_y = {
				-0.24,
				-1,
			},
			facial_hair_mask_z = {
				-1,
				-1,
			},
			use_alpha_masking = {
				0,
			},
		},
	},
	facial_hair_keep_small_sideburns_01 = {
		property_overrides = {
			facial_hair_mask_x = {
				-0.999,
				-0.999,
			},
			facial_hair_mask_y = {
				-0.027,
				-1,
			},
			facial_hair_mask_z = {
				-1,
				-0.474,
			},
			use_alpha_masking = {
				0,
			},
		},
	},
	facial_hair_keep_small_sideburns_02 = {
		property_overrides = {
			facial_hair_mask_x = {
				-1,
				-1,
			},
			facial_hair_mask_y = {
				-0.014,
				-1,
			},
			facial_hair_mask_z = {
				-1,
				-0.652,
			},
			use_alpha_masking = {
				0,
			},
		},
	},
	facial_hair_keep_small_sideburns_03 = {
		property_overrides = {
			facial_hair_mask_x = {
				-1,
				-1,
			},
			facial_hair_mask_y = {
				-0.014,
				-1,
			},
			facial_hair_mask_z = {
				-1,
				-0.761,
			},
			use_alpha_masking = {
				0,
			},
		},
	},
	facial_hair_mask_underside_01 = {
		property_overrides = {
			facial_hair_mask_x = {
				-0.964,
				-0.964,
			},
			facial_hair_mask_y = {
				0.005,
				-1,
			},
			facial_hair_mask_z = {
				-0.894,
				-1,
			},
			use_alpha_masking = {
				0,
			},
		},
	},
	facial_hair_mask_shrink_side_underside_01 = {
		property_overrides = {
			facial_hair_mask_x = {
				-0.968,
				-0.984,
			},
			facial_hair_mask_y = {
				-0.114,
				-1,
			},
			facial_hair_mask_z = {
				-1,
				-1,
			},
			use_alpha_masking = {
				1,
			},
		},
	},
	facial_hair_mask_cowl_01 = {
		property_overrides = {
			facial_hair_mask_x = {
				-1,
				-0.994,
			},
			facial_hair_mask_y = {
				-0.329,
				-0.697,
			},
			facial_hair_mask_z = {
				-1,
				-0.735,
			},
			use_alpha_masking = {
				0,
			},
		},
	},
	facial_hair_mask_shrink_front = {
		property_overrides = {
			facial_hair_mask_x = {
				-1,
				-1,
			},
			facial_hair_mask_y = {
				-0.2,
				-1,
			},
			facial_hair_mask_z = {
				-1,
				-1,
			},
			use_alpha_masking = {
				0,
			},
		},
	},
	ogryn_facial_hair_mask_sides_01 = {
		property_overrides = {
			facial_hair_mask_x = {
				-0.961,
				-0.961,
			},
			facial_hair_mask_y = {
				-1,
				-0.792,
			},
			facial_hair_mask_z = {
				-1,
				-1,
			},
			use_alpha_masking = {
				1,
			},
		},
	},
	ogryn_facial_hair_mask_sides_02 = {
		property_overrides = {
			facial_hair_mask_x = {
				-0.98,
				-0.98,
			},
			facial_hair_mask_y = {
				-1,
				-0.974,
			},
			facial_hair_mask_z = {
				-1,
				-1,
			},
			use_alpha_masking = {
				1,
			},
		},
	},
	ogryn_facial_hair_mask_sides_03 = {
		property_overrides = {
			facial_hair_mask_x = {
				-0.954,
				-0.954,
			},
			facial_hair_mask_y = {
				-1,
				-0.909,
			},
			facial_hair_mask_z = {
				-1,
				-1,
			},
			use_alpha_masking = {
				1,
			},
		},
	},
	ogryn_facial_hair_mask_chin_strap_01 = {
		property_overrides = {
			facial_hair_mask_x = {
				-0.948,
				-0.948,
			},
			facial_hair_mask_y = {
				-0.194,
				-1,
			},
			facial_hair_mask_z = {
				-1,
				-0.584,
			},
			use_alpha_masking = {
				1,
			},
		},
	},
	ogryn_facial_hair_mask_chin_strap_02 = {
		property_overrides = {
			facial_hair_mask_x = {
				-0.948,
				-0.948,
			},
			facial_hair_mask_y = {
				-0.194,
				-0.909,
			},
			facial_hair_mask_z = {
				-1,
				-0.584,
			},
			use_alpha_masking = {
				1,
			},
		},
	},
	ogryn_facial_hair_keep_small_sideburns_01 = {
		property_overrides = {
			facial_hair_mask_x = {
				-0.948,
				-0.948,
			},
			facial_hair_mask_y = {
				-0.155,
				-1,
			},
			facial_hair_mask_z = {
				-1,
				-0.323,
			},
			use_alpha_masking = {
				0,
			},
		},
	},
	ogryn_facial_hair_keep_small_sideburns_02 = {
		property_overrides = {
			facial_hair_mask_x = {
				-0.948,
				-0.948,
			},
			facial_hair_mask_y = {
				-0.105,
				-1,
			},
			facial_hair_mask_z = {
				-1,
				-0.39,
			},
			use_alpha_masking = {
				0,
			},
		},
	},
	ogryn_facial_hair_scarf_01 = {
		property_overrides = {
			facial_hair_mask_x = {
				-1,
				-1,
			},
			facial_hair_mask_y = {
				-1,
				-0.548,
			},
			facial_hair_mask_z = {
				-1,
				-0.616,
			},
			use_alpha_masking = {
				1,
			},
		},
	},
	ogryn_facial_hair_scarf_02 = {
		property_overrides = {
			facial_hair_mask_x = {
				-0.58,
				-0.664,
			},
			facial_hair_mask_y = {
				-0.558,
				-0.634,
			},
			facial_hair_mask_z = {
				-1,
				-0.634,
			},
			use_alpha_masking = {
				1,
			},
		},
	},
}

return material_overrides
