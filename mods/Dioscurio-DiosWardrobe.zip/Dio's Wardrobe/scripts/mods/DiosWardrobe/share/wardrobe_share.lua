local mod = get_mod("DiosWardrobe")

--[[
  OUTFIT SHARING OVER VOX MANIFOLD

  Each player's current Dio's Wardrobe outfit is serialized, compressed, and cycled through
  one Vox Manifold presence key in chunks. Other players reassemble it and Dio's Wardrobe
  builds that player's gear with it, the same way it builds your own.

  Vox Manifold carries at most ~230 bytes per mod per player and is last-write-wins, so:

    * Every payload carries a SUMMARY: outfit hash (h), chunk count (n), character (k),
      vocabulary hash (q).
    * A player who is missing someone's outfit puts that hash in their own payload as a
      REQUEST (w).
    * A player only CYCLES chunks (i, c), one per ~2.2s, while at least one party member is
      requesting their current hash. Otherwise they publish the summary alone and stay
      quiet.
    * A reassembled outfit is verified against its hash, cached in memory, and saved to
      disk, so the same outfit is instant next time.

  Payload (version p = 1), all fields short:
    p  payload version      q  vocabulary hash       h  outfit hash (absent: no outfit)
    n  chunk count          k  character id prefix   i  chunk index   c  chunk text
    w  outfit hash this player is requesting
    r  resend counter (0-35). Vox Manifold drops a publish identical to the last one, and a
       publish can be lost on the way to the backend, so a request or a changed summary
       that never landed would never be retried. Bumping r forces a fresh write: twice,
       5s apart, after any change, and every 8s while a request makes no progress.
--]]

local Wire = mod:io_dofile("Dio's Wardrobe/scripts/mods/DiosWardrobe/share/wire")
local MasterItems = require("scripts/backend/master_items")
local ItemPackage = require("scripts/foundation/managers/package/utilities/item_package")
local FixedFrame = require("scripts/utilities/fixed_frame")
local NetworkLookup = require("scripts/network_lookup/network_lookup")
local PlayerCharacterConstants = require("scripts/settings/player_character/player_character_constants")
local SLOT_EQUIP_ORDER = PlayerCharacterConstants.slot_equip_order

local ID = "dio.wardrobe"
local PAYLOAD_VERSION = 1
-- Keeps every payload at or under Vox Manifold's 200-byte comfort line (hard limit 250),
-- measured through its real encoder with every field present at its longest.
local CHUNK_CHARS = 88
local CYCLE_INTERVAL = 2.2
local POLL_INTERVAL = 1.0
-- Your own outfit is packed once after entering the Mourningstar and once after entering
-- a mission, then left alone until the next transition. The delay lets the character
-- finish spawning first.
local REBUILD_DELAY = 3
local MAX_CHUNKS = 120
local CACHE_PREFIX = "vox_outfit_"
local REINFORCE_COUNT = 2
local REINFORCE_INTERVAL = 5
local STALL_RESEND = 8

-- slots whose gear is rebuilt for other players (head gear lives on the face)
local PEER_SLOTS = {
  slot_body_face = true,
  slot_gear_upperbody = true,
  slot_gear_lowerbody = true,
  slot_gear_extra_cosmetic = true,
}
local PEER_SLOT_ORDER = { "slot_body_face", "slot_gear_upperbody", "slot_gear_lowerbody", "slot_gear_extra_cosmetic" }
local MATERIAL_SLOTS = { "slot_gear_head", "slot_gear_upperbody", "slot_gear_lowerbody", "slot_gear_extra_cosmetic", "slot_primary", "slot_secondary" }

mod.version = mod.version or "1"

local Share = {
  manifold = nil,
  unsubscribe = nil,
  vocab = nil,

  my = { hash = nil, chunks = {}, n = 0, index = 1, pos = 1, pass_len = 2, k = nil, cycling = false },
  my_dirty = true,
  want = nil,

  collecting = {},   -- [hash] = { n, parts, have }
  cache = {},        -- [hash] = outfit table
  bad_hash = {},     -- [hash] = true when it failed to verify, so it is not re-requested forever
  peers = {},        -- [account_id] = { hash, k, applied_hash, applied_unit }
  load_attempts = {},
  broken = {},
  roster = {},       -- [account_id] = { name, running } for /wardrobe_status
  noted_without = {},
  prefetched = {},   -- [hash] = true once its items were queued for loading       -- [tag..slot..hash] = true after a failed build; that slot shows normal gear

  t_cycle = 0,
  t_poll = 0,
  poll_now = true,   -- set by Vox Manifold's update signal and by finished loads
  clock = 0,
  retry_at = nil,    -- when a rebuild waiting for a player's gear to load is retried
  t_rebuild = 0,

  r = 0,
  reinforce = 0,
  t_reinforce = 0,
  t_stall = 0,
  warned = {},
}
mod.wardrobe_share = Share

-- defined further down, used by rebuild_my_outfit
local sanitize_outfit

local function warn_once(key, fmt, ...)
  if not Share.warned[key] then
    Share.warned[key] = true
    mod:warning(fmt, ...)
  end
end

-- Presence updates can reach a friend at a fraction of the rate they are sent (observed:
-- roughly every other one). With a pass of n sends they then catch the same pieces on
-- every pass whenever n shares a factor with that rate: a 38-piece outfit cycled for 7
-- minutes without ever arriving. A pass whose length is prime shares no factor with any
-- such rate, so each pass lands on different pieces and a friend who catches one update
-- in k has everything within k passes. The padding slots resend the first pieces.
local function prime_at_least(n)
  -- at least 7 so a tiny outfit's pass cannot itself be a multiple of the skip rate
  local c = math.max(n, 7)
  while true do
    local is_prime = true
    for d = 2, math.floor(math.sqrt(c)) do
      if c % d == 0 then is_prime = false break end
    end
    if is_prime then return c end
    c = c + 1
  end
end
Share.prime_at_least = prime_at_least

local function state_changed()
  Share.reinforce = REINFORCE_COUNT
  Share.t_reinforce = 0
end

local function sharing_enabled()
  return mod:get("share_my_outfit") ~= false
end

local function viewing_enabled()
  return mod:get("show_others_outfits") ~= false
end

local function short_id(id)
  return type(id) == "string" and id:sub(1, 6) or nil
end

---------------------------------------------------------------------------
-- vocabulary: identical on every client with the same vendored material data
---------------------------------------------------------------------------

local FIELD_NAMES = {
  "slot_gear_head", "slot_gear_upperbody", "slot_gear_lowerbody", "slot_gear_extra_cosmetic",
  "slot_primary", "slot_secondary", "slot_body_face", "gear_customization_data",
  "body_customization_data", "attachments", "is_visible", "customize", "is_extra", "material_overrides",
  "material_data", "number", "scalar", "scalar2", "scalar3", "scalar4", "textures", "mask_torso",
  "mask_arms", "mask_legs", "mask_face", "mask_hair", "mask_facial_hair", "hide_body", "hide_arms",
  "hide_legs", "hide_hair", "hide_beard", "hide_eyebrows", "shirtless", "pantless",
  "use_custom_hair_color", "custom_hair_color", "content/items/characters/player/",
}

local function build_vocab()
  local strings = {}
  local ItemMaterialOverrides = mod.ItemMaterialOverrides

  local function walk(t, depth)
    if depth > 6 then return end
    for k, v in pairs(t) do
      if type(k) == "string" then strings[#strings + 1] = k end
      if type(v) == "string" then
        strings[#strings + 1] = v
      elseif type(v) == "table" then
        walk(v, depth + 1)
      end
    end
  end

  for name in pairs(mod.material_library_names) do
    strings[#strings + 1] = name
    local entry = ItemMaterialOverrides[name]
    if type(entry) == "table" then
      walk({ p = entry.property_overrides, t = entry.texture_overrides }, 0)
    end
  end

  for i = 1, #FIELD_NAMES do
    strings[#strings + 1] = FIELD_NAMES[i]
  end

  for i = 1, 16 do
    strings[#strings + 1] = "attachment_" .. i
  end

  return Wire.build_vocab(strings)
end

---------------------------------------------------------------------------
-- my outfit -> wire form
---------------------------------------------------------------------------

-- Merge a list of material names into the mod's custom material format. Written out here
-- because mod.merge_materials drops property overrides (it stores them at the top level
-- instead of under property_overrides), which would lose them on the wire.
local function materials_to_custom(names)
  local ItemMaterialOverrides = mod.ItemMaterialOverrides
  local merged = { property_overrides = {}, texture_overrides = {} }
  local any = false

  for _, name in ipairs(names) do
    local data = ItemMaterialOverrides[name]
    if type(data) == "table" then
      for p, v in pairs(data.property_overrides or {}) do
        merged.property_overrides[p] = type(v) == "table" and table.clone(v) or v
        any = true
      end
      for s, v in pairs(data.texture_overrides or {}) do
        merged.texture_overrides[s] = type(v) == "table" and table.clone(v) or v
        any = true
      end
    end
  end

  return any and mod:material_data_to_custom(merged) or nil
end

local function library_only(names)
  if type(names) ~= "table" then return nil end
  local out = {}
  for _, name in ipairs(names) do
    if type(name) == "string" and mod.material_library_names[name] then
      out[#out + 1] = name
    end
  end
  return #out > 0 and out or nil
end

local function has_content(t)
  return type(t) == "table" and next(t) ~= nil
end

local function build_wire_outfit()
  local src = mod.current_slots_data
  if type(src) ~= "table" then return nil end

  local out = {}
  local any = false

  for _, slot in ipairs(MATERIAL_SLOTS) do
    if has_content(src[slot]) then
      out[slot] = table.clone(src[slot])
      any = true
    end
  end

  local body = src.body_customization_data
  if has_content(body) then
    out.body_customization_data = table.clone(body)
    for _, v in pairs(body) do
      if v == true or (type(v) == "string" and v ~= "") then any = true end
    end
  end

  local gear = {}
  for item_name, data in pairs(src.gear_customization_data or {}) do
    if type(data) == "table" then
      local d = table.clone(data)
      d.material_overrides = library_only(d.material_overrides)

      for _, att in pairs(d.attachments or {}) do
        if type(att) == "table" then
          local generated = {}
          for _, name in ipairs(att.material_overrides or {}) do
            if not mod.material_library_names[name] then
              generated[#generated + 1] = name
            end
          end

          att.material_overrides = library_only(att.material_overrides)

          local custom = materials_to_custom(generated)
          if custom then
            att.material_data = att.material_data or custom
          end
        end
      end

      gear[item_name] = d
      any = true
    end
  end
  out.gear_customization_data = gear

  return any and out or nil
end

local function rebuild_my_outfit()
  Share.my_dirty = false

  local player = Managers.player and Managers.player:local_player_safe(1)
  local character_id = player and player:character_id()

  local outfit = build_wire_outfit()
  local my = Share.my
  local old_hash = my.hash

  if not outfit or not Share.vocab then
    my.hash, my.chunks, my.n, my.index, my.pos, my.pass_len = nil, {}, 0, 1, 1, 2
  else
    local text = Wire.serialize(outfit, Share.vocab)
    local hash = Wire.hash(text)

    if hash ~= old_hash then
      local packed = Wire.compress(text)
      local chunks = Wire.split(packed, CHUNK_CHARS)

      if #chunks > MAX_CHUNKS then
        warn_once("too_big", "[Dio's Wardrobe] Your outfit is too large to share (%d chunks). Other players will see your normal gear.", #chunks)
        my.hash, my.chunks, my.n = nil, {}, 0
      else
        my.hash, my.chunks, my.n, my.index, my.pos = hash, chunks, #chunks, 1, 1
        my.pass_len = prime_at_least(#chunks)
        -- a party member wearing an identical outfit resolves from this without a transfer
        Share.cache[hash] = sanitize_outfit(table.clone(outfit))
      end
    end
  end

  local old_k = my.k
  my.k = short_id(character_id)

  if my.hash ~= old_hash or my.k ~= old_k then
    if my.hash then
      mod:info("[Dio's Wardrobe] Your outfit is ready to share (%s, %d pieces)", my.hash, my.n)
    else
      mod:info("[Dio's Wardrobe] Nothing customized on this character, so there is no outfit to share")
    end
  end

  if (my.hash ~= old_hash or my.k ~= old_k) and Share.manifold then
    state_changed()
    Share.manifold.mark_dirty(ID)
  end
end

mod.mark_share_outfit_dirty = function()
  Share.my_dirty = true
end

---------------------------------------------------------------------------
-- payload
---------------------------------------------------------------------------

-- Must stay free of side effects: Vox Manifold may call it at any time.
local function build_payload()
  if not Share.vocab then return nil end

  local p = { p = PAYLOAD_VERSION, q = Share.vocab.hash }
  local my = Share.my

  if sharing_enabled() and my.hash then
    p.h, p.n, p.k = my.hash, my.n, my.k

    if my.cycling and my.n > 0 then
      local i = ((my.index - 1) % my.n) + 1
      p.i, p.c = i, my.chunks[i]
    end
  end

  if viewing_enabled() and Share.want then
    p.w = Share.want
  end

  if Share.r ~= 0 then
    p.r = Share.r
  end

  return p
end

---------------------------------------------------------------------------
-- disk cache (compressed text only; never executed)
---------------------------------------------------------------------------

local function cache_file(hash)
  return CACHE_PREFIX .. hash .. ".txt"
end

local function decode_packed(hash, packed)
  local text = Wire.decompress(packed)
  if not text or Wire.hash(text) ~= hash then
    return nil, "hash mismatch"
  end

  local outfit, err = Wire.deserialize(text, Share.vocab)
  if type(outfit) ~= "table" then
    return nil, err or "not a table"
  end

  return outfit
end

local function load_from_disk(hash)
  local ok, result = pcall(function()
    if not mod.file_exist(cache_file(hash)) then return nil end
    for line in mod.read_all_lines(cache_file(hash)) do
      return decode_packed(hash, line)
    end
  end)
  return ok and result or nil
end

local function save_to_disk(hash, packed)
  pcall(function()
    local dir = mod:persistent_table("data").directory
    mod:override_mod_file(dir .. cache_file(hash), packed)
  end)
end

---------------------------------------------------------------------------
-- validating a received outfit: drop anything that names an item this client lacks
---------------------------------------------------------------------------

sanitize_outfit = function(outfit)
  local clean = mod:default_slot_data()

  for _, slot in ipairs(MATERIAL_SLOTS) do
    if type(outfit[slot]) == "table" then clean[slot] = outfit[slot] end
  end

  if type(outfit.body_customization_data) == "table" then
    clean.body_customization_data = outfit.body_customization_data
  end

  for item_name, data in pairs(type(outfit.gear_customization_data) == "table" and outfit.gear_customization_data or {}) do
    if type(item_name) == "string" and type(data) == "table" and MasterItems.get_item(item_name) then
      local attachments = {}
      for att_item, att in pairs(type(data.attachments) == "table" and data.attachments or {}) do
        if type(att_item) == "string" and type(att) == "table" and type(att.name) == "string" and MasterItems.get_item(att_item) then
          attachments[att_item] = att
        end
      end
      data.attachments = attachments
      clean.gear_customization_data[item_name] = data
    end
  end

  return clean
end

---------------------------------------------------------------------------
-- applying to other players
---------------------------------------------------------------------------

local function find_player(account_id)
  local players = Managers.player and Managers.player:players()
  if not players then return nil end

  for _, player in pairs(players) do
    if player.remote and player:account_id() == account_id then
      return player
    end
  end

  return nil
end

local function outfit_for_player(player)
  if not viewing_enabled() or not player or not player.account_id then return nil end

  local account_id = player:account_id()
  local peer = account_id and Share.peers[account_id]
  if not peer or not peer.hash then return nil end

  local outfit = Share.cache[peer.hash]
  if not outfit then return nil end

  -- only for the character it was made on
  local character_id = player:character_id()
  if peer.k and short_id(character_id) ~= peer.k then return nil end

  return outfit, peer
end

-- Every package the customized item depends on, restricted to real package names.
local function item_packages(item)
  local ok, deps = pcall(ItemPackage.compile_item_instance_dependencies, item, MasterItems.get_cached(), nil, nil)
  local out = {}

  if ok and type(deps) == "table" then
    for name in pairs(deps) do
      if mod:wd_is_known_package(name) then
        out[name] = true
      end
    end
  end

  return out
end

-- Every unit the spawner will ask for, resolved the way Items.base_unit resolves it.
local function collect_units(item, breed_name, out, depth)
  if type(item) == "string" then
    item = item ~= "" and MasterItems.get_item(item) or nil
  end
  if type(item) ~= "table" or depth > 10 then return end

  local breed_unit = type(item.breed_base_unit) == "table" and item.breed_base_unit[breed_name]
  local unit_3p = (type(breed_unit) == "string" and breed_unit ~= "") and breed_unit or item.base_unit

  if type(unit_3p) == "string" and unit_3p ~= "" then out[unit_3p] = true end
  if type(item.base_unit_1p) == "string" and item.base_unit_1p ~= "" then out[item.base_unit_1p] = true end

  for _, att in pairs(type(item.attachments) == "table" and item.attachments or {}) do
    if type(att) == "table" then
      collect_units(att.item, breed_name, out, depth + 1)
      for _, child in pairs(type(att.children) == "table" and att.children or {}) do
        if type(child) == "table" then collect_units(child.item, breed_name, out, depth + 1) end
      end
    end
  end
end

-- Ready means: every dependency is loaded under Dio's Wardrobe's own pin, and every unit
-- the spawn will request can actually be fetched. The dependency list alone was not
-- enough: in testing, a customized item passed it and then failed to spawn a unit
-- ("Unit not found"), leaving the equip half done.
local function item_ready(item, breed_name)
  for name in pairs(item_packages(item)) do
    if not Managers.package:has_loaded(name) and not mod:wd_is_pinned(name) then
      return false, "package " .. name
    end
  end

  local units = {}
  collect_units(item, breed_name, units, 0)

  for unit_name in pairs(units) do
    if not Application.can_get_resource("unit", unit_name) then
      return false, "unit " .. unit_name
    end
  end

  return true
end

local function husk_breed(ext)
  local props = ext._static_profile_properties
  return props and props.breed
end

-- What Dio's Wardrobe loads for another player's outfit: only packages and units that are
-- not already loaded. Whatever the game has loaded for that player (their face, their real
-- gear) stays the game's to load and unload. Pinning those as well tied their lifetime to
-- Dio's Wardrobe and was part of the crash when a player left.
local function missing_for(item, breed_name, out)
  for name in pairs(item_packages(item)) do
    if not Managers.package:has_loaded(name) then out[name] = true end
  end

  local units = {}
  collect_units(item, breed_name, units, 0)
  for unit_name in pairs(units) do
    if not Application.can_get_resource("unit", unit_name) and mod:wd_is_known_package(unit_name) then
      out[unit_name] = true
    end
  end

  return out
end

-- Load callbacks never touch a character. A callback runs whenever the load finishes,
-- possibly while that player is leaving, and anything spawned inside it is charged to the
-- callback: that is exactly the "Load Callback->..._pin" holder seen in the crash.
-- A callback only marks the player as ready; the next regular update does the rebuild,
-- after checking the player is still here.
local function mark_ready(account_id)
  local peer = account_id and Share.peers[account_id]
  if peer and peer.wait_slots then
    peer.ready_slots = peer.ready_slots or {}
    for slot_name in pairs(peer.wait_slots) do
      peer.ready_slots[slot_name] = true
    end
    peer.wait_slots = nil
    Share.poll_now = true
  end
end

-- As soon as an outfit is known, start loading every item it names (extra attachments,
-- including enemy gear from Dio's Wardrobe Extra, which this client would otherwise never
-- load). By the time the player's gear is built the units are usually ready, and if not,
-- the build waits for them instead of failing.
local function prefetch_outfit(hash, outfit)
  if Share.prefetched[hash] then return end
  Share.prefetched[hash] = true

  local names = {}
  for item_name, data in pairs(outfit.gear_customization_data or {}) do
    names[item_name] = true
    for att_item in pairs(type(data.attachments) == "table" and data.attachments or {}) do
      names[att_item] = true
    end
  end

  local to_load = {}
  for name in pairs(names) do
    local item = MasterItems.get_item(name)
    if item then
      missing_for(item, nil, to_load)
    end
  end

  mod:wd_pin_all(to_load, function()
    for account_id, peer in pairs(Share.peers) do
      if peer.hash == hash then mark_ready(account_id) end
    end
    for key in pairs(Share.load_attempts) do Share.load_attempts[key] = nil end
  end)
end

-- The husk extension of a player who is still in the game, or nil. A destroyed husk
-- unregisters its extension, so this also rejects a player who is leaving.
local function live_husk(player)
  if not player or not find_player(player:account_id()) then return nil end

  local unit = player.player_unit
  if not unit or not Unit.alive(unit) then return nil end

  local ext = ScriptUnit.has_extension(unit, "visual_loadout_system")
  if not ext or not ext.is_husk or not ext._equipment then return nil end

  return ext
end

---------------------------------------------------------------------------
-- spawn tracking
--
-- A spawn that fails part way ("Unit not found") leaves the units it already made attached
-- to the character, but the slot never records them, so the game never removes them. When
-- that player left, the stray units kept their resources in use and the game crashed
-- unloading them ("Trying to unload resource ... that's used elsewhere", after "Unit ...
-- has still childs attached"). Every attempt to build another player's gear now records
-- what it spawns, and on failure removes whatever no slot owns.
---------------------------------------------------------------------------

local function run_tracked(fn, ...)
  local spawner = Managers.state and Managers.state.unit_spawner
  local spawned = {}
  local own = spawner and rawget(spawner, "spawn_unit")
  local base = spawner and spawner.spawn_unit

  if spawner and base then
    spawner.spawn_unit = function(self, ...)
      local unit = base(self, ...)
      spawned[#spawned + 1] = unit
      return unit
    end
  end

  local args = { n = select("#", ...), ... }
  local ok, err = xpcall(function() return fn(unpack(args, 1, args.n)) end, debug.traceback)

  if spawner and base then
    spawner.spawn_unit = own
  end

  return ok, err, spawned
end

local function owned_units(ext)
  local owned = {}

  for _, slot in pairs(ext._equipment or {}) do
    if slot.unit_3p then owned[slot.unit_3p] = true end
    if slot.unit_1p then owned[slot.unit_1p] = true end
    for _, by_unit in pairs({ slot.attachments_by_unit_3p, slot.attachments_by_unit_1p }) do
      for _, list in pairs(by_unit or {}) do
        for _, unit in pairs(list) do owned[unit] = true end
      end
    end
  end

  return owned
end

local function discard_strays(ext, spawned)
  if #spawned == 0 then return 0 end

  local spawner = Managers.state and Managers.state.unit_spawner
  local owned = owned_units(ext)
  local removed = 0

  for i = #spawned, 1, -1 do
    local unit = spawned[i]
    if unit and not owned[unit] and Unit.alive(unit) then
      pcall(function() World.unlink_unit(Unit.world(unit), unit) end)
      if spawner then
        pcall(spawner.mark_for_deletion, spawner, unit)
      end
      removed = removed + 1
    end
  end

  return removed
end

-- first line of an error, for the one-line warnings; the full traceback goes to the log once
local function short_err(err)
  local s = tostring(err)
  return s:match("^[^\n]*") or s
end

-- Rebuilds one slot through the same two handlers the game runs when a player changes
-- gear mid-mission, so unequip/equip bookkeeping (fx, dialogue, visibility) is the game's
-- own. The equip passes through the husk hook, which applies the outfit.
-- Rebuilding a slot has to take its dependent slots with it, in the order the game uses
-- (this is what the game's UIProfileSpawner does). The face carries twelve: hair, beard,
-- head gear, eyes, tattoos, scars, skin and hair colour, makeup. Swapping the face without
-- them left those units attached to the destroyed face; they kept using the face's
-- animation package, and the game crashed unloading it when that player left.
local function reequip_slot(ext, player, slot_name)
  local slot = ext._equipment[slot_name]
  local profile = player:profile()
  local item = profile and profile.visual_loadout and profile.visual_loadout[slot_name]

  if not slot or not item then return end

  local comp = ext._equipment_component
  local config = ext._slot_configuration and ext._slot_configuration[slot_name]
  local dependents = {}

  if config and config.slot_dependencies then
    -- the game returns a shared scratch table, so copy it before anything else runs
    local unequipped = comp:unequip_slot_dependencies(config, ext._equipment, SLOT_EQUIP_ORDER)
    for dep_slot, dep_item in pairs(unequipped or {}) do
      dependents[dep_slot] = dep_item
    end
  end

  local slot_id = NetworkLookup.player_inventory_slot_names[slot_name]
  local item_id = NetworkLookup.player_item_names[item.name]
  local go_id = ext._game_object_id

  if slot_id and item_id and go_id then
    if slot.item then
      ext:rpc_player_unequip_item_from_slot(nil, go_id, slot_id)
    end
    ext:rpc_player_equip_item_from_profile_to_slot(nil, go_id, slot_id, item_id)
  else
    if slot.item then
      comp:unequip_item(slot)
    end
    ext:_equip_item_to_slot(slot_name, item)
  end

  -- put the dependents back on the new unit, in equip order
  for i = 1, #SLOT_EQUIP_ORDER do
    local dep_slot = SLOT_EQUIP_ORDER[i]
    local dep_item = dependents[dep_slot]
    local dep = dep_item and ext._equipment[dep_slot]

    if dep and not dep.item then
      ext:_equip_item_to_slot(dep_slot, dep_item)
    end
  end
end

-- The game may still be loading a player's real gear, for instance just after they
-- switch character. Rebuilding before that finishes spawns units that do not exist yet
-- ("Unit not found"), so wait until every slot's real item, and each item attached to the
-- face, is loaded.
-- reequip_slot with a way back. If the rebuild fails, remove whatever it left unowned, then
-- put the player's normal item (and the face's dependents) back without customizing, so a
-- failure costs that slot's outfit and never leaves the character half built.
local function safe_reequip_slot(ext, player, slot_name)
  local ok, err, spawned = run_tracked(reequip_slot, ext, player, slot_name)
  if ok then return true end

  -- a slot the failed spawn marked equipped but never got a unit for
  local slot = ext._equipment[slot_name]
  if slot and slot.item and not (slot.unit_3p and Unit.alive(slot.unit_3p)) then
    pcall(ext._equipment_component.unequip_item, ext._equipment_component, slot)
  end

  discard_strays(ext, spawned)

  local profile = player:profile()
  local visual_loadout = profile and profile.visual_loadout

  Share.plain_equip = true
  local ok2, err2, spawned2 = run_tracked(function()
    for i = 1, #SLOT_EQUIP_ORDER do
      local name = SLOT_EQUIP_ORDER[i]
      local wanted = name == slot_name or (slot_name == "slot_body_face" and ext._slot_configuration.slot_body_face.slot_dependencies and table.contains(ext._slot_configuration.slot_body_face.slot_dependencies, name))
      local slot = wanted and ext._equipment[name]
      local item = slot and visual_loadout and visual_loadout[name]
      if slot and item and not slot.item then
        ext:_equip_item_to_slot(name, item)
      end
    end
  end)
  Share.plain_equip = false

  if not ok2 then
    discard_strays(ext, spawned2)
    mod:warning("[Dio's Wardrobe] Could not restore another player's %s either: %s", slot_name, short_err(err2))
  end

  error(err, 0)
end

-- True once every slot this player has equipped has finished spawning. The game streams
-- other players' gear in; rebuilding a slot whose packages are still arriving is what the
-- "Unit not found" failure looked like.
local function slots_settled(ext)
  local comp = ext._equipment_component
  for _, slot in pairs(ext._equipment or {}) do
    if slot.equipped then
      local status = slot.attachment_spawn_status
      if status ~= nil and status ~= "fully_spawned" then
        return false, "slot " .. tostring(slot.name) .. " " .. tostring(status)
      end
      if comp and comp._has_slot_package_streaming and comp._slot_is_loaded then
        local ok, loaded = pcall(comp._slot_is_loaded, comp, slot)
        if ok and not loaded then
          return false, "slot " .. tostring(slot.name) .. " loading"
        end
      end
    end
  end
  return true
end

local function player_gear_ready(ext, player)
  local profile = player:profile()
  local visual_loadout = profile and profile.visual_loadout
  if not visual_loadout then return false end

  local settled, why = slots_settled(ext)
  if not settled then return false, why end

  local breed = husk_breed(ext)

  for _, slot_name in ipairs(PEER_SLOT_ORDER) do
    local item = visual_loadout[slot_name]
    if item then
      local ready, missing = item_ready(item, breed)
      if not ready then return false, missing end
    end
  end

  local face_config = ext._slot_configuration and ext._slot_configuration.slot_body_face
  for _, dep_slot in ipairs(face_config and face_config.slot_dependencies or {}) do
    local item = visual_loadout[dep_slot]
    if type(item) == "table" then
      local ready, missing = item_ready(item, breed)
      if not ready then return false, missing end
    end
  end

  return true
end

local function refresh_player(player)
  local ext = live_husk(player)
  if not ext then return false end

  if not player_gear_ready(ext, player) then
    -- try again shortly; nothing is touched meanwhile
    Share.retry_at = Share.clock + 2
    return false
  end

  for _, slot_name in ipairs(PEER_SLOT_ORDER) do
    local ok, err = pcall(safe_reequip_slot, ext, player, slot_name)
    if not ok then
      warn_once("refresh_" .. tostring(player:account_id()) .. slot_name .. tostring(err), "[Dio's Wardrobe] Could not refresh another player's %s: %s", slot_name, tostring(err))
    end
  end

  return true
end

local function schedule_package_load(custom_item, player, slot_name, hash, missing, breed_name)
  local key = tostring(player:account_id()) .. slot_name .. tostring(hash)
  local attempts = (Share.load_attempts[key] or 0) + 1
  Share.load_attempts[key] = attempts

  if attempts > 2 then
    warn_once("pkg" .. key, "[Dio's Wardrobe] Gave up loading %s for another player's outfit (missing %s).", slot_name, tostring(missing))
    return
  end

  -- whatever is missing, including units absent from the dependency list (the enemy
  -- helmet case); the rebuild itself happens in the next update, never in the callback
  local account_id = player:account_id()
  local peer = Share.peers[account_id]
  if peer then
    peer.wait_slots = peer.wait_slots or {}
    peer.wait_slots[slot_name] = true
  end

  mod:wd_pin_all(missing_for(custom_item, breed_name, {}), function()
    mark_ready(account_id)
  end)
end

-- Body slots under shirtless / pantless / hidden gear. Mirrors what hooks.lua does for
-- the local player, using the husk's own equip.
local function equip_missing_body_slots(func, ext, player, slot_name, outfit, tag)
  local loadout = player:profile() and player:profile().loadout
  if not loadout then return end

  local wanted = mod:with_peer_context(outfit, player, ext, tag, function()
    local w = {}
    if slot_name == "slot_gear_upperbody" then
      if mod:show_arms_slot(ext) then w[#w + 1] = "slot_body_arms" end
      if mod:show_body_slot(ext) then w[#w + 1] = "slot_body_torso" end
    elseif slot_name == "slot_gear_lowerbody" then
      if mod:show_legs_slot(ext) then w[#w + 1] = "slot_body_legs" end
    end
    return w
  end) or {}

  for _, body_slot in ipairs(wanted) do
    local slot = ext._equipment[body_slot]
    if slot and not slot.item and loadout[body_slot] then
      local body_item = mod:prepare_body_slot_item(loadout, body_slot)
      if item_ready(body_item, husk_breed(ext)) then
        func(ext, body_slot, body_item)
      end
    end
  end
end

mod:hook(CLASS.PlayerHuskVisualLoadoutExtension, "_equip_item_to_slot", function(func, self, slot_name, item, optional_existing_unit_3p)
  local custom, outfit, peer, tag = nil, nil, nil, nil
  local player = self._player

  if item and PEER_SLOTS[slot_name] and player and player.account_id and not Share.plain_equip then
    outfit, peer = outfit_for_player(player)

    if outfit then
      tag = short_id(player:account_id())
      custom = mod:with_peer_context(outfit, player, self, tag, function()
        return mod:make_custom_item(slot_name, table.clone_instance(item), "husk")
      end)

      local broken_key = custom and (tag .. slot_name .. tostring(peer.hash))

      if custom and Share.broken[broken_key] then
        custom = nil
      elseif custom then
        local ready, missing = item_ready(custom, husk_breed(self))
        if not ready then
          schedule_package_load(custom, player, slot_name, peer.hash, missing, husk_breed(self))
          custom = nil
        end
      end

      if custom then
        -- Last line of defence. If the customized item still fails to spawn, clear
        -- whatever part of it did spawn and fall back to the player's real item, so a
        -- failure costs their outfit on that slot and never leaves stray units behind.
        local ok, err, spawned = run_tracked(func, self, slot_name, custom, optional_existing_unit_3p)

        if ok then
          if peer.applied_hash ~= peer.hash then
            mod:info("[Dio's Wardrobe] Showing %s's outfit on their %s", tostring(peer.name or "?"), slot_name)
          end
          peer.applied_hash = peer.hash
          peer.applied_unit = self._unit

          local body_ok, body_err = pcall(equip_missing_body_slots, func, self, player, slot_name, outfit, tag)
          if not body_ok then
            warn_once("body" .. broken_key, "[Dio's Wardrobe] Could not show another player's body slots: %s", tostring(body_err))
          end

          return
        end

        Share.broken[broken_key] = true
        warn_once("equip" .. broken_key, "[Dio's Wardrobe] Another player's %s could not be built, showing their normal gear instead: %s", slot_name, tostring(err))

        local slot = self._equipment[slot_name]
        if slot and slot.item then
          pcall(self._equipment_component.unequip_item, self._equipment_component, slot)
        end
        discard_strays(self, spawned)
      end
    end
  end

  -- Crash guard (2026-10-04): another player's own gear can arrive before its package is loaded
  -- ("Unit not found" in unit_spawner_manager.lua:586 from spawn_item_attachments), which took the whole game
  -- down. Catch it, clear what spawned, and leave that slot empty instead of crashing.
  local ok, err, spawned = run_tracked(func, self, slot_name, item, optional_existing_unit_3p)
  if not ok then
    warn_once("plain" .. tostring(slot_name) .. tostring(item and item.name), "[Dio's Wardrobe] Another player's %s could not be spawned yet (package not loaded), skipped: %s", tostring(slot_name), tostring(err):sub(1, 200))
    local slot = self._equipment and self._equipment[slot_name]
    if slot and slot.item then
      pcall(self._equipment_component.unequip_item, self._equipment_component, slot)
    end
    discard_strays(self, spawned)
  end
end)

-- The husk hook records applied_hash / applied_unit whenever it customizes gear, which
-- covers a player who spawns after their outfit is known. This handles the rest: an
-- outfit that arrives or changes after spawn, and reverting one that went away.
-- pending_* stops the same refresh being issued every poll while packages load.
local function apply_peers()
  for account_id, peer in pairs(Share.peers) do
    if viewing_enabled() and peer.hash and Share.cache[peer.hash] then
      local ok, err = pcall(prefetch_outfit, peer.hash, Share.cache[peer.hash])
      if not ok then
        warn_once("prefetch" .. peer.hash, "[Dio's Wardrobe] Could not preload another player's outfit: %s", tostring(err))
      end
    end

    local player = find_player(account_id)
    local ext = player and live_husk(player)
    local unit = ext and player.player_unit

    if unit then
      local target = viewing_enabled() and peer.hash and Share.cache[peer.hash] and peer.hash or nil

      if target and peer.ready_slots then
        -- slots that fell back earlier and whose resources have now loaded
        local slots = peer.ready_slots
        peer.ready_slots = nil
        for _, slot_name in ipairs(PEER_SLOT_ORDER) do
          if slots[slot_name] then
            local ok, err = pcall(safe_reequip_slot, ext, player, slot_name)
            if not ok then
              warn_once("ready" .. account_id .. slot_name .. tostring(err), "[Dio's Wardrobe] Could not rebuild another player's %s: %s", slot_name, tostring(err))
            end
          end
        end
      end

      if target then
        local applied = peer.applied_hash == target and peer.applied_unit == unit
        local pending = peer.pending_hash == target and peer.pending_unit == unit

        if not applied and not pending and refresh_player(player) then
          peer.pending_hash, peer.pending_unit = target, unit
        end
      elseif peer.applied_hash then
        if refresh_player(player) then
          peer.applied_hash, peer.applied_unit = nil, nil
          peer.pending_hash, peer.pending_unit = nil, nil
        end
      end
    end
  end
end

---------------------------------------------------------------------------
-- reading other members
---------------------------------------------------------------------------

local function accept_chunk(hash, n, i, c, who)
  if type(n) ~= "number" or n < 1 or n > MAX_CHUNKS or n % 1 ~= 0 then return end
  if type(i) ~= "number" or i < 1 or i > n or i % 1 ~= 0 then return end
  if type(c) ~= "string" or #c == 0 or #c > CHUNK_CHARS then return end

  local col = Share.collecting[hash]
  if not col or col.n ~= n then
    col = { n = n, parts = {}, have = 0, who = who or "?", started = Share.clock, reported = Share.clock }
    Share.collecting[hash] = col
    mod:info("[Dio's Wardrobe] Receiving %s's outfit (%s, %d pieces)", col.who, hash, n)
  end

  if not col.parts[i] then
    col.parts[i] = c
    col.have = col.have + 1
    Share.t_stall = 0
  end

  if col.have < col.n then return end

  Share.collecting[hash] = nil
  mod:info("[Dio's Wardrobe] Received %s's outfit (%s, %d pieces) in %.0fs", col.who, hash, col.n, Share.clock - col.started)

  local packed = table.concat(col.parts, "", 1, col.n)
  local outfit, err = decode_packed(hash, packed)

  if not outfit then
    Share.bad_hash[hash] = true
    warn_once("bad" .. hash, "[Dio's Wardrobe] Discarded a shared outfit that failed to verify (%s).", tostring(err))
    return
  end

  Share.cache[hash] = sanitize_outfit(outfit)
  save_to_disk(hash, packed)
end

local function process_members()
  local Manifold = Share.manifold
  if not Manifold then return end

  local members = Manifold.members()
  local seen = {}
  local want = nil
  local requested_from_me = false

  for i = 1, #members do
    local member = members[i]

    local member_name = "?"
    pcall(function() member_name = member:name() or "?" end)

    if not Manifold.is_myself(member) and not Manifold.has_mod(member, ID) then
      local account_id = member.account_id and member:account_id()
      if account_id and not Share.noted_without[account_id] then
        Share.noted_without[account_id] = true
        mod:info("[Dio's Wardrobe] %s is not running this version of Dio's Wardrobe (older For the Drip builds cannot be seen)", member_name)
      end
      if account_id then
        Share.roster[account_id] = { name = member_name, running = false }
      end
    end

    if not Manifold.is_myself(member) and Manifold.has_mod(member, ID) then
      local account_id = member.account_id and member:account_id()
      local p = Manifold.get(member, ID)
      if account_id then
        Share.roster[account_id] = { name = member_name, running = true }
        Share.noted_without[account_id] = nil
      end

      if account_id and type(p) == "table" and p.p == PAYLOAD_VERSION then
        seen[account_id] = true

        if p.w and p.w == Share.my.hash then
          requested_from_me = true
        end

        if p.q ~= Share.vocab.hash then
          warn_once("vocab" .. account_id, "[Dio's Wardrobe] A party member runs a different version of Dio's Wardrobe's material data; their outfit cannot be shown.")
        else
          local peer = Share.peers[account_id] or {}
          Share.peers[account_id] = peer

          local hash = type(p.h) == "string" and p.h or nil
          if peer.hash ~= hash or peer.name == nil then
            if hash then
              mod:info("[Dio's Wardrobe] %s is sharing an outfit (%s, %s pieces)%s", member_name, hash, tostring(p.n), Share.cache[hash] and ", already have it" or "")
            else
              mod:info("[Dio's Wardrobe] %s runs Dio's Wardrobe but is not sharing an outfit (nothing customized, or sharing turned off)", member_name)
            end
          end
          peer.name = member_name
          peer.hash = hash
          peer.k = type(p.k) == "string" and p.k or nil

          if hash and not Share.cache[hash] and not Share.bad_hash[hash] then
            local from_disk = load_from_disk(hash)

            if from_disk then
              Share.cache[hash] = sanitize_outfit(from_disk)
            else
              if p.i and p.c then
                local who = "?"
                pcall(function() who = member:name() or "?" end)
                accept_chunk(hash, p.n, p.i, p.c, who)
              end

              if not Share.cache[hash] and not want then
                want = hash
              end
            end
          end
        end
      elseif account_id and p == false then
        -- runs Dio's Wardrobe with sharing off: treat as no outfit
        seen[account_id] = true
        local peer = Share.peers[account_id] or {}
        Share.peers[account_id] = peer
        peer.hash = nil
      end
    end
  end

  for account_id in pairs(Share.peers) do
    if not seen[account_id] then
      Share.peers[account_id] = nil
    end
  end

  -- progress line every 30s per transfer, so a stuck one shows up in the log
  for hash, col in pairs(Share.collecting) do
    if Share.clock - col.reported >= 30 then
      col.reported = Share.clock
      local missing = {}
      for idx = 1, col.n do
        if not col.parts[idx] then missing[#missing + 1] = idx end
      end
      mod:info("[Dio's Wardrobe] Receiving %s's outfit: %d/%d pieces after %.0fs, missing %s", col.who, col.have, col.n, Share.clock - col.started, table.concat(missing, ",", 1, math.min(#missing, 20)))
    end
  end

  -- drop half-received outfits nobody is sending any more
  for hash in pairs(Share.collecting) do
    local still_wanted = false
    for _, peer in pairs(Share.peers) do
      if peer.hash == hash then still_wanted = true break end
    end
    if not still_wanted then Share.collecting[hash] = nil end
  end

  if not viewing_enabled() then
    want = nil
  end

  local my = Share.my
  local cycling = requested_from_me and sharing_enabled() and my.n > 0

  if want ~= Share.want or cycling ~= my.cycling then
    if want ~= Share.want then
      Share.t_stall = 0
      state_changed()
    end
    Share.want = want
    my.cycling = cycling
    Manifold.mark_dirty(ID)
  end

  apply_peers()
end

---------------------------------------------------------------------------
-- lifecycle
---------------------------------------------------------------------------

local function update(dt)
  if not Share.manifold then return end
  dt = dt or 0

  if Share.my_dirty then
    Share.t_rebuild = Share.t_rebuild + dt
  end
  if Share.my_dirty and Share.t_rebuild >= REBUILD_DELAY then
    Share.t_rebuild = 0
    local ok, err = pcall(rebuild_my_outfit)
    if not ok then
      warn_once("rebuild", "[Dio's Wardrobe] Could not prepare your outfit for sharing: %s", tostring(err))
    end
  end

  -- Other players are read when Vox Manifold says something changed, and every second
  -- only while a transfer is in progress in either direction. Otherwise nothing runs.
  Share.clock = Share.clock + dt
  if Share.retry_at and Share.clock >= Share.retry_at then
    Share.retry_at = nil
    Share.poll_now = true
  end

  local transferring = Share.want ~= nil or Share.my.cycling or next(Share.collecting) ~= nil
  Share.t_poll = Share.t_poll + dt
  if Share.poll_now or (transferring and Share.t_poll >= POLL_INTERVAL) then
    Share.t_poll = 0
    Share.poll_now = false
    local ok, err = pcall(process_members)
    if not ok then
      warn_once("process", "[Dio's Wardrobe] Outfit sharing error: %s", tostring(err))
    end
  end

  local resend = false

  if Share.reinforce > 0 then
    Share.t_reinforce = Share.t_reinforce + dt
    if Share.t_reinforce >= REINFORCE_INTERVAL then
      Share.t_reinforce = 0
      Share.reinforce = Share.reinforce - 1
      resend = true
    end
  end

  if Share.want then
    Share.t_stall = Share.t_stall + dt
    if Share.t_stall >= STALL_RESEND then
      Share.t_stall = 0
      resend = true
    end
  end

  if resend then
    Share.r = (Share.r + 1) % 36
    Share.manifold.mark_dirty(ID)
  end

  local my = Share.my
  if my.cycling and my.n > 0 then
    Share.t_cycle = Share.t_cycle + dt
    if Share.t_cycle >= CYCLE_INTERVAL then
      Share.t_cycle = 0
      my.pos = (my.pos % my.pass_len) + 1
      my.index = ((my.pos - 1) % my.n) + 1
      Share.manifold.mark_dirty(ID)
    end
  end
end

local function start()
  local vox = get_mod("Vox Manifold")
  local Manifold = vox and vox.api

  if not Manifold then
    mod:info("[Dio's Wardrobe] Vox Manifold not found; outfit sharing is off.")
    return
  end

  local ok, vocab = pcall(build_vocab)
  if not ok then
    mod:error("[Dio's Wardrobe] Could not build the sharing vocabulary: %s", tostring(vocab))
    return
  end
  Share.vocab = vocab

  local registered, err = Manifold.register(ID, mod, build_payload)
  if not registered then
    mod:error("[Dio's Wardrobe] Could not register with Vox Manifold: %s", tostring(err))
    return
  end

  Share.manifold = Manifold
  Share.unsubscribe = Manifold.on_update(ID, function()
    Share.poll_now = true
  end)
  Share.my_dirty = true

  mod:info("[Dio's Wardrobe] Outfit sharing on (Vox Manifold, vocabulary %s, %d strings)", vocab.hash, #vocab.list)
end

local function stop()
  if Share.manifold then
    Share.manifold.unregister(ID)
  end
  if Share.unsubscribe then
    Share.unsubscribe()
  end
  Share.manifold, Share.unsubscribe = nil, nil
end

-- chain onto Dio's Wardrobe's own callbacks rather than replacing them
local previous_all_mods_loaded = mod.on_all_mods_loaded
mod.on_all_mods_loaded = function(...)
  if previous_all_mods_loaded then previous_all_mods_loaded(...) end
  Share.all_mods_loaded = true
  start()
end

local previous_update = mod.update
mod.update = function(dt, ...)
  if previous_update then previous_update(dt, ...) end
  update(dt)
end

local previous_setting_changed = mod.on_setting_changed
mod.on_setting_changed = function(setting_id, ...)
  if previous_setting_changed then previous_setting_changed(setting_id, ...) end
  if setting_id == "share_my_outfit" or setting_id == "show_others_outfits" then
    Share.my.cycling = false
    state_changed()
    if Share.manifold then Share.manifold.mark_dirty(ID) end
    -- re-evaluated on the next update; show_others_outfits off reverts everyone
    Share.poll_now = true
  end
end

mod.on_unload = function()
  stop()
end

mod.on_disabled = function()
  stop()
end

mod.on_enabled = function()
  -- DMF also calls this while mods are still loading, before Vox Manifold exists;
  -- start() then runs from on_all_mods_loaded instead
  if Share.all_mods_loaded and not Share.manifold then
    start()
  end
end

mod:command("wardrobe_status", "Show what Dio's Wardrobe is sharing and receiving", function()
  local my = Share.my
  if not Share.manifold then
    mod:echo("Dio's Wardrobe: outfit sharing is off (Vox Manifold missing?)")
    return
  end
  mod:echo("Your outfit: %s", my.hash and (my.n .. " pieces" .. (my.cycling and ", sending now" or "")) or "none (nothing customized on this character)")
  local any = false
  for account_id, r in pairs(Share.roster) do
    any = true
    if not r.running then
      mod:echo("%s: not running this version of Dio's Wardrobe", r.name)
    else
      local peer = Share.peers[account_id]
      local hash = peer and peer.hash
      if not hash then
        mod:echo("%s: runs it, no outfit shared", r.name)
      elseif Share.cache[hash] then
        mod:echo("%s: outfit received, %s", r.name, peer.applied_hash == hash and "showing" or "waiting to show (their gear may still be loading)")
      else
        local col = Share.collecting[hash]
        mod:echo("%s: receiving outfit, %s", r.name, col and (col.have .. "/" .. col.n .. " pieces") or "waiting for them to start sending")
      end
    end
  end
  if not any then
    mod:echo("No party members seen. Outfits are shared with players in your party (strike team), not strangers.")
  end
end)

-- Your outfit is packed on entering the Mourningstar or a mission (both run through
-- StateGameplay), not on every edit. Changes made in between go out at the next
-- transition.
local previous_state_changed = mod.on_game_state_changed
mod.on_game_state_changed = function(status, state_name, ...)
  if previous_state_changed then previous_state_changed(status, state_name, ...) end
  if status == "enter" and state_name == "StateGameplay" then
    Share.my_dirty = true
    Share.t_rebuild = 0
  end
end

-- exposed for testing
Share._build_payload = build_payload
Share._build_wire_outfit = build_wire_outfit
Share._rebuild = rebuild_my_outfit
Share._process = process_members
Share._build_vocab = build_vocab
Share._start = start
