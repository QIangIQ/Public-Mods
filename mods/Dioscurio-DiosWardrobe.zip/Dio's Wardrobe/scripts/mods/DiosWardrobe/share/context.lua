local mod = get_mod("DiosWardrobe")

--[[
  WHOSE OUTFIT IS BEING BUILT

  make_custom_item was written for the local player only: it reads mod.current_slots_data
  and the local player's profile. To build another player's outfit it runs inside a
  context that swaps those for the other player's, then restores them, even on error.

  Outside a context every helper here answers exactly as the original code did.
--]]

mod._ctx = nil

mod.ctx_player = function(self)
  if mod._ctx then
    return mod._ctx.player
  end

  return Managers.player and Managers.player:local_player_safe(1)
end

mod.ctx_owner_tag = function(self)
  return mod._ctx and mod._ctx.tag or "me"
end

mod.in_peer_context = function(self)
  return mod._ctx ~= nil
end

-- Replaces utils.lua's version, which always returned the local player's extension.
mod.get_visual_loadout_extension = function()
  if mod._ctx then
    return mod._ctx.visual_loadout_extension
  end

  local player = Managers.player:local_player_safe(1)

  if player and player.player_unit then
    return ScriptUnit.has_extension(player.player_unit, "visual_loadout_system")
  end

  return nil
end

-- Runs fn with another player's outfit active. Returns fn's result, or nil if it threw.
mod.with_peer_context = function(self, outfit, player, visual_loadout_extension, tag, fn)
  local saved = {
    slots = mod.current_slots_data,
    selected_unit_slot = mod.selected_unit_slot,
    selected_extra_attach = mod.selected_extra_attach,
    ctx = mod._ctx,
  }

  -- make_custom_item writes into the data it reads, so it always gets a fresh copy
  mod.current_slots_data = table.clone(outfit)
  mod.selected_unit_slot = "none"
  mod.selected_extra_attach = ""
  mod._ctx = {
    player = player,
    visual_loadout_extension = visual_loadout_extension,
    tag = tag,
  }

  local ok, result = pcall(fn)

  mod.current_slots_data = saved.slots
  mod.selected_unit_slot = saved.selected_unit_slot
  mod.selected_extra_attach = saved.selected_extra_attach
  mod._ctx = saved.ctx

  if not ok then
    mod:error("Could not build another player's outfit: %s", tostring(result))
    return nil
  end

  return result
end
