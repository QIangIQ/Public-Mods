local mod = get_mod("DiosWardrobe")

--[[
  PLAYER-HOSTED SERVERS (Realms)

  On Fatshark's servers the local player's unit is only a client-side copy, so nothing Dio's
  Wardrobe equips on it ever leaves this machine. When this machine is the host, the local
  player's unit is the real one: whenever it equips a slot, and whenever a player joins,
  the game tells every client "equip slot X from this player's profile, item Y". Each
  client looks slot X up in its own copy of the host's profile and crashes if it is not
  there ("Profile item mismatch ... Client item was N/A").

  Dio's Wardrobe equips body slots (torso, arms, legs) that the plain profile does not have,
  so a host wearing a shirtless or hidden-gear outfit crashed everyone who joined.

  While a player unit on this host is sending those messages, each one is checked against
  the plain visual loadout, the one every client builds for that profile:
    equip   - slot not in it: dropped. Otherwise sent with the plain item's id.
    unequip - slot not in it: dropped.
  Only the outgoing messages change. What the host itself sees is untouched.
--]]

local ProfileUtils = require("scripts/utilities/profile_utils")

local Guard = { player = nil }

local function pack(...)
  return { n = select("#", ...), ... }
end

local EQUIP_RPC = "rpc_player_equip_item_from_profile_to_slot"
local UNEQUIP_RPC = "rpc_player_unequip_item_from_slot"

local ADDED_SLOTS = {
  slot_body_torso = true,
  slot_body_arms = true,
  slot_body_legs = true,
  slot_body_eye_color = true,
}

local function COSMETIC_PREFIX(slot_name)
  return slot_name:sub(1, 10) == "slot_body_" or slot_name:sub(1, 10) == "slot_gear_"
end

local function native_visual_loadout(player)
  local profile = player and player:profile()
  local loadout = profile and profile.loadout
  if not loadout then return nil end

  mod._wd_native_visual_loadout = true
  local ok, result = pcall(ProfileUtils.generate_visual_loadout, loadout)
  mod._wd_native_visual_loadout = false

  return ok and result or nil
end

-- Returns false to drop the message, or true plus the item id to send.
local function check(rpc_name, slot_id, item_id)
  local player = Guard.player
  if not player then return true, item_id end

  local slot_name = NetworkLookup.player_inventory_slot_names[slot_id]
  local native = native_visual_loadout(player)
  if not slot_name or not native then return true, item_id end

  local native_item = native[slot_name]

  -- only the body slots Dio's Wardrobe adds can be missing; weapons, pocketables and the
  -- rest are never touched
  if not native_item then
    if ADDED_SLOTS[slot_name] then
      return false
    end
    return true, item_id
  end

  if rpc_name == EQUIP_RPC and COSMETIC_PREFIX(slot_name) then
    local native_id = native_item.name and NetworkLookup.player_item_names[native_item.name]
    return true, native_id or item_id
  end

  return true, item_id
end

local function guarded(func, self, ...)
  if not self._is_server then
    return func(self, ...)
  end

  local outer = Guard.player
  Guard.player = self._player

  local results = pack(pcall(func, self, ...))

  Guard.player = outer

  if not results[1] then
    error(results[2], 0)
  end

  return unpack(results, 2, results.n)
end

for _, method in ipairs({ "game_object_initialized", "equip_item_to_slot", "unequip_item_from_slot" }) do
  mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, method, function(func, self, ...)
    return guarded(func, self, ...)
  end)
end

-- hot_join_sync sends through RPC directly instead of the game session
mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, "hot_join_sync", function(func, self, ...)
  if not self._is_server or type(RPC) ~= "table" then
    return func(self, ...)
  end

  local orig_equip = RPC[EQUIP_RPC]

  local ok_patch = pcall(function()
    RPC[EQUIP_RPC] = function(channel, go_id, slot_id, item_id, ...)
      local send, id = check(EQUIP_RPC, slot_id, item_id)
      if send then
        return orig_equip(channel, go_id, slot_id, id, ...)
      end
    end
  end)

  local results = pack(pcall(guarded, func, self, ...))

  if ok_patch then
    RPC[EQUIP_RPC] = orig_equip
  end

  if not results[1] then
    error(results[2], 0)
  end

  return unpack(results, 2, results.n)
end)

mod:hook(CLASS.GameSessionManager, "send_rpc_clients_except", function(func, self, rpc_name, except_channel_id, go_id, slot_id, item_id, ...)
  if Guard.player and (rpc_name == EQUIP_RPC or rpc_name == UNEQUIP_RPC) then
    local send, id = check(rpc_name, slot_id, item_id)
    if not send then
      return
    end
    if rpc_name == EQUIP_RPC then
      item_id = id
    end
  end

  return func(self, rpc_name, except_channel_id, go_id, slot_id, item_id, ...)
end)
