--[[
  Wire format for sharing outfits over Vox Manifold.

  Pure Lua, no game calls, so it can be tested outside the game.

    serialize(t, vocab)    table  -> compact text. Strings found in the shared vocabulary
                                     are written as #<base36 index> instead of the string.
    deserialize(s, vocab)  text   -> table, or nil + error. Only builds plain data
                                     (tables, strings, numbers, booleans). Never executes.
    compress / decompress  LZW, 12-bit codes, 2 URL-safe base64 characters per code.
    hash(s)                FNV-1a 32-bit as 8 hex characters.
    split(s, n)            s cut into pieces of at most n characters.

  The vocabulary is built by both clients from the same vendored material files, so
  index N means the same string on both ends. Its hash travels with every payload and a
  reader ignores a sender whose vocabulary differs.
--]]

local Wire = {}

local byte, char, sub, format = string.byte, string.char, string.sub, string.format
local concat, sort = table.concat, table.sort
local floor = math.floor

---------------------------------------------------------------------------
-- hash
---------------------------------------------------------------------------

-- FNV-1a 32-bit, done in doubles so it runs on LuaJIT without bit ops.
function Wire.hash(s)
  local h = 2166136261
  for i = 1, #s do
    local b = byte(s, i)
    -- h = h xor b  (b < 256, so only the low byte changes)
    local low = h % 256
    local x, bitv, r = 0, 1, 0
    local a, c = low, b
    for _ = 1, 8 do
      local abit, cbit = a % 2, c % 2
      if abit ~= cbit then r = r + bitv end
      a, c, bitv = (a - abit) / 2, (c - cbit) / 2, bitv * 2
    end
    h = h - low + r
    -- h = (h * 16777619) mod 2^32, split to stay exact in a double
    local hi, lo = floor(h / 65536), h % 65536
    h = ((hi * 16777619) % 65536 * 65536 + lo * 16777619) % 4294967296
  end
  return format("%08x", h)
end

---------------------------------------------------------------------------
-- base36 for vocabulary indices
---------------------------------------------------------------------------

local B36 = "0123456789abcdefghijklmnopqrstuvwxyz"

local function to36(n)
  if n == 0 then return "0" end
  local out = {}
  while n > 0 do
    local d = n % 36
    out[#out + 1] = sub(B36, d + 1, d + 1)
    n = (n - d) / 36
  end
  local s = {}
  for i = #out, 1, -1 do s[#s + 1] = out[i] end
  return concat(s)
end

---------------------------------------------------------------------------
-- vocabulary
---------------------------------------------------------------------------

-- strings: array of candidate strings (duplicates allowed). Returns a vocab object.
function Wire.build_vocab(strings)
  local seen, list = {}, {}
  for i = 1, #strings do
    local s = strings[i]
    if type(s) == "string" and #s > 2 and not seen[s] then
      seen[s] = true
      list[#list + 1] = s
    end
  end
  sort(list)
  local index = {}
  for i = 1, #list do index[list[i]] = i end
  return { list = list, index = index, hash = sub(Wire.hash(concat(list, "\n")), 1, 4) }
end

---------------------------------------------------------------------------
-- serialize
---------------------------------------------------------------------------

local function is_array(t)
  local n = #t
  if n == 0 then return false end
  local count = 0
  for k in pairs(t) do
    if type(k) ~= "number" or k < 1 or k > n or k % 1 ~= 0 then return false end
    count = count + 1
  end
  return count == n
end

local function enc_string(s, vocab)
  local idx = vocab and vocab.index[s]
  if idx then
    return "#" .. to36(idx)
  end
  -- quote with minimal escaping: only " and \ need it in this format
  return '"' .. s:gsub('[\\"]', "\\%0") .. '"'
end

local function enc_number(n)
  if n ~= n or n == math.huge or n == -math.huge then return "0" end
  if n % 1 == 0 and n > -1e15 and n < 1e15 then return format("%d", n) end
  local s = format("%.5g", n)
  -- drop leading zero: 0.35 -> .35, -0.35 -> -.35
  s = s:gsub("^(%-?)0%.", "%1.")
  return s
end

local function enc(v, vocab, out, depth)
  if depth > 16 then error("table too deep") end
  local tv = type(v)
  if tv == "string" then
    out[#out + 1] = enc_string(v, vocab)
  elseif tv == "number" then
    out[#out + 1] = enc_number(v)
  elseif tv == "boolean" then
    out[#out + 1] = v and "T" or "F"
  elseif tv == "table" then
    if is_array(v) then
      out[#out + 1] = "["
      for i = 1, #v do
        if i > 1 then out[#out + 1] = "," end
        enc(v[i], vocab, out, depth + 1)
      end
      out[#out + 1] = "]"
    else
      local keys = {}
      for k, val in pairs(v) do
        local tk, tval = type(k), type(val)
        if (tk == "string" or tk == "number") and (tval == "string" or tval == "number" or tval == "boolean" or tval == "table") then
          keys[#keys + 1] = k
        end
      end
      sort(keys, function(a, b)
        local ta, tb = type(a), type(b)
        if ta ~= tb then return ta == "number" end
        return a < b
      end)
      out[#out + 1] = "{"
      for i = 1, #keys do
        local k = keys[i]
        if i > 1 then out[#out + 1] = "," end
        if type(k) == "number" then out[#out + 1] = enc_number(k) else out[#out + 1] = enc_string(k, vocab) end
        out[#out + 1] = ":"
        enc(v[k], vocab, out, depth + 1)
      end
      out[#out + 1] = "}"
    end
  else
    out[#out + 1] = "N"
  end
end

function Wire.serialize(t, vocab)
  local out = {}
  enc(t, vocab, out, 0)
  return concat(out)
end

---------------------------------------------------------------------------
-- deserialize (data only, bounded)
---------------------------------------------------------------------------

local MAX_INPUT = 65536
local MAX_DEPTH = 16

function Wire.deserialize(s, vocab)
  if type(s) ~= "string" or #s > MAX_INPUT then return nil, "bad input" end
  local pos, len = 1, #s

  local parse_value

  local function peek() return sub(s, pos, pos) end

  local function parse_string()
    pos = pos + 1 -- opening quote
    local buf = {}
    while pos <= len do
      local c = sub(s, pos, pos)
      if c == "\\" then
        buf[#buf + 1] = sub(s, pos + 1, pos + 1)
        pos = pos + 2
      elseif c == '"' then
        pos = pos + 1
        return concat(buf)
      else
        buf[#buf + 1] = c
        pos = pos + 1
      end
    end
    error("unterminated string")
  end

  local function parse_token()
    pos = pos + 1 -- '#'
    local start = pos
    while pos <= len and sub(s, pos, pos):match("[0-9a-z]") do pos = pos + 1 end
    local idx = tonumber(sub(s, start, pos - 1), 36)
    local str = idx and vocab and vocab.list[idx]
    if not str then error("unknown vocabulary token") end
    return str
  end

  local function parse_number()
    local start = pos
    while pos <= len and sub(s, pos, pos):match("[%-%+%.%deE]") do pos = pos + 1 end
    local n = tonumber(sub(s, start, pos - 1))
    if not n then error("bad number") end
    return n
  end

  local function parse_key()
    local c = peek()
    if c == '"' then return parse_string()
    elseif c == "#" then return parse_token()
    else return parse_number() end
  end

  function parse_value(depth)
    if depth > MAX_DEPTH then error("too deep") end
    local c = peek()
    if c == "{" then
      pos = pos + 1
      local t = {}
      if peek() == "}" then pos = pos + 1 return t end
      while true do
        local k = parse_key()
        if peek() ~= ":" then error("expected :") end
        pos = pos + 1
        t[k] = parse_value(depth + 1)
        local d = peek()
        pos = pos + 1
        if d == "}" then return t end
        if d ~= "," then error("expected , or }") end
      end
    elseif c == "[" then
      pos = pos + 1
      local t = {}
      if peek() == "]" then pos = pos + 1 return t end
      while true do
        t[#t + 1] = parse_value(depth + 1)
        local d = peek()
        pos = pos + 1
        if d == "]" then return t end
        if d ~= "," then error("expected , or ]") end
      end
    elseif c == '"' then return parse_string()
    elseif c == "#" then return parse_token()
    elseif c == "T" then pos = pos + 1 return true
    elseif c == "F" then pos = pos + 1 return false
    elseif c == "N" then pos = pos + 1 return nil
    else return parse_number() end
  end

  local ok, result = pcall(parse_value, 0)
  if not ok then return nil, tostring(result) end
  if pos <= len then return nil, "trailing data" end
  return result
end

---------------------------------------------------------------------------
-- LZW, 12-bit codes, 2 base64url chars per code
---------------------------------------------------------------------------

local B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"
local B64_REV = {}
for i = 1, 64 do B64_REV[byte(B64, i)] = i - 1 end

local MAX_CODE = 4096

local function put_code(out, code)
  local hi, lo = floor(code / 64), code % 64
  out[#out + 1] = sub(B64, hi + 1, hi + 1) .. sub(B64, lo + 1, lo + 1)
end

function Wire.compress(input)
  if input == "" then return "" end
  local dict, next_code = {}, 256
  for i = 0, 255 do dict[char(i)] = i end
  local out = {}
  local w = ""
  for i = 1, #input do
    local c = sub(input, i, i)
    local wc = w .. c
    if dict[wc] then
      w = wc
    else
      put_code(out, dict[w])
      dict[wc] = next_code
      next_code = next_code + 1
      if next_code >= MAX_CODE then
        dict, next_code = {}, 256
        for j = 0, 255 do dict[char(j)] = j end
      end
      w = c
    end
  end
  put_code(out, dict[w])
  return concat(out)
end

function Wire.decompress(data)
  if data == "" then return "" end
  if #data % 2 ~= 0 then return nil, "odd length" end
  local dict, next_code = {}, 256
  for i = 0, 255 do dict[i] = char(i) end
  local out = {}
  local prev
  for i = 1, #data, 2 do
    local a, b = B64_REV[byte(data, i)], B64_REV[byte(data, i + 1)]
    if not a or not b then return nil, "bad character" end
    local code = a * 64 + b
    local entry
    if dict[code] then
      entry = dict[code]
    elseif prev and code == next_code then
      entry = prev .. sub(prev, 1, 1)
    else
      return nil, "bad code"
    end
    out[#out + 1] = entry
    if prev then
      dict[next_code] = prev .. sub(entry, 1, 1)
      next_code = next_code + 1
      if next_code >= MAX_CODE then
        -- The encoder reset one code earlier than this point, so the code just read
        -- was already written against the fresh dictionary and pairs with the next one.
        dict, next_code = {}, 256
        for j = 0, 255 do dict[j] = char(j) end
      end
      prev = entry
    else
      prev = entry
    end
    if #out > 200000 then return nil, "too large" end
  end
  return concat(out)
end

function Wire.split(s, n)
  local parts = {}
  for i = 1, #s, n do parts[#parts + 1] = sub(s, i, i + n - 1) end
  return parts
end

return Wire
