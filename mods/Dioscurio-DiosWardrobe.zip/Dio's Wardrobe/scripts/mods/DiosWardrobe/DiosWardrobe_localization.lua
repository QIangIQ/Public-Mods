return {
  mod_name =
  {
    en = "Dio's Wardrobe",
  },
  mod_description =
  {
    en = "Gear customization with outfit sharing over Vox Manifold. Based on For the Drip by Adspartan. Author: Dioscurio",
  },
  apply_mat_on_index_change =
  {
    en = "Apply material on selection change",
  },
  save_current_preset =
  {
    en = "Save current look",
  },
  toggle_editor =
  {
    en = "Toggle Editor",
  },
  reset_window_position =
  {
    en = "Reset Editor Position",
  },
  preview_attachments  =
  {
    en = "Preview Selected Attachment",
  },
  editor_scale =
  {
    en = "Editor text scale (0 = match screen)",
  },
  editor_scale_description =
  {
    en = "Size of the editor window's text and buttons. 0 picks a size from your screen height. Lower it if the editor does not fit.",
  },
  share_my_outfit =
  {
    en = "Share my outfit with party (Vox Manifold)",
  },
  share_my_outfit_description =
  {
    en = "Party members running Dio's Wardrobe and Vox Manifold see your customized gear.",
  },
  show_others_outfits =
  {
    en = "Show party members' outfits",
  },
  show_others_outfits_description =
  {
    en = "Show the customized gear of party members who share theirs. Turning this off restores their normal gear.",
  },
}
