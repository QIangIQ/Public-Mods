-- QIangIQ's Ankha: swaps the local player's body for a Custom Assets unit
-- (third person, first-person arms, and menu / operative-select previews).
-- Author: QIangIQ
local mod = get_mod("QIangIQsAnkha")

-- Cross-client sync ---------------------------------------------------------------
-- QIangIQsModelSync publishes which QIangIQ replacer mods a player has on, with their options, through
-- Vox Manifold (the transport Dio's Wardrobe shares outfits with). No asset data is sent: every client shows
-- the model from its own installed files. While another player's unit is worked on, sync_ctx holds that
-- player's options and opt() answers from them; for my own unit opt() is mod:get().
local SYNC_KEY = "ankha"
local SYNC_BOOLS = { "model_enabled", "hide_body", "tail_custom" }
local SYNC_DEFAULTS = { model_enabled = false, hide_body = true, tail_custom = false }
local SYNC_VALUES = { "shape_breast", "shape_butt", "tail_length", "tail_thickness" }
local SYNC_LAYOUT = #SYNC_BOOLS * 100 + #SYNC_VALUES -- a peer on another version of this mod is not decoded
local sync_ctx = nil
local sync_known = setmetatable({}, { __mode = "k" })   -- other players' extensions this mod has shown something on
local sync_all = setmetatable({}, { __mode = "k" })     -- every visual loadout extension seen
local sync_decoded = setmetatable({}, { __mode = "k" }) -- published array -> options table
local SYNC_FALSE = { __index = function() return false end }
local SYNC_OFF = setmetatable({}, SYNC_FALSE)           -- "everything off": removes what was shown
local sync_extra_import = nil

local function opt(key)
    if sync_ctx then
        return sync_ctx[key]
    end
    return mod:get(key)
end

local function sync_api()
    local hub = get_mod("QIangIQsModelSync")
    return hub and hub.api
end

local function sync_me()
    local players = Managers.player
    if not players then
        return nil
    end
    local ok, player = pcall(players.local_player_safe, players, 1)
    return ok and player or nil
end

-- published array { layout, checkbox bits, value, value, ... [, extra] } -> options by setting id
local function sync_decode(raw)
    local t = sync_decoded[raw]
    if t ~= nil then
        return t
    end
    t = false
    if type(raw) == "table" and raw[1] == SYNC_LAYOUT then
        t = setmetatable({}, SYNC_FALSE)
        local mask = tonumber(raw[2]) or 0
        for i = 1, #SYNC_BOOLS do
            t[SYNC_BOOLS[i]] = mask % 2 >= 1
            mask = math.floor(mask / 2)
        end
        for i = 1, #SYNC_VALUES do
            local v = raw[2 + i]
            if v ~= nil then
                t[SYNC_VALUES[i]] = v
            end
        end
        if sync_extra_import then
            sync_extra_import(t, raw[3 + #SYNC_VALUES])
        end
    end
    sync_decoded[raw] = t
    return t
end

-- whose options apply to this extension: nil = mine, a table = that player's (SYNC_OFF when they publish
-- nothing for this mod)
local function sync_owner(ext)
    sync_all[ext] = true
    local player = ext._player
    if player == nil or player == sync_me() then
        return nil
    end
    local api = sync_api()
    local raw = api and api.peer(SYNC_KEY, player)
    local state = raw and sync_decode(raw)
    if state then
        sync_known[ext] = true
        return state
    end
    return SYNC_OFF
end

-- my own unit, or another player's unit this mod is (or was) showing something on
local function sync_shown(ext)
    local player = ext._player
    return player ~= nil and (player == sync_me() or sync_known[ext] == true)
end

local function sync_pack(...)
    return { n = select("#", ...), ... }
end

-- runs a hook body with the options of the extension's owner
local function sync_wrap(fn, ext_index)
    return function(...)
        local ext = select(ext_index, ...)
        local previous = sync_ctx
        sync_ctx = sync_owner(ext)
        local results = sync_pack(pcall(fn, ...))
        sync_ctx = previous
        if not results[1] then
            error(results[2], 0)
        end
        return unpack(results, 2, results.n)
    end
end

-- The same hook on my own unit's extension and on other players' (husk) extensions. While the mods load, the
-- classes do not exist yet: CLASS.<name> is then only the name and DMF delays the hook ("needs to be delayed"
-- in the log), so the husk class cannot be inspected here. Its methods are taken from
-- player_husk_visual_loadout_extension.lua instead.
local SYNC_HUSK_METHODS = { init = true, update = true, _update_item_visibility = true, destroy = true }

local function vl_hook_safe(method, fn)
    mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, method, sync_wrap(fn, 1))
    if SYNC_HUSK_METHODS[method] then
        mod:hook_safe(CLASS.PlayerHuskVisualLoadoutExtension, method, sync_wrap(fn, 1))
    end
end

local function vl_hook(method, fn)
    mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, method, sync_wrap(fn, 2))
    if SYNC_HUSK_METHODS[method] then
        mod:hook(CLASS.PlayerHuskVisualLoadoutExtension, method, sync_wrap(fn, 2))
    elseif method == "_unequip_item_from_slot" then
        -- a husk has no _unequip_item_from_slot: its unequip arrives as rpc_player_unequip_item_from_slot
        -- (self, channel_id, go_id, slot_id), slot name = NetworkLookup.player_inventory_slot_names[slot_id]
        -- (player_husk_visual_loadout_extension.lua)
        mod:hook(CLASS.PlayerHuskVisualLoadoutExtension, "rpc_player_unequip_item_from_slot", sync_wrap(function(func, self, channel_id, go_id, slot_id, ...)
            local NetworkLookup = require("scripts/network_lookup/network_lookup")
            local slot_name = NetworkLookup.player_inventory_slot_names[slot_id]
            return fn(function()
                return func(self, channel_id, go_id, slot_id)
            end, self, slot_name)
        end, 2))
    end
end
-- ----------------------------------------------------------------------------------

mod.AUTHOR = "QIangIQ"

-- Every piece is its own Custom Assets unit: Custom Assets id = <Mod>:<Custom folder>, unit name =
-- the --asset-path used at compile time. The base is the bare body; each clothing part is a separate
-- unit (and a separate first-person arms unit when it covers the arms) that is spawned and linked the
-- same way, so parts can be switched on and off one by one.
local BODY = "ankha"
local ARMS = "ankha_arms"
local function asset_id(name)
    return "QIangIQsAnkha:" .. name
end
local function unit_name(name)
    return "content/mods/qiangiq_ankha/" .. name
end
local BODY_UNIT = unit_name(BODY)
local ARMS_UNIT = unit_name(ARMS)
-- { id (setting "part_<id>"), body = Custom folder of the third-person unit, arms = folder of the first-person unit or nil,
--   default = false for parts that start switched off, needs = id of a part that must be on as well,
--   glow = slider setting for the part's emissive material, glow_default, color = colour setting,
--   setting = id of another part whose on/off option this part shares (it has no option of its own),
--   when / unless = a checkbox setting that must be on / off for the part to be shown,
--   flame = true for a part whose emissive material takes the flame colour (see apply_part_glow) }
local PARTS = {}
local PART_BY_ID = {}
for _, part in ipairs(PARTS) do
    PART_BY_ID[part.id] = part
end
local function part_on(part)
    local on = opt("part_" .. (part.setting or part.id))
    if on == nil then
        on = part.default ~= false
    end
    if on and part.when and not opt(part.when) then
        return false
    end
    if on and part.unless and opt(part.unless) then
        return false
    end
    if on and part.needs and PART_BY_ID[part.needs] then
        return part_on(PART_BY_ID[part.needs])
    end
    return on and true or false
end

-- QIangIQ character swap mods: only one model is shown at a time. Turning one on (option,
-- keybind or chat command) switches the others off through their saved "model_enabled" setting
-- (DMFMod:set / DMFMod:get, dmf/modules/core/settings.lua).
local CHARACTER_MODS = { "QIangIQsAnubis", "QIangIQsDominanceAnubis", "QIangIQsEmber", "QIangIQsCitlali", "QIangIQsYvonne", "QIangIQsKulveTaroth", "QIangIQsNavia", "QIangIQsZhuangFangyi", "QIangIQsArknightsEmber", "QIangIQsHornet", "QIangIQsAlienQueen", "QIangIQsAnkha", "QIangIQsValkyrHeirloom", "QIangIQsMesaHeirloom", "QIangIQsCitrinePrime", "QIangIQsOctaviaPrime", "QIangIQsOraxia", "QIangIQsSevagothPrime", "QIangIQsVorunaPrime", "QIangIQsWispPrime", "QIangIQsYareliPrime", "QIangIQsMarieGemini", "QIangIQsEleanorGemini", "QIangIQsJade" }

-- The model is fitted to one skeleton (human); bodies of the other breed use a different
-- skeleton, so they are left alone. Breed names as keyed in player_character_constants.lua
-- (human / ogryn).
local EXCLUDED_BREEDS = { ogryn = true }

-- player_unit_visual_loadout_extension.lua:205-206 keeps the breed on the extension itself
-- (self._static_profile_properties.breed), so it is known even when this mod is loaded mid-game.
local function ext_breed(ext)
    local props = ext._static_profile_properties
    return (props and props.breed) or ext.__qiangiq_breed
end

local custom_assets = nil
local ready = {} -- [Custom folder] = true once its package is loaded
local function model_on()
    return opt("model_enabled") ~= false
end

-- extensions / UI spawners we have touched (weak keys)
local tracked = setmetatable({}, { __mode = "k" })
local tracked_ui = setmetatable({}, { __mode = "k" })

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function local_player()
    local players = Managers.player
    if not players then
        return nil
    end
    local ok, player = pcall(players.local_player_safe, players, 1)
    return ok and player or nil
end

-- slot_body_* / slot_gear_* hold the body parts and cosmetics; weapons live in other slots
local function hide_body_slots(slots, key)
    if not slots then
        return
    end
    local attachments_key = key == "unit_1p" and "attachments_by_unit_1p" or "attachments_by_unit_3p"
    for slot_name, slot in pairs(slots) do
        if string.find(slot_name, "^slot_body_") or string.find(slot_name, "^slot_gear_") then
            local unit = slot[key]
            if unit_ok(unit) then
                Unit.set_unit_visibility(unit, false, true)
                local attachments = slot[attachments_key] and slot[attachments_key][unit]
                if attachments then
                    for i = 1, #attachments do
                        if unit_ok(attachments[i]) then
                            Unit.set_unit_visibility(attachments[i], false, true)
                        end
                    end
                end
            end
        end
    end
end

-- In-game player unit -----------------------------------------------------------

local function is_local_human(ext)
    return sync_shown(ext)
end

local function delete_unit(unit)
    if unit_ok(unit) then
        local unit_spawner = Managers.state and Managers.state.unit_spawner
        if unit_spawner then
            unit_spawner:mark_for_deletion(unit)
        end
    end
end

local function delete_all(units)
    if units then
        for id, unit in pairs(units) do
            delete_unit(unit)
            units[id] = nil
        end
    end
end

local function despawn(ext)
    delete_unit(ext.__qiangiq_ankha_unit)
    delete_unit(ext.__qiangiq_ankha_arms)
    ext.__qiangiq_ankha_unit = nil
    ext.__qiangiq_ankha_arms = nil
    delete_all(ext.__qiangiq_ankha_parts)
    delete_all(ext.__qiangiq_ankha_part_arms)
end

local FP_CUSTOM_FOV = false

-- same spawn + link pattern the game uses for gear (visual_loadout_customization.lua)
local function spawn_linked(world, parent, unit_name, is_first_person)
    local unit_spawner = Managers.state and Managers.state.unit_spawner
    if not (world and unit_spawner and unit_ok(parent)) then
        return nil
    end
    local unit = unit_spawner:spawn_unit(unit_name, Unit.world_pose(parent, 1))
    if not unit then
        return nil
    end
    if is_first_person then
        Unit.set_unit_culling(unit, false)
    end
    if is_first_person and FP_CUSTOM_FOV then
        -- 1P items are drawn with the first-person FOV (equipment_component.lua:359). Without this flag the
        -- arms are drawn with the world FOV while the weapon uses the 1P one, so the weapon shows beside the hand.
        Unit.set_shader_pass_flag_for_meshes_in_unit_and_childs(unit, "custom_fov", true)
    end
    World.link_unit(world, unit, 1, parent, 1, World.LINK_MODE_NODE_NAME)
    return unit
end

-- Glow slider for the model's emissive layer (nil = the model has none). The layer's material is the
-- compiler's PBR emissive one, whose brightness is its scalar variable "intensity"
-- (pbr_emissive_profile.cpp, id32 0x32f447e5 = "intensity"); set the way the game applies scalar
-- material overrides (visual_loadout_customization.lua:516, Unit.set_scalar_for_materials(unit, name, value, true)).
local GLOW_SETTING = nil
local GLOW_DEFAULT = 1.7

-- Glow colour for the model's emissive materials (emissive_color, id32 0xc985395a; same call as the parts'
-- colour option below, visual_loadout_customization.lua:534). The exporter bakes emissive_color as (1, 1, 1)
-- when an emission texture is connected, so white = the model as built. Only written while the option is on;
-- turning it off writes white back once.
local GLOW_COLOR = false -- true = the model has the "glow_color_custom" + r / g / b options
-- the colour the emissive material was built with (written back when the option is turned off)
local GLOW_BASE = { 1, 1, 1 }
local colored = setmetatable({}, { __mode = "k" })

local function custom_glow_color()
    if GLOW_COLOR and opt("glow_color_custom") then
        local r = math.max(opt("glow_color_r") or GLOW_BASE[1], 0)
        local g = math.max(opt("glow_color_g") or GLOW_BASE[2], 0)
        local b = math.max(opt("glow_color_b") or GLOW_BASE[3], 0)
        return r, g, b
    end
    return nil
end

local function apply_glow_color(unit)
    local r, g, b = custom_glow_color()
    if r then
        Unit.set_vector3_for_materials(unit, "emissive_color", Vector3(r, g, b), true)
        colored[unit] = true
    elseif colored[unit] then
        Unit.set_vector3_for_materials(unit, "emissive_color", Vector3(GLOW_BASE[1], GLOW_BASE[2], GLOW_BASE[3]), true)
        colored[unit] = nil
    end
end

local function apply_glow(unit)
    if GLOW_SETTING and unit_ok(unit) then
        Unit.set_scalar_for_materials(unit, "intensity", opt(GLOW_SETTING) or GLOW_DEFAULT, true)
        apply_glow_color(unit)
    end
end

-- Flame parts: their emission picture is greyscale, so emissive_color is the flame's colour. It is the custom glow
-- colour while that option is on, otherwise the mean colour of the model's own flame pictures.
local FLAME_COLOR = { 1, 1, 1 }

-- Emissive colours offered for parts with a colour option (emissive_color = id32 0xc985395a in the same
-- material; a Vector3 set like visual_loadout_customization.lua:534, Unit.set_vector3_for_materials).
local GLOW_COLORS = {
    cyan = { 0, 0.85, 1 },
    pink = { 1, 0.08, 0.55 },
    green = { 0.15, 1, 0.2 },
    gold = { 1, 0.69, 0.06 },
    purple = { 0.55, 0.15, 1 },
    red = { 1, 0.04, 0.04 },
    white = { 1, 1, 1 },
}

local function apply_part_glow(part, unit)
    if part.glow and unit_ok(unit) then
        Unit.set_scalar_for_materials(unit, "intensity", opt(part.glow) or part.glow_default, true)
        local c = part.color and GLOW_COLORS[opt(part.color) or "cyan"]
        if c then
            Unit.set_vector3_for_materials(unit, "emissive_color", Vector3(c[1], c[2], c[3]), true)
        end
        if part.flame then
            local r, g, b = custom_glow_color()
            if not r then
                r, g, b = FLAME_COLOR[1], FLAME_COLOR[2], FLAME_COLOR[3]
            end
            Unit.set_vector3_for_materials(unit, "emissive_color", Vector3(r, g, b), true)
        end
    end
end

-- Tail size (nil = not offered). Scales are set on the tail's own nodes, the call the game uses to size a
-- unit (ui_profile_spawner.lua:1722, Unit.set_local_scale(unit, node, Vector3)). A bone runs along its
-- local Z (see the physics notes), so X/Y is thickness and Z is length; children inherit it.
local TAIL = { thick = "tail_01", long = "tail_02" }

local function apply_tail(unit)
    if not (TAIL and unit_ok(unit) and Unit.has_node(unit, TAIL.thick) and Unit.has_node(unit, TAIL.long)) then
        return
    end
    local on = opt("tail_custom")
    local thick = on and math.max(opt("tail_thickness") or 1, 0.1) or 1
    local long = on and math.max(opt("tail_length") or 1, 0.1) or 1
    Unit.set_local_scale(unit, Unit.node(unit, TAIL.thick), Vector3(thick, thick, 1))
    Unit.set_local_scale(unit, Unit.node(unit, TAIL.long), Vector3(1, 1, long))
end

-- Body proportions: a uniform scale on the model's own soft-body bones (the physics bones the breasts, butt and
-- thighs are weighted to), set with the same call as the tail size. Their children and every vertex weighted to
-- them scale around the bone's head. Clothing parts carry the same bones and are scaled the same way.
-- { setting, { bones } }
local SHAPE = {
    { "shape_breast", { "breast_l", "breast_r" } },
    { "shape_butt", { "butt_l", "butt_r" } },
}

local function apply_shape(unit)
    if not unit_ok(unit) then
        return
    end
    for _, row in ipairs(SHAPE) do
        local v = math.max(opt(row[1]) or 1, 0.1)
        local scale = Vector3(v, v, v)
        for _, name in ipairs(row[2]) do
            if Unit.has_node(unit, name) then
                Unit.set_local_scale(unit, Unit.node(unit, name), scale)
            end
        end
    end
end

local function apply_shape_all(body, parts)
    apply_shape(body)
    if parts then
        for _, unit in pairs(parts) do
            apply_shape(unit)
        end
    end
end

local function apply(ext, first_person_mode)
    if not model_on() then
        despawn(ext)
        return
    end
    local world = ext.__qiangiq_world

    local fp_arms = opt("first_person_arms") and true or false
    ext.__qiangiq_ankha_fp = first_person_mode and true or false

    if ready[BODY] and not unit_ok(ext.__qiangiq_ankha_unit) then
        ext.__qiangiq_ankha_unit = spawn_linked(world, ext._unit, BODY_UNIT, false)
    end
    if ready[ARMS] and fp_arms and not unit_ok(ext.__qiangiq_ankha_arms) then
        ext.__qiangiq_ankha_arms = spawn_linked(world, ext._first_person_unit, ARMS_UNIT, true)
    elseif not fp_arms and ext.__qiangiq_ankha_arms then
        delete_unit(ext.__qiangiq_ankha_arms)
        ext.__qiangiq_ankha_arms = nil
    end

    local body = ext.__qiangiq_ankha_unit
    local arms = ext.__qiangiq_ankha_arms
    apply_glow(body)
    apply_glow(arms)
    apply_tail(body)
    if unit_ok(body) then
        Unit.set_unit_visibility(body, not first_person_mode, true)
    end
    if unit_ok(arms) then
        Unit.set_unit_visibility(arms, first_person_mode and true or false, true)
    end

    -- clothing parts: spawned next to the body while their option is on, deleted when it is off
    local parts = ext.__qiangiq_ankha_parts or {}
    local part_arms = ext.__qiangiq_ankha_part_arms or {}
    ext.__qiangiq_ankha_parts = parts
    ext.__qiangiq_ankha_part_arms = part_arms
    for _, part in ipairs(PARTS) do
        local id = part.id
        local on = part_on(part)
        if on and ready[part.body] and unit_ok(body) and not unit_ok(parts[id]) then
            parts[id] = spawn_linked(world, ext._unit, unit_name(part.body), false)
        elseif not on and parts[id] then
            delete_unit(parts[id])
            parts[id] = nil
        end
        if unit_ok(parts[id]) then
            apply_part_glow(part, parts[id])
            Unit.set_unit_visibility(parts[id], not first_person_mode, true)
        end
        if part.arms then
            local want = on and fp_arms
            if want and ready[part.arms] and unit_ok(arms) and not unit_ok(part_arms[id]) then
                part_arms[id] = spawn_linked(world, ext._first_person_unit, unit_name(part.arms), true)
            elseif not want and part_arms[id] then
                delete_unit(part_arms[id])
                part_arms[id] = nil
            end
            if unit_ok(part_arms[id]) then
                apply_part_glow(part, part_arms[id])
                Unit.set_unit_visibility(part_arms[id], first_person_mode and true or false, true)
            end
        end
    end

    if opt("hide_body") then
        if not first_person_mode and unit_ok(body) then
            hide_body_slots(ext._equipment, "unit_3p")
        elseif first_person_mode and unit_ok(arms) then
            hide_body_slots(ext._equipment, "unit_1p")
        end
    end
end

-- Menu previews (operative select, inventory, lobby) --------------------------

local function ui_profile_is_mine(profile)
    -- __qiangiq_npc: the companion NPC spawned by QIangIQsCompanionSwap is nobody's character
    if not profile or profile.__qiangiq_npc then
        return false
    end
    -- skip previews of characters that belong to someone else (other players, bots)
    local players = Managers.player and Managers.player:players()
    local me = local_player()
    if players and profile.character_id then
        for _, player in pairs(players) do
            if player ~= me and player.character_id and player:character_id() == profile.character_id then
                return false
            end
        end
    end
    return true
end

local function ui_despawn(spawner)
    local unit = spawner.__qiangiq_ankha_unit
    spawner.__qiangiq_ankha_unit = nil
    spawner.__qiangiq_ankha_parent = nil
    if unit_ok(unit) and spawner._world then
        -- same call ui_profile_spawner.lua uses for its own character unit
        World.destroy_unit(spawner._world, unit)
    end
    local parts = spawner.__qiangiq_ankha_parts
    if parts then
        for id, part_unit in pairs(parts) do
            if unit_ok(part_unit) and spawner._world then
                World.destroy_unit(spawner._world, part_unit)
            end
            parts[id] = nil
        end
    end
end

local function ui_apply(spawner)
    local data = spawner._character_spawn_data
    if not data or not unit_ok(data.unit_3p) then
        return
    end
    -- ui_profile_spawner.lua:179-180 reads profile.archetype.breed
    local archetype = data.profile and data.profile.archetype
    local excluded = archetype and EXCLUDED_BREEDS[archetype.breed]
    if excluded or not (model_on() and opt("menu_previews") and ready[BODY] and ui_profile_is_mine(data.profile)) then
        if spawner.__qiangiq_ankha_unit then
            ui_despawn(spawner)
            if spawner._visible then
                spawner:_update_items_visibility()
            end
        end
        return
    end
    if spawner.__qiangiq_ankha_parent ~= data.unit_3p then
        ui_despawn(spawner)
    end
    local unit = spawner.__qiangiq_ankha_unit
    if not unit_ok(unit) then
        local world = spawner._world
        unit = World.spawn_unit_ex(world, BODY_UNIT, nil, Unit.world_pose(data.unit_3p, 1))
        World.link_unit(world, unit, 1, data.unit_3p, 1, World.LINK_MODE_NODE_NAME)
        spawner.__qiangiq_ankha_unit = unit
        spawner.__qiangiq_ankha_parent = data.unit_3p
        tracked_ui[spawner] = true
    end
    apply_glow(unit)
    apply_tail(unit)
    Unit.set_unit_visibility(unit, spawner._visible and true or false, true)
    local parts = spawner.__qiangiq_ankha_parts or {}
    spawner.__qiangiq_ankha_parts = parts
    for _, part in ipairs(PARTS) do
        local id = part.id
        local on = part_on(part)
        if on and ready[part.body] and not unit_ok(parts[id]) then
            local world = spawner._world
            parts[id] = World.spawn_unit_ex(world, unit_name(part.body), nil, Unit.world_pose(data.unit_3p, 1))
            World.link_unit(world, parts[id], 1, data.unit_3p, 1, World.LINK_MODE_NODE_NAME)
        elseif not on and parts[id] then
            if unit_ok(parts[id]) then
                World.destroy_unit(spawner._world, parts[id])
            end
            parts[id] = nil
        end
        if unit_ok(parts[id]) then
            apply_part_glow(part, parts[id])
            Unit.set_unit_visibility(parts[id], spawner._visible and true or false, true)
        end
    end
    if spawner._visible and opt("hide_body") then
        hide_body_slots(data.slots, "unit_3p")
    end
end

-- Physics ------------------------------------------------------------------------
-- The model's own physics bones (the avatar's "Phy_*" chains) are in the compiled units as extra nodes
-- that the player's skeleton does not have, so node-name linking leaves them at their rest pose. Each
-- one is driven here as a damped spring: its tip is a point that lags behind where the rest pose puts
-- it and is pulled back, and the bone is turned to point at it. Only engine calls the game's own
-- scripts use: Unit.node / has_node / local_rotation / local_position / world_position /
-- world_rotation / set_local_rotation, Quaternion.multiply / inverse / rotate / axis_angle,
-- Vector3.cross / dot / length.
-- { bone, parent, area, length (m) }, parents first
-- (from the fitted armature). A parent that is not in this list is a normal skeleton / helper node.
local JIGGLE_BONES = {
    { "ear_l_001", "j_head", "ear", 0.063 },
    { "ear_l_002", "ear_l_001", "ear", 0.063 },
    { "ear_l_003", "ear_l_002", "ear", 0.063 },
    { "ear_r_001", "j_head", "ear", 0.063 },
    { "ear_r_002", "ear_r_001", "ear", 0.063 },
    { "ear_r_003", "ear_r_002", "ear", 0.063 },
    { "hair_back_hair_a_l", "j_head", "hair", 0.167 },
    { "hair_back_hair_b_l", "hair_back_hair_a_l", "hair", 0.094 },
    { "hair_back_hair_a_r", "j_head", "hair", 0.167 },
    { "hair_back_hair_b_r", "hair_back_hair_a_r", "hair", 0.094 },
    { "hair_back_side_hair_a_l", "j_head", "hair", 0.152 },
    { "hair_back_side_hair_b_l", "hair_back_side_hair_a_l", "hair", 0.110 },
    { "hair_back_side_hair_a_r", "j_head", "hair", 0.152 },
    { "hair_back_side_hair_b_r", "hair_back_side_hair_a_r", "hair", 0.110 },
    { "hair_front", "j_head", "hair", 0.151 },
    { "hair_front_l", "j_head", "hair", 0.133 },
    { "hair_front_r", "j_head", "hair", 0.133 },
    { "hair_side_hair_a_l", "j_head", "hair", 0.154 },
    { "hair_side_hair_b_l", "hair_side_hair_a_l", "hair", 0.195 },
    { "hair_side_hair_a_r", "j_head", "hair", 0.154 },
    { "hair_side_hair_b_r", "hair_side_hair_a_r", "hair", 0.195 },
    { "breast_l", "j_spine2", "breast", 0.135 },
    { "breast_l_001", "breast_l", "breast", 0.135 },
    { "breast_r", "j_spine2", "breast", 0.135 },
    { "breast_r_001", "breast_r", "breast", 0.135 },
    { "butt_l", "j_hips", "butt", 0.195 },
    { "butt_r", "j_hips", "butt", 0.195 },
    { "tail_01", "j_hips", "tail", 0.122 },
    { "tail_02", "tail_01", "tail", 0.122 },
    { "tail_03", "tail_02", "tail", 0.122 },
    { "tail_04", "tail_03", "tail", 0.122 },
    { "tail_05", "tail_04", "tail", 0.122 },
    { "tail_06", "tail_05", "tail", 0.122 },
    { "tail_07", "tail_06", "tail", 0.122 },
    { "tail_08", "tail_07", "tail", 0.122 },
}
-- per 60 fps frame: pull = share of the remaining offset removed, drag = share of velocity lost;
-- max_angle = largest swing of one bone from its rest pose (degrees); slider = the option that scales the area.
-- flow = every bone of the chain is its own free point (the chain bends bone by bone and a wave runs down
-- it); without it the bones after the first only follow the first one (one soft lump).
-- carry = share of the character's own travel the points are taken along with (1 = no trailing while running);
-- hang = the area takes part in the "hang" option (rest direction leaned towards straight down);
-- drape = the area always hangs straight down in the world (cloth hung from an arm);
-- total = largest lean of any bone from where it would point if its whole chain were stiff (degrees).
-- bend_step = largest difference between the bends of two neighbouring joints of a chain (degrees).
-- segments = the chain is simulated as this many long segments (each one spring point, like a chain of a few
-- long bones) and their bend is spread smoothly over its bones. For chains of many short bones: one free point
-- per short bone let every joint flip from side to side every frame while running.
-- own = prefix of the area's own settings (<own>_stiffness, _damping, _limit, _gravity, _trail, _segments),
-- used instead of the settings for all areas. hang_slider = the area's own "hang" (gravity) setting.
local JIGGLE_GROUPS = {
    breast = { pull = 0.22, drag = 0.16, max_angle = 14, slider = "jiggle_breast" },
    butt = { pull = 0.28, drag = 0.20, max_angle = 10, slider = "jiggle_butt" },
    thigh = { pull = 0.30, drag = 0.22, max_angle = 6, slider = "jiggle_butt" },
    tail = { pull = 0.07, drag = 0.34, max_angle = 32, slider = "jiggle_tail", flow = true, carry = 0.92, total = 50, own = "tail_phys", segments = 4, gravity = 0.3 },
    hair = { pull = 0.05, drag = 0.30, max_angle = 40, slider = "jiggle_hair", flow = true, carry = 0.92, hang = true, total = 45, hang_slider = "jiggle_hair_gravity", gravity = 0.4 },
    ear = { pull = 0.25, drag = 0.18, max_angle = 14, slider = "jiggle_ear" },
    drape = { pull = 0.10, drag = 0.40, max_angle = 28, slider = "jiggle_cloth", flow = true, carry = 0.95, drape = true },
    plume = { pull = 0.07, drag = 0.34, max_angle = 30, slider = "jiggle_hair", flow = true, carry = 0.92, total = 30 },
    cloth = { pull = 0.08, drag = 0.36, max_angle = 35, slider = "jiggle_cloth", flow = true, carry = 0.92, hang = true, total = 40 },
}
-- this model's own values
JIGGLE_GROUPS.hair.pull = 0.04
JIGGLE_GROUPS.hair.drag = 0.45
JIGGLE_GROUPS.hair.max_angle = 10
JIGGLE_GROUPS.hair.total = 18
local jiggle_state = setmetatable({}, { __mode = "k" })
-- options, read once per change instead of every frame
local JIGGLE = { on = true, stiffness = 1, damping = 1, limit = 1, hang = 0, amount = {}, tune = {}, layout = 0 }

local function jiggle_read_settings()
    JIGGLE.on = opt("jiggle") ~= false
    JIGGLE.stiffness = math.max(opt("jiggle_stiffness") or 1, 0.05)
    JIGGLE.damping = math.max(opt("jiggle_damping") or 1, 0.05)
    JIGGLE.limit = math.max(opt("jiggle_limit") or 1, 0.05)
    JIGGLE.hang = math.max(opt("jiggle_hang") or 0, 0)
    local layout = 0
    for name, g in pairs(JIGGLE_GROUPS) do
        JIGGLE.amount[name] = math.max(opt(g.slider) or 1, 0)
        -- the values each area uses: the settings for all areas, or the area's own
        local t = { stiffness = JIGGLE.stiffness, damping = JIGGLE.damping, limit = JIGGLE.limit, hang = JIGGLE.hang, trail = 1, segments = g.segments }
        if g.hang_slider then
            t.hang = math.max(opt(g.hang_slider) or g.gravity or JIGGLE.hang, 0)
        end
        if g.own then
            t.stiffness = math.max(opt(g.own .. "_stiffness") or 1, 0.05)
            t.damping = math.max(opt(g.own .. "_damping") or 1, 0.05)
            t.limit = math.max(opt(g.own .. "_limit") or 1, 0.05)
            t.hang = math.max(opt(g.own .. "_gravity") or g.gravity or 0, 0)
            t.trail = math.max(opt(g.own .. "_trail") or 1, 0)
            if g.segments then
                t.segments = math.max(math.floor((opt(g.own .. "_segments") or g.segments) + 0.5), 1)
                layout = layout * 17 + t.segments
            end
        end
        JIGGLE.tune[name] = t
    end
    -- a new segment count rebuilds every unit's chains
    JIGGLE.layout = layout
end

local function jiggle_init(unit)
    local bones, by_name = {}, {}
    for _, def in ipairs(JIGGLE_BONES) do
        local name, parent_name = def[1], def[2]
        local parent = by_name[parent_name]
        -- usable when the unit has the bone and the node it hangs from (parts only carry what they need)
        if Unit.has_node(unit, name) and (parent or Unit.has_node(unit, parent_name)) then
            local node = Unit.node(unit, name)
            local b = {
                node = node,
                group = def[3],
                parent = parent,
                parent_node = not parent and Unit.node(unit, parent_name) or nil,
                rest = QuaternionBox(Unit.local_rotation(unit, node)),
                lpos = Vector3Box(Unit.local_position(unit, node)),
                -- the bone runs along its own local Z for its length (the compiler writes every node's
                -- local transform as glTF (x, y, z) -> (x, -z, y), and a glTF bone runs along its Y)
                tip = Vector3Box(Vector3(0, 0, def[4])),
                len = def[4],
            }
            bones[#bones + 1] = b
            by_name[name] = b
        end
    end
    -- segment chains: one unbranched chain per group, hanging from a skeleton node, parents first
    local chains = {}
    for group, g in pairs(JIGGLE_GROUPS) do
        local nseg = JIGGLE.tune[group] and JIGGLE.tune[group].segments or g.segments
        if nseg and nseg > 0 then
            local list, ok = {}, true
            for _, b in ipairs(bones) do
                if b.group == group then
                    if (#list == 0 and b.parent) or (#list > 0 and b.parent ~= list[#list]) then
                        ok = false
                    end
                    list[#list + 1] = b
                end
            end
            if ok and #list >= 2 then
                -- split by length into segments; each bone's place along the chain (model metres)
                local total_len = 0
                for _, b in ipairs(list) do
                    b.arc = total_len + b.len * 0.5
                    total_len = total_len + b.len
                end
                local n = math.min(nseg, #list)
                local segs = {}
                for _, b in ipairs(list) do
                    local k = math.min(math.floor(b.arc / total_len * n) + 1, n)
                    local seg = segs[k]
                    if not seg then
                        seg = { first = #list + 1, last = 0, len = 0, start = math.huge }
                        segs[k] = seg
                    end
                    b.chain = true
                end
                local idx = {}
                for i, b in ipairs(list) do
                    local k = math.min(math.floor(b.arc / total_len * n) + 1, n)
                    local seg = segs[k]
                    seg.first = math.min(seg.first, i)
                    seg.last = math.max(seg.last, i)
                    seg.len = seg.len + b.len
                    seg.start = math.min(seg.start, b.arc - b.len * 0.5)
                end
                local packed = {}
                for k = 1, n do
                    if segs[k] then
                        local seg = segs[k]
                        seg.centre = seg.start + seg.len * 0.5
                        packed[#packed + 1] = seg
                    end
                end
                chains[#chains + 1] = { group = group, bones = list, segs = packed }
            end
        end
    end
    local free = {}
    for _, b in ipairs(bones) do
        if not b.chain then
            free[#free + 1] = b
        end
    end
    return { bones = free, chains = chains, active = false, layout = JIGGLE.layout }
end

local function jiggle_rest(unit, state)
    for _, b in ipairs(state.bones) do
        Unit.set_local_rotation(unit, b.node, b.rest:unbox())
        b.px = nil
    end
    for _, chain in ipairs(state.chains) do
        for _, b in ipairs(chain.bones) do
            Unit.set_local_rotation(unit, b.node, b.rest:unbox())
        end
        for _, seg in ipairs(chain.segs) do
            seg.px = nil
        end
    end
    state.rx = nil
    state.active = false
end

-- a segment chain (group with `segments`) has physics of its own: a chain of a few long, straight segments,
-- each turned about its head like one long flowing bone (spring point at its end with pull, drag, carry,
-- max_angle around its rest direction, total around the stiff chain's direction). The bones only show it:
-- each segment's turn is spread over its bones as a bend that blends into the neighbouring segments' bends,
-- so the tail curves smoothly. What the bones do is never read back into the simulation.
local function jiggle_chain(unit, chain, travel, f)
    local g = JIGGLE_GROUPS[chain.group]
    local amount = JIGGLE.amount[chain.group] or 1
    local bones, segs = chain.bones, chain.segs
    local first = bones[1]
    local parent_rot = Unit.world_rotation(unit, first.parent_node)
    local head = Unit.world_position(unit, first.node)
    local len = Vector3.length(first.lpos:unbox())
    local scale = len > 1e-3 and Vector3.length(head - Unit.world_position(unit, first.parent_node)) / len or 1
    if scale < 1e-4 then
        scale = 1
    end
    if amount <= 0 then
        for _, b in ipairs(bones) do
            Unit.set_local_rotation(unit, b.node, b.rest:unbox())
        end
        for _, seg in ipairs(segs) do
            seg.px = nil
        end
        return
    end
    local tune = JIGGLE.tune[chain.group] or JIGGLE
    local keep = (1 - math.min(g.drag * tune.damping, 0.95)) ^ f
    local pull = 1 - (1 - math.min(g.pull * tune.stiffness / amount, 0.95)) ^ f
    local max_angle = math.min(math.rad(g.max_angle) * amount * tune.limit, 1.4)
    local total = g.total and math.min(math.rad(g.total) * amount * tune.limit, 3)
    local carry = 1 - (1 - g.carry) * (tune.trail or 1)
    local hang = tune.hang or 0
    -- gravity: the direction a segment is pulled towards, leaned towards straight down (world Z is up)
    local function lean(d)
        if hang <= 0 then
            return d
        end
        local l = d + Vector3(0, 0, -hang)
        local ll = Vector3.length(l)
        return ll > 1e-4 and l / ll or d
    end
    -- the segments: rest shape under what the segments above do, and the stiff chain's direction
    local bends = {}
    local rot, h = parent_rot, head
    local rigid_rot, rigid_h = parent_rot, head
    for k, seg in ipairs(segs) do
        local r, hh, seg_head = rot, h, nil
        local rr, rh, rigid_head = rigid_rot, rigid_h, nil
        for i = seg.first, seg.last do
            local b = bones[i]
            if i > 1 then
                hh = hh + Quaternion.rotate(r, b.lpos:unbox()) * scale
                rh = rh + Quaternion.rotate(rr, b.lpos:unbox()) * scale
            end
            seg_head = seg_head or hh
            rigid_head = rigid_head or rh
            r = Quaternion.multiply(r, b.rest:unbox())
            rr = Quaternion.multiply(rr, b.rest:unbox())
        end
        local tip = bones[seg.last].tip:unbox()
        local rest_tip = hh + Quaternion.rotate(r, tip) * scale
        local chord = rest_tip - seg_head
        local length = Vector3.length(chord)
        local turn_q
        local bend = Vector3(0, 0, 0)
        if length > 1e-6 then
            local rest_dir = chord / length
            local goal_dir = lean(rest_dir)
            local goal_tip = seg_head + goal_dir * length
            local p, pp = goal_tip, goal_tip
            if seg.px then
                p = Vector3(seg.px, seg.py, seg.pz)
                pp = Vector3(seg.qx, seg.qy, seg.qz)
                local along = travel * carry
                p, pp = p + along, pp + along
                if Vector3.length(p - goal_tip) > 4 * length + 0.5 then
                    p, pp = goal_tip, goal_tip -- teleported: start over at rest
                end
            end
            local nxt = p + (p - pp) * keep + (goal_tip - p) * pull
            local dir = nxt - seg_head
            local dl = Vector3.length(dir)
            dir = dl > 1e-6 and dir / dl or goal_dir
            local axis = Vector3.cross(goal_dir, dir)
            local al = Vector3.length(axis)
            local angle = math.acos(math.max(-1, math.min(1, Vector3.dot(goal_dir, dir))))
            if al > 1e-6 and angle > max_angle then
                dir = Quaternion.rotate(Quaternion.axis_angle(axis / al, max_angle), goal_dir)
            end
            if total then
                local rd = rh + Quaternion.rotate(rr, tip) * scale - rigid_head
                local rl = Vector3.length(rd)
                if rl > 1e-6 then
                    rd = lean(rd / rl)
                    local ax = Vector3.cross(rd, dir)
                    local axl = Vector3.length(ax)
                    if axl > 1e-6 and math.acos(math.max(-1, math.min(1, Vector3.dot(rd, dir)))) > total then
                        dir = Quaternion.rotate(Quaternion.axis_angle(ax / axl, total), rd)
                    end
                end
            end
            axis = Vector3.cross(rest_dir, dir)
            al = Vector3.length(axis)
            angle = math.acos(math.max(-1, math.min(1, Vector3.dot(rest_dir, dir))))
            if al > 1e-6 and angle > 1e-5 then
                turn_q = Quaternion.axis_angle(axis / al, angle)
                bend = axis / al * angle
            else
                dir = rest_dir
            end
            local e = seg_head + dir * length
            seg.qx, seg.qy, seg.qz = p.x, p.y, p.z
            seg.px, seg.py, seg.pz = e.x, e.y, e.z
        end
        bends[k] = bend / seg.len
        -- the next segment hangs from this one turned as one piece about its head
        if turn_q then
            rot = Quaternion.multiply(turn_q, r)
            h = seg_head + Quaternion.rotate(turn_q, hh - seg_head)
        else
            rot, h = r, hh
        end
        rigid_rot, rigid_h = rr, rh
    end
    -- the bones: bend per model metre taken between the segment centres, so the curve has no kinks
    local n = #segs
    local k = 1
    rot, h = parent_rot, head
    for i, b in ipairs(bones) do
        while i > segs[k].last do
            k = k + 1
        end
        local seg = segs[k]
        local d = bends[k]
        if b.arc < seg.centre and k > 1 then
            local t = (b.arc - segs[k - 1].centre) / (seg.centre - segs[k - 1].centre)
            d = bends[k - 1] * (1 - t) + d * t
        elseif b.arc > seg.centre and k < n then
            local t = (b.arc - seg.centre) / (segs[k + 1].centre - seg.centre)
            d = d * (1 - t) + bends[k + 1] * t
        end
        local turn = d * b.len
        local ta = Vector3.length(turn)
        local world_rot = Quaternion.multiply(rot, b.rest:unbox())
        if ta > 1e-6 then
            world_rot = Quaternion.multiply(Quaternion.axis_angle(turn / ta, ta), world_rot)
        end
        Unit.set_local_rotation(unit, b.node, Quaternion.multiply(Quaternion.inverse(rot), world_rot))
        rot = world_rot
    end
end

local function jiggle_update(unit, dt)
    if not unit_ok(unit) then
        return
    end
    local state = jiggle_state[unit]
    if state and state.layout ~= JIGGLE.layout then
        jiggle_rest(unit, state)
        state = nil
    end
    if not state then
        state = jiggle_init(unit)
        jiggle_state[unit] = state
    end
    if not JIGGLE.on then
        if state.active then
            jiggle_rest(unit, state)
        end
        return
    end
    state.active = true
    local f = math.min(dt or 0.0167, 0.05) * 60
    -- how far the character itself travelled since the last frame (node 1 = the unit's root)
    local root = Unit.world_position(unit, 1)
    local travel = Vector3(0, 0, 0)
    if state.rx then
        travel = root - Vector3(state.rx, state.ry, state.rz)
        if Vector3.length(travel) > 2 then
            travel = Vector3(0, 0, 0)
        end
    end
    state.rx, state.ry, state.rz = root.x, root.y, root.z
    -- ground level under the character (its root is at its feet) and its facing, for draped cloth
    local floor = root.z + 0.02
    local back = Quaternion.forward(Unit.world_rotation(unit, 1))
    for _, b in ipairs(state.bones) do
        local g = JIGGLE_GROUPS[b.group]
        local amount = JIGGLE.amount[b.group] or 1
        local tune = JIGGLE.tune[b.group] or JIGGLE
        local parent = b.parent
        local parent_rot, head, scale
        if parent then
            parent_rot, scale = parent.rot, parent.scale
            head = parent.head + Quaternion.rotate(parent_rot, b.lpos:unbox()) * scale
        else
            parent_rot = Unit.world_rotation(unit, b.parent_node)
            head = Unit.world_position(unit, b.node)
            -- world size of one model unit (characters can be scaled)
            local len = Vector3.length(b.lpos:unbox())
            scale = len > 1e-3 and Vector3.length(head - Unit.world_position(unit, b.parent_node)) / len or 1
            if scale < 1e-4 then
                scale = 1
            end
        end
        local rest_rot = Quaternion.multiply(parent_rot, b.rest:unbox())
        -- where the bone would point if the whole chain above it were stiff
        local rigid_rot = parent and Quaternion.multiply(parent.rigid, b.rest:unbox()) or rest_rot
        local tip_off = Quaternion.rotate(rest_rot, b.tip:unbox()) * scale
        local length = Vector3.length(tip_off)
        local world_rot = rest_rot
        if amount <= 0 then
            b.px = nil -- area switched off: stay on the rest pose
        elseif length > 1e-6 then
            local keep = (1 - math.min(g.drag * tune.damping, 0.95)) ^ f
            local pull = 1 - (1 - math.min(g.pull * tune.stiffness / amount, 0.95)) ^ f
            local max_angle = math.min(math.rad(g.max_angle) * amount * tune.limit, 1.4)
            local rest_dir = tip_off / length
            local rest_tip = head + tip_off
            local flow = g.flow
            -- goal_dir: the direction the bone is pulled towards and limited around
            local goal_dir = rest_dir
            if flow and g.drape then
                -- loose cloth hung from a limb: straight down in the world, whatever the limb does
                -- (its modelled angle to the limb is only right for the pose it was modelled in)
                goal_dir = Vector3(0, 0, -1)
                rest_tip = head + goal_dir * length
            elseif flow and g.hang and tune.hang > 0 then
                -- lean the direction the bone is pulled towards to straight down (world Z is up)
                local lean = rest_dir + Vector3(0, 0, -tune.hang)
                local ll = Vector3.length(lean)
                if ll > 1e-4 then
                    goal_dir = lean / ll
                    rest_tip = head + goal_dir * length
                end
            end
            -- a tip kept in the world lags when the body moves. Flowing chains keep every tip in the
            -- world; in the other areas only the bone on a normal skeleton node does, and the bones after
            -- it keep theirs relative to their own head, so they follow the bone before them
            local world_tip = flow or not parent
            local origin = world_tip and Vector3(0, 0, 0) or head
            local p, pp = rest_tip, rest_tip
            if b.px then
                p = origin + Vector3(b.px, b.py, b.pz)
                pp = origin + Vector3(b.qx, b.qy, b.qz)
                if flow then
                    local along = travel * (1 - (1 - g.carry) * (tune.trail or 1))
                    p, pp = p + along, pp + along
                end
                if Vector3.length(p - rest_tip) > 4 * length + 0.5 then
                    p, pp = rest_tip, rest_tip -- teleported: start over at rest
                end
            end
            local k, q = keep, pull
            if parent and not flow then
                -- a follower, not a second spring
                k, q = keep * 0.35, math.min(pull * 1.6, 0.9)
            end
            local nxt = p + (p - pp) * k + (rest_tip - p) * q
            local dir = nxt - head
            local dl = Vector3.length(dir)
            dir = dl > 1e-6 and dir / dl or goal_dir
            -- keep the swing within max_angle of the goal direction
            local axis = Vector3.cross(goal_dir, dir)
            local al = Vector3.length(axis)
            local angle = math.acos(math.max(-1, math.min(1, Vector3.dot(goal_dir, dir))))
            if al > 1e-6 and angle > max_angle then
                dir = Quaternion.rotate(Quaternion.axis_angle(axis / al, max_angle), goal_dir)
            end
            if g.drape and (head + dir * length).z < floor then
                -- the cloth is longer than the arm is high: what reaches the ground lies on it, trailing
                -- the way it already leans (behind the character when it hangs dead straight)
                local dz = math.max(-length, math.min(length, floor - head.z))
                local flat = math.sqrt(math.max(0, length * length - dz * dz))
                local hx, hy = dir.x, dir.y
                local hn = math.sqrt(hx * hx + hy * hy)
                if hn < 1e-3 then
                    hx, hy, hn = -back.x, -back.y, math.max(math.sqrt(back.x * back.x + back.y * back.y), 1e-3)
                end
                dir = Vector3(hx / hn * flat, hy / hn * flat, dz) / length
            end
            if g.total then
                -- and the whole chain within `total` of its stiff shape: per-bone limits add up along a
                -- long chain, which let the far end fold right over
                local rigid_dir = Quaternion.rotate(rigid_rot, b.tip:unbox())
                local rl = Vector3.length(rigid_dir)
                if rl > 1e-6 then
                    rigid_dir = rigid_dir / rl
                    local total = math.min(math.rad(g.total) * amount * tune.limit, 3)
                    local ax = Vector3.cross(rigid_dir, dir)
                    local axl = Vector3.length(ax)
                    if axl > 1e-6 and math.acos(math.max(-1, math.min(1, Vector3.dot(rigid_dir, dir)))) > total then
                        dir = Quaternion.rotate(Quaternion.axis_angle(ax / axl, total), rigid_dir)
                    end
                end
            end
            if flow and g.bend_step and parent and parent.group == b.group and parent.bend_x then
                -- snake-like chains: the bend of a joint (rotation from its goal direction, as axis * angle)
                -- may differ from the bend of the joint before it by at most bend_step, so the curvature
                -- changes gradually along the chain instead of kinking from one bone to the next
                local bax = Vector3.cross(goal_dir, dir)
                local bal = Vector3.length(bax)
                local bang = math.acos(math.max(-1, math.min(1, Vector3.dot(goal_dir, dir))))
                local bend = bal > 1e-6 and bax / bal * bang or Vector3(0, 0, 0)
                local parent_bend = Vector3(parent.bend_x, parent.bend_y, parent.bend_z)
                local diff = bend - parent_bend
                local dl2 = Vector3.length(diff)
                local step = math.rad(g.bend_step) * amount * tune.limit
                if dl2 > step then
                    bend = parent_bend + diff * (step / dl2)
                    local bl = Vector3.length(bend)
                    if bl > max_angle then
                        bend, bl = bend * (max_angle / bl), max_angle
                    end
                    dir = bl > 1e-6 and Quaternion.rotate(Quaternion.axis_angle(bend / bl, bl), goal_dir) or goal_dir
                end
            end
            if g.bend_step then
                -- this joint's final bend, for the next bone of the chain (this frame only)
                local bax = Vector3.cross(goal_dir, dir)
                local bal = Vector3.length(bax)
                if bal > 1e-6 then
                    local bend = bax / bal * math.acos(math.max(-1, math.min(1, Vector3.dot(goal_dir, dir))))
                    b.bend_x, b.bend_y, b.bend_z = bend.x, bend.y, bend.z
                else
                    b.bend_x, b.bend_y, b.bend_z = 0, 0, 0
                end
            end
            -- turn the bone from its rest direction to that direction
            axis = Vector3.cross(rest_dir, dir)
            al = Vector3.length(axis)
            angle = math.acos(math.max(-1, math.min(1, Vector3.dot(rest_dir, dir))))
            if al > 1e-6 and angle > 1e-5 then
                world_rot = Quaternion.multiply(Quaternion.axis_angle(axis / al, angle), rest_rot)
            elseif angle < 1 then
                dir = rest_dir
            end
            nxt = head + dir * length
            local sp, sn = p - origin, nxt - origin
            b.qx, b.qy, b.qz = sp.x, sp.y, sp.z
            b.px, b.py, b.pz = sn.x, sn.y, sn.z
        end
        Unit.set_local_rotation(unit, b.node, Quaternion.multiply(Quaternion.inverse(parent_rot), world_rot))
        -- kept for this bone's children, this frame only
        b.rot, b.head, b.scale, b.rigid = world_rot, head, scale, rigid_rot
    end
    for _, chain in ipairs(state.chains) do
        jiggle_chain(unit, chain, travel, f)
    end
end

-- the body and every clothing part carry their own copy of the bones; each is driven from the same
-- skeleton nodes with the same numbers, so they move together
local function jiggle_all(body, parts, dt)
    jiggle_update(body, dt)
    if parts then
        for _, unit in pairs(parts) do
            jiggle_update(unit, dt)
        end
    end
end

-- Hooks ----------------------------------------------------------------------

vl_hook_safe("init", function(self, extension_init_context, unit, extension_init_data)
    self.__qiangiq_world = extension_init_context and extension_init_context.world
    -- player_unit_visual_loadout_extension.lua:81 reads extension_init_data.archetype.breed
    local archetype = extension_init_data and extension_init_data.archetype
    self.__qiangiq_breed = archetype and archetype.breed
end)

vl_hook_safe("_update_item_visibility", function(self, first_person_mode)
    if not is_local_human(self) then
        return
    end
    if EXCLUDED_BREEDS[ext_breed(self)] then
        if self.__qiangiq_ankha_unit or self.__qiangiq_ankha_arms then
            despawn(self)
        end
        return
    end
    tracked[self] = true
    apply(self, first_person_mode)
end)

-- PlayerUnitVisualLoadoutExtension.update = function (self, unit, dt, t)
vl_hook_safe("update", function(self, unit, dt)
    -- the third-person units are hidden in first person, so nothing to move then
    if tracked[self] and self.__qiangiq_ankha_unit and not self.__qiangiq_ankha_fp then
        jiggle_all(self.__qiangiq_ankha_unit, self.__qiangiq_ankha_parts, dt)
        apply_tail(self.__qiangiq_ankha_unit)
        apply_shape_all(self.__qiangiq_ankha_unit, self.__qiangiq_ankha_parts)
    end
end)

vl_hook("destroy", function(func, self, ...)
    despawn(self)
    tracked[self] = nil
    return func(self, ...)
end)

mod:hook_safe(CLASS.UIProfileSpawner, "_update_items_visibility", function(self)
    ui_apply(self)
end)

-- UIProfileSpawner.update = function (self, dt, t, input_service)
mod:hook_safe(CLASS.UIProfileSpawner, "update", function(self, dt)
    local data = self._character_spawn_data
    if data and data.is_ready then
        ui_apply(self)
        if self.__qiangiq_ankha_unit then
            jiggle_all(self.__qiangiq_ankha_unit, self.__qiangiq_ankha_parts, dt)
            apply_tail(self.__qiangiq_ankha_unit)
            apply_shape_all(self.__qiangiq_ankha_unit, self.__qiangiq_ankha_parts)
        end
    end
end)

mod:hook(CLASS.UIProfileSpawner, "_despawn_current_character_profile", function(func, self, ...)
    ui_despawn(self)
    return func(self, ...)
end)

-- Package loading through Custom Assets --------------------------------------

local function refresh_all()
    for ext in pairs(tracked) do
        if unit_ok(ext._unit) then
            if not model_on() then
                despawn(ext)
            end
            ext:force_update_item_visibility()
        end
    end
    for spawner in pairs(tracked_ui) do
        ui_apply(spawner)
    end
end

local function acquire(name)
    local id = asset_id(name)
    local ticket, err = custom_assets.acquire(mod, id, function(_, _, load_error)
        if load_error then
            mod:error("%s failed to load: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", id, tostring(load_error))
            return
        end
        ready[name] = true
        refresh_all()
    end, { resident = true, reference_name = id })
    if not ticket then
        mod:error("%s could not be requested: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", id, tostring(err))
    end
end

-- Two models of the same group saved "on" (e.g. a newly installed mod, which defaults to on):
-- the later one in CHARACTER_MODS keeps it.
local function resolve_at_load()
    local mine = false
    for _, name in ipairs(CHARACTER_MODS) do
        if name == "QIangIQsAnkha" then
            mine = true
        elseif mine then
            local other = get_mod(name)
            if other and other:get("model_enabled") ~= false and model_on() then
                mod:set("model_enabled", false, false)
            end
        end
    end
end

mod.on_all_mods_loaded = function()
    resolve_at_load()
    jiggle_read_settings()
    custom_assets = get_mod("CustomAssets")
    if not custom_assets or not custom_assets.is_api_compatible or not custom_assets.is_api_compatible(1) then
        mod:error("Custom Assets (API 1) is missing. Install it and put it above QIangIQsAnkha in mod_load_order.txt.")
        return
    end
    acquire(BODY)
    acquire(ARMS)
    for _, part in ipairs(PARTS) do
        acquire(part.body)
        if part.arms then
            acquire(part.arms)
        end
    end
end

local function switch_others_off()
    for _, name in ipairs(CHARACTER_MODS) do
        if name ~= "QIangIQsAnkha" then
            local other = get_mod(name)
            if other and other:get("model_enabled") ~= false then
                other:set("model_enabled", false, true)
            end
        end
    end
end

mod.toggle_model = function()
    local on = not model_on()
    mod:set("model_enabled", on, true)
    mod:echo("Ankha model %s", on and "on" or "off")
end

mod:command("ankha", "Toggle the Ankha model on your character", function()
    mod.toggle_model()
end)

mod.on_setting_changed = function(setting_id)
    if setting_id == "model_enabled" and model_on() then
        switch_others_off()
    end
    jiggle_read_settings()
    refresh_all()
end

mod.on_disabled = function()
    for ext in pairs(tracked) do
        despawn(ext)
        -- hooks are off now, so this restores the normal body/gear visibility
        if unit_ok(ext._unit) then
            ext:force_update_item_visibility()
        end
    end
    for spawner in pairs(tracked_ui) do
        ui_despawn(spawner)
        if spawner._character_spawn_data and spawner._visible then
            spawner:_update_items_visibility()
        end
    end
end

mod.on_enabled = function()
    refresh_all()
end

mod.on_unload = function()
    for ext in pairs(tracked) do
        despawn(ext)
    end
    for spawner in pairs(tracked_ui) do
        ui_despawn(spawner)
    end
    if custom_assets and custom_assets.release_owner then
        custom_assets.release_owner(mod)
    end
end


-- Cross-client sync: what this mod publishes about me, and the refresh when anyone's options change ---------
local function sync_applies(info)
    return model_on() and (info.breed == nil or not EXCLUDED_BREEDS[info.breed])
end

local sync_enabled = true
local function sync_changed()
    local api = sync_api()
    if api then
        api.changed()
    end
end

mod.sync_key = SYNC_KEY
-- info = { breed, companion_breed, templates = { [weapon_template] = true } } of my own character (fields nil
-- while I have no unit). Returns the array to publish, or nil when this mod shows nothing on my character.
mod.sync_export = function(info)
    info = info or {}
    if not sync_enabled or not sync_applies(info) then
        return nil
    end
    local mask, bit = 0, 1
    for i = 1, #SYNC_BOOLS do
        local key = SYNC_BOOLS[i]
        local v = mod:get(key)
        if v == nil then
            v = SYNC_DEFAULTS[key]
        end
        if v then
            mask = mask + bit
        end
        bit = bit * 2
    end
    local out = { SYNC_LAYOUT, mask }
    for i = 1, #SYNC_VALUES do
        local v = mod:get(SYNC_VALUES[i])
        if type(v) == "number" then
            v = math.floor(v * 100 + 0.5) / 100
        elseif type(v) ~= "string" then
            v = false -- not set: the reader falls back to its default
        end
        out[2 + i] = v
    end
    return out
end

mod.sync_refresh = function()
    for ext in pairs(sync_all) do
        if ext._unit and Unit.alive(ext._unit) and ext.force_update_item_visibility then
            pcall(ext.force_update_item_visibility, ext)
        end
    end
end

local sync_prev_setting_changed = mod.on_setting_changed
mod.on_setting_changed = function(...)
    if sync_prev_setting_changed then
        sync_prev_setting_changed(...)
    end
    sync_changed()
end

local sync_prev_disabled = mod.on_disabled
mod.on_disabled = function(...)
    sync_enabled = false
    if sync_prev_disabled then
        sync_prev_disabled(...)
    end
    sync_changed()
end

local sync_prev_enabled = mod.on_enabled
mod.on_enabled = function(...)
    sync_enabled = true
    if sync_prev_enabled then
        sync_prev_enabled(...)
    end
    sync_changed()
end
