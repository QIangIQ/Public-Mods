return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsAnkha` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsAnkha", {
            mod_script = "QIangIQsAnkha/scripts/mods/QIangIQsAnkha/QIangIQsAnkha",
            mod_data = "QIangIQsAnkha/scripts/mods/QIangIQsAnkha/QIangIQsAnkha_data",
            mod_localization = "QIangIQsAnkha/scripts/mods/QIangIQsAnkha/QIangIQsAnkha_localization",
        })
    end,
    version = "1.0.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
