return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsRearview` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsRearview", {
			mod_script       = "QIangIQsRearview/scripts/mods/QIangIQsRearview/QIangIQsRearview",
			mod_data         = "QIangIQsRearview/scripts/mods/QIangIQsRearview/QIangIQsRearview_data",
			mod_localization = "QIangIQsRearview/scripts/mods/QIangIQsRearview/QIangIQsRearview_localization",
		})
	end,
	packages = {},
}
