local mod = get_mod("QIangIQsRearview")

local function dropdown(id, default, title, tooltip, options)
	return { setting_id = id, type = "dropdown", default_value = default, localize = false, title = title, tooltip = tooltip, options = options }
end

local function numeric(id, default, lo, hi, title, tooltip)
	return { setting_id = id, type = "numeric", default_value = default, range = { lo, hi }, decimals_number = 0, localize = false, title = title, tooltip = tooltip }
end

local function opt(text, value)
	return { text = text, value = value, show_widget_localization = false }
end

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			{
				setting_id = "toggle_key",
				type = "keybind",
				default_value = {},
				keybind_trigger = "pressed",
				keybind_type = "function_call",
				function_name = "toggle_mirror",
				localize = false,
				title = "Toggle mirror (key)",
				tooltip = "Shows or hides the mirror without opening the menu.",
			},
			{
				setting_id = "mirror_on",
				type = "checkbox",
				default_value = true,
				localize = false,
				title = "Mirror on",
				tooltip = "Shows the rear silhouette view.",
			},
			dropdown("corner", "top_center", "Position", "Where the mirror sits on screen.", {
				opt("Top centre", "top_center"),
				opt("Top left", "top_left"),
				opt("Top right", "top_right"),
				opt("Bottom left", "bottom_left"),
				opt("Bottom right", "bottom_right"),
			}),
			numeric("width_pct", 28, 10, 60, "Width (percent of screen)", "Height follows a 16:9 shape."),
			numeric("fov", 75, 30, 120, "Field of view (degrees)", "Vertical field of view of the virtual rear camera."),
			{
				setting_id = "match_pitch",
				type = "checkbox",
				default_value = true,
				localize = false,
				title = "Match look pitch",
				tooltip = "The mirror tilts with your view: look down and it looks down behind you. Off keeps it level with the exact opposite of your view direction.",
			},
			{
				setting_id = "show_players",
				type = "checkbox",
				default_value = true,
				localize = false,
				title = "Show teammates",
				tooltip = "Draws your teammates (and bots) behind you as green boxes.",
			},
			{
				setting_id = "show_player_names",
				type = "checkbox",
				default_value = true,
				localize = false,
				title = "Teammate names",
				tooltip = "Labels each teammate with their name and distance.",
			},
			{
				setting_id = "show_skeleton",
				type = "checkbox",
				default_value = true,
				localize = false,
				title = "Draw skeletons (specials)",
				tooltip = "A stick figure through specials and hounds; every other enemy stays a box.",
			},
			{
				setting_id = "rave_mode",
				type = "checkbox",
				default_value = false,
				localize = false,
				title = "Rave trappers",
				tooltip = "Only trappers: their box and skeleton constantly cycle through the rainbow, so they stand out from every other enemy.",
			},
			numeric("rave_speed", 30, 5, 200, "Rave speed", "How fast the colours cycle (cycles per 100 seconds)."),
			numeric("box_fill_opacity", 45, 0, 100, "Box fill opacity (percent)", "How solid the inside of each enemy box is. 0 leaves only the outline."),
			numeric("box_outline_opacity", 100, 0, 100, "Box outline opacity (percent)", "How solid the box edges are. 0 leaves only the fill."),
			numeric("panel_opacity", 51, 0, 100, "Panel backdrop opacity (percent)", "How dark the mirror panel behind the boxes is."),
			numeric("max_range", 60, 10, 200, "Range (metres)", "Enemies further away than this are not shown."),
			numeric("heartbeat_s", 5, 1, 60, "Debug heartbeat (seconds)", "How often a status line is written to debug.log while the mirror is live."),
		},
	},
}
