return {
	mod_name = {
		en = "QIangIQ's Rearview Mirror",
	},
	mod_description = {
		en = "A rearview mirror drawn in a corner of the HUD. A real second camera crashes Darktide (engine 'Bad Skinner' assertion), so this shows everything behind you as coloured box silhouettes, mirrored like a car mirror: white = horde, orange = elite, red = special, amber = hound, purple = boss. Logs to mods/QIangIQsRearview/debug.log.",
	},
}
