local mod = get_mod("QIangIQsRearview")

--[[
    REARVIEW (silhouette mirror)

    A second camera crashes Darktide ("Bad Skinner" assertion: every character
    would be skinned twice per frame), so this mirror does not render the
    world again. It draws what is behind you instead: every enemy that is
    behind the camera is projected through a virtual rear-facing camera and
    drawn as a box silhouette in a HUD panel, coloured by threat. The panel is
    mirrored like a car mirror (things on your right appear on the right).

    Drawn from HudElementCrosshair.update with Gui.rect (the route proven by
    QIangIQsSpecialTracer). No viewport, no render target.

    Debug: ./../mods/QIangIQsRearview/debug.log (flushed per line).
--]]

local LOG_PATH = "./../mods/QIangIQsRearview/debug.log"
local LOG_MAX_BYTES = 512 * 1024
local MARGIN = 24
local MAX_RECTS = 4000

local function get_io()
	local mods = rawget(_G, "Mods")
	return mods and mods.lua and mods.lua.io or nil
end

local log_bytes = 0
local function dlog(text)
	local line = string.format("[%s] %s\n", tostring(os.date("%H:%M:%S")), text)
	if log_bytes + #line > LOG_MAX_BYTES then return end
	local io_lib = get_io()
	local f = io_lib and io_lib.open(LOG_PATH, "a")
	if not f then return end
	f:write(line) f:flush() f:close()
	log_bytes = log_bytes + #line
end

local S = { frames = 0, errors = 0, last_beat = 0, shown = 0, entities = 0, rects = 0, hidden = false }
local seen_err = {}
local function derr(tag, err)
	S.errors = S.errors + 1
	local key = tag .. tostring(err)
	if not seen_err[key] and S.errors < 60 then
		seen_err[key] = true
		dlog("ERROR " .. tag .. ": " .. tostring(err))
	end
end

-- ------------------------------------------------------------- helpers --

local function get_cam()
	local lp = Managers.player and Managers.player:local_player_safe(1)
	local vp = lp and lp.viewport_name
	local cm = vp and Managers.state and Managers.state.camera
	if not cm or not cm:has_viewport(vp) then return nil end
	local ok, c = pcall(cm.camera, cm, vp)
	return ok and c or nil
end

local function cam_frame(cam)
	local ok, F = pcall(function()
		local p = Camera.world_position(cam)
		local r = Camera.world_rotation(cam)
		local f, rt, u = Quaternion.forward(r), Quaternion.right(r), Quaternion.up(r)
		local fx, fy, fz = f.x, f.y, f.z
		local ux, uy, uz = u.x, u.y, u.z
		if mod:get("match_pitch") ~= false then
			-- rear camera: yaw turned 180 degrees, same pitch as the player's view
			-- (F.f* holds the NEGATED rear forward; the draw code uses -dot(F.f))
			local rfx, rfy, rfz = -f.x, -f.y, f.z
			local cx = rt.y * rfz - rt.z * rfy
			local cy = rt.z * rfx - rt.x * rfz
			local cz = rt.x * rfy - rt.y * rfx
			if cz < 0 then cx, cy, cz = -cx, -cy, -cz end
			local len = math.sqrt(cx * cx + cy * cy + cz * cz)
			if len > 1e-4 then
				fx, fy, fz = f.x, f.y, -f.z
				ux, uy, uz = cx / len, cy / len, cz / len
			end
		end
		return {
			ox = p.x, oy = p.y, oz = p.z,
			fx = fx, fy = fy, fz = fz,
			rx = rt.x, ry = rt.y, rz = rt.z,
			ux = ux, uy = uy, uz = uz,
		}
	end)
	return ok and F or nil
end

local function pos_of(unit, node)
	local ok, x, y, z = pcall(function()
		local v = Unit.world_position(unit, node or 1)
		return v.x, v.y, v.z
	end)
	if ok then return x, y, z end
	return nil
end

local function unit_breed(unit)
	local ok, ext = pcall(ScriptUnit.has_extension, unit, "unit_data_system")
	if not ok or not ext or not ext.breed then return nil end
	local ok2, breed = pcall(ext.breed, ext)
	if not ok2 or type(breed) ~= "table" then return nil end
	return breed
end

local function unit_alive(unit)
	if not Unit.alive(unit) then return false end
	local ok, ext = pcall(ScriptUnit.has_extension, unit, "health_system")
	if ok and ext and ext.is_alive then
		local ok2, a = pcall(ext.is_alive, ext)
		if ok2 and a == false then return false end
	end
	return true
end

-- threat class -> colour (a, r, g, b), height in metres, half-width in metres
local CLASSES = {
	boss    = { { 255, 190, 60, 255 }, 3.2, 1.0 },
	special = { { 255, 255, 50, 50 }, 1.8, 0.4 },
	hound   = { { 255, 255, 175, 40 }, 1.0, 0.5 },
	elite   = { { 255, 255, 130, 30 }, 1.9, 0.45 },
	horde   = { { 200, 210, 210, 215 }, 1.8, 0.35 },
	player  = { { 255, 70, 255, 120 }, 1.8, 0.4 },
}
local HOUNDS = { chaos_hound = true, chaos_armored_hound = true, chaos_hound_mutator = true }

local function classify(breed)
	if HOUNDS[breed.name] then return "hound" end
	if breed.is_boss then return "boss" end
	local tags = breed.tags
	if tags and tags.special then return "special" end
	if tags and tags.elite then return "elite" end
	return "horde"
end

-- ------------------------------------------------------ skeleton / rave --

local SKEL_CHAINS = {
	{ "j_hips", "j_spine", "j_spine1", "j_spine2", "j_neck", "j_head" },
	{ "j_neck", "j_leftshoulder", "j_leftarm", "j_leftforearm", "j_lefthand" },
	{ "j_neck", "j_rightshoulder", "j_rightarm", "j_rightforearm", "j_righthand" },
	{ "j_hips", "j_leftupleg", "j_leftleg", "j_leftfoot", "j_lefttoebase" },
	{ "j_hips", "j_rightupleg", "j_rightleg", "j_rightfoot", "j_righttoebase" },
}
local skel_nodes = setmetatable({}, { __mode = "k" })

local function skel_index(unit)
	local c = skel_nodes[unit]
	if c then return c end
	c = {}
	for ci = 1, #SKEL_CHAINS do
		local list = {}
		for k = 1, #SKEL_CHAINS[ci] do
			local ok, has = pcall(Unit.has_node, unit, SKEL_CHAINS[ci][k])
			if ok and has then list[#list + 1] = Unit.node(unit, SKEL_CHAINS[ci][k]) end
		end
		c[ci] = list
	end
	skel_nodes[unit] = c
	return c
end

local function rave_rgb(t, offset)
	local h = ((t + (offset or 0)) % 1) * 6
	local i = math.floor(h)
	local f = h - i
	local q = 1 - f
	if i == 0 then return 255, math.floor(f * 255), 0 end
	if i == 1 then return math.floor(q * 255), 255, 0 end
	if i == 2 then return 0, 255, math.floor(f * 255) end
	if i == 3 then return 0, math.floor(q * 255), 255 end
	if i == 4 then return math.floor(f * 255), 0, 255 end
	return 255, 0, math.floor(q * 255)
end

-- --------------------------------------------------------------- scan --

local tracked = {}
local last_scan = -10

local function scan()
	local ext = Managers.state and Managers.state.extension
	if not ext then return end
	local entities = ext:get_entities("MinionHuskLocomotionExtension")
	if next(entities) == nil then
		entities = ext:get_entities("MinionLocomotionExtension")
	end
	local seen, n = {}, 0
	for unit in pairs(entities) do
		n = n + 1
		local e = tracked[unit]
		if not e then
			local breed = unit_breed(unit)
			if breed then
				e = { class = classify(breed), name = breed.name, trapper = breed.name == "renegade_netgunner" }
				tracked[unit] = e
			end
		end
		if e then seen[unit] = true end
	end
	for unit in pairs(tracked) do
		if not seen[unit] then tracked[unit] = nil end
	end
	S.entities = n
end

-- ------------------------------------------------------------- players --

local font_cache = nil
local function font_path()
	if font_cache then return font_cache end
	local ok_f, UIFonts = pcall(require, "scripts/managers/ui/ui_fonts")
	if ok_f and UIFonts and UIFonts.data_by_type then
		local ok, data = pcall(UIFonts.data_by_type, "proxima_nova_bold")
		if ok and data and data.path then font_cache = data.path return font_cache end
	end
	local fm = Managers.font
	if fm and fm.data_by_type then
		local ok, data = pcall(fm.data_by_type, fm, "proxima_nova_bold")
		if ok and data and data.path then font_cache = data.path end
	end
	return font_cache
end

local function draw_text(gui, text, font, size, x, y, colour)
	local g2 = rawget(_G, "Gui2")
	if g2 and g2.slug_text then
		local ok = pcall(g2.slug_text, gui, text, font, size, Vector3(x, y, 1000), Vector2(math.huge, math.huge), { shadow = false, color = colour })
		if ok then return end
	end
	pcall(Gui.slug_text, gui, text, font, size, Vector3(x, y, 1001), nil, colour)
end

local PLAYER_COLOUR = { 255, 70, 255, 120 }

-- Teammates (everyone but the local player) as plain-number entries.
local function gather_players()
	local out = {}
	local pm = Managers.player
	if not pm then return out end
	local me = pm:local_player_safe(1)
	for _, player in pairs(pm:players()) do
		if player ~= me then
			local ok = pcall(function()
				local unit = player.player_unit
				if unit and unit_alive(unit) then
					local name = player:name() or "?"
					local human = player:is_human_controlled()
					out[#out + 1] = { unit = unit, name = human and name or ("[bot] " .. name) }
				end
			end)
			if not ok then S.errors = S.errors + 1 end
		end
	end
	return out
end

-- --------------------------------------------------------------- draw --

local rect_count = 0
local function rect(gui, x, y, w, h, c)
	if rect_count >= MAX_RECTS or w <= 0 or h <= 0 then return end
	rect_count = rect_count + 1
	Gui.rect(gui, Vector3(x, y, 999), Vector2(w, h), Color(c[1], c[2], c[3], c[4]))
end

local function clampn(v, a, b) return v < a and a or (v > b and b or v) end

local function panel_origin(corner, w, h)
	local rw, rh = RESOLUTION_LOOKUP.width, RESOLUTION_LOOKUP.height
	local x
	if corner == "top_left" or corner == "bottom_left" then
		x = MARGIN
	elseif corner == "top_right" or corner == "bottom_right" then
		x = rw - w - MARGIN
	else
		x = (rw - w) * 0.5
	end
	local y = (corner == "bottom_left" or corner == "bottom_right") and (rh - h - MARGIN) or MARGIN
	return x, y
end

local function overlay(ui_renderer)
	S.frames = S.frames + 1
	local now = os.clock()
	if S.hidden or not mod:get("mirror_on") then return end
	local cam = get_cam()
	local F = cam and cam_frame(cam)
	if not F then return end

	if now - last_scan >= 0.2 then
		last_scan = now
		local ok, err = pcall(scan)
		if not ok then derr("scan", err) end
	end

	local gui = ui_renderer.gui
	rect_count = 0
	S.shown = 0

	local pw = RESOLUTION_LOOKUP.width * ((mod:get("width_pct") or 28) / 100)
	local ph = pw * 9 / 16
	local px, py = panel_origin(mod:get("corner") or "top_center", pw, ph)

	-- backdrop, frame and horizon
	rect(gui, px, py, pw, ph, { math.floor(255 * (mod:get("panel_opacity") or 51) / 100), 8, 10, 14 })
	local fc = { 255, 200, 200, 210 }
	rect(gui, px - 2, py - 2, pw + 4, 2, fc)
	rect(gui, px - 2, py + ph, pw + 4, 2, fc)
	rect(gui, px - 2, py, 2, ph, fc)
	rect(gui, px + pw, py, 2, ph, fc)
	rect(gui, px, py + ph * 0.5, pw, 1, { 90, 200, 200, 210 })

	local vfov = math.rad(mod:get("fov") or 75)
	local tv = math.tan(vfov * 0.5)
	local th = tv * 16 / 9
	local max_r2 = (mod:get("max_range") or 60) ^ 2

	-- far-to-near so near enemies draw on top
	local list = {}
	for unit, e in pairs(tracked) do
		local ok = pcall(function()
			if not unit_alive(unit) then tracked[unit] = nil return end
			local x, y, z = pos_of(unit, 1)
			if not x then return end
			local dx, dy, dz = x - F.ox, y - F.oy, z - F.oz
			local d2 = dx * dx + dy * dy + dz * dz
			if d2 > max_r2 then return end
			local depth = -(dx * F.fx + dy * F.fy + dz * F.fz) -- along the rear-facing camera
			if depth < 0.4 then return end
			list[#list + 1] = { unit = unit, e = e, dx = dx, dy = dy, dz = dz, depth = depth, d2 = d2 }
		end)
		if not ok then S.errors = S.errors + 1 end
	end
	if mod:get("show_players") ~= false then
		for _, pl in ipairs(gather_players()) do
			pcall(function()
				local x, y, z = pos_of(pl.unit, 1)
				if not x then return end
				local dx, dy, dz = x - F.ox, y - F.oy, z - F.oz
				local d2 = dx * dx + dy * dy + dz * dz
				if d2 > max_r2 then return end
				local depth = -(dx * F.fx + dy * F.fy + dz * F.fz)
				if depth < 0.4 then return end
				list[#list + 1] = { unit = pl.unit, e = { class = "player", name = pl.name, player = true },
					dx = dx, dy = dy, dz = dz, depth = depth, d2 = d2 }
			end)
		end
	end
	table.sort(list, function(a, b) return a.depth > b.depth end)

	local cl = { px, py, px + pw, py + ph }
	local nskel = 0
	local rave = mod:get("rave_mode")
	local rave_speed = (mod:get("rave_speed") or 30) / 100
	local skeleton = mod:get("show_skeleton")
	local cl_r, cl_g, cl_b = 255, 255, 255
	for i = 1, #list do
		local it = list[i]
		local cls = CLASSES[it.e.class] or CLASSES.horde
		local col, height, hw = cls[1], cls[2], cls[3]
		-- mirrored: positive world-right stays on screen-right
		local sx = (it.dx * F.rx + it.dy * F.ry + it.dz * F.rz) / it.depth / th
		local sy_feet = (it.dx * F.ux + it.dy * F.uy + it.dz * F.uz) / it.depth / tv
		local sy_head = sy_feet + height / it.depth / tv
		local w = hw * 2 / it.depth / th
		local x1 = px + pw * (0.5 + 0.5 * (sx - w * 0.5))
		local x2 = px + pw * (0.5 + 0.5 * (sx + w * 0.5))
		local y_f = py + ph * (0.5 - 0.5 * sy_feet)
		local y_h = py + ph * (0.5 - 0.5 * sy_head)
		x1, x2 = clampn(x1, cl[1], cl[3]), clampn(x2, cl[1], cl[3])
		local ya, yb = clampn(math.min(y_h, y_f), cl[2], cl[4]), clampn(math.max(y_h, y_f), cl[2], cl[4])
		if x2 - x1 >= 1 and yb - ya >= 1 then
			local fade = clampn(1.2 - it.depth / ((mod:get("max_range") or 60) * 1.1), 0.35, 1)
			local c = { math.floor(col[1] * fade), col[2], col[3], col[4] }
			if rave and it.e.trapper then
				c[2], c[3], c[4] = rave_rgb(now * rave_speed, i * 0.11)
			end
			local fo = (mod:get("box_fill_opacity") or 45) / 100
			local oo = (mod:get("box_outline_opacity") or 100) / 100
			local oc = { math.floor(c[1] * oo), c[2], c[3], c[4] }
			if fo > 0 then
				rect(gui, x1, ya, x2 - x1, yb - ya, { math.floor(c[1] * fo), c[2], c[3], c[4] })
			end
			if oo > 0 then
				rect(gui, x1, ya, x2 - x1, 2, oc)
				rect(gui, x1, yb - 2, x2 - x1, 2, oc)
				rect(gui, x1, ya, 2, yb - ya, oc)
				rect(gui, x2 - 2, ya, 2, yb - ya, oc)
			end
			S.shown = S.shown + 1
			if it.e.player and mod:get("show_player_names") ~= false then
				local font = font_path()
				if font then
					local label = string.format("%s  %dm", it.e.name, math.floor(math.sqrt(it.d2) + 0.5))
					local size = 18
					local lx = clampn((x1 + x2) * 0.5 - #label * size * 0.25, cl[1], cl[3] - #label * size * 0.5)
					local ly = clampn(ya - size - 2, cl[2], cl[4] - size)
					draw_text(gui, label, font, size, lx + 1, ly + 1, { 220, 0, 0, 0 })
					draw_text(gui, label, font, size, lx, ly, { 255, 150, 255, 180 })
				end
			end
		end

		-- stick figure for the nearest few
		if skeleton and (it.e.class == "special" or it.e.class == "hound") and nskel < 14 then
			nskel = nskel + 1
			local okk, errk = pcall(function()
				local idx = skel_index(it.unit)
				local c = { 255, cl_r, cl_g, cl_b }
				if rave and it.e.trapper then
					c[2], c[3], c[4] = rave_rgb(now * rave_speed, i * 0.11)
				else
					c[2], c[3], c[4] = col[2], col[3], col[4]
				end
				for ci = 1, #idx do
					local nodes = idx[ci]
					local have, ax, ay = false, 0, 0
					for k = 1, #nodes do
						local v = Unit.world_position(it.unit, nodes[k])
						local dx, dy, dz = v.x - F.ox, v.y - F.oy, v.z - F.oz
						local dep = -(dx * F.fx + dy * F.fy + dz * F.fz)
						local bx, by
						if dep > 0.3 then
							bx = px + pw * (0.5 + 0.5 * ((dx * F.rx + dy * F.ry + dz * F.rz) / dep / th))
							by = py + ph * (0.5 - 0.5 * ((dx * F.ux + dy * F.uy + dz * F.uz) / dep / tv))
						end
						if have and bx then
							local len = math.sqrt((bx - ax) ^ 2 + (by - ay) ^ 2)
							local steps = math.min(math.floor(len / 1.5) + 1, 80)
							for sI = 0, steps do
								local f = sI / steps
								local x, y = ax + (bx - ax) * f, ay + (by - ay) * f
								if x >= cl[1] and x <= cl[3] - 2 and y >= cl[2] and y <= cl[4] - 2 then
									rect(gui, x, y, 2, 2, c)
								end
							end
						end
						if bx then have, ax, ay = true, bx, by else have = false end
					end
				end
			end)
			if not okk then derr("skeleton", errk) end
		end
	end
	S.rects = rect_count

	local beat = mod:get("heartbeat_s") or 5
	if now - S.last_beat >= beat then
		S.last_beat = now
		dlog(string.format("beat frames=%d entities=%d tracked=%d shown=%d rects=%d errors=%d",
			S.frames, S.entities, (function() local c = 0 for _ in pairs(tracked) do c = c + 1 end return c end)(), S.shown, S.rects, S.errors))
	end
end

mod:hook_safe("HudElementCrosshair", "update", function(self, dt, t, ui_renderer)
	if not ui_renderer or not ui_renderer.gui then return end
	local ok, err = pcall(overlay, ui_renderer)
	if not ok then derr("overlay", err) end
end)

-- ----------------------------------------------------------- plumbing --

mod.toggle_mirror = function()
	local on = not mod:get("mirror_on")
	mod:set("mirror_on", on)
	mod:notify("Rearview mirror %s", on and "on" or "off")
	dlog("toggle: mirror_on=" .. tostring(on))
end

mod.on_setting_changed = function(id)
	dlog("setting " .. tostring(id) .. "=" .. tostring(mod:get(id)))
end

mod.on_game_state_changed = function(status, state_name)
	if status == "enter" then tracked = {} end
end

mod.on_unload = function() dlog("unload") end

mod:command("rearview_status", "Rearview: write the current state to debug.log", function()
	dlog(string.format("status frames=%d entities=%d shown=%d rects=%d errors=%d on=%s",
		S.frames, S.entities, S.shown, S.rects, S.errors, tostring(mod:get("mirror_on"))))
	mod:echo("Rearview status written to " .. LOG_PATH)
end)

mod:command("rearview_log_clear", "Rearview: empty debug.log", function()
	local io_lib = get_io()
	local f = io_lib and io_lib.open(LOG_PATH, "w")
	if f then f:close() end
	log_bytes = 0
	mod:echo("Rearview debug log cleared")
end)

dlog("loaded (silhouette mirror, no second camera)")
