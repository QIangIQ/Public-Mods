return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsDominanceAnubis` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsDominanceAnubis", {
            mod_script = "QIangIQsDominanceAnubis/scripts/mods/QIangIQsDominanceAnubis/QIangIQsDominanceAnubis",
            mod_data = "QIangIQsDominanceAnubis/scripts/mods/QIangIQsDominanceAnubis/QIangIQsDominanceAnubis_data",
            mod_localization = "QIangIQsDominanceAnubis/scripts/mods/QIangIQsDominanceAnubis/QIangIQsDominanceAnubis_localization",
        })
    end,
    version = "1.11.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
