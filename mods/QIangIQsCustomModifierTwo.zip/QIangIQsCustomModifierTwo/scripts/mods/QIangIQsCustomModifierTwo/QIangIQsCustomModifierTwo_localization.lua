return {
	mod_name = {
		en = "QIangIQ's Custom Modifier Two",
	},
	mod_description = {
		en = "Restores the Havoc \"Sticky Poxbursters\" modifier for SoloPlay. When a poxburster explodes, every player within 5 m is covered in bile (30 percent slower for 10 seconds) and a poxwalker pack is sent after each player hit. Chance and pack options apply immediately; activation applies from the next mission.",
	},
	activation_mode = {
		en = "Activation",
	},
	activation_mode_description = {
		en = "Every SoloPlay mission: always active in your own offline games.\nSticky Poxbursters condition only: active only when that condition is selected (needs this mod above SoloPlay in the load order).\nOff: never active.",
	},
	activation_always = {
		en = "Every SoloPlay mission",
	},
	activation_condition = {
		en = "Sticky Poxbursters condition only",
	},
	activation_off = {
		en = "Off",
	},
	bomber_chance = {
		en = "Sticky poxburster chance (percent)",
	},
	bomber_chance_description = {
		en = "Chance for each poxburster to be sticky. The game's own value is 100.",
	},
	spawn_packs = {
		en = "Spawn poxwalker packs",
	},
	spawn_packs_description = {
		en = "On: each player hit by the bile gets a pack of 10-12 mutated poxwalkers sent after them (the game's behaviour).\nOff: bile only.",
	},
	max_enemies = {
		en = "Stop spawning packs above this many enemies",
	},
	max_enemies_description = {
		en = "No new pack is spawned while this many enemies are alive or queued.",
	},
}
