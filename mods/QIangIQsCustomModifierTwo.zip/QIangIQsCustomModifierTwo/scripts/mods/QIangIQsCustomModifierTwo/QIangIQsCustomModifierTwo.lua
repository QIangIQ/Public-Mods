-- QIangIQsCustomModifierTwo: Sticky Poxbursters for SoloPlay
--
-- Uses the game's own, unmodified pieces:
--   mutator  mutator_havoc_sticky_poxburster   mutator_havoc_templates.lua:90-143
--            (MutatorNurgleWarp; gives the buff to poxbursters at 100%, lines 92-99;
--             three poxwalker packs, lines 101-142)
--   buff     havoc_sticky_poxburster           havoc_buff_templates.lua:591-616
--   bile     _apply_poxburster_bile            havoc_buff_templates.lua:562-589 (5 m radius)
--   debuff   hit_by_poxburster_bile            minion_buff_templates.lua:267-287
--
-- Missing in the game (defined here as a marker only):
--   mutator  mutator_armored_bombers           loaded by circumstance mutator_havoc_sticky_poxbursters
--            (havoc_circumstance_template.lua:123-136). Its breed chaos_armored_bomber does
--            not exist in scripts/settings/breed/breeds, so this half cannot be restored.
--
-- Why the effect is triggered from the explosion:
--   The buff has no conditional_exit_func, so its stop_func only runs when the corpse's
--   buff extension is destroyed (buff.lua:843-848, buff_extension_base.lua:137-142).
--   SoloPlay skips exactly that call for this buff (SoloPlay workarounds/havoc.lua:79),
--   so under SoloPlay the effect never fires. Here the native stop_func is run once,
--   right after BtChaosPoxwalkerExplodeAction.enter creates the explosion, while the
--   unit and its position still exist.

local mod = get_mod("QIangIQsCustomModifierTwo")

local function soloplay()
	return get_mod("SoloPlay")
end

mod.on_all_mods_loaded = function ()
	if not soloplay() then
		mod:error("SoloPlay is required and must be enabled")
	end
end

local MatchmakingConstants = require("scripts/settings/network/matchmaking_constants")
local MutatorManager = require("scripts/managers/mutator/mutator_manager")
local MutatorNurgleWarp = require("scripts/managers/mutator/mutators/mutator_nurgle_warp")
local MutatorTemplates = require("scripts/settings/mutator/mutator_templates")
local BtChaosPoxwalkerExplodeAction = require("scripts/extension_systems/behavior/nodes/actions/bt_chaos_poxwalker_explode_action")
local HOST_TYPES = MatchmakingConstants.HOST_TYPES

local STICKY_MUTATOR = "mutator_havoc_sticky_poxburster"
local STICKY_BUFF = "havoc_sticky_poxburster"
local ARMORED_BOMBERS_MUTATOR = "mutator_armored_bombers"
local BOMBER_BREED = "chaos_poxwalker_bomber"
local DEFAULT_MAX_ENEMIES = 240 -- HavocEnemyDirector planner.lua default total_cap

-- Marker only, like mutator_single_twin (mutator_modify_pacing_templates.lua:724-726).
-- Lets SoloPlay accept the "Sticky Poxbursters" condition; its presence also tells the
-- loader below that the condition was selected.
local armored_bombers_marker = {
	name = ARMORED_BOMBERS_MUTATOR,
	class = "scripts/managers/mutator/mutators/mutator_base",
}

mod:hook_require("scripts/settings/mutator/mutator_templates", function (templates)
	if templates[ARMORED_BOMBERS_MUTATOR] == nil then
		templates[ARMORED_BOMBERS_MUTATOR] = armored_bombers_marker
	end
end)

-- The native mutator's breed chance table (mutator_havoc_templates.lua:96-99).
-- Only the real poxburster entry is changed; chaos_armored_bomber is left as-is.
local native_bomber_chance

local function sticky_template()
	return MutatorTemplates[STICKY_MUTATOR]
end

local function refresh_bomber_chance()
	local template = sticky_template()
	local chances = template and template.random_spawn_buff_templates and template.random_spawn_buff_templates.breed_chances

	if not chances then
		return
	end

	if native_bomber_chance == nil then
		native_bomber_chance = chances[BOMBER_BREED]
	end

	chances[BOMBER_BREED] = math.min(math.max((mod:get("bomber_chance") or 100) / 100, 0), 1)
end

refresh_bomber_chance()

local handled = setmetatable({}, { __mode = "k" })
local native_stop_func

mod:hook_require("scripts/settings/buff/havoc_buff_templates", function (templates)
	local template = templates[STICKY_BUFF]

	if not template or template.__qiangiq_two_modified then
		return
	end

	native_stop_func = template.stop_func

	-- Units already handled at the explosion do nothing later. Everything else keeps
	-- the previous behaviour (including SoloPlay's own wrapper, whichever loads first).
	template.stop_func = function (template_data, template_context, extension_destroyed)
		if handled[template_context.unit] then
			return
		end

		return native_stop_func(template_data, template_context, extension_destroyed)
	end
	template.__qiangiq_two_modified = true
end)

local function run_sticky_effect(unit)
	handled[unit] = true

	local mutator_manager = Managers.state and Managers.state.mutator

	-- The native stop_func indexes this mutator without a nil check (line 608-612).
	if not native_stop_func or not mutator_manager or not mutator_manager:mutator(STICKY_MUTATOR) then
		return
	end

	local side_system = Managers.state.extension:system("side_system")
	-- Same value the buff's start_func stores (havoc_buff_templates.lua:595-600).
	local template_data = {
		side = side_system.side_by_unit[unit],
	}

	if not template_data.side then
		return
	end

	local ok, err = pcall(native_stop_func, template_data, { unit = unit, is_server = true }, false)

	if not ok then
		mod:error("sticky poxburster effect skipped: %s", tostring(err))
	end
end

mod:hook_safe(BtChaosPoxwalkerExplodeAction, "enter", function (self, unit)
	if handled[unit] or not Managers.state.game_session or not Managers.state.game_session:is_server() then
		return
	end

	local buff_extension = ScriptUnit.has_extension(unit, "buff_system")

	if buff_extension and buff_extension:has_buff_using_buff_template(STICKY_BUFF) then
		run_sticky_effect(unit)
	end
end)

-- Same singleplay test as SoloPlay's is_soloplay (SoloPlay.lua:28-41), with the
-- host-type part alone while the game mode may not exist yet.
local function soloplay_authority()
	-- Never in the Mourningstar hub.
	local game_mode_manager = Managers.state and Managers.state.game_mode
	if game_mode_manager and game_mode_manager:game_mode_name() == "hub" then
		return false
	end

	-- Hosting a Realms game: the session host type is HOST_TYPES.player there
	-- (Realms connection_host.lua:641-642), so SoloPlay's singleplay test fails.
	-- Same host test as realms_loadout talents/session.lua:31-40.
	local session = Managers.multiplayer_session
	if session and session:host_type() == HOST_TYPES.player then
		local connection = Managers.connection

		return connection ~= nil and connection:is_host() and true or false
	end

	local solo = soloplay()

	if not solo then
		return false
	end

	if solo.has_local_gameplay_authority then
		return solo.has_local_gameplay_authority() and true or false
	end

	if Managers.state and Managers.state.game_mode then
		return solo.is_soloplay()
	end

	local session = Managers.multiplayer_session

	return session ~= nil and session:host_type() == HOST_TYPES.singleplay
end

-- Load once per mission through the native single-mutator loader (same approach as
-- HavocConditionManager condition_compatibility.lua:41-59).
mod:hook_safe(MutatorManager, "_load_mutators", function (self)
	if not self._is_server or self._mutators[STICKY_MUTATOR] or not sticky_template() then
		return
	end

	local mode = mod:get("activation_mode") or "always"

	if mode == "off" then
		return
	end

	local condition_selected = self._mutators[ARMORED_BOMBERS_MUTATOR] ~= nil
	local wanted = condition_selected or mode == "always" and soloplay_authority()

	if not wanted then
		return
	end

	refresh_bomber_chance()
	self:load_mutator_from_name(STICKY_MUTATOR)
	mod:info("loaded %s (%s)", STICKY_MUTATOR, condition_selected and "Sticky Poxbursters condition" or "always on")
end)

-- Pack spawns: optional, and capped. Only for the sticky mutator's own instance.
mod:hook(MutatorNurgleWarp, "spawn_random_from_template", function (func, self, optional_target_unit)
	if self._template ~= sticky_template() then
		return func(self, optional_target_unit)
	end

	if not mod:get("spawn_packs") then
		return
	end

	local minion_spawn_manager = Managers.state and Managers.state.minion_spawn
	local queued = self._spawn_queue_size or 0
	local max_enemies = mod:get("max_enemies") or DEFAULT_MAX_ENEMIES

	if minion_spawn_manager and minion_spawn_manager:total_allocated_num_enemies() + queued >= max_enemies then
		return
	end

	return func(self, optional_target_unit)
end)

mod.on_setting_changed = function ()
	refresh_bomber_chance()
end

mod.on_disabled = function ()
	local template = sticky_template()
	local chances = template and template.random_spawn_buff_templates and template.random_spawn_buff_templates.breed_chances

	if chances and native_bomber_chance ~= nil then
		chances[BOMBER_BREED] = native_bomber_chance
	end
end

mod.on_enabled = function ()
	refresh_bomber_chance()
end
