local mod = get_mod("QIangIQsCustomModifierTwo")

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			{
				setting_id    = "activation_mode",
				type          = "dropdown",
				default_value = "always",
				options = {
					{ text = "activation_always",    value = "always" },
					{ text = "activation_condition", value = "condition" },
					{ text = "activation_off",       value = "off" },
				},
			},
			{
				setting_id    = "bomber_chance",
				type          = "numeric",
				default_value = 100,
				range         = { 0, 100 },
			},
			{
				setting_id    = "spawn_packs",
				type          = "checkbox",
				default_value = true,
			},
			{
				setting_id    = "max_enemies",
				type          = "numeric",
				default_value = 240,
				range         = { 20, 600 },
			},
		},
	},
}
