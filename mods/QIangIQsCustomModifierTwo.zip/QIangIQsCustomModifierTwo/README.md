# QIangIQsCustomModifierTwo: Sticky Poxbursters for SoloPlay

When a poxburster explodes, every player within 5 m (bots included) gets
poxburster bile: 30% slower for 10 seconds, with the vomit screen effect.
For **each player hit**, a pack of 10–12 mutated poxwalkers spawns out of
sight ahead and is sent after that player.

This is the game's own Havoc "Sticky Poxbursters" code, triggered at the moment
of the explosion instead of at corpse cleanup. SoloPlay blocks the cleanup path
(`workarounds/havoc.lua` line 79), so without this mod the effect never fires.

## Options
| Option | Default | |
|---|---|---|
| Activation | Every SoloPlay mission | or only with the "Sticky Poxbursters" condition (mod above SoloPlay), or off |
| Sticky poxburster chance (percent) | 100 | game's own value is 100 |
| Spawn poxwalker packs | On | Off = bile only |
| Stop spawning packs above this many enemies | 240 | |

## Source
* Mutator `mutator_havoc_sticky_poxburster`: `mutator_havoc_templates.lua` 90–143
* Buff `havoc_sticky_poxburster` and bile: `havoc_buff_templates.lua` 560–616
* Bile debuff `hit_by_poxburster_bile`: `minion_buff_templates.lua` 267–287
* Pack spawning `MutatorNurgleWarp`: `mutator_nurgle_warp.lua`
* Explosion `BtChaosPoxwalkerExplodeAction.enter`: `bt_chaos_poxwalker_explode_action.lua`

Not restored: `mutator_armored_bombers`. It isn't defined anywhere and its
breed (`chaos_armored_bomber`) doesn't exist. This mod registers an empty
placeholder under that name only so SoloPlay will let you pick the condition.
