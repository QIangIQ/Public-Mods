return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsCustomModifierTwo` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsCustomModifierTwo", {
			mod_script       = "QIangIQsCustomModifierTwo/scripts/mods/QIangIQsCustomModifierTwo/QIangIQsCustomModifierTwo",
			mod_data         = "QIangIQsCustomModifierTwo/scripts/mods/QIangIQsCustomModifierTwo/QIangIQsCustomModifierTwo_data",
			mod_localization = "QIangIQsCustomModifierTwo/scripts/mods/QIangIQsCustomModifierTwo/QIangIQsCustomModifierTwo_localization",
		})
	end,
	packages = {},
}
