return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsPowerAxe` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsPowerAxe", {
            mod_script = "QIangIQsPowerAxe/scripts/mods/QIangIQsPowerAxe/QIangIQsPowerAxe",
            mod_data = "QIangIQsPowerAxe/scripts/mods/QIangIQsPowerAxe/QIangIQsPowerAxe_data",
            mod_localization = "QIangIQsPowerAxe/scripts/mods/QIangIQsPowerAxe/QIangIQsPowerAxe_localization",
        })
    end,
    version = "0.2.0",
    author = "QIangIQ",
    packages = {},
}
