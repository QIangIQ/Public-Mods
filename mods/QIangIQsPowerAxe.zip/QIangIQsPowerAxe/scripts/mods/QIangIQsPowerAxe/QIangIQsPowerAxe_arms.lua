
-- First-person arm playback of the Vermintide 2 billhook clips (QIangIQsPowerAxe 0.3.0).
--
-- Method = QIangIQsChainLaspistol_brace.lua (QIangIQsKarambit / QIangIQsButterflyKnife driver method, seen working in game):
-- a skeleton-only "driver" unit with the first-person bone names (Custom/pa_fp_driver, a rename of cl_fp_driver) is linked to
-- the first-person unit; every frame it copies the animated first-person pose, the arm mesh units are re-linked to it with
-- LINK_MODE_NODE_NAME, and Lua then overrides bones: both arms are solved with a two-bone IK towards hand targets and the
-- hands get their rotation from the hand's finger bones (forward = hand -> j_*handmiddle1, up = j_*handpinky1 -> j_*handindex1).
-- The targets come from QIangIQsPowerAxe_billhook.lua: the VT2 first-person rig's hands, elbows and weapon-attach frame,
-- baked in the camera / weapon-attach frame (A:\Dowloads\staging\vt2\bake_lua.py), so the arm shapes are VT2's and the
-- Darktide arm lengths only decide how far each hand can reach. The weapon rig is moved to the baked attach frame.
local Arms = {}
local CFG = nil

function Arms.setup(cfg)
    CFG = cfg
end

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function parent_chain(unit, node)
    local list, current, guard = {}, node, 0

    while current and guard < 64 do
        list[#list + 1] = current

        if current == 1 then
            break
        end

        current = Unit.scene_graph_parent(unit, current)
        guard = guard + 1
    end

    return list
end

local function root_relative(unit, node)
    if node == nil or node == 1 then
        return Quaternion.identity(), Vector3(0, 0, 0)
    end

    local chain = parent_chain(unit, node)
    local rotation, position = Quaternion.identity(), Vector3(0, 0, 0)
    local first = chain[#chain] == 1 and #chain - 1 or #chain

    for i = first, 1, -1 do
        position = position + Quaternion.rotate(rotation, Unit.local_position(unit, chain[i]))
        rotation = Quaternion.multiply(rotation, Unit.local_rotation(unit, chain[i]))
    end

    return rotation, position
end

local REQUIRED = {
    "j_leftarm", "j_leftforearm", "j_lefthand", "j_lefthandmiddle1", "j_lefthandindex1", "j_lefthandpinky1",
    "j_rightarm", "j_rightforearm", "j_righthand", "j_righthandmiddle1", "j_righthandindex1", "j_righthandpinky1",
    "j_rightweaponattach", "ap_camera_node",
}

local function make_fpd(driver, fp_unit)
    local fpd = { driver = driver, fp_unit = fp_unit, nodes = {}, by_node = {}, fp_chains = {} }

    for _, name in ipairs(CFG.fp_nodes) do
        if Unit.has_node(driver, name) then
            local node = Unit.node(driver, name)

            if node ~= 1 and not fpd.by_node[node] then
                local entry = { node = node, parent = Unit.scene_graph_parent(driver, node) }

                if Unit.has_node(fp_unit, name) then
                    entry.fp = Unit.node(fp_unit, name)
                    fpd.fp_chains[entry.fp] = parent_chain(fp_unit, entry.fp)
                end

                fpd.by_node[node] = entry
                fpd.nodes[#fpd.nodes + 1] = entry
            end
        end
    end

    for _, name in ipairs(REQUIRED) do
        if not Unit.has_node(driver, name) then
            return nil, name
        end
    end

    return fpd
end

local function copy_pose(fpd)
    local driver, fp_unit = fpd.driver, fpd.fp_unit
    local poses = {}

    local function pose_of(node)
        if node == nil or node == 1 then
            return Quaternion.identity(), Vector3(0, 0, 0)
        end

        local pose = poses[node]

        if pose then
            return pose[1], pose[2]
        end

        local entry = fpd.by_node[node]
        local rotation, position

        if entry and entry.fp then
            local chain = fpd.fp_chains[entry.fp]
            rotation, position = Quaternion.identity(), Vector3(0, 0, 0)

            local first = chain[#chain] == 1 and #chain - 1 or #chain

            for i = first, 1, -1 do
                position = position + Quaternion.rotate(rotation, Unit.local_position(fp_unit, chain[i]))
                rotation = Quaternion.multiply(rotation, Unit.local_rotation(fp_unit, chain[i]))
            end
        else
            local parent_rotation, parent_position = pose_of(Unit.scene_graph_parent(driver, node))

            rotation = Quaternion.multiply(parent_rotation, Unit.local_rotation(driver, node))
            position = parent_position + Quaternion.rotate(parent_rotation, Unit.local_position(driver, node))
        end

        poses[node] = { rotation, position }

        return rotation, position
    end

    for i = 1, #fpd.nodes do
        local entry = fpd.nodes[i]

        if entry.fp then
            local rotation, position = pose_of(entry.node)
            local parent_rotation, parent_position = pose_of(entry.parent)
            local inverse_parent = Quaternion.inverse(parent_rotation)

            Unit.set_local_rotation(driver, entry.node, Quaternion.multiply(inverse_parent, rotation))
            Unit.set_local_position(driver, entry.node, Quaternion.rotate(inverse_parent, position - parent_position))
        end
    end
end

-- IK helpers (driver root-relative space), QIangIQsChainLaspistol_brace.lua ----------------------------------------------
local function rotation_between(u, v)
    local lu, lv = Vector3.length(u), Vector3.length(v)

    if lu < 1e-6 or lv < 1e-6 then
        return Quaternion.identity()
    end

    u, v = u * (1 / lu), v * (1 / lv)

    local axis = Vector3.cross(u, v)
    local s = Vector3.length(axis)

    if s < 1e-6 then
        return Quaternion.identity()
    end

    return Quaternion.axis_angle(axis * (1 / s), math.atan2(s, Vector3.dot(u, v)))
end

local function turn_node(driver, node, q)
    local pr = root_relative(driver, Unit.scene_graph_parent(driver, node))
    local r = root_relative(driver, node)

    Unit.set_local_rotation(driver, node, Quaternion.multiply(Quaternion.inverse(pr), Quaternion.multiply(q, r)))
end

local function pos(driver, name)
    local _, p = root_relative(driver, Unit.node(driver, name))

    return p
end

local function two_bone(driver, side, target, pole_point)
    local arm, fore = Unit.node(driver, "j_" .. side .. "arm"), Unit.node(driver, "j_" .. side .. "forearm")
    local S, E, H = pos(driver, "j_" .. side .. "arm"), pos(driver, "j_" .. side .. "forearm"), pos(driver, "j_" .. side .. "hand")
    local a, b = Vector3.length(E - S), Vector3.length(H - E)
    local to_target = target - S
    local d = math.clamp(Vector3.length(to_target), math.abs(a - b) + 1e-3, a + b - 1e-3)
    local dir = Vector3.normalize(to_target)
    local pv = pole_point - S

    pv = pv - dir * Vector3.dot(pv, dir)

    if Vector3.length(pv) < 1e-5 then
        pv = (E - S) - dir * Vector3.dot(E - S, dir)
    end

    if Vector3.length(pv) < 1e-5 then
        return
    end

    pv = Vector3.normalize(pv)

    local cos_a = math.clamp((a * a + d * d - b * b) / (2 * a * d), -1, 1)
    local sin_a = math.sqrt(math.max(0, 1 - cos_a * cos_a))
    local elbow = S + dir * (cos_a * a) + pv * (sin_a * a)

    turn_node(driver, arm, rotation_between(E - S, elbow - S))

    local E1, H1 = pos(driver, "j_" .. side .. "forearm"), pos(driver, "j_" .. side .. "hand")

    turn_node(driver, fore, rotation_between(H1 - E1, (S + dir * d) - E1))
end

-- Baked clips ----------------------------------------------------------------------------------------------------------
local function lerp_frames(a, b, w)
    local out = {}

    for k = 1, #a do
        out[k] = a[k] + (b[k] - a[k]) * w
    end

    return out
end

local function sample(clip, t, loop)
    local frames = clip.frames
    local n = #frames
    local x = (loop and (t % clip.length) or math.clamp(t, 0, clip.length)) / clip.length * (n - 1)
    local i = math.min(math.floor(x), n - 2)

    return lerp_frames(frames[i + 1], frames[i + 2], x - i)
end

-- clip names per weapon set (the bake files hold every clip of the VT2 set except the inspect / idle offsets)
local SETS = {
    billhook = {
        idle = "idle", walk = "walk", run = "run", equip = "equip", push = "attack_swing_stab_02",
        special = "attack_swing_stab_02", stab = "attack_swing_stab_01",
        left = "attack_swing_left", right = "attack_swing_left_diagonal_01", left_diagonal = "attack_swing_left_diagonal_01",
        inspect_start = "inspect_start", inspect_loop = "inspect_loop", inspect_end = "inspect_end",
        -- VT2 billhook has no parry clip; the halberd's (two-handed polearm) parry_pose stands in for the block
        block = "parry_pose", block_from = "halberd",
        hit = {
            attack_swing_left = "attack_swing_hit_pull", attack_swing_left_diagonal_01 = "attack_swing_left_diagonal_hit",
            attack_swing_stab_01 = "attack_swing_stab_01_hit", attack_swing_stab_02 = "attack_swing_stab_02_hit",
            heavy_swing_down = "heavy_swing_down_hit", heavy_swing_stab = "heavy_swing_stab_hit",
        },
        hit_armor = {
            attack_swing_left = "attack_swing_down_hit_shield", attack_swing_left_diagonal_01 = "attack_swing_left_diagonal_hit_shield",
        },
        idle_offset = { left = "idle_offset_left", right = "idle_offset_right", up = "idle_offset_up", down = "idle_offset_down", neutral = "idle_offset_neutral" },
        inspect_offset = { left = "inspect_offset_left", right = "inspect_offset_right", up = "inspect_offset_up", down = "inspect_offset_down",
            left_down = "inspect_offset_left_down", right_down = "inspect_offset_right_down" },
        heavy_left = "heavy_swing_down", heavy_right = "heavy_swing_down", heavy_stab = "heavy_swing_stab",
        charge = "heavy_swing_down_charge", charge_stab = "heavy_swing_stab_charge",
    },
    halberd = {
        idle = "idle", walk = "walk", run = "run", equip = "equip", block = "parry_pose", push = "push",
        special = "special_action_pull", stab = "swing_stab_01",
        left = "swing_left_diagonal_01", right = "swing_stab_03", left_diagonal = "swing_left_diagonal_01",
        inspect_start = "inspect_start", inspect_loop = "inspect_loop", inspect_end = "inspect_end",
        heavy_left = "heavy_swing_right", heavy_right = "heavy_swing_right", heavy_stab = "swing_stab_02",
        charge = "heavy_swing_right_charge",
        inspect_offset = { left = "inspect_offset_left", right = "inspect_offset_right", up = "inspect_offset_up", down = "inspect_offset_down",
            left_down = "inspect_offset_left_down", right_down = "inspect_offset_right_down" },
    },
    great_axe = {
        idle = "idle_axe", walk = "walk_axe", run = "run_axe", equip = "equip_axe", block = "parry_pose", push = "push",
        special = "push", stab = "push",
        inspect_start = "inspect_start", inspect_end = "inspect_end",
        left = "swing_left", right = "swing_right", left_down = "swing_left_down", right_down = "swing_right_down",
        left_diagonal = "swing_left_diagonal", right_diagonal = "swing_right_diagonal", left_up = "swing_left_up",
        heavy_left = "heavy_swing_left", heavy_right = "heavy_swing_right", heavy_stab = "heavy_swing_right",
        heavy_left_diagonal = "heavy_swing_left_diagonal", heavy_right_diagonal = "heavy_swing_right_diagonal",
        charge_left = "heavy_swing_left_charge", charge_right = "heavy_swing_right_charge", charge = "heavy_swing_right_charge",
        hit = {
            swing_left = "swing_left_hit", swing_right = "swing_right_hit", swing_left_down = "swing_left_down_hit",
            swing_right_down = "swing_right_down_hit",
        },
    },
}

-- rotation taking u onto v, also when they are opposite
local function align(u, v)
    u, v = Vector3.normalize(u), Vector3.normalize(v)

    if Vector3.dot(u, v) < -0.9995 then
        local side = math.abs(u.z) < 0.9 and Vector3(0, 0, 1) or Vector3(1, 0, 0)

        return Quaternion.axis_angle(Vector3.normalize(Vector3.cross(u, side)), math.pi)
    end

    return rotation_between(u, v)
end

-- look-direction weights (left, right, up, down) of the weapon sway, from how fast the view turned this frame
local function sway_weights(data, fp_unit, dt)
    local f = Quaternion.rotate(Unit.world_rotation(fp_unit, 1), Vector3(0, 1, 0))
    local yaw, pitch = math.atan2(f.x, f.y), math.asin(math.clamp(f.z, -1, 1))
    local w = data.sway or { 0, 0, 0, 0 }

    if data.sway_prev and dt > 1e-4 then
        local dyaw = yaw - data.sway_prev[1]

        if dyaw > math.pi then
            dyaw = dyaw - 2 * math.pi
        elseif dyaw < -math.pi then
            dyaw = dyaw + 2 * math.pi
        end

        -- the weapon lags the view: turning right shifts it left, looking up shifts it down
        local target = {
            math.clamp(dyaw / dt / 3, 0, 1), math.clamp(-dyaw / dt / 3, 0, 1),
            math.clamp(-(pitch - data.sway_prev[2]) / dt / 3, 0, 1), math.clamp((pitch - data.sway_prev[2]) / dt / 3, 0, 1),
        }
        local k = 1 - math.exp(-dt * 10)

        for i = 1, 4 do
            w[i] = w[i] + (target[i] - w[i]) * k
        end
    end

    data.sway_prev = { yaw, pitch }
    data.sway = w

    return w
end

-- Darktide action -> clip and how to play it. The action's anim_event (powersword_2h_p1_m1.lua: attack_left, attack_right,
-- attack_stab_01, attack_left_diagonal_up, heavy_attack_left_down, heavy_attack_right_down, heavy_attack_left, heavy_attack_right,
-- heavy_attack_stab, heavy_charge_*, attack_push, parry_pose, equip) tells which swing it is; the action names are only
-- action_light_1.. / action_heavy_1.. mode: "loop" (clock), "hold" (frame 0), "charge" (real seconds, held at the end),
-- "once" (stretched over the action, the fast part of the clip on the damage window), "inspect"
local function pick_clip(S, action)
    local name = action.name
    local ev = type(action.event) == "string" and action.event or ""

    if not name or name == "none" then
        local speed = action.speed or 0

        if speed > 3.2 then
            return S.run, "loop"
        elseif speed > 0.4 then
            return S.walk, "loop"
        end

        return S.idle, "loop"
    end

    if name:find("inspect", 1, true) then
        return S.inspect_start, "inspect"
    elseif name:find("wield", 1, true) or ev == "equip" then
        return S.equip, "once"
    elseif name:find("block", 1, true) or ev:find("parry", 1, true) then
        return S.block, "loop"
    elseif name:find("push", 1, true) and not name:find("follow", 1, true) or ev:find("push", 1, true) then
        return S.push, "once"
    end

    local text = ev ~= "" and ev or name
    local dir = text:find("right", 1, true) and "right" or "left"
    local kind = text:find("stab", 1, true) and "stab" or dir
    local variant = text:find("_down", 1, true) and "_down" or text:find("diagonal", 1, true) and "_diagonal"
        or text:find("_up", 1, true) and "_up" or ""

    if name:find("special", 1, true) then
        return S.special or S.push, "once"
    elseif text:find("charge", 1, true) or name:find("start", 1, true) then
        return S["charge_" .. kind] or S.charge, "charge"
    elseif text:find("heavy", 1, true) or name:find("heavy", 1, true) then
        return S["heavy_" .. kind .. variant] or S["heavy_" .. kind] or S.heavy_left, "once"
    end

    return S[kind .. variant] or S[kind] or S.left or S.idle, "once"
end

-- piecewise time warp: action time -> clip time, so the clip's fast part falls on the action's damage window
local function warp(clip, action)
    local e, total, L = action.elapsed or 0, math.max(action.total or clip.length, 0.05), clip.length
    local d0, d1, h0, h1 = action.dws, action.dwe, clip.hit0, clip.hit1

    if not (d0 and d1 and h0 and h1) or d1 <= d0 or d1 >= total or h1 >= L or d0 <= 0 then
        return e / total * L
    end

    if e < d0 then
        return e / d0 * h0
    elseif e < d1 then
        return h0 + (e - d0) / (d1 - d0) * (h1 - h0)
    end

    return h1 + (e - d1) / (total - d1) * (L - h1)
end

local V = {}

local function vec(f, i)
    return Vector3(f[i], f[i + 1], f[i + 2])
end

-- hand frame from the hand's own finger bones, as QIangIQsChainLaspistol_brace.lua apply_hold
local function solve_hand(driver, side, f, i, t_r, t_p)
    local target_p = t_p + Quaternion.rotate(t_r, vec(f, i))
    local forward = Quaternion.rotate(t_r, Vector3.normalize(vec(f, i + 3)))
    local up = Quaternion.rotate(t_r, Vector3.normalize(vec(f, i + 6)))
    local pole = target_p + Quaternion.rotate(t_r, vec(f, i + 9))
    local hand = Unit.node(driver, "j_" .. side .. "hand")
    local hand_r, hand_p = root_relative(driver, hand)
    local inv_hand = Quaternion.inverse(hand_r)
    local f_local = Quaternion.rotate(inv_hand, pos(driver, "j_" .. side .. "handmiddle1") - hand_p)
    local u_local = Quaternion.rotate(inv_hand, pos(driver, "j_" .. side .. "handindex1") - pos(driver, "j_" .. side .. "handpinky1"))

    forward = Vector3.normalize(forward - up * Vector3.dot(forward, up))
    u_local = Vector3.normalize(u_local)
    f_local = Vector3.normalize(f_local - u_local * Vector3.dot(f_local, u_local))

    local target_r = Quaternion.multiply(Quaternion.look(forward, up), Quaternion.inverse(Quaternion.look(f_local, u_local)))

    two_bone(driver, side, target_p, pole)

    local parent_r = root_relative(driver, Unit.scene_graph_parent(driver, hand))

    Unit.set_local_rotation(driver, hand, Quaternion.multiply(Quaternion.inverse(parent_r), target_r))
end

-- start / stop / update ------------------------------------------------------------------------------------------------
local function arm_units(ext)
    local found = {}

    for slot_name, slot in pairs(ext._equipment or {}) do
        if type(slot_name) == "string" and (slot_name:find("^slot_body") or slot_name:find("^slot_gear")) and unit_ok(slot.unit_1p) then
            found[#found + 1] = slot.unit_1p
        end
    end

    return found
end

local function relink(world, unit, parent)
    World.unlink_unit(world, unit)
    World.link_unit(world, unit, 1, parent, 1, World.LINK_MODE_NODE_NAME)
end

function Arms.stop(ext)
    local data = ext.__qiangiq_poweraxe_arms

    if not data then
        return
    end

    ext.__qiangiq_poweraxe_arms = nil

    local world = ext.__qiangiq_poweraxe_world

    if world and unit_ok(data.fp_unit) then
        for unit in pairs(data.arms) do
            if unit_ok(unit) then
                relink(world, unit, data.fp_unit)
            end
        end
    end

    if unit_ok(data.driver) then
        local unit_spawner = Managers.state and Managers.state.unit_spawner

        if unit_spawner then
            unit_spawner:mark_for_deletion(data.driver)
        end
    end
end

local function start(ext, fp_unit, world)
    local unit_spawner = Managers.state and Managers.state.unit_spawner
    local path = CFG.driver_path()

    if not (unit_spawner and path) then
        return nil
    end

    local driver = unit_spawner:spawn_unit(path, Unit.world_pose(fp_unit, 1))

    if not driver then
        return nil
    end

    local ok, fpd, missing = pcall(make_fpd, driver, fp_unit)

    if not ok or not fpd then
        unit_spawner:mark_for_deletion(driver)
        CFG.error("arm driver lacks node " .. tostring(ok and missing or fpd) .. ": billhook arms off")

        return nil
    end

    World.link_unit(world, driver, 1, fp_unit, 1)
    copy_pose(fpd)

    local data = { driver = driver, fpd = fpd, fp_unit = fp_unit, arms = {}, pose = nil }

    ext.__qiangiq_poweraxe_arms = data

    return data
end

-- The weapon rig: moved from the fp attach node to the driver root once. Measured at that moment (the retail grip, the weapon
-- in the right hand): the rig's pose in the hand frame (rel_*), where the wrist sits in the rig frame (grip) and the rig's shaft
-- axis (pommel -> head node of the shaft, in rig axes). Afterwards the rig is held by the wrist with the retail hand relation,
-- turned about the wrist so its shaft runs along the VT2 shaft (baked attach z, through both hands): it cannot come off the
-- hand, and which end is the head is decided by the measured axis.
-- metres of shaft left below the lower hand (the VT2 billhook leaves 0.2 to 0.6 m; the shorter axe leaves less)
local POMMEL_BELOW_HAND = 0.1

local function link_weapon(data, world, slot)
    local rig = slot.unit_1p
    local driver = data.driver

    World.update_unit_and_children(world, driver)

    local node = Unit.node(driver, "j_righthand")
    local hand_r, hand_p = Unit.world_rotation(driver, node), Unit.world_position(driver, node)
    local inv_hand = Quaternion.inverse(hand_r)
    local rig_r, rig_p = Unit.world_rotation(rig, 1), Unit.world_position(rig, 1)
    local rel_p = Quaternion.rotate(inv_hand, rig_p - hand_p)

    -- a rig that has not been placed yet gives a garbage grip: wait a few frames, then give up on the retail relation
    data.link_tries = (data.link_tries or 0) + 1

    if Vector3.length(rel_p) > 1.2 then
        if data.link_tries < 90 then
            return false
        end

        rel_p = Vector3(0, 0, 0)
    end

    local inv_rig = Quaternion.inverse(rig_r)
    local axis = Vector3(0, 0, 1)
    local pommel = nil

    for unit in pairs(slot.item_name_by_unit_1p or {}) do
        if unit_ok(unit) and Unit.has_node(unit, "ap_head_01") and Unit.has_node(unit, "ap_pommel_01") then
            local along = Unit.world_position(unit, Unit.node(unit, "ap_head_01")) - Unit.world_position(unit, Unit.node(unit, "ap_pommel_01"))

            if Vector3.length(along) > 0.05 then
                axis = Vector3.normalize(Quaternion.rotate(inv_rig, along))
                pommel = Quaternion.rotate(inv_rig, Unit.world_position(unit, Unit.node(unit, "ap_pommel_01")) - rig_p)
            end

            break
        end
    end

    data.rig = rig
    data.rel_p = Vector3Box(rel_p)
    data.rel_r = QuaternionBox(Quaternion.multiply(inv_hand, rig_r))
    data.grip = Vector3Box(Quaternion.rotate(inv_rig, hand_p - rig_p))
    data.axis = Vector3Box(axis)
    data.pommel = pommel and Vector3Box(pommel)

    World.unlink_unit(world, rig)
    World.link_unit(world, rig, 1, driver, 1, World.LINK_MODE_NONE)
    CFG.info(string.format("axe linked to the driver after %d tries: grip offset %.3f %.3f %.3f m, shaft axis in the rig %.2f %.2f %.2f, pommel %s",
        data.link_tries, rel_p.x, rel_p.y, rel_p.z, axis.x, axis.y, axis.z, pommel and string.format("%.3f %.3f %.3f", pommel.x, pommel.y, pommel.z) or "none"))

    return true
end

-- slot: the equipment slot of the axe; action: set (billhook / halberd / great_axe), name, elapsed, total, dws, dwe, speed, clock
function Arms.update(ext, slot, action, dt)
    local fpe = unit_ok(ext._unit) and ScriptUnit.has_extension(ext._unit, "first_person_system")
    local fp_unit = fpe and fpe:first_person_unit()
    local world = ext.__qiangiq_poweraxe_world
    local data = ext.__qiangiq_poweraxe_arms
    local want = slot ~= nil and slot.hidden_1p == false and CFG.driver_path() ~= nil and world ~= nil and unit_ok(fp_unit)
        and unit_ok(slot.unit_1p) and fpe.is_in_first_person_mode and fpe:is_in_first_person_mode()

    if data and (not want or data.fp_unit ~= fp_unit or not unit_ok(data.driver)) then
        Arms.stop(ext)
        data = nil
    end

    if not want then
        ext.__qiangiq_poweraxe_why = (ext.__qiangiq_poweraxe_why or 0) - (dt or 0)

        if ext.__qiangiq_poweraxe_why <= 0 then
            ext.__qiangiq_poweraxe_why = 3
            CFG.info(string.format("arms idle: slot %s hidden_1p %s driver %s world %s fp_unit %s unit_1p %s first-person %s",
                tostring(slot ~= nil), tostring(slot and slot.hidden_1p), tostring(CFG.driver_path()), tostring(world ~= nil),
                tostring(unit_ok(fp_unit)), tostring(slot ~= nil and unit_ok(slot.unit_1p)),
                tostring(fpe and fpe.is_in_first_person_mode and fpe:is_in_first_person_mode())))
        end

        return
    end

    data = data or start(ext, fp_unit, world)

    if not data then
        return
    end

    for _, unit in ipairs(arm_units(ext)) do
        if not data.arms[unit] then
            relink(world, unit, data.driver)
            data.arms[unit] = true
        end
    end

    for unit in pairs(data.arms) do
        if not unit_ok(unit) then
            data.arms[unit] = nil
        end
    end

    copy_pose(data.fpd)

    if data.rig ~= slot.unit_1p and not link_weapon(data, world, slot) then
        World.update_unit_and_children(world, data.driver)

        return
    end

    -- pose of the moment: the baked clip frame, smoothed towards (hard cuts between clips would pop)
    local set_name = action.set
    local S, baked = SETS[set_name], CFG.baked(set_name)

    if not (S and baked) then
        return
    end

    local inspecting = action.name ~= nil and action.name:find("inspect", 1, true) ~= nil

    if data.inspecting and not inspecting then
        data.inspect_end_t = action.clock
    end

    data.inspecting = inspecting

    local clip_name, mode = pick_clip(S, action)
    local end_clip = baked[S.inspect_end]

    if mode == "loop" and clip_name ~= S.block and data.inspect_end_t and end_clip and action.clock - data.inspect_end_t < end_clip.length then
        clip_name, mode = S.inspect_end, "inspect_end"
    end

    local hit = CFG.hit()

    if mode == "once" and hit and hit.t >= action.clock - (action.elapsed or 0) - 0.05 then
        clip_name = (hit.armor and S.hit_armor and S.hit_armor[clip_name]) or (S.hit and S.hit[clip_name]) or clip_name
    end

    local source = baked

    if S.block_from and clip_name == S.block then
        source = CFG.baked(S.block_from) or baked
    end

    local clip = source[clip_name] or baked[clip_name] or baked[S.idle]
    local frame

    if mode == "inspect" then
        local e = action.elapsed or 0
        local loop_clip = baked[S.inspect_loop or ""]

        if e < clip.length then
            frame = sample(clip, e, false)
        elseif loop_clip then
            clip_name, frame = S.inspect_loop, sample(loop_clip, e - clip.length, true)
        else
            frame = sample(clip, clip.length, false)
        end

        -- the inspect_offset_* clips are additive on the inspect loop; weights from the look direction
        if S.inspect_offset and loop_clip then
            local w = sway_weights(data, fp_unit, dt or 0)
            local t = e - clip.length
            local base = sample(loop_clip, t, true)
            local combos = {
                { "left", w[1] }, { "right", w[2] }, { "up", w[3] }, { "down", w[4] },
                { "left_down", w[1] * w[4] }, { "right_down", w[2] * w[4] },
            }

            for _, c in ipairs(combos) do
                local off = baked[S.inspect_offset[c[1]]]

                if off and c[2] > 0.001 then
                    local sampled = sample(off, math.max(t, 0), true)
                    local b = sample(loop_clip, math.max(t, 0), true)

                    for i = 1, #frame do
                        frame[i] = frame[i] + (sampled[i] - b[i]) * c[2]
                    end
                end
            end
        end
    elseif mode == "inspect_end" then
        frame = sample(clip, action.clock - data.inspect_end_t, false)
    elseif mode == "loop" then
        frame = sample(clip, action.clock, true)

        -- idle sway layers (the *_offset clips are additive on the idle pose, baked as idle pose + delta)
        if clip_name == S.idle and S.idle_offset and baked[S.idle_offset.neutral] then
            local w = sway_weights(data, fp_unit, dt or 0)
            local neutral = sample(baked[S.idle_offset.neutral], 0, false)

            for n, key in ipairs({ "left", "right", "up", "down" }) do
                local off = baked[S.idle_offset[key]]

                if off and w[n] > 0.001 then
                    local sampled = sample(off, 0, false)

                    for i = 1, #frame do
                        frame[i] = frame[i] + (sampled[i] - neutral[i]) * w[n]
                    end
                end
            end
        end
    elseif mode == "hold" then
        frame = sample(clip, 0, false)
    elseif mode == "charge" then
        frame = sample(clip, action.elapsed or 0, false)
    else
        frame = sample(clip, warp(clip, action), false)
    end

    data.clip = clip_name

    dt = dt or 0

    local k = 1 - math.exp(-dt * (mode == "loop" and 8 or 30))

    if data.pose then
        for i = 1, #frame do
            data.pose[i] = data.pose[i] + (frame[i] - data.pose[i]) * k
        end
    else
        data.pose = frame
    end

    local f = data.pose
    local driver = data.driver
    local cam_r, cam_p = root_relative(driver, Unit.node(driver, "ap_camera_node"))
    local ok, err = pcall(function()
        local t_r = Quaternion.multiply(cam_r, Quaternion.look(Vector3.normalize(vec(f, 4)), Vector3.normalize(vec(f, 7))))
        local t_p = cam_p + Quaternion.rotate(cam_r, vec(f, 1))

        solve_hand(driver, "right", f, 10, t_r, t_p)
        solve_hand(driver, "left", f, 22, t_r, t_p)

        local adj = Quaternion.from_yaw_pitch_roll(math.rad(CFG.opt("weapon_yaw", 0)), math.rad(CFG.opt("weapon_pitch", 0)),
            math.rad(CFG.opt("weapon_roll", 0)))
        local hand_r, hand_p = root_relative(driver, Unit.node(driver, "j_righthand"))
        local retail_r = Quaternion.multiply(hand_r, data.rel_r:unbox())
        local shaft = Quaternion.rotate(cam_r, Vector3.normalize(vec(f, 7)))
        local rig_r = Quaternion.multiply(align(Quaternion.rotate(retail_r, data.axis:unbox()), shaft), retail_r)

        rig_r = Quaternion.multiply(rig_r, adj)

        local off = Vector3(CFG.opt("weapon_x", 0), CFG.opt("weapon_y", 0), CFG.opt("weapon_z", 0)) * 0.01

        -- VT2 holds the polearm on the attach bone's z line, both hands on it (the VT2 billhook mesh sits 0.885 m down that
        -- line, so its butt is below the lower hand). The axe's pommel goes on the same line just below the lower hand.
        local rig_p
        local pommel = data.pommel and data.pommel:unbox()

        if pommel then
            local low = math.min(f[12], f[24]) - POMMEL_BELOW_HAND
            rig_p = t_p + shaft * low - Quaternion.rotate(rig_r, pommel)
        else
            rig_p = hand_p - Quaternion.rotate(rig_r, data.grip:unbox())
        end

        Unit.set_local_position(data.rig, 1, rig_p + Quaternion.rotate(rig_r, off))
        Unit.set_local_rotation(data.rig, 1, rig_r)
    end)

    if not ok and not data.reported then
        data.reported = true
        CFG.error("arms: " .. tostring(err))
    end

    data.log_t = (data.log_t or 0) - dt

    if data.log_t <= 0 then
        data.log_t = 3

        local hp = pos(driver, "j_righthand")
        local rp = Unit.local_position(data.rig, 1)
        local lp = pos(driver, "j_lefthand")

        CFG.info(string.format("arms: %s clip %s mode %s, right hand %.2f %.2f %.2f, left hand %.2f %.2f %.2f, axe %.2f %.2f %.2f, action %s event %s, ok=%s",
            tostring(action.set), tostring(clip_name), tostring(mode), hp.x, hp.y, hp.z, lp.x, lp.y, lp.z, rp.x, rp.y, rp.z,
            tostring(action.name), tostring(action.event), tostring(ok)))
    end

    World.update_unit_and_children(world, driver)
end

function Arms.debug(ext)
    local data = ext.__qiangiq_poweraxe_arms

    if not data then
        return "arms: not active (driver asset " .. tostring(CFG.driver_path()) .. ")"
    end

    local n = 0

    for _ in pairs(data.arms) do
        n = n + 1
    end

    return string.format("arms: active, %d arm units on the driver, weapon linked: %s, clip %s", n, tostring(data.rig ~= nil), tostring(data.clip))
end

return Arms
