-- QIangIQ's Power Axe 0.5.1: the unreleased two-handed power axe (poweraxe_2h) as a weapon, all four datamined marks.
-- 0.3.0: optional billhook arms (Vermintide 2 first-person clips baked to Lua, played by IK on a driver unit), see QIangIQsPowerAxe_arms.lua.
-- 0.4.0: halberd and great axe arm styles, every clip of the three VT2 sets baked, the swing synced to the action's damage window, walk / run / block / push / heavy charge clips, the axe follows the right hand.
-- 0.5.0: axe held by the wrist (retail hand relation) and turned onto the VT2 shaft line, billhook block (halberd parry pose), hit variants from the attack_hit events, idle / inspect sway layers, every billhook clip baked.
-- 0.5.1: axe placed on the VT2 shaft line with its pommel just below the lower hand (renders showed the VT2 billhook butt sits below the left hand), so both hands hold the shaft.
--
-- What is datamined (A:\Dowloads\Darktide_NonMod\unreleased_sweep_oct25, assets\weapon__2h_power_axe_poweraxe_2h_p1_p2_.txt,
-- build 139617):
--   * content/weapons/player/melee/2h_power_axe/wpn_2h_power_axe_chained_rig and attachments head_01, head_02, head_03,
--     head_ml01, shaft_01, shaft_02, shaft_03, pommel_01, pommel_02, pommel_03, pommel_ml01 (12 units, 11 materials, 91
--     textures; every unit has its package, so the game loads their own textures: nothing is rebuilt or repainted).
--   * HUD icons content/ui/materials/icons/weapons/hud/poweraxe_2h_p1_m1, poweraxe_2h_p2_m1, _m2, _m3 (material + package).
--   * NOT in the files: weapon template, item, animation set of its own, sounds. The 2h_maul first-person set (75 clips,
--     unreleased-fp-animation-clips) is an alternate build of the released 2H power maul set.
--   * Node names (id32 match, A:\Dowloads\staging\poweraxe\probe_axe_nodes.py): rig root rp_2h_power_axe_chained_rig;
--     shaft_NN has ap_pommel_01 and ap_head_01 (no connector: the head sits straight on the shaft, unlike the maul, whose
--     shaft carries ap_connector_01); head_NN has rp_head_01 and ap_trinket_hook; no fx_sweep / fx_block /
--     fx_special_active nodes anywhere on the axe.
--
-- How it is built (QIangIQsMeltagun / QIangIQsSwordShield pattern: template clone + NetworkLookup append + alias copy, item
-- clone into MasterItems.get_cached(), equip by override_slot):
--   * Templates: poweraxe_2h_p1_m1, poweraxe_2h_p2_m1, poweraxe_2h_p2_m2, poweraxe_2h_p2_m3 (the names of the four HUD
--     icons). Each is a clone of a released 2H power maul template: powermaul_2h_p1_m1 or powermaul_2h_p1_m2
--     (power_mauls_2h/*.lua, they differ in moveset: m1 left-down / right-down chain, m2 left / right / diagonal chain).
--     Which one a mark clones is a setting; the default alternates (p1_m1 m1, p2_m1 m2, p2_m2 m1, p2_m3 m2). That mapping
--     and the part sets below are an assumption of this mod, the game has no data for them.
--   * Power maul special kept (power field, activate_special + explosion on impact), so it is a power axe.
--   * Items: clone of powermaul_2h_p1_m1 / _m2 with base_unit = the axe rig. Item tree of the maul (master item data,
--     http_cache.db): shaft -> connector -> head, shaft -> pommel, trail. The axe tree is shaft -> head, shaft -> pommel;
--     connector, trinkets and the (chain sword) trail go.
--   * fx sources _block / _sweep / _special_active need a node that exists on some attachment (player_unit_fx_extension.lua
--     :824-860 logs an exception and falls back to the root otherwise), so all three point at the shaft's ap_head_01.
--   * Animations: the released 2h_power_maul state machine by default. Setting "Animation set" = unreleased switches the
--     first-person state machine to content/characters/player/human/first_person/animations/2h_maul. Its event names are a
--     superset of the released one's (limn state_machine dump, A:\Dowloads\staging\poweraxe\sm_cmp.py: 165 events vs 159,
--     none missing), so every action of the cloned template works; it plays the alternate clips for the same events. Sweep
--     (hit) paths stay the released clips' matrices (matrices_data_location, action_sweep.lua:190): the unreleased set has
--     none, so a swing may look different from where it hits.
--   * Parts: head / shaft / pommel are picked per mark (set 01, 02, 03, ml01 = the datamined numbers, ml01 has no shaft so
--     shaft 01 is used) and can be overridden in the settings.
--   * Standalone: needs no other mod; HUD icon and every unit are the game's own.
-- Author: QIangIQ
local mod = get_mod("QIangIQsPowerAxe")

local WeaponTemplates = require("scripts/settings/equipment/weapon_templates/weapon_templates")
local MasterItems = require("scripts/backend/master_items")
local NetworkLookup = require("scripts/network_lookup/network_lookup")

local AXE = "content/weapons/player/melee/2h_power_axe/"
local ITEM_ROOT = "content/items/weapons/player/melee/"
local PART_ROOT = ITEM_ROOT .. "qiangiq_poweraxe/"
local RIG = AXE .. "wpn_2h_power_axe_chained_rig"
local RIG_NODE = "rp_2h_power_axe_chained_rig"
local HEAD_NODE, POMMEL_NODE = "ap_head_01", "ap_pommel_01"
local FX_NODE = "ap_head_01"
local HUD_ICON_ROOT = "content/ui/materials/icons/weapons/hud/"
local RELEASED_SM = "content/characters/player/human/first_person/animations/2h_power_maul"
local UNRELEASED_SM = "content/characters/player/human/first_person/animations/2h_maul"

local DONOR_FAMILIES = {
    sword = { m1 = "powersword_2h_p1_m1", m2 = "powersword_2h_p1_m2" },
    maul = { m1 = "powermaul_2h_p1_m1", m2 = "powermaul_2h_p1_m2" },
}

-- Billhook arms (0.3.0): the Vermintide 2 billhook first-person clips baked to hand / elbow / weapon targets, played by a
-- two-bone IK on a driver unit that ships in this mod (Custom/pa_fp_driver, needs the Custom Assets framework like the
-- Chain Laspistol's brace). QIangIQsPowerAxe_arms.lua; the clips are QIangIQsPowerAxe_billhook.lua.
local DRIVERS = {
    { id = "QIangIQsPowerAxe:pa_fp_driver", unit = "content/mods/qiangiq_poweraxe/pa_fp_driver" },
}
local driver_loaded = {}
local baked_clips = {}

local Arms = mod:io_dofile("QIangIQsPowerAxe/scripts/mods/QIangIQsPowerAxe/QIangIQsPowerAxe_arms")

Arms.setup({
    fp_nodes = mod:io_dofile("QIangIQsPowerAxe/scripts/mods/QIangIQsPowerAxe/QIangIQsPowerAxe_fp_nodes"),
    opt = function(key, default)
        local v = mod:get(key)

        if v == nil then
            return default
        end

        return tonumber(v) or v
    end,
    baked = function(set_name)
        if set_name == "billhook" or set_name == "halberd" or set_name == "great_axe" then
            baked_clips[set_name] = baked_clips[set_name]
                or mod:io_dofile("QIangIQsPowerAxe/scripts/mods/QIangIQsPowerAxe/QIangIQsPowerAxe_" .. set_name)

            return baked_clips[set_name]
        end
    end,
    driver_path = function()
        for i, d in ipairs(DRIVERS) do
            if driver_loaded[i] then
                return d.unit
            end
        end
    end,
    error = function(text)
        mod:error("%s", text)
    end,
    info = function(text)
        mod:info("%s", text)
    end,
    hit = function()
        return mod.__qiangiq_poweraxe_hit
    end,
})

local function family()
    return DONOR_FAMILIES[mod:get("animation_family")] and mod:get("animation_family") or "sword"
end

local function donor_name_of(moveset)
    return DONOR_FAMILIES[family()][moveset]
end
local KINDS = { "shaft", "head", "pommel" }
local SETS = {
    shaft = { ["01"] = true, ["02"] = true, ["03"] = true },
    head = { ["01"] = true, ["02"] = true, ["03"] = true, ml01 = true },
    pommel = { ["01"] = true, ["02"] = true, ["03"] = true, ml01 = true },
}
local ARCHETYPES = { "zealot", "veteran", "psyker", "adamant" }

local MARKS = {
    { key = "p1_m1", template = "poweraxe_2h_p1_m1", set = "01", moveset = "m1", display = "loc_qiangiq_poweraxe_p1_m1" },
    { key = "p2_m1", template = "poweraxe_2h_p2_m1", set = "02", moveset = "m2", display = "loc_qiangiq_poweraxe_p2_m1" },
    { key = "p2_m2", template = "poweraxe_2h_p2_m2", set = "03", moveset = "m1", display = "loc_qiangiq_poweraxe_p2_m2" },
    { key = "p2_m3", template = "poweraxe_2h_p2_m3", set = "ml01", moveset = "m2", display = "loc_qiangiq_poweraxe_p2_m3" },
}
local MARK_BY_KEY, MARK_BY_TEMPLATE, ITEM_NAMES = {}, {}, {}

for _, mark in ipairs(MARKS) do
    mark.item = ITEM_ROOT .. mark.template
    MARK_BY_KEY[mark.key] = mark
    MARK_BY_TEMPLATE[mark.template] = mark
    ITEM_NAMES[mark.item] = mark
end

mod:add_global_localize_strings({
    loc_qiangiq_poweraxe_family = { en = "Power Axe (datamined)" },
    loc_qiangiq_poweraxe_p1_m1 = { en = "Power Axe P1 M1 (datamined)" },
    loc_qiangiq_poweraxe_p2_m1 = { en = "Power Axe P2 M1 (datamined)" },
    loc_qiangiq_poweraxe_p2_m2 = { en = "Power Axe P2 M2 (datamined)" },
    loc_qiangiq_poweraxe_p2_m3 = { en = "Power Axe P2 M3 (datamined)" },
    loc_qiangiq_poweraxe_desc = {
        en = "The two-handed power axe found unreleased in the game files. Uses the Power Maul's moveset and power field special.",
    },
})

local function say(fmt, ...)
    local text = string.format(fmt, ...)

    mod:echo(text)
    mod:info(text)
end

-- Network lookups (QIangIQsShardStaff append_lookup): new names go at the end so no existing id moves -------------
local function append_lookup(lookup_name, key)
    local lookup = NetworkLookup[lookup_name]

    if not lookup then
        return false, "no lookup"
    end

    local existing = rawget(lookup, key)

    if existing then
        return true, existing
    end

    local index = #lookup + 1

    rawset(lookup, index, key)
    rawset(lookup, key, index)

    return true, index
end

-- Particle / sound aliases keyed by wielded_weapon_template (QIangIQsShardStaff alias_template_keys) --------------
local ALIAS_MODULES = {
    "scripts/settings/particles/player_character_particle_aliases",
    "scripts/settings/sound/player_character_sound_event_aliases",
}

local function alias_keys(root, source, target, seen, counter)
    if type(root) ~= "table" or seen[root] then
        return
    end

    seen[root] = true

    local value = rawget(root, source)

    if value ~= nil and rawget(root, target) == nil then
        root[target] = value
        counter.n = counter.n + 1
    end

    for _, child in pairs(root) do
        if type(child) == "table" then
            alias_keys(child, source, target, seen, counter)
        end
    end
end

local function copy_aliases(source, target)
    local counter = { n = 0 }

    for _, path in ipairs(ALIAS_MODULES) do
        local ok, module = pcall(require, path)

        if ok then
            alias_keys(module, source, target, {}, counter)
        else
            mod:error("alias module %s: %s", path, tostring(module))
        end
    end

    return counter.n
end

local function package_found(path)
    local ok, exists = pcall(Application.can_get_resource, "package", path)

    return ok and exists and true or false
end

-- The loadout's weapon cards draw item.hud_icon straight from the engine. When the item's own reference to that icon
-- package is released while a card still draws it, the engine aborts ("Trying to unload resource ... that's used
-- elsewhere by the engine", CTD opening the Realms loadout 2026-10-27, package poweraxe_2h_p1_m1). One reference of
-- our own keeps each icon package resident for the whole session, so the item's releases never reach zero.
local pinned_icons = {}

local function pin_package(path)
    if pinned_icons[path] then
        return
    end

    local package_manager = Managers and Managers.package

    if not (package_manager and package_manager.load) then
        return
    end

    local ok, id = pcall(package_manager.load, package_manager, path, "QIangIQsPowerAxe_hud_icon", nil, false)

    if ok and id then
        pinned_icons[path] = id
    end
end

-- Settings ------------------------------------------------------------------------------------------------------------
local function moveset_of(mark)
    local choice = mod:get("moveset_" .. mark.key)

    return DONOR_FAMILIES.maul[choice] and choice or mark.moveset
end

local function part_set(kind, mark)
    local choice = mod:get(kind .. "_set")
    local set = (choice and choice ~= "mark") and choice or mark.set

    if kind == "shaft" and set == "ml01" then
        set = "01"
    end

    if not SETS[kind][set] then
        set = "01"
    end

    return set
end

local function part_unit(kind, set)
    return string.format("%sattachments/%s_%s/%s_%s", AXE, kind, set, kind, set)
end

local function part_item_name(kind, set)
    return string.format("%s%s_%s", PART_ROOT, kind, set)
end

-- Template ------------------------------------------------------------------------------------------------------------
local anim_used = {}

local function apply_axe(clone, mark, notes)
    -- the axe has no fx nodes of its own; see the header
    clone.fx_sources = table.clone(clone.fx_sources or {})

    for source in pairs(clone.fx_sources) do
        clone.fx_sources[source] = FX_NODE
    end

    if mod:get("animation_set") == "unreleased" and family() == "maul" then
        if package_found(UNRELEASED_SM) then
            -- player_unit_animation_state.lua:112 indexes PlayerUnitAnimationStateMachineSettings by the state machine
            -- path (QIangIQsMeltagun 0.2.2: CTD on spawn without the entry), and the unreleased set is not listed in
            -- state_machine_melee_first_person.lua, so it gets the released maul's entry
            local SMSettings = require("scripts/settings/animation/player_unit_animation_state_machine_settings")

            if not SMSettings[UNRELEASED_SM] then
                SMSettings[UNRELEASED_SM] = table.clone(SMSettings[RELEASED_SM] or { blend_time = 0 })
            end

            clone.anim_state_machine_1p = UNRELEASED_SM
            anim_used[mark.template] = true
            notes[#notes + 1] = "unreleased 2h_maul animations"
        else
            notes[#notes + 1] = "2h_maul animation package not found, released animations kept"
        end
    end
end

local function ensure_template(mark)
    if rawget(WeaponTemplates, mark.template) then
        mark.template_ok = true
        mark.official_template = not mark.template_ours

        return true
    end

    local donor_name = donor_name_of(moveset_of(mark))
    local donor = WeaponTemplates[donor_name]

    if not donor then
        return false
    end

    local clone = table.clone(donor)

    clone.name = mark.template

    -- weapon_templates.lua _require_template: action_settings.name = action_name
    for action_name, action_settings in pairs(clone.actions) do
        action_settings.name = action_name
    end

    mark.template_notes = {}
    apply_axe(clone, mark, mark.template_notes)

    WeaponTemplates[mark.template] = clone
    mark.template_ours = true
    mark.donor = donor_name

    local ok, index = append_lookup("weapon_templates", mark.template)

    mark.template_id = ok and index or nil
    mark.aliases = copy_aliases(donor_name, mark.template)
    mark.template_ok = ok

    return ok
end

-- Items ---------------------------------------------------------------------------------------------------------------
local function find_item(cache, preferred, template)
    local direct = rawget(cache, preferred)

    if direct and direct.weapon_template == template then
        return preferred, direct
    end

    for name, item in pairs(cache) do
        if type(item) == "table" and item.weapon_template == template then
            return name, item
        end
    end
end

-- Only base_unit is kept: Items.base_unit can also read per-breed / first-person variants of the source part
local function only_base_unit(item, unit)
    for key in pairs(item) do
        if type(key) == "string" and key ~= "base_unit" and key:find("^base_unit") then
            item[key] = nil
        end
    end

    item.base_unit = unit
end

local function make_part(cache, name, template_item, unit, attach_node)
    local item = table.clone(template_item)

    only_base_unit(item, unit)
    item.name = name
    item.resource_dependencies = { [unit] = true }
    item.attachments = nil
    item.material_overrides = nil
    item.material_override_items = nil
    item.attach_node = attach_node
    cache[name] = item

    return name
end

-- a fresh tree node with the donor node's flags (leaf_attach_node_override, link_map_mode_override, material fields)
local function fresh_node(node, item_name)
    local out = {}

    for key, value in pairs(node) do
        if key ~= "children" and key ~= "item" then
            out[key] = type(value) == "table" and table.clone(value) or value
        end
    end

    out.item = item_name
    out.children = {}

    return out
end

local function dump_tree(tree, prefix, out)
    for slot_name, node in pairs(tree) do
        if type(node) == "table" then
            local path = prefix .. slot_name

            out[#out + 1] = string.format("%s=%s", path, tostring(node.item))

            if type(node.children) == "table" then
                dump_tree(node.children, path .. "/", out)
            end
        end
    end

    return out
end

local function ensure_part(cache, kind, set, template_item, attach_node, notes)
    if not package_found(part_unit(kind, set)) then
        notes[#notes + 1] = string.format("%s_%s package not found", kind, set)

        return nil
    end

    local name = part_item_name(kind, set)

    if not rawget(cache, name) then
        make_part(cache, name, template_item, part_unit(kind, set), attach_node)
    end

    return name
end

local function archetypes_of(source_item)
    local archetypes, seen = {}, {}

    for _, archetype in ipairs(source_item.archetypes or {}) do
        archetypes[#archetypes + 1] = archetype
        seen[archetype] = true
    end

    for _, archetype in ipairs(ARCHETYPES) do
        if mod:get("unlock_" .. archetype) and not seen[archetype] then
            archetypes[#archetypes + 1] = archetype
            seen[archetype] = true
        end
    end

    return archetypes
end

local function build_item(cache, mark)
    -- the item tree always comes from the maul item (shaft/connector/head, shaft/pommel); only the template follows the swing set
    local donor_template = DONOR_FAMILIES.maul[moveset_of(mark)]
    local source_name, source_item = find_item(cache, ITEM_ROOT .. donor_template, donor_template)

    if not source_item then
        return false
    end

    if type(source_item.attachments) ~= "table" then
        return false, "source item has no attachments"
    end

    local item = table.clone(source_item)
    local notes = {}

    item.name = mark.item
    item.weapon_template = mark.template
    item.display_name = mark.display
    item.description = "loc_qiangiq_poweraxe_desc"
    item.dev_description = nil
    item.archetypes = archetypes_of(source_item)

    for _, field in ipairs({ "weapon_family_display_name", "weapon_pattern_display_name", "weapon_mark_display_name" }) do
        if type(item[field]) == "table" then
            item[field].loc_id = field == "weapon_family_display_name" and "loc_qiangiq_poweraxe_family" or mark.display
        end
    end

    if not mark.trees_logged then
        mark.trees_logged = true
        mod:info("source tree of %s: %s", tostring(source_name), table.concat(dump_tree(item.attachments, "", {}), "; "))
    end

    -- master item data of powermaul_2h_p1_m1 (http_cache.db, build 139617): shaft = 2h_power_maul_shaft_01, shaft/connector
    -- = ..._connector_01 with the head under it, shaft/pommel, trail = 2h_chain_sword_trail_01
    local shaft = item.attachments.shaft
    local shaft_children = shaft and type(shaft.children) == "table" and shaft.children
    local connector = shaft_children and shaft_children.connector
    local head = connector and type(connector.children) == "table" and connector.children.head
    local pommel = shaft_children and shaft_children.pommel

    local function source_of(node)
        return node and type(node.item) == "string" and rawget(cache, node.item)
    end

    local shaft_source, head_source, pommel_source = source_of(shaft), source_of(head), source_of(pommel)

    if not (shaft_source and head_source and pommel_source) then
        return false, "no shaft, shaft/connector/head or shaft/pommel slot in " .. tostring(source_name)
    end

    local picked = {}
    local shaft_name = ensure_part(cache, "shaft", part_set("shaft", mark), shaft_source, RIG_NODE, notes)
    local head_name = ensure_part(cache, "head", part_set("head", mark), head_source, HEAD_NODE, notes)
    local pommel_name = ensure_part(cache, "pommel", part_set("pommel", mark), pommel_source, POMMEL_NODE, notes)

    if not (shaft_name and head_name and pommel_name) then
        return false, table.concat(notes, "; ")
    end

    picked.shaft, picked.head, picked.pommel = part_set("shaft", mark), part_set("head", mark), part_set("pommel", mark)

    local head_node = fresh_node(head, head_name)
    local pommel_node = fresh_node(pommel, pommel_name)

    shaft.item = shaft_name
    shaft.children = { head = head_node, pommel = pommel_node }

    -- the sweep trail unit is built for the chain sword rig's j_trail nodes, which the axe rig lacks
    if item.attachments.trail then
        item.attachments.trail.item = ""
        item.attachments.trail.children = {}
    end

    only_base_unit(item, RIG)

    local deps = item.resource_dependencies or {}

    if source_item.base_unit then
        deps[source_item.base_unit] = nil
    end

    deps[RIG] = true

    -- bottom-right weapon HUD: item.hud_icon (hud_element_player_weapon.lua:77), the game's own unreleased icon
    local icon = HUD_ICON_ROOT .. mark.template

    if package_found(icon) then
        if type(item.hud_icon) == "string" then
            deps[item.hud_icon] = nil
        end

        item.hud_icon = icon
        deps[icon] = true
        pin_package(icon)
        notes[#notes + 1] = "hud icon " .. mark.template
    else
        notes[#notes + 1] = "hud icon package not found, the maul's stays"
    end

    -- what the offline item compile adds for the weapon template (item_package.lua:239-249): state machines, sounds, effects
    local WeaponTemplateResourceDependencies = require("scripts/utilities/weapon_template_resource_dependencies")

    for _, resource in ipairs(WeaponTemplateResourceDependencies.generate(mark.template)) do
        deps[resource] = true
    end

    item.resource_dependencies = deps

    local ok, index = append_lookup("player_item_names", mark.item)

    if not ok then
        return false
    end

    cache[mark.item] = item
    mark.item_id = index
    mark.source_item_name = source_name
    mark.slot = item.slots and item.slots[1]
    mark.archetypes = item.archetypes
    mark.picked = picked
    mark.notes = notes

    return true
end

local function ensure_item(mark)
    local ok, has_data = pcall(MasterItems.has_data)

    if not ok or not has_data then
        return false
    end

    local cache = MasterItems.get_cached()

    if rawget(cache, mark.item) and not mark.dirty then
        mark.item_ok = true

        return true
    end

    local built, err = build_item(cache, mark)

    if err and err ~= mark.last_error then
        mark.last_error = err
        mod:error("%s: %s", mark.template, err)
    end

    mark.item_ok = built and rawget(cache, mark.item) ~= nil

    if mark.item_ok then
        mark.dirty = false
    end

    return mark.item_ok
end

-- Unlock lists (weapon_unlock_settings.lua WeaponUnlockSettings[archetype][level] = { item names }); realms_loadout
-- builds its human weapon list from it
local function add_to_unlock_lists()
    if not mod:get("add_to_unlock_list") then
        return
    end

    local ok, unlocks = pcall(require, "scripts/settings/weapon_unlock/weapon_unlock_settings")

    if not ok or not unlocks then
        mod:error("WeaponUnlockSettings not found")

        return
    end

    local level = math.floor(mod:get("unlock_level") or 1)

    for _, archetype in ipairs(ARCHETYPES) do
        local list = unlocks[archetype]

        if mod:get("unlock_" .. archetype) and list then
            list[level] = list[level] or {}

            for _, mark in ipairs(MARKS) do
                if not table.find(list[level], mark.item) then
                    table.insert(list[level], mark.item)
                end
            end
        end
    end
end

local next_poll = 0

local function poll()
    if next_poll > os.clock() then
        return
    end

    next_poll = os.clock() + 1

    for _, mark in ipairs(MARKS) do
        local before_t, before_i = mark.template_ok, mark.item_ok
        local ok_t, err_t = pcall(ensure_template, mark)
        local ok_i, err_i = true, nil

        if mark.template_ok then
            ok_i, err_i = pcall(ensure_item, mark)
        end

        if not ok_t then
            mod:error("template %s: %s", mark.template, tostring(err_t))
        end

        if not ok_i then
            mod:error("item %s: %s", mark.template, tostring(err_i))
        end

        if mark.template_ok and not before_t then
            if mark.official_template then
                mod:info("the game now has its own %s template; using it", mark.template)
            else
                mod:info("template %s registered (clone of %s), %s alias entries; %s", mark.template, tostring(mark.donor),
                    tostring(mark.aliases), table.concat(mark.template_notes or {}, "; "))
            end
        end

        if mark.item_ok and not before_i then
            mod:info("item %s injected (clone of %s, slot %s, parts %s/%s/%s): %s", mark.item, tostring(mark.source_item_name),
                tostring(mark.slot), tostring(mark.picked and mark.picked.shaft), tostring(mark.picked and mark.picked.head),
                tostring(mark.picked and mark.picked.pommel), table.concat(mark.notes or {}, "; "))
        end
    end
end

-- Parts and archetypes can change while the game runs: rebuild the items (equip again to see them). Animation set and
-- moveset are read when the templates are built, so those need the mods reloaded (Ctrl+Shift+R) or a restart.
local ITEM_SETTINGS = {
    shaft_set = true, head_set = true, pommel_set = true,
    unlock_zealot = true, unlock_veteran = true, unlock_psyker = true, unlock_adamant = true,
}

mod.on_setting_changed = function(setting_id)
    if ITEM_SETTINGS[setting_id] then
        for _, mark in ipairs(MARKS) do
            mark.dirty = true
        end
    end
end

-- Shaft position ------------------------------------------------------------------------------------------------------
-- The rig's own grip node (775ed761, z -0.1751 on the axe rig, +0.016 on the maul rig) has no known name, so how the
-- axe sits in the hands is a guess; the setting slides the shaft (and the head and pommel on it) along the rig.
local tracked = {}

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function shaft_unit(names)
    if names then
        for unit, item_name in pairs(names) do
            if type(item_name) == "string" and item_name:find(PART_ROOT .. "shaft_", 1, true) == 1 and unit_ok(unit) then
                return unit
            end
        end
    end
end

local function place_shaft(ext, names)
    local unit = shaft_unit(names)

    if not unit then
        return
    end

    local offset = (mod:get("shaft_offset") or 0) / 100
    local turn = tonumber(mod:get("blade_turn")) or 0
    local key = offset .. ":" .. turn
    local placed = ext.__qiangiq_poweraxe_offset

    if not placed then
        placed = {}
        ext.__qiangiq_poweraxe_offset = placed
    end

    if placed[unit] == nil and offset == 0 and turn == 0 then
        return
    end

    if placed[unit] ~= key then
        placed[unit] = key
        Unit.set_local_position(unit, 1, Vector3(0, 0, offset))
        -- blade_turn: quarter turns of the whole axe about the shaft axis (z), to face the blade the right way
        Unit.set_local_rotation(unit, 1, Quaternion.axis_angle(Vector3(0, 0, 1), math.rad(turn)))
    end
end

-- current action of the local player: name, seconds into it, its length (scaled), the clock
local function action_info(ext)
    local ok, info = pcall(function()
        local ude = ScriptUnit.has_extension(ext._unit, "unit_data_system")
        local wa = ude and ude:read_component("weapon_action")

        if not wa then
            return nil
        end

        local t = Managers.time:time("gameplay")
        local template = WeaponTemplates[wa.template_name]
        local settings = template and template.actions and template.actions[wa.current_action_name]
        local total = settings and settings.total_time
        local scale = math.max(wa.time_scale or 1, 0.1)

        if total and total < 10 then
            total = total / scale
        else
            total = nil
        end

        local dws = settings and settings.damage_window_start
        local dwe = settings and settings.damage_window_end
        local locomotion = ude:read_component("locomotion")
        local velocity = locomotion and locomotion.velocity_current
        local speed = velocity and Vector3.length(Vector3(velocity.x, velocity.y, 0)) or 0

        return {
            event = settings and settings.anim_event, name = wa.current_action_name, elapsed = t - (wa.start_t or t), total = total, clock = t,
            dws = dws and dws / scale or nil, dwe = dwe and dwe / scale or nil, speed = speed,
        }
    end)

    return ok and info or nil
end

local function apply_visuals(ext, dt)
    if not ext._is_local_unit or not ext._equipment then
        return
    end

    local ours

    for _, slot in pairs(ext._equipment) do
        local item = slot.item

        if item and ITEM_NAMES[item.name] then
            place_shaft(ext, slot.item_name_by_unit_3p)
            place_shaft(ext, slot.item_name_by_unit_1p)
            ours = slot
        end
    end

    local style = mod:get("arm_style")

    if ours and (style == "billhook" or style == "halberd" or style == "great_axe") then
        local ok, err = pcall(function()
            local info = action_info(ext)

            if info then
                info.set = style
                Arms.update(ext, ours, info, dt)
            end
        end)

        if not ok then
            mod:error("arms update: %s", tostring(err))
            pcall(Arms.stop, ext)
        end
    else
        pcall(Arms.stop, ext)
    end
end

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "_update_item_visibility", function(self)
    if self._is_local_unit then
        tracked[self] = true
        apply_visuals(self)
    end
end)

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "init", function(self, extension_init_context)
    self.__qiangiq_poweraxe_world = extension_init_context and extension_init_context.world
end)

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "update", function(self, unit, dt)
    if tracked[self] then
        apply_visuals(self, dt)
    end
end)

mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, "destroy", function(func, self, ...)
    pcall(Arms.stop, self)
    tracked[self] = nil

    return func(self, ...)
end)

-- Anim event guard (QIangIQsMeltagun 0.2.1 / QIangIQsSwordShield pattern): with the unreleased state machine, events it
-- lacks are skipped instead of failing (Unit.has_animation_event as player_character_state_ledge_vaulting.lua:109 does).
-- AuthoritativePlayerUnitAnimationExtension (hosting) has no _local_wielded_weapon_template, so the wielded template name is
-- stored from inventory_slot_wielded.
local skipped_events = {}

local function guard(unit_field)
    return function(func, self, event_name, ...)
        if event_name == "attack_hit" or event_name == "attack_hit_shield" then
            local ok, t = pcall(function()
                return Managers.time:time("gameplay")
            end)

            mod.__qiangiq_poweraxe_hit = { t = ok and t or 0, armor = event_name == "attack_hit_shield" }
        end

        local wielded = self.__qiangiq_poweraxe_wielded or self._local_wielded_weapon_template

        if anim_used[wielded] then
            local unit = self[unit_field]

            if unit and not Unit.has_animation_event(unit, event_name) then
                if not skipped_events[event_name] then
                    skipped_events[event_name] = true
                    mod:info("skipped anim event %s: not in the 2h_maul state machine", tostring(event_name))
                end

                return
            end
        end

        return func(self, event_name, ...)
    end
end

for _, class_name in ipairs({ "PlayerUnitAnimationExtension", "AuthoritativePlayerUnitAnimationExtension" }) do
    mod:hook_safe(CLASS[class_name], "inventory_slot_wielded", function(self, weapon_template)
        self.__qiangiq_poweraxe_wielded = weapon_template and weapon_template.name or false
    end)

    for _, method in ipairs({ "anim_event_1p", "anim_event_with_variable_float_1p", "anim_event_with_variable_floats_1p" }) do
        mod:hook(CLASS[class_name], method, guard("_first_person_unit"))
    end
end

mod.update = function()
    poll()
end

local function acquire_driver()
    local custom_assets = get_mod("CustomAssets")

    if not custom_assets or not custom_assets.is_api_compatible or not custom_assets.is_api_compatible(1) then
        mod:info("Custom Assets (API 1) not installed: no billhook arms")

        return
    end

    for i, d in ipairs(DRIVERS) do
        local ticket = custom_assets.acquire(mod, d.id, function(_, _, load_error)
            if load_error then
                mod:info("arm driver %s not loaded: %s", d.id, tostring(load_error))

                return
            end

            driver_loaded[i] = true
            mod:info("arm driver %s loaded", d.id)
        end, { resident = true, reference_name = d.id })

        if not ticket then
            mod:info("arm driver %s could not be requested (mod not installed?)", d.id)
        end
    end
end

mod.on_all_mods_loaded = function()
    add_to_unlock_lists()
    acquire_driver()
end

mod.on_unload = function()
    local ok, cache = pcall(MasterItems.get_cached)

    if ok and cache then
        for _, mark in ipairs(MARKS) do
            cache[mark.item] = nil
        end

        for _, kind in ipairs(KINDS) do
            for set in pairs(SETS[kind]) do
                cache[part_item_name(kind, set)] = nil
            end
        end
    end

    for _, mark in ipairs(MARKS) do
        if mark.template_ours then
            WeaponTemplates[mark.template] = nil
        end
    end
end

-- Equip without the backend (QIangIQsShardStaff override): only where this client hosts ----------------------------
local function local_player()
    local players = Managers.player

    return players and players:local_player_safe(1)
end

local function equipped_item_name(player, slot)
    local unit = player and player.player_unit

    if not unit or not Unit.alive(unit) then
        return nil
    end

    local extension = ScriptUnit.has_extension(unit, "visual_loadout_system")
    local item = extension and extension:item_from_slot(slot)

    return item and item.name
end

local previous = {}

local function override(slot, item_name)
    local player = local_player()
    local sync = Managers.profile_synchronization
    local host = sync and sync:synchronizer_host()

    if not player then
        say("no local player")

        return false
    end

    if not host then
        say("not the host here. Use the Psykhanium, a SoloPlay game or a game you host")

        return false
    end

    host:override_slot(player:peer_id(), player:local_player_id(), slot, item_name)
    say("override_slot(%s, %s) sent", slot, tostring(item_name))

    return true
end

local function status()
    for _, mark in ipairs(MARKS) do
        say("%s: template %s (id %s, from %s, %s), item %s (id %s, slot %s, parts %s/%s/%s)", mark.template,
            tostring(mark.template_ok), tostring(mark.template_id), tostring(mark.donor), anim_used[mark.template] and "2h_maul animations" or "released animations",
            tostring(mark.item_ok), tostring(mark.item_id), tostring(mark.slot), tostring(mark.picked and mark.picked.shaft),
            tostring(mark.picked and mark.picked.head), tostring(mark.picked and mark.picked.pommel))

        local notes = {}

        for _, list in ipairs({ mark.template_notes, mark.notes }) do
            for _, note in ipairs(list or {}) do
                notes[#notes + 1] = note
            end
        end

        if #notes > 0 then
            say("  %s", table.concat(notes, "; "))
        end
    end

    local player = local_player()
    local ext = player and player.player_unit and ScriptUnit.has_extension(player.player_unit, "visual_loadout_system")

    say("  billhook arms: %s (driver loaded: %s)", ext and Arms.debug(ext) or "no local unit", tostring(driver_loaded[1] == true))
    say("  axe rig package found: %s, 2h_maul state machine package found: %s", tostring(package_found(RIG)),
        tostring(package_found(UNRELEASED_SM)))
end

mod:command("poweraxe", mod:localize("command_poweraxe"), function(action, which)
    action = action or "status"

    if action == "status" then
        status()
    elseif action == "equip" then
        local mark = MARK_BY_KEY[which or "p1_m1"]

        if not mark then
            say("usage: /poweraxe equip [p1_m1|p2_m1|p2_m2|p2_m3]")

            return
        end

        if not (mark.template_ok and mark.item_ok and mark.slot) then
            say("%s not ready yet (template %s, item %s)", mark.template, tostring(mark.template_ok), tostring(mark.item_ok))

            return
        end

        local player = local_player()

        previous[mark.slot] = previous[mark.slot] or (player and equipped_item_name(player, mark.slot))
        override(mark.slot, mark.item)
    elseif action == "restore" then
        local any = false

        for slot, item_name in pairs(previous) do
            if item_name and override(slot, item_name) then
                previous[slot] = nil
                any = true
            end
        end

        if not any then
            say("nothing to restore (equip first)")
        end
    else
        say("usage: /poweraxe [status|equip <mark>|restore]")
    end
end)
