local mod = get_mod("QIangIQsPowerAxe")

local function part_options(with_ml01)
    local options = {
        { text = "part_mark", value = "mark" },
        { text = "part_01", value = "01" },
        { text = "part_02", value = "02" },
        { text = "part_03", value = "03" },
    }

    if with_ml01 then
        options[#options + 1] = { text = "part_ml01", value = "ml01" }
    end

    return options
end

local function moveset_widget(key, default)
    return {
        setting_id = "moveset_" .. key,
        type = "dropdown",
        default_value = default,
        options = {
            { text = "moveset_m1", value = "m1" },
            { text = "moveset_m2", value = "m2" },
        },
    }
end

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = false,
    options = {
        widgets = {
            { setting_id = "add_to_unlock_list", type = "checkbox", default_value = true },
            { setting_id = "unlock_level", type = "numeric", default_value = 1, range = { 1, 30 }, decimals_number = 0 },
            { setting_id = "unlock_zealot", type = "checkbox", default_value = true },
            { setting_id = "unlock_veteran", type = "checkbox", default_value = true },
            { setting_id = "unlock_psyker", type = "checkbox", default_value = true },
            { setting_id = "unlock_adamant", type = "checkbox", default_value = true },
            {
                setting_id = "animation_set",
                type = "dropdown",
                default_value = "released",
                options = {
                    { text = "animation_released", value = "released" },
                    { text = "animation_unreleased", value = "unreleased" },
                },
            },
            {
                setting_id = "animation_family",
                type = "dropdown",
                default_value = "sword",
                options = {
                    { text = "family_sword", value = "sword" },
                    { text = "family_maul", value = "maul" },
                },
            },
            {
                setting_id = "blade_turn",
                type = "dropdown",
                default_value = "180",
                options = {
                    { text = "turn_0", value = "0" },
                    { text = "turn_90", value = "90" },
                    { text = "turn_180", value = "180" },
                    { text = "turn_270", value = "270" },
                },
            },
            { setting_id = "shaft_set", type = "dropdown", default_value = "mark", options = part_options(false) },
            { setting_id = "head_set", type = "dropdown", default_value = "mark", options = part_options(true) },
            { setting_id = "pommel_set", type = "dropdown", default_value = "mark", options = part_options(true) },
            { setting_id = "shaft_offset", type = "numeric", default_value = 0, range = { -40, 40 }, decimals_number = 1 },
            {
                setting_id = "movesets",
                type = "group",
                sub_widgets = {
                    moveset_widget("p1_m1", "m1"),
                    moveset_widget("p2_m1", "m2"),
                    moveset_widget("p2_m2", "m1"),
                    moveset_widget("p2_m3", "m2"),
                },
            },
        },
    },
}
