-- QIangIQ's Ember Heirloom, Warframe 1:1: the model keeps its own Warframe skeleton (no fit to the Darktide
-- skeleton) and is driven by Warframe's own clips. Each clip is a skeleton-only "driver" unit (Custom Assets, simple
-- animation) linked to the player unit; the model is linked to the driver by node name, the same way
-- QIangIQsEmotes plays a custom dance (QIangIQsEmotes.lua play_dance: World.link_unit(driver, 1, unit, 1), then
-- World.link_unit(body, 1, driver, 1, World.LINK_MODE_NODE_NAME), Unit.play_simple_animation(driver, 0, nil, loop, speed)).
-- Author: QIangIQ
local mod = get_mod("QIangIQsEmberWF")

local MODEL = "ember_wf"
local ASSET_DIR = "content/mods/qiangiq_ember_wf/"
-- clip -> { speed = ground speed (m/s) the clip was authored for (hip travel / duration in build\drivers*.log); nil = not
-- matched to movement. once = plays one time (dur = its length in s, from the same logs) and holds the state that long }
-- Warframe sources: ember_wf\clips_all.txt (D:\WarframeRip\char), one Warframe clip per Darktide state.
local CLIPS = {
    idle = {}, walk = { speed = 1.81 }, jog = { speed = 3.76 }, sprint = { speed = 6.5 }, fall = {},
    u_crouch = {}, u_crouchwalk = { speed = 1.84 }, u_slide = {},
    r_idle = {}, r_walk = { speed = 1.81 }, r_jog = { speed = 4.23 }, r_sprint = { speed = 6.5 },
    r_crouch = {}, r_crouchwalk = { speed = 1.84 }, r_slide = {}, r_aim = {}, r_aimwalk = { speed = 2.11 },
    r_fire = {}, r_reload = { once = true, dur = 2.37 }, r_jump = {},
    p_idle = {}, p_walk = { speed = 1.81 }, p_jog = { speed = 3.76 }, p_sprint = { speed = 6.5 },
    p_crouch = {}, p_crouchwalk = { speed = 1.84 }, p_slide = {}, p_aim = {},
    p_fire = {}, p_reload = { once = true, dur = 1.1 }, p_jump = {}, p_equip = { once = true, dur = 0.47 },
    m_idle = {}, m_walk = { speed = 1.81 }, m_jog = { speed = 4.23 }, m_sprint = { speed = 6.5 },
    m_crouch = {}, m_crouchwalk = { speed = 1.84 }, m_slide = {}, m_block = {}, m_blockwalk = { speed = 3.76 }, m_jump = {},
    m_equip = { once = true, dur = 0.53 },
    -- hit = the clip's own damage window (fractions of the clip): Warframe's StartMeleeSweep / EndMeleeSweep events from
    -- the Packages.bin dump where the clip has them, otherwise the frames where the weapon hand moves faster than half
    -- its peak speed (classify_swings.py, classify_stances.txt). Used to retime the clip onto Darktide's damage window.
    m_swing1 = { once = true, dur = 0.4, hit = { 0.4, 0.88 } }, m_swing2 = { once = true, dur = 0.4, hit = { 0.36, 0.596 } },
    m_swing3 = { once = true, dur = 0.4, hit = { 0.257, 0.415 } }, m_swing4 = { once = true, dur = 0.63, hit = { 0.444, 0.667 } },
    m_heavy = { once = true, dur = 0.73, hit = { 0.333, 0.524 } }, m_push = { once = true, dur = 0.27 },
    -- idle, r_idle, p_idle: Ember's Noble idles (Menu\Idles\Ember\NobleIdle*); m_idle: Sword IdleNoble;
    -- dodges: Ember's own (Powers\Ember\EmberAugmentDodge*), ember_wf\clips_noble.txt
    dodge_f = { once = true, dur = 0.9 }, dodge_b = { once = true, dur = 0.97 },
    dodge_l = { once = true, dur = 0.97 }, dodge_r = { once = true, dur = 0.97 },
    throw = { once = true, dur = 0.87 },
    hang = {}, climb = { once = true, dur = 0.83 },
    down = {}, getup = { once = true, dur = 1.17 },
    stagger_f = { once = true, dur = 0.23 }, stagger_b = { once = true, dur = 0.23 },
    stagger_l = { once = true, dur = 0.23 }, stagger_r = { once = true, dur = 0.23 },
    netted = {}, pounced = {}, grabbed = {}, catapulted = {}, stunned = {},
    interact = {}, minigame = {}, revive = {}, hogtied = {},
    -- female-frame movement for the "movement_style" option (ember_wf\clips_titania.txt; Ember has no walk of her own)
    t_walk = { speed = 2.51 }, t_jog = { speed = 5.86 }, t_sprint = { speed = 6.95 },
    w_jog = { speed = 7.81 }, w_sprint = { speed = 11.69 },
    -- duelling sword (combatsword_p3): Titania's rapier movement (ember_wf\clips_duel.txt); pokes from Iron Phoenix,
    -- slashes from Swooping Falcon (ember_wf\clips_stance.txt, stance -> clips from Warframe's own MeleeTree data).
    -- Swooping Falcon has no slash sweeping up to her left, so d_slash_lu stays the Rapier's (Melee\Rapier\Combo1B).
    d_idle = {}, d_walk = { speed = 3.67 }, d_jog = { speed = 4.72 }, d_sprint = { speed = 6.95 },
    d_crouch = {}, d_crouchwalk = { speed = 1.83 }, d_slide = {}, d_block = {}, d_blockwalk = { speed = 3.76 },
    d_jump = {}, d_equip = { once = true, dur = 0.4 }, d_parry = { once = true, dur = 0.93 },
    d_thrust1 = { once = true, dur = 0.4, hit = { 0.421, 0.995 } }, d_thrust2 = { once = true, dur = 0.5, hit = { 0.533, 0.667 } },
    d_thrust_heavy = { once = true, dur = 0.4, hit = { 0.421, 0.995 } },
    d_charge = { once = true, dur = 1.0 }, d_charge_slash = { once = true, dur = 1.0 },
    d_slash_ld = { once = true, dur = 0.333, hit = { 0.4, 0.7 } }, d_slash_rd = { once = true, dur = 0.4, hit = { 0.504, 0.777 } },
    d_slash_lu = { once = true, dur = 0.23, hit = { 0.375, 0.75 } }, d_slash_ru = { once = true, dur = 0.6, hit = { 0.5, 0.667 } },
    d_heavy_rd = { once = true, dur = 0.967, hit = { 0.552, 0.621 } }, d_heavy_ld = { once = true, dur = 0.867, hit = { 0.423, 0.769 } },
    d_push = { once = true, dur = 0.27 },
    -- transitions (ember_wf\clips_stance.txt): attack -> idle is the Sword attacks' own "Holster" clip; jump start and
    -- landing per weapon set. Warframe has no walk / jog / sprint start or stop clips for these sets.
    s_recover = { once = true, dur = 0.3 },
    d_jumpstart = { once = true, dur = 0.167 }, d_land = { once = true, dur = 0.267 },
    m_jumpstart = { once = true, dur = 0.167 }, m_land = { once = true, dur = 0.267 },
    r_jumpstart = { once = true, dur = 0.167 }, r_land = { once = true, dur = 0.267 }, r_landjog = { once = true, dur = 0.267 },
    p_jumpstart = { once = true, dur = 0.133 }, p_land = { once = true, dur = 0.267 },
}
-- movement_style -> clip used instead of the shared walk / jog / sprint (any weapon set); nil keeps the shared one
local STYLE = {
    titania = { walk = "t_walk", jog = "t_jog", sprint = "t_sprint" },
    wisp = { jog = "w_jog", sprint = "w_sprint" },
}
local MIN_DWELL = 0.4 -- s a clip stays before the next switch (a new driver restarts the clip)
local RESTART_RATIO = 0.35 -- same clip restarted when the wanted rate drifts this far from the playing one

local CHARACTER_MODS = { "QIangIQsAnubis", "QIangIQsDominanceAnubis", "QIangIQsEmber", "QIangIQsCitlali", "QIangIQsYvonne", "QIangIQsKulveTaroth", "QIangIQsNavia", "QIangIQsZhuangFangyi", "QIangIQsArknightsEmber", "QIangIQsHornet", "QIangIQsAlienQueen", "QIangIQsAnkha", "QIangIQsValkyrHeirloom", "QIangIQsMesaHeirloom", "QIangIQsCitrinePrime", "QIangIQsOctaviaPrime", "QIangIQsOraxia", "QIangIQsSevagothPrime", "QIangIQsVorunaPrime", "QIangIQsWispPrime", "QIangIQsYareliPrime", "QIangIQsMarieGemini", "QIangIQsEleanorGemini", "QIangIQsJade" }
local EXCLUDED_BREEDS = { ogryn = true } -- the model is human sized

local custom_assets = nil
local ready = {} -- [Custom folder] = true once its package is loaded
local tracked = setmetatable({}, { __mode = "k" }) -- visual loadout extensions this mod has touched

local function opt(key)
    return mod:get(key)
end

local function model_on()
    return opt("model_enabled") == true
end

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function unit_name(name)
    return ASSET_DIR .. name
end

local function local_player_unit()
    local players = Managers.player
    if not players then
        return nil
    end
    local ok, player = pcall(players.local_player_safe, players, 1)
    return ok and player and player.player_unit or nil
end

local function is_local(ext)
    local unit = ext._unit
    return unit_ok(unit) and unit == local_player_unit()
end

local function ext_breed(ext)
    local props = ext._static_profile_properties
    return (props and props.breed) or rawget(ext, "__qiangiq_breed")
end

local function delete_unit(unit)
    if unit_ok(unit) then
        local unit_spawner = Managers.state and Managers.state.unit_spawner
        if unit_spawner then
            unit_spawner:mark_for_deletion(unit)
        end
    end
end

-- slot_body_* / slot_gear_* hold the body parts and cosmetics; weapons live in other slots (as QIangIQsEmber.lua)
local function hide_body_slots(slots)
    if not slots then
        return
    end
    for slot_name, slot in pairs(slots) do
        if string.find(slot_name, "^slot_body_") or string.find(slot_name, "^slot_gear_") then
            local unit = slot.unit_3p
            if unit_ok(unit) then
                Unit.set_unit_visibility(unit, false, true)
                local attachments = slot.attachments_by_unit_3p and slot.attachments_by_unit_3p[unit]
                if attachments then
                    for i = 1, #attachments do
                        if unit_ok(attachments[i]) then
                            Unit.set_unit_visibility(attachments[i], false, true)
                        end
                    end
                end
            end
        end
    end
end

-- What the player is doing: ground speed from the locomotion component (foot_ik.lua:355 reads velocity_current the
-- same way), state from character_state (jumping / falling / sprinting, see player_character_state_*.lua).
local function read_motion(unit)
    local data_extension = ScriptUnit.has_extension(unit, "unit_data_system")
    if not data_extension then
        return 0, nil
    end
    local locomotion = data_extension:read_component("locomotion")
    local character_state = data_extension:read_component("character_state")
    local velocity = locomotion and locomotion.velocity_current
    local speed = 0
    if velocity then
        speed = math.sqrt(velocity.x * velocity.x + velocity.y * velocity.y)
    end
    return speed, character_state and character_state.state_name
end

-- Darktide state -> Warframe clip ------------------------------------------------------------------------------------
-- Components read (all from the game's unit_data_system, names checked against Aussiemon/Darktide-Source-Code master):
--   character_state.state_name (player_character_state_*.lua), movement_state.is_crouching (dodging.lua:213),
--   dodge_character_state.dodge_direction (local: x right, y forward; dodging.lua:37 picks dodge_bwd when |y| > |x|),
--   inventory.wielded_slot (player_unit_weapon_extension.lua:431), alternate_fire.is_active (alternate_fire.lua:19),
--   weapon_action.template_name / current_action_name (action_handler.lua:52-54), whose action `kind` comes from the
--   weapon template (WeaponTemplate.current_weapon_template, weapon_template.lua:6).
local WeaponTemplates = nil

local function weapon_template(name)
    if not WeaponTemplates then
        local ok, t = pcall(require, "scripts/settings/equipment/weapon_templates/weapon_templates")
        WeaponTemplates = ok and t or {}
    end
    return name and WeaponTemplates[name]
end

local function has_keyword(template, pattern)
    local keywords = template and template.keywords
    if keywords then
        for i = 1, #keywords do
            if string.find(keywords[i], pattern) then
                return true
            end
        end
    end
    return false
end

-- clip set for what is in her hands: m_ melee, p_ pistols, r_ other ranged (rifles, staves, flamers), "" bare hands
local function weapon_set(slot, template)
    if slot == "slot_primary" then
        -- duelling sword: keywords { "melee", "combat_sword", "p3" } (combatsword_p3_m1.lua), stabs + parry special
        if has_keyword(template, "^combat_sword$") and has_keyword(template, "^p3$") then
            return "d_"
        end
        return "m_"
    end
    if slot == "slot_secondary" then
        if has_keyword(template, "pistol") or has_keyword(template, "revolver") then
            return "p_"
        end
        return "r_"
    end
    return ""
end

local function locomotion(set, speed, crouch, sprinting)
    local u = set == "" and "u_" or set
    if crouch then
        return speed < 0.4 and u .. "crouch" or u .. "crouchwalk"
    end
    local name = (sprinting and speed > 3.2) and "sprint" or speed < 0.4 and "idle" or speed < 2.8 and "walk" or speed < 5.0 and "jog" or "sprint"
    local style = set ~= "d_" and STYLE[opt("movement_style") or "titania"] -- the rapier set has its own Titania moves
    if style and style[name] and ready["ember_wf_" .. style[name]] then
        return style[name]
    end
    return set == "" and name or set .. name
end

local DISABLED = {
    knocked_down = "down", dead = "down", exploding = "down", hogtied = "hogtied", netted = "netted",
    pounced = "pounced", grabbed = "grabbed", warp_grabbed = "grabbed", consumed = "grabbed", mutant_charged = "catapulted",
    catapulted = "catapulted", ledge_hanging = "hang", ledge_hanging_pull_up = "climb", ledge_vaulting = "climb",
    ledge_hanging_falling = "fall", ladder_climbing = "hang", ladder_top_entering = "climb", ladder_top_leaving = "climb",
    interacting = "interact", minigame = "minigame",
}

local function read(unit, name)
    local ext = ScriptUnit.has_extension(unit, "unit_data_system")
    if not ext then
        return nil
    end
    local ok, c = pcall(ext.read_component, ext, name)
    return ok and c or nil
end

-- returns the clip for this frame; data.swing counts melee swings so consecutive attacks alternate clips
local function pick_clip(unit, data, speed, state)
    -- take-off and touch-down times, for the jump start / landing transition clips
    local airborne = state == "jumping" or state == "falling"
    if airborne and not data.air then
        data.air, data.air_t0, data.jumped = true, data.clock, state == "jumping"
    elseif not airborne and data.air then
        data.air, data.land_t0 = false, data.clock
    end
    local mapped = DISABLED[state]
    if mapped then
        return mapped
    end
    if state == "stunned" then
        return "stagger_b"
    end
    if state == "dodging" then
        local dodge = read(unit, "dodge_character_state")
        local d = dodge and dodge.dodge_direction
        if d then
            if math.abs(d.y) > math.abs(d.x) then
                return d.y > 0 and "dodge_f" or "dodge_b"
            end
            return d.x > 0 and "dodge_r" or "dodge_l"
        end
        return "dodge_b"
    end
    local inventory = read(unit, "inventory")
    local slot = inventory and inventory.wielded_slot
    local action = read(unit, "weapon_action")
    local template = weapon_template(action and action.template_name)
    local action_name = action and action.current_action_name
    local kind = template and template.actions and action_name and template.actions[action_name] and template.actions[action_name].kind or ""
    local set = weapon_set(slot, template)
    if slot == "slot_grenade_ability" or has_keyword(template, "grenade") then
        if action_name and action_name ~= "none" and not string.find(kind, "wield") then
            return "throw"
        end
    end
    if state == "sliding" then
        return (set == "" and "u_" or set) .. "slide"
    end
    if state == "jumping" or state == "falling" then
        local start = CLIPS[set .. "jumpstart"]
        if set ~= "" and start and data.jumped and data.clock - data.air_t0 < start.dur and ready["ember_wf_" .. set .. "jumpstart"] then
            return set .. "jumpstart"
        end
        return set == "" and "fall" or set .. "jump"
    end
    local movement = read(unit, "movement_state")
    local crouch = movement and movement.is_crouching
    local last_kind = data.kind
    data.kind = kind
    if set == "d_" then
        -- the attack's own anim_event (combatsword_p3_m1.lua: heavy_charge_stab_left, heavy_attack_stab_left,
        -- attack_left_diagonal_down, attack_right_diagonal_up, heavy_attack_right_diagonal_down, parry_pose,
        -- parry_special, attack_push) picks a Rapier thrust or a slash sweeping the same way
        local def = template and template.actions and template.actions[action_name]
        local ev = def and def.anim_event or ""
        if kind == "windup" then
            data.timing = { def = def, start_t = action.start_t, time_scale = action.time_scale }
            return string.find(ev, "stab") and "d_charge" or "d_charge_slash"
        end
        if kind == "sweep" then
            data.timing = { def = def, start_t = action.start_t, time_scale = action.time_scale }
            local heavy = string.find(ev, "heavy") ~= nil
            if string.find(ev, "stab") then
                if heavy then
                    return "d_thrust_heavy"
                end
                if action.start_t ~= data.swing_t then
                    data.swing = ((data.swing or 0) % 2) + 1
                end
                data.swing_t = action.start_t
                return "d_thrust" .. (data.swing or 1)
            end
            local side = string.find(ev, "left") and "l" or "r"
            if heavy then
                return "d_heavy_" .. side .. "d"
            end
            return "d_slash_" .. side .. (string.find(ev, "up") and "u" or "d")
        end
        if kind == "push" then
            return "d_push"
        end
        if string.find(ev, "parry_special") then
            return "d_parry"
        end
        if kind == "block" or string.find(action_name or "", "block") then
            return speed < 0.4 and "d_block" or "d_blockwalk"
        end
        if kind == "wield" then
            return "d_equip"
        end
    end
    if set == "m_" then
        if kind == "windup" or kind == "sweep" then
            -- a new attack (a windup, or a sweep not coming out of one) moves on to the next swing clip
            local start_t = action.start_t
            if start_t ~= data.swing_t and (kind == "windup" or last_kind ~= "windup") then
                data.swing = ((data.swing or 0) % 4) + 1
            end
            data.swing_t = start_t
            -- the swing clip starts during the windup at its own pace and is retimed once the sweep begins
            data.timing = kind == "sweep" and { def = template.actions[action_name], start_t = start_t, time_scale = action.time_scale } or nil
            return string.find(action_name, "heavy") and "m_heavy" or "m_swing" .. (data.swing or 1)
        end
        if kind == "push" then
            return "m_push"
        end
        if kind == "block" or string.find(action_name or "", "block") then
            return speed < 0.4 and "m_block" or "m_blockwalk"
        end
        if kind == "wield" then
            return "m_equip"
        end
    elseif set ~= "" then
        if string.find(kind, "reload") then
            return set .. "reload"
        end
        if string.find(kind, "shoot") or string.find(kind, "flamer") or string.find(kind, "projectile") or string.find(kind, "chain_lightning") then
            return set .. "fire"
        end
        if kind == "ranged_wield" and set == "p_" then
            return "p_equip"
        end
        local alt = read(unit, "alternate_fire")
        if alt and alt.is_active and not crouch then
            return (speed > 0.4 and set == "r_") and "r_aimwalk" or set .. "aim"
        end
    end
    -- just touched down: the weapon set's landing clip (a one-shot, so it finishes before movement takes over)
    if set ~= "" and not crouch and data.land_t0 and data.clock - data.land_t0 < 0.1 then
        local land = (set == "r_" and speed > 2.8) and "r_landjog" or set .. "land"
        if CLIPS[land] and ready["ember_wf_" .. land] then
            return land
        end
    end
    return locomotion(set, speed, crouch, state == "sprinting")
end

local function wanted_rate(clip, speed)
    local info = CLIPS[clip]
    if info.speed and opt("anim_speed_match") ~= false then
        return math.max(0.5, math.min(1.6, speed / info.speed))
    end
    return 1
end

local function data_of(ext)
    local data = rawget(ext, "__qiangiq_wf")
    if not data then
        data = { t = 0, clock = 0 }
        rawset(ext, "__qiangiq_wf", data)
    end
    return data
end

local function despawn(ext)
    local data = rawget(ext, "__qiangiq_wf")
    if not data then
        return
    end
    local world = rawget(ext, "__qiangiq_world")
    if unit_ok(data.model) and world then
        World.unlink_unit(world, data.model)
    end
    delete_unit(data.model)
    delete_unit(data.driver)
    if data.pending then
        if unit_ok(data.pending.model) and world then
            World.unlink_unit(world, data.pending.model)
        end
        delete_unit(data.pending.model)
        delete_unit(data.pending.driver)
    end
    rawset(ext, "__qiangiq_wf", nil)
end

-- Glow ----------------------------------------------------------------------------------------------
-- Ported from QIangIQsEmber.lua. The emissive layers (fire core, trim) are the compiler's PBR emissive material, whose
-- brightness is the scalar variable "intensity" (id32 0x32f447e5) and whose colour is "emissive_color" (id32 0xc985395a);
-- both are set the way the game applies material overrides (visual_loadout_customization.lua:516 / :534,
-- Unit.set_scalar_for_materials / Unit.set_vector3_for_materials). Materials without them (the glass skin) ignore the call.
-- The engine's response to "intensity" is far from linear: 0-100 % maps onto 0-3 along a power curve (1 % ~ 0.1, 100 % = 3).
local GLOW_DEFAULT = 23 -- %
local GLOW_MAX = 3
local GLOW_CURVE = 0.74
local colored = setmetatable({}, { __mode = "k" })

local function glow_intensity(pct)
    local t = math.max(math.min(pct or 0, 100), 0) / 100
    return GLOW_MAX * t ^ GLOW_CURVE
end

local function custom_glow_color()
    if opt("glow_color_custom") then
        return math.max(opt("glow_color_r") or 1, 0), math.max(opt("glow_color_g") or 1, 0), math.max(opt("glow_color_b") or 1, 0)
    end
    return nil
end

local function apply_glow(unit, intensity)
    if not unit_ok(unit) then
        return
    end
    Unit.set_scalar_for_materials(unit, "intensity", intensity or glow_intensity(opt("glow_level") or GLOW_DEFAULT), true)
    local r, g, b = custom_glow_color()
    if r then
        Unit.set_vector3_for_materials(unit, "emissive_color", Vector3(r, g, b), true)
        colored[unit] = true
    elseif colored[unit] then
        Unit.set_vector3_for_materials(unit, "emissive_color", Vector3(1, 1, 1), true)
        colored[unit] = nil
    end
end

-- Reactive glow: brightens with the Psyker's peril ("warp_charge" component, current_percentage) and the Veteran's
-- plasma gun heat ("slot_secondary", overheat_current_percentage), from the glow setting at none to glow_reactive_peak at
-- full; 0 for other classes or when a component cannot be read (pcall). Same reads as QIangIQsEmber.lua reactive_level.
local REACTIVE_FOLLOW = 0.15 -- share of the way to the new level per 60 fps frame (smooths flicker)
local REACTIVE_SOURCE = { psyker = { "warp_charge", "current_percentage" }, veteran = { "slot_secondary", "overheat_current_percentage" } }

local function reactive_level(ext)
    local player = ext._player
    local ok, archetype = pcall(function()
        return player and player:archetype_name()
    end)
    local source = ok and REACTIVE_SOURCE[archetype]
    local unit = ext._unit
    if not (source and unit_ok(unit)) then
        return 0
    end
    local unit_data_extension = ScriptUnit.has_extension(unit, "unit_data_system")
    if not unit_data_extension then
        return 0
    end
    local ok2, component = pcall(unit_data_extension.read_component, unit_data_extension, source[1])
    local v = ok2 and component and component[source[2]]
    return type(v) == "number" and math.clamp01(v) or 0
end

local function apply_reactive_glow(ext, data, dt)
    if not unit_ok(data.model) then
        return
    end
    if not opt("glow_reactive") then
        if rawget(ext, "__qiangiq_wf_rshown") then
            rawset(ext, "__qiangiq_wf_rshown", nil)
            apply_glow(data.model)
        end
        return
    end
    local f = math.min(dt or 0.0167, 0.1) * 60
    local shown = rawget(ext, "__qiangiq_wf_rshown") or 0
    shown = shown + (reactive_level(ext) - shown) * (1 - (1 - REACTIVE_FOLLOW) ^ f)
    rawset(ext, "__qiangiq_wf_rshown", shown)
    local own = glow_intensity(opt("glow_level") or GLOW_DEFAULT)
    local peak = glow_intensity(opt("glow_reactive_peak") or 100)
    apply_glow(data.model, own + math.max(peak - own, 0) * shown)
end

-- How many frames a new driver plays before the model moves onto it. A driver linked the frame it is spawned has not
-- evaluated its animation yet (bones still at their spawn values), and the model snapped to that for a frame or more:
-- the stretched / folded body seen at every idle -> walk -> jog switch in the 2026-10-19 recording.
local SWAP_FRAMES = 3

-- Start `clip` on a fresh driver AND a fresh model, linked the way QIangIQsEmotes links its dance (driver on the player
-- unit, model on the driver by node name, both just spawned, so the model is still in its rest pose when linked). Relinking
-- an already posed model bakes that pose into the link offsets and folds / stretches the body (2026-10-19 recording and
-- 2026-10-20 "trembling"). The new pair stays hidden for SWAP_FRAMES, then replaces the old pair.
local function play_clip(ext, data, clip, rate)
    local world = rawget(ext, "__qiangiq_world")
    local unit_spawner = Managers.state and Managers.state.unit_spawner
    if not (world and unit_spawner and unit_ok(ext._unit)) then
        return false
    end
    local pose = Unit.world_pose(ext._unit, 1)
    local driver = unit_spawner:spawn_unit(unit_name("ember_wf_" .. clip), pose)
    local model = driver and unit_spawner:spawn_unit(unit_name(MODEL), pose)
    if not (driver and model) then
        delete_unit(driver)
        delete_unit(model)
        return false
    end
    World.link_unit(world, driver, 1, ext._unit, 1)
    World.link_unit(world, model, 1, driver, 1, World.LINK_MODE_NODE_NAME)
    Unit.play_simple_animation(driver, 0, nil, not (CLIPS[clip] and CLIPS[clip].once), rate)
    Unit.set_unit_visibility(model, false, true)
    if data.pending then
        World.unlink_unit(world, data.pending.model)
        delete_unit(data.pending.model)
        delete_unit(data.pending.driver)
    end
    data.pending = { driver = driver, model = model, frames = 0 }
    data.clip = clip
    data.rate = rate
    data.since = 0
    return true
end

local function finish_swap(ext, data)
    local pending = data.pending
    local world = rawget(ext, "__qiangiq_world")
    if not (pending and world) then
        return
    end
    if not (unit_ok(pending.driver) and unit_ok(pending.model)) then
        data.pending = nil
        return
    end
    if unit_ok(data.model) then
        World.unlink_unit(world, data.model)
    end
    delete_unit(data.model)
    delete_unit(data.driver)
    data.model, data.driver = pending.model, pending.driver
    data.pending = nil
    Unit.set_unit_visibility(data.model, not data.first_person, true)
    apply_glow(data.model)
end

-- the model and the locomotion clips are needed; any other clip not loaded (yet) falls back to locomotion in step()
local function assets_ready()
    for _, name in ipairs({ MODEL, "ember_wf_idle", "ember_wf_walk", "ember_wf_jog", "ember_wf_sprint", "ember_wf_fall" }) do
        if not ready[name] then
            return false
        end
    end
    return true
end

local function apply(ext, first_person_mode)
    if not model_on() or not assets_ready() then
        despawn(ext)
        return
    end
    local data = data_of(ext)
    if not unit_ok(data.model) or not unit_ok(data.driver) then
        data.model, data.driver, data.clip = nil, nil, nil
        if not data.pending then
            play_clip(ext, data, "idle", 1)
        end
    end
    data.first_person = first_person_mode and true or false
    if unit_ok(data.model) then
        Unit.set_unit_visibility(data.model, not first_person_mode, true)
        apply_glow(data.model)
    end
    if opt("hide_body") ~= false and not first_person_mode then
        hide_body_slots(ext._equipment)
    end
end

local function refresh_all()
    for ext in pairs(tracked) do
        local ok = pcall(function()
            if unit_ok(ext._unit) and ext.force_update_item_visibility then
                ext:force_update_item_visibility()
            end
        end)
        if not ok then
            tracked[ext] = nil
        end
    end
end

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "init", function(self, extension_init_context, unit, extension_init_data)
    self.__qiangiq_world = extension_init_context and extension_init_context.world
    local archetype = extension_init_data and extension_init_data.archetype
    self.__qiangiq_breed = archetype and archetype.breed
end)

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "_update_item_visibility", function(self, first_person_mode)
    if not is_local(self) then
        return
    end
    if EXCLUDED_BREEDS[ext_breed(self)] then
        despawn(self)
        return
    end
    tracked[self] = true
    apply(self, first_person_mode)
end)

-- Cloth ------------------------------------------------------------------------------------------
-- Warframe simulates the sleeves, leg ropes and fire cloth; the clips carry no tracks for those bones, so without
-- this they stay at their modelled angle to the limb (the sleeves swung through the body as cream shards,
-- 2026-10-20 screenshots). Solver copied from QIangIQsEmber.lua (jiggle_update), bone table generated from this
-- model's armature by D:\WarframeRip\char\jiggle_table.py.
local JIGGLE_BONES = {
    { "GAME_C1_CLOTH33_RLOOMARMLCLOTH", "GAME_L1_TWIST1", "drape", 0.076 },
    { "GAME_C1_CLOTH35_RLOOMARMLCLOTH", "GAME_C1_CLOTH33_RLOOMARMLCLOTH", "drape", 0.108 },
    { "GAME_C1_CLOTH37_RLOOMARMLCLOTH", "GAME_C1_CLOTH35_RLOOMARMLCLOTH", "drape", 0.080 },
    { "GAME_C1_CLOTH47_RLOOMARMLCLOTH", "GAME_C1_CLOTH37_RLOOMARMLCLOTH", "drape", 0.057 },
    { "GAME_C1_CLOTH41_RLOOMARMLCLOTH", "GAME_C1_CLOTH47_RLOOMARMLCLOTH", "drape", 0.062 },
    { "GAME_C1_CLOTH44_RLOOMARMLCLOTH", "GAME_C1_CLOTH41_RLOOMARMLCLOTH", "drape", 0.065 },
    { "GAME_C1_CLOTH52_RLOOMARMLCLOTH", "GAME_L1_ARM2", "drape", 0.051 },
    { "GAME_C1_CLOTH36_RLOOMARMLCLOTH", "GAME_C1_CLOTH52_RLOOMARMLCLOTH", "drape", 0.104 },
    { "GAME_C1_CLOTH38_RLOOMARMLCLOTH", "GAME_C1_CLOTH36_RLOOMARMLCLOTH", "drape", 0.081 },
    { "GAME_C1_CLOTH46_RLOOMARMLCLOTH", "GAME_C1_CLOTH38_RLOOMARMLCLOTH", "drape", 0.050 },
    { "GAME_C1_CLOTH53_RLOOMARMLCLOTH", "GAME_C1_CLOTH46_RLOOMARMLCLOTH", "drape", 0.066 },
    { "GAME_C1_CLOTH5_RLOOMARMLCLOTH", "GAME_C1_CLOTH53_RLOOMARMLCLOTH", "drape", 0.075 },
    { "GAME_C1_CLOTH3_RLOOMARMLCLOTH", "GAME_L1_ARM1", "drape", 0.086 },
    { "GAME_C1_CLOTH34_RLOOMARMLCLOTH", "GAME_C1_CLOTH3_RLOOMARMLCLOTH", "drape", 0.115 },
    { "GAME_C1_CLOTH22_RLOOMARMLCLOTH", "GAME_C1_CLOTH34_RLOOMARMLCLOTH", "drape", 0.105 },
    { "GAME_C1_CLOTH16_RLOOMARMLCLOTH", "GAME_C1_CLOTH22_RLOOMARMLCLOTH", "drape", 0.070 },
    { "GAME_C1_CLOTH13_RLOOMARMLCLOTH", "GAME_C1_CLOTH16_RLOOMARMLCLOTH", "drape", 0.053 },
    { "GAME_C1_CLOTH10_RLOOMARMLCLOTH", "GAME_C1_CLOTH13_RLOOMARMLCLOTH", "drape", 0.059 },
    { "GAME_C1_CLOTH1_ELMETFIRECLOTH", "GAME_C1_HEAD1", "plume", 0.051 },
    { "GAME_C1_CLOTH9_ELMETFIRECLOTH", "GAME_C1_CLOTH1_ELMETFIRECLOTH", "plume", 0.051 },
    { "GAME_C1_CLOTH20_ELMETFIRECLOTH", "GAME_C1_HEAD1", "plume", 0.048 },
    { "GAME_C1_CLOTH17_ELMETFIRECLOTH", "GAME_C1_CLOTH20_ELMETFIRECLOTH", "plume", 0.048 },
    { "GAME_C1_CLOTH63_ELMETFIRECLOTH", "GAME_C1_HEAD1", "plume", 0.024 },
    { "GAME_C1_CLOTH50_ELMETFIRECLOTH", "GAME_C1_CLOTH63_ELMETFIRECLOTH", "plume", 0.031 },
    { "GAME_C1_CLOTH43_ELMETFIRECLOTH", "GAME_C1_HEAD1", "plume", 0.024 },
    { "GAME_C1_CLOTH55_ELMETFIRECLOTH", "GAME_C1_CLOTH43_ELMETFIRECLOTH", "plume", 0.031 },
    { "GAME_C1_CLOTH46_ELMETFIRECLOTH", "GAME_C1_HEAD1", "plume", 0.028 },
    { "GAME_C1_CLOTH60_ELMETFIRECLOTH", "GAME_C1_CLOTH46_ELMETFIRECLOTH", "plume", 0.030 },
    { "GAME_C1_CLOTH81_ELMETFIRECLOTH", "GAME_C1_HEAD1", "plume", 0.033 },
    { "GAME_C1_CLOTH70_ELMETFIRECLOTH", "GAME_C1_CLOTH81_ELMETFIRECLOTH", "plume", 0.041 },
    { "GAME_C1_CLOTH64_ELMETFIRECLOTH", "GAME_C1_HEAD1", "plume", 0.033 },
    { "GAME_C1_CLOTH75_ELMETFIRECLOTH", "GAME_C1_CLOTH64_ELMETFIRECLOTH", "plume", 0.045 },
    { "GAME_C1_CLOTH67_ELMETFIRECLOTH", "GAME_C1_HEAD1", "plume", 0.038 },
    { "GAME_C1_CLOTH79_ELMETFIRECLOTH", "GAME_C1_CLOTH67_ELMETFIRECLOTH", "plume", 0.042 },
    { "GAME_C1_CLOTH3_ELMETFIRECLOTH", "GAME_C1_NECK1", "plume", 0.051 },
    { "GAME_C1_CLOTH8_ELMETFIRECLOTH", "GAME_C1_CLOTH3_ELMETFIRECLOTH", "plume", 0.051 },
    { "GAME_C1_CLOTH42_ELMETFIRECLOTH", "GAME_C1_NECK1", "plume", 0.029 },
    { "GAME_C1_CLOTH29_ELMETFIRECLOTH", "GAME_C1_CLOTH42_ELMETFIRECLOTH", "plume", 0.038 },
    { "GAME_C1_CLOTH22_ELMETFIRECLOTH", "GAME_C1_NECK1", "plume", 0.030 },
    { "GAME_C1_CLOTH34_ELMETFIRECLOTH", "GAME_C1_CLOTH22_ELMETFIRECLOTH", "plume", 0.038 },
    { "GAME_C1_CLOTH25_ELMETFIRECLOTH", "GAME_C1_NECK1", "plume", 0.034 },
    { "GAME_C1_CLOTH39_ELMETFIRECLOTH", "GAME_C1_CLOTH25_ELMETFIRECLOTH", "plume", 0.036 },
    { "GAME_C1_CLOTH87_RLOOMARMRCLOTH", "GAME_R1_TWIST1", "drape", 0.076 },
    { "GAME_C1_CLOTH89_RLOOMARMRCLOTH", "GAME_C1_CLOTH87_RLOOMARMRCLOTH", "drape", 0.108 },
    { "GAME_C1_CLOTH91_RLOOMARMRCLOTH", "GAME_C1_CLOTH89_RLOOMARMRCLOTH", "drape", 0.080 },
    { "GAME_C1_CLOTH101", "GAME_C1_CLOTH91_RLOOMARMRCLOTH", "drape", 0.057 },
    { "GAME_C1_CLOTH95_RLOOMARMRCLOTH", "GAME_C1_CLOTH101", "drape", 0.062 },
    { "GAME_C1_CLOTH98_RLOOMARMRCLOTH", "GAME_C1_CLOTH95_RLOOMARMRCLOTH", "drape", 0.065 },
    { "GAME_C1_CLOTH106", "GAME_R1_ARM2", "drape", 0.051 },
    { "GAME_C1_CLOTH90_RLOOMARMRCLOTH", "GAME_C1_CLOTH106", "drape", 0.104 },
    { "GAME_C1_CLOTH92_RLOOMARMRCLOTH", "GAME_C1_CLOTH90_RLOOMARMRCLOTH", "drape", 0.081 },
    { "GAME_C1_CLOTH100", "GAME_C1_CLOTH92_RLOOMARMRCLOTH", "drape", 0.050 },
    { "GAME_C1_CLOTH108", "GAME_C1_CLOTH100", "drape", 0.066 },
    { "GAME_C1_CLOTH59_RLOOMARMRCLOTH", "GAME_C1_CLOTH108", "drape", 0.075 },
    { "GAME_C1_CLOTH57_RLOOMARMRCLOTH", "GAME_R1_ARM1", "drape", 0.086 },
    { "GAME_C1_CLOTH88_RLOOMARMRCLOTH", "GAME_C1_CLOTH57_RLOOMARMRCLOTH", "drape", 0.115 },
    { "GAME_C1_CLOTH76_RLOOMARMRCLOTH", "GAME_C1_CLOTH88_RLOOMARMRCLOTH", "drape", 0.105 },
    { "GAME_C1_CLOTH70_RLOOMARMRCLOTH", "GAME_C1_CLOTH76_RLOOMARMRCLOTH", "drape", 0.070 },
    { "GAME_C1_CLOTH67_RLOOMARMRCLOTH", "GAME_C1_CLOTH70_RLOOMARMRCLOTH", "drape", 0.053 },
    { "GAME_C1_CLOTH64_RLOOMARMRCLOTH", "GAME_C1_CLOTH67_RLOOMARMRCLOTH", "drape", 0.059 },
    { "GAME_R1_CLOTH53", "GAME_L1_LEG3", "cloth", 0.045 },
    { "GAME_R1_CLOTH49", "GAME_R1_CLOTH53", "cloth", 0.036 },
    { "GAME_R1_CLOTH54", "GAME_R1_CLOTH49", "cloth", 0.033 },
    { "GAME_R1_CLOTH58", "GAME_L1_LEG3", "cloth", 0.023 },
    { "GAME_R1_CLOTH50", "GAME_R1_CLOTH58", "cloth", 0.035 },
    { "GAME_R1_CLOTH57", "GAME_R1_CLOTH50", "cloth", 0.026 },
    { "GAME_R1_CLOTH71", "GAME_L1_LEG3", "cloth", 0.034 },
    { "GAME_R1_CLOTH68", "GAME_R1_CLOTH71", "cloth", 0.035 },
    { "GAME_R1_CLOTH65", "GAME_R1_CLOTH68", "cloth", 0.029 },
    { "GAME_C1_CLOTH110", "GAME_L1_LEG2", "cloth", 0.020 },
    { "GAME_C1_CLOTH115", "GAME_C1_CLOTH110", "cloth", 0.055 },
    { "GAME_C1_CLOTH119", "GAME_C1_CLOTH115", "cloth", 0.055 },
    { "GAME_C1_CLOTH111", "GAME_L1_LEG2", "cloth", 0.020 },
    { "GAME_C1_CLOTH114", "GAME_C1_CLOTH111", "cloth", 0.055 },
    { "GAME_C1_CLOTH118", "GAME_C1_CLOTH114", "cloth", 0.055 },
    { "GAME_C1_CLOTH124", "GAME_L1_LEG2", "cloth", 0.020 },
    { "GAME_C1_CLOTH126", "GAME_C1_CLOTH124", "cloth", 0.055 },
    { "GAME_C1_CLOTH129", "GAME_C1_CLOTH126", "cloth", 0.055 },
    { "GAME_C1_CLOTH137", "GAME_L1_LEG2", "cloth", 0.020 },
    { "GAME_C1_CLOTH142", "GAME_C1_CLOTH137", "cloth", 0.055 },
    { "GAME_C1_CLOTH146", "GAME_C1_CLOTH142", "cloth", 0.055 },
    { "GAME_C1_CLOTH138", "GAME_L1_LEG2", "cloth", 0.020 },
    { "GAME_C1_CLOTH141", "GAME_C1_CLOTH138", "cloth", 0.055 },
    { "GAME_C1_CLOTH145", "GAME_C1_CLOTH141", "cloth", 0.055 },
    { "GAME_C1_CLOTH151", "GAME_L1_LEG2", "cloth", 0.020 },
    { "GAME_C1_CLOTH153", "GAME_C1_CLOTH151", "cloth", 0.055 },
    { "GAME_C1_CLOTH156", "GAME_C1_CLOTH153", "cloth", 0.055 },
    { "GAME_C1_CLOTH240", "GAME_L1_LEG2", "cloth", 0.024 },
    { "GAME_C1_CLOTH228", "GAME_C1_CLOTH240", "cloth", 0.052 },
    { "GAME_C1_CLOTH217", "GAME_L1_LEG2", "cloth", 0.029 },
    { "GAME_C1_CLOTH221", "GAME_C1_CLOTH217", "cloth", 0.052 },
    { "GAME_C1_CLOTH232", "GAME_L1_LEG2", "cloth", 0.029 },
    { "GAME_C1_CLOTH236", "GAME_C1_CLOTH232", "cloth", 0.046 },
    { "GAME_C1_CLOTH264", "GAME_L1_LEG2", "cloth", 0.024 },
    { "GAME_C1_CLOTH252", "GAME_C1_CLOTH264", "cloth", 0.052 },
    { "GAME_C1_CLOTH241", "GAME_L1_LEG2", "cloth", 0.029 },
    { "GAME_C1_CLOTH245", "GAME_C1_CLOTH241", "cloth", 0.052 },
    { "GAME_C1_CLOTH256", "GAME_L1_LEG2", "cloth", 0.029 },
    { "GAME_C1_CLOTH260", "GAME_C1_CLOTH256", "cloth", 0.046 },
    { "GAME_C1_CLOTH22_TORSOFIRECLOTH", "GAME_L1_LEG2", "plume", 0.193 },
    { "GAME_C1_CLOTH57_TORSOFIRECLOTH", "GAME_C1_CLOTH22_TORSOFIRECLOTH", "plume", 0.053 },
    { "GAME_C1_CLOTH36_TORSOFIRECLOTH", "GAME_C1_CLOTH57_TORSOFIRECLOTH", "plume", 0.030 },
    { "GAME_C1_CLOTH48_TORSOFIRECLOTH", "GAME_C1_CLOTH36_TORSOFIRECLOTH", "plume", 0.027 },
    { "GAME_C1_CLOTH99_TORSOFIRECLOTH", "GAME_L1_LEG2", "plume", 0.120 },
    { "GAME_C1_CLOTH69_TORSOFIRECLOTH", "GAME_C1_CLOTH99_TORSOFIRECLOTH", "plume", 0.084 },
    { "GAME_C1_CLOTH78_TORSOFIRECLOTH", "GAME_C1_CLOTH69_TORSOFIRECLOTH", "plume", 0.072 },
    { "GAME_C1_CLOTH66_TORSOFIRECLOTH", "GAME_C1_CLOTH78_TORSOFIRECLOTH", "plume", 0.061 },
    { "GAME_C1_CLOTH61_TORSOFIRECLOTH", "GAME_L1_LEG2", "plume", 0.120 },
    { "GAME_C1_CLOTH72_TORSOFIRECLOTH", "GAME_C1_CLOTH61_TORSOFIRECLOTH", "plume", 0.084 },
    { "GAME_C1_CLOTH79_TORSOFIRECLOTH", "GAME_C1_CLOTH72_TORSOFIRECLOTH", "plume", 0.072 },
    { "GAME_C1_CLOTH75_TORSOFIRECLOTH", "GAME_C1_CLOTH79_TORSOFIRECLOTH", "plume", 0.061 },
    { "GAME_C1_CLOTH86_TORSOFIRECLOTH", "GAME_L1_LEG2", "plume", 0.120 },
    { "GAME_C1_CLOTH89_TORSOFIRECLOTH", "GAME_C1_CLOTH86_TORSOFIRECLOTH", "plume", 0.084 },
    { "GAME_C1_CLOTH92_TORSOFIRECLOTH", "GAME_C1_CLOTH89_TORSOFIRECLOTH", "plume", 0.071 },
    { "GAME_C1_CLOTH95_TORSOFIRECLOTH", "GAME_C1_CLOTH92_TORSOFIRECLOTH", "plume", 0.060 },
    { "GAME_C1_CLOTH21_TORSOFIRECLOTH", "GAME_L1_LEG1", "plume", 0.108 },
    { "GAME_C1_CLOTH8_TORSOFIRECLOTH", "GAME_C1_CLOTH21_TORSOFIRECLOTH", "plume", 0.108 },
    { "GAME_C1_CLOTH20_TORSOFIRECLOTH", "GAME_L1_LEG1", "plume", 0.106 },
    { "GAME_C1_CLOTH17_TORSOFIRECLOTH", "GAME_C1_CLOTH20_TORSOFIRECLOTH", "plume", 0.106 },
    { "GAME_C1_CLOTH24_TORSOFIRECLOTH", "GAME_L1_LEG1", "plume", 0.072 },
    { "GAME_C1_CLOTH59_TORSOFIRECLOTH", "GAME_C1_CLOTH24_TORSOFIRECLOTH", "plume", 0.110 },
    { "GAME_C1_CLOTH39_TORSOFIRECLOTH", "GAME_C1_CLOTH59_TORSOFIRECLOTH", "plume", 0.078 },
    { "GAME_C1_CLOTH50_TORSOFIRECLOTH", "GAME_C1_CLOTH39_TORSOFIRECLOTH", "plume", 0.062 },
    { "GAME_C1_CLOTH26_TORSOFIRECLOTH", "GAME_L1_LEG1", "plume", 0.140 },
    { "GAME_C1_CLOTH58_TORSOFIRECLOTH", "GAME_C1_CLOTH26_TORSOFIRECLOTH", "plume", 0.081 },
    { "GAME_C1_CLOTH41_TORSOFIRECLOTH", "GAME_C1_CLOTH58_TORSOFIRECLOTH", "plume", 0.049 },
    { "GAME_C1_CLOTH49_TORSOFIRECLOTH", "GAME_C1_CLOTH41_TORSOFIRECLOTH", "plume", 0.042 },
    { "GAME_L1_CLOTH53", "GAME_R1_LEG3", "cloth", 0.045 },
    { "GAME_L1_CLOTH49", "GAME_L1_CLOTH53", "cloth", 0.036 },
    { "GAME_L1_CLOTH54", "GAME_L1_CLOTH49", "cloth", 0.033 },
    { "GAME_L1_CLOTH58", "GAME_R1_LEG3", "cloth", 0.023 },
    { "GAME_L1_CLOTH50", "GAME_L1_CLOTH58", "cloth", 0.035 },
    { "GAME_L1_CLOTH57", "GAME_L1_CLOTH50", "cloth", 0.026 },
    { "GAME_L1_CLOTH71", "GAME_R1_LEG3", "cloth", 0.034 },
    { "GAME_L1_CLOTH68", "GAME_L1_CLOTH71", "cloth", 0.035 },
    { "GAME_L1_CLOTH65", "GAME_L1_CLOTH68", "cloth", 0.029 },
    { "GAME_C1_CLOTH164", "GAME_R1_LEG2", "cloth", 0.020 },
    { "GAME_C1_CLOTH169", "GAME_C1_CLOTH164", "cloth", 0.055 },
    { "GAME_C1_CLOTH173", "GAME_C1_CLOTH169", "cloth", 0.055 },
    { "GAME_C1_CLOTH165", "GAME_R1_LEG2", "cloth", 0.020 },
    { "GAME_C1_CLOTH168", "GAME_C1_CLOTH165", "cloth", 0.055 },
    { "GAME_C1_CLOTH172", "GAME_C1_CLOTH168", "cloth", 0.055 },
    { "GAME_C1_CLOTH178", "GAME_R1_LEG2", "cloth", 0.020 },
    { "GAME_C1_CLOTH180", "GAME_C1_CLOTH178", "cloth", 0.055 },
    { "GAME_C1_CLOTH183", "GAME_C1_CLOTH180", "cloth", 0.055 },
    { "GAME_C1_CLOTH191", "GAME_R1_LEG2", "cloth", 0.020 },
    { "GAME_C1_CLOTH196", "GAME_C1_CLOTH191", "cloth", 0.055 },
    { "GAME_C1_CLOTH200", "GAME_C1_CLOTH196", "cloth", 0.055 },
    { "GAME_C1_CLOTH192", "GAME_R1_LEG2", "cloth", 0.020 },
    { "GAME_C1_CLOTH195", "GAME_C1_CLOTH192", "cloth", 0.055 },
    { "GAME_C1_CLOTH199", "GAME_C1_CLOTH195", "cloth", 0.055 },
    { "GAME_C1_CLOTH205", "GAME_R1_LEG2", "cloth", 0.020 },
    { "GAME_C1_CLOTH207", "GAME_C1_CLOTH205", "cloth", 0.055 },
    { "GAME_C1_CLOTH210", "GAME_C1_CLOTH207", "cloth", 0.055 },
    { "GAME_C1_CLOTH288", "GAME_R1_LEG2", "cloth", 0.024 },
    { "GAME_C1_CLOTH276", "GAME_C1_CLOTH288", "cloth", 0.052 },
    { "GAME_C1_CLOTH265", "GAME_R1_LEG2", "cloth", 0.029 },
    { "GAME_C1_CLOTH269", "GAME_C1_CLOTH265", "cloth", 0.052 },
    { "GAME_C1_CLOTH280", "GAME_R1_LEG2", "cloth", 0.029 },
    { "GAME_C1_CLOTH284", "GAME_C1_CLOTH280", "cloth", 0.046 },
    { "GAME_C1_CLOTH312", "GAME_R1_LEG2", "cloth", 0.024 },
    { "GAME_C1_CLOTH300", "GAME_C1_CLOTH312", "cloth", 0.052 },
    { "GAME_C1_CLOTH289", "GAME_R1_LEG2", "cloth", 0.029 },
    { "GAME_C1_CLOTH293", "GAME_C1_CLOTH289", "cloth", 0.052 },
    { "GAME_C1_CLOTH304", "GAME_R1_LEG2", "cloth", 0.029 },
    { "GAME_C1_CLOTH308", "GAME_C1_CLOTH304", "cloth", 0.046 },
    { "GAME_C1_CLOTH2_TORSOFIRECLOTH", "GAME_R1_LEG1", "plume", 0.108 },
    { "GAME_C1_CLOTH9_TORSOFIRECLOTH", "GAME_C1_CLOTH2_TORSOFIRECLOTH", "plume", 0.108 },
}
local JIGGLE_COLLIDERS = {
    { "GAME_C1_HIP1", "GAME_C1_SPINE1", 0.140 },
    { "GAME_C1_SPINE1", "GAME_C1_SPINE3", 0.120 },
    { "GAME_C1_SPINE3", "GAME_C1_NECK1", 0.090 },
    { "GAME_L1_LEG1", "GAME_L1_LEG2", 0.085 },
    { "GAME_L1_LEG2", "GAME_L1_LEG3", 0.060 },
    { "GAME_L1_ARM1", "GAME_L1_ARM2", 0.050 },
    { "GAME_L1_ARM2", "GAME_L1_ARM3", 0.040 },
    { "GAME_R1_LEG1", "GAME_R1_LEG2", 0.085 },
    { "GAME_R1_LEG2", "GAME_R1_LEG3", 0.060 },
    { "GAME_R1_ARM1", "GAME_R1_ARM2", 0.050 },
    { "GAME_R1_ARM2", "GAME_R1_ARM3", 0.040 },
}
local JIGGLE_GROUPS = {
    breast = { pull = 0.22, drag = 0.16, max_angle = 14, slider = "jiggle_breast" },
    butt = { pull = 0.28, drag = 0.20, max_angle = 10, slider = "jiggle_butt" },
    thigh = { pull = 0.30, drag = 0.22, max_angle = 6, slider = "jiggle_butt" },
    tail = { pull = 0.07, drag = 0.34, max_angle = 32, slider = "jiggle_tail", flow = true, carry = 0.92, total = 50 },
    hair = { pull = 0.05, drag = 0.30, max_angle = 40, slider = "jiggle_hair", flow = true, carry = 0.92, hang = true, total = 45 },
    ear = { pull = 0.25, drag = 0.18, max_angle = 14, slider = "jiggle_ear" },
    drape = { pull = 0.10, drag = 0.40, max_angle = 28, slider = "jiggle_cloth", flow = true, carry = 0.95, drape = true },
    plume = { pull = 0.07, drag = 0.34, max_angle = 30, slider = "jiggle_hair", flow = true, carry = 0.92, total = 30 },
    cloth = { pull = 0.08, drag = 0.36, max_angle = 35, slider = "jiggle_cloth", flow = true, carry = 0.92, hang = true, total = 40 },
}
-- Body collision: capsules along the body (node, node it runs to, radius in metres). Loose chains (hair, tail,
-- plume, cloth, drape) are pushed out of them so they rest on the body instead of passing through it. Only the
-- nodes the unit really has are used, and only the chains that hang free are tested.
local COLLIDE_GROUPS = { tail = true, hair = true, plume = true, cloth = true, drape = true }
local jiggle_state = setmetatable({}, { __mode = "k" })
-- options, read once per change instead of every frame
local JIGGLE = { on = true, stiffness = 1, damping = 1, limit = 1, hang = 0, amount = {} }

local function jiggle_read_settings()
    JIGGLE.on = opt("jiggle") ~= false
    JIGGLE.stiffness = math.max(opt("jiggle_stiffness") or 1, 0.05)
    JIGGLE.damping = math.max(opt("jiggle_damping") or 1, 0.05)
    JIGGLE.limit = math.max(opt("jiggle_limit") or 1, 0.05)
    JIGGLE.hang = math.max(opt("jiggle_hang") or 0, 0)
    for name, g in pairs(JIGGLE_GROUPS) do
        JIGGLE.amount[name] = math.max(opt(g.slider) or 1, 0)
    end
end

local function jiggle_init(unit)
    local bones, by_name = {}, {}
    for _, def in ipairs(JIGGLE_BONES) do
        local name, parent_name = def[1], def[2]
        local parent = by_name[parent_name]
        -- usable when the unit has the bone and the node it hangs from (parts only carry what they need)
        if Unit.has_node(unit, name) and (parent or Unit.has_node(unit, parent_name)) then
            local node = Unit.node(unit, name)
            local b = {
                node = node,
                group = def[3],
                parent = parent,
                parent_node = not parent and Unit.node(unit, parent_name) or nil,
                rest = QuaternionBox(Unit.local_rotation(unit, node)),
                lpos = Vector3Box(Unit.local_position(unit, node)),
                -- the bone runs along its own local Z for its length (the compiler writes every node's
                -- local transform as glTF (x, y, z) -> (x, -z, y), and a glTF bone runs along its Y)
                tip = Vector3Box(Vector3(0, 0, def[4])),
            }
            bones[#bones + 1] = b
            by_name[name] = b
        end
    end
    local colliders = {}
    for _, def in ipairs(JIGGLE_COLLIDERS) do
        if Unit.has_node(unit, def[1]) and Unit.has_node(unit, def[2]) then
            colliders[#colliders + 1] = { Unit.node(unit, def[1]), Unit.node(unit, def[2]), def[3] }
        end
    end
    return { bones = bones, active = false, colliders = colliders }
end

-- push a point out of every body capsule (a, b, radius in world metres)
local function collide_point(p, segs, pad)
    for i = 1, #segs do
        local s = segs[i]
        local a, ab = s.a, s.ab
        local t = math.max(0, math.min(1, Vector3.dot(p - a, ab) / s.len2))
        local c = a + ab * t
        local d = p - c
        local dl = Vector3.length(d)
        local r = s.r + pad
        if dl < r then
            p = dl > 1e-5 and c + d / dl * r or c + Vector3(0, 0, 1) * r
        end
    end
    return p
end

local function jiggle_rest(unit, state)
    for _, b in ipairs(state.bones) do
        Unit.set_local_rotation(unit, b.node, b.rest:unbox())
        b.px = nil
    end
    state.rx = nil
    state.active = false
end

local function jiggle_update(unit, dt)
    if not unit_ok(unit) then
        return
    end
    local state = jiggle_state[unit]
    if not state then
        state = jiggle_init(unit)
        jiggle_state[unit] = state
    end
    if not JIGGLE.on then
        if state.active then
            jiggle_rest(unit, state)
        end
        return
    end
    state.active = true
    local f = math.min(dt or 0.0167, 0.05) * 60
    -- how far the character itself travelled since the last frame (node 1 = the unit's root)
    local root = Unit.world_position(unit, 1)
    local travel = Vector3(0, 0, 0)
    if state.rx then
        travel = root - Vector3(state.rx, state.ry, state.rz)
        if Vector3.length(travel) > 2 then
            travel = Vector3(0, 0, 0)
        end
    end
    state.rx, state.ry, state.rz = root.x, root.y, root.z
    -- ground level under the character (its root is at its feet) and its facing, for draped cloth
    local floor = root.z + 0.02
    local back = Quaternion.forward(Unit.world_rotation(unit, 1))
    -- body capsules in world space for this frame (the body is posed before the bones are moved)
    local segs = {}
    for _, c in ipairs(state.colliders or {}) do
        local a, e = Unit.world_position(unit, c[1]), Unit.world_position(unit, c[2])
        local ab = e - a
        local l2 = Vector3.dot(ab, ab)
        if l2 > 1e-8 then
            segs[#segs + 1] = { a = a, ab = ab, len2 = l2, r = c[3] }
        end
    end
    for _, b in ipairs(state.bones) do
        local g = JIGGLE_GROUPS[b.group]
        local amount = JIGGLE.amount[b.group] or 1
        local parent = b.parent
        local parent_rot, head, scale
        if parent then
            parent_rot, scale = parent.rot, parent.scale
            head = parent.head + Quaternion.rotate(parent_rot, b.lpos:unbox()) * scale
        else
            parent_rot = Unit.world_rotation(unit, b.parent_node)
            head = Unit.world_position(unit, b.node)
            -- world size of one model unit (characters can be scaled)
            local len = Vector3.length(b.lpos:unbox())
            scale = len > 1e-3 and Vector3.length(head - Unit.world_position(unit, b.parent_node)) / len or 1
            if scale < 1e-4 then
                scale = 1
            end
        end
        local rest_rot = Quaternion.multiply(parent_rot, b.rest:unbox())
        -- where the bone would point if the whole chain above it were stiff
        local rigid_rot = parent and Quaternion.multiply(parent.rigid, b.rest:unbox()) or rest_rot
        local tip_off = Quaternion.rotate(rest_rot, b.tip:unbox()) * scale
        local length = Vector3.length(tip_off)
        local world_rot = rest_rot
        if amount <= 0 then
            b.px = nil -- area switched off: stay on the rest pose
        elseif length > 1e-6 then
            local keep = (1 - math.min(g.drag * JIGGLE.damping, 0.95)) ^ f
            local pull = 1 - (1 - math.min(g.pull * JIGGLE.stiffness / amount, 0.95)) ^ f
            local max_angle = math.min(math.rad(g.max_angle) * amount * JIGGLE.limit, 1.4)
            local rest_dir = tip_off / length
            local rest_tip = head + tip_off
            local flow = g.flow
            -- goal_dir: the direction the bone is pulled towards and limited around
            local goal_dir = rest_dir
            if flow and g.drape then
                -- loose cloth hung from a limb: straight down in the world, whatever the limb does
                -- (its modelled angle to the limb is only right for the pose it was modelled in)
                goal_dir = Vector3(0, 0, -1)
                rest_tip = head + goal_dir * length
            elseif flow and g.hang and JIGGLE.hang > 0 then
                -- lean the direction the bone is pulled towards to straight down (world Z is up)
                local lean = rest_dir + Vector3(0, 0, -JIGGLE.hang)
                local ll = Vector3.length(lean)
                if ll > 1e-4 then
                    goal_dir = lean / ll
                    rest_tip = head + goal_dir * length
                end
            end
            -- a tip kept in the world lags when the body moves. Flowing chains keep every tip in the
            -- world; in the other areas only the bone on a normal skeleton node does, and the bones after
            -- it keep theirs relative to their own head, so they follow the bone before them
            local world_tip = flow or not parent
            local origin = world_tip and Vector3(0, 0, 0) or head
            local p, pp = rest_tip, rest_tip
            if b.px then
                p = origin + Vector3(b.px, b.py, b.pz)
                pp = origin + Vector3(b.qx, b.qy, b.qz)
                if flow then
                    local along = travel * g.carry
                    p, pp = p + along, pp + along
                end
                if Vector3.length(p - rest_tip) > 4 * length + 0.5 then
                    p, pp = rest_tip, rest_tip -- teleported: start over at rest
                end
            end
            local k, q = keep, pull
            if parent and not flow then
                -- a follower, not a second spring
                k, q = keep * 0.35, math.min(pull * 1.6, 0.9)
            end
            local nxt = p + (p - pp) * k + (rest_tip - p) * q
            local dir = nxt - head
            local dl = Vector3.length(dir)
            dir = dl > 1e-6 and dir / dl or goal_dir
            -- keep the swing within max_angle of the goal direction
            local axis = Vector3.cross(goal_dir, dir)
            local al = Vector3.length(axis)
            local angle = math.acos(math.max(-1, math.min(1, Vector3.dot(goal_dir, dir))))
            if al > 1e-6 and angle > max_angle then
                dir = Quaternion.rotate(Quaternion.axis_angle(axis / al, max_angle), goal_dir)
            end
            if g.drape and (head + dir * length).z < floor then
                -- the cloth is longer than the arm is high: what reaches the ground lies on it, trailing
                -- the way it already leans (behind the character when it hangs dead straight)
                local dz = math.max(-length, math.min(length, floor - head.z))
                local flat = math.sqrt(math.max(0, length * length - dz * dz))
                local hx, hy = dir.x, dir.y
                local hn = math.sqrt(hx * hx + hy * hy)
                if hn < 1e-3 then
                    hx, hy, hn = -back.x, -back.y, math.max(math.sqrt(back.x * back.x + back.y * back.y), 1e-3)
                end
                dir = Vector3(hx / hn * flat, hy / hn * flat, dz) / length
            end
            if g.total then
                -- and the whole chain within `total` of its stiff shape: per-bone limits add up along a
                -- long chain, which let the far end fold right over
                local rigid_dir = Quaternion.rotate(rigid_rot, b.tip:unbox())
                local rl = Vector3.length(rigid_dir)
                if rl > 1e-6 then
                    rigid_dir = rigid_dir / rl
                    local total = math.min(math.rad(g.total) * amount * JIGGLE.limit, 3)
                    local ax = Vector3.cross(rigid_dir, dir)
                    local axl = Vector3.length(ax)
                    if axl > 1e-6 and math.acos(math.max(-1, math.min(1, Vector3.dot(rigid_dir, dir)))) > total then
                        dir = Quaternion.rotate(Quaternion.axis_angle(ax / axl, total), rigid_dir)
                    end
                end
            end
            if COLLIDE_GROUPS[b.group] and #segs > 0 then
                -- the tip may not end inside the body: slide it out along the surface, keeping the bone's length
                local tip = head + dir * length
                local out = collide_point(tip, segs, 0.01)
                if out ~= tip then
                    local nd = out - head
                    local nl = Vector3.length(nd)
                    if nl > 1e-6 then
                        dir = nd / nl
                    end
                end
            end
            if flow and g.bend_step and parent and parent.group == b.group and parent.bend_x then
                -- snake-like chains: the bend of a joint (rotation from its goal direction, as axis * angle)
                -- may differ from the bend of the joint before it by at most bend_step, so the curvature
                -- changes gradually along the chain instead of kinking from one bone to the next
                local bax = Vector3.cross(goal_dir, dir)
                local bal = Vector3.length(bax)
                local bang = math.acos(math.max(-1, math.min(1, Vector3.dot(goal_dir, dir))))
                local bend = bal > 1e-6 and bax / bal * bang or Vector3(0, 0, 0)
                local parent_bend = Vector3(parent.bend_x, parent.bend_y, parent.bend_z)
                local diff = bend - parent_bend
                local dl2 = Vector3.length(diff)
                local step = math.rad(g.bend_step) * amount * JIGGLE.limit
                if dl2 > step then
                    bend = parent_bend + diff * (step / dl2)
                    local bl = Vector3.length(bend)
                    if bl > max_angle then
                        bend, bl = bend * (max_angle / bl), max_angle
                    end
                    dir = bl > 1e-6 and Quaternion.rotate(Quaternion.axis_angle(bend / bl, bl), goal_dir) or goal_dir
                end
            end
            if g.bend_step then
                -- this joint's final bend, for the next bone of the chain (this frame only)
                local bax = Vector3.cross(goal_dir, dir)
                local bal = Vector3.length(bax)
                if bal > 1e-6 then
                    local bend = bax / bal * math.acos(math.max(-1, math.min(1, Vector3.dot(goal_dir, dir))))
                    b.bend_x, b.bend_y, b.bend_z = bend.x, bend.y, bend.z
                else
                    b.bend_x, b.bend_y, b.bend_z = 0, 0, 0
                end
            end
            -- turn the bone from its rest direction to that direction
            axis = Vector3.cross(rest_dir, dir)
            al = Vector3.length(axis)
            angle = math.acos(math.max(-1, math.min(1, Vector3.dot(rest_dir, dir))))
            if al > 1e-6 and angle > 1e-5 then
                world_rot = Quaternion.multiply(Quaternion.axis_angle(axis / al, angle), rest_rot)
            elseif angle < 1 then
                dir = rest_dir
            end
            nxt = head + dir * length
            local sp, sn = p - origin, nxt - origin
            b.qx, b.qy, b.qz = sp.x, sp.y, sp.z
            b.px, b.py, b.pz = sn.x, sn.y, sn.z
        end
        Unit.set_local_rotation(unit, b.node, Quaternion.multiply(Quaternion.inverse(parent_rot), world_rot))
        -- kept for this bone's children, this frame only
        b.rot, b.head, b.scale, b.rigid = world_rot, head, scale, rigid_rot
    end
end


-- Attack retiming --------------------------------------------------------------------------------
-- Warframe swings run on Warframe's timing; Darktide hits on its own. Each attack clip is cut at its own damage window
-- (CLIPS[clip].hit) into windup / hit / recovery, and each part is played at the rate that lands it on the Darktide
-- action's: damage_window_start, damage_window_end, then the start_attack chain_time (when the next swing can begin),
-- all in action time divided by weapon_action.time_scale (action_handler.lua:301-307: start_t, time_scale). A windup's
-- charge clip reaches its wound-up pose at the heavy_attack chain_time. Rates are worked out at each part boundary from
-- the time actually left, so a late start (the 3-frame swap) or a clamped rate is made up in the next part.
local WARP_MIN, WARP_MAX = 0.33, 3

local function game_time()
    local tm = Managers.time
    if not tm then
        return nil
    end
    local ok, t = pcall(tm.time, tm, "gameplay")
    return ok and t or nil
end

local function warp_rate(w, now)
    local left = w.targets[w.i] - (now - w.start_t)
    return math.max(WARP_MIN, math.min(WARP_MAX, (w.bounds[w.i] - w.ct) / math.max(left, 0.03)))
end

-- returns the rate to play `clip` at from clip time ct, or nil when the clip / action has no timing to fit
local function start_warp(data, clip, ct)
    data.warp = nil
    local info, timing, now = CLIPS[clip], data.timing, game_time()
    local def = timing and timing.def
    if not (info and info.dur and def and now) then
        return nil
    end
    local scale = (timing.time_scale and timing.time_scale > 0) and timing.time_scale or 1
    local chains = def.allowed_chain_actions or {}
    local w
    if info.hit and def.damage_window_start and def.damage_window_end then
        local d0, d1 = def.damage_window_start / scale, def.damage_window_end / scale
        local nxt = (chains.start_attack and chains.start_attack.chain_time) or def.total_time or 1
        w = { bounds = { info.hit[1] * info.dur, info.hit[2] * info.dur, info.dur }, targets = { d0, d1, math.max(nxt / scale, d1 + 0.05) } }
    elseif def.kind == "windup" and chains.heavy_attack and chains.heavy_attack.chain_time then
        w = { bounds = { info.dur }, targets = { chains.heavy_attack.chain_time / scale } }
    else
        return nil
    end
    w.start_t, w.ct, w.i, w.clip = timing.start_t, ct or 0, 1, clip
    while w.i < #w.bounds and w.ct >= w.bounds[w.i] do
        w.i = w.i + 1
    end
    w.rate = warp_rate(w, now)
    data.warp = w
    return w.rate
end

local function advance_warp(data, dt)
    local w = data.warp
    if not w or w.done then
        return
    end
    if w.clip ~= data.clip then
        data.warp = nil
        return
    end
    w.ct = w.ct + dt * w.rate
    if w.ct < w.bounds[w.i] then
        return
    end
    if w.i >= #w.bounds then
        w.done = true -- not looping: the clip holds its last frame
        return
    end
    w.i = w.i + 1
    local now = game_time()
    local driver = data.pending and data.pending.driver or data.driver
    if now and unit_ok(driver) then
        w.rate = warp_rate(w, now)
        data.rate = w.rate
        Unit.play_simple_animation(driver, w.ct, nil, false, w.rate)
    end
end

-- Clip switching ---------------------------------------------------------------------------------
local function step(ext, dt)
    local data = rawget(ext, "__qiangiq_wf")
    if data and data.pending and unit_ok(ext._unit) then
        data.pending.frames = data.pending.frames + 1
        if data.pending.frames >= SWAP_FRAMES then
            finish_swap(ext, data)
        end
    end
    if data then
        data.clock = (data.clock or 0) + dt
        advance_warp(data, dt)
    end
    if data and not data.first_person and unit_ok(ext._unit) then
        apply_reactive_glow(ext, data, dt)
        if unit_ok(data.model) then
            jiggle_update(data.model, dt)
        end
    end
    if data and unit_ok(data.model) and unit_ok(ext._unit) and unit_ok(data.driver) and not data.pending then
        data.since = (data.since or 0) + dt
        if opt("wf_animations") ~= false and not data.first_person then
            local speed, state = read_motion(ext._unit)
            local clip = pick_clip(ext._unit, data, speed, state)
            if not ready["ember_wf_" .. clip] then
                clip = locomotion("", speed, false, state == "sprinting")
            end
            local rate = wanted_rate(clip, speed)
            local now, want = CLIPS[data.clip] or {}, CLIPS[clip]
            local plain = function(name)
                return CLIPS[name] and CLIPS[name].speed ~= nil or name == "idle" or string.find(name or "", "_idle$") or string.find(name or "", "crouch$")
            end
            local warped = data.warp and data.warp.clip == data.clip
            local playing_once
            if warped then
                playing_once = not data.warp.done
            else
                playing_once = now.once and data.since < (now.dur or 0) / (data.rate or 1)
            end
            -- an attack that ended with her standing still recovers to idle through the Sword's SlashToIdle clip
            if plain(clip) and speed < 0.4 and now.hit and not playing_once and ready["ember_wf_s_recover"] then
                clip, want, rate = "s_recover", CLIPS.s_recover, 1
            end
            local timed = data.timing and (want.hit or clip == "d_charge" or clip == "d_charge_slash")
            local new_action = timed and not (data.warp and data.warp.start_t == data.timing.start_t)
            if clip ~= data.clip then
                -- a one-shot (swing, reload, dodge, throw...) finishes before plain movement takes over again;
                -- plain movement keeps MIN_DWELL between switches, actions switch at once
                local hold = playing_once and plain(clip)
                local dwell = (plain(clip) and plain(data.clip)) and MIN_DWELL or 0.05
                if not hold and data.since >= dwell then
                    play_clip(ext, data, clip, timed and start_warp(data, clip, 0) or rate)
                end
            elseif new_action and data.warp then
                -- the same swing clip for the next attack: start it over on the new attack's timing
                play_clip(ext, data, clip, start_warp(data, clip, 0) or rate)
            elseif new_action then
                -- the swing clip already running from the windup: retime it from where it is now
                local ct = math.min(data.since * (data.rate or 1), (want.dur or 0))
                local r = start_warp(data, clip, ct)
                if r then
                    data.rate = r
                    Unit.play_simple_animation(data.pending and data.pending.driver or data.driver, ct, nil, false, r)
                end
            elseif want.once and not playing_once and not warped then
                play_clip(ext, data, clip, rate) -- same one-shot asked again (another dodge the same way, a second throw)
            elseif want.speed and data.since >= 0.6 and math.abs(rate - data.rate) > RESTART_RATIO * data.rate then
                play_clip(ext, data, clip, rate)
            end
        end
    end
end

mod.update = function(dt)
    dt = dt or 0
    for ext in pairs(tracked) do
        -- a destroyed extension (level ended, character left) raises on any field read: forget it
        local ok = pcall(step, ext, dt)
        if not ok then
            tracked[ext] = nil
        end
    end
    -- only one QIangIQ character model at a time: another one switched on turns this one off
    mod.__check_t = (mod.__check_t or 0) + dt
    if mod.__check_t > 1 then
        mod.__check_t = 0
        if model_on() then
            for _, name in ipairs(CHARACTER_MODS) do
                local other = get_mod(name)
                if other and other:get("model_enabled") == true then
                    mod:set("model_enabled", false, true)
                    break
                end
            end
        end
    end
end

-- Menu previews (operative select, inventory, lobby) --------------------------------------------------
-- Ported from QIangIQsEmber.lua ui_apply. The preview character unit gets the idle driver (linked to it, playing the
-- idle clip) and the model linked to that driver by node name, the same pair as in the world.
local tracked_ui = setmetatable({}, { __mode = "k" })

local function ui_profile_is_mine(profile)
    -- __qiangiq_npc: the companion NPC spawned by QIangIQsCompanionSwap is nobody's character
    if not profile or profile.__qiangiq_npc then
        return false
    end
    local players = Managers.player and Managers.player:players()
    local me = Managers.player and Managers.player:local_player_safe(1)
    if players and profile.character_id then
        for _, player in pairs(players) do
            if player ~= me and player.character_id and player:character_id() == profile.character_id then
                return false
            end
        end
    end
    return true
end

local function ui_despawn(spawner)
    local model, driver = rawget(spawner, "__qiangiq_wf_model"), rawget(spawner, "__qiangiq_wf_driver")
    rawset(spawner, "__qiangiq_wf_model", nil)
    rawset(spawner, "__qiangiq_wf_driver", nil)
    rawset(spawner, "__qiangiq_wf_parent", nil)
    local world = spawner._world
    -- children first: a unit with units still linked to it cannot be destroyed cleanly
    if unit_ok(model) and world then
        World.unlink_unit(world, model)
        World.destroy_unit(world, model)
    end
    if unit_ok(driver) and world then
        World.unlink_unit(world, driver)
        World.destroy_unit(world, driver)
    end
end

local function ui_apply(spawner)
    local data = spawner._character_spawn_data
    if not data or not unit_ok(data.unit_3p) then
        return
    end
    local archetype = data.profile and data.profile.archetype
    local excluded = archetype and EXCLUDED_BREEDS[archetype.breed]
    if excluded or not (model_on() and opt("menu_previews") ~= false and assets_ready() and ui_profile_is_mine(data.profile)) then
        if rawget(spawner, "__qiangiq_wf_model") then
            ui_despawn(spawner)
            if spawner._visible then
                spawner:_update_items_visibility()
            end
        end
        return
    end
    if rawget(spawner, "__qiangiq_wf_parent") ~= data.unit_3p then
        ui_despawn(spawner)
    end
    local model = rawget(spawner, "__qiangiq_wf_model")
    if not unit_ok(model) then
        local world = spawner._world
        local pose = Unit.world_pose(data.unit_3p, 1)
        local driver = World.spawn_unit_ex(world, unit_name("ember_wf_idle"), nil, pose)
        model = World.spawn_unit_ex(world, unit_name(MODEL), nil, pose)
        World.link_unit(world, driver, 1, data.unit_3p, 1)
        World.link_unit(world, model, 1, driver, 1, World.LINK_MODE_NODE_NAME)
        Unit.play_simple_animation(driver, 0, nil, true, 1)
        rawset(spawner, "__qiangiq_wf_model", model)
        rawset(spawner, "__qiangiq_wf_driver", driver)
        rawset(spawner, "__qiangiq_wf_parent", data.unit_3p)
        tracked_ui[spawner] = true
    end
    apply_glow(model)
    Unit.set_unit_visibility(model, spawner._visible and true or false, true)
    if spawner._visible and opt("hide_body") ~= false then
        hide_body_slots(data.slots)
    end
end

mod:hook_safe(CLASS.UIProfileSpawner, "_update_items_visibility", function(self)
    pcall(ui_apply, self)
end)

-- UIProfileSpawner.update = function (self, dt, t, input_service)
mod:hook_safe(CLASS.UIProfileSpawner, "update", function(self, dt)
    local data = self._character_spawn_data
    if data and data.is_ready then
        pcall(ui_apply, self)
    end
end)

mod:hook(CLASS.UIProfileSpawner, "_despawn_current_character_profile", function(func, self, ...)
    pcall(ui_despawn, self)
    return func(self, ...)
end)

-- Assets ---------------------------------------------------------------------------------------
local function acquire(name)
    local id = "QIangIQsEmberWF:" .. name
    local ticket, err = custom_assets.acquire(mod, id, function(_, _, load_error)
        if load_error then
            mod:error("%s failed to load: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", id, tostring(load_error))
            return
        end
        ready[name] = true
        refresh_all()
    end, { resident = true, reference_name = id })
    if not ticket then
        mod:error("%s could not be requested: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", id, tostring(err))
    end
end

-- The fire core and the trim glow use the retail emissive parent #ID[e04dba68a38d1429] (build.json external_resources),
-- which only exists while a retail package holding it is loaded; without it emissives render magenta (same fix as
-- QIangIQsEmber.lua load_emissive_parent; package from ResourceLoader's catalog material_005.lua, packages[593]).
local EMISSIVE_PARENT_PACKAGE = "content/weapons/player/ranged/bolt_pistol/attachments/sight_01/sight_01"

local function load_emissive_parent()
    local packages = Managers.package
    if packages and not packages:has_loaded(EMISSIVE_PARENT_PACKAGE) then
        packages:load(EMISSIVE_PARENT_PACKAGE, "QIangIQsEmberWF_emissive_parent", function()
            mod:info("emissive parent package loaded")
        end)
    end
end

mod.on_all_mods_loaded = function()
    pcall(load_emissive_parent)
    jiggle_read_settings()
    custom_assets = get_mod("CustomAssets")
    if not custom_assets or not custom_assets.is_api_compatible or not custom_assets.is_api_compatible(1) then
        mod:error("Custom Assets (API 1) is missing. Install it and put it above QIangIQsEmberWF in mod_load_order.txt.")
        return
    end
    acquire(MODEL)
    for clip in pairs(CLIPS) do
        acquire("ember_wf_" .. clip)
    end
end

local function switch_others_off()
    for _, name in ipairs(CHARACTER_MODS) do
        local other = get_mod(name)
        if other and other:get("model_enabled") ~= false then
            other:set("model_enabled", false, true)
        end
    end
end

mod.toggle_model = function()
    local on = not model_on()
    mod:set("model_enabled", on, true)
    mod:echo("Warframe Ember model %s", on and "on" or "off")
end

mod:command("emberwf", "Toggle the Warframe 1:1 Ember Heirloom model on your character", function()
    mod.toggle_model()
end)

mod.on_setting_changed = function(setting_id)
    if setting_id == "model_enabled" and model_on() then
        switch_others_off()
    end
    jiggle_read_settings()
    refresh_all()
end

mod.on_disabled = function()
    for spawner in pairs(tracked_ui) do
        pcall(ui_despawn, spawner)
    end
    for ext in pairs(tracked) do
        pcall(despawn, ext)
        if unit_ok(ext._unit) and ext.force_update_item_visibility then
            ext:force_update_item_visibility()
        end
    end
end

mod.on_enabled = function()
    refresh_all()
end

mod.on_unload = function()
    for spawner in pairs(tracked_ui) do
        pcall(ui_despawn, spawner)
    end
    for ext in pairs(tracked) do
        pcall(despawn, ext)
    end
    if custom_assets and custom_assets.release_owner then
        custom_assets.release_owner(mod)
    end
end
