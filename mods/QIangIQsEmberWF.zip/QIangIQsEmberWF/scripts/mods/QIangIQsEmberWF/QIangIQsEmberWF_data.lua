local mod = get_mod("QIangIQsEmberWF")

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = true,
    options = {
        widgets = {
            {
                setting_id = "model_enabled",
                type = "checkbox",
                default_value = false,
            },
            {
                setting_id = "hide_body",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "wf_animations",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "movement_style",
                type = "dropdown",
                default_value = "titania",
                options = {
                    { text = "movement_style_titania", value = "titania" },
                    { text = "movement_style_wisp", value = "wisp" },
                    { text = "movement_style_shared", value = "shared" },
                },
            },
            {
                setting_id = "jiggle",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "anim_speed_match",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "menu_previews",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "glow_level",
                type = "numeric",
                default_value = 23,
                range = { 0, 100 },
                decimals_number = 0,
            },
            {
                setting_id = "glow_reactive_group",
                type = "group",
                sub_widgets = {
                    {
                        setting_id = "glow_reactive",
                        type = "checkbox",
                        default_value = true,
                    },
                    {
                        setting_id = "glow_reactive_peak",
                        type = "numeric",
                        default_value = 100,
                        range = { 0, 100 },
                        decimals_number = 0,
                    },
                },
            },
            {
                setting_id = "glow_color_group",
                type = "group",
                sub_widgets = {
                    {
                        setting_id = "glow_color_custom",
                        type = "checkbox",
                        default_value = false,
                    },
                    {
                        setting_id = "glow_color_r",
                        type = "numeric",
                        default_value = 1,
                        range = { 0, 1 },
                        decimals_number = 2,
                    },
                    {
                        setting_id = "glow_color_g",
                        type = "numeric",
                        default_value = 1,
                        range = { 0, 1 },
                        decimals_number = 2,
                    },
                    {
                        setting_id = "glow_color_b",
                        type = "numeric",
                        default_value = 1,
                        range = { 0, 1 },
                        decimals_number = 2,
                    },
                },
            },
            {
                setting_id = "toggle_keybind",
                type = "keybind",
                default_value = {},
                keybind_trigger = "pressed",
                keybind_type = "function_call",
                function_name = "toggle_model",
            },
        },
    },
}
