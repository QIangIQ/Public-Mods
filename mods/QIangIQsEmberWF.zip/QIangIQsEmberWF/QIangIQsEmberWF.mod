return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsEmberWF` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsEmberWF", {
            mod_script = "QIangIQsEmberWF/scripts/mods/QIangIQsEmberWF/QIangIQsEmberWF",
            mod_data = "QIangIQsEmberWF/scripts/mods/QIangIQsEmberWF/QIangIQsEmberWF_data",
            mod_localization = "QIangIQsEmberWF/scripts/mods/QIangIQsEmberWF/QIangIQsEmberWF_localization",
        })
    end,
    version = "0.1.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
