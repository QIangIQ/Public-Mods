return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsScumHook` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsScumHook", {
			mod_script       = "QIangIQsScumHook/scripts/mods/QIangIQsScumHook/QIangIQsScumHook",
			mod_data         = "QIangIQsScumHook/scripts/mods/QIangIQsScumHook/QIangIQsScumHook_data",
			mod_localization = "QIangIQsScumHook/scripts/mods/QIangIQsScumHook/QIangIQsScumHook_localization",
		})
	end,
	version = "1.0.1",
	packages = {},
}
