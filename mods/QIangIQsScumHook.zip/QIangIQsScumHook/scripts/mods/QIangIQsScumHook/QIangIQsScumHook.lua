local mod = get_mod("QIangIQsScumHook")

-- Chain Hook: a Hive Scum combat ability for the legacy (1.10.0) Hive Scum
-- tree from QIangIQsLegacyTalents.
--
-- Press the ability: the melee weapon stays in the right hand and the left
-- hand comes up holding the hook, in the Hive Scum's own left handed quick
-- throw (first person left arm only; see "The left arm").
-- While the key is held the hook stays in the hand and the enemy it would
-- catch is outlined. Let go (or just tap) and the hook flies HOOK_RANGE
-- metres along the aim at HOOK_SPEED (stopping early at a wall). Every enemy
-- it passes that is not a boss or an Ogryn is caught and stunned, until the
-- hook is full. It then snaps back at RETURN_SPEED, dragging them, and drops
-- them in a row right in front of the player with a heavy stagger. Pressing
-- the ability again while the hook is flying out reels it in early with
-- whatever it holds; that press costs no charge.
--
-- The node only goes into the legacy nodes table, so it exists only while
-- QIangIQsLegacyTalents runs legacy data (Realms, SoloPlay, Psykhanium). On
-- Fatshark's mission servers the official tree is used and nothing here runs.
--
-- The pull itself runs on the server, in the ability buff's update. Enemies
-- are moved with MinionLocomotionExtension.teleport_to, the call the Beast of
-- Nurgle uses to carry a minion (chaos_beast_of_nurgle_consume_minion.lua),
-- and stunned with Stagger.force_stagger, as the Mortis pull buffs do
-- (hordes_buffs_utilities.lua pull_enemies_towards_target_unit). The held key
-- is read with input_extension:get("combat_ability_hold"), the way
-- interactor_extension.lua reads "interact_hold"; combat_ability_hold is one
-- of the inputs sent to the server (input_handler_settings.lua actions).

local ArchetypeTalents = require("scripts/settings/ability/archetype_talents/archetype_talents")
local BuffSettings = require("scripts/settings/buff/buff_settings")
local BuffTemplates = require("scripts/settings/buff/buff_templates")
local EffectTemplates = require("scripts/settings/fx/effect_templates")
local PlayerAbilities = require("scripts/settings/ability/player_abilities/player_abilities")
local Stagger = require("scripts/utilities/attack/stagger")
local StaggerSettings = require("scripts/settings/damage/stagger_settings")

local stagger_types = StaggerSettings.stagger_types
local stat_buffs = BuffSettings.stat_buffs

local HOOK_RANGE = 30
local HOOK_SPEED = 10
-- Once the hook is full (or at full range, or at a wall, or reeled in) it
-- snaps back fast, like Roadhog's: 30 m comes back in under a second.
local RETURN_SPEED = 40
-- Fast Hook augment: both speeds doubled.
local FAST_MULTIPLIER = 2
-- Enemies one hook can hold. The Gang Hook augment adds AUGMENT_EXTRA_TARGETS.
local BASE_MAX_TARGETS = 1
local AUGMENT_EXTRA_TARGETS = 2
-- How close to the hook's path an enemy has to be to get caught.
local CATCH_RADIUS = 1.5
-- Where caught enemies land: this far in front of the player, side by side.
local LAND_DISTANCE = 1.5
local LAND_SPACING = 0.9
-- 1.10.0 talent_settings_broker.lua: combat_ability.punk_rage.cooldown.
local COOLDOWN = 30
local MAX_CHARGES = 2
-- Spare Hooks augment: 2 more charges (4 in all), through the stat buff the
-- game's own extra charge talents use (veteran_combat_ability_extra_charge).
local AUGMENT_EXTRA_CHARGES = 2
-- The longest the hook can be held in the hand before it is thrown anyway.
local AIM_MAX_TIME = 10
-- Safety net: the hook always ends after this long.
local HOOK_MAX_TIME = AIM_MAX_TIME + HOOK_RANGE / HOOK_SPEED + HOOK_RANGE / RETURN_SPEED + 5
-- A reel press is buffered by Rampage's template (broker_punk_rage.lua
-- buffer_time 0.5) and can start the ability just after the hook is back.
-- Presses this soon after a hook ends are treated as reel presses too.
local REEL_GRACE = 0.6
-- Grapple augment: a rope to the big enemy, Pathfinder style. The player is
-- popped into the air (the jumping state) and keeps the normal in-air
-- movement, so they can strafe, while the rope pulls them towards the
-- enemy's chest (pull, m/s^2) and is reeled in (reel, m/s) down to
-- min_rope; at full length it only lets them swing around the enemy, and it
-- follows the enemy as it moves. It lasts up to tether_time seconds; jump
-- or press the ability again to let go. Speeds are capped at max_speed.
local GRAPPLE = {
	pull = 30,
	reel = 12,
	min_rope = 3.5,
	max_speed = 22,
	tether_time = 8,
	-- On the ground with the rope this much longer than min_rope: popped
	-- back into the air.
	lift_slack = 1,
}
-- Mod settings that override GRAPPLE (same units): reel and pull speeds, the
-- speed cap, gravity on the rope in percent of the game's 11.82 m/s², and the
-- height of the hop when jumping off the rope (0: no hop; the game's own jump
-- is 0.68 m, jump_speed 4).
GRAPPLE.gravity = 100
GRAPPLE.jump_height = 0
GRAPPLE.setting_ids = {
	reel = "grapple_reel_speed",
	pull = "grapple_pull",
	max_speed = "grapple_max_speed",
	gravity = "grapple_gravity",
	jump_height = "grapple_jump_height",
}

local function _grapple(key)
	local value = mod:get(GRAPPLE.setting_ids[key])

	return type(value) == "number" and value or GRAPPLE[key]
end
-- Tough Haul augment: toughness per enemy caught.
local TOUGHNESS_PER_ENEMY = 20
-- Used when a player's eye height cannot be read.
local DEFAULT_EYE_HEIGHT = 1.6

-- Landing stagger: the heaviest type (stagger_settings.lua
-- stagger_impact_comparison: explosion = 4) with the duration and immune
-- time hordes_legendary_generic_buff_templates.lua uses (4, _, 4). The
-- length is cut so the stagger does not carry them away from the player.
local LAND_STAGGER_TYPE = stagger_types.explosion
local LAND_STAGGER_DURATION = 4
local LAND_STAGGER_LENGTH = 0.2
-- While hooked: the heavy stagger the Mortis sticky grenade pull uses
-- (hordes_legendary_veteran_buff_templates.lua), lasting until they land.
local HOOKED_STAGGER_TYPE = stagger_types.heavy

local TALENT_NAME = "qiangiq_broker_chain_hook"
local ABILITY_NAME = "qiangiq_broker_chain_hook"
local BUFF_NAME = "qiangiq_broker_chain_hook"
local EFFECT_TEMPLATE_NAME = "qiangiq_broker_chain_hook_chain"
local NODE_NAME = "node_qiangiq_broker_chain_hook"
local LOC_NAME = "loc_qiangiq_broker_chain_hook"
local LOC_DESCRIPTION = "loc_qiangiq_broker_chain_hook_description"

-- The hand thrust: psyker_shout.lua, adamant_shout.lua and the cryptic
-- templates play "ability_shout"; it is in every human first person weapon
-- state machine, and psyker_shout plays it on the third person body too.
local THROW_ANIM = "ability_shout"

-- Augments: ability_modifier nodes under Chain Hook, fields as the 1.10.0
-- Rampage modifiers. Each talent's passive adds a buff the hook checks for,
-- as the Deflect augments do. Icons are Hive Scum talent textures. Gang Hook
-- keeps the names it shipped with, so saved builds keep it. Places: three
-- in a row above Chain Hook and two below it, each joined to it by a short
-- line, all left of the (moved) tree.
local ICON_PATH = "content/ui/textures/icons/talents/broker/"
local AUGMENTS = {
	{
		key = "extra_targets",
		talent = "qiangiq_broker_chain_hook_extra_targets",
		node = "node_qiangiq_broker_chain_hook_extra_targets",
		icon = ICON_PATH .. "broker_melee_cleave_on_melee_kill",
		x = 520,
		y = 1620,
		format_values = {
			extra_targets = AUGMENT_EXTRA_TARGETS,
		},
	},
	{
		key = "fast",
		talent = "qiangiq_broker_chain_hook_fast",
		node = "node_qiangiq_broker_chain_hook_fast",
		icon = ICON_PATH .. "broker_stamina_grants_atk_speed",
		x = 640,
		y = 1620,
		format_values = {
			speed = HOOK_SPEED * FAST_MULTIPLIER,
			return_speed = RETURN_SPEED * FAST_MULTIPLIER,
		},
	},
	{
		key = "charges",
		talent = "qiangiq_broker_chain_hook_charges",
		node = "node_qiangiq_broker_chain_hook_charges",
		icon = ICON_PATH .. "broker_increased_blitz_ammo",
		x = 760,
		y = 1620,
		stat_buffs = {
			[stat_buffs.ability_extra_charges] = AUGMENT_EXTRA_CHARGES,
		},
		format_values = {
			charges = MAX_CHARGES + AUGMENT_EXTRA_CHARGES,
		},
	},
	{
		key = "grapple",
		talent = "qiangiq_broker_chain_hook_grapple",
		node = "node_qiangiq_broker_chain_hook_grapple",
		icon = ICON_PATH .. "broker_damage_vs_elites_monsters",
		x = 530,
		y = 1920,
		format_values = {
			reel_speed = _grapple("reel"),
			tether_time = GRAPPLE.tether_time,
		},
	},
	{
		key = "toughness",
		talent = "qiangiq_broker_chain_hook_toughness",
		node = "node_qiangiq_broker_chain_hook_toughness",
		icon = ICON_PATH .. "broker_passive_restore_toughness_on_close_ranged_kill",
		x = 650,
		y = 1920,
		format_values = {
			toughness = TOUGHNESS_PER_ENEMY,
		},
	},
}
local AUGMENT_BY_KEY = {}

for _, augment in ipairs(AUGMENTS) do
	augment.loc_name = "loc_" .. augment.talent
	augment.loc_description = "loc_" .. augment.talent .. "_description"
	AUGMENT_BY_KEY[augment.key] = augment
end

-- Rampage's ability template (broker_punk_rage.lua): an instant stance_change
-- that adds ability_template_tweak_data.buff_to_add and wields the melee
-- weapon. A new ability template cannot be added after load, because
-- player_unit_data_component_config.lua builds a network lookup of the
-- template names when the game starts.
local ABILITY_TEMPLATE = "broker_punk_rage"
-- The hook item and its weapon template (see "The hook item").
local WEAPON_TEMPLATE_NAME = "qiangiq_chain_hook"
local ITEM_NAME = "content/items/weapons/player/qiangiq_chain_hook"

local LAYOUT_PATH = "scripts/ui/views/talent_builder_view/layouts/broker_tree"

-- 1.10.0 broker_tree.lua. Every 1.10.0 Hive Scum node is at x 515 or more,
-- just clear of the overview panel on the left of the talent view, so the
-- whole tree is moved right by TREE.shift_x to make room for Chain Hook and
-- its augments at its left edge, level with the abilities. The tree is then
-- wider than the screen, so the background can also be dragged left and
-- right (see "Dragging the tree sideways"). Chain Hook is reached from the
-- stimm duration node above Desperado, the way Desperado is.
local PARENT_NODES = {
	"node_9e73b9a9-bd27-46c2-b75d-1972b411c6b8",
}
-- The way on to the keystones, as Desperado leads on to the row below it:
-- the crit node (x 664, y 1924 before the move), which links to the melee
-- damage node and from there to the whole tree. A straight line to the melee
-- damage node itself would cross Desperado or Rampage; the extended mag node
-- only led to Vulture's Mark. Chain Hook sits far enough left of Desperado
-- that the line to the crit node passes under Desperado's augments; neither
-- of its lines crosses another node or line.
local CHILD_NODES = {
	"node_089c4280-425c-40cd-8ec6-0aa812fe11ff",
}
-- shift_x: how far the 1.10.0 nodes move right. pan_left/pan_right: how far
-- the tree can be dragged left/right of where the view puts it.
local TREE = {
	shift_x = 380,
	pan_left = 700,
	pan_right = 500,
	-- Chain Hook's own place.
	node_x = 520,
	node_y = 1750,
}
-- 1.10.0 broker_tree.lua: the exclusive group of the Hive Scum abilities.
local EXCLUSIVE_GROUP = "ability_1"

-- Textures the current game already draws for the Hive Scum. Talent textures
-- work as HUD ability icons (holier_revenant uses zealot_2_base_2).
local NODE_ICON = "content/ui/textures/icons/talents/broker/broker_knockback_push"
local ABILITY_HUD_ICON = NODE_ICON
local ABILITY_ICON = "content/ui/materials/icons/abilities/ultimate/default"

-- Mortis sounds (hordes_buffs_utilities.lua SFX_NAMES). Strings starting with
-- "wwise/events/player/" in the talent are loaded for the archetype
-- (archetype_resource_dependencies.lua).
local SOUND_THROW = "wwise/events/player/play_horde_mode_buff_gravitation"
local SOUND_CATCH = "wwise/events/player/play_horde_mode_buff_stagger_hit"
local SOUND_LAND = "wwise/events/player/play_horde_mode_buff_stagger_pulse"

-- The chain: the game's spiked hanging chain
-- (content/environment/artsets/imperial/global/props/chains/), the same
-- iron chain and spike atlas hung in the Psykhanium arena. hanging_chains_long_04
-- is a straight chain hanging down -Z from its root: links from 0 to -6.02 m
-- (mesh 1) and a spear head from -5.94 to -6.51 m (mesh 2), measured on the
-- unit in the bundle. The unit has no package of its own; the smallest package
-- that holds it is the Cooling toxic gas theme (about 40 units), loaded the
-- way expedition_spawner.lua loads theme packages. Segments are laid from the
-- hook head back to the player; only the first keeps its spear head.
local CHAIN_UNIT = "content/environment/artsets/imperial/global/props/chains/hanging_chains_long_04"
local CHAIN_PACKAGE = "content/levels/tank_foundry/missions/lm_cooling_themes/toxic_gas_01/theme_toxic_gas_01_lm_cooling"
local CHAIN_SEGMENT_LENGTH = 6.02
local CHAIN_TIP_LENGTH = 6.51
local CHAIN_SPEAR_MESH = 2
local CHAIN_MIN_SCALE = 0.1

-- Fallback until the package is loaded: armour sparks
-- (player_character_particle_names.lua) at the hook head and every
-- CHAIN_LINK_SPACING metres back to the player.
local CHAIN_PARTICLE = "content/fx/particles/impacts/armor_penetrate"
local CHAIN_LINK_SPACING = 1.5
local CHAIN_REDRAW_INTERVAL = 0.1

-- The hook head: the user's Roadhog hook model, compiled with
-- DarktideGLBCompiler into mods/QIangIQsScumHook/Custom/hook_head and loaded
-- through Custom Assets (as QIangIQsShardStaff loads its models). Its root is
-- the chain end of the handle and the blade runs HOOK_HEAD_LENGTH metres
-- down -Z, the same way the chain hangs. Without Custom Assets the chain
-- keeps its own spear head instead.
local HOOK_HEAD_ASSET = "QIangIQsScumHook:hook_head"
local HOOK_HEAD_UNIT = "content/mods/qiangiq_scumhook/hook_head"
local HOOK_HEAD_LENGTH = 0.8

-- The chain leaves from the left hand: "j_lefthand" on the first person arms
-- in first person, on the body otherwise (the node fx templates attach to on
-- human rigs, ground_impact_fx_templates.lua). If a rig has no such node the
-- chain starts below and left of the eyes.
local LEFT_HAND_NODE = "j_lefthand"
local HAND_FALLBACK_LEFT = 0.25
local HAND_FALLBACK_DOWN = 0.35
local HAND_FALLBACK_FORWARD = 0.3

-- The outline the Veteran's Executioner's Stance puts on targets
-- (veteran_buff_templates.lua OUTLINE_NAME, outline_settings.lua).
local OUTLINE_NAME = "special_target"

local state = mod:persistent_table("chain_hook_state_v3", {
	registered = false,
	node_inserted = false,
	node_message = nil,
})
-- Legacy nodes already moved right by TREE.shift_x (weak keys).
state.shifted_nodes = state.shifted_nodes or setmetatable({}, {
	__mode = "k",
})

-- Enemies on a hook right now, so two hooks never fight over one enemy.
local hooked_units = mod:persistent_table("chain_hook_hooked_units", {})

-- The server's hook path per player. Where the server runs (host, Psykhanium,
-- SoloPlay) the chain is drawn from it, so it shows exactly where the hook
-- stopped. Other players' machines work the path out themselves and cannot
-- see where it filled up.
local active_paths = mod:persistent_table("chain_hook_active_paths", {})
-- Server: the hook (template data) each grappling player is tied to.
local grapple_tethers = mod:persistent_table("chain_hook_grapple_tethers", {})

if getmetatable(active_paths) == nil then
	setmetatable(active_paths, { __mode = "k" })
end

-- When each player's last hook ended (gameplay time), for REEL_GRACE.
local hook_ended_at = mod:persistent_table("chain_hook_ended_at", {})

if getmetatable(hook_ended_at) == nil then
	setmetatable(hook_ended_at, { __mode = "k" })
end

local hook_head = {
	ready = false,
}

-- ####################################################################
-- Who can be hooked
-- ####################################################################

-- Breed tags as in the breed files under settings/breed/breeds: bosses are
-- monster, captain, cultist_captain, lord and witch (daemonhosts); Ogryns are
-- tagged ogryn. Ritualists, companions and props are left alone by asking for
-- a fighting role tag.
local BIG_TAGS = {
	"monster",
	"captain",
	"cultist_captain",
	"lord",
	"witch",
	"ogryn",
}
local NEVER_TAGS = {
	"ritualist",
	"companion",
}
local ROLE_TAGS = {
	"horde",
	"roamer",
	"elite",
	"special",
}

local function _has_any(tags, list)
	for i = 1, #list do
		if tags[list[i]] then
			return true
		end
	end

	return false
end

local function _can_hook_breed(breed)
	local tags = breed and breed.tags

	if not tags or not tags.minion then
		return false
	end

	if _has_any(tags, BIG_TAGS) or _has_any(tags, NEVER_TAGS) then
		return false
	end

	return _has_any(tags, ROLE_TAGS)
end

-- Bosses and Ogryns: what the Grapple augment latches onto.
local function _is_big_breed(breed)
	local tags = breed and breed.tags

	if not tags or not tags.minion then
		return false
	end

	return _has_any(tags, BIG_TAGS) and not _has_any(tags, NEVER_TAGS)
end

local function _breed(unit)
	local unit_data_extension = ScriptUnit.has_extension(unit, "unit_data_system")

	return unit_data_extension and unit_data_extension.breed and unit_data_extension:breed()
end

local function _has_buff(unit, buff_name)
	local buff_extension = ScriptUnit.has_extension(unit, "buff_system")

	if not buff_extension or not buff_extension.has_buff_using_buff_template then
		return false
	end

	local ok, has = pcall(buff_extension.has_buff_using_buff_template, buff_extension, buff_name)

	return ok and has and true or false
end

local function _has_augment(unit, key)
	return _has_buff(unit, AUGMENT_BY_KEY[key].talent)
end

-- ####################################################################
-- Hook path (shared by the server pull and the chain everyone sees)
-- ####################################################################

-- Eye position and aim, from the first_person component the way
-- force_sword_2h_p1_buff_templates.lua reads it. Other players' units fall
-- back to their body's facing.
local function _eye_and_aim(unit)
	local unit_data_extension = ScriptUnit.has_extension(unit, "unit_data_system")
	local ok, first_person = false, nil

	if unit_data_extension then
		ok, first_person = pcall(unit_data_extension.read_component, unit_data_extension, "first_person")
	end

	if ok and first_person and first_person.position and first_person.rotation then
		return first_person.position, Quaternion.forward(first_person.rotation)
	end

	local position = Unit.world_position(unit, 1)

	return position + Vector3(0, 0, DEFAULT_EYE_HEIGHT), Quaternion.forward(Unit.world_rotation(unit, 1))
end

local function _eye_height(unit, eye)
	-- Unit.world_position, not POSITION_LOOKUP: in game that read failed from
	-- outside the gameplay update ("Vector3 or Vector4 expected, got userdata").
	local feet = Unit.alive(unit) and Unit.world_position(unit, 1)

	return feet and math.max(eye.z - feet.z, 0.5) or DEFAULT_EYE_HEIGHT
end

-- Is the ability key held? The server reads the player's networked input,
-- the owner's machine its own; nobody else can know.
local function _hold(unit)
	local input_extension = ScriptUnit.has_extension(unit, "input_system")

	if not input_extension or not input_extension.get then
		return false
	end

	local ok, held = pcall(input_extension.get, input_extension, "combat_ability_hold")

	return ok and held and true or false
end

local function _is_local_owner(unit)
	local player_manager = Managers.player
	local player = player_manager and player_manager.local_player_safe and player_manager:local_player_safe(1)

	return player ~= nil and player.player_unit == unit
end

-- How far the hook can fly: HOOK_RANGE, or up to the first wall
-- (object_penetration.lua uses this filter for static geometry).
local function _reach(physics_world, from, direction)
	if not physics_world then
		return HOOK_RANGE
	end

	local hit, hit_position = PhysicsWorld.raycast(physics_world, from, direction, HOOK_RANGE, "closest", "types", "statics", "collision_filter", "filter_player_character_shooting_raycast_statics")

	if hit and hit_position then
		return math.max(Vector3.distance(from, hit_position) - 0.25, 0)
	end

	return HOOK_RANGE
end

-- path = { phase, start, direction, reach, distance, head, out_speed,
-- back_speed, aim_time, last_hold, reeled }. phase is "aim" (in the hand),
-- "out", "back" or "grapple" (latched onto a big enemy, server only).
local function _new_path(unit)
	local eye, direction = _eye_and_aim(unit)
	local speed_multiplier = _has_augment(unit, "fast") and FAST_MULTIPLIER or 1

	return {
		phase = "aim",
		start = Vector3Box(eye),
		direction = Vector3Box(direction),
		reach = HOOK_RANGE,
		distance = 0,
		head = Vector3Box(eye),
		out_speed = HOOK_SPEED * speed_multiplier,
		back_speed = RETURN_SPEED * speed_multiplier,
		aim_time = 0,
		last_hold = true,
		reeled = false,
	}
end

local function _throw(path, unit, physics_world)
	local eye, direction = _eye_and_aim(unit)

	path.start:store(eye)
	path.direction:store(direction)
	path.head:store(eye)
	path.reach = _reach(physics_world, eye, direction)
	path.distance = 0
	path.phase = "out"
end

-- Moves a flying hook one step. Returns true once the hook is back.
local function _advance(path, eye, dt)
	if path.phase == "out" then
		path.distance = math.min(path.distance + path.out_speed * dt, path.reach)
		path.head:store(path.start:unbox() + path.direction:unbox() * path.distance)

		if path.distance >= path.reach then
			path.phase = "back"
		end

		return false
	end

	local step = path.back_speed * dt
	local head = path.head:unbox()
	local to_eye = eye - head
	local remaining = Vector3.length(to_eye)

	if remaining <= LAND_DISTANCE + step then
		path.head:store(eye)

		return true
	end

	path.head:store(head + to_eye / remaining * step)

	return false
end

-- One update of a hook. Returns "thrown" when it leaves the hand, "reeled"
-- when a new press calls it back early, "back" when it is home.
local function _step(path, unit, hold, dt, physics_world)
	if path.phase == "aim" then
		path.aim_time = path.aim_time + dt

		if hold and path.aim_time < AIM_MAX_TIME then
			local eye, direction = _eye_and_aim(unit)

			path.start:store(eye)
			path.direction:store(direction)
			path.head:store(eye)

			return nil
		end

		_throw(path, unit, physics_world)

		path.last_hold = hold

		return "thrown"
	end

	local event

	if hold and not path.last_hold and path.phase == "out" and not path.reeled then
		path.reeled = true
		path.phase = "back"
		event = "reeled"
	end

	path.last_hold = hold

	if path.phase == "grapple" then
		return event
	end

	local eye = _eye_and_aim(unit)

	if _advance(path, eye, dt) then
		return "back"
	end

	return event
end

-- ####################################################################
-- Server: catching, dragging, landing, grappling
-- ####################################################################

local BROADPHASE_RESULTS = {}

local function _distance_to_segment(point, a, b)
	local ab = b - a
	local length_squared = Vector3.length_squared(ab)

	if length_squared == 0 then
		return Vector3.distance(point, a)
	end

	local t = math.clamp(Vector3.dot(point - a, ab) / length_squared, 0, 1)

	return Vector3.distance(point, a + ab * t)
end

local function _sound(event_name, position)
	local fx_system = Managers.state.extension:system("fx_system")

	if fx_system and position then
		fx_system:trigger_wwise_event(event_name, position)
	end
end

-- Tough Haul: toughness_extension recover_flat_toughness through
-- Toughness.replenish_flat. "ability_stance" is the reason Rampage's own
-- refill uses, and it is allowed through the no-toughness-regen effects
-- (player_unit_toughness_extension.lua COMBAT_ABILITIES_ALLOWED_RECOVERY_REASONS).
local function _reward(template_data)
	if template_data.toughness_per_enemy then
		local Toughness = require("scripts/utilities/toughness/toughness")

		Toughness.replenish_flat(template_data.player_unit, template_data.toughness_per_enemy, false, "ability_stance")
	end
end

local function _flat_direction(from, to)
	local direction = Vector3.flat(to - from)

	if Vector3.length_squared(direction) == 0 then
		return nil
	end

	return Vector3.normalize(direction)
end

-- Where the rope is tied: the enemy's chest.
local function _grapple_anchor(template_data)
	return Unit.world_position(template_data.grapple_target, 1) + Vector3(0, 0, template_data.eye_height * 0.6)
end

-- Grapple: tie the player to the big enemy. The pull itself runs in the
-- player's in-air character states (see "Grapple rope").
local function _start_grapple(template_data, enemy_unit)
	local player_unit = template_data.player_unit
	local to = POSITION_LOOKUP[enemy_unit]

	hooked_units[enemy_unit] = player_unit
	template_data.grapple_target = enemy_unit
	template_data.grapple_time = 0
	template_data.let_go = false
	template_data.path.phase = "grapple"
	template_data.path.last_hold = _hold(player_unit)
	template_data.rope = Vector3.distance(_grapple_anchor(template_data), POSITION_LOOKUP[player_unit])
	grapple_tethers[player_unit] = template_data

	_sound(SOUND_CATCH, to)
	_reward(template_data)
end

local function _catch(template_data, from, to)
	local broadphase = template_data.broadphase
	local player_unit = template_data.player_unit
	local middle = (from + to) * 0.5
	local radius = CATCH_RADIUS + Vector3.distance(from, to) * 0.5
	local num_hits = broadphase.query(broadphase, middle, radius, BROADPHASE_RESULTS, template_data.enemy_side_names)
	local hooked = template_data.hooked
	local max_targets = template_data.max_targets

	for i = 1, num_hits do
		if #hooked >= max_targets then
			break
		end

		local enemy_unit = BROADPHASE_RESULTS[i]
		local enemy_position = POSITION_LOOKUP[enemy_unit]

		if enemy_position and HEALTH_ALIVE[enemy_unit] and not hooked_units[enemy_unit] then
			local breed = _breed(enemy_unit)
			local small = _can_hook_breed(breed)
			local big = not small and template_data.grapple and #hooked == 0 and _is_big_breed(breed)

			-- The hook path is at eye height; enemies are measured at chest
			-- height so short and tall enemies are caught alike.
			local chest = enemy_position + Vector3(0, 0, template_data.eye_height * 0.6)

			if (small or big) and _distance_to_segment(chest, from, to) <= CATCH_RADIUS then
				if big then
					_start_grapple(template_data, enemy_unit)

					return
				end

				hooked_units[enemy_unit] = player_unit
				hooked[#hooked + 1] = enemy_unit

				local pull_direction = _flat_direction(enemy_position, POSITION_LOOKUP[player_unit]) or Vector3.up()

				Stagger.force_stagger(enemy_unit, HOOKED_STAGGER_TYPE, pull_direction, HOOK_MAX_TIME, 0, HOOK_MAX_TIME, player_unit, true)
				_sound(SOUND_CATCH, enemy_position)
				_reward(template_data)
			end
		end
	end

	-- Full: the hook stops where it is and comes back.
	if #hooked >= max_targets then
		template_data.path.phase = "back"
	end
end

local function _release(template_data)
	local hooked = template_data.hooked

	for i = 1, #hooked do
		hooked_units[hooked[i]] = nil
		hooked[i] = nil
	end

	if template_data.grapple_target then
		hooked_units[template_data.grapple_target] = nil
		template_data.grapple_target = nil
	end

	if template_data.player_unit and grapple_tethers[template_data.player_unit] == template_data then
		grapple_tethers[template_data.player_unit] = nil
	end
end

local function _teleport(enemy_unit, position, rotation)
	local locomotion_extension = ScriptUnit.has_extension(enemy_unit, "locomotion_system")

	if locomotion_extension and locomotion_extension.teleport_to then
		locomotion_extension:teleport_to(position, rotation)
	end
end

local function _drag(template_data)
	local head = template_data.path.head:unbox()
	local player_position = POSITION_LOOKUP[template_data.player_unit]
	local ground = head - Vector3(0, 0, template_data.eye_height)
	local hooked = template_data.hooked

	for i = #hooked, 1, -1 do
		local enemy_unit = hooked[i]

		if not HEALTH_ALIVE[enemy_unit] then
			hooked_units[enemy_unit] = nil

			table.remove(hooked, i)
		else
			local facing = _flat_direction(ground, player_position)
			local rotation = facing and Quaternion.look(facing, Vector3.up()) or nil

			_teleport(enemy_unit, ground, rotation)
		end
	end
end

local function _land(template_data)
	local player_unit = template_data.player_unit
	local player_position = POSITION_LOOKUP[player_unit]
	local hooked = template_data.hooked
	local count = #hooked

	if not player_position or count == 0 then
		_release(template_data)

		return
	end

	local _, aim = _eye_and_aim(player_unit)
	local forward = Vector3.flat(aim)

	if Vector3.length_squared(forward) == 0 then
		forward = Vector3.flat(Quaternion.forward(Unit.world_rotation(player_unit, 1)))
	end

	forward = Vector3.normalize(forward)

	local right = Vector3.cross(forward, Vector3.up())
	local nav_world = Managers.state.nav_mesh and Managers.state.nav_mesh:nav_world()
	local NavQueries = require("scripts/utilities/nav_queries")
	local facing = Quaternion.look(-forward, Vector3.up())

	for i = 1, count do
		local enemy_unit = hooked[i]

		if HEALTH_ALIVE[enemy_unit] then
			local side = (i - 1 - (count - 1) * 0.5) * LAND_SPACING
			local wanted = player_position + forward * LAND_DISTANCE + right * side
			local position = nav_world and NavQueries.position_on_mesh(nav_world, wanted, 2, 2)

			if not position and nav_world then
				-- No navmesh there (a ledge or a wall): land at the player's feet.
				position = NavQueries.position_on_mesh(nav_world, player_position, 2, 2)
			end

			_teleport(enemy_unit, position or wanted, facing)
			Stagger.force_stagger(enemy_unit, LAND_STAGGER_TYPE, forward, LAND_STAGGER_DURATION, LAND_STAGGER_LENGTH, LAND_STAGGER_DURATION, player_unit, true)
		end
	end

	_sound(SOUND_LAND, player_position + forward * LAND_DISTANCE)
	_release(template_data)
end

-- The rope stays on the big enemy, reeling in, until the player lets go
-- (jump or a new press), the enemy dies or tether_time is up. Returns true
-- when finished.
local function _update_grapple(template_data, dt)
	local target = template_data.grapple_target

	if not target or not HEALTH_ALIVE[target] or not Unit.alive(target) or template_data.let_go then
		_release(template_data)

		return true
	end

	local path = template_data.path
	local player_unit = template_data.player_unit
	local anchor = _grapple_anchor(template_data)
	local hold = _hold(player_unit)
	local pressed = hold and not path.last_hold

	path.last_hold = hold
	path.head:store(anchor)
	template_data.grapple_time = template_data.grapple_time + dt

	if pressed or template_data.grapple_time >= GRAPPLE.tether_time then
		_release(template_data)

		return true
	end

	local distance = Vector3.distance(anchor, Unit.world_position(player_unit, 1))

	template_data.rope = math.max(math.min(template_data.rope, distance) - _grapple("reel") * dt, GRAPPLE.min_rope)

	return false
end

local function _player_can_hold(unit)
	if not HEALTH_ALIVE[unit] then
		return false
	end

	local unit_data_extension = ScriptUnit.has_extension(unit, "unit_data_system")
	local character_state = unit_data_extension and unit_data_extension:read_component("character_state")

	if not character_state then
		return true
	end

	local PlayerUnitStatus = require("scripts/utilities/attack/player_unit_status")

	return not PlayerUnitStatus.is_disabled(character_state)
end

-- Drops everyone where they are, still staggered, when the hook breaks.
local function _drop(template_data)
	local player_unit = template_data.player_unit
	local hooked = template_data.hooked

	for i = 1, #hooked do
		local enemy_unit = hooked[i]

		if HEALTH_ALIVE[enemy_unit] then
			Stagger.force_stagger(enemy_unit, HOOKED_STAGGER_TYPE, Vector3.up(), LAND_STAGGER_DURATION, 0, LAND_STAGGER_DURATION, player_unit, true)
		end
	end

	_release(template_data)
end

local function _server_start(template_data, template_context)
	local unit = template_context.unit
	local SharedBuffFunctions = require("scripts/settings/buff/helper_functions/shared_buff_functions")
	local path = _new_path(unit)

	template_data.player_unit = unit
	template_data.physics_world = template_context.physics_world
	template_data.broadphase, template_data.enemy_side_names = SharedBuffFunctions.get_broadphase_and_enemy_side_names(unit)
	template_data.path = path
	template_data.hooked = {}
	template_data.max_targets = BASE_MAX_TARGETS + (_has_augment(unit, "extra_targets") and AUGMENT_EXTRA_TARGETS or 0)
	template_data.grapple = _has_augment(unit, "grapple")
	template_data.toughness_per_enemy = _has_augment(unit, "toughness") and TOUGHNESS_PER_ENEMY or nil
	template_data.eye_height = _eye_height(unit, path.start:unbox())
	template_data.time = 0
	template_data.done = false

	active_paths[unit] = path
end

local function _server_update(template_data, template_context, dt)
	if template_data.done or not template_data.path then
		return
	end

	local unit = template_data.player_unit

	template_data.time = template_data.time + dt

	local path = template_data.path

	if template_data.time > HOOK_MAX_TIME and path.phase ~= "grapple" or not _player_can_hold(unit) then
		_drop(template_data)

		template_data.done = true

		return
	end

	if path.phase == "grapple" then
		template_data.done = _update_grapple(template_data, dt)

		return
	end

	local before = path.head:unbox()
	local was_out = path.phase == "out"
	local event = _step(path, unit, _hold(unit), dt, template_data.physics_world)

	if event == "thrown" then
		_sound(SOUND_THROW, path.start:unbox())
	end

	if was_out then
		_catch(template_data, before, path.head:unbox())

		if path.phase == "grapple" then
			return
		end
	end

	if event == "back" then
		_land(template_data)

		template_data.done = true
	elseif path.phase ~= "aim" then
		_drag(template_data)
	end
end

-- ####################################################################
-- The hook everyone sees (runs on every machine through the buff's
-- player_effects, like the Deflect shimmer)
-- ####################################################################

local _particle_loaded = nil

local function _can_draw_sparks()
	if _particle_loaded == nil then
		local ok, loaded = pcall(Application.can_get_resource, "particles", CHAIN_PARTICLE)

		_particle_loaded = ok and loaded and true or false
	end

	return _particle_loaded
end

local chain_package = mod:persistent_table("chain_hook_chain_package", {
	id = nil,
	ready = false,
	failed = false,
})

local function _request_chain_package()
	if chain_package.id or chain_package.failed then
		return
	end

	local package_manager = Managers.package

	if not package_manager then
		return
	end

	local ok, id = pcall(package_manager.load, package_manager, CHAIN_PACKAGE, "QIangIQsScumHook", function ()
		chain_package.ready = true
	end)

	if ok then
		chain_package.id = id
	else
		chain_package.failed = true

		mod:warning("Chain Hook could not load the chain package: %s", tostring(id))
	end
end

local _chain_unit_available = nil

local function _can_draw_units()
	if not chain_package.ready then
		_request_chain_package()

		return false
	end

	if _chain_unit_available == nil then
		local ok, loaded = pcall(Application.can_get_resource, "unit", CHAIN_UNIT)

		_chain_unit_available = ok and loaded and true or false
	end

	return _chain_unit_available
end

-- Turns the unit's -Z (the way the chain hangs) onto direction.
local QUARTER_TURN_X = math.pi * 0.5

local function _chain_rotation(direction)
	local up = math.abs(direction.z) > 0.99 and Vector3(0, 1, 0) or Vector3.up()

	return Quaternion.multiply(Quaternion.look(direction, up), Quaternion.axis_angle(Vector3.right(), QUARTER_TURN_X))
end

local function _destroy_chain(template_data, world)
	local units = template_data.chain_units

	if not units then
		return
	end

	for i = #units, 1, -1 do
		local chain_unit = units[i]

		if world and Unit.alive(chain_unit) then
			World.destroy_unit(world, chain_unit)
		end

		units[i] = nil
	end
end

local function _segment(template_data, world, index)
	local units = template_data.chain_units
	local chain_unit = units[index]

	if chain_unit then
		return chain_unit
	end

	chain_unit = World.spawn_unit_ex(world, CHAIN_UNIT, nil, Vector3.zero(), Quaternion.identity())
	units[index] = chain_unit

	if index > 1 or not template_data.keep_spear then
		-- The spear head is hidden on every segment but the first, and on that
		-- one too when the hook head model is drawn ("Mesh index %u out of
		-- bounds in Unit" in Darktide.exe: meshes are addressed by index).
		local ok = pcall(Unit.set_mesh_visibility, chain_unit, CHAIN_SPEAR_MESH, false)

		if not ok then
			template_data.spear_hide_failed = true
		end
	end

	return chain_unit
end

-- Lays the chain from head back to origin: the first segment ends at head
-- (in its spear head when keep_spear), the rest follow end to end, and the
-- last one is shortened to stop at origin.
local function _draw_chain_units(template_data, world, origin, head)
	local to_head = head - origin
	local length = Vector3.length(to_head)
	local units = template_data.chain_units

	if length < 0.01 then
		_destroy_chain(template_data, world)

		return
	end

	local direction = to_head / length
	local rotation = _chain_rotation(direction)
	local first_length = template_data.keep_spear and CHAIN_TIP_LENGTH or CHAIN_SEGMENT_LENGTH
	-- Shorter than one segment (just thrown, almost back): squeeze the first
	-- segment so it still starts at the hand.
	local first_scale = math.max(math.min(length / first_length, 1), CHAIN_MIN_SCALE)
	local root = head - direction * (first_length * first_scale)
	local covered = first_length * first_scale
	local index = 1

	while true do
		local chain_unit = _segment(template_data, world, index)
		local scale = first_scale

		if index > 1 then
			local remaining = length - covered

			scale = math.max(math.min(remaining / CHAIN_SEGMENT_LENGTH, 1), CHAIN_MIN_SCALE)
			root = head - direction * (covered + scale * CHAIN_SEGMENT_LENGTH)
			covered = covered + scale * CHAIN_SEGMENT_LENGTH
		end

		Unit.set_local_position(chain_unit, 1, root)
		Unit.set_local_rotation(chain_unit, 1, rotation)
		Unit.set_local_scale(chain_unit, 1, Vector3(1, 1, scale))

		if covered >= length - 0.01 then
			break
		end

		index = index + 1
	end

	for i = #units, index + 1, -1 do
		if Unit.alive(units[i]) then
			World.destroy_unit(world, units[i])
		end

		units[i] = nil
	end
end

local function _draw_sparks(template_data, world, origin, head, t)
	if not _can_draw_sparks() then
		return
	end

	local next_draw_t = template_data.next_draw_t

	if next_draw_t and t < next_draw_t then
		return
	end

	template_data.next_draw_t = t + CHAIN_REDRAW_INTERVAL

	local to_head = head - origin
	local length = Vector3.length(to_head)

	World.create_particles(world, CHAIN_PARTICLE, head)

	if length > CHAIN_LINK_SPACING then
		local direction = to_head / length

		for distance = CHAIN_LINK_SPACING, length - CHAIN_LINK_SPACING * 0.5, CHAIN_LINK_SPACING do
			World.create_particles(world, CHAIN_PARTICLE, origin + direction * distance)
		end
	end
end

-- The hook head unit, its root HOOK_HEAD_LENGTH behind tip, pointing along
-- direction.
local function _draw_head(template_data, world, tip, direction)
	local head_unit = template_data.head_unit
	local root = tip - direction * HOOK_HEAD_LENGTH
	local rotation = _chain_rotation(direction)

	if not head_unit then
		head_unit = World.spawn_unit_ex(world, HOOK_HEAD_UNIT, nil, root, rotation)
		template_data.head_unit = head_unit
	end

	Unit.set_local_position(head_unit, 1, root)
	Unit.set_local_rotation(head_unit, 1, rotation)

	return root
end

local function _destroy_head(template_data, world)
	local head_unit = template_data.head_unit

	if head_unit and world and Unit.alive(head_unit) then
		World.destroy_unit(world, head_unit)
	end

	template_data.head_unit = nil
end

-- Where the chain leaves the player: the left hand (first person arms for
-- the local player in first person, the body otherwise).
local function _hand_position(unit)
	local first_person_extension = ScriptUnit.has_extension(unit, "first_person_system")
	local source = unit

	if first_person_extension and first_person_extension:is_in_first_person_mode() then
		source = first_person_extension:first_person_unit() or unit
	end

	if Unit.alive(source) and Unit.has_node(source, LEFT_HAND_NODE) then
		return Unit.world_position(source, Unit.node(source, LEFT_HAND_NODE))
	end

	local eye, aim = _eye_and_aim(unit)
	local up = Vector3.up()
	local right = Vector3.normalize(Vector3.cross(aim, up))

	return eye - right * HAND_FALLBACK_LEFT - up * HAND_FALLBACK_DOWN + aim * HAND_FALLBACK_FORWARD
end

local function _safe_hand_position(unit)
	local ok, position = pcall(_hand_position, unit)

	if ok and position then
		return position
	end

	return (_eye_and_aim(unit))
end

-- ####################################################################
-- The left arm (local player, first person only)
-- ####################################################################

-- While the hook is held and thrown, only the first person LEFT arm moves,
-- playing the Hive Scum's own left handed quick throw: the
-- "ability_knife_throw" event that base_template_settings.lua
-- grenade_ability_quick_flash_grenade (and the Zealot's
-- grenade_ability_zealot_throwing_knives) plays on whatever weapon is
-- wielded. In that throw the left hand throws and the weapon stays in the
-- right hand, so the melee weapon keeps its own animations and can attack.
--   * The throw runs on a hidden copy of the first person rig (the breed's
--     first_person_unit) with the wielded weapon's own first person state
--     machine (WeaponTemplate.state_machines, as
--     player_unit_animation_state.lua sets it on the real rig), so it is
--     already loaded.
--   * The visible arms follow a second copy of the rig (the pose rig), with
--     no animation of its own, the way QIangIQsButterflyKnife.lua fp_start
--     drives its first person fingers: the pose rig is linked to the first
--     person unit, the arm units (QIangIQsButterflyKnife_fingers.lua
--     Fingers.arm_units) are relinked to it by node name, and every frame
--     (PlayerUnitVisualLoadoutExtension.update) it copies the first person
--     rig's pose (Fingers.update), then the left arm bones are copied from
--     the throwing copy and the rig is updated with
--     World.update_unit_and_children. The right arm keeps the real rig's
--     pose. Afterwards the arm units are linked back (fp_stop).
--   * The throw is played once on the copy, and two of its poses are kept:
--     the wind-up ("Held arm" setting, seconds into the throw) and the
--     follow-through ("Thrown arm" setting). While held the left arm shows
--     the wind-up. Let go: it swings to the follow-through in ARM_CAST_TIME
--     and stays there, holding the chain, until the hook is back. A tap
--     plays the throw straight through to the follow-through.
--   * The hook is linked to the pose rig's left hand: its grip in the fist
--     (the middle of the curled middle finger), the shaft coming out of the
--     top of the fist, tilted forward from the forearm line by the "Hook
--     angle in the hand" setting, the hook end facing the knuckles.
-- If any piece is missing, the arm is left alone and the hook is drawn from
-- the hand's fallback point.

-- base_template_settings.lua grenade_ability_quick_flash_grenade:
-- anim_event "ability_knife_throw", anim_time_scale 1.25 (ActionBase sets it
-- as attack_speed), fire_time 0.25, total_time 0.55 (action seconds).
local ARM_SOURCE = {
	event = "ability_knife_throw",
	attack_speed = 1.25,
}
-- Seconds into the throw (action seconds; fire_time 0.25, total_time 0.55)
-- of the wind-up and the follow-through, and the hook's forward tilt in the
-- hand in degrees: mod settings, these are the defaults.
local ARM_SETTING_DEFAULTS = {
	arm_hold_time = 0.12,
	arm_follow_time = 0.3,
	hook_hand_angle = 45,
}
local ARM_BLEND_IN = 0.1
-- Seconds the arm takes to swing from the wind-up to the follow-through.
local ARM_CAST_TIME = 0.08

local function _arm_setting(setting_id)
	local value = mod:get(setting_id)

	return type(value) == "number" and value or ARM_SETTING_DEFAULTS[setting_id]
end
-- Far below the level and hidden: the animated copy only drives bones.
local ARM_DRIVER_DEPTH = 500

-- The first person arm bones as listed in QIangIQsButterflyKnife_cs2arms.lua;
-- any a rig lacks are skipped.
local LEFT_ARM_BONES = {
	"j_leftshoulder",
	"j_leftarm",
	"j_leftarmroll1",
	"j_leftforearm",
	"j_leftforearmroll1",
	"j_leftforearmroll2",
	"j_lefthand",
	"j_leftweaponattach",
	"j_lefthandthumb1",
	"j_lefthandthumb2",
	"j_lefthandthumb3",
	"j_lefthandindex1",
	"j_lefthandindex2",
	"j_lefthandindex3",
	"j_lefthandmiddle1",
	"j_lefthandmiddle2",
	"j_lefthandmiddle3",
	"j_lefthandring1",
	"j_lefthandring2",
	"j_lefthandring3",
	"j_lefthandpinky1",
	"j_lefthandpinky2",
	"j_lefthandpinky3",
}
-- The hook is linked to the hand. The knife throw does not move the left
-- weapon attach node with the hand (in game the hook sat by the forearm), so
-- the fist is found from the hand's own bones: its middle is the middle of
-- the curled middle finger, the shaft carries on from the forearm (elbow to
-- wrist), and the hook end faces the knuckles (wrist to middle knuckle).
local ARM_GRIP_BONE = "j_lefthand"
local FIST_BONES = { "j_lefthandmiddle1", "j_lefthandmiddle2", "j_lefthandmiddle3" }
local FIST_ELBOW, FIST_WRIST, FIST_KNUCKLE = "j_leftforearm", "j_lefthand", "j_lefthandmiddle1"
-- The model's root is the end of its handle; the ribbed grip starts just
-- after it, so the root sits this far below the middle of the fist.
local HOOK_GRIP_FROM_ROOT = 0.06

-- The first person rig's nodes (QIangIQsButterflyKnife_fp_nodes.lua), copied
-- onto the pose rig every frame.
local FP_NODES = {
	"root_point", "ap_aim", "ap_camera_node", "ep_mainhand", "ep_offhand", "j_aim_target",
	"j_lefthandikpolevector", "j_righthandikpolevector", "ap_light_locator", "j_spine2", "j_leftshoulder", "j_rightshoulder",
	"j_leftarm", "j_rightarm", "j_leftarmroll1", "j_leftforearm", "j_rightarmroll1", "j_rightforearm",
	"j_leftforearmroll1", "j_leftforearmroll2", "j_lefthand", "j_rightforearmroll1", "j_rightforearmroll2", "j_righthand",
	"j_lefthandthumb1", "j_leftinhandindex", "j_leftinhandmiddle", "j_leftinhandpinky", "j_leftinhandring", "j_leftweaponattach",
	"j_righthandthumb1", "j_rightinhandindex", "j_rightinhandmiddle", "j_rightinhandpinky", "j_rightinhandring", "j_rightweaponattach",
	"j_lefthandikeffector", "j_lefthandindex1", "j_lefthandmiddle1", "j_lefthandpinky1", "j_lefthandring1", "j_lefthandthumb2",
	"j_righthandikeffector", "j_righthandindex1", "j_righthandmiddle1", "j_righthandpinky1", "j_righthandring1", "j_righthandthumb2",
	"j_lefthandindex2", "j_lefthandmiddle2", "j_lefthandpinky2", "j_lefthandring2",
	"j_lefthandthumb3", "j_righthandindex2", "j_righthandmiddle2", "j_righthandpinky2", "j_righthandring2", "j_righthandthumb3",
	"j_lefthandindex3", "j_lefthandmiddle3", "j_lefthandpinky3", "j_lefthandring3", "j_righthandindex3", "j_righthandmiddle3",
	"j_righthandpinky3", "j_righthandring3",
}

local function _wielded_state_machine(unit, visual_loadout_extension, unit_data_extension, breed)
	local inventory_component = unit_data_extension.read_component and unit_data_extension:read_component("inventory")
	local wielded_slot = inventory_component and inventory_component.wielded_slot

	if not wielded_slot or wielded_slot == "none" then
		return nil
	end

	local weapon_template = visual_loadout_extension:weapon_template_from_slot(wielded_slot)

	if not weapon_template then
		return nil
	end

	local WeaponTemplate = require("scripts/utilities/weapon/weapon_template")
	local _, state_machine_1p, initialization_variables = WeaponTemplate.state_machines(weapon_template, breed.name)

	return state_machine_1p, initialization_variables
end

-- Setting a state machine that is not loaded crashes the game
-- ("AnimationStateMachine ... does not exist"); the wielded weapon's is
-- loaded, but it is checked (Application.can_get_resource, as
-- weapon_template_resource_dependencies.lua checks a resource).
local arm_not_loaded_warned = false

local function _arm_ready(state_machine)
	local ok, ready = false, false

	if state_machine then
		ok, ready = pcall(Application.can_get_resource, "state_machine", state_machine)
	end

	if ok and ready then
		return true
	end

	if not arm_not_loaded_warned then
		arm_not_loaded_warned = true

		mod:warning("Chain Hook left arm: the wielded weapon's animation is not loaded (%s)", tostring(state_machine))
	end

	return false
end

local function _first_person_unit(unit)
	local first_person_extension = ScriptUnit.has_extension(unit, "first_person_system")

	if not first_person_extension or not first_person_extension:is_in_first_person_mode() then
		return nil
	end

	return first_person_extension:first_person_unit()
end

-- The units that make up the visible first person arms
-- (QIangIQsButterflyKnife_fingers.lua Fingers.arm_units).
local function _arm_units(visual_loadout_extension)
	local found = {}

	if not visual_loadout_extension then
		return found
	end

	for key, value in pairs(visual_loadout_extension) do
		if type(key) == "string" then
			if string.find(key, "^__qiangiq_.+_arms$") and not string.find(key, "_part_arms$") then
				if value ~= nil and Unit.alive(value) then
					found[#found + 1] = value
				end
			elseif string.find(key, "^__qiangiq_.+_part_arms$") and type(value) == "table" then
				for _, part in pairs(value) do
					if part ~= nil and Unit.alive(part) then
						found[#found + 1] = part
					end
				end
			end
		end
	end

	local equipment = visual_loadout_extension._equipment

	if equipment then
		for slot_name, slot in pairs(equipment) do
			if type(slot_name) == "string" and (string.find(slot_name, "^slot_body") or string.find(slot_name, "^slot_gear")) and slot.unit_1p and Unit.alive(slot.unit_1p) then
				found[#found + 1] = slot.unit_1p
			end
		end
	end

	return found
end

-- Animated copy rigs alive now. Their animations fire the same flow events as
-- the real arms (sounds, effects, anim callbacks), and the game's flow
-- callbacks look up the owner's extensions, which a copy has none of
-- (flow_callbacks.lua _should_play_player_fx); those events are dropped.
local arm_drivers = {}

local DRIVER_FLOW_CALLBACKS = {
	"player_fx",
	"player_voice",
	"player_footstep",
	"player_inventory_event",
	"player_inventory_fx",
	"anim_callback",
	"call_anim_event",
}

mod:hook_require("scripts/script_flow_nodes/flow_callbacks", function (FlowCallbacks)
	for _, name in ipairs(DRIVER_FLOW_CALLBACKS) do
		if FlowCallbacks[name] then
			mod:hook(FlowCallbacks, name, function (func, params, ...)
				if params and (arm_drivers[params.first_person_unit] or arm_drivers[params.unit] or arm_drivers[params.source_unit]) then
					return nil
				end

				return func(params, ...)
			end)
		end
	end
end)

-- Puts the arm units back on the first person unit and removes both rigs
-- (QIangIQsButterflyKnife.lua fp_stop).
local function _destroy_arm(arm, world)
	if not arm then
		return
	end

	if world and arm.fp_unit and Unit.alive(arm.fp_unit) then
		for _, arm_unit in ipairs(arm.arm_units or {}) do
			if Unit.alive(arm_unit) then
				World.unlink_unit(world, arm_unit)
				World.link_unit(world, arm_unit, 1, arm.fp_unit, 1, World.LINK_MODE_NODE_NAME)
			end
		end
	end

	arm.arm_units = nil

	for _, key in ipairs({ "driver", "pose" }) do
		local rig = arm[key]

		if rig then
			arm_drivers[rig] = nil

			if world and Unit.alive(rig) then
				World.destroy_unit(world, rig)
			end
		end

		arm[key] = nil
	end
end

-- Sets up both rigs. Returns nil when it cannot work.
local function _create_arm(unit, world)
	local fp_unit = _first_person_unit(unit)
	local unit_data_extension = ScriptUnit.has_extension(unit, "unit_data_system")
	local breed = unit_data_extension and unit_data_extension.breed and unit_data_extension:breed()
	local rig_name = breed and breed.first_person_unit
	local visual_loadout_extension = ScriptUnit.has_extension(unit, "visual_loadout_system")

	if not fp_unit or not rig_name or not visual_loadout_extension then
		return nil
	end

	local state_machine, initialization_variables = _wielded_state_machine(unit, visual_loadout_extension, unit_data_extension, breed)

	if not _arm_ready(state_machine) then
		return nil
	end

	local arm = {
		fp_unit = fp_unit,
		bones = {},
		copies = {},
		weight = 0,
		anim_t = 0,
		display = "live",
	}

	arm.driver = World.spawn_unit_ex(world, rig_name, nil, Vector3(0, 0, -ARM_DRIVER_DEPTH), Quaternion.identity())
	arm_drivers[arm.driver] = true

	pcall(Unit.set_unit_visibility, arm.driver, false)

	local driver = arm.driver

	-- player_unit_animation_state.lua _set_anim_state_machine.
	Unit.set_animation_state_machine(driver, state_machine)

	if initialization_variables then
		for variable_name, value in pairs(initialization_variables) do
			local variable_id = Unit.animation_find_variable(driver, variable_name)

			if variable_id then
				value = type(value) == "function" and value(unit) or value

				Unit.animation_set_variable(driver, variable_id, value)
			end
		end
	end

	if not Unit.has_animation_event(driver, ARM_SOURCE.event) then
		_destroy_arm(arm, world)

		mod:warning("Chain Hook left arm: %s has no %s", tostring(state_machine), ARM_SOURCE.event)

		return nil
	end

	-- The pose rig: same rig, no animation, follows the first person unit.
	local pose = World.spawn_unit_ex(world, rig_name, nil, Unit.world_position(fp_unit, 1), Unit.world_rotation(fp_unit, 1))

	arm.pose = pose
	arm_drivers[pose] = true

	pcall(Unit.disable_animation_state_machine, pose)
	pcall(Unit.set_unit_visibility, pose, false)

	for _, name in ipairs(FP_NODES) do
		if Unit.has_node(fp_unit, name) and Unit.has_node(pose, name) then
			local node = Unit.node(pose, name)

			if node ~= 1 then
				arm.copies[#arm.copies + 1] = {
					from = Unit.node(fp_unit, name),
					to = node,
				}
			end
		end
	end

	for _, name in ipairs(LEFT_ARM_BONES) do
		if Unit.has_node(driver, name) and Unit.has_node(pose, name) then
			arm.bones[#arm.bones + 1] = {
				from = Unit.node(driver, name),
				to = Unit.node(pose, name),
			}
		end
	end

	if #arm.bones == 0 or not Unit.has_node(pose, ARM_GRIP_BONE) then
		_destroy_arm(arm, world)

		return nil
	end

	World.link_unit(world, pose, 1, fp_unit, 1)

	arm.arm_units = _arm_units(visual_loadout_extension)

	for _, arm_unit in ipairs(arm.arm_units) do
		World.unlink_unit(world, arm_unit)
		World.link_unit(world, arm_unit, 1, pose, 1, World.LINK_MODE_NODE_NAME)
	end

	arm.grip_node = Unit.node(pose, ARM_GRIP_BONE)

	for key, name in pairs({ fist_elbow = FIST_ELBOW, fist_wrist = FIST_WRIST, fist_knuckle = FIST_KNUCKLE }) do
		arm[key] = Unit.has_node(pose, name) and Unit.node(pose, name) or nil
	end

	arm.fist_nodes = {}

	for _, name in ipairs(FIST_BONES) do
		if Unit.has_node(pose, name) then
			arm.fist_nodes[#arm.fist_nodes + 1] = Unit.node(pose, name)
		end
	end

	return arm
end

-- Plays the throw on the copy from the start, at the action's speed
-- (ActionBase.trigger_anim_event sets attack_speed). arm.anim_t counts
-- action seconds.
local function _play_throw(arm)
	local attack_speed = Unit.animation_find_variable(arm.driver, "attack_speed")

	if attack_speed then
		Unit.animation_set_variable(arm.driver, attack_speed, ARM_SOURCE.attack_speed)
	end

	Unit.animation_event(arm.driver, ARM_SOURCE.event)

	arm.anim_t = 0
	arm.plays = (arm.plays or 0) + 1
end

-- The copy's left arm now, to show while held or after the follow-through.
local function _snapshot(arm)
	local shot = {}

	for i, bone in ipairs(arm.bones) do
		shot[i] = {
			rotation = QuaternionBox(Unit.local_rotation(arm.driver, bone.from)),
			position = Vector3Box(Unit.local_position(arm.driver, bone.from)),
		}
	end

	return shot
end

-- Drives the copy through the hook phases. The throw plays once; while
-- held the arm shows its wind-up, on release it swings to the
-- follow-through and stays there.
local function _step_arm(arm, phase, dt)
	if not arm.plays then
		_play_throw(arm)
	else
		arm.anim_t = arm.anim_t + dt
	end

	arm.weight = math.min(arm.weight + dt / ARM_BLEND_IN, 1)

	local hold_at = _arm_setting("arm_hold_time")
	local follow_at = math.max(_arm_setting("arm_follow_time"), hold_at + 0.05)

	-- The throw keeps playing on the copy while the arm is held: the
	-- follow-through is kept as it goes past.
	if not arm.follow and arm.anim_t >= follow_at then
		arm.follow = _snapshot(arm)
	end

	if phase == "aim" then
		if arm.display == "live" and arm.anim_t >= hold_at then
			arm.held = _snapshot(arm)
			arm.display = "held"
		end

		return
	end

	if arm.display == "held" then
		if arm.follow then
			arm.display = "cast"
			arm.cast_t = 0
		else
			-- Let go before the copy got there: on with the throw itself.
			arm.display = "live"
		end
	elseif arm.display == "cast" then
		arm.cast_t = arm.cast_t + dt

		if arm.cast_t >= ARM_CAST_TIME then
			arm.display = "after"
		end
	elseif arm.display == "live" and arm.follow then
		arm.display = "after"
	end
end

-- One frame of the pose rig: the first person pose, then the copy's left
-- arm on top. Returns the grip's world position (where the hook is held).
local function _pose_arm(arm, world)
	local fp_unit, driver, pose = arm.fp_unit, arm.driver, arm.pose

	if not Unit.alive(fp_unit) or not Unit.alive(driver) or not Unit.alive(pose) then
		return nil
	end

	-- QIangIQsButterflyKnife_fingers.lua Fingers.update: the same rig, so the
	-- local transforms copy over node for node.
	for _, copy in ipairs(arm.copies) do
		Unit.set_local_rotation(pose, copy.to, Unit.local_rotation(fp_unit, copy.from))
		Unit.set_local_position(pose, copy.to, Unit.local_position(fp_unit, copy.from))
	end

	local display = arm.display
	local shot = display == "held" and arm.held or display == "after" and arm.follow or nil
	local weight = arm.weight
	local cast = display == "cast" and math.min(arm.cast_t / ARM_CAST_TIME, 1) or nil

	for i, bone in ipairs(arm.bones) do
		local rotation, position

		if cast then
			rotation = Quaternion.lerp(arm.held[i].rotation:unbox(), arm.follow[i].rotation:unbox(), cast)
			position = Vector3.lerp(arm.held[i].position:unbox(), arm.follow[i].position:unbox(), cast)
		elseif shot then
			rotation, position = shot[i].rotation:unbox(), shot[i].position:unbox()
		else
			rotation, position = Unit.local_rotation(driver, bone.from), Unit.local_position(driver, bone.from)
		end

		if weight < 1 then
			rotation = Quaternion.lerp(Unit.local_rotation(pose, bone.to), rotation, weight)
			position = Vector3.lerp(Unit.local_position(pose, bone.to), position, weight)
		end

		Unit.set_local_rotation(pose, bone.to, rotation)
		Unit.set_local_position(pose, bone.to, position)
	end

	World.update_unit_and_children(world, pose)

	return Unit.world_position(pose, arm.grip_node)
end

-- Template data of every hook whose arm is posed, by player unit.
local posed_arms = {}

-- Where the hook is held: the root's world position and rotation, in the
-- axes _chain_rotation gives the flying hook. The shaft carries on from the
-- forearm out of the fist, the hook end facing the knuckles. Without those
-- bones it is held at the hand pointing along the aim.
local function _fist_pose(arm, aim)
	local pose = arm.pose
	local hand = Unit.world_position(pose, arm.grip_node)

	if arm.fist_elbow and arm.fist_wrist and arm.fist_knuckle and #arm.fist_nodes > 0 then
		local along = Unit.world_position(pose, arm.fist_wrist) - Unit.world_position(pose, arm.fist_elbow)
		local facing = Unit.world_position(pose, arm.fist_knuckle) - Unit.world_position(pose, arm.fist_wrist)

		if Vector3.length_squared(along) > 1e-8 and Vector3.length_squared(facing) > 1e-8 then
			along = Vector3.normalize(along)
			facing = Vector3.normalize(facing)

			if math.abs(Vector3.dot(along, facing)) < 0.99 then
				local middle = Vector3(0, 0, 0)

				for _, node in ipairs(arm.fist_nodes) do
					middle = middle + Unit.world_position(pose, node)
				end

				middle = middle / #arm.fist_nodes

				-- Tilted forward, from the forearm line towards the knuckles.
				local tilt = math.rad(_arm_setting("hook_hand_angle"))
				local side = Vector3.normalize(facing - along * Vector3.dot(facing, along))
				local shaft = along * math.cos(tilt) + side * math.sin(tilt)
				local front = side * math.cos(tilt) - along * math.sin(tilt)
				local rotation = Quaternion.multiply(Quaternion.look(shaft, front), Quaternion.axis_angle(Vector3.right(), QUARTER_TURN_X))

				return middle - shaft * HOOK_GRIP_FROM_ROOT, rotation
			end
		end
	end

	return hand, _chain_rotation(aim)
end

-- The hook held in the posed hand: linked to the hand, in the fist.
local function _hold_head(template_data, arm, world)
	local head_unit = template_data.head_unit
	local aim = template_data.held_direction

	if not head_unit or not Unit.alive(head_unit) or not aim then
		return
	end

	if template_data.head_linked ~= arm.pose then
		World.link_unit(world, head_unit, 1, arm.pose, arm.grip_node)

		template_data.head_linked = arm.pose
	end

	local position, rotation = _fist_pose(arm, aim:unbox())
	local hand_position = Unit.world_position(arm.pose, arm.grip_node)
	local hand_rotation_inverse = Quaternion.inverse(Unit.world_rotation(arm.pose, arm.grip_node))

	Unit.set_local_position(head_unit, 1, Quaternion.rotate(hand_rotation_inverse, position - hand_position))
	Unit.set_local_rotation(head_unit, 1, Quaternion.multiply(hand_rotation_inverse, rotation))
end

-- Lets go of the held hook (thrown, or the arm stopped).
local function _release_head(template_data, world)
	local head_unit = template_data.head_unit

	if template_data.head_linked and head_unit and world and Unit.alive(head_unit) then
		World.unlink_unit(world, head_unit)
	end

	template_data.head_linked = nil
end

local function _pose_all_arms()
	for unit, template_data in pairs(posed_arms) do
		local arm = template_data.arm
		local world = template_data.world

		if arm and not template_data.arm_failed then
			local ok, grip = pcall(_pose_arm, arm, world)

			if not ok then
				template_data.arm_failed = true
				posed_arms[unit] = nil

				pcall(_release_head, template_data, world)
				pcall(_destroy_arm, arm, world)

				template_data.arm = nil

				mod:warning("Chain Hook left arm turned off: %s", tostring(grip))
			elseif grip then
				arm.grip = Vector3Box(grip)

				if template_data.draw_head and template_data.held_direction then
					local held_ok, err = pcall(_hold_head, template_data, arm, world)

					if not held_ok then
						template_data.draw_head = false

						mod:warning("Chain Hook could not hold the hook: %s", tostring(err))
					end
				end
			end
		end
	end
end

-- Every frame for the local player, the way QIangIQsButterflyKnife.lua poses
-- its first person rig (vl_hook_safe "update").
mod:hook_require("scripts/extension_systems/visual_loadout/player_unit_visual_loadout_extension", function (PlayerUnitVisualLoadoutExtension)
	mod:hook_safe(PlayerUnitVisualLoadoutExtension, "update", function (self)
		if posed_arms[self._unit] then
			_pose_all_arms()
		end
	end)
end)

-- One frame of the left arm for the effect: creates it on first use and
-- steps the copy rig; the posing runs in the visual loadout update. Returns
-- the grip's world position from the last pose, or nil. Any error turns the
-- arm off for the rest of this hook.
local function _update_arm(template_data, unit, world, phase, dt)
	if template_data.arm_failed or not template_data.local_owner then
		return nil
	end

	local ok, result = pcall(function ()
		local arm = template_data.arm

		if arm and arm.fp_unit ~= _first_person_unit(unit) then
			-- Left first person (third person view, spectating): stop.
			posed_arms[unit] = nil

			_release_head(template_data, world)
			_destroy_arm(arm, world)

			template_data.arm = nil

			return nil
		end

		if not arm then
			arm = _create_arm(unit, world)

			if not arm then
				template_data.arm_failed = true

				return nil
			end

			template_data.arm = arm
			template_data.world = world
			posed_arms[unit] = template_data
		end

		_step_arm(arm, phase, dt)

		return arm.grip and arm.grip:unbox()
	end)

	if not ok then
		template_data.arm_failed = true
		posed_arms[unit] = nil

		mod:warning("Chain Hook left arm turned off: %s", tostring(result))

		pcall(_release_head, template_data, world)
		pcall(_destroy_arm, template_data.arm, world)

		template_data.arm = nil

		return nil
	end

	return result
end

local function _finish_arm(template_data, world)
	if template_data.unit then
		posed_arms[template_data.unit] = nil
	end

	pcall(_release_head, template_data, world)
	pcall(_destroy_arm, template_data.arm, world)

	template_data.arm = nil
	template_data.held_direction = nil
end

-- ####################################################################
-- Outline of the enemy the held hook would catch (local player only)
-- ####################################################################

-- Enemies from the side's enemy_units_lookup, as the Veteran's outline buff
-- finds them. The first one along the aim, within CATCH_RADIUS of the line
-- and before any wall, is the one the hook reaches first.
local function _aim_target(unit, eye, direction, reach, grapple)
	local side_system = Managers.state.extension:system("side_system")
	local side = side_system and side_system.side_by_unit[unit]
	local enemy_units = side and side.enemy_units_lookup

	if not enemy_units then
		return nil
	end

	local lift = Vector3(0, 0, _eye_height(unit, eye) * 0.6)
	local best_unit, best_distance = nil, math.huge

	for enemy_unit in pairs(enemy_units) do
		local position = HEALTH_ALIVE[enemy_unit] and Unit.alive(enemy_unit) and Unit.world_position(enemy_unit, 1)

		if position and not hooked_units[enemy_unit] then
			local chest = position + lift
			local along = Vector3.dot(chest - eye, direction)

			if along >= 0 and along <= reach + CATCH_RADIUS and along < best_distance and Vector3.distance(chest, eye + direction * along) <= CATCH_RADIUS then
				local breed = _breed(enemy_unit)

				if _can_hook_breed(breed) or grapple and _is_big_breed(breed) then
					best_unit, best_distance = enemy_unit, along
				end
			end
		end
	end

	return best_unit
end

local function _set_outline(template_data, target)
	local current = template_data.outlined

	if current == target then
		return
	end

	local extension_manager = Managers.state.extension

	if not extension_manager or not extension_manager:has_system("outline_system") then
		return
	end

	local outline_system = extension_manager:system("outline_system")

	-- remove_outline returns quietly for a unit that is gone (outline_system.lua).
	if current then
		outline_system:remove_outline(current, OUTLINE_NAME)
	end

	if target then
		outline_system:add_outline(target, OUTLINE_NAME)
	end

	template_data.outlined = target
end

local function _update_outline(template_data, path, unit, world)
	local eye = path.start:unbox()
	local direction = path.direction:unbox()
	local reach = _reach(world and World.physics_world(world), eye, direction)

	_set_outline(template_data, _aim_target(unit, eye, direction, reach, template_data.grapple))
end

local function _finish_effect(template_data, world)
	template_data.done = true

	_finish_arm(template_data, world)
	pcall(_set_outline, template_data, nil)
	_destroy_chain(template_data, world)
	_destroy_head(template_data, world)
end

local chain_effect_template = {
	name = EFFECT_TEMPLATE_NAME,
	resources = {},
	start = function (template_data, template_context)
		local unit = template_data.unit

		template_data.path = _new_path(unit)
		template_data.next_draw_t = nil
		template_data.done = false
		template_data.chain_units = {}
		template_data.local_owner = _is_local_owner(unit)
		template_data.grapple = _has_augment(unit, "grapple")
		template_data.draw_head = hook_head.ready
		template_data.keep_spear = not hook_head.ready

		_request_chain_package()
	end,
	update = function (template_data, template_context, dt, t)
		local unit = template_data.unit
		local world = template_context.world

		if template_data.done then
			return
		end

		if not ALIVE[unit] then
			_finish_effect(template_data, world)

			return
		end

		local server_path = active_paths[unit]
		local path = template_data.path

		if server_path then
			-- This machine runs the hook: draw the real one.
			template_data.following_server = true
			path = server_path
		elseif template_data.following_server then
			_finish_effect(template_data, world)

			return
		else
			-- Work it out here: the owner knows their own key, everyone else
			-- sees it thrown straight away.
			local hold = template_data.local_owner and _hold(unit) or false
			local event = _step(path, unit, hold, dt, world and World.physics_world(world))

			if event == "back" then
				_finish_effect(template_data, world)

				return
			end
		end

		-- The local player's left arm is posed from the mirrored grenade throw
		-- and holds the hook at its grip; otherwise the chain leaves the hand.
		local grip = template_data.local_owner and _update_arm(template_data, unit, world, path.phase, dt)
		local hand = grip or _safe_hand_position(unit)

		template_data.held_direction = path.phase == "aim" and Vector3Box(path.direction:unbox()) or nil

		if path.phase == "aim" then
			-- Held out: the hook sits in the hand, pointing where you aim.
			_destroy_chain(template_data, world)

			-- Held in the posed left hand, the hook is placed by the arm (see
			-- "The left arm"); it is only made here.
			if template_data.draw_head and not template_data.head_linked then
				_draw_head(template_data, world, hand + path.direction:unbox() * HOOK_HEAD_LENGTH, path.direction:unbox())
			end

			if template_data.local_owner then
				pcall(_update_outline, template_data, path, unit, world)
			end

			return
		end

		if template_data.outlined then
			pcall(_set_outline, template_data, nil)
		end

		if template_data.head_linked then
			_release_head(template_data, world)
		end

		local tip = path.head:unbox()
		local chain_end = tip

		if template_data.draw_head then
			local to_tip = tip - hand
			local direction = Vector3.length_squared(to_tip) > 0.0001 and Vector3.normalize(to_tip) or path.direction:unbox()

			chain_end = _draw_head(template_data, world, tip, direction)
		end

		if _can_draw_units() then
			_draw_chain_units(template_data, world, hand, chain_end)
		else
			_draw_sparks(template_data, world, hand, chain_end, t)
		end
	end,
	stop = function (template_data, template_context)
		_finish_effect(template_data, template_context.world)
	end,
}

-- ####################################################################
-- Game data
-- ####################################################################

local function _gameplay_time()
	local time_manager = Managers.time

	if time_manager and time_manager.has_timer and time_manager:has_timer("gameplay") then
		return time_manager:time("gameplay")
	end

	return nil
end

-- Not predicted: the server alone adds it (player_unit_buff_extension.lua
-- add_internally_controlled_buff) and syncs it, so the server decides when
-- the hook is over, through conditional_exit_func (buff.lua).
local function _buff_template()
	return {
		class_name = "buff",
		predicted = false,
		unique_buff_id = BUFF_NAME,
		start_func = function (template_data, template_context)
			if template_context.is_server then
				local ok, err = pcall(_server_start, template_data, template_context)

				if not ok then
					template_data.done = true

					mod:error("Chain Hook could not start: %s", tostring(err))
				end
			end
		end,
		update_func = function (template_data, template_context, dt, t)
			if not template_context.is_server then
				return
			end

			local ok, err = pcall(_server_update, template_data, template_context, dt)

			if not ok then
				pcall(_release, template_data)

				template_data.done = true

				mod:error("Chain Hook failed: %s", tostring(err))
			end

			-- Over: the chain stops following this path right away.
			if template_data.done and template_data.player_unit then
				active_paths[template_data.player_unit] = nil
			end
		end,
		conditional_exit_func = function (template_data, template_context)
			return template_context.is_server and template_data.done == true
		end,
		stop_func = function (template_data, template_context)
			local unit = template_context.unit

			if unit then
				active_paths[unit] = nil
				hook_ended_at[unit] = _gameplay_time()
			end

			if template_context.is_server and template_data.hooked then
				pcall(_drop, template_data)
			end
		end,
		player_effects = {
			effect_template = chain_effect_template,
		},
	}
end

local function _ability()
	-- Same fields as broker_abilities.lua broker_ability_punk_rage, with
	-- charges as broker_abilities.lua's syringe ability: max_charges plus the
	-- ability_extra_charges stat buff (player_unit_ability_extension.lua
	-- max_ability_charges).
	return {
		ability_group = ABILITY_NAME,
		ability_template = ABILITY_TEMPLATE,
		cooldown = COOLDOWN,
		hud_icon = ABILITY_HUD_ICON,
		icon = ABILITY_ICON,
		-- Equipped only, for its animations (see "The hook item").
		inventory_item_name = ITEM_NAME,
		can_be_previously_wielded_to = false,
		can_be_wielded_when_depleted = false,
		max_charges = MAX_CHARGES,
		name = ABILITY_NAME,
		resource_cost_per_charge = COOLDOWN,
		resource_regen_per_second = 1,
		stat_buff = "ability_extra_charges",
		usage_cost_type = "charges",
		-- No hand animation from the action itself: the throw is played by
		-- the start hook below (_play_throw_anim).
		ability_template_tweak_data = {
			anim = false,
			anim_3p = false,
			buff_to_add = BUFF_NAME,
		},
		archetypes = {
			"broker",
		},
	}
end

local function _resource_strings()
	local out = {}

	for _, name in ipairs({ SOUND_THROW, SOUND_CATCH, SOUND_LAND }) do
		if Application.can_get_resource("package", name) then
			out[#out + 1] = name
		end
	end

	return out
end

local function _number_values(values)
	local out = {}

	for name, value in pairs(values) do
		out[name] = {
			format_type = "number",
			value = value,
		}
	end

	return out
end

local function _talent(ability)
	local broker_talents = ArchetypeTalents.broker
	local rage = broker_talents and rawget(broker_talents, "broker_ability_punk_rage")

	return {
		description = LOC_DESCRIPTION,
		display_name = LOC_NAME,
		icon = NODE_ICON,
		is_main_ability = true,
		large_icon = rage and rage.large_icon or nil,
		name = "Hive Scum Chain Hook",
		format_values = _number_values({
			range = HOOK_RANGE,
			speed = HOOK_SPEED,
			return_speed = RETURN_SPEED,
			charges = MAX_CHARGES,
			cooldown = COOLDOWN,
		}),
		player_ability = {
			ability_type = "combat_ability",
			ability = ability,
		},
		qiangiq_resources = _resource_strings(),
	}
end

-- Same as QIangIQsLegacyTalents class_swap.lua _append_lookup: new names go
-- at the end so every existing id keeps its index.
local function _append_lookup(lookup_name, name)
	local NetworkLookup = rawget(_G, "NetworkLookup") or require("scripts/network_lookup/network_lookup")
	local lookup = NetworkLookup[lookup_name]

	if not lookup then
		mod:error("NetworkLookup.%s is missing", lookup_name)

		return
	end

	if rawget(lookup, name) == nil then
		local index = #lookup + 1

		rawset(lookup, index, name)
		rawset(lookup, name, index)
	end
end

-- ####################################################################
-- The hook item (carries the grenade animations)
-- ####################################################################

-- The ability has an inventory item (player_unit_ability_extension.lua
-- _equip_ability puts it in slot_combat_ability). It is never wielded (see
-- the can_wield hook): it is there so its package, which holds the item's
-- resource_dependencies, loads the grenade state machines the left arm plays
-- (see "The left arm"). It was first built to be wielded; its weapon
-- template is a copy of the shield's (force_field_weapon_template_generator
-- .lua): wield, hold to aim, let go to throw, then back to the previous
-- weapon. The hands use the one-handed grenade throw
-- (grenade_weapon_template_generator.lua):
--   * wield: "to_grenade";
--   * holding: "to_aim_arc", the wind-up;
--   * throw: "throw"; the throw action costs
--     the charge (consume_ability_usage_cost at start, as
--     ActionWeaponBase.start reads it) and its start adds the hook buff.
-- The template and item are registered the way QIangIQsDauntlessArmory
-- registers its weapons: a clone in WeaponTemplates plus NetworkLookup
-- weapon_templates, and a clone of the master item plus NetworkLookup
-- player_item_names.

local _poll_wield

do
	local SOURCE_WEAPON_TEMPLATE = "psyker_force_field"
	-- psyker_abilities.lua psyker_force_field inventory_item_name.
	local SOURCE_ITEM = "content/items/weapons/player/psyker_shield"
	local THROW_STATE_MACHINE_1P = "content/characters/player/human/first_person/animations/grenade_equipable"
	local THROW_STATE_MACHINE_3P = "content/characters/player/human/third_person/animations/grenade"
	local ANIM_WIELD = "to_grenade"
	local ANIM_HOLD = "to_aim_arc"
	local ANIM_THROW = "throw"
	-- The grenade aim's end event.
	local ANIM_CANCEL = "to_unaim_arc"

	-- Particle and sound aliases are keyed by the wielded weapon template; the
	-- copy gets the source template's entries (QIangIQsDauntlessArmory
	-- copy_aliases, from QIangIQsShardStaff alias_template_keys).
	local ALIAS_MODULES = {
		"scripts/settings/particles/player_character_particle_aliases",
		"scripts/settings/sound/player_character_sound_event_aliases",
	}

	local function _alias_keys(root, source, target, seen)
		if type(root) ~= "table" or seen[root] then
			return
		end

		seen[root] = true

		local value = rawget(root, source)

		if value ~= nil and rawget(root, target) == nil then
			root[target] = value
		end

		for _, child in pairs(root) do
			if type(child) == "table" then
				_alias_keys(child, source, target, seen)
			end
		end
	end

	local function _copy_aliases(source, target)
		for _, path in ipairs(ALIAS_MODULES) do
			local ok, module = pcall(require, path)

			if ok then
				_alias_keys(module, source, target, {})
			end
		end
	end

	local wield_state = mod:persistent_table("chain_hook_wield_state", {
		template = false,
		item = false,
	})

	local function _set_anims(action, anim_event)
		action.anim_event = anim_event
		action.anim_event_3p = anim_event
		action.anim_end_event = nil
		action.chain_anim_event = nil
		action.chain_anim_event_3p = nil
	end

	-- The aim and place actions become plain timed actions (kind "dummy"), so
	-- nothing of the shield (preview, placement, shield unit) runs.
	local function _as_dummy(action)
		action.kind = "dummy"
		action.place_configuration = nil
		action.visual_unit = nil
		action.functional_unit = nil
		action.use_aim_data = nil
		action.place_time = nil
		action.vo_tag = nil
		action.unwield_slot = nil
	end

	local function _make_weapon_template(source)
		local template = table.clone(source)

		template.name = WEAPON_TEMPLATE_NAME
		template.anim_state_machine_1p = THROW_STATE_MACHINE_1P
		template.anim_state_machine_3p = THROW_STATE_MACHINE_3P
		template.keywords = {}
		template.wieldable_slot_scripts = nil
		template.action_aim_force_field_screen_ui_validation = nil

		local actions = template.actions

		_set_anims(actions.action_wield, ANIM_WIELD)

		for _, name in ipairs({ "action_aim_force_field", "action_instant_aim_force_field" }) do
			_as_dummy(actions[name])
		end

		_set_anims(actions.action_aim_force_field, ANIM_HOLD)

		for _, name in ipairs({ "action_place_force_field", "action_instant_place_force_field" }) do
			local action = actions[name]

			_as_dummy(action)
			_set_anims(action, ANIM_THROW)

			action.consume_ability_usage_cost = true
			action.consume_usage_cost_at_start = true
			action.qiangiq_chain_hook_throw = true
			-- Back to the previous weapon when the poke is over, as the cancel
			-- action does.
			action.conditional_state_to_action_input = {
				action_end = {
					input_name = "unwield_to_previous",
				},
			}
		end

		_set_anims(actions.action_cancel, ANIM_CANCEL)

		-- weapon_templates.lua _require_template: action_settings.name = action_name
		for action_name, action_settings in pairs(actions) do
			action_settings.name = action_name
		end

		return template
	end

	local function _ensure_weapon_template()
		if wield_state.template then
			return true
		end

		local WeaponTemplates = require("scripts/settings/equipment/weapon_templates/weapon_templates")

		if not rawget(WeaponTemplates, WEAPON_TEMPLATE_NAME) then
			local source = WeaponTemplates[SOURCE_WEAPON_TEMPLATE]

			if not source then
				return false
			end

			WeaponTemplates[WEAPON_TEMPLATE_NAME] = _make_weapon_template(source)
		end

		_append_lookup("weapon_templates", WEAPON_TEMPLATE_NAME)
		_copy_aliases(SOURCE_WEAPON_TEMPLATE, WEAPON_TEMPLATE_NAME)

		wield_state.template = true

		return true
	end

	local function _ensure_item()
		local MasterItems = require("scripts/backend/master_items")
		local ok, has_data = pcall(MasterItems.has_data)

		if not ok or not has_data then
			return false
		end

		local cache = MasterItems.get_cached()

		if not rawget(cache, ITEM_NAME) then
			local source = rawget(cache, SOURCE_ITEM)

			if type(source) ~= "table" then
				return false
			end

			local item = table.clone(source)

			item.name = ITEM_NAME
			item.weapon_template = WEAPON_TEMPLATE_NAME
			item.archetypes = {
				"broker",
			}
			-- The Psyker shield item runs the shield placement preview
			-- (psyker_force_field_placement_preview_effects.lua, spawned from the
			-- aim action's visual_unit); the hook has no preview, and with the
			-- visual_unit gone that script crashed in spawn_unit.
			item.wieldable_slot_scripts = nil

			-- Items only load what resource_dependencies lists, and the offline
			-- compile puts the template's state machines, sounds and effects there
			-- (item_package.lua, WeaponTemplateResourceDependencies.generate).
			-- Without it the grenade state machine was never loaded and wielding
			-- the hook crashed ("AnimationStateMachine ... does not exist",
			-- player_unit_animation_state.lua:154); QIangIQsDauntlessArmory 0.3.0
			-- fixed the same crash this way.
			local WeaponTemplateResourceDependencies = require("scripts/utilities/weapon_template_resource_dependencies")
			local dependencies = table.clone(source.resource_dependencies or {})

			for _, resource in ipairs(WeaponTemplateResourceDependencies.generate(WEAPON_TEMPLATE_NAME)) do
				dependencies[resource] = true
			end

			item.resource_dependencies = dependencies
			cache[ITEM_NAME] = item

			mod:info("Chain Hook item %s added (copy of %s, slots %s)", ITEM_NAME, SOURCE_ITEM, table.concat(item.slots or {}, ","))
		end

		_append_lookup("player_item_names", ITEM_NAME)

		wield_state.item = true

		return true
	end

	-- Every frame until both exist: the master items arrive from the backend
	-- some time after the mods load.
	_poll_wield = function ()
		if wield_state.template and wield_state.item then
			return
		end

		local ok, err = pcall(_ensure_weapon_template)

		if not ok then
			mod:error("Chain Hook weapon template: %s", tostring(err))
		elseif wield_state.template then
			ok, err = pcall(_ensure_item)

			if not ok then
				mod:error("Chain Hook item: %s", tostring(err))
			end
		end
	end
end

local function _register_augment(augment)
	-- Marker buff (and the extra charges for Spare Hooks): no duration, no
	-- HUD icon, removed with the talent. Fields as
	-- veteran_combat_ability_extra_charge.
	BuffTemplates[augment.talent] = {
		name = augment.talent,
		class_name = "buff",
		max_stacks = 1,
		predicted = false,
		stat_buffs = augment.stat_buffs,
	}

	ArchetypeTalents.broker[augment.talent] = {
		description = augment.loc_description,
		display_name = augment.loc_name,
		icon = augment.icon,
		name = augment.talent,
		format_values = _number_values(augment.format_values),
		passive = {
			buff_template_name = augment.talent,
			identifier = augment.talent,
		},
	}

	_append_lookup("archetype_talent_names", augment.talent)
	_append_lookup("talent_node_names", augment.node)
	_append_lookup("buff_templates", augment.talent)
end

local function _register_data()
	if state.registered then
		return
	end

	local buff = _buff_template()

	buff.name = BUFF_NAME
	BuffTemplates[BUFF_NAME] = buff

	EffectTemplates[EFFECT_TEMPLATE_NAME] = chain_effect_template

	local ability = _ability()

	PlayerAbilities[ABILITY_NAME] = ability
	ArchetypeTalents.broker[TALENT_NAME] = _talent(ability)

	_append_lookup("archetype_talent_names", TALENT_NAME)
	_append_lookup("talent_node_names", NODE_NAME)
	_append_lookup("buff_templates", BUFF_NAME)
	_append_lookup("player_abilities", ABILITY_NAME)
	_append_lookup("effect_templates", EFFECT_TEMPLATE_NAME)

	for _, augment in ipairs(AUGMENTS) do
		_register_augment(augment)
	end

	state.registered = true
end

-- ####################################################################
-- Legacy tree node
-- ####################################################################

-- QIangIQsLegacyTalents swaps layout.nodes between the official and legacy
-- tables (mode_toggle.lua). Its record holds the legacy table whichever mode
-- is active, so the node goes in there and never into the official tree.
local function _legacy_nodes()
	local legacy_mod = get_mod("QIangIQsLegacyTalents")

	if not legacy_mod then
		return nil, "QIangIQsLegacyTalents is not installed or loads after this mod"
	end

	local legacy_state = legacy_mod:persistent_table("legacy_state")
	local toggle = legacy_state and legacy_state.toggle

	if not toggle or not toggle.tables then
		return nil, "QIangIQsLegacyTalents has no legacy data loaded"
	end

	local layout = require(LAYOUT_PATH)

	for i = 1, toggle.count do
		if toggle.tables[i] == layout and toggle.keys[i] == "nodes" then
			return toggle.legacy[i]
		end
	end

	return nil, "the legacy Hive Scum tree is turned off in QIangIQsLegacyTalents"
end

local function _add_unique(node, key, name)
	local list = node[key]

	if not list then
		list = {}
		node[key] = list
	end

	for i = 1, #list do
		if list[i] == name then
			return
		end
	end

	list[#list + 1] = name
end

-- Fields as the 1.10.0 Rampage modifier nodes (broker_tree.lua). Appended in
-- AUGMENTS order after the nodes already there, so saved builds keep their
-- indices.
local function _insert_augments(nodes, by_name)
	local hook = by_name[NODE_NAME]

	if not hook then
		return
	end

	for _, augment in ipairs(AUGMENTS) do
		if not by_name[augment.node] then
			nodes[#nodes + 1] = {
				cost = 1,
				icon = augment.icon,
				max_points = 1,
				talent = augment.talent,
				type = "ability_modifier",
				widget_name = augment.node,
				x = augment.x,
				x_normalized = 0,
				y = augment.y,
				y_normalized = 0,
				children = {},
				parents = {
					NODE_NAME,
				},
				requirements = {
					all_parents_chosen = false,
					children_unlock_points = 1,
					min_points_spent = 0,
				},
			}
			by_name[augment.node] = nodes[#nodes]

			_add_unique(hook, "children", augment.node)
		end
	end
end
local function _insert_node()
	local nodes, reason = _legacy_nodes()

	if not nodes then
		return false, reason
	end

	local by_name = {}

	for _, node in ipairs(nodes) do
		by_name[node.widget_name] = node
	end

	if by_name[NODE_NAME] then
		_insert_augments(nodes, by_name)

		return true
	end

	for _, list in ipairs({ PARENT_NODES, CHILD_NODES }) do
		for _, name in ipairs(list) do
			if not by_name[name] then
				return false, "the legacy Hive Scum tree has no node " .. name
			end
		end
	end

	-- Make room: every node already there moves right (once per node, the
	-- legacy table is kept while the toggle is off).
	for _, node in ipairs(nodes) do
		if not state.shifted_nodes[node] then
			node.x = node.x + TREE.shift_x
			state.shifted_nodes[node] = true
		end
	end

	local parents, children = {}, {}

	for i, name in ipairs(PARENT_NODES) do
		parents[i] = name
	end

	for i, name in ipairs(CHILD_NODES) do
		children[i] = name
	end

	-- Fields as the 1.10.0 Rampage node, plus target_slot the way
	-- QIangIQsLegacyTalents _adapt_layout sets it. Appended last, so the index
	-- of every existing node (used by saved builds) is unchanged.
	nodes[#nodes + 1] = {
		cost = 1,
		icon = NODE_ICON,
		max_points = 1,
		talent = TALENT_NAME,
		target_slot = "slot_combat_ability",
		type = "ability",
		widget_name = NODE_NAME,
		x = TREE.node_x,
		x_normalized = 0,
		y = TREE.node_y,
		y_normalized = 0,
		children = children,
		parents = parents,
		requirements = {
			all_parents_chosen = false,
			children_unlock_points = 1,
			exclusive_group = EXCLUSIVE_GROUP,
			min_points_spent = 0,
		},
	}

	for _, name in ipairs(PARENT_NODES) do
		_add_unique(by_name[name], "children", NODE_NAME)
	end

	-- Two-way, as Rampage and the melee damage node list each other.
	for _, name in ipairs(CHILD_NODES) do
		_add_unique(by_name[name], "parents", NODE_NAME)
	end

	by_name[NODE_NAME] = nodes[#nodes]

	_insert_augments(nodes, by_name)

	return true
end

local function _try_insert_node()
	if state.node_inserted then
		return
	end

	local ok, reason = _insert_node()

	state.node_inserted = ok
	state.node_message = reason

	if ok then
		mod:info("Chain Hook added to the legacy Hive Scum tree")
	end
end

_register_data()
_try_insert_node()

-- The hook head model, through the Custom Assets API the way
-- QIangIQsShardStaff loads its models. Optional: without it the chain keeps
-- its own spear head.
local function _acquire_hook_head()
	local custom_assets = get_mod("CustomAssets")

	if not custom_assets or not custom_assets.is_api_compatible or not custom_assets.is_api_compatible(1) then
		mod:warning("Custom Assets (API 1) is missing: Chain Hook uses the chain's own spear head")

		return
	end

	local ticket, err = custom_assets.acquire(mod, HOOK_HEAD_ASSET, function (_, _, load_error)
		if load_error then
			mod:error("%s failed to load: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", HOOK_HEAD_ASSET, tostring(load_error))

			return
		end

		hook_head.ready = true
	end, { resident = true, reference_name = HOOK_HEAD_ASSET })

	if not ticket then
		mod:error("%s could not be requested: %s", HOOK_HEAD_ASSET, tostring(err))
	end
end

-- Dragging the tree sideways --------------------------------------------------

-- node_builder_view_base.lua _handle_scenegraph_coordinates drags the
-- background only up and down in the talent view ("if not
-- self._player_mode then scenegraph_settings.x = final_x"). While the
-- background is being dragged there, the same cursor difference it uses for
-- y is added to x, kept within TREE.pan_left/pan_right of where the tree
-- started. The game's class() copies the base class's methods into each
-- subclass when the subclass is made (class.lua), so hooking the base class
-- alone would miss the talent view: the hook goes on both. A flag keeps a
-- call that passes through both from being applied twice.
TREE.install_pan = function (Class)
	mod:hook(Class, "_handle_scenegraph_coordinates", function (func, self, widget_name, scenegraph_id, input_service, move_input_prefix, render_settings, is_background, ...)
		if self._qiangiq_panning or self._qiangiq_pan_owner or not (is_background and self._player_mode) then
			return func(self, widget_name, scenegraph_id, input_service, move_input_prefix, render_settings, is_background, ...)
		end

		self._qiangiq_panning = true

		local last = self._dragging_scenegraph_id == scenegraph_id and self._cursor_last_coordinates
		local last_x = last and last[1]
		local ok, handled, finalized = pcall(func, self, widget_name, scenegraph_id, input_service, move_input_prefix, render_settings, is_background, ...)

		self._qiangiq_panning = nil

		if not ok then
			error(handled, 0)
		end

		local saved = self._saved_scenegraph_settings
		local settings = saved and saved[scenegraph_id]

		if settings then
			self._qiangiq_pan_base_x = self._qiangiq_pan_base_x or settings.x

			local current = self._cursor_current_coordinates

			if last_x and current and current[1] ~= last_x then
				local base_x = self._qiangiq_pan_base_x
				local diff_x = (current[1] - last_x) / self._nodes_render_scale

				settings.x = math.clamp(settings.x + diff_x, base_x - TREE.pan_left, base_x + TREE.pan_right)
			end
		end

		return handled, finalized
	end)
end

mod:hook_require("scripts/ui/views/node_builder_view_base/node_builder_view_base", TREE.install_pan)
mod:hook_require("scripts/ui/views/talent_builder_view/talent_builder_view", TREE.install_pan)

mod.on_all_mods_loaded = function ()
	_try_insert_node()

	if not state.node_inserted then
		mod:warning("Chain Hook was not added to the Hive Scum tree: %s", tostring(state.node_message))
	end

	_acquire_hook_head()
	_poll_wield()
end

mod.update = function ()
	_poll_wield()
end

-- ####################################################################
-- Hooks
-- ####################################################################

-- Is a hook out (or just back) for this player? Then a press of the ability
-- is the early reel, not a new throw.
local function _hook_busy(unit, t)
	if _has_buff(unit, BUFF_NAME) then
		return true
	end

	local ended_at = hook_ended_at[unit]

	return ended_at ~= nil and t ~= nil and t - ended_at < REEL_GRACE
end

-- Values swapped in around ActionStanceChange.start for a reel press: no
-- charge spent (action_ability_base.lua reads consume_ability_usage_cost from
-- the tweak data first), no new buff (buff_to_add nil), no hand animation,
-- no voice line.
local REEL_TWEAK_KEYS = {
	"consume_ability_usage_cost",
	"buff_to_add",
	"anim",
	"anim_3p",
}
local REEL_TWEAK_VALUES = {
	consume_ability_usage_cost = false,
	anim = false,
	anim_3p = false,
}

-- The throw: the third person body plays the hand thrust the way
-- ActionBase.trigger_anim_event plays a 3p event. In first person only the
-- left arm moves (see "The left arm"); the right hand keeps the melee weapon.
local function _play_throw_anim(action)
	local animation_extension = action._animation_extension

	if not animation_extension then
		return
	end

	local weapon_action_component = action._weapon_action_component
	local time_scale = weapon_action_component and weapon_action_component.time_scale or 1

	animation_extension:anim_event_with_variable_floats(THROW_ANIM, "attack_speed", time_scale, "action_time_offset", 0)
end

mod:hook_require("scripts/extension_systems/ability/actions/action_stance_change", function (ActionStanceChange)
	mod:hook(ActionStanceChange, "start", function (func, self, action_settings, t, ...)
		local tweak_data = self._ability_template_tweak_data
		local ability = self._ability
		local is_hook = ability and ability.name == ABILITY_NAME or tweak_data and tweak_data.buff_to_add == BUFF_NAME

		if not is_hook or not tweak_data or not action_settings then
			return func(self, action_settings, t, ...)
		end

		local refill_toughness, vo_tag = action_settings.refill_toughness, action_settings.vo_tag
		local reel = _hook_busy(self._player_unit, t)
		local saved_tweak = {}

		-- Rampage's template refills toughness on activation
		-- (broker_punk_rage.lua refill_toughness); Chain Hook does not.
		action_settings.refill_toughness = false

		if reel then
			action_settings.vo_tag = nil

			for _, key in ipairs(REEL_TWEAK_KEYS) do
				saved_tweak[key] = tweak_data[key]
				tweak_data[key] = REEL_TWEAK_VALUES[key]
			end
		end

		-- The game's table.pack returns the table and the value count.
		local results, n = table.pack(pcall(func, self, action_settings, t, ...))

		action_settings.refill_toughness, action_settings.vo_tag = refill_toughness, vo_tag

		if reel then
			for _, key in ipairs(REEL_TWEAK_KEYS) do
				tweak_data[key] = saved_tweak[key]
			end
		end

		if not results[1] then
			error(results[2], 0)
		end

		if not reel then
			pcall(_play_throw_anim, self)
		end

		return unpack(results, 2, n)
	end)
end)

-- The hook item is never wielded: the press runs Rampage's template (the
-- melee weapon stays out) and the left arm alone throws.
mod:hook_require("scripts/extension_systems/ability/player_unit_ability_extension", function (PlayerUnitAbilityExtension)
	mod:hook(PlayerUnitAbilityExtension, "can_wield", function (func, self, slot_name, previous_check)
		if slot_name == "slot_combat_ability" then
			local ability = self._equipped_abilities and self._equipped_abilities.combat_ability

			if ability and ability.name == ABILITY_NAME then
				return false
			end
		end

		return func(self, slot_name, previous_check)
	end)
end)

-- ####################################################################
-- Grapple rope (server: the player's in-air movement)
-- ####################################################################

-- The tether a player is on, if any.
local function _tether_for(unit)
	local template_data = grapple_tethers[unit]
	local target = template_data and template_data.grapple_target

	if target and HEALTH_ALIVE[target] and Unit.alive(target) then
		return template_data
	end

	return nil
end

-- The rope on one in-air step: pulled towards the anchor while longer than
-- min_rope, and at full length no moving away from the enemy (relative to
-- its own movement, so a charging enemy drags the player along).
local function _tether_velocity(template_data, position, velocity, dt)
	local target = template_data.grapple_target
	local to_anchor = _grapple_anchor(template_data) - position
	local distance = Vector3.length(to_anchor)

	if distance < 0.01 then
		return velocity
	end

	local direction = to_anchor / distance

	if distance > GRAPPLE.min_rope then
		velocity = velocity + direction * _grapple("pull") * dt
	end

	if distance >= template_data.rope then
		local locomotion_extension = ScriptUnit.has_extension(target, "locomotion_system")
		local ok, target_velocity = false, nil

		if locomotion_extension and locomotion_extension.current_velocity then
			ok, target_velocity = pcall(locomotion_extension.current_velocity, locomotion_extension)
		end

		target_velocity = ok and target_velocity or Vector3(0, 0, 0)

		local closing = Vector3.dot(velocity - target_velocity, direction)

		if closing < 0 then
			velocity = velocity - direction * closing
		end
	end

	local speed = Vector3.length(velocity)

	local max_speed = _grapple("max_speed")

	if speed > max_speed then
		velocity = velocity * (max_speed / speed)
	end

	return velocity
end

-- In the air (player_character_state_jumping.lua / _falling.lua): after the
-- state's own air movement (which keeps strafing) has set velocity_wanted,
-- the rope is applied on top. Jump lets go, with an optional hop.
--
-- Gravity: jumping takes it off velocity_wanted.z itself; falling leaves it
-- to the locomotion, which with calculate_fall_velocity replaces
-- velocity_wanted.z with the current fall speed and then applies gravity
-- (player_unit_locomotion_extension.lua _update_script_driven_movement), so
-- the rope's vertical pull would be lost there. While on the rope, falling
-- does what jumping does: calculate_fall_velocity off and gravity applied here,
-- as QIangIQsSourceMovement does on surf ramps. It is turned back on at the
-- start of the next step, before the state's own movement runs.
for _, state_path in ipairs({
	"scripts/extension_systems/character_state_machine/character_states/player_character_state_jumping",
	"scripts/extension_systems/character_state_machine/character_states/player_character_state_falling",
}) do
	mod:hook_require(state_path, function (State)
		mod:hook(State, "fixed_update", function (func, self, unit, dt, t, next_state_params, fixed_frame)
			local steering = self._locomotion_steering_component

			if self._qiangiq_rope_gravity then
				self._qiangiq_rope_gravity = nil
				steering.calculate_fall_velocity = true
			end

			local next_state = func(self, unit, dt, t, next_state_params, fixed_frame)
			local template_data = self._is_server and _tether_for(unit)

			if template_data and not template_data.let_go then
				local ok, err = pcall(function ()
					local velocity = steering.velocity_wanted
					local gravity = self._constants.gravity
					local gravity_scale = _grapple("gravity") / 100

					if steering.calculate_fall_velocity then
						-- Falling: velocity_wanted.z is the current fall speed.
						velocity = Vector3(velocity.x, velocity.y, velocity.z - gravity * gravity_scale * dt)
						steering.calculate_fall_velocity = false
						self._qiangiq_rope_gravity = true
					else
						-- Jumping: full gravity already taken off.
						velocity = Vector3(velocity.x, velocity.y, velocity.z + gravity * (1 - gravity_scale) * dt)
					end

					if self._input_extension:get("jump") then
						template_data.let_go = true

						local jump_height = _grapple("jump_height")

						if jump_height > 0 then
							velocity = Vector3(velocity.x, velocity.y, math.max(velocity.z, 0) + math.sqrt(2 * gravity * jump_height))
						end

						steering.velocity_wanted = velocity

						return
					end

					steering.velocity_wanted = _tether_velocity(template_data, self._locomotion_component.position, velocity, dt)
				end)

				if not ok then
					template_data.let_go = true

					mod:warning("Chain Hook grapple rope stopped: %s", tostring(err))
				end
			end

			return next_state
		end)
	end)
end

-- On the ground with slack to take up: popped into the air with the game's
-- own jump, so the rope works there (a dragging enemy lifts them off).
for _, state_path in ipairs({
	"scripts/extension_systems/character_state_machine/character_states/player_character_state_walking",
	"scripts/extension_systems/character_state_machine/character_states/player_character_state_sprinting",
}) do
	mod:hook_require(state_path, function (State)
		mod:hook(State, "fixed_update", function (func, self, unit, dt, t, next_state_params, fixed_frame)
			local next_state = func(self, unit, dt, t, next_state_params, fixed_frame)

			if next_state == nil and self._is_server then
				local template_data = _tether_for(unit)

				if template_data and not template_data.let_go then
					local ok, distance = pcall(function ()
						return Vector3.distance(_grapple_anchor(template_data), self._locomotion_component.position)
					end)

					if ok and distance > GRAPPLE.min_rope + GRAPPLE.lift_slack then
						return "jumping"
					end
				end
			end

			return next_state
		end)
	end)
end

-- ####################################################################
-- Text
-- ####################################################################

local loc_text = {
	[LOC_NAME] = "talent_name",
	[LOC_DESCRIPTION] = "talent_description",
}

for _, augment in ipairs(AUGMENTS) do
	loc_text[augment.loc_name] = "augment_" .. augment.key .. "_name"
	loc_text[augment.loc_description] = "augment_" .. augment.key .. "_description"
end

mod:hook(CLASS.LocalizationManager, "_lookup", function (func, self, key)
	local mod_key = loc_text[key]

	if mod_key then
		return mod:localize(mod_key)
	end

	return func(self, key)
end)

mod:command("chain_hook", mod:localize("command_description"), function ()
	if state.node_inserted then
		mod:echo("Chain Hook is in the legacy Hive Scum tree, left of the tree beside the stimm duration node.")
	else
		mod:echo("Chain Hook is not in the Hive Scum tree: %s", tostring(state.node_message))
	end

	mod:echo("Hook head model: %s", hook_head.ready and "loaded" or "not loaded (chain spear head used)")
end)
