return {
	grapple_reel_speed = {
		en = "Grapple: reel-in speed (m/s)",
	},
	grapple_reel_speed_description = {
		en = "How fast the rope shortens towards the boss or Ogryn you are tied to, down to 3.5 m.",
	},
	grapple_pull = {
		en = "Grapple: pull towards the boss (m/s²)",
	},
	grapple_pull_description = {
		en = "How hard the rope pulls you in while it is longer than 3.5 m. Higher: you fly in faster.",
	},
	grapple_max_speed = {
		en = "Grapple: top speed (m/s)",
	},
	grapple_max_speed_description = {
		en = "Your speed is capped at this while tied on.",
	},
	grapple_gravity = {
		en = "Grapple: gravity on the rope (percent)",
	},
	grapple_gravity_description = {
		en = "Gravity while you are tied on, in percent of the game's (11.82 m/s²). Lower: you float and swing longer.",
	},
	grapple_jump_height = {
		en = "Grapple: jump off height (m)",
	},
	grapple_jump_height_description = {
		en = "Jumping lets go of the rope. This adds a hop of this height as you let go. 0: no hop. The game's own jump is about 0.7 m.",
	},
	arm_hold_time = {
		en = "Held arm (seconds into the throw)",
	},
	arm_hold_time_description = {
		en = "Where the left arm stops while you hold the hook: lower values hold it lower, before the wind-up gets high. The throw releases at 0.25.",
	},
	arm_follow_time = {
		en = "Thrown arm (seconds into the throw)",
	},
	arm_follow_time_description = {
		en = "The pose the left arm keeps after the throw while the chain is out. Just after the release (0.25) the arm is out in front.",
	},
	hook_hand_angle = {
		en = "Hook angle in the hand (degrees)",
	},
	hook_hand_angle_description = {
		en = "0: the hook carries on straight up from the forearm. Higher tilts it forward, negative tilts it back.",
	},
	mod_name = {
		en = "QIangIQ's Scum Hook",
	},
	mod_description = {
		en = "Adds Chain Hook, a new Hive Scum combat ability, to the legacy Hive Scum tree from QIangIQs Legacy Talents. Hold the ability to hold the hook out and see who it would catch, let go to throw it 30 metres. The first enemy it catches that is not a boss or an Ogryn is yanked back and dropped in front of you, staggered. Press again while it flies to reel it in early. 2 charges, and five augments. Legacy trees only, so Fatshark missions are untouched. Every player in a Realms game needs this mod.",
	},
	talent_name = {
		en = "Chain Hook",
	},
	talent_description = {
		en = "Hold to hold the hook out: the enemy it would catch is outlined. Let go (or just tap) to throw it up to {range:%%s} metres where you are aiming, at {speed:%%s} metres a second. It stops early at a wall.\n\nThe first enemy it touches is caught and stunned, unless it is a boss, a captain or an Ogryn. The hook then snaps back at {return_speed:%%s} metres a second and drops the enemy right in front of you, staggered.\n\nPress again while the hook flies out to reel it in early, with whatever it holds. That press costs no charge.\n\nCharges: {charges:%%s}. Cooldown: {cooldown:%%s} seconds per charge.",
	},
	augment_extra_targets_name = {
		en = "Chain Hook: Gang Hook",
	},
	augment_extra_targets_description = {
		en = "Chain Hook holds {extra_targets:%%s} more enemies. It keeps flying until it has caught 3 enemies, reaches its full range, hits a wall or is reeled in, then snaps back with all of them.",
	},
	augment_fast_name = {
		en = "Chain Hook: Fast Hook",
	},
	augment_fast_description = {
		en = "Chain Hook flies out at {speed:%%s} metres a second and snaps back at {return_speed:%%s}: twice as fast.",
	},
	augment_charges_name = {
		en = "Chain Hook: Spare Hooks",
	},
	augment_charges_description = {
		en = "Chain Hook has {charges:%%s} charges.",
	},
	augment_grapple_name = {
		en = "Chain Hook: Grapple",
	},
	augment_grapple_description = {
		en = "Chain Hook also latches onto Ogryns and bosses when it is empty. Instead of pulling them in, it ties you to them: you are lifted into the air and pulled in on a rope that reels in at {reel_speed:%%s} metres a second (set in the mod options), keeping your air control so you can strafe and swing around them. The rope follows them as they move. Jump or press again to let go; it lets go by itself after {tether_time:%%s} seconds.",
	},
	augment_toughness_name = {
		en = "Chain Hook: Tough Haul",
	},
	augment_toughness_description = {
		en = "Gain {toughness:%%s} toughness for every enemy Chain Hook catches.",
	},
	command_description = {
		en = "Shows whether Chain Hook is in the legacy Hive Scum tree and whether the hook model loaded.",
	},
}
