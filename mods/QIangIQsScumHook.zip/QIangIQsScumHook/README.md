# QIangIQsScumHook

Chain Hook, a new Hive Scum combat ability in the legacy (1.10.0) Hive Scum tree from QIangIQsLegacyTalents. Needs QIangIQsLegacyTalents loaded before it, and Custom Assets for the hook model (optional: without it the chain's own spear head is the hook). Every player in a Realms game needs this mod.

## What it does

- **Press:** your melee weapon stays in your right hand and keeps its own animations, so you can still attack. Only your left arm moves: it plays the Hive Scum's own left handed quick throw (the one the flash grenade and the Zealot's knives use) and comes up with the hook gripped in the fist, hook end up past the thumb.
- **Hold to aim:** while the key is held the left arm stays at the wind-up of the throw (low enough to see the hook), hook in hand, and the enemy it would catch first is outlined (the Veteran's target outline). Only you see the outline.
- **Let go (or tap) to throw:** the left arm swings straight to the follow-through, out in front, the hook flies up to 30 m where you aim, at 10 m/s, and stops early at a wall. The arm stays out holding the chain until the hook is back.
- **Catch:** the first enemy within 1.5 m of the hook's path is caught and stunned. Bosses (monster, captain, cultist captain, lord, daemonhost), Ogryns and ritualists are never caught.
- **Snap back:** as soon as the hook is full (or at full range, or at a wall) it comes back at 40 m/s, dragging what it caught.
- **Early reel:** press the ability again while the hook flies out and it comes straight back with whatever it holds. That press spends no charge.
- **Land:** caught enemies are dropped side by side 1.5 m in front of you, on the navmesh, with the heaviest stagger (explosion type, 4 s), cut short so it does not carry them away from you.
- **Charges:** 2, each recharging in 30 s (the 1.10.0 Rampage cooldown).
- **Chain:** leaves from your hand (the first person arms in first person, the body otherwise), not the middle of the screen. It is the game's spiked iron chain from the Psykhanium arena, with your Roadhog hook model on the end.
- If you go down or get grabbed mid-pull, everyone is dropped where they are, staggered.

## Augments (ability modifiers under Chain Hook)

| Augment | Effect |
|---|---|
| Gang Hook | Holds 2 more enemies (3 in all); keeps flying until it has 3, reaches 30 m, hits a wall or is reeled in |
| Fast Hook | Twice as fast: 20 m/s out, 80 m/s back |
| Spare Hooks | 4 charges (2 more, through the game's own extra charges stat) |
| Grapple | When the hook is empty it also latches onto Ogryns and bosses and ties you to them, Pathfinder style. You are popped into the air and keep your normal air control (strafe), while the rope pulls you in (30 m/s²) and reels in at 12 m/s down to 3.5 m. At full length it only stops you moving away, so you swing round them, and it follows them as they move, so a charging Ogryn drags you along. Speed is capped at 22 m/s. Jump or press the ability again to let go; it lets go by itself after 8 s. They are not staggered, so they keep moving |
| Tough Haul | 20 toughness for each enemy caught (a grappled one counts) |

## Settings

- **Held arm (seconds into the throw):** where the left arm stops while you hold. Lower holds it lower. Default 0.12.
- **Thrown arm (seconds into the throw):** the pose kept after the throw. Default 0.3.
- **Hook angle in the hand (degrees):** 0 is straight on from the forearm, higher tilts the hook forward. Default 45.
- **Grapple: reel-in speed (m/s):** how fast the rope shortens towards the boss, down to 3.5 m. Default 12.
- **Grapple: pull towards the boss (m/s²):** how hard the rope pulls you in. Default 30.
- **Grapple: top speed (m/s):** your speed cap while tied on. Default 22.
- **Grapple: gravity on the rope (%):** gravity while tied on, in percent of the game's 11.82 m/s². Default 100.
- **Grapple: jump off height (m):** a hop of this height when you jump to let go. 0 is no hop; the game's own jump is about 0.7 m. Default 0.

The arm settings apply from the next throw and the grapple settings at once, so they can be tuned in a mission.

## Where it sits

Chain Hook sits at the left edge of the Hive Scum tree, level with the abilities, in the ability group (it replaces your combat ability). The overview panel on the left of the talent view cannot be moved, and it covers everything left of x 515, so the whole tree is moved right by 380 to make room: the hook and its five augments sit at x 520 to 840, the old tree starts at 895. The stimm duration node above Desperado leads into the hook, the way it leads into Desperado. From Chain Hook a line runs to the crit chance node below Desperado, which links to the melee damage node, so the whole lower tree and all three keystones can be reached from it. (A straight line to the melee damage node itself would have to cross Desperado or Rampage.) Gang Hook, Fast Hook and Spare Hooks are in a row above it and Grapple and Tough Haul below it, each joined to it by a short line. Only the legacy tree is moved; the current game's tree is untouched.

**Dragging sideways.** In the talent view you can now drag the background left and right as well as up and down (the game only allowed up and down), up to 700 to the left and 500 to the right of where the tree starts. This works on every class's tree, with or without the hook. (The game copies the base view's methods into the talent view when it is made, so the drag is hooked on both the base view and the talent view; a guard stops it being applied twice.) The test harness checks that nothing overlaps and no line crosses a node.

## How it is built

| Part | Taken from |
|---|---|
| Activation | the Rampage press (`broker_punk_rage` ability template, its animations turned off), which adds the hook buff; the ability also carries an `inventory_item_name`, as `cryptic_chordclaw` does, so `_equip_ability` equips the hook item, which is never wielded |
| Charges | `max_charges` plus the `ability_extra_charges` stat buff, as the Hive Scum syringe ability and `veteran_combat_ability_extra_charge` |
| Item | (left from the grenade version, no longer needed for the arm) a copy of the Psyker shield master item named `content/items/weapons/player/qiangiq_chain_hook` with weapon template `qiangiq_chain_hook`, registered as QIangIQsDauntlessArmory registers its weapons. It is only there so its package loads the grenade state machines: the item's `resource_dependencies` are merged with `WeaponTemplateResourceDependencies.generate`, and the Psyker placement preview slot script is removed |
| Never wielded | `PlayerUnitAbilityExtension.can_wield` returns false for `slot_combat_ability` while Chain Hook is equipped, so the press never swaps away from your melee weapon |
| Left arm animation | `ability_knife_throw`, the event `base_template_settings.lua` `grenade_ability_quick_flash_grenade` (and the Zealot's knives) plays on whatever weapon is wielded, at its `anim_time_scale` 1.25. It runs on a hidden copy of the first person rig far below the level, with the wielded weapon's own first person state machine (`WeaponTemplate.state_machines`, set up as `player_unit_animation_state.lua` does), so nothing extra has to load. Held: the arm shows the wind-up, kept as the throw passes the "Held arm" setting (default 0.12 s). The throw keeps playing on the copy and its follow-through is kept at the "Thrown arm" setting (default 0.3 s, just after the release at `fire_time` 0.25). Let go: the arm swings from the wind-up to the follow-through in 0.08 s and stays there until the hook is back; nothing is replayed, so the arm casts with the chain |
| Left arm only | QIangIQsButterflyKnife's first person technique: a second copy of the rig with no animation is linked to the first person unit and the visible arm units (body and gear first person units, other mods' arms) are relinked to it by node name. Every frame (`PlayerUnitVisualLoadoutExtension.update`) it copies the real first person pose, then the left arm and finger bones are copied from the throwing copy, and `World.update_unit_and_children` updates it. The right arm keeps the real rig's melee pose. When the hook ends the arms are linked back to the first person unit and both copies removed |
| Hook in the hand | linked to the pose rig's left hand (`j_lefthand`). The knife throw does not carry the left weapon attach node with the hand (in game the hook sat by the forearm), so the fist is found from the hand's bones: the grip is the middle of the curled middle finger (`j_lefthandmiddle1` to `3`), the handle end 6 cm below it, the shaft comes out of the top of the fist, tilted forward from the forearm line (`j_leftforearm` to `j_lefthand`) by the "Hook angle in the hand" setting (default 45 degrees), and the hook end faces the knuckles; let go on the throw |
| Third person | the game's `ability_shout` third person animation, as Rampage plays it |
| Hold and reel input | `input_extension:get("combat_ability_hold")`, as `interactor_extension.lua` reads `interact_hold`; it is one of the inputs the server receives |
| Outline | `outline_system:add_outline(unit, "special_target")`, as the Veteran's stance buff; targets from the side's `enemy_units_lookup` |
| Moving enemies | `MinionLocomotionExtension.teleport_to`, as the Beast of Nurgle carries a minion |
| Stun and landing stagger | `Stagger.force_stagger`, as the Mortis pull buffs and Deflect use it |
| Grapple rope | on the server, after `PlayerCharacterStateJumping` / `PlayerCharacterStateFalling` `fixed_update` has set `velocity_wanted` from the game's own air movement (`_air_movement`, the strafing), the rope is added on top: a pull towards the enemy's chest, and at full rope length the part of the velocity moving away from the enemy (measured against the enemy's own `current_velocity`) is removed. On the ground (`walking` / `sprinting`) with slack to take up, the state returns `jumping`, the game's own jump, to get airborne. Jump input in the air lets go |
| Toughness | `Toughness.replenish_flat(unit, 20, false, "ability_stance")` |
| Chain | `hanging_chains_long_04` segments from the Cooling toxic gas theme package; sparks until it is loaded |
| Hook model | your `roadhogs-chain-hook.zip` model, compiled with DarktideGLBCompiler to `Custom/hook_head` (0.8 m long, 4174 triangles, textures at 1024) and loaded through Custom Assets |
| Server side | the hook buff is not predicted: the server adds it and ends it, and every machine draws it through its effect template |

## Testing

In the harness with the current game Lua (165 checks pass): all six nodes land in the legacy tree only, Chain Hook leads on to the crit chance node and from there the melee damage node, the 1.10.0 nodes move right once only, nothing sits left of x 515, dragging moves the background sideways within its limits and not outside the talent view, also through the real talent view class, overlapping and crossing nothing; lookups, talents and texts register; charges and Spare Hooks; the hook item is equipped with the ability and never wielded; nothing asks for the local player before the connection is up; the held hook never reads POSITION_LOOKUP outside the gameplay update; the throwing copy runs the wielded weapon's state machine (with its start variables) and plays `ability_knife_throw` at 1.25 while nothing is played on the real first person rig; the visible arms follow the pose rig and go back to the first person unit afterwards; the left arm follows the copy's left arm while raising, stays at the wind-up (0.12 s) while held, the throw is played once and its follow-through kept, on release the arm swings to it within 0.1 s with no replay and stays there, and a tap goes straight through; the right arm equals the real rig's melee pose while both move; the hook is linked to the left hand with its grip in the fist, tilted 45 degrees forward from the forearm (0 when set to 0), and let go on the throw; the chain leaves from the left grip; no arm (hook still drawn) when the weapon's animation is not loaded, has no quick throw, nothing is wielded, or in third person; a posing error turns the arm off and puts the arms back; the press plays only the third person shout; Grapple ties the player to the Ogryn with no catapult, pulls at 30 m/s², at full rope length removes only the moving-away part (sideways speed kept), drags the player with a moving Ogryn, caps speed at 22 m/s, is applied only on the server, pops a grounded player into a jump, reels to 3.5 m, lets go on jump, on a new press and after 8 s, follows the reel, pull, top speed, gravity and jump off sliders, keeps the rope's pull up while falling (the game's own fall speed is switched off for that step and switched back on after), and never staggers or pulls the Ogryn.

**Not tested in game.** Things to watch:
- If the left arm does not move, the chat log says why: "Chain Hook left arm: the wielded weapon's animation is not loaded", "... has no ability_knife_throw", or "Chain Hook left arm turned off:" with the reason.
- The three settings' defaults: if the held hook is out of view, lower "Held arm"; if the arm is gone after the throw, try a "Thrown arm" nearer 0.25; turn the hook with "Hook angle in the hand".
- On other players' machines the hook is thrown at once (they cannot know you are holding it).
- Grapple's rope runs on the server, so it is smooth when you host. Played as a client of someone else's game, your own machine does not predict the rope and you will likely be snapped back and forth while tethered.
- The pull, reel speed, rope length and speed cap are first guesses for the feel; say what to change.
- The hook model's normal map convention and the metal look made from its specular map.
- How bosses react to the stagger, and enemies teleported every frame while staggered.
- The press used to reel still fires the game's "combat ability used" event, so talents that trigger on ability use can trigger on it.
