return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsHorizonMaulShields` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsHorizonMaulShields", {
            mod_script = "QIangIQsHorizonMaulShields/scripts/mods/QIangIQsHorizonMaulShields/QIangIQsHorizonMaulShields",
            mod_data = "QIangIQsHorizonMaulShields/scripts/mods/QIangIQsHorizonMaulShields/QIangIQsHorizonMaulShields_data",
            mod_localization = "QIangIQsHorizonMaulShields/scripts/mods/QIangIQsHorizonMaulShields/QIangIQsHorizonMaulShields_localization",
        })
    end,
    version = "1.0.6",
    author = "QIangIQ",
    packages = {},
}
