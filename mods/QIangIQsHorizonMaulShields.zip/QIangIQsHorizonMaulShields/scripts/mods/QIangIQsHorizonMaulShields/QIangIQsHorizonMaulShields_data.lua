local mod = get_mod("QIangIQsHorizonMaulShields")

local WEAPONS = mod:io_dofile("QIangIQsHorizonMaulShields/scripts/mods/QIangIQsHorizonMaulShields/QIangIQsHorizonMaulShields_weapons")

local CHOICES = {
    { text = "choice_retail", value = "retail" },
    { text = "choice_es01", value = "es01" },
    { text = "choice_bloodrose", value = "bloodrose" },
}

-- one group per weapon family, one dropdown per mark and part (mace / shield), each independent
local widgets = {}

for _, w in ipairs(WEAPONS) do
    local sub = {}

    for _, template in ipairs(w.templates) do
        if w.mace then
            sub[#sub + 1] = { setting_id = template .. "_mace", type = "dropdown", default_value = w.default or "es01", options = table.clone(CHOICES) }
            -- each mace weapon mark: its own fit on top of the shared mace fit
            sub[#sub + 1] = { setting_id = template .. "_mace_scale", type = "numeric", default_value = 1, range = { 0.3, 3 }, decimals_number = 2 }
            sub[#sub + 1] = { setting_id = template .. "_mace_width", type = "numeric", default_value = 1, range = { 0.3, 3 }, decimals_number = 2 }
            sub[#sub + 1] = { setting_id = template .. "_mace_grip", type = "numeric", default_value = 0, range = { -0.5, 0.5 }, decimals_number = 2 }
            sub[#sub + 1] = { setting_id = template .. "_mace_roll", type = "numeric", default_value = 0, range = { -180, 180 }, decimals_number = 0 }
            sub[#sub + 1] = { setting_id = template .. "_mace_tilt", type = "numeric", default_value = 0, range = { -45, 45 }, decimals_number = 0 }
        end

        if w.shield then
            -- each shield weapon mark: its own model choice and its own fit
            sub[#sub + 1] = { setting_id = template .. "_shield", type = "dropdown", default_value = "es01", options = table.clone(CHOICES) }
            sub[#sub + 1] = { setting_id = template .. "_shield_scale", type = "numeric", default_value = 1, range = { 0.3, 2 }, decimals_number = 2 }
            sub[#sub + 1] = { setting_id = template .. "_shield_depth", type = "numeric", default_value = 0, range = { -30, 30 }, decimals_number = 1 }
            sub[#sub + 1] = { setting_id = template .. "_shield_raise", type = "numeric", default_value = 0, range = { -50, 50 }, decimals_number = 1 }
            sub[#sub + 1] = { setting_id = template .. "_shield_turn", type = "checkbox", default_value = false }
        end
    end

    widgets[#widgets + 1] = { setting_id = "group_" .. w.family, type = "group", sub_widgets = sub }
end

widgets[#widgets + 1] = {
    setting_id = "group_fit",
    type = "group",
    sub_widgets = {
        { setting_id = "mace_scale", type = "numeric", default_value = 1, range = { 0.3, 3 }, decimals_number = 2 },
        { setting_id = "mace_fp_scale", type = "numeric", default_value = 1, range = { 0.2, 1.5 }, decimals_number = 2 },
        { setting_id = "mace_grip", type = "numeric", default_value = 0, range = { -0.5, 0.5 }, decimals_number = 2 },
        { setting_id = "mace_roll", type = "numeric", default_value = 0, range = { -180, 180 }, decimals_number = 0 },
        { setting_id = "mace_flip", type = "checkbox", default_value = false },
    },
}

widgets[#widgets + 1] = { setting_id = "menu_previews", type = "checkbox", default_value = true }

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = true,
    options = { widgets = widgets },
}
