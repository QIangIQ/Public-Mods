-- Blunt melee templates (Aussiemon Darktide-Source-Code master, scripts/settings/equipment/weapon_templates; keywords,
-- 3P state machine and damage profiles read 2026-11-01):
--   ogryn_clubs/ogryn_club_p2_m1..m3            bully clubs (ogryn_club_light/heavy_* profiles)
--   ogryn_clubs/ogryn_club_p1_m1..m3            latrine shovels (ogryn_shovel_* profiles)
--   ogryn_power_mauls/ogryn_powermaul_p1_m1..m3 Ogryn power maul
--   ogryn_powermaul_slabshield/*_p1_m1..m2      Ogryn battle maul & slab shield (3P state machine slab_shield)
--   ogryn_hammers_2h/ogryn_hammer_2h_p1_m1      Ogryn two-handed hammer (keyword hammer)
--   ogryn_pickaxes_2h/ogryn_pickaxe_2h_p1_m1..m3 Ogryn pickaxes
--   power_mauls/powermaul_p1_m1..m2             shock maul (power_sword 3P set)
--   power_mauls/powermaul_p2_m1                 Arbites shock maul (adamant_power_maul 3P set)
--   power_mauls/powermaul_p3_m1                 Skitarii arc maul (arc_maul 3P set)
--   power_maul_shields/powermaul_shield_p1_m1..m2  Arbites shock maul & shield (assault_shield_maul)
--   power_mauls_2h/powermaul_2h_p1_m1..m2       two-handed power maul (thunder_hammer 3P set)
--   thunder_hammers_2h/thunderhammer_2h_p1_m1..m2  thunder hammers
--   combat_axes/combataxe_p3_m1..m3             sapper shovels (default_light_shovel / *_shovel_* profiles)
--   crowbars/crowbar_p1_m1                      crowbar
--   shotpistol_shield/shotpistol_shield_p1_m1   Arbites shotpistol & shield (shield only)
-- Not used: combat axes p1/p2 (bladed), saws, gauntlets, blades, swords, knives (REPORT.md lists why).
-- shield = frame key of the retail shield unit (QIangIQsHorizonMaulShields.lua SHIELD_FRAMES).
-- default = default choice of the mace setting (mauls and hammers ES01, tools Retail).
return {
    { family = "bully_club", templates = { "ogryn_club_p2_m1", "ogryn_club_p2_m2", "ogryn_club_p2_m3" }, mace = true },
    { family = "ogryn_power_maul", templates = { "ogryn_powermaul_p1_m1", "ogryn_powermaul_p1_m2", "ogryn_powermaul_p1_m3" }, mace = true },
    { family = "slab_shield", templates = { "ogryn_powermaul_slabshield_p1_m1", "ogryn_powermaul_slabshield_p1_m2" }, mace = true, shield = "slab" },
    { family = "ogryn_hammer_2h", templates = { "ogryn_hammer_2h_p1_m1" }, mace = true },
    { family = "shock_maul", templates = { "powermaul_p1_m1", "powermaul_p1_m2" }, mace = true },
    { family = "arbites_shock_maul", templates = { "powermaul_p2_m1" }, mace = true },
    { family = "arc_maul", templates = { "powermaul_p3_m1" }, mace = true },
    { family = "arbites_shield_maul", templates = { "powermaul_shield_p1_m1", "powermaul_shield_p1_m2" }, mace = true, shield = "assault" },
    { family = "power_maul_2h", templates = { "powermaul_2h_p1_m1", "powermaul_2h_p1_m2" }, mace = true },
    { family = "thunder_hammer", templates = { "thunderhammer_2h_p1_m1", "thunderhammer_2h_p1_m2" }, mace = true },
    { family = "arbites_shotpistol_shield", templates = { "shotpistol_shield_p1_m1" }, shield = "assault" },
    { family = "latrine_shovel", templates = { "ogryn_club_p1_m1", "ogryn_club_p1_m2", "ogryn_club_p1_m3" }, mace = true, default = "retail" },
    { family = "ogryn_pickaxe", templates = { "ogryn_pickaxe_2h_p1_m1", "ogryn_pickaxe_2h_p1_m2", "ogryn_pickaxe_2h_p1_m3" }, mace = true, default = "retail" },
    { family = "sapper_shovel", templates = { "combataxe_p3_m1", "combataxe_p3_m2", "combataxe_p3_m3" }, mace = true, default = "retail" },
    { family = "crowbar", templates = { "crowbar_p1_m1" }, mace = true, default = "retail" },
}
