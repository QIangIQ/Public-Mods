local loc = {
    mod_name = { en = "QIangIQ's Horizon Maul Shields" },
    mod_description = { en = "Horizon Walker weapons over every maul and shield: Tactical Suppression Gear ES01 or Crimson Blood Rose (mace and shield), chosen per weapon mark. Needs Custom Assets for the models; without it the retail look stays. /hwmaul debug shows the fit, /hwmaul tree lists the wielded weapon's parts. By QIangIQ." },
    choice_retail = { en = "Retail" },
    choice_es01 = { en = "Tactical Suppression Gear ES01" },
    choice_bloodrose = { en = "Crimson Blood Rose" },
    group_bully_club = { en = "Ogryn bully clubs" },
    group_ogryn_power_maul = { en = "Ogryn power mauls" },
    group_slab_shield = { en = "Ogryn battle maul & slab shield" },
    group_shock_maul = { en = "Shock mauls" },
    group_arbites_shock_maul = { en = "Arbites shock maul" },
    group_arc_maul = { en = "Skitarii arc maul" },
    group_arbites_shield_maul = { en = "Arbites shock maul & shield" },
    group_power_maul_2h = { en = "Two-handed power mauls" },
    group_arbites_shotpistol_shield = { en = "Arbites shotpistol & shield" },
    group_ogryn_hammer_2h = { en = "Ogryn two-handed hammer" },
    group_thunder_hammer = { en = "Thunder hammers" },
    group_latrine_shovel = { en = "Ogryn latrine shovels" },
    group_ogryn_pickaxe = { en = "Ogryn pickaxes" },
    group_sapper_shovel = { en = "Sapper shovels" },
    group_crowbar = { en = "Crowbar" },
    group_fit = { en = "Mace fit (all weapons)" },
    mace_scale = { en = "Mace length" },
    mace_scale_description = { en = "x the retail weapon's butt-to-head length." },
    mace_fp_scale = { en = "Mace size in first person" },
    mace_grip = { en = "Mace grip" },
    mace_grip_description = { en = "Moves the mace along its shaft, in mace lengths (positive = toward the head)." },
    mace_roll = { en = "Mace spin about the shaft" },
    mace_flip = { en = "Flip mace end to end" },
    menu_previews = { en = "Show in menus (inventory, character previews)" },
}

-- setting names per mark, from the same weapon list the data file uses
local ok, list = pcall(function()
    return get_mod("QIangIQsHorizonMaulShields"):io_dofile("QIangIQsHorizonMaulShields/scripts/mods/QIangIQsHorizonMaulShields/QIangIQsHorizonMaulShields_weapons")
end)
local WEAPONS = ok and list or {}

local MARK = { m1 = "Mk 1", m2 = "Mk 2", m3 = "Mk 3" }

for _, w in ipairs(WEAPONS) do
    for _, template in ipairs(w.templates) do
        local mark = MARK[template:match("_(m%d+)$")] or template

        if w.mace then
            loc[template .. "_mace"] = { en = mark .. " mace (" .. template .. ")" }
            loc[template .. "_mace_scale"] = { en = mark .. " mace length" }
            loc[template .. "_mace_width"] = { en = mark .. " mace thickness" }
            loc[template .. "_mace_width_description"] = { en = "x the default thickness (matched to the retail head and shaft sizes). This weapon only." }
            loc[template .. "_mace_grip"] = { en = mark .. " mace grip shift" }
            loc[template .. "_mace_grip_description"] = { en = "Moves the mace along its shaft, in mace lengths (positive = toward the head). This weapon only." }
            loc[template .. "_mace_roll"] = { en = mark .. " mace spin about the shaft" }
            loc[template .. "_mace_tilt"] = { en = mark .. " mace tilt" }
        end

        if w.shield then
            loc[template .. "_shield"] = { en = mark .. " shield (" .. template .. ")" }
            loc[template .. "_shield_scale"] = { en = mark .. " shield size" }
            loc[template .. "_shield_scale_description"] = { en = "x the retail shield's height, this weapon only." }
            loc[template .. "_shield_depth"] = { en = mark .. " shield distance from the arm (cm)" }
            loc[template .. "_shield_raise"] = { en = mark .. " shield height offset (cm)" }
            loc[template .. "_shield_turn"] = { en = mark .. " shield turned around" }
        end
    end
end

return loc
