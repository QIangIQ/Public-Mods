-- QIangIQ's Horizon Maul Shields: Horizon Walker MuYingying weapons (Tactical Suppression Gear ES01, Crimson Blood Rose)
-- over every retail maul and shield, chosen per weapon mark (QIangIQsHorizonMaulShields_weapons.lua).
-- Models are Custom Assets units built in the horizon_maul_shields build folder (bake_hw.py, build_units.py).
-- Spawning, fitting, records and menu previews follow QIangIQsHorizonStaffs 1.3.1 (QIangIQsSpearArsenal 2.2 fit);
-- the shield goes on the retail shield unit the way QIangIQsSwordShield 0.6.x puts its heater there.
-- Standalone: Custom Assets is optional (without it the retail look stays and a log line says so).
-- Only the local player's own weapons are changed; other players keep the retail look.
-- Author: QIangIQ
local mod = get_mod("QIangIQsHorizonMaulShields")

mod.AUTHOR = "QIangIQ"

local WEAPONS = mod:io_dofile("QIangIQsHorizonMaulShields/scripts/mods/QIangIQsHorizonMaulShields/QIangIQsHorizonMaulShields_weapons")

-- template -> { mace = bool, shield = frame key }
local TEMPLATES = {}

for _, w in ipairs(WEAPONS) do
    for _, template in ipairs(w.templates) do
        TEMPLATES[template] = { mace = w.mace, shield = w.shield, default = w.default or "es01" }
    end
end

-- Retail shield units in their own frame (+x front face, z up, y width), measured from the decoded units with the
-- Map Viewer pipeline (build/probe_retail.py, renders/contact_retail_frames.png):
--   assault: content/weapons/player/shields/assault_shield/attachments/assault_shield_01/assault_shield_01
--            x -0.096..0.145, y -0.196..0.428, z -0.599..0.405 (QIangIQsSwordShield probe4/probe8 agree)
--   slab:    content/weapons/player/shields/ogryn_slab_shield/wpn_ogryn_slab_shield_chained_rig
--            x -0.205..0.352, y -0.516..0.994, z -1.511..0.793
-- The Horizon shields are built front face at x = 0, centred on y/z, height 1 (build_units.py normalise_shield).
local SHIELD_FRAMES = {
    assault = { front = 0.145, y = 0.116, z = -0.097, height = 1.004 },
    slab = { front = 0.352, y = 0.239, z = -0.359, height = 2.304 },
}

-- Custom folder = asset id "<Mod>:<folder>", unit path = --asset-path at compile time
local MODELS = { "es01_mace", "es01_shield", "bloodrose_mace", "bloodrose_shield" }

local function asset_id(key)
    return "QIangIQsHorizonMaulShields:" .. key
end

local function unit_path(key)
    return "content/mods/qiangiq_hwmaul/" .. key
end

local loaded = {}
local mod_on = true

local FIT_FRAMES = 10
local REFIT_EVERY = 20 -- lesson-weapon-fit-stale-at-spawn: refit every 20th frame as well
local fit_generation = 0

local tracked = setmetatable({}, { __mode = "k" })
local tracked_ui = setmetatable({}, { __mode = "k" })
local tracked_wpn = setmetatable({}, { __mode = "k" })

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

-- "es01" / "bloodrose" when that part of this template is replaced and its model is loaded, else nil
local function choice(template, part)
    local cfg = TEMPLATES[template]

    if not (mod_on and cfg and cfg[part]) then
        return nil
    end

    local v = mod:get(template .. "_" .. part)

    if v == nil then
        v = part == "mace" and cfg.default or "es01"
    end

    if (v == "es01" or v == "bloodrose") and loaded[v .. "_" .. part] then
        return v
    end

    return nil
end

-- Item trees -----------------------------------------------------------------------------------------------------
-- Live items: item.attachments[name] = { item = <path or item table>, children = { ... } }. QIangIQsSwordShield
-- (console dump 2026-10-25): powermaul_shield_p1_m1 has left = the whole shield item, right = powermaul_p1_empty with
-- the maul parts under it. Units are matched to items through slot.item_name_by_unit_1p/3p
-- (equipment_component.lua:300/346).

local function item_name(it)
    if type(it) == "table" then
        return it.name
    end

    return it
end

local function collect(attachments, out)
    if type(attachments) ~= "table" then
        return
    end

    for _, a in pairs(attachments) do
        if type(a) == "table" then
            local n = item_name(a.item)

            if type(n) == "string" and n ~= "" then
                out[n] = true
            end

            collect(a.children, out)

            if type(a.item) == "table" then
                collect(a.item.attachments, out)
            end
        end
    end
end

-- names of every item in attachment slot `slot_name` of the item (that item and everything under it), and its own name
local function subtree(item, slot_name)
    local a = item and item.attachments and item.attachments[slot_name]

    if type(a) ~= "table" then
        return nil, nil
    end

    local out = {}
    local top = item_name(a.item)

    if type(top) == "string" and top ~= "" then
        out[top] = true
    end

    collect(a.children, out)

    if type(a.item) == "table" then
        collect(a.item.attachments, out)
    end

    return out, top
end

-- shield units (set), shield root unit, right-hand root unit; nil where not found
local function split_units(item, names)
    if not names then
        return nil, nil, nil
    end

    local shield_set, shield_top = subtree(item, "left")
    local right_set, right_top = subtree(item, "right")
    local shields, shield_root, right_root, rights = {}, nil, nil, {}

    for unit, name in pairs(names) do
        if unit_ok(unit) then
            if shield_set and shield_set[name] then
                shields[unit] = true

                if name == shield_top and not shield_root then
                    shield_root = unit
                end
            elseif right_set and right_set[name] then
                rights[unit] = true

                if name == right_top and not right_root then
                    right_root = unit
                end
            end
        end
    end

    return shield_root and shields or nil, shield_root, right_root, right_root and rights or nil
end

-- Mace fit ---------------------------------------------------------------------------------------------------------
-- Retail maul and club parts run along their unit's local +z with the origin at the grip (decoded units, build/
-- probe of power_maul shaft_01 z -0.169..0.394, head_01 z 0..1.022, club_pipe_01..03 z -0.31..1.38). The fit works
-- in the grip unit's local frame only, so the result does not depend on the animation pose:
--   * direction = the grip unit's local axis nearest to the hand -> farthest piece (always snapped);
--   * up = a fixed local axis (z, else x), so it cannot swap between two near-equal axes from frame to frame
--     (1.0.x picked the "least aligned" world axis every refit: the mace head turned 90 degrees between frames);
--   * pieces = the right-hand subtree only when the item has one (1.0.x also counted the item root and aimed the
--     Arbites shield maul's mace toward it, hard to the left).
-- Unit.box: centres and largest half-extent only (hard-rules-and-tips).

-- Thickness (2026-11-01, user: "the 2h powermaul or arbites has the handle too large and blocks my view"): 1.0.3 scaled
-- the mace uniformly by the retail reach, so on long weapons its head and shaft grew far past the retail ones. Now the
-- length follows the reach, and the cross-section scale is the smaller of retail head width / model head width and
-- retail shaft thickness / model shaft thickness, so neither is ever bigger than retail.
-- Retail sizes in metres, from the decoded first variant of each family (build/retail_maul_sizes.json; shaft = middle
-- 40 % of the shaft or grip unit, head = widest cross-section of the head unit). Template -> unit folder is inferred
-- from the folder names and sizes (human_power_maul = shock maul, human_power_maul_short = Arbites, power_maul = Ogryn).
local RETAIL_SIZE = {
    powermaul_p1 = { head = 0.166, shaft = 0.036 },            -- human_power_maul
    powermaul_p2 = { head = 0.142, shaft = 0.109 },            -- human_power_maul_short
    powermaul_shield_p1 = { head = 0.142, shaft = 0.109 },     -- human_power_maul_short
    powermaul_p3 = { head = 0.116, shaft = 0.062 },            -- arc_maul deluxe01
    powermaul_2h_p1 = { head = 0.185, shaft = 0.047 },         -- 2h_power_maul (grip_07)
    thunderhammer_2h_p1 = { head = 0.307, shaft = 0.038 },     -- thunder_hammer
    ogryn_powermaul_p1 = { head = 0.254, shaft = 0.199 },      -- power_maul
    ogryn_powermaul_slabshield_p1 = { head = 0.254, shaft = 0.199 },
    ogryn_hammer_2h_p1 = { head = 0.675, shaft = 0.117 },      -- 2h_hammer_ogryn
    ogryn_pickaxe_2h_p1 = { head = 0.6, shaft = 0.132 },       -- 2h_pickaxe_ogryn (head capped: the pick spans 1.56 m)
    ogryn_club_p2 = { head = 0.364, shaft = 0.235 },           -- club_pipe_01..03
    ogryn_club_p1 = { head = 0.735, shaft = 0.114 },           -- shovel_ogryn
    combataxe_p3 = { head = 0.169, shaft = 0.038 },            -- shovel
    crowbar_p1 = { head = 0.2, shaft = 0.073 },                -- crowbar_01
}
-- Horizon maces, in model lengths (build/mace_profile.py): widest head band, shaft core
local MODEL_SIZE = {
    es01 = { head = 0.235, shaft = 0.075 },
    bloodrose = { head = 0.249, shaft = 0.04 },
}

local function cross_scale(template, model)
    local r = template and RETAIL_SIZE[template:gsub("_m%d+$", "")]
    local m = MODEL_SIZE[model]

    if not (r and m) then
        return nil
    end

    return math.min(r.head / m.head, r.shaft / m.shaft)
end

local function fmt(v)
    return string.format("(%.3f, %.3f, %.3f)", v.x, v.y, v.z)
end

local last_fit = {}
-- unit axis i as a fresh Vector3 (Vector3 values are frame temporaries: one stored in a module table at load turned
-- into stale userdata, "bad argument #1 to '__mul' (Vector3 expected, got userdata)", 1.0.5)
local function axis_vec(i)
    return Vector3(i == 1 and 1 or 0, i == 2 and 1 or 0, i == 3 and 1 or 0)
end

local function mace_parts(origin_unit, units, keep, skip)
    local parts = {}

    local function add(unit)
        if unit_ok(unit) and not (skip and skip[unit]) and (not keep or keep[unit] or unit == origin_unit) then
            local pose, ext = Unit.box(unit)

            if pose and ext then
                local half = math.max(ext.x, ext.y, ext.z)

                if half > 0.005 then
                    parts[#parts + 1] = { center = Matrix4x4.translation(pose), half = half }
                end
            end
        end
    end

    add(origin_unit)

    for i = 1, #units do
        if units[i] ~= origin_unit then
            add(units[i])
        end
    end

    return parts
end

local function tget(template, key, default)
    local v = template and mod:get(template .. "_" .. key)

    if v == nil then
        return default
    end

    return v
end

local function fit_mace(mace, template, model, origin_unit, units, keep, skip, parent_scale, view, first_person)
    local parts = mace_parts(origin_unit, units, keep, skip)

    if #parts == 0 then
        return false
    end

    local origin = Unit.world_position(origin_unit, 1)
    local base_rot = Unit.world_rotation(origin_unit, 1)
    local bx, by, bz = Quaternion.right(base_rot), Quaternion.forward(base_rot), Quaternion.up(base_rot)

    local function to_local(v)
        return Vector3(Vector3.dot(v, bx), Vector3.dot(v, by), Vector3.dot(v, bz))
    end

    local far_d, far_c = 0, nil

    for i = 1, #parts do
        parts[i].lc = to_local(parts[i].center - origin)

        local d = Vector3.length_squared(parts[i].lc)

        if d > far_d then
            far_d, far_c = d, parts[i].lc
        end
    end

    if not far_c or far_d < 0.0001 then
        return false
    end

    -- snapped local shaft axis
    local comp = { far_c.x, far_c.y, far_c.z }
    local a = 1

    for i = 2, 3 do
        if math.abs(comp[i]) > math.abs(comp[a]) then
            a = i
        end
    end

    local sign = comp[a] < 0 and -1 or 1
    local quality = math.abs(comp[a]) / math.sqrt(far_d)

    if mod:get("mace_flip") then
        sign = -sign
    end

    local axis = axis_vec(a) * sign
    local t_min, t_max = 0, 0

    for i = 1, #parts do
        local lc = parts[i].lc
        local t = ({ lc.x, lc.y, lc.z })[a] * sign

        t_min = math.min(t_min, t - parts[i].half)
        t_max = math.max(t_max, t + parts[i].half)
    end

    local length = t_max - t_min

    if length <= 0 then
        return false
    end

    local ls = (mod:get("mace_scale") or 1) * tget(template, "mace_scale", 1) * (first_person and (mod:get("mace_fp_scale") or 1) or 1)
    local s_world = length * ls
    local shift = (mod:get("mace_grip") or 0) + tget(template, "mace_grip", 0)

    -- fixed up axis: local z, or local x when the shaft runs along z
    local up = a == 3 and axis_vec(1) or axis_vec(3)
    local dir = axis
    local roll = math.rad((mod:get("mace_roll") or 0) + tget(template, "mace_roll", 0))

    if roll ~= 0 then
        local side = Vector3.cross(dir, up)

        up = up * math.cos(roll) + side * math.sin(roll)
    end

    local tilt = math.rad(tget(template, "mace_tilt", 0))

    if tilt ~= 0 then
        local side = Vector3.cross(dir, up)

        dir = Vector3.normalize(dir * math.cos(tilt) + side * math.sin(tilt))
    end

    local k = parent_scale and parent_scale > 0 and parent_scale or 1
    local local_pos = dir * ((t_min * ls - shift * s_world) / k)

    Unit.set_local_position(mace, 1, local_pos)
    Unit.set_local_rotation(mace, 1, Quaternion.look(dir, up))
    -- length along the shaft (model +y) = retail reach; thickness from the retail head / shaft sizes
    local overall = (mod:get("mace_scale") or 1) * tget(template, "mace_scale", 1) * (first_person and (mod:get("mace_fp_scale") or 1) or 1)
    local cs = cross_scale(template, model)
    local s_cross = cs and cs * overall * tget(template, "mace_width", 1) or s_world

    Unit.set_local_scale(mace, 1, Vector3(s_cross / k, s_world / k, s_cross / k))

    if view then
        last_fit[view] = string.format("%s %s: %d pieces, shaft = local %s%s (%.2f of hand->farthest), length %.3f (hand at %.2f), start %s",
            view, tostring(template), #parts, sign < 0 and "-" or "+", ({ "x", "y", "z" })[a], quality, length, -t_min / length, fmt(local_pos))
    end

    return true
end

-- Shield placement in the retail shield unit's frame; every shield weapon mark has its own fit settings
local function place_shield(shield, frame_key, template, view)
    local f = SHIELD_FRAMES[frame_key]
    local h = f.height * (mod:get(template .. "_shield_scale") or 1)
    local depth = (mod:get(template .. "_shield_depth") or 0) / 100
    local raise = (mod:get(template .. "_shield_raise") or 0) / 100
    local turn = mod:get(template .. "_shield_turn")
    local x = f.front + depth

    Unit.set_local_position(shield, 1, Vector3(x, f.y, f.z + raise))
    Unit.set_local_rotation(shield, 1, turn and Quaternion(Vector3(0, 0, 1), math.pi) or Quaternion.identity())
    Unit.set_local_scale(shield, 1, Vector3(h, h, h))

    if view then
        last_fit[view .. ":shield"] = string.format("%s shield (%s frame): front x %.3f, centre y %.3f z %.3f, height %.3f%s",
            view, frame_key, x, f.y, f.z + raise, h, turn and ", turned" or "")
    end
end

-- Records: one table per (holder, slot, view); rec.mace / rec.shield = { unit, parent, model } ----------------------

local function drop_part(rec, part, destroy_fn)
    local p = rec[part]

    if p then
        destroy_fn(p.unit)
        rec[part] = nil
    end
end

-- spawns or keeps the custom unit of one part; returns its unit or nil
local function ensure_part(rec, part, model, parent, spawn_fn, destroy_fn, first_person)
    local p = rec[part]

    if p and (p.model ~= model or p.parent ~= parent or not unit_ok(p.unit)) then
        drop_part(rec, part, destroy_fn)
        p = nil
    end

    if not model or not unit_ok(parent) then
        return nil
    end

    if not p then
        local unit = spawn_fn(parent, unit_path(model .. "_" .. part))

        if not unit then
            return nil
        end

        if first_person then
            Unit.set_shader_pass_flag_for_meshes_in_unit_and_childs(unit, "custom_fov", true)
        end

        p = { unit = unit, parent = parent, model = model, frames = 0 }
        rec[part] = p
    end

    return p
end

-- slot view: { base, attachments, names, item, visible }
local function sync_view(records, key, view, spawn_fn, destroy_fn, parent_scale, first_person)
    local rec = records[key]
    local base, attachments, item = view.base, view.attachments, view.item
    local template = item and item.weapon_template
    local cfg = TEMPLATES[template]
    local mace_model = unit_ok(base) and attachments and choice(template, "mace")
    local shield_model = unit_ok(base) and attachments and choice(template, "shield")
    local shields, shield_root, right_root, rights

    if (mace_model or shield_model) and view.names then
        shields, shield_root, right_root, rights = split_units(item, view.names)
    end

    if cfg and cfg.shield and (mace_model or shield_model) then
        if not shield_root then
            -- the shield cannot be told apart from the weapon here (no unit -> item map, or another tree):
            -- keep the retail weapon rather than guess
            mace_model, shield_model = nil, nil
        end
    end

    if not rec then
        if not (mace_model or shield_model) then
            return
        end

        rec = {}
        records[key] = rec
    end

    if rec.base ~= base then
        drop_part(rec, "mace", destroy_fn)
        drop_part(rec, "shield", destroy_fn)
        rec.base = base
        rec.hid = false
        rec.mace_hid = false
    end

    local mace_parent = right_root or base
    local mace = ensure_part(rec, "mace", mace_model or nil, mace_parent, spawn_fn, destroy_fn, first_person)
    local shield = ensure_part(rec, "shield", shield_model or nil, shield_root, spawn_fn, destroy_fn, first_person)

    if not mace and not shield then
        records[key] = nil

        if rec.hid and unit_ok(base) and view.visible then
            Unit.set_unit_visibility(base, true, true)
        end

        return
    end

    if mace then
        local count = #attachments

        if mace.count ~= count or mace.gen ~= fit_generation then
            mace.count, mace.gen, mace.frames = count, fit_generation, 0
        end

        mace.frames = mace.frames + 1

        if mace.frames <= FIT_FRAMES or mace.frames % REFIT_EVERY == 0 then
            local parent_s = Unit.local_scale(mace_parent, 1)
            local k = (parent_scale or 1) * (parent_s and parent_s.x or 1)

            if fit_mace(mace.unit, template, mace.model, mace_parent, attachments, rights, shields, k, key, first_person) then
                mace.fitted = true
            end
        end
    end

    if shield and (shield.gen ~= fit_generation) then
        shield.gen = fit_generation
        place_shield(shield.unit, cfg.shield, template, key)
    end

    -- visibility: the game's slot visibility first, then retail parts off where replaced, then the custom units
    -- (recursive visibility reaches linked units, so the custom units are set last)
    if not view.visible then
        if mace then
            Unit.set_unit_visibility(mace.unit, false, true)
        end

        if shield then
            Unit.set_unit_visibility(shield.unit, false, true)
        end

        return
    end

    local mace_on = mace and mace.fitted

    if mace_on then
        Unit.set_unit_visibility(base, false, true)

        if shield_root and not shield then
            Unit.set_unit_visibility(shield_root, true, true)
        end

        rec.mace_hid = true
    elseif rec.mace_hid then
        -- mace switched back to retail: the retail weapon once, then only the shield is handled
        Unit.set_unit_visibility(base, true, true)
        rec.mace_hid = false
    end

    if shield then
        Unit.set_unit_visibility(shield_root, false, true)
        Unit.set_unit_visibility(shield.unit, true, true)
    end

    if mace then
        Unit.set_unit_visibility(mace.unit, mace_on and true or false, true)
    end

    rec.hid = true
end

local function clear_records(records, destroy_fn)
    if not records then
        return
    end

    for key, rec in pairs(records) do
        drop_part(rec, "mace", destroy_fn)
        drop_part(rec, "shield", destroy_fn)
        records[key] = nil
    end
end

-- In game --------------------------------------------------------------------------------------------------------

local function local_player()
    local players = Managers.player

    if not players then
        return nil
    end

    local ok, player = pcall(players.local_player_safe, players, 1)

    return ok and player or nil
end

local function ingame_spawn(ext, first_person)
    return function(parent, path)
        local world = ext.__qiangiq_hwmaul_world
        local unit_spawner = Managers.state and Managers.state.unit_spawner

        if not (world and unit_spawner) then
            return nil
        end

        local unit = unit_spawner:spawn_unit(path, Unit.world_pose(parent, 1))

        if not unit then
            return nil
        end

        if first_person then
            Unit.set_unit_culling(unit, false)
        end

        World.link_unit(world, unit, 1, parent, 1, World.LINK_MODE_NONE)

        return unit
    end
end

local function ingame_destroy(unit)
    if unit_ok(unit) then
        local unit_spawner = Managers.state and Managers.state.unit_spawner

        if unit_spawner then
            unit_spawner:mark_for_deletion(unit)
        end
    end
end

local function ingame_apply(ext)
    local records = ext.__qiangiq_hwmaul_records

    if not records then
        records = {}
        ext.__qiangiq_hwmaul_records = records
    end

    local equipment = ext._equipment

    if not equipment then
        return
    end

    for slot_name, slot in pairs(equipment) do
        local item = slot.item
        local key3, key1 = slot_name .. ":3p", slot_name .. ":1p"

        if item and TEMPLATES[item.weapon_template] or records[key3] or records[key1] then
            local base_3p, base_1p = slot.unit_3p, slot.unit_1p

            sync_view(records, key3, {
                base = base_3p,
                attachments = base_3p and slot.attachments_by_unit_3p and slot.attachments_by_unit_3p[base_3p],
                names = slot.item_name_by_unit_3p,
                item = item,
                visible = slot.hidden_3p == false,
            }, ingame_spawn(ext, false), ingame_destroy, 1, false)
            sync_view(records, key1, {
                base = base_1p,
                attachments = base_1p and slot.attachments_by_unit_1p and slot.attachments_by_unit_1p[base_1p],
                names = slot.item_name_by_unit_1p,
                item = item,
                visible = slot.hidden_1p == false,
            }, ingame_spawn(ext, true), ingame_destroy, 1, true)
        end
    end
end

local function is_mine(ext)
    local me = local_player()

    return me ~= nil and ext._player == me
end

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "init", function(self, extension_init_context)
    self.__qiangiq_hwmaul_world = extension_init_context and extension_init_context.world
end)

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "_update_item_visibility", function(self)
    if not is_mine(self) then
        return
    end

    tracked[self] = true
    ingame_apply(self)
end)

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "update", function(self)
    if tracked[self] then
        ingame_apply(self)
    end
end)

mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, "_unequip_item_from_slot", function(func, self, slot_name, ...)
    local records = self.__qiangiq_hwmaul_records

    if records then
        for _, view in ipairs({ ":3p", ":1p" }) do
            local rec = records[slot_name .. view]

            if rec then
                drop_part(rec, "mace", ingame_destroy)
                drop_part(rec, "shield", ingame_destroy)
                records[slot_name .. view] = nil
            end
        end
    end

    return func(self, slot_name, ...)
end)

mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, "destroy", function(func, self, ...)
    clear_records(self.__qiangiq_hwmaul_records, ingame_destroy)
    tracked[self] = nil

    return func(self, ...)
end)

-- Menu previews (QIangIQsHorizonStaffs) ---------------------------------------------------------------------------

local function ui_profile_is_mine(profile)
    if not profile then
        return false
    end

    local players = Managers.player and Managers.player:players()
    local me = local_player()

    if players and profile.character_id then
        for _, player in pairs(players) do
            if player ~= me and player.character_id and player:character_id() == profile.character_id then
                return false
            end
        end
    end

    return true
end

local function ui_spawn(world)
    return function(parent, path)
        local unit = World.spawn_unit_ex(world, path, nil, Unit.world_pose(parent, 1))

        World.link_unit(world, unit, 1, parent, 1, World.LINK_MODE_NONE)

        return unit
    end
end

local function ui_destroy_fn(world)
    return function(unit)
        if unit_ok(unit) and world then
            World.destroy_unit(world, unit)
        end
    end
end

local function scale_x(unit)
    if unit_ok(unit) then
        local s = Unit.local_scale(unit, 1)

        return s and s.x or 1
    end

    return 1
end

local function profile_apply(spawner)
    local world = spawner._world
    local records = spawner.__qiangiq_hwmaul_records

    if not records then
        records = {}
        spawner.__qiangiq_hwmaul_records = records
    end

    local data = spawner._character_spawn_data
    local allowed = data and data.slots and mod:get("menu_previews") ~= false and ui_profile_is_mine(data.profile)

    if not allowed then
        clear_records(records, ui_destroy_fn(world))

        return
    end

    tracked_ui[spawner] = true

    local k = scale_x(data.unit_3p)

    for slot_name, slot in pairs(data.slots) do
        local item = slot.item

        if item and TEMPLATES[item.weapon_template] or records[slot_name] then
            local base = slot.unit_3p

            sync_view(records, slot_name, {
                base = base,
                attachments = base and slot.attachments_by_unit_3p and slot.attachments_by_unit_3p[base],
                names = slot.item_name_by_unit_3p,
                item = item,
                visible = spawner._visible and slot.hidden_3p == false,
            }, ui_spawn(world), ui_destroy_fn(world), k, false)
        end
    end
end

mod:hook_safe(CLASS.UIProfileSpawner, "_update_items_visibility", function(self)
    profile_apply(self)
end)

mod:hook_safe(CLASS.UIProfileSpawner, "update", function(self)
    local data = self._character_spawn_data

    if data and data.is_ready then
        profile_apply(self)
    elseif self.__qiangiq_hwmaul_records then
        clear_records(self.__qiangiq_hwmaul_records, ui_destroy_fn(self._world))
    end
end)

mod:hook(CLASS.UIProfileSpawner, "_despawn_current_character_profile", function(func, self, ...)
    clear_records(self.__qiangiq_hwmaul_records, ui_destroy_fn(self._world))

    return func(self, ...)
end)

local function weapon_apply(spawner)
    local world = spawner._world
    local records = spawner.__qiangiq_hwmaul_records

    if not records then
        records = {}
        spawner.__qiangiq_hwmaul_records = records
    end

    local data = spawner._weapon_spawn_data

    if not (data and mod:get("menu_previews") ~= false) then
        if next(records) ~= nil then
            clear_records(records, ui_destroy_fn(world))

            if data and data.visible and unit_ok(data.item_unit_3p) then
                Unit.set_unit_visibility(data.item_unit_3p, true, true)
            end
        end

        return
    end

    tracked_wpn[spawner] = true

    local base = data.item_unit_3p

    sync_view(records, "weapon", {
        base = base,
        attachments = base and data.attachment_units_3p and data.attachment_units_3p[base],
        names = data.item_name_by_unit_3p,
        item = data.item,
        visible = data.visible and true or false,
    }, ui_spawn(world), ui_destroy_fn(world), scale_x(data.link_unit), false)
end

mod:hook_safe(CLASS.UIWeaponSpawner, "update", function(self)
    weapon_apply(self)
end)

mod:hook(CLASS.UIWeaponSpawner, "_despawn_current_weapon", function(func, self, ...)
    clear_records(self.__qiangiq_hwmaul_records, ui_destroy_fn(self._world))

    return func(self, ...)
end)

-- Refresh ---------------------------------------------------------------------------------------------------------

local function refresh_all()
    for ext in pairs(tracked) do
        if unit_ok(ext._unit) then
            ingame_apply(ext)
            ext:force_update_item_visibility()
        end
    end

    for spawner in pairs(tracked_ui) do
        profile_apply(spawner)

        if spawner._character_spawn_data and spawner._visible then
            spawner:_update_items_visibility()
        end
    end

    for spawner in pairs(tracked_wpn) do
        weapon_apply(spawner)
    end
end

local function remove_all()
    for ext in pairs(tracked) do
        clear_records(ext.__qiangiq_hwmaul_records, ingame_destroy)
    end

    for spawner in pairs(tracked_ui) do
        clear_records(spawner.__qiangiq_hwmaul_records, ui_destroy_fn(spawner._world))
    end

    for spawner in pairs(tracked_wpn) do
        clear_records(spawner.__qiangiq_hwmaul_records, ui_destroy_fn(spawner._world))
    end
end

-- Debug -----------------------------------------------------------------------------------------------------------

local function tree_lines(attachments, depth, out)
    if type(attachments) ~= "table" or depth > 6 then
        return
    end

    for name, a in pairs(attachments) do
        if type(a) == "table" then
            out[#out + 1] = string.rep("  ", depth) .. tostring(name) .. " = " .. tostring(item_name(a.item))
            tree_lines(a.children, depth + 1, out)

            if type(a.item) == "table" then
                tree_lines(a.item.attachments, depth + 1, out)
            end
        end
    end
end

mod:command("hwmaul", "Horizon Maul Shields: /hwmaul debug (fit), /hwmaul tree (wielded weapon's item tree and units)", function(which)
    if which == "tree" then
        for ext in pairs(tracked) do
            for slot_name, slot in pairs(ext._equipment or {}) do
                local item = slot.item

                if item and TEMPLATES[item.weapon_template] then
                    local out = {}

                    tree_lines(item.attachments, 1, out)
                    mod:echo("%s: %s", slot_name, tostring(item.weapon_template))
                    mod:info("%s: %s (%s)\n%s", slot_name, tostring(item.weapon_template), tostring(item.name), table.concat(out, "\n"))

                    local names, amap = slot.item_name_by_unit_3p or {}, slot.attachment_map_by_unit_3p or {}
                    local n = 0

                    for unit, name in pairs(names) do
                        n = n + 1
                        mod:info("  3p unit %s: item %s, attachment %s", tostring(unit), tostring(name), tostring(amap[unit]))
                    end

                    local _, shield_root, right_root = split_units(item, slot.item_name_by_unit_3p)

                    mod:echo("  %d units, shield %s, right hand %s (full tree in the console log)", n,
                        shield_root and "found" or "not found", right_root and "found" or "not found")
                end
            end
        end

        return
    end

    local any = false

    for _, line in pairs(last_fit) do
        mod:echo(line)
        any = true
    end

    local list = {}

    for _, key in ipairs(MODELS) do
        list[#list + 1] = key .. (loaded[key] and " ok" or " not loaded")
    end

    mod:echo("models: %s", table.concat(list, ", "))

    if not any then
        mod:echo("Nothing fitted yet: wield a maul or shield weapon.")
    end
end)

-- Other QIangIQ mods that replace the same weapons: only one mod shows a weapon at a time. Same pattern as
-- QIangIQsMeleeArsenal (OTHER_SETTINGS + claim_template + mod.release_template; "the later one in the list keeps it"
-- at load, QIangIQsHorizonStaffs claim_pending). Switching a weapon on here switches it off there, and their
-- release_template call switches it to Retail here. Every mod is optional (get_mod).
local OTHER_SETTINGS = {
    { "QIangIQsVerdictAxe", "replace_weapon", "ogryn_club_p2_m3" },
    { "QIangIQsSteelKanabo", "replace_mk1", "ogryn_club_p2_m1" },
    { "QIangIQsSteelKanabo", "replace_mk2", "ogryn_club_p2_m2" },
    { "QIangIQsSteelKanabo", "replace_mk3", "ogryn_club_p2_m3" },
}
-- QIangIQsMMJBat (powermaul_p1_m1/m2, 0.1.1+) and the per-weapon-profile mods answer release_template
local RELEASE_MODS = { "QIangIQsMMJBat", "QIangIQsMeleeArsenal", "QIangIQsSkullRuneblade", "QIangIQsWarframeArsenal",
    "QIangIQsButterflyKnife", "QIangIQsKarambit" }

local function part_on(template, part)
    local cfg = TEMPLATES[template]

    if not (cfg and cfg[part]) then
        return false
    end

    local v = mod:get(template .. "_" .. part)

    if v == nil then
        v = part == "mace" and cfg.default or "es01"
    end

    return v == "es01" or v == "bloodrose"
end

local function claim_template(template)
    for _, o in ipairs(OTHER_SETTINGS) do
        if o[3] == template then
            local other = get_mod(o[1])

            if other and other:get(o[2]) then
                other:set(o[2], false, true)
            end
        end
    end

    for _, name in ipairs(RELEASE_MODS) do
        local other = get_mod(name)

        if other and other.release_template then
            pcall(other.release_template, template)
        end
    end
end

local claim_pending = true

-- called by the other mods when they switch this weapon on: both parts go back to Retail here
mod.release_template = function(template)
    if claim_pending or not TEMPLATES[template] then
        return
    end

    local changed = false

    for _, part in ipairs({ "mace", "shield" }) do
        if part_on(template, part) then
            mod:set(template .. "_" .. part, "retail", false)
            changed = true
        end
    end

    if changed then
        fit_generation = fit_generation + 1
        refresh_all()
        mod:echo("%s is now shown by another QIangIQ mod: set to Retail in Horizon Maul Shields.", template)
    end
end

-- Settings and lifecycle ------------------------------------------------------------------------------------------

mod.on_setting_changed = function(setting_id)
    local template, part = nil, nil

    if type(setting_id) == "string" then
        template, part = setting_id:match("^(.+)_(mace)$")

        if not template then
            template, part = setting_id:match("^(.+)_(shield)$")
        end
    end

    if template and TEMPLATES[template] and part_on(template, part) then
        claim_template(template)
    end

    fit_generation = fit_generation + 1
    refresh_all()
end

-- at load: this mod is the later one in mod_load_order.txt, so it keeps the weapons it has switched on. The claim
-- waits for the first frame, after every mod has read its settings (QIangIQsHorizonStaffs mod.update).
mod.update = function()
    if claim_pending then
        claim_pending = false

        if mod_on then
            for template in pairs(TEMPLATES) do
                if part_on(template, "mace") or part_on(template, "shield") then
                    claim_template(template)
                end
            end
        end
    end
end

-- Custom Assets API 1, the QIangIQsSwordShield acquire call. Optional (user rule: no other mod is needed).
local function acquire(key)
    local id = asset_id(key)
    local custom_assets = get_mod("CustomAssets")

    if not custom_assets or not custom_assets.is_api_compatible or not custom_assets.is_api_compatible(1) then
        mod:info("Custom Assets (API 1) is not installed: %s is not shown, the retail look stays", id)

        return
    end

    local ticket, err = custom_assets.acquire(mod, id, function(_, _, load_error)
        if load_error then
            mod:info("%s did not load: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", id, tostring(load_error))

            return
        end

        loaded[key] = true
        mod:info("%s loaded", id)
        refresh_all()
    end, { resident = true, reference_name = id })

    if not ticket then
        mod:info("%s could not be requested: %s", id, tostring(err))
    end
end

mod.on_all_mods_loaded = function()
    for _, key in ipairs(MODELS) do
        acquire(key)
    end

    -- optional: QIangIQsArmoryVis stowed copies show the skins too (its register() contract, as QIangIQsSwordShield
    -- 0.6.5; this mod is not in its KNOWN_REPLACERS list)
    local armory_vis = get_mod("QIangIQsArmoryVis")

    if armory_vis and armory_vis.register and mod.armory_vis then
        armory_vis.register("QIangIQsHorizonMaulShields", mod.armory_vis)
    end
end

mod.on_disabled = function()
    mod_on = false
    remove_all()

    for ext in pairs(tracked) do
        if unit_ok(ext._unit) then
            ext:force_update_item_visibility()
        end
    end

    for spawner in pairs(tracked_ui) do
        if spawner._character_spawn_data and spawner._visible then
            spawner:_update_items_visibility()
        end
    end

    for spawner in pairs(tracked_wpn) do
        local data = spawner._weapon_spawn_data

        if data and data.visible and unit_ok(data.item_unit_3p) then
            Unit.set_unit_visibility(data.item_unit_3p, true, true)
        end
    end
end

mod.on_enabled = function()
    mod_on = true
    refresh_all()
end

mod.on_unload = function()
    remove_all()

    local custom_assets = get_mod("CustomAssets")

    if custom_assets and custom_assets.release_owner then
        custom_assets.release_owner(mod)
    end
end

-- Retail power-field / shock particles ------------------------------------------------------------------------------
-- The retail slot scripts keep spawning their particles on the hidden retail parts' fx sources, so the crackle drew
-- over the Horizon models (user screenshot 2026-11-01, lightning on the ES01 shield). While a Horizon skin is on for
-- that mark and part, their particle starts are skipped on the local player's weapons. Sounds, buffs and damage are
-- untouched (visual only). Method names from Aussiemon master wieldable_slot_scripts/*.lua; each init gets
-- (context, slot, weapon_template, ...) and context.is_local_unit.
local VFX_HOOKS = {
    { "PowerWeaponEffects", "mace", { "_play_single_vfx", "_start_vfx_loop", "_start_emit_vfx_loop" } },
    { "WieldedIdlingEffects", "mace", { "_start_vfx_loop" } },
    { "ShockMaulHitEffects", "mace", { "_start_particle_effect" } },
    { "PowerWeaponChargesEffects", "mace", { "_start_vfx_loop" } },
    { "ThunderHammerEffects", "mace", { "_start_vfx_loop" } },
    { "RiotShieldEffects", "shield", { "_start_windup_vfx_loop", "_update_windup_vfx_loop", "_trigger_activation_vfx", "_start_passive_vfx_loop" } },
}

for _, h in ipairs(VFX_HOOKS) do
    local class_name, part, methods = h[1], h[2], h[3]

    mod:hook_safe(CLASS[class_name], "init", function(self, context, slot, weapon_template)
        self.__qiangiq_hwmaul_template = weapon_template and weapon_template.name
        self.__qiangiq_hwmaul_local = context and context.is_local_unit
    end)

    for _, method in ipairs(methods) do
        mod:hook(CLASS[class_name], method, function(func, self, ...)
            if self.__qiangiq_hwmaul_local and choice(self.__qiangiq_hwmaul_template, part) then
                return
            end

            return func(self, ...)
        end)
    end
end

-- QIangIQsArmoryVis stowed copies (QIangIQsHorizonStaffs mod.armory_vis): optional, called by Armory Vis if present.
-- A copy without a unit -> item map keeps its retail shield (sync_view).
mod.armory_vis = {
    apply = function(holder, world, equipment)
        holder.__qiangiq_hwmaul_world = world
        holder._equipment = equipment
        ingame_apply(holder)
    end,
    clear = function(holder)
        clear_records(holder.__qiangiq_hwmaul_records, ingame_destroy)
        holder.__qiangiq_hwmaul_records = nil
    end,
}
