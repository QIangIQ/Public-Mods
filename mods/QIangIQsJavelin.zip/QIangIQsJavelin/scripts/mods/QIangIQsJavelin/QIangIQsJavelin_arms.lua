
-- First-person arm playback of Vermintide 2 clips for the Javelin (QIangIQsJavelin): arm code of QIangIQsJavelin 0.5.1.
--
-- Method = QIangIQsChainLaspistol_brace.lua (QIangIQsKarambit / QIangIQsButterflyKnife driver method, seen working in game):
-- a skeleton-only "driver" unit with the first-person bone names (Custom/pa_fp_driver, a rename of cl_fp_driver) is linked to
-- the first-person unit; every frame it copies the animated first-person pose, the arm mesh units are re-linked to it with
-- LINK_MODE_NODE_NAME, and Lua then overrides bones: both arms are solved with a two-bone IK towards hand targets and the
-- hands get their rotation from the hand's finger bones (forward = hand -> j_*handmiddle1, up = j_*handpinky1 -> j_*handindex1).
-- The targets come from QIangIQsJavelin_billhook.lua: the VT2 first-person rig's hands, elbows and weapon-attach frame,
-- baked in the camera / weapon-attach frame (A:\Dowloads\staging\vt2\bake_lua.py), so the arm shapes are VT2's and the
-- Darktide arm lengths only decide how far each hand can reach. The weapon rig is moved to the baked attach frame.
local Arms = {}
local CFG = nil

function Arms.setup(cfg)
    CFG = cfg
end

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function parent_chain(unit, node)
    local list, current, guard = {}, node, 0

    while current and guard < 64 do
        list[#list + 1] = current

        if current == 1 then
            break
        end

        current = Unit.scene_graph_parent(unit, current)
        guard = guard + 1
    end

    return list
end

local function root_relative(unit, node)
    if node == nil or node == 1 then
        return Quaternion.identity(), Vector3(0, 0, 0)
    end

    local chain = parent_chain(unit, node)
    local rotation, position = Quaternion.identity(), Vector3(0, 0, 0)
    local first = chain[#chain] == 1 and #chain - 1 or #chain

    for i = first, 1, -1 do
        position = position + Quaternion.rotate(rotation, Unit.local_position(unit, chain[i]))
        rotation = Quaternion.multiply(rotation, Unit.local_rotation(unit, chain[i]))
    end

    return rotation, position
end

local REQUIRED = {
    "j_leftarm", "j_leftforearm", "j_lefthand", "j_lefthandmiddle1", "j_lefthandindex1", "j_lefthandpinky1",
    "j_rightarm", "j_rightforearm", "j_righthand", "j_righthandmiddle1", "j_righthandindex1", "j_righthandpinky1",
    "j_rightweaponattach", "ap_camera_node",
}

local function make_fpd(driver, fp_unit)
    local fpd = { driver = driver, fp_unit = fp_unit, nodes = {}, by_node = {}, fp_chains = {} }

    for _, name in ipairs(CFG.fp_nodes) do
        if Unit.has_node(driver, name) then
            local node = Unit.node(driver, name)

            if node ~= 1 and not fpd.by_node[node] then
                local entry = { node = node, parent = Unit.scene_graph_parent(driver, node) }

                if Unit.has_node(fp_unit, name) then
                    entry.fp = Unit.node(fp_unit, name)
                    fpd.fp_chains[entry.fp] = parent_chain(fp_unit, entry.fp)
                end

                fpd.by_node[node] = entry
                fpd.nodes[#fpd.nodes + 1] = entry
            end
        end
    end

    for _, name in ipairs(REQUIRED) do
        if not Unit.has_node(driver, name) then
            return nil, name
        end
    end

    return fpd
end

local function copy_pose(fpd)
    local driver, fp_unit = fpd.driver, fpd.fp_unit
    local poses = {}

    local function pose_of(node)
        if node == nil or node == 1 then
            return Quaternion.identity(), Vector3(0, 0, 0)
        end

        local pose = poses[node]

        if pose then
            return pose[1], pose[2]
        end

        local entry = fpd.by_node[node]
        local rotation, position

        if entry and entry.fp then
            local chain = fpd.fp_chains[entry.fp]
            rotation, position = Quaternion.identity(), Vector3(0, 0, 0)

            local first = chain[#chain] == 1 and #chain - 1 or #chain

            for i = first, 1, -1 do
                position = position + Quaternion.rotate(rotation, Unit.local_position(fp_unit, chain[i]))
                rotation = Quaternion.multiply(rotation, Unit.local_rotation(fp_unit, chain[i]))
            end
        else
            local parent_rotation, parent_position = pose_of(Unit.scene_graph_parent(driver, node))

            rotation = Quaternion.multiply(parent_rotation, Unit.local_rotation(driver, node))
            position = parent_position + Quaternion.rotate(parent_rotation, Unit.local_position(driver, node))
        end

        poses[node] = { rotation, position }

        return rotation, position
    end

    for i = 1, #fpd.nodes do
        local entry = fpd.nodes[i]

        if entry.fp then
            local rotation, position = pose_of(entry.node)
            local parent_rotation, parent_position = pose_of(entry.parent)
            local inverse_parent = Quaternion.inverse(parent_rotation)

            Unit.set_local_rotation(driver, entry.node, Quaternion.multiply(inverse_parent, rotation))
            Unit.set_local_position(driver, entry.node, Quaternion.rotate(inverse_parent, position - parent_position))
        end
    end
end

-- IK helpers (driver root-relative space), QIangIQsChainLaspistol_brace.lua ----------------------------------------------
local function rotation_between(u, v)
    local lu, lv = Vector3.length(u), Vector3.length(v)

    if lu < 1e-6 or lv < 1e-6 then
        return Quaternion.identity()
    end

    u, v = u * (1 / lu), v * (1 / lv)

    local axis = Vector3.cross(u, v)
    local s = Vector3.length(axis)

    if s < 1e-6 then
        return Quaternion.identity()
    end

    return Quaternion.axis_angle(axis * (1 / s), math.atan2(s, Vector3.dot(u, v)))
end

local function turn_node(driver, node, q)
    local pr = root_relative(driver, Unit.scene_graph_parent(driver, node))
    local r = root_relative(driver, node)

    Unit.set_local_rotation(driver, node, Quaternion.multiply(Quaternion.inverse(pr), Quaternion.multiply(q, r)))
end

local function pos(driver, name)
    local _, p = root_relative(driver, Unit.node(driver, name))

    return p
end

local function two_bone(driver, side, target, pole_point)
    local arm, fore = Unit.node(driver, "j_" .. side .. "arm"), Unit.node(driver, "j_" .. side .. "forearm")
    local S, E, H = pos(driver, "j_" .. side .. "arm"), pos(driver, "j_" .. side .. "forearm"), pos(driver, "j_" .. side .. "hand")
    local a, b = Vector3.length(E - S), Vector3.length(H - E)
    local to_target = target - S
    local d = math.clamp(Vector3.length(to_target), math.abs(a - b) + 1e-3, a + b - 1e-3)
    local dir = Vector3.normalize(to_target)
    local pv = pole_point - S

    pv = pv - dir * Vector3.dot(pv, dir)

    if Vector3.length(pv) < 1e-5 then
        pv = (E - S) - dir * Vector3.dot(E - S, dir)
    end

    if Vector3.length(pv) < 1e-5 then
        return
    end

    pv = Vector3.normalize(pv)

    local cos_a = math.clamp((a * a + d * d - b * b) / (2 * a * d), -1, 1)
    local sin_a = math.sqrt(math.max(0, 1 - cos_a * cos_a))
    local elbow = S + dir * (cos_a * a) + pv * (sin_a * a)

    turn_node(driver, arm, rotation_between(E - S, elbow - S))

    local E1, H1 = pos(driver, "j_" .. side .. "forearm"), pos(driver, "j_" .. side .. "hand")

    turn_node(driver, fore, rotation_between(H1 - E1, (S + dir * d) - E1))
end

-- Baked clips ----------------------------------------------------------------------------------------------------------
local function lerp_frames(a, b, w)
    local out = {}

    for k = 1, #a do
        out[k] = a[k] + (b[k] - a[k]) * w
    end

    return out
end

local function sample(clip, t, loop)
    local frames = clip.frames
    local n = #frames
    local x = (loop and (t % clip.length) or math.clamp(t, 0, clip.length)) / clip.length * (n - 1)
    local i = math.min(math.floor(x), n - 2)

    return lerp_frames(frames[i + 1], frames[i + 2], x - i)
end

-- rotation taking u onto v, also when they are opposite
local function align(u, v)
    u, v = Vector3.normalize(u), Vector3.normalize(v)

    if Vector3.dot(u, v) < -0.9995 then
        local side = math.abs(u.z) < 0.9 and Vector3(0, 0, 1) or Vector3(1, 0, 0)

        return Quaternion.axis_angle(Vector3.normalize(Vector3.cross(u, side)), math.pi)
    end

    return rotation_between(u, v)
end

-- look-direction weights (left, right, up, down) of the weapon sway, from how fast the view turned this frame
local function sway_weights(data, fp_unit, dt)
    local f = Quaternion.rotate(Unit.world_rotation(fp_unit, 1), Vector3(0, 1, 0))
    local yaw, pitch = math.atan2(f.x, f.y), math.asin(math.clamp(f.z, -1, 1))
    local w = data.sway or { 0, 0, 0, 0 }

    if data.sway_prev and dt > 1e-4 then
        local dyaw = yaw - data.sway_prev[1]

        if dyaw > math.pi then
            dyaw = dyaw - 2 * math.pi
        elseif dyaw < -math.pi then
            dyaw = dyaw + 2 * math.pi
        end

        -- the weapon lags the view: turning right shifts it left, looking up shifts it down
        local target = {
            math.clamp(dyaw / dt / 3, 0, 1), math.clamp(-dyaw / dt / 3, 0, 1),
            math.clamp(-(pitch - data.sway_prev[2]) / dt / 3, 0, 1), math.clamp((pitch - data.sway_prev[2]) / dt / 3, 0, 1),
        }
        local k = 1 - math.exp(-dt * 10)

        for i = 1, 4 do
            w[i] = w[i] + (target[i] - w[i]) * k
        end
    end

    data.sway_prev = { yaw, pitch }
    data.sway = w

    return w
end

-- piecewise time warp: action time -> clip time, so the clip's fast part falls on the action's damage window
local function warp(clip, action)
    local e, total, L = action.elapsed or 0, math.max(action.total or clip.length, 0.05), clip.length
    local d0, d1, h0, h1 = action.dws, action.dwe, clip.hit0, clip.hit1

    if not (d0 and d1 and h0 and h1) or d1 <= d0 or d1 >= total or h1 >= L or d0 <= 0 then
        return e / total * L
    end

    if e < d0 then
        return e / d0 * h0
    elseif e < d1 then
        return h0 + (e - d0) / (d1 - d0) * (h1 - h0)
    end

    return h1 + (e - d1) / (total - d1) * (L - h1)
end

local V = {}

local function vec(f, i)
    return Vector3(f[i], f[i + 1], f[i + 2])
end

-- hand frame from the hand's own finger bones, as QIangIQsChainLaspistol_brace.lua apply_hold
local function solve_hand(driver, side, f, i, t_r, t_p)
    local target_p = t_p + Quaternion.rotate(t_r, vec(f, i))
    local forward = Quaternion.rotate(t_r, Vector3.normalize(vec(f, i + 3)))
    local up = Quaternion.rotate(t_r, Vector3.normalize(vec(f, i + 6)))
    local pole = target_p + Quaternion.rotate(t_r, vec(f, i + 9))
    local hand = Unit.node(driver, "j_" .. side .. "hand")
    local hand_r, hand_p = root_relative(driver, hand)
    local inv_hand = Quaternion.inverse(hand_r)
    local f_local = Quaternion.rotate(inv_hand, pos(driver, "j_" .. side .. "handmiddle1") - hand_p)
    local u_local = Quaternion.rotate(inv_hand, pos(driver, "j_" .. side .. "handindex1") - pos(driver, "j_" .. side .. "handpinky1"))

    forward = Vector3.normalize(forward - up * Vector3.dot(forward, up))
    u_local = Vector3.normalize(u_local)
    f_local = Vector3.normalize(f_local - u_local * Vector3.dot(f_local, u_local))

    local target_r = Quaternion.multiply(Quaternion.look(forward, up), Quaternion.inverse(Quaternion.look(f_local, u_local)))

    two_bone(driver, side, target_p, pole)

    local parent_r = root_relative(driver, Unit.scene_graph_parent(driver, hand))

    Unit.set_local_rotation(driver, hand, Quaternion.multiply(Quaternion.inverse(parent_r), target_r))
end

-- start / stop / update ------------------------------------------------------------------------------------------------
local function arm_units(ext)
    local found = {}

    for slot_name, slot in pairs(ext._equipment or {}) do
        if type(slot_name) == "string" and (slot_name:find("^slot_body") or slot_name:find("^slot_gear")) and unit_ok(slot.unit_1p) then
            found[#found + 1] = slot.unit_1p
        end
    end

    return found
end

local function relink(world, unit, parent)
    World.unlink_unit(world, unit)
    World.link_unit(world, unit, 1, parent, 1, World.LINK_MODE_NODE_NAME)
end

function Arms.stop(ext)
    local data = ext.__qiangiq_javelin_arms

    if not data then
        return
    end

    ext.__qiangiq_javelin_arms = nil

    local world = ext.__qiangiq_javelin_world

    if world and unit_ok(data.fp_unit) then
        for unit in pairs(data.arms) do
            if unit_ok(unit) then
                relink(world, unit, data.fp_unit)
            end
        end
    end

    if unit_ok(data.driver) then
        local unit_spawner = Managers.state and Managers.state.unit_spawner

        if unit_spawner then
            unit_spawner:mark_for_deletion(data.driver)
        end
    end
end

local function start(ext, fp_unit, world)
    local unit_spawner = Managers.state and Managers.state.unit_spawner
    local path = CFG.driver_path()

    if not (unit_spawner and path) then
        return nil
    end

    local driver = unit_spawner:spawn_unit(path, Unit.world_pose(fp_unit, 1))

    if not driver then
        return nil
    end

    local ok, fpd, missing = pcall(make_fpd, driver, fp_unit)

    if not ok or not fpd then
        unit_spawner:mark_for_deletion(driver)
        CFG.error("arm driver lacks node " .. tostring(ok and missing or fpd) .. ": arms off")

        return nil
    end

    World.link_unit(world, driver, 1, fp_unit, 1)
    copy_pose(fpd)

    local data = { driver = driver, fpd = fpd, fp_unit = fp_unit, arms = {}, pose = nil }

    ext.__qiangiq_javelin_arms = data

    return data
end

-- Clips: the melee clips are the Vermintide 2 Spear & Shield set (QIangIQsJavelin_spear_shield.lua); the charged throw and the
-- bare fists are the VT2 Javelin set (QIangIQsJavelin_javelin.lua, its unarmed_* clips). Both baked by the same method.
local S, J = "spear_shield", "javelin"

-- Darktide action (the donor's action names, see QIangIQsJavelin.lua) -> VT2 clip and how to play it.
-- Port, 1 for 1, of 1h_spears_shield.lua: light_attack_left = attack_swing_stab, light_attack_right = attack_swing_stab_lh,
-- light_attack_last = attack_swing_heavy_left, light_attack_stab_postpush = push_stab, heavy_attack = attack_swing_heavy_left,
-- heavy_attack_right = attack_swing_heavy_down_right, heavy_attack_stab = attack_swing_heavy_stab, push = attack_push,
-- charges = attack_swing_charge_left / _right_diagonal_pose / _stab.
-- mode: "loop" (clock), "charge" (real seconds, held at the end), "once" (stretched over the action, the fast part of the clip on
-- the damage window), "inspect", "throw_charge" (idle_to_throw, then the throw pose loops)
local MELEE = {
    action_melee_start_left = { "heavy_swing_charge_left", "charge" },
    action_melee_start_left_2 = { "heavy_swing_charge_left", "charge" },
    action_melee_start_push_combo = { "heavy_swing_charge_left", "charge" },
    action_melee_start_right = { "heavy_swing_charge_right_diagonal", "charge" },
    action_melee_start_right_2 = { "heavy_swing_charge_stab", "charge" },
    action_left_light = { "swing_stab_01", "once" },
    action_right_light = { "swing_stab_02", "once" },
    action_left_light_2 = { "heavy_swing_left", "once" },
    action_right_light_pushfollow = { "push_stab", "once" },
    action_left_heavy = { "heavy_swing_left", "once" },
    action_right_heavy = { "heavy_swing_down_right", "once" },
    action_right_heavy_2 = { "heavy_swing_stab", "once" },
    action_push = { "push", "once" },
}

-- hit variants (the clips played when the swing connects), from the attack_hit anim event
local HIT = { heavy_swing_left = "swing_left_hit", heavy_swing_down_right = "swing_down_right_hit" }

local function pick_clip(action)
    local name = action.name
    local speed = action.speed or 0

    local function move(set, prefix)
        if speed > 3.2 then
            return set, prefix .. "run", "loop"
        elseif speed > 0.4 then
            return set, prefix .. "walk", "loop"
        end

        return set, prefix .. "idle", "loop"
    end

    if action.thrown then
        if name == "action_throw" then
            return J, "throw", "once"
        elseif name and name:find("wield", 1, true) then
            return J, "unarmed_equip", "once"
        elseif name and (name:find("fist", 1, true) or name:find("push", 1, true)) then
            return J, "unarmed_action", "once"
        end

        return move(J, "unarmed_")
    end

    if not name or name == "none" then
        return move(S, "")
    elseif name:find("inspect", 1, true) then
        return S, "inspect_start", "inspect"
    elseif name:find("wield", 1, true) then
        return S, "equip", "once"
    elseif name == "action_throw_charge" then
        return J, "idle_to_throw", "throw_charge"
    elseif name == "action_throw" then
        return J, "throw", "once"
    elseif name == "action_block" then
        return S, "heavy_swing_charge_left_pose", "charge"
    end

    local c = MELEE[name]

    if c then
        return S, c[1], c[2]
    end

    return move(S, "")
end

-- The weapon rig: moved from the fp attach node to the driver root once, then placed every frame on the baked VT2 weapon-attach
-- frame (the model's long axis +Z on the attach z line, grip centre at the right hand's height on that line).
local function link_weapon(data, world, slot)
    local rig = slot.unit_1p

    World.update_unit_and_children(world, data.driver)

    data.rig = rig

    World.unlink_unit(world, rig)
    World.link_unit(world, rig, 1, data.driver, 1, World.LINK_MODE_NONE)
    CFG.info("weapon rig linked to the arm driver")

    return true
end

-- slot: the equipment slot of the weapon; action: name, event, elapsed, total, dws, dwe, speed, clock, thrown
function Arms.update(ext, slot, action, dt)
    local fpe = unit_ok(ext._unit) and ScriptUnit.has_extension(ext._unit, "first_person_system")
    local fp_unit = fpe and fpe:first_person_unit()
    local world = ext.__qiangiq_javelin_world
    local data = ext.__qiangiq_javelin_arms
    local want = slot ~= nil and slot.hidden_1p == false and CFG.driver_path() ~= nil and world ~= nil and unit_ok(fp_unit)
        and unit_ok(slot.unit_1p) and fpe.is_in_first_person_mode and fpe:is_in_first_person_mode()

    if data and (not want or data.fp_unit ~= fp_unit or not unit_ok(data.driver)) then
        Arms.stop(ext)
        data = nil
    end

    if not want then
        ext.__qiangiq_javelin_why = (ext.__qiangiq_javelin_why or 0) - (dt or 0)

        if ext.__qiangiq_javelin_why <= 0 then
            ext.__qiangiq_javelin_why = 3
            CFG.info(string.format("arms idle: slot %s hidden_1p %s driver %s world %s fp_unit %s unit_1p %s first-person %s",
                tostring(slot ~= nil), tostring(slot and slot.hidden_1p), tostring(CFG.driver_path()), tostring(world ~= nil),
                tostring(unit_ok(fp_unit)), tostring(slot ~= nil and unit_ok(slot.unit_1p)),
                tostring(fpe and fpe.is_in_first_person_mode and fpe:is_in_first_person_mode())))
        end

        return
    end

    data = data or start(ext, fp_unit, world)

    if not data then
        return
    end

    for _, unit in ipairs(arm_units(ext)) do
        if not data.arms[unit] then
            relink(world, unit, data.driver)
            data.arms[unit] = true
        end
    end

    for unit in pairs(data.arms) do
        if not unit_ok(unit) then
            data.arms[unit] = nil
        end
    end

    copy_pose(data.fpd)

    if data.rig ~= slot.unit_1p and not link_weapon(data, world, slot) then
        World.update_unit_and_children(world, data.driver)

        return
    end

    -- pose of the moment: the baked clip frame, smoothed towards (hard cuts between clips would pop)
    local src_name, clip_name, mode = pick_clip(action)
    local baked = CFG.baked(src_name)

    if not baked then
        return
    end

    local inspecting = action.name ~= nil and action.name:find("inspect", 1, true) ~= nil

    if data.inspecting and not inspecting then
        data.inspect_end_t = action.clock
    end

    data.inspecting = inspecting

    local end_clip = baked.inspect_end

    if mode == "loop" and src_name == S and data.inspect_end_t and end_clip and action.clock - data.inspect_end_t < end_clip.length then
        clip_name, mode = "inspect_end", "inspect_end"
    end

    local hit = CFG.hit()

    if mode == "once" and hit and hit.t >= action.clock - (action.elapsed or 0) - 0.05 and HIT[clip_name] and baked[HIT[clip_name]] then
        clip_name = HIT[clip_name]
    end

    local clip = baked[clip_name] or baked.idle or baked.unarmed_idle

    if not clip then
        return
    end

    local frame

    if mode == "inspect" then
        local e = action.elapsed or 0
        local loop_clip = baked.inspect_loop

        if e < clip.length then
            frame = sample(clip, e, false)
        elseif loop_clip then
            clip_name, frame = "inspect_loop", sample(loop_clip, e - clip.length, true)
        else
            frame = sample(clip, clip.length, false)
        end
    elseif mode == "inspect_end" then
        frame = sample(clip, action.clock - data.inspect_end_t, false)
    elseif mode == "throw_charge" then
        local e = action.elapsed or 0
        local pose = baked.idle_throw_pose

        if e < clip.length or not pose then
            frame = sample(clip, e, false)
        else
            clip_name, frame = "idle_throw_pose", sample(pose, e - clip.length, true)
        end
    elseif mode == "loop" then
        frame = sample(clip, action.clock, true)
    elseif mode == "charge" then
        frame = sample(clip, action.elapsed or 0, false)
    else
        frame = sample(clip, warp(clip, action), false)
    end

    data.clip = src_name .. ":" .. clip_name

    dt = dt or 0

    local k = 1 - math.exp(-dt * (mode == "loop" and 8 or 30))

    if data.pose and #data.pose == #frame then
        for i = 1, #frame do
            data.pose[i] = data.pose[i] + (frame[i] - data.pose[i]) * k
        end
    else
        data.pose = frame
    end

    local f = data.pose
    local driver = data.driver
    local cam_r, cam_p = root_relative(driver, Unit.node(driver, "ap_camera_node"))
    local ok, err = pcall(function()
        local t_r = Quaternion.multiply(cam_r, Quaternion.look(Vector3.normalize(vec(f, 4)), Vector3.normalize(vec(f, 7))))
        local t_p = cam_p + Quaternion.rotate(cam_r, vec(f, 1))

        solve_hand(driver, "right", f, 10, t_r, t_p)
        solve_hand(driver, "left", f, 22, t_r, t_p)

        local adj = Quaternion.from_yaw_pitch_roll(math.rad(CFG.opt("weapon_yaw", 0)), math.rad(CFG.opt("weapon_pitch", 0)),
            math.rad(CFG.opt("weapon_roll", 0)))
        local rig_r = Quaternion.multiply(t_r, adj)
        local shaft = Quaternion.rotate(t_r, Vector3(0, 0, 1))
        local along = f[12] + CFG.opt("weapon_slide", 0) * 0.01
        local off = Vector3(CFG.opt("weapon_x", 0), CFG.opt("weapon_y", 0), CFG.opt("weapon_z", 0)) * 0.01
        local scale = CFG.opt("weapon_scale", 100) * 0.01

        Unit.set_local_position(data.rig, 1, t_p + shaft * along + Quaternion.rotate(rig_r, off))
        Unit.set_local_rotation(data.rig, 1, rig_r)
        Unit.set_local_scale(data.rig, 1, Vector3(scale, scale, scale))
    end)

    if not ok and not data.reported then
        data.reported = true
        CFG.error("arms: " .. tostring(err))
    end

    data.log_t = (data.log_t or 0) - dt

    if data.log_t <= 0 then
        data.log_t = 3

        local hp = pos(driver, "j_righthand")
        local rp = Unit.local_position(data.rig, 1)
        local lp = pos(driver, "j_lefthand")

        CFG.info(string.format("arms: clip %s mode %s, right hand %.2f %.2f %.2f, left hand %.2f %.2f %.2f, weapon %.2f %.2f %.2f, action %s event %s thrown %s, ok=%s",
            tostring(data.clip), tostring(mode), hp.x, hp.y, hp.z, lp.x, lp.y, lp.z, rp.x, rp.y, rp.z,
            tostring(action.name), tostring(action.event), tostring(action.thrown), tostring(ok)))
    end

    World.update_unit_and_children(world, driver)
end

function Arms.debug(ext)
    local data = ext.__qiangiq_javelin_arms

    if not data then
        return "arms: not active (driver asset " .. tostring(CFG.driver_path()) .. ")"
    end

    local n = 0

    for _ in pairs(data.arms) do
        n = n + 1
    end

    return string.format("arms: active, %d arm units on the driver, weapon linked: %s, clip %s", n, tostring(data.rig ~= nil), tostring(data.clip))
end

return Arms
