local mod = get_mod("QIangIQsJavelin")

local function number(id, default, min, max, decimals)
    return { setting_id = id, type = "numeric", default_value = default, range = { min, max }, decimals_number = decimals or 0 }
end

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = false,
    options = {
        widgets = {
            {
                setting_id = "model_pick",
                type = "dropdown",
                default_value = "elvenspear",
                options = {
                    { text = "model_elvenspear", value = "elvenspear" },
                    { text = "model_javelin", value = "javelin" },
                    { text = "model_longinus", value = "longinus" },
                },
            },
            { setting_id = "vt2_arms", type = "checkbox", default_value = true },
            { setting_id = "add_to_unlock_list", type = "checkbox", default_value = true },
            number("unlock_level", 1, 1, 30),
            { setting_id = "unlock_zealot", type = "checkbox", default_value = true },
            { setting_id = "unlock_veteran", type = "checkbox", default_value = false },
            { setting_id = "unlock_psyker", type = "checkbox", default_value = false },
            { setting_id = "unlock_adamant", type = "checkbox", default_value = false },
            number("charge_time", 0.85, 0.2, 3, 2),
            number("throw_speed", 55, 20, 120),
            number("throw_gravity", 14, 0, 40),
            number("pickup_radius", 1, 0.5, 5, 1),
            number("stagger_resistance_modifier", 0.01, 0.001, 1, 3),
            number("ragdoll_push_force", 2500, 0, 10000),
            {
                setting_id = "tuning",
                type = "group",
                sub_widgets = {
                    number("weapon_x", 0, -100, 100),
                    number("weapon_y", 0, -100, 100),
                    number("weapon_z", 0, -100, 100),
                    number("weapon_yaw", 0, -180, 180),
                    number("weapon_pitch", 0, -180, 180),
                    number("weapon_roll", 0, -180, 180),
                    number("weapon_slide", 0, -100, 100),
                    number("weapon_scale", 100, 20, 300),
                    number("projectile_yaw", 0, -180, 180),
                    number("projectile_pitch", -90, -180, 180),
                    number("projectile_roll", 0, -180, 180),
                    number("projectile_scale", 100, 20, 300),
                },
            },
        },
    },
}
