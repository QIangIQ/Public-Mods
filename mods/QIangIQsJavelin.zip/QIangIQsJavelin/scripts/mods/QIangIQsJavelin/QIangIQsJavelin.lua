-- QIangIQ's Javelin 0.1.0: a Dauntless javelin for the Zealot. Melee is the Vermintide 2 Spear & Shield moveset, ported action
-- for action; hold the special action to charge a throw that instantly kills anything human sized and hard-staggers Ogryn and
-- bosses. The javelin stays in whatever it hits, or in the ground, and you fight with your fists until you run within a metre of
-- it. Setting "model" swaps the javelin for the Lance of Longinus.
--
-- Sources (nothing here is invented; where the game gave no data the choice is marked as such):
--   * Melee: Vermintide 2 scripts/settings/equipment/weapon_templates/1h_spears_shield.lua (vt2 source). Every
--     attack keeps its VT2 damage window, total time and anim time scale (VT2 divides window, total and chain times by
--     anim_time_scale, action_sweep.lua:370 / :457, so the Darktide values are the VT2 ones divided by it), and its reach
--     (range_mod 1.35 + range_mod_add 0.5 on the light stabs) relative to the Darktide value. Chain order: stab, stab, sweep
--     (light_attack_left, light_attack_right, light_attack_last), push -> stab (light_attack_stab_postpush), heavy_attack,
--     heavy_attack_right, heavy_attack_stab. Darktide's combat sword p1 m1 is the donor template, so its input chain and its
--     damage profiles stay (the damage numbers are Darktide's, not VT2's) and the sweep paths stay the sword's swings.
--   * Arms: the VT2 first-person clips of the Spear & Shield set (melee) and of the Javelin set (throw, bare fists) are baked
--     to Lua (QIangIQsJavelin_spear_shield.lua / _javelin.lua) and played by IK on a driver unit, the QIangIQsPowerAxe method
--     (QIangIQsJavelin_arms.lua). The VT2 Elven Spear swing clips could not be named from the files (their state machine
--     dictionary has gaps), so the Spear & Shield set stands in; its shield hand is empty.
--   * Throw: dual_shivs_p1_m1.lua action_special_throw (kind weapon_throw, projectile_item, fire_time, charges in
--     weapon_special_tweak_data, WeaponSpecialKillCountCharges). The charge is special_action_hold -> release
--     (ogryn_powermaul_slabshield_p1_m1.lua, hierarchy entry), the throw only chains after the charge time, an early release
--     just ends the charge. Projectile template = dual_shivs_p1_throwing_knives with delete_on_impact / delete_on_hit_mass off,
--     sticks_to_armor_types for every armor type, restitution 0 (projectile_locomotion.lua:190-215: the javelin stops where it
--     hits; the engine physics then let it fall, projectile_unit_locomotion_extension.lua:387). Instant kill: the damage
--     profile flag instakill_non_monster_or_captain_or_ogryn (attack.lua:263), hard stagger for the rest: the Crossbow's
--     "explosion" stagger category recipe.
--   * Pickup: WeaponSpecialKillCountCharges.fixed_update is hooked (server side): within the pickup radius of a landed javelin
--     the charge is given back and the projectile removed. A javelin that is gone (out of bounds, fuse) returns after 3 s.
--   * Fists: extra actions on the same template, chosen by action_condition_func while the charge is 0.
--   * Models: Custom/javelin (procedural, build_javelin_glb.py) and Custom/longinus (the Lance of Longinus FBX from the assets
--     folder, flat crimson metal, 2.2 m), Custom Assets framework like the other QIangIQs weapons. Without it the weapon works
--     with the combat sword look and no arms (standalone rule).
-- Author: QIangIQ
local mod = get_mod("QIangIQsJavelin")

local WeaponTemplates = require("scripts/settings/equipment/weapon_templates/weapon_templates")
local MasterItems = require("scripts/backend/master_items")
local NetworkLookup = require("scripts/network_lookup/network_lookup")

local ITEM_ROOT = "content/items/weapons/player/melee/"
local TEMPLATE = "javelin_p1_m1"
local ITEM = ITEM_ROOT .. TEMPLATE
local DONOR_TEMPLATE = "combatsword_p1_m1"
local DONOR_ITEM = ITEM_ROOT .. DONOR_TEMPLATE
local KNIFE_TEMPLATE = "dual_shivs_p1_throwing_knives"
local KNIFE_ITEM = "content/items/weapons/player/shivs_throwing_knives"
local PROJECTILE = "qiangiq_javelin_projectile"
local ARCHETYPES = { "zealot", "veteran", "psyker", "adamant" }
local FIRE_TIME = 0.17         -- VT2 javelin throw clip: release at 0.167 s

local ASSETS = {
    elvenspear = { id = "QIangIQsJavelin:elvenspear", unit = "content/mods/qiangiq_javelin/elvenspear" },
    javelin = { id = "QIangIQsJavelin:javelin", unit = "content/mods/qiangiq_javelin/javelin" },
    longinus = { id = "QIangIQsJavelin:longinus", unit = "content/mods/qiangiq_javelin/longinus" },
    driver = { id = "QIangIQsJavelin:jv_fp_driver", unit = "content/mods/qiangiq_javelin/jv_fp_driver" },
}
local ready = { elvenspear = false, javelin = false, longinus = false, driver = false }

mod:add_global_localize_strings({
    loc_qiangiq_javelin = { en = "Javelin (Dauntless)" },
    loc_qiangiq_javelin_family = { en = "Javelin" },
    loc_qiangiq_javelin_desc = {
        en = "A Dauntless javelin. Hold the special action to charge a throw that kills human sized enemies outright and hard staggers Ogryn and bosses. It stays where it lands: you fight with your fists until you run up to it.",
    },
})

local function say(fmt, ...)
    local text = string.format(fmt, ...)

    mod:echo(text)
    mod:info(text)
end

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function model_key()
    -- "model_pick" replaced the first "model" setting so a value saved while the javelin was the default no longer applies
    local key = mod:get("model_pick")

    return (key == "longinus" or key == "javelin") and key or "elvenspear"
end

-- unit of the chosen model if its Custom Assets build is loaded, else nil (the combat sword look stays)
local function model_unit()
    local key = model_key()

    return ready[key] and ASSETS[key].unit or nil
end

-- Network lookups (QIangIQsShardStaff append_lookup): new names go at the end so no existing id moves -------------
local function append_lookup(lookup_name, key)
    local lookup = NetworkLookup[lookup_name]

    if not lookup then
        return false, "no lookup"
    end

    local existing = rawget(lookup, key)

    if existing then
        return true, existing
    end

    local index = #lookup + 1

    rawset(lookup, index, key)
    rawset(lookup, key, index)

    return true, index
end

-- Particle / sound aliases keyed by wielded_weapon_template (QIangIQsShardStaff alias_template_keys) --------------
local ALIAS_MODULES = {
    "scripts/settings/particles/player_character_particle_aliases",
    "scripts/settings/sound/player_character_sound_event_aliases",
}

local function alias_keys(root, source, target, seen, counter)
    if type(root) ~= "table" or seen[root] then
        return
    end

    seen[root] = true

    local value = rawget(root, source)

    if value ~= nil and rawget(root, target) == nil then
        root[target] = value
        counter.n = counter.n + 1
    end

    for _, child in pairs(root) do
        if type(child) == "table" then
            alias_keys(child, source, target, seen, counter)
        end
    end
end

local function copy_aliases(source, target)
    local counter = { n = 0 }

    for _, path in ipairs(ALIAS_MODULES) do
        local ok, module = pcall(require, path)

        if ok then
            alias_keys(module, source, target, {}, counter)
        else
            mod:error("alias module %s: %s", path, tostring(module))
        end
    end

    return counter.n
end

local function opt(key, default)
    local v = mod:get(key)

    if v == nil then
        return default
    end

    return tonumber(v) or v
end

-- Charge conditions: the javelin in hand is one special charge ----------------------------------------------------------
local function charges_of(condition_func_params)
    local component = condition_func_params and condition_func_params.inventory_slot_component

    return component and component.num_special_charges or 0
end

local function has_javelin(_, condition_func_params)
    return charges_of(condition_func_params) > 0
end

local function no_javelin(_, condition_func_params)
    return charges_of(condition_func_params) <= 0
end

-- Projectile ----------------------------------------------------------------------------------------------------------------
local projectile_template

local function refresh_projectile_visibility()
    -- the knife unit under the javelin model stays hidden once a model rides on it; until then it is the visible stand-in
    if projectile_template then
        projectile_template.always_hidden = model_unit() ~= nil
    end
end

local function ensure_projectile()
    if projectile_template then
        return projectile_template
    end

    local ProjectileTemplates = require("scripts/settings/projectile/projectile_templates")
    local ProjectileLocomotionTemplates = require("scripts/settings/projectile_locomotion/projectile_locomotion_templates")
    local DamageProfileTemplates = require("scripts/settings/damage/damage_profile_templates")
    local ArmorSettings = require("scripts/settings/damage/armor_settings")
    local knife = rawget(ProjectileTemplates, KNIFE_TEMPLATE)
    local base_profile = DamageProfileTemplates.dual_shivs_throwing_knives

    if not knife or not base_profile then
        return nil, "dual_shivs throwing knife projectile or damage profile not found"
    end

    local locomotion = table.clone(knife.locomotion_template)
    local params = locomotion.spawn_projectile_parameters
    local integrator = locomotion.integrator_parameters

    params.initial_speed = opt("throw_speed", 55)
    params.pitch_offset = { max = 0, min = 0 }
    params.yaw_offset = nil
    integrator.gravity = opt("throw_gravity", 14)
    integrator.radius = 0.12
    integrator.coefficient_of_restitution = 0                    -- projectile_locomotion.lua:190: it stops where it hits
    integrator.rotate_towards_direction = true
    locomotion.name = PROJECTILE
    ProjectileLocomotionTemplates[PROJECTILE] = locomotion

    -- instant kill on everything human sized (attack.lua:263), the heaviest stagger on the rest (the Crossbow's recipe:
    -- stagger_calculation.lua, category "explosion", the breed's stagger reduction ignored, a tiny resistance modifier)
    local profile = table.clone(base_profile)

    profile.instakill_non_monster_or_captain_or_ogryn = true
    profile.stagger_category = "explosion"
    profile.ignore_stagger_reduction = true
    profile.stagger_resistance_modifier = opt("stagger_resistance_modifier", 0.01)
    profile.ragdoll_push_force = math.max(profile.ragdoll_push_force or 0, opt("ragdoll_push_force", 2500))
    profile.ranges = { max = 80, min = 60 }                      -- no damage drop-off for the Ogryn / boss hit

    local sticks = {}

    for _, name in pairs(ArmorSettings.types) do
        if type(name) == "string" then
            sticks[name] = true
        end
    end

    local impact = knife.damage.impact

    projectile_template = {
        name = PROJECTILE,
        item_name = KNIFE_ITEM,
        always_hidden = false,
        play_vce = true,
        same_side_suppression_enabled = false,
        locomotion_template = locomotion,
        projectile_type = knife.projectile_type,
        sticks_to_armor_types = sticks,
        damage = {
            use_suppression = true,
            impact = {
                delete_on_hit_mass = false,
                delete_on_impact = false,
                damage_profile = profile,
                damage_type = impact.damage_type,
                suppression_settings = table.clone(impact.suppression_settings),
            },
            fuse = {
                fuse_time = 3600,
            },
        },
        effects = {
            spawn = {
                vfx = {
                    link = true,
                    orphaned_policy = "stop",
                    particle_name = "content/fx/particles/weapons/grenades/grenade_trail",
                },
                sfx = table.clone(knife.effects.spawn.sfx),
            },
        },
    }

    ProjectileTemplates[PROJECTILE] = projectile_template

    local ok = append_lookup("projectile_template_names", PROJECTILE)

    if not ok then
        ProjectileTemplates[PROJECTILE] = nil
        projectile_template = nil

        return nil, "NetworkLookup.projectile_template_names missing"
    end

    refresh_projectile_visibility()

    return projectile_template
end

-- Template ------------------------------------------------------------------------------------------------------------
-- VT2 1h_spears_shield.lua: anim_time_scale (time_mod 0.9 x factor), damage_window_start / _end, total_time, and range
-- (range_mod 1.35, plus range_mod_add 0.5 on the stabs and the last sweep). VT2 divides all of them by the anim time scale.
local PORT = {
    action_left_light = { scale = 0.9 * 1.3, dws = 0.38, dwe = 0.52, total = 2.1, reach = 1.85 },              -- light_attack_left
    action_right_light = { scale = 0.9 * 1.3, dws = 0.38, dwe = 0.52, total = 2.1, reach = 1.85 },             -- light_attack_right
    action_left_light_2 = { scale = 0.9 * 1.25, dws = 0.27, dwe = 0.43, total = 1.1, reach = 1.85 },          -- light_attack_last
    action_right_light_pushfollow = { scale = 0.9 * 1.3, dws = 0.3, dwe = 0.4, total = 1.1, reach = 1.35 },    -- light_attack_stab_postpush
    action_left_heavy = { scale = 0.9 * 1.15, dws = 0.27, dwe = 0.43, total = 1.0, reach = 1.35 },            -- heavy_attack
    action_right_heavy = { scale = 1, dws = 0.3, dwe = 0.37, total = 2.25, reach = 1.35 },                     -- heavy_attack_right
    action_right_heavy_2 = { scale = 0.9 * 1.15, dws = 0.25, dwe = 0.32, total = 2.25, reach = 1.35 },         -- heavy_attack_stab
}

-- time of the light -> heavy switch while charging (VT2 allowed_chain_actions heavy_attack start_time 0.4 / 0.5)
local HEAVY_AT = {
    action_melee_start_left = 0.4,
    action_melee_start_left_2 = 0.5,
    action_melee_start_right = 0.5,
    action_melee_start_right_2 = 0.5,
    action_melee_start_push_combo = 0.4,
}

local FIST_OF = {
    action_melee_start_left = "action_fist_start",
    action_melee_start_left_2 = "action_fist_start",
    action_melee_start_right = "action_fist_start",
    action_melee_start_right_2 = "action_fist_start",
    action_melee_start_push_combo = "action_fist_start",
    action_left_light = "action_fist_jab",
    action_right_light = "action_fist_jab",
    action_left_light_2 = "action_fist_jab",
    action_right_light_pushfollow = "action_fist_jab",
    action_left_heavy = "action_fist_heavy",
    action_right_heavy = "action_fist_heavy",
    action_right_heavy_2 = "action_fist_heavy",
}

local function scale_numbers(tbl, factor)
    for key, value in pairs(tbl) do
        if type(value) == "number" then
            tbl[key] = value * factor
        elseif type(value) == "table" then
            scale_numbers(value, factor)
        end
    end
end

local function fist_profile(source, attack_factor, impact_factor)
    local profile = table.clone(source)

    if type(profile.power_distribution) == "table" then
        local attack, impact = profile.power_distribution.attack, profile.power_distribution.impact

        if type(attack) == "table" then
            scale_numbers(attack, attack_factor)
        elseif type(attack) == "number" then
            profile.power_distribution.attack = attack * attack_factor
        end

        if type(impact) == "table" then
            scale_numbers(impact, impact_factor)
        elseif type(impact) == "number" then
            profile.power_distribution.impact = impact * impact_factor
        end
    end

    return profile
end

local function replace_special(list)
    for i, entry in ipairs(list) do
        if entry.input == "special_action" then
            list[i] = {
                input = "special_action_hold",
                transition = {
                    { input = "special_action_release", transition = "base" },
                    { input = "wield", transition = "base" },
                },
            }
        elseif type(entry.transition) == "table" then
            replace_special(entry.transition)
        end
    end
end

local function apply_spear(clone, notes)
    local BaseTemplateSettings = require("scripts/settings/equipment/weapon_templates/base_template_settings")
    local DamageSettings = require("scripts/settings/damage/damage_settings")
    local damage_types = DamageSettings.damage_types
    local actions = clone.actions
    local projectile, err = ensure_projectile()

    if not projectile then
        notes[#notes + 1] = "throw off: " .. tostring(err)
    end

    -- fists first, from the untouched donor actions
    local light_src = actions.action_left_light
    local heavy_src = actions.action_left_heavy
    local light_profile = fist_profile(light_src.damage_profile, 0.35, 0.6)
    local heavy_profile = fist_profile(heavy_src.damage_profile, 0.6, 0.8)

    local function fist_chain(extra)
        local chain = {
            wield = BaseTemplateSettings.generate_wield_chain_actions(),
            start_attack = { action_name = "action_fist_start", chain_time = 0.3 },
            block = { action_name = "action_block", chain_time = 0.1 },
        }

        for key, value in pairs(extra or {}) do
            chain[key] = value
        end

        return chain
    end

    local start = table.clone(actions.action_melee_start_left)

    start.start_input = "start_attack"
    start.action_condition_func = no_javelin
    start.allowed_chain_actions = fist_chain({
        light_attack = { action_name = "action_fist_jab", chain_time = 0 },
        heavy_attack = { action_name = "action_fist_heavy", chain_time = 0.5 },
    })
    start.allowed_chain_actions.start_attack = nil
    actions.action_fist_start = start

    local jab = table.clone(light_src)

    jab.start_input = nil
    jab.action_condition_func = no_javelin
    jab.damage_window_start = 0.15
    jab.damage_window_end = 0.3
    jab.total_time = 0.7
    jab.range_mod = 0.7
    jab.weapon_box = { 0.15, 0.1, 0.75 }
    jab.damage_profile = light_profile
    jab.damage_type = damage_types.punch
    jab.wounds_shape = nil
    jab.allowed_chain_actions = fist_chain()
    actions.action_fist_jab = jab

    local haymaker = table.clone(heavy_src)

    haymaker.start_input = nil
    haymaker.action_condition_func = no_javelin
    haymaker.damage_window_start = 0.2
    haymaker.damage_window_end = 0.35
    haymaker.total_time = 0.9
    haymaker.range_mod = 0.8
    haymaker.weapon_box = { 0.2, 0.15, 0.8 }
    haymaker.damage_profile = heavy_profile
    haymaker.damage_type = damage_types.punch
    haymaker.wounds_shape = nil
    haymaker.allowed_chain_actions = fist_chain()
    actions.action_fist_heavy = haymaker

    -- the port: timings, reach, the spear in hand needs the javelin
    for name, p in pairs(PORT) do
        local action = actions[name]

        if action then
            action.damage_window_start = p.dws / p.scale
            action.damage_window_end = p.dwe / p.scale
            action.total_time = p.total / p.scale
            action.range_mod = (action.range_mod or 1.25) * p.reach / 1.35
        end
    end

    if actions.action_push then
        actions.action_push.total_time = 0.8
    end

    for name, action in pairs(actions) do
        if type(action) == "table" then
            if action.weapon_box and not name:find("fist", 1, true) then
                local box = action.weapon_box

                action.weapon_box = { box[1], box[2], box[3] * 1.35 }
            end

            if FIST_OF[name] then
                action.action_condition_func = has_javelin
            end
        end
    end

    -- chains: special action -> charge, and every attack chain gets the fist alternative
    for name, action in pairs(actions) do
        local chain = type(action) == "table" and action.allowed_chain_actions

        if chain and not name:find("fist", 1, true) then
            if chain.special_action then
                chain.special_action_hold = { action_name = "action_throw_charge", chain_time = chain.special_action.chain_time or 0.2 }
                chain.special_action = nil
            end

            for key, entry in pairs(chain) do
                if type(entry) == "table" and entry.action_name and FIST_OF[entry.action_name] then
                    chain[key] = { entry, { action_name = FIST_OF[entry.action_name], chain_time = entry.chain_time } }
                end
            end

            local heavy_at = HEAVY_AT[name]

            if heavy_at then
                local heavy = chain.heavy_attack

                if heavy and heavy[1] then
                    heavy[1].chain_time = heavy_at
                end
            end
        end
    end

    replace_special(clone.action_input_hierarchy)

    -- charge: hold the special action; early release ends it, release after the charge time throws
    actions.action_throw_charge = {
        allowed_during_sprint = true,
        anim_end_event = "attack_finished",
        anim_event = "heavy_charge_left",
        anim_event_3p = "attack_swing_charge_left",
        kind = "dummy",
        start_input = "special_action_hold",
        stop_input = "special_action_release",
        total_time = math.huge,
        uninterruptible = true,
        action_condition_func = has_javelin,
        crosshair = { crosshair_type = "dot" },
        action_movement_curve = {
            { modifier = 0.7, t = 0.3 },
            { modifier = 0.65, t = 1 },
            start_modifier = 0.9,
        },
        allowed_chain_actions = {
            wield = BaseTemplateSettings.generate_wield_chain_actions(),
            special_action_release = { action_name = "action_throw", chain_time = opt("charge_time", 0.85) },
        },
        anim_end_event_condition_func = function(unit, data, end_reason)
            return end_reason ~= "new_interrupting_action" and end_reason ~= "action_complete"
        end,
    }

    if projectile then
        actions.action_throw = {
            allowed_during_sprint = true,
            anim_end_event = "attack_finished",
            anim_event = "attack_special",
            anim_event_3p = "attack_swing_right_diagonal",
            fire_time = FIRE_TIME,
            kind = "weapon_throw",
            projectile_item = KNIFE_ITEM,
            projectile_template = projectile,
            sprint_requires_press_to_interrupt = false,
            total_time = 0.55,
            uninterruptible = true,
            action_condition_func = has_javelin,
            crosshair = { crosshair_type = "dot" },
            allowed_chain_actions = {
                wield = BaseTemplateSettings.generate_wield_chain_actions({ chain_time = 0.15 }),
                start_attack = { action_name = "action_fist_start", chain_time = 0.35 },
                block = { action_name = "action_block", chain_time = 0.3 },
            },
            anim_end_event_condition_func = function(unit, data, end_reason)
                return end_reason ~= "new_interrupting_action" and end_reason ~= "action_complete"
            end,
        }
    else
        actions.action_throw = nil
        actions.action_throw_charge = nil
    end

    -- the javelin is one special charge; nothing refills it but picking it up (breed_tag_charges empty, none added)
    clone.weapon_special_class = "WeaponSpecialKillCountCharges"
    clone.weapon_special_tweak_data = {
        default_num_charges_to_add = 0,
        initial_charges = 1,
        keep_active_on_unwield = true,
        max_charges = 1,
        num_charges_to_consume_on_activation = 1,
        breed_tag_charges = {},
        qiangiq_javelin = true,
    }
    clone.special_action_name = projectile and "action_throw_charge" or nil

    -- the model has no fx nodes of its own except the empties ap_pommel_01 / ap_head_01 (player_unit_fx_extension.lua:824-860
    -- falls back to the root with an error log otherwise)
    clone.fx_sources = table.clone(clone.fx_sources or {})

    for source in pairs(clone.fx_sources) do
        clone.fx_sources[source] = "ap_head_01"
    end

    notes[#notes + 1] = projectile and "throw ready" or "throw off"
end

local state = { notes = {} }

local function ensure_template()
    if rawget(WeaponTemplates, TEMPLATE) then
        state.template_ok = true

        return true
    end

    local donor = WeaponTemplates[DONOR_TEMPLATE]

    if not donor then
        return false
    end

    local clone = table.clone(donor)

    clone.name = TEMPLATE

    -- weapon_templates.lua _require_template: action_settings.name = action_name
    for action_name, action_settings in pairs(clone.actions) do
        action_settings.name = action_name
    end

    state.notes = {}
    apply_spear(clone, state.notes)

    for action_name, action_settings in pairs(clone.actions) do
        action_settings.name = action_name
    end

    WeaponTemplates[TEMPLATE] = clone
    state.template_ours = true

    local ok, index = append_lookup("weapon_templates", TEMPLATE)

    state.template_id = ok and index or nil
    state.aliases = copy_aliases(DONOR_TEMPLATE, TEMPLATE)
    state.template_ok = ok

    return ok
end

-- Items ---------------------------------------------------------------------------------------------------------------
local function find_item(cache, preferred, template)
    local direct = rawget(cache, preferred)

    if direct and direct.weapon_template == template then
        return preferred, direct
    end

    for name, item in pairs(cache) do
        if type(item) == "table" and item.weapon_template == template then
            return name, item
        end
    end
end

-- Only base_unit is kept: Items.base_unit can also read per-breed / first-person variants of the source part
local function only_base_unit(item, unit)
    for key in pairs(item) do
        if type(key) == "string" and key ~= "base_unit" and key:find("^base_unit") then
            item[key] = nil
        end
    end

    item.base_unit = unit
end

local function archetypes_of(source_item)
    local archetypes, seen = {}, {}

    for _, archetype in ipairs(source_item.archetypes or {}) do
        archetypes[#archetypes + 1] = archetype
        seen[archetype] = true
    end

    for _, archetype in ipairs(ARCHETYPES) do
        if mod:get("unlock_" .. archetype) and not seen[archetype] then
            archetypes[#archetypes + 1] = archetype
            seen[archetype] = true
        end
    end

    return archetypes
end

local function build_item(cache)
    local source_name, source_item = find_item(cache, DONOR_ITEM, DONOR_TEMPLATE)

    if not source_item then
        return false, "donor item " .. DONOR_TEMPLATE .. " not found"
    end

    local item = table.clone(source_item)
    local notes = {}

    item.name = ITEM
    item.weapon_template = TEMPLATE
    item.display_name = "loc_qiangiq_javelin"
    item.description = "loc_qiangiq_javelin_desc"
    item.dev_description = nil
    item.archetypes = archetypes_of(source_item)

    for _, field in ipairs({ "weapon_family_display_name", "weapon_pattern_display_name", "weapon_mark_display_name" }) do
        if type(item[field]) == "table" then
            item[field].loc_id = field == "weapon_family_display_name" and "loc_qiangiq_javelin_family" or "loc_qiangiq_javelin"
        end
    end

    local deps = item.resource_dependencies or {}
    local unit = model_unit()

    -- The item keeps the combat sword's own unit: a Custom Assets unit is a resource inside a generated package, not a package, so
    -- naming it as base_unit or dependency makes the package synchronizer fail ("Package reference ... does not exist", a crash on
    -- equip). The model is spawned beside the sword by apply_visuals instead and the sword is hidden.
    notes[#notes + 1] = unit and ("model " .. model_key() .. " (spawned over the sword)") or "model not loaded, the combat sword look stays"

    local WeaponTemplateResourceDependencies = require("scripts/utilities/weapon_template_resource_dependencies")

    for _, resource in ipairs(WeaponTemplateResourceDependencies.generate(TEMPLATE)) do
        deps[resource] = true
    end

    -- the throwing knife's projectile unit (it has the "dynamic" actor manual_physics needs; projectile_unit_locomotion_extension.lua:51)
    local knife = rawget(cache, KNIFE_ITEM)

    if knife then
        if knife.base_unit then
            deps[knife.base_unit] = true
        end

        for dependency in pairs(knife.resource_dependencies or {}) do
            deps[dependency] = true
        end
    else
        notes[#notes + 1] = "knife projectile item not found"
    end

    item.resource_dependencies = deps

    local ok, index = append_lookup("player_item_names", ITEM)

    if not ok then
        return false, "player_item_names lookup missing"
    end

    cache[ITEM] = item
    state.item_id = index
    state.slot = item.slots and item.slots[1]
    state.source_item_name = source_name
    state.item_notes = notes
    state.item_model = unit and model_key() or "sword"

    return true
end

local function ensure_item()
    local ok, has_data = pcall(MasterItems.has_data)

    if not ok or not has_data then
        return false
    end

    local cache = MasterItems.get_cached()

    if rawget(cache, ITEM) and not state.item_dirty then
        state.item_ok = true

        return true
    end

    local built, err = build_item(cache)

    if err and err ~= state.last_error then
        state.last_error = err
        mod:error("%s", err)
    end

    state.item_ok = built and rawget(cache, ITEM) ~= nil

    if state.item_ok then
        state.item_dirty = false
    end

    return state.item_ok
end

-- Unlock list (weapon_unlock_settings.lua WeaponUnlockSettings[archetype][level] = { item names }); realms_loadout builds its
-- weapon list from it
local function add_to_unlock_lists()
    if not mod:get("add_to_unlock_list") then
        return
    end

    local ok, unlocks = pcall(require, "scripts/settings/weapon_unlock/weapon_unlock_settings")

    if not ok or not unlocks then
        mod:error("WeaponUnlockSettings not found")

        return
    end

    local level = math.floor(opt("unlock_level", 1))

    for _, archetype in ipairs(ARCHETYPES) do
        local list = unlocks[archetype]

        if mod:get("unlock_" .. archetype) and list then
            list[level] = list[level] or {}

            if not table.find(list[level], ITEM) then
                table.insert(list[level], ITEM)
            end
        end
    end
end

local next_poll = 0

local function poll()
    if next_poll > os.clock() then
        return
    end

    next_poll = os.clock() + 1

    local before_t, before_i = state.template_ok, state.item_ok
    local ok_t, err_t = pcall(ensure_template)
    local ok_i, err_i = true, nil

    if state.template_ok then
        ok_i, err_i = pcall(ensure_item)
    end

    if not ok_t then
        mod:error("template: %s", tostring(err_t))
    end

    if not ok_i then
        mod:error("item: %s", tostring(err_i))
    end

    if state.template_ok and not before_t then
        mod:info("template %s registered (clone of %s), %s alias entries; %s", TEMPLATE, DONOR_TEMPLATE, tostring(state.aliases),
            table.concat(state.notes or {}, "; "))
    end

    if state.item_ok and (not before_i or state.last_model ~= state.item_model) then
        state.last_model = state.item_model
        mod:info("item %s injected (clone of %s, slot %s): %s", ITEM, tostring(state.source_item_name), tostring(state.slot),
            table.concat(state.item_notes or {}, "; "))
    end
end

-- Settings that change what is built: the items are rebuilt (equip again to see them). The throw numbers, charge time and
-- moveset are read when the template is built, so those need the mods reloaded (Ctrl+Shift+R) or a restart.
local ITEM_SETTINGS = {
    model_pick = true, unlock_zealot = true, unlock_veteran = true, unlock_psyker = true, unlock_adamant = true,
}

mod.on_setting_changed = function(setting_id)
    if ITEM_SETTINGS[setting_id] then
        state.item_dirty = true
        refresh_projectile_visibility()
    end
end

-- Javelins in flight / landed ---------------------------------------------------------------------------------------------
-- Every client spawns the projectile, the model rides on it (the Crossbow's riding bolt). The record also feeds the pickup.
local javelins = {}

local function riding_rotation()
    return Quaternion.from_yaw_pitch_roll(math.rad(opt("projectile_yaw", 0)), math.rad(opt("projectile_pitch", -90)),
        math.rad(opt("projectile_roll", 0)))
end

local function start_riding(self, extension_init_context, unit, extension_init_data)
    if not (extension_init_data and extension_init_data.projectile_template_name == PROJECTILE) then
        return
    end

    local rec = { owner = extension_init_data.owner_unit, ext = self, born = os.clock() }

    javelins[unit] = rec

    local path = model_unit()
    local world = extension_init_context and extension_init_context.world

    if path and world and unit_ok(unit) then
        local model = World.spawn_unit_ex(world, path, nil, Unit.world_pose(unit, 1))

        if model then
            local scale = opt("projectile_scale", 100) * 0.01

            World.link_unit(world, model, 1, unit, 1, World.LINK_MODE_NODE_NAME)
            Unit.set_local_rotation(model, 1, riding_rotation())
            Unit.set_local_scale(model, 1, Vector3(scale, scale, scale))
            Unit.set_unit_visibility(model, true, true)
            rec.model, rec.world = model, world
        end
    end
end

local function drop_record(unit)
    local rec = javelins[unit]

    if rec then
        javelins[unit] = nil

        if rec.model and Unit.alive(rec.model) then
            pcall(World.destroy_unit, rec.world, rec.model)
        end
    end
end

mod:hook_safe(CLASS.ProjectileUnitLocomotionExtension, "init", function(self, extension_init_context, unit, extension_init_data)
    start_riding(self, extension_init_context, unit, extension_init_data)
end)

if CLASS.ProjectileHuskLocomotionExtension then
    mod:hook_safe(CLASS.ProjectileHuskLocomotionExtension, "init", function(self, extension_init_context, unit, extension_init_data)
        start_riding(self, extension_init_context, unit, extension_init_data)
    end)
end

-- Pickup (server): inside the pickup radius of a landed javelin the charge is given back and the projectile removed -----
local recall_requested = false
local landed_states

local function is_server()
    local ok, server = pcall(function()
        local session = Managers.state and Managers.state.game_session

        return session == nil or session:is_server()
    end)

    return ok and server
end

local function landed(rec)
    if not rec.ext or not rec.ext.current_state then
        return false
    end

    if not landed_states then
        local states = require("scripts/settings/projectile_locomotion/projectile_locomotion_settings").states

        landed_states = { [states.sticky] = true, [states.sleep] = true, [states.engine_physics] = true }
    end

    return landed_states[rec.ext:current_state()] == true and os.clock() - rec.born > 0.4
end

local function remove_projectile(unit)
    pcall(function()
        Managers.state.player_unit_spawn:relinquish_unit_ownership(unit)
    end)
    pcall(function()
        Managers.state.unit_spawner:mark_for_deletion(unit)
    end)
    drop_record(unit)
end

local function pickup_step(special, t)
    local component = special._inventory_slot_component

    if component.num_special_charges > 0 then
        special.__qiangiq_javelin_missing = nil

        return
    end

    local owner = special._player_unit

    if not unit_ok(owner) or not is_server() then
        return
    end

    local position = Unit.world_position(owner, 1)
    local radius = opt("pickup_radius", 1)
    local any = false

    for unit, rec in pairs(javelins) do
        if rec.owner == owner and unit_ok(unit) then
            any = true

            if landed(rec) or recall_requested then
                local p = Unit.world_position(unit, 1)
                local dx, dy, dz = p.x - position.x, p.y - position.y, math.abs(p.z - position.z)

                if (dx * dx + dy * dy <= radius * radius and dz <= 2.2) or recall_requested then
                    recall_requested = false
                    component.num_special_charges = 1
                    remove_projectile(unit)
                    mod:info("javelin picked up")

                    return
                end
            end
        end
    end

    -- gone for good (out of bounds, fuse): it comes back to the hand after 3 s
    if any then
        special.__qiangiq_javelin_missing = nil
    elseif special.__qiangiq_javelin_missing == nil then
        special.__qiangiq_javelin_missing = t
    elseif t - special.__qiangiq_javelin_missing > 3 then
        special.__qiangiq_javelin_missing = nil
        component.num_special_charges = 1
        mod:info("javelin lost, back in hand")
    end
end

mod:hook_require("scripts/extension_systems/weapon/special_classes/weapon_special_kill_count_charges", function(Special)
    mod:hook_safe(Special, "fixed_update", function(self, dt, t)
        local tweak = self._tweak_data

        if tweak and tweak.qiangiq_javelin then
            local ok, err = pcall(pickup_step, self, t)

            if not ok and err ~= state.pickup_error then
                state.pickup_error = err
                mod:error("pickup: %s", tostring(err))
            end
        end
    end)
end)


-- Sweep guard: the javelin stays in the world as a projectile (delete_on_impact off), and a melee sweep that hits a projectile
-- which is not in true flight indexes a nil template in ProjectileUnitLocomotionExtension.register_sweep_hit
-- (projectile_unit_locomotion_extension.lua:644-648: true_flight_template.sweep_hit_dot_validation_func). A resting projectile has no
-- true flight template, so such sweeps are ignored (the same guard the Bell mod carries for its resting pickups).
mod:hook_require("scripts/extension_systems/locomotion/projectile_unit_locomotion_extension", function(Ext)
    mod:hook(Ext, "register_sweep_hit", function(func, self, ...)
        local data = self._integration_data

        if not (data and data.true_flight_template) then
            return
        end

        return func(self, ...)
    end)
end)

-- Arms (QIangIQsPowerAxe method): VT2 first-person clips baked to Lua, played by IK on a driver unit -----------------------
local baked_clips = {}

local Arms = mod:io_dofile("QIangIQsJavelin/scripts/mods/QIangIQsJavelin/QIangIQsJavelin_arms")

Arms.setup({
    fp_nodes = mod:io_dofile("QIangIQsJavelin/scripts/mods/QIangIQsJavelin/QIangIQsJavelin_fp_nodes"),
    opt = opt,
    baked = function(set_name)
        if set_name == "spear_shield" or set_name == "javelin" then
            baked_clips[set_name] = baked_clips[set_name]
                or mod:io_dofile("QIangIQsJavelin/scripts/mods/QIangIQsJavelin/QIangIQsJavelin_" .. set_name)

            return baked_clips[set_name]
        end
    end,
    driver_path = function()
        if ready.driver and mod:get("vt2_arms") ~= false then
            return ASSETS.driver.unit
        end
    end,
    error = function(text)
        mod:error("%s", text)
    end,
    info = function(text)
        mod:info("%s", text)
    end,
    hit = function()
        return mod.__qiangiq_javelin_hit
    end,
})

local tracked = {}

-- current action of the local player: name, seconds into it, its length (scaled), the clock, and whether the javelin has left
-- the hand (no charge left, except in the throw action until its release time)
local function action_info(ext, slot_name)
    local ok, info = pcall(function()
        local ude = ScriptUnit.has_extension(ext._unit, "unit_data_system")
        local wa = ude and ude:read_component("weapon_action")

        if not wa then
            return nil
        end

        local t = Managers.time:time("gameplay")
        local template = WeaponTemplates[wa.template_name]
        local settings = template and template.actions and template.actions[wa.current_action_name]
        local total = settings and settings.total_time
        local scale = math.max(wa.time_scale or 1, 0.1)

        if total and total < 10 then
            total = total / scale
        else
            total = nil
        end

        local dws = settings and settings.damage_window_start
        local dwe = settings and settings.damage_window_end
        local locomotion = ude:read_component("locomotion")
        local velocity = locomotion and locomotion.velocity_current
        local speed = velocity and Vector3.length(Vector3(velocity.x, velocity.y, 0)) or 0
        local elapsed = t - (wa.start_t or t)
        local inventory = ude:read_component(slot_name)
        local thrown = inventory ~= nil and (inventory.num_special_charges or 0) <= 0

        if thrown and wa.current_action_name == "action_throw" and elapsed < FIRE_TIME / scale then
            thrown = false
        end

        return {
            event = settings and settings.anim_event, name = wa.current_action_name, elapsed = elapsed, total = total, clock = t,
            dws = dws and dws / scale or nil, dwe = dwe and dwe / scale or nil, speed = speed, thrown = thrown,
        }
    end)

    return ok and info or nil
end

-- The held model: the item keeps the combat sword's unit (see build_item); the chosen model is spawned next to it, follows its pose
-- (or the arms module's rig placement in first person) and the sword is hidden. hidden remembers the units this mod hid.
local hidden = setmetatable({}, { __mode = "k" })

local function set_visible(unit, visible, flag_hidden)
    if not unit_ok(unit) then
        return
    end

    if visible then
        if hidden[unit] then
            hidden[unit] = nil
            Unit.set_unit_visibility(unit, not flag_hidden, true)
        end
    else
        hidden[unit] = true
        Unit.set_unit_visibility(unit, false, true)
    end
end

-- models are spawned by the unit spawner (QIangIQsSwordShield spawn_linked: the pattern that draws custom units in first
-- person), so they go back through it; a unit that came from World.spawn_unit_ex is destroyed in its world
local function delete_model(entry)
    if not unit_ok(entry.unit) then
        return
    end

    local unit_spawner = Managers.state and Managers.state.unit_spawner

    if entry.spawner and unit_spawner then
        unit_spawner:mark_for_deletion(entry.unit)
    else
        pcall(World.destroy_unit, entry.world, entry.unit)
    end
end

local function destroy_models(ext)
    local models = ext.__qiangiq_javelin_models

    if not models then
        return
    end

    ext.__qiangiq_javelin_models = nil

    for _, entry in pairs(models) do
        delete_model(entry)
    end
end

-- the custom model of one sword unit (spawned once per sword unit and model path)
local function model_for(ext, sword, key)
    local path = model_unit()
    local world = ext.__qiangiq_javelin_world

    if not (path and world and unit_ok(sword)) then
        return nil
    end

    local models = ext.__qiangiq_javelin_models

    if not models then
        models = {}
        ext.__qiangiq_javelin_models = models
    end

    local entry = models[key]

    if entry and (entry.sword ~= sword or entry.path ~= path or not unit_ok(entry.unit)) then
        delete_model(entry)

        entry = nil
        models[key] = nil
    end

    if not entry then
        local unit_spawner = Managers.state and Managers.state.unit_spawner
        local unit = unit_spawner and unit_spawner:spawn_unit(path, Unit.world_pose(sword, 1))
        local via_spawner = unit ~= nil

        if not unit then
            unit = World.spawn_unit_ex(world, path, nil, Unit.world_pose(sword, 1))
        end

        if not unit then
            return nil
        end

        -- QIangIQsSwordShield spawn_linked: a first-person unit also needs culling off or it can be culled for good
        if key == "unit_1p" then
            pcall(Unit.set_unit_culling, unit, false)
        end

        -- equipment_component.lua:360 / :474 flags the first-person unit and its children "custom_fov"; units spawned apart from
        -- the item (like this model) have to be flagged themselves or the first-person pass does not draw them
        if key == "unit_1p" then
            local ok, err = pcall(Unit.set_shader_pass_flag_for_meshes_in_unit_and_childs, unit, "custom_fov", true)

            if not ok then
                mod:error("custom_fov flag: %s", tostring(err))
            end
        end

        mod:info("held model spawned for %s: %s (%s)", key, path, via_spawner and "unit spawner" or "world")

        entry = { unit = unit, sword = sword, path = path, world = world, spawner = via_spawner }
        models[key] = entry
    end

    return entry.unit
end

-- one frame of the held weapon: show the model (or the sword while no model is loaded), hide both while the javelin is thrown
local function show_weapon(ext, slot, thrown, arms_on)
    local result = {}

    for _, key in ipairs({ "unit_1p", "unit_3p" }) do
        local sword = slot[key]
        local flag_hidden = key == "unit_1p" and slot.hidden_1p or slot.hidden_3p

        if unit_ok(sword) then
            local model = model_for(ext, sword, key)

            if model then
                set_visible(sword, false, flag_hidden)

                for _, attachment in ipairs(slot[key == "unit_1p" and "attachments_1p" or "attachments_3p"] or {}) do
                    set_visible(attachment, false, flag_hidden)
                end

                Unit.set_unit_visibility(model, not thrown and not flag_hidden, true)

                -- the arms module places the first-person model itself; otherwise it follows the sword
                if not (key == "unit_1p" and arms_on) then
                    local adj = Quaternion.from_yaw_pitch_roll(math.rad(opt("weapon_yaw", 0)), math.rad(opt("weapon_pitch", 0)),
                        math.rad(opt("weapon_roll", 0)))
                    local rotation = Quaternion.multiply(Unit.world_rotation(sword, 1), adj)
                    local off = Vector3(opt("weapon_x", 0), opt("weapon_y", 0), opt("weapon_z", 0)) * 0.01
                    local scale = opt("weapon_scale", 100) * 0.01

                    Unit.set_local_position(model, 1, Unit.world_position(sword, 1) + Quaternion.rotate(rotation, off))
                    Unit.set_local_rotation(model, 1, rotation)
                    Unit.set_local_scale(model, 1, Vector3(scale, scale, scale))
                end

                result[key] = model
            else
                set_visible(sword, not thrown, flag_hidden)

                for _, attachment in ipairs(slot[key == "unit_1p" and "attachments_1p" or "attachments_3p"] or {}) do
                    set_visible(attachment, not thrown, flag_hidden)
                end
            end
        end
    end

    return result
end

local function apply_visuals(ext, dt)
    if not ext._is_local_unit or not ext._equipment then
        return
    end

    local ours, ours_name

    for slot_name, slot in pairs(ext._equipment) do
        local item = slot.item

        if item and item.name == ITEM then
            ours, ours_name = slot, slot_name
        end
    end

    if not ours then
        pcall(Arms.stop, ext)
        destroy_models(ext)

        return
    end

    local ok, err = pcall(function()
        local info = action_info(ext, ours_name)

        if info then
            local models = show_weapon(ext, ours, info.thrown, ext.__qiangiq_javelin_arms ~= nil)
            -- the arms module drives the first-person model as its rig; without a model it drives the sword
            local rig_slot = ours

            if models.unit_1p then
                rig_slot = { unit_1p = models.unit_1p, hidden_1p = ours.hidden_1p }
            end

            Arms.update(ext, rig_slot, info, dt)
        end
    end)

    if not ok then
        mod:error("arms update: %s", tostring(err))
        pcall(Arms.stop, ext)
    end
end

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "_update_item_visibility", function(self)
    if self._is_local_unit then
        tracked[self] = true
        apply_visuals(self)
    end
end)

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "init", function(self, extension_init_context)
    self.__qiangiq_javelin_world = extension_init_context and extension_init_context.world
end)

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "update", function(self, unit, dt)
    if tracked[self] then
        apply_visuals(self, dt)
    end
end)

mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, "destroy", function(func, self, ...)
    pcall(Arms.stop, self)
    destroy_models(self)
    tracked[self] = nil

    return func(self, ...)
end)

-- Hit events for the swing variants of the arms (attack_hit / attack_hit_shield, as the PowerAxe records them) ---------------
for _, class_name in ipairs({ "PlayerUnitAnimationExtension", "AuthoritativePlayerUnitAnimationExtension" }) do
    for _, method in ipairs({ "anim_event_1p", "anim_event_with_variable_float_1p", "anim_event_with_variable_floats_1p" }) do
        mod:hook(CLASS[class_name], method, function(func, self, event_name, ...)
            if event_name == "attack_hit" or event_name == "attack_hit_shield" then
                local ok, t = pcall(function()
                    return Managers.time:time("gameplay")
                end)

                mod.__qiangiq_javelin_hit = { t = ok and t or 0, armor = event_name == "attack_hit_shield" }
            end

            return func(self, event_name, ...)
        end)
    end
end

mod.update = function()
    poll()

    local now = os.clock()

    for unit, rec in pairs(javelins) do
        if not unit_ok(unit) then
            drop_record(unit)
        elseif now - rec.born > 3700 then
            drop_record(unit)
        end
    end
end

-- Custom Assets (optional): the models and the arm driver -------------------------------------------------------------------
local function acquire_assets()
    local custom_assets = get_mod("CustomAssets")

    if not custom_assets or not custom_assets.is_api_compatible or not custom_assets.is_api_compatible(1) then
        mod:info("Custom Assets (API 1) not installed: combat sword look, no VT2 arms")

        return
    end

    for key, asset in pairs(ASSETS) do
        local ticket = custom_assets.acquire(mod, asset.id, function(_, _, load_error)
            if load_error then
                mod:info("asset %s not loaded: %s", asset.id, tostring(load_error))

                return
            end

            ready[key] = true
            mod:info("asset %s loaded", asset.id)

            if key ~= "driver" then
                state.item_dirty = true
                refresh_projectile_visibility()
            end
        end, { resident = true, reference_name = asset.id })

        if type(ticket) == "table" and ticket.package_name then
            asset.package = ticket.package_name
        end

        if not ticket then
            mod:info("asset %s could not be requested (not patched yet?)", asset.id)
        end
    end
end

mod.on_all_mods_loaded = function()
    add_to_unlock_lists()
    acquire_assets()
end

mod.on_unload = function()
    local ok, cache = pcall(MasterItems.get_cached)

    if ok and cache then
        cache[ITEM] = nil
    end

    if state.template_ours then
        WeaponTemplates[TEMPLATE] = nil
    end

    for unit in pairs(javelins) do
        drop_record(unit)
    end
end

-- Equip without the backend (QIangIQsShardStaff override): only where this client hosts ----------------------------------------
local function local_player()
    local players = Managers.player

    return players and players:local_player_safe(1)
end

local function equipped_item_name(player, slot)
    local unit = player and player.player_unit

    if not unit_ok(unit) then
        return nil
    end

    local extension = ScriptUnit.has_extension(unit, "visual_loadout_system")
    local item = extension and extension:item_from_slot(slot)

    return item and item.name
end

local previous = {}

local function override(slot, item_name)
    local player = local_player()
    local sync = Managers.profile_synchronization
    local host = sync and sync:synchronizer_host()

    if not player then
        say("no local player")

        return false
    end

    if not host then
        say("not the host here. Use the Psykhanium, a SoloPlay game or a game you host")

        return false
    end

    host:override_slot(player:peer_id(), player:local_player_id(), slot, item_name)
    say("override_slot(%s, %s) sent", slot, tostring(item_name))

    return true
end

local function status()
    say("%s: template %s (id %s), item %s (id %s, slot %s, model %s)", TEMPLATE, tostring(state.template_ok), tostring(state.template_id),
        tostring(state.item_ok), tostring(state.item_id), tostring(state.slot), tostring(state.item_model))

    local notes = {}

    for _, list in ipairs({ state.notes, state.item_notes }) do
        for _, note in ipairs(list or {}) do
            notes[#notes + 1] = note
        end
    end

    if #notes > 0 then
        say("  %s", table.concat(notes, "; "))
    end

    local count = 0

    for _ in pairs(javelins) do
        count = count + 1
    end

    local player = local_player()
    local ext = player and player.player_unit and ScriptUnit.has_extension(player.player_unit, "visual_loadout_system")

    say("  assets javelin %s, longinus %s, driver %s; projectiles out: %d", tostring(ready.javelin), tostring(ready.longinus),
        tostring(ready.driver), count)
    say("  arms: %s", ext and Arms.debug(ext) or "no local unit")
end

mod:command("javelin", mod:localize("command_javelin"), function(action)
    action = action or "status"

    if action == "status" then
        status()
    elseif action == "equip" then
        if not (state.template_ok and state.item_ok and state.slot) then
            say("%s not ready yet (template %s, item %s)", TEMPLATE, tostring(state.template_ok), tostring(state.item_ok))

            return
        end

        local player = local_player()

        previous[state.slot] = previous[state.slot] or (player and equipped_item_name(player, state.slot))
        override(state.slot, ITEM)
    elseif action == "restore" then
        local any = false

        for slot, item_name in pairs(previous) do
            if item_name and override(slot, item_name) then
                previous[slot] = nil
                any = true
            end
        end

        if not any then
            say("nothing to restore (equip first)")
        end
    elseif action == "recall" then
        recall_requested = true
        say("recall: the javelin returns to your hand")
    else
        say("usage: /javelin [status|equip|restore|recall]")
    end
end)
