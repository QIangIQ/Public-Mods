return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsJavelin` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsJavelin", {
            mod_script = "QIangIQsJavelin/scripts/mods/QIangIQsJavelin/QIangIQsJavelin",
            mod_data = "QIangIQsJavelin/scripts/mods/QIangIQsJavelin/QIangIQsJavelin_data",
            mod_localization = "QIangIQsJavelin/scripts/mods/QIangIQsJavelin/QIangIQsJavelin_localization",
        })
    end,
    version = "0.1.0",
    author = "QIangIQ",
    packages = {},
}
