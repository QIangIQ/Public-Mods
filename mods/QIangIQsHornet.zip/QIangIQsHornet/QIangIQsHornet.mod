return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsHornet` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsHornet", {
            mod_script = "QIangIQsHornet/scripts/mods/QIangIQsHornet/QIangIQsHornet",
            mod_data = "QIangIQsHornet/scripts/mods/QIangIQsHornet/QIangIQsHornet_data",
            mod_localization = "QIangIQsHornet/scripts/mods/QIangIQsHornet/QIangIQsHornet_localization",
        })
    end,
    version = "1.0.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
