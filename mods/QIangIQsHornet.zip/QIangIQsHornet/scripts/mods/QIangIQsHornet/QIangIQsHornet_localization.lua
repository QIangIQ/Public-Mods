return {
    mod_name = {
        en = "QIangIQ's Hornet",
    },
    mod_description = {
        en = "Replaces your own human character with Hornet (Bom39) as a Custom Assets model: third person, first-person arms and menu previews, with physics on her chest, butt, thighs, belly and cloak, and sliders for her proportions. Only one QIangIQ human character model is shown at a time. Personal use. By QIangIQ.",
    },
    model_enabled = {
        en = "Show the Hornet model",
    },
    model_enabled_description = {
        en = "Turning this on switches the other QIangIQ human character models off. Chat command: /hornet",
    },
    hide_body = {
        en = "Hide original body and cosmetics",
    },
    hide_body_description = {
        en = "Hides your character's body, face, hair and gear slots while the model is shown. Weapons stay visible.",
    },
    first_person_arms = {
        en = "Model arms in first person",
    },
    first_person_arms_description = {
        en = "Replaces the first-person arms and gloves with the model's arms.",
    },
    menu_previews = {
        en = "Show in menus (operative select, inventory)",
    },
    menu_previews_description = {
        en = "Shows the model on your own operatives in menu previews. Other players' characters are left alone. Ogryns are never replaced.",
    },
    parts_group = {
        en = "Clothing and attachments",
    },
    part_cloak = {
        en = "Cloak",
    },
    part_cloak_description = {
        en = "Her red cloak (and its physics). Off = the part is removed from the model (third person, first-person arms and menus).",
    },
    part_needle = {
        en = "Needle",
    },
    part_needle_description = {
        en = "The needle on her waist. Off = the part is removed from the model (third person, first-person arms and menus).",
    },
    part_bra = {
        en = "Bra",
    },
    part_bra_description = {
        en = "Off = the part is removed from the model (third person, first-person arms and menus).",
    },
    part_panty = {
        en = "Panty",
    },
    part_panty_description = {
        en = "Off = the part is removed from the model (third person, first-person arms and menus).",
    },
    shape_group = {
        en = "Body proportions",
    },
    shape_breast = {
        en = "Breast size",
    },
    shape_breast_description = {
        en = "Scales the breasts. 1 = as modelled, 0.5 to 2. Clothing on them follows.",
    },
    shape_butt = {
        en = "Butt size",
    },
    shape_butt_description = {
        en = "Scales the butt. 1 = as modelled, 0.5 to 2.",
    },
    shape_thigh = {
        en = "Thigh size",
    },
    shape_thigh_description = {
        en = "Scales the soft upper thighs. 1 = as modelled, 0.5 to 2.",
    },
    shape_belly = {
        en = "Belly size",
    },
    shape_belly_description = {
        en = "Scales the belly. 1 = as modelled, 0.5 to 2.",
    },
    shape_breast_lift = {
        en = "Breast lift (degrees)",
    },
    shape_breast_lift_description = {
        en = "Turns the breasts up (positive) or down (negative) from how they were modelled. 0 = as modelled. Works while physics is on.",
    },
    physics_group = {
        en = "Physics",
    },
    jiggle = {
        en = "Physics on",
    },
    jiggle_description = {
        en = "Physics on the model's chest, butt, thighs, belly and cloak.",
    },
    jiggle_breast = {
        en = "Amount: breasts",
    },
    jiggle_breast_description = {
        en = "1 = as built. Higher = looser and wider swings, lower = tighter. 0 = this area does not move.",
    },
    jiggle_butt = {
        en = "Amount: butt and thighs",
    },
    jiggle_butt_description = {
        en = "1 = as built. Higher = looser and wider swings, lower = tighter. 0 = this area does not move.",
    },
    jiggle_belly = {
        en = "Amount: belly",
    },
    jiggle_belly_description = {
        en = "1 = as built. Higher = looser and wider swings, lower = tighter. 0 = this area does not move.",
    },
    jiggle_cloth = {
        en = "Amount: clothing and chains",
    },
    jiggle_cloth_description = {
        en = "1 = as built. Higher = looser and wider swings, lower = tighter. 0 = this area does not move.",
    },
    jiggle_stiffness = {
        en = "Stiffness (all areas except the tail)",
    },
    jiggle_stiffness_description = {
        en = "How hard everything is pulled back to its rest pose. 1 = as built. Higher = snaps back faster, lower = softer and slower.",
    },
    jiggle_damping = {
        en = "Damping (all areas except the tail)",
    },
    jiggle_damping_description = {
        en = "How quickly the wobble dies out. 1 = as built. Higher = settles at once, lower = keeps bouncing longer.",
    },
    jiggle_limit = {
        en = "Swing limit (all areas except the tail)",
    },
    jiggle_limit_description = {
        en = "Scales the largest angle a bone may swing away from its rest pose. 1 = as built.",
    },
    jiggle_hang = {
        en = "Hang (clothing)",
    },
    jiggle_hang_description = {
        en = "How strongly loose clothing is drawn straight down instead of keeping its modelled direction when you lean or look up and down. 0 = keep the modelled shape. Hair and tail have their own gravity settings.",
    },
    toggle_keybind = {
        en = "Toggle Hornet model",
    },
}
