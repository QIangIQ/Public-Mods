return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`DiosSorter` encountered an error loading the Darktide Mod Framework.")

		new_mod("DiosSorter", {
			mod_script       = "Dio's Sorter/scripts/mods/DiosSorter/DiosSorter",
			mod_data         = "Dio's Sorter/scripts/mods/DiosSorter/DiosSorter_data",
			mod_localization = "Dio's Sorter/scripts/mods/DiosSorter/DiosSorter_localization",
		})
	end,
	version = "2.12.24",
	packages = {},
}
