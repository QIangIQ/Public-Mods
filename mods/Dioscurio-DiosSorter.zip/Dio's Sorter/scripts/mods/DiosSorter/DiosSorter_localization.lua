return {
	mod_name = {
		en = "Dio's Sorter",
	},
	mod_description = {
		en = "v2.12.24  |  Author: Dioscurio\nSorts the mod options list alphabetically, with your favourites pinned to the top. Uses DMF's own favourite stars, so there is nothing extra to configure.",
	},

	sort_mode = {
		en = "Sort order",
	},
	--[[
		DMF passes every localization string through string.format, so a bare
		'%' would be read as a format specifier and throw. Write '%%' for a
		literal percent sign. None are needed here, but the rule applies to any
		string added later.
	--]]
	sort_mode_tooltip = {
		en = "Alphabetical order for the mod list. Names are compared with colour codes and leading punctuation stripped, so a red mod or one called '!!! Something' sorts under its actual first letter rather than under a symbol. Off leaves the list in load order, which is DMF's default.",
	},
	sort_ascending = {
		en = "A to Z",
	},
	sort_descending = {
		en = "Z to A",
	},
	sort_off = {
		en = "Off (load order)",
	},

	shorten_names = {
		en = "Shorten long names",
	},
	shorten_names_tooltip = {
		en = "Truncates over-long mod names in the list. Some mods ship joke names hundreds of characters long, which spill over the rows above and below - the usual workaround is inserting dummy spacer mods to hold blank rows. The full name still shows in the tooltip. Cuts on character boundaries, so accented and non-Latin names are not corrupted.",
	},
	name_limit = {
		en = "Name length limit",
	},
	name_limit_tooltip = {
		en = "Maximum characters before a name is truncated with an ellipsis. 42 fits comfortably on one row at most resolutions. Raise it if you run a wide display, lower it if names still wrap.",
	},

	favourites_first = {
		en = "Favourites at top",
	},
	favourites_first_tooltip = {
		en = "Pins mods you have starred to the top of the list. This reads DMF's own favourites, the same star you click in the mod menu, so there is no separate pin list to maintain. Favourites stay at the top in both sort directions - reversing them would bury the things you pinned.",
	},
}
