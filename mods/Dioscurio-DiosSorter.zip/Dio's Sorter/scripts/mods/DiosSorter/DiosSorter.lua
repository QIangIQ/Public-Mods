local mod = get_mod("DiosSorter")
local dmf = get_mod("DMF")

--[[
    Dio's Sorter
    ============

    Sorts the DMF mod options list alphabetically, optionally with your
    favourites pinned to the top.

    HOW THE LIST IS BUILT (verified in DMF, not assumed)

    Every mod appends its own options block to dmf.options_widgets_data as it
    loads (core/options.lua:771), so the list arrives in LOAD ORDER - which is
    why an unsorted menu looks arbitrary.

    dmf.create_mod_options_settings (ui/options/mod_options.lua:705) is what
    walks that table to build the visible list, at lines 716 and 738. Sorting
    the table immediately before that call therefore reorders the menu with no
    UI code of our own.

    WHY NOT DO WHAT SortModMenu DOES

    Two reasons, both learned from watching it fail on this install:

      1. It REPLACES dmf.initialize_dmf_options_view outright. That function is
         called once, from dmf_loader.lua:71, and does real work - registering
         the view and four require paths. Replacing it means owning all of that
         forever, and any DMF change to it silently breaks you. We WRAP
         create_mod_options_settings instead, so DMF keeps doing its own job.

      2. Its name normaliser calls into kernel32 via FFI for Unicode letter
         classification, and `local kernel32 = ffi.load("kernel32")` sits
         unguarded at file scope in its _data.lua. If that throws, the options
         data never registers and the mod disappears from the menu - which is
         the exact symptom here.

         That machinery only matters for non-ASCII mod names. Measured against
         the real mod list on this install, ASCII names trigger ZERO FFI calls,
         so the dependency buys nothing and can fail everything. This does it in
         plain Lua.
--]]

-- ---------------------------------------------------------------------------
-- Name normalisation
-- ---------------------------------------------------------------------------

--[[
    Strip DMF colour codes, lowercase, and reduce to comparable characters.

    Colour codes look like {#ff0000} and would otherwise sort a red mod under
    "{". Leading punctuation and glyph characters are dropped for the same
    reason - a mod called "!!! Best Mod" should sort under B, not "!".

    Non-ASCII bytes are KEPT rather than classified. We cannot tell a letter
    from a symbol without Unicode tables, but keeping them sorts such names
    consistently next to each other, which is far better than excluding them
    (unstable) or loading a DLL to find out (fragile).
--]]
local function normalise(name)
    if type(name) ~= "string" then
        return ""
    end

    local s = name:gsub("{#[^}]*}", "")     -- colour codes
    s = s:lower()

    local out = {}
    for i = 1, #s do
        local c = s:sub(i, i)
        local b = c:byte()
        if c:match("[a-z0-9]") then
            out[#out + 1] = c
        elseif b > 127 then
            out[#out + 1] = c               -- keep, do not classify
        else
            out[#out + 1] = " "             -- punctuation and spacing
        end
    end

    s = table.concat(out)
    s = s:gsub("%s%s+", " ")
    return (s:match("^%s*(.-)%s*$")) or ""
end

mod.normalise = normalise

-- ---------------------------------------------------------------------------
-- Long-name shortening
--
-- Some mods ship deliberately enormous display names - one on this install is
-- 280 characters. DMF renders the name on a fixed-height row, so an
-- over-length name spills into the entries above and below. The usual
-- workaround is inserting dummy "spacer" mods to hold blank rows, which is why
-- ___spacer1-4 exist in the load order.
--
-- Both places DMF renders a mod name read readable_mod_name off the same
-- widget data we already sort:
--     mod_options.lua:247  create_mod_toggle_template  (the toggle row)
--     mod_options.lua:534  create_mod_category         (the left-hand entry)
-- so shortening it once here fixes both, with no UI code.
--
-- Truncation rather than a smaller font: shrinking type enough to fit 280
-- characters on one row would make it unreadable, and the row height is fixed
-- regardless. The full name still appears in the tooltip.
-- ---------------------------------------------------------------------------

--[[
    Originals, keyed by the widget-data header table.

    Truncation MUST be idempotent. Without keeping the original we would
    re-truncate an already-truncated name every time the menu opens, eating
    three more characters each pass until nothing was left. Everything is
    always derived from the stored original.
--]]
local original_names = setmetatable({}, { __mode = "k" })

--[[
    LENGTH MEANS VISIBLE CHARACTERS, NOT BYTES.

    This distinction is the whole feature. Measured across the real mod list:

        Alf's DMF Extensions   ~700 bytes  ->  20 visible
        Zealots Don't Die        46 bytes  ->  17 visible
        Ritual Zones             69 bytes  ->  ~16 visible
        QIangIQ's Outliner      158 bytes  ->  158 visible
        QIangIQ's Tracker       305 bytes  ->  305 visible

    Alf's name is rainbow-coloured, so EVERY character carries its own
    {#color(r,g,b)} code. Measuring bytes made a 20-character name look like the
    longest on the list, and cutting it at byte 42 landed inside the first
    colour code and destroyed it.

    Counting visible characters instead means only the two genuinely oversized
    names are touched, and every colour-coded name is left exactly alone -
    which is what was asked for.
--]]

--[[
    Walk a string, yielding (chunk, is_markup, is_char).

    Markup is {#...}; everything else is counted one UTF-8 character at a time,
    since a byte-wise cut would split 'ä' in the German name into an invalid
    sequence that renders as a box.
--]]
local function utf8_char_len(b)
    if b < 0x80 then return 1
    elseif b < 0xE0 then return 2
    elseif b < 0xF0 then return 3
    else return 4 end
end

local function visible_length(s)
    local n, i, len = 0, 1, #s
    while i <= len do
        if s:sub(i, i + 1) == "{#" then
            local close = s:find("}", i, true)
            i = close and (close + 1) or (len + 1)
        else
            i = i + utf8_char_len(s:byte(i) or 0)
            n = n + 1
        end
    end
    return n
end

--[[
    Truncate to `limit` VISIBLE characters, keeping markup intact.

    Colour codes are copied through without counting, so a coloured name is cut
    at the right visual point rather than mid-code. If any code was opened we
    append {#reset()} so the truncation cannot leak its colour into the rest of
    the menu.
--]]
local function truncate_visible(s, limit)
    local out, n, i, len = {}, 0, 1, #s
    local saw_markup = false

    while i <= len and n < limit do
        if s:sub(i, i + 1) == "{#" then
            local close = s:find("}", i, true)
            if not close then break end
            out[#out + 1] = s:sub(i, close)
            saw_markup = true
            i = close + 1
        else
            local clen = utf8_char_len(s:byte(i) or 0)
            out[#out + 1] = s:sub(i, i + clen - 1)
            i = i + clen
            n = n + 1
        end
    end

    out[#out + 1] = "..."
    if saw_markup then
        out[#out + 1] = "{#reset()}"
    end
    return table.concat(out)
end

local function shorten_names()
    local data = dmf and dmf.options_widgets_data
    if type(data) ~= "table" then
        return
    end

    local enabled = mod:get("shorten_names") ~= false
    local limit = tonumber(mod:get("name_limit")) or 60
    if limit < 10 then
        limit = 10
    end

    for i = 1, #data do
        local head = data[i] and data[i][1]
        if head then
            if original_names[head] == nil then
                original_names[head] = head.readable_mod_name or false
            end

            local original = original_names[head]
            if original then
                --[[
                    Untouched unless it genuinely overflows.

                    Anything at or under the limit is written back byte-for-byte
                    identical, so a colour-coded or glyph-laden name is never
                    reconstructed and cannot be subtly altered.
                --]]
                if not enabled or visible_length(original) <= limit then
                    head.readable_mod_name = original
                else
                    head.readable_mod_name = truncate_visible(original, limit - 3)
                end
            end
        end
    end
end

mod.shorten_names = shorten_names

-- ---------------------------------------------------------------------------
-- Favourites (DMF's own list, not a parallel one)
-- ---------------------------------------------------------------------------

--[[
    DMF already stores favourites under "options_menu_favorite_mods"
    (mod_options.lua:517) and exposes a star in its own UI. Reading that list
    means the star you click is the thing that pins - no second mechanism to
    keep in sync, and nothing to configure.
--]]
local function favourite_lookup()
    local set = {}
    local ok, list = pcall(function()
        return dmf:get("options_menu_favorite_mods")
    end)
    if ok and type(list) == "table" then
        for i = 1, #list do
            set[list[i]] = true
        end
    end
    return set
end

-- ---------------------------------------------------------------------------
-- Sorting
-- ---------------------------------------------------------------------------

--[[
    Each entry of options_widgets_data is an array whose [1] is the mod's
    header block, carrying mod_name / readable_mod_name / title
    (mod_options.lua:718-719 reads exactly those, with that fallback order).
--]]
local function entry_names(entry)
    local head = entry and entry[1]
    if not head then
        return "", ""
    end
    local display = head.readable_mod_name or head.title or head.mod_name or ""
    return tostring(head.mod_name or ""), normalise(display)
end

function mod.sort_options()
    local data = dmf and dmf.options_widgets_data
    if type(data) ~= "table" or #data < 2 then
        return false
    end

    local mode = mod:get("sort_mode") or "ascending"
    if mode == "off" then
        return false
    end

    local favourites_first = mod:get("favourites_first") ~= false
    local favs = favourites_first and favourite_lookup() or nil

    --[[
        MANUAL FAVOURITE ORDER.

        Favourites were pinned to the top but then sorted alphabetically among
        themselves, so the pin order was not yours to choose.

        WHY THIS IS NOT DRAG AND DROP. The mod options list is a vanilla view
        (ViewElementGrid inside OptionsView); making rows draggable means
        adding hit regions, a drag ghost, drop-index calculation and reflow to
        someone else's grid widget, and doing it from a mod means hooking the
        grid's input handling. That is a rebuild of the view, not a feature
        toggle, and it would break on any Fatshark change to the options UI.

        So the ordering is data rather than gesture: a stored list of mod names,
        edited with /favs and /favmove. Same result - your pins in your order -
        without owning a reimplementation of the options grid.
    --]]
    local manual = mod.favourite_order and mod.favourite_order() or nil

    --[[
        Precompute the sort keys.

        normalise() is not free, and table.sort calls its comparator O(n log n)
        times - recomputing inside it would run the string work dozens of times
        per mod. It also guarantees a STABLE key per entry, which matters:
        a comparator that can return different answers for the same pair on
        different calls makes table.sort throw "invalid order function".
    --]]
    local key = {}
    for i = 1, #data do
        local mod_name, display = entry_names(data[i])
        --[[
            rank orders favourites among themselves. Anything not in the manual
            list sorts after everything that is, and then alphabetically - so a
            newly favourited mod appears at the bottom of the pins rather than
            somewhere arbitrary in the middle.
        --]]
        local rank = math.huge

        if manual and mod_name then
            rank = manual[mod_name] or math.huge
        end

        key[data[i]] = {
            fav = (favs and favs[mod_name]) and 0 or 1,
            rank = rank,
            name = display,
            -- Final tiebreak so two identically-named mods never compare equal
            -- in both directions.
            id = mod_name,
        }
    end

    local descending = mode == "descending"

    local ok, err = pcall(table.sort, data, function(a, b)
        local ka, kb = key[a], key[b]
        if not ka or not kb then
            return false
        end

        -- Favourites always float to the top, in BOTH sort directions:
        -- reversing them would bury the things you pinned.
        if ka.fav ~= kb.fav then
            return ka.fav < kb.fav
        end

        --[[
            Manual rank applies only WITHIN the favourites, and is never
            reversed by descending mode - the order you set by hand is the
            order you meant, in both directions.
        --]]
        if ka.fav == 0 and ka.rank ~= kb.rank then
            return ka.rank < kb.rank
        end

        if ka.name ~= kb.name then
            if descending then
                return ka.name > kb.name
            end
            return ka.name < kb.name
        end

        return ka.id < kb.id
    end)

    if not ok then
        mod:error("[Dio's Sorter] sort failed: %s", tostring(err))
        return false
    end

    return true
end

-- ---------------------------------------------------------------------------
-- Hook
-- ---------------------------------------------------------------------------

--[[
    Wrap, do not replace.

    create_mod_options_settings is a plain field on the dmf mod object rather
    than a class method, so mod:hook does not apply - we capture the original
    and call through. DMF keeps ownership of the actual work; we only reorder
    its input immediately beforehand.

    Sorting here rather than once at load also means the order follows your
    settings live: change the direction and the next time you open the menu it
    is already correct.
--]]
local original_create = dmf and dmf.create_mod_options_settings

if type(original_create) == "function" then
    dmf.create_mod_options_settings = function(self, options_templates)
        --[[
            Shorten BEFORE sorting.

            Sorting keys off the display name, so if the two ran the other way
            round a truncated name could sort under different text than the one
            shown - "QIangIQ's Zielverfolgungs..." and its full form normalise
            identically here, but that is luck rather than design.
        --]]
        pcall(mod.shorten_names)
        pcall(mod.sort_options)
        return original_create(self, options_templates)
    end
else
    mod:error("[Dio's Sorter] dmf.create_mod_options_settings not found - DMF may have changed. Sorting disabled.")
end

mod.on_all_mods_loaded = function()
    --[[
        Sort once at load as well.

        The hook covers every menu open, but sorting now means the very first
        open is already ordered even if DMF ever caches the built list.
    --]]
    pcall(mod.sort_options)
end

--[[
    Re-sort when the direction changes, so the setting takes effect without
    needing a menu reopen.
--]]
mod.on_setting_changed = function(setting_id)
    if setting_id == "shorten_names" or setting_id == "name_limit" then
        pcall(mod.shorten_names)
    end

    --[[
        The manual favourite order is cached, so a change from anywhere has to
        drop the cache before the re-sort below reads it - otherwise the sort
        runs against the previous order. Handled here because this is the
        mod's only on_setting_changed and must stay that way.
    --]]
    --[[
        The favourite positions are generated settings named favpos_<mod>, so
        they cannot be matched by a fixed list - a prefix test is the only way
        to catch them.
    --]]
    local is_favpos = type(setting_id) == "string"
        and string.sub(setting_id, 1, 7) == "favpos_"

    if is_favpos then
        pcall(mod.invalidate_favourite_order)
    end

    if is_favpos or setting_id == "sort_mode" or setting_id == "favourites_first"
        or setting_id == "shorten_names" or setting_id == "name_limit" then
        pcall(mod.sort_options)
    end
end

mod:command("diosort", "Re-sort the mod options list now", function()
    local ok = mod.sort_options()
    mod:echo(ok and "Mod list sorted." or "Sort skipped (mode off, or list unavailable).")
end)

-- ---------------------------------------------------------------------------
-- MANUAL FAVOURITE ORDER
-- ---------------------------------------------------------------------------

--[[
    THE MENU IS THE SOURCE OF TRUTH.

    _data.lua generates one numeric row per favourited mod, stored as
    "favpos_<mod name>". This reads those values back.

    The first version kept the order in a single array setting edited by chat
    commands. That worked but was not what was asked for - the request was a
    menu - and it also meant two places could disagree about the order. The
    settings ARE the order now; the commands below only read and write the same
    values the menu does.

    Cached because mod:get CLONES table settings on every read
    (dmf settings.lua:82-87). These are numbers rather than tables so the clone
    does not apply, but sort_options can run several times while a menu is
    open and there is no reason to re-read a dozen settings each time.
--]]
local order_cache = nil

function mod.invalidate_favourite_order()
    order_cache = nil
end

--- name -> position, or nil when nothing has a position yet.
function mod.favourite_order()
    if order_cache then
        return order_cache
    end

    local favs = favourite_lookup()
    if not favs or not next(favs) then
        return nil
    end

    local out, any = {}, false

    for name in pairs(favs) do
        local ok, v = pcall(mod.get, mod, "favpos_" .. name)

        --[[
            DMFMod:get returns nil for a setting that has never been written -
            it reads the settings blob with NO default fallback
            (settings.lua:82-88). So a favourite whose row has not been touched
            has no position, and sorts after the ones that do rather than
            defaulting to 1 and fighting them.
        --]]
        if ok and type(v) == "number" then
            out[name] = v
            any = true
        end
    end

    if not any then
        return nil
    end

    order_cache = out
    return out
end

--[[
    The current favourites in the order they will appear, for /favs.
--]]
local function ordered_favourites()
    local favs = favourite_lookup()
    if not favs then
        return {}
    end

    local rank = mod.favourite_order() or {}
    local list = {}

    for name in pairs(favs) do
        list[#list + 1] = name
    end

    table.sort(list, function(a, b)
        local ra = rank[a] or math.huge
        local rb = rank[b] or math.huge

        if ra ~= rb then
            return ra < rb
        end

        return a < b
    end)

    return list
end

mod:command("favs", "List favourited mods in their current order", function()
    local list = ordered_favourites()

    if #list == 0 then
        mod:echo("[Sorter] no favourited mods - star them in the mod options list first")
        return
    end

    local rank = mod.favourite_order() or {}

    mod:echo("[Sorter] favourite order (edit in Dio's Sorter options, or /favmove):")

    for i = 1, #list do
        local r = rank[list[i]]
        mod:echo(string.format("  %d. %s%s", i, list[i], r and "" or "   (no position set)"))
    end
end)

mod:command("favmove", "Move a favourite: /favmove <from> <to>", function(from, to)
    local list = ordered_favourites()
    local a, b = tonumber(from), tonumber(to)

    if not a or not b then
        mod:echo("[Sorter] usage: /favmove <from> <to>   (see /favs for numbers)")
        return
    end

    if a < 1 or a > #list or b < 1 or b > #list then
        mod:echo(string.format("[Sorter] positions must be 1-%d", #list))
        return
    end

    if a == b then
        return
    end

    --[[
        Remove then insert, in that order. Inserting first shifts the element
        being removed and moves the wrong one.
    --]]
    local name = table.remove(list, a)
    table.insert(list, b, name)

    --[[
        Renumber EVERY favourite from the reordered list, so the menu values
        and this command can never disagree. notify_mod true so the sort and
        the cache invalidation both run through the normal handler rather than
        being poked by hand here.
    --]]
    for i = 1, #list do
        pcall(mod.set, mod, "favpos_" .. list[i], i, i == #list)
    end

    mod:echo(string.format("[Sorter] moved %s to position %d", name, b))
end)

mod:command("favreset", "Renumber favourites alphabetically", function()
    local favs = favourite_lookup()
    local list = {}

    for name in pairs(favs or {}) do
        list[#list + 1] = name
    end

    table.sort(list)

    for i = 1, #list do
        pcall(mod.set, mod, "favpos_" .. list[i], i, i == #list)
    end

    mod:echo(string.format("[Sorter] renumbered %d favourite(s) alphabetically", #list))
end)
