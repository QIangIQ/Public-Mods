local mod = get_mod("DiosSorter")

--[[
    No FFI, no file-scope work that can throw.

    SortModMenu builds its dropdown options here at load time by enumerating
    every installed mod and running each name through a kernel32 FFI call. If
    anything in that chain fails, _data.lua dies - and since _data.lua is what
    registers a mod's options, the mod vanishes from the settings menu while
    appearing to be installed correctly.

    This file is a plain table. There is nothing here that can fail.
--]]

--[[
	FAVOURITE ORDER - A GENERATED MENU.

	The ask was a draggable list or a menu to order favourites. Drag and drop
	means rebuilding the vanilla options grid - hit regions, drag ghost, drop
	index, reflow - from a mod, and that breaks on any Fatshark change to the
	options view. A menu is achievable, and this is it.

	DMF's options are static tables, so widgets cannot change while the game
	runs - but they CAN be generated at load from the favourites that exist now.
	One numeric row per favourited mod; lowest number sorts first.

	THE HONEST LIMITATION: starring a new mod does not add its row until the next
	reload, because this list is built at load. Stated in the tooltip rather than
	left to be discovered.

	Wrapped in pcall for the reason this file's header gives: if _data.lua throws,
	the mod vanishes from the settings menu while still appearing installed.
	Generated code is exactly what earns that caution.
--]]
local function favourite_widgets()
	local out = {}

	local ok, list = pcall(function()
		local dmf_mod = get_mod("DMF")
		return dmf_mod and dmf_mod:get("options_menu_favorite_mods") or nil
	end)

	if not ok or type(list) ~= "table" or #list == 0 then
		return nil
	end

	--[[
		Sorted so the menu has a stable order regardless of the order DMF
		happens to store favourites in - otherwise rows would shuffle between
		sessions and the numbers would appear to move on their own.
	--]]
	local names = {}

	for i = 1, #list do
		if type(list[i]) == "string" then
			names[#names + 1] = list[i]
		end
	end

	table.sort(names)

	for i = 1, #names do
		out[#out + 1] = {
			setting_id      = "favpos_" .. names[i],
			type            = "numeric",
			default_value   = i,
			range           = { 1, 60 },
			decimals_number = 0,
			step            = 1,
		}
	end

	return out
end

local fav_widgets = nil
local ok_gen, generated = pcall(favourite_widgets)

if ok_gen and generated and #generated > 0 then
	fav_widgets = generated
end

return {
	name        = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			{
				setting_id     = "sort_mode",
				type           = "dropdown",
				default_value  = "ascending",
				tooltip        = "sort_mode_tooltip",
				options = {
					{ text = "sort_ascending",  value = "ascending" },
					{ text = "sort_descending", value = "descending" },
					{ text = "sort_off",        value = "off" },
				},
			},
			{
				setting_id    = "favourites_first",
				type          = "checkbox",
				default_value = true,
				tooltip       = "favourites_first_tooltip",
			},
			{
				setting_id    = "shorten_names",
				type          = "checkbox",
				default_value = true,
				tooltip       = "shorten_names_tooltip",
			},
			{
				setting_id      = "name_limit",
				type            = "numeric",
				default_value   = 60,
				range           = { 10, 120 },
				decimals_number = 0,
				step            = 1,
				tooltip         = "name_limit_tooltip",
			},
			--[[
				Generated favourite-order rows, appended only when there are
				favourites to order. An empty group would render as a heading with
				nothing under it.
			--]]
			fav_widgets and {
				setting_id  = "group_fav_order",
				type        = "group",
				sub_widgets = fav_widgets,
			} or nil,
		},
	},
}
