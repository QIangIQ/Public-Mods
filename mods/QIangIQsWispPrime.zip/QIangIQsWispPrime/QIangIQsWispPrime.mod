return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsWispPrime` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsWispPrime", {
            mod_script = "QIangIQsWispPrime/scripts/mods/QIangIQsWispPrime/QIangIQsWispPrime",
            mod_data = "QIangIQsWispPrime/scripts/mods/QIangIQsWispPrime/QIangIQsWispPrime_data",
            mod_localization = "QIangIQsWispPrime/scripts/mods/QIangIQsWispPrime/QIangIQsWispPrime_localization",
        })
    end,
    version = "1.0.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
