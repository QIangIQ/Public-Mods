local mod = get_mod("QIangIQsWispPrime")

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = true,
    options = {
        widgets = {
            {
                setting_id = "model_enabled",
                type = "checkbox",
                default_value = false,
            },
            {
                setting_id = "hide_body",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "first_person_arms",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "menu_previews",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "physics_group",
                type = "group",
                sub_widgets = {
                    {
                        setting_id = "jiggle",
                        type = "checkbox",
                        default_value = true,
                    },
                    {
                        setting_id = "jiggle_cloth",
                        type = "numeric",
                        default_value = 1,
                        range = { 0, 3 },
                        decimals_number = 2,
                    },
                    {
                        setting_id = "jiggle_stiffness",
                        type = "numeric",
                        default_value = 1,
                        range = { 0.25, 3 },
                        decimals_number = 2,
                    },
                    {
                        setting_id = "jiggle_damping",
                        type = "numeric",
                        default_value = 1,
                        range = { 0.25, 3 },
                        decimals_number = 2,
                    },
                    {
                        setting_id = "jiggle_limit",
                        type = "numeric",
                        default_value = 1,
                        range = { 0.25, 3 },
                        decimals_number = 2,
                    },
                    {
                        setting_id = "jiggle_hang",
                        type = "numeric",
                        default_value = 0.15,
                        range = { 0, 1 },
                        decimals_number = 2,
                    },
                },
            },
            {
                setting_id = "toggle_keybind",
                type = "keybind",
                default_value = {},
                keybind_trigger = "pressed",
                keybind_type = "function_call",
                function_name = "toggle_model",
            },
        },
    },
}
