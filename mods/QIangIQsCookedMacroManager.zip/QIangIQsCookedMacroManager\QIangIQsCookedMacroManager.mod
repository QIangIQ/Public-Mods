return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsCookedMacroManager` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsCookedMacroManager", {
			mod_script       = "QIangIQsCookedMacroManager/scripts/mods/QIangIQsCookedMacroManager/QIangIQsCookedMacroManager",
			mod_data         = "QIangIQsCookedMacroManager/scripts/mods/QIangIQsCookedMacroManager/QIangIQsCookedMacroManager_data",
			mod_localization = "QIangIQsCookedMacroManager/scripts/mods/QIangIQsCookedMacroManager/QIangIQsCookedMacroManager_localization",
		})
	end,
	packages = {},
}
