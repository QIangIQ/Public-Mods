return {
    mod_name = {
        en = "QIangIQ's Syandana Gallery",
    },
    mod_description = {
        en = "Shows Warframe syandana models (taken from your own Warframe install) on your back, one at a time, picked from a list, each with its own saved position, turn and size. Works on the game's own characters and on the QIangIQ character models. Personal use only. By QIangIQ.",
    },
    enabled = {
        en = "Show the syandana",
    },
    enabled_description = {
        en = "Chat command: /syandana (on / off for this session), /syandana next, /syandana prev, /syandana <number>, /syandana <part of a name>.",
    },
    item = {
        en = "Syandana",
    },
    item_description = {
        en = "Which syandana is shown. The sliders below belong to the syandana picked here and are saved for it.",
    },
    item_x = {
        en = "Move right / left (cm)",
    },
    item_x_description = {
        en = "Moves this syandana to your right (+) or left (-).",
    },
    item_y = {
        en = "Move forward / back (cm)",
    },
    item_y_description = {
        en = "Moves this syandana forward (+) or back (-).",
    },
    item_z = {
        en = "Move up / down (cm)",
    },
    item_z_description = {
        en = "Moves this syandana up (+) or down (-).",
    },
    item_yaw = {
        en = "Turn (degrees)",
    },
    item_yaw_description = {
        en = "Turns this syandana about the vertical.",
    },
    item_pitch = {
        en = "Tilt (degrees)",
    },
    item_pitch_description = {
        en = "Tilts this syandana forward / back.",
    },
    item_roll = {
        en = "Roll (degrees)",
    },
    item_roll_description = {
        en = "Rolls this syandana to the side.",
    },
    item_scale = {
        en = "Size",
    },
    item_scale_description = {
        en = "1 = its Warframe size.",
    },
    reset_item = {
        en = "Reset this syandana",
    },
    reset_item_description = {
        en = "Puts this syandana's position, turn and size back to the default.",
    },
    menu_previews = {
        en = "Show in menus (operative previews)",
    },
    menu_previews_description = {
        en = "Also shows it on your own operatives in menu previews.",
    },
    physics_group = {
        en = "Physics",
    },
    jiggle = {
        en = "Physics on",
    },
    jiggle_description = {
        en = "Cloth physics on the syandana's own Warframe cloth bones (items that have them; up to 32 bones each).",
    },
    jiggle_cloth = {
        en = "Amount",
    },
    jiggle_cloth_description = {
        en = "1 = as built. Higher = looser and wider swings, lower = tighter. 0 = does not move.",
    },
    jiggle_stiffness = {
        en = "Stiffness",
    },
    jiggle_stiffness_description = {
        en = "How hard the cloth is pulled back to its rest pose. 1 = as built. Higher = snaps back faster, lower = softer and slower.",
    },
    jiggle_damping = {
        en = "Damping",
    },
    jiggle_damping_description = {
        en = "How quickly the wobble dies out. 1 = as built. Higher = settles at once, lower = keeps bouncing longer.",
    },
    jiggle_limit = {
        en = "Swing limit",
    },
    jiggle_limit_description = {
        en = "Scales the largest angle a bone may swing away from its rest pose. 1 = as built.",
    },
    jiggle_hang = {
        en = "Hang",
    },
    jiggle_hang_description = {
        en = "How strongly the cloth is drawn straight down instead of keeping its modelled direction when you lean or look up and down. 0 = keep the modelled shape.",
    },
    next_keybind = {
        en = "Next syandana",
    },
    prev_keybind = {
        en = "Previous syandana",
    },
    toggle_keybind = {
        en = "On / off for this session",
    },
    syn_april2015scarf = {
        en = "April2015 Scarf",
    },
    syn_archer = {
        en = "Archer",
    },
    syn_barocape = {
        en = "Baro Cape",
    },
    syn_barocape2 = {
        en = "Baro Cape2",
    },
    syn_barocape3 = {
        en = "Baro Cape3",
    },
    syn_baruukdeluxecape = {
        en = "Baruuk Deluxe Cape",
    },
    syn_billowingcape = {
        en = "Billowing Cape",
    },
    syn_centurioncape = {
        en = "Centurion Cape",
    },
    syn_cephsyandana = {
        en = "Ceph Syandana",
    },
    syn_conclavenrgcape = {
        en = "Conclave NRG Cape",
    },
    syn_crowsyandana = {
        en = "Crow Syandana",
    },
    syn_crpaladthemedscarf = {
        en = "Crp Alad Themed Scarf",
    },
    syn_crpcubinator = {
        en = "Crp Cubinator",
    },
    syn_crpmodularscarf = {
        en = "Crp Modular Scarf",
    },
    syn_daxsquarecape = {
        en = "Dax Square Cape",
    },
    syn_daxtwotailscape = {
        en = "Dax Two Tails Cape",
    },
    syn_dexsyandana = {
        en = "Dex Syandana",
    },
    syn_dinospikescarf = {
        en = "Dino Spike Scarf",
    },
    syn_draculacapesyandana = {
        en = "Dracula Cape Syandana",
    },
    syn_duelistsyandana = {
        en = "Duelist Syandana",
    },
    syn_emberdeluxebsyandana = {
        en = "Ember Deluxe B Syandana",
    },
    syn_emberdeluxesyandana = {
        en = "Ember Deluxe Syandana",
    },
    syn_energyscarf = {
        en = "Energy Scarf",
    },
    syn_equinoxdeluxe = {
        en = "Equinox Deluxe",
    },
    syn_equinoxprimecape = {
        en = "Equinox Prime Cape",
    },
    syn_erosioncape = {
        en = "Erosion Cape",
    },
    syn_fireflyscarf = {
        en = "Fire Fly Scarf",
    },
    syn_garudacape = {
        en = "Garuda Cape",
    },
    syn_garudadeluxesyandana = {
        en = "Garuda Deluxe Syandana",
    },
    syn_gaussdeluxecape = {
        en = "Gauss Deluxe Cape",
    },
    syn_gaussdeluxeiisyandana = {
        en = "Gauss Deluxe II Syandana",
    },
    syn_glassdeluxesyandana = {
        en = "Glass Deluxe Syandana",
    },
    syn_grendeldeluxeiisyandana = {
        en = "Grendel Deluxe II Syandana",
    },
    syn_grineerturbine = {
        en = "Grineer Turbine",
    },
    syn_grnamphisscarf = {
        en = "Grn Amphis Scarf",
    },
    syn_grnbannerscarf = {
        en = "Grn Banner Scarf",
    },
    syn_grnhoodedcape = {
        en = "Grn Hooded Cape",
    },
    syn_grnqueenscarf = {
        en = "Grn Queen Scarf",
    },
    syn_grnstraps = {
        en = "Grn Straps",
    },
    syn_grntubescarf = {
        en = "Grn Tube Scarf",
    },
    syn_grnvhcape = {
        en = "Grn Vh Cape",
    },
    syn_hildryndeluxecape = {
        en = "Hildryn Deluxe Cape",
    },
    syn_hornskullscarf = {
        en = "Horn Skull Scarf",
    },
    syn_icespikecape = {
        en = "Ice Spike Cape",
    },
    syn_inarosdlxcape = {
        en = "Inaros Dlx Cape",
    },
    syn_infbatcape = {
        en = "Inf Bat Cape",
    },
    syn_infcoralsyandana = {
        en = "Inf Coral Syandana",
    },
    syn_infgrnwolfcape = {
        en = "Inf Grn Wolf Cape",
    },
    syn_infmembranecape = {
        en = "Inf Membrane Cape",
    },
    syn_infribcage = {
        en = "Inf Rib Cage",
    },
    syn_inftentaclescarf = {
        en = "Inf Tentacle Scarf",
    },
    syn_infestedscarffins = {
        en = "Infested Scarf Fins",
    },
    syn_ivaradeluxessyandana = {
        en = "Ivara Deluxes Syandana",
    },
    syn_jadesyandana = {
        en = "Jade Syandana",
    },
    syn_lasbackpack = {
        en = "Las Backpack",
    },
    syn_lasnightwavecape = {
        en = "Las Nightwave Cape",
    },
    syn_limbodeluxecape = {
        en = "Limbo Deluxe Cape",
    },
    syn_lisetscarf = {
        en = "Liset Scarf",
    },
    syn_mesadeluxesyandana = {
        en = "Mesa Deluxe Syandana",
    },
    syn_narmerevosyandana = {
        en = "Narmer Evo Syandana",
    },
    syn_nefsyandana = {
        en = "Nef Syandana",
    },
    syn_nekrosdeluxechains = {
        en = "Nekros Deluxe Chains",
    },
    syn_nezhadeluxescarf = {
        en = "Nezha Deluxe Scarf",
    },
    syn_nezhaleveriancape = {
        en = "Nezha Leverian Cape",
    },
    syn_nidusdeluxescarf = {
        en = "Nidus Deluxe Scarf",
    },
    syn_novadeluxeeffigy = {
        en = "Nova Deluxe Effigy",
    },
    syn_novaiideluxesyandana = {
        en = "Nova II Deluxe Syandana",
    },
    syn_nyxdeluxesyandana = {
        en = "Nyx Deluxe Syandana",
    },
    syn_octaviadeluxe = {
        en = "Octavia Deluxe",
    },
    syn_pacifistsyandana = {
        en = "Pacifist Syandana",
    },
    syn_paxduviricussyandana = {
        en = "Pax Duviricus Syandana",
    },
    syn_priestscarf = {
        en = "Priest Scarf",
    },
    syn_primeakrabu = {
        en = "Prime Akrabu",
    },
    syn_primealtra = {
        en = "Prime Altra",
    },
    syn_primeartifexsyandana = {
        en = "Prime Artifex Syandana",
    },
    syn_primeavia = {
        en = "Prime Avia",
    },
    syn_primechromacape = {
        en = "Prime Chroma Cape",
    },
    syn_primecitrinesyandana = {
        en = "Prime Citrine Syandana",
    },
    syn_primegrendelsyandana = {
        en = "Prime Grendel Syandana",
    },
    syn_primeinarossyandana = {
        en = "Prime Inaros Syandana",
    },
    syn_primekhorasyandana = {
        en = "Prime Khora Syandana",
    },
    syn_primelimbocape = {
        en = "Prime Limbo Cape",
    },
    syn_primemerulinasyandana = {
        en = "Prime Merulina Syandana",
    },
    syn_primenavescarf = {
        en = "Prime Nave Scarf",
    },
    syn_primeneurovyre = {
        en = "Prime Neurovyre",
    },
    syn_primeniduscape = {
        en = "Prime Nidus Cape",
    },
    syn_primeoctaviasyandana = {
        en = "Prime Octavia Syandana",
    },
    syn_primepyra = {
        en = "Prime Pyra",
    },
    syn_primerevenantcape = {
        en = "Prime Revenant Cape",
    },
    syn_primerhoptron = {
        en = "Prime Rhoptron",
    },
    syn_primescarf = {
        en = "Prime Scarf",
    },
    syn_primescarfatlas = {
        en = "Prime Scarf Atlas",
    },
    syn_primescarfb = {
        en = "Prime Scarf B",
    },
    syn_primescarfc = {
        en = "Prime Scarf C",
    },
    syn_primescarfd = {
        en = "Prime Scarf D",
    },
    syn_primescarfe = {
        en = "Prime Scarf E",
    },
    syn_primescarff = {
        en = "Prime Scarf F",
    },
    syn_primescarfg = {
        en = "Prime Scarf G",
    },
    syn_primescarfoberon = {
        en = "Prime Scarf Oberon",
    },
    syn_primescarfv = {
        en = "Prime Scarf V",
    },
    syn_primestyanaxsyandana = {
        en = "Prime Styanax Syandana",
    },
    syn_primesuratorsyandana = {
        en = "Prime Surator Syandana",
    },
    syn_primetwitchscarf = {
        en = "Prime Twitch Scarf",
    },
    syn_primevitam = {
        en = "Prime Vitam",
    },
    syn_primevorunasyandana = {
        en = "Prime Voruna Syandana",
    },
    syn_primewispsyandana = {
        en = "Prime Wisp Syandana",
    },
    syn_primewukongsyandana = {
        en = "Prime Wukong Syandana",
    },
    syn_ps4obsidianscarf = {
        en = "PS4 Obsidian Scarf",
    },
    syn_ps5syandana = {
        en = "PS5 Syandana",
    },
    syn_qorvexdeluxesyandana = {
        en = "Qorvex Deluxe Syandana",
    },
    syn_quillcape = {
        en = "Quill Cape",
    },
    syn_rhinodeluxescarf = {
        en = "Rhino Deluxe Scarf",
    },
    syn_sapient = {
        en = "Sapient",
    },
    syn_sbflamescarf = {
        en = "SB Flame Scarf",
    },
    syn_sentsyandanab = {
        en = "Sent Syandana B",
    },
    syn_siriusorionsyandana = {
        en = "Sirius Orion Syandana",
    },
    syn_stalkerscarf = {
        en = "Stalker Scarf",
    },
    syn_swrausyandana = {
        en = "SW Rau Syandana",
    },
    syn_swreliquiasyandana = {
        en = "SW Reliquia Syandana",
    },
    syn_swrhodorasyandana = {
        en = "SW Rhodora Syandana",
    },
    syn_swronesyandana = {
        en = "SWR One Syandana",
    },
    syn_syndicatearbitersofhexis = {
        en = "Syndicate Arbiters Of Hexis",
    },
    syn_syndicatecephalon = {
        en = "Syndicate Cephalon",
    },
    syn_syndicatenewloka = {
        en = "Syndicate New Loka",
    },
    syn_syndicateperrinsequence = {
        en = "Syndicate Perrin Sequence",
    },
    syn_syndicatesteelmeridian = {
        en = "Syndicate Steel Meridian",
    },
    syn_tennoconscarf = {
        en = "Tenno Con Scarf",
    },
    syn_tennocon2017scarf = {
        en = "Tenno Con2017 Scarf",
    },
    syn_tennocon2020scarf = {
        en = "Tenno Con2020 Scarf",
    },
    syn_tennocon2023scarf = {
        en = "Tenno Con2023 Scarf",
    },
    syn_tennocon2025scarf = {
        en = "Tenno Con2025 Scarf",
    },
    syn_tennocon2025scarforokin = {
        en = "Tenno Con2025 Scarf Orokin",
    },
    syn_titaniadeluxev2cape = {
        en = "Titania Deluxe V2 Cape",
    },
    syn_titaniaprimesyandana = {
        en = "Titania Prime Syandana",
    },
    syn_tnalchemistsyandana = {
        en = "Tn Alchemist Syandana",
    },
    syn_tnashdeluxe2syandana = {
        en = "Tn Ash Deluxe2 Syandana",
    },
    syn_tnbrokenframesyandana = {
        en = "Tn Broken Frame Syandana",
    },
    syn_tncharityribbonsyandana = {
        en = "Tn Charity Ribbon Syandana",
    },
    syn_tnconcretesyandana = {
        en = "Tn Concrete Syandana",
    },
    syn_tnglasssyandana = {
        en = "Tn Glass Syandana",
    },
    syn_tnguandaoscarf = {
        en = "Tn Guandao Scarf",
    },
    syn_tngyrecape = {
        en = "Tn Gyre Cape",
    },
    syn_tnkorahsyandanadeluxe = {
        en = "Tn Korah Syandana Deluxe",
    },
    syn_tnlargecape = {
        en = "Tn Large Cape",
    },
    syn_tnlefaucheuxsyandana = {
        en = "Tn Lefaucheux Syandana",
    },
    syn_tnodalisksyandana = {
        en = "Tn Odalisk Syandana",
    },
    syn_tnonisyandana = {
        en = "Tn Oni Syandana",
    },
    syn_tnpagemastersyandana = {
        en = "Tn Pagemaster Syandana",
    },
    syn_tnpyrav2syandana = {
        en = "Tn Pyra V2 Syandana",
    },
    syn_tnrailjacksyandana = {
        en = "Tn Railjack Syandana",
    },
    syn_tnsmallbatterycape = {
        en = "Tn Small Battery Cape",
    },
    syn_tnsparrowcape = {
        en = "Tn Sparrow Cape",
    },
    syn_tnstyanaxsyandana = {
        en = "Tn Styanax Syandana",
    },
    syn_tnsundialcape = {
        en = "Tn Sundial Cape",
    },
    syn_tnsyandananewplayerxpmeshskin = {
        en = "Tn Syandana New Player Xp Mesh Skin",
    },
    syn_tnvoltdeluxesyandana = {
        en = "Tn Volt Deluxe Syandana",
    },
    syn_tnwispdeluxesyandana = {
        en = "Tn Wisp Deluxe Syandana",
    },
    syn_tnwraithesyandana = {
        en = "Tn Wraithe Syandana",
    },
    syn_turtleneckscarf = {
        en = "Turtle Neck Scarf",
    },
    syn_twitchprime = {
        en = "Twitch Prime",
    },
    syn_twitch2021syandana = {
        en = "Twitch2021 Syandana",
    },
    syn_u17intermscarf = {
        en = "U17 Interm Scarf",
    },
    syn_u17tnocape = {
        en = "U17 Tno Cape",
    },
    syn_umbradaxsyandana = {
        en = "Umbra Dax Syandana",
    },
    syn_wolf = {
        en = "Wolf",
    },
}
