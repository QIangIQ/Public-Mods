return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsSyandanaGallery` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsSyandanaGallery", {
            mod_script = "QIangIQsSyandanaGallery/scripts/mods/QIangIQsSyandanaGallery/QIangIQsSyandanaGallery",
            mod_data = "QIangIQsSyandanaGallery/scripts/mods/QIangIQsSyandanaGallery/QIangIQsSyandanaGallery_data",
            mod_localization = "QIangIQsSyandanaGallery/scripts/mods/QIangIQsSyandanaGallery/QIangIQsSyandanaGallery_localization",
        })
    end,
    version = "1.1.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
