return {
    mod_name = {
        en = "QIangIQ's MMJ Silenced Uzi",
    },
    mod_description = {
        en = "Replaces the Recon Lasgun with Mullet Mad Jack's silenced Uzi: MMJ's sprites and clips in first person, a shot clip and sound for every round. Visual only: the weapon still works as before. Contains Mullet Mad Jack art and audio: personal use only.",
    },
    command_desc = { en = "MMJ Silenced Uzi status (add flip to turn the sprite rotation round)" },
    replace_lasgun_p3_m1 = { en = "Replace Recon Lasgun (lasgun_p3_m1)" },
    replace_lasgun_p3_m2 = { en = "Replace Recon Lasgun (lasgun_p3_m2)" },
    replace_lasgun_p3_m3 = { en = "Replace Recon Lasgun (lasgun_p3_m3)" },
    third_person = { en = "Third person: your character" },
    third_person_others = { en = "Third person: other players" },
    third_person_hide = { en = "Hide the weapon" },
    third_person_retail = { en = "Show the weapon" },
    sounds = { en = "MMJ sounds" },
    volume = { en = "Sound volume (%%)" },
    layout = { en = "Screen layout" },
    mmj_fov = { en = "MMJ weapon camera field of view (degrees)" },
    size = { en = "Size (%%)" },
    offset_x = { en = "Move right (cm)" },
    offset_y = { en = "Move up (cm)" },
    smear_cap = { en = "Fade sprites bigger than this share of the screen (%%, 0 = off)" },
}
