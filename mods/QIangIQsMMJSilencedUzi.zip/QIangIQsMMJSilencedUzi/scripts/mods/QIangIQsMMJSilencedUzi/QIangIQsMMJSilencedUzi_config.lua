-- QIangIQsMMJSilencedUzi per-weapon data (gen.py spec silenced_uzi). Clips are MMJ clip names from silenced_uzi\OBJ-Weapon-SilenceUzi__23364.
-- Action map sources: Darktide weapon templates (Aussiemon master) via tools\dump_actions.py.
return {
    ranged = true,
    idle = "silence-uzi-idle",
    templates = { lasgun_p3_m1 = true, lasgun_p3_m2 = true, lasgun_p3_m3 = true },
    shot = { clips = { "silence-uzi-shot" }, sounds = { "255716__paul368__silenced-pistol-layered-powerful.ogg" } },
    actions = {
        action_wield = { clips = { "silence-uzi-introfast" }, over_shot = true, sounds = { "sfx_wp_uzi_intro.ogg" } },
        action_reload = { clips = { "silence-uzi-reload" }, stretch = true, reload_template = true, over_shot = true, sounds = { "sfx_wp_uzi_reload.ogg" } },
    },
}
