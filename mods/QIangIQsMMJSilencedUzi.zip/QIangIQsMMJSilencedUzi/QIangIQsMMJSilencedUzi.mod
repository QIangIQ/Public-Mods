return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsMMJSilencedUzi` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsMMJSilencedUzi", {
            mod_script = "QIangIQsMMJSilencedUzi/scripts/mods/QIangIQsMMJSilencedUzi/QIangIQsMMJSilencedUzi",
            mod_data = "QIangIQsMMJSilencedUzi/scripts/mods/QIangIQsMMJSilencedUzi/QIangIQsMMJSilencedUzi_data",
            mod_localization = "QIangIQsMMJSilencedUzi/scripts/mods/QIangIQsMMJSilencedUzi/QIangIQsMMJSilencedUzi_localization",
        })
    end,
    version = "0.1.0",
    author = "QIangIQ",
    packages = {},
}
