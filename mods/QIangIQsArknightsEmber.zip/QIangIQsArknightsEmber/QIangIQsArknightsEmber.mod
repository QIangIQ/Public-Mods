return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsArknightsEmber` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsArknightsEmber", {
            mod_script = "QIangIQsArknightsEmber/scripts/mods/QIangIQsArknightsEmber/QIangIQsArknightsEmber",
            mod_data = "QIangIQsArknightsEmber/scripts/mods/QIangIQsArknightsEmber/QIangIQsArknightsEmber_data",
            mod_localization = "QIangIQsArknightsEmber/scripts/mods/QIangIQsArknightsEmber/QIangIQsArknightsEmber_localization",
        })
    end,
    version = "1.1.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
