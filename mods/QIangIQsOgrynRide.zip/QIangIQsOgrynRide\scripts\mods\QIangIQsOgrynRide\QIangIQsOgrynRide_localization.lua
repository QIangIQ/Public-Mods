return {
	mod_name = {
		en = "QIangIQ's Ogryn Ride",
	},
	mod_description = {
		en = "Ride on an Ogryn's back. You cannot move, but you can still look around and shoot from up there.\nWorks when you are the host (SoloPlay or Realms), and on a Realms game when the host also has Ogryn Ride.\n\nHold K (rebindable) while looking at an Ogryn to get on or off.\n/ride  get on or off the nearest Ogryn (jump also gets off)\n/ridego  an Ogryn bot walks where you look / stops\n/ridebot  spawn an Ogryn bot\n/ridebotdespawn  remove the bots this mod spawned",
	},
	group_keys = {
		en = "Keybinds",
	},
	key_ride = {
		en = "Get on / off the nearest Ogryn",
	},
	key_walk = {
		en = "Ogryn bot: walk where I look / stop",
	},
	key_spawn = {
		en = "Spawn an Ogryn bot",
	},
	group_interact = {
		en = "Hold to ride",
	},
	interact_mount = {
		en = "Show the hold-to-ride prompt near an Ogryn",
	},
	interact_mount_description = {
		en = "Shows a prompt when you look at a free Ogryn within 2.5 m, like the revive prompt. It uses its own key, separate from the game's Interact key, so pickups, doors and reviving are never affected.",
	},
	key_ride_hold = {
		en = "Hold to ride / get off (own key, not Interact)",
	},
	interact_hold_time = {
		en = "Hold time (s)",
	},
	group_seat = {
		en = "Seat",
	},
	seat_mode = {
		en = "Seats per Ogryn",
	},
	seat_mode_description = {
		en = "Back: one rider. Shoulders: two riders, one on each shoulder. The host's setting decides.",
	},
	seat_mode_back = {
		en = "Back (1 rider)",
	},
	seat_mode_shoulders = {
		en = "Shoulders (2 riders)",
	},
	shoulder_width = {
		en = "Shoulder seat distance from the middle (m)",
	},
	shoulder_width_description = {
		en = "Each shoulder rider sits this far to the side. Never closer than your collision radius, so the two riders cannot overlap.",
	},
	seat_height_v2 = {
		en = "Seat height (m)",
	},
	seat_height_v2_description = {
		en = "Height above the Ogryn's feet (the Ogryn is 2.2 m tall). Below 2.2 your collision body stays on top of the Ogryn (overlapping bodies froze the game) and only your visible body, camera and shots sink into the Ogryn. 1.3 = only your upper body shows.",
	},
	seat_back = {
		en = "Seat offset behind the Ogryn (m)",
	},
	crouch_pose = {
		en = "Crouch while riding",
	},
	crouch_pose_description = {
		en = "Your third-person body uses the game's crouch animation while riding. Only the look changes.",
	},
	sit_emote_slot = {
		en = "Emote slot to play while riding",
	},
	sit_emote_slot_description = {
		en = "0 = off. Plays the emote equipped in this slot instead of crouching. Needs QIangIQ's Emotes.",
	},
	group_bot = {
		en = "Ogryn bot",
	},
	steer_distance = {
		en = "Walk target distance ahead (m)",
	},
	debug_log = {
		en = "Write ride diagnostics to the console log",
	},
}
