local mod = get_mod("QIangIQsOgrynRide")

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			{
				setting_id = "group_keys",
				type = "group",
				sub_widgets = {
					{
						setting_id      = "key_ride",
						type            = "keybind",
						default_value   = {},
						keybind_global  = true,
						keybind_trigger = "pressed",
						keybind_type    = "function_call",
						function_name   = "toggle_ride",
					},
					{
						setting_id      = "key_walk",
						type            = "keybind",
						default_value   = {},
						keybind_global  = true,
						keybind_trigger = "pressed",
						keybind_type    = "function_call",
						function_name   = "toggle_walk",
					},
					{
						setting_id      = "key_spawn",
						type            = "keybind",
						default_value   = {},
						keybind_global  = true,
						keybind_trigger = "pressed",
						keybind_type    = "function_call",
						function_name   = "spawn_ogryn_bot",
					},
				},
			},
			{
				setting_id = "group_interact",
				type = "group",
				sub_widgets = {
					{
						setting_id    = "interact_mount",
						type          = "checkbox",
						default_value = true,
					},
					{
						setting_id      = "key_ride_hold",
						type            = "keybind",
						default_value   = { "k" },
						keybind_global  = false,
						keybind_trigger = "held",
						keybind_type    = "function_call",
						function_name   = "ride_key_held",
					},
					{
						setting_id      = "interact_hold_time",
						type            = "numeric",
						default_value   = 1,
						range           = { 0.2, 3 },
						decimals_number = 1,
					},
				},
			},
			{
				setting_id = "group_seat",
				type = "group",
				sub_widgets = {
					{
						setting_id    = "seat_mode",
						type          = "dropdown",
						default_value = "back",
						options       = {
							{ text = "seat_mode_back",      value = "back" },
							{ text = "seat_mode_shoulders", value = "shoulders" },
						},
					},
					{
						setting_id      = "shoulder_width",
						type            = "numeric",
						default_value   = 0.6,
						range           = { 0.3, 1.5 },
						decimals_number = 2,
					},
					{
						setting_id      = "seat_height_v2",
						type            = "numeric",
						default_value   = 2.25,
						range           = { 0, 4 },
						decimals_number = 2,
					},
					{
						setting_id      = "seat_back",
						type            = "numeric",
						default_value   = 0.3,
						range           = { -2, 2 },
						decimals_number = 2,
					},
					{
						setting_id    = "crouch_pose",
						type          = "checkbox",
						default_value = true,
					},
					{
						setting_id      = "sit_emote_slot",
						type            = "numeric",
						default_value   = 0,
						range           = { 0, 5 },
						decimals_number = 0,
					},
				},
			},
			{
				setting_id = "group_bot",
				type = "group",
				sub_widgets = {
					{
						setting_id      = "steer_distance",
						type            = "numeric",
						default_value   = 6,
						range           = { 2, 12 },
						decimals_number = 1,
					},
					{
						setting_id    = "debug_log",
						type          = "checkbox",
						default_value = false,
					},
				},
			},
		},
	},
}
