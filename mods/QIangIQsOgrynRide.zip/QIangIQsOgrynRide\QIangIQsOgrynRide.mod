return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsOgrynRide` encountered an error loading the Darktide Mod Framework.")

		new_mod("QIangIQsOgrynRide", {
			mod_script       = "QIangIQsOgrynRide/scripts/mods/QIangIQsOgrynRide/QIangIQsOgrynRide",
			mod_data         = "QIangIQsOgrynRide/scripts/mods/QIangIQsOgrynRide/QIangIQsOgrynRide_data",
			mod_localization = "QIangIQsOgrynRide/scripts/mods/QIangIQsOgrynRide/QIangIQsOgrynRide_localization",
		})
	end,
	version = "1.3.0",
	author = "QIangIQ",
	packages = {},
}
