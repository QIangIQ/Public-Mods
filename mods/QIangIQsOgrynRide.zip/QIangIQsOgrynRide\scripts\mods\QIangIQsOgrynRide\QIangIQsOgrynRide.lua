local mod = get_mod("QIangIQsOgrynRide")

-- QIangIQ's Ogryn Ride: ride on an Ogryn's back.
-- The rider stays in its normal character state, so weapons and looking work; every fixed update it
-- is teleported onto the Ogryn and its movement input is zeroed. An Ogryn bot is steered with its
-- hold-position order (the same call the game's bot_hold_position flow node uses).
--
-- Roles:
--   host   (game_session:is_server(): SoloPlay, Realms host) decides every ride, for itself and for
--          Realms clients. It runs the teleport for each rider, because the server's position counts.
--   client (Realms client with this mod) asks the host over the Realms network API and, once the host
--          confirms, runs the same teleport on its own predicted unit so prediction agrees with the host.

local BotCharacterProfiles = require("scripts/settings/bot_character_profiles") -- bot_spawner
local BotSpawning = require("scripts/managers/bot/bot_spawning") -- bot_spawner
local MasterItems = require("scripts/backend/master_items") -- bot_spawner
local NavQueries = require("scripts/utilities/nav_queries") -- flow_callbacks.lua:19
local PlayerMovement = require("scripts/utilities/player_movement") -- player_character_state_grabbed.lua:11
local PlayerUnitStatus = require("scripts/utilities/attack/player_unit_status") -- bot_group.lua

-- Ogryn bot profiles with bot_gestalts first (tutorial_bot_profiles.lua), then misc_bot_profiles.lua.
local OGRYN_BOT_PROFILES = { "tutorial_guide_ogryn", "darktide_seven_02" }
local MOUNT_RANGE = 4
local NAV_ABOVE, NAV_BELOW = 0.5, 2 -- flow_callbacks.lua:1445
local STEER_INTERVAL = 1
local STEER_MIN_CHANGE = 2 -- metres the walk target must move before it is sent again
-- The Ogryn body is 2.2 m tall (breed_settings.lua base_player_body_size_heights.ogryn_sized). A lower
-- seat puts the rider's collision capsule inside the Ogryn's, which froze the game once the Ogryn walked.
-- So the collision seat never goes below this; a lower setting only sinks the rendered body, camera and
-- shot origin (see "Sink" below).
local MIN_SEAT_HEIGHT = 2.2
-- Performance guard: frames slower than this, this many in a row, stop walking / dismount.
local SLOW_FRAME_DT = 0.25
local SLOW_FRAMES_STOP_WALK = 8
local SLOW_FRAMES_DISMOUNT = 20
local DIAG_INTERVAL = 2

-- Realms network RPC names (Realms/docs/README.md "Network API").
local RPC_REQUEST = "ride_request" -- client -> host
local RPC_DISMOUNT = "ride_dismount" -- client -> host
local RPC_WALK = "ride_walk" -- client -> host
local RPC_STATE = "ride_state" -- host -> client
local RPC_MSG = "ride_msg" -- host -> client

-- Movement inputs read by the character states (character_states/*.lua, utilities/dodge.lua).
local BLOCKED_INPUTS = {
	jump = true,
	jump_held = true,
	dodge = true,
	stationary_dodge = true,
	always_dodge = true,
	diagonal_forward_dodge = true,
	sprint = true,
	sprinting = true,
	hold_to_sprint = true,
	crouch = true,
	crouching = true,
	hold_to_crouch = true,
}

-- riders[rider_unit] = record. The host holds every rider; a client holds only its own.
local riders = {}
local riders_by_player = {}
local mounted_by = {} -- [mount_unit] = { [seat] = rider_unit }, seat = "back" | "left" | "right"
local drops = {} -- [rider_unit] = Vector3Box: put down here on its next fixed update
local spawned_bot_ids = {}
local slow_frames = 0
local next_diag_t = 0
local realms = nil
local network_ready = false

-- ##########################################################
-- Helpers

local function is_server()
	local game_session = Managers.state and Managers.state.game_session

	return game_session and game_session:is_server()
end

local function chat_open()
	return Managers.ui and Managers.ui:chat_using_input()
end

local function local_player()
	return Managers.player and Managers.player:local_player_safe(1)
end

local function normalize_peer(peer_id)
	return string.lower(tostring(peer_id))
end

local function is_realms_client()
	local connection = Managers.connection

	return network_ready and not is_server() and connection and connection:is_client() and realms.network_is_available() or false
end

local function host_peer()
	local connection = Managers.connection

	return connection and connection:host() and normalize_peer(connection:host())
end

local function breed_name(unit)
	local unit_data_extension = ScriptUnit.has_extension(unit, "unit_data_system")
	local breed = unit_data_extension and unit_data_extension:breed()

	return breed and breed.name
end

local function is_disabled(unit)
	local unit_data_extension = ScriptUnit.extension(unit, "unit_data_system")

	return PlayerUnitStatus.is_disabled(unit_data_extension:read_component("character_state"))
end

-- Fresh position each call (player_character_state_grabbed.lua:73). POSITION_LOOKUP values
-- read from a chat command were not valid Vector3s in game.
local function unit_position(unit)
	return Unit.world_position(unit, 1)
end

local function send(rpc_name, recipient, ...)
	if not network_ready then
		return false, "Realms is not loaded"
	end

	local ok, sent, send_error = pcall(realms.network_send, mod, rpc_name, recipient, ...)

	if not ok then
		return false, tostring(sent)
	end

	return sent == true, send_error
end

-- Message to the rider: chat on this PC, or a Realms message to the client that rides.
local function tell(record, text)
	if record and record.peer then
		send(RPC_MSG, record.peer, text)
	else
		mod:echo(text)
	end
end

-- ##########################################################
-- Seats: one on the back, or one on each shoulder (setting "seat_mode").

local SEAT_SIDES = { back = 0, left = -1, right = 1 }
local SEAT_LABELS = { back = "back", left = "left shoulder", right = "right shoulder" }

local function seat_count(mount_unit)
	local count = 0

	for _ in pairs(mounted_by[mount_unit] or {}) do
		count = count + 1
	end

	return count
end

local function free_seat(mount_unit)
	local seats = mounted_by[mount_unit] or {}

	if mod:get("seat_mode") == "shoulders" then
		if seats.back then
			return nil
		end

		return not seats.left and "left" or not seats.right and "right" or nil
	end

	return next(seats) == nil and "back" or nil
end

local function seat_from_side(side)
	return side == -1 and "left" or side == 1 and "right" or "back"
end

-- Shoulder riders stand side by side at +-width: keep their two collision capsules apart
-- (PlayerUnitLocomotionExtension.mover_radius, player_unit_locomotion_extension.lua:1189).
local function safe_shoulder_width(rider_unit, width)
	local locomotion_extension = ScriptUnit.has_extension(rider_unit, "locomotion_system")
	local ok, radius = pcall(function ()
		return locomotion_extension and locomotion_extension.mover_radius and locomotion_extension:mover_radius()
	end)

	radius = ok and type(radius) == "number" and radius or 0.5

	return math.max(type(width) == "number" and width or 0.6, radius + 0.05)
end

local function find_nearest_ogryn(from_unit)
	local from_position = unit_position(from_unit)
	local best_unit, best_distance = nil, MOUNT_RANGE

	for _, player in pairs(Managers.player:players()) do
		local unit = player.player_unit

		if unit and unit ~= from_unit and player:unit_is_alive() and breed_name(unit) == "ogryn" and free_seat(unit) and not riders[unit] then
			local distance = Vector3.distance(from_position, unit_position(unit))

			if distance < best_distance then
				best_unit, best_distance = unit, distance
			end
		end
	end

	return best_unit
end

local function seat_position(record)
	local mount_unit = record.mount
	local rotation = Unit.local_rotation(mount_unit, 1)
	local position = unit_position(mount_unit) + Vector3(0, 0, record.seat_height) - Quaternion.forward(rotation) * record.seat_back

	if record.seat_side ~= 0 then
		position = position + Quaternion.right(rotation) * (record.seat_side * record.shoulder_width)
	end

	return position
end

local function bot_extensions(mount_unit)
	local behavior_extension = ScriptUnit.has_extension(mount_unit, "behavior_system")
	local navigation_extension = ScriptUnit.has_extension(mount_unit, "navigation_system")

	if behavior_extension and behavior_extension.set_hold_position and navigation_extension then
		return behavior_extension, navigation_extension
	end
end

local function position_on_mesh(navigation_extension, position)
	return NavQueries.position_on_mesh(navigation_extension:nav_world(), position, NAV_ABOVE, NAV_BELOW, navigation_extension:traverse_logic())
end

-- Send a hold position only when it moved enough; every send makes the bot plan a new path.
local function send_hold(record, behavior_extension, position, force)
	local last = record.last_hold and record.last_hold:unbox()

	if not force and last and Vector3.distance(last, position) < STEER_MIN_CHANGE then
		return
	end

	behavior_extension:set_hold_position(position, 1)

	if record.last_hold then
		record.last_hold:store(position)
	else
		record.last_hold = Vector3Box(position)
	end
end

-- ##########################################################
-- Pose

-- Crouch: the third-person crouch events the game itself uses (crouch.lua:53, :69). Only the
-- animation; movement state and collision stay standing. On the host the event of a client's unit
-- goes through AuthoritativePlayerUnitAnimationExtension, which passes it on to the other clients.
local function rider_anim_event(unit, event_name)
	local animation_extension = ScriptUnit.has_extension(unit, "animation_system")

	if animation_extension then
		pcall(animation_extension.anim_event, animation_extension, event_name)
	end
end

-- Emote: one of the local player's equipped emote slots through QIangIQsEmotes (mod.emote_1..5,
-- mod.stop_emote). The game source has no sit animation by name.
local function start_pose(record)
	if record.is_local then
		local slot = math.floor(mod:get("sit_emote_slot") or 0)
		local emotes = slot > 0 and get_mod("QIangIQsEmotes")
		local play = emotes and emotes["emote_" .. slot]

		if play then
			local ok, err = pcall(play)

			record.emote_started = ok

			if not ok then
				mod:echo("Riding emote failed: " .. tostring(err))
			end
		elseif slot > 0 then
			mod:echo("The riding emote needs QIangIQ's Emotes.")
		end
	end

	if not record.emote_started and mod:get("crouch_pose") then
		record.crouched = true
		rider_anim_event(record.unit, "to_crouch")
	end
end

local function end_pose(record)
	if record.emote_started then
		local emotes = get_mod("QIangIQsEmotes")

		if emotes and emotes.stop_emote then
			pcall(emotes.stop_emote)
		end
	end

	local was_crouched = record.crouched

	record.emote_started = false
	record.crouched = false
	record.recrouch = false

	if was_crouched and ALIVE[record.unit] then
		rider_anim_event(record.unit, "to_uncrouch")
	end
end

-- ##########################################################
-- Records

local function add_record(rider_unit, rider_player, mount_unit, fields)
	local record = {
		unit = rider_unit,
		player = rider_player,
		mount = mount_unit,
		is_local = fields.is_local,
		authority = fields.authority,
		peer = fields.peer,
		seat_height = math.max(fields.seat_height, MIN_SEAT_HEIGHT),
		raw_seat_height = fields.seat_height,
		visual_drop = math.max(MIN_SEAT_HEIGHT - fields.seat_height, 0),
		seat_back = fields.seat_back,
		seat = fields.seat,
		seat_side = SEAT_SIDES[fields.seat] or 0,
		shoulder_width = safe_shoulder_width(rider_unit, fields.shoulder_width),
		walking = false,
		dismount_requested = false,
		dismount_sent = false,
		next_steer_t = 0,
		last_hold = nil,
		crouched = false,
		recrouch = false,
		emote_started = false,
	}

	riders[rider_unit] = record
	riders_by_player[rider_player] = record
	mounted_by[mount_unit] = mounted_by[mount_unit] or {}
	mounted_by[mount_unit][fields.seat] = rider_unit

	return record
end

local function remove_record(record)
	riders[record.unit] = nil
	riders_by_player[record.player] = nil

	local seats = mounted_by[record.mount]

	if seats and seats[record.seat] == record.unit then
		seats[record.seat] = nil

		if next(seats) == nil then
			mounted_by[record.mount] = nil
		end
	end
end

-- Other riders on the same Ogryn.
local function co_riders(record)
	local list = {}

	for _, rider_unit in pairs(mounted_by[record.mount] or {}) do
		local other = riders[rider_unit]

		if other and other ~= record then
			list[#list + 1] = other
		end
	end

	return list
end

local function local_record()
	local player = local_player()

	return player and riders_by_player[player]
end

-- ##########################################################
-- Host: mount / dismount

local function host_drop_position(record)
	local mount_unit = record.mount

	if not ALIVE[record.unit] or not ALIVE[mount_unit] then
		return nil
	end

	-- Beside the Ogryn on the nav mesh when the Ogryn is a bot; otherwise at its feet.
	local drop = unit_position(mount_unit)
	local _, navigation_extension = bot_extensions(mount_unit)

	if navigation_extension then
		local forward = Quaternion.forward(Unit.local_rotation(mount_unit, 1))

		drop = position_on_mesh(navigation_extension, drop - forward * 1.2) or drop
	end

	return drop
end

local function host_dismount(record, reason)
	local drop = host_drop_position(record)

	if drop then
		drops[record.unit] = Vector3Box(drop)
	end

	if ALIVE[record.mount] then
		local behavior_extension = bot_extensions(record.mount)

		-- Release the bot only when nobody else is still riding it.
		if behavior_extension and seat_count(record.mount) <= 1 then
			behavior_extension:set_hold_position(nil)
		end
	end

	local others = co_riders(record)

	end_pose(record)
	remove_record(record)

	-- A walking rider got off: the one still up there holds the Ogryn where it is.
	if record.walking then
		for i = 1, #others do
			others[i].last_hold = nil
			others[i].next_steer_t = 0
		end
	end

	if record.peer then
		if drop then
			send(RPC_STATE, record.peer, false, nil, nil, nil, nil, drop.x, drop.y, drop.z)
		else
			send(RPC_STATE, record.peer, false)
		end
	end

	if reason then
		tell(record, "Dismounted: " .. reason)
	end
end

-- Checks shared by the host's own /ride and a client's request. Returns the mount or nil.
local function host_pick_mount(rider_unit, record_for_messages)
	if not rider_unit or not ALIVE[rider_unit] then
		return nil
	end

	if riders[rider_unit] then
		return nil
	end

	if breed_name(rider_unit) == "ogryn" then
		tell(record_for_messages, "Ogryns are too big to ride an Ogryn.")

		return nil
	end

	if seat_count(rider_unit) > 0 then
		tell(record_for_messages, "Someone is riding you.")

		return nil
	end

	if is_disabled(rider_unit) then
		return nil
	end

	local mount_unit = find_nearest_ogryn(rider_unit)

	if not mount_unit then
		tell(record_for_messages, string.format("No free Ogryn seat within %d m.", MOUNT_RANGE))
	end

	return mount_unit
end

local function host_mount(rider_unit, rider_player, mount_unit, peer)
	local seat = free_seat(mount_unit)

	if not seat then
		tell({ peer = peer }, "No free seat on that Ogryn.")

		return
	end

	local first = seat_count(mount_unit) == 0
	local record = add_record(rider_unit, rider_player, mount_unit, {
		is_local = peer == nil,
		authority = true,
		peer = peer,
		seat = seat,
		seat_height = mod:get("seat_height_v2"),
		seat_back = mod:get("seat_back"),
		shoulder_width = mod:get("shoulder_width"),
	})

	start_pose(record)

	local behavior_extension = bot_extensions(mount_unit)

	-- Only the first rider stops the bot; a second rider joins whatever it is doing.
	if behavior_extension and first then
		send_hold(record, behavior_extension, unit_position(mount_unit), true)
	elseif behavior_extension then
		record.last_hold = Vector3Box(unit_position(mount_unit))
	end

	if peer then
		local mount_player = Managers.state.player_unit_spawn:owner(mount_unit)

		-- Raw height: the client clamps the collision seat itself and sinks the rest (1.0.x clients only clamp).
		-- Seat side and shoulder width ride in the drop_x / drop_y slots (unused while mounted; older clients ignore them).
		send(RPC_STATE, peer, true, mount_player:peer_id(), mount_player:local_player_id(), record.raw_seat_height, record.seat_back, record.seat_side, record.shoulder_width)
	end

	local where = SEAT_LABELS[seat]

	if behavior_extension then
		tell(record, "Mounted an Ogryn bot (" .. where .. "). /ridego (or the walk key) makes it walk where you look.")
	else
		tell(record, "Mounted an Ogryn (" .. where .. "; player-controlled, it moves you).")
	end
end

local function host_toggle_walk(record)
	if not bot_extensions(record.mount) then
		tell(record, "This Ogryn is not a bot; it walks by itself.")

		return
	end

	record.walking = not record.walking
	record.next_steer_t = 0
	record.last_hold = nil

	-- One steerer per Ogryn: whoever starts walking takes over from the other rider.
	if record.walking then
		for _, other in ipairs(co_riders(record)) do
			if other.walking then
				other.walking = false
				tell(other, "Ogryn: the other rider is steering now.")
			end
		end
	end

	tell(record, record.walking and "Ogryn: walking where you look." or "Ogryn: holding position.")
end

local function host_record_for_peer(peer)
	for _, record in pairs(riders) do
		if record.peer == peer then
			return record
		end
	end
end

local function host_player_for_peer(peer)
	for _, player in pairs(Managers.player:players()) do
		if player:is_human_controlled() and player:local_player_id() == 1 and normalize_peer(player:peer_id()) == peer then
			return player
		end
	end
end

-- ##########################################################
-- Client: state from the host

local function client_clear(drop)
	local record = local_record()

	if record then
		end_pose(record)
		remove_record(record)

		if drop and ALIVE[record.unit] then
			drops[record.unit] = Vector3Box(drop)
		end
	end
end

local function on_state(sender, mounted, mount_peer, mount_local_player_id, seat_height, seat_back, drop_x, drop_y, drop_z)
	if is_server() or sender ~= host_peer() then
		return
	end

	if not mounted then
		local drop = type(drop_x) == "number" and type(drop_y) == "number" and type(drop_z) == "number" and Vector3(drop_x, drop_y, drop_z) or nil

		client_clear(drop)

		return
	end

	if type(mount_peer) ~= "string" or type(mount_local_player_id) ~= "number" or type(seat_height) ~= "number" or type(seat_back) ~= "number" then
		return
	end

	local player = local_player()
	local rider_unit = player and player.player_unit
	local mount_player = Managers.player:player(mount_peer, mount_local_player_id)
	local mount_unit = mount_player and mount_player.player_unit

	if not rider_unit or not ALIVE[rider_unit] or not mount_unit or not ALIVE[mount_unit] then
		send(RPC_DISMOUNT, "host")

		return
	end

	client_clear(nil)

	local side = type(drop_x) == "number" and drop_x or 0

	local record = add_record(rider_unit, player, mount_unit, {
		is_local = true,
		authority = false,
		seat = seat_from_side(side),
		seat_height = seat_height,
		seat_back = seat_back,
		shoulder_width = type(drop_y) == "number" and drop_y or nil,
	})

	start_pose(record)
end

local function on_msg(sender, text)
	if is_server() or sender ~= host_peer() or type(text) ~= "string" then
		return
	end

	mod:echo(text)
end

-- ##########################################################
-- Host: requests from clients

local function on_request(sender)
	if not is_server() then
		return
	end

	local player = host_player_for_peer(sender)
	local rider_unit = player and player.player_unit

	if not rider_unit then
		return
	end

	local mount_unit = host_pick_mount(rider_unit, { peer = sender })

	if mount_unit then
		host_mount(rider_unit, player, mount_unit, sender)
	end
end

local function on_dismount(sender)
	if not is_server() then
		return
	end

	local record = host_record_for_peer(sender)

	if record then
		host_dismount(record, "by command")
	end
end

local function on_walk(sender)
	if not is_server() then
		return
	end

	local record = host_record_for_peer(sender)

	if record then
		host_toggle_walk(record)
	end
end

-- ##########################################################
-- Per fixed update (runs inside the rider's locomotion update, on the host and on the riding client)

local function hold_seat(record)
	PlayerMovement.teleport_fixed_update(record.unit, seat_position(record))

	local unit_data_extension = ScriptUnit.extension(record.unit, "unit_data_system")
	local locomotion_component = unit_data_extension:write_component("locomotion")

	locomotion_component.velocity_current = Vector3.zero()
end

local function steer(record, t)
	if t < record.next_steer_t then
		return
	end

	record.next_steer_t = t + STEER_INTERVAL

	local behavior_extension, navigation_extension = bot_extensions(record.mount)

	if not behavior_extension then
		return
	end

	local mount_position = unit_position(record.mount)

	if not record.walking then
		local other_steers = false

		for _, other in ipairs(co_riders(record)) do
			other_steers = other_steers or other.walking
		end

		if not record.last_hold and not other_steers then
			send_hold(record, behavior_extension, mount_position, true)
		end

		return
	end

	local unit_data_extension = ScriptUnit.extension(record.unit, "unit_data_system")
	local look_rotation = unit_data_extension:read_component("first_person").rotation
	local forward = Vector3.flat(Quaternion.forward(look_rotation))

	if Vector3.length_squared(forward) < 0.0001 then
		return
	end

	forward = Vector3.normalize(forward)

	local distance = mod:get("steer_distance")

	for _, scale in ipairs({ 1, 0.6, 0.3 }) do
		local target = position_on_mesh(navigation_extension, mount_position + forward * distance * scale)

		if target then
			send_hold(record, behavior_extension, target, false)

			return
		end
	end
end

local function should_dismount(record)
	if record.dismount_requested then
		return "jump"
	elseif not ALIVE[record.mount] then
		return "Ogryn gone"
	elseif not ALIVE[record.unit] then
		return "rider gone"
	elseif is_disabled(record.mount) then
		return "Ogryn disabled"
	elseif is_disabled(record.unit) then
		return "rider disabled"
	end
end

mod:hook("PlayerUnitLocomotionExtension", "fixed_update", function (func, self, unit, dt, t, frame)
	local record = riders[unit]

	if record then
		if record.authority then
			local reason = should_dismount(record)

			if reason then
				host_dismount(record, reason)

				return func(self, unit, dt, t, frame)
			end
		else
			-- Client: the host decides. Ask once on jump; wait while the Ogryn is not here yet.
			if record.dismount_requested and not record.dismount_sent then
				record.dismount_sent = true
				send(RPC_DISMOUNT, "host")
			end

			if not ALIVE[record.mount] then
				return func(self, unit, dt, t, frame)
			end
		end

		local ok, err = pcall(hold_seat, record)

		if ok and record.authority then
			ok, err = pcall(steer, record, t)
		end

		if not ok then
			mod:echo("Ride error: " .. tostring(err))

			if record.authority then
				host_dismount(record, "error")
			else
				send(RPC_DISMOUNT, "host")
				client_clear(nil)
			end

			return func(self, unit, dt, t, frame)
		end

		func(self, unit, dt, t, frame)
		pcall(hold_seat, record)

		return
	end

	local drop = drops[unit]

	if drop then
		drops[unit] = nil
		pcall(PlayerMovement.teleport_fixed_update, unit, drop:unbox())
	end

	return func(self, unit, dt, t, frame)
end)

-- ##########################################################
-- Sink: a seat below MIN_SEAT_HEIGHT. The mover stays on top of the Ogryn; only what is drawn moves down.

local function visual_drop(unit)
	local record = riders[unit]

	return record and record.visual_drop > 0 and ALIVE[record.mount] and record.visual_drop or nil
end

-- post_update places the unit root (and through it the first-person unit, weapons and the position the
-- server syncs to other peers) from these two boxes (player_unit_locomotion_extension.lua:943-979).
-- Both are rewritten from the mover on the next fixed update (:188, :203); restored here anyway.
mod:hook("PlayerUnitLocomotionExtension", "post_update", function (func, self, unit, dt, t)
	local drop = visual_drop(unit)

	if not drop then
		return func(self, unit, dt, t)
	end

	local offset = Vector3(0, 0, drop)
	local latest = self._latest_simulated_position:unbox()
	local old = self._old_position:unbox()

	self._latest_simulated_position:store(latest - offset)
	self._old_position:store(old - offset)
	func(self, unit, dt, t)
	self._latest_simulated_position:store(latest)
	self._old_position:store(old)
end)

-- Shots and aim start from first_person.position (locomotion position + eye height,
-- player_unit_first_person_extension.lua:290-331): lower it the same amount so shots leave from the camera.
mod:hook_safe("PlayerUnitFirstPersonExtension", "fixed_update", function (self, unit)
	local drop = visual_drop(unit)

	if drop then
		local fp_component = self._first_person_component

		fp_component.position = fp_component.position - Vector3(0, 0, drop)
	end
end)

-- On the host this also covers a riding client: its unit reads the client's network input here.
mod:hook("PlayerUnitInputExtension", "get", function (func, self, action)
	local result = func(self, action)
	local record = riders_by_player[self._player]

	if record then
		if action == "move" then
			return Vector3.zero()
		end

		if action == "jump" and result then
			record.dismount_requested = true
		end

		if BLOCKED_INPUTS[action] then
			return false
		end
	end

	return result
end)

-- The game stands the body back up when its own crouch state ends: crouch again next frame.
for _, class_name in ipairs({ "PlayerUnitAnimationExtension", "AuthoritativePlayerUnitAnimationExtension" }) do
	mod:hook_safe(class_name, "anim_event", function (self, event_name)
		local record = event_name == "to_uncrouch" and riders[self._unit]

		if record and record.crouched then
			record.recrouch = true
		end
	end)
end

-- ##########################################################
-- Commands and keybinds

local NOT_HOST = "Ogryn Ride works when you are the host (SoloPlay or Realms), or on a Realms game whose host also has Ogryn Ride."

mod.toggle_ride = function ()
	if chat_open() then
		return
	end

	local player = local_player()
	local rider_unit = player and player.player_unit

	if is_server() then
		local record = riders[rider_unit]

		if record then
			host_dismount(record, "by command")

			return
		end

		local mount_unit = host_pick_mount(rider_unit, nil)

		if mount_unit then
			host_mount(rider_unit, player, mount_unit, nil)
		end
	elseif is_realms_client() then
		local record = local_record()
		local sent, send_error = send(record and RPC_DISMOUNT or RPC_REQUEST, "host")

		if not sent then
			mod:echo(send_error == "target_rpc_unsupported" and "The host does not have Ogryn Ride." or "Could not reach the host: " .. tostring(send_error))
		end
	else
		mod:echo(NOT_HOST)
	end
end

mod.toggle_walk = function ()
	if chat_open() then
		return
	end

	if is_server() then
		local record = local_record()

		if record then
			host_toggle_walk(record)
		end
	elseif is_realms_client() and local_record() then
		send(RPC_WALK, "host")
	end
end

local function ogryn_profile_name()
	local item_definitions = MasterItems.get_cached()

	if not item_definitions then
		return nil
	end

	local profiles = BotCharacterProfiles(item_definitions)

	for i = 1, #OGRYN_BOT_PROFILES do
		if profiles[OGRYN_BOT_PROFILES[i]] then
			return OGRYN_BOT_PROFILES[i]
		end
	end
end

local last_spawn_t = -math.huge

mod.spawn_ogryn_bot = function ()
	if chat_open() then
		return
	end

	if not is_server() then
		mod:echo("Only the host can spawn bots (SoloPlay, or the Realms host).")

		return
	end

	local now = Managers.time:time("main")

	if now - last_spawn_t < 2 then
		return
	end

	last_spawn_t = now

	local profile_name = ogryn_profile_name()

	if not profile_name then
		mod:echo("No Ogryn bot profile found.")

		return
	end

	local local_player_id = BotSpawning.spawn_bot_character(profile_name)

	if local_player_id then
		spawned_bot_ids[#spawned_bot_ids + 1] = local_player_id
		mod:echo("Spawning Ogryn bot.")
	else
		-- Realms returns nil at its bot limit (Realms/core/bot_backfill.lua).
		mod:echo("Could not spawn another bot (bot limit reached?).")
	end
end

mod.despawn_ogryn_bots = function ()
	if not is_server() then
		return
	end

	for i = #spawned_bot_ids, 1, -1 do
		pcall(BotSpawning.despawn_bot_character, spawned_bot_ids[i])
		spawned_bot_ids[i] = nil
	end
end

mod:command("ride", "Get on or off the nearest Ogryn", mod.toggle_ride)
mod:command("ridego", "Ogryn bot: walk where you look / stop", mod.toggle_walk)
mod:command("ridebot", "Spawn an Ogryn bot (host)", mod.spawn_ogryn_bot)
mod:command("ridebotdespawn", "Remove the Ogryn bots this mod spawned (host)", mod.despawn_ogryn_bots)

-- ##########################################################
-- Hold-to-ride prompt, like the revive prompt. The game's interaction HUD only shows real interactees
-- (an Ogryn is one only while downed) and a new interaction type cannot be added from a mod (note 44),
-- so the mod draws its own prompt. Drawing: World.create_screen_gui + Gui.slug_text, as QIangIQsMemoryDoctor.
-- It has its own DMF "held" keybind (called with true on press, false on release: dmf keybindings.lua:65-72,
-- 318-330), so it never reads or blocks the game's Interact input and game interactions stay separate.

local PROMPT_RANGE = 2.5
local PROMPT_MIN_DOT = 0.5 -- the Ogryn must be within ~60 degrees of where you look
local prompt = {
	gui = nil,
	world = nil,
	font = nil,
	hold = 0,
	key_down = false,
	need_release = false,
}

mod.ride_key_held = function (is_pressed)
	prompt.key_down = is_pressed and true or false
end

local function prompt_gui()
	local world_manager = Managers.world
	local world = world_manager and world_manager:has_world("level_world") and world_manager:world("level_world")

	if not world then
		prompt.gui, prompt.world = nil, nil

		return nil
	end

	if not prompt.gui or prompt.world ~= world then
		prompt.gui = World.create_screen_gui(world, "immediate")
		prompt.world = world
	end

	if not prompt.font then
		local data = Managers.font and Managers.font:data_by_type("arial")

		prompt.font = data and data.path
	end

	return prompt.font and prompt.gui
end

-- Label of the bound key, from the saved DMF keybind ({ "k" } or { "k", "ctrl" }).
local function ride_key_text()
	local keys = mod:get("key_ride_hold")

	if type(keys) ~= "table" or not keys[1] then
		return nil
	end

	local parts = {}

	for i = #keys, 1, -1 do
		parts[#parts + 1] = string.upper(tostring(keys[i]))
	end

	return table.concat(parts, "+")
end

local function text_width(gui, text, font, size)
	local ok, min, max = pcall(Gui.slug_text_extents, gui, text, font, size)

	if ok and min and max then
		return max[1] - min[1]
	end

	return #text * size * 0.55
end

-- Returns the Ogryn the prompt is for and whether it is a dismount, or nil.
local function prompt_target(unit)
	local record = riders[unit]

	if record then
		return record.mount, true
	end

	if breed_name(unit) == "ogryn" or seat_count(unit) > 0 or is_disabled(unit) then
		return nil
	end

	local unit_data_extension = ScriptUnit.extension(unit, "unit_data_system")
	local look = Vector3.flat(Quaternion.forward(unit_data_extension:read_component("first_person").rotation))
	local from = unit_position(unit)
	local best_unit, best_distance = nil, PROMPT_RANGE

	if Vector3.length_squared(look) < 0.0001 then
		return nil
	end

	look = Vector3.normalize(look)

	for _, player in pairs(Managers.player:players()) do
		local other = player.player_unit

		if other and other ~= unit and ALIVE[other] and breed_name(other) == "ogryn" and free_seat(other) and not riders[other] and not is_disabled(other) then
			local to = unit_position(other) - from
			local distance = Vector3.length(to)
			local flat = Vector3.flat(to)

			if distance < best_distance and (Vector3.length_squared(flat) < 0.01 or Vector3.dot(Vector3.normalize(flat), look) >= PROMPT_MIN_DOT) then
				best_unit, best_distance = other, distance
			end
		end
	end

	return best_unit, false
end

local function draw_prompt(text, progress)
	local gui = prompt_gui()

	if not gui then
		return
	end

	local font = prompt.font
	local resolution = RESOLUTION_LOOKUP
	local scale = resolution and resolution.scale or 1
	local screen_w, screen_h = resolution and resolution.width or 1920, resolution and resolution.height or 1080
	local size = math.max(10, math.floor(20 * scale + 0.5))
	local pad = math.floor(8 * scale + 0.5)
	local bar_h = math.max(3, math.floor(5 * scale + 0.5))
	local width = text_width(gui, text, font, size)
	local box_w = width + pad * 2
	local box_h = size + bar_h + pad * 3
	local x = math.floor((screen_w - box_w) * 0.5)
	local y = math.floor(screen_h * 0.7) -- below the game's own interaction prompt

	-- Screen gui y grows downward here, as in QIangIQsMemoryDoctor's overlay.
	Gui.rect(gui, Vector3(x, y, 899), Vector2(box_w, box_h), Color(150, 12, 12, 12))
	Gui.slug_text(gui, text, font, size, Vector3(x + pad, y + pad, 900), nil, Color(255, 235, 235, 235))
	Gui.rect(gui, Vector3(x + pad, y + pad * 2 + size, 900), Vector2(width, bar_h), Color(200, 60, 60, 60))

	if progress > 0 then
		Gui.rect(gui, Vector3(x + pad, y + pad * 2 + size, 901), Vector2(width * math.min(progress, 1), bar_h), Color(255, 210, 170, 60))
	end
end

local function update_prompt(dt)
	if not mod:get("interact_mount") or chat_open() or not (is_server() or is_realms_client()) then
		prompt.hold = 0

		return
	end

	local player = local_player()
	local unit = player and player.player_unit

	if not unit or not ALIVE[unit] then
		prompt.hold = 0

		return
	end

	local ok, target, is_dismount = pcall(prompt_target, unit)

	if not ok or not target then
		prompt.hold = 0

		return
	end

	local key_text = ride_key_text()

	if not key_text then
		prompt.hold = 0

		return
	end

	local held = prompt.key_down

	if prompt.need_release then
		prompt.need_release = held
		held = false
	end

	prompt.hold = held and prompt.hold + dt or 0

	local hold_time = mod:get("interact_hold_time") or 1
	local action = is_dismount and "get off the Ogryn" or "ride the Ogryn"

	draw_prompt(string.format("Hold %s to %s", key_text, action), prompt.hold / hold_time)

	if prompt.hold >= hold_time then
		prompt.hold = 0
		prompt.need_release = true
		mod.toggle_ride()
	end
end

-- ##########################################################
-- Performance guard and optional diagnostics (console log)

local function dismount_all(reason)
	if is_server() then
		for _, record in pairs(riders) do
			host_dismount(record, reason)
		end
	else
		if local_record() then
			send(RPC_DISMOUNT, "host")
		end

		client_clear(nil)
	end
end

mod.update = function (dt)
	local prompt_ok, prompt_error = pcall(update_prompt, dt)

	if not prompt_ok and mod:get("debug_log") then
		mod:info("prompt error: %s", tostring(prompt_error))
	end

	if next(riders) == nil then
		slow_frames = 0

		return
	end

	if dt > SLOW_FRAME_DT then
		slow_frames = slow_frames + 1
	else
		slow_frames = 0
	end

	if slow_frames >= SLOW_FRAMES_DISMOUNT then
		slow_frames = 0
		dismount_all("performance guard: frames over " .. SLOW_FRAME_DT .. " s")

		return
	elseif slow_frames == SLOW_FRAMES_STOP_WALK then
		for _, record in pairs(riders) do
			if record.walking then
				record.walking = false
				record.last_hold = nil
				record.next_steer_t = 0
				tell(record, "Ogryn: holding position (performance guard).")
			end
		end
	end

	local now = Managers.time:time("main")
	local write_diag = mod:get("debug_log") and now >= next_diag_t

	if write_diag then
		next_diag_t = now + DIAG_INTERVAL
	end

	for _, record in pairs(riders) do
		if ALIVE[record.unit] and ALIVE[record.mount] then
			if record.recrouch then
				record.recrouch = false
				rider_anim_event(record.unit, "to_crouch")
			end

			if write_diag then
				local last = record.last_hold and record.last_hold:unbox()

				mod:info("diag dt=%.3f authority=%s peer=%s walking=%s mount=%s rider=%s hold=%s", dt, tostring(record.authority), tostring(record.peer), tostring(record.walking), tostring(unit_position(record.mount)), tostring(unit_position(record.unit)), tostring(last))
			end
		end
	end
end

-- ##########################################################
-- Lifetime

local function reset()
	prompt.gui, prompt.world, prompt.hold, prompt.key_down, prompt.need_release = nil, nil, 0, false, false
	table.clear(riders)
	table.clear(riders_by_player)
	table.clear(mounted_by)
	table.clear(drops)
	table.clear(spawned_bot_ids)
	slow_frames = 0
end

mod.on_all_mods_loaded = function ()
	-- Realms/docs/README.md: get the Realms mod object and register RPCs in on_all_mods_loaded.
	realms = get_mod("Realms")

	if not realms or type(realms.network_register) ~= "function" or type(realms.network_send) ~= "function" then
		realms = nil

		return
	end

	local handlers = {
		[RPC_REQUEST] = on_request,
		[RPC_DISMOUNT] = on_dismount,
		[RPC_WALK] = on_walk,
		[RPC_STATE] = on_state,
		[RPC_MSG] = on_msg,
	}

	network_ready = true

	for rpc_name, handler in pairs(handlers) do
		local ok, registered, register_error = pcall(realms.network_register, mod, rpc_name, function (sender_peer_id, ...)
			handler(normalize_peer(sender_peer_id), ...)
		end)

		if not ok or not registered then
			network_ready = false
			mod:info("Realms network registration failed for %s: %s", rpc_name, tostring(ok and register_error or registered))
		end
	end
end

mod.on_game_state_changed = function (status, state_name)
	if state_name == "StateGameplay" then -- name DMF reports (console log: "ON_GAME_STATE_CHANGED() ... StateGameplay")
		reset()
	end
end

mod.on_disabled = function ()
	prompt.key_down, prompt.hold = false, 0
	dismount_all("mod disabled")
end
