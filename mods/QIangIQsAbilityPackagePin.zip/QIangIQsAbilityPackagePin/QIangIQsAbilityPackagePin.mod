return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsAbilityPackagePin` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsAbilityPackagePin", {
            mod_script = "QIangIQsAbilityPackagePin/scripts/mods/QIangIQsAbilityPackagePin/QIangIQsAbilityPackagePin",
            mod_data = "QIangIQsAbilityPackagePin/scripts/mods/QIangIQsAbilityPackagePin/QIangIQsAbilityPackagePin_data",
            mod_localization = "QIangIQsAbilityPackagePin/scripts/mods/QIangIQsAbilityPackagePin/QIangIQsAbilityPackagePin_localization",
        })
    end,
    version = "0.1.0",
    author = "QIangIQ",
    packages = {},
}