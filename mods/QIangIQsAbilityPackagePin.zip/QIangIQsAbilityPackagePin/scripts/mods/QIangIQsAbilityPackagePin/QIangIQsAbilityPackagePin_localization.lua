return {
    mod_name = { en = "QIangIQ's Ability Package Pin" },
    mod_description = { en = "Crash fix: keeps grenade and combat ability packages loaded after their first use, so changing loadout or entering a mission cannot unload one that is still in use." },
}