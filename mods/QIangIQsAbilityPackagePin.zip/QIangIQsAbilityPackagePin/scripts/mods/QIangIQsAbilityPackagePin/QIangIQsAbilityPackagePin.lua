local mod = get_mod("QIangIQsAbilityPackagePin")

-- Crash fix for "Trying to unload resource ... that's used elsewhere by the engine" (resource_manager.cpp:612) from
-- package_manager.lua:502 has_unloaded, right after PlayerUnitAbilityExtension logs 'Unequipping ability
-- "zealot_shock_grenade"' in a profile re-sync:
--   2026-11-03 02:50 content/ui/materials/icons/throwables/hud/shock_grenade (hub -> Psykhanium),
--   2026-11-04 00:18 content/weapons/player/ranged/grenade_stumm/textures/grenade_stumm_01 in package
--   content/weapons/player/ranged/grenade_stumm/wpn_grenade_stumm (hub, matchmaking).
-- The grenade's packages drop to zero references while the HUD or a unit still uses them. Why they are still in use is not
-- known (Datavault lesson-ability-package-unload-crash). This mod keeps one extra reference, for the whole game session, to
-- every package of an ability item once it has been equipped: PackageManager.load / release count references per package
-- (package_manager.lua:93), and the list is the one the package synchroniser uses (ItemPackage.compile_item_instance_dependencies,
-- which includes hud_icon). The cost is that those few packages stay in memory.
local ItemPackage = require("scripts/foundation/managers/package/utilities/item_package")
local MasterItems = require("scripts/backend/master_items")

local REFERENCE = "QIangIQsAbilityPackagePin"
local pinned = mod:persistent_table("pinned") -- package name -> load id; survives mod reloads, so nothing is pinned twice

local function pin_item(extension, item)
    local dependencies = ItemPackage.compile_item_instance_dependencies(item, MasterItems.get_cached(), nil, extension._mission)
    local added = 0

    for package_name in pairs(dependencies) do
        if not pinned[package_name] then
            pinned[package_name] = Managers.package:load(package_name, REFERENCE, nil, true)
            added = added + 1
        end
    end

    if added > 0 then
        mod:info("%s: pinned %d packages", tostring(item.name), added)
    end
end

mod:hook_require("scripts/extension_systems/visual_loadout/player_unit_visual_loadout_extension", function(class)
    mod:hook_safe(class, "_equip_item_to_slot", function(self, item, slot_name)
        if item and type(slot_name) == "string" and slot_name:find("ability") and mod:is_enabled() then
            local ok, err = pcall(pin_item, self, item)

            if not ok then
                mod:info("pin failed for %s: %s", tostring(item.name), tostring(err))
            end
        end
    end)
end)