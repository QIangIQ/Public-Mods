-- QIangIQsDauntlessMaul third person: the unreleased 2h_maul FIRST-PERSON clips on the third-person body (coordinator brief
-- 2026-11-01, user choice; Datavault decision-retarget-3p-animations). Copy of QIangIQsChainaxe2h_tp.lua (QIangIQsEmotes
-- custom-dance method, lesson-emotes-standard-body), with the Mauler clips swapped for the 2h_maul ones.
--
-- How:
--   * Custom/dm_tp_driver is a skeleton-only unit on the player's third-person skeleton (167 nodes) whose simple animation is
--     seven 2h_maul 1p clips one after the other (work folder dauntless_maul: tp_bake_maul.py, bl_tp_driver.py; the
--     compiled clip was decoded back and matched the bake within 0.07 degrees, verify_tp.py). The 1p and 3p skeletons share
--     the bind of every bone used, so j_spine2 and everything under it keep the 1p clip's rotations relative to the 1p root.
--   * On an attack the driver is spawned, its unit root linked to the player's j_hips (the bake puts the driver's j_hips on its
--     root), and the body and gear units except the legs (slot_body_legs, slot_gear_lowerbody) are moved onto it by node name,
--     with the maul (its rig follows the driver's j_rightweaponattach). The legs stay on the game's own body.
--   * Timing: the clip plays at the action's time scale (weapon_action.time_scale of the local player; 1 for others), from its
--     start, as the first-person state machine plays it. A charge clip holds its last frame until the heavy attack.
--   * Other players: the anim event reaches clients as an index (AnimationSystem.rpc_player_anim_event). The index of each
--     event is learnt when this client's own maul plays it, so another player's attacks show once you have swung yours.
--   * Ends when the clip is over or the weapon plays any other event of its template (block, special, wield, ...), and snaps
--     back to the game's thunder hammer animation (no blend). Every engine call on a unit checks Unit.alive first.
local WeaponTemplates = require("scripts/settings/equipment/weapon_templates/weapon_templates")

local Tp = {}
local CFG

function Tp.setup(cfg)
    CFG = cfg
end

-- seconds of each clip in the driver's clip (tp_bake_maul.py output, tp_frames.json "clips")
local SPANS = {
    attack_left = { start = 0, length = 1.1667 },
    attack_left_down = { start = 1.2667, length = 1.1 },
    attack_left_diagonal_down = { start = 2.4667, length = 1.0833 },
    attack_right_down = { start = 3.6333, length = 1.0833 },
    attack_heavy_left_down = { start = 4.8, length = 1.1 },
    attack_heavy_left_down_charge = { start = 6.0, length = 2.5 },
    push = { start = 8.6, length = 1.25 },
    -- 0.4.0 (own attack pattern)
    attack_heavy_left_diagonal_up = { start = 9.9667, length = 1.25 },
    attack_heavy_right_diagonal_up = { start = 11.3333, length = 1.1667 },
    attack_heavy_left_diagonal_up_charge = { start = 12.6, length = 2.5 },
    attack_heavy_right_diagonal_up_charge = { start = 15.2, length = 2.5 },
}
-- donor (powermaul_2h_p1_m1 / _m2) third-person anim events -> 2h_maul clip; the pairs follow the 2h_maul first-person state
-- machine's own events for those swings (dauntless_maul\sm_2h_maul_L2.txt)
local PICK = {
    attack_swing_left = { "attack_left" },
    attack_swing_left_down = { "attack_left_down" },
    attack_swing_left_diagonal = { "attack_left_diagonal_down" },
    attack_swing_right_down = { "attack_right_down" },
    attack_swing_heavy_left_down = { "attack_heavy_left_down" },
    attack_swing_charge_left_down = { "attack_heavy_left_down_charge", "charge" },
    attack_push = { "push" },
}
local KEEP_ON_BODY = { slot_body_legs = true, slot_gear_lowerbody = true }
local MAX_HOLD = 3.5

local active = {}      -- 3p unit -> state
local wielded = {}     -- 3p unit -> weapon template name
local event_names = {} -- state machine event index -> name (learnt from this client's own swings)
local stop_events = {} -- template name -> set of its other anim events

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function now()
    local time = Managers.time

    return time and time:has_timer("gameplay") and time:time("gameplay") or os.clock()
end

-- 0.4.0: the own attack pattern's 2h_maul event names (QIangIQsDauntlessMaul_pattern.lua TP_PICK)
function Tp.add_picks(picks)
    for event, entry in pairs(picks) do
        PICK[event] = entry
    end
end

function Tp.knows(event)
    return PICK[event] ~= nil
end

function Tp.mode(event)
    return PICK[event] and PICK[event][2]
end

local function pick(event)
    local entry = PICK[event]

    if entry then
        return entry[1], entry[2]
    end
end

local function template_events(name)
    if stop_events[name] then
        return stop_events[name]
    end

    local set = {}
    local template = WeaponTemplates[name]

    local function scan(t, depth)
        if depth > 4 then
            return
        end

        for k, v in pairs(t) do
            if type(v) == "string" and type(k) == "string" and k:find("anim_event") then
                set[v] = true
            elseif type(v) == "table" then
                scan(v, depth + 1)
            end
        end
    end

    if template and template.actions then
        scan(template.actions, 0)
    end

    stop_events[name] = set

    return set
end

-- body/gear units of a player unit with the node each is linked to (QIangIQsEmotes standard_body_units / attach_index)
local function attach_index(parent, item, breed_name)
    local node = item and ((item.breed_attach_node and breed_name and item.breed_attach_node[breed_name]) or item.attach_node)

    if node == nil or node == "" then
        return 1
    end

    if tonumber(node) ~= nil then
        return tonumber(node)
    end

    if Unit.has_node(parent, node) then
        return Unit.node(parent, node)
    end
end

local function movable_units(unit)
    local ext = ScriptUnit.has_extension(unit, "visual_loadout_system")
    local found = {}

    for name, slot in pairs(ext and ext._equipment or {}) do
        local item = slot.item
        local body = type(name) == "string" and (name:find("^slot_body_") or name:find("^slot_gear_")) and not KEEP_ON_BODY[name]
        local maul = item and item.name == CFG.item_name()

        if (body or maul) and unit_ok(slot.unit_3p) then
            local map_mode = item and item.link_map_mode and World[item.link_map_mode]

            if map_mode == nil or map_mode == World.LINK_MODE_NODE_NAME then
                found[#found + 1] = { unit = slot.unit_3p, item = item }
            end
        end
    end

    return found
end

local function relink(world, child, parent, node)
    World.unlink_unit(world, child)
    World.link_unit(world, child, 1, parent, node, World.LINK_MODE_NODE_NAME)
end

function Tp.stop(unit)
    local data = active[unit]

    if not data then
        return
    end

    active[unit] = nil

    if unit_ok(unit) then
        for _, moved in ipairs(data.moved) do
            if unit_ok(moved.unit) then
                relink(data.world, moved.unit, unit, moved.node)
            end
        end
    end

    if unit_ok(data.driver) then
        local unit_spawner = Managers.state and Managers.state.unit_spawner

        if unit_spawner then
            unit_spawner:mark_for_deletion(data.driver)
        end
    end
end

local function start(unit)
    local path = CFG.tp_driver_path()
    local unit_spawner = Managers.state and Managers.state.unit_spawner
    local world = unit_ok(unit) and Unit.world(unit)

    if not (path and unit_spawner and world and Unit.has_node(unit, "j_hips")) then
        return nil
    end

    local driver = unit_spawner:spawn_unit(path, Unit.world_pose(unit, 1))

    if not unit_ok(driver) then
        return nil
    end

    World.link_unit(world, driver, 1, unit, Unit.node(unit, "j_hips"))

    local unit_data = ScriptUnit.has_extension(unit, "unit_data_system")
    local breed_name = unit_data and unit_data.breed_name and unit_data:breed_name()
    local data = { driver = driver, world = world, moved = {} }

    for _, entry in ipairs(movable_units(unit)) do
        local own = attach_index(unit, entry.item, breed_name)
        local on_driver = own and attach_index(driver, entry.item, breed_name)

        if own and on_driver then
            relink(world, entry.unit, driver, on_driver)
            data.moved[#data.moved + 1] = { unit = entry.unit, node = own }
        end
    end

    active[unit] = data

    return data
end

-- 0.3.1: third-person anim events can differ from the first-person ones (powermaul_2h_p1_m1 action_right_down_light:
-- anim_event attack_swing_right_down, anim_event_3p attack_swing_right_diagonal). The clip is picked by the action's
-- first-person event, looked up from the template's own actions (CFG.event_1p).
local function pick_for(template_name, event)
    local event_1p = CFG.event_1p and CFG.event_1p(template_name, event) or event

    return pick(event_1p)
end

function Tp.on_event(unit, event)
    local template_name = wielded[unit]

    if not (template_name and template_name == CFG.template_name() and CFG.enabled()) then
        return
    end

    local clip_name, mode = pick_for(template_name, event)
    local data = active[unit]

    if not clip_name or not SPANS[clip_name] then
        if data and template_events(template_name)[event] then
            Tp.stop(unit)
        end

        return
    end

    local t = now()

    -- a pose event (charged windup entered from a swing): keep a running charge; with no driver running, show the charge
    -- clip's held end
    if mode == "hold" then
        if data then
            return
        end

        data = start(unit)

        if not data or not unit_ok(data.driver) then
            return
        end

        local span = SPANS[clip_name]

        Unit.play_simple_animation(data.driver, span.start + span.length - 0.05, span.start + span.length, false, 1)
        data.clip = clip_name
        data.end_t = t + MAX_HOLD

        return
    end

    data = data or start(unit)

    if not data or not unit_ok(data.driver) then
        return
    end

    local span = SPANS[clip_name]
    local speed = math.max(CFG.time_scale(unit) or 1, 0.1)

    Unit.play_simple_animation(data.driver, span.start, span.start + span.length, false, speed)
    data.clip = clip_name
    data.end_t = t + (mode == "charge" and MAX_HOLD + span.length / speed or span.length / speed)
end

function Tp.update()
    if next(active) == nil then
        return
    end

    local t = now()

    for unit, data in pairs(active) do
        if not unit_ok(unit) or not unit_ok(data.driver) or wielded[unit] ~= CFG.template_name() or t >= data.end_t then
            Tp.stop(unit)
        end
    end
end

function Tp.wielded(unit, template_name)
    wielded[unit] = template_name

    if active[unit] and template_name ~= CFG.template_name() then
        Tp.stop(unit)
    end
end

-- learning the state machine index of an event from this client's own swing
function Tp.learn(func, unit, event_name, ...)
    if wielded[unit] ~= CFG.template_name() or not pick_for(wielded[unit], event_name) and not template_events(wielded[unit])[event_name] then
        return func(...)
    end

    local original = Unit.animation_event

    Unit.animation_event = function(u, name, ...)
        local index = original(u, name, ...)

        if u == unit and name == event_name and index then
            event_names[index] = name
        end

        return index
    end

    local ok, a, b = pcall(func, ...)

    Unit.animation_event = original

    if not ok then
        error(a, 0)
    end

    return a, b
end

function Tp.on_husk_event(unit, event_index)
    local name = event_names[event_index]

    if name then
        Tp.on_event(unit, name)
    end
end

function Tp.forget(unit)
    Tp.stop(unit)
    wielded[unit] = nil
end

function Tp.stop_all()
    for unit in pairs(active) do
        Tp.stop(unit)
    end
end

function Tp.debug()
    local n, learnt = 0, 0

    for _ in pairs(active) do
        n = n + 1
    end

    for _ in pairs(event_names) do
        learnt = learnt + 1
    end

    return string.format("third person: %d attacking, %d events learnt for other players, driver %s", n, learnt,
        tostring(CFG.tp_driver_path()))
end

return Tp
