-- QIangIQsDauntlessMaul 0.4.0: the maul's own attack pattern, built on the unreleased 2h_maul first-person clips (owner,
-- 2026-11-01: "its a different weapon it shouldnt have the same atk pattern as crusher").
--
-- How each step was chosen (work folder dauntless_maul\swing_analysis.py, swing_analysis.json): every 2h_maul clip's head
-- path (j_rightweaponattach + 0.8 m along the shaft, camera frame) gives its real direction and hit time (head speed above
-- half its peak). Each step borrows, as one piece, the retail 2H power maul action that swings the same way: damage profile,
-- sweep (matrices_data_location), damage window, timings, movement and chain times. They have to stay together because the
-- sweep reads its source clip's matrices between that action's own damage-window times (sweep_spline_exported.lua:120-124).
-- Only the first-person anim event (the 2h_maul one) and the chain targets change. No new action name: every name below is
-- an action of powermaul_2h_p1_m1 or _m2, so the network action list keeps its retail order
-- (Datavault lesson-weapon-action-lookup-shift).
--
--   step  2h_maul clip (hit time, travel)              borrowed retail action (window, travel)              name here
--   L1    attack_left_down (0.34-0.49, down-left)      m2 action_light_1 swing_left_down (0.40-0.47, down-left)  action_light_1
--   L2    attack_right_down (0.42-0.49, down-right)    m1 action_right_down_light (0.43-0.50, down-right)        action_right_down_light
--   L3    attack_left_diagonal_down (0.32-0.41, left-down) m1 action_left_light swing_left_diagonal (0.30-0.40) action_left_light
--   L4    attack_left (0.33-0.48, left)                m1 action_left_down_light swing_left (0.42-0.53, left)     action_left_down_light
--   H1    attack_heavy_left_down (0.32-0.44, down)     m1 action_left_heavy (0.33-0.47, down)                     action_left_heavy
--   H2    attack_heavy_right_diagonal_up (0.28-0.43, right-up)  m1 action_right_heavy (0.35-0.50, right; flat,
--         about 30 degrees below the clip's rise: no retail 2H maul / thunder hammer heavy rises like it)        action_right_heavy
--   H3    attack_heavy_left_diagonal_up (0.30-0.42, left-up)    m2 action_heavy_1 heavy_swing_left (0.37-0.47, left;
--         flat, same caveat)                                                                                      action_heavy_1
-- Windups (charges), each the retail windup that led to the borrowed heavy (its heavy chain_time):
--   W1 m1 action_melee_start_left  -> L1 / H1, charge heavy_charge_left_down, chained: heavy_charge_left_down_pose
--   W2 m1 action_melee_start_right -> L2 / H2, charge heavy_charge_right_diagonal_up (the 2h_maul set has no pose for it)
--   W3 m2 action_melee_start_1     -> L3 / H3, charge heavy_charge_left_diagonal_up, chained: heavy_charge_left_diagonal_up_pose
--   W4 m1 action_melee_start_left_2 -> L4 / H1, as W1
-- Light chain W1 L1 W2 L2 W3 L3 W4 L4 (then W1); heavy chain W1 H1 W2 H2 W3 H3 (then W1).
-- The 2h_maul event names come from its state machine (sm_2h_maul_L2.txt); heavy_attack_right_diagonal_up,
-- heavy_charge_left_down_pose and heavy_charge_left_diagonal_up_pose are hash-only there and were named by id32 match.
-- Third person: each step sends its borrowed action's third-person event, except H3, which sends the thunder hammer
-- set's own attack_swing_heavy_left_diagonal_up (3p state machine 3d740ee5b691ab2e, clip thunder_hammer/
-- attack_heavy_left_diagonal_up), so other players see a rising left heavy even without this mod's driver.
-- displayed_attacks types follow the borrowed actions' places in their donor chains (powermaul_2h_p1_m1 / _m2).
local Pattern = {}

local STEPS = {
    { key = "L1", name = "action_light_1", from = { "m2", "action_light_1" }, anim = "attack_left_down", type = "smiter" },
    { key = "L2", name = "action_right_down_light", from = { "m1", "action_right_down_light" }, anim = "attack_right_down", type = "smiter" },
    { key = "L3", name = "action_left_light", from = { "m1", "action_left_light" }, anim = "attack_left_diagonal_down", type = "tank" },
    { key = "L4", name = "action_left_down_light", from = { "m1", "action_left_down_light" }, anim = "attack_left", type = "tank" },
    { key = "H1", name = "action_left_heavy", from = { "m1", "action_left_heavy" }, anim = "heavy_attack_left_down", type = "smiter" },
    { key = "H2", name = "action_right_heavy", from = { "m1", "action_right_heavy" }, anim = "heavy_attack_right_diagonal_up", type = "tank" },
    { key = "H3", name = "action_heavy_1", from = { "m2", "action_heavy_1" }, anim = "heavy_attack_left_diagonal_up", type = "tank",
      anim_3p = "attack_swing_heavy_left_diagonal_up" },
}
local WINDUPS = {
    { key = "W1", name = "action_melee_start_left", from = { "m1", "action_melee_start_left" }, light = "L1", heavy = "H1",
      anim = "heavy_charge_left_down", chain = "heavy_charge_left_down_pose" },
    { key = "W2", name = "action_melee_start_right", from = { "m1", "action_melee_start_right" }, light = "L2", heavy = "H2",
      anim = "heavy_charge_right_diagonal_up" },
    { key = "W3", name = "action_melee_start_1", from = { "m2", "action_melee_start_1" }, light = "L3", heavy = "H3",
      anim = "heavy_charge_left_diagonal_up", chain = "heavy_charge_left_diagonal_up_pose" },
    { key = "W4", name = "action_melee_start_left_2", from = { "m1", "action_melee_start_left_2" }, light = "L4", heavy = "H1",
      anim = "heavy_charge_left_down", chain = "heavy_charge_left_down_pose" },
}
-- after which step the chain goes to which windup
local NEXT = { L1 = "W2", L2 = "W3", L3 = "W4", L4 = "W1", H1 = "W2", H2 = "W3", H3 = "W1" }
-- donor windups the chains of the kept actions (block, push, special, ...) used to start from -> this pattern's windup
local START_ALIAS = {
    action_melee_start_left = "action_melee_start_left", action_melee_start_right = "action_melee_start_left",
    action_melee_start_left_2 = "action_melee_start_left", action_melee_start_right_2 = "action_melee_start_left",
}

Pattern.FIRST_WINDUP = "action_melee_start_left"

local function by_key(list)
    local out = {}

    for _, entry in ipairs(list) do
        out[entry.key] = entry
    end

    return out
end

local function retarget_start(chain_actions, target)
    local start = chain_actions and chain_actions.start_attack

    if type(start) == "table" and start.action_name then
        start.action_name = target
    end
end

-- clone: the template copy being built (a clone of powermaul_2h_p1_m1); donors: { m1 = template, m2 = template }
function Pattern.apply(clone, donors)
    local steps, windups = by_key(STEPS), by_key(WINDUPS)
    local actions = clone.actions
    local used = {}

    for _, list in ipairs({ STEPS, WINDUPS }) do
        for _, entry in ipairs(list) do
            local source = donors[entry.from[1]] and donors[entry.from[1]].actions[entry.from[2]]

            if not source then
                return false, string.format("%s: %s.%s missing", entry.key, entry.from[1], entry.from[2])
            end

            local action = table.clone(source)

            action.name = entry.name
            action.anim_event_3p = entry.anim_3p or source.anim_event_3p or source.anim_event
            action.anim_event = entry.anim
            entry.action = action
            used[entry.name] = true
        end
    end

    for _, entry in ipairs(STEPS) do
        retarget_start(entry.action.allowed_chain_actions, windups[NEXT[entry.key]].name)
    end

    for _, entry in ipairs(WINDUPS) do
        local action, source = entry.action, donors[entry.from[1]].actions[entry.from[2]]
        local chain = action.allowed_chain_actions or {}

        action.chain_anim_event = entry.chain

        if entry.chain then
            action.chain_anim_event_3p = source.chain_anim_event_3p or source.chain_anim_event or action.anim_event_3p
        else
            action.chain_anim_event_3p = nil
        end

        if chain.light_attack then
            chain.light_attack.action_name = steps[entry.light].name
        end

        if chain.heavy_attack then
            chain.heavy_attack.action_name = steps[entry.heavy].name
        end
    end

    -- donor sweeps and windups this pattern does not use go; the kept actions (block, push, special, wield, inspect, ...)
    -- start attacks from W1
    for name, action in pairs(actions) do
        if not used[name] and (action.kind == "sweep" or action.kind == "windup") and not name:find("push") then
            actions[name] = nil
        end
    end

    for name, action in pairs(actions) do
        if not used[name] then
            local start = action.allowed_chain_actions and action.allowed_chain_actions.start_attack

            if type(start) == "table" and START_ALIAS[start.action_name] then
                start.action_name = START_ALIAS[start.action_name]
            end
        end
    end

    for _, list in ipairs({ STEPS, WINDUPS }) do
        for _, entry in ipairs(list) do
            actions[entry.name] = entry.action
            entry.action = nil
        end
    end

    -- push follow-up and every other kept chain must point at an action that exists
    for name, action in pairs(actions) do
        for input, chain in pairs(action.allowed_chain_actions or {}) do
            if type(chain) == "table" and chain.action_name and not actions[chain.action_name] then
                return false, string.format("%s.%s -> %s missing", name, input, chain.action_name)
            end
        end
    end

    local display = clone.displayed_attacks and table.clone(clone.displayed_attacks) or {}

    display.primary = display.primary or {}
    display.secondary = display.secondary or {}
    display.primary.attack_chain = { steps.L1.type, steps.L2.type, steps.L3.type, steps.L4.type }
    display.secondary.attack_chain = { steps.H1.type, steps.H2.type, steps.H3.type }
    clone.displayed_attacks = display

    return true
end

-- first-person events of this pattern -> third-person driver clip (QIangIQsDauntlessMaul_tp.lua SPANS)
Pattern.TP_PICK = {
    attack_left_down = { "attack_left_down" },
    attack_right_down = { "attack_right_down" },
    attack_left_diagonal_down = { "attack_left_diagonal_down" },
    attack_left = { "attack_left" },
    heavy_attack_left_down = { "attack_heavy_left_down" },
    heavy_attack_right_diagonal_up = { "attack_heavy_right_diagonal_up" },
    heavy_attack_left_diagonal_up = { "attack_heavy_left_diagonal_up" },
    heavy_charge_left_down = { "attack_heavy_left_down_charge", "charge" },
    heavy_charge_right_diagonal_up = { "attack_heavy_right_diagonal_up_charge", "charge" },
    heavy_charge_left_diagonal_up = { "attack_heavy_left_diagonal_up_charge", "charge" },
    heavy_charge_left_down_pose = { "attack_heavy_left_down_charge", "hold" },
    heavy_charge_left_diagonal_up_pose = { "attack_heavy_left_diagonal_up_charge", "hold" },
}

return Pattern
