-- QIangIQ's Dauntless Maul 0.3.0: the unreleased 2H maul (content/weapons/player/melee/2h_maul) as a weapon.
-- 0.4.0: own attack pattern (setting attack_pattern, default dauntless; QIangIQsDauntlessMaul_pattern.lua): lights left-down,
--   right-down, left-diagonal, left; heavies overhead, rising right, rising left, all on 2h_maul clips, each step with the
--   sweep, damage and timing of the retail 2H power maul action that swings the same way. The Crusher Mk I / Mk II chains
--   stay selectable. Combo Tracker gets the pattern of whichever chain is in use, built from the template's own actions.
-- 0.3.1: third-person clip picked by the action's first-person event (Mk I light 2 sends attack_swing_right_diagonal in
--   3p for attack_swing_right_down in 1p); Combo Tracker highlights the maul with the Crusher Mk I pattern.
-- 0.3.0: burning weapon special (QIangIQsDauntlessMaul_special.lua: power sword activation class, the next 1-2 hitting
--   swings set enemies within 2.5 m of the hit on fire; retail sources listed there), ability equip guard (copy of
--   QIangIQsChainaxe2h_guard.lua, Datavault lesson-ability-unit-not-loaded), broker in the unlock lists (as
--   QIangIQsDauntlessFalchion), drawn bottom-right HUD icon (the QIangIQsCrossbow way, Custom/hud_icon; the game's own
--   maul_2h_p1_m1 icon is placeholder text).
-- 0.2.0: (1) first-person event remap: the 2h_maul state machine's main layer has no transition for six of the donor's
--   events (attack_swing_left, _left_down, _left_diagonal, _right_down, _heavy_left_down, _charge_left_down; they only reach
--   an empty layer-7 state). It names those swings attack_left, attack_left_down, attack_left_diagonal_down,
--   attack_right_down, heavy_attack_left_down, heavy_charge_left_down (sm_events_map.py, dauntless_maul\sm_2h_maul_L2.txt),
--   so 0.1.0 showed no arm motion for those swings with the unreleased set. (2) third person: those 2h_maul clips (+ push)
--   retargeted onto the 3p body through Custom/dm_tp_driver (QIangIQsDauntlessMaul_tp.lua); optional, needs Custom
--   Assets, falls back to the retail thunder hammer set without it.
--
-- What is datamined (dauntless_datamine\07_related_2h_maul, unreleased_sweep_oct25\index.tsv;
-- node names by id32 match, work folder dauntless_maul\probe_out.txt):
--   * attachments head_01 / head_deluxe01, connector_01 / connector_deluxe01, shaft_01 / shaft_deluxe01, pommel_01 /
--     pommel_deluxe01, trail_01 (every unit has its own package). No rig, no weapon template, no item, no sounds, no
--     third-person animations. The "deluxe01" set is named like the released premium parts (power_sword_blade_deluxe01,
--     human_power_maul_head_deluxe01); calling it the Dauntless's is a reading of where it was found, not proven.
--   * shaft_NN: ap_connector_01 z 0.572, ap_pommel_01 z -0.1512, fx_sweep / fx_block / fx_special_active all at the origin.
--     connector_NN: ap_head_01 z 0.0722. trail_01: rp_trail_01, j_trail_01..04, fx_sweep z 0.8094. No ap_trinket /
--     ap_trinket_hook on any part (hash check), so the donor's trinket slots go.
--   * First-person state machine content/characters/player/human/first_person/animations/2h_maul (75 clips). Its events
--     are a superset of the released 2h_power_maul set (limn dump, poweraxe\sm_cmp.py: 165 vs 159
--     events, none missing; Datavault technique-2h-maul-sm-comparison).
--   * HUD icon content/ui/materials/icons/weapons/hud/maul_2h_p1_m1 exists but is placeholder text (decoded:
--     dauntless_maul\maul_2h_p1_m1_icon_dark.png), so the donor's icon is kept.
--
-- How it is built (QIangIQsChainsword2h / QIangIQsPowerAxe pattern):
--   * Template zz_qiangiq_maul_2h_p1_m1 = clone of powermaul_2h_p1_m1 or _m2 (setting). The name sorts after every retail
--     template and the clone adds no action names and keeps the donor's __base_template_lookup, so the WEAPON_TEMPLATES,
--     WEAPON_ACTIONS and weapon tweak network lists (player_unit_data_component_config.lua) keep every retail index
--     (Datavault lesson-weapon-action-lookup-shift, lesson-shardstaff-hub-aim-constraint-crash).
--   * 1P: the unreleased 2h_maul state machine (setting), registered in PlayerUnitAnimationStateMachineSettings with the
--     released maul's entry (QIangIQsMeltagun 0.2.2 spawn CTD) and an anim event guard (QIangIQsPowerAxe). 3P: the donor's
--     own thunder_hammer state machine, the game's own pairing for this event set; nothing foreign is played, so there is
--     nothing to retarget. Sweep (hit) paths stay the donor's.
--   * Item = clone of the donor master item (http_cache.db build 139617, dauntless_maul\maul_items.json): base unit
--     wpn_power_maul_chained_rig, shaft -> connector -> head, shaft -> pommel, trail. Here each slot holds the 2h_maul
--     part on the same attach node (render check dauntless_maul\render_cmp.png); the trail is the 2h_maul trail_01.
--   * fx_sources: the 2h_maul shaft's fx nodes sit at the grip; setting fx_at_head points _block / _special_active /
--     _sweep at the connector's ap_head_01 (the only part with that node). This placement is this mod's choice.
--   * Standalone: needs no other mod. Every unit, animation and icon is the game's own; only the optional third-person
--     driver (0.2.0) is a Custom Assets unit, and without Custom Assets the 3p side stays the retail thunder hammer set.
-- Author: QIangIQ
local mod = get_mod("QIangIQsDauntlessMaul")

local WeaponTemplates = require("scripts/settings/equipment/weapon_templates/weapon_templates")
local MasterItems = require("scripts/backend/master_items")
local NetworkLookup = require("scripts/network_lookup/network_lookup")

local MAUL = "content/weapons/player/melee/2h_maul/attachments/"
local ITEM_ROOT = "content/items/weapons/player/melee/"
local PART_ROOT = ITEM_ROOT .. "qiangiq_dauntlessmaul/"
local TRAIL_UNIT = MAUL .. "trail_01/trail_01"
local KINDS = { "shaft", "connector", "head", "pommel" }
local FX_NODE = "ap_head_01"
local RELEASED_SM = "content/characters/player/human/first_person/animations/2h_power_maul"
local UNRELEASED_SM = "content/characters/player/human/first_person/animations/2h_maul"
local ARCHETYPES = { "zealot", "veteran", "psyker", "adamant", "broker" }

-- 0.3.0 burning special (QIangIQsDauntlessMaul_special.lua); its class is registered here, before any template is built
local Special = mod:io_dofile("QIangIQsDauntlessMaul/scripts/mods/QIangIQsDauntlessMaul/QIangIQsDauntlessMaul_special")

Special.setup({
    stacks = function()
        return tonumber(mod:get("burn_stacks")) or 3
    end,
    debug = function(fmt, ...)
        if mod:get("debug") then
            mod:info(fmt, ...)
        end
    end,
})

-- 0.4.0 own attack pattern (QIangIQsDauntlessMaul_pattern.lua)
local Pattern = mod:io_dofile("QIangIQsDauntlessMaul/scripts/mods/QIangIQsDauntlessMaul/QIangIQsDauntlessMaul_pattern")

-- 0.3.0 ability equip guard (crash lesson-ability-unit-not-loaded; the backend-less equip below is the trigger it names)
local Guard = mod:io_dofile("QIangIQsDauntlessMaul/scripts/mods/QIangIQsDauntlessMaul/QIangIQsDauntlessMaul_guard")

Guard.setup(mod)

local DONORS = { m1 = "powermaul_2h_p1_m1", m2 = "powermaul_2h_p1_m2" }
local MARK = {
    template = "zz_qiangiq_maul_2h_p1_m1",
    item = ITEM_ROOT .. "zz_qiangiq_maul_2h_p1_m1",
    display = "loc_qiangiq_dauntlessmaul_p1_m1",
}

mod:add_global_localize_strings({
    loc_qiangiq_dauntlessmaul_family = { en = "2H Maul (datamined)" },
    loc_qiangiq_dauntlessmaul_p1_m1 = { en = "Dauntless Maul (datamined)" },
    loc_qiangiq_dauntlessmaul_desc = {
        en = "The unreleased 2H maul found in the game files, with its own attack pattern on the unreleased maul animations.",
    },
})

local function say(fmt, ...)
    local text = string.format(fmt, ...)

    mod:echo(text)
    mod:info(text)
end

local function debug(fmt, ...)
    if mod:get("debug") then
        mod:info(fmt, ...)
    end
end

-- Network lookups (QIangIQsShardStaff append_lookup): new names go at the end so no existing id moves -------------
local function append_lookup(lookup_name, key)
    local lookup = NetworkLookup[lookup_name]

    if not lookup then
        return false, "no lookup"
    end

    local existing = rawget(lookup, key)

    if existing then
        return true, existing
    end

    local index = #lookup + 1

    rawset(lookup, index, key)
    rawset(lookup, key, index)

    return true, index
end

-- Particle / sound aliases keyed by wielded_weapon_template (QIangIQsShardStaff alias_template_keys) --------------
local ALIAS_MODULES = {
    "scripts/settings/particles/player_character_particle_aliases",
    "scripts/settings/sound/player_character_sound_event_aliases",
}

local function alias_keys(root, source, target, seen, counter)
    if type(root) ~= "table" or seen[root] then
        return
    end

    seen[root] = true

    local value = rawget(root, source)

    if value ~= nil and rawget(root, target) == nil then
        root[target] = value
        counter.n = counter.n + 1
    end

    for _, child in pairs(root) do
        if type(child) == "table" then
            alias_keys(child, source, target, seen, counter)
        end
    end
end

local function copy_aliases(source, target)
    local counter = { n = 0 }

    for _, path in ipairs(ALIAS_MODULES) do
        local ok, module = pcall(require, path)

        if ok then
            alias_keys(module, source, target, {}, counter)
        else
            mod:error("alias module %s: %s", path, tostring(module))
        end
    end

    return counter.n
end

local function package_found(path)
    local ok, exists = pcall(Application.can_get_resource, "package", path)

    return ok and exists and true or false
end

-- attack_pattern: dauntless (0.4.0 own pattern, built on the m1 clone), crusher_m1, crusher_m2 (the retail chains)
local function attack_pattern()
    local value = mod:get("attack_pattern")

    return (value == "crusher_m1" or value == "crusher_m2") and value or "dauntless"
end

local function donor_name()
    return attack_pattern() == "crusher_m2" and DONORS.m2 or DONORS.m1
end

local function part_set()
    return mod:get("part_set") == "01" and "01" or "deluxe01"
end

local function part_unit(kind, set)
    return string.format("%s%s_%s/%s_%s", MAUL, kind, set, kind, set)
end

-- Template ------------------------------------------------------------------------------------------------------------
local anim_used = {}

local function ensure_template()
    if rawget(WeaponTemplates, MARK.template) then
        MARK.template_ok = true
        MARK.official_template = not MARK.template_ours

        return true
    end

    local donor = WeaponTemplates[donor_name()]

    if not donor then
        return false
    end

    local clone = table.clone(donor)

    clone.name = MARK.template

    -- weapon_templates.lua _require_template: action_settings.name = action_name
    for action_name, action_settings in pairs(clone.actions) do
        action_settings.name = action_name
    end

    MARK.notes = {}

    local own_pattern = attack_pattern() == "dauntless" and package_found(UNRELEASED_SM)

    if own_pattern then
        local ok, err = Pattern.apply(clone, { m1 = WeaponTemplates[DONORS.m1], m2 = WeaponTemplates[DONORS.m2] })

        if ok then
            MARK.notes[#MARK.notes + 1] = "own 2h_maul attack pattern"
        else
            mod:error("attack pattern not built (%s): Crusher Mk I chains kept", tostring(err))
            clone = table.clone(donor)
            clone.name = MARK.template

            for action_name, action_settings in pairs(clone.actions) do
                action_settings.name = action_name
            end

            own_pattern = false
        end
    elseif attack_pattern() == "dauntless" then
        MARK.notes[#MARK.notes + 1] = "2h_maul animation package not found: Crusher Mk I chains"
    end

    if mod:get("fx_at_head") ~= false then
        clone.fx_sources = table.clone(clone.fx_sources or {})

        for source in pairs(clone.fx_sources) do
            clone.fx_sources[source] = FX_NODE
        end

        MARK.notes[#MARK.notes + 1] = "fx at ap_head_01"
    end

    if mod:get("special_mode") ~= "retail" then
        local swings = tonumber(mod:get("burn_swings")) or 2

        Special.apply(clone, swings)
        MARK.notes[#MARK.notes + 1] = string.format("burning special (%d swings, %s stacks)", swings, tostring(mod:get("burn_stacks")))
    end

    -- the own pattern plays 2h_maul event names, so it always uses the 2h_maul state machine
    if own_pattern or mod:get("animation_set") ~= "released" then
        if package_found(UNRELEASED_SM) then
            -- player_unit_animation_state.lua:112 indexes PlayerUnitAnimationStateMachineSettings by the state machine path
            -- (QIangIQsMeltagun 0.2.2: CTD on spawn without the entry); the unreleased set is not listed, so it gets the
            -- released maul's entry (QIangIQsPowerAxe apply_axe)
            local SMSettings = require("scripts/settings/animation/player_unit_animation_state_machine_settings")

            if not SMSettings[UNRELEASED_SM] then
                SMSettings[UNRELEASED_SM] = table.clone(SMSettings[RELEASED_SM] or { blend_time = 0 })
            end

            clone.anim_state_machine_1p = UNRELEASED_SM
            anim_used[MARK.template] = true
            MARK.notes[#MARK.notes + 1] = "unreleased 2h_maul 1P animations"
        else
            MARK.notes[#MARK.notes + 1] = "2h_maul animation package not found, released animations kept"
        end
    end

    WeaponTemplates[MARK.template] = clone
    MARK.template_ours = true
    MARK.donor = donor_name()

    local ok, index = append_lookup("weapon_templates", MARK.template)

    MARK.template_id = ok and index or nil
    MARK.aliases = copy_aliases(MARK.donor, MARK.template)
    MARK.template_ok = ok

    return ok
end

-- Items ---------------------------------------------------------------------------------------------------------------
local function find_item(cache, preferred, template)
    local direct = rawget(cache, preferred)

    if direct and direct.weapon_template == template then
        return preferred, direct
    end

    for name, item in pairs(cache) do
        if type(item) == "table" and item.weapon_template == template then
            return name, item
        end
    end
end

-- Only base_unit is kept: Items.base_unit can also read per-breed / first-person variants of the source part
local function only_base_unit(item, unit)
    for key in pairs(item) do
        if type(key) == "string" and key ~= "base_unit" and key:find("^base_unit") then
            item[key] = nil
        end
    end

    item.base_unit = unit
end

-- the part keeps the donor part's attach_node (shaft rp_power_maul_chained_rig, connector ap_connector_01, head
-- ap_head_01, pommel ap_pommel_01, trail "1"; maul_items.json); every 2h_maul part has the parent node it needs
local function make_part(cache, name, template_item, unit)
    local item = table.clone(template_item)

    only_base_unit(item, unit)
    item.name = name
    item.resource_dependencies = { [unit] = true }
    item.attachments = nil
    item.material_overrides = nil
    item.material_override_items = nil
    cache[name] = item

    return name
end

-- a tree node with the donor node's flags (leaf_attach_node_override, link_map_mode_override, material fields)
local function fresh_node(node, item_name)
    local out = {}

    for key, value in pairs(node) do
        if key ~= "children" and key ~= "item" then
            out[key] = type(value) == "table" and table.clone(value) or value
        end
    end

    out.item = item_name
    out.children = {}

    return out
end

local function dump_tree(tree, prefix, out)
    for slot_name, node in pairs(tree) do
        if type(node) == "table" then
            local path = prefix .. slot_name

            out[#out + 1] = string.format("%s=%s", path, tostring(node.item))

            if type(node.children) == "table" then
                dump_tree(node.children, path .. "/", out)
            end
        end
    end

    return out
end

local function archetypes_of(source_item)
    local archetypes, seen = {}, {}

    for _, archetype in ipairs(source_item.archetypes or {}) do
        archetypes[#archetypes + 1] = archetype
        seen[archetype] = true
    end

    for _, archetype in ipairs(ARCHETYPES) do
        if mod:get("unlock_" .. archetype) and not seen[archetype] then
            archetypes[#archetypes + 1] = archetype
            seen[archetype] = true
        end
    end

    return archetypes
end

local function child(node, name)
    return node and type(node.children) == "table" and node.children[name]
end

local function build_item(cache)
    local donor = donor_name()
    local source_name, source_item = find_item(cache, ITEM_ROOT .. donor, donor)

    if not source_item then
        return false
    end

    if type(source_item.attachments) ~= "table" then
        return false, "source item has no attachments"
    end

    local set = part_set()
    local units = { trail = TRAIL_UNIT }

    for _, kind in ipairs(KINDS) do
        units[kind] = part_unit(kind, set)
    end

    for _, unit in pairs(units) do
        if not package_found(unit) then
            return false, unit .. " package not found"
        end
    end

    local item = table.clone(source_item)

    item.name = MARK.item
    item.weapon_template = MARK.template
    item.display_name = MARK.display
    item.description = "loc_qiangiq_dauntlessmaul_desc"
    item.dev_description = nil
    item.archetypes = archetypes_of(source_item)

    for _, field in ipairs({ "weapon_family_display_name", "weapon_pattern_display_name", "weapon_mark_display_name" }) do
        if type(item[field]) == "table" then
            item[field].loc_id = field == "weapon_family_display_name" and "loc_qiangiq_dauntlessmaul_family" or MARK.display
        end
    end

    if not MARK.tree_logged then
        MARK.tree_logged = true
        mod:info("source tree of %s: %s", tostring(source_name), table.concat(dump_tree(item.attachments, "", {}), "; "))
    end

    -- master item data of powermaul_2h_p1_m1 (http_cache.db, build 139617): shaft, shaft/connector, shaft/connector/head,
    -- shaft/connector/slot_trinket_1, shaft/connector/trinket_hook(/slot_trinket_2), shaft/pommel, trail,
    -- zzz_shared_material_overrides
    local nodes = { shaft = item.attachments.shaft, trail = item.attachments.trail }

    nodes.connector = child(nodes.shaft, "connector")
    nodes.head = child(nodes.connector, "head")
    nodes.pommel = child(nodes.shaft, "pommel")

    local names = {}

    for kind, node in pairs(nodes) do
        local source = node and type(node.item) == "string" and rawget(cache, node.item)

        if not source then
            return false, "no " .. kind .. " slot in " .. tostring(source_name)
        end

        local name = kind == "trail" and PART_ROOT .. "trail_01" or string.format("%s%s_%s", PART_ROOT, kind, set)

        if not rawget(cache, name) then
            make_part(cache, name, source, units[kind])

            -- powermaul_2h_p1_m1's trail item links to node "1" (the rig root); _m2's thunder_hammer trail names
            -- rp_thunder_hammer_chained_rig, which this rig does not have
            if kind == "trail" then
                cache[name].attach_node = "1"
            end
        end

        names[kind] = name
    end

    local connector = fresh_node(nodes.connector, names.connector)

    connector.children.head = fresh_node(nodes.head, names.head)
    nodes.shaft.item = names.shaft
    nodes.shaft.children = { connector = connector, pommel = fresh_node(nodes.pommel, names.pommel) }
    nodes.trail.item = names.trail
    nodes.trail.children = {}

    -- powermaul_2h_p1_m2 carries a navy material override (mo_default_navy); _m1's slot is empty, as here
    local shared = item.attachments.zzz_shared_material_overrides

    if type(shared) == "table" then
        shared.item = ""
        shared.children = {}
    end

    local deps = item.resource_dependencies or {}

    for _, unit in pairs(units) do
        deps[unit] = true
    end

    -- what the offline item compile adds for the weapon template (item_package.lua:239-249): state machines, sounds, effects
    local WeaponTemplateResourceDependencies = require("scripts/utilities/weapon_template_resource_dependencies")

    for _, resource in ipairs(WeaponTemplateResourceDependencies.generate(MARK.template)) do
        deps[resource] = true
    end

    -- generate() already collects anim_state_machine_1p (weapon_template_resource_dependencies.lua
    -- _is_valid_state_machine_resource); listed again so the 2h_maul package can never be missed
    if anim_used[MARK.template] then
        deps[UNRELEASED_SM] = true
    end

    item.resource_dependencies = deps

    local ok, index = append_lookup("player_item_names", MARK.item)

    if not ok then
        return false
    end

    cache[MARK.item] = item
    MARK.item_id = index
    MARK.source_item_name = source_name
    MARK.slot = item.slots and item.slots[1]
    MARK.set = set

    return true
end

local function ensure_item()
    local ok, has_data = pcall(MasterItems.has_data)

    if not ok or not has_data then
        return false
    end

    local cache = MasterItems.get_cached()

    if rawget(cache, MARK.item) and not MARK.dirty then
        MARK.item_ok = true

        return true
    end

    local built, err = build_item(cache)

    if err and err ~= MARK.last_error then
        MARK.last_error = err
        mod:error("%s: %s", MARK.template, err)
    end

    MARK.item_ok = built and rawget(cache, MARK.item) ~= nil

    if MARK.item_ok then
        MARK.dirty = false
    end

    return MARK.item_ok
end

-- Unlock lists (weapon_unlock_settings.lua WeaponUnlockSettings[archetype][level] = { item names }); realms_loadout
-- builds its human weapon list from it
local function add_to_unlock_lists()
    if not mod:get("add_to_unlock_list") then
        return
    end

    local ok, unlocks = pcall(require, "scripts/settings/weapon_unlock/weapon_unlock_settings")

    if not ok or not unlocks then
        mod:error("WeaponUnlockSettings not found")

        return
    end

    local level = math.floor(mod:get("unlock_level") or 1)

    for _, archetype in ipairs(ARCHETYPES) do
        local list = unlocks[archetype]

        if mod:get("unlock_" .. archetype) and list then
            list[level] = list[level] or {}

            if not table.find(list[level], MARK.item) then
                table.insert(list[level], MARK.item)
            end
        end
    end
end

local next_poll = 0

local function poll()
    if next_poll > os.clock() then
        return
    end

    next_poll = os.clock() + 1

    local before_t, before_i = MARK.template_ok, MARK.item_ok
    local ok_t, err_t = pcall(ensure_template)
    local ok_i, err_i = true, nil

    if MARK.template_ok then
        ok_i, err_i = pcall(ensure_item)
    end

    if not ok_t then
        mod:error("template: %s", tostring(err_t))
    end

    if not ok_i then
        mod:error("item: %s", tostring(err_i))
    end

    if MARK.template_ok and not before_t then
        if MARK.official_template then
            mod:info("the game now has its own %s template; using it", MARK.template)
        else
            mod:info("template %s registered (clone of %s, %s), %s alias entries", MARK.template, tostring(MARK.donor),
                table.concat(MARK.notes or {}, "; "), tostring(MARK.aliases))
        end
    end

    if MARK.item_ok and not before_i then
        mod:info("item %s injected (clone of %s, slot %s, parts %s)", MARK.item, tostring(MARK.source_item_name), tostring(MARK.slot),
            tostring(MARK.set))
    end
end

-- Archetypes and parts can change while the game runs: rebuild the item (equip again to see it). Moveset, animation set
-- and fx placement are read when the template is built, so they need the mods reloaded (Ctrl+Shift+R) or a restart.
local ITEM_SETTINGS = {
    part_set = true, unlock_zealot = true, unlock_veteran = true, unlock_psyker = true, unlock_adamant = true, unlock_broker = true,
}

mod.on_setting_changed = function(setting_id)
    if ITEM_SETTINGS[setting_id] then
        MARK.dirty = true
    end
end

-- Anim event guard (QIangIQsPowerAxe / QIangIQsMeltagun 0.2.1 pattern): with the unreleased state machine, events it lacks
-- are skipped instead of failing (Unit.has_animation_event as player_character_state_ledge_vaulting.lua:109 does).
-- AuthoritativePlayerUnitAnimationExtension (hosting) has no _local_wielded_weapon_template, so the wielded template name is
-- stored from inventory_slot_wielded.
local skipped_events = {}

-- 0.2.0: donor events the 2h_maul state machine only knows under its own names (see the header). false = not played: the
-- 2h_maul left-down charge clip holds its own end pose, and the donor's chain pose event would snap to the released pose
-- clip (unverified in game).
local REMAP_1P = {
    attack_swing_left = "attack_left",
    attack_swing_left_down = "attack_left_down",
    attack_swing_left_diagonal = "attack_left_diagonal_down",
    attack_swing_right_down = "attack_right_down",
    attack_swing_heavy_left_down = "heavy_attack_left_down",
    attack_swing_charge_left_down = "heavy_charge_left_down",
    attack_swing_charge_left_down_pose = false,
}

local function guard(unit_field)
    return function(func, self, event_name, ...)
        local wielded = self.__qiangiq_dauntlessmaul_wielded or self._local_wielded_weapon_template

        if anim_used[wielded] then
            local unit = self[unit_field]
            local mapped = REMAP_1P[event_name]

            if mapped == false then
                return
            end

            if mapped and unit and Unit.alive(unit) and Unit.has_animation_event(unit, mapped) then
                debug("1p event %s -> %s", event_name, mapped)
                event_name = mapped
            end

            if unit and Unit.alive(unit) and not Unit.has_animation_event(unit, event_name) then
                if not skipped_events[event_name] then
                    skipped_events[event_name] = true
                    mod:info("skipped anim event %s: not in the 2h_maul state machine", tostring(event_name))
                end

                return
            end
        end

        return func(self, event_name, ...)
    end
end

-- the wielded name (__qiangiq_dauntlessmaul_wielded) is stored by the one inventory_slot_wielded hook in the third-person
-- block below: DMF keeps only the first hook a mod puts on a method ("Attempting to rehook active hook", dmf hooks.lua:243-254)
for _, class_name in ipairs({ "PlayerUnitAnimationExtension", "AuthoritativePlayerUnitAnimationExtension" }) do
    for _, method in ipairs({ "anim_event_1p", "anim_event_with_variable_float_1p", "anim_event_with_variable_floats_1p" }) do
        mod:hook(CLASS[class_name], method, guard("_first_person_unit"))
    end
end

-- Third person (0.2.0): the 2h_maul clips on the 3p body through Custom/dm_tp_driver (QIangIQsDauntlessMaul_tp.lua) ---------
local TP_DRIVER = { id = "QIangIQsDauntlessMaul:dm_tp_driver", unit = "content/mods/qiangiq_dauntlessmaul/dm_tp_driver" }
local tp_driver_loaded = false
local Tp = mod:io_dofile("QIangIQsDauntlessMaul/scripts/mods/QIangIQsDauntlessMaul/QIangIQsDauntlessMaul_tp")

Tp.add_picks(Pattern.TP_PICK)

-- weapon_action.time_scale of the local player (QIangIQsChainaxe2h action_info); other players play at speed 1
local function time_scale(unit)
    local ok, scale = pcall(function()
        local ext = ScriptUnit.has_extension(unit, "visual_loadout_system")

        if not (ext and ext._is_local_unit) then
            return 1
        end

        local ude = ScriptUnit.has_extension(unit, "unit_data_system")
        local wa = ude and ude:read_component("weapon_action")

        return wa and wa.time_scale or 1
    end)

    return ok and scale or 1
end

-- third-person event -> first-person event of the same action, per template; only where every action sending that
-- third-person event sends the same first-person one (built once per template)
local event_1p_maps = {}

local function event_1p(template_name, event)
    local map = event_1p_maps[template_name]

    if not map then
        map = {}

        local template = WeaponTemplates[template_name]
        local conflict = {}

        for _, action in pairs(template and template.actions or {}) do
            for _, pair in ipairs({ { "anim_event_3p", "anim_event" }, { "chain_anim_event_3p", "chain_anim_event" } }) do
                local e3, e1 = action[pair[1]] or action[pair[2]], action[pair[2]]

                if type(e3) == "string" and type(e1) == "string" then
                    if map[e3] ~= nil and map[e3] ~= e1 then
                        conflict[e3] = true
                    end

                    map[e3] = e1
                end
            end
        end

        -- conflicts: prefer the first-person event the driver has a clip for (0.4.0: the push follow-up and the rising left
        -- heavy both send attack_swing_heavy_left_diagonal_up in third person)
        for e3 in pairs(conflict) do
            map[e3] = nil

            for _, action in pairs(template and template.actions or {}) do
                for _, pair in ipairs({ { "anim_event_3p", "anim_event" }, { "chain_anim_event_3p", "chain_anim_event" } }) do
                    local a3, a1 = action[pair[1]] or action[pair[2]], action[pair[2]]

                    if a3 == e3 and type(a1) == "string" and Tp.knows(a1) and not (map[e3] and Tp.mode(map[e3]) ~= "hold") then
                        map[e3] = a1
                    end
                end
            end
        end

        event_1p_maps[template_name] = map
    end

    return map[event] or event
end

Tp.setup({
    event_1p = event_1p,
    tp_driver_path = function()
        return tp_driver_loaded and TP_DRIVER.unit or nil
    end,
    enabled = function()
        return mod:get("maul_3p") ~= false
    end,
    template_name = function()
        return MARK.template
    end,
    item_name = function()
        return MARK.item
    end,
    time_scale = time_scale,
})

mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, "destroy", function(func, self, ...)
    pcall(Tp.forget, self._unit)

    return func(self, ...)
end)

if CLASS.PlayerHuskVisualLoadoutExtension then
    mod:hook(CLASS.PlayerHuskVisualLoadoutExtension, "destroy", function(func, self, ...)
        pcall(Tp.forget, self._unit)

        return func(self, ...)
    end)
end

-- anim events of the weapon on the local unit (client prediction or a local server) and on other players
-- (rpc_player_anim_event*, an event index; Tp.learn), as in QIangIQsChainaxe2h
for _, class_name in ipairs({ "PlayerUnitAnimationExtension", "AuthoritativePlayerUnitAnimationExtension", "PlayerHuskAnimationExtension" }) do
    local class = CLASS[class_name]

    if class then
        -- one hook for both jobs: the 1p anim event guard's wielded name and the third-person driver
        mod:hook_safe(class, "inventory_slot_wielded", function(self, weapon_template)
            self.__qiangiq_dauntlessmaul_wielded = weapon_template and weapon_template.name or false
            pcall(Tp.wielded, self._unit, weapon_template and weapon_template.name or nil)
        end)

        if class_name ~= "PlayerHuskAnimationExtension" then
            for _, method in ipairs({ "anim_event", "anim_event_with_variable_float", "anim_event_with_variable_floats",
                "anim_event_with_variable_int" }) do
                if class[method] then
                    mod:hook(class, method, function(func, self, event_name, ...)
                        local a, b = Tp.learn(func, self._unit, event_name, self, event_name, ...)
                        local ok, err = pcall(Tp.on_event, self._unit, event_name)

                        if not ok then
                            mod:error("third person: %s", tostring(err))
                        end

                        return a, b
                    end)
                end
            end
        end
    end
end

if CLASS.AnimationSystem then
    for _, rpc in ipairs({ "rpc_player_anim_event", "rpc_player_anim_event_variable_float", "rpc_player_anim_event_variable_floats",
        "rpc_player_anim_event_variable_int" }) do
        if CLASS.AnimationSystem[rpc] then
            mod:hook_safe(CLASS.AnimationSystem, rpc, function(self, channel_id, unit_id, event_index, ...)
                local is_first_person = select(select("#", ...), ...)

                if is_first_person then
                    return
                end

                local ok, err = pcall(function()
                    local unit = Managers.state.unit_spawner:unit(unit_id)

                    if unit and Unit.alive(unit) then
                        Tp.on_husk_event(unit, event_index)
                    end
                end)

                if not ok then
                    mod:error("third person (other player): %s", tostring(err))
                end
            end)
        end
    end
end

-- Bottom-right weapon icon (0.3.0) --------------------------------------------------------------------------------------
-- hud_element_player_weapon.lua:76-80 reads item.hud_icon into widget.content.icon; the game's maul_2h_p1_m1 icon is
-- placeholder text. The drawn icon (maul_icon.py, dauntless_split\make_icons.py render of the deluxe01 parts) is compiled
-- into Custom/hud_icon (build_hud_icon.py, one quad; loading it makes the texture resident) and shown through
-- ui_default_base, as QIangIQsCrossbow does (Datavault technique-weapon-hud-icon-custom-texture). Without Custom Assets or
-- before the patcher has run, the donor's 2H power maul icon stays.
local HUD_ICON_ASSET = "QIangIQsDauntlessMaul:hud_icon"
local HUD_ICON_MATERIAL = "content/ui/materials/base/ui_default_base"
local HUD_ICON_TEXTURE = "content/mods/qiangiq_dauntlessmaul/hud_icon_material_0_bca"
local icon_ready = false

-- the handler destroys and recreates the element when the slot's weapon changes (hud_element_player_weapon_handler.lua:82)
mod:hook_safe(CLASS.HudElementPlayerWeapon, "init", function(self, parent, draw_layer, start_scale, data)
    self.__qiangiq_dauntlessmaul_icon = data and data.weapon_name == MARK.item
end)

mod:hook_safe(CLASS.HudElementPlayerWeapon, "update", function(self)
    local widget = self.__qiangiq_dauntlessmaul_icon and icon_ready and self._widgets_by_name and self._widgets_by_name.icon

    if not widget then
        return
    end

    local style = widget.style.icon

    style.material_values = style.material_values or {}

    if widget.content.icon ~= HUD_ICON_MATERIAL or style.material_values.texture_map ~= HUD_ICON_TEXTURE then
        widget.content.icon = HUD_ICON_MATERIAL
        style.material_values.texture_map = HUD_ICON_TEXTURE
        widget.dirty = true
    end
end)

-- Combo Tracker (mod by mrouzon): it draws the icons from weapon_template.displayed_attacks (copied from the donor) but
-- highlights the live combo from a pattern keyed by item name (combo_tracker_patterns.lua), which this item is not in.
-- After its on_slot_wielded hook (it loads earlier in mod_load_order.txt) the maul's own pattern (combo_pattern below) is
-- given to it and the light / heavy sweep lists are rebuilt the way its _handle_weapon_pattern does
-- (combo_tracker.lua:302-320).
-- 0.4.0: the pattern is built from this template's own actions (name, kind, allowed_chain_actions: the fields Combo Tracker
-- reads, combo_tracker.lua:302-360), so the own pattern and both Crusher chains highlight correctly.
local function combo_pattern()
    local template = WeaponTemplates[MARK.template]

    if not template or not template.actions then
        return nil
    end

    local pattern = {}

    for name, action in pairs(template.actions) do
        if type(action) == "table" and type(action.allowed_chain_actions) == "table" then
            pattern[name] = { name = name, kind = action.kind, allowed_chain_actions = action.allowed_chain_actions }
        end
    end

    pattern["default"] = template.actions[Pattern.FIRST_WINDUP] and Pattern.FIRST_WINDUP
        or (template.actions.action_melee_start_1 and "action_melee_start_1") or Pattern.FIRST_WINDUP

    return pattern
end

mod:hook_safe(CLASS.PlayerUnitWeaponExtension, "on_slot_wielded", function(self, slot_name)
    local ct = get_mod("combo_tracker")

    if not ct or ct._weapon_name ~= MARK.item or ct._weapon_actions ~= nil then
        return
    end

    local ok, err = pcall(function()
        local actions = combo_pattern()

        if not actions then
            return
        end

        local light, heavy = {}, {}
        local current = actions[actions["default"]]

        for i = 1, #(ct._primary_attack_chain or {}) do
            light[i] = current.allowed_chain_actions.light_attack.action_name
            current = actions[actions[light[i]].allowed_chain_actions.start_attack.action_name]
        end

        current = actions[actions["default"]]

        for i = 1, #(ct._secondary_attack_chain or {}) do
            heavy[i] = current.allowed_chain_actions.heavy_attack.action_name
            current = actions[actions[heavy[i]].allowed_chain_actions.start_attack.action_name]
        end

        ct._weapon_actions = actions
        ct._light_sweeps = light
        ct._heavy_sweeps = heavy
        ct._is_foldable_shovel = false
    end)

    if not ok then
        debug("combo tracker pattern: %s", tostring(err))
    end
end)

local function acquire_driver()
    local custom_assets = get_mod("CustomAssets")

    if not custom_assets or not custom_assets.is_api_compatible or not custom_assets.is_api_compatible(1) then
        mod:info("Custom Assets (API 1) not installed: third person keeps the retail thunder hammer animations")

        return
    end

    local ticket = custom_assets.acquire(mod, TP_DRIVER.id, function(_, _, load_error)
        if load_error then
            mod:info("third-person driver %s not loaded: %s", TP_DRIVER.id, tostring(load_error))

            return
        end

        tp_driver_loaded = true
        mod:info("third-person driver %s loaded", TP_DRIVER.id)
    end, { resident = true, reference_name = TP_DRIVER.id })

    if not ticket then
        mod:info("third-person driver %s could not be requested (Custom folder not patched?)", TP_DRIVER.id)
    end

    local icon_ticket = custom_assets.acquire(mod, HUD_ICON_ASSET, function(_, _, load_error)
        if load_error then
            mod:info("HUD icon %s not loaded: %s", HUD_ICON_ASSET, tostring(load_error))

            return
        end

        icon_ready = true
        mod:info("HUD icon %s loaded", HUD_ICON_ASSET)
    end, { resident = true, reference_name = HUD_ICON_ASSET })

    if not icon_ticket then
        mod:info("HUD icon %s could not be requested (Custom folder not patched?)", HUD_ICON_ASSET)
    end
end

mod.update = function()
    poll()

    local ok, err = pcall(Tp.update)

    if not ok then
        mod:error("third person update: %s", tostring(err))
        pcall(Tp.stop_all)
    end

    Guard.tick()
end

mod.on_all_mods_loaded = function()
    add_to_unlock_lists()
    acquire_driver()
end

mod.on_unload = function()
    pcall(Tp.stop_all)
    Guard.unload()

    local ok, cache = pcall(MasterItems.get_cached)

    if ok and cache then
        cache[MARK.item] = nil

        for name in pairs(cache) do
            if type(name) == "string" and name:find(PART_ROOT, 1, true) == 1 then
                cache[name] = nil
            end
        end
    end

    if MARK.template_ours then
        WeaponTemplates[MARK.template] = nil
    end
end

-- Equip without the backend (QIangIQsShardStaff override): only where this client hosts ----------------------------
local function local_player()
    local players = Managers.player

    return players and players:local_player_safe(1)
end

local function equipped_item_name(player, slot)
    local unit = player and player.player_unit

    if not unit or not Unit.alive(unit) then
        return nil
    end

    local extension = ScriptUnit.has_extension(unit, "visual_loadout_system")
    local item = extension and extension:item_from_slot(slot)

    return item and item.name
end

local previous = {}

local function override(slot, item_name)
    local player = local_player()
    local sync = Managers.profile_synchronization
    local host = sync and sync:synchronizer_host()

    if not player then
        say("no local player")

        return false
    end

    if not host then
        say("not the host here. Use the Psykhanium, a SoloPlay game or a game you host")

        return false
    end

    host:override_slot(player:peer_id(), player:local_player_id(), slot, item_name)
    say("override_slot(%s, %s) sent", slot, tostring(item_name))

    return true
end

local function status()
    say("%s: template %s (id %s, from %s; %s), item %s (id %s, slot %s, parts %s)", MARK.template, tostring(MARK.template_ok),
        tostring(MARK.template_id), tostring(MARK.donor), table.concat(MARK.notes or {}, "; "), tostring(MARK.item_ok),
        tostring(MARK.item_id), tostring(MARK.slot), tostring(MARK.set))
    say("  2h_maul state machine package found: %s, head package found: %s, trail package found: %s",
        tostring(package_found(UNRELEASED_SM)), tostring(package_found(part_unit("head", part_set()))), tostring(package_found(TRAIL_UNIT)))

    if MARK.last_error then
        say("  last error: %s", MARK.last_error)
    end

    local skipped = 0

    for _ in pairs(skipped_events) do
        skipped = skipped + 1
    end

    say("  %s", Tp.debug())
    debug("skipped anim events so far: %d", skipped)
end

mod:command("dauntlessmaul", mod:localize("command_dauntlessmaul"), function(action)
    action = action or "status"

    if action == "status" then
        status()
    elseif action == "equip" then
        if not (MARK.template_ok and MARK.item_ok and MARK.slot) then
            say("%s not ready yet (template %s, item %s)", MARK.template, tostring(MARK.template_ok), tostring(MARK.item_ok))

            return
        end

        local player = local_player()

        previous[MARK.slot] = previous[MARK.slot] or (player and equipped_item_name(player, MARK.slot))
        override(MARK.slot, MARK.item)
    elseif action == "restore" then
        local any = false

        for slot, item_name in pairs(previous) do
            if item_name and override(slot, item_name) then
                previous[slot] = nil
                any = true
            end
        end

        if not any then
            say("nothing to restore (equip first)")
        end
    else
        say("usage: /dauntlessmaul [status|equip|restore]")
    end
end)
