-- QIangIQsDauntlessMaul 0.3.0: "burning" weapon special (owner request 2026-11-01): press special, and the next swings that hit
-- set enemies around the hit on fire. Built only from retail pieces (Darktide source, Aussiemon 1.13.4 copy):
--   * Activation and swing count: the power sword's special class, WeaponSpecialDeactivateAfterNumActivations
--     (powersword_p1_m1.lua:978). It stays active for active_duration seconds (refreshed by every hit,
--     weapon_special_deactivate_after_num_activations.lua process_hit) and counts one activation per swing that hits
--     (on_exit_damage_window); utilities/weapon_special.lua update_active turns it off at num_activations.
--     num_activations: 1 = power sword (powersword_p1_m1.lua weapon_special_tweak_data), 2 = power maul and shield
--     (powermaul_shield_p1_m1.lua:1349, the only retail value above 1). The other tweak values stay the 2H power maul's
--     (active_duration 4, keep_active_on_*, powermaul_2h_p1_m1.lua:1240-1248), and so does its activate action and anim.
--   * The fire on hit: on the first enemy a swing hits (the same rule and placement as the 2H maul's own
--     WeaponSpecialExplodeOnImpact.process_hit), the retail explosion zealot_charge_impact_with_burning
--     (player_explosion_templates.lua:89-111: radius 2.5, stagger-only zealot_dash_impact profile, flame_grenade_initial_blast
--     vfx and sfx, on_hit_buff flamer_assault) is created. It is the Zealot's burning-charge impact.
--   * Extra stacks: the explosion adds 1 flamer_assault stack (weapon_system.lua _handle_explosion_on_hit_buffs). The
--     setting burn_stacks tops each enemy in the same 2.5 m radius up by the rest, server side, with the call retail
--     melee burn uses (add_internally_controlled_buff_with_stacks("flamer_assault", n, t, "owner_unit", player), as in
--     hordes_fire_family_buff_templates.lua:89). Default 3 = zealot_resist_death_subnodes.burn_stacks_melee
--     (talent_settings_zealot.lua:253, the Zealot talent's burn stacks per melee hit). Enemies are found the way
--     hordes_buffs_utilities.lua:79-101 does (broadphase_system.broadphase, side:relation_side_names("enemy")).
--   * flamer_assault itself (weapon_buff_templates.lua:50): 4 s, 0.5 s ticks, max 31 stacks, damage grows with stacks.
-- No new action, template or explosion name is added, so no network lookup changes (Datavault
-- lesson-weapon-action-lookup-shift). The class name is only looked up locally (weapon.lua:63 CLASSES[...]).
require("scripts/extension_systems/weapon/special_classes/weapon_special_deactivate_after_num_activations")

local AttackSettings = require("scripts/settings/damage/attack_settings")
local Explosion = require("scripts/utilities/attack/explosion")
local ExplosionTemplates = require("scripts/settings/damage/explosion_templates")
local PowerLevelSettings = require("scripts/settings/damage/power_level_settings")

local Special = {}
local CLASS_NAME = "QIangIQDauntlessMaulBurnSpecial"
local EXPLOSION = "zealot_charge_impact_with_burning"
local BURN_BUFF = "flamer_assault"
local DEFAULT_POWER_LEVEL = PowerLevelSettings.default_power_level
local BROADPHASE_RESULTS = {}
local CFG

Special.CLASS_NAME = CLASS_NAME

local function burn_area(player_unit, position, radius, stacks, t)
    local game_session = Managers.state and Managers.state.game_session

    if not (game_session and game_session:is_server()) or stacks <= 0 then
        return 0
    end

    local extension_manager = Managers.state.extension
    local broadphase = extension_manager:system("broadphase_system").broadphase
    local side = extension_manager:system("side_system").side_by_unit[player_unit]

    if not (broadphase and side) then
        return 0
    end

    local num_hits = broadphase.query(broadphase, position, radius, BROADPHASE_RESULTS, side:relation_side_names("enemy"))
    local burned = 0

    for i = 1, num_hits do
        local enemy_unit = BROADPHASE_RESULTS[i]
        local buff_extension = HEALTH_ALIVE[enemy_unit] and ScriptUnit.has_extension(enemy_unit, "buff_system")

        if buff_extension then
            buff_extension:add_internally_controlled_buff_with_stacks(BURN_BUFF, stacks, t, "owner_unit", player_unit)
            burned = burned + 1
        end
    end

    return burned
end

function Special.setup(cfg)
    CFG = cfg

    local Burn = class(CLASS_NAME, "WeaponSpecialDeactivateAfterNumActivations")

    Burn.process_hit = function (self, t, weapon, action_settings, num_hit_enemies, target_is_alive, target_unit, damage, result, damage_efficiency, stagger_result, hit_position, attack_direction, abort_attack, optional_origin_slot)
        -- the power sword's own bookkeeping (refreshes special_active_start_t on a live hit)
        CLASSES.WeaponSpecialDeactivateAfterNumActivations.process_hit(self, t, weapon, action_settings, num_hit_enemies, target_is_alive, target_unit, damage, result, damage_efficiency, stagger_result, hit_position, attack_direction, abort_attack, optional_origin_slot)

        local inventory_slot_component = self._inventory_slot_component

        if not target_is_alive or not inventory_slot_component.special_active or num_hit_enemies ~= 1 or not hit_position then
            return
        end

        local template = ExplosionTemplates[EXPLOSION]
        local player_unit = self._player_unit

        if not template or not Unit.alive(player_unit) then
            return
        end

        -- placement as WeaponSpecialExplodeOnImpact.process_hit: half a metre from the hit towards the player
        local player_position = POSITION_LOOKUP[player_unit] + Vector3(0, 0, 0.75)
        local explosion_position = hit_position + 0.5 * Vector3.normalize(player_position - hit_position)
        local world = Unit.world(player_unit)
        local physics_world = World.physics_world(world)

        Explosion.create_explosion(world, physics_world, explosion_position, Quaternion.look(attack_direction), player_unit, template, DEFAULT_POWER_LEVEL, 1, AttackSettings.attack_types.explosion, false, false, weapon.item, optional_origin_slot, nil, nil, nil, true)

        local extra = math.max((CFG.stacks() or 1) - 1, 0)
        local radius = type(template.radius) == "number" and template.radius or 2.5
        -- 0.4.1: t is the hit time process_hit gets (0.4.0 used the global FixedFrame, which is a module in the game, not a
        -- global: CTD "attempt to index global 'FixedFrame'", Datavault lesson-fixedframe-not-global). The mod-added burn
        -- runs under pcall so a fault in it can never stop the sweep.
        local ok, burned = pcall(burn_area, player_unit, explosion_position, radius, extra, t)

        if not ok then
            CFG.debug("burn special: extra stacks failed: %s", tostring(burned))
            burned = 0
        end

        CFG.debug("burn special: explosion at hit, +%d extra %s stacks on %d enemies", extra, BURN_BUFF, burned)
    end

    return Burn
end

-- template edit (called from ensure_template while the clone is built)
function Special.apply(clone, num_activations)
    local tweak = table.clone(clone.weapon_special_tweak_data or {})

    tweak.num_activations = num_activations
    tweak.explosion_template = nil
    clone.weapon_special_class = CLASS_NAME
    clone.weapon_special_tweak_data = tweak
end

return Special
