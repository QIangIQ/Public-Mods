local mod = get_mod("QIangIQsDauntlessMaul")

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = false,
    options = {
        widgets = {
            {
                setting_id = "attack_pattern",
                type = "dropdown",
                default_value = "dauntless",
                options = {
                    { text = "attack_pattern_dauntless", value = "dauntless" },
                    { text = "attack_pattern_crusher_m1", value = "crusher_m1" },
                    { text = "attack_pattern_crusher_m2", value = "crusher_m2" },
                },
            },
            {
                setting_id = "part_set",
                type = "dropdown",
                default_value = "deluxe01",
                options = {
                    { text = "part_set_deluxe01", value = "deluxe01" },
                    { text = "part_set_01", value = "01" },
                },
            },
            {
                setting_id = "animation_set",
                type = "dropdown",
                default_value = "unreleased",
                options = {
                    { text = "animation_set_unreleased", value = "unreleased" },
                    { text = "animation_set_released", value = "released" },
                },
            },
            {
                setting_id = "special_mode",
                type = "dropdown",
                default_value = "burn",
                options = {
                    { text = "special_mode_burn", value = "burn" },
                    { text = "special_mode_retail", value = "retail" },
                },
            },
            {
                setting_id = "burn_swings",
                type = "dropdown",
                default_value = 2,
                options = {
                    { text = "burn_swings_1", value = 1 },
                    { text = "burn_swings_2", value = 2 },
                },
            },
            { setting_id = "burn_stacks", type = "numeric", default_value = 3, range = { 1, 31 }, decimals_number = 0 },
            { setting_id = "fx_at_head", type = "checkbox", default_value = true },
            { setting_id = "maul_3p", type = "checkbox", default_value = true },
            { setting_id = "add_to_unlock_list", type = "checkbox", default_value = true },
            { setting_id = "unlock_level", type = "numeric", default_value = 1, range = { 1, 30 }, decimals_number = 0 },
            { setting_id = "unlock_zealot", type = "checkbox", default_value = true },
            { setting_id = "unlock_veteran", type = "checkbox", default_value = false },
            { setting_id = "unlock_psyker", type = "checkbox", default_value = false },
            { setting_id = "unlock_adamant", type = "checkbox", default_value = true },
            { setting_id = "unlock_broker", type = "checkbox", default_value = false },
            { setting_id = "debug", type = "checkbox", default_value = false },
        },
    },
}
