return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsDauntlessMaul` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsDauntlessMaul", {
            mod_script = "QIangIQsDauntlessMaul/scripts/mods/QIangIQsDauntlessMaul/QIangIQsDauntlessMaul",
            mod_data = "QIangIQsDauntlessMaul/scripts/mods/QIangIQsDauntlessMaul/QIangIQsDauntlessMaul_data",
            mod_localization = "QIangIQsDauntlessMaul/scripts/mods/QIangIQsDauntlessMaul/QIangIQsDauntlessMaul_localization",
        })
    end,
    version = "0.4.1",
    author = "QIangIQ",
    packages = {},
}
