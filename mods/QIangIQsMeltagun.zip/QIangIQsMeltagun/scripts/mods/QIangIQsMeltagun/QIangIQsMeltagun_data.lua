local mod = get_mod("QIangIQsMeltagun")

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = false,
    options = {
        widgets = {
            { setting_id = "unlock_zealot", type = "checkbox", default_value = true },
            { setting_id = "unlock_veteran", type = "checkbox", default_value = true },
            { setting_id = "unlock_level", type = "numeric", default_value = 1, range = { 1, 30 }, decimals_number = 0 },
            { setting_id = "plasma_animations", type = "checkbox", default_value = false },
            {
                setting_id = "jet",
                type = "dropdown",
                default_value = "none",
                options = {
                    { text = "jet_none", value = "none" },
                    { text = "jet_white", value = "white" },
                    { text = "jet_vomit", value = "vomit" },
                    { text = "jet_both", value = "both" },
                },
            },
            { setting_id = "orange_beam", type = "checkbox", default_value = false },
            { setting_id = "trail_brightness", type = "numeric", default_value = 2, range = { 0.5, 10 }, decimals_number = 1 },
        },
    },
}
