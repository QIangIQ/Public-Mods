return {
    mod_name = {
        en = "QIangIQ's Meltagun",
    },
    mod_description = {
        en = "Adds the unreleased Meltagun as a Zealot and Veteran weapon, built from the retail melta_gun model in the game files (rig, receiver, barrel, fuel flask, grip and hose). The game has no template for it yet, so it handles on the Plasma Gun's base (plasmagun_p1_m1) with the retail melta first-person animations and reload, a flamer-style heat jet with flamer ignition and roar sounds, and the melta HUD icon. Needs no other mods. Moveset:\n"
            .. "- Primary (tap): Melt Blast. A short spool-up, then a shotgun-like cone of 7 white-hot melta rays that pierce several enemies and hit armour very hard up close, falling off quickly past 6 m (22 m max).\n"
            .. "- Secondary (hold, then fire): Meltdown Beam. A longer charge into a tighter cone of 9 rays that burns a lane through a horde out to 16 m and bursts on what it exits.\n"
            .. "- Special (hold): vent heat. Heat is shared by both attacks; overheating is as dangerous as on the Plasma Gun.\n"
            .. "6 Melt Blasts or 3 Meltdown Beams per flask. Pick it in Realms Loadout (/rl) or equip with /melta equip in the Psykhanium or a game you host. Everyone in the game needs this mod.",
    },
    command_melta = {
        en = "/melta [status|equip|restore|sound <event>]",
    },
    unlock_zealot = { en = "List it in the Zealot weapon unlock list (Realms Loadout reads it)" },
    unlock_veteran = { en = "List it in the Veteran weapon unlock list" },
    unlock_level = { en = "Unlock level in those lists (needs a restart)" },
    plasma_animations = { en = "Use the Plasma Gun's first-person animations instead of the melta's (needs a restart)" },
    jet = { en = "Extra cloud at the muzzle" },
    jet_description = { en = "Optional cloud on top of the white-hot pellet trails (only you see it). None (default), White = the renegade flamer's white flame, Vomit = the Beast of Nurgle vomit stream, Both = layered." },
    jet_none = { en = "None" },
    trail_brightness = { en = "Trail brightness" },
    trail_brightness_description = { en = "Multiplier on the white-hot colour of the pellet trails." },
    jet_white = { en = "White flame" },
    jet_vomit = { en = "Beast of Nurgle vomit" },
    jet_both = { en = "Both" },
    orange_beam = { en = "Also draw the orange plasma beam (needs a restart)" },
    orange_beam_description = { en = "The renegade captain's orange plasma beam as the shot's core line; other players see it too." },
    plasma_animations_description = { en = "Off (default) = the retail melta_gun first-person state machine from the game files. On = the Plasma Gun's, with the flask following your hand on reloads." },
}
