-- QIangIQ's Meltagun 0.10.2: the unreleased retail Meltagun as a Zealot / Veteran weapon.
--
-- 0.10.2: "/melta sound" errored with "WwisePlugin: Bad Game Source parameter" (auto source from a position); now
--   the player unit is the source.
-- 0.10.1: CTD on the first shot of 0.10.0, network_lookup.lua:605 "[NetworkLookup] Table player_character_sounds does not
-- contain key: wwise/events/weapon/play_meltagun_p1_fire_single_shot". Gear sounds synced to other clients are sent as
-- an index into NetworkLookup.player_character_sounds, which network_lookup.lua builds once from the retail aliases
-- (PlayerCharacterSounds.resource_events), so events no retail alias uses are missing. The melta events (and their
-- _husk versions) are now appended to that lookup in a fixed sorted order, so every client with the mod gets the same
-- indices.
-- 0.10.0 (user picked "Retail sounds, drop AC6" after the Oct 30 name list): the game has its own Meltagun sound
-- events (datamine/datafile-oct30/newly_named_7564.tsv lines 97558-97564, 98230-98251, 99199-99208, Datavault
-- Techniques/datafile-name-list-2026-10-30): play/stop_meltagun_charge(_fast), play_meltagun_p1_fire_single_shot(_charge),
-- play_meltagun_p1_equip, play_meltagun_p1_reload_grab_ammo/_in/_out, play_bullet_hits_meltagun_armored/unarmored,
-- each with a _husk version. Now: ranged_charging / ranged_fast_charging = the melta charge loops, ranged_single_shot =
-- single shot (Melt Blast) / single shot charge (Meltdown Beam), sfx_equip = melta equip, reload aliases = grab/in/out,
-- pre-shot, shot tail and the flamer roar are silent (the melta shot covers them). Unit hits swap the impact sfx for the
-- melta hit events in a hook on FxSystem.play_impact_fx (every client: the server plays it and the rpc path calls it
-- too), armoured vs unarmoured from the target's armour. No melta overheat or vent events exist, so those keep 0.8.0.
-- Surface hits keep the incendiary sounds (the surface_hit/start/stop events look made for a beam). The AC6 sounds,
-- their settings and the SimpleAudio lookup are removed. "/melta sound <name>" plays one event to test it in game.
-- 0.9.2 (user: "when inspecting, the little switch that the character flips befroe presisng hte vent button bugs out
-- and displays floating off to the left. alongside the mag underenders when inspecitng"): the melta set has no inspect
-- clip, so inspect plays the plasma_rifle one, which drives ap_release_01 / ap_release_02 / ap_magazine_01 to the
-- plasma rifle's spots (run.txt: plasma ap_release_01 at x -0.061, its flask node at z -0.028 inside the melta
-- receiver). While action_inspect runs, those nodes are pinned to their last pose before the inspect, on the first-person
-- unit and the 1p rig, from the animation-update callback of ScriptWorld.update (after animations, before the scene
-- graph links the receiver to them).
-- 0.9.1: launch error, "%" in the ac6_volume name went through DMF's string.format; removed.
--
-- 0.9.0 (user picked Armored Core VI sounds on the AC6 sound picker; "keep it in nexus zip, just make sure to say that
-- it requires simpleaudio"): optional AC6 sounds through SimpleAudio (its README: play_file(path, settings,
-- unit_or_position), "mods/..." paths resolve from the mods folder). Every gear sound of the local player goes through
-- PlayerUnitVisualLoadoutExtension.resolve_gear_sound (one-shots, and resolve_looping_gear_sound for the play_/stop_
-- loop aliases), so while the melta is the active template that hook plays the picked file and hands back the silence
-- event: charge (play_ranged_charging / play_ranged_fast_charging), shot (ranged_single_shot; Meltdown Beam when the
-- current action is action_shoot_charged), overheat warning (weapon_overload), vent (play_ranged_plasma_venting); the
-- shot tail, pre-shot ignition and flamer roar go quiet. The projectile sound plays at the hit point from the
-- _play_line_fx hook. Without SimpleAudio, or with the setting off, the 0.8.0 retail sounds stay. Files: audio/ac6_*.mp3
-- rendered from AC6 sd\weapon.bnk / bullet_glide.bnk (BinderKeys sd key, wwiser + vgmstream).
--
-- 0.8.0 (user after 0.7.0: "melta gun still has windup and warning audio form plasmagun", "currently nonexistent
-- shooting and projectile noise"; asked about AC6 sounds):
--   * The "windup" is PlasmagunOverheatEffects' looping alias weapon_overload_loop (plasmagun_overheat_effects.lua:7,
--     runs while heat > 0, so it rises with every charge) and the warning is its threshold alias weapon_overload
--     (stages high / critical) plus sfx_about_to_explode; all three were still the plasma gun's (copied by
--     copy_aliases). Now: loop = laspistol heat loop, critical loop = servo-skull flame loop, threshold warnings =
--     flamer last-round click / alt-fire switch, about-to-explode = flamer alt-fire off, vent rattle silent. All events
--     are retail entries of player_character_sound_event_aliases.lua.
--   * Shot: the incendiary shotgun's blast (shotgun_p1_m3 ranged_single_shot "play_shotgun_p1_m3") and its tail
--     (play_player_wpn_refl_shotgun) instead of silence; the flamer roar loop and every new event are added to the
--     item's resource dependencies (they were not loaded before, so the roar never played).
--
-- 0.7.0 (user after 0.6.0: "2x the heat gen", "instead of a cloud in front of muzzle, it should be a trail", "make it
-- conical instead of a beam, more of a shotgun like sm2", "make more of the barrel heat up ... char the reviecer"):
--   * Heat: every overheat_percent / full_charge_overheat_percent of the four charge templates doubled.
--   * Cone: each shot is a fan of hit scans: the normal one plus a ring around it (Melt Blast 1 + 6 at 7 degrees, Meltdown
--     Beam 1 + 8 at 4 degrees), rotations built like utilities/spread.lua _combine_spread_rotations (roll around forward,
--     then pitch). ActionShootHitScan._shoot is called once per pellet; heat and ammo stay once per shot (they live in
--     fixed_update). Per-pellet power is lower, a close hit lands every pellet.
--   * Trail: one thin beam per pellet from content/fx/particles/weapons/rifles/lasgun/lasgun_beam, placed like
--     PlayerUnitFxExtension._spawn_unit_fx_line ("hit_distance" = width, length, length) and tinted white-hot through its
--     "beam" cloud's "beam_color" vector (the variable Polychromatic's guns/data/direct_effects.lua tints). The cloud
--     jet is now optional (default none).
--
-- 0.6.0 (user after 0.5.0: barrel "flash white-hot for a frame or two before reverting", "unable to fire gun immediatley
-- after reloading", "beam still looks like enemy plasmagunner beam"; pointed at Custom Flames / Polychromatic):
--   * Glow: written every frame after the slot scripts (PlayerUnitVisualLoadoutExtension.update runs
--     WieldableSlotScripts.update, WeaponTemperatureEffects sends set_barrel_overheat each frame and reset it).
--   * Reload: action_reload (reload_state, total_time 9.4) only chained to wield, so firing waited for the full plasma
--     reload time after the melta clip ended. Chains to shoot / brace / vent from 6.8 s (ammo refills at 6.7 s,
--     plasma_rifle_reload_template.lua lift_weapon).
--   * Beam: the orange renegade-captain beam is off by default (option). The shot is a particle jet drawn the way
--     CustomFlames (Nexus mod, CustomFlames.lua FlamerGasEffects._update_effects) uses enemy flames as player streams:
--     renegade_flame_thrower ("Renegade White") and/or bon_vomit_projectile ("Nurgle Vomit", rotated 75 degrees),
--     particle variable 1 = life (distance / 50), custom fov in first person. Option "jet" picks white / vomit / both.
--     Polychromatic is not installed here, so it was not used.
--
-- 0.5.0 (user after 0.4.0: "nearly perfect, now only the heat doesnt show up on my peril bar, and give it 2x more ammo
-- reserve, make the barrel heat up to pure white similar to the dual autopistols and plasmagun. also make the melta's
-- projectile trail more "liquidy" ... recolor beast of nurgle vomit into plasma-white color perhaps"):
--   * Reserve 90 -> 180.
--   * Barrel glow: the BarrelOverheat component (scripts/components/barrel_overheat.lua) sets the material scalar
--     "overheat" on its unit, driven by WeaponTemperatureEffects; PlasmaCoil (plasma_coil.lua) sets
--     "external_overheat_glow". The melta parts carry neither component (but barrel_01 has an overheat mask), so the mod
--     sets both scalars on the melta attachments itself from the weapon's heat (local player only).
--   * Trail: the shotgun smoke line is gone; the 0.3.0 flamer stream (never visible) is replaced by the Beast of Nurgle
--     vomit stream (chaos_beast_of_nurgle_settings.lua bon_vomit_projectile), drawn the way utilities/flamer.lua does it:
--     particle variables "1".."4" are world-space control points (here a straight line muzzle -> hit). Its colour is
--     baked into the particle (no named colour variable; the .particles file holds only hashes), so it is not recoloured.
--   * Peril bar: the 0.4.0 log shows the heat rising (0.03 -> 0.63 over 4 shots). The first seconds with the melta
--     wielded now log the heat the HUD reads (slot component of the local player) to find where it is lost.
--
-- 0.4.0 (user after 0.3.3: "still no effects, also the heat % is not shown, give it vastrly increased damage, and a
-- heavy stagger. ver similar to helldivers 2's melta gun"):
--   * Shot look: the line effect is back, through the engine's own path (action_shoot.lua:1105 spawn_unit_fx_line, the
--     path the plasma bolt rendered on): renegade_captain_plasma_beam (minion_line_effects.lua, orange plasma beam +
--     orange linger, sfx dropped), plus a second line, shotgun_incendiary_trail (player_line_effects.lua, burning smoke
--     trail), on the same shot. Both are registered line effects, so other players see them too. The flamer stream from
--     0.3.0 is still tried on top, and the first shots log what ran (console log, "melta fx").
--   * Heat: _add_heat is wrapped; when the shot did not raise overheat_current_percentage (the overcharge HUD hides at
--     0, hud_element_overcharge.lua _update_overheat) it adds the melta's own heat via Overheat.increase_immediate.
--     /melta status prints the heat.
--   * Damage: blast x4, beam x6 power, armoured near x2, carapace (super_armor) never below 0.75 near.
--   * Stagger: stagger_category "explosion" (light/medium/heavy/explosion), stagger_override "heavy"
--     (stagger_calculation.lua _get_stagger_type), ignore_stagger_reduction, stagger_resistance_modifier 0.5, impact x3.
--
-- 0.3.0 (user after 0.2.2: plasma unload on reload, plasma shot sound and bolt; "mimic flamer's or SM2's melta or
-- Helldivers' melta"; and the 2026-10-25 rule that mods must be standalone):
--   * Reload: in the melta 1p state machine the state reached by event "reload" plays plasma_rifle/reload_start (the
--     plasma unload) and the state "reload_start" plays melta_gun/reload_start (_scratch_melta\sm_reload.py byte
--     offsets: event id32 right before each clip murmur64). The plasma reload template's first state sends "reload"
--     (plasma_rifle_reload_template.lua lift_weapon.anim_1p), so a clone sends "reload_start" in 1p (3p keeps "reload").
--   * Shot: no line effect or muzzle flash; each shot spawns the flamer's burst stream particle from the muzzle toward
--     the hit point the way flamer_gas_effects.lua does (create_particles + "life" = distance / speed 35, custom fov in
--     1p, impact effect at the end, flamethrower 3d roar loop), held for the shot's flame time. Sounds are aliased for
--     meltagun_p1_m1: pre-shot flamethrower ignition (flamer_p1_m1 ranged_pre_shoot), shot = the Helbore charged shots
--     (lasgun_p2_m1 / m3 charged), tail = heavy rifle reflection. All retail files; SimpleAudio and the wavs are gone.
--   * Only the shooter sees the flame stream (the line effect used to be synced through the fx system).
-- 0.3.1 (user: "still plasmagun vent, still plasmagun impact on enemy and surfaces, firing noise still hellbore"):
--   * Hits: fire_configuration.damage_type pellet_incendiary (incendiary shotgun impacts) instead of plasma.
--   * Vent / charge / overheat / clip-out: the meltagun_p1_m1 entries copied from plasmagun_p1_m1 in the sound and particle
--     alias tables are replaced (Purgatus charge loop, servo-skull flame loop, flame-staff charge particle, thumper smoke).
--   * Shot: silent shot alias, the flamer roar loop from 0.3.0 is the shot sound.
-- 0.3.2: CTD on 0.3.1 load: the SOUNDS table (with "%s_..." alias patterns) sat in the template, so
--   WeaponTemplateResourceDependencies.generate put a non-existent package name in the item. Template no longer holds it;
--   extra alias resources are added to the item only after Application.can_get_resource("package", name).
-- 0.3.3: no flame visible in 0.3.2: the _play_line_fx hook sat on ActionShoot, but class() copies inherited functions
--   into ActionShootHitScan at creation, so the hook never ran. Now hooked on ActionShootHitScan.
--
-- 0.2.0 (user after the first in-game test: "still plasmagun reload and firing", HUD icon still the plasma gun's):
--   * The retail melta_gun 1p state machine is complete enough to use (limn --dump-raw state_machine,
--     _scratch_melta\sm_events.py / sm_events.txt): ae5da140b9c940ab.state_machine holds every plasma_rifle event name
--     (attack_charge, attack_charge_shoot, heavy_charge(_shoot), vent(_end/_override), reload_start/middle/end, ...) plus
--     mid_reload_finished, shoot_finished, aim_offset_x/y, raise. It plays the melta clips (charge_start/shoot,
--     heavy_charge_*, vent_*, reload_start, mag_offset, push, equip, idle, sprint, slide) and plasma_rifle clips for the
--     rest (reload_middle/end, ironsight, inspect). It is now the default; "plasma_animations" brings the old one back.
--     With it the receiver links to the melta rig by node name as the retail parts are built for, so no static receiver.
--   * (replaced in 0.3.0) Firing look: no melta particles or sounds exist in the files, so the beam/muzzle are the Krieg lasgun's charged and
--     bfg ones (LineEffects.lasbeam_charged / lasbeam_bfg, lasgun_charged_muzzle / lasgun_bfg_muzzle, lasgun_p2_m1.lua)
--     instead of the blue plasma bolt, and the local shot sound is a synthesised melta roar (audio/*.wav, made by
--     _scratch_melta\make_audio.py on the PC) through SimpleAudio, as QIangIQsDauntlessArmory does for the crossbow.
--   * HUD icon: the item's hud_icon (hud_element_player_weapon.lua:77 reads item.hud_icon when the template has none)
--     is the retail content/ui/materials/icons/weapons/hud/meltagun_p1_m1, a package like the plasma one
--     (all_resources.json exts material + package), added to the item's resource_dependencies so it loads.
--
-- What is in the game files (A:\Dowloads\Darktide_NonMod\dauntless_oct22_recheck\all_resources.json, Oct 22 2026 build;
-- the units are already in the Oct 11 dump, dauntless_datamine\_raw\e44cfb8d688d2b9e.unit):
--   * content/weapons/player/ranged/melta_gun/wpn_melta_gun_chained_rig and attachments receiver_01, barrel_01,
--     magazine_01, grip_01, connector_01 (with full texture sets, barrel_01 has an overheat mask).
--   * HUD / mastery icons content/ui/.../meltagun_p1_m1 and meltagun_p1, so the template name is meltagun_p1_m1.
--   * An unfinished first-person animation set content/characters/player/human/first_person/animations/melta_gun
--     (27 clips: charge_start/shoot, heavy_charge_*, vent_*, reload_start, push, equip, idle, run, sprint, slide);
--     no third-person set, no reload end, no ironsight. Weapon template, item, stats: NOT in the build.
--   * Node names (id32 match, dauntless_datamine\_scratch_melta\melta_nodes.py / run.txt):
--       receiver_01: ap_barrel_01 (0,0.4301,0.0888), ap_magazine_01 (-0.0641,0.1349,0.1141), ap_grip_01 (0,0.0665,0.0323),
--         ap_connector_01 (0,0.3686,-0.0386), fx_reload, fx_stock_01, ap_release_01/02, ap_anim_01/02/03
--       barrel_01: fx_muzzle and fx_overheat at its root, fx_barrel_01 at the tip (y 0.2483; mesh ends at 0.266)
--       grip_01: ap_trigger_01 (0,-0.0665,-0.0323) = exactly under the receiver origin once attached
--       rig: ap_trigger_01 at the origin, same as the plasma_rifle rig, so no grip shift is needed.
--
-- Behaviour is borrowed from plasmagun_p1_m1 (Aussiemon source master, plasma_rifles/plasmagun_p1_m1.lua): the melta
-- animation set is a subset of the plasma rifle's (charge_start/charge_shoot/heavy_charge_*/vent_* clips with the same
-- names, first_person/animations/plasma_rifle), and the barrel carries the same fx_muzzle / fx_overheat nodes.
-- Rig overlap with the plasma rifle rig is 0.438 (run.txt). The new-weapon recipe is QIangIQsDauntlessArmory's
-- (template clone + NetworkLookup append + alias copy, item clone into MasterItems, static receiver, resource deps).
--
-- Own moveset (extrapolated, the game has no melta numbers):
--   * Melt Blast (tap): own charge template (spool-up), 5 ammo, thick short beam (sphere sweep radius 0.3, range 22,
--     penetration depth 2.5), own damage profile from default_plasma_bfg_light: attack power x1.6, cleave x2.5, armour
--     attack modifiers x1.3 near, all attack modifiers x0.6 far, near/far ranges 6/18 m.
--   * Meltdown Beam (brace + fire): own charge template (longer), 10 ammo, wide beam (radius 0.55, range 16, depth 5)
--     with the plasma demolition explosion, own profile from default_plasma_bfg: attack x1.5, cleave x2, same armour rules.
--   * Flask: 30 rounds, 90 reserve (own WeaponAmmoTemplates entry, wired through __base_template_lookup as in
--     QIangIQsDauntlessArmory 0.4.2). Vent / overheat / explode: the plasma gun's, slightly faster venting.
-- Author: QIangIQ
local mod = get_mod("QIangIQsMeltagun")

local WeaponTemplates = require("scripts/settings/equipment/weapon_templates/weapon_templates")
local MasterItems = require("scripts/backend/master_items")
local NetworkLookup = require("scripts/network_lookup/network_lookup")

local W = "content/weapons/player/ranged/melta_gun/"
local ITEM_ROOT = "content/items/weapons/player/ranged/"

-- 0.10.3: the template name must sort after every retail template. weapon_action.template_name is sent as an index
-- into the sorted table.keys(WeaponTemplates) (player_unit_data_component_config.lua:131-140), and so are the tweak
-- lists built from it. "meltagun_p1_m1" sorted before unarmed_hub_human, so on a Fatshark hub server a correction
-- decoded the hub template as "unarmed" and crashed in hub_aim_constraints.lua (no aim_constraint_target_torso).
-- Vault: Lessons/lesson-shardstaff-hub-aim-constraint-crash.
local TEMPLATE = "zz_qiangiq_meltagun_p1_m1"
local SOURCE_TEMPLATE = "plasmagun_p1_m1"
local ITEM = ITEM_ROOT .. "meltagun_p1_m1"                     -- same pattern as the game's meltagun_p1_m1 icon names
local SOURCE_ITEM = ITEM_ROOT .. "plasmagun_p1_m1"
local RIG = W .. "wpn_melta_gun_chained_rig"
local HUD_ICON = "content/ui/materials/icons/weapons/hud/meltagun_p1_m1"
local MELTA_SM_1P = "content/characters/player/human/first_person/animations/melta_gun"
local DISPLAY = "loc_qiangiq_meltagun"
-- Shot look and sound, retail only (flamer_p1_m1.lua action_shoot fx; player_character_sound_event_aliases.lua)
local FLAME = {
    stream = "content/fx/particles/weapons/rifles/player_flamer/flamer_code_control_burst",
    stream_3p = "content/fx/particles/weapons/rifles/player_flamer/flamer_code_control_3p",
    impact = "content/fx/particles/weapons/rifles/zealot_flamer/zealot_flamer_impact_delay",
    loop = "wwise/events/weapon/play_flamethrower_fire_loop_3d",
    loop_stop = "wwise/events/weapon/stop_flamethrower_fire_loop_3d",
    speed = 35,
    -- 0.6.0: enemy streams as CustomFlames uses them (CustomFlames.lua renegadeWhite / nurgleVomit, speed 50)
    white = "content/fx/particles/enemies/renegade_flamer/renegade_flame_thrower",
    liquid = "content/fx/particles/enemies/beast_of_nurgle/bon_vomit_projectile",
    jet_speed = 50,
    -- 0.7.0: player_line_effects.lua lasbeam vfx; Polychromatic direct_effects.lua: cloud "beam", vector "beam_color"
    trail_vfx = "content/fx/particles/weapons/rifles/lasgun/lasgun_beam",
    trail_width = 0.05,
    trail_color = { 1, 0.92, 0.78 },
}
-- 0.3.1: no Helbore shot (user), the flamer roar is the shot; charge = Purgatus staff warp-fire charge loop
-- (forcestaff_p2_m1 ranged_charging), vent = servo-skull flame loop (companion_servo_skull_flame_loop)
local SOUNDS = {
    -- 0.10.0: the retail melta events (see the header); pre-shot and tail stay silent
    pre_shoot = "wwise/events/weapon/play_weapon_silence",
    shot = "wwise/events/weapon/play_meltagun_p1_fire_single_shot",
    shot_charged = "wwise/events/weapon/play_meltagun_p1_fire_single_shot_charge",
    tail = "wwise/events/weapon/play_weapon_silence",
    charge = "wwise/events/weapon/%s_meltagun_charge",
    charge_fast = "wwise/events/weapon/%s_meltagun_charge_fast",
    equip = "wwise/events/weapon/play_meltagun_p1_equip",
    reload_out = "wwise/events/weapon/play_meltagun_p1_reload_out",
    reload_grab = "wwise/events/weapon/play_meltagun_p1_reload_grab_ammo",
    reload_in = "wwise/events/weapon/play_meltagun_p1_reload_in",
    hit_armored = "wwise/events/weapon/play_bullet_hits_meltagun_armored",
    hit_unarmored = "wwise/events/weapon/play_bullet_hits_meltagun_unarmored",
    vent = "wwise/events/weapon/%s_servoskull_weapon_flame_loop",
    -- 0.8.0: overheat hum / warnings (weapon_overload_loop, weapon_overload, sfx_about_to_explode)
    heat_loop = "wwise/events/weapon/%s_laspistol_heat_loop",
    heat_loop_critical = "wwise/events/weapon/%s_servoskull_weapon_flame_loop",
    warn_high = "wwise/events/weapon/play_last_bullet_flamethrower",
    warn_critical = "wwise/events/weapon/play_flametrower_alt_fire_on",
    about_to_explode = "wwise/events/weapon/play_flametrower_alt_fire_off",
    silence = "wwise/events/weapon/play_weapon_silence",
}
-- 0.3.1: particle aliases (player_character_particle_aliases.lua) instead of the blue plasma ones
local PARTICLES = {
    charge = "content/fx/particles/weapons/flame_staff/psyker_flame_staff_charge",      -- forcestaff_p2_m1 ranged_charging
    vent = "content/fx/particles/weapons/flame_staff/psyker_flame_staff_charge",
    clip_out = "content/fx/particles/weapons/rifles/ogryn_thumper/ogryn_thumper_reload_smoke", -- ogryn_thumper_p1_m2
}
-- 0.3.1: hits use the incendiary shotgun's impact effects (impact_fx_pellet_incendiary.lua: shotgun_incendiary_impact)
local IMPACT_DAMAGE_TYPE = "pellet_incendiary"
-- 0.4.0: shot lines through the fx system (registered names, NetworkLookup.line_effects): orange plasma beam of the
-- renegade captain (minion_line_effects.lua) and the incendiary shotgun's burning trail (player_line_effects.lua)
local BEAM_LINE = "renegade_captain_plasma_beam"
local TRAIL_LINE = "shotgun_incendiary_trail"

local PARTS = {
    receiver = { unit = W .. "attachments/receiver_01/receiver_01" },
    barrel = { unit = W .. "attachments/barrel_01/barrel_01", attach_node = "ap_barrel_01" },
    magazine = { unit = W .. "attachments/magazine_01/magazine_01", attach_node = "ap_magazine_01" },
    grip = { unit = W .. "attachments/grip_01/grip_01", attach_node = "ap_grip_01" },
    connector = { unit = W .. "attachments/connector_01/connector_01", attach_node = "ap_connector_01" },
}
local PART_ORDER = { "receiver", "barrel", "magazine", "grip", "connector" }

-- Moveset numbers ----------------------------------------------------------------------------------------------------
local AMMO_TEMPLATE = "qiangiq_meltagun_p1_m1"
local AMMO = { clip = 30, reserve = 180 }
local BLAST_AMMO, BEAM_AMMO = 5, 10

-- shapes of plasmagun_p1_m1_charge_direct / _shoot / _shoot_charged / _charge (weapon_charge_templates.lua:34-78)
local CHARGE_TEMPLATES = {
    action_charge_direct = {
        name = "qiangiq_meltagun_charge_direct",
        template = {
            charge_on_action_start = true,
            full_charge_overheat_percent = 0.04,
            fully_charged_charge_level = 0.525,
            limit_max_charge_to_ammo_clip = true,
            min_charge = 0.05,
            charge_duration = { lerp_basic = 0.7, lerp_perfect = 0.45 },
            overheat_percent = { lerp_basic = 0.16, lerp_perfect = 0.08 },
        },
    },
    action_shoot = {
        name = "qiangiq_meltagun_shoot",
        template = {
            use_charge = true,
            overheat_percent = { lerp_basic = 0.6, lerp_perfect = 0.36 },
        },
    },
    action_shoot_charged = {
        name = "qiangiq_meltagun_shoot_charged",
        template = {
            limit_max_charge_to_ammo_clip = true,
            use_charge = true,
            overheat_percent = { lerp_basic = 1, lerp_perfect = 0.6 },
        },
    },
    action_charge = {
        name = "qiangiq_meltagun_charge",
        template = {
            charge_on_action_start = true,
            charge_duration = { lerp_basic = 1.6, lerp_perfect = 1 },
            overheat_percent = { lerp_basic = 0.3, lerp_perfect = 0.2 },
            full_charge_overheat_percent = { lerp_basic = 0.04, lerp_perfect = 0.02 },
        },
    },
}

local ATTACKS = {
    action_shoot = {
        profile = "qiangiq_meltagun_blast",
        base_profile = "default_plasma_bfg_light",
        attack_mult = 1.2,
        impact_mult = 3,
        cleave_mult = 3,
        ranges = { min = 6, max = 18 },
        range = 22,
        radius = 0.15,
        pellets = 7,
        spread = 7,
        depth = 2.5,
        ammo = BLAST_AMMO,
        flame_time = 0.3,
    },
    action_shoot_charged = {
        profile = "qiangiq_meltagun_beam",
        base_profile = "default_plasma_bfg",
        attack_mult = 1.5,
        impact_mult = 3,
        cleave_mult = 3,
        ranges = { min = 8, max = 16 },
        range = 16,
        radius = 0.25,
        pellets = 9,
        spread = 4,
        depth = 5,
        ammo = BEAM_AMMO,
        flame_time = 0.6,
    },
}

local ARMOURED = { "armored", "super_armor", "resistant", "berserker", "disgustingly_resilient" }
local NEAR_ARMOUR_MULT, FAR_MULT = 2, 0.6
local MIN_NEAR_CARAPACE = 0.75
-- 0.4.0 heavy stagger (stagger_settings.lua categories, stagger_calculation.lua _get_stagger_type: any threshold
-- passed becomes stagger_override; stagger_resistance_modifier scales the breed thresholds)
local STAGGER = {
    stagger_category = "explosion",
    stagger_override = "heavy",
    ignore_stagger_reduction = true,
    stagger_resistance_modifier = 0.5,
}

mod:add_global_localize_strings({
    loc_qiangiq_meltagun = { en = "Meltagun (datamined)" },
})

local function say(fmt, ...)
    local text = string.format(fmt, ...)

    mod:echo(text)
    mod:info(text)
end

-- Network lookups (QIangIQsShardStaff append_lookup): new names go at the end so no existing id moves -------------
local function append_lookup(lookup_name, key)
    local lookup = NetworkLookup[lookup_name]

    if not lookup then
        return false, "no lookup"
    end

    local existing = rawget(lookup, key)

    if existing then
        return true, existing
    end

    local index = #lookup + 1

    rawset(lookup, index, key)
    rawset(lookup, key, index)

    return true, index
end

-- Particle / sound aliases keyed by wielded_weapon_template (QIangIQsShardStaff alias_template_keys) --------------
local ALIAS_MODULES = {
    "scripts/settings/particles/player_character_particle_aliases",
    "scripts/settings/sound/player_character_sound_event_aliases",
}

local function alias_keys(root, source, target, seen, counter)
    if type(root) ~= "table" or seen[root] then
        return
    end

    seen[root] = true

    local value = rawget(root, source)

    if value ~= nil and rawget(root, target) == nil then
        root[target] = value
        counter.n = counter.n + 1
    end

    for _, child in pairs(root) do
        if type(child) == "table" then
            alias_keys(child, source, target, seen, counter)
        end
    end
end

local function copy_aliases(source, target)
    local counter = { n = 0 }

    for _, path in ipairs(ALIAS_MODULES) do
        local ok, module = pcall(require, path)

        if ok then
            alias_keys(module, source, target, {}, counter)
        else
            mod:error("alias module %s: %s", path, tostring(module))
        end
    end

    return counter.n
end

-- 0.3.0: own shot sounds for meltagun_p1_m1 in the retail alias table (switch wielded_weapon_template [, charge_level])
local function set_sound_aliases()
    local ok, aliases = pcall(require, "scripts/settings/sound/player_character_sound_event_aliases")

    if not ok or type(aliases) ~= "table" then
        return
    end

    local function set(alias, value)
        local events = aliases[alias] and aliases[alias].events

        if events then
            events[TEMPLATE] = value
        end
    end

    set("ranged_single_shot", { default = SOUNDS.shot, fully_charged = SOUNDS.shot_charged })
    set("ranged_pre_shoot", SOUNDS.pre_shoot)
    set("ranged_shot_tail", SOUNDS.tail)
    set("ranged_charging", SOUNDS.charge)
    set("ranged_fast_charging", SOUNDS.charge_fast)
    set("sfx_equip", SOUNDS.equip)
    set("sfx_magazine_eject", SOUNDS.reload_out)
    set("plasma_flask_remove", SOUNDS.reload_out)
    set("sfx_grab_clip", SOUNDS.reload_grab)
    set("sfx_magazine_insert", SOUNDS.reload_in)
    set("plasma_flask_insert", SOUNDS.reload_in)

    -- 0.10.1: synced gear sounds go over the network as NetworkLookup.player_character_sounds indices (see the header)
    local events = {}

    for _, event in ipairs({ SOUNDS.shot, SOUNDS.shot_charged, SOUNDS.equip, SOUNDS.reload_out, SOUNDS.reload_grab,
        SOUNDS.reload_in }) do
        events[#events + 1] = event
        events[#events + 1] = event .. "_husk"
    end

    for _, pattern in ipairs({ SOUNDS.charge, SOUNDS.charge_fast }) do
        for _, verb in ipairs({ "play", "stop" }) do
            local event = (pattern:gsub("%%s", verb))

            events[#events + 1] = event
            events[#events + 1] = event .. "_husk"
        end
    end

    table.sort(events)

    for _, event in ipairs(events) do
        local ok_lookup, err = append_lookup("player_character_sounds", event)

        if not ok_lookup then
            mod:error("sound lookup %s: %s", event, tostring(err))
        end
    end
    set("ranged_plasma_venting", SOUNDS.vent)
    set("weapon_overload_loop", { default = SOUNDS.heat_loop, critical = SOUNDS.heat_loop_critical })
    set("weapon_overload", { high = SOUNDS.warn_high, critical = SOUNDS.warn_critical })
    set("sfx_about_to_explode", SOUNDS.about_to_explode)
    set("sfx_vent_rattle", SOUNDS.silence)

    local ok_p, particles = pcall(require, "scripts/settings/particles/player_character_particle_aliases")

    if ok_p and type(particles) == "table" then
        local function set_particle(alias, value)
            local entries = particles[alias] and particles[alias].particles

            if entries then
                entries[TEMPLATE] = value
            end
        end

        set_particle("ranged_charging", PARTICLES.charge)
        set_particle("plasma_venting", PARTICLES.vent)
        set_particle("clip_out", PARTICLES.clip_out)
        set_particle("weapon_overload_loop", { low = PARTICLES.vent, high = PARTICLES.vent, critical = PARTICLES.vent })
    end
end

-- Damage profiles: registered under their own names (damage_profile_templates.lua sets .name = key, and
-- network_lookup.lua:175 builds damage_profile_templates from that table, so the name must be in the lookup) --------
local function scale(value, k)
    if type(value) == "number" then
        return value * k
    elseif type(value) == "table" then
        local out = {}

        for i, v in pairs(value) do
            out[i] = type(v) == "number" and v * k or v
        end

        return out
    end

    return value
end

local function make_profile(spec)
    local DamageProfileTemplates = require("scripts/settings/damage/damage_profile_templates")
    local existing = rawget(DamageProfileTemplates, spec.profile)

    if existing then
        return existing
    end

    local base = DamageProfileTemplates[spec.base_profile]

    if not base then
        return nil, "damage profile " .. spec.base_profile .. " not found"
    end

    local profile = table.clone(base)

    profile.name = spec.profile

    if profile.power_distribution then
        profile.power_distribution.attack = scale(profile.power_distribution.attack, spec.attack_mult)
        profile.power_distribution.impact = scale(profile.power_distribution.impact, spec.impact_mult or 1)
    end

    for key, value in pairs(STAGGER) do
        profile[key] = value
    end

    if profile.cleave_distribution then
        profile.cleave_distribution.attack = scale(profile.cleave_distribution.attack, spec.cleave_mult)
        profile.cleave_distribution.impact = scale(profile.cleave_distribution.impact, spec.cleave_mult)
    end

    profile.ranges = { min = spec.ranges.min, max = spec.ranges.max }

    local mods = profile.armor_damage_modifier_ranged

    if mods and mods.near and mods.near.attack then
        for _, armour in ipairs(ARMOURED) do
            local v = mods.near.attack[armour]

            if v ~= nil then
                mods.near.attack[armour] = scale(v, NEAR_ARMOUR_MULT)
            end
        end

        local carapace = mods.near.attack.super_armor

        if type(carapace) == "number" and carapace < MIN_NEAR_CARAPACE then
            mods.near.attack.super_armor = MIN_NEAR_CARAPACE
        end
    end

    if mods and mods.far and mods.far.attack then
        for armour, v in pairs(mods.far.attack) do
            mods.far.attack[armour] = scale(v, FAR_MULT)
        end
    end

    local ok = append_lookup("damage_profile_templates", spec.profile)

    if not ok then
        return nil, "NetworkLookup.damage_profile_templates missing"
    end

    DamageProfileTemplates[spec.profile] = profile

    return profile
end

-- Hit scan: the cloned action already owns a deep copy of the plasma hit scan template (table.clone of the template)
local function tune_hit_scan(hit_scan, spec, profile)
    hit_scan.range = spec.range

    if hit_scan.damage and hit_scan.damage.impact then
        hit_scan.damage.impact.damage_profile = profile
    end

    if hit_scan.damage and hit_scan.damage.penetration then
        hit_scan.damage.penetration.depth = spec.depth
    end

    for _, test in ipairs(hit_scan.collision_tests or {}) do
        if test.test == "sphere" then
            test.radius = spec.radius
        end
    end
end

-- weapon_tweak_templates.lua: templates are preparsed before we clone, so the clone's lookup entries name the base
-- template; changing base_identifier makes _build_templates read ours (as QIangIQsDauntlessArmory does for ammo)
local function swap_base(clone, template_type, key, base_identifier)
    local lookup = rawget(clone, "__base_template_lookup")
    local per_type = lookup and lookup[template_type]
    local entry = per_type and per_type[key]

    if entry then
        entry.base_identifier = base_identifier

        return true
    end

    return false
end

local function register_handling_templates()
    local WeaponChargeTemplates = require("scripts/settings/equipment/weapon_handling_templates/weapon_charge_templates")
    local WeaponAmmoTemplates = require("scripts/settings/equipment/weapon_handling_templates/weapon_ammo_templates")

    for _, def in pairs(CHARGE_TEMPLATES) do
        WeaponChargeTemplates[def.name] = table.clone(def.template)
    end

    WeaponAmmoTemplates[AMMO_TEMPLATE] = {
        ammunition_clips = { { lerp_basic = AMMO.clip, lerp_perfect = AMMO.clip } },
        ammunition_reserve = { lerp_basic = AMMO.reserve, lerp_perfect = AMMO.reserve },
    }
end

local melta_sm_used = false

-- 0.4.0: a copy of a registered line effect; the name stays (fx extension sends NetworkLookup.line_effects[name] to
-- other peers, player_unit_fx_extension.lua:1215), the copy sits in the template so its particles load with the item
local function melta_line(name, no_sound)
    local LineEffects = require("scripts/settings/effects/line_effects")
    local base = LineEffects[name]

    if not base or not NetworkLookup.line_effects or not NetworkLookup.line_effects[name] then
        return nil
    end

    local copy = table.clone(base)

    copy.name = name

    if no_sound then
        copy.sfx = nil
    end

    return copy
end

local function build_moveset(clone, notes)
    local WeaponTweakTemplateSettings = require("scripts/settings/equipment/weapon_templates/weapon_tweak_template_settings")
    local template_types = WeaponTweakTemplateSettings.template_types

    register_handling_templates()

    for action_name, def in pairs(CHARGE_TEMPLATES) do
        if not swap_base(clone, template_types.charge, action_name, def.name) then
            notes[#notes + 1] = "no charge lookup for " .. action_name
        end
    end

    if not swap_base(clone, template_types.ammo, "base", AMMO_TEMPLATE) then
        clone.ammo_template = AMMO_TEMPLATE
    end

    for action_name, spec in pairs(ATTACKS) do
        local action = clone.actions[action_name]
        local fire = action and action.fire_configuration

        if fire and fire.hit_scan_template then
            local profile, err = make_profile(spec)

            if not profile then
                error(err)
            end

            tune_hit_scan(fire.hit_scan_template, spec, profile)
            fire.damage_type = IMPACT_DAMAGE_TYPE
            action.ammunition_usage_min = spec.ammo
            action.ammunition_usage_max = spec.ammo

            -- 0.3.0: flamer stream instead of the plasma bolt (spawned in the _play_line_fx hook below); the resource
            -- strings sit in the template so WeaponTemplateResourceDependencies.generate loads them with the item
            action.fx = action.fx or {}
            action.fx.muzzle_flash_effect = nil
            action.fx.is_charge_dependant = nil
            action.fx.line_effect = mod:get("orange_beam") and melta_line(BEAM_LINE, true) or nil
            action.fx.pre_shoot_sfx_alias = "ranged_pre_shoot"
            action.fx.qiangiq_flame = {
                name = FLAME.stream,
                name_3p = FLAME.stream_3p,
                impact = FLAME.impact,
                -- 0.10.0: no flamer roar (loop / loop_stop), the melta shot event is the shot sound
                speed = FLAME.speed,
                duration = spec.flame_time,
                range = spec.range,
                white = FLAME.white,
                liquid = FLAME.liquid,
                jet_speed = FLAME.jet_speed,
                trail_vfx = FLAME.trail_vfx,
                pellets = spec.pellets,
                spread = spec.spread,
            }
        else
            notes[#notes + 1] = "no hit scan in " .. action_name
        end
    end

    -- slower follow-up than the plasma gun's 0.45 s: the melta needs to spool again
    local shoot = clone.actions.action_shoot
    local chain = shoot and shoot.allowed_chain_actions and shoot.allowed_chain_actions.shoot_charge

    if chain then
        chain.chain_time = 0.6
    end

    -- muzzle effects at the barrel tip: the melta barrel's fx_muzzle sits at its root, fx_barrel_01 at the tip
    clone.fx_sources = table.clone(clone.fx_sources or {})
    clone.fx_sources._muzzle = "fx_barrel_01"

    local overheat = clone.overheat_configuration

    if overheat then
        overheat.vent_duration = 2.5
    end

    clone.keywords = { "ranged", "plasma_rifle", "p1" }


    if not mod:get("plasma_animations") then
        local ok, exists = pcall(Application.can_get_resource, "package", MELTA_SM_1P)

        if ok and exists then
            -- 0.2.2: player_unit_animation_state.lua:112 indexes PlayerUnitAnimationStateMachineSettings by the state
            -- machine path (CTD "state_machine_settings (a nil value)" without it); the melta set is not listed in
            -- state_machine_ranged_first_person.lua, so it gets the plasma_rifle entry (blend_time = 0).
            local SMSettings = require("scripts/settings/animation/player_unit_animation_state_machine_settings")

            if not SMSettings[MELTA_SM_1P] then
                SMSettings[MELTA_SM_1P] = table.clone(SMSettings["content/characters/player/human/first_person/animations/plasma_rifle"] or { blend_time = 0 })
            end

            clone.anim_state_machine_1p = MELTA_SM_1P
            melta_sm_used = true

            -- 0.3.0: melta unload clip (state "reload_start"), see the header
            local reload = table.clone(clone.reload_template)

            reload.name = "qiangiq_meltagun"
            reload.lift_weapon.anim_1p = "reload_start"
            reload.lift_weapon.anim_3p = "reload"
            clone.reload_template = reload

            -- 0.6.0: fire / brace / vent straight after the refill (6.7 s) instead of waiting out total_time 9.4
            local reload_action = clone.actions.action_reload

            if reload_action then
                reload_action.allowed_chain_actions = reload_action.allowed_chain_actions or {}
                reload_action.allowed_chain_actions.shoot_charge = { action_name = "action_charge_direct", chain_time = 6.8 }
                reload_action.allowed_chain_actions.brace = { action_name = "action_charge", chain_time = 6.8 }
                reload_action.allowed_chain_actions.vent = { action_name = "action_vent", chain_time = 6.8 }
            end
            notes[#notes + 1] = "melta first-person animations"
        else
            notes[#notes + 1] = "melta first-person animation package not found, plasma animations kept"
        end
    end
end

-- State -------------------------------------------------------------------------------------------------------------
local st = { template_ok = false, item_ok = false, notes = {} }
local next_poll = 0

local function ensure_template()
    local existing = rawget(WeaponTemplates, TEMPLATE)

    if existing then
        st.template_ok = true
        st.official_template = not st.template_ours

        return true
    end

    local source = WeaponTemplates[SOURCE_TEMPLATE]

    if not source then
        return false
    end

    local clone = table.clone(source)

    clone.name = TEMPLATE

    -- weapon_templates.lua _require_template: action_settings.name = action_name
    for action_name, action_settings in pairs(clone.actions) do
        action_settings.name = action_name
    end

    st.template_notes = {}
    build_moveset(clone, st.template_notes)

    WeaponTemplates[TEMPLATE] = clone
    st.template_ours = true

    local ok, index = append_lookup("weapon_templates", TEMPLATE)

    st.template_id = ok and index or nil
    st.aliases = copy_aliases(SOURCE_TEMPLATE, TEMPLATE)
    set_sound_aliases()
    st.template_ok = ok

    return ok
end

-- Items -------------------------------------------------------------------------------------------------------------
local function part_of(item)
    local base_unit = type(item) == "table" and item.base_unit

    if type(base_unit) ~= "string" then
        return nil
    end

    return base_unit:match("/attachments/([%a_]+)_%a*%d+/")
end

local function find_item(cache, preferred, template)
    local direct = rawget(cache, preferred)

    if direct and direct.weapon_template == template then
        return preferred, direct
    end

    for name, item in pairs(cache) do
        if type(item) == "table" and item.weapon_template == template then
            return name, item
        end
    end
end

local function only_base_unit(item, unit)
    for key in pairs(item) do
        if type(key) == "string" and key ~= "base_unit" and key:find("^base_unit") then
            item[key] = nil
        end
    end

    item.base_unit = unit
end

local function attachment_name(part)
    return ITEM_ROOT .. "qiangiq_melta/meltagun_" .. part .. "_01"
end

local function make_attachment(cache, part, template_item)
    local name = attachment_name(part)
    local def = PARTS[part]
    local item = table.clone(template_item)

    only_base_unit(item, def.unit)
    item.name = name
    item.resource_dependencies = { [def.unit] = true }
    item.attachments = nil
    item.material_overrides = nil
    item.material_override_items = nil

    if def.attach_node then
        item.attach_node = def.attach_node
    end

    cache[name] = item

    return name
end

local function rebuild_tree(cache, tree, placed, reachable, notes)
    for slot_name, node in pairs(tree) do
        if type(node) == "table" then
            local item_name = node.item
            local keep_children_reachable = reachable

            if type(item_name) == "string" and item_name ~= "" then
                local source_part_item = rawget(cache, item_name)
                local part = part_of(source_part_item)

                if part and PARTS[part] and reachable and not placed[part] then
                    node.item = make_attachment(cache, part, source_part_item)
                    placed[part] = { node = node, template_item = source_part_item, parent = tree, slot = slot_name }
                    notes[#notes + 1] = string.format("%s <- %s", part, item_name)
                else
                    node.item = ""
                    keep_children_reachable = false
                end
            end

            if type(node.children) == "table" then
                rebuild_tree(cache, node.children, placed, keep_children_reachable, notes)
            end
        end
    end
end

local function dump_tree(tree, prefix, out)
    for slot_name, node in pairs(tree) do
        if type(node) == "table" then
            local path = prefix .. slot_name

            out[#out + 1] = string.format("%s=%s%s%s", path, tostring(node.item),
                node.leaf_attach_node_override and (" leaf:" .. tostring(node.leaf_attach_node_override)) or "",
                node.link_map_mode_override and (" map:" .. tostring(node.link_map_mode_override)) or "")

            if type(node.children) == "table" then
                dump_tree(node.children, path .. "/", out)
            end
        end
    end

    return out
end

local function build_item(cache)
    local source_name, source_item = find_item(cache, SOURCE_ITEM, SOURCE_TEMPLATE)

    if not source_item then
        return false
    end

    local item = table.clone(source_item)
    local notes = {}
    local placed = {}

    item.name = ITEM
    item.weapon_template = TEMPLATE
    item.archetypes = { "zealot", "veteran" }

    local deps = item.resource_dependencies or {}

    if item.base_unit then
        deps[item.base_unit] = nil
    end

    only_base_unit(item, RIG)
    deps[RIG] = true
    item.resource_dependencies = deps
    item.display_name = DISPLAY

    for _, field in ipairs({ "weapon_family_display_name", "weapon_pattern_display_name", "weapon_mark_display_name" }) do
        if type(item[field]) == "table" then
            item[field].loc_id = DISPLAY
        end
    end

    -- bottom-right weapon HUD: item.hud_icon (the plasma template has no hud_icon of its own)
    local ok_icon, icon_package = pcall(Application.can_get_resource, "package", HUD_ICON)

    if ok_icon and icon_package then
        if type(item.hud_icon) == "string" then
            deps[item.hud_icon] = nil
        end

        item.hud_icon = HUD_ICON
        deps[HUD_ICON] = true
        notes[#notes + 1] = "melta hud icon"
    else
        notes[#notes + 1] = "melta hud icon package not found"
    end

    if type(item.attachments) ~= "table" then
        return false, "source item has no attachments"
    end

    mod:info("source tree of %s: %s", tostring(source_name), table.concat(dump_tree(item.attachments, "", {}), "; "))
    rebuild_tree(cache, item.attachments, placed, true, notes)

    local receiver = placed.receiver

    if not receiver then
        return false, "no receiver slot in " .. tostring(source_name)
    end

    -- Static receiver only with the plasma animations: they drive the rig's nodes to plasma positions
    -- (QIangIQsDauntlessArmory 0.2.0). The melta state machine is made for this rig, so then the parts follow it.
    if not melta_sm_used then
        receiver.node.link_map_mode_override = "LINK_MODE_NONE"
    end

    receiver.node.children = receiver.node.children or {}

    local receiver_children = receiver.node.children

    for _, part in ipairs(PART_ORDER) do
        local p = placed[part]

        if p and part ~= "receiver" then
            p.node.leaf_attach_node_override = nil
            p.node.link_map_mode_override = nil

            if p.parent ~= receiver_children then
                local slot = rawget(receiver_children, p.slot) == nil and p.slot or ("qiangiq_" .. part)

                p.parent[p.slot] = { item = "", children = {} }
                receiver_children[slot] = p.node
                notes[#notes + 1] = string.format("%s moved under the receiver", part)
            end
        end
    end

    for _, part in ipairs(PART_ORDER) do
        if not placed[part] then
            receiver_children["qiangiq_" .. part] = {
                item = make_attachment(cache, part, receiver.template_item),
                children = {},
            }
            notes[#notes + 1] = string.format("%s added under the receiver (%s)", part, PARTS[part].attach_node)
        end
    end

    -- the offline item compile's template resources (item_package.lua:239-249): state machines, sounds, effects
    local WeaponTemplateResourceDependencies = require("scripts/utilities/weapon_template_resource_dependencies")

    for _, resource in ipairs(WeaponTemplateResourceDependencies.generate(TEMPLATE)) do
        deps[resource] = true
    end

    -- 0.3.2: the aliased sounds and particles (set_sound_aliases) are not in the cloned plasma item's compiled
    -- dependencies. Only names the resource manager knows go in: 0.3.1 crashed with "Package reference
    -- 'wwise/events/weapon/%s_forcestaff_warp_fire_charge_loop' does not exist" (package_manager.lua:108) because a
    -- %s alias pattern reached the item through the template.
    local extra = {
        PARTICLES.charge, PARTICLES.clip_out, SOUNDS.pre_shoot, SOUNDS.warn_high, SOUNDS.warn_critical,
        SOUNDS.about_to_explode,
    }

    -- 0.10.0: melta events with their _husk versions (other players hear those)
    for _, event in ipairs({ SOUNDS.shot, SOUNDS.shot_charged, SOUNDS.equip, SOUNDS.reload_out, SOUNDS.reload_grab,
        SOUNDS.reload_in, SOUNDS.hit_armored, SOUNDS.hit_unarmored }) do
        extra[#extra + 1] = event
        extra[#extra + 1] = event .. "_husk"
    end

    for _, pattern in ipairs({ SOUNDS.charge, SOUNDS.charge_fast }) do
        for _, verb in ipairs({ "play", "stop" }) do
            extra[#extra + 1] = (pattern:gsub("%%s", verb))
            extra[#extra + 1] = (pattern:gsub("%%s", verb)) .. "_husk"
        end
    end

    for _, pattern in ipairs({ SOUNDS.vent, SOUNDS.heat_loop, SOUNDS.heat_loop_critical }) do
        extra[#extra + 1] = (pattern:gsub("%%s", "play"))
        extra[#extra + 1] = (pattern:gsub("%%s", "stop"))
    end

    for _, resource in ipairs(extra) do
        local ok_res, exists = pcall(Application.can_get_resource, "package", resource)

        if ok_res and exists then
            deps[resource] = true
        else
            notes[#notes + 1] = "no package " .. resource
        end
    end

    local ok, index = append_lookup("player_item_names", ITEM)

    if not ok then
        return false
    end

    cache[ITEM] = item
    st.item_id = index
    st.source_item_name = source_name
    st.slot = item.slots and item.slots[1]
    st.notes = notes

    return true
end

local function ensure_item()
    local ok, has_data = pcall(MasterItems.has_data)

    if not ok or not has_data then
        return false
    end

    local cache = MasterItems.get_cached()

    if rawget(cache, ITEM) then
        st.item_ok = true

        return true
    end

    local built, err = build_item(cache)

    if err and err ~= st.last_error then
        st.last_error = err
        mod:error("%s", err)
    end

    st.item_ok = built and rawget(cache, ITEM) ~= nil

    return st.item_ok
end

-- Unlock lists (weapon_unlock_settings.lua WeaponUnlockSettings[archetype][level]; realms_loadout reads them)
local function add_to_unlock_lists()
    local ok, unlocks = pcall(require, "scripts/settings/weapon_unlock/weapon_unlock_settings")

    if not ok or not unlocks then
        mod:error("WeaponUnlockSettings not found")

        return
    end

    local level = math.floor(mod:get("unlock_level") or 1)

    for archetype, setting in pairs({ zealot = "unlock_zealot", veteran = "unlock_veteran" }) do
        local list = unlocks[archetype]

        if mod:get(setting) and list then
            list[level] = list[level] or {}

            if not table.find(list[level], ITEM) then
                table.insert(list[level], ITEM)
            end
        end
    end
end

local function poll()
    if next_poll > os.clock() then
        return
    end

    next_poll = os.clock() + 1

    local before_t, before_i = st.template_ok, st.item_ok
    local ok_t, err_t = pcall(ensure_template)
    local ok_i, err_i = true, nil

    if st.template_ok then
        ok_i, err_i = pcall(ensure_item)
    end

    if not ok_t then
        mod:error("template: %s", tostring(err_t))
    end

    if not ok_i then
        mod:error("item: %s", tostring(err_i))
    end

    if st.template_ok and not before_t then
        if st.official_template then
            mod:info("the game now has its own %s template; using it", TEMPLATE)
        else
            mod:info("template %s registered (clone of %s), %s alias entries; %s", TEMPLATE, SOURCE_TEMPLATE,
                tostring(st.aliases), table.concat(st.template_notes or {}, "; "))
        end
    end

    if st.item_ok and not before_i then
        mod:info("item %s injected (clone of %s, slot %s): %s", ITEM, tostring(st.source_item_name), tostring(st.slot),
            table.concat(st.notes or {}, "; "))
    end
end

-- Anim event guard, only with the experimental melta first-person set (QIangIQsDauntlessArmory guard: events the
-- state machine lacks are skipped, Unit.has_animation_event as player_character_state_ledge_vaulting.lua:109 does).
-- 0.2.1: also on AuthoritativePlayerUnitAnimationExtension, which plays the events when you host (Psykhanium, SoloPlay)
-- and has no _local_wielded_weapon_template, so the wielded template name is stored from inventory_slot_wielded
-- (authoritative_player_unit_animation_extension.lua:210, player_unit_animation_extension.lua:118). Only the 1p
-- events need it: the 3p state machine stays the Plasma Gun's.
local skipped_events = {}
local ANIM_CLASSES = { "PlayerUnitAnimationExtension", "AuthoritativePlayerUnitAnimationExtension" }

local function guard(unit_field)
    return function(func, self, event_name, ...)
        if melta_sm_used and (self.__qiangiq_melta_wielded or self._local_wielded_weapon_template) == TEMPLATE then
            local unit = self[unit_field]

            if unit and not Unit.has_animation_event(unit, event_name) then
                if not skipped_events[event_name] then
                    skipped_events[event_name] = true
                    mod:info("skipped anim event %s (%s): not in the melta state machine", tostring(event_name),
                        unit_field == "_first_person_unit" and "1p" or "3p")
                end

                return
            end
        end

        return func(self, event_name, ...)
    end
end

for _, class_name in ipairs(ANIM_CLASSES) do
    mod:hook_safe(CLASS[class_name], "inventory_slot_wielded", function(self, weapon_template)
        self.__qiangiq_melta_wielded = weapon_template and weapon_template.name or false
    end)

    for _, method in ipairs({ "anim_event_1p", "anim_event_with_variable_float_1p", "anim_event_with_variable_floats_1p" }) do
        mod:hook(CLASS[class_name], method, guard("_first_person_unit"))
    end
end

-- Flask follows the left hand on reloads -------------------------------------------------------------------------
-- The receiver is static (LINK_MODE_NONE), so the plasma reload's rig ap_magazine_01 motion is copied onto the
-- receiver's ap_magazine_01 relative to its idle pose (QIangIQsDauntlessArmory 0.4.2 follow_hand). The grip offset is
-- zero: plasma and melta rigs both hold ap_trigger_01 at the origin and the melta grip's trigger lands on it.
local tracked = {}

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function receiver_unit(names)
    local want = attachment_name("receiver")

    if names then
        for unit, item_name in pairs(names) do
            if item_name == want and unit_ok(unit) then
                return unit
            end
        end
    end
end

local function mag_record(records, unit)
    local rec = records[unit]

    if rec then
        return rec
    end

    if not Unit.has_node(unit, "ap_magazine_01") then
        return nil
    end

    local index = Unit.node(unit, "ap_magazine_01")
    local q = Unit.local_position(unit, index)

    rec = { index = index, pos = { q[1], q[2], q[3] }, rot = QuaternionBox(Unit.local_rotation(unit, index)) }
    records[unit] = rec

    return rec
end

local function follow_hand(rec, unit, rig, reloading)
    if not (unit_ok(rig) and Unit.has_node(rig, "ap_magazine_01")) then
        return
    end

    local index = Unit.node(rig, "ap_magazine_01")
    local p = Unit.local_position(rig, index)
    local q = Unit.local_rotation(rig, index)

    if not reloading or not rec.hand_rest then
        rec.hand_rest = { pos = { p[1], p[2], p[3] }, rot = QuaternionBox(q) }
        Unit.set_local_position(unit, rec.index, Vector3(rec.pos[1], rec.pos[2], rec.pos[3]))
        Unit.set_local_rotation(unit, rec.index, rec.rot:unbox())

        return
    end

    local rest = rec.hand_rest
    local delta_rot = Quaternion.multiply(q, Quaternion.inverse(rest.rot:unbox()))
    local idle = Vector3(rec.pos[1] - rest.pos[1], rec.pos[2] - rest.pos[2], rec.pos[3] - rest.pos[3])
    local moved = p + Quaternion.rotate(delta_rot, idle)

    Unit.set_local_position(unit, rec.index, moved)
    Unit.set_local_rotation(unit, rec.index, Quaternion.multiply(delta_rot, rec.rot:unbox()))
end

local function reloading(ext)
    local ok, weapon_action = pcall(function()
        local ude = ScriptUnit.has_extension(ext._unit, "unit_data_system")

        return ude and ude:read_component("weapon_action")
    end)

    return ok and weapon_action and weapon_action.template_name == TEMPLATE and weapon_action.current_action_name == "action_reload"
end

-- 0.9.2: pin the switch / flask nodes during inspect (see the header)
local INSPECT_NODES = { "ap_release_01", "ap_release_02", "ap_magazine_01" }
local pinned = {}
local inspect_logged = false

local function inspecting(ext)
    local ok, weapon_action = pcall(function()
        local ude = ScriptUnit.has_extension(ext._unit, "unit_data_system")

        return ude and ude:read_component("weapon_action")
    end)

    return ok and weapon_action and weapon_action.template_name == TEMPLATE and weapon_action.current_action_name == "action_inspect"
end

-- outside inspect: remember each node's local pose; during inspect: mark the unit so the callback restores it
local function track_inspect_nodes(unit, active)
    if not unit_ok(unit) then
        return
    end

    local rec = pinned[unit]

    if not rec then
        rec = { nodes = {} }

        for _, name in ipairs(INSPECT_NODES) do
            if Unit.has_node(unit, name) then
                local index = Unit.node(unit, name)

                rec.nodes[#rec.nodes + 1] = {
                    index = index,
                    pos = Vector3Box(Unit.local_position(unit, index)),
                    rot = QuaternionBox(Unit.local_rotation(unit, index)),
                }
            end
        end

        pinned[unit] = rec
    end

    if active and rec.captured then
        rec.active = true

        return
    end

    rec.active = false

    for _, node in ipairs(rec.nodes) do
        node.pos:store(Unit.local_position(unit, node.index))
        node.rot:store(Unit.local_rotation(unit, node.index))
    end

    rec.captured = #rec.nodes > 0
end

local function pin_inspect_nodes()
    for unit, rec in pairs(pinned) do
        if not unit_ok(unit) then
            pinned[unit] = nil
        elseif rec.active then
            for _, node in ipairs(rec.nodes) do
                Unit.set_local_position(unit, node.index, node.pos:unbox())
                Unit.set_local_rotation(unit, node.index, node.rot:unbox())
            end

            if not inspect_logged then
                inspect_logged = true
                mod:info("inspect: pinned %d nodes", #rec.nodes)
            end
        end
    end
end

local function any_pinned()
    for _, rec in pairs(pinned) do
        if rec.active then
            return true
        end
    end

    return false
end

local ScriptWorld = require("scripts/foundation/utilities/script_world")

mod:hook(ScriptWorld, "update", function(func, world, dt, anim_callback, scene_callback)
    if not any_pinned() then
        return func(world, dt, anim_callback, scene_callback)
    end

    return func(world, dt, function(...)
        pcall(pin_inspect_nodes)

        if anim_callback then
            return anim_callback(...)
        end
    end, scene_callback)
end)

-- 0.5.0 barrel glow: material scalars of BarrelOverheat ("overheat", barrel_overheat.lua) and PlasmaCoil
-- ("external_overheat_glow", plasma_coil.lua), set on every melta attachment from the slot's overheat
local GLOW_VARIABLES = { "overheat", "external_overheat_glow" }
local GLOW_FULL_AT = 0.8
local heat_samples, heat_frames = 6, 0

local function set_glow(slot, value)
    for _, view in ipairs({ { slot.unit_1p, slot.attachments_by_unit_1p }, { slot.unit_3p, slot.attachments_by_unit_3p } }) do
        local list = view[1] and view[2] and view[2][view[1]]

        if list then
            for i = 1, #list do
                local unit = list[i]

                if unit_ok(unit) then
                    for _, variable in ipairs(GLOW_VARIABLES) do
                        pcall(Unit.set_scalar_for_materials, unit, variable, value, true)
                    end
                end
            end
        end
    end
end

local function update_glow(ext, slot)
    local ok, component = pcall(function()
        local ude = ScriptUnit.has_extension(ext._unit, "unit_data_system")

        return ude and ude:read_component(slot.name)
    end)
    local heat = ok and component and component.overheat_current_percentage or 0
    local value = math.min(heat / GLOW_FULL_AT, 1)

    -- 0.6.0: every frame; WeaponTemperatureEffects writes the same material scalar each frame before this hook
    set_glow(slot, value)

    -- what PerilGauge / the overcharge HUD read (read_component(slot).overheat_current_percentage), once a second
    heat_frames = heat_frames + 1

    if heat_samples > 0 and heat > 0 and heat_frames >= 60 then
        heat_samples = heat_samples - 1
        heat_frames = 0
        mod:info("melta fx: hud heat %s in %s (state %s), glow %.2f", tostring(heat), tostring(slot.name),
            tostring(component.overheat_state), value)
    end
end

local function apply(ext)
    if not ext._is_local_unit or not ext._equipment then
        return
    end

    local records = ext.__qiangiq_melta_mags

    if not records then
        records = {}
        ext.__qiangiq_melta_mags = records
    end

    for unit in pairs(records) do
        if not unit_ok(unit) then
            records[unit] = nil
        end
    end

    for _, slot in pairs(ext._equipment) do
        local item = slot.item

        if item and item.name == ITEM then
            update_glow(ext, slot)
        end

        if item and item.name == ITEM and melta_sm_used then
            local active = inspecting(ext)

            track_inspect_nodes(ext._first_person_unit, active)
            track_inspect_nodes(slot.unit_1p, active)
        end

        if item and item.name == ITEM and not melta_sm_used then
            local is_reloading = reloading(ext)

            for _, view in ipairs({ { slot.item_name_by_unit_3p, slot.unit_3p }, { slot.item_name_by_unit_1p, slot.unit_1p } }) do
                local unit = receiver_unit(view[1])
                local rec = unit and mag_record(records, unit)

                if rec then
                    follow_hand(rec, unit, view[2], is_reloading)
                end
            end
        end
    end
end

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "_update_item_visibility", function(self)
    if self._is_local_unit then
        tracked[self] = true
        apply(self)
    end
end)

mod:hook_safe(CLASS.PlayerUnitVisualLoadoutExtension, "update", function(self)
    if tracked[self] then
        apply(self)
    end
end)

mod:hook(CLASS.PlayerUnitVisualLoadoutExtension, "destroy", function(func, self, ...)
    tracked[self] = nil

    return func(self, ...)
end)

-- Melta shot: flamer burst stream from the muzzle to the hit point (flamer_gas_effects.lua _update_effects shape),
-- spawned where ActionShootHitScan plays its line effect (action_shoot_hit_scan.lua:227 -> action_shoot.lua:1105)
local flames = {}
local flame_clock = 0

-- 0.4.0: first shots log what ran ("melta fx" in the console log) so a missing effect can be traced
local diag_left = 8

local function diag(fmt, ...)
    if diag_left > 0 then
        diag_left = diag_left - 1
        mod:info("melta fx: " .. fmt, ...)
    end
end

-- 0.10.0: melta hit sounds on unit hits (see the header). The parsed impact fx is copied once per (fx, armour) with
-- its sfx / sfx_husk lists swapped, so name, vfx, decals and the 1p weakspot indicator stay as they were.
local Armor = require("scripts/utilities/attack/armor")
local ARMORED = { armored = true, super_armor = true }
local melta_impacts = {}

local function wields_melta(unit)
    local ude = ScriptUnit.has_extension(unit, "unit_data_system")
    local visual_loadout = ScriptUnit.has_extension(unit, "visual_loadout_system")
    local inventory = ude and ude:read_component("inventory")
    local slot = inventory and inventory.wielded_slot
    local template = slot and visual_loadout and visual_loadout.weapon_template_from_slot
        and visual_loadout:weapon_template_from_slot(slot)

    return template ~= nil and template.name == TEMPLATE
end

local function melta_impact(impact_fx, target_unit)
    local armored = false

    if target_unit then
        local ude = ScriptUnit.has_extension(target_unit, "unit_data_system")
        local breed = ude and ude:breed()
        local ok, armor = pcall(Armor.armor_type, target_unit, breed)

        armored = ok and ARMORED[armor] == true
    end

    local by_armor = melta_impacts[impact_fx]

    if not by_armor then
        by_armor = {}
        melta_impacts[impact_fx] = by_armor
    end

    local copy = by_armor[armored]

    if not copy then
        local event = armored and SOUNDS.hit_armored or SOUNDS.hit_unarmored

        copy = {}

        for key, value in pairs(impact_fx) do
            copy[key] = value
        end

        copy.sfx = { event }
        copy.sfx_husk = { event .. "_husk" }
        by_armor[armored] = copy
    end

    return copy
end

mod:hook(CLASS.FxSystem, "play_impact_fx", function(func, self, impact_fx, hit_position, attack_direction,
    source_parameters, attacking_unit, optional_target_unit, ...)
    if impact_fx and impact_fx.sfx and attacking_unit then
        local ok, melta = pcall(wields_melta, attacking_unit)

        if ok and melta then
            impact_fx = melta_impact(impact_fx, optional_target_unit)
        end
    end

    return func(self, impact_fx, hit_position, attack_direction, source_parameters, attacking_unit,
        optional_target_unit, ...)
end)

local function stop_flame(entry)
    if entry.world and entry.id then
        pcall(World.stop_spawning_particles, entry.world, entry.id)
    end

    if entry.source then
        pcall(WwiseWorld.trigger_resource_event, entry.wwise_world, entry.loop_stop, entry.source)
        pcall(WwiseWorld.destroy_manual_source, entry.wwise_world, entry.source)
    end
end

local function spawn_flame(self, end_position)
    local fx = self._action_settings and self._action_settings.fx
    local flame = fx and fx.qiangiq_flame
    local world = self._world

    if not flame or not world or self._unit_data_extension.is_resimulating then
        return
    end

    local pose = self._fx_extension:vfx_spawner_pose(self:_muzzle_fx_source())
    local from_pos = Matrix4x4.translation(pose)
    local to_vector = end_position - from_pos
    local distance = Vector3.length(to_vector)

    if distance < 0.01 then
        return
    end

    local direction = Vector3.normalize(to_vector)
    local rotation = Quaternion.look(direction)
    local id

    -- 0.6.0: CustomFlames.lua stream handling: variable 1 = life (distance / speed), vomit yawed 75 degrees, custom fov
    local style = mod:get("jet") or "none"
    local names = {}

    if style == "white" or style == "both" then
        names[#names + 1] = flame.white
    end

    if style == "vomit" or style == "both" then
        names[#names + 1] = flame.liquid
    end

    local first_person = self._first_person_extension and self._first_person_extension:is_in_first_person_mode()
    local life = distance / (flame.jet_speed or 50)

    for i, name in ipairs(names) do
        local particle_rotation = rotation

        if name == flame.liquid then
            local euler = Vector3(Quaternion.to_euler_angles_xyz(rotation))

            euler[3] = euler[3] + 75

            if euler[3] >= 180 then
                euler[3] = euler[3] - 360
            end

            particle_rotation = Quaternion.from_euler_angles_xyz(euler[1], euler[2], euler[3])
        end

        local particle_id = World.create_particles(world, name, from_pos, particle_rotation)

        if first_person then
            World.set_particles_use_custom_fov(world, particle_id, true)
        end

        World.set_particles_variable(world, particle_id, 1, Vector3(life, life, life))

        if i == 1 then
            id = particle_id
        else
            flames[#flames + 1] = { world = world, id = particle_id, stop_t = flame_clock + flame.duration }
        end
    end

    diag("jet %s (%d particles), life %.2f", style, #names, life)

    local entry = { world = world, id = id, stop_t = flame_clock + flame.duration, loop_stop = flame.loop_stop }
    local wwise_world = self._wwise_world

    if wwise_world and flame.loop then
        local sound_pos = from_pos + direction * math.clamp(distance - 0.1, 0, 4)

        entry.wwise_world = wwise_world
        entry.source = WwiseWorld.make_manual_source(wwise_world, sound_pos, rotation)
        WwiseWorld.trigger_resource_event(wwise_world, flame.loop, entry.source)
    end

    flames[#flames + 1] = entry

    if flame.impact and distance < flame.range - 0.05 then
        World.create_particles(world, flame.impact, end_position, Quaternion.look(-direction))
    end
end

-- second line (burning trail) through the fx system, the way ActionShoot._play_line_fx spawns one (action_shoot.lua:1105)
local function spawn_trail(self, trail, position, end_position, optional_attachment_id)
    local oob = Managers.state.out_of_bounds

    if oob then
        end_position = oob:limit_line_end_position_to_soft_cap_extents(position, end_position)
    end

    local link = true

    if trail.link ~= nil then
        link = trail.link
    end

    self._fx_extension:spawn_unit_fx_line(trail, self._critical_strike_component.is_active, self:_muzzle_fx_source(),
        end_position, link, "stop", nil, true, optional_attachment_id)
end

-- 0.7.0: white-hot trail per pellet, laid out like PlayerUnitFxExtension._spawn_unit_fx_line (player_unit_fx_extension.lua:
-- particles at the muzzle looking down the line, "hit_distance" = width, length, length) and tinted through the lasgun
-- beam's "beam" cloud / "beam_color" vector (Polychromatic guns/data/direct_effects.lua + engines/live_tint.lua)
local function spawn_beam_trail(self, flame, end_position)
    local world = self._world

    if not world or self._unit_data_extension.is_resimulating then
        return
    end

    local pose = self._fx_extension:vfx_spawner_pose(self:_muzzle_fx_source())
    local from_pos = Matrix4x4.translation(pose)
    local line = end_position - from_pos
    local length = Vector3.length(line)

    if length < 0.05 then
        return
    end

    local name = flame.trail_vfx
    local id = World.create_particles(world, name, from_pos, Quaternion.look(Vector3.normalize(line)))

    if self._first_person_extension and self._first_person_extension:is_in_first_person_mode() then
        World.set_particles_use_custom_fov(world, id, true)
    end

    local variable = World.find_particles_variable(world, name, "hit_distance")

    if variable then
        World.set_particles_variable(world, id, variable, Vector3(FLAME.trail_width, length, length))
    end

    if World.has_particles_material(world, id, "beam") then
        local c = FLAME.trail_color
        local k = mod:get("trail_brightness") or 2

        World.set_particles_material_vector3(world, id, "beam", "beam_color", Vector3(c[1] * k, c[2] * k, c[3] * k))
    end

    flames[#flames + 1] = { world = world, id = id, stop_t = flame_clock + (flame.duration or 0.3) }
end

-- 0.7.0 cone: extra hit scans around the aimed one; rotation as utilities/spread.lua _combine_spread_rotations
local SHOT_RESULT_FLAGS = { "hit_minion", "hit_weakspot", "killing_blow" }

mod:hook("ActionShootHitScan", "_shoot", function(func, self, position, rotation, power_level, charge_level, t, fire_config, ...)
    local result = func(self, position, rotation, power_level, charge_level, t, fire_config, ...)
    local fx = self._action_settings and self._action_settings.fx
    local flame = fx and fx.qiangiq_flame
    local count = flame and flame.pellets or 1

    if count > 1 and not self.__qiangiq_pellet and rotation then
        local shot_result = self._shot_result
        local seen = {}

        for _, key in ipairs(SHOT_RESULT_FLAGS) do
            seen[key] = shot_result and shot_result[key]
        end

        local pitch = math.degrees_to_radians(flame.spread or 5)
        local ring = count - 1

        self.__qiangiq_pellet = true

        for i = 1, ring do
            local roll = (i - 1) / ring * math.pi * 2
            local pellet_rotation = Quaternion.multiply(Quaternion.multiply(rotation, Quaternion(Vector3.forward(), roll)),
                Quaternion(Vector3.right(), pitch))
            local ok, err = pcall(func, self, position, pellet_rotation, power_level, charge_level, t, fire_config, ...)

            if not ok then
                mod:error("melta pellet: %s", tostring(err))

                break
            end

            for _, key in ipairs(SHOT_RESULT_FLAGS) do
                seen[key] = seen[key] or (shot_result and shot_result[key])
            end
        end

        self.__qiangiq_pellet = nil

        if shot_result then
            for _, key in ipairs(SHOT_RESULT_FLAGS) do
                shot_result[key] = seen[key]
            end
        end
    end

    return result
end)

-- 0.3.3: hooked on ActionShootHitScan itself: class() (scripts/foundation/utilities/class.lua) copies the super's
-- functions into the subclass when it is created, so a hook on ActionShoot never reaches ActionShootHitScan
mod:hook("ActionShootHitScan", "_play_line_fx", function(func, self, line_effect, position, end_position, ...)
    local fx = self._action_settings and self._action_settings.fx
    local flame = fx and fx.qiangiq_flame

    if flame and end_position then
        diag("shot, line %s, pellet %s, distance %.1f", tostring(line_effect and line_effect.name),
            tostring(self.__qiangiq_pellet), position and Vector3.distance(position, end_position) or -1)

        if flame.trail_vfx then
            local ok, err = pcall(spawn_beam_trail, self, flame, end_position)

            if not ok then
                mod:error("melta trail: %s", tostring(err))
            end
        end

        -- the roar, impact and optional cloud jet once per shot, not per pellet
        if not self.__qiangiq_pellet then
            local ok, err = pcall(spawn_flame, self, end_position)

            if not ok then
                mod:error("flame stream: %s", tostring(err))
            end
        end
    end

    return func(self, line_effect, position, end_position, ...)
end)

-- 0.4.0 heat: ActionShoot._add_heat (action_shoot.lua:568) -> Overheat.increase_immediate; if the shot left the
-- heat unchanged, add the melta's own amount (lerp_basic of its charge template) so the overcharge HUD shows it
local HEAT_BY_ACTION = {}

for action_name, def in pairs(CHARGE_TEMPLATES) do
    local percent = def.template.overheat_percent

    HEAT_BY_ACTION[action_name] = {
        use_charge = def.template.use_charge,
        overheat_percent = type(percent) == "table" and percent.lerp_basic or percent,
    }
end

mod:hook("ActionShootHitScan", "_add_heat", function(func, self, dt, t, charge_level, ...)
    local fx = self._action_settings and self._action_settings.fx
    local slot = self._inventory_slot_component

    if not (fx and fx.qiangiq_flame and slot) then
        return func(self, dt, t, charge_level, ...)
    end

    local before = slot.overheat_current_percentage
    local result = func(self, dt, t, charge_level, ...)
    local after = slot.overheat_current_percentage
    local fallback = HEAT_BY_ACTION[self._action_settings.name]
    local state = slot.overheat_state

    diag("heat %s -> %s (state %s, charge template %s)", tostring(before), tostring(after), tostring(state),
        tostring(self._weapon_extension:charge_template() ~= nil))

    if after == before and fallback and fallback.overheat_percent and state ~= "lockout" and state ~= "soft_lockout"
        and state ~= "exploding" then
        local Overheat = require("scripts/utilities/overheat")
        local ok, err = pcall(Overheat.increase_immediate, t, charge_level or 1, slot, fallback, self._player_unit,
            self._critical_strike_component.is_active)

        if not ok then
            mod:error("melta heat: %s", tostring(err))
        end
    end

    return result
end)

local function update_flames(dt)
    flame_clock = flame_clock + (dt or 0)

    local now = flame_clock

    for i = #flames, 1, -1 do
        local entry = flames[i]

        if now >= entry.stop_t then
            stop_flame(entry)
            table.remove(flames, i)
        end
    end
end

mod.update = function(dt)
    poll()
    update_flames(dt)
end

mod.on_all_mods_loaded = function()
    add_to_unlock_lists()
end

mod.on_unload = function()
    for i = #flames, 1, -1 do
        stop_flame(flames[i])
        flames[i] = nil
    end

    local ok, cache = pcall(MasterItems.get_cached)

    if ok and cache then
        cache[ITEM] = nil

        for part in pairs(PARTS) do
            cache[attachment_name(part)] = nil
        end
    end

    if st.template_ours then
        WeaponTemplates[TEMPLATE] = nil
    end
end

-- Equip without the backend (QIangIQsShardStaff override): only where this client hosts ----------------------------
local function local_player()
    local players = Managers.player

    return players and players:local_player_safe(1)
end

local function equipped_item_name(player, slot)
    local unit = player and player.player_unit

    if not unit or not Unit.alive(unit) then
        return nil
    end

    local extension = ScriptUnit.has_extension(unit, "visual_loadout_system")
    local item = extension and extension:item_from_slot(slot)

    return item and item.name
end

local previous = {}

local function override(slot, item_name)
    local player = local_player()
    local sync = Managers.profile_synchronization
    local host = sync and sync:synchronizer_host()

    if not player then
        say("no local player")

        return false
    end

    if not host then
        say("not the host here. Use the Psykhanium, a SoloPlay game or a game you host")

        return false
    end

    host:override_slot(player:peer_id(), player:local_player_id(), slot, item_name)
    say("override_slot(%s, %s) sent", slot, tostring(item_name))

    return true
end

local function package_state(path)
    local ok, exists = pcall(Application.can_get_resource, "package", path)

    return ok and tostring(exists) or "?"
end

local function status()
    say("meltagun: template %s (id %s, from %s), item %s (id %s, slot %s)", tostring(st.template_ok),
        tostring(st.template_id), SOURCE_TEMPLATE, tostring(st.item_ok), tostring(st.item_id), tostring(st.slot))

    for _, part in ipairs(PART_ORDER) do
        say("  %s package found: %s", part, package_state(PARTS[part].unit))
    end

    say("  rig %s package found: %s", RIG, package_state(RIG))
    say("  melta 1p animation package found: %s (in use: %s), hud icon package found: %s", package_state(MELTA_SM_1P),
        tostring(melta_sm_used), package_state(HUD_ICON))

    local player = Managers.player and Managers.player:local_player_safe(1)
    local unit = player and player.player_unit

    if unit and Unit.alive(unit) then
        local unit_data = ScriptUnit.has_extension(unit, "unit_data_system")
        local ok, slot = pcall(function()
            return unit_data:read_component("slot_secondary")
        end)

        if ok and slot then
            say("  heat %.0f%% (%s)", (slot.overheat_current_percentage or 0) * 100, tostring(slot.overheat_state))
        end
    end

    for _, list in ipairs({ st.template_notes, st.notes }) do
        if list and #list > 0 then
            say("  %s", table.concat(list, "; "))
        end
    end
end

-- 0.10.0: "/melta sound <name>" plays wwise/events/weapon/<name> at the player, to hear each melta event in game
local function test_sound(name)
    if not name then
        say("usage: /melta sound play_meltagun_p1_fire_single_shot (any wwise/events/weapon/ event)")

        return
    end

    local event = name:find("/") and name or ("wwise/events/weapon/" .. name)
    local player = local_player()
    local unit = player and player.player_unit
    local ok_res, exists = pcall(Application.can_get_resource, "package", event)

    if not (ok_res and exists) then
        say("%s: not in the game files", event)

        return
    end

    local world = Managers.world:world("level_world")
    local wwise_world = world and Managers.world:wwise_world(world)

    if not (wwise_world and unit) then
        say("no world or player unit")

        return
    end

    -- 0.10.2: a bare position gave "WwisePlugin: Bad Game Source parameter"; the unit is a valid auto source
    local source = WwiseWorld.make_auto_source(wwise_world, unit)
    local id = WwiseWorld.trigger_resource_event(wwise_world, event, source)

    say("%s -> playing id %s", event, tostring(id))
end

mod:command("melta", mod:localize("command_melta"), function(action, name)
    action = action or "status"

    if action == "status" then
        status()
    elseif action == "equip" then
        if not (st.template_ok and st.item_ok and st.slot) then
            say("meltagun not ready yet (template %s, item %s)", tostring(st.template_ok), tostring(st.item_ok))

            return
        end

        local player = local_player()

        previous[st.slot] = previous[st.slot] or (player and equipped_item_name(player, st.slot))
        override(st.slot, ITEM)
    elseif action == "restore" then
        local any = false

        for slot, item_name in pairs(previous) do
            if item_name and override(slot, item_name) then
                previous[slot] = nil
                any = true
            end
        end

        if not any then
            say("nothing to restore (equip first)")
        end
    elseif action == "sound" then
        test_sound(name)
    else
        say("usage: /melta [status|equip|restore|sound <event>]")
    end
end)
