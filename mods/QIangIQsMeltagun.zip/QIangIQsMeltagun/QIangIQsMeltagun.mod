return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsMeltagun` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsMeltagun", {
            mod_script = "QIangIQsMeltagun/scripts/mods/QIangIQsMeltagun/QIangIQsMeltagun",
            mod_data = "QIangIQsMeltagun/scripts/mods/QIangIQsMeltagun/QIangIQsMeltagun_data",
            mod_localization = "QIangIQsMeltagun/scripts/mods/QIangIQsMeltagun/QIangIQsMeltagun_localization",
        })
    end,
    version = "0.10.3",
    author = "QIangIQ",
    packages = {},
}
