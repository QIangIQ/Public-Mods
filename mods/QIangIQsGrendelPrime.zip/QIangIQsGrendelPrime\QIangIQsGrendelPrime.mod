return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsGrendelPrime` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsGrendelPrime", {
            mod_script = "QIangIQsGrendelPrime/scripts/mods/QIangIQsGrendelPrime/QIangIQsGrendelPrime",
            mod_data = "QIangIQsGrendelPrime/scripts/mods/QIangIQsGrendelPrime/QIangIQsGrendelPrime_data",
            mod_localization = "QIangIQsGrendelPrime/scripts/mods/QIangIQsGrendelPrime/QIangIQsGrendelPrime_localization",
        })
    end,
    version = "1.1.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
