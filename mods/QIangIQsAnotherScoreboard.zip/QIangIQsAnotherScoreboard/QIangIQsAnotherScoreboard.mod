return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`QIangIQsAnotherScoreboard` failed loading DMF.")
		new_mod("QIangIQsAnotherScoreboard", {
			mod_script       = "QIangIQsAnotherScoreboard/scripts/mods/QIangIQsAnotherScoreboard/QIangIQsAnotherScoreboard",
			mod_data         = "QIangIQsAnotherScoreboard/scripts/mods/QIangIQsAnotherScoreboard/QIangIQsAnotherScoreboard_data",
			mod_localization = "QIangIQsAnotherScoreboard/scripts/mods/QIangIQsAnotherScoreboard/QIangIQsAnotherScoreboard_localization",
		})
	end,
	version = "1.2.8-qiangiq.1",
	author = "QIangIQ (based on AnotherScoreboard)",
	load_after = { "QIangIQsSyncChannel" },
	packages = {},
}
