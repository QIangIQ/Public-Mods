-- Sync with other players through QIangIQsSyncChannel (api in QIangIQsSyncChannel.lua: provide / roster /
-- on_change / mark_dirty / withdraw). Every player running this mod shares, in category "x":
--
--   "sb" = { 1, mission, o1, o2, ... }  my OWN counts of the stats in OWNER_STATS (a player knows their own
--                                       dodges, slides, ability uses, downs ... better than a teammate does)
--   "v<id>" = { a1, a2, ... }           what MY client counted for player <id> (first ID_LENGTH characters of the
--                                       account id) in AVERAGE_STATS: kills and damage are seen by every client
--
-- On the scoreboard, once another player runs this mod:
--   * AVERAGE_STATS of every player = the average of what each client that runs the mod counted for that player
--     (client side numbers, mine included). A client's own number is kept apart from the shown one:
--     entry.sync_offset = shown score - locally counted score, so counting goes on from the local number.
--   * OWNER_STATS of a player = that player's own count, not my count of them.
-- Without another player running it nothing changes. Author: QIangIQ
local mod = get_mod("QIangIQsAnotherScoreboard")

local CATEGORY = "x"
local NAME = "scoreboardsync"
local OWN_KEY = "sb"
local VIEW_PREFIX = "v"
local SCHEMA = 1
local ID_LENGTH = 8
local POLL_INTERVAL = 1.0
local MIN_PUBLISH_INTERVAL = 3.0

-- QIangIQsAnotherScoreboard_stats.lua STAT_DEFS ids; the order is the wire order, only ever append
local OWNER_STATS = {
    "dodges",
    "slides",
    "combat_ability_uses",
    "ammo_pickups",
    "ammo_collected",
    "healthstation_uses",
    "damage_taken",
    "downs",
    "deaths",
    "downs_and_deaths",
    "revives_and_rescues",
    "times_disabled",
    "disabled_helped",
}
local AVERAGE_STATS = {
    "total_kills",
    "damage_dealt",
    "specials_killed",
    "elites_killed",
    "damage_to_bosses",
}
local DAMAGE_INDEX = 2 -- AVERAGE_STATS entry whose average also goes to _data._total_damage (same increments)

local Sync = {
    channel = nil,
    unsubscribe = nil,
    loaded = false,
    poll_now = true,
    poll_timer = 0,
    last_sent = nil,
    last_publish = -math.huge,
    clock = 0,
}

local function stats()
    return mod.get_stats and mod.get_stats()
end

local function enabled()
    return mod:is_enabled() and mod:get("sync_enabled")
end

local function short_id(account_id)
    return string.sub(tostring(account_id), 1, ID_LENGTH)
end

-- as QIangIQsSprays_sync.lua Sync.mission(): the map's mission name
local function mission_name()
    local mission = Managers.state and Managers.state.mission
    if not mission then
        return nil
    end
    local ok, name = pcall(mission.mission_name, mission)
    return ok and type(name) == "string" and name or nil
end

local function entry_for(Stats, stat_id, account_id, create)
    local data = Stats.data_for(stat_id)
    if not data then
        return nil
    end
    local entry = data[account_id]
    if not entry and create then
        entry = { value = 0, score = 0 }
        data[account_id] = entry
    end
    return entry
end

-- what this client counted itself (the shown number minus what the sync added)
local function local_score(entry)
    return (entry.score or 0) - (entry.sync_offset or 0)
end

local function round(n)
    return math.floor(n + 0.5)
end

-- Publishing ------------------------------------------------------------------------------
-- free of side effects: the channel may call it at any time
local function build()
    if not enabled() then
        return nil
    end
    local Stats = stats()
    local me = mod._me and mod._me()
    local mission = mission_name()
    if not Stats or not me or not mission then
        return nil
    end
    local out = {}
    local own = { SCHEMA, mission }
    for i = 1, #OWNER_STATS do
        local entry = entry_for(Stats, OWNER_STATS[i], me)
        own[i + 2] = entry and round(entry.score or 0) or 0
    end
    out[OWN_KEY] = own
    for account_id in pairs(mod._player_roster or {}) do
        local view = {}
        for i = 1, #AVERAGE_STATS do
            local entry = entry_for(Stats, AVERAGE_STATS[i], account_id)
            view[i] = entry and round(local_score(entry)) or 0
        end
        out[VIEW_PREFIX .. short_id(account_id)] = view
    end
    return out
end

local function signature(values)
    local keys = {}
    for key in pairs(values) do
        keys[#keys + 1] = key
    end
    table.sort(keys)
    local parts = {}
    for i = 1, #keys do
        local value = values[keys[i]]
        parts[i] = keys[i] .. "=" .. table.concat(value, ",", 1, #value)
    end
    return table.concat(parts, ";")
end

local function publish_if_changed()
    local values = build()
    local text = values and signature(values) or ""
    if text ~= Sync.last_sent and Sync.clock - Sync.last_publish >= MIN_PUBLISH_INTERVAL then
        Sync.last_sent = text
        Sync.last_publish = Sync.clock
        if Sync.channel then
            Sync.channel.mark_dirty()
        end
    end
end

-- Applying what the others sent -----------------------------------------------------------
local function valid_count(value)
    return type(value) == "number" and value == value and value >= 0 and value < 1e15
end

-- shown score of one entry := merged (the local count stays recoverable through sync_offset)
local function set_merged(Stats, stat_id, account_id, merged)
    local entry = entry_for(Stats, stat_id, account_id, true)
    if not entry then
        return false
    end
    local offset = (entry.sync_offset or 0)
    local counted = (entry.score or 0) - offset
    local changed = entry.score ~= merged
    entry.value = (entry.value or 0) + (merged - (entry.score or 0))
    entry.score = merged
    entry.sync_offset = merged - counted
    return changed
end

-- the shown scores are replaced by the client side counts again
local function unmerge(Stats)
    local changed = false
    local ids = { "_total_damage" }
    for i = 1, #AVERAGE_STATS do
        ids[#ids + 1] = AVERAGE_STATS[i]
    end
    for i = 1, #ids do
        local data = Stats.data_for(ids[i])
        for _, entry in pairs(data or {}) do
            if entry.sync_offset and entry.sync_offset ~= 0 then
                entry.score = (entry.score or 0) - entry.sync_offset
                entry.value = (entry.value or 0) - entry.sync_offset
                entry.sync_offset = 0
                changed = true
            end
        end
    end
    return changed
end

local function touch_scoreboard()
    local external = mod.external_stats
    if external and external.revision then
        external.revision = external.revision + 1 -- the open scoreboard rebuilds from it
    end
end

function Sync.apply()
    local Stats = stats()
    if not Stats then
        return
    end
    if not enabled() then
        if unmerge(Stats) then
            touch_scoreboard()
        end
        return
    end
    local roster = mod._player_roster or {}
    local mission = mission_name()
    local me = mod._me and mod._me()
    if not mission or not me or not roster[me] then
        return
    end

    -- account id of each player in the game by the short id used on the wire (an ambiguous short id is left out)
    local by_short = {}
    for account_id in pairs(roster) do
        local key = short_id(account_id)
        by_short[key] = by_short[key] == nil and account_id or false
    end

    -- samples[account id] = { sum = { ... }, n = clients that counted this player }
    local samples = {}
    local function add_sample(account_id, view)
        local sample = samples[account_id]
        if not sample then
            sample = { sum = {}, n = 0 }
            for i = 1, #AVERAGE_STATS do
                sample.sum[i] = 0
            end
            samples[account_id] = sample
        end
        for i = 1, #AVERAGE_STATS do
            sample.sum[i] = sample.sum[i] + view[i]
        end
        sample.n = sample.n + 1
    end

    local changed = false

    -- my own client's counts
    for account_id in pairs(roster) do
        local view = {}
        for i = 1, #AVERAGE_STATS do
            local entry = entry_for(Stats, AVERAGE_STATS[i], account_id)
            view[i] = entry and local_score(entry) or 0
        end
        add_sample(account_id, view)
    end

    -- the other clients' counts, and each of them for their own stats
    local others = false
    local channel = Sync.channel
    for client_id, peer in pairs(channel and channel.roster() or {}) do
        local bucket = peer.running and type(peer.data) == "table" and peer.data[CATEGORY] or nil
        local own = type(bucket) == "table" and bucket[OWN_KEY] or nil
        if type(own) == "table" and own[1] == SCHEMA and own[2] == mission and client_id ~= me then
            others = true
            if roster[client_id] then
                for i = 1, #OWNER_STATS do
                    local value = own[i + 2]
                    if valid_count(value) then
                        local entry = entry_for(Stats, OWNER_STATS[i], client_id, true)
                        if entry and entry.score ~= value then
                            entry.score = value
                            if OWNER_STATS[i] ~= "damage_taken" then -- a "diff" stat keeps its last raw reading in value
                                entry.value = value
                            end
                            changed = true
                        end
                    end
                end
            end
            for key, view in pairs(bucket) do
                if string.sub(key, 1, #VIEW_PREFIX) == VIEW_PREFIX and #key == #VIEW_PREFIX + ID_LENGTH then
                    local account_id = by_short[string.sub(key, #VIEW_PREFIX + 1)]
                    if account_id and type(view) == "table" then
                        local ok = true
                        for i = 1, #AVERAGE_STATS do
                            ok = ok and valid_count(view[i])
                        end
                        if ok then
                            add_sample(account_id, view)
                        end
                    end
                end
            end
        end
    end

    if not others then
        if unmerge(Stats) then
            changed = true
        end
    else
        for account_id, sample in pairs(samples) do
            for i = 1, #AVERAGE_STATS do
                local merged = round(sample.sum[i] / sample.n)
                if set_merged(Stats, AVERAGE_STATS[i], account_id, merged) then
                    changed = true
                end
                if i == DAMAGE_INDEX then
                    set_merged(Stats, "_total_damage", account_id, merged)
                end
            end
        end
    end

    if changed then
        touch_scoreboard()
    end
end

-- Lifecycle (called from QIangIQsAnotherScoreboard.lua) -----------------------------------
function Sync.start()
    Sync.loaded = true
    if not Sync.channel then
        local host = get_mod("QIangIQsSyncChannel")
        local channel = host and host.api
        if not channel then
            mod:info("[Sync] QIangIQsSyncChannel not found; nothing is shared.")
        else
            channel.provide(NAME, CATEGORY, build)
            Sync.channel = channel
            Sync.unsubscribe = channel.on_change(function()
                Sync.poll_now = true
            end)
        end
    end
    Sync.poll_now = true
end

function Sync.stop()
    if Sync.channel then
        Sync.channel.withdraw(NAME)
    end
    if Sync.unsubscribe then
        Sync.unsubscribe()
    end
    Sync.channel, Sync.unsubscribe, Sync.last_sent = nil, nil, nil
    local Stats = stats()
    if Stats then
        unmerge(Stats)
    end
end

function Sync.on_setting_changed()
    Sync.poll_now = true
    Sync.last_sent = nil
end

function Sync.update(dt)
    if not Sync.loaded then
        return
    end
    Sync.clock = Sync.clock + (dt or 0)
    Sync.poll_timer = Sync.poll_timer + (dt or 0)
    if Sync.poll_now or Sync.poll_timer >= POLL_INTERVAL then
        Sync.poll_now = false
        Sync.poll_timer = 0
        publish_if_changed()
        Sync.apply()
    end
end

return Sync
