# Changelog

## Local: dodges performed

- Added **Void shield damage** (Damage details, Live Stat "Shield Dmg"): shield damage on Captains and Twins, which previously reported as 0. Exact for the host; on a client a hit can be credited to the next attack report if the shield value arrives a frame apart.
- Added **Slides** (Survival > Utility and Live Stat), counted per player like Dodges.
- **Number of Live Stats** is now a 1-10 slider with ten stat pickers (still saved per class).
- Added a **Dodges** row under Survival > Utility, a matching scoreboard visibility option and a **Dodges** Live Stat. A dodge is counted each time a player enters the `dodging` character state, the same signal Power DI records.
- Added **Maximum Players Shown** (4-12, default 4). The Tab/end scoreboard, history, Live Stats HUD and boss popup show up to that many players; the scoreboard panel widens by 100 px per player past four and scales down if it would leave the screen. Players five and up reuse the four player colors. The loadout tab shows four player cards at a time, the page holding the selected player.

## 1.2.2

- Added Simplified Chinese localization for mod options, scoreboards, history, loadouts, and enemy-detail rows.
- Added the **Recent history capacity** option with limits from 10 to 100 missions in steps of 10; the default remains 10.
- Added mouse-wheel scrolling, range indicators, and independent scroll positions for Recent and Saved history lists.
- Saved history remains unlimited.
- Corrected Simplified Chinese percentage formatting and a damage-over-time detail hint.

### Credits

- Simplified Chinese localization contributed by [Keaun (@liukangcc)](https://github.com/liukangcc) in [PR #1](https://github.com/Vansinnet/AnotherScoreboard/pull/1).
