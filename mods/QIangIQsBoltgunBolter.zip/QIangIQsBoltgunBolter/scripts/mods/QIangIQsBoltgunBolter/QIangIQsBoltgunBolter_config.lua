-- QIangIQsBoltgunBolter per-weapon data (weapons\gen.py spec bolter). Clips are the Animations keys of BP_WeaponAnimations_ActionWeapon_Boltgun.
-- Action names and kinds: Darktide weapon templates (Aussiemon master), read by gen.py actions_of.
return {
    ranged = true,
    idle = "Idle",
    templates = { bolter_p1_m1 = true, bolter_p1_m2 = true },
    shot = { clips = { "Fire" }, sounds = { "BoltgunFire01.ogg", "BoltgunFire02.ogg", "BoltgunFire03.ogg", "BoltgunFire04.ogg", "BoltgunFire05.ogg" }, time = 0.45 },
    actions = {
        action_reload = { clips = { "Reload" }, stretch = true, reload_template = true, over_shot = true, tempo = true, empty_clips = { "ReloadFull" }, sounds = { "BoltgunReloadPartial.ogg" }, empty_sounds = { "BoltgunReloadFull.ogg" } },
        action_wield = { clips = { "Pickup" }, tempo = true, speed_to = 1.9, sounds = { "WPN_MC_Boltgun_PickupAnim.ogg" } },
    },
}
