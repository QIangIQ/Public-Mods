return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsBoltgunBolter` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsBoltgunBolter", {
            mod_script = "QIangIQsBoltgunBolter/scripts/mods/QIangIQsBoltgunBolter/QIangIQsBoltgunBolter",
            mod_data = "QIangIQsBoltgunBolter/scripts/mods/QIangIQsBoltgunBolter/QIangIQsBoltgunBolter_data",
            mod_localization = "QIangIQsBoltgunBolter/scripts/mods/QIangIQsBoltgunBolter/QIangIQsBoltgunBolter_localization",
        })
    end,
    version = "0.1.0",
    author = "QIangIQ",
    packages = {},
}
