local mod = get_mod("QIangIQsWallclimber")

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = true,
    options = {
        widgets = {
            { setting_id = "hide_prologue", type = "checkbox", default_value = true },
            { setting_id = "patrols", type = "checkbox", default_value = true },
            { setting_id = "full_scale_s1", type = "checkbox", default_value = true },
            {
                setting_id = "rappel_key",
                type = "keybind",
                default_value = {},
                keybind_trigger = "held",
                keybind_type = "function_call",
                function_name = "rappel",
            },
            { setting_id = "brightness", type = "numeric", default_value = 0, range = { -4, 6 }, decimals_number = 1 },
        },
    },
}
