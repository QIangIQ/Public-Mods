return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsWallclimber` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsWallclimber", {
            mod_script = "QIangIQsWallclimber/scripts/mods/QIangIQsWallclimber/QIangIQsWallclimber",
            mod_data = "QIangIQsWallclimber/scripts/mods/QIangIQsWallclimber/QIangIQsWallclimber_data",
            mod_localization = "QIangIQsWallclimber/scripts/mods/QIangIQsWallclimber/QIangIQsWallclimber_localization",
        })
    end,
    version = "0.7.16",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}



