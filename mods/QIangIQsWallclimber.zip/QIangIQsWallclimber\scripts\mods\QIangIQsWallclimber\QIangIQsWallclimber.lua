-- QIangIQ's Wallclimber: ARMORED CORE VI "Operation Wallclimber" (m50_30_00_00) inside Darktide.
-- PERSONAL USE ONLY: geometry/textures/collision are converted from the user's own AC6 install
-- (A:\Dowloads\QIangIQsWallclimber, build_section.py). Nothing spawns outside a single-player session.
--
-- Mission "wallclimber_ac6" (SoloPlay list) = a copy of core_research (Clandestium Gloriana: Void zone, daylight sky
-- and snow) with its normal coop rules (your own loadout and talents), enemy pacing held off, "unkillable" added and
-- cinematics skipped. The base level is hidden (units invisible, lights off; units reaching into the map lose
-- physics; sky kept) and Wallclimber is spawned above it at the world origin; you start next to the AC drop point.
-- Section 1 only in this build. 0.1.x-0.2.0 used the prologue as base (see note 80).
local mod = get_mod("QIangIQsWallclimber")
local MatchmakingConstants = require("scripts/settings/network/matchmaking_constants")
local PlayerMovement = require("scripts/utilities/player_movement")
local HOST_TYPES = MatchmakingConstants.HOST_TYPES

-- 0.7.0: two builds of the map. wc1s1 = start -> hangar only, rebuilt at scale 0.7 (needs the "full_scale_s1" setting
-- on, the default); wc1 = the whole route at scale 0.35. Pins are authored in the wc1 frame (the Map Viewer) and are
-- converted to whichever build is loaded (see load_pins).
local SECTION = (mod:get("full_scale_s1") ~= false) and "wc1s1" or "wc1"
local Layout = mod:io_dofile("QIangIQsWallclimber/scripts/mods/QIangIQsWallclimber/" .. SECTION .. "_layout")
if type(Layout) ~= "table" or type(Layout.chunks) ~= "table" then
    mod:error(SECTION .. "_layout.lua could not be read; Wallclimber is unavailable")
    Layout = { chunks = {}, start = { 0, 0, 0 }, start_forward = { 0, 1, 0 }, library = SECTION .. "_lib" }
end

local MOD_ID = "QIangIQsWallclimber:"
local UNIT_PREFIX = "content/mods/qiangiq_wallclimber/"
local MISSION_KEY = "wallclimber_ac6"
-- 0.3.0: base = core_research (Clandestium Gloriana, Void zone: daylight sky and snow, user's choice) instead of the
-- prologue (black night sky). Its game mode coop_complete_objective has no prologue restrictions, so no game-mode
-- clone is needed; pacing is held off (hook below) and "unkillable" is added so a fall cannot fail the mission.
local HOST_MISSION = "core_research"
local SPAWNS_PER_FRAME = 12
local SKY_SIZE = 1000       -- units with a half-extent above this are kept visible (sky dome)
-- The map is lifted by base_z so all of it sits above the prologue: the prologue's player_mover_blocker volumes
-- are engine volumes (no Lua can remove them) and reach z 93.3. The prologue floor keeps its physics, so bots,
-- pickups and minions it spawns stay on it instead of falling out of bounds (out_of_bounds_manager.lua).
local BASE_Z = Layout.base_z or 0
local FALL_LIMIT = (Layout.min_z or -150) + BASE_Z - 15
local INTRUDE_Z = (Layout.min_z or -150) + BASE_Z - 5  -- prologue units reaching above this lose their physics

-- ---------------------------------------------------------------------------------------------------- registration
-- Runs at file load, before SoloPlay builds its list (SoloPlaySettings.lua:196): keep this mod above Soloplay.
local function register()
    local ok, err = pcall(function()
        local MissionTemplates = require("scripts/settings/mission/mission_templates")
        local host = MissionTemplates[HOST_MISSION]
        if not host or rawget(MissionTemplates, MISSION_KEY) then
            return
        end
        local template = table.clone(host)
        template.name = MISSION_KEY
        template.mission_name = "loc_mission_name_wallclimber_ac6"
        template.not_available_on_mission_board = true
        template.gameplay_modifiers = { "unkillable" }
        MissionTemplates[MISSION_KEY] = template
        -- mission names are networked by index (network_lookup.lua:314); append like _init (Factory, note 46)
        local NetworkLookup = require("scripts/network_lookup/network_lookup")
        local lookup = rawget(NetworkLookup, "missions")
        if lookup and rawget(lookup, MISSION_KEY) == nil then
            local index = #lookup + 1
            rawset(lookup, index, MISSION_KEY)
            rawset(lookup, MISSION_KEY, index)
        end
        local DialogueSettings = require("scripts/settings/dialogue/dialogue_settings")
        if DialogueSettings.blocked_auto_load_files then
            DialogueSettings.blocked_auto_load_files[MISSION_KEY] = DialogueSettings.blocked_auto_load_files[HOST_MISSION]
        end
        if DialogueSettings.level_specific_load_files then
            DialogueSettings.level_specific_load_files[MISSION_KEY] = DialogueSettings.level_specific_load_files[HOST_MISSION]
        end
    end)
    if not ok then
        mod:error("could not add the Wallclimber mission: %s", tostring(err))
    end
end

mod:add_global_localize_strings({
    loc_mission_name_wallclimber_ac6 = { en = "Operation Wallclimber (AC6) - QIangIQ" },
})
register()

-- ---------------------------------------------------------------------------------------------------- state
local custom_assets = nil
local tickets = {}
local loaded = {}
local load_state = "idle"   -- idle | loading | ready
local units, unit_set = {}, {}
local named = {}            -- layout row name -> spawned unit (bridge parts)
local bridges = {}          -- 0.4.5 drawbridge states, built from Layout.bridges in start_spawning
local spawn_queue = nil
local release_pending = false
local auto_enter = nil
local mission_check = false -- set on gameplay enter; the mission manager is not ready at that moment (0.1.2 log)
local hidden = {}           -- prologue units already hidden
local hide_t = 0
local force_hide_big = false -- 0.5.0 "/wallclimber hide all": also hide units larger than SKY_SIZE (kept as sky by default)
local kept_big = 0           -- count of big units kept visible in the last pass (logged as "KEPT big unit")

local function say(fmt, ...)
    mod:echo("[Wallclimber] " .. string.format(fmt, ...))
end

local function local_player()
    local players = Managers.player
    if not players then
        return nil
    end
    local ok, player = pcall(players.local_player_safe, players, 1)
    return ok and player or nil
end

local function unit_ok(unit)
    return unit ~= nil and Unit.alive(unit)
end

local function current_mission()
    local m = Managers.state and Managers.state.mission
    local ok, name = pcall(function() return m and m:mission_name() end)
    return ok and name or nil
end

local function level_world()
    return Managers.world and Managers.world:world("level_world")
end

-- single-player sessions of our own mission only (personal-use assets; the hide pass would wipe any other map)
local function gate()
    if current_mission() ~= MISSION_KEY then
        return false, "only in the SoloPlay mission \"Operation Wallclimber (AC6) - QIangIQ\""
    end
    local session = Managers.multiplayer_session
    if not session or session:host_type() ~= HOST_TYPES.singleplay then
        return false, "single-player sessions only (start it from SoloPlay)"
    end
    local game_mode = Managers.state and Managers.state.game_mode
    local mode = game_mode and game_mode:game_mode_name()
    if mode == "hub" or mode == "prologue_hub" or mode == "hub_singleplay" then
        return false, "missions only"
    end
    return true
end

-- ---------------------------------------------------------------------------------------------------- prologue hiding
local function hide_prologue()
    if not mod:get("hide_prologue") or current_mission() ~= MISSION_KEY then
        return 0
    end
    local world = level_world()
    if not world then
        return 0
    end
    local ok, levels = pcall(World.get_data, world, "levels")
    if not ok or type(levels) ~= "table" then
        return 0
    end
    local n = 0
    local function hide_unit(u)
        hidden[u] = true
        local keep, top = false, nil
        local bok, pose, extents = pcall(Unit.box, u)
        if bok and extents then
            local ex, ey, ez = Vector3.to_elements(extents)
            local r = math.max(ex, ey, ez)
            keep = r > SKY_SIZE and not force_hide_big
            top = Vector3.z(Matrix4x4.translation(pose)) + r
            if keep then
                kept_big = kept_big + 1
                if kept_big <= 12 then
                    local px, py, pz = Vector3.to_elements(Matrix4x4.translation(pose))
                    mod:info("KEPT big unit r=%.0f at (%.0f, %.0f, %.0f)", r, px, py, pz)
                end
            end
        end
        if not keep then
            pcall(Unit.set_unit_visibility, u, false, true)
            if top and top > INTRUDE_Z then
                pcall(Unit.disable_physics, u)
            end
            local lok, nl = pcall(Unit.num_lights, u)
            if lok and nl then
                for i = 1, nl do
                    pcall(Light.set_enabled, Unit.light(u, i), false)
                end
            end
            n = n + 1
        end
    end
    for _, data in pairs(levels) do
        local level = data.level
        if level then
            local uok, lunits = pcall(Level.units, level, true)
            if uok and lunits then
                for _, u in ipairs(lunits) do
                    if not hidden[u] and not unit_set[u] and unit_ok(u) then
                        hide_unit(u)
                    end
                end
            end
        end
    end
    -- 0.5.0: units that are not part of any level (spawned at runtime by the base mission: props, pickups,
    -- objective units) were never swept. World.units(world) lists everything in the world
    -- (world_level_despawn_manager.lua:179); only those below the Wallclimber floor are hidden, so the player,
    -- their weapons, our units and patrols (all above INTRUDE_Z) are untouched.
    -- REVERTED (0.5.1): the World.units sweep crashed the engine in Unit.world_position (crash 2026-10-18 05:08,
    -- hide_prologue line 205; pcall cannot catch an engine fault). Do not call Unit functions on arbitrary
    -- World.units entries.
    return n
end

-- ---------------------------------------------------------------------------------------------------- units
local function despawn_all()
    for _, unit in ipairs(units) do
        if unit_ok(unit) then
            local world = Unit.world(unit)
            if world then
                World.destroy_unit(world, unit)
            end
        end
    end
    units, unit_set, spawn_queue, named, bridges = {}, {}, nil, {}, {}
    if mod.reset_env then
        mod.reset_env()
    end
    if mod.release_rappel_light then
        mod.release_rappel_light()
    end
end

local function release_all()
    if custom_assets and custom_assets.release then
        for _, t in pairs(tickets) do
            custom_assets.release(t)
        end
    end
    tickets, loaded, load_state = {}, {}, "idle"
end

local function clear_fall_speed(player_unit)
    -- the engine teleport only zeroes velocity_wanted (player_movement.lua:40); clear the fall speed too (Factory)
    local ude = ScriptUnit.has_extension(player_unit, "unit_data_system")
    if ude then
        pcall(function()
            ude:write_component("locomotion").velocity_current = Vector3.zero()
        end)
    end
end

local function ground_below(pos)
    local world = level_world()
    local pw = world and World.physics_world(world)
    if not pw then
        return nil
    end
    local ok, hit, hit_pos = pcall(PhysicsWorld.raycast, pw, pos, Vector3(0, 0, -1), 400, "closest",
        "collision_filter", "filter_player_mover")
    if ok and hit and hit_pos then
        return hit_pos
    end
    return nil
end

local function teleport_to_start()
    local player = local_player()
    local player_unit = player and player.player_unit
    if not unit_ok(player_unit) then
        return
    end
    -- the AC drop point itself is over a ~10 m hole (no render or collision under it, coverage.py); safe_start is
    -- the nearest walkable collision, 7 m away
    local s = Layout.safe_start or Layout.start
    local f = Layout.start_forward
    local top = Vector3(s[1], s[2], s[3] + BASE_Z + 5)
    local ground = ground_below(top)
    local pos = ground and (ground + Vector3(0, 0, 0.2)) or Vector3(s[1], s[2], s[3] + BASE_Z + 0.2)
    local rot = Quaternion.look(Vector3(f[1], f[2], 0), Vector3.up())
    PlayerMovement.teleport(player, pos, rot)
    clear_fall_speed(player_unit)
    return ground ~= nil
end

local function start_spawning()
    spawn_queue = {}
    for _, row in ipairs(Layout.chunks) do
        if loaded[row[1]] and row[5] ~= "defer" then
            spawn_queue[#spawn_queue + 1] = row
        end
    end
    bridges = {}
    for _, b in ipairs(Layout.bridges or {}) do
        bridges[#bridges + 1] = { def = b, state = "up", t = 0 }
    end
    say("building Wallclimber section 1: %d chunks", #spawn_queue)
end

local function load_map()
    custom_assets = custom_assets or get_mod("CustomAssets")
    if not custom_assets or not custom_assets.is_api_compatible or not custom_assets.is_api_compatible(1) then
        say("Custom Assets (API 1) is missing")
        return
    end
    load_state = "loading"
    local pending, failed = #Layout.chunks, 0
    local function chunk_done()
        pending = pending - 1
        if pending == 0 then
            load_state = "ready"
            if failed > 0 then
                say("%d chunk(s) failed to load (run CUSTOM_ASSETS_PATCH.bat with the game closed)", failed)
            end
            if gate() then
                start_spawning()
            end
        end
    end
    local lib_id = MOD_ID .. Layout.library
    local t, err = custom_assets.acquire(mod, lib_id, function(_, _, load_error)
        if load_error then
            load_state = "idle"
            say("%s failed to load: %s (run CUSTOM_ASSETS_PATCH.bat with the game closed)", lib_id, tostring(load_error))
            return
        end
        -- chunks reference the library's materials, so they are requested after it (Factory)
        for _, row in ipairs(Layout.chunks) do
            local name = row[1]
            local id = MOD_ID .. name
            local ct, cerr = custom_assets.acquire(mod, id, function(_, _, chunk_error)
                if chunk_error then
                    failed = failed + 1
                else
                    loaded[name] = true
                end
                chunk_done()
            end, { reference_name = id })
            if ct then
                tickets[name] = ct
            else
                failed = failed + 1
                mod:info("%s could not be requested: %s", id, tostring(cerr))
                chunk_done()
            end
        end
    end, { reference_name = lib_id })
    if not t then
        load_state = "idle"
        say("%s could not be requested: %s", lib_id, tostring(err))
        return
    end
    tickets[Layout.library] = t
    say("loading Wallclimber (%d packages)...", #Layout.chunks + 1)
end

local function request_enter()
    local ok, why = gate()
    if not ok then
        say("%s", why)
        return
    end
    if #units > 0 then
        teleport_to_start()
        say("back at the drop point")
    elseif load_state == "ready" then
        start_spawning()
    elseif load_state == "loading" then
        say("still loading...")
    else
        load_map()
    end
end

local function debug()
    local ok, why = gate()
    local session = Managers.multiplayer_session
    local game_mode = Managers.state and Managers.state.game_mode
    say("gate: %s%s | host: %s | mission: %s | game mode: %s", tostring(ok), why and (" (" .. why .. ")") or "",
        session and tostring(session:host_type()) or "none", tostring(current_mission()),
        game_mode and tostring(game_mode:game_mode_name()) or "none")
    local n_loaded, n_hidden = 0, 0
    for _ in pairs(loaded) do n_loaded = n_loaded + 1 end
    for _ in pairs(hidden) do n_hidden = n_hidden + 1 end
    say("load: %s, chunks loaded %d/%d, spawned %d, prologue units seen %d", load_state, n_loaded, #Layout.chunks,
        #units, n_hidden)
    local player = local_player()
    local pu = player and player.player_unit
    if unit_ok(pu) then
        local p = Unit.world_position(pu, 1)
        local g = ground_below(p + Vector3(0, 0, 2))
        say("player at (%.1f, %.1f, %.1f); ground below: %s", Vector3.x(p), Vector3.y(p), Vector3.z(p),
            g and string.format("%.1f", Vector3.z(g)) or "none")
    end
end

-- ---------------------------------------------------------------------------------------------------- marks / rappel
-- Positions are stored section-local (Stingray, without the lift) as "x,y,z" strings in the mod's settings.
local function to_local(world_pos)
    return Vector3(Vector3.x(world_pos), Vector3.y(world_pos), Vector3.z(world_pos) - BASE_Z)
end

local function to_game(lp)
    -- Stingray local = (gx, gz, gy) * scale about center_game (install_section.py)
    local c, s = Layout.center_game or { 0, 0, 0 }, Layout.scale or 1
    return c[1] + Vector3.x(lp) / s, c[2] + Vector3.z(lp) / s, c[3] + Vector3.y(lp) / s
end

local function pos_string(v)
    return string.format("%.2f,%.2f,%.2f", Vector3.x(v), Vector3.y(v), Vector3.z(v))
end

local function parse_pos(str)
    if type(str) ~= "string" then
        return nil
    end
    local x, y, z = str:match("^([-%d%.]+),([-%d%.]+),([-%d%.]+)$")
    return x and Vector3(tonumber(x), tonumber(y), tonumber(z)) or nil
end

local function player_unit()
    local player = local_player()
    local pu = player and player.player_unit
    return unit_ok(pu) and pu or nil, player
end

local function mark(label)
    local pu = player_unit()
    if not pu then
        return
    end
    local lp = to_local(Unit.world_position(pu, 1))
    local gx, gy, gz = to_game(lp)
    say("mark %s: local (%.1f, %.1f, %.1f) | AC6 game (%.1f, %.1f, %.1f)", tostring(label or ""), Vector3.x(lp),
        Vector3.y(lp), Vector3.z(lp), gx, gy, gz)
    mod:info("MARK %s local %s game %.2f,%.2f,%.2f", tostring(label or ""), pos_string(lp), gx, gy, gz)
end

-- 0.4.8 rappel event (user): a spool of rope sits at the anchor (Layout.rope.spool), highlighted by a light. Hold the
-- rappel key next to it for RAPPEL_HOLD s: the rope is "thrown" - its pieces (build_rope.py, draped on the cliff)
-- grow one after another down the path (Unit.set_local_scale, Aura.lua:96) - then you go down along it with the
-- camera free (PlayerMovement.teleport with rotation nil keeps the look direction, player_movement.lua:33).
-- Light: the battery luggable light unit, shrunk and kept in place every frame (Aura mod, Aura.lua:78-97 and 165).
-- Without Layout.rope the 0.4.6 straight rope between the rappel_top / rappel_bottom settings is used.
local RAPPEL_SPEED = 4      -- metres per second along the rope
local RAPPEL_REACH = 3      -- metres from the spool (the event area)
local RAPPEL_HOLD = 1.5     -- seconds the key must be held in the area
local THROW_GAP = 0.12      -- seconds between rope pieces leaving the spool
local THROW_GROW = 0.3      -- seconds for one piece to reach full length
local ROPE = Layout.rope
local ROPE_UNIT = Layout.section and (Layout.section .. "_rope") or "wc1_rope"
local rappel = nil          -- { phase = "throw"|"descend", t, waypoints = { Vector3Box }, seg, seg_t }
local rappel_hold, hold_t, in_area = false, 0, false
local rope_units = {}       -- spawned rope pieces (or the 0.4.6 straight rope)
local rope_thrown = false
local rlight = nil          -- { ids = {}, pending = n, base_unit, unit }

local function v3(t)
    return Vector3(t[1], t[2], t[3])
end

local function rappel_points()
    if ROPE then
        return v3(ROPE.spool_pos), v3(ROPE.landing)
    end
    return parse_pos(mod:get("rappel_top")), parse_pos(mod:get("rappel_bottom"))
end

local function release_rappel_light()
    if rlight then
        if unit_ok(rlight.unit) then
            World.destroy_unit(Unit.world(rlight.unit), rlight.unit)
        end
        for _, id in ipairs(rlight.ids) do
            pcall(function() Managers.package:release(id) end)
        end
    end
    rlight = nil
end

local function request_rappel_light()
    local ok1, MasterItems = pcall(require, "scripts/backend/master_items")
    local ok2, ItemPackage = pcall(require, "scripts/foundation/managers/package/utilities/item_package")
    if not (ok1 and ok2) or not MasterItems.has_data() then
        return
    end
    local item = MasterItems.get_item("content/items/luggable/battery_01_luggable")
    if not item then
        return
    end
    local deps = ItemPackage.compile_item_instance_dependencies(item, MasterItems.get_cached(), nil, nil)
    local state = { ids = {}, pending = 0, base_unit = item.base_unit }
    rlight = state
    for package_name in pairs(deps) do
        state.pending = state.pending + 1
        state.ids[#state.ids + 1] = Managers.package:load(package_name, "QIangIQsWallclimber", function()
            state.pending = state.pending - 1
        end, true)
    end
end

local function update_rappel_light(top)
    if not rlight then
        local ok = pcall(request_rappel_light)
        if not ok then
            rlight = { ids = {}, pending = 1 }   -- give up quietly; no highlight
        end
        return
    end
    local pos = top + Vector3(0, 0, BASE_Z + 1.5)
    if not unit_ok(rlight.unit) then
        local world = level_world()
        if rlight.pending > 0 or not world or not rlight.base_unit then
            return
        end
        rlight.unit = World.spawn_unit(world, rlight.base_unit, pos, Quaternion.identity())
        if not rlight.unit then
            return
        end
        Unit.set_local_scale(rlight.unit, 1, Vector3.one() * 0.001)
        local light = Unit.light(rlight.unit, 1)
        if light then
            Light.set_volumetric_intensity(light, 0.025)
            Light.set_casts_shadows(light, false)
            Light.set_color_filter(light, Vector3(1, 0.75, 0.35))
            Light.set_type(light, "omni")
            Light.set_intensity(light, 25)
            Light.set_falloff_start(light, 0)
            Light.set_falloff_end(light, 9)
            Light.set_enabled(light, true)
        end
    end
    Unit.set_local_position(rlight.unit, 1, pos)
end

local function spawn_rope_unit(name, pos, rot)
    local world = level_world()
    if not world or not loaded[name] then
        return nil
    end
    local unit = World.spawn_unit_ex(world, UNIT_PREFIX .. name, nil, pos, rot or Quaternion.identity())
    if unit then
        units[#units + 1] = unit
        unit_set[unit] = true
        rope_units[#rope_units + 1] = { unit = unit, t = 0 }
    end
    return unit
end

local function start_rappel()
    if current_mission() ~= MISSION_KEY or #units == 0 or rappel then
        return
    end
    local top, bottom = rappel_points()
    if not (top and bottom) then
        say("no rappel set: /wallclimber rappel top (at the cliff edge), /wallclimber rappel bottom (on the snowbank)")
        return
    end
    local pu = player_unit()
    if not pu then
        return
    end
    local here = to_local(Unit.world_position(pu, 1))
    if Vector3.length(here - top) > RAPPEL_REACH + 2 then
        say("rappel: stand at the rope spool (%.0f m away)", Vector3.length(here - top))
        return
    end
    local lift = Vector3(0, 0, BASE_Z)
    local wps = { Vector3Box(here + lift) }
    if ROPE then
        for _, p in ipairs(ROPE.descent) do
            wps[#wps + 1] = Vector3Box(v3(p) + lift)
        end
    else
        wps[#wps + 1] = Vector3Box(bottom + lift + Vector3(0, 0, 0.2))
    end
    rappel = { phase = rope_thrown and "descend" or "throw", t = 0, waypoints = wps, seg = 1, seg_t = 0, next_piece = 1 }
    if not rope_thrown and not ROPE then
        -- 0.4.6 fallback: one straight rope, stretched below
        local dir = Vector3.normalize(bottom - top)
        local u = spawn_rope_unit(ROPE_UNIT, top + lift + Vector3(0, 0, 0.3), Quaternion.look(dir, Vector3.up()))
        if u then
            Unit.set_local_scale(u, 1, Vector3(1, 0.01, 1))
        end
        rappel.next_piece = 2
    end
    say(rope_thrown and "rappelling..." or "rope thrown...")
end

-- keybind (keybind_trigger "held", DogWhistle_data.lua:116): called with true on press, false on release
mod.rappel = function(held)
    rappel_hold = held and true or false
end

mod.release_rappel_light = function()
    release_rappel_light()
    rope_units, rope_thrown, rappel, hold_t, in_area = {}, false, nil, 0, false
end

local function update_rappel_area(dt, here)
    local top = rappel_points()
    if not top or rappel then
        return
    end
    update_rappel_light(top)
    local inside = here ~= nil and Vector3.length(here - top) <= RAPPEL_REACH
    if inside and not in_area then
        say(rope_thrown and "rope: hold the rappel key to go down" or "rope spool: hold the rappel key (mod options) for %.1f s to throw the rope", RAPPEL_HOLD)
    end
    in_area = inside
    if inside and rappel_hold then
        hold_t = hold_t + dt
        if hold_t >= RAPPEL_HOLD then
            hold_t = 0
            start_rappel()
        end
    else
        hold_t = 0
    end
end

local function update_rappel(dt)
    local pu, player = player_unit()
    if not pu then
        rappel = nil
        return
    end
    if rappel.phase == "throw" then
        rappel.t = rappel.t + dt
        local lift = Vector3(0, 0, BASE_Z)
        if ROPE then
            -- next piece leaves the spool every THROW_GAP s
            while rappel.next_piece <= #ROPE.pieces and rappel.t >= (rappel.next_piece - 1) * THROW_GAP do
                local name = ROPE.pieces[rappel.next_piece]
                for _, row in ipairs(Layout.chunks) do
                    if row[1] == name then
                        local u = spawn_rope_unit(name, Vector3(row[2], row[3], row[4]) + lift)
                        if u then
                            Unit.set_local_scale(u, 1, Vector3.one() * 0.01)
                        end
                        break
                    end
                end
                rappel.next_piece = rappel.next_piece + 1
            end
        end
        local all_full = rappel.next_piece > (ROPE and #ROPE.pieces or 1)
        for _, r in ipairs(rope_units) do
            if r.t < 1 and unit_ok(r.unit) then
                r.t = math.min(r.t + dt / THROW_GROW, 1)
                if ROPE then
                    Unit.set_local_scale(r.unit, 1, Vector3.one() * math.max(r.t, 0.01))
                else
                    local top, bottom = rappel_points()
                    Unit.set_local_scale(r.unit, 1, Vector3(1, math.max(Vector3.length(bottom - top) * r.t, 0.01), 1))
                end
            end
            if r.t < 1 then
                all_full = false
            end
        end
        clear_fall_speed(pu)
        if all_full then
            rope_thrown = true
            rappel.phase = "descend"
            say("rappelling...")
        end
        return
    end
    -- 0.4.9 descent (user): the step to the rope top is automatic; on the rope you control it - hold back (S) to go
    -- down, dodge backwards to drop a few metres, forward (W) to climb, nothing = hang still. Camera free.
    -- Input: the player unit's input_system extension, get("move") = (right-left, forward-backward, 0) and
    -- get("dodge") (human_unit_input.lua:21-31, dodge.lua:30).
    local w = rappel.waypoints
    if not rappel.cum then
        rappel.cum, rappel.s, rappel.burst, rappel.dodge_was = { 0 }, 0, 0, false
        for k = 2, #w do
            rappel.cum[k] = rappel.cum[k - 1] + Vector3.length(w[k]:unbox() - w[k - 1]:unbox())
        end
    end
    local cum, total = rappel.cum, rappel.cum[#w]
    local rope_start = cum[math.min(2, #w)]
    if rappel.s < rope_start then
        rappel.s = math.min(rappel.s + dt * 3, rope_start)
        if rappel.s >= rope_start then
            say("on the rope: hold back (S) to go down, dodge back to drop, forward (W) to climb")
        end
    else
        local ext = ScriptUnit.has_extension(pu, "input_system") and ScriptUnit.extension(pu, "input_system")
        local mv = ext and ext:get("move")
        local fwd = mv and Vector3.y(mv) or 0
        local dodge = ext and ext:get("dodge") and true or false
        if dodge and not rappel.dodge_was and fwd < -0.3 then
            rappel.burst = 5
        end
        rappel.dodge_was = dodge
        local ds = 0
        if fwd < -0.3 then
            ds = -fwd * RAPPEL_SPEED * dt
        elseif fwd > 0.3 then
            ds = -fwd * 2 * dt
        end
        if rappel.burst > 0 then
            local b = math.min(rappel.burst, 16 * dt)
            ds, rappel.burst = ds + b, rappel.burst - b
        end
        rappel.s = math.max(rope_start, math.min(rappel.s + ds, total))
    end
    local k = 1
    while k < #w - 1 and cum[k + 1] < rappel.s do
        k = k + 1
    end
    local pos
    if #w == 1 then
        pos = w[1]:unbox()
    else
        local a, b = w[k]:unbox(), w[k + 1]:unbox()
        local len = math.max(cum[k + 1] - cum[k], 0.001)
        pos = a + (b - a) * math.min(math.max((rappel.s - cum[k]) / len, 0), 1)
    end
    PlayerMovement.teleport(player, pos, nil)
    clear_fall_speed(pu)
    local _, rbottom = rappel_points()
    local at_ground = rbottom and rappel.s > rope_start and Vector3.z(pos) <= Vector3.z(rbottom) + BASE_Z + 1.0
    if at_ground or rappel.s >= total then
        rappel = nil
        say("rappel done")
    end
end

-- ---------------------------------------------------------------------------------------------------- drawbridges
-- 0.4.5: the two AC6 drawbridges (AEG501_041) are a base unit plus two leaf units whose origin is the leaf pivot.
-- AC6 stores only the raised and lowered poses (skeleton a000_000011 vs bind pose: 50 deg about the pivot), so the
-- lowering is an even rotation over BRIDGE_SECONDS (user's choice). Collision: "up" (raised leaves) is removed when
-- lowering starts, "down" (AC6's lowered collision AEG501_040_h) is spawned when it ends.
-- Root-node rotation of a spawned unit: Unit.set_local_rotation(unit, 1, q) (area_of_effect_unit_spawner_extension.lua:120,
-- CaptainShield.lua:293); Quaternion.axis_angle(axis, radians) (hideable_ammo.lua:35).
local BRIDGE_SECONDS = 20
local BRIDGE_TRIGGER = 20    -- metres from the user's mark at the south end of each deck

local function spawn_named(name)
    local world = level_world()
    if not world or not loaded[name] then
        return nil
    end
    for _, row in ipairs(Layout.chunks) do
        if row[1] == name then
            local unit = World.spawn_unit_ex(world, UNIT_PREFIX .. name, nil, Vector3(row[2], row[3], row[4] + BASE_Z),
                Quaternion.identity())
            if unit then
                units[#units + 1] = unit
                unit_set[unit] = true
                named[name] = unit
            end
            return unit
        end
    end
    return nil
end

local function set_leaves(b, k)
    for _, leaf in ipairs(b.def.leaves) do
        local unit = named[leaf.unit]
        if unit_ok(unit) then
            local a = leaf.axis
            Unit.set_local_rotation(unit, 1, Quaternion.axis_angle(Vector3(a[1], a[2], a[3]), leaf.angle * k))
        end
    end
end

local function start_lowering(b)
    if b.state ~= "up" then
        return
    end
    b.state, b.t = "lowering", 0
    local up = named[b.def.up]
    if unit_ok(up) then
        World.destroy_unit(Unit.world(up), up)
    end
    named[b.def.up] = nil
    say("bridge %s lowering (%d s)", b.def.part, BRIDGE_SECONDS)
end

local function update_bridges(dt, here)
    for _, b in ipairs(bridges) do
        if b.state == "up" and here then
            local tr = b.def.trigger
            if (mod.bridge_auto or Vector3.length(here - Vector3(tr[1], tr[2], tr[3])) < BRIDGE_TRIGGER)
                and not (mod.bridge_locked and mod.bridge_locked()) then
                start_lowering(b)
            end
        elseif b.state == "lowering" then
            b.t = b.t + dt
            local k = math.min(b.t / BRIDGE_SECONDS, 1)
            set_leaves(b, k)
            if k >= 1 then
                b.state = "down"
                spawn_named(b.def.down)
                local gate = b.def.gate and named[b.def.gate]
                if unit_ok(gate) then
                    World.destroy_unit(Unit.world(gate), gate)
                end
                say("bridge %s down", b.def.part)
            end
        end
    end
end

-- ---------------------------------------------------------------------------------------------------- patrols
-- 0.5.0: enemy groups on the snowbank below the rappel and on the open ground before the drawbridges.
-- Minions walk on the navmesh (MinionNavigationExtension._create_nav_bot: GwNavBot.create(nav_world, ...),
-- minion_navigation_extension.lua:156) and Wallclimber is custom geometry lifted above the base level, which has no
-- navmesh there. So every position is probed first with NavQueries.position_on_mesh (nav_queries.lua:7, nav world
-- from Managers.state.nav_mesh:nav_world(), explosive_luggable.lua:23) and only positions ON a navmesh get a minion
-- (spawn call as monster_spawner/minion_spawn_manager.lua:95, villains side from side_system:get_side_from_name).
-- Zones spawn when the player comes within PATROL_ACTIVATE metres. Results are echoed and logged ("PATROL ...").
-- Extra points: /wallclimber patrol add (at your position), /wallclimber patrol clear.
local PATROL_ACTIVATE = 80
local PATROL_BREEDS = { "renegade_melee", "renegade_assault" }
local patrol_zones = nil    -- { { name, center = Vector3Box, points = { Vector3Box }, spawned = bool } }
local patrol_units = {}
local patrol_done = {}      -- zone keys already spawned this mission (survives a zone-list rebuild)
local zone_bake_queue = {}  -- 0.7.1: spawners that found no navmesh at their spot ask for a bake around themselves
local cleared_zones = {}    -- 0.7.0: spawner names whose last wave is dead (props with opens_on = name vanish)

-- 0.6.0: pins placed in the Map Viewer (Pins tab) are written to wc1_pins.lua (section-local metres):
-- path = { {x,y,z}, ... } (main path, in order), triggers = { { pos, radius, count, breeds, name }, ... }
local function load_pins()
    local ok, res = pcall(function()
        return mod:io_dofile("QIangIQsWallclimber/scripts/mods/QIangIQsWallclimber/wc1_pins")
    end)
    if not (ok and type(res) == "table") then
        return nil
    end
    return res
end

local PIN_FRAME = { scale = 0.35, center = { 1185, 1500, 1875 } }   -- the frame the Map Viewer writes pins in (wc1)
local function convert_pins(pins)
    -- 0.7.0: wc1 local -> loaded section local. Same game point, other scale/centre; radii scale with it.
    if not pins or (Layout.scale or PIN_FRAME.scale) == PIN_FRAME.scale
        and (Layout.center_game or PIN_FRAME.center)[1] == PIN_FRAME.center[1] then
        return pins
    end
    local c1, s1 = Layout.center_game, Layout.scale
    local c0, s0 = PIN_FRAME.center, PIN_FRAME.scale
    local k = s1 / s0
    local function pt(p)
        local gx, gz, gy = c0[1] + p[1] / s0, c0[3] + p[2] / s0, c0[2] + p[3] / s0
        return { (gx - c1[1]) * s1, (gz - c1[3]) * s1, (gy - c1[2]) * s1 }
    end
    local function pts(list)
        local o = {}
        for i, p in ipairs(list or {}) do
            o[i] = pt(p)
        end
        return o
    end
    local out = {}
    for key, v in pairs(pins) do
        out[key] = v
    end
    out.path = pins.path and pts(pins.path)
    local function recs(list, ptkeys, radkeys)
        if not list then
            return nil
        end
        local o = {}
        for i, r in ipairs(list) do
            local n = {}
            for key, v in pairs(r) do
                n[key] = v
            end
            for _, key in ipairs(ptkeys) do
                if r[key] then
                    n[key] = (#r[key] == 3 and type(r[key][1]) == "number") and pt(r[key]) or pts(r[key])
                end
            end
            for _, key in ipairs(radkeys) do
                if type(r[key]) == "number" then
                    n[key] = r[key] * k
                end
            end
            o[i] = n
        end
        return o
    end
    out.triggers = recs(pins.triggers, { "pos" }, { "radius" })
    out.gas = recs(pins.gas, { "pts" }, {})
    out.kills = recs(pins.kills, { "pts" }, {})
    out.pickups = recs(pins.pickups, { "pos" }, {})
    out.props = recs(pins.props, { "pos" }, {})
    return out
end

local load_pins_raw = load_pins
load_pins = function()
    return convert_pins(load_pins_raw())
end

local function build_patrol_zones()
    patrol_zones = {}
    local function zone(name, center, offsets, opts)
        local pts = {}
        for _, o in ipairs(offsets) do
            pts[#pts + 1] = Vector3Box(center + Vector3(o[1], o[2], 0))
        end
        local key = name .. "#" .. tostring(#patrol_zones + 1)
        patrol_zones[#patrol_zones + 1] = { name = name, key = key, center = Vector3Box(center), points = pts,
            spawned = patrol_done[key] or false, activate = opts and opts.activate or PATROL_ACTIVATE,
            breeds = opts and opts.breeds, cool = 0, waves = opts and opts.waves or 1,
            wave_delay = opts and opts.wave_delay or 20, wave = 0, units = {},
            boss = (opts and opts.breeds and #opts.breeds == 1 and #offsets == 1) or false }
    end
    local pins = load_pins()
    local use_defaults = not (pins and pins.triggers and #pins.triggers > 0)
    if not use_defaults then
        for i, t in ipairs(pins.triggers) do
            local n = math.max(1, t.count or 6)
            local offs = { { 0, 0 } }
            for k = 1, n - 1 do
                local a = (k / (n - 1)) * 2 * math.pi
                local sr = t.spawn_radius or t.radius * 0.5
                offs[#offs + 1] = { math.cos(a) * sr, math.sin(a) * sr }
            end
            zone(t.name or ("trigger " .. i), v3(t.pos), offs, { activate = t.radius, breeds = t.breeds, waves = t.waves,
                wave_delay = t.wave_delay })
        end
    end
    local ring = { { 0, 0 }, { 6, 4 }, { -6, 4 }, { 4, -7 }, { -5, -6 }, { 12, 0 }, { -12, 0 } }
    if use_defaults and Layout.rope and Layout.rope.landing then
        zone("snowbank", v3(Layout.rope.landing), ring)
    end
    local b1, b2 = Layout.bridges and Layout.bridges[1], Layout.bridges and Layout.bridges[2]
    if use_defaults and b1 and b2 then
        -- the plaza lies south of the decks (reference shots: x 40-200, y 280-360); the triggers are at the south ends
        local mid = (v3(b1.trigger) + v3(b2.trigger)) * 0.5
        zone("bridge plaza", mid + Vector3(0, -14, 0), { { 0, 0 }, { 20, 8 }, { -20, 8 }, { 36, -6 }, { -36, -6 }, { 10, -16 }, { -10, -16 }, { 0, 14 } })
    end
    for entry in tostring(mod:get("patrol_points") or ""):gmatch("[^;]+") do
        local p = parse_pos(entry)
        if p then
            zone("custom", p, { { 0, 0 }, { 4, 3 }, { -4, 3 } })
        end
    end
end

local function nav_world()
    local nm = Managers.state and Managers.state.nav_mesh
    local ok, nw = pcall(function() return nm and nm:nav_world() end)
    return ok and nw or nil
end

local function spawn_patrol_zone(z)
    z.wave_t = math.max(z.wave_delay or 20, 5)     -- a later wave that finds nothing to spawn on retries after this
    z.cool = 20     -- retry no sooner than this many seconds when nothing could spawn (e.g. before the navmesh bake)
    local ok, err = pcall(function()
        local NavQueries = require("scripts/utilities/nav_queries")
        local nw = nav_world()
        local side = Managers.state.extension:system("side_system"):get_side_from_name("villains")
        local minion_spawn = Managers.state.minion_spawn
        local spawned, on_mesh, total = 0, 0, #z.points
        for i, box in ipairs(z.points) do
            local lp = box:unbox()
            lp = lp + Vector3((math.random() - 0.5) * 6, (math.random() - 0.5) * 6, 0)
            local gp = ground_below(lp + Vector3(0, 0, BASE_Z + 6))
            local pos = gp and (gp + Vector3(0, 0, 0.1)) or (lp + Vector3(0, 0, BASE_Z))
            local mesh_pos = nw and NavQueries.position_on_mesh(nw, pos, 2, 2) or nil
            if mesh_pos then
                for _, o in ipairs(z.units) do
                    if unit_ok(o) and HEALTH_ALIVE[o] and Vector3.length(Unit.world_position(o, 1) - mesh_pos) < 1.5 then
                        mesh_pos = nil
                        break
                    end
                end
            end
            if mesh_pos then
                on_mesh = on_mesh + 1
                local list = (z.breeds and #z.breeds > 0) and z.breeds or PATROL_BREEDS
                local breed = list[(i % #list) + 1]
                local rot = Quaternion.look(Vector3(math.random() - 0.5, math.random() - 0.5, 0), Vector3.up())
                local unit = minion_spawn:spawn_minion(breed, mesh_pos, rot, side.side_id)
                if unit then
                    patrol_units[#patrol_units + 1] = unit
                    z.units[#z.units + 1] = unit
                    spawned = spawned + 1
                end
            end
        end
        mod:info("PATROL zone %s: ground found %s, nav_world %s, %d/%d positions on a navmesh, %d spawned", z.name,
            tostring(true), tostring(nw ~= nil), on_mesh, total, spawned)
        if on_mesh == 0 and (z.bake_n or 0) < 2 then
            z.bake_n = (z.bake_n or 0) + 1
            zone_bake_queue[#zone_bake_queue + 1] = z
        end
        if spawned > 0 then
            z.spawned = true
            z.wave = (z.wave or 0) + 1
            patrol_done[z.key] = true
            say("patrol %s: %d enemies%s", z.name, spawned, (z.waves or 1) > 1 and (" (wave %d/%d)"):format(z.wave, z.waves) or "")
        elseif not z.warned then
            z.warned = true
            say("patrol %s: no navmesh here (0/%d positions); nobody spawned. /wallclimber navmesh bakes one", z.name, total)
        end
    end)
    if not ok then
        mod:error("patrol zone %s failed: %s", z.name, tostring(err))
        say("patrol %s failed: %s", z.name, tostring(err))
    end
end

local function zone_alive(z)
    local n = 0
    for _, u in ipairs(z.units or {}) do
        if unit_ok(u) and HEALTH_ALIVE[u] then
            n = n + 1
        end
    end
    return n
end

-- 0.7.4: a one-breed trigger (boss) next to a wave stream waits until the stream has sent its last wave and is nearly dead
local function boss_blocked(z, here, dt)
    if #(z.breeds or {}) ~= 1 or #z.points ~= 1 then
        return false
    end
    local c = z.center:unbox()
    local hold = false
    for _, o in ipairs(patrol_zones) do
        if o ~= z and (o.waves or 1) > 1 and Vector3.length(Vector3.flat(o.center:unbox() - c)) < 150 then
            local running = o.spawned and not ((o.wave or 0) >= o.waves and zone_alive(o) <= 2)
            local starting = (not o.spawned) and here and Vector3.length(here - o.center:unbox()) < o.activate * 1.2
            if running or starting then
                hold = true
            end
        end
    end
    if hold then
        z.held = (z.held or 0) + (dt or 0)
        if z.held < 15 then
            return true
        end
    end
    return false
end

-- 0.7.4: the runtime navmesh is a patchwork, so minions far from the players often have no route and stand still (waves
-- of gunners piling up, the beast "stuck", 2026-10-18). Zone minions that have not moved for NUDGE_STILL seconds while a
-- player is NUDGE_MIN..NUDGE_MAX m away are teleported NUDGE_STEP m toward that player onto the navmesh. Option
-- "nudge_stuck" = false turns it off.
local NUDGE_EVERY, NUDGE_STILL, NUDGE_MIN, NUDGE_MAX, NUDGE_STEP = 2.5, 5, 30, 160, 22
local nudge_t = 0
local nudge_last = setmetatable({}, { __mode = "k" })

local function nudge_stuck(dt)
    nudge_t = nudge_t - dt
    if nudge_t > 0 or mod:get("nudge_stuck") == false then
        return
    end
    nudge_t = NUDGE_EVERY
    local ok, err = pcall(function()
        local NavQueries = require("scripts/utilities/nav_queries")
        local nw = nav_world()
        if not nw then
            return
        end
        local ppos = {}
        for _, player in pairs(Managers.player:human_players()) do
            local pu = player.player_unit
            if unit_ok(pu) then
                ppos[#ppos + 1] = Unit.world_position(pu, 1)
            end
        end
        if #ppos == 0 then
            return
        end
        local moved_n = 0
        for _, z in ipairs(patrol_zones or {}) do
            for _, u in ipairs(z.units or {}) do
                if unit_ok(u) and HEALTH_ALIVE[u] then
                    local p = Unit.world_position(u, 1)
                    if z.boss or (z.waves or 1) > 1 then
                        local pe = ScriptUnit.has_extension(u, "perception_system")
                        if pe and pe.aggro_state and pe:aggro_state() ~= "aggroed" then
                            pe:aggro()
                        end
                    end
                    local best, bd = nil, math.huge
                    for _, q in ipairs(ppos) do
                        local d = Vector3.length(Vector3.flat(q - p))
                        if d < bd then
                            best, bd = q, d
                        end
                    end
                    local rec = nudge_last[u]
                    if not rec then
                        rec = { pos = Vector3Box(p), still = 0 }
                        nudge_last[u] = rec
                    end
                    local moved = Vector3.length(p - rec.pos:unbox())
                    rec.pos:store(p)
                    if moved < 1 and bd > NUDGE_MIN and bd < (z.boss and 400 or NUDGE_MAX) then
                        rec.still = rec.still + NUDGE_EVERY
                    else
                        rec.still = 0
                    end
                    if rec.still >= NUDGE_STILL then
                        rec.still = 0
                        local dir = Vector3.normalize(Vector3.flat(best - p))
                        local target = p + dir * math.min(z.boss and 32 or NUDGE_STEP, bd - NUDGE_MIN)
                        local mp = NavQueries.position_on_mesh(nw, target, 12, 12)
                        local loco = mp and ScriptUnit.has_extension(u, "locomotion_system")
                        if loco then
                            loco:teleport_to(mp, Quaternion.look(dir, Vector3.up()))
                            moved_n = moved_n + 1
                        end
                    end
                end
            end
        end
        if moved_n > 0 then
            mod:info("NUDGE moved %d stuck minion(s) toward the players", moved_n)
        end
    end)
    if not ok then
        mod:error("nudge failed: %s", tostring(err))
    end
end

local function update_patrols(here, dt)
    if not here or mod:get("patrols") == false then
        return
    end
    if not patrol_zones then
        build_patrol_zones()
    end
    for _, z in ipairs(patrol_zones) do
        if not z.spawned then
            z.cool = math.max(0, (z.cool or 0) - dt)
            local dz = Vector3.length(here - z.center:unbox())
            if dz < z.activate then
                z.pending = true
            end
            if z.cool <= 0 and (dz < z.activate or (z.pending and z.boss and dz < z.activate * 3))
                and not boss_blocked(z, here, dt) then
                spawn_patrol_zone(z)
            end
        elseif (z.waves or 1) > (z.wave or 1) then
            -- 0.7.0 waves: the next group comes after wave_delay seconds while a player is near, unless the zone
            -- already holds 3x its group size (a stream, not a flood)
            z.wave_t = (z.wave_t or 0) - dt
            if z.wave_t <= 0 then
                if Vector3.length(here - z.center:unbox()) < z.activate * 2 and zone_alive(z) < #z.points * 3 then
                    spawn_patrol_zone(z)
                else
                    z.wave_t = 3
                end
            end
        end
        if z.spawned and not z.cleared and (z.wave or 1) >= (z.waves or 1) and zone_alive(z) == 0 then
            z.cleared = true
            cleared_zones[z.name] = true
            say("spawner %s cleared", z.name)
        end
    end
    nudge_stuck(dt)
end

-- ---------------------------------------------------------------------------------------------------- pox gas
-- 0.6.2: permanent pox gas inside polygons drawn in the Map Viewer (Pins tab, "Pox gas"), built like the game's own
-- Toxic Gas circumstance (mutator_toxic_gas_volumes.lua): a volumetric fog unit plus a liquid area with the
-- LiquidAreaTemplates.toxic_gas template (life_time 99999, buff in_toxic_gas, gas particles per cell,
-- minion_liquid_area_templates.lua:72).
--   * Damage and gas particles: the liquid is PAINTED cell by cell over the polygon (LiquidArea.start_paint / paint,
--     liquid_area.lua:48; LiquidAreaExtension.paint_liquid_at fills the cell under the point plus the ring around it, as
--     the flamer gas does), so the gas has exactly the polygon's outline instead of flowing out over the navmesh. It
--     needs the baked navmesh under it; points without one are skipped and the zone retries every 10 s.
--   * Fog: the prop "toxic_fog_volume" (level_props/props/toxic_gas_volume.lua, unit
--     content/environment/volumetrics/toxic_fog_volume, in packages/boot_assets) spawned with the "level_prop" unit
--     template (breach_charge_addon.lua:64 pattern), then ToxicGasFog:set_volume_enabled(true) like the mutator does
--     (mutator_toxic_gas_volumes.lua:103). Level designers place these at scale 1, roughly 10 m apart, so they are tiled
--     over the polygon (at most GAS_FOG_MAX per polygon).
local GAS_PAINT_STEP = 2
local GAS_PAINT_PER_UPDATE = 40
local GAS_PAINT_JOIN = 14
local GAS_FOG_STEP = 9
local GAS_FOG_MAX = 40
local GAS_ACTIVATE_EXTRA = 70   -- start filling a zone when you are within its radius + this
local gas_zones = nil
local gas_units = {}

local function poly_contains(poly, x, y)
    local inside, j = false, #poly
    for i = 1, #poly do
        local xi, yi, xj, yj = poly[i][1], poly[i][2], poly[j][1], poly[j][2]
        if (yi > y) ~= (yj > y) and x < (xj - xi) * (y - yi) / (yj - yi) + xi then
            inside = not inside
        end
        j = i
    end
    return inside
end

local function poly_grid(poly, step, offset)
    local minx, miny, maxx, maxy = math.huge, math.huge, -math.huge, -math.huge
    for _, q in ipairs(poly) do
        minx, miny, maxx, maxy = math.min(minx, q[1]), math.min(miny, q[2]), math.max(maxx, q[1]), math.max(maxy, q[2])
    end
    local out = {}
    local x = minx + offset
    while x <= maxx do
        local y = miny + offset
        while y <= maxy do
            if poly_contains(poly, x, y) then
                out[#out + 1] = { x, y }
            end
            y = y + step
        end
        x = x + step
    end
    return out, (maxx - minx) * (maxy - miny)
end

-- 0.6.2 fix: a polygon on a slope has no single height. The old ray started at the polygon's average height + 6 m,
-- which on the uphill side lies underneath the ground, so the points there found nothing (gas 1 on the snow slope).
-- The start height is now interpolated from the polygon's corners (inverse distance) and the ray starts 25 m above it.
local function gas_ground(pts, x, y)
    local wsum, zsum = 0, 0
    for _, q in ipairs(pts) do
        local w = 1 / (((q[1] - x) ^ 2 + (q[2] - y) ^ 2) + 1)
        wsum, zsum = wsum + w, zsum + w * q[3]
    end
    local zi = zsum / wsum
    local gp = ground_below(Vector3(x, y, zi + BASE_Z + 25))
    return gp, zi
end

local function build_gas_zones()
    gas_zones = {}
    local pins = load_pins()
    for i, g in ipairs(pins and pins.gas or {}) do
        if g.pts and #g.pts >= 3 then
            local minx, miny, maxx, maxy, zsum = math.huge, math.huge, -math.huge, -math.huge, 0
            for _, q in ipairs(g.pts) do
                minx, miny, maxx, maxy = math.min(minx, q[1]), math.min(miny, q[2]), math.max(maxx, q[1]), math.max(maxy, q[2])
                zsum = zsum + q[3]
            end
            local cx, cy, cz = (minx + maxx) / 2, (miny + maxy) / 2, zsum / #g.pts
            local radius = 0
            for _, q in ipairs(g.pts) do
                radius = math.max(radius, math.sqrt((q[1] - cx) ^ 2 + (q[2] - cy) ^ 2))
            end
            local paint = poly_grid(g.pts, GAS_PAINT_STEP, GAS_PAINT_STEP / 2)
            local _, area = poly_grid(g.pts, 1000, 0)
            local fog_step = math.max(GAS_FOG_STEP, math.sqrt(math.max(area, 1) / GAS_FOG_MAX))
            local fog = poly_grid(g.pts, fog_step, fog_step / 2)
            if #fog == 0 then
                fog = { { cx, cy } }
            end
            gas_zones[#gas_zones + 1] = { name = g.name or ("gas " .. i), center = Vector3Box(Vector3(cx, cy, cz)), radius = radius,
                z = cz, pts = g.pts, paint = paint, paint_i = 1, painted = 0, fog = fog, fog_done = false, cool = 0 }
        end
    end
end

local function spawn_gas_fog(z)
    z.fog_done = true
    local ok, err = pcall(function()
        local LevelProps = require("scripts/settings/level_prop/level_props")
        local Component = require("scripts/utilities/component")
        local settings = LevelProps.toxic_fog_volume
        local made, enabled = 0, 0
        for _, p in ipairs(z.fog) do
            local gp, zi = gas_ground(z.pts, p[1], p[2])
            local pos = gp or Vector3(p[1], p[2], zi + BASE_Z)
            local rot = Quaternion.axis_angle(Vector3.up(), math.random() * 2 * math.pi)
            local unit = Managers.state.unit_spawner:spawn_network_unit(settings.unit_name, "level_prop", pos, rot, nil, settings)
            if unit then
                made = made + 1
                gas_units[#gas_units + 1] = unit
                for _, comp in ipairs(Component.get_components_by_name(unit, "ToxicGasFog")) do
                    comp:set_volume_enabled(true)
                    enabled = enabled + 1
                end
            end
        end
        mod:info("GAS zone %s: %d fog units, %d fog components enabled", z.name, made, enabled)
    end)
    if not ok then
        mod:error("gas fog %s failed: %s", z.name, tostring(err))
    end
end

-- 0.7.2: the whole polygon cannot be painted at once: liquid needs a navmesh under each cell and the auto bake only
-- covers the area around the player (gas 1 painted 617 of 86598 points, gas 2 none, 2026-10-18). Cells are now painted
-- when a player is within GAS_PAINT_NEAR m of them and re-tried after every bake (bake_epoch); a pass that painted
-- nothing sleeps 8 s, one that painted something continues after 2 s.
local GAS_PAINT_NEAR = 90
local bake_epoch = 0

local function paint_gas(z, here)
    local ok, err = pcall(function()
        local LiquidArea = require("scripts/extension_systems/liquid_area/utilities/liquid_area")
        local Templates = require("scripts/settings/liquid_area/liquid_area_templates")
        local nw = nav_world()
        if not nw then
            return
        end
        z.paint_id = z.paint_id or LiquidArea.start_paint()
        z.done = z.done or {}
        if z.epoch ~= bake_epoch then
            z.epoch, z.pass_hits = bake_epoch, 0
        end
        local n = #z.paint
        local hx, hy = Vector3.x(here), Vector3.y(here)
        local near2 = GAS_PAINT_NEAR * GAS_PAINT_NEAR
        for _ = 1, GAS_PAINT_PER_UPDATE do
            local idx = z.paint_i
            local p = z.paint[idx]
            if p and not z.done[idx] and (p[1] - hx) ^ 2 + (p[2] - hy) ^ 2 < near2 then
                local gp = gas_ground(z.pts, p[1], p[2])
                local unit = gp and LiquidArea.paint(z.paint_id, GAS_PAINT_JOIN, gp + Vector3(0, 0, 0.1), nw, Templates.toxic_gas, true, 1)
                if unit then
                    z.done[idx] = true
                    z.painted = z.painted + 1
                    z.pass_hits = (z.pass_hits or 0) + 1
                    z.units = z.units or {}
                    if not z.units[unit] then
                        z.units[unit] = true
                        gas_units[#gas_units + 1] = unit
                    end
                end
            end
            z.paint_i = idx + 1
            if z.paint_i > n then
                z.paint_i = 1
                if (z.pass_hits or 0) == 0 then
                    z.cool = 8
                    if z.painted == 0 and not z.warned then
                        z.warned = true
                        say("pox gas %s: no navmesh near you yet; it fills in as the navmesh is baked", z.name)
                    end
                else
                    z.cool = 2
                    if not z.said then
                        z.said = true
                        say("pox gas %s: filling (%d cells so far)", z.name, z.painted)
                    end
                    mod:info("GAS zone %s: %d cells painted so far", z.name, z.painted)
                end
                z.pass_hits = 0
                break
            end
        end
    end)
    if not ok then
        mod:error("gas zone %s failed: %s", z.name, tostring(err))
        z.cool = 30
    end
end

local function update_gas(here, dt)
    if not here or mod:get("pox_gas") == false then
        return
    end
    if not gas_zones then
        build_gas_zones()
    end
    for _, z in ipairs(gas_zones) do
        z.cool = math.max(0, z.cool - dt)
        if z.cool <= 0 and Vector3.length(here - z.center:unbox()) < z.radius + GAS_ACTIVATE_EXTRA then
            if not z.fog_done then
                spawn_gas_fog(z)
            end
            paint_gas(z, here)
        end
    end
end

-- ---------------------------------------------------------------------------------------------------- navmesh bake
-- 0.6.0: "/wallclimber navmesh" bakes a navmesh over the Wallclimber geometry around the pins (or the default patrol
-- zones), with the same calls the game makes for Expedition levels (bake_navmesh.lua push_units/generate,
-- expedition_spawner.lua:29 navgen_settings, :598 completion, :646 start): GwNavGeneration.create, reset_current_navtag,
-- push_unit_meshes (physics mesh), push_seed_point, generate_async with nav_mesh:set_async_paused(true), then
-- finish_async_generation each frame, GwNavData.is_alive_in_database, nav_mesh:_make_sparse_graph_dirty().
-- Only chunk units near a pin/zone are pushed (the whole map would be far too slow). Run it standing on Wallclimber
-- ground after the map is built; once done, enemies in range spawn on the new navmesh.
local BAKE_RADIUS = 45
local handoff_hold = false  -- 0.7.4: set near the section line; no new bakes, so the swap never meets a running one
local navbake = nil         -- { job_id, t, data }
local bake_tiles = {}       -- 0.6.2: auto bake, tiles ("ix:iy") already baked or queued

local function bake_points()
    local pts, pins = {}, load_pins()
    if pins and ((pins.path and #pins.path > 0) or (pins.triggers and #pins.triggers > 0) or (pins.gas and #pins.gas > 0)) then
        for _, p in ipairs(pins.path or {}) do
            pts[#pts + 1] = v3(p)
        end
        for _, g in ipairs(pins.gas or {}) do
            if g.pts and #g.pts >= 3 then
                local zsum = 0
                for _, q in ipairs(g.pts) do
                    pts[#pts + 1] = v3(q)
                    zsum = zsum + q[3]
                end
                for _, q in ipairs(poly_grid(g.pts, 25, 12)) do
                    pts[#pts + 1] = Vector3(q[1], q[2], zsum / #g.pts)
                end
            end
        end
        for _, t in ipairs(pins.triggers or {}) do
            pts[#pts + 1] = v3(t.pos)
        end
    else
        if not patrol_zones then
            build_patrol_zones()
        end
        for _, z in ipairs(patrol_zones) do
            pts[#pts + 1] = z.center:unbox()
        end
    end
    return pts
end

local function finish_navbake(msg)
    pcall(function() Managers.state.nav_mesh:set_async_paused(false) end)
    navbake = nil
    say("%s", msg)
end

local function start_navbake(opts)
    if navbake then
        say("navmesh bake already running")
        return
    end
    local ok, err = pcall(function()
        local Gen = rawget(_G, "GwNavGeneration")
        if not Gen then
            error("GwNavGeneration is not available in this game build")
        end
        local world, nw = level_world(), nav_world()
        if not (world and nw and #units > 0) then
            error("build the map first (nav world: " .. tostring(nw ~= nil) .. ", units: " .. #units .. ")")
        end
        local pts = opts and opts.pts or bake_points()
        local pu = player_unit()
        local nav_gen = Gen.create(world)
        local pushed = 0
        for _, row in ipairs(Layout.chunks) do
            local name, unit = row[1], named[row[1]]
            if unit_ok(unit) and not name:find("rope") and not name:find("spool") and not name:find("_br") then
                local bok, pose, extents = pcall(Unit.box, unit)
                if bok and extents then
                    local c = to_local(Matrix4x4.translation(pose))
                    local ex, ey, ez = Vector3.to_elements(extents)
                    local r = math.max(ex, ey, ez)
                    for _, p in ipairs(pts) do
                        local dx, dy = Vector3.x(c) - Vector3.x(p), Vector3.y(c) - Vector3.y(p)
                        if math.sqrt(dx * dx + dy * dy) < BAKE_RADIUS + r then
                            Gen.reset_current_navtag(nav_gen)
                            Gen.push_unit_meshes(nav_gen, unit, true, false, true)
                            pushed = pushed + 1
                            break
                        end
                    end
                end
            end
        end
        if pushed == 0 then
            Gen.destroy(nav_gen)
            for _, k in ipairs(opts and opts.keys or {}) do
                bake_tiles[k] = true
            end
            error("no Wallclimber chunk within " .. BAKE_RADIUS .. " m of the pins/zones")
        end
        if pu then
            Gen.push_seed_point(nav_gen, Unit.local_position(pu, 1))
        end
        for _, p in ipairs(pts) do
            local gp = ground_below(p + Vector3(0, 0, BASE_Z + 6))
            if gp then
                Gen.push_seed_point(nav_gen, gp)
            end
        end
        local settings = {
            altitude_tolerance = 0.5, atomic_consume_units = true, cell_size = 3, consume_terrain = true,
            database_index = 0, entity_height = 1.6, entity_radius = 0.38, height_field_sampling = 1,
            min_navigable_surface = 0.5, output_type = 1, raster_precision = 0.1, sector_name = "world",
            slope_max = 60, step_max = 0.5, sector_id = math.uuid(),
        }
        Managers.state.nav_mesh:set_async_paused(true)
        local job_id = Gen.generate_async(nav_gen, nw, settings, { [math.uuid()] = "WallclimberNav" })
        Gen.destroy(nav_gen)
        for _, k in ipairs(opts and opts.keys or {}) do
            bake_tiles[k] = true
        end
        navbake = { job_id = job_id, t = 0 }
        mod:info("NAVBAKE started: %d chunk units, %d region points", pushed, #pts)
        say("navmesh bake started: %d chunk units around %d points (a few seconds to a minute)", pushed, #pts)
    end)
    if not ok then
        mod:error("navmesh bake failed to start: %s", tostring(err))
        pcall(function() Managers.state.nav_mesh:set_async_paused(false) end)
        say("navmesh bake failed: %s", tostring(err))
    end
end

local function update_navbake(dt)
    if not navbake then
        return
    end
    navbake.t = navbake.t + dt
    if navbake.t > 180 then
        finish_navbake("navmesh bake gave up after 180 s")
        return
    end
    local ok, err = pcall(function()
        if not navbake.data then
            local done, navmesh = GwNavGeneration.finish_async_generation(nav_world(), navbake.job_id)
            if done then
                navbake.data = navmesh
            end
        end
        if navbake.data and GwNavData.is_alive_in_database(navbake.data) then
            local t = navbake.t
            Managers.state.nav_mesh:_make_sparse_graph_dirty()
            for _, z in ipairs(patrol_zones or {}) do
                z.cool, z.warned = 0, false
            end
            bake_epoch = bake_epoch + 1
            mod:info("NAVBAKE done in %.1f s", t)
            finish_navbake(string.format("navmesh ready (%.0f s); enemies spawn when you are in range", t))
        end
    end)
    if not ok then
        mod:error("navmesh bake failed: %s", tostring(err))
        finish_navbake("navmesh bake failed: " .. tostring(err))
    end
end

-- 0.6.2: automatic navmesh. The navmesh is baked from the chunk units near the given points, so instead of typing
-- "/wallclimber navmesh" every few metres, the map is cut into AUTO_TILE squares and every square within AUTO_RADIUS of
-- the player that has not been baked yet is baked in one go as soon as the player gets within AUTO_TRIGGER of an
-- unbaked square (so a new bake starts well before the edge of the old one). One bake at a time; "auto_navmesh" = false
-- in the mod options turns it off.
local AUTO_TILE = 40
local AUTO_RADIUS = 140
local AUTO_TRIGGER = 90
local auto_bake_t = 3

local function auto_navbake(here, dt)
    if navbake or handoff_hold or not here or mod:get("auto_navmesh") == false or mod:get("patrols") == false and mod:get("pox_gas") == false then
        return
    end
    auto_bake_t = auto_bake_t - dt
    if auto_bake_t > 0 then
        return
    end
    auto_bake_t = 1
    local hx, hy = Vector3.x(here), Vector3.y(here)
    local cx, cy = math.floor(hx / AUTO_TILE), math.floor(hy / AUTO_TILE)
    local n = math.ceil(AUTO_RADIUS / AUTO_TILE)
    local pts, keys, nearest = {}, {}, math.huge
    for ix = cx - n, cx + n do
        for iy = cy - n, cy + n do
            local key = ix .. ":" .. iy
            if not bake_tiles[key] then
                local tx, ty = (ix + 0.5) * AUTO_TILE, (iy + 0.5) * AUTO_TILE
                local d = math.sqrt((tx - hx) ^ 2 + (ty - hy) ^ 2)
                if d < AUTO_RADIUS then
                    pts[#pts + 1] = Vector3(tx, ty, Vector3.z(here))
                    keys[#keys + 1] = key
                    nearest = math.min(nearest, d)
                end
            end
        end
    end
    if #pts > 0 and nearest < AUTO_TRIGGER then
        auto_bake_t = 8
        start_navbake({ pts = pts, keys = keys })
    end
end

-- ---------------------------------------------------------------------------------------------------- per frame
local rescue_t = 0
local EDGE_MARGIN = 12      -- metres inside the section box (half extent ~449.8 m; soft out-of-bounds ~460 m)
local last_safe = nil       -- Vector3Box: last position inside the section
local edge_t = 0
-- ---------------------------------------------------------------------------------------------------- mission pins
-- 0.7.0: pins from the Map Viewer that turn the map into a mission (wc1_pins.lua, section-local metres):
--   kills   = { { name, pts = { {x,y,z}... } } }   instakill polygon: a player inside it (from 5 m below the lowest corner
--             to 12 m above the highest) dies like in a level kill volume (volume_event_functions.lua player_instakill:
--             PlayerDeath.die + Attack.execute with kill_volume_and_off_navmesh). This mod makes players unkillable so a
--             fall cannot fail the mission (is_unkillable); then the box sends them back to the nearest main-path pin
--             outside every box instead. Setting "kill_boxes" = false disables it.
--   pickups = { { pos, pickup, yaw } }              pickup_system:spawn_pickup(name, pos, rot) (pickup_system.lua:944) once, when
--             a player comes within PICKUP_ACTIVATE m. Chests are the *_crate / *_pocketable pickups.
--   props   = { { pos, unit, yaw, scale, opens_on } } any unit path the game has loaded (Application.can_get_resource);
--             opens_on = a spawner name: the prop (a gate) is destroyed once that spawner's last wave is dead.
local PICKUP_ACTIVATE = 90
local PROP_ACTIVATE = 160
local mission = nil
local mission_units = {}
local mission_net = {}   -- 0.7.7: mission units spawned through the pickup system (network units)

local function delete_net_unit(u)
    local ok = pcall(function()
        Managers.state.unit_spawner:mark_for_deletion(u)
    end)
    return ok
end

local function is_server()
    local gs = Managers.state and Managers.state.game_session
    if not gs then
        return true
    end
    local ok, res = pcall(gs.is_server, gs)
    return not ok or res ~= false
end

local function build_mission()
    local pins = load_pins() or {}
    local m = { kills = {}, pickups = {}, props = {}, kill_t = 0, path = pins.path or {} }
    for _, k in ipairs(pins.kills or {}) do
        if k.pts and #k.pts >= 3 then
            local zmin, zmax, cx, cy = math.huge, -math.huge, 0, 0
            for _, q in ipairs(k.pts) do
                zmin, zmax = math.min(zmin, q[3]), math.max(zmax, q[3])
                cx, cy = cx + q[1] / #k.pts, cy + q[2] / #k.pts
            end
            m.kills[#m.kills + 1] = { name = k.name or "kill", pts = k.pts, zmin = zmin - 5, zmax = zmax + 12, cx = cx, cy = cy }
        end
    end
    for _, p in ipairs(pins.pickups or {}) do
        m.pickups[#m.pickups + 1] = { def = p, done = false, cool = 0 }
        if tostring(p.pickup):find("luggable") then
            m.obj = m.obj or { done = false, placed = false, said = 0, chk = 0 }
        end
    end
    for _, p in ipairs(pins.props or {}) do
        m.props[#m.props + 1] = { def = p, unit = nil, gone = false, cool = 0 }
    end
    return m
end

local function in_kill_box(m, x, y, z)
    for _, k in ipairs(m.kills) do
        if z >= k.zmin and z <= k.zmax and poly_contains(k.pts, x, y) then
            return true
        end
    end
    return false
end

local function kill_player(m, player, unit)
    local ok, err = pcall(function()
        local health = ScriptUnit.has_extension(unit, "health_system")
        if health and health:is_unkillable() then
            -- nearest main-path pin that is not inside a kill box
            local here = to_local(Unit.world_position(unit, 1))
            local best, bd = nil, math.huge
            for _, p in ipairs(m.path) do
                if not in_kill_box(m, p[1], p[2], p[3]) then
                    local d = Vector3.length(Vector3(p[1], p[2], p[3]) - here)
                    if d < bd then
                        best, bd = p, d
                    end
                end
            end
            local dest = best or Layout.safe_start or Layout.start
            local ground = ground_below(Vector3(dest[1], dest[2], dest[3] + BASE_Z + 6))
            local pos = ground and (ground + Vector3(0, 0, 0.2)) or Vector3(dest[1], dest[2], dest[3] + BASE_Z + 0.5)
            PlayerMovement.teleport(player, pos, nil)
            clear_fall_speed(unit)
            return
        end
        local PlayerDeath = require("scripts/utilities/player_death")
        local Attack = require("scripts/utilities/attack/attack")
        local DamageProfileTemplates = require("scripts/settings/damage/damage_profile_templates")
        PlayerDeath.die(unit, nil, nil, "kill_volume")
        Attack.execute(unit, DamageProfileTemplates.kill_volume_and_off_navmesh, "instakill", true, "attack_direction",
            Vector3.down())
    end)
    if not ok then
        mod:error("kill box failed: %s", tostring(err))
    end
end

-- 0.7.1: the auto bake only covers tiles near the player, so a spawner further away (boss, hangar door stream) found
-- 0/N positions on a navmesh (2026-10-18 test). It now queues a bake around its own points; update_navbake resets every
-- zone's retry timer when a bake finishes, so the spawn follows.
local function process_zone_bakes()
    if navbake or handoff_hold or #zone_bake_queue == 0 then
        return
    end
    local z = table.remove(zone_bake_queue, 1)
    local pts = { z.center:unbox() }
    for _, b in ipairs(z.points) do
        pts[#pts + 1] = b:unbox()
    end
    mod:info("NAVBAKE requested by spawner %s", tostring(z.name))
    start_navbake({ pts = pts })
end

-- 0.7.5: forced interaction near the hangar: a luggable pickup pin (battery_01_luggable) is the "power cell"; a player
-- carrying it (inventory wielded_slot slot_luggable) within 12 m of the hangar door zone completes the objective. The
-- section swap waits for it (only when the cell was actually placed).
-- 0.7.8: the power cell has a real socket: the game's own luggable socket prop (level_props.luggable_socket, unit
-- socket_luggable_battery_01, the one the expedition/level sockets use) is spawned at the hangar door with the
-- "level_prop" template; its interactee extension gives the normal "insert" prompt, LuggableSocketExtension.is_occupied
-- tells us it is done. World markers ("objective" template, same call the objective system uses) point at the cell and the
-- socket. If the socket unit is not loaded the old rule applies: carry the cell within 12 m of the door.
local function mark_unit(unit)
    local holder = {}
    pcall(function()
        Managers.event:trigger("add_world_marker_unit", "objective", unit, function(marker_id)
            holder.id = marker_id
        end, { ui_target_type = "default" })
    end)
    return holder
end

local function unmark(holder)
    if holder and holder.id then
        pcall(function()
            Managers.event:trigger("remove_world_marker", holder.id)
        end)
        holder.id = nil
    end
end

local function finish_objective(o)
    o.done = true
    cleared_zones["objective"] = true
    unmark(o.sock_mark)
    unmark(o.item_mark)
    say("objective complete: the hangar door is powered")
end

local SOCKET_UNIT = "content/environment/gameplay/luggable_sockets/socket_luggable_battery_01"
local CELL_UNIT = "content/pickups/luggables/battery_01/luggable_battery_01"
local SOCKET_RANGE = 3.2
local SOCKET_HOLD = 1.5

local function insert_cell(o, player, pu)
    pcall(function()
        local PlayerUnitVisualLoadout = require("scripts/extension_systems/visual_loadout/utilities/player_unit_visual_loadout")
        local inv = ScriptUnit.extension(pu, "unit_data_system"):read_component("inventory")
        local t = Managers.time:time("gameplay")
        PlayerUnitVisualLoadout.unequip_item_from_slot(pu, "slot_luggable", t)
        PlayerUnitVisualLoadout.wield_previous_weapon_slot(inv, pu, t)
    end)
    pcall(function()
        local world = level_world()
        local sp = Unit.world_position(o.socket, 1)
        if world and Application.can_get_resource("unit", CELL_UNIT) then
            local cell = World.spawn_unit_ex(world, CELL_UNIT, nil, sp + Vector3(0, 0, 0.45), Unit.world_rotation(o.socket, 1))
            pcall(Unit.disable_physics, cell)
            mission_units[#mission_units + 1] = cell
        end
    end)
end

local function update_objective(m, dt)
    local o = m.obj
    if not o or o.done then
        return
    end
    o.chk = o.chk - dt
    if o.chk > 0 then
        return
    end
    o.chk = 0.5
    local door
    for _, z in ipairs(patrol_zones or {}) do
        if z.name:find("hangar door", 1, true) then
            door = z.center:unbox()
            break
        end
    end
    if not door then
        return
    end
    local near, carried_at_door = math.huge, false
    local at_socket, socket_player, socket_pu = false, nil, nil
    local sp = o.socket and unit_ok(o.socket) and Unit.world_position(o.socket, 1) or nil
    pcall(function()
        for _, player in pairs(Managers.player:human_players()) do
            local pu = player.player_unit
            if unit_ok(pu) then
                local pw = Unit.world_position(pu, 1)
                near = math.min(near, Vector3.length(Vector3.flat(pw - door)))
                local ude = ScriptUnit.has_extension(pu, "unit_data_system")
                local inv = ude and ude:read_component("inventory")
                local carrying = inv and inv.wielded_slot == "slot_luggable"
                if carrying and Vector3.length(Vector3.flat(pw - door)) < 12 then
                    carried_at_door = true
                end
                if carrying and sp and Vector3.length(Vector3.flat(pw - sp)) < SOCKET_RANGE and math.abs(Vector3.z(pw) - Vector3.z(sp)) < 3 then
                    at_socket, socket_player, socket_pu = true, player, pu
                end
            end
        end
    end)
    if o.item and not o.item_mark and unit_ok(o.item) then
        o.item_mark = mark_unit(o.item)
    end
    if not o.socket and not o.sock_fail and near < 160 then
        local ok, err = pcall(function()
            local world = level_world()
            if not (world and Application.can_get_resource("unit", SOCKET_UNIT)) then
                error("socket unit is not loaded in this mission")
            end
            local gp = ground_below(door + Vector3(0, 0, BASE_Z + 6))
            local pos = gp or (door + Vector3(0, 0, BASE_Z))
            local unit = World.spawn_unit_ex(world, SOCKET_UNIT, nil, pos + Vector3(0, 0, 0.1), Quaternion.identity())
            if not unit then
                error("spawn returned nothing")
            end
            pcall(Unit.set_visibility, unit, "main", true)
            o.socket = unit
            mission_units[#mission_units + 1] = unit
            o.sock_mark = mark_unit(unit)
            mod:info("OBJECTIVE socket placed")
            say("objective: take the power cell to the socket at the hangar door and stand at it for a moment")
        end)
        if not ok then
            o.sock_fail = true
            mod:error("socket failed: %s", tostring(err))
            say("no socket available (%s); carry the power cell to the hangar door instead", tostring(err))
        end
    end
    if o.socket and not unit_ok(o.socket) then
        o.socket, o.sock_fail = nil, true
    end
    if o.socket then
        if at_socket and is_server() then
            o.hold = (o.hold or 0) + 0.5
            if o.hold == 0.5 then
                say("inserting the power cell... stay at the socket")
            end
            if o.hold >= SOCKET_HOLD then
                insert_cell(o, socket_player, socket_pu)
                finish_objective(o)
            end
        else
            o.hold = 0
        end
    elseif o.sock_fail and carried_at_door then
        finish_objective(o)
    end
end

mod.bridge_locked = function()
    local o = mission and mission.obj
    return o ~= nil and o.placed == true and not o.done
end

local function update_mission(here, dt)
    if not here then
        return
    end
    if not mission then
        mission = build_mission()
        mod:info("MISSION pins: %d kill boxes, %d pickups, %d props", #mission.kills, #mission.pickups, #mission.props)
    end
    local m = mission
    update_objective(m, dt)
    local server = is_server()
    if server and #m.pickups > 0 then
        for _, p in ipairs(m.pickups) do
            if not p.done then
                p.cool = math.max(0, p.cool - dt)
                local d = p.def
                local lp = Vector3(d.pos[1], d.pos[2], d.pos[3])
                if p.cool <= 0 and Vector3.length(here - lp) < PICKUP_ACTIVATE then
                    p.cool = 10
                    local ok, err = pcall(function()
                        local sys = Managers.state.extension:system("pickup_system")
                        local gp = ground_below(lp + Vector3(0, 0, BASE_Z + 6))
                        local pos = gp and (gp + Vector3(0, 0, 0.25)) or (lp + Vector3(0, 0, BASE_Z + 0.5))
                        local rot = Quaternion(Vector3.up(), math.rad(d.yaw or 0))
                        local unit = sys:spawn_pickup(d.pickup, pos, rot)
                        if unit then
                            p.done = true
                            mission_units[#mission_units + 1] = unit
                            mission_net[unit] = true
                            mod:info("MISSION pickup %s placed", tostring(d.pickup))
                            if m.obj and tostring(d.pickup):find("luggable") then
                                m.obj.placed = true
                                m.obj.item = unit
                                say("objective: carry the power cell to the hangar door")
                            end
                        end
                    end)
                    if not ok then
                        p.done = true
                        mod:error("pickup %s failed: %s", tostring(d.pickup), tostring(err))
                        say("pickup %s failed (see log)", tostring(d.pickup))
                    end
                end
            end
        end
    end
    for _, p in ipairs(m.props) do
        local d = p.def
        if p.unit and not unit_ok(p.unit) then
            p.unit, p.gone = nil, true
        end
        if not p.gone and not p.unit then
            local lp = Vector3(d.pos[1], d.pos[2], d.pos[3])
            p.cool = math.max(0, p.cool - dt)
            if p.cool <= 0 and Vector3.length(here - lp) < PROP_ACTIVATE and not (d.opens_on ~= "" and cleared_zones[d.opens_on]) then
                p.cool = 15
                local world = level_world()
                if world and Application.can_get_resource and Application.can_get_resource("unit", d.unit) then
                    local ok, unit = pcall(World.spawn_unit_ex, world, d.unit, nil, lp + Vector3(0, 0, BASE_Z),
                        Quaternion(Vector3.up(), math.rad(d.yaw or 0)))
                    if ok and unit then
                        if (d.scale or 1) ~= 1 then
                            Unit.set_local_scale(unit, 1, Vector3(d.scale, d.scale, d.scale))
                        end
                        p.unit = unit
                        mission_units[#mission_units + 1] = unit
                    end
                elseif not p.warned then
                    p.warned = true
                    say("prop %s: the game has not loaded that unit (or the path is wrong)", tostring(d.unit))
                    mod:warning("MISSION prop unit not available: %s", tostring(d.unit))
                end
            end
        elseif p.unit and d.opens_on ~= "" and cleared_zones[d.opens_on] then
            World.destroy_unit(Unit.world(p.unit), p.unit)
            p.unit, p.gone = nil, true
            say("gate opened (%s cleared)", d.opens_on)
        end
    end
    if server and #m.kills > 0 and mod:get("kill_boxes") ~= false then
        m.kill_t = m.kill_t + dt
        if m.kill_t >= 0.25 then
            m.kill_t = 0
            local pm = Managers.player
            local ok, players = pcall(function() return pm:human_players() end)
            for _, player in pairs(ok and players or {}) do
                local unit = player.player_unit
                if unit_ok(unit) and HEALTH_ALIVE[unit] then
                    local lp = to_local(Unit.world_position(unit, 1))
                    if in_kill_box(m, Vector3.x(lp), Vector3.y(lp), Vector3.z(lp)) then
                        kill_player(m, player, unit)
                    end
                end
            end
        end
    end
end

local function reset_mission(exiting)
    for _, u in ipairs(mission_units) do
        if unit_ok(u) then
            if mission_net[u] then
                if not exiting then
                    delete_net_unit(u)
                end
            else
                pcall(World.destroy_unit, Unit.world(u), u)
            end
        end
    end
    mission_units, mission_net, mission, cleared_zones = {}, {}, nil, {}
end

-- ---------------------------------------------------------------------------------------------------- section handoff
-- 0.7.0 EXPERIMENT ("floating origin"): the engine only represents positions within about +-512 m of the world origin
-- (network position range, out-of-bounds hard cap), so a map wider than that cannot exist at one scale. Instead the
-- route is cut into sections built around their own centre (wc1s1, wc1s2, ... same scale and the same base_z). When a
-- player crosses a section's handoff line (a game-space z), the next section's packages (preloaded when within
-- `preload` game metres of the line) replace the current one: the old chunks are destroyed, the next layout becomes
-- `Layout`, its chunks are spawned and every player is teleported to the same game point expressed in the new frame
-- (to_game / the new centre and scale). Same place, new coordinates, so the world appears not to move.
-- Known limits (untested): minions, pickups and painted gas of the old section stay at their old world positions (they
-- are meaningless in the new frame), the baked navmesh of the old section stays too, bake tiles restart.
-- "/wallclimber section" shows the state, "/wallclimber section now" forces the switch (when preloaded).
local HANDOFF = { wc1s1 = { to = "wc1s2", line_gz = 2780, preload = 320 },
    wc1s2 = { to = "wc1s3", line_gz = 4400, preload = 320 } }   -- 0.7.11: s3 = the Wall (game z 4350..5650)   -- s1 ends at the bridge ravine (gz 2850)
local next_layout, next_state = nil, "idle"      -- idle | loading | ready | failed
local handoff_moves = nil

local function preload_next(name)
    custom_assets = custom_assets or get_mod("CustomAssets")
    if not custom_assets or not custom_assets.is_api_compatible or not custom_assets.is_api_compatible(1) then
        next_state = "failed"
        say("handoff: Custom Assets (API 1) is missing")
        return
    end
    local lay = mod:io_dofile("QIangIQsWallclimber/scripts/mods/QIangIQsWallclimber/" .. name .. "_layout")
    if type(lay) ~= "table" or type(lay.chunks) ~= "table" or (lay.base_z or 0) ~= BASE_Z then
        next_state = "failed"
        say("handoff: section %s is unusable (layout missing or base_z %s is not %s)", name,
            tostring(type(lay) == "table" and lay.base_z), tostring(BASE_Z))
        return
    end
    next_layout, next_state = lay, "loading"
    local pending, failed = #lay.chunks, 0
    local function done()
        pending = pending - 1
        if pending == 0 then
            next_state = failed == 0 and "ready" or "failed"
            say("handoff: section %s %s (%d chunks, %d failed)", name, next_state, #lay.chunks, failed)
        end
    end
    local lib_id = MOD_ID .. lay.library
    local t, err = custom_assets.acquire(mod, lib_id, function(_, _, load_error)
        if load_error then
            next_state = "failed"
            say("handoff: %s failed to load: %s", lib_id, tostring(load_error))
            return
        end
        for _, row in ipairs(lay.chunks) do
            local cname = row[1]
            local id = MOD_ID .. cname
            local ct = custom_assets.acquire(mod, id, function(_, _, chunk_error)
                if chunk_error then
                    failed = failed + 1
                else
                    loaded[cname] = true
                end
                done()
            end, { reference_name = id })
            if ct then
                tickets[cname] = ct
            else
                failed = failed + 1
                done()
            end
        end
    end, { reference_name = lib_id })
    if t then
        tickets[lay.library] = t
        say("handoff: loading section %s (%d packages)", name, #lay.chunks + 1)
    else
        next_state = "failed"
        say("handoff: %s could not be requested: %s", lib_id, tostring(err))
    end
end

local handoff_job = nil

-- 0.7.10: the swap leaves the players over nothing for several seconds (old chunks gone, new ones spawning). They fell,
-- died, and the game respawned them on the far side of the map. Now they are pinned where they stood every frame.
local tp_n = 0
mod.tp = function(player, pos, rot, tag)
    local pu = player.player_unit
    if tag ~= "hold" then
        local gm = Managers.state.game_mode
        mod:info("TP queue %s pu=%s gm=%s pending=%s QB=%s", tag, tostring(pu), tostring(gm),
            tostring(gm and gm._num_physics_safe_callbacks), tostring(QuaternionBox))
    end
    local bpos = Vector3Box(pos)
    local brot = nil
    tp_n = tp_n + 1
    local log_it = tag ~= "hold" or tp_n % 40 == 1
    Managers.state.game_mode:register_physics_safe_callback(function()
        local alive = ALIVE[pu]
        local before = unit_ok(pu) and Unit.world_position(pu, 1) or nil
        local ok, err = pcall(PlayerMovement._teleport_callback, pu, bpos, brot, false, false)
        if log_it then
            local after = unit_ok(pu) and Unit.world_position(pu, 1) or nil
            local function f(v)
                return v and ("%.1f,%.1f,%.1f"):format(Vector3.x(v), Vector3.y(v), Vector3.z(v)) or "nil"
            end
            mod:info("TP %s alive=%s ok=%s err=%s before=%s want=%s after=%s", tag, tostring(alive and true), tostring(ok),
                tostring(err), f(before), f(bpos:unbox()), f(after))
        end
    end)
end

mod.hold_players = function(list)
    for _, mv in ipairs(list or handoff_moves or {}) do
        local pu = mv.player.player_unit
        if unit_ok(pu) and mv.hold then
            local ok, err = pcall(function()
                mod.tp(mv.player, mv.hold:unbox(), mv.rot, "hold")
                clear_fall_speed(pu)
            end)
            if not ok and not mod.hold_err then
                mod.hold_err = true
                mod:error("hold teleport failed: %s", tostring(err))
            end
        end
    end
end

local function do_handoff()
    local lay = next_layout
    if not lay then
        return
    end
    local moves = {}
    pcall(function()
        for _, player in pairs(Managers.player:human_players()) do
            local u = player.player_unit
            if unit_ok(u) then
                local gx, gy, gz = to_game(to_local(Unit.world_position(u, 1)))
                moves[#moves + 1] = { player = player, g = { gx, gy, gz }, rot = Unit.local_rotation(u, 1),
                    hold = Vector3Box(Unit.world_position(u, 1) + Vector3(0, 0, 0.3)) }
                mod:info("HANDOFF start: game (%.1f, %.1f, %.1f)", gx, gy, gz)
            end
        end
    end)
    -- 0.7.5: destroying ~300 units and the minions in one frame left async physics queries pointing at freed actors (engine
    -- access violation in fetch_queries, twice). Now: switch the actors off, let the queries drain, destroy 8 units per frame.
    local old = units
    units, unit_set, spawn_queue, named, bridges = {}, {}, nil, {}, {}
    if mod.reset_env then
        mod.reset_env()
    end
    if mod.release_rappel_light then
        mod.release_rappel_light()
    end
    handoff_hold = false
    mod.bridge_auto = false
    handoff_moves = moves
    handoff_job = { lay = lay, old = old, wait = 0, minions = false }
    next_layout, next_state = nil, "idle"
    say("section handoff -> %s (%d players)", tostring(lay.section), #moves)
end

local function step_handoff(dt)
    local j = handoff_job
    j.wait = j.wait - dt
    if j.wait > 0 then
        return
    end
    local ok, err = pcall(function()
        if not j.minions then
            -- 0.7.6: the crash survived the staged destroy (0.7.5) with ~40 minions alive: their async sight/attack raycasts
            -- hit the freed actors in the next physics fetch. Remove every minion first and let the queries drain.
            j.minions = true
            j.wait = 1.5
            local ms = Managers.state.minion_spawn
            pcall(ms.despawn_all_minions, ms)
            for _, u in ipairs(patrol_units) do
                if unit_ok(u) and HEALTH_ALIVE[u] then
                    ms:despawn_minion(u)
                end
            end
            for _, u in ipairs(gas_units) do
                if unit_ok(u) then
                    delete_net_unit(u)
                end
            end
            return
        end
        local n = 0
        while #j.old > 0 and n < 8 do
            local u = table.remove(j.old)
            if unit_ok(u) then
                local world = Unit.world(u)
                if world then
                    World.destroy_unit(world, u)
                end
            end
            n = n + 1
        end
        if #j.old > 0 then
            return
        end
        handoff_job = nil
        reset_mission()
        Layout = j.lay
        ROPE = nil
        patrol_zones, patrol_units, patrol_done = nil, {}, {}
        zone_bake_queue = {}
        gas_zones, gas_units = nil, {}
        bake_tiles, navbake, last_safe, rappel = {}, nil, nil, nil
        start_spawning()
    end)
    if not ok then
        handoff_job = nil
        mod:error("handoff step failed: %s", tostring(err))
    end
end

local function finish_handoff()
    local moves = handoff_moves
    if not moves then
        return false
    end
    handoff_moves = nil
    local c, s = Layout.center_game, Layout.scale
    local landed = 0
    for _, mv in ipairs(moves) do
        local lp = Vector3((mv.g[1] - c[1]) * s, (mv.g[3] - c[3]) * s, (mv.g[2] - c[2]) * s)
        local he = Layout.half_extent
        local raw_x, raw_y = Vector3.x(lp), Vector3.y(lp)
        if he then
            local mx, my = he[1] - EDGE_MARGIN - 4, he[2] - EDGE_MARGIN - 4
            lp = Vector3(math.max(-mx, math.min(mx, raw_x)), math.max(-my, math.min(my, raw_y)), Vector3.z(lp))
        end
        local ground = ground_below(lp + Vector3(0, 0, BASE_Z + 3))
        local pos = ground and (ground + Vector3(0, 0, 0.2)) or (lp + Vector3(0, 0, BASE_Z + 0.5))
        mod:info("HANDOFF land: local (%.1f, %.1f, %.1f) clamped to (%.1f, %.1f), ground %s, pos (%.1f, %.1f, %.1f)",
            raw_x, raw_y, Vector3.z(lp), Vector3.x(lp), Vector3.y(lp), tostring(ground ~= nil),
            Vector3.x(pos), Vector3.y(pos), Vector3.z(pos))
        last_safe = Vector3Box(pos)
        mod.bridge_auto = true
        mv.hold = Vector3Box(pos)
        local lok, lerr = pcall(function()
            mod.tp(mv.player, pos, mv.rot, "land")
            clear_fall_speed(mv.player.player_unit)
        end)
        if not lok then
            mod:error("land teleport failed: %s", tostring(lerr))
        end
        if ground then
            landed = landed + 1
        end
    end
    mod.settle = { moves = moves, t = 1.5 }
    mod.trace = { t = 8, n = 0 }
    say("section %s ready: %d/%d players on ground", tostring(Layout.section), landed, #moves)
    return true
end

local function update_handoff(here, dt)
    local h = HANDOFF[Layout.section or ""]
    if not h or not here or mod.settle or mod:get("section_handoff") == false then
        return
    end
    local _, _, gz = to_game(here)
    if next_state == "ready" then
        handoff_hold = gz > h.line_gz - 60
    end
    if next_state == "idle" and gz > h.line_gz - h.preload then
        preload_next(h.to)
    elseif next_state == "ready" and gz >= h.line_gz then
        if navbake or handoff_job then
            return
        end
        local o = mission and mission.obj
        if o and o.placed and not o.done then
            o.said = (o.said or 0) - dt
            if o.said <= 0 then
                o.said = 20
                say("objective: carry the power cell to the hangar door before moving on")
            end
            return
        end
        do_handoff()
    end
end

local function handoff_command(arg)
    local h = HANDOFF[Layout.section or ""]
    local pu = player_unit()
    local gz = pu and select(3, to_game(to_local(Unit.world_position(pu, 1)))) or 0
    if arg == "now" then
        if next_state == "idle" and h then
            preload_next(h.to)
            say("handoff: preloading; run it again once it says ready")
        elseif next_state == "ready" and not navbake and not handoff_job then
            do_handoff()
        end
    end
    say("section %s (scale %s); next: %s, %s; game z %.0f, line %s", tostring(Layout.section), tostring(Layout.scale),
        h and h.to or "-", next_state, gz, h and tostring(h.line_gz) or "-")
end

mod.update = function(dt)
    if mod.trace then
        mod.trace.t = mod.trace.t - dt
        mod.trace.n = mod.trace.n - dt
        if mod.trace.n <= 0 then
            mod.trace.n = 0.4
            local tpu = player_unit()
            if tpu then
                local tp = Unit.world_position(tpu, 1)
                mod:info("TRACE pos %.1f,%.1f,%.1f (%s)", Vector3.x(tp), Vector3.y(tp), Vector3.z(tp), tostring(Layout.section))
            end
        end
        if mod.trace.t <= 0 then
            mod.trace = nil
        end
    end
    if handoff_moves then
        mod.hold_players()
    elseif mod.settle then
        mod.hold_players(mod.settle.moves)
        mod.settle.t = mod.settle.t - dt
        if mod.settle.t <= 0 then
            mod.settle = nil
        end
    end
    if handoff_job then
        step_handoff(dt)
        return
    end
    if mission_check then
        local name = current_mission()
        if name then
            mission_check = false
            if name == MISSION_KEY then
                auto_enter = 0.5
            end
        end
    end
    if spawn_queue then
        local world = level_world()
        if world then
            for _ = 1, SPAWNS_PER_FRAME do
                local row = table.remove(spawn_queue)
                if not row then
                    break
                end
                local unit = World.spawn_unit_ex(world, UNIT_PREFIX .. row[1], nil, Vector3(row[2], row[3], row[4] + BASE_Z),
                    Quaternion.identity())
                if unit then
                    units[#units + 1] = unit
                    unit_set[unit] = true
                    named[row[1]] = unit
                end
            end
            if #spawn_queue == 0 then
                spawn_queue = nil
                local n = hide_prologue()
                local on_ground = finish_handoff() or teleport_to_start()
                say("Wallclimber ready (%d chunks, %d prologue units hidden)%s", #units, n,
                    on_ground and "" or " - no ground found under the drop point")
            end
        end
        return
    end
    if auto_enter then
        local player = local_player()
        -- wait out the prologue's intro cinematic (Managers.state.cinematic:is_playing(), hud_visibility_groups.lua:37)
        local cin = Managers.state and Managers.state.cinematic
        local cok, playing = pcall(function() return cin and cin:is_playing() end)
        if cok and playing then
            auto_enter = 3
        elseif player and unit_ok(player.player_unit) then
            auto_enter = auto_enter - dt
            if auto_enter <= 0 then
                auto_enter = nil
                request_enter()
            end
        end
    end
    if #units == 0 then
        return
    end
    local fpu = player_unit()
    local fhere = fpu and to_local(Unit.world_position(fpu, 1)) or nil
    if #bridges > 0 then
        update_bridges(dt, fhere)
    end
    update_rappel_area(dt, fhere)
    update_patrols(fhere, dt)
    update_gas(fhere, dt)
    update_mission(fhere, dt)
    update_handoff(fhere, dt)
    update_navbake(dt)
    auto_navbake(fhere, dt)
    process_zone_bakes()
    if rappel then
        update_rappel(dt)
        return
    end
    -- prologue sub-levels stream in later: keep hiding new units
    hide_t = hide_t + dt
    if hide_t > 2 then
        hide_t = 0
        hide_prologue()
    end
    rescue_t = rescue_t + dt
    if rescue_t < 0.25 then
        return
    end
    rescue_t = 0
    local player = local_player()
    local pu = player and player.player_unit
    if not unit_ok(pu) then
        return
    end
    local wp = Unit.world_position(pu, 1)
    if Vector3.z(wp) < FALL_LIMIT then
        teleport_to_start()
        say("caught you falling; back at the drop point")
        return
    end
    -- Section edge: the game kills a player past its soft out-of-bounds limit (90% of the network range, ~460 m,
    -- gameplay_init_step_out_of_bounds.lua:32) and respawns them on the hidden base level; 0.4.0 test: death at the
    -- end of the bridge, then a markers_aio crash tagging Gloriana's power cell. Keep the player EDGE_MARGIN inside.
    local he = Layout.half_extent
    if he then
        local x, y = Vector3.x(wp), Vector3.y(wp)
        if math.abs(x) > he[1] - EDGE_MARGIN or math.abs(y) > he[2] - EDGE_MARGIN then
            if last_safe then
                PlayerMovement.teleport(player, last_safe:unbox(), nil)
                clear_fall_speed(pu)
            end
            edge_t = edge_t - 0.25
            if edge_t <= 0 then
                edge_t = 5
                if mod.bridge_locked and mod.bridge_locked() then
                    say("the bridge is locked: power the hangar door first")
                else
                    say("end of the built map (the next section is not built yet)")
                end
            end
        else
            last_safe = Vector3Box(wp)
        end
    end
end

-- No enemy pacing (patrols, hordes, specials) in our mission: GameModeCoopCompleteObjective._set_pacing is how the
-- game switches it on when players leave the start area (game_mode_coop_complete_objective.lua:266).
mod:hook("GameModeCoopCompleteObjective", "_set_pacing", function(func, self, enabled)
    if current_mission() == MISSION_KEY then
        return func(self, false)
    end
    return func(self, enabled)
end)

-- 0.6.1: crash after the first navmesh bake (2026-10-18 05:31, "path_type_linear.lua:263: attempt to perform
-- arithmetic on local 'start_index' (a nil value)", called from main_path_manager.lua:603 update). The player now
-- stands on a navmesh that belongs to no main-path group, so the group lookup returns nil. The main path is of no use
-- in our mission (pacing is held off), so a failing update is skipped instead of ending the game.
local main_path_warned = false
mod:hook("MainPathManager", "update", function(func, self, ...)
    if current_mission() ~= MISSION_KEY then
        return func(self, ...)
    end
    -- 0.7.1: 2026-10-18 07:49 native crash (not a Lua error, pcall cannot catch it): the engine call
    -- nav_spawn_points:get_group_from_position inside update_progress_on_path (path_type_linear.lua:234) died 0.5 s after
    -- a runtime navmesh bake finished. The spawn-point data belongs to the original navmesh. Our mission has no main path
    -- use (pacing is held off), so the update is not run at all.
    if not main_path_warned then
        main_path_warned = true
        mod:info("MainPathManager.update is skipped in this mission (native crash after a navmesh bake otherwise)")
    end
end)

-- 0.6.2: second crash after the bake (2026-10-18 05:57): specials_pacing.lua:1504 _update_rush_prevention ->
-- path_type_linear.lua:174 _information_from_position, same nil 'start_index' (the player's navmesh group has no
-- main-path index). Make the lookup harmless in our mission (a position off the main path counts as distance 0) and
-- keep the whole pacing update from ending the game should another lookup fail.
mod:hook("PathTypeLinear", "_information_from_position", function(func, self, position, ...)
    if current_mission() ~= MISSION_KEY then
        return func(self, position, ...)
    end
    -- 0.7.1: also native (get_group_from_position), so never call the original in our mission
    return position, 0
end)

-- 0.7.2: with MainPathManager.update skipped nothing fills the segment indices any more and the bots' melee action
-- (bt_bot_melee_action.lua:686 _allow_engage, "attempt to compare two nil values", Lua crash 2026-10-18 08:02) compares
-- them. Bots skip that code when is_main_path_ready() is false; segment_index_by_unit gets a harmless value too.
mod:hook("MainPathManager", "is_main_path_ready", function(func, self, ...)
    if current_mission() == MISSION_KEY and #units > 0 then
        return false
    end
    return func(self, ...)
end)

mod:hook("MainPathManager", "segment_index_by_unit", function(func, self, ...)
    local res = func(self, ...)
    if res == nil and current_mission() == MISSION_KEY then
        return 1
    end
    return res
end)

local pacing_warned = false
mod:hook("PacingManager", "update", function(func, self, ...)
    if current_mission() ~= MISSION_KEY then
        return func(self, ...)
    end
    -- 0.7.1: pacing is held off in our mission and its updates reach the same native group lookup: skipped
    if not pacing_warned then
        pacing_warned = true
        mod:info("PacingManager.update is skipped in this mission")
    end
end)

-- Brightness: the prologue's shading environment is dark. CameraManager.shading_callback adds the user's gamma to
-- "exposure_compensation" every frame before ShadingEnvironment.apply (camera_manager.lua:263/322,
-- script_world.lua:297-300); add our own offset after it, in our mission only.
mod:hook_safe("CameraManager", "shading_callback", function(self, world, shading_env)
    if current_mission() ~= MISSION_KEY then
        return
    end
    local boost = mod:get("brightness") or 0
    if boost ~= 0 then
        ShadingEnvironment.set_scalar(shading_env, "exposure_compensation",
            ShadingEnvironment.scalar(shading_env, "exposure_compensation") + boost)
    end
end)

-- Sky/fog: the shading environment is chosen by blend volumes around the camera position
-- (EnvironmentBlend.blend_list, camera_manager.lua:275). The map floats BASE_Z above the base level, outside its
-- volumes (0.3.0 test: the right sky only near the ravine bottom), so sample at the camera position minus the lift.
-- 0.4.6: following the camera gave the fog and sky only near the bridge (user): the base level's volumes only cover
-- part of the map, so one fixed point is sampled. 0.4.7: the 0.4.6 point (bridge mark at foot height) lay outside the
-- volume (dark everywhere); the reference look (user: the plaza south of the raised bridge) was the camera there, so
-- the default is the first bridge mark at eye height. "/wallclimber sky" stores the current camera point instead
-- (setting env_sample), "/wallclimber sky follow" goes back to following the camera.
local ENV_DEFAULT = Layout.bridges and Layout.bridges[1] and Layout.bridges[1].trigger or nil
local last_camera_local = nil
local function env_sample()
    local v = mod:get("env_sample")
    if v == "follow" then
        return nil
    end
    local p = parse_pos(v)
    if p then
        return p
    end
    return ENV_DEFAULT and Vector3(ENV_DEFAULT[1], ENV_DEFAULT[2], ENV_DEFAULT[3] + 1.7) or nil
end
-- 0.4.10: the eye-height point was still dark in game (no volume there). Each environment is a unit volume
-- (ShadingEnvironmentExtension.weight: Unit.is_point_inside_volume "env_volume", environment_blend.lua:45-89); with
-- none hit you get the dark default. So the point is searched once per map: a grid over the bridge plaza (where the
-- user's reference shots were taken) and, if nothing there, the whole section; the point with the highest summed
-- non-default weight wins. Logged as "ENV ..." in the console log.
local env_found = nil       -- Vector3Box or false
local env_retry = 0
mod.reset_env = function()
    env_found = nil
end
local function search_env(blender)
    local layers = blender._blend_layers or {}
    local function score(p)
        local s = 0
        for _, lb in ipairs(layers) do
            for _, b in ipairs(lb) do
                local ok, w = pcall(b.weight, b, p)
                if ok and w then
                    s = s + w
                end
            end
        end
        return s
    end
    local best, best_p = 0, nil
    local function scan(x0, x1, y0, y1, z0, z1, step, zstep)
        for x = x0, x1, step do
            for y = y0, y1, step do
                for z = z0, z1, zstep do
                    local p = Vector3(x, y, z)
                    local sc = score(p)
                    if sc > best then
                        best, best_p = sc, p
                    end
                end
            end
        end
    end
    scan(40, 200, 280, 360, -45, -20, 8, 5)
    if best < 1 then
        scan(-440, 440, -440, 440, -150, 150, 40, 25)
    end
    local n = 0
    for li, lb in ipairs(layers) do
        for _, b in ipairs(lb) do
            n = n + 1
            local okn, nm = pcall(b.name, b)
            mod:info("ENV layer %d %s weight at best %.2f", li, tostring(okn and nm or "?"),
                best_p and (select(2, pcall(b.weight, b, best_p)) or 0) or 0)
        end
    end
    mod:info("ENV %d environment volumes, best point %s score %.2f", n, best_p and pos_string(best_p) or "none", best)
    return best_p and Vector3Box(best_p) or false
end

mod:hook("EnvironmentBlend", "blend_list", function(func, self, camera_pos, default_resource, ...)
    if #units > 0 and camera_pos and current_mission() == MISSION_KEY then
        last_camera_local = Vector3Box(camera_pos - Vector3(0, 0, BASE_Z))
        local v = mod:get("env_sample")
        if v == "follow" then
            camera_pos = camera_pos - Vector3(0, 0, BASE_Z)
        elseif parse_pos(v) then
            camera_pos = parse_pos(v)
        else
            if env_found == nil or (env_found == false and env_retry <= 0) then
                local ok, res = pcall(search_env, self)
                env_found = ok and res or false
                env_retry = 300    -- frames until the next try while nothing is found (volumes can register late)
            elseif env_found == false then
                env_retry = env_retry - 1
            end
            camera_pos = env_found and env_found:unbox() or env_sample() or (camera_pos - Vector3(0, 0, BASE_Z))
        end
    end
    return func(self, camera_pos, default_resource, ...)
end)

mod:hook("CinematicSceneSystem", "_can_play", function(func, self, cinematic_name, ...)
    if current_mission() == MISSION_KEY then
        return false
    end
    return func(self, cinematic_name, ...)
end)

mod:command("wallclimber", mod:localize("cmd_desc"), function(arg, arg2)
    if arg == "debug" then
        debug()
    elseif arg == "mark" then
        mark(arg2)
    elseif arg == "sky" then
        if arg2 == "follow" then
            mod:set("env_sample", "follow", false)
            say("sky/fog: following the camera")
        elseif arg2 == "auto" then
            mod:set("env_sample", "", false)
            mod.reset_env()
            say("sky/fog: automatic (searched point)")
        elseif last_camera_local then
            mod:set("env_sample", pos_string(last_camera_local:unbox()), false)
            say("sky/fog: fixed to this spot (%s)", pos_string(last_camera_local:unbox()))
        end
    elseif arg == "hide" then
        force_hide_big = (arg2 == "all")
        hidden, kept_big = {}, 0
        local n = hide_prologue()
        say("hide pass: %d units hidden, %d big (sky-size) units kept%s", n, kept_big,
            force_hide_big and " (hide all: big units hidden too)" or " (\"/wallclimber hide all\" hides those too)")
    elseif arg == "section" then
        handoff_command(arg2)
    elseif arg == "navmesh" then
        start_navbake()
    elseif arg == "patrol" then
        local pu = player_unit()
        if arg2 == "add" and pu then
            local cur = tostring(mod:get("patrol_points") or "")
            mod:set("patrol_points", cur .. (cur == "" and "" or ";") .. pos_string(to_local(Unit.world_position(pu, 1))), false)
            patrol_zones = nil
            say("patrol point added here (spawns when you come within %d m)", PATROL_ACTIVATE)
        elseif arg2 == "clear" then
            mod:set("patrol_points", "", false)
            patrol_zones = nil
            say("custom patrol points cleared")
        elseif arg2 == "now" then
            build_patrol_zones()
            for _, z in ipairs(patrol_zones) do
                if not z.spawned then
                    spawn_patrol_zone(z)
                end
            end
        else
            say("patrol: add | clear | now (spawn every zone now)")
        end
    elseif arg == "bridge" then
        for _, b in ipairs(bridges) do
            start_lowering(b)
        end
    elseif arg == "rappel" then
        local pu = player_unit()
        if arg2 == "clear" then
            mod:set("rappel_top", "", false)
            mod:set("rappel_bottom", "", false)
            say("rappel cleared")
        elseif (arg2 == "top" or arg2 == "bottom") and pu then
            mod:set("rappel_" .. arg2, pos_string(to_local(Unit.world_position(pu, 1))), false)
            mark("rappel_" .. arg2)
        else
            start_rappel()
        end
    else
        request_enter()
    end
end)

mod.on_game_state_changed = function(status, state_name)
    if state_name == "StateGameplay" and status == "exit" then
        -- destroy our units now, release packages on the next gameplay enter (Factory v0.1.1 CTD rule)
        despawn_all()
        handoff_hold = false
        hidden, auto_enter, mission_check, rappel, last_safe = {}, nil, false, nil, nil
        patrol_zones, patrol_units, patrol_done, navbake = nil, {}, {}, nil
        gas_zones, gas_units = nil, {}
        bake_tiles = {}
        reset_mission(true)
        zone_bake_queue = {}
        if next(tickets) then
            release_pending = true
        end
    elseif state_name == "StateGameplay" and status == "enter" then
        if release_pending then
            release_pending = false
            release_all()
        end
        mission_check = true
    end
end

mod.on_disabled = function()
    despawn_all()
end

mod.on_unload = function()
    despawn_all()
end
