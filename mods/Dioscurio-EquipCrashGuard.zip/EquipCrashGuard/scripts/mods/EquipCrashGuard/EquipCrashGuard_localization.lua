return {
	mod_name = {
		en = "Equip Crash Guard",
	},
	mod_description = {
		en = "Stops the 'Unit not found' crash (unit_spawner_manager.lua:586) when another player's weapon or grenade arrives before its model has loaded. The item is skipped for a moment and re-equipped once it has loaded, instead of crashing the game.",
	},
	notify = {
		en = "Chat message when a crash is caught",
	},
	notify_description = {
		en = "Prints a line in chat each time the guard catches one. Off by default; it is always written to the console log either way.",
	},
}
