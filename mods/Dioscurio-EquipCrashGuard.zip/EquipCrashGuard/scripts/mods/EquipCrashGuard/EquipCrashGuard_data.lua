local mod = get_mod("EquipCrashGuard")

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			{
				setting_id = "notify",
				type = "checkbox",
				default_value = false,
			},
		},
	},
}
