local mod = get_mod("EquipCrashGuard")

--[[
Equip Crash Guard

Crash this fixes:
  unit_spawner_manager.lua:586: Unit not found #ID[...]
  ... visual_loadout_customization.lua spawn_base_unit
  ... player_husk_visual_loadout_extension.lua _equip_item_to_slot
  RPC rpc_player_equip_item_to_slot

Another player (a "husk") equips an item - here a krak grenade, right after loading
into the Mourningstar - before this client has finished loading that item's package.
The game spawns the item's base unit anyway, the unit is not loaded, and the error is
fatal.

What this does:
  1. Runs every husk equip inside a protected call that records which units it spawned.
  2. If it fails, it removes anything half-spawned, leaves that slot empty, and queues
     a retry.
  3. Retries once the slot's package reports loaded (or after a short timeout),
     backing off between tries and giving up after a few.
  4. Skips the server's later "unequip" for a slot it left empty, because the game's
     own unequip reads slot.item and would crash on the empty slot.

While a slot waits, that player's item is simply not drawn on your screen. Nothing is
sent to the server; it only affects what your client renders.
]]

local NetworkLookup = require("scripts/network_lookup/network_lookup")

local MAX_TRIES = 6           -- failed attempts before giving up on a slot
local WAIT_FOR_LOAD = 10      -- seconds to wait for the package before trying anyway
local BACKOFF = { 0.5, 1, 2, 4, 8, 15 }

-- husk extension -> { [slot_name] = entry }. Weak keys so a destroyed husk is dropped.
local pending = setmetatable({}, { __mode = "k" })
local retrying = nil -- entry being retried right now, so its try count carries over

local function log(fmt, ...)
	local msg = string.format(fmt, ...)
	mod:info("%s", msg)
	if mod:get("notify") then
		mod:echo("[Equip Crash Guard] %s", msg)
	end
end

local function first_line(err)
	local s = tostring(err)
	return s:match("^[^\n]*") or s
end

-- Calls fn while recording every unit the unit spawner creates during the call.
local function run_tracked(fn, ...)
	local spawner = Managers.state and Managers.state.unit_spawner
	local spawned = {}
	local own = spawner and rawget(spawner, "spawn_unit")
	local base = spawner and spawner.spawn_unit

	if spawner and base then
		spawner.spawn_unit = function(self, ...)
			local unit = base(self, ...)
			spawned[#spawned + 1] = unit
			return unit
		end
	end

	local args = { n = select("#", ...), ... }
	local ok, err = xpcall(function()
		return fn(unpack(args, 1, args.n))
	end, debug.traceback)

	if spawner and base then
		spawner.spawn_unit = own -- nil restores the class method
	end

	return ok, err, spawned
end

-- Every unit some slot of this husk still references.
local function owned_units(ext)
	local owned = {}

	for _, slot in pairs(ext._equipment or {}) do
		if slot.unit_3p then owned[slot.unit_3p] = true end
		if slot.unit_1p then owned[slot.unit_1p] = true end
		for _, by_unit in pairs({ slot.attachments_by_unit_3p, slot.attachments_by_unit_1p }) do
			for _, list in pairs(by_unit or {}) do
				for _, unit in pairs(list) do
					owned[unit] = true
				end
			end
		end
	end

	return owned
end

-- Undo a failed equip: delete strays no slot owns, then unequip the slot (which deletes
-- what it does own). Strays are worked out first so nothing is deleted twice.
local function clean_up(ext, slot_name, spawned)
	local spawner = Managers.state and Managers.state.unit_spawner
	local owned = owned_units(ext)

	for i = #spawned, 1, -1 do
		local unit = spawned[i]
		if unit and not owned[unit] and Unit.alive(unit) then
			pcall(function()
				World.unlink_unit(Unit.world(unit), unit)
			end)
			if spawner then
				pcall(spawner.mark_for_deletion, spawner, unit)
			end
		end
	end

	local slot = ext._equipment and ext._equipment[slot_name]
	if not slot then
		return
	end

	if slot.item then
		pcall(ext._equipment_component.unequip_item, ext._equipment_component, slot)
	end

	-- whatever unequip managed, leave the slot in the plain "empty" state
	slot.equipped = false
	slot.item = nil
	slot.unit_3p = nil
	slot.unit_1p = nil
	slot.attachments_by_unit_3p = nil
	slot.attachments_by_unit_1p = nil
	slot.attachment_spawn_status = nil
end

local function slot_loaded(ext, slot)
	local comp = ext._equipment_component
	if not comp or not comp._has_slot_package_streaming then
		return true
	end
	local ok, loaded = pcall(comp._slot_is_loaded, comp, slot)
	return ok and loaded
end

local function player_label(ext)
	local player = ext._player
	local ok, name = pcall(function()
		return player and player:name()
	end)
	return ok and name and tostring(name) or "another player"
end

-- Every husk equip (from the RPCs, a profile sync, or our own retry) passes through here.
mod:hook("PlayerHuskVisualLoadoutExtension", "_equip_item_to_slot", function(func, self, slot_name, item, optional_existing_unit_3p)
	local entry = retrying
	retrying = nil

	local list = pending[self]
	if list then
		list[slot_name] = nil
	end

	local ok, err, spawned = run_tracked(func, self, slot_name, item, optional_existing_unit_3p)
	if ok then
		if entry then
			log("%s's %s loaded and was equipped (try %d).", player_label(self), tostring(slot_name), entry.tries + 1)
			if self._wielded_slot == slot_name then
				pcall(self.wield_slot, self, slot_name)
			end
		end
		return
	end

	local item_name = item and item.name or "?"
	clean_up(self, slot_name, spawned)

	local tries = (entry and entry.tries or 0) + 1
	if tries >= MAX_TRIES then
		log("Gave up on %s's %s (%s) after %d tries: %s", player_label(self), tostring(slot_name), item_name, tries, first_line(err))
		return
	end

	if tries == 1 then
		log("Caught a crash: %s's %s (%s) was not loaded yet. Will re-equip once it loads. %s", player_label(self), tostring(slot_name), item_name, first_line(err))
		mod:info("%s", tostring(err))
	end

	list = pending[self] or {}
	pending[self] = list
	list[slot_name] = {
		item = item,
		existing = optional_existing_unit_3p,
		tries = tries,
		first_t = entry and entry.first_t or nil,
		next_t = nil,
	}
end)

-- The server's unequip for a slot we had to leave empty would crash on slot.item.
mod:hook("PlayerHuskVisualLoadoutExtension", "rpc_player_unequip_item_from_slot", function(func, self, channel_id, go_id, slot_id, ...)
	local slot_name = NetworkLookup.player_inventory_slot_names[slot_id]
	local list = pending[self]
	if list and slot_name then
		list[slot_name] = nil
	end

	local slot = slot_name and self._equipment and self._equipment[slot_name]
	if slot and not slot.item then
		return
	end

	return func(self, channel_id, go_id, slot_id, ...)
end)

-- Retries. Cheap when nothing is pending: one table lookup per husk per frame.
mod:hook_safe("PlayerHuskVisualLoadoutExtension", "update", function(self, unit, dt, t)
	local list = pending[self]
	if not list or next(list) == nil then
		return
	end

	for slot_name, entry in pairs(list) do
		local slot = self._equipment and self._equipment[slot_name]

		if not slot or slot.item then
			-- gone, or something else got equipped meanwhile: nothing to restore
			list[slot_name] = nil
		else
			entry.first_t = entry.first_t or t
			entry.next_t = entry.next_t or (t + BACKOFF[math.min(entry.tries, #BACKOFF)])

			local waited = t - entry.first_t
			if t >= entry.next_t and (slot_loaded(self, slot) or waited >= WAIT_FOR_LOAD) then
				local existing = entry.existing
				if existing and not Unit.alive(existing) then
					existing = nil
				end

				list[slot_name] = nil
				retrying = entry
				local ok, err = pcall(self._equip_item_to_slot, self, slot_name, entry.item, existing)
				retrying = nil
				if not ok then
					mod:info("retry error for %s: %s", tostring(slot_name), tostring(err))
				end
				return -- at most one retry per husk per frame
			end
		end
	end
end)

mod.on_game_state_changed = function(status, state_name)
	if status == "exit" and state_name == "StateGameplay" then
		pending = setmetatable({}, { __mode = "k" })
		retrying = nil
	end
end
