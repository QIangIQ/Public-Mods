return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`EquipCrashGuard` encountered an error loading the Darktide Mod Framework.")

		new_mod("EquipCrashGuard", {
			mod_script       = "EquipCrashGuard/scripts/mods/EquipCrashGuard/EquipCrashGuard",
			mod_data         = "EquipCrashGuard/scripts/mods/EquipCrashGuard/EquipCrashGuard_data",
			mod_localization = "EquipCrashGuard/scripts/mods/EquipCrashGuard/EquipCrashGuard_localization",
		})
	end,
	version = "1.0.0",
	author = "Dioscurio",
	packages = {},
}
