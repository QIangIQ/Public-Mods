Equip Crash Guard 1.0.0
=======================

Fixes this crash:
  unit_spawner_manager.lua:586: Unit not found #ID[...]
  (RPC rpc_player_equip_item_to_slot, spawn_base_unit / _equip_item_to_slot in the stack)

It happens when another player equips something (in the crash log, a krak grenade
right after loading into the Mourningstar) before your game has loaded that item's
model. The game tries to spawn it anyway and crashes.

With this mod, the item is skipped for a moment instead and re-equipped as soon as
it has loaded, usually within a second or two. Worst case, you briefly won't see
that player's grenade or weapon. Nothing is sent to the server; it only changes
what your own game draws. It does nothing until the crash would happen.

INSTALL (game closed)
1. Copy the EquipCrashGuard folder into:
   ...\steamapps\common\Warhammer 40,000 DARKTIDE\mods\
2. Open mods\mod_load_order.txt and add this line on its own (anywhere below dmf):
   EquipCrashGuard
3. Start the game. It appears in Mod Options as "Equip Crash Guard".

Optional: turn on "Chat message when a crash is caught" in its options to see when it
saves you. Either way, each catch is written to the console log as
[EquipCrashGuard] Caught a crash: ...

Compatible with Dio's Wardrobe (which has its own copy of this guard); both can be on.
