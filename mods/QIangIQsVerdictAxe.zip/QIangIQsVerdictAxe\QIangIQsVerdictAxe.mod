return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsVerdictAxe` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsVerdictAxe", {
            mod_script = "QIangIQsVerdictAxe/scripts/mods/QIangIQsVerdictAxe/QIangIQsVerdictAxe",
            mod_data = "QIangIQsVerdictAxe/scripts/mods/QIangIQsVerdictAxe/QIangIQsVerdictAxe_data",
            mod_localization = "QIangIQsVerdictAxe/scripts/mods/QIangIQsVerdictAxe/QIangIQsVerdictAxe_localization",
        })
    end,
    version = "1.2.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
