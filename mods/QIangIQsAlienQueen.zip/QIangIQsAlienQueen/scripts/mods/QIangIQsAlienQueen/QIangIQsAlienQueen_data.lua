local mod = get_mod("QIangIQsAlienQueen")

return {
    name = mod:localize("mod_name"),
    description = mod:localize("mod_description"),
    is_togglable = true,
    options = {
        widgets = {
            {
                setting_id = "model_enabled",
                type = "checkbox",
                default_value = false,
            },
            {
                setting_id = "hide_body",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "first_person_arms",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "menu_previews",
                type = "checkbox",
                default_value = true,
            },
            {
                setting_id = "parts_group",
                type = "group",
                sub_widgets = {
                    {
                        setting_id = "part_tail",
                        type = "checkbox",
                        default_value = true,
                    },
                    {
                        setting_id = "part_crest",
                        type = "checkbox",
                        default_value = true,
                    },
                    {
                        setting_id = "part_hugger",
                        type = "checkbox",
                        default_value = true,
                    },
                    {
                        setting_id = "part_bra",
                        type = "checkbox",
                        default_value = true,
                    },
                },
            },
            {
                setting_id = "shape_group",
                type = "group",
                sub_widgets = {
                    {
                        setting_id = "shape_breast",
                        type = "numeric",
                        default_value = 1,
                        range = { 0.5, 2 },
                        decimals_number = 2,
                    },
                    {
                        setting_id = "shape_butt",
                        type = "numeric",
                        default_value = 1,
                        range = { 0.5, 2 },
                        decimals_number = 2,
                    },
                    {
                        setting_id = "shape_breast_lift",
                        type = "numeric",
                        default_value = 0,
                        range = { -20, 40 },
                        decimals_number = 0,
                    },
                },
            },
            {
                setting_id = "tail_group",
                type = "group",
                sub_widgets = {
                    {
                        setting_id = "tail_custom",
                        type = "checkbox",
                        default_value = false,
                    },
                    {
                        setting_id = "tail_length",
                        type = "numeric",
                        default_value = 1,
                        range = { 0.5, 3 },
                        decimals_number = 2,
                    },
                    {
                        setting_id = "tail_thickness",
                        type = "numeric",
                        default_value = 1,
                        range = { 0.5, 3 },
                        decimals_number = 2,
                    },
                },
            },
            {
                setting_id = "physics_group",
                type = "group",
                sub_widgets = {
                    {
                        setting_id = "jiggle",
                        type = "checkbox",
                        default_value = true,
                    },
                    {
                        setting_id = "jiggle_breast",
                        type = "numeric",
                        default_value = 1,
                        range = { 0, 3 },
                        decimals_number = 2,
                    },
                    {
                        setting_id = "jiggle_butt",
                        type = "numeric",
                        default_value = 1,
                        range = { 0, 3 },
                        decimals_number = 2,
                    },
                    {
                        setting_id = "jiggle_cloth",
                        type = "numeric",
                        default_value = 1,
                        range = { 0, 3 },
                        decimals_number = 2,
                    },
                    {
                        setting_id = "jiggle_stiffness",
                        type = "numeric",
                        default_value = 1,
                        range = { 0.25, 3 },
                        decimals_number = 2,
                    },
                    {
                        setting_id = "jiggle_damping",
                        type = "numeric",
                        default_value = 1,
                        range = { 0.25, 3 },
                        decimals_number = 2,
                    },
                    {
                        setting_id = "jiggle_limit",
                        type = "numeric",
                        default_value = 1,
                        range = { 0.25, 3 },
                        decimals_number = 2,
                    },
                    {
                        setting_id = "jiggle_hang",
                        type = "numeric",
                        default_value = 0.15,
                        range = { 0, 1 },
                        decimals_number = 2,
                    },
                },
            },
            {
                setting_id = "tail_phys_group",
                type = "group",
                sub_widgets = {
                    {
                        setting_id = "jiggle_tail",
                        type = "numeric",
                        default_value = 1,
                        range = { 0, 3 },
                        decimals_number = 2,
                    },
                    {
                        setting_id = "tail_phys_segments",
                        type = "numeric",
                        default_value = 6,
                        range = { 2, 10 },
                        decimals_number = 0,
                    },
                    {
                        setting_id = "tail_phys_stiffness",
                        type = "numeric",
                        default_value = 1,
                        range = { 0.25, 3 },
                        decimals_number = 2,
                    },
                    {
                        setting_id = "tail_phys_damping",
                        type = "numeric",
                        default_value = 1,
                        range = { 0.25, 3 },
                        decimals_number = 2,
                    },
                    {
                        setting_id = "tail_phys_limit",
                        type = "numeric",
                        default_value = 1,
                        range = { 0.25, 3 },
                        decimals_number = 2,
                    },
                    {
                        setting_id = "tail_phys_gravity",
                        type = "numeric",
                        default_value = 0.3,
                        range = { 0, 1 },
                        decimals_number = 2,
                    },
                    {
                        setting_id = "tail_phys_trail",
                        type = "numeric",
                        default_value = 1,
                        range = { 0, 3 },
                        decimals_number = 2,
                    },
                },
            },
            {
                setting_id = "toggle_keybind",
                type = "keybind",
                default_value = {},
                keybind_trigger = "pressed",
                keybind_type = "function_call",
                function_name = "toggle_model",
            },
        },
    },
}
