return {
    run = function()
        fassert(rawget(_G, "new_mod"), "`QIangIQsAlienQueen` encountered an error loading the Darktide Mod Framework.")
        new_mod("QIangIQsAlienQueen", {
            mod_script = "QIangIQsAlienQueen/scripts/mods/QIangIQsAlienQueen/QIangIQsAlienQueen",
            mod_data = "QIangIQsAlienQueen/scripts/mods/QIangIQsAlienQueen/QIangIQsAlienQueen_data",
            mod_localization = "QIangIQsAlienQueen/scripts/mods/QIangIQsAlienQueen/QIangIQsAlienQueen_localization",
        })
    end,
    version = "1.1.0",
    author = "QIangIQ",
    require = { "CustomAssets" },
    load_after = { "CustomAssets" },
    packages = {},
}
