local stats = {
  { "total_kills", "Total Kills" },
  { "lesser_enemies_killed", "Lesser Enemies Killed" },
  { "specials_killed", "Specials Killed" },
  { "elites_killed", "Elites Killed" },
  { "companion_kills", "Companion Kills" },
  { "damage_dealt", "Damage Dealt" },
  { "melee_damage", "Melee Damage" },
  { "ranged_damage", "Ranged Damage" },
  { "other_damage", "Other Damage" },
  { "dot_damage", "Damage over Time" },
  { "companion_damage", "Companion Damage" },
  { "damage_to_bosses", "Damage to Bosses" },
  { "void_shield_damage", "Void Shield Damage" },
  { "headshots", "Headshots" },
  { "critical_hits", "Critical Hits" },
  { "enemies_staggered", "Enemies Staggered" },
  { "debuffs_applied", "Debuffs Applied" },
  { "damage_taken", "Damage Taken" },
  { "downs_and_deaths", "Downs and Deaths" },
  { "times_disabled", "Times Disabled" },
  { "healthstation_uses", "Health Station Uses" },
  { "ammo_pickups", "Ammo Pickups" },
  { "ammo_collected", "Ammo Collected" },
  { "combat_ability_uses", "Combat Ability Uses" },
  { "enemies_aggroed", "Enemies Aggroed" },
  { "coherency_uptime", "Coherency Uptime" },
  { "dodges", "Dodges" },
  { "slides", "Slides" },
}

local en = {
  mod_name        = "QIangIQ's Chat Output",
  mod_description = "Sends AnotherScoreboard's end-of-mission stats to chat. Each stat is its own toggle.",
  send_at_end         = "Send at end of mission",
  send_at_end_tooltip = "Post the selected stats to chat automatically when the mission ends.",
  send_now_key         = "Send now (keybind)",
  send_now_key_tooltip = "Post the selected stats to chat immediately from the current scoreboard data.",
  show_class_icon      = "Show class icon",
  shorten_values       = "Shorten large numbers",
  shorten_values_tooltip = "12345 becomes 12.3K, 1234567 becomes 1.2M.",
  name_length          = "Name length (characters)",
  name_length_tooltip  = "Player names are cut to this many characters.",
  message_delay        = "Delay between messages (seconds)",
  message_delay_tooltip = "Each stat is one chat line; this spaces them out.",
  group_combat         = "Combat stats",
  group_survival       = "Survival stats",
}

for _, s in ipairs(stats) do
  en["stat_" .. s[1]] = s[2]
end

return { en = en }
