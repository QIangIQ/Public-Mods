local mod = get_mod("QIangIQsChatOutput")
local stats = mod:io_dofile("QIangIQsChatOutput/scripts/mods/QIangIQsChatOutput/QIangIQsChatOutput_stats")

local function stat_widgets(section)
  local widgets = {}
  for i = 1, #stats do
    local stat = stats[i]
    if stat.section == section then
      widgets[#widgets + 1] = {
        setting_id    = "stat_" .. stat.id,
        type          = "checkbox",
        default_value = stat.default,
        title         = "stat_" .. stat.id,
      }
    end
  end
  return widgets
end

return {
  name         = "QIangIQ's Chat Output",
  description  = "Sends AnotherScoreboard end-of-mission stats to chat.",
  is_togglable = true,
  options      = {
    widgets = {
      { setting_id = "send_at_end", type = "checkbox", default_value = true,
        title = "send_at_end", tooltip = "send_at_end_tooltip" },
      { setting_id = "send_now_key", type = "keybind", default_value = {},
        title = "send_now_key", tooltip = "send_now_key_tooltip",
        keybind_global = true, keybind_trigger = "pressed",
        keybind_type = "function_call", function_name = "send_now" },
      { setting_id = "show_class_icon", type = "checkbox", default_value = true,
        title = "show_class_icon" },
      { setting_id = "shorten_values", type = "checkbox", default_value = true,
        title = "shorten_values", tooltip = "shorten_values_tooltip" },
      { setting_id = "name_length", type = "numeric", default_value = 3, range = { 1, 20 },
        title = "name_length", tooltip = "name_length_tooltip" },
      { setting_id = "message_delay", type = "numeric", default_value = 1, range = { 0, 5 },
        title = "message_delay", tooltip = "message_delay_tooltip" },
      { setting_id = "group_combat", type = "group", title = "group_combat",
        sub_widgets = stat_widgets("combat") },
      { setting_id = "group_survival", type = "group", title = "group_survival",
        sub_widgets = stat_widgets("survival") },
    },
  },
}
