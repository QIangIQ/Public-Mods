-- mods/QIangIQsChatOutput/scripts/mods/QIangIQsChatOutput/QIangIQsChatOutput.lua
-- Reads AnotherScoreboard's live stat tables (get_stats():defs(), get_stat_data) and posts them to chat.
-- Chat channel capture and the end-of-mission trigger follow the dmgtochat mod.

local mod = get_mod("QIangIQsChatOutput")

local STATS = mod:io_dofile("QIangIQsChatOutput/scripts/mods/QIangIQsChatOutput/QIangIQsChatOutput_stats")

mod._memory = mod:persistent_table("QIangIQsChatOutput")
mod._memory.channel_handle = nil
mod._memory.sent_report    = false

local cutscene_seen = {}
local queue = {}
local queue_timer = 0

mod:hook_safe("StateGameplay", "on_enter", function()
  mod._memory.sent_report = false
  cutscene_seen = {}
  queue = {}
end)

local function get_channel_handle(self, channel_handle)
  mod._memory.channel_handle = channel_handle or self._selected_channel_handle
end

mod:hook_safe("ConstantElementChat", "_on_connect_to_channel",         get_channel_handle)
mod:hook_safe("ConstantElementChat", "_on_disconnect_from_channel",    get_channel_handle)
mod:hook_safe("ConstantElementChat", "_next_connected_channel_handle", get_channel_handle)

local function shorten(value)
  if not mod:get("shorten_values") then
    return string.format("%d", math.floor(value + 0.5))
  end
  local abs = math.abs(value)
  if abs >= 1000000 then
    return string.format("%.1fM", value / 1000000)
  elseif abs >= 1000 then
    return string.format("%.1fK", value / 1000)
  elseif value == math.floor(value) then
    return string.format("%d", value)
  end
  return string.format("%.1f", value)
end

local function enabled_stats()
  local list = {}
  for i = 1, #STATS do
    if mod:get("stat_" .. STATS[i].id) then
      list[#list + 1] = STATS[i]
    end
  end
  return list
end

-- One chat line per enabled stat: "<Label>: <icon><name> <value> ..." sorted best first.
local function build_messages()
  local sb = get_mod("QIangIQsAnotherScoreboard") or get_mod("AnotherScoreboard")
  if not sb or not sb.get_stats then
    return nil
  end
  local scoreboard_stats = sb.get_stats()
  if not scoreboard_stats then
    return nil
  end

  local players = {}
  local name_length = mod:get("name_length")
  for _, player in pairs(Managers.player:players()) do
    if player:is_human_controlled() then
      local icon = ""
      if mod:get("show_class_icon") then
        local profile = player._profile
        local archetype = profile and profile.archetype and profile.archetype.name
        local ui_settings = require("scripts/settings/ui/ui_settings")
        icon = archetype and ui_settings and ui_settings.archetype_font_icon and ui_settings.archetype_font_icon[archetype] or ""
      end
      players[#players + 1] = {
        id   = player:account_id() or player:name(),
        tag  = string.sub(player:name(), 1, name_length),
        icon = icon,
      }
    end
  end
  if #players == 0 then
    return nil
  end

  local messages = {}
  for _, stat in ipairs(enabled_stats()) do
    local data = sb:get_stat_data(stat.id)
    if data then
      local def = scoreboard_stats.def(stat.id)
      local lower_is_better = def and def.dir == "desc"

      local entries = {}
      for _, p in ipairs(players) do
        local entry = data[p.id]
        entries[#entries + 1] = { tag = p.tag, icon = p.icon, value = entry and entry.score or 0 }
      end

      table.sort(entries, function(a, b)
        if a.value ~= b.value then
          if lower_is_better then
            return a.value < b.value
          end
          return a.value > b.value
        end
        return a.tag < b.tag
      end)

      local parts = {}
      for _, e in ipairs(entries) do
        parts[#parts + 1] = string.format("%s%s %s", e.icon, e.tag, shorten(e.value))
      end
      messages[#messages + 1] = string.format(" %s: %s", stat.short, table.concat(parts, " "))
    end
  end

  return messages
end

local function send_report(force)
  if mod._memory.sent_report and not force then
    return
  end
  local chan = mod._memory.channel_handle
  if not chan then
    return
  end

  local messages = build_messages()
  if not messages or #messages == 0 then
    return
  end

  queue = messages
  queue_timer = 0
  mod._memory.sent_report = true
end

function mod.send_now()
  send_report(true)
end

function mod.update(dt)
  if #queue == 0 then
    return
  end
  queue_timer = queue_timer - dt
  if queue_timer > 0 then
    return
  end
  local chan = mod._memory.channel_handle
  if not chan then
    queue = {}
    return
  end
  Managers.chat:send_channel_message(chan, table.remove(queue, 1))
  queue_timer = mod:get("message_delay")
end

mod:hook_safe("CinematicSceneExtension", "setup_from_component", function(self)
  if not mod:get("send_at_end") then
    return
  end
  local name = self._cinematic_name or ""
  if name == "outro_win" or name == "outro_fail" then
    if cutscene_seen[name] then
      send_report(false)
    else
      cutscene_seen[name] = true
    end
  end
end)
