return {
  run = function()
    fassert(rawget(_G, "new_mod"), "`QIangIQsChatOutput` encountered an error loading the Darktide Mod Framework.")

    new_mod("QIangIQsChatOutput", {
      mod_script       = "QIangIQsChatOutput/scripts/mods/QIangIQsChatOutput/QIangIQsChatOutput",
      mod_data         = "QIangIQsChatOutput/scripts/mods/QIangIQsChatOutput/QIangIQsChatOutput_data",
      mod_localization = "QIangIQsChatOutput/scripts/mods/QIangIQsChatOutput/QIangIQsChatOutput_localization",
    })
  end,
  packages = {},
}
